/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import jakarta.el.ELException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.math.RoundingMode;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ELArithmetic
/*     */ {
/*     */   public static final class BigDecimalDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1) {
/*  37 */       return ((BigDecimal)num0).add((BigDecimal)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/*  42 */       if (num instanceof BigDecimal) {
/*  43 */         return num;
/*     */       }
/*  45 */       if (num instanceof BigInteger) {
/*  46 */         return new BigDecimal((BigInteger)num);
/*     */       }
/*  48 */       return new BigDecimal(num.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(String str) {
/*  53 */       return new BigDecimal(str);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number divide(Number num0, Number num1) {
/*  58 */       return ((BigDecimal)num0).divide((BigDecimal)num1, RoundingMode.HALF_UP);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number subtract(Number num0, Number num1) {
/*  63 */       return ((BigDecimal)num0).subtract((BigDecimal)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number mod(Number num0, Number num1) {
/*  68 */       return Double.valueOf(num0.doubleValue() % num1.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number multiply(Number num0, Number num1) {
/*  73 */       return ((BigDecimal)num0).multiply((BigDecimal)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1) {
/*  78 */       return (obj0 instanceof BigDecimal || obj1 instanceof BigDecimal);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class BigIntegerDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1) {
/*  86 */       return ((BigInteger)num0).add((BigInteger)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/*  91 */       if (num instanceof BigInteger) {
/*  92 */         return num;
/*     */       }
/*  94 */       return new BigInteger(num.toString());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(String str) {
/*  99 */       return new BigInteger(str);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number divide(Number num0, Number num1) {
/* 104 */       return (new BigDecimal((BigInteger)num0)).divide(new BigDecimal((BigInteger)num1), RoundingMode.HALF_UP);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number multiply(Number num0, Number num1) {
/* 109 */       return ((BigInteger)num0).multiply((BigInteger)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number mod(Number num0, Number num1) {
/* 114 */       return ((BigInteger)num0).remainder((BigInteger)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number subtract(Number num0, Number num1) {
/* 119 */       return ((BigInteger)num0).subtract((BigInteger)num1);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1) {
/* 124 */       return (obj0 instanceof BigInteger || obj1 instanceof BigInteger);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class DoubleDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1) {
/* 133 */       if (num0 instanceof BigDecimal)
/* 134 */         return ((BigDecimal)num0).add(new BigDecimal(num1.doubleValue())); 
/* 135 */       if (num1 instanceof BigDecimal) {
/* 136 */         return (new BigDecimal(num0.doubleValue())).add((BigDecimal)num1);
/*     */       }
/* 138 */       return Double.valueOf(num0.doubleValue() + num1.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/* 143 */       if (num instanceof Double) {
/* 144 */         return num;
/*     */       }
/* 146 */       if (num instanceof BigInteger) {
/* 147 */         return new BigDecimal((BigInteger)num);
/*     */       }
/* 149 */       return Double.valueOf(num.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(String str) {
/* 154 */       return Double.valueOf(str);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number divide(Number num0, Number num1) {
/* 159 */       return Double.valueOf(num0.doubleValue() / num1.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number mod(Number num0, Number num1) {
/* 164 */       return Double.valueOf(num0.doubleValue() % num1.doubleValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Number subtract(Number num0, Number num1) {
/* 170 */       if (num0 instanceof BigDecimal)
/* 171 */         return ((BigDecimal)num0).subtract(new BigDecimal(num1.doubleValue())); 
/* 172 */       if (num1 instanceof BigDecimal) {
/* 173 */         return (new BigDecimal(num0.doubleValue())).subtract((BigDecimal)num1);
/*     */       }
/* 175 */       return Double.valueOf(num0.doubleValue() - num1.doubleValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Number multiply(Number num0, Number num1) {
/* 181 */       if (num0 instanceof BigDecimal)
/* 182 */         return ((BigDecimal)num0).multiply(new BigDecimal(num1.doubleValue())); 
/* 183 */       if (num1 instanceof BigDecimal) {
/* 184 */         return (new BigDecimal(num0.doubleValue())).multiply((BigDecimal)num1);
/*     */       }
/* 186 */       return Double.valueOf(num0.doubleValue() * num1.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1) {
/* 191 */       return (obj0 instanceof Double || obj1 instanceof Double || obj0 instanceof Float || obj1 instanceof Float || (obj0 instanceof String && 
/* 192 */         ELSupport.isStringFloat((String)obj0)) || (obj1 instanceof String && 
/* 193 */         ELSupport.isStringFloat((String)obj1)));
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class LongDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1) {
/* 201 */       return Long.valueOf(num0.longValue() + num1.longValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/* 206 */       if (num instanceof Long) {
/* 207 */         return num;
/*     */       }
/* 209 */       return Long.valueOf(num.longValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number coerce(String str) {
/* 214 */       return Long.valueOf(str);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number divide(Number num0, Number num1) {
/* 219 */       return Long.valueOf(num0.longValue() / num1.longValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number mod(Number num0, Number num1) {
/* 224 */       return Long.valueOf(num0.longValue() % num1.longValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number subtract(Number num0, Number num1) {
/* 229 */       return Long.valueOf(num0.longValue() - num1.longValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number multiply(Number num0, Number num1) {
/* 234 */       return Long.valueOf(num0.longValue() * num1.longValue());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1) {
/* 239 */       return (obj0 instanceof Long || obj1 instanceof Long);
/*     */     }
/*     */   }
/*     */   
/* 243 */   public static final BigDecimalDelegate BIGDECIMAL = new BigDecimalDelegate();
/*     */   
/* 245 */   public static final BigIntegerDelegate BIGINTEGER = new BigIntegerDelegate();
/*     */   
/* 247 */   public static final DoubleDelegate DOUBLE = new DoubleDelegate();
/*     */   
/* 249 */   public static final LongDelegate LONG = new LongDelegate();
/*     */   
/* 251 */   private static final Long ZERO = Long.valueOf(0L);
/*     */   
/*     */   public static Number add(Object obj0, Object obj1) {
/* 254 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 255 */     if (delegate == null) {
/* 256 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 259 */     Number num0 = delegate.coerce(obj0);
/* 260 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 262 */     return delegate.add(num0, num1);
/*     */   }
/*     */   public static Number mod(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 266 */     if (obj0 == null && obj1 == null) {
/* 267 */       return Long.valueOf(0L);
/*     */     }
/*     */ 
/*     */     
/* 271 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 272 */       delegate = DOUBLE;
/* 273 */     } else if (DOUBLE.matches(obj0, obj1)) {
/* 274 */       delegate = DOUBLE;
/* 275 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 276 */       delegate = BIGINTEGER;
/*     */     } else {
/* 278 */       delegate = LONG;
/*     */     } 
/*     */     
/* 281 */     Number num0 = delegate.coerce(obj0);
/* 282 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 284 */     return delegate.mod(num0, num1);
/*     */   }
/*     */   
/*     */   public static Number subtract(Object obj0, Object obj1) {
/* 288 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 289 */     if (delegate == null) {
/* 290 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 293 */     Number num0 = delegate.coerce(obj0);
/* 294 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 296 */     return delegate.subtract(num0, num1);
/*     */   }
/*     */   public static Number divide(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 300 */     if (obj0 == null && obj1 == null) {
/* 301 */       return ZERO;
/*     */     }
/*     */ 
/*     */     
/* 305 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 306 */       delegate = BIGDECIMAL;
/* 307 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 308 */       delegate = BIGDECIMAL;
/*     */     } else {
/* 310 */       delegate = DOUBLE;
/*     */     } 
/*     */     
/* 313 */     Number num0 = delegate.coerce(obj0);
/* 314 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 316 */     return delegate.divide(num0, num1);
/*     */   }
/*     */   
/*     */   public static Number multiply(Object obj0, Object obj1) {
/* 320 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 321 */     if (delegate == null) {
/* 322 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 325 */     Number num0 = delegate.coerce(obj0);
/* 326 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 328 */     return delegate.multiply(num0, num1);
/*     */   }
/*     */   
/*     */   private static ELArithmetic findDelegate(Object obj0, Object obj1) {
/* 332 */     if (obj0 == null && obj1 == null) {
/* 333 */       return null;
/*     */     }
/*     */     
/* 336 */     if (BIGDECIMAL.matches(obj0, obj1))
/* 337 */       return BIGDECIMAL; 
/* 338 */     if (DOUBLE.matches(obj0, obj1)) {
/* 339 */       if (BIGINTEGER.matches(obj0, obj1)) {
/* 340 */         return BIGDECIMAL;
/*     */       }
/* 342 */       return DOUBLE;
/*     */     } 
/* 344 */     if (BIGINTEGER.matches(obj0, obj1)) {
/* 345 */       return BIGINTEGER;
/*     */     }
/* 347 */     return LONG;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isNumber(Object obj) {
/* 352 */     return (obj != null && isNumberType(obj.getClass()));
/*     */   }
/*     */   
/*     */   public static boolean isNumberType(Class<?> type) {
/* 356 */     return (type == long.class || type == double.class || type == byte.class || type == short.class || type == int.class || type == float.class || Number.class
/* 357 */       .isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract Number add(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */   
/*     */   protected abstract Number multiply(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */   
/*     */   protected abstract Number subtract(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */   
/*     */   protected abstract Number mod(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */   
/*     */   protected abstract Number coerce(Number paramNumber);
/*     */   
/*     */   protected final Number coerce(Object obj) {
/* 376 */     if (isNumber(obj)) {
/* 377 */       return coerce((Number)obj);
/*     */     }
/* 379 */     if (obj == null || "".equals(obj)) {
/* 380 */       return coerce(ZERO);
/*     */     }
/* 382 */     if (obj instanceof String) {
/* 383 */       return coerce((String)obj);
/*     */     }
/* 385 */     if (obj instanceof Character) {
/* 386 */       return coerce(Short.valueOf((short)((Character)obj).charValue()));
/*     */     }
/*     */     
/* 389 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), "Number" }));
/*     */   }
/*     */   
/*     */   protected abstract Number coerce(String paramString);
/*     */   
/*     */   protected abstract Number divide(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */   protected abstract boolean matches(Object paramObject1, Object paramObject2);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\ELArithmetic.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */