/*    */ package org.apache.el.lang;
/*    */ 
/*    */ import jakarta.el.FunctionMapper;
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionMapperFactory
/*    */   extends FunctionMapper
/*    */ {
/* 27 */   protected FunctionMapperImpl memento = null;
/*    */   protected final FunctionMapper target;
/*    */   
/*    */   public FunctionMapperFactory(FunctionMapper mapper) {
/* 31 */     if (mapper == null) {
/* 32 */       throw new NullPointerException(MessageFactory.get("error.noFunctionMapperTarget"));
/*    */     }
/* 34 */     this.target = mapper;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Method resolveFunction(String prefix, String localName) {
/* 40 */     if (this.memento == null) {
/* 41 */       this.memento = new FunctionMapperImpl();
/*    */     }
/* 43 */     Method m = this.target.resolveFunction(prefix, localName);
/* 44 */     if (m != null) {
/* 45 */       this.memento.mapFunction(prefix, localName, m);
/*    */     }
/* 47 */     return m;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void mapFunction(String prefix, String localName, Method method) {
/* 53 */     if (this.memento == null) {
/* 54 */       this.memento = new FunctionMapperImpl();
/*    */     }
/* 56 */     this.memento.mapFunction(prefix, localName, method);
/*    */   }
/*    */ 
/*    */   
/*    */   public FunctionMapper create() {
/* 61 */     return this.memento;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\FunctionMapperFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */