/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import jakarta.el.FunctionMapper;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionMapperImpl
/*     */   extends FunctionMapper
/*     */   implements Externalizable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  36 */   protected ConcurrentMap<String, Function> functions = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   public Method resolveFunction(String prefix, String localName) {
/*  40 */     Function f = this.functions.get(prefix + ":" + prefix);
/*  41 */     if (f == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     return f.getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public void mapFunction(String prefix, String localName, Method m) {
/*  49 */     String key = prefix + ":" + prefix;
/*  50 */     if (m == null) {
/*  51 */       this.functions.remove(key);
/*     */     } else {
/*  53 */       Function f = new Function(prefix, localName, m);
/*  54 */       this.functions.put(key, f);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/*  60 */     out.writeObject(this.functions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/*  66 */     this.functions = (ConcurrentMap<String, Function>)in.readObject();
/*     */   }
/*     */   
/*     */   public static class Function
/*     */     implements Externalizable {
/*     */     protected transient Method m;
/*     */     protected String owner;
/*     */     protected String name;
/*     */     protected String[] types;
/*     */     protected String prefix;
/*     */     protected String localName;
/*     */     
/*     */     public Function(String prefix, String localName, Method m) {
/*  79 */       if (localName == null) {
/*  80 */         throw new NullPointerException(MessageFactory.get("error.nullLocalName"));
/*     */       }
/*  82 */       if (m == null) {
/*  83 */         throw new NullPointerException(MessageFactory.get("error.nullMethod"));
/*     */       }
/*  85 */       this.prefix = prefix;
/*  86 */       this.localName = localName;
/*  87 */       this.m = m;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Function() {}
/*     */ 
/*     */     
/*     */     public void writeExternal(ObjectOutput out) throws IOException {
/*  96 */       out.writeUTF((this.prefix != null) ? this.prefix : "");
/*  97 */       out.writeUTF(this.localName);
/*  98 */       if (this.owner != null && this.name != null && this.types != null) {
/*  99 */         out.writeUTF(this.owner);
/* 100 */         out.writeUTF(this.name);
/* 101 */         out.writeObject(this.types);
/*     */       } else {
/* 103 */         out.writeUTF(this.m.getDeclaringClass().getName());
/* 104 */         out.writeUTF(this.m.getName());
/* 105 */         out.writeObject(ReflectionUtil.toTypeNameArray(this.m.getParameterTypes()));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 112 */       this.prefix = in.readUTF();
/* 113 */       if (this.prefix.isEmpty()) {
/* 114 */         this.prefix = null;
/*     */       }
/* 116 */       this.localName = in.readUTF();
/* 117 */       this.owner = in.readUTF();
/* 118 */       this.name = in.readUTF();
/* 119 */       this.types = (String[])in.readObject();
/*     */     }
/*     */     
/*     */     public Method getMethod() {
/* 123 */       if (this.m == null) {
/*     */         try {
/* 125 */           Class<?> t = ReflectionUtil.forName(this.owner);
/* 126 */           Class<?>[] p = ReflectionUtil.toTypeArray(this.types);
/* 127 */           this.m = t.getMethod(this.name, p);
/* 128 */         } catch (Exception exception) {}
/*     */       }
/*     */ 
/*     */       
/* 132 */       return this.m;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 137 */       if (obj instanceof Function) {
/* 138 */         return (hashCode() == obj.hashCode());
/*     */       }
/* 140 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 145 */       return (this.prefix + this.prefix).hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\FunctionMapperImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */