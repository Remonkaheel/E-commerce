/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELResolver;
/*     */ import jakarta.el.EvaluationListener;
/*     */ import jakarta.el.FunctionMapper;
/*     */ import jakarta.el.ImportHandler;
/*     */ import jakarta.el.VariableMapper;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EvaluationContext
/*     */   extends ELContext
/*     */ {
/*     */   private final ELContext elContext;
/*     */   private final FunctionMapper fnMapper;
/*     */   private final VariableMapper varMapper;
/*     */   private LambdaExpressionNestedState lambdaExpressionNestedState;
/*     */   
/*     */   public EvaluationContext(ELContext elContext, FunctionMapper fnMapper, VariableMapper varMapper) {
/*  43 */     this.elContext = elContext;
/*  44 */     this.fnMapper = fnMapper;
/*  45 */     this.varMapper = varMapper;
/*     */   }
/*     */   
/*     */   public ELContext getELContext() {
/*  49 */     return this.elContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionMapper getFunctionMapper() {
/*  54 */     return this.fnMapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public VariableMapper getVariableMapper() {
/*  59 */     return this.varMapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContext(Class<?> key) {
/*  64 */     return this.elContext.getContext(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public ELResolver getELResolver() {
/*  69 */     return this.elContext.getELResolver();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPropertyResolved() {
/*  74 */     return this.elContext.isPropertyResolved();
/*     */   }
/*     */ 
/*     */   
/*     */   public void putContext(Class<?> key, Object contextObject) {
/*  79 */     this.elContext.putContext(key, contextObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertyResolved(boolean resolved) {
/*  84 */     this.elContext.setPropertyResolved(resolved);
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/*  89 */     return this.elContext.getLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocale(Locale locale) {
/*  94 */     this.elContext.setLocale(locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertyResolved(Object base, Object property) {
/*  99 */     this.elContext.setPropertyResolved(base, property);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImportHandler getImportHandler() {
/* 104 */     return this.elContext.getImportHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addEvaluationListener(EvaluationListener listener) {
/* 109 */     this.elContext.addEvaluationListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<EvaluationListener> getEvaluationListeners() {
/* 114 */     return this.elContext.getEvaluationListeners();
/*     */   }
/*     */ 
/*     */   
/*     */   public void notifyBeforeEvaluation(String expression) {
/* 119 */     this.elContext.notifyBeforeEvaluation(expression);
/*     */   }
/*     */ 
/*     */   
/*     */   public void notifyAfterEvaluation(String expression) {
/* 124 */     this.elContext.notifyAfterEvaluation(expression);
/*     */   }
/*     */ 
/*     */   
/*     */   public void notifyPropertyResolved(Object base, Object property) {
/* 129 */     this.elContext.notifyPropertyResolved(base, property);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLambdaArgument(String name) {
/* 134 */     return this.elContext.isLambdaArgument(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getLambdaArgument(String name) {
/* 139 */     return this.elContext.getLambdaArgument(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void enterLambdaScope(Map<String, Object> arguments) {
/* 144 */     this.elContext.enterLambdaScope(arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public void exitLambdaScope() {
/* 149 */     this.elContext.exitLambdaScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T convertToType(Object obj, Class<T> type) {
/* 154 */     return (T)this.elContext.convertToType(obj, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LambdaExpressionNestedState getLambdaExpressionNestedState() {
/* 162 */     if (this.lambdaExpressionNestedState != null)
/*     */     {
/*     */       
/* 165 */       return this.lambdaExpressionNestedState;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (this.elContext instanceof EvaluationContext) {
/* 172 */       return ((EvaluationContext)this.elContext).getLambdaExpressionNestedState();
/*     */     }
/*     */     
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLambdaExpressionNestedState(LambdaExpressionNestedState lambdaExpressionNestedState) {
/* 180 */     if (this.lambdaExpressionNestedState != null)
/*     */     {
/* 182 */       throw new IllegalStateException(MessageFactory.get("error.lambda.wrongNestedState"));
/*     */     }
/*     */     
/* 185 */     this.lambdaExpressionNestedState = lambdaExpressionNestedState;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\EvaluationContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */