/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.FunctionMapper;
/*     */ import jakarta.el.MethodExpression;
/*     */ import jakarta.el.ValueExpression;
/*     */ import jakarta.el.VariableMapper;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import org.apache.el.MethodExpressionImpl;
/*     */ import org.apache.el.MethodExpressionLiteral;
/*     */ import org.apache.el.ValueExpressionImpl;
/*     */ import org.apache.el.parser.AstCompositeExpression;
/*     */ import org.apache.el.parser.AstFunction;
/*     */ import org.apache.el.parser.ELParser;
/*     */ import org.apache.el.parser.Node;
/*     */ import org.apache.el.parser.NodeVisitor;
/*     */ import org.apache.el.util.ConcurrentCache;
/*     */ import org.apache.el.util.ExceptionUtils;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExpressionBuilder
/*     */   implements NodeVisitor
/*     */ {
/*  49 */   private static final SynchronizedStack<ELParser> parserCache = new SynchronizedStack<>();
/*     */ 
/*     */   
/*     */   private static final int CACHE_SIZE;
/*     */ 
/*     */   
/*     */   static {
/*  56 */     if (System.getSecurityManager() == null) {
/*  57 */       cacheSizeStr = System.getProperty("org.apache.el.ExpressionBuilder.CACHE_SIZE", "5000");
/*     */     } else {
/*     */       
/*  60 */       cacheSizeStr = AccessController.<String>doPrivileged(() -> System.getProperty("org.apache.el.ExpressionBuilder.CACHE_SIZE", "5000"));
/*     */     } 
/*  62 */     CACHE_SIZE = Integer.parseInt(cacheSizeStr);
/*     */   } private static final String CACHE_SIZE_PROP = "org.apache.el.ExpressionBuilder.CACHE_SIZE"; static {
/*     */     String cacheSizeStr;
/*  65 */   } private static final ConcurrentCache<String, Node> expressionCache = new ConcurrentCache(CACHE_SIZE);
/*     */   
/*     */   private FunctionMapper fnMapper;
/*     */   
/*     */   private VariableMapper varMapper;
/*     */   
/*     */   private final String expression;
/*     */   
/*     */   public ExpressionBuilder(String expression, ELContext ctx) throws ELException {
/*  74 */     this.expression = expression;
/*     */     
/*  76 */     FunctionMapper ctxFn = ctx.getFunctionMapper();
/*  77 */     VariableMapper ctxVar = ctx.getVariableMapper();
/*     */     
/*  79 */     if (ctxFn != null) {
/*  80 */       this.fnMapper = new FunctionMapperFactory(ctxFn);
/*     */     }
/*  82 */     if (ctxVar != null) {
/*  83 */       this.varMapper = new VariableMapperFactory(ctxVar);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Node createNode(String expr) throws ELException {
/*  88 */     return createNodeInternal(expr);
/*     */   }
/*     */   
/*     */   private static Node createNodeInternal(String expr) throws ELException {
/*  92 */     if (expr == null) {
/*  93 */       throw new ELException(MessageFactory.get("error.null"));
/*     */     }
/*     */     
/*  96 */     Node node = (Node)expressionCache.get(expr);
/*  97 */     if (node == null) {
/*  98 */       ELParser parser = parserCache.pop();
/*     */       try {
/* 100 */         if (parser == null) {
/* 101 */           parser = new ELParser(new StringReader(expr));
/*     */         } else {
/* 103 */           parser.ReInit(new StringReader(expr));
/*     */         } 
/* 105 */         AstCompositeExpression astCompositeExpression = parser.CompositeExpression();
/*     */ 
/*     */         
/* 108 */         int numChildren = astCompositeExpression.jjtGetNumChildren();
/* 109 */         if (numChildren == 1) {
/* 110 */           node = astCompositeExpression.jjtGetChild(0);
/*     */         } else {
/* 112 */           Class<?> type = null;
/*     */           
/* 114 */           for (int i = 0; i < numChildren; i++) {
/* 115 */             Node child = node.jjtGetChild(i);
/* 116 */             if (!(child instanceof org.apache.el.parser.AstLiteralExpression))
/*     */             {
/*     */               
/* 119 */               if (type == null) {
/* 120 */                 type = child.getClass();
/*     */               }
/* 122 */               else if (!type.equals(child.getClass())) {
/* 123 */                 throw new ELException(MessageFactory.get("error.mixed", new Object[] { expr }));
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 129 */         if (node instanceof org.apache.el.parser.AstDeferredExpression || node instanceof org.apache.el.parser.AstDynamicExpression) {
/* 130 */           node = node.jjtGetChild(0);
/*     */         }
/* 132 */         expressionCache.put(expr, node);
/* 133 */       } catch (Throwable t) {
/* 134 */         ExceptionUtils.handleThrowable(t);
/* 135 */         throw new ELException(MessageFactory.get("error.parseFail", new Object[] { expr }), t);
/*     */       } finally {
/* 137 */         if (parser != null) {
/* 138 */           parserCache.push(parser);
/*     */         }
/*     */       } 
/*     */     } 
/* 142 */     return node;
/*     */   }
/*     */   
/*     */   private void prepare(Node node) throws ELException {
/*     */     try {
/* 147 */       node.accept(this);
/* 148 */     } catch (Exception e) {
/* 149 */       if (e instanceof ELException) {
/* 150 */         throw (ELException)e;
/*     */       }
/* 152 */       throw new ELException(e);
/*     */     } 
/*     */     
/* 155 */     if (this.fnMapper instanceof FunctionMapperFactory) {
/* 156 */       this.fnMapper = ((FunctionMapperFactory)this.fnMapper).create();
/*     */     }
/* 158 */     if (this.varMapper instanceof VariableMapperFactory) {
/* 159 */       this.varMapper = ((VariableMapperFactory)this.varMapper).create();
/*     */     }
/*     */   }
/*     */   
/*     */   private Node build() throws ELException {
/* 164 */     Node n = createNodeInternal(this.expression);
/* 165 */     prepare(n);
/* 166 */     if (n instanceof org.apache.el.parser.AstDeferredExpression || n instanceof org.apache.el.parser.AstDynamicExpression) {
/* 167 */       n = n.jjtGetChild(0);
/*     */     }
/* 169 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Node node) throws ELException {
/* 174 */     if (node instanceof AstFunction) {
/*     */       
/* 176 */       AstFunction funcNode = (AstFunction)node;
/*     */       
/* 178 */       Method m = null;
/*     */       
/* 180 */       if (this.fnMapper != null) {
/* 181 */         m = this.fnMapper.resolveFunction(funcNode.getPrefix(), funcNode.getLocalName());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       if (m == null && this.varMapper != null && funcNode.getPrefix().isEmpty()) {
/* 188 */         this.varMapper.resolveVariable(funcNode.getLocalName());
/*     */         
/*     */         return;
/*     */       } 
/* 192 */       if (this.fnMapper == null) {
/* 193 */         throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */       }
/*     */       
/* 196 */       if (m == null) {
/* 197 */         throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] { funcNode.getOutputName() }));
/*     */       }
/*     */       
/* 200 */       int methodParameterCount = (m.getParameterTypes()).length;
/*     */       
/* 202 */       int inputParameterCount = node.jjtGetChild(0).jjtGetNumChildren();
/* 203 */       if ((m.isVarArgs() && inputParameterCount < methodParameterCount - 1) || (
/* 204 */         !m.isVarArgs() && inputParameterCount != methodParameterCount)) {
/* 205 */         throw new ELException(MessageFactory.get("error.fnMapper.paramcount", new Object[] { funcNode.getOutputName(), "" + methodParameterCount, "" + node
/* 206 */                 .jjtGetChild(0).jjtGetNumChildren() }));
/*     */       }
/* 208 */     } else if (node instanceof org.apache.el.parser.AstIdentifier && this.varMapper != null) {
/* 209 */       String variable = node.getImage();
/*     */ 
/*     */       
/* 212 */       this.varMapper.resolveVariable(variable);
/*     */     } 
/*     */   }
/*     */   
/*     */   public ValueExpression createValueExpression(Class<?> expectedType) throws ELException {
/* 217 */     Node n = build();
/* 218 */     return (ValueExpression)new ValueExpressionImpl(this.expression, n, this.fnMapper, this.varMapper, expectedType);
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodExpression createMethodExpression(Class<?> expectedReturnType, Class<?>[] expectedParamTypes) throws ELException {
/* 223 */     Node n = build();
/* 224 */     if (!n.isParametersProvided() && expectedParamTypes == null) {
/* 225 */       throw new NullPointerException(MessageFactory.get("error.method.nullParms"));
/*     */     }
/* 227 */     if (n instanceof org.apache.el.parser.AstValue || n instanceof org.apache.el.parser.AstIdentifier) {
/* 228 */       return (MethodExpression)new MethodExpressionImpl(this.expression, n, this.fnMapper, this.varMapper, expectedReturnType, expectedParamTypes);
/*     */     }
/* 230 */     if (n instanceof org.apache.el.parser.AstLiteralExpression) {
/* 231 */       return (MethodExpression)new MethodExpressionLiteral(this.expression, expectedReturnType, expectedParamTypes);
/*     */     }
/* 233 */     throw new ELException(MessageFactory.get("error.invalidMethodExpression", new Object[] { this.expression }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SynchronizedStack<T>
/*     */   {
/*     */     public static final int DEFAULT_SIZE = 128;
/*     */ 
/*     */     
/*     */     private static final int DEFAULT_LIMIT = -1;
/*     */ 
/*     */     
/*     */     private int size;
/*     */ 
/*     */     
/*     */     private final int limit;
/*     */ 
/*     */     
/* 252 */     private int index = -1;
/*     */     
/*     */     private Object[] stack;
/*     */ 
/*     */     
/*     */     SynchronizedStack() {
/* 258 */       this(128, -1);
/*     */     }
/*     */     
/*     */     SynchronizedStack(int size, int limit) {
/* 262 */       this.size = size;
/* 263 */       this.limit = limit;
/* 264 */       this.stack = new Object[size];
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized boolean push(T obj) {
/* 269 */       this.index++;
/* 270 */       if (this.index == this.size) {
/* 271 */         if (this.limit == -1 || this.size < this.limit) {
/* 272 */           expand();
/*     */         } else {
/* 274 */           this.index--;
/* 275 */           return false;
/*     */         } 
/*     */       }
/* 278 */       this.stack[this.index] = obj;
/* 279 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized T pop() {
/* 284 */       if (this.index == -1) {
/* 285 */         return null;
/*     */       }
/* 287 */       T result = (T)this.stack[this.index];
/* 288 */       this.stack[this.index--] = null;
/* 289 */       return result;
/*     */     }
/*     */     
/*     */     private void expand() {
/* 293 */       int newSize = this.size * 2;
/* 294 */       if (this.limit != -1 && newSize > this.limit) {
/* 295 */         newSize = this.limit;
/*     */       }
/* 297 */       Object[] newStack = new Object[newSize];
/* 298 */       System.arraycopy(this.stack, 0, newStack, 0, this.size);
/*     */ 
/*     */ 
/*     */       
/* 302 */       this.stack = newStack;
/* 303 */       this.size = newSize;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\ExpressionBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */