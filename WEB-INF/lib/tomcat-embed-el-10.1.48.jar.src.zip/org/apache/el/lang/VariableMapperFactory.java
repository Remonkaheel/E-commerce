/*    */ package org.apache.el.lang;
/*    */ 
/*    */ import jakarta.el.ValueExpression;
/*    */ import jakarta.el.VariableMapper;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableMapperFactory
/*    */   extends VariableMapper
/*    */ {
/*    */   private final VariableMapper target;
/*    */   private VariableMapper momento;
/*    */   
/*    */   public VariableMapperFactory(VariableMapper target) {
/* 30 */     if (target == null) {
/* 31 */       throw new NullPointerException(MessageFactory.get("error.noVariableMapperTarget"));
/*    */     }
/* 33 */     this.target = target;
/*    */   }
/*    */   
/*    */   public VariableMapper create() {
/* 37 */     return this.momento;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueExpression resolveVariable(String variable) {
/* 42 */     ValueExpression expr = this.target.resolveVariable(variable);
/* 43 */     if (expr != null) {
/* 44 */       if (this.momento == null) {
/* 45 */         this.momento = new VariableMapperImpl();
/*    */       }
/* 47 */       this.momento.setVariable(variable, expr);
/*    */     } 
/* 49 */     return expr;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueExpression setVariable(String variable, ValueExpression expression) {
/* 54 */     throw new UnsupportedOperationException(MessageFactory.get("error.cannotSetVariables"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\VariableMapperFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */