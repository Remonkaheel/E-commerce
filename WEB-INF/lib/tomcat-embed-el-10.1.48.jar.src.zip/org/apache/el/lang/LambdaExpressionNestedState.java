/*    */ package org.apache.el.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LambdaExpressionNestedState
/*    */ {
/* 30 */   private int nestingCount = 0;
/*    */   private boolean hasFormalParameters = false;
/*    */   
/*    */   public void incrementNestingCount() {
/* 34 */     this.nestingCount++;
/*    */   }
/*    */   
/*    */   public int getNestingCount() {
/* 38 */     return this.nestingCount;
/*    */   }
/*    */   
/*    */   public void setHasFormalParameters() {
/* 42 */     this.hasFormalParameters = true;
/*    */   }
/*    */   
/*    */   public boolean getHasFormalParameters() {
/* 46 */     return this.hasFormalParameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\LambdaExpressionNestedState.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */