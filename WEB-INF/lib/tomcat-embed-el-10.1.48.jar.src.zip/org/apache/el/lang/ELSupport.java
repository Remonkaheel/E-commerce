/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.LambdaExpression;
/*     */ import java.beans.PropertyEditor;
/*     */ import java.beans.PropertyEditorManager;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.security.AccessController;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.el.util.ExceptionUtils;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ELSupport
/*     */ {
/*  47 */   private static final Long ZERO = Long.valueOf(0L);
/*     */   
/*     */   protected static final boolean COERCE_TO_ZERO;
/*     */ 
/*     */   
/*     */   static {
/*  53 */     if (System.getSecurityManager() != null) {
/*  54 */       coerceToZeroStr = AccessController.<String>doPrivileged(() -> System.getProperty("org.apache.el.parser.COERCE_TO_ZERO", "false"));
/*     */     } else {
/*     */       
/*  57 */       coerceToZeroStr = System.getProperty("org.apache.el.parser.COERCE_TO_ZERO", "false");
/*     */     } 
/*  59 */     COERCE_TO_ZERO = Boolean.parseBoolean(coerceToZeroStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     String coerceToZeroStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compare(ELContext ctx, Object obj0, Object obj1) throws ELException {
/*  95 */     if (obj0 == obj1 || equals(ctx, obj0, obj1)) {
/*  96 */       return 0;
/*     */     }
/*  98 */     if (isBigDecimalOp(obj0, obj1)) {
/*  99 */       BigDecimal bd0 = (BigDecimal)coerceToNumber(ctx, obj0, BigDecimal.class);
/* 100 */       BigDecimal bd1 = (BigDecimal)coerceToNumber(ctx, obj1, BigDecimal.class);
/* 101 */       return bd0.compareTo(bd1);
/*     */     } 
/* 103 */     if (isDoubleOp(obj0, obj1)) {
/* 104 */       Double d0 = (Double)coerceToNumber(ctx, obj0, Double.class);
/* 105 */       Double d1 = (Double)coerceToNumber(ctx, obj1, Double.class);
/* 106 */       return d0.compareTo(d1);
/*     */     } 
/* 108 */     if (isBigIntegerOp(obj0, obj1)) {
/* 109 */       BigInteger bi0 = (BigInteger)coerceToNumber(ctx, obj0, BigInteger.class);
/* 110 */       BigInteger bi1 = (BigInteger)coerceToNumber(ctx, obj1, BigInteger.class);
/* 111 */       return bi0.compareTo(bi1);
/*     */     } 
/* 113 */     if (isLongOp(obj0, obj1)) {
/* 114 */       Long l0 = (Long)coerceToNumber(ctx, obj0, Long.class);
/* 115 */       Long l1 = (Long)coerceToNumber(ctx, obj1, Long.class);
/* 116 */       return l0.compareTo(l1);
/*     */     } 
/* 118 */     if (obj0 instanceof String || obj1 instanceof String) {
/* 119 */       return coerceToString(ctx, obj0).compareTo(coerceToString(ctx, obj1));
/*     */     }
/* 121 */     if (obj0 instanceof Comparable) {
/*     */       
/* 123 */       Comparable<Object> comparable = (Comparable<Object>)obj0;
/* 124 */       return (obj1 != null) ? comparable.compareTo(obj1) : 1;
/*     */     } 
/* 126 */     if (obj1 instanceof Comparable) {
/*     */       
/* 128 */       Comparable<Object> comparable = (Comparable<Object>)obj1;
/* 129 */       return (obj0 != null) ? -comparable.compareTo((T)obj0) : -1;
/*     */     } 
/* 131 */     throw new ELException(MessageFactory.get("error.compare", new Object[] { obj0, obj1 }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(ELContext ctx, Object obj0, Object obj1) throws ELException {
/* 156 */     if (obj0 == obj1)
/* 157 */       return true; 
/* 158 */     if (obj0 == null || obj1 == null)
/* 159 */       return false; 
/* 160 */     if (isBigDecimalOp(obj0, obj1)) {
/* 161 */       BigDecimal bd0 = (BigDecimal)coerceToNumber(ctx, obj0, BigDecimal.class);
/* 162 */       BigDecimal bd1 = (BigDecimal)coerceToNumber(ctx, obj1, BigDecimal.class);
/* 163 */       return bd0.equals(bd1);
/* 164 */     }  if (isDoubleOp(obj0, obj1)) {
/* 165 */       Double d0 = (Double)coerceToNumber(ctx, obj0, Double.class);
/* 166 */       Double d1 = (Double)coerceToNumber(ctx, obj1, Double.class);
/* 167 */       return d0.equals(d1);
/* 168 */     }  if (isBigIntegerOp(obj0, obj1)) {
/* 169 */       BigInteger bi0 = (BigInteger)coerceToNumber(ctx, obj0, BigInteger.class);
/* 170 */       BigInteger bi1 = (BigInteger)coerceToNumber(ctx, obj1, BigInteger.class);
/* 171 */       return bi0.equals(bi1);
/* 172 */     }  if (isLongOp(obj0, obj1)) {
/* 173 */       Long l0 = (Long)coerceToNumber(ctx, obj0, Long.class);
/* 174 */       Long l1 = (Long)coerceToNumber(ctx, obj1, Long.class);
/* 175 */       return l0.equals(l1);
/* 176 */     }  if (obj0 instanceof Boolean || obj1 instanceof Boolean)
/* 177 */       return coerceToBoolean(ctx, obj0, false).equals(coerceToBoolean(ctx, obj1, false)); 
/* 178 */     if (obj0.getClass().isEnum())
/* 179 */       return obj0.equals(coerceToEnum(ctx, obj1, obj0.getClass())); 
/* 180 */     if (obj1.getClass().isEnum())
/* 181 */       return obj1.equals(coerceToEnum(ctx, obj0, obj1.getClass())); 
/* 182 */     if (obj0 instanceof String || obj1 instanceof String) {
/* 183 */       int lexCompare = coerceToString(ctx, obj0).compareTo(coerceToString(ctx, obj1));
/* 184 */       return (lexCompare == 0);
/*     */     } 
/* 186 */     return obj0.equals(obj1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enum<?> coerceToEnum(ELContext ctx, Object obj, Class<Enum<?>> type) {
/*     */     Enum<?> result;
/* 198 */     if (ctx != null) {
/* 199 */       boolean originalIsPropertyResolved = ctx.isPropertyResolved();
/*     */       try {
/* 201 */         Object object = ctx.getELResolver().convertToType(ctx, obj, type);
/* 202 */         if (ctx.isPropertyResolved()) {
/* 203 */           return (Enum)object;
/*     */         }
/*     */       } finally {
/* 206 */         ctx.setPropertyResolved(originalIsPropertyResolved);
/*     */       } 
/*     */     } 
/*     */     
/* 210 */     if (obj == null || "".equals(obj)) {
/* 211 */       return null;
/*     */     }
/* 213 */     if (type.isAssignableFrom(obj.getClass())) {
/* 214 */       return (Enum)obj;
/*     */     }
/*     */     
/* 217 */     if (!(obj instanceof String)) {
/* 218 */       throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), type }));
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 223 */       result = Enum.valueOf(type, (String)obj);
/* 224 */     } catch (IllegalArgumentException iae) {
/* 225 */       throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), type }));
/*     */     } 
/* 227 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean coerceToBoolean(ELContext ctx, Object obj, boolean primitive) throws ELException {
/* 243 */     if (ctx != null) {
/* 244 */       boolean originalIsPropertyResolved = ctx.isPropertyResolved();
/*     */       try {
/* 246 */         Boolean result = (Boolean)ctx.getELResolver().convertToType(ctx, obj, Boolean.class);
/* 247 */         if (ctx.isPropertyResolved()) {
/* 248 */           return result;
/*     */         }
/*     */       } finally {
/* 251 */         ctx.setPropertyResolved(originalIsPropertyResolved);
/*     */       } 
/*     */     } 
/*     */     
/* 255 */     if (!COERCE_TO_ZERO && !primitive && 
/* 256 */       obj == null) {
/* 257 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 261 */     if (obj == null || "".equals(obj)) {
/* 262 */       return Boolean.FALSE;
/*     */     }
/* 264 */     if (obj instanceof Boolean) {
/* 265 */       return (Boolean)obj;
/*     */     }
/* 267 */     if (obj instanceof String) {
/* 268 */       return Boolean.valueOf((String)obj);
/*     */     }
/*     */     
/* 271 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), Boolean.class }));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Character coerceToCharacter(ELContext ctx, Object obj) throws ELException {
/* 276 */     if (ctx != null) {
/* 277 */       boolean originalIsPropertyResolved = ctx.isPropertyResolved();
/*     */       try {
/* 279 */         Character result = (Character)ctx.getELResolver().convertToType(ctx, obj, Character.class);
/* 280 */         if (ctx.isPropertyResolved()) {
/* 281 */           return result;
/*     */         }
/*     */       } finally {
/* 284 */         ctx.setPropertyResolved(originalIsPropertyResolved);
/*     */       } 
/*     */     } 
/*     */     
/* 288 */     if (obj == null || "".equals(obj)) {
/* 289 */       return Character.valueOf(false);
/*     */     }
/* 291 */     if (obj instanceof String) {
/* 292 */       return Character.valueOf(((String)obj).charAt(0));
/*     */     }
/* 294 */     if (ELArithmetic.isNumber(obj)) {
/* 295 */       return Character.valueOf((char)((Number)obj).shortValue());
/*     */     }
/* 297 */     Class<?> objType = obj.getClass();
/* 298 */     if (obj instanceof Character) {
/* 299 */       return (Character)obj;
/*     */     }
/*     */     
/* 302 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, objType, Character.class }));
/*     */   }
/*     */   
/*     */   protected static Number coerceToNumber(Number number, Class<?> type) throws ELException {
/* 306 */     if (long.class == type || Long.class.equals(type)) {
/* 307 */       return Long.valueOf(number.longValue());
/*     */     }
/* 309 */     if (double.class == type || Double.class.equals(type)) {
/* 310 */       return Double.valueOf(number.doubleValue());
/*     */     }
/* 312 */     if (int.class == type || Integer.class.equals(type)) {
/* 313 */       return Integer.valueOf(number.intValue());
/*     */     }
/* 315 */     if (BigInteger.class.equals(type)) {
/* 316 */       if (number instanceof BigDecimal) {
/* 317 */         return ((BigDecimal)number).toBigInteger();
/*     */       }
/* 319 */       if (number instanceof BigInteger) {
/* 320 */         return number;
/*     */       }
/* 322 */       return BigInteger.valueOf(number.longValue());
/*     */     } 
/* 324 */     if (BigDecimal.class.equals(type)) {
/* 325 */       if (number instanceof BigDecimal) {
/* 326 */         return number;
/*     */       }
/* 328 */       if (number instanceof BigInteger) {
/* 329 */         return new BigDecimal((BigInteger)number);
/*     */       }
/* 331 */       return new BigDecimal(number.doubleValue());
/*     */     } 
/* 333 */     if (byte.class == type || Byte.class.equals(type)) {
/* 334 */       return Byte.valueOf(number.byteValue());
/*     */     }
/* 336 */     if (short.class == type || Short.class.equals(type)) {
/* 337 */       return Short.valueOf(number.shortValue());
/*     */     }
/* 339 */     if (float.class == type || Float.class.equals(type)) {
/* 340 */       return Float.valueOf(number.floatValue());
/*     */     }
/* 342 */     if (Number.class.equals(type)) {
/* 343 */       return number;
/*     */     }
/*     */     
/* 346 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { number, number.getClass(), type }));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Number coerceToNumber(ELContext ctx, Object obj, Class<?> type) throws ELException {
/* 351 */     if (ctx != null) {
/* 352 */       boolean originalIsPropertyResolved = ctx.isPropertyResolved();
/*     */       try {
/* 354 */         Object result = ctx.getELResolver().convertToType(ctx, obj, type);
/* 355 */         if (ctx.isPropertyResolved()) {
/* 356 */           return (Number)result;
/*     */         }
/*     */       } finally {
/* 359 */         ctx.setPropertyResolved(originalIsPropertyResolved);
/*     */       } 
/*     */     } 
/*     */     
/* 363 */     if (!COERCE_TO_ZERO && 
/* 364 */       obj == null && !type.isPrimitive()) {
/* 365 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 369 */     if (obj == null || "".equals(obj)) {
/* 370 */       return coerceToNumber(ZERO, type);
/*     */     }
/* 372 */     if (obj instanceof String) {
/* 373 */       return coerceToNumber((String)obj, type);
/*     */     }
/* 375 */     if (ELArithmetic.isNumber(obj)) {
/* 376 */       return coerceToNumber((Number)obj, type);
/*     */     }
/*     */     
/* 379 */     if (obj instanceof Character) {
/* 380 */       return coerceToNumber(Short.valueOf((short)((Character)obj).charValue()), type);
/*     */     }
/*     */     
/* 383 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), type }));
/*     */   }
/*     */   
/*     */   protected static Number coerceToNumber(String val, Class<?> type) throws ELException {
/* 387 */     if (long.class == type || Long.class.equals(type)) {
/*     */       try {
/* 389 */         return Long.valueOf(val);
/* 390 */       } catch (NumberFormatException nfe) {
/* 391 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 394 */     if (int.class == type || Integer.class.equals(type)) {
/*     */       try {
/* 396 */         return Integer.valueOf(val);
/* 397 */       } catch (NumberFormatException nfe) {
/* 398 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 401 */     if (double.class == type || Double.class.equals(type)) {
/*     */       try {
/* 403 */         return Double.valueOf(val);
/* 404 */       } catch (NumberFormatException nfe) {
/* 405 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 408 */     if (BigInteger.class.equals(type)) {
/*     */       try {
/* 410 */         return new BigInteger(val);
/* 411 */       } catch (NumberFormatException nfe) {
/* 412 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 415 */     if (BigDecimal.class.equals(type)) {
/*     */       try {
/* 417 */         return new BigDecimal(val);
/* 418 */       } catch (NumberFormatException nfe) {
/* 419 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 422 */     if (byte.class == type || Byte.class.equals(type)) {
/*     */       try {
/* 424 */         return Byte.valueOf(val);
/* 425 */       } catch (NumberFormatException nfe) {
/* 426 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 429 */     if (short.class == type || Short.class.equals(type)) {
/*     */       try {
/* 431 */         return Short.valueOf(val);
/* 432 */       } catch (NumberFormatException nfe) {
/* 433 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/* 436 */     if (float.class == type || Float.class.equals(type)) {
/*     */       try {
/* 438 */         return Float.valueOf(val);
/* 439 */       } catch (NumberFormatException nfe) {
/* 440 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */       } 
/*     */     }
/*     */     
/* 444 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { val, String.class, type }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String coerceToString(ELContext ctx, Object obj) {
/* 457 */     if (ctx != null) {
/* 458 */       boolean originalIsPropertyResolved = ctx.isPropertyResolved();
/*     */       try {
/* 460 */         String result = (String)ctx.getELResolver().convertToType(ctx, obj, String.class);
/* 461 */         if (ctx.isPropertyResolved()) {
/* 462 */           return result;
/*     */         }
/*     */       } finally {
/* 465 */         ctx.setPropertyResolved(originalIsPropertyResolved);
/*     */       } 
/*     */     } 
/*     */     
/* 469 */     if (obj == null)
/* 470 */       return ""; 
/* 471 */     if (obj instanceof String)
/* 472 */       return (String)obj; 
/* 473 */     if (obj instanceof Enum) {
/* 474 */       return ((Enum)obj).name();
/*     */     }
/*     */     try {
/* 477 */       return obj.toString();
/* 478 */     } catch (ELException e) {
/*     */       
/* 480 */       throw e;
/* 481 */     } catch (Throwable t) {
/* 482 */       ExceptionUtils.handleThrowable(t);
/* 483 */       throw new ELException(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T coerceToType(ELContext ctx, Object obj, Class<T> type) throws ELException {
/* 490 */     if (ctx != null) {
/* 491 */       boolean originalIsPropertyResolved = ctx.isPropertyResolved();
/*     */       try {
/* 493 */         T result = (T)ctx.getELResolver().convertToType(ctx, obj, type);
/* 494 */         if (ctx.isPropertyResolved()) {
/* 495 */           return result;
/*     */         }
/*     */       } finally {
/* 498 */         ctx.setPropertyResolved(originalIsPropertyResolved);
/*     */       } 
/*     */     } 
/*     */     
/* 502 */     if (type == null || Object.class.equals(type) || (obj != null && type.isAssignableFrom(obj.getClass()))) {
/*     */       
/* 504 */       T result = (T)obj;
/* 505 */       return result;
/*     */     } 
/*     */     
/* 508 */     if (!COERCE_TO_ZERO && 
/* 509 */       obj == null && !type.isPrimitive() && !String.class.isAssignableFrom(type)) {
/* 510 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 514 */     if (String.class.equals(type))
/*     */     {
/* 516 */       return (T)coerceToString(ctx, obj);
/*     */     }
/*     */     
/* 519 */     if (ELArithmetic.isNumberType(type))
/*     */     {
/* 521 */       return (T)coerceToNumber(ctx, obj, type);
/*     */     }
/*     */     
/* 524 */     if (Character.class.equals(type) || char.class == type)
/*     */     {
/* 526 */       return (T)coerceToCharacter(ctx, obj);
/*     */     }
/*     */     
/* 529 */     if (Boolean.class.equals(type) || boolean.class == type)
/*     */     {
/* 531 */       return (T)coerceToBoolean(ctx, obj, (boolean.class == type));
/*     */     }
/*     */     
/* 534 */     if (type.isEnum())
/*     */     {
/* 536 */       return (T)coerceToEnum(ctx, obj, type);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 541 */     if (obj == null) {
/* 542 */       return null;
/*     */     }
/* 544 */     if (obj instanceof String) {
/* 545 */       String str = (String)obj;
/* 546 */       PropertyEditor editor = PropertyEditorManager.findEditor(type);
/* 547 */       if (editor == null) {
/* 548 */         if (str.isEmpty()) {
/* 549 */           return null;
/*     */         }
/* 551 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), type }));
/*     */       } 
/*     */       try {
/* 554 */         editor.setAsText(str);
/*     */         
/* 556 */         T result = (T)editor.getValue();
/* 557 */         return result;
/* 558 */       } catch (RuntimeException e) {
/* 559 */         if (str.isEmpty()) {
/* 560 */           return null;
/*     */         }
/* 562 */         throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), type }), e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 569 */     if (obj instanceof Set && type == Map.class && ((Set)obj).isEmpty())
/*     */     {
/* 571 */       return (T)Collections.EMPTY_MAP;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 576 */     if (type.isArray() && obj.getClass().isArray()) {
/*     */       
/* 578 */       T result = (T)coerceToArray(ctx, obj, type);
/* 579 */       return result;
/*     */     } 
/*     */     
/* 582 */     if (obj instanceof LambdaExpression && isFunctionalInterface(type)) {
/* 583 */       return coerceToFunctionalInterface(ctx, (LambdaExpression)obj, type);
/*     */     }
/*     */     
/* 586 */     throw new ELException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), type }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object coerceToArray(ELContext ctx, Object obj, Class<?> type) {
/* 594 */     int size = Array.getLength(obj);
/*     */ 
/*     */ 
/*     */     
/* 598 */     Class<?> componentType = type.getComponentType();
/*     */     
/* 600 */     Object result = Array.newInstance(componentType, size);
/*     */     
/* 602 */     for (int i = 0; i < size; i++) {
/* 603 */       Array.set(result, i, coerceToType(ctx, Array.get(obj, i), componentType));
/*     */     }
/*     */     
/* 606 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T coerceToFunctionalInterface(ELContext ctx, LambdaExpression lambdaExpression, Class<T> type) {
/* 612 */     Supplier<T> proxy = () -> Proxy.newProxyInstance(type.getClassLoader(), new Class[] { type }, ());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     if (System.getSecurityManager() != null) {
/* 630 */       Objects.requireNonNull(proxy); return AccessController.doPrivileged(proxy::get);
/*     */     } 
/* 632 */     return proxy.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBigDecimalOp(Object obj0, Object obj1) {
/* 638 */     return (obj0 instanceof BigDecimal || obj1 instanceof BigDecimal);
/*     */   }
/*     */   
/*     */   public static boolean isBigIntegerOp(Object obj0, Object obj1) {
/* 642 */     return (obj0 instanceof BigInteger || obj1 instanceof BigInteger);
/*     */   }
/*     */   
/*     */   public static boolean isDoubleOp(Object obj0, Object obj1) {
/* 646 */     return (obj0 instanceof Double || obj1 instanceof Double || obj0 instanceof Float || obj1 instanceof Float);
/*     */   }
/*     */   
/*     */   public static boolean isLongOp(Object obj0, Object obj1) {
/* 650 */     return (obj0 instanceof Long || obj1 instanceof Long || obj0 instanceof Integer || obj1 instanceof Integer || obj0 instanceof Character || obj1 instanceof Character || obj0 instanceof Short || obj1 instanceof Short || obj0 instanceof Byte || obj1 instanceof Byte);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStringFloat(String str) {
/* 656 */     int len = str.length();
/* 657 */     if (len > 1) {
/* 658 */       for (int i = 0; i < len; i++) {
/* 659 */         switch (str.charAt(i)) {
/*     */           case 'E':
/* 661 */             return true;
/*     */           case 'e':
/* 663 */             return true;
/*     */           case '.':
/* 665 */             return true;
/*     */         } 
/*     */       } 
/*     */     }
/* 669 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isFunctionalInterface(Class<?> type) {
/* 678 */     if (!type.isInterface()) {
/* 679 */       return false;
/*     */     }
/*     */     
/* 682 */     boolean foundAbstractMethod = false;
/* 683 */     Method[] methods = type.getMethods();
/* 684 */     for (Method method : methods) {
/* 685 */       if (Modifier.isAbstract(method.getModifiers()))
/*     */       {
/*     */         
/* 688 */         if (!overridesObjectMethod(method)) {
/*     */ 
/*     */           
/* 691 */           if (foundAbstractMethod)
/*     */           {
/* 693 */             return false;
/*     */           }
/* 695 */           foundAbstractMethod = true;
/*     */         } 
/*     */       }
/*     */     } 
/* 699 */     return foundAbstractMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean overridesObjectMethod(Method method) {
/* 708 */     if ("equals".equals(method.getName())) {
/* 709 */       if (method.getReturnType().equals(boolean.class) && 
/* 710 */         method.getParameterCount() == 1) {
/* 711 */         return method.getParameterTypes()[0].equals(Object.class);
/*     */       }
/*     */     }
/* 714 */     else if ("hashCode".equals(method.getName())) {
/* 715 */       if (method.getReturnType().equals(int.class)) {
/* 716 */         return (method.getParameterCount() == 0);
/*     */       }
/* 718 */     } else if ("toString".equals(method.getName()) && 
/* 719 */       method.getReturnType().equals(String.class)) {
/* 720 */       return (method.getParameterCount() == 0);
/*     */     } 
/*     */ 
/*     */     
/* 724 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\ELSupport.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */