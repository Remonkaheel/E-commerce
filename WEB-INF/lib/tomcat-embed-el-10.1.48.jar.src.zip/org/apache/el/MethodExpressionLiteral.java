/*     */ package org.apache.el;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.MethodExpression;
/*     */ import jakarta.el.MethodInfo;
/*     */ import jakarta.el.MethodReference;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodExpressionLiteral
/*     */   extends MethodExpression
/*     */   implements Externalizable
/*     */ {
/*  37 */   private static final Annotation[] EMPTY_ANNOTATION_ARRAY = new Annotation[0];
/*  38 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */   
/*     */   private Class<?> expectedType;
/*     */   
/*     */   private String expr;
/*     */   
/*     */   private Class<?>[] paramTypes;
/*     */ 
/*     */   
/*     */   public MethodExpressionLiteral() {}
/*     */ 
/*     */   
/*     */   public MethodExpressionLiteral(String expr, Class<?> expectedType, Class<?>[] paramTypes) {
/*  51 */     this.expr = expr;
/*  52 */     this.expectedType = expectedType;
/*  53 */     this.paramTypes = paramTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(ELContext context) throws ELException {
/*  58 */     context.notifyBeforeEvaluation(getExpressionString());
/*  59 */     MethodInfo result = getMethodInfoInternal();
/*  60 */     context.notifyAfterEvaluation(getExpressionString());
/*  61 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private MethodInfo getMethodInfoInternal() throws ELException {
/*  66 */     return new MethodInfo(this.expr, this.expectedType, this.paramTypes);
/*     */   }
/*     */   
/*     */   public Object invoke(ELContext context, Object[] params) throws ELException {
/*     */     Object result;
/*  71 */     context.notifyBeforeEvaluation(getExpressionString());
/*     */     
/*  73 */     if (this.expectedType != null) {
/*  74 */       result = context.convertToType(this.expr, this.expectedType);
/*     */     } else {
/*  76 */       result = this.expr;
/*     */     } 
/*  78 */     context.notifyAfterEvaluation(getExpressionString());
/*  79 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodReference getMethodReference(ELContext context) {
/*  85 */     if (context == null) {
/*  86 */       throw new NullPointerException(MessageFactory.get("error.context.null"));
/*     */     }
/*  88 */     context.notifyBeforeEvaluation(getExpressionString());
/*     */     
/*  90 */     MethodReference result = new MethodReference(null, getMethodInfoInternal(), EMPTY_ANNOTATION_ARRAY, EMPTY_OBJECT_ARRAY);
/*  91 */     context.notifyAfterEvaluation(getExpressionString());
/*  92 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/*  97 */     return this.expr;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 102 */     return (obj instanceof MethodExpressionLiteral && hashCode() == obj.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 107 */     return this.expr.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLiteralText() {
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 117 */     this.expr = in.readUTF();
/* 118 */     String type = in.readUTF();
/* 119 */     if (!type.isEmpty()) {
/* 120 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 122 */     this.paramTypes = ReflectionUtil.toTypeArray((String[])in.readObject());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 127 */     out.writeUTF(this.expr);
/* 128 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/* 129 */     out.writeObject(ReflectionUtil.toTypeNameArray(this.paramTypes));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\MethodExpressionLiteral.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */