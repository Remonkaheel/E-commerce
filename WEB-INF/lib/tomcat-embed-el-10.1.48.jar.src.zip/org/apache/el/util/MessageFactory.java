/*    */ package org.apache.el.util;
/*    */ 
/*    */ import java.text.FieldPosition;
/*    */ import java.text.Format;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MessageFactory
/*    */ {
/* 27 */   private static final ResourceBundle DEFAULT_BUNDLE = ResourceBundle.getBundle("org.apache.el.LocalStrings");
/*    */   
/* 29 */   private static final MessageFactory DEFAULT_MESSAGE_FACTORY = new MessageFactory(DEFAULT_BUNDLE);
/*    */   
/*    */   public static String get(String key) {
/* 32 */     return DEFAULT_MESSAGE_FACTORY.getInternal(key);
/*    */   }
/*    */   private final ResourceBundle bundle;
/*    */   public static String get(String key, Object... args) {
/* 36 */     return DEFAULT_MESSAGE_FACTORY.getInternal(key, args);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MessageFactory(ResourceBundle bundle) {
/* 42 */     this.bundle = bundle;
/*    */   }
/*    */   
/*    */   protected String getInternal(String key) {
/*    */     try {
/* 47 */       return this.bundle.getString(key);
/* 48 */     } catch (MissingResourceException e) {
/* 49 */       return key;
/*    */     } 
/*    */   }
/*    */   
/*    */   protected String getInternal(String key, Object... args) {
/* 54 */     String value = getInternal(key);
/*    */     
/* 56 */     MessageFormat mf = new MessageFormat(value);
/* 57 */     Format[] formats = null;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 62 */     if (args != null) {
/* 63 */       for (int i = 0; i < args.length; i++) {
/* 64 */         if (args[i] instanceof Number) {
/* 65 */           if (formats == null) {
/* 66 */             formats = mf.getFormatsByArgumentIndex();
/*    */           }
/* 68 */           if (i < formats.length && !(formats[i] instanceof java.text.NumberFormat)) {
/* 69 */             args[i] = args[i].toString();
/*    */           }
/*    */         } 
/*    */       } 
/*    */     }
/*    */     
/* 75 */     return mf.format(args, new StringBuffer(), (FieldPosition)null).toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\e\\util\MessageFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */