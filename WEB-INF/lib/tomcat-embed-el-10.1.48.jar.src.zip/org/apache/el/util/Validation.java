/*    */ package org.apache.el.util;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Validation
/*    */ {
/* 28 */   private static final String[] invalidIdentifiers = new String[] { "_", "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "enum", "extends", "false", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "null", "package", "private", "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "true", "try", "void", "volatile", "while" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   private static final boolean IS_SECURITY_ENABLED = (System.getSecurityManager() != null);
/*    */   
/*    */   private static final boolean SKIP_IDENTIFIER_CHECK;
/*    */ 
/*    */   
/*    */   static {
/* 41 */     if (IS_SECURITY_ENABLED) {
/* 42 */       skipIdentifierCheckStr = AccessController.<String>doPrivileged(() -> System.getProperty("org.apache.el.parser.SKIP_IDENTIFIER_CHECK", "false"));
/*    */     } else {
/*    */       
/* 45 */       skipIdentifierCheckStr = System.getProperty("org.apache.el.parser.SKIP_IDENTIFIER_CHECK", "false");
/*    */     } 
/* 47 */     SKIP_IDENTIFIER_CHECK = Boolean.parseBoolean(skipIdentifierCheckStr);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     String skipIdentifierCheckStr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isIdentifier(String key) {
/* 65 */     if (SKIP_IDENTIFIER_CHECK) {
/* 66 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 70 */     if (key == null || key.isEmpty()) {
/* 71 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 75 */     int i = 0;
/* 76 */     int j = invalidIdentifiers.length;
/* 77 */     while (i < j) {
/* 78 */       int k = i + j >>> 1;
/* 79 */       int result = invalidIdentifiers[k].compareTo(key);
/* 80 */       if (result == 0) {
/* 81 */         return false;
/*    */       }
/* 83 */       if (result < 0) {
/* 84 */         i = k + 1; continue;
/*    */       } 
/* 86 */       j = k;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 94 */     return (key.charAt(0) != '#');
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\e\\util\Validation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */