/*    */ package org.apache.el.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionUtils
/*    */ {
/*    */   public static void handleThrowable(Throwable t) {
/* 33 */     if (t instanceof ThreadDeath) {
/* 34 */       throw (ThreadDeath)t;
/*    */     }
/* 36 */     if (t instanceof StackOverflowError) {
/*    */       return;
/*    */     }
/*    */     
/* 40 */     if (t instanceof VirtualMachineError)
/* 41 */       throw (VirtualMachineError)t; 
/*    */   }
/*    */   
/*    */   public static void preload() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\e\\util\ExceptionUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */