/*     */ package org.apache.el;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.PropertyNotWritableException;
/*     */ import jakarta.el.ValueExpression;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueExpressionLiteral
/*     */   extends ValueExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Object value;
/*     */   private String valueString;
/*     */   private Class<?> expectedType;
/*     */   
/*     */   public ValueExpressionLiteral() {}
/*     */   
/*     */   public ValueExpressionLiteral(Object value, Class<?> expectedType) {
/*  46 */     this.value = value;
/*  47 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getValue(ELContext context) {
/*     */     Object result;
/*  53 */     context.notifyBeforeEvaluation(getExpressionString());
/*     */     
/*  55 */     if (this.expectedType != null) {
/*  56 */       result = context.convertToType(this.value, this.expectedType);
/*     */     } else {
/*  58 */       result = this.value;
/*     */     } 
/*  60 */     context.notifyAfterEvaluation(getExpressionString());
/*  61 */     return (T)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object value) {
/*  66 */     context.notifyBeforeEvaluation(getExpressionString());
/*  67 */     throw new PropertyNotWritableException(MessageFactory.get("error.value.literal.write", new Object[] { this.value }));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context) {
/*  72 */     context.notifyBeforeEvaluation(getExpressionString());
/*  73 */     context.notifyAfterEvaluation(getExpressionString());
/*  74 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context) {
/*  79 */     context.notifyBeforeEvaluation(getExpressionString());
/*  80 */     Class<?> result = (this.value != null) ? this.value.getClass() : null;
/*  81 */     context.notifyAfterEvaluation(getExpressionString());
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getExpectedType() {
/*  87 */     return this.expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/*  92 */     if (this.valueString == null) {
/*  93 */       this.valueString = (this.value != null) ? this.value.toString() : null;
/*     */     }
/*  95 */     return this.valueString;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 100 */     return (obj instanceof ValueExpressionLiteral && equals((ValueExpressionLiteral)obj));
/*     */   }
/*     */   
/*     */   public boolean equals(ValueExpressionLiteral ve) {
/* 104 */     return (ve != null && this.value != null && ve.value != null && (this.value == ve.value || this.value
/* 105 */       .equals(ve.value)));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 110 */     return (this.value != null) ? this.value.hashCode() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLiteralText() {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 120 */     out.writeObject(this.value);
/* 121 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/*     */   }
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 126 */     this.value = in.readObject();
/* 127 */     String type = in.readUTF();
/* 128 */     if (!type.isEmpty())
/* 129 */       this.expectedType = ReflectionUtil.forName(type); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\ValueExpressionLiteral.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */