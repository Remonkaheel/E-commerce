/*     */ package org.apache.el;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.FunctionMapper;
/*     */ import jakarta.el.PropertyNotFoundException;
/*     */ import jakarta.el.PropertyNotWritableException;
/*     */ import jakarta.el.ValueExpression;
/*     */ import jakarta.el.ValueReference;
/*     */ import jakarta.el.VariableMapper;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.lang.ExpressionBuilder;
/*     */ import org.apache.el.parser.Node;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueExpressionImpl
/*     */   extends ValueExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class<?> expectedType;
/*     */   private String expr;
/*     */   private FunctionMapper fnMapper;
/*     */   private VariableMapper varMapper;
/*     */   private transient Node node;
/*     */   
/*     */   public ValueExpressionImpl() {}
/*     */   
/*     */   public ValueExpressionImpl(String expr, Node node, FunctionMapper fnMapper, VariableMapper varMapper, Class<?> expectedType) {
/*  92 */     this.expr = expr;
/*  93 */     this.node = node;
/*  94 */     this.fnMapper = fnMapper;
/*  95 */     this.varMapper = varMapper;
/*  96 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 101 */     if (!(obj instanceof ValueExpressionImpl)) {
/* 102 */       return false;
/*     */     }
/* 104 */     if (obj.hashCode() != hashCode()) {
/* 105 */       return false;
/*     */     }
/*     */     
/* 108 */     return getNode().equals(((ValueExpressionImpl)obj).getNode());
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getExpectedType() {
/* 113 */     return this.expectedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 126 */     return this.expr;
/*     */   }
/*     */   
/*     */   private Node getNode() throws ELException {
/* 130 */     if (this.node == null) {
/* 131 */       this.node = ExpressionBuilder.createNode(this.expr);
/*     */     }
/* 133 */     return this.node;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context) throws PropertyNotFoundException, ELException {
/* 138 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 139 */     context.notifyBeforeEvaluation(getExpressionString());
/* 140 */     Class<?> result = getNode().getType(ctx);
/* 141 */     context.notifyAfterEvaluation(getExpressionString());
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getValue(ELContext context) throws PropertyNotFoundException, ELException {
/* 148 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 149 */     context.notifyBeforeEvaluation(getExpressionString());
/* 150 */     Object value = getNode().getValue(ctx);
/* 151 */     if (this.expectedType != null) {
/* 152 */       value = context.convertToType(value, this.expectedType);
/*     */     }
/* 154 */     context.notifyAfterEvaluation(getExpressionString());
/* 155 */     return (T)value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 160 */     return getNode().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLiteralText() {
/*     */     try {
/* 166 */       return getNode() instanceof org.apache.el.parser.AstLiteralExpression;
/* 167 */     } catch (ELException ele) {
/* 168 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context) throws PropertyNotFoundException, ELException {
/* 174 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 175 */     context.notifyBeforeEvaluation(getExpressionString());
/* 176 */     boolean result = getNode().isReadOnly(ctx);
/* 177 */     context.notifyAfterEvaluation(getExpressionString());
/* 178 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 183 */     this.expr = in.readUTF();
/* 184 */     String type = in.readUTF();
/* 185 */     if (!type.isEmpty()) {
/* 186 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 188 */     this.fnMapper = (FunctionMapper)in.readObject();
/* 189 */     this.varMapper = (VariableMapper)in.readObject();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object value) throws PropertyNotFoundException, PropertyNotWritableException, ELException {
/* 195 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 196 */     context.notifyBeforeEvaluation(getExpressionString());
/* 197 */     getNode().setValue(ctx, value);
/* 198 */     context.notifyAfterEvaluation(getExpressionString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 203 */     out.writeUTF(this.expr);
/* 204 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/* 205 */     out.writeObject(this.fnMapper);
/* 206 */     out.writeObject(this.varMapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     return "ValueExpression[" + this.expr + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueReference getValueReference(ELContext context) {
/* 216 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 217 */     context.notifyBeforeEvaluation(getExpressionString());
/* 218 */     ValueReference result = getNode().getValueReference(ctx);
/* 219 */     context.notifyAfterEvaluation(getExpressionString());
/* 220 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\ValueExpressionImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */