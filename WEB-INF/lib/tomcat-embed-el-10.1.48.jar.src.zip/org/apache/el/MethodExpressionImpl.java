/*     */ package org.apache.el;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.FunctionMapper;
/*     */ import jakarta.el.MethodExpression;
/*     */ import jakarta.el.MethodInfo;
/*     */ import jakarta.el.MethodNotFoundException;
/*     */ import jakarta.el.MethodReference;
/*     */ import jakarta.el.PropertyNotFoundException;
/*     */ import jakarta.el.VariableMapper;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.lang.ExpressionBuilder;
/*     */ import org.apache.el.parser.Node;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodExpressionImpl
/*     */   extends MethodExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class<?> expectedType;
/*     */   private String expr;
/*     */   private FunctionMapper fnMapper;
/*     */   private VariableMapper varMapper;
/*     */   private transient Node node;
/*     */   private Class<?>[] paramTypes;
/*     */   
/*     */   public MethodExpressionImpl() {}
/*     */   
/*     */   public MethodExpressionImpl(String expr, Node node, FunctionMapper fnMapper, VariableMapper varMapper, Class<?> expectedType, Class<?>[] paramTypes) {
/*  88 */     this.expr = expr;
/*  89 */     this.node = node;
/*  90 */     this.fnMapper = fnMapper;
/*  91 */     this.varMapper = varMapper;
/*  92 */     this.expectedType = expectedType;
/*  93 */     this.paramTypes = paramTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 118 */     return (obj instanceof MethodExpressionImpl && obj.hashCode() == hashCode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 139 */     return this.expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(ELContext context) throws PropertyNotFoundException, MethodNotFoundException, ELException {
/* 165 */     Node n = getNode();
/* 166 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 167 */     ctx.notifyBeforeEvaluation(getExpressionString());
/* 168 */     MethodInfo result = n.getMethodInfo(ctx, this.paramTypes);
/* 169 */     ctx.notifyAfterEvaluation(getExpressionString());
/* 170 */     return result;
/*     */   }
/*     */   
/*     */   private Node getNode() throws ELException {
/* 174 */     if (this.node == null) {
/* 175 */       this.node = ExpressionBuilder.createNode(this.expr);
/*     */     }
/* 177 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 197 */     return this.expr.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(ELContext context, Object[] params) throws PropertyNotFoundException, MethodNotFoundException, ELException {
/* 226 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 227 */     ctx.notifyBeforeEvaluation(getExpressionString());
/* 228 */     Object result = getNode().invoke(ctx, this.paramTypes, params);
/* 229 */     ctx.notifyAfterEvaluation(getExpressionString());
/* 230 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 235 */     this.expr = in.readUTF();
/* 236 */     String type = in.readUTF();
/* 237 */     if (!type.isEmpty()) {
/* 238 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 240 */     this.paramTypes = ReflectionUtil.toTypeArray((String[])in.readObject());
/* 241 */     this.fnMapper = (FunctionMapper)in.readObject();
/* 242 */     this.varMapper = (VariableMapper)in.readObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 247 */     out.writeUTF(this.expr);
/* 248 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/* 249 */     out.writeObject(ReflectionUtil.toTypeNameArray(this.paramTypes));
/* 250 */     out.writeObject(this.fnMapper);
/* 251 */     out.writeObject(this.varMapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLiteralText() {
/* 256 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParametersProvided() {
/* 262 */     return getNode().isParametersProvided();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodReference getMethodReference(ELContext context) {
/* 268 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/* 269 */     ctx.notifyBeforeEvaluation(getExpressionString());
/* 270 */     MethodReference methodReference = getNode().getMethodReference(ctx);
/* 271 */     ctx.notifyAfterEvaluation(getExpressionString());
/* 272 */     return methodReference;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\MethodExpressionImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */