/*     */ package org.apache.el.stream;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELResolver;
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamELResolverImpl
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  32 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  37 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/*  47 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "Tomcat 10.1.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/*  53 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(ELContext context, Object base, Object method, Class<?>[] paramTypes, Object[] params) {
/*  64 */     if ("stream".equals(method) && params.length == 0) {
/*  65 */       if (base.getClass().isArray()) {
/*  66 */         context.setPropertyResolved(true);
/*  67 */         return new Stream(new ArrayIterator(base));
/*  68 */       }  if (base instanceof Collection) {
/*  69 */         context.setPropertyResolved(true);
/*     */         
/*  71 */         Collection<Object> collection = (Collection<Object>)base;
/*  72 */         return new Stream(collection.iterator());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   private static class ArrayIterator
/*     */     implements Iterator<Object>
/*     */   {
/*     */     private final Object base;
/*     */     private final int size;
/*  85 */     private int index = 0;
/*     */     
/*     */     ArrayIterator(Object base) {
/*  88 */       this.base = base;
/*  89 */       this.size = Array.getLength(base);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  94 */       return (this.size > this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object next() {
/*     */       try {
/* 100 */         return Array.get(this.base, this.index++);
/* 101 */       } catch (ArrayIndexOutOfBoundsException e) {
/* 102 */         throw new NoSuchElementException();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 108 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\stream\StreamELResolverImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */