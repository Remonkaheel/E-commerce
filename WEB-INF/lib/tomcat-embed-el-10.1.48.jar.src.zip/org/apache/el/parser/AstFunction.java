/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import jakarta.el.ELClass;
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.FunctionMapper;
/*     */ import jakarta.el.LambdaExpression;
/*     */ import jakarta.el.ValueExpression;
/*     */ import jakarta.el.VariableMapper;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.el.lang.ELSupport;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstFunction
/*     */   extends SimpleNode
/*     */ {
/*  36 */   private String localName = "";
/*     */   
/*  38 */   private String prefix = "";
/*     */ 
/*     */   
/*     */   public AstFunction(int id) {
/*  42 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalName() {
/*  47 */     return this.localName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getOutputName() {
/*  52 */     if (this.prefix == null) {
/*  53 */       return this.localName;
/*     */     }
/*  55 */     return this.prefix + ":" + this.prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/*  61 */     return this.prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/*  68 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */ 
/*     */     
/*  71 */     if (fnMapper == null) {
/*  72 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  74 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*  75 */     if (m == null) {
/*  76 */       throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] { getOutputName() }));
/*     */     }
/*  78 */     return m.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/*     */     Object result;
/*  85 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */ 
/*     */     
/*  88 */     if (fnMapper == null) {
/*  89 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  91 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*     */     
/*  93 */     if (m == null && this.prefix.isEmpty()) {
/*     */ 
/*     */ 
/*     */       
/*  97 */       Object obj = null;
/*  98 */       if (ctx.isLambdaArgument(this.localName)) {
/*  99 */         obj = ctx.getLambdaArgument(this.localName);
/*     */       }
/* 101 */       if (obj == null) {
/* 102 */         VariableMapper varMapper = ctx.getVariableMapper();
/* 103 */         if (varMapper != null) {
/* 104 */           obj = varMapper.resolveVariable(this.localName);
/* 105 */           if (obj != null)
/*     */           {
/* 107 */             obj = ((ValueExpression)obj).getValue((ELContext)ctx);
/*     */           }
/*     */         } 
/*     */       } 
/* 111 */       if (obj == null) {
/* 112 */         obj = ctx.getELResolver().getValue((ELContext)ctx, null, this.localName);
/*     */       }
/* 114 */       if (obj instanceof LambdaExpression) {
/*     */         
/* 116 */         int i = 0;
/* 117 */         while (obj instanceof LambdaExpression && i < jjtGetNumChildren()) {
/* 118 */           Node args = jjtGetChild(i);
/* 119 */           obj = ((LambdaExpression)obj).invoke(((AstMethodParameters)args).getParameters(ctx));
/* 120 */           i++;
/*     */         } 
/* 122 */         if (i < jjtGetNumChildren())
/*     */         {
/*     */           
/* 125 */           throw new ELException(MessageFactory.get("error.lambda.tooManyMethodParameterSets"));
/*     */         }
/* 127 */         return obj;
/*     */       } 
/*     */ 
/*     */       
/* 131 */       obj = ctx.getImportHandler().resolveClass(this.localName);
/* 132 */       if (obj != null) {
/* 133 */         return ctx.getELResolver().invoke((ELContext)ctx, new ELClass((Class)obj), "<init>", null, ((AstMethodParameters)this.children[0])
/* 134 */             .getParameters(ctx));
/*     */       }
/* 136 */       obj = ctx.getImportHandler().resolveStatic(this.localName);
/* 137 */       if (obj != null) {
/* 138 */         return ctx.getELResolver().invoke((ELContext)ctx, new ELClass((Class)obj), this.localName, null, ((AstMethodParameters)this.children[0])
/* 139 */             .getParameters(ctx));
/*     */       }
/*     */     } 
/*     */     
/* 143 */     if (m == null) {
/* 144 */       throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] { getOutputName() }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 149 */     if (jjtGetNumChildren() != 1) {
/* 150 */       throw new ELException(MessageFactory.get("error.function.tooManyMethodParameterSets", new Object[] { getOutputName() }));
/*     */     }
/*     */     
/* 153 */     Node parameters = jjtGetChild(0);
/* 154 */     Class<?>[] paramTypes = m.getParameterTypes();
/* 155 */     Object[] params = null;
/* 156 */     int inputParameterCount = parameters.jjtGetNumChildren();
/* 157 */     int methodParameterCount = paramTypes.length;
/* 158 */     if (inputParameterCount == 0 && methodParameterCount == 1 && m.isVarArgs()) {
/* 159 */       params = new Object[] { null };
/* 160 */     } else if (inputParameterCount > 0) {
/* 161 */       params = new Object[methodParameterCount];
/*     */       try {
/* 163 */         for (int i = 0; i < methodParameterCount; i++) {
/* 164 */           if (m.isVarArgs() && i == methodParameterCount - 1) {
/* 165 */             if (inputParameterCount < methodParameterCount) {
/* 166 */               (new Object[1])[0] = null; params[i] = new Object[1];
/* 167 */             } else if (inputParameterCount == methodParameterCount && 
/* 168 */               isArray(parameters.jjtGetChild(i).getValue(ctx))) {
/* 169 */               params[i] = parameters.jjtGetChild(i).getValue(ctx);
/*     */             } else {
/* 171 */               Object[] varargs = new Object[inputParameterCount - methodParameterCount + 1];
/* 172 */               Class<?> target = paramTypes[i].getComponentType();
/* 173 */               for (int j = i; j < inputParameterCount; j++) {
/* 174 */                 varargs[j - i] = parameters.jjtGetChild(j).getValue(ctx);
/* 175 */                 varargs[j - i] = ELSupport.coerceToType((ELContext)ctx, varargs[j - i], target);
/*     */               } 
/* 177 */               params[i] = varargs;
/*     */             } 
/*     */           } else {
/* 180 */             params[i] = parameters.jjtGetChild(i).getValue(ctx);
/*     */           } 
/* 182 */           params[i] = ELSupport.coerceToType((ELContext)ctx, params[i], paramTypes[i]);
/*     */         } 
/* 184 */       } catch (ELException ele) {
/* 185 */         throw new ELException(MessageFactory.get("error.function", new Object[] { getOutputName() }), ele);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 190 */       result = m.invoke(null, params);
/* 191 */     } catch (IllegalAccessException iae) {
/* 192 */       throw new ELException(MessageFactory.get("error.function", new Object[] { getOutputName() }), iae);
/* 193 */     } catch (InvocationTargetException ite) {
/* 194 */       Throwable cause = ite.getCause();
/* 195 */       if (cause instanceof ThreadDeath) {
/* 196 */         throw (ThreadDeath)cause;
/*     */       }
/* 198 */       if (cause instanceof VirtualMachineError) {
/* 199 */         throw (VirtualMachineError)cause;
/*     */       }
/* 201 */       throw new ELException(MessageFactory.get("error.function", new Object[] { getOutputName() }), cause);
/*     */     } 
/* 203 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isArray(Object obj) {
/* 208 */     if (obj == null) {
/* 209 */       return false;
/*     */     }
/* 211 */     return obj.getClass().isArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocalName(String localName) {
/* 216 */     this.localName = localName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 221 */     this.prefix = prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 227 */     return ELParserTreeConstants.jjtNodeName[this.id] + "[" + ELParserTreeConstants.jjtNodeName[this.id] + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstFunction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */