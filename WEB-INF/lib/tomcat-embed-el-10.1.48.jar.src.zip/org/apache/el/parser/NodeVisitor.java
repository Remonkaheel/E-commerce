package org.apache.el.parser;

public interface NodeVisitor {
  void visit(Node paramNode) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\NodeVisitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */