/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDeferredExpression
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstDeferredExpression(int id) {
/* 27 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 33 */     return this.children[0].getType(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 39 */     return this.children[0].getValue(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isReadOnly(EvaluationContext ctx) throws ELException {
/* 45 */     return this.children[0].isReadOnly(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(EvaluationContext ctx, Object value) throws ELException {
/* 51 */     this.children[0].setValue(ctx, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstDeferredExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */