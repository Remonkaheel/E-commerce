/*     */ package org.apache.el.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  22 */   protected static String EOL = System.getProperty("line.separator", "\n");
/*     */   
/*     */   public Token currentToken;
/*     */   
/*     */   public int[][] expectedTokenSequences;
/*     */   
/*     */   public String[] tokenImage;
/*     */   
/*     */   public ParseException(Token currentTokenVal, int[][] expectedTokenSequencesVal, String[] tokenImageVal) {
/*  31 */     super(initialise(currentTokenVal, expectedTokenSequencesVal, tokenImageVal));
/*  32 */     this.currentToken = currentTokenVal;
/*  33 */     this.expectedTokenSequences = expectedTokenSequencesVal;
/*  34 */     this.tokenImage = tokenImageVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String message) {
/*  52 */     super(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String initialise(Token currentToken, int[][] expectedTokenSequences, String[] tokenImage) {
/*  82 */     StringBuilder expected = new StringBuilder();
/*  83 */     int maxSize = 0;
/*  84 */     for (int i = 0; i < expectedTokenSequences.length; i++) {
/*  85 */       if (maxSize < (expectedTokenSequences[i]).length) {
/*  86 */         maxSize = (expectedTokenSequences[i]).length;
/*     */       }
/*  88 */       for (int k = 0; k < (expectedTokenSequences[i]).length; k++) {
/*  89 */         expected.append(tokenImage[expectedTokenSequences[i][k]]).append(' ');
/*     */       }
/*  91 */       if (expectedTokenSequences[i][(expectedTokenSequences[i]).length - 1] != 0) {
/*  92 */         expected.append("...");
/*     */       }
/*  94 */       expected.append(EOL).append("    ");
/*     */     } 
/*  96 */     String retval = "Encountered \"";
/*  97 */     Token tok = currentToken.next;
/*  98 */     for (int j = 0; j < maxSize; j++) {
/*  99 */       if (j != 0) {
/* 100 */         retval = retval + " ";
/*     */       }
/* 102 */       if (tok.kind == 0) {
/* 103 */         retval = retval + retval;
/*     */         break;
/*     */       } 
/* 106 */       retval = retval + " " + retval;
/* 107 */       retval = retval + " \"";
/* 108 */       retval = retval + retval;
/* 109 */       retval = retval + " \"";
/* 110 */       tok = tok.next;
/*     */     } 
/* 112 */     if (currentToken.next != null) {
/* 113 */       retval = retval + "\" at line " + retval + ", column " + currentToken.next.beginLine;
/*     */     }
/* 115 */     retval = retval + "." + retval;
/*     */     
/* 117 */     if (expectedTokenSequences.length != 0) {
/*     */ 
/*     */       
/* 120 */       if (expectedTokenSequences.length == 1) {
/* 121 */         retval = retval + "Was expecting:" + retval + "    ";
/*     */       } else {
/* 123 */         retval = retval + "Was expecting one of:" + retval + "    ";
/*     */       } 
/* 125 */       retval = retval + retval;
/*     */     } 
/*     */     
/* 128 */     return retval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String add_escapes(String str) {
/* 137 */     StringBuilder retval = new StringBuilder();
/*     */     
/* 139 */     for (int i = 0; i < str.length(); i++) {
/* 140 */       char ch; switch (str.charAt(i)) {
/*     */         case '\b':
/* 142 */           retval.append("\\b");
/*     */           break;
/*     */         case '\t':
/* 145 */           retval.append("\\t");
/*     */           break;
/*     */         case '\n':
/* 148 */           retval.append("\\n");
/*     */           break;
/*     */         case '\f':
/* 151 */           retval.append("\\f");
/*     */           break;
/*     */         case '\r':
/* 154 */           retval.append("\\r");
/*     */           break;
/*     */         case '"':
/* 157 */           retval.append("\\\"");
/*     */           break;
/*     */         case '\'':
/* 160 */           retval.append("\\'");
/*     */           break;
/*     */         case '\\':
/* 163 */           retval.append("\\\\");
/*     */           break;
/*     */         default:
/* 166 */           if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/* 167 */             String s = "0000" + Integer.toString(ch, 16);
/* 168 */             retval.append("\\u" + s.substring(s.length() - 4)); break;
/*     */           } 
/* 170 */           retval.append(ch);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 175 */     return retval.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\ParseException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */