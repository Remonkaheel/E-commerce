/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AstListData
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstListData(int id) {
/* 30 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 36 */     List<Object> result = new ArrayList();
/*    */     
/* 38 */     if (this.children != null) {
/* 39 */       for (Node child : this.children) {
/* 40 */         result.add(child.getValue(ctx));
/*    */       }
/*    */     }
/*    */     
/* 44 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 50 */     return List.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstListData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */