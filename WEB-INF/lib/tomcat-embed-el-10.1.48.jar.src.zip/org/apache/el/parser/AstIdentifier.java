/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import jakarta.el.ELClass;
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.MethodExpression;
/*     */ import jakarta.el.MethodInfo;
/*     */ import jakarta.el.MethodNotFoundException;
/*     */ import jakarta.el.MethodReference;
/*     */ import jakarta.el.PropertyNotFoundException;
/*     */ import jakarta.el.ValueExpression;
/*     */ import jakarta.el.ValueReference;
/*     */ import jakarta.el.VariableMapper;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.Validation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstIdentifier
/*     */   extends SimpleNode
/*     */ {
/*     */   public AstIdentifier(int id) {
/*  38 */     super(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/*  44 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  45 */     if (varMapper != null) {
/*  46 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  47 */       if (expr != null) {
/*  48 */         return expr.getType(ctx.getELContext());
/*     */       }
/*     */     } 
/*  51 */     ctx.setPropertyResolved(false);
/*  52 */     Class<?> result = ctx.getELResolver().getType((ELContext)ctx, null, this.image);
/*  53 */     if (!ctx.isPropertyResolved()) {
/*  54 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */     }
/*  56 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/*  63 */     if (ctx.isLambdaArgument(this.image)) {
/*  64 */       return ctx.getLambdaArgument(this.image);
/*     */     }
/*     */ 
/*     */     
/*  68 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  69 */     if (varMapper != null) {
/*  70 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  71 */       if (expr != null) {
/*  72 */         return expr.getValue(ctx.getELContext());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  77 */     ctx.setPropertyResolved(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     if (this.parent instanceof AstValue) {
/*  86 */       ctx.putContext(getClass(), Boolean.FALSE);
/*     */     } else {
/*  88 */       ctx.putContext(getClass(), Boolean.TRUE);
/*     */     } 
/*     */     try {
/*  91 */       result = ctx.getELResolver().getValue((ELContext)ctx, null, this.image);
/*     */     }
/*     */     finally {
/*     */       
/*  95 */       ctx.putContext(getClass(), Boolean.FALSE);
/*     */     } 
/*     */     
/*  98 */     if (ctx.isPropertyResolved()) {
/*  99 */       return result;
/*     */     }
/*     */ 
/*     */     
/* 103 */     Object result = ctx.getImportHandler().resolveClass(this.image);
/* 104 */     if (result != null) {
/* 105 */       return new ELClass((Class)result);
/*     */     }
/* 107 */     result = ctx.getImportHandler().resolveStatic(this.image);
/* 108 */     if (result != null) {
/*     */       try {
/* 110 */         return ((Class)result).getField(this.image).get(null);
/* 111 */       } catch (IllegalArgumentException|IllegalAccessException|NoSuchFieldException|SecurityException e) {
/* 112 */         throw new ELException(e);
/*     */       } 
/*     */     }
/*     */     
/* 116 */     throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx) throws ELException {
/* 122 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 123 */     if (varMapper != null) {
/* 124 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/* 125 */       if (expr != null) {
/* 126 */         return expr.isReadOnly(ctx.getELContext());
/*     */       }
/*     */     } 
/* 129 */     ctx.setPropertyResolved(false);
/* 130 */     boolean result = ctx.getELResolver().isReadOnly((ELContext)ctx, null, this.image);
/* 131 */     if (!ctx.isPropertyResolved()) {
/* 132 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value) throws ELException {
/* 140 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 141 */     if (varMapper != null) {
/* 142 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/* 143 */       if (expr != null) {
/* 144 */         expr.setValue(ctx.getELContext(), value);
/*     */         return;
/*     */       } 
/*     */     } 
/* 148 */     ctx.setPropertyResolved(false);
/* 149 */     ctx.getELResolver().setValue((ELContext)ctx, null, this.image, value);
/* 150 */     if (!ctx.isPropertyResolved()) {
/* 151 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(EvaluationContext ctx, Class<?>[] paramTypes, Object[] paramValues) throws ELException {
/* 158 */     return getMethodExpression(ctx).invoke(ctx.getELContext(), paramValues);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class<?>[] paramTypes) throws ELException {
/* 164 */     return getMethodExpression(ctx).getMethodInfo(ctx.getELContext());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodReference getMethodReference(EvaluationContext ctx) {
/* 170 */     return getMethodExpression(ctx).getMethodReference(ctx.getELContext());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImage(String image) {
/* 176 */     if (!Validation.isIdentifier(image)) {
/* 177 */       throw new ELException(MessageFactory.get("error.identifier.notjava", new Object[] { image }));
/*     */     }
/* 179 */     this.image = image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueReference getValueReference(EvaluationContext ctx) {
/* 185 */     VariableMapper varMapper = ctx.getVariableMapper();
/*     */     
/* 187 */     if (varMapper == null) {
/* 188 */       return null;
/*     */     }
/*     */     
/* 191 */     ValueExpression expr = varMapper.resolveVariable(this.image);
/*     */     
/* 193 */     if (expr == null) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     return expr.getValueReference((ELContext)ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   private MethodExpression getMethodExpression(EvaluationContext ctx) throws ELException {
/* 202 */     Object obj = null;
/*     */ 
/*     */ 
/*     */     
/* 206 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 207 */     ValueExpression ve = null;
/* 208 */     if (varMapper != null) {
/* 209 */       ve = varMapper.resolveVariable(this.image);
/* 210 */       if (ve != null) {
/* 211 */         obj = ve.getValue((ELContext)ctx);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 217 */     if (ve == null) {
/* 218 */       ctx.setPropertyResolved(false);
/* 219 */       obj = ctx.getELResolver().getValue((ELContext)ctx, null, this.image);
/*     */     } 
/*     */ 
/*     */     
/* 223 */     if (obj instanceof MethodExpression)
/* 224 */       return (MethodExpression)obj; 
/* 225 */     if (obj == null) {
/* 226 */       throw new MethodNotFoundException(MessageFactory.get("error.identifier.noMethod", new Object[] { this.image }));
/*     */     }
/* 228 */     throw new ELException(
/* 229 */         MessageFactory.get("error.identifier.notMethodExpression", new Object[] { this.image, obj.getClass().getName() }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstIdentifier.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */