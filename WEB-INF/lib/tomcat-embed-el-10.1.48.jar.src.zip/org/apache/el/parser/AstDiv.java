/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.ELArithmetic;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDiv
/*    */   extends ArithmeticNode
/*    */ {
/*    */   public AstDiv(int id) {
/* 28 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 34 */     Object obj0 = this.children[0].getValue(ctx);
/* 35 */     Object obj1 = this.children[1].getValue(ctx);
/* 36 */     return ELArithmetic.divide(obj0, obj1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstDiv.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */