/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstMethodParameters
/*    */   extends SimpleNode
/*    */ {
/* 24 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*    */   
/*    */   public AstMethodParameters(int id) {
/* 27 */     super(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] getParameters(EvaluationContext ctx) {
/* 32 */     int numChildren = jjtGetNumChildren();
/*    */     
/* 34 */     if (numChildren == 0) {
/* 35 */       return EMPTY_OBJECT_ARRAY;
/*    */     }
/* 37 */     Object[] params = new Object[numChildren];
/* 38 */     for (int i = 0; i < numChildren; i++) {
/* 39 */       params[i] = jjtGetChild(i).getValue(ctx);
/*    */     }
/* 41 */     return params;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     StringBuilder result = new StringBuilder();
/* 50 */     result.append('(');
/* 51 */     if (this.children != null) {
/* 52 */       for (Node n : this.children) {
/* 53 */         result.append(n.toString());
/* 54 */         result.append(',');
/*    */       } 
/*    */     }
/* 57 */     result.append(')');
/* 58 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstMethodParameters.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */