/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstOr
/*    */   extends BooleanNode
/*    */ {
/*    */   public AstOr(int id) {
/* 28 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 34 */     int i = 0;
/* 35 */     while (i < this.children.length - 1) {
/* 36 */       Object object = this.children[i].getValue(ctx);
/* 37 */       Boolean b = ELSupport.coerceToBoolean((ELContext)ctx, object, true);
/* 38 */       if (b.booleanValue()) {
/* 39 */         return b;
/*    */       }
/* 41 */       i++;
/*    */     } 
/* 43 */     Object obj = this.children[i].getValue(ctx);
/* 44 */     return ELSupport.coerceToBoolean((ELContext)ctx, obj, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstOr.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */