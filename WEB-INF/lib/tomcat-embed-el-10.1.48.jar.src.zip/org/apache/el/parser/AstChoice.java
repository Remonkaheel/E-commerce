/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstChoice
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstChoice(int id) {
/* 28 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 34 */     Object val = getValue(ctx);
/* 35 */     return (val != null) ? val.getClass() : null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 41 */     Object obj0 = this.children[0].getValue(ctx);
/* 42 */     Boolean b0 = ELSupport.coerceToBoolean((ELContext)ctx, obj0, true);
/* 43 */     return this.children[b0.booleanValue() ? 1 : 2].getValue(ctx);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstChoice.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */