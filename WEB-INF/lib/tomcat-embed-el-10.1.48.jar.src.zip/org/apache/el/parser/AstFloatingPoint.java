/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import java.math.BigDecimal;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstFloatingPoint
/*    */   extends SimpleNode
/*    */ {
/*    */   private volatile Number number;
/*    */   
/*    */   public AstFloatingPoint(int id) {
/* 29 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Number getFloatingPoint() {
/* 38 */     if (this.number == null) {
/*    */       try {
/* 40 */         Double d = Double.valueOf(this.image);
/* 41 */         if (d.isInfinite() || d.isNaN()) {
/* 42 */           this.number = new BigDecimal(this.image);
/*    */         } else {
/* 44 */           this.number = d;
/*    */         } 
/* 46 */       } catch (NumberFormatException e) {
/*    */ 
/*    */         
/* 49 */         throw new ELException(e);
/*    */       } 
/*    */     }
/* 52 */     return this.number;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 58 */     return getFloatingPoint();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 64 */     return getFloatingPoint().getClass();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstFloatingPoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */