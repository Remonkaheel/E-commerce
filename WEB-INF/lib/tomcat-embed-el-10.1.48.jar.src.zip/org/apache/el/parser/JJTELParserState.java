/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JJTELParserState
/*     */ {
/*  14 */   private List<Node> nodes = new ArrayList<>();
/*  15 */   private List<Integer> marks = new ArrayList<>();
/*  16 */   private int sp = 0;
/*  17 */   private int mk = 0;
/*     */ 
/*     */   
/*     */   private boolean node_created;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nodeCreated() {
/*  25 */     return this.node_created;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  32 */     this.nodes.clear();
/*  33 */     this.marks.clear();
/*  34 */     this.sp = 0;
/*  35 */     this.mk = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node rootNode() {
/*  42 */     return this.nodes.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushNode(Node n) {
/*  47 */     this.nodes.add(n);
/*  48 */     this.sp++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node popNode() {
/*  55 */     if (--this.sp < this.mk) {
/*  56 */       this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/*     */     }
/*  58 */     return this.nodes.remove(this.nodes.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node peekNode() {
/*  63 */     return this.nodes.get(this.nodes.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nodeArity() {
/*  70 */     return this.sp - this.mk;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearNodeScope(Node n) {
/*  75 */     while (this.sp > this.mk) {
/*  76 */       popNode();
/*     */     }
/*  78 */     this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void openNodeScope(Node n) {
/*  83 */     this.marks.add(Integer.valueOf(this.mk));
/*  84 */     this.mk = this.sp;
/*  85 */     n.jjtOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeNodeScope(Node n, int num) {
/*  94 */     this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/*  95 */     while (num-- > 0) {
/*  96 */       Node c = popNode();
/*  97 */       c.jjtSetParent(n);
/*  98 */       n.jjtAddChild(c, num);
/*     */     } 
/* 100 */     n.jjtClose();
/* 101 */     pushNode(n);
/* 102 */     this.node_created = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeNodeScope(Node n, boolean condition) {
/* 112 */     if (condition) {
/* 113 */       int a = nodeArity();
/* 114 */       this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/* 115 */       while (a-- > 0) {
/* 116 */         Node c = popNode();
/* 117 */         c.jjtSetParent(n);
/* 118 */         n.jjtAddChild(c, a);
/*     */       } 
/* 120 */       n.jjtClose();
/* 121 */       pushNode(n);
/* 122 */       this.node_created = true;
/*     */     } else {
/* 124 */       this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/* 125 */       this.node_created = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\JJTELParserState.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */