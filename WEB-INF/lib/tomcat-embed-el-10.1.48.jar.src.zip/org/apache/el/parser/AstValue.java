/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.ELResolver;
/*     */ import jakarta.el.MethodInfo;
/*     */ import jakarta.el.MethodReference;
/*     */ import jakarta.el.PropertyNotFoundException;
/*     */ import jakarta.el.ValueReference;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.el.lang.ELSupport;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstValue
/*     */   extends SimpleNode
/*     */ {
/*  40 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */ 
/*     */   
/*     */   protected static class Target
/*     */   {
/*     */     protected Object base;
/*     */     
/*     */     protected Object property;
/*     */   }
/*     */ 
/*     */   
/*     */   public AstValue(int id) {
/*  52 */     super(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/*  58 */     Target t = getTarget(ctx);
/*  59 */     ctx.setPropertyResolved(false);
/*  60 */     Class<?> result = ctx.getELResolver().getType((ELContext)ctx, t.base, t.property);
/*  61 */     if (!ctx.isPropertyResolved()) {
/*  62 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { t.base, t.property }));
/*     */     }
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Target getTarget(EvaluationContext ctx) throws ELException {
/*  70 */     Object base = this.children[0].getValue(ctx);
/*     */ 
/*     */     
/*  73 */     if (base == null) {
/*  74 */       throw new PropertyNotFoundException(
/*  75 */           MessageFactory.get("error.unreachable.base", new Object[] { this.children[0].getImage() }));
/*     */     }
/*     */ 
/*     */     
/*  79 */     Object property = null;
/*  80 */     int propCount = jjtGetNumChildren();
/*     */     
/*  82 */     int i = 1;
/*     */     
/*  84 */     ELResolver resolver = ctx.getELResolver();
/*  85 */     while (i < propCount) {
/*  86 */       if (i + 2 < propCount && this.children[i + 1] instanceof AstMethodParameters) {
/*     */         
/*  88 */         base = resolver.invoke((ELContext)ctx, base, this.children[i].getValue(ctx), null, ((AstMethodParameters)this.children[i + 1])
/*  89 */             .getParameters(ctx));
/*  90 */         i += 2;
/*  91 */       } else if (i + 2 == propCount && this.children[i + 1] instanceof AstMethodParameters) {
/*     */         
/*  93 */         ctx.setPropertyResolved(false);
/*  94 */         property = this.children[i].getValue(ctx);
/*  95 */         i += 2;
/*     */         
/*  97 */         if (property == null) {
/*  98 */           throw new PropertyNotFoundException(
/*  99 */               MessageFactory.get("error.unreachable.property", new Object[] { this.children[i].getImage() }));
/*     */         }
/* 101 */       } else if (i + 1 < propCount) {
/*     */         
/* 103 */         property = this.children[i].getValue(ctx);
/* 104 */         ctx.setPropertyResolved(false);
/* 105 */         base = resolver.getValue((ELContext)ctx, base, property);
/* 106 */         i++;
/*     */       }
/*     */       else {
/*     */         
/* 110 */         ctx.setPropertyResolved(false);
/* 111 */         property = this.children[i].getValue(ctx);
/* 112 */         i++;
/*     */         
/* 114 */         if (property == null) {
/* 115 */           throw new PropertyNotFoundException(
/* 116 */               MessageFactory.get("error.unreachable.property", new Object[] { this.children[i].getImage() }));
/*     */         }
/*     */       } 
/* 119 */       if (base == null) {
/* 120 */         throw new PropertyNotFoundException(
/* 121 */             MessageFactory.get("error.unreachable.property", new Object[] { this.children[i].getImage() }));
/*     */       }
/*     */     } 
/*     */     
/* 125 */     Target t = new Target();
/* 126 */     t.base = base;
/* 127 */     t.property = property;
/* 128 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 134 */     Object base = this.children[0].getValue(ctx);
/* 135 */     int propCount = jjtGetNumChildren();
/* 136 */     int i = 1;
/* 137 */     Object suffix = null;
/* 138 */     ELResolver resolver = ctx.getELResolver();
/* 139 */     while (base != null && i < propCount) {
/* 140 */       suffix = this.children[i].getValue(ctx);
/* 141 */       if (i + 1 < propCount && this.children[i + 1] instanceof AstMethodParameters) {
/* 142 */         AstMethodParameters mps = (AstMethodParameters)this.children[i + 1];
/* 143 */         if (base instanceof org.apache.el.stream.Optional && "orElseGet".equals(suffix) && mps.jjtGetNumChildren() == 1) {
/* 144 */           Node paramFoOptional = mps.jjtGetChild(0);
/* 145 */           if (!(paramFoOptional instanceof AstLambdaExpression) && !(paramFoOptional instanceof jakarta.el.LambdaExpression))
/*     */           {
/* 147 */             throw new ELException(MessageFactory.get("stream.optional.paramNotLambda", new Object[] { suffix }));
/*     */           }
/*     */         } 
/*     */         
/* 151 */         Object[] paramValues = mps.getParameters(ctx);
/* 152 */         base = resolver.invoke((ELContext)ctx, base, suffix, getTypesFromValues(paramValues), paramValues);
/* 153 */         i += 2;
/*     */         continue;
/*     */       } 
/* 156 */       if (suffix == null) {
/* 157 */         return null;
/*     */       }
/*     */       
/* 160 */       ctx.setPropertyResolved(false);
/* 161 */       base = resolver.getValue((ELContext)ctx, base, suffix);
/* 162 */       i++;
/*     */     } 
/*     */     
/* 165 */     if (!ctx.isPropertyResolved()) {
/* 166 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { base, suffix }));
/*     */     }
/* 168 */     return base;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx) throws ELException {
/* 174 */     Target t = getTarget(ctx);
/* 175 */     ctx.setPropertyResolved(false);
/* 176 */     boolean result = ctx.getELResolver().isReadOnly((ELContext)ctx, t.base, t.property);
/* 177 */     if (!ctx.isPropertyResolved()) {
/* 178 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { t.base, t.property }));
/*     */     }
/* 180 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value) throws ELException {
/* 186 */     Target t = getTarget(ctx);
/* 187 */     ctx.setPropertyResolved(false);
/* 188 */     ELResolver resolver = ctx.getELResolver();
/*     */ 
/*     */     
/* 191 */     Class<?> targetClass = resolver.getType((ELContext)ctx, t.base, t.property);
/* 192 */     resolver.setValue((ELContext)ctx, t.base, t.property, ELSupport.coerceToType((ELContext)ctx, value, targetClass));
/* 193 */     if (!ctx.isPropertyResolved()) {
/* 194 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { t.base, t.property }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class[] paramTypes) throws ELException {
/*     */     Class<?>[] types;
/* 203 */     Target t = getTarget(ctx);
/*     */     
/* 205 */     if (isParametersProvided()) {
/* 206 */       Object[] values = ((AstMethodParameters)jjtGetChild(jjtGetNumChildren() - 1)).getParameters(ctx);
/* 207 */       types = getTypesFromValues(values);
/*     */     } else {
/* 209 */       types = paramTypes;
/*     */     } 
/* 211 */     Method m = ReflectionUtil.getMethod(ctx, t.base, t.property, types, null);
/* 212 */     return new MethodInfo(m.getName(), m.getReturnType(), m.getParameterTypes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(EvaluationContext ctx, Class[] paramTypes, Object[] paramValues) throws ELException {
/*     */     Class<?>[] types;
/*     */     Object result;
/* 221 */     Target t = getTarget(ctx);
/*     */ 
/*     */ 
/*     */     
/* 225 */     if (isParametersProvided()) {
/* 226 */       values = ((AstMethodParameters)jjtGetChild(jjtGetNumChildren() - 1)).getParameters(ctx);
/* 227 */       types = getTypesFromValues(values);
/*     */     } else {
/* 229 */       values = paramValues;
/* 230 */       types = paramTypes;
/*     */     } 
/* 232 */     Method m = ReflectionUtil.getMethod(ctx, t.base, t.property, types, values);
/*     */ 
/*     */     
/* 235 */     Object[] values = convertArgs(ctx, values, m);
/*     */ 
/*     */     
/*     */     try {
/* 239 */       result = m.invoke(t.base, values);
/* 240 */     } catch (IllegalAccessException|IllegalArgumentException e) {
/* 241 */       throw new ELException(e);
/* 242 */     } catch (InvocationTargetException ite) {
/* 243 */       Throwable cause = ite.getCause();
/* 244 */       if (cause instanceof ThreadDeath) {
/* 245 */         throw (ThreadDeath)cause;
/*     */       }
/* 247 */       if (cause instanceof VirtualMachineError) {
/* 248 */         throw (VirtualMachineError)cause;
/*     */       }
/* 250 */       throw new ELException(cause);
/*     */     } 
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodReference getMethodReference(EvaluationContext ctx) {
/* 258 */     Target t = getTarget(ctx);
/*     */     
/* 260 */     Object[] values = null;
/* 261 */     Class<?>[] types = null;
/* 262 */     if (isParametersProvided()) {
/* 263 */       values = ((AstMethodParameters)jjtGetChild(jjtGetNumChildren() - 1)).getParameters(ctx);
/* 264 */       types = getTypesFromValues(values);
/*     */     } 
/* 266 */     Method m = ReflectionUtil.getMethod(ctx, t.base, t.property, types, values);
/*     */ 
/*     */     
/* 269 */     values = convertArgs(ctx, values, m);
/*     */     
/* 271 */     return new MethodReference(t.base, getMethodInfo(ctx, types), m.getAnnotations(), values);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object[] convertArgs(EvaluationContext ctx, Object[] src, Method m) {
/* 276 */     Class<?>[] types = m.getParameterTypes();
/* 277 */     if (types.length == 0)
/*     */     {
/* 279 */       return EMPTY_ARRAY;
/*     */     }
/*     */     
/* 282 */     int paramCount = types.length;
/*     */     
/* 284 */     if ((m.isVarArgs() && paramCount > 1 && (src == null || paramCount > src.length)) || (
/* 285 */       !m.isVarArgs() && (src == null || src.length != paramCount))) {
/* 286 */       String msg, srcCount = null;
/* 287 */       if (src != null) {
/* 288 */         srcCount = Integer.toString(src.length);
/*     */       }
/*     */       
/* 291 */       if (m.isVarArgs()) {
/* 292 */         msg = MessageFactory.get("error.invoke.tooFewParams", new Object[] { m.getName(), srcCount, 
/* 293 */               Integer.toString(paramCount) });
/*     */       } else {
/* 295 */         msg = MessageFactory.get("error.invoke.wrongParams", new Object[] { m.getName(), srcCount, 
/* 296 */               Integer.toString(paramCount) });
/*     */       } 
/* 298 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 301 */     if (src == null)
/*     */     {
/*     */ 
/*     */       
/* 305 */       return new Object[1];
/*     */     }
/*     */     
/* 308 */     Object[] dest = new Object[paramCount];
/*     */     
/* 310 */     for (int i = 0; i < paramCount - 1; i++) {
/* 311 */       dest[i] = ELSupport.coerceToType((ELContext)ctx, src[i], types[i]);
/*     */     }
/*     */     
/* 314 */     if (m.isVarArgs()) {
/* 315 */       Class<?> varArgType = m.getParameterTypes()[paramCount - 1].getComponentType();
/* 316 */       Object[] varArgs = (Object[])Array.newInstance(varArgType, src.length - paramCount - 1);
/* 317 */       for (int j = 0; j < src.length - paramCount - 1; j++) {
/* 318 */         varArgs[j] = ELSupport.coerceToType((ELContext)ctx, src[paramCount - 1 + j], varArgType);
/*     */       }
/* 320 */       dest[paramCount - 1] = varArgs;
/*     */     } else {
/* 322 */       dest[paramCount - 1] = ELSupport.coerceToType((ELContext)ctx, src[paramCount - 1], types[paramCount - 1]);
/*     */     } 
/*     */     
/* 325 */     return dest;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?>[] getTypesFromValues(Object[] values) {
/* 330 */     if (values == null) {
/* 331 */       return null;
/*     */     }
/*     */     
/* 334 */     Class<?>[] result = new Class[values.length];
/* 335 */     for (int i = 0; i < values.length; i++) {
/* 336 */       if (values[i] == null) {
/* 337 */         result[i] = null;
/*     */       } else {
/* 339 */         result[i] = values[i].getClass();
/*     */       } 
/*     */     } 
/* 342 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueReference getValueReference(EvaluationContext ctx) {
/* 352 */     if (this.children.length > 2 && jjtGetChild(2) instanceof AstMethodParameters)
/*     */     {
/* 354 */       return null;
/*     */     }
/* 356 */     Target t = getTarget(ctx);
/* 357 */     return new ValueReference(t.base, t.property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParametersProvided() {
/* 368 */     int len = this.children.length;
/* 369 */     if (len > 2) {
/* 370 */       return jjtGetChild(len - 1) instanceof AstMethodParameters;
/*     */     }
/* 372 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstValue.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */