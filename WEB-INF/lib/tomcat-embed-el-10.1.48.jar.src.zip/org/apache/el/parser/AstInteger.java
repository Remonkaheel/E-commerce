/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import java.math.BigInteger;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstInteger
/*    */   extends SimpleNode
/*    */ {
/*    */   private volatile Number number;
/*    */   
/*    */   public AstInteger(int id) {
/* 29 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Number getInteger() {
/* 38 */     if (this.number == null) {
/*    */       try {
/*    */         try {
/* 41 */           this.number = Long.valueOf(this.image);
/* 42 */         } catch (NumberFormatException ignore) {
/*    */           
/* 44 */           this.number = new BigInteger(this.image);
/*    */         } 
/* 46 */       } catch (ArithmeticException|NumberFormatException e) {
/*    */ 
/*    */ 
/*    */         
/* 50 */         throw new ELException(e);
/*    */       } 
/*    */     }
/* 53 */     return this.number;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 59 */     return getInteger().getClass();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 65 */     return getInteger();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstInteger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */