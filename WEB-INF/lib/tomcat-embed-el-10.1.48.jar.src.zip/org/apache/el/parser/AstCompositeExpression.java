/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstCompositeExpression
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstCompositeExpression(int id) {
/* 28 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 34 */     return String.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 40 */     StringBuilder sb = new StringBuilder(16);
/* 41 */     if (this.children != null)
/*    */     {
/* 43 */       for (Node child : this.children) {
/* 44 */         Object obj = child.getValue(ctx);
/* 45 */         if (obj != null) {
/* 46 */           sb.append(ELSupport.coerceToString((ELContext)ctx, obj));
/*    */         }
/*    */       } 
/*    */     }
/* 50 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstCompositeExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */