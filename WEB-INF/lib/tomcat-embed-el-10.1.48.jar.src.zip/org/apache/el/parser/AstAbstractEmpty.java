/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AstAbstractEmpty
/*    */   extends SimpleNode
/*    */ {
/*    */   private final Boolean RETURN_EMPTY;
/*    */   private final Boolean RETURN_NOT_EMPTY;
/*    */   
/*    */   public AstAbstractEmpty(int id, boolean invert) {
/* 35 */     super(id);
/* 36 */     if (invert) {
/* 37 */       this.RETURN_EMPTY = Boolean.FALSE;
/* 38 */       this.RETURN_NOT_EMPTY = Boolean.TRUE;
/*    */     } else {
/* 40 */       this.RETURN_EMPTY = Boolean.TRUE;
/* 41 */       this.RETURN_NOT_EMPTY = Boolean.FALSE;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 48 */     return Boolean.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 54 */     Object obj = this.children[0].getValue(ctx);
/* 55 */     if (obj == null || (obj instanceof String && ((String)obj).isEmpty()) || (obj instanceof Object[] && ((Object[])obj).length == 0) || (obj instanceof Collection && ((Collection)obj)
/*    */       
/* 57 */       .isEmpty()) || (obj instanceof Map && ((Map)obj)
/* 58 */       .isEmpty())) {
/* 59 */       return this.RETURN_EMPTY;
/*    */     }
/* 61 */     return this.RETURN_NOT_EMPTY;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstAbstractEmpty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */