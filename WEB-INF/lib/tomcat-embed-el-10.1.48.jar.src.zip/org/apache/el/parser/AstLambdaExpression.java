/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.LambdaExpression;
/*     */ import jakarta.el.ValueExpression;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.el.ValueExpressionImpl;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.lang.LambdaExpressionNestedState;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AstLambdaExpression
/*     */   extends SimpleNode
/*     */ {
/*     */   public AstLambdaExpression(int id) {
/*  34 */     super(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/*  43 */     LambdaExpressionNestedState state = ctx.getLambdaExpressionNestedState();
/*  44 */     if (state == null) {
/*     */ 
/*     */       
/*  47 */       state = new LambdaExpressionNestedState();
/*  48 */       populateNestedState(state);
/*  49 */       ctx.setLambdaExpressionNestedState(state);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  54 */     int methodParameterSetCount = jjtGetNumChildren() - 2;
/*  55 */     if (methodParameterSetCount > state.getNestingCount()) {
/*  56 */       throw new ELException(MessageFactory.get("error.lambda.tooManyMethodParameterSets"));
/*     */     }
/*     */ 
/*     */     
/*  60 */     AstLambdaParameters formalParametersNode = (AstLambdaParameters)this.children[0];
/*  61 */     SimpleNode[] arrayOfSimpleNode = formalParametersNode.children;
/*     */ 
/*     */ 
/*     */     
/*  65 */     ValueExpressionImpl ve = new ValueExpressionImpl("", this.children[1], ctx.getFunctionMapper(), ctx.getVariableMapper(), null);
/*     */ 
/*     */     
/*  68 */     List<String> formalParameters = new ArrayList<>();
/*  69 */     if (arrayOfSimpleNode != null) {
/*  70 */       for (Node formalParamNode : arrayOfSimpleNode) {
/*  71 */         formalParameters.add(formalParamNode.getImage());
/*     */       }
/*     */     }
/*  74 */     LambdaExpression le = new LambdaExpression(formalParameters, (ValueExpression)ve);
/*  75 */     le.setELContext((ELContext)ctx);
/*     */     
/*  77 */     if (jjtGetNumChildren() == 2) {
/*     */ 
/*     */ 
/*     */       
/*  81 */       if (state.getHasFormalParameters()) {
/*  82 */         return le;
/*     */       }
/*  84 */       return le.invoke((ELContext)ctx, (Object[])null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     int methodParameterIndex = 2;
/*  99 */     Object result = le.invoke(((AstMethodParameters)this.children[methodParameterIndex]).getParameters(ctx));
/* 100 */     methodParameterIndex++;
/*     */     
/* 102 */     while (result instanceof LambdaExpression && methodParameterIndex < jjtGetNumChildren()) {
/*     */       
/* 104 */       result = ((LambdaExpression)result).invoke(((AstMethodParameters)this.children[methodParameterIndex]).getParameters(ctx));
/* 105 */       methodParameterIndex++;
/*     */     } 
/*     */     
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateNestedState(LambdaExpressionNestedState lambdaExpressionNestedState) {
/* 114 */     lambdaExpressionNestedState.incrementNestingCount();
/*     */     
/* 116 */     if (jjtGetNumChildren() > 1) {
/* 117 */       Node firstChild = jjtGetChild(0);
/* 118 */       if (firstChild instanceof AstLambdaParameters) {
/* 119 */         if (firstChild.jjtGetNumChildren() > 0) {
/* 120 */           lambdaExpressionNestedState.setHasFormalParameters();
/*     */         }
/*     */       } else {
/*     */         return;
/*     */       } 
/*     */       
/* 126 */       Node secondChild = jjtGetChild(1);
/* 127 */       if (secondChild instanceof AstLambdaExpression) {
/* 128 */         ((AstLambdaExpression)secondChild).populateNestedState(lambdaExpressionNestedState);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     StringBuilder result = new StringBuilder();
/* 139 */     for (Node n : this.children) {
/* 140 */       result.append(n.toString());
/*     */     }
/* 142 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstLambdaExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */