/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AstConcatenation
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstConcatenation(int id) {
/* 28 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 35 */     String s1 = ELSupport.coerceToString((ELContext)ctx, this.children[0].getValue(ctx));
/* 36 */     String s2 = ELSupport.coerceToString((ELContext)ctx, this.children[1].getValue(ctx));
/* 37 */     return s1 + s1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 43 */     return String.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstConcatenation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */