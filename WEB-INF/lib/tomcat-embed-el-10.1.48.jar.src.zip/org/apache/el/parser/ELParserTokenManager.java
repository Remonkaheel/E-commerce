/*      */ package org.apache.el.parser;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.Deque;
/*      */ 
/*      */ public class ELParserTokenManager implements ELParserConstants {
/*    8 */   Deque<Integer> deque = new ArrayDeque<>();
/*      */ 
/*      */   
/*   11 */   public PrintStream debugStream = System.out;
/*      */ 
/*      */   
/*      */   public void setDebugStream(PrintStream ds) {
/*   15 */     this.debugStream = ds;
/*      */   }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0) {
/*   19 */     switch (pos) {
/*      */       case 0:
/*   21 */         if ((active0 & 0xCL) != 0L) {
/*   22 */           this.jjmatchedKind = 1;
/*   23 */           return 5;
/*      */         } 
/*   25 */         return -1;
/*      */     } 
/*   27 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0) {
/*   32 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*   36 */     this.jjmatchedKind = kind;
/*   37 */     this.jjmatchedPos = pos;
/*   38 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*   42 */     switch (this.curChar) {
/*      */       case 35:
/*   44 */         return jjMoveStringLiteralDfa1_0(8L);
/*      */       case 36:
/*   46 */         return jjMoveStringLiteralDfa1_0(4L);
/*      */     } 
/*   48 */     return jjMoveNfa_0(7, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_0(long active0) {
/*      */     try {
/*   54 */       this.curChar = this.input_stream.readChar();
/*   55 */     } catch (IOException e) {
/*   56 */       jjStopStringLiteralDfa_0(0, active0);
/*   57 */       return 1;
/*      */     } 
/*   59 */     switch (this.curChar) {
/*      */       case 123:
/*   61 */         if ((active0 & 0x4L) != 0L)
/*   62 */           return jjStopAtPos(1, 2); 
/*   63 */         if ((active0 & 0x8L) != 0L) {
/*   64 */           return jjStopAtPos(1, 3);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*   70 */     return jjStartNfa_0(0, active0);
/*      */   }
/*      */   
/*   73 */   static final long[] jjbitVec0 = new long[] { -2L, -1L, -1L, -1L };
/*      */   
/*   75 */   static final long[] jjbitVec2 = new long[] { 0L, 0L, -1L, -1L };
/*      */   
/*      */   private int jjMoveNfa_0(int startState, int curPos) {
/*   78 */     int startsAt = 0;
/*   79 */     this.jjnewStateCnt = 8;
/*   80 */     int i = 1;
/*   81 */     this.jjstateSet[0] = startState;
/*   82 */     int kind = Integer.MAX_VALUE;
/*      */     while (true) {
/*   84 */       if (++this.jjround == Integer.MAX_VALUE) {
/*   85 */         ReInitRounds();
/*      */       }
/*   87 */       if (this.curChar < 64) {
/*   88 */         long l = 1L << this.curChar;
/*      */         do {
/*   90 */           switch (this.jjstateSet[--i]) {
/*      */             case 7:
/*   92 */               if ((0xFFFFFFE7FFFFFFFFL & l) != 0L) {
/*   93 */                 if (kind > 1) {
/*   94 */                   kind = 1;
/*      */                 }
/*      */                 
/*   97 */                 jjCheckNAddStates(0, 4);
/*      */               }
/*   99 */               else if ((0x1800000000L & l) != 0L) {
/*  100 */                 if (kind > 1) {
/*  101 */                   kind = 1;
/*      */                 }
/*      */                 
/*  104 */                 jjCheckNAdd(5);
/*      */               } 
/*      */               
/*  107 */               if ((0xFFFFFFE7FFFFFFFFL & l) != 0L) {
/*  108 */                 jjCheckNAddTwoStates(0, 1);
/*      */               }
/*      */               break;
/*      */             case 0:
/*  112 */               if ((0xFFFFFFE7FFFFFFFFL & l) != 0L) {
/*  113 */                 jjCheckNAddTwoStates(0, 1);
/*      */               }
/*      */               break;
/*      */             case 2:
/*  117 */               if ((0xFFFFFFE7FFFFFFFFL & l) == 0L) {
/*      */                 break;
/*      */               }
/*  120 */               if (kind > 1) {
/*  121 */                 kind = 1;
/*      */               }
/*  123 */               jjCheckNAddStates(0, 4);
/*      */               break;
/*      */             
/*      */             case 3:
/*  127 */               if ((0xFFFFFFE7FFFFFFFFL & l) != 0L) {
/*  128 */                 jjCheckNAddTwoStates(3, 4);
/*      */               }
/*      */               break;
/*      */             case 4:
/*  132 */               if ((0x1800000000L & l) != 0L) {
/*  133 */                 jjCheckNAdd(5);
/*      */               }
/*      */               break;
/*      */             case 5:
/*  137 */               if ((0xFFFFFFE7FFFFFFFFL & l) == 0L) {
/*      */                 break;
/*      */               }
/*  140 */               if (kind > 1) {
/*  141 */                 kind = 1;
/*      */               }
/*  143 */               jjCheckNAddStates(5, 8);
/*      */               break;
/*      */             
/*      */             case 6:
/*  147 */               if ((0x1800000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  150 */               if (kind > 1) {
/*  151 */                 kind = 1;
/*      */               }
/*  153 */               jjCheckNAddStates(9, 13);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*  159 */         } while (i != startsAt);
/*  160 */       } else if (this.curChar < 128) {
/*  161 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do {
/*  163 */           switch (this.jjstateSet[--i]) {
/*      */             case 7:
/*  165 */               if (kind > 1) {
/*  166 */                 kind = 1;
/*      */               }
/*  168 */               jjCheckNAddStates(0, 4);
/*      */               
/*  170 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*  171 */                 jjCheckNAddTwoStates(0, 1); break;
/*  172 */               }  if (this.curChar == 92) {
/*  173 */                 if (kind > 1) {
/*  174 */                   kind = 1;
/*      */                 }
/*      */                 
/*  177 */                 jjCheckNAddStates(14, 17);
/*      */               } 
/*      */               break;
/*      */             
/*      */             case 0:
/*  182 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*  183 */                 jjCheckNAddTwoStates(0, 1);
/*      */               }
/*      */               break;
/*      */             case 1:
/*  187 */               if (this.curChar != 92) {
/*      */                 break;
/*      */               }
/*  190 */               if (kind > 1) {
/*  191 */                 kind = 1;
/*      */               }
/*  193 */               jjCheckNAddStates(14, 17);
/*      */               break;
/*      */             
/*      */             case 2:
/*  197 */               if (kind > 1) {
/*  198 */                 kind = 1;
/*      */               }
/*  200 */               jjCheckNAddStates(0, 4);
/*      */               break;
/*      */             
/*      */             case 3:
/*  204 */               jjCheckNAddTwoStates(3, 4);
/*      */               break;
/*      */             
/*      */             case 5:
/*  208 */               if ((0xF7FFFFFFEFFFFFFFL & l) == 0L) {
/*      */                 break;
/*      */               }
/*  211 */               if (kind > 1) {
/*  212 */                 kind = 1;
/*      */               }
/*  214 */               jjCheckNAddStates(5, 8);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*  220 */         } while (i != startsAt);
/*      */       } else {
/*  222 */         int hiByte = this.curChar >> 8;
/*  223 */         int i1 = hiByte >> 6;
/*  224 */         long l1 = 1L << (hiByte & 0x3F);
/*  225 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  226 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do {
/*  228 */           switch (this.jjstateSet[--i]) {
/*      */             case 7:
/*  230 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  231 */                 jjCheckNAddTwoStates(0, 1);
/*      */               }
/*  233 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  234 */                 if (kind > 1) {
/*  235 */                   kind = 1;
/*      */                 }
/*      */                 
/*  238 */                 jjCheckNAddStates(0, 4);
/*      */               } 
/*      */               break;
/*      */             
/*      */             case 0:
/*  243 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  244 */                 jjCheckNAddTwoStates(0, 1);
/*      */               }
/*      */               break;
/*      */             case 2:
/*  248 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*      */                 break;
/*      */               }
/*  251 */               if (kind > 1) {
/*  252 */                 kind = 1;
/*      */               }
/*  254 */               jjCheckNAddStates(0, 4);
/*      */               break;
/*      */             
/*      */             case 3:
/*  258 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  259 */                 jjCheckNAddTwoStates(3, 4);
/*      */               }
/*      */               break;
/*      */             case 5:
/*  263 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*      */                 break;
/*      */               }
/*  266 */               if (kind > 1) {
/*  267 */                 kind = 1;
/*      */               }
/*  269 */               jjCheckNAddStates(5, 8);
/*      */               break;
/*      */             
/*      */             default:
/*  273 */               if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*  279 */         } while (i != startsAt);
/*      */       } 
/*  281 */       if (kind != Integer.MAX_VALUE) {
/*  282 */         this.jjmatchedKind = kind;
/*  283 */         this.jjmatchedPos = curPos;
/*  284 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  286 */       curPos++;
/*  287 */       if ((i = this.jjnewStateCnt) == (startsAt = 8 - (this.jjnewStateCnt = startsAt))) {
/*  288 */         return curPos;
/*      */       }
/*      */       try {
/*  291 */         this.curChar = this.input_stream.readChar();
/*  292 */       } catch (IOException e) {
/*  293 */         return curPos;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_2(int pos, long active0) {
/*  299 */     switch (pos) {
/*      */       case 0:
/*  301 */         if ((active0 & 0x20000L) != 0L) {
/*  302 */           return 1;
/*      */         }
/*  304 */         if ((active0 & 0xA0D555401C000L) != 0L) {
/*  305 */           this.jjmatchedKind = 55;
/*  306 */           return 16;
/*      */         } 
/*  308 */         return -1;
/*      */       case 1:
/*  310 */         if ((active0 & 0xA09400001C000L) != 0L) {
/*  311 */           this.jjmatchedKind = 55;
/*  312 */           this.jjmatchedPos = 1;
/*  313 */           return 16;
/*      */         } 
/*  315 */         if ((active0 & 0x41554000000L) != 0L) {
/*  316 */           return 16;
/*      */         }
/*  318 */         return -1;
/*      */       case 2:
/*  320 */         if ((active0 & 0xA014000000000L) != 0L) {
/*  321 */           return 16;
/*      */         }
/*  323 */         if ((active0 & 0x8000001C000L) != 0L) {
/*  324 */           this.jjmatchedKind = 55;
/*  325 */           this.jjmatchedPos = 2;
/*  326 */           return 16;
/*      */         } 
/*  328 */         return -1;
/*      */       case 3:
/*  330 */         if ((active0 & 0x14000L) != 0L) {
/*  331 */           return 16;
/*      */         }
/*  333 */         if ((active0 & 0x80000008000L) != 0L) {
/*  334 */           this.jjmatchedKind = 55;
/*  335 */           this.jjmatchedPos = 3;
/*  336 */           return 16;
/*      */         } 
/*  338 */         return -1;
/*      */     } 
/*  340 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_2(int pos, long active0) {
/*  345 */     return jjMoveNfa_2(jjStopStringLiteralDfa_2(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_2() {
/*  349 */     switch (this.curChar) {
/*      */       case 33:
/*  351 */         this.jjmatchedKind = 37;
/*  352 */         return jjMoveStringLiteralDfa1_2(34359738368L);
/*      */       case 37:
/*  354 */         return jjStopAtPos(0, 50);
/*      */       case 38:
/*  356 */         return jjMoveStringLiteralDfa1_2(549755813888L);
/*      */       case 40:
/*  358 */         return jjStopAtPos(0, 18);
/*      */       case 41:
/*  360 */         return jjStopAtPos(0, 19);
/*      */       case 42:
/*  362 */         return jjStopAtPos(0, 44);
/*      */       case 43:
/*  364 */         this.jjmatchedKind = 45;
/*  365 */         return jjMoveStringLiteralDfa1_2(4503599627370496L);
/*      */       case 44:
/*  367 */         return jjStopAtPos(0, 24);
/*      */       case 45:
/*  369 */         this.jjmatchedKind = 46;
/*  370 */         return jjMoveStringLiteralDfa1_2(18014398509481984L);
/*      */       case 46:
/*  372 */         return jjStartNfaWithStates_2(0, 17, 1);
/*      */       case 47:
/*  374 */         return jjStopAtPos(0, 48);
/*      */       case 58:
/*  376 */         return jjStopAtPos(0, 22);
/*      */       case 59:
/*  378 */         return jjStopAtPos(0, 23);
/*      */       case 60:
/*  380 */         this.jjmatchedKind = 27;
/*  381 */         return jjMoveStringLiteralDfa1_2(2147483648L);
/*      */       case 61:
/*  383 */         this.jjmatchedKind = 53;
/*  384 */         return jjMoveStringLiteralDfa1_2(8589934592L);
/*      */       case 62:
/*  386 */         this.jjmatchedKind = 25;
/*  387 */         return jjMoveStringLiteralDfa1_2(536870912L);
/*      */       case 63:
/*  389 */         return jjStopAtPos(0, 47);
/*      */       case 91:
/*  391 */         return jjStopAtPos(0, 20);
/*      */       case 93:
/*  393 */         return jjStopAtPos(0, 21);
/*      */       case 97:
/*  395 */         return jjMoveStringLiteralDfa1_2(1099511627776L);
/*      */       case 100:
/*  397 */         return jjMoveStringLiteralDfa1_2(562949953421312L);
/*      */       case 101:
/*  399 */         return jjMoveStringLiteralDfa1_2(8813272891392L);
/*      */       case 102:
/*  401 */         return jjMoveStringLiteralDfa1_2(32768L);
/*      */       case 103:
/*  403 */         return jjMoveStringLiteralDfa1_2(1140850688L);
/*      */       case 108:
/*  405 */         return jjMoveStringLiteralDfa1_2(4563402752L);
/*      */       case 109:
/*  407 */         return jjMoveStringLiteralDfa1_2(2251799813685248L);
/*      */       case 110:
/*  409 */         return jjMoveStringLiteralDfa1_2(343597449216L);
/*      */       case 111:
/*  411 */         return jjMoveStringLiteralDfa1_2(4398046511104L);
/*      */       case 116:
/*  413 */         return jjMoveStringLiteralDfa1_2(16384L);
/*      */       case 123:
/*  415 */         return jjStopAtPos(0, 8);
/*      */       case 124:
/*  417 */         return jjMoveStringLiteralDfa1_2(2199023255552L);
/*      */       case 125:
/*  419 */         return jjStopAtPos(0, 9);
/*      */     } 
/*  421 */     return jjMoveNfa_2(0, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_2(long active0) {
/*      */     try {
/*  427 */       this.curChar = this.input_stream.readChar();
/*  428 */     } catch (IOException e) {
/*  429 */       jjStopStringLiteralDfa_2(0, active0);
/*  430 */       return 1;
/*      */     } 
/*  432 */     switch (this.curChar) {
/*      */       case 38:
/*  434 */         if ((active0 & 0x8000000000L) != 0L) {
/*  435 */           return jjStopAtPos(1, 39);
/*      */         }
/*      */         break;
/*      */       case 61:
/*  439 */         if ((active0 & 0x20000000L) != 0L)
/*  440 */           return jjStopAtPos(1, 29); 
/*  441 */         if ((active0 & 0x80000000L) != 0L)
/*  442 */           return jjStopAtPos(1, 31); 
/*  443 */         if ((active0 & 0x200000000L) != 0L)
/*  444 */           return jjStopAtPos(1, 33); 
/*  445 */         if ((active0 & 0x800000000L) != 0L)
/*  446 */           return jjStopAtPos(1, 35); 
/*  447 */         if ((active0 & 0x10000000000000L) != 0L) {
/*  448 */           return jjStopAtPos(1, 52);
/*      */         }
/*      */         break;
/*      */       case 62:
/*  452 */         if ((active0 & 0x40000000000000L) != 0L) {
/*  453 */           return jjStopAtPos(1, 54);
/*      */         }
/*      */         break;
/*      */       case 97:
/*  457 */         return jjMoveStringLiteralDfa2_2(active0, 32768L);
/*      */       case 101:
/*  459 */         if ((active0 & 0x40000000L) != 0L)
/*  460 */           return jjStartNfaWithStates_2(1, 30, 16); 
/*  461 */         if ((active0 & 0x100000000L) != 0L)
/*  462 */           return jjStartNfaWithStates_2(1, 32, 16); 
/*  463 */         if ((active0 & 0x1000000000L) != 0L) {
/*  464 */           return jjStartNfaWithStates_2(1, 36, 16);
/*      */         }
/*      */         break;
/*      */       case 105:
/*  468 */         return jjMoveStringLiteralDfa2_2(active0, 562949953421312L);
/*      */       case 109:
/*  470 */         return jjMoveStringLiteralDfa2_2(active0, 8796093022208L);
/*      */       case 110:
/*  472 */         return jjMoveStringLiteralDfa2_2(active0, 1099511627776L);
/*      */       case 111:
/*  474 */         return jjMoveStringLiteralDfa2_2(active0, 2252074691592192L);
/*      */       case 113:
/*  476 */         if ((active0 & 0x400000000L) != 0L) {
/*  477 */           return jjStartNfaWithStates_2(1, 34, 16);
/*      */         }
/*      */         break;
/*      */       case 114:
/*  481 */         if ((active0 & 0x40000000000L) != 0L) {
/*  482 */           return jjStartNfaWithStates_2(1, 42, 16);
/*      */         }
/*  484 */         return jjMoveStringLiteralDfa2_2(active0, 16384L);
/*      */       case 116:
/*  486 */         if ((active0 & 0x4000000L) != 0L)
/*  487 */           return jjStartNfaWithStates_2(1, 26, 16); 
/*  488 */         if ((active0 & 0x10000000L) != 0L) {
/*  489 */           return jjStartNfaWithStates_2(1, 28, 16);
/*      */         }
/*      */         break;
/*      */       case 117:
/*  493 */         return jjMoveStringLiteralDfa2_2(active0, 65536L);
/*      */       case 124:
/*  495 */         if ((active0 & 0x20000000000L) != 0L) {
/*  496 */           return jjStopAtPos(1, 41);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  502 */     return jjStartNfa_2(0, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_2(long old0, long active0) {
/*  506 */     if ((active0 &= old0) == 0L) {
/*  507 */       return jjStartNfa_2(0, old0);
/*      */     }
/*      */     try {
/*  510 */       this.curChar = this.input_stream.readChar();
/*  511 */     } catch (IOException e) {
/*  512 */       jjStopStringLiteralDfa_2(1, active0);
/*  513 */       return 2;
/*      */     } 
/*  515 */     switch (this.curChar) {
/*      */       case 100:
/*  517 */         if ((active0 & 0x10000000000L) != 0L)
/*  518 */           return jjStartNfaWithStates_2(2, 40, 16); 
/*  519 */         if ((active0 & 0x8000000000000L) != 0L) {
/*  520 */           return jjStartNfaWithStates_2(2, 51, 16);
/*      */         }
/*      */         break;
/*      */       case 108:
/*  524 */         return jjMoveStringLiteralDfa3_2(active0, 98304L);
/*      */       case 112:
/*  526 */         return jjMoveStringLiteralDfa3_2(active0, 8796093022208L);
/*      */       case 116:
/*  528 */         if ((active0 & 0x4000000000L) != 0L) {
/*  529 */           return jjStartNfaWithStates_2(2, 38, 16);
/*      */         }
/*      */         break;
/*      */       case 117:
/*  533 */         return jjMoveStringLiteralDfa3_2(active0, 16384L);
/*      */       case 118:
/*  535 */         if ((active0 & 0x2000000000000L) != 0L) {
/*  536 */           return jjStartNfaWithStates_2(2, 49, 16);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  542 */     return jjStartNfa_2(1, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_2(long old0, long active0) {
/*  546 */     if ((active0 &= old0) == 0L) {
/*  547 */       return jjStartNfa_2(1, old0);
/*      */     }
/*      */     try {
/*  550 */       this.curChar = this.input_stream.readChar();
/*  551 */     } catch (IOException e) {
/*  552 */       jjStopStringLiteralDfa_2(2, active0);
/*  553 */       return 3;
/*      */     } 
/*  555 */     switch (this.curChar) {
/*      */       case 101:
/*  557 */         if ((active0 & 0x4000L) != 0L) {
/*  558 */           return jjStartNfaWithStates_2(3, 14, 16);
/*      */         }
/*      */         break;
/*      */       case 108:
/*  562 */         if ((active0 & 0x10000L) != 0L) {
/*  563 */           return jjStartNfaWithStates_2(3, 16, 16);
/*      */         }
/*      */         break;
/*      */       case 115:
/*  567 */         return jjMoveStringLiteralDfa4_2(active0, 32768L);
/*      */       case 116:
/*  569 */         return jjMoveStringLiteralDfa4_2(active0, 8796093022208L);
/*      */     } 
/*      */ 
/*      */     
/*  573 */     return jjStartNfa_2(2, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_2(long old0, long active0) {
/*  577 */     if ((active0 &= old0) == 0L) {
/*  578 */       return jjStartNfa_2(2, old0);
/*      */     }
/*      */     try {
/*  581 */       this.curChar = this.input_stream.readChar();
/*  582 */     } catch (IOException e) {
/*  583 */       jjStopStringLiteralDfa_2(3, active0);
/*  584 */       return 4;
/*      */     } 
/*  586 */     switch (this.curChar) {
/*      */       case 101:
/*  588 */         if ((active0 & 0x8000L) != 0L) {
/*  589 */           return jjStartNfaWithStates_2(4, 15, 16);
/*      */         }
/*      */         break;
/*      */       case 121:
/*  593 */         if ((active0 & 0x80000000000L) != 0L) {
/*  594 */           return jjStartNfaWithStates_2(4, 43, 16);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  600 */     return jjStartNfa_2(3, active0);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_2(int pos, int kind, int state) {
/*  604 */     this.jjmatchedKind = kind;
/*  605 */     this.jjmatchedPos = pos;
/*      */     try {
/*  607 */       this.curChar = this.input_stream.readChar();
/*  608 */     } catch (IOException e) {
/*  609 */       return pos + 1;
/*      */     } 
/*  611 */     return jjMoveNfa_2(state, pos + 1);
/*      */   }
/*      */   
/*  614 */   static final long[] jjbitVec3 = new long[] { -4503598551400446L, -8193L, -17388175097857L, 1297036692691091455L };
/*      */   
/*  616 */   static final long[] jjbitVec4 = new long[] { 0L, 0L, 297242231151001600L, -36028797027352577L };
/*  617 */   static final long[] jjbitVec5 = new long[] { -1L, -1L, -1L, 88094074470339L };
/*  618 */   static final long[] jjbitVec6 = new long[] { 0L, -4837147474772623360L, -17179879616L, -18014398509481985L };
/*  619 */   static final long[] jjbitVec7 = new long[] { -1L, -1L, -1021L, -1L };
/*      */   
/*  621 */   static final long[] jjbitVec8 = new long[] { -281474976710657L, -8547991553L, 33023L, 1979120929931264L };
/*  622 */   static final long[] jjbitVec9 = new long[] { -4294965248L, -351843720886273L, -1L, -7205547885240254465L };
/*      */   
/*  624 */   static final long[] jjbitVec10 = new long[] { 281474976514048L, -8192L, 563224831328255L, 301749971126844416L };
/*  625 */   static final long[] jjbitVec11 = new long[] { 1168302407679L, 8791831609343L, 4602678814877679616L, 0L };
/*  626 */   static final long[] jjbitVec12 = new long[] { 2594073385365405680L, -562932790263808L, 2577745637692514273L, 1733604397398638592L };
/*      */   
/*  628 */   static final long[] jjbitVec13 = new long[] { 247132830528276448L, 7881300924956672L, 2589004636761079776L, 144678150914244608L };
/*  629 */   static final long[] jjbitVec14 = new long[] { 2589004636760940512L, 562965791113216L, 288167810662516712L, 144115188075921408L };
/*  630 */   static final long[] jjbitVec15 = new long[] { 2594071186342010848L, 13002342400L, 2589567586714640353L, 1688863818907648L };
/*  631 */   static final long[] jjbitVec16 = new long[] { 2882303761516978144L, -288230361111969792L, 3457638613854978016L, 127L };
/*  632 */   static final long[] jjbitVec17 = new long[] { -9219431387180826626L, 127L, 2309762420256548246L, 4026531935L };
/*  633 */   static final long[] jjbitVec18 = new long[] { 1L, 35184372088575L, 7936L, 0L };
/*  634 */   static final long[] jjbitVec19 = new long[] { -9223363240761753601L, -8514196127940608L, -4294950909L, -576460752303480641L };
/*      */   
/*  636 */   static final long[] jjbitVec20 = new long[] { -1L, -3263218177L, 9168765891372858879L, -8388803L };
/*      */   
/*  638 */   static final long[] jjbitVec21 = new long[] { -12713985L, 134217727L, -4294901761L, 4557642822898941951L };
/*  639 */   static final long[] jjbitVec22 = new long[] { -1L, -105553116266497L, -4160749570L, 144053615424700415L };
/*      */   
/*  641 */   static final long[] jjbitVec23 = new long[] { 1125895612129279L, 527761286627327L, 4503599627370495L, 411041792L };
/*  642 */   static final long[] jjbitVec24 = new long[] { -4294967296L, 72057594037927935L, -274877906944097L, 18014398509481983L };
/*  643 */   static final long[] jjbitVec25 = new long[] { 2147483647L, 8796093022142464L, -263882790666241L, 1023L };
/*  644 */   static final long[] jjbitVec26 = new long[] { -4286578689L, 2097151L, 549755813888L, 0L };
/*  645 */   static final long[] jjbitVec27 = new long[] { 4503599627370464L, 4064L, -288019261329244168L, 274877906943L };
/*  646 */   static final long[] jjbitVec28 = new long[] { 68719476735L, 4611686018360336384L, 511L, 28110114275721216L };
/*  647 */   static final long[] jjbitVec29 = new long[] { -1L, -1L, -1L, 0L };
/*  648 */   static final long[] jjbitVec30 = new long[] { -3233808385L, 4611686017001275199L, 6908521828386340863L, 2295745090394464220L };
/*      */   
/*  650 */   static final long[] jjbitVec31 = new long[] { Long.MIN_VALUE, -9222809086900305919L, -3758161920L, 0L };
/*  651 */   static final long[] jjbitVec32 = new long[] { -864764451093480316L, -4294949920L, 511L, 0L };
/*  652 */   static final long[] jjbitVec33 = new long[] { -140737488355329L, -2147483649L, -1L, 3509778554814463L };
/*      */   
/*  654 */   static final long[] jjbitVec34 = new long[] { -245465970900993L, 141836999983103L, 9187201948305063935L, 2139062143L };
/*  655 */   static final long[] jjbitVec35 = new long[] { 140737488355328L, 0L, 0L, 0L };
/*  656 */   static final long[] jjbitVec36 = new long[] { 2251241253188403424L, -2L, -4823449601L, -576460752303423489L };
/*      */   
/*  658 */   static final long[] jjbitVec37 = new long[] { -422212465066016L, -1L, 576460748008488959L, -281474976710656L };
/*      */   
/*  660 */   static final long[] jjbitVec38 = new long[] { -1L, -1L, 18014398509481983L, 0L };
/*  661 */   static final long[] jjbitVec39 = new long[] { -1L, -1L, -1L, 8796093022207L };
/*  662 */   static final long[] jjbitVec40 = new long[] { -1L, -1L, 8191L, 4611686018427322368L };
/*  663 */   static final long[] jjbitVec41 = new long[] { 13198434443263L, -9223231299366420481L, -3221225473L, 281474976710655L };
/*  664 */   static final long[] jjbitVec42 = new long[] { -12893290496L, -1L, 71916856549571071L, -36028797018963968L };
/*      */   
/*  666 */   static final long[] jjbitVec43 = new long[] { 72057628397664187L, 4503599627370495L, 4503599627370492L, 2953235455648202752L };
/*  667 */   static final long[] jjbitVec44 = new long[] { -281200098804736L, 2305843004918726783L, 2251799813685232L, 8935422993945886720L };
/*      */   
/*  669 */   static final long[] jjbitVec45 = new long[] { 2199023255551L, -4287426849551675401L, 4495436853045886975L, 7890092085477381L };
/*  670 */   static final long[] jjbitVec46 = new long[] { -141291530846594L, -281200233021441L, -1L, 34359738367L };
/*  671 */   static final long[] jjbitVec47 = new long[] { -1L, -1L, -281406257233921L, 1152921504606845055L };
/*      */   
/*  673 */   static final long[] jjbitVec48 = new long[] { -1L, -211106232532993L, -1L, 67108863L };
/*  674 */   static final long[] jjbitVec49 = new long[] { 6881498030004502655L, -37L, 1125899906842623L, -524288L };
/*      */   
/*  676 */   static final long[] jjbitVec50 = new long[] { 4611686018427387903L, -65536L, -196609L, 2305561534236983551L };
/*      */   
/*  678 */   static final long[] jjbitVec51 = new long[] { 6755399441055744L, -9286475208138752L, -1L, 2305843009213693951L };
/*      */   
/*  680 */   static final long[] jjbitVec52 = new long[] { -8646911293141286896L, -274743689218L, Long.MAX_VALUE, 425688104188L };
/*  681 */   static final long[] jjbitVec53 = new long[] { 0L, 0L, 297277419818057727L, -36028797027352577L };
/*  682 */   static final long[] jjbitVec54 = new long[] { -1L, -4836865999795912705L, -17179879616L, -18014398509481985L };
/*      */   
/*  684 */   static final long[] jjbitVec55 = new long[] { -1L, -1L, -773L, -1L };
/*      */   
/*  686 */   static final long[] jjbitVec56 = new long[] { -281474976710657L, -8547991553L, -4611686018427485953L, 1979120929931446L };
/*      */   
/*  688 */   static final long[] jjbitVec57 = new long[] { -3892377537L, -65970697666561L, -1L, -6917531227739127809L };
/*      */   
/*  690 */   static final long[] jjbitVec58 = new long[] { -32768L, -6145L, 1125899906842623L, 306244774661193727L };
/*  691 */   static final long[] jjbitVec59 = new long[] { 70368744177663L, 8792066490367L, 4602678814877679616L, -1048576L };
/*  692 */   static final long[] jjbitVec60 = new long[] { -1L, -281681135140865L, -881018876128026641L, 1733885649045453215L };
/*      */   
/*  694 */   static final long[] jjbitVec61 = new long[] { -3211631683292264466L, 18014125208779143L, -869759877059461138L, -143270973599040577L };
/*      */   
/*  696 */   static final long[] jjbitVec62 = new long[] { -869759877059600402L, 844217442122143L, -4323518207764871188L, 144396388183129543L };
/*  697 */   static final long[] jjbitVec63 = new long[] { -2017614832085377041L, 281264647060959L, -869196927105900561L, 1970115463626207L };
/*  698 */   static final long[] jjbitVec64 = new long[] { -139281L, -287949109465154081L, 3457638613854978028L, 3658904103781503L };
/*      */   
/*  700 */   static final long[] jjbitVec65 = new long[] { -8646911284551352322L, 67076095L, 4323434403644581270L, 4093591391L };
/*  701 */   static final long[] jjbitVec66 = new long[] { -4422530440275951615L, -527765581332737L, 2305843009196916703L, 64L };
/*  702 */   static final long[] jjbitVec67 = new long[] { -1L, -64513L, -3221225473L, -576460752303480641L };
/*      */   
/*  704 */   static final long[] jjbitVec68 = new long[] { -12713985L, 3892314111L, -4294901761L, 4557642822898941951L };
/*  705 */   static final long[] jjbitVec69 = new long[] { 9007194961862655L, 3905461007941631L, -1L, 4394700505087L };
/*  706 */   static final long[] jjbitVec70 = new long[] { -4227893248L, 72057594037927935L, -272678883688449L, 18014398509481983L };
/*  707 */   static final long[] jjbitVec71 = new long[] { 1152657619668697087L, 8796093022207936L, -263882790666241L, 67044351L };
/*  708 */   static final long[] jjbitVec72 = new long[] { -4026531841L, -6917529029788565505L, 4611405093273535487L, 0L };
/*  709 */   static final long[] jjbitVec73 = new long[] { -1L, 4494803601395711L, -1L, 4503599627370495L };
/*  710 */   static final long[] jjbitVec74 = new long[] { 72057594037927935L, 4611686018427380735L, 511L, 288230376151121920L };
/*  711 */   static final long[] jjbitVec75 = new long[] { -1L, -1L, -1L, -288230376151711745L };
/*      */   
/*  713 */   static final long[] jjbitVec76 = new long[] { -9223235697412868096L, -9222527753657516031L, -3758161920L, 562821641207808L };
/*      */   
/*  715 */   static final long[] jjbitVec77 = new long[] { -140737488355329L, -2147483649L, -1L, 4494940973301759L };
/*      */   
/*  717 */   static final long[] jjbitVec78 = new long[] { -245465970900993L, -9223230199854792705L, 9187201948305063935L, -2155905153L };
/*      */   
/*  719 */   static final long[] jjbitVec79 = new long[] { 2251518330118602976L, -2L, -4722786305L, -576460752303423489L };
/*      */   
/*  721 */   static final long[] jjbitVec80 = new long[] { 17592185987071L, -4615908143078047745L, -1L, 1125899906842623L };
/*  722 */   static final long[] jjbitVec81 = new long[] { 72058693549555711L, 4503599627370495L, -1L, 2954361351327121471L };
/*  723 */   static final long[] jjbitVec82 = new long[] { -211106232532993L, 2305843004919775231L, -1L, 9223372032626884609L };
/*      */   
/*  725 */   static final long[] jjbitVec83 = new long[] { 36028797018963967L, -252201583360655361L, -1L, 35184368733388807L };
/*  726 */   static final long[] jjbitVec84 = new long[] { -141291530846594L, -281200233021441L, -1L, 288010473826156543L };
/*      */   
/*  728 */   static final long[] jjbitVec85 = new long[] { 6881498031078244479L, -37L, 1125899906842623L, -524288L };
/*      */   
/*  730 */   static final long[] jjbitVec86 = new long[] { 7036870122864639L, -9286475208138752L, -1L, -6917529027641081857L };
/*      */   
/*  732 */   static final long[] jjbitVec87 = new long[] { -8646911293074243568L, -274743689218L, Long.MAX_VALUE, 1008806742219095292L };
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_2(int startState, int curPos) {
/*  736 */     int startsAt = 0;
/*  737 */     this.jjnewStateCnt = 29;
/*  738 */     int i = 1;
/*  739 */     this.jjstateSet[0] = startState;
/*  740 */     int kind = Integer.MAX_VALUE;
/*      */     while (true) {
/*  742 */       if (++this.jjround == Integer.MAX_VALUE) {
/*  743 */         ReInitRounds();
/*      */       }
/*  745 */       if (this.curChar < 64) {
/*  746 */         long l = 1L << this.curChar;
/*      */         do {
/*  748 */           switch (this.jjstateSet[--i]) {
/*      */             case 0:
/*  750 */               if ((0x3FF000000000000L & l) != 0L) {
/*  751 */                 if (kind > 10) {
/*  752 */                   kind = 10;
/*      */                 }
/*      */                 
/*  755 */                 jjCheckNAddStates(18, 22); break;
/*      */               } 
/*  757 */               if (this.curChar == 36) {
/*  758 */                 if (kind > 55) {
/*  759 */                   kind = 55;
/*      */                 }
/*      */                 
/*  762 */                 jjCheckNAdd(16); break;
/*      */               } 
/*  764 */               if (this.curChar == 39) {
/*  765 */                 jjCheckNAddStates(23, 25); break;
/*  766 */               }  if (this.curChar == 34) {
/*  767 */                 jjCheckNAddStates(26, 28); break;
/*  768 */               }  if (this.curChar == 46) {
/*  769 */                 jjCheckNAdd(1);
/*      */               }
/*      */               break;
/*      */             case 1:
/*  773 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  776 */               if (kind > 11) {
/*  777 */                 kind = 11;
/*      */               }
/*  779 */               jjCheckNAddTwoStates(1, 2);
/*      */               break;
/*      */             
/*      */             case 3:
/*  783 */               if ((0x280000000000L & l) != 0L) {
/*  784 */                 jjCheckNAdd(4);
/*      */               }
/*      */               break;
/*      */             case 4:
/*  788 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  791 */               if (kind > 11) {
/*  792 */                 kind = 11;
/*      */               }
/*  794 */               jjCheckNAdd(4);
/*      */               break;
/*      */             
/*      */             case 5:
/*  798 */               if (this.curChar == 34) {
/*  799 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 6:
/*  803 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L) {
/*  804 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 8:
/*  808 */               if ((0x8400000000L & l) != 0L) {
/*  809 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 9:
/*  813 */               if (this.curChar == 34 && kind > 13) {
/*  814 */                 kind = 13;
/*      */               }
/*      */               break;
/*      */             case 10:
/*  818 */               if (this.curChar == 39) {
/*  819 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 11:
/*  823 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L) {
/*  824 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 13:
/*  828 */               if ((0x8400000000L & l) != 0L) {
/*  829 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 14:
/*  833 */               if (this.curChar == 39 && kind > 13) {
/*  834 */                 kind = 13;
/*      */               }
/*      */               break;
/*      */             case 15:
/*  838 */               if (this.curChar != 36) {
/*      */                 break;
/*      */               }
/*  841 */               if (kind > 55) {
/*  842 */                 kind = 55;
/*      */               }
/*  844 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 16:
/*  848 */               if ((0x3FF00100FFFC1FFL & l) == 0L) {
/*      */                 break;
/*      */               }
/*  851 */               if (kind > 55) {
/*  852 */                 kind = 55;
/*      */               }
/*  854 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 17:
/*  858 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  861 */               if (kind > 10) {
/*  862 */                 kind = 10;
/*      */               }
/*  864 */               jjCheckNAddStates(18, 22);
/*      */               break;
/*      */             
/*      */             case 18:
/*  868 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  871 */               if (kind > 10) {
/*  872 */                 kind = 10;
/*      */               }
/*  874 */               jjCheckNAdd(18);
/*      */               break;
/*      */             
/*      */             case 19:
/*  878 */               if ((0x3FF000000000000L & l) != 0L) {
/*  879 */                 jjCheckNAddTwoStates(19, 20);
/*      */               }
/*      */               break;
/*      */             case 20:
/*  883 */               if (this.curChar != 46) {
/*      */                 break;
/*      */               }
/*  886 */               if (kind > 11) {
/*  887 */                 kind = 11;
/*      */               }
/*  889 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             
/*      */             case 21:
/*  893 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  896 */               if (kind > 11) {
/*  897 */                 kind = 11;
/*      */               }
/*  899 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             
/*      */             case 23:
/*  903 */               if ((0x280000000000L & l) != 0L) {
/*  904 */                 jjCheckNAdd(24);
/*      */               }
/*      */               break;
/*      */             case 24:
/*  908 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  911 */               if (kind > 11) {
/*  912 */                 kind = 11;
/*      */               }
/*  914 */               jjCheckNAdd(24);
/*      */               break;
/*      */             
/*      */             case 25:
/*  918 */               if ((0x3FF000000000000L & l) != 0L) {
/*  919 */                 jjCheckNAddTwoStates(25, 26);
/*      */               }
/*      */               break;
/*      */             case 27:
/*  923 */               if ((0x280000000000L & l) != 0L) {
/*  924 */                 jjCheckNAdd(28);
/*      */               }
/*      */               break;
/*      */             case 28:
/*  928 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/*  931 */               if (kind > 11) {
/*  932 */                 kind = 11;
/*      */               }
/*  934 */               jjCheckNAdd(28);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*  940 */         } while (i != startsAt);
/*  941 */       } else if (this.curChar < 128) {
/*  942 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do {
/*  944 */           switch (this.jjstateSet[--i]) {
/*      */             case 0:
/*  946 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L) {
/*      */                 break;
/*      */               }
/*  949 */               if (kind > 55) {
/*  950 */                 kind = 55;
/*      */               }
/*  952 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 2:
/*  956 */               if ((0x2000000020L & l) != 0L) {
/*  957 */                 jjAddStates(29, 30);
/*      */               }
/*      */               break;
/*      */             case 6:
/*  961 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*  962 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 7:
/*  966 */               if (this.curChar == 92) {
/*  967 */                 this.jjstateSet[this.jjnewStateCnt++] = 8;
/*      */               }
/*      */               break;
/*      */             case 8:
/*  971 */               if (this.curChar == 92) {
/*  972 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 11:
/*  976 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*  977 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 12:
/*  981 */               if (this.curChar == 92) {
/*  982 */                 this.jjstateSet[this.jjnewStateCnt++] = 13;
/*      */               }
/*      */               break;
/*      */             case 13:
/*  986 */               if (this.curChar == 92) {
/*  987 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 16:
/*  991 */               if ((0x87FFFFFE87FFFFFEL & l) == 0L) {
/*      */                 break;
/*      */               }
/*  994 */               if (kind > 55) {
/*  995 */                 kind = 55;
/*      */               }
/*  997 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 22:
/* 1001 */               if ((0x2000000020L & l) != 0L) {
/* 1002 */                 jjAddStates(31, 32);
/*      */               }
/*      */               break;
/*      */             case 26:
/* 1006 */               if ((0x2000000020L & l) != 0L) {
/* 1007 */                 jjAddStates(33, 34);
/*      */               }
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/* 1013 */         } while (i != startsAt);
/*      */       } else {
/* 1015 */         int hiByte = this.curChar >> 8;
/* 1016 */         int i1 = hiByte >> 6;
/* 1017 */         long l1 = 1L << (hiByte & 0x3F);
/* 1018 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1019 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do {
/* 1021 */           switch (this.jjstateSet[--i]) {
/*      */             case 0:
/* 1023 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2)) {
/*      */                 break;
/*      */               }
/* 1026 */               if (kind > 55) {
/* 1027 */                 kind = 55;
/*      */               }
/* 1029 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 6:
/* 1033 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1034 */                 jjAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 11:
/* 1038 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1039 */                 jjAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 16:
/* 1043 */               if (!jjCanMove_2(hiByte, i1, i2, l1, l2)) {
/*      */                 break;
/*      */               }
/* 1046 */               if (kind > 55) {
/* 1047 */                 kind = 55;
/*      */               }
/* 1049 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             default:
/* 1053 */               if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 1059 */         } while (i != startsAt);
/*      */       } 
/* 1061 */       if (kind != Integer.MAX_VALUE) {
/* 1062 */         this.jjmatchedKind = kind;
/* 1063 */         this.jjmatchedPos = curPos;
/* 1064 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1066 */       curPos++;
/* 1067 */       if ((i = this.jjnewStateCnt) == (startsAt = 29 - (this.jjnewStateCnt = startsAt))) {
/* 1068 */         return curPos;
/*      */       }
/*      */       try {
/* 1071 */         this.curChar = this.input_stream.readChar();
/* 1072 */       } catch (IOException e) {
/* 1073 */         return curPos;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_1(int pos, long active0) {
/* 1079 */     switch (pos) {
/*      */       case 0:
/* 1081 */         if ((active0 & 0x20000L) != 0L) {
/* 1082 */           return 1;
/*      */         }
/* 1084 */         if ((active0 & 0xA0D555401C000L) != 0L) {
/* 1085 */           this.jjmatchedKind = 55;
/* 1086 */           return 16;
/*      */         } 
/* 1088 */         return -1;
/*      */       case 1:
/* 1090 */         if ((active0 & 0xA09400001C000L) != 0L) {
/* 1091 */           this.jjmatchedKind = 55;
/* 1092 */           this.jjmatchedPos = 1;
/* 1093 */           return 16;
/*      */         } 
/* 1095 */         if ((active0 & 0x41554000000L) != 0L) {
/* 1096 */           return 16;
/*      */         }
/* 1098 */         return -1;
/*      */       case 2:
/* 1100 */         if ((active0 & 0xA014000000000L) != 0L) {
/* 1101 */           return 16;
/*      */         }
/* 1103 */         if ((active0 & 0x8000001C000L) != 0L) {
/* 1104 */           this.jjmatchedKind = 55;
/* 1105 */           this.jjmatchedPos = 2;
/* 1106 */           return 16;
/*      */         } 
/* 1108 */         return -1;
/*      */       case 3:
/* 1110 */         if ((active0 & 0x14000L) != 0L) {
/* 1111 */           return 16;
/*      */         }
/* 1113 */         if ((active0 & 0x80000008000L) != 0L) {
/* 1114 */           this.jjmatchedKind = 55;
/* 1115 */           this.jjmatchedPos = 3;
/* 1116 */           return 16;
/*      */         } 
/* 1118 */         return -1;
/*      */     } 
/* 1120 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_1(int pos, long active0) {
/* 1125 */     return jjMoveNfa_1(jjStopStringLiteralDfa_1(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_1() {
/* 1129 */     switch (this.curChar) {
/*      */       case 33:
/* 1131 */         this.jjmatchedKind = 37;
/* 1132 */         return jjMoveStringLiteralDfa1_1(34359738368L);
/*      */       case 37:
/* 1134 */         return jjStopAtPos(0, 50);
/*      */       case 38:
/* 1136 */         return jjMoveStringLiteralDfa1_1(549755813888L);
/*      */       case 40:
/* 1138 */         return jjStopAtPos(0, 18);
/*      */       case 41:
/* 1140 */         return jjStopAtPos(0, 19);
/*      */       case 42:
/* 1142 */         return jjStopAtPos(0, 44);
/*      */       case 43:
/* 1144 */         this.jjmatchedKind = 45;
/* 1145 */         return jjMoveStringLiteralDfa1_1(4503599627370496L);
/*      */       case 44:
/* 1147 */         return jjStopAtPos(0, 24);
/*      */       case 45:
/* 1149 */         this.jjmatchedKind = 46;
/* 1150 */         return jjMoveStringLiteralDfa1_1(18014398509481984L);
/*      */       case 46:
/* 1152 */         return jjStartNfaWithStates_1(0, 17, 1);
/*      */       case 47:
/* 1154 */         return jjStopAtPos(0, 48);
/*      */       case 58:
/* 1156 */         return jjStopAtPos(0, 22);
/*      */       case 59:
/* 1158 */         return jjStopAtPos(0, 23);
/*      */       case 60:
/* 1160 */         this.jjmatchedKind = 27;
/* 1161 */         return jjMoveStringLiteralDfa1_1(2147483648L);
/*      */       case 61:
/* 1163 */         this.jjmatchedKind = 53;
/* 1164 */         return jjMoveStringLiteralDfa1_1(8589934592L);
/*      */       case 62:
/* 1166 */         this.jjmatchedKind = 25;
/* 1167 */         return jjMoveStringLiteralDfa1_1(536870912L);
/*      */       case 63:
/* 1169 */         return jjStopAtPos(0, 47);
/*      */       case 91:
/* 1171 */         return jjStopAtPos(0, 20);
/*      */       case 93:
/* 1173 */         return jjStopAtPos(0, 21);
/*      */       case 97:
/* 1175 */         return jjMoveStringLiteralDfa1_1(1099511627776L);
/*      */       case 100:
/* 1177 */         return jjMoveStringLiteralDfa1_1(562949953421312L);
/*      */       case 101:
/* 1179 */         return jjMoveStringLiteralDfa1_1(8813272891392L);
/*      */       case 102:
/* 1181 */         return jjMoveStringLiteralDfa1_1(32768L);
/*      */       case 103:
/* 1183 */         return jjMoveStringLiteralDfa1_1(1140850688L);
/*      */       case 108:
/* 1185 */         return jjMoveStringLiteralDfa1_1(4563402752L);
/*      */       case 109:
/* 1187 */         return jjMoveStringLiteralDfa1_1(2251799813685248L);
/*      */       case 110:
/* 1189 */         return jjMoveStringLiteralDfa1_1(343597449216L);
/*      */       case 111:
/* 1191 */         return jjMoveStringLiteralDfa1_1(4398046511104L);
/*      */       case 116:
/* 1193 */         return jjMoveStringLiteralDfa1_1(16384L);
/*      */       case 123:
/* 1195 */         return jjStopAtPos(0, 8);
/*      */       case 124:
/* 1197 */         return jjMoveStringLiteralDfa1_1(2199023255552L);
/*      */       case 125:
/* 1199 */         return jjStopAtPos(0, 9);
/*      */     } 
/* 1201 */     return jjMoveNfa_1(0, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_1(long active0) {
/*      */     try {
/* 1207 */       this.curChar = this.input_stream.readChar();
/* 1208 */     } catch (IOException e) {
/* 1209 */       jjStopStringLiteralDfa_1(0, active0);
/* 1210 */       return 1;
/*      */     } 
/* 1212 */     switch (this.curChar) {
/*      */       case 38:
/* 1214 */         if ((active0 & 0x8000000000L) != 0L) {
/* 1215 */           return jjStopAtPos(1, 39);
/*      */         }
/*      */         break;
/*      */       case 61:
/* 1219 */         if ((active0 & 0x20000000L) != 0L)
/* 1220 */           return jjStopAtPos(1, 29); 
/* 1221 */         if ((active0 & 0x80000000L) != 0L)
/* 1222 */           return jjStopAtPos(1, 31); 
/* 1223 */         if ((active0 & 0x200000000L) != 0L)
/* 1224 */           return jjStopAtPos(1, 33); 
/* 1225 */         if ((active0 & 0x800000000L) != 0L)
/* 1226 */           return jjStopAtPos(1, 35); 
/* 1227 */         if ((active0 & 0x10000000000000L) != 0L) {
/* 1228 */           return jjStopAtPos(1, 52);
/*      */         }
/*      */         break;
/*      */       case 62:
/* 1232 */         if ((active0 & 0x40000000000000L) != 0L) {
/* 1233 */           return jjStopAtPos(1, 54);
/*      */         }
/*      */         break;
/*      */       case 97:
/* 1237 */         return jjMoveStringLiteralDfa2_1(active0, 32768L);
/*      */       case 101:
/* 1239 */         if ((active0 & 0x40000000L) != 0L)
/* 1240 */           return jjStartNfaWithStates_1(1, 30, 16); 
/* 1241 */         if ((active0 & 0x100000000L) != 0L)
/* 1242 */           return jjStartNfaWithStates_1(1, 32, 16); 
/* 1243 */         if ((active0 & 0x1000000000L) != 0L) {
/* 1244 */           return jjStartNfaWithStates_1(1, 36, 16);
/*      */         }
/*      */         break;
/*      */       case 105:
/* 1248 */         return jjMoveStringLiteralDfa2_1(active0, 562949953421312L);
/*      */       case 109:
/* 1250 */         return jjMoveStringLiteralDfa2_1(active0, 8796093022208L);
/*      */       case 110:
/* 1252 */         return jjMoveStringLiteralDfa2_1(active0, 1099511627776L);
/*      */       case 111:
/* 1254 */         return jjMoveStringLiteralDfa2_1(active0, 2252074691592192L);
/*      */       case 113:
/* 1256 */         if ((active0 & 0x400000000L) != 0L) {
/* 1257 */           return jjStartNfaWithStates_1(1, 34, 16);
/*      */         }
/*      */         break;
/*      */       case 114:
/* 1261 */         if ((active0 & 0x40000000000L) != 0L) {
/* 1262 */           return jjStartNfaWithStates_1(1, 42, 16);
/*      */         }
/* 1264 */         return jjMoveStringLiteralDfa2_1(active0, 16384L);
/*      */       case 116:
/* 1266 */         if ((active0 & 0x4000000L) != 0L)
/* 1267 */           return jjStartNfaWithStates_1(1, 26, 16); 
/* 1268 */         if ((active0 & 0x10000000L) != 0L) {
/* 1269 */           return jjStartNfaWithStates_1(1, 28, 16);
/*      */         }
/*      */         break;
/*      */       case 117:
/* 1273 */         return jjMoveStringLiteralDfa2_1(active0, 65536L);
/*      */       case 124:
/* 1275 */         if ((active0 & 0x20000000000L) != 0L) {
/* 1276 */           return jjStopAtPos(1, 41);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1282 */     return jjStartNfa_1(0, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_1(long old0, long active0) {
/* 1286 */     if ((active0 &= old0) == 0L) {
/* 1287 */       return jjStartNfa_1(0, old0);
/*      */     }
/*      */     try {
/* 1290 */       this.curChar = this.input_stream.readChar();
/* 1291 */     } catch (IOException e) {
/* 1292 */       jjStopStringLiteralDfa_1(1, active0);
/* 1293 */       return 2;
/*      */     } 
/* 1295 */     switch (this.curChar) {
/*      */       case 100:
/* 1297 */         if ((active0 & 0x10000000000L) != 0L)
/* 1298 */           return jjStartNfaWithStates_1(2, 40, 16); 
/* 1299 */         if ((active0 & 0x8000000000000L) != 0L) {
/* 1300 */           return jjStartNfaWithStates_1(2, 51, 16);
/*      */         }
/*      */         break;
/*      */       case 108:
/* 1304 */         return jjMoveStringLiteralDfa3_1(active0, 98304L);
/*      */       case 112:
/* 1306 */         return jjMoveStringLiteralDfa3_1(active0, 8796093022208L);
/*      */       case 116:
/* 1308 */         if ((active0 & 0x4000000000L) != 0L) {
/* 1309 */           return jjStartNfaWithStates_1(2, 38, 16);
/*      */         }
/*      */         break;
/*      */       case 117:
/* 1313 */         return jjMoveStringLiteralDfa3_1(active0, 16384L);
/*      */       case 118:
/* 1315 */         if ((active0 & 0x2000000000000L) != 0L) {
/* 1316 */           return jjStartNfaWithStates_1(2, 49, 16);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1322 */     return jjStartNfa_1(1, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_1(long old0, long active0) {
/* 1326 */     if ((active0 &= old0) == 0L) {
/* 1327 */       return jjStartNfa_1(1, old0);
/*      */     }
/*      */     try {
/* 1330 */       this.curChar = this.input_stream.readChar();
/* 1331 */     } catch (IOException e) {
/* 1332 */       jjStopStringLiteralDfa_1(2, active0);
/* 1333 */       return 3;
/*      */     } 
/* 1335 */     switch (this.curChar) {
/*      */       case 101:
/* 1337 */         if ((active0 & 0x4000L) != 0L) {
/* 1338 */           return jjStartNfaWithStates_1(3, 14, 16);
/*      */         }
/*      */         break;
/*      */       case 108:
/* 1342 */         if ((active0 & 0x10000L) != 0L) {
/* 1343 */           return jjStartNfaWithStates_1(3, 16, 16);
/*      */         }
/*      */         break;
/*      */       case 115:
/* 1347 */         return jjMoveStringLiteralDfa4_1(active0, 32768L);
/*      */       case 116:
/* 1349 */         return jjMoveStringLiteralDfa4_1(active0, 8796093022208L);
/*      */     } 
/*      */ 
/*      */     
/* 1353 */     return jjStartNfa_1(2, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_1(long old0, long active0) {
/* 1357 */     if ((active0 &= old0) == 0L) {
/* 1358 */       return jjStartNfa_1(2, old0);
/*      */     }
/*      */     try {
/* 1361 */       this.curChar = this.input_stream.readChar();
/* 1362 */     } catch (IOException e) {
/* 1363 */       jjStopStringLiteralDfa_1(3, active0);
/* 1364 */       return 4;
/*      */     } 
/* 1366 */     switch (this.curChar) {
/*      */       case 101:
/* 1368 */         if ((active0 & 0x8000L) != 0L) {
/* 1369 */           return jjStartNfaWithStates_1(4, 15, 16);
/*      */         }
/*      */         break;
/*      */       case 121:
/* 1373 */         if ((active0 & 0x80000000000L) != 0L) {
/* 1374 */           return jjStartNfaWithStates_1(4, 43, 16);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1380 */     return jjStartNfa_1(3, active0);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_1(int pos, int kind, int state) {
/* 1384 */     this.jjmatchedKind = kind;
/* 1385 */     this.jjmatchedPos = pos;
/*      */     try {
/* 1387 */       this.curChar = this.input_stream.readChar();
/* 1388 */     } catch (IOException e) {
/* 1389 */       return pos + 1;
/*      */     } 
/* 1391 */     return jjMoveNfa_1(state, pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_1(int startState, int curPos) {
/* 1395 */     int startsAt = 0;
/* 1396 */     this.jjnewStateCnt = 29;
/* 1397 */     int i = 1;
/* 1398 */     this.jjstateSet[0] = startState;
/* 1399 */     int kind = Integer.MAX_VALUE;
/*      */     while (true) {
/* 1401 */       if (++this.jjround == Integer.MAX_VALUE) {
/* 1402 */         ReInitRounds();
/*      */       }
/* 1404 */       if (this.curChar < 64) {
/* 1405 */         long l = 1L << this.curChar;
/*      */         do {
/* 1407 */           switch (this.jjstateSet[--i]) {
/*      */             case 0:
/* 1409 */               if ((0x3FF000000000000L & l) != 0L) {
/* 1410 */                 if (kind > 10) {
/* 1411 */                   kind = 10;
/*      */                 }
/*      */                 
/* 1414 */                 jjCheckNAddStates(18, 22); break;
/*      */               } 
/* 1416 */               if (this.curChar == 36) {
/* 1417 */                 if (kind > 55) {
/* 1418 */                   kind = 55;
/*      */                 }
/*      */                 
/* 1421 */                 jjCheckNAdd(16); break;
/*      */               } 
/* 1423 */               if (this.curChar == 39) {
/* 1424 */                 jjCheckNAddStates(23, 25); break;
/* 1425 */               }  if (this.curChar == 34) {
/* 1426 */                 jjCheckNAddStates(26, 28); break;
/* 1427 */               }  if (this.curChar == 46) {
/* 1428 */                 jjCheckNAdd(1);
/*      */               }
/*      */               break;
/*      */             case 1:
/* 1432 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1435 */               if (kind > 11) {
/* 1436 */                 kind = 11;
/*      */               }
/* 1438 */               jjCheckNAddTwoStates(1, 2);
/*      */               break;
/*      */             
/*      */             case 3:
/* 1442 */               if ((0x280000000000L & l) != 0L) {
/* 1443 */                 jjCheckNAdd(4);
/*      */               }
/*      */               break;
/*      */             case 4:
/* 1447 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1450 */               if (kind > 11) {
/* 1451 */                 kind = 11;
/*      */               }
/* 1453 */               jjCheckNAdd(4);
/*      */               break;
/*      */             
/*      */             case 5:
/* 1457 */               if (this.curChar == 34) {
/* 1458 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 6:
/* 1462 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L) {
/* 1463 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 8:
/* 1467 */               if ((0x8400000000L & l) != 0L) {
/* 1468 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 9:
/* 1472 */               if (this.curChar == 34 && kind > 13) {
/* 1473 */                 kind = 13;
/*      */               }
/*      */               break;
/*      */             case 10:
/* 1477 */               if (this.curChar == 39) {
/* 1478 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 11:
/* 1482 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L) {
/* 1483 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 13:
/* 1487 */               if ((0x8400000000L & l) != 0L) {
/* 1488 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 14:
/* 1492 */               if (this.curChar == 39 && kind > 13) {
/* 1493 */                 kind = 13;
/*      */               }
/*      */               break;
/*      */             case 15:
/* 1497 */               if (this.curChar != 36) {
/*      */                 break;
/*      */               }
/* 1500 */               if (kind > 55) {
/* 1501 */                 kind = 55;
/*      */               }
/* 1503 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 16:
/* 1507 */               if ((0x3FF00100FFFC1FFL & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1510 */               if (kind > 55) {
/* 1511 */                 kind = 55;
/*      */               }
/* 1513 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 17:
/* 1517 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1520 */               if (kind > 10) {
/* 1521 */                 kind = 10;
/*      */               }
/* 1523 */               jjCheckNAddStates(18, 22);
/*      */               break;
/*      */             
/*      */             case 18:
/* 1527 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1530 */               if (kind > 10) {
/* 1531 */                 kind = 10;
/*      */               }
/* 1533 */               jjCheckNAdd(18);
/*      */               break;
/*      */             
/*      */             case 19:
/* 1537 */               if ((0x3FF000000000000L & l) != 0L) {
/* 1538 */                 jjCheckNAddTwoStates(19, 20);
/*      */               }
/*      */               break;
/*      */             case 20:
/* 1542 */               if (this.curChar != 46) {
/*      */                 break;
/*      */               }
/* 1545 */               if (kind > 11) {
/* 1546 */                 kind = 11;
/*      */               }
/* 1548 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             
/*      */             case 21:
/* 1552 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1555 */               if (kind > 11) {
/* 1556 */                 kind = 11;
/*      */               }
/* 1558 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             
/*      */             case 23:
/* 1562 */               if ((0x280000000000L & l) != 0L) {
/* 1563 */                 jjCheckNAdd(24);
/*      */               }
/*      */               break;
/*      */             case 24:
/* 1567 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1570 */               if (kind > 11) {
/* 1571 */                 kind = 11;
/*      */               }
/* 1573 */               jjCheckNAdd(24);
/*      */               break;
/*      */             
/*      */             case 25:
/* 1577 */               if ((0x3FF000000000000L & l) != 0L) {
/* 1578 */                 jjCheckNAddTwoStates(25, 26);
/*      */               }
/*      */               break;
/*      */             case 27:
/* 1582 */               if ((0x280000000000L & l) != 0L) {
/* 1583 */                 jjCheckNAdd(28);
/*      */               }
/*      */               break;
/*      */             case 28:
/* 1587 */               if ((0x3FF000000000000L & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1590 */               if (kind > 11) {
/* 1591 */                 kind = 11;
/*      */               }
/* 1593 */               jjCheckNAdd(28);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 1599 */         } while (i != startsAt);
/* 1600 */       } else if (this.curChar < 128) {
/* 1601 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do {
/* 1603 */           switch (this.jjstateSet[--i]) {
/*      */             case 0:
/* 1605 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1608 */               if (kind > 55) {
/* 1609 */                 kind = 55;
/*      */               }
/* 1611 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 2:
/* 1615 */               if ((0x2000000020L & l) != 0L) {
/* 1616 */                 jjAddStates(29, 30);
/*      */               }
/*      */               break;
/*      */             case 6:
/* 1620 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/* 1621 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 7:
/* 1625 */               if (this.curChar == 92) {
/* 1626 */                 this.jjstateSet[this.jjnewStateCnt++] = 8;
/*      */               }
/*      */               break;
/*      */             case 8:
/* 1630 */               if (this.curChar == 92) {
/* 1631 */                 jjCheckNAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 11:
/* 1635 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/* 1636 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 12:
/* 1640 */               if (this.curChar == 92) {
/* 1641 */                 this.jjstateSet[this.jjnewStateCnt++] = 13;
/*      */               }
/*      */               break;
/*      */             case 13:
/* 1645 */               if (this.curChar == 92) {
/* 1646 */                 jjCheckNAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 16:
/* 1650 */               if ((0x87FFFFFE87FFFFFEL & l) == 0L) {
/*      */                 break;
/*      */               }
/* 1653 */               if (kind > 55) {
/* 1654 */                 kind = 55;
/*      */               }
/* 1656 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 22:
/* 1660 */               if ((0x2000000020L & l) != 0L) {
/* 1661 */                 jjAddStates(31, 32);
/*      */               }
/*      */               break;
/*      */             case 26:
/* 1665 */               if ((0x2000000020L & l) != 0L) {
/* 1666 */                 jjAddStates(33, 34);
/*      */               }
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/* 1672 */         } while (i != startsAt);
/*      */       } else {
/* 1674 */         int hiByte = this.curChar >> 8;
/* 1675 */         int i1 = hiByte >> 6;
/* 1676 */         long l1 = 1L << (hiByte & 0x3F);
/* 1677 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1678 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do {
/* 1680 */           switch (this.jjstateSet[--i]) {
/*      */             case 0:
/* 1682 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2)) {
/*      */                 break;
/*      */               }
/* 1685 */               if (kind > 55) {
/* 1686 */                 kind = 55;
/*      */               }
/* 1688 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             case 6:
/* 1692 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1693 */                 jjAddStates(26, 28);
/*      */               }
/*      */               break;
/*      */             case 11:
/* 1697 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1698 */                 jjAddStates(23, 25);
/*      */               }
/*      */               break;
/*      */             case 16:
/* 1702 */               if (!jjCanMove_2(hiByte, i1, i2, l1, l2)) {
/*      */                 break;
/*      */               }
/* 1705 */               if (kind > 55) {
/* 1706 */                 kind = 55;
/*      */               }
/* 1708 */               jjCheckNAdd(16);
/*      */               break;
/*      */             
/*      */             default:
/* 1712 */               if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/* 1718 */         } while (i != startsAt);
/*      */       } 
/* 1720 */       if (kind != Integer.MAX_VALUE) {
/* 1721 */         this.jjmatchedKind = kind;
/* 1722 */         this.jjmatchedPos = curPos;
/* 1723 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1725 */       curPos++;
/* 1726 */       if ((i = this.jjnewStateCnt) == (startsAt = 29 - (this.jjnewStateCnt = startsAt))) {
/* 1727 */         return curPos;
/*      */       }
/*      */       try {
/* 1730 */         this.curChar = this.input_stream.readChar();
/* 1731 */       } catch (IOException e) {
/* 1732 */         return curPos;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1738 */   public static final String[] jjstrLiteralImages = new String[] { "", null, "${", "#{", null, null, null, null, "{", "}", null, null, null, null, "true", "false", "null", ".", "(", ")", "[", "]", ":", ";", ",", ">", "gt", "<", "lt", ">=", "ge", "<=", "le", "==", "eq", "!=", "ne", "!", "not", "&&", "and", "||", "or", "empty", "*", "+", "-", "?", "/", "div", "%", "mod", "+=", "=", "->", null, null, null, null };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Token jjFillToken() {
/* 1752 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1753 */     String curTokenImage = (im == null) ? this.input_stream.GetImage() : im;
/* 1754 */     int beginLine = this.input_stream.getBeginLine();
/* 1755 */     int beginColumn = this.input_stream.getBeginColumn();
/* 1756 */     int endLine = this.input_stream.getEndLine();
/* 1757 */     int endColumn = this.input_stream.getEndColumn();
/* 1758 */     Token t = Token.newToken(this.jjmatchedKind, curTokenImage);
/*      */     
/* 1760 */     t.beginLine = beginLine;
/* 1761 */     t.endLine = endLine;
/* 1762 */     t.beginColumn = beginColumn;
/* 1763 */     t.endColumn = endColumn;
/*      */     
/* 1765 */     return t;
/*      */   }
/*      */   
/* 1768 */   static final int[] jjnextStates = new int[] { 0, 1, 3, 4, 2, 0, 1, 4, 2, 0, 1, 4, 5, 2, 0, 1, 2, 6, 18, 19, 20, 25, 26, 11, 12, 14, 6, 7, 9, 3, 4, 23, 24, 27, 28 };
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
/* 1772 */     switch (hiByte) {
/*      */       case 0:
/* 1774 */         return ((jjbitVec2[i2] & l2) != 0L);
/*      */     } 
/* 1776 */     if ((jjbitVec0[i1] & l1) != 0L) {
/* 1777 */       return true;
/*      */     }
/* 1779 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2) {
/* 1784 */     switch (hiByte) {
/*      */       case 0:
/* 1786 */         return ((jjbitVec4[i2] & l2) != 0L);
/*      */       case 2:
/* 1788 */         return ((jjbitVec5[i2] & l2) != 0L);
/*      */       case 3:
/* 1790 */         return ((jjbitVec6[i2] & l2) != 0L);
/*      */       case 4:
/* 1792 */         return ((jjbitVec7[i2] & l2) != 0L);
/*      */       case 5:
/* 1794 */         return ((jjbitVec8[i2] & l2) != 0L);
/*      */       case 6:
/* 1796 */         return ((jjbitVec9[i2] & l2) != 0L);
/*      */       case 7:
/* 1798 */         return ((jjbitVec10[i2] & l2) != 0L);
/*      */       case 8:
/* 1800 */         return ((jjbitVec11[i2] & l2) != 0L);
/*      */       case 9:
/* 1802 */         return ((jjbitVec12[i2] & l2) != 0L);
/*      */       case 10:
/* 1804 */         return ((jjbitVec13[i2] & l2) != 0L);
/*      */       case 11:
/* 1806 */         return ((jjbitVec14[i2] & l2) != 0L);
/*      */       case 12:
/* 1808 */         return ((jjbitVec15[i2] & l2) != 0L);
/*      */       case 13:
/* 1810 */         return ((jjbitVec16[i2] & l2) != 0L);
/*      */       case 14:
/* 1812 */         return ((jjbitVec17[i2] & l2) != 0L);
/*      */       case 15:
/* 1814 */         return ((jjbitVec18[i2] & l2) != 0L);
/*      */       case 16:
/* 1816 */         return ((jjbitVec19[i2] & l2) != 0L);
/*      */       case 18:
/* 1818 */         return ((jjbitVec20[i2] & l2) != 0L);
/*      */       case 19:
/* 1820 */         return ((jjbitVec21[i2] & l2) != 0L);
/*      */       case 20:
/* 1822 */         return ((jjbitVec0[i2] & l2) != 0L);
/*      */       case 22:
/* 1824 */         return ((jjbitVec22[i2] & l2) != 0L);
/*      */       case 23:
/* 1826 */         return ((jjbitVec23[i2] & l2) != 0L);
/*      */       case 24:
/* 1828 */         return ((jjbitVec24[i2] & l2) != 0L);
/*      */       case 25:
/* 1830 */         return ((jjbitVec25[i2] & l2) != 0L);
/*      */       case 26:
/* 1832 */         return ((jjbitVec26[i2] & l2) != 0L);
/*      */       case 27:
/* 1834 */         return ((jjbitVec27[i2] & l2) != 0L);
/*      */       case 28:
/* 1836 */         return ((jjbitVec28[i2] & l2) != 0L);
/*      */       case 29:
/* 1838 */         return ((jjbitVec29[i2] & l2) != 0L);
/*      */       case 31:
/* 1840 */         return ((jjbitVec30[i2] & l2) != 0L);
/*      */       case 32:
/* 1842 */         return ((jjbitVec31[i2] & l2) != 0L);
/*      */       case 33:
/* 1844 */         return ((jjbitVec32[i2] & l2) != 0L);
/*      */       case 44:
/* 1846 */         return ((jjbitVec33[i2] & l2) != 0L);
/*      */       case 45:
/* 1848 */         return ((jjbitVec34[i2] & l2) != 0L);
/*      */       case 46:
/* 1850 */         return ((jjbitVec35[i2] & l2) != 0L);
/*      */       case 48:
/* 1852 */         return ((jjbitVec36[i2] & l2) != 0L);
/*      */       case 49:
/* 1854 */         return ((jjbitVec37[i2] & l2) != 0L);
/*      */       case 77:
/* 1856 */         return ((jjbitVec38[i2] & l2) != 0L);
/*      */       case 159:
/* 1858 */         return ((jjbitVec39[i2] & l2) != 0L);
/*      */       case 164:
/* 1860 */         return ((jjbitVec40[i2] & l2) != 0L);
/*      */       case 166:
/* 1862 */         return ((jjbitVec41[i2] & l2) != 0L);
/*      */       case 167:
/* 1864 */         return ((jjbitVec42[i2] & l2) != 0L);
/*      */       case 168:
/* 1866 */         return ((jjbitVec43[i2] & l2) != 0L);
/*      */       case 169:
/* 1868 */         return ((jjbitVec44[i2] & l2) != 0L);
/*      */       case 170:
/* 1870 */         return ((jjbitVec45[i2] & l2) != 0L);
/*      */       case 171:
/* 1872 */         return ((jjbitVec46[i2] & l2) != 0L);
/*      */       case 215:
/* 1874 */         return ((jjbitVec47[i2] & l2) != 0L);
/*      */       case 250:
/* 1876 */         return ((jjbitVec48[i2] & l2) != 0L);
/*      */       case 251:
/* 1878 */         return ((jjbitVec49[i2] & l2) != 0L);
/*      */       case 253:
/* 1880 */         return ((jjbitVec50[i2] & l2) != 0L);
/*      */       case 254:
/* 1882 */         return ((jjbitVec51[i2] & l2) != 0L);
/*      */       case 255:
/* 1884 */         return ((jjbitVec52[i2] & l2) != 0L);
/*      */     } 
/* 1886 */     if ((jjbitVec3[i1] & l1) != 0L) {
/* 1887 */       return true;
/*      */     }
/* 1889 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_2(int hiByte, int i1, int i2, long l1, long l2) {
/* 1894 */     switch (hiByte) {
/*      */       case 0:
/* 1896 */         return ((jjbitVec53[i2] & l2) != 0L);
/*      */       case 2:
/* 1898 */         return ((jjbitVec5[i2] & l2) != 0L);
/*      */       case 3:
/* 1900 */         return ((jjbitVec54[i2] & l2) != 0L);
/*      */       case 4:
/* 1902 */         return ((jjbitVec55[i2] & l2) != 0L);
/*      */       case 5:
/* 1904 */         return ((jjbitVec56[i2] & l2) != 0L);
/*      */       case 6:
/* 1906 */         return ((jjbitVec57[i2] & l2) != 0L);
/*      */       case 7:
/* 1908 */         return ((jjbitVec58[i2] & l2) != 0L);
/*      */       case 8:
/* 1910 */         return ((jjbitVec59[i2] & l2) != 0L);
/*      */       case 9:
/* 1912 */         return ((jjbitVec60[i2] & l2) != 0L);
/*      */       case 10:
/* 1914 */         return ((jjbitVec61[i2] & l2) != 0L);
/*      */       case 11:
/* 1916 */         return ((jjbitVec62[i2] & l2) != 0L);
/*      */       case 12:
/* 1918 */         return ((jjbitVec63[i2] & l2) != 0L);
/*      */       case 13:
/* 1920 */         return ((jjbitVec64[i2] & l2) != 0L);
/*      */       case 14:
/* 1922 */         return ((jjbitVec65[i2] & l2) != 0L);
/*      */       case 15:
/* 1924 */         return ((jjbitVec66[i2] & l2) != 0L);
/*      */       case 16:
/* 1926 */         return ((jjbitVec67[i2] & l2) != 0L);
/*      */       case 18:
/* 1928 */         return ((jjbitVec20[i2] & l2) != 0L);
/*      */       case 19:
/* 1930 */         return ((jjbitVec68[i2] & l2) != 0L);
/*      */       case 20:
/* 1932 */         return ((jjbitVec0[i2] & l2) != 0L);
/*      */       case 22:
/* 1934 */         return ((jjbitVec22[i2] & l2) != 0L);
/*      */       case 23:
/* 1936 */         return ((jjbitVec69[i2] & l2) != 0L);
/*      */       case 24:
/* 1938 */         return ((jjbitVec70[i2] & l2) != 0L);
/*      */       case 25:
/* 1940 */         return ((jjbitVec71[i2] & l2) != 0L);
/*      */       case 26:
/* 1942 */         return ((jjbitVec72[i2] & l2) != 0L);
/*      */       case 27:
/* 1944 */         return ((jjbitVec73[i2] & l2) != 0L);
/*      */       case 28:
/* 1946 */         return ((jjbitVec74[i2] & l2) != 0L);
/*      */       case 29:
/* 1948 */         return ((jjbitVec75[i2] & l2) != 0L);
/*      */       case 31:
/* 1950 */         return ((jjbitVec30[i2] & l2) != 0L);
/*      */       case 32:
/* 1952 */         return ((jjbitVec76[i2] & l2) != 0L);
/*      */       case 33:
/* 1954 */         return ((jjbitVec32[i2] & l2) != 0L);
/*      */       case 44:
/* 1956 */         return ((jjbitVec77[i2] & l2) != 0L);
/*      */       case 45:
/* 1958 */         return ((jjbitVec78[i2] & l2) != 0L);
/*      */       case 46:
/* 1960 */         return ((jjbitVec35[i2] & l2) != 0L);
/*      */       case 48:
/* 1962 */         return ((jjbitVec79[i2] & l2) != 0L);
/*      */       case 49:
/* 1964 */         return ((jjbitVec37[i2] & l2) != 0L);
/*      */       case 77:
/* 1966 */         return ((jjbitVec38[i2] & l2) != 0L);
/*      */       case 159:
/* 1968 */         return ((jjbitVec39[i2] & l2) != 0L);
/*      */       case 164:
/* 1970 */         return ((jjbitVec40[i2] & l2) != 0L);
/*      */       case 166:
/* 1972 */         return ((jjbitVec80[i2] & l2) != 0L);
/*      */       case 167:
/* 1974 */         return ((jjbitVec42[i2] & l2) != 0L);
/*      */       case 168:
/* 1976 */         return ((jjbitVec81[i2] & l2) != 0L);
/*      */       case 169:
/* 1978 */         return ((jjbitVec82[i2] & l2) != 0L);
/*      */       case 170:
/* 1980 */         return ((jjbitVec83[i2] & l2) != 0L);
/*      */       case 171:
/* 1982 */         return ((jjbitVec84[i2] & l2) != 0L);
/*      */       case 215:
/* 1984 */         return ((jjbitVec47[i2] & l2) != 0L);
/*      */       case 250:
/* 1986 */         return ((jjbitVec48[i2] & l2) != 0L);
/*      */       case 251:
/* 1988 */         return ((jjbitVec85[i2] & l2) != 0L);
/*      */       case 253:
/* 1990 */         return ((jjbitVec50[i2] & l2) != 0L);
/*      */       case 254:
/* 1992 */         return ((jjbitVec86[i2] & l2) != 0L);
/*      */       case 255:
/* 1994 */         return ((jjbitVec87[i2] & l2) != 0L);
/*      */     } 
/* 1996 */     if ((jjbitVec3[i1] & l1) != 0L) {
/* 1997 */       return true;
/*      */     }
/* 1999 */     return false;
/*      */   }
/*      */ 
/*      */   
/* 2003 */   int curLexState = 0;
/* 2004 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public Token getNextToken() {
/* 2013 */     int curPos = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       try {
/* 2018 */         this.curChar = this.input_stream.BeginToken();
/* 2019 */       } catch (Exception e) {
/* 2020 */         this.jjmatchedKind = 0;
/* 2021 */         this.jjmatchedPos = -1;
/* 2022 */         Token matchedToken = jjFillToken();
/* 2023 */         return matchedToken;
/*      */       } 
/* 2025 */       this.image = this.jjimage;
/* 2026 */       this.image.setLength(0);
/* 2027 */       this.jjimageLen = 0;
/*      */       
/* 2029 */       switch (this.curLexState) {
/*      */         case 0:
/* 2031 */           this.jjmatchedKind = Integer.MAX_VALUE;
/* 2032 */           this.jjmatchedPos = 0;
/* 2033 */           curPos = jjMoveStringLiteralDfa0_0();
/*      */           break;
/*      */         case 1:
/*      */           try {
/* 2037 */             this.input_stream.backup(0);
/* 2038 */             while (this.curChar <= 32 && (0x100002600L & 1L << this.curChar) != 0L) {
/* 2039 */               this.curChar = this.input_stream.BeginToken();
/*      */             }
/* 2041 */           } catch (IOException e1) {
/*      */             continue;
/*      */           } 
/* 2044 */           this.jjmatchedKind = Integer.MAX_VALUE;
/* 2045 */           this.jjmatchedPos = 0;
/* 2046 */           curPos = jjMoveStringLiteralDfa0_1();
/* 2047 */           if (this.jjmatchedPos == 0 && this.jjmatchedKind > 58) {
/* 2048 */             this.jjmatchedKind = 58;
/*      */           }
/*      */           break;
/*      */         case 2:
/*      */           try {
/* 2053 */             this.input_stream.backup(0);
/* 2054 */             while (this.curChar <= 32 && (0x100002600L & 1L << this.curChar) != 0L) {
/* 2055 */               this.curChar = this.input_stream.BeginToken();
/*      */             }
/* 2057 */           } catch (IOException e1) {
/*      */             continue;
/*      */           } 
/* 2060 */           this.jjmatchedKind = Integer.MAX_VALUE;
/* 2061 */           this.jjmatchedPos = 0;
/* 2062 */           curPos = jjMoveStringLiteralDfa0_2();
/* 2063 */           if (this.jjmatchedPos == 0 && this.jjmatchedKind > 58) {
/* 2064 */             this.jjmatchedKind = 58;
/*      */           }
/*      */           break;
/*      */       } 
/* 2068 */       if (this.jjmatchedKind != Integer.MAX_VALUE) {
/* 2069 */         if (this.jjmatchedPos + 1 < curPos) {
/* 2070 */           this.input_stream.backup(curPos - this.jjmatchedPos - 1);
/*      */         }
/* 2072 */         if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/* 2073 */           Token matchedToken = jjFillToken();
/* 2074 */           TokenLexicalActions(matchedToken);
/* 2075 */           if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 2076 */             this.curLexState = jjnewLexState[this.jjmatchedKind];
/*      */           }
/* 2078 */           return matchedToken;
/*      */         } 
/* 2080 */         if (jjnewLexState[this.jjmatchedKind] != -1)
/* 2081 */           this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2086 */     int error_line = this.input_stream.getEndLine();
/* 2087 */     int error_column = this.input_stream.getEndColumn();
/* 2088 */     String error_after = null;
/* 2089 */     boolean EOFSeen = false;
/*      */     try {
/* 2091 */       this.input_stream.readChar();
/* 2092 */       this.input_stream.backup(1);
/* 2093 */     } catch (IOException e1) {
/* 2094 */       EOFSeen = true;
/* 2095 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/* 2096 */       if (this.curChar == 10 || this.curChar == 13) {
/* 2097 */         error_line++;
/* 2098 */         error_column = 0;
/*      */       } else {
/* 2100 */         error_column++;
/*      */       } 
/*      */     } 
/* 2103 */     if (!EOFSeen) {
/* 2104 */       this.input_stream.backup(1);
/* 2105 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/*      */     } 
/* 2107 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void SkipLexicalActions(Token matchedToken) {
/* 2113 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void MoreLexicalActions() {
/* 2120 */     this.jjimageLen += this.lengthOfMatch = this.jjmatchedPos + 1;
/* 2121 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void TokenLexicalActions(Token matchedToken) {
/* 2128 */     switch (this.jjmatchedKind) {
/*      */       case 2:
/* 2130 */         this.image.append(jjstrLiteralImages[2]);
/* 2131 */         this.lengthOfMatch = jjstrLiteralImages[2].length();
/* 2132 */         this.deque.push(Integer.valueOf(0));
/*      */         break;
/*      */       case 3:
/* 2135 */         this.image.append(jjstrLiteralImages[3]);
/* 2136 */         this.lengthOfMatch = jjstrLiteralImages[3].length();
/* 2137 */         this.deque.push(Integer.valueOf(0));
/*      */         break;
/*      */       case 8:
/* 2140 */         this.image.append(jjstrLiteralImages[8]);
/* 2141 */         this.lengthOfMatch = jjstrLiteralImages[8].length();
/* 2142 */         this.deque.push(Integer.valueOf(this.curLexState));
/*      */         break;
/*      */       case 9:
/* 2145 */         this.image.append(jjstrLiteralImages[9]);
/* 2146 */         this.lengthOfMatch = jjstrLiteralImages[9].length();
/* 2147 */         SwitchTo(((Integer)this.deque.pop()).intValue());
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jjCheckNAdd(int state) {
/* 2155 */     if (this.jjrounds[state] != this.jjround) {
/* 2156 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/* 2157 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 2163 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/* 2164 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 2168 */     jjCheckNAdd(state1);
/* 2169 */     jjCheckNAdd(state2);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end) {
/*      */     do {
/* 2174 */       jjCheckNAdd(jjnextStates[start]);
/* 2175 */     } while (start++ != end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream) {
/* 2199 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/* 2200 */     this.curLexState = this.defaultLexState;
/* 2201 */     this.input_stream = stream;
/* 2202 */     ReInitRounds();
/*      */   }
/*      */ 
/*      */   
/*      */   private void ReInitRounds() {
/* 2207 */     this.jjround = -2147483647;
/* 2208 */     for (int i = 29; i-- > 0;) {
/* 2209 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState) {
/* 2217 */     ReInit(stream);
/* 2218 */     SwitchTo(lexState);
/*      */   }
/*      */ 
/*      */   
/*      */   public void SwitchTo(int lexState) {
/* 2223 */     if (lexState >= 3 || lexState < 0) {
/* 2224 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/*      */     
/* 2227 */     this.curLexState = lexState;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2233 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "IN_EXPRESSION", "IN_SET_OR_MAP" };
/*      */ 
/*      */   
/* 2236 */   public static final int[] jjnewLexState = new int[] { -1, -1, 1, 1, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */   
/* 2239 */   static final long[] jjtoToken = new long[] { 360287970189635343L };
/* 2240 */   static final long[] jjtoSkip = new long[] { 240L };
/* 2241 */   static final long[] jjtoSpecial = new long[] { 0L }; protected SimpleCharStream input_stream; private final int[] jjrounds; private final int[] jjstateSet; private final StringBuilder jjimage;
/* 2242 */   static final long[] jjtoMore = new long[] { 0L }; private StringBuilder image; private int jjimageLen; private int lengthOfMatch; protected int curChar;
/*      */   
/*      */   public ELParserTokenManager(SimpleCharStream stream) {
/* 2245 */     this.jjrounds = new int[29];
/* 2246 */     this.jjstateSet = new int[58];
/* 2247 */     this.jjimage = new StringBuilder();
/* 2248 */     this.image = this.jjimage; this.input_stream = stream; } public ELParserTokenManager(SimpleCharStream stream, int lexState) { this.jjrounds = new int[29]; this.jjstateSet = new int[58]; this.jjimage = new StringBuilder(); this.image = this.jjimage;
/*      */     ReInit(stream);
/*      */     SwitchTo(lexState); }
/*      */ 
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\ELParserTokenManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */