/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import jakarta.el.ELException;
/*     */ import jakarta.el.MethodInfo;
/*     */ import jakarta.el.MethodReference;
/*     */ import jakarta.el.PropertyNotWritableException;
/*     */ import jakarta.el.ValueReference;
/*     */ import java.util.Arrays;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleNode
/*     */   implements Node
/*     */ {
/*     */   protected SimpleNode parent;
/*     */   protected SimpleNode[] children;
/*     */   protected final int id;
/*     */   protected String image;
/*     */   
/*     */   public SimpleNode(int i) {
/*  48 */     this.id = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtOpen() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtClose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtSetParent(Node n) {
/*  66 */     this.parent = (SimpleNode)n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node jjtGetParent() {
/*  72 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtAddChild(Node n, int i) {
/*  78 */     if (this.children == null) {
/*  79 */       this.children = new SimpleNode[i + 1];
/*  80 */     } else if (i >= this.children.length) {
/*  81 */       SimpleNode[] c = new SimpleNode[i + 1];
/*  82 */       System.arraycopy(this.children, 0, c, 0, this.children.length);
/*  83 */       this.children = c;
/*     */     } 
/*  85 */     this.children[i] = (SimpleNode)n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node jjtGetChild(int i) {
/*  91 */     return this.children[i];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int jjtGetNumChildren() {
/*  97 */     return (this.children == null) ? 0 : this.children.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     if (this.image != null) {
/* 110 */       return ELParserTreeConstants.jjtNodeName[this.id] + "[" + ELParserTreeConstants.jjtNodeName[this.id] + "]";
/*     */     }
/* 112 */     return ELParserTreeConstants.jjtNodeName[this.id];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImage() {
/* 118 */     return this.image;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setImage(String image) {
/* 123 */     this.image = image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 135 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx) throws ELException {
/* 141 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value) throws ELException {
/* 147 */     throw new PropertyNotWritableException(MessageFactory.get("error.syntax.set"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(NodeVisitor visitor) throws Exception {
/* 153 */     visitor.visit(this);
/* 154 */     if (this.children != null) {
/* 155 */       for (Node child : this.children) {
/* 156 */         child.accept(visitor);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(EvaluationContext ctx, Class<?>[] paramTypes, Object[] paramValues) throws ELException {
/* 164 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class<?>[] paramTypes) throws ELException {
/* 170 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodReference getMethodReference(EvaluationContext ctx) {
/* 176 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 182 */     int prime = 31;
/* 183 */     int result = 1;
/* 184 */     result = 31 * result + Arrays.hashCode((Object[])this.children);
/* 185 */     result = 31 * result + this.id;
/* 186 */     result = 31 * result + ((this.image == null) ? 0 : this.image.hashCode());
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 193 */     if (this == obj) {
/* 194 */       return true;
/*     */     }
/* 196 */     if (!(obj instanceof SimpleNode)) {
/* 197 */       return false;
/*     */     }
/* 199 */     SimpleNode other = (SimpleNode)obj;
/* 200 */     if (this.id != other.id) {
/* 201 */       return false;
/*     */     }
/* 203 */     if (this.image == null) {
/* 204 */       if (other.image != null) {
/* 205 */         return false;
/*     */       }
/* 207 */     } else if (!this.image.equals(other.image)) {
/* 208 */       return false;
/*     */     } 
/* 210 */     return Arrays.equals((Object[])this.children, (Object[])other.children);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueReference getValueReference(EvaluationContext ctx) {
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParametersProvided() {
/* 228 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\SimpleNode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */