/*    */ package org.apache.el.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstEmpty
/*    */   extends AstAbstractEmpty
/*    */ {
/*    */   public AstEmpty(int id) {
/* 23 */     super(id, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstEmpty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */