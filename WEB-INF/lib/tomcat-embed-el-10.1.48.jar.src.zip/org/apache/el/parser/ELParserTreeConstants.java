/*    */ package org.apache.el.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ELParserTreeConstants
/*    */ {
/*    */   public static final int JJTCOMPOSITEEXPRESSION = 0;
/*    */   public static final int JJTLITERALEXPRESSION = 1;
/*    */   public static final int JJTDEFERREDEXPRESSION = 2;
/*    */   public static final int JJTDYNAMICEXPRESSION = 3;
/*    */   public static final int JJTVOID = 4;
/*    */   public static final int JJTSEMICOLON = 5;
/*    */   public static final int JJTASSIGN = 6;
/*    */   public static final int JJTLAMBDAEXPRESSION = 7;
/*    */   public static final int JJTLAMBDAPARAMETERS = 8;
/*    */   public static final int JJTCHOICE = 9;
/*    */   public static final int JJTOR = 10;
/*    */   public static final int JJTAND = 11;
/*    */   public static final int JJTEQUAL = 12;
/*    */   public static final int JJTNOTEQUAL = 13;
/*    */   public static final int JJTLESSTHAN = 14;
/*    */   public static final int JJTGREATERTHAN = 15;
/*    */   public static final int JJTLESSTHANEQUAL = 16;
/*    */   public static final int JJTGREATERTHANEQUAL = 17;
/*    */   public static final int JJTCONCATENATION = 18;
/*    */   public static final int JJTPLUS = 19;
/*    */   public static final int JJTMINUS = 20;
/*    */   public static final int JJTMULT = 21;
/*    */   public static final int JJTDIV = 22;
/*    */   public static final int JJTMOD = 23;
/*    */   public static final int JJTNEGATIVE = 24;
/*    */   public static final int JJTNOTEMPTY = 25;
/*    */   public static final int JJTNOT = 26;
/*    */   public static final int JJTEMPTY = 27;
/*    */   public static final int JJTVALUE = 28;
/*    */   public static final int JJTDOTSUFFIX = 29;
/*    */   public static final int JJTBRACKETSUFFIX = 30;
/*    */   public static final int JJTMETHODPARAMETERS = 31;
/*    */   public static final int JJTSETDATA = 32;
/*    */   public static final int JJTLISTDATA = 33;
/*    */   public static final int JJTMAPDATA = 34;
/*    */   public static final int JJTMAPENTRY = 35;
/*    */   public static final int JJTIDENTIFIER = 36;
/*    */   public static final int JJTFUNCTION = 37;
/*    */   public static final int JJTTRUE = 38;
/*    */   public static final int JJTFALSE = 39;
/*    */   public static final int JJTFLOATINGPOINT = 40;
/*    */   public static final int JJTINTEGER = 41;
/*    */   public static final int JJTSTRING = 42;
/*    */   public static final int JJTNULL = 43;
/* 51 */   public static final String[] jjtNodeName = new String[] { "CompositeExpression", "LiteralExpression", "DeferredExpression", "DynamicExpression", "void", "Semicolon", "Assign", "LambdaExpression", "LambdaParameters", "Choice", "Or", "And", "Equal", "NotEqual", "LessThan", "GreaterThan", "LessThanEqual", "GreaterThanEqual", "Concatenation", "Plus", "Minus", "Mult", "Div", "Mod", "Negative", "NotEmpty", "Not", "Empty", "Value", "DotSuffix", "BracketSuffix", "MethodParameters", "SetData", "ListData", "MapData", "MapEntry", "Identifier", "Function", "True", "False", "FloatingPoint", "Integer", "String", "Null" };
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\ELParserTreeConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */