/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstLiteralExpression
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstLiteralExpression(int id) {
/* 27 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 33 */     return String.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 39 */     return this.image;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setImage(String image) {
/* 45 */     if (image.indexOf('\\') == -1) {
/* 46 */       this.image = image;
/*    */       return;
/*    */     } 
/* 49 */     int size = image.length();
/* 50 */     StringBuilder buf = new StringBuilder(size);
/* 51 */     for (int i = 0; i < size; i++) {
/* 52 */       char c = image.charAt(i);
/* 53 */       if (c == '\\' && i + 2 < size) {
/* 54 */         char c1 = image.charAt(i + 1);
/* 55 */         char c2 = image.charAt(i + 2);
/* 56 */         if ((c1 == '#' || c1 == '$') && c2 == '{') {
/* 57 */           c = c1;
/* 58 */           i++;
/*    */         } 
/*    */       } 
/* 61 */       buf.append(c);
/*    */     } 
/* 63 */     this.image = buf.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstLiteralExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */