/*    */ package org.apache.el.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstNotEmpty
/*    */   extends AstAbstractEmpty
/*    */ {
/*    */   public AstNotEmpty(int id) {
/* 23 */     super(id, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstNotEmpty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */