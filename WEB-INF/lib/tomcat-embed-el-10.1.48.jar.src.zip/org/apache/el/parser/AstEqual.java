/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstEqual
/*    */   extends BooleanNode
/*    */ {
/*    */   public AstEqual(int id) {
/* 28 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 34 */     Object obj0 = this.children[0].getValue(ctx);
/* 35 */     Object obj1 = this.children[1].getValue(ctx);
/* 36 */     return Boolean.valueOf(ELSupport.equals((ELContext)ctx, obj0, obj1));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstEqual.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */