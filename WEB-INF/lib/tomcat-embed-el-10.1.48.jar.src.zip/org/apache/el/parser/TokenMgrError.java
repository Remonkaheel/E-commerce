/*     */ package org.apache.el.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenMgrError
/*     */   extends Error
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int LEXICAL_ERROR = 0;
/*     */   public static final int STATIC_LEXER_ERROR = 1;
/*     */   public static final int INVALID_LEXICAL_STATE = 2;
/*     */   public static final int LOOP_DETECTED = 3;
/*     */   int errorCode;
/*     */   
/*     */   protected static final String addEscapes(String str) {
/*  49 */     StringBuilder retval = new StringBuilder();
/*     */     
/*  51 */     for (int i = 0; i < str.length(); i++) {
/*  52 */       char ch; switch (str.charAt(i)) {
/*     */         case '\b':
/*  54 */           retval.append("\\b");
/*     */           break;
/*     */         case '\t':
/*  57 */           retval.append("\\t");
/*     */           break;
/*     */         case '\n':
/*  60 */           retval.append("\\n");
/*     */           break;
/*     */         case '\f':
/*  63 */           retval.append("\\f");
/*     */           break;
/*     */         case '\r':
/*  66 */           retval.append("\\r");
/*     */           break;
/*     */         case '"':
/*  69 */           retval.append("\\\"");
/*     */           break;
/*     */         case '\'':
/*  72 */           retval.append("\\'");
/*     */           break;
/*     */         case '\\':
/*  75 */           retval.append("\\\\");
/*     */           break;
/*     */         default:
/*  78 */           if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/*  79 */             String s = "0000" + Integer.toString(ch, 16);
/*  80 */             retval.append("\\u" + s.substring(s.length() - 4)); break;
/*     */           } 
/*  82 */           retval.append(ch);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/*  87 */     return retval.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String LexicalErr(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, int curChar) {
/* 100 */     char curChar1 = (char)curChar;
/* 101 */     return "Lexical error at line " + errorLine + ", column " + errorColumn + ".  Encountered: " + (
/* 102 */       EOFSeen ? "<EOF> " : ("\"" + addEscapes(String.valueOf(curChar1)) + "\" (" + curChar + "), ")) + "after : \"" + 
/* 103 */       addEscapes(errorAfter) + "\"";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 115 */     return super.getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenMgrError() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenMgrError(String message, int reason) {
/* 130 */     super(message);
/* 131 */     this.errorCode = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenMgrError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, int curChar, int reason) {
/* 138 */     this(LexicalErr(EOFSeen, lexState, errorLine, errorColumn, errorAfter, curChar), reason);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\TokenMgrError.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */