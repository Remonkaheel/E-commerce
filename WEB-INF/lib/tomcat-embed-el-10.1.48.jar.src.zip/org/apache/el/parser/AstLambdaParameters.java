/*    */ package org.apache.el.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AstLambdaParameters
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstLambdaParameters(int id) {
/* 23 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 31 */     StringBuilder result = new StringBuilder();
/* 32 */     result.append('(');
/* 33 */     if (this.children != null) {
/* 34 */       for (Node n : this.children) {
/* 35 */         result.append(n.toString());
/* 36 */         result.append(',');
/*    */       } 
/*    */     }
/* 39 */     result.append(")->");
/* 40 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstLambdaParameters.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */