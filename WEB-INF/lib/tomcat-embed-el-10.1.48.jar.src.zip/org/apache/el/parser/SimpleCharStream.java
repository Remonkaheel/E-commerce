/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleCharStream
/*     */ {
/*     */   public static final boolean staticFlag = false;
/*     */   int bufsize;
/*     */   int available;
/*     */   int tokenBegin;
/*  23 */   public int bufpos = -1;
/*     */   
/*     */   protected int[] bufline;
/*     */   
/*     */   protected int[] bufcolumn;
/*     */   
/*  29 */   protected int column = 0;
/*     */   
/*  31 */   protected int line = 1;
/*     */   
/*     */   protected boolean prevCharIsCR = false;
/*     */   
/*     */   protected boolean prevCharIsLF = false;
/*     */   
/*     */   protected Reader inputStream;
/*     */   
/*     */   protected char[] buffer;
/*     */   
/*  41 */   protected int maxNextCharInd = 0;
/*     */   
/*  43 */   protected int inBuf = 0;
/*     */   
/*  45 */   protected int tabSize = 1;
/*     */   
/*     */   protected boolean trackLineColumn = true;
/*     */ 
/*     */   
/*     */   public void setTabSize(int i) {
/*  51 */     this.tabSize = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTabSize() {
/*  56 */     return this.tabSize;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void ExpandBuff(boolean wrapAround) {
/*  61 */     char[] newbuffer = new char[this.bufsize + 2048];
/*  62 */     int[] newbufline = new int[this.bufsize + 2048];
/*  63 */     int[] newbufcolumn = new int[this.bufsize + 2048];
/*     */     
/*     */     try {
/*  66 */       if (wrapAround) {
/*  67 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  68 */         System.arraycopy(this.buffer, 0, newbuffer, this.bufsize - this.tokenBegin, this.bufpos);
/*  69 */         this.buffer = newbuffer;
/*     */         
/*  71 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  72 */         System.arraycopy(this.bufline, 0, newbufline, this.bufsize - this.tokenBegin, this.bufpos);
/*  73 */         this.bufline = newbufline;
/*     */         
/*  75 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  76 */         System.arraycopy(this.bufcolumn, 0, newbufcolumn, this.bufsize - this.tokenBegin, this.bufpos);
/*  77 */         this.bufcolumn = newbufcolumn;
/*     */         
/*  79 */         this.maxNextCharInd = this.bufpos += this.bufsize - this.tokenBegin;
/*     */       } else {
/*  81 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  82 */         this.buffer = newbuffer;
/*     */         
/*  84 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  85 */         this.bufline = newbufline;
/*     */         
/*  87 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  88 */         this.bufcolumn = newbufcolumn;
/*     */         
/*  90 */         this.maxNextCharInd = this.bufpos -= this.tokenBegin;
/*     */       } 
/*  92 */     } catch (Throwable t) {
/*  93 */       throw new Error(t.getMessage());
/*     */     } 
/*     */     
/*  96 */     this.bufsize += 2048;
/*  97 */     this.available = this.bufsize;
/*  98 */     this.tokenBegin = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void FillBuff() throws IOException {
/* 103 */     if (this.maxNextCharInd == this.available) {
/* 104 */       if (this.available == this.bufsize) {
/* 105 */         if (this.tokenBegin > 2048) {
/* 106 */           this.bufpos = this.maxNextCharInd = 0;
/* 107 */           this.available = this.tokenBegin;
/* 108 */         } else if (this.tokenBegin < 0) {
/* 109 */           this.bufpos = this.maxNextCharInd = 0;
/*     */         } else {
/* 111 */           ExpandBuff(false);
/*     */         } 
/* 113 */       } else if (this.available > this.tokenBegin) {
/* 114 */         this.available = this.bufsize;
/* 115 */       } else if (this.tokenBegin - this.available < 2048) {
/* 116 */         ExpandBuff(true);
/*     */       } else {
/* 118 */         this.available = this.tokenBegin;
/*     */       } 
/*     */     }
/*     */     
/*     */     try {
/*     */       int i;
/* 124 */       if ((i = this.inputStream.read(this.buffer, this.maxNextCharInd, this.available - this.maxNextCharInd)) == -1) {
/* 125 */         this.inputStream.close();
/* 126 */         throw new IOException();
/*     */       } 
/* 128 */       this.maxNextCharInd += i;
/*     */       
/*     */       return;
/* 131 */     } catch (IOException e) {
/* 132 */       this.bufpos--;
/* 133 */       backup(0);
/* 134 */       if (this.tokenBegin == -1) {
/* 135 */         this.tokenBegin = this.bufpos;
/*     */       }
/* 137 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char BeginToken() throws IOException {
/* 144 */     this.tokenBegin = -1;
/* 145 */     char c = readChar();
/* 146 */     this.tokenBegin = this.bufpos;
/*     */     
/* 148 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void UpdateLineColumn(char c) {
/* 153 */     this.column++;
/*     */     
/* 155 */     if (this.prevCharIsLF) {
/* 156 */       this.prevCharIsLF = false;
/* 157 */       this.line += this.column = 1;
/* 158 */     } else if (this.prevCharIsCR) {
/* 159 */       this.prevCharIsCR = false;
/* 160 */       if (c == '\n') {
/* 161 */         this.prevCharIsLF = true;
/*     */       } else {
/* 163 */         this.line += this.column = 1;
/*     */       } 
/*     */     } 
/*     */     
/* 167 */     switch (c) {
/*     */       case '\r':
/* 169 */         this.prevCharIsCR = true;
/*     */         break;
/*     */       case '\n':
/* 172 */         this.prevCharIsLF = true;
/*     */         break;
/*     */       case '\t':
/* 175 */         this.column--;
/* 176 */         this.column += this.tabSize - this.column % this.tabSize;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     this.bufline[this.bufpos] = this.line;
/* 183 */     this.bufcolumn[this.bufpos] = this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 189 */     if (this.inBuf > 0) {
/* 190 */       this.inBuf--;
/*     */       
/* 192 */       if (++this.bufpos == this.bufsize) {
/* 193 */         this.bufpos = 0;
/*     */       }
/*     */       
/* 196 */       return this.buffer[this.bufpos];
/*     */     } 
/*     */     
/* 199 */     if (++this.bufpos >= this.maxNextCharInd) {
/* 200 */       FillBuff();
/*     */     }
/*     */     
/* 203 */     char c = this.buffer[this.bufpos];
/*     */     
/* 205 */     UpdateLineColumn(c);
/* 206 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getColumn() {
/* 218 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getLine() {
/* 230 */     return this.bufline[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndColumn() {
/* 236 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndLine() {
/* 242 */     return this.bufline[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBeginColumn() {
/* 248 */     return this.bufcolumn[this.tokenBegin];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBeginLine() {
/* 254 */     return this.bufline[this.tokenBegin];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void backup(int amount) {
/* 261 */     this.inBuf += amount;
/* 262 */     if ((this.bufpos -= amount) < 0) {
/* 263 */       this.bufpos += this.bufsize;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 270 */     this.inputStream = dstream;
/* 271 */     this.line = startline;
/* 272 */     this.column = startcolumn - 1;
/*     */     
/* 274 */     this.available = this.bufsize = buffersize;
/* 275 */     this.buffer = new char[buffersize];
/* 276 */     this.bufline = new int[buffersize];
/* 277 */     this.bufcolumn = new int[buffersize];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(Reader dstream, int startline, int startcolumn) {
/* 283 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(Reader dstream) {
/* 289 */     this(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 295 */     this.inputStream = dstream;
/* 296 */     this.line = startline;
/* 297 */     this.column = startcolumn - 1;
/*     */     
/* 299 */     if (this.buffer == null || buffersize != this.buffer.length) {
/* 300 */       this.available = this.bufsize = buffersize;
/* 301 */       this.buffer = new char[buffersize];
/* 302 */       this.bufline = new int[buffersize];
/* 303 */       this.bufcolumn = new int[buffersize];
/*     */     } 
/* 305 */     this.prevCharIsLF = this.prevCharIsCR = false;
/* 306 */     this.tokenBegin = this.inBuf = this.maxNextCharInd = 0;
/* 307 */     this.bufpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn) {
/* 313 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream) {
/* 319 */     ReInit(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, String encoding, int startline, int startcolumn, int buffersize) throws UnsupportedEncodingException {
/* 326 */     this((encoding == null) ? new InputStreamReader(dstream) : 
/* 327 */         new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 333 */     this(new InputStreamReader(dstream), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, String encoding, int startline, int startcolumn) throws UnsupportedEncodingException {
/* 340 */     this(dstream, encoding, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, int startline, int startcolumn) {
/* 346 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, String encoding) throws UnsupportedEncodingException {
/* 352 */     this(dstream, encoding, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream) {
/* 358 */     this(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, String encoding, int startline, int startcolumn, int buffersize) throws UnsupportedEncodingException {
/* 365 */     ReInit((encoding == null) ? new InputStreamReader(dstream) : 
/* 366 */         new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 372 */     ReInit(new InputStreamReader(dstream), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, String encoding) throws UnsupportedEncodingException {
/* 378 */     ReInit(dstream, encoding, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream) {
/* 384 */     ReInit(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, String encoding, int startline, int startcolumn) throws UnsupportedEncodingException {
/* 391 */     ReInit(dstream, encoding, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn) {
/* 397 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String GetImage() {
/* 403 */     if (this.bufpos >= this.tokenBegin) {
/* 404 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/*     */     }
/* 406 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] GetSuffix(int len) {
/* 413 */     char[] ret = new char[len];
/*     */     
/* 415 */     if (this.bufpos + 1 >= len) {
/* 416 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/*     */     } else {
/* 418 */       System.arraycopy(this.buffer, this.bufsize - len - this.bufpos - 1, ret, 0, len - this.bufpos - 1);
/* 419 */       System.arraycopy(this.buffer, 0, ret, len - this.bufpos - 1, this.bufpos + 1);
/*     */     } 
/*     */     
/* 422 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void Done() {
/* 428 */     this.buffer = null;
/* 429 */     this.bufline = null;
/* 430 */     this.bufcolumn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustBeginLineColumn(int newLine, int newCol) {
/* 438 */     int len, start = this.tokenBegin;
/*     */ 
/*     */     
/* 441 */     if (this.bufpos >= this.tokenBegin) {
/* 442 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/*     */     } else {
/* 444 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/*     */     } 
/*     */     
/* 447 */     int i = 0, j = 0, k = 0;
/* 448 */     int nextColDiff = 0, columnDiff = 0;
/*     */     
/* 450 */     while (i < len && this.bufline[j = start % this.bufsize] == this.bufline[k = ++start % this.bufsize]) {
/* 451 */       this.bufline[j] = newLine;
/* 452 */       nextColDiff = columnDiff + this.bufcolumn[k] - this.bufcolumn[j];
/* 453 */       this.bufcolumn[j] = newCol + columnDiff;
/* 454 */       columnDiff = nextColDiff;
/* 455 */       i++;
/*     */     } 
/*     */     
/* 458 */     if (i < len) {
/* 459 */       this.bufline[j] = newLine++;
/* 460 */       this.bufcolumn[j] = newCol + columnDiff;
/*     */       
/* 462 */       while (i++ < len) {
/* 463 */         if (this.bufline[j = start % this.bufsize] != this.bufline[++start % this.bufsize]) {
/* 464 */           this.bufline[j] = newLine++; continue;
/*     */         } 
/* 466 */         this.bufline[j] = newLine;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 471 */     this.line = this.bufline[j];
/* 472 */     this.column = this.bufcolumn[j];
/*     */   }
/*     */ 
/*     */   
/*     */   boolean getTrackLineColumn() {
/* 477 */     return this.trackLineColumn;
/*     */   }
/*     */ 
/*     */   
/*     */   void setTrackLineColumn(boolean tlc) {
/* 482 */     this.trackLineColumn = tlc;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\SimpleCharStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */