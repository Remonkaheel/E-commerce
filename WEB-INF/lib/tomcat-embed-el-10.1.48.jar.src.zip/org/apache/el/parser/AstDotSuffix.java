/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ import org.apache.el.util.Validation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDotSuffix
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstDotSuffix(int id) {
/* 29 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 35 */     return this.image;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setImage(String image) {
/* 41 */     if (!Validation.isIdentifier(image)) {
/* 42 */       throw new ELException(MessageFactory.get("error.identifier.notjava", new Object[] { image }));
/*    */     }
/* 44 */     this.image = image;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstDotSuffix.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */