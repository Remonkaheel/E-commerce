/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELException;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AstSetData
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstSetData(int id) {
/* 30 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 36 */     Set<Object> result = new HashSet();
/*    */     
/* 38 */     if (this.children != null) {
/* 39 */       for (Node child : this.children) {
/* 40 */         result.add(child.getValue(ctx));
/*    */       }
/*    */     }
/*    */     
/* 44 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 50 */     return Set.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstSetData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */