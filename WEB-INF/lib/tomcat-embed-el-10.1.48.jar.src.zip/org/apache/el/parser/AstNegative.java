/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELException;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstNegative
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstNegative(int id) {
/* 31 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx) throws ELException {
/* 37 */     return Number.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 43 */     Object obj = this.children[0].getValue(ctx);
/*    */     
/* 45 */     if (obj == null) {
/* 46 */       return Long.valueOf(0L);
/*    */     }
/* 48 */     if (obj instanceof BigDecimal) {
/* 49 */       return ((BigDecimal)obj).negate();
/*    */     }
/* 51 */     if (obj instanceof BigInteger) {
/* 52 */       return ((BigInteger)obj).negate();
/*    */     }
/* 54 */     if (obj instanceof String) {
/* 55 */       if (ELSupport.isStringFloat((String)obj)) {
/* 56 */         return Double.valueOf(-Double.parseDouble((String)obj));
/*    */       }
/* 58 */       return Long.valueOf(-Long.parseLong((String)obj));
/*    */     } 
/* 60 */     if (obj instanceof Long) {
/* 61 */       return Long.valueOf(-((Long)obj).longValue());
/*    */     }
/* 63 */     if (obj instanceof Double) {
/* 64 */       return Double.valueOf(-((Double)obj).doubleValue());
/*    */     }
/* 66 */     if (obj instanceof Integer) {
/* 67 */       return Integer.valueOf(-((Integer)obj).intValue());
/*    */     }
/* 69 */     if (obj instanceof Float) {
/* 70 */       return Float.valueOf(-((Float)obj).floatValue());
/*    */     }
/* 72 */     if (obj instanceof Short) {
/* 73 */       return Short.valueOf((short)-((Short)obj).shortValue());
/*    */     }
/* 75 */     if (obj instanceof Byte) {
/* 76 */       return Byte.valueOf((byte)-((Byte)obj).byteValue());
/*    */     }
/* 78 */     Long num = (Long)ELSupport.coerceToNumber((ELContext)ctx, obj, Long.class);
/* 79 */     return Long.valueOf(-num.longValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\AstNegative.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */