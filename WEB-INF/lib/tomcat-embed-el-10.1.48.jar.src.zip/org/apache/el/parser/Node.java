package org.apache.el.parser;

import jakarta.el.ELException;
import jakarta.el.MethodInfo;
import jakarta.el.MethodReference;
import jakarta.el.ValueReference;
import org.apache.el.lang.EvaluationContext;

public interface Node {
  void jjtOpen();
  
  void jjtClose();
  
  void jjtSetParent(Node paramNode);
  
  Node jjtGetParent();
  
  void jjtAddChild(Node paramNode, int paramInt);
  
  Node jjtGetChild(int paramInt);
  
  int jjtGetNumChildren();
  
  String getImage();
  
  Object getValue(EvaluationContext paramEvaluationContext) throws ELException;
  
  void setValue(EvaluationContext paramEvaluationContext, Object paramObject) throws ELException;
  
  Class<?> getType(EvaluationContext paramEvaluationContext) throws ELException;
  
  boolean isReadOnly(EvaluationContext paramEvaluationContext) throws ELException;
  
  void accept(NodeVisitor paramNodeVisitor) throws Exception;
  
  MethodInfo getMethodInfo(EvaluationContext paramEvaluationContext, Class<?>[] paramArrayOfClass) throws ELException;
  
  Object invoke(EvaluationContext paramEvaluationContext, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject) throws ELException;
  
  ValueReference getValueReference(EvaluationContext paramEvaluationContext);
  
  boolean isParametersProvided();
  
  MethodReference getMethodReference(EvaluationContext paramEvaluationContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\parser\Node.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */