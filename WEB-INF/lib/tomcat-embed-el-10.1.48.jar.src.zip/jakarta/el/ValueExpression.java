/*    */ package jakarta.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ValueExpression
/*    */   extends Expression
/*    */ {
/*    */   private static final long serialVersionUID = 8577809572381654673L;
/*    */   
/*    */   public abstract <T> T getValue(ELContext paramELContext);
/*    */   
/*    */   public abstract void setValue(ELContext paramELContext, Object paramObject);
/*    */   
/*    */   public abstract boolean isReadOnly(ELContext paramELContext);
/*    */   
/*    */   public abstract Class<?> getType(ELContext paramELContext);
/*    */   
/*    */   public abstract Class<?> getExpectedType();
/*    */   
/*    */   public ValueReference getValueReference(ELContext context) {
/* 83 */     context.notifyBeforeEvaluation(getExpressionString());
/* 84 */     context.notifyAfterEvaluation(getExpressionString());
/* 85 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ValueExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */