/*    */ package jakarta.el;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LambdaExpression
/*    */ {
/*    */   private final List<String> formalParameters;
/*    */   private final ValueExpression expression;
/* 28 */   private final Map<String, Object> nestedArguments = new HashMap<>();
/* 29 */   private ELContext context = null;
/*    */   
/*    */   public LambdaExpression(List<String> formalParameters, ValueExpression expression) {
/* 32 */     this.formalParameters = formalParameters;
/* 33 */     this.expression = expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setELContext(ELContext context) {
/* 38 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object invoke(ELContext context, Object... args) throws ELException {
/* 44 */     Objects.requireNonNull(context);
/*    */     
/* 46 */     int formalParamCount = 0;
/* 47 */     if (this.formalParameters != null) {
/* 48 */       formalParamCount = this.formalParameters.size();
/*    */     }
/*    */     
/* 51 */     int argCount = 0;
/* 52 */     if (args != null) {
/* 53 */       argCount = args.length;
/*    */     }
/*    */     
/* 56 */     if (formalParamCount > argCount) {
/* 57 */       throw new ELException(Util.message(context, "lambdaExpression.tooFewArgs", new Object[] { Integer.valueOf(argCount), 
/* 58 */               Integer.valueOf(formalParamCount) }));
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 64 */     Map<String, Object> lambdaArguments = new HashMap<>(this.nestedArguments);
/* 65 */     for (int i = 0; i < formalParamCount; i++) {
/* 66 */       lambdaArguments.put(this.formalParameters.get(i), args[i]);
/*    */     }
/*    */     
/* 69 */     context.enterLambdaScope(lambdaArguments);
/*    */     
/*    */     try {
/* 72 */       Object result = this.expression.getValue(context);
/*    */ 
/*    */       
/* 75 */       if (result instanceof LambdaExpression) {
/* 76 */         ((LambdaExpression)result).nestedArguments.putAll(lambdaArguments);
/*    */       }
/* 78 */       return result;
/*    */     } finally {
/* 80 */       context.exitLambdaScope();
/*    */     } 
/*    */   }
/*    */   
/*    */   public Object invoke(Object... args) {
/* 85 */     return invoke(this.context, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\LambdaExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */