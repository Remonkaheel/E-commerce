/*    */ package jakarta.el;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueReference
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Object base;
/*    */   private final Object property;
/*    */   
/*    */   public ValueReference(Object base, Object property) {
/* 32 */     this.base = base;
/* 33 */     this.property = property;
/*    */   }
/*    */   
/*    */   public Object getBase() {
/* 37 */     return this.base;
/*    */   }
/*    */   
/*    */   public Object getProperty() {
/* 41 */     return this.property;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ValueReference.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */