/*     */ package jakarta.el;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportHandler
/*     */ {
/*  34 */   private static final Map<String, Set<String>> standardPackages = new HashMap<>();
/*     */ 
/*     */   
/*     */   static {
/*  38 */     Set<String> servletClassNames = new HashSet<>();
/*     */     
/*  40 */     servletClassNames.add("AsyncContext");
/*  41 */     servletClassNames.add("AsyncListener");
/*  42 */     servletClassNames.add("Filter");
/*  43 */     servletClassNames.add("FilterChain");
/*  44 */     servletClassNames.add("FilterConfig");
/*  45 */     servletClassNames.add("FilterRegistration");
/*  46 */     servletClassNames.add("FilterRegistration.Dynamic");
/*  47 */     servletClassNames.add("ReadListener");
/*  48 */     servletClassNames.add("Registration");
/*  49 */     servletClassNames.add("Registration.Dynamic");
/*  50 */     servletClassNames.add("RequestDispatcher");
/*  51 */     servletClassNames.add("Servlet");
/*  52 */     servletClassNames.add("ServletConfig");
/*  53 */     servletClassNames.add("ServletConnection");
/*  54 */     servletClassNames.add("ServletContainerInitializer");
/*  55 */     servletClassNames.add("ServletContext");
/*  56 */     servletClassNames.add("ServletContextAttributeListener");
/*  57 */     servletClassNames.add("ServletContextListener");
/*  58 */     servletClassNames.add("ServletRegistration");
/*  59 */     servletClassNames.add("ServletRegistration.Dynamic");
/*  60 */     servletClassNames.add("ServletRequest");
/*  61 */     servletClassNames.add("ServletRequestAttributeListener");
/*  62 */     servletClassNames.add("ServletRequestListener");
/*  63 */     servletClassNames.add("ServletResponse");
/*  64 */     servletClassNames.add("SessionCookieConfig");
/*  65 */     servletClassNames.add("WriteListener");
/*     */     
/*  67 */     servletClassNames.add("AsyncEvent");
/*  68 */     servletClassNames.add("GenericFilter");
/*  69 */     servletClassNames.add("GenericServlet");
/*  70 */     servletClassNames.add("HttpConstraintElement");
/*  71 */     servletClassNames.add("HttpMethodConstraintElement");
/*  72 */     servletClassNames.add("MultipartConfigElement");
/*  73 */     servletClassNames.add("ServletContextAttributeEvent");
/*  74 */     servletClassNames.add("ServletContextEvent");
/*  75 */     servletClassNames.add("ServletInputStream");
/*  76 */     servletClassNames.add("ServletOutputStream");
/*  77 */     servletClassNames.add("ServletRequestAttributeEvent");
/*  78 */     servletClassNames.add("ServletRequestEvent");
/*  79 */     servletClassNames.add("ServletRequestWrapper");
/*  80 */     servletClassNames.add("ServletResponseWrapper");
/*  81 */     servletClassNames.add("ServletSecurityElement");
/*     */     
/*  83 */     servletClassNames.add("DispatcherType");
/*  84 */     servletClassNames.add("SessionTrackingMode");
/*     */     
/*  86 */     servletClassNames.add("ServletException");
/*  87 */     servletClassNames.add("UnavailableException");
/*  88 */     standardPackages.put("jakarta.servlet", servletClassNames);
/*     */ 
/*     */     
/*  91 */     Set<String> servletHttpClassNames = new HashSet<>();
/*     */     
/*  93 */     servletHttpClassNames.add("HttpServletMapping");
/*  94 */     servletHttpClassNames.add("HttpServletRequest");
/*  95 */     servletHttpClassNames.add("HttpServletResponse");
/*  96 */     servletHttpClassNames.add("HttpSession");
/*  97 */     servletHttpClassNames.add("HttpSessionActivationListener");
/*  98 */     servletHttpClassNames.add("HttpSessionAttributeListener");
/*  99 */     servletHttpClassNames.add("HttpSessionBindingListener");
/* 100 */     servletHttpClassNames.add("HttpSessionIdListener");
/* 101 */     servletHttpClassNames.add("HttpSessionListener");
/* 102 */     servletHttpClassNames.add("HttpUpgradeHandler");
/* 103 */     servletHttpClassNames.add("Part");
/* 104 */     servletHttpClassNames.add("PushBuilder");
/* 105 */     servletHttpClassNames.add("WebConnection");
/*     */     
/* 107 */     servletHttpClassNames.add("Cookie");
/* 108 */     servletHttpClassNames.add("HttpFilter");
/* 109 */     servletHttpClassNames.add("HttpServlet");
/* 110 */     servletHttpClassNames.add("HttpServletRequestWrapper");
/* 111 */     servletHttpClassNames.add("HttpServletResponseWrapper");
/* 112 */     servletHttpClassNames.add("HttpSessionBindingEvent");
/* 113 */     servletHttpClassNames.add("HttpSessionEvent");
/* 114 */     servletHttpClassNames.add("HttpUtils");
/*     */     
/* 116 */     servletHttpClassNames.add("MappingMatch");
/* 117 */     standardPackages.put("jakarta.servlet.http", servletHttpClassNames);
/*     */ 
/*     */     
/* 120 */     Set<String> servletJspClassNames = new HashSet<>();
/*     */     
/* 122 */     servletJspClassNames.add("HttpJspPage");
/* 123 */     servletJspClassNames.add("JspApplicationContext");
/* 124 */     servletJspClassNames.add("JspPage");
/*     */     
/* 126 */     servletJspClassNames.add("ErrorData");
/* 127 */     servletJspClassNames.add("JspContext");
/* 128 */     servletJspClassNames.add("JspEngineInfo");
/* 129 */     servletJspClassNames.add("JspFactory");
/* 130 */     servletJspClassNames.add("JspWriter");
/* 131 */     servletJspClassNames.add("PageContext");
/* 132 */     servletJspClassNames.add("Exceptions");
/* 133 */     servletJspClassNames.add("JspException");
/* 134 */     servletJspClassNames.add("JspTagException");
/* 135 */     servletJspClassNames.add("SkipPageException");
/* 136 */     standardPackages.put("jakarta.servlet.jsp", servletJspClassNames);
/*     */     
/* 138 */     Set<String> javaLangClassNames = new HashSet<>();
/*     */ 
/*     */     
/* 141 */     javaLangClassNames.add("Appendable");
/* 142 */     javaLangClassNames.add("AutoCloseable");
/* 143 */     javaLangClassNames.add("CharSequence");
/* 144 */     javaLangClassNames.add("Cloneable");
/* 145 */     javaLangClassNames.add("Comparable");
/* 146 */     javaLangClassNames.add("Iterable");
/* 147 */     javaLangClassNames.add("ProcessHandle");
/* 148 */     javaLangClassNames.add("ProcessHandle.Info");
/* 149 */     javaLangClassNames.add("Readable");
/* 150 */     javaLangClassNames.add("Runnable");
/* 151 */     javaLangClassNames.add("StackWalker.StackFrame");
/* 152 */     javaLangClassNames.add("System.Logger");
/* 153 */     javaLangClassNames.add("Thread.Builder");
/* 154 */     javaLangClassNames.add("Thread.Builder.OfPlatform");
/* 155 */     javaLangClassNames.add("Thread.Builder.OfVirtual");
/* 156 */     javaLangClassNames.add("Thread.UncaughtExceptionHandler");
/*     */     
/* 158 */     javaLangClassNames.add("Boolean");
/* 159 */     javaLangClassNames.add("Byte");
/* 160 */     javaLangClassNames.add("Character");
/* 161 */     javaLangClassNames.add("Character.Subset");
/* 162 */     javaLangClassNames.add("Character.UnicodeBlock");
/* 163 */     javaLangClassNames.add("Class");
/* 164 */     javaLangClassNames.add("ClassLoader");
/* 165 */     javaLangClassNames.add("ClassValue");
/* 166 */     javaLangClassNames.add("Compiler");
/* 167 */     javaLangClassNames.add("Double");
/* 168 */     javaLangClassNames.add("Enum");
/* 169 */     javaLangClassNames.add("Enum.EnumDesc");
/* 170 */     javaLangClassNames.add("Float");
/* 171 */     javaLangClassNames.add("IO");
/* 172 */     javaLangClassNames.add("InheritableThreadLocal");
/* 173 */     javaLangClassNames.add("Integer");
/* 174 */     javaLangClassNames.add("Long");
/* 175 */     javaLangClassNames.add("Math");
/* 176 */     javaLangClassNames.add("Module");
/* 177 */     javaLangClassNames.add("ModuleLayer");
/* 178 */     javaLangClassNames.add("ModuleLayer.Controller");
/* 179 */     javaLangClassNames.add("Number");
/* 180 */     javaLangClassNames.add("Object");
/* 181 */     javaLangClassNames.add("Package");
/* 182 */     javaLangClassNames.add("Process");
/* 183 */     javaLangClassNames.add("ProcessBuilder");
/* 184 */     javaLangClassNames.add("ProcessBuilder.Redirect");
/* 185 */     javaLangClassNames.add("Record");
/* 186 */     javaLangClassNames.add("Runtime");
/* 187 */     javaLangClassNames.add("Runtime.Version");
/* 188 */     javaLangClassNames.add("RuntimePermission");
/* 189 */     javaLangClassNames.add("ScopedValue");
/* 190 */     javaLangClassNames.add("ScopedValue.CallableOp");
/* 191 */     javaLangClassNames.add("ScopedValue.Carrier");
/* 192 */     javaLangClassNames.add("SecurityManager");
/* 193 */     javaLangClassNames.add("Short");
/* 194 */     javaLangClassNames.add("StableValue");
/* 195 */     javaLangClassNames.add("StackTraceElement");
/* 196 */     javaLangClassNames.add("StackWalker");
/* 197 */     javaLangClassNames.add("StrictMath");
/* 198 */     javaLangClassNames.add("String");
/* 199 */     javaLangClassNames.add("StringBuffer");
/* 200 */     javaLangClassNames.add("StringBuilder");
/* 201 */     javaLangClassNames.add("StringTemplate");
/* 202 */     javaLangClassNames.add("StringTemplate.Processor");
/* 203 */     javaLangClassNames.add("StringTemplate.Processor.Linkage");
/* 204 */     javaLangClassNames.add("System");
/* 205 */     javaLangClassNames.add("System.LoggerFinder");
/* 206 */     javaLangClassNames.add("Thread");
/* 207 */     javaLangClassNames.add("ThreadGroup");
/* 208 */     javaLangClassNames.add("ThreadLocal");
/* 209 */     javaLangClassNames.add("Throwable");
/* 210 */     javaLangClassNames.add("Void");
/*     */     
/* 212 */     javaLangClassNames.add("Character.UnicodeScript");
/* 213 */     javaLangClassNames.add("ProcessBuilder.Redirect.Type");
/* 214 */     javaLangClassNames.add("StackWalker.Option");
/* 215 */     javaLangClassNames.add("System.Logger.Level");
/* 216 */     javaLangClassNames.add("Thread.State");
/*     */     
/* 218 */     javaLangClassNames.add("ArithmeticException");
/* 219 */     javaLangClassNames.add("ArrayIndexOutOfBoundsException");
/* 220 */     javaLangClassNames.add("ArrayStoreException");
/* 221 */     javaLangClassNames.add("ClassCastException");
/* 222 */     javaLangClassNames.add("ClassNotFoundException");
/* 223 */     javaLangClassNames.add("CloneNotSupportedException");
/* 224 */     javaLangClassNames.add("EnumConstantNotPresentException");
/* 225 */     javaLangClassNames.add("Exception");
/* 226 */     javaLangClassNames.add("IllegalAccessException");
/* 227 */     javaLangClassNames.add("IllegalArgumentException");
/* 228 */     javaLangClassNames.add("IllegalCallerException");
/* 229 */     javaLangClassNames.add("IllegalMonitorStateException");
/* 230 */     javaLangClassNames.add("IllegalStateException");
/* 231 */     javaLangClassNames.add("IllegalThreadStateException");
/* 232 */     javaLangClassNames.add("IndexOutOfBoundsException");
/* 233 */     javaLangClassNames.add("InstantiationException");
/* 234 */     javaLangClassNames.add("InterruptedException");
/* 235 */     javaLangClassNames.add("LayerInstantiationException");
/* 236 */     javaLangClassNames.add("MatchException");
/* 237 */     javaLangClassNames.add("NegativeArraySizeException");
/* 238 */     javaLangClassNames.add("NoSuchFieldException");
/* 239 */     javaLangClassNames.add("NoSuchMethodException");
/* 240 */     javaLangClassNames.add("NullPointerException");
/* 241 */     javaLangClassNames.add("NumberFormatException");
/* 242 */     javaLangClassNames.add("ReflectiveOperationException");
/* 243 */     javaLangClassNames.add("RuntimeException");
/* 244 */     javaLangClassNames.add("SecurityException");
/* 245 */     javaLangClassNames.add("StringIndexOutOfBoundsException");
/* 246 */     javaLangClassNames.add("TypeNotPresentException");
/* 247 */     javaLangClassNames.add("UnsupportedOperationException");
/* 248 */     javaLangClassNames.add("WrongThreadException");
/*     */     
/* 250 */     javaLangClassNames.add("AbstractMethodError");
/* 251 */     javaLangClassNames.add("AssertionError");
/* 252 */     javaLangClassNames.add("BootstrapMethodError");
/* 253 */     javaLangClassNames.add("ClassCircularityError");
/* 254 */     javaLangClassNames.add("ClassFormatError");
/* 255 */     javaLangClassNames.add("Error");
/* 256 */     javaLangClassNames.add("ExceptionInInitializerError");
/* 257 */     javaLangClassNames.add("IllegalAccessError");
/* 258 */     javaLangClassNames.add("IncompatibleClassChangeError");
/* 259 */     javaLangClassNames.add("InstantiationError");
/* 260 */     javaLangClassNames.add("InternalError");
/* 261 */     javaLangClassNames.add("LinkageError");
/* 262 */     javaLangClassNames.add("NoClassDefFoundError");
/* 263 */     javaLangClassNames.add("NoSuchFieldError");
/* 264 */     javaLangClassNames.add("NoSuchMethodError");
/* 265 */     javaLangClassNames.add("OutOfMemoryError");
/* 266 */     javaLangClassNames.add("StackOverflowError");
/* 267 */     javaLangClassNames.add("ThreadDeath");
/* 268 */     javaLangClassNames.add("UnknownError");
/* 269 */     javaLangClassNames.add("UnsatisfiedLinkError");
/* 270 */     javaLangClassNames.add("UnsupportedClassVersionError");
/* 271 */     javaLangClassNames.add("VerifyError");
/* 272 */     javaLangClassNames.add("VirtualMachineError");
/*     */     
/* 274 */     javaLangClassNames.add("Deprecated");
/* 275 */     javaLangClassNames.add("FunctionalInterface");
/* 276 */     javaLangClassNames.add("Override");
/* 277 */     javaLangClassNames.add("SafeVarargs");
/* 278 */     javaLangClassNames.add("SuppressWarnings");
/* 279 */     standardPackages.put("java.lang", javaLangClassNames);
/*     */   }
/*     */ 
/*     */   
/* 283 */   private Map<String, Set<String>> packageNames = new ConcurrentHashMap<>();
/* 284 */   private Map<String, String> classNames = new ConcurrentHashMap<>();
/* 285 */   private Map<String, Class<?>> clazzes = new ConcurrentHashMap<>();
/* 286 */   private Map<String, Class<?>> statics = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   public ImportHandler() {
/* 290 */     importPackage("java.lang");
/*     */   }
/*     */ 
/*     */   
/*     */   public void importStatic(String name) throws ELException {
/* 295 */     int lastPeriod = name.lastIndexOf('.');
/*     */     
/* 297 */     if (lastPeriod < 0) {
/* 298 */       throw new ELException(Util.message(null, "importHandler.invalidStaticName", new Object[] { name }));
/*     */     }
/*     */     
/* 301 */     String className = name.substring(0, lastPeriod);
/* 302 */     String fieldOrMethodName = name.substring(lastPeriod + 1);
/*     */     
/* 304 */     Class<?> clazz = findClass(className, true);
/*     */     
/* 306 */     if (clazz == null) {
/* 307 */       throw new ELException(Util.message(null, "importHandler.invalidClassNameForStatic", new Object[] { className, name }));
/*     */     }
/*     */     
/* 310 */     boolean found = false;
/*     */     
/* 312 */     for (Field field : clazz.getFields()) {
/* 313 */       if (field.getName().equals(fieldOrMethodName)) {
/* 314 */         int modifiers = field.getModifiers();
/* 315 */         if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers)) {
/* 316 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 322 */     if (!found) {
/* 323 */       for (Method method : clazz.getMethods()) {
/* 324 */         if (method.getName().equals(fieldOrMethodName)) {
/* 325 */           int modifiers = method.getModifiers();
/* 326 */           if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers)) {
/* 327 */             found = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 334 */     if (!found) {
/* 335 */       throw new ELException(
/* 336 */           Util.message(null, "importHandler.staticNotFound", new Object[] { fieldOrMethodName, className, name }));
/*     */     }
/*     */     
/* 339 */     Class<?> conflict = this.statics.get(fieldOrMethodName);
/* 340 */     if (conflict != null) {
/* 341 */       throw new ELException(Util.message(null, "importHandler.ambiguousStaticImport", new Object[] { name, conflict
/* 342 */               .getName() + "." + conflict.getName() }));
/*     */     }
/*     */     
/* 345 */     this.statics.put(fieldOrMethodName, clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void importClass(String name) throws ELException {
/* 350 */     int lastPeriodIndex = name.lastIndexOf('.');
/*     */     
/* 352 */     if (lastPeriodIndex < 0) {
/* 353 */       throw new ELException(Util.message(null, "importHandler.invalidClassName", new Object[] { name }));
/*     */     }
/*     */     
/* 356 */     String unqualifiedName = name.substring(lastPeriodIndex + 1);
/* 357 */     String currentName = this.classNames.putIfAbsent(unqualifiedName, name);
/*     */     
/* 359 */     if (currentName != null && !currentName.equals(name))
/*     */     {
/* 361 */       throw new ELException(Util.message(null, "importHandler.ambiguousImport", new Object[] { name, currentName }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void importPackage(String name) {
/* 372 */     Set<String> preloaded = standardPackages.get(name);
/* 373 */     if (preloaded == null) {
/* 374 */       this.packageNames.put(name, Collections.emptySet());
/*     */     } else {
/* 376 */       this.packageNames.put(name, preloaded);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> resolveClass(String name) {
/* 382 */     if (name == null || name.contains(".")) {
/* 383 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 387 */     Class<?> result = this.clazzes.get(name);
/*     */     
/* 389 */     if (result != null) {
/* 390 */       if (NotFound.class.equals(result)) {
/* 391 */         return null;
/*     */       }
/* 393 */       return result;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 398 */     String className = this.classNames.get(name);
/* 399 */     if (className != null) {
/* 400 */       Class<?> clazz = findClass(className, true);
/* 401 */       if (clazz != null) {
/* 402 */         this.clazzes.put(name, clazz);
/* 403 */         return clazz;
/*     */       } 
/*     */       
/* 406 */       StringBuilder sb = new StringBuilder(className);
/* 407 */       int replacementPosition = sb.lastIndexOf(".");
/* 408 */       while (replacementPosition > -1) {
/* 409 */         sb.setCharAt(replacementPosition, '$');
/* 410 */         clazz = findClass(sb.toString(), true);
/* 411 */         if (clazz != null) {
/* 412 */           this.clazzes.put(name, clazz);
/* 413 */           return clazz;
/*     */         } 
/* 415 */         replacementPosition = sb.lastIndexOf(".", replacementPosition);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 421 */     for (Map.Entry<String, Set<String>> entry : this.packageNames.entrySet()) {
/* 422 */       if (!((Set)entry.getValue()).isEmpty())
/*     */       {
/* 424 */         if (!((Set)entry.getValue()).contains(name)) {
/*     */           continue;
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 431 */       className = (String)entry.getKey() + "." + (String)entry.getKey();
/* 432 */       Class<?> clazz = findClass(className, false);
/* 433 */       if (clazz != null) {
/* 434 */         if (result != null) {
/* 435 */           throw new ELException(
/* 436 */               Util.message(null, "importHandler.ambiguousImport", new Object[] { className, result.getName() }));
/*     */         }
/* 438 */         result = clazz;
/*     */       } 
/*     */     } 
/* 441 */     if (result == null) {
/*     */ 
/*     */       
/* 444 */       this.clazzes.put(name, NotFound.class);
/*     */     } else {
/* 446 */       this.clazzes.put(name, result);
/*     */     } 
/*     */     
/* 449 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> resolveStatic(String name) {
/* 454 */     return this.statics.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> findClass(String name, boolean throwException) {
/*     */     Class<?> clazz;
/* 460 */     ClassLoader cl = Util.getContextClassLoader();
/*     */     try {
/* 462 */       clazz = cl.loadClass(name);
/* 463 */     } catch (ClassNotFoundException e) {
/* 464 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 469 */     int modifiers = clazz.getModifiers();
/* 470 */     if (!Modifier.isPublic(modifiers) || Modifier.isAbstract(modifiers) || Modifier.isInterface(modifiers) || 
/* 471 */       !isExported(clazz)) {
/* 472 */       if (throwException) {
/* 473 */         throw new ELException(Util.message(null, "importHandler.invalidClass", new Object[] { name }));
/*     */       }
/* 475 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 479 */     return clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isExported(Class<?> type) {
/* 484 */     String packageName = type.getPackage().getName();
/* 485 */     Module module = type.getModule();
/* 486 */     return module.isExported(packageName);
/*     */   }
/*     */   
/*     */   private static class NotFound {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ImportHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */