/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticFieldELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  35 */     Objects.requireNonNull(context);
/*     */     
/*  37 */     if (base instanceof ELClass && property instanceof String) {
/*  38 */       context.setPropertyResolved(base, property);
/*     */       
/*  40 */       Class<?> clazz = ((ELClass)base).getKlass();
/*  41 */       String name = (String)property;
/*  42 */       Exception exception = null;
/*     */       try {
/*  44 */         Field field = clazz.getField(name);
/*  45 */         int modifiers = field.getModifiers();
/*  46 */         if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers) && Util.canAccess(null, field)) {
/*  47 */           return field.get(null);
/*     */         }
/*  49 */       } catch (IllegalArgumentException|IllegalAccessException|NoSuchFieldException|SecurityException e) {
/*  50 */         exception = e;
/*     */       } 
/*  52 */       String msg = Util.message(context, "staticFieldELResolver.notFound", new Object[] { name, clazz.getName() });
/*  53 */       if (exception == null) {
/*  54 */         throw new PropertyNotFoundException(msg);
/*     */       }
/*  56 */       throw new PropertyNotFoundException(msg, exception);
/*     */     } 
/*     */     
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/*  65 */     Objects.requireNonNull(context);
/*     */     
/*  67 */     if (base instanceof ELClass && property instanceof String) {
/*  68 */       Class<?> clazz = ((ELClass)base).getKlass();
/*  69 */       String name = (String)property;
/*     */       
/*  71 */       throw new PropertyNotWritableException(
/*  72 */           Util.message(context, "staticFieldELResolver.notWritable", new Object[] { name, clazz.getName() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(ELContext context, Object base, Object method, Class<?>[] paramTypes, Object[] params) {
/*  79 */     Objects.requireNonNull(context);
/*     */     
/*  81 */     if (base instanceof ELClass && method instanceof String) {
/*  82 */       context.setPropertyResolved(base, method);
/*     */       
/*  84 */       Class<?> clazz = ((ELClass)base).getKlass();
/*  85 */       String methodName = (String)method;
/*     */       
/*  87 */       if ("<init>".equals(methodName)) {
/*  88 */         Constructor<?> constructor = Util.findConstructor(context, clazz, paramTypes, params);
/*     */ 
/*     */         
/*  91 */         Object[] arrayOfObject = Util.buildParameters(context, constructor.getParameterTypes(), constructor.isVarArgs(), params);
/*     */         
/*  93 */         Object object = null;
/*     */         
/*     */         try {
/*  96 */           object = constructor.newInstance(arrayOfObject);
/*  97 */         } catch (InvocationTargetException e) {
/*  98 */           Throwable cause = e.getCause();
/*  99 */           Util.handleThrowable(cause);
/* 100 */           throw new ELException(cause);
/* 101 */         } catch (ReflectiveOperationException e) {
/* 102 */           throw new ELException(e);
/*     */         } 
/* 104 */         return object;
/*     */       } 
/*     */ 
/*     */       
/* 108 */       Method match = Util.findMethod(context, clazz, null, methodName, paramTypes, params);
/*     */       
/* 110 */       if (match == null) {
/* 111 */         throw new MethodNotFoundException(
/* 112 */             Util.message(context, "staticFieldELResolver.methodNotFound", new Object[] { methodName, clazz.getName() }));
/*     */       }
/*     */ 
/*     */       
/* 116 */       Object[] parameters = Util.buildParameters(context, match.getParameterTypes(), match.isVarArgs(), params);
/*     */       
/* 118 */       Object result = null;
/*     */       try {
/* 120 */         result = match.invoke(null, parameters);
/* 121 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 122 */         throw new ELException(e);
/* 123 */       } catch (InvocationTargetException e) {
/* 124 */         Throwable cause = e.getCause();
/* 125 */         Util.handleThrowable(cause);
/* 126 */         throw new ELException(cause);
/*     */       } 
/* 128 */       return result;
/*     */     } 
/*     */     
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/* 136 */     Objects.requireNonNull(context);
/*     */     
/* 138 */     if (base instanceof ELClass && property instanceof String) {
/* 139 */       context.setPropertyResolved(base, property);
/*     */       
/* 141 */       Class<?> clazz = ((ELClass)base).getKlass();
/* 142 */       String name = (String)property;
/* 143 */       Exception exception = null;
/*     */       try {
/* 145 */         Field field = clazz.getField(name);
/* 146 */         int modifiers = field.getModifiers();
/* 147 */         if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers) && Util.canAccess(null, field))
/*     */         {
/* 149 */           return null;
/*     */         }
/* 151 */       } catch (IllegalArgumentException|NoSuchFieldException|SecurityException e) {
/* 152 */         exception = e;
/*     */       } 
/* 154 */       String msg = Util.message(context, "staticFieldELResolver.notFound", new Object[] { name, clazz.getName() });
/* 155 */       if (exception == null) {
/* 156 */         throw new PropertyNotFoundException(msg);
/*     */       }
/* 158 */       throw new PropertyNotFoundException(msg, exception);
/*     */     } 
/*     */     
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 167 */     Objects.requireNonNull(context);
/*     */     
/* 169 */     if (base instanceof ELClass && property instanceof String) {
/* 170 */       context.setPropertyResolved(base, property);
/*     */     }
/* 172 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 192 */     return String.class;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\StaticFieldELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */