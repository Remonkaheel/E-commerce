/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private final boolean readOnly;
/*     */   
/*     */   public ArrayELResolver() {
/*  35 */     this.readOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayELResolver(boolean readOnly) {
/*  44 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  49 */     Objects.requireNonNull(context);
/*     */     
/*  51 */     if (base != null && base.getClass().isArray()) {
/*  52 */       context.setPropertyResolved(base, property);
/*     */       try {
/*  54 */         int idx = coerce(property);
/*  55 */         checkBounds(base, idx);
/*  56 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  63 */       if (this.readOnly) {
/*  64 */         return null;
/*     */       }
/*  66 */       return base.getClass().getComponentType();
/*     */     } 
/*     */     
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  74 */     Objects.requireNonNull(context);
/*     */     
/*  76 */     if (base != null && base.getClass().isArray()) {
/*  77 */       context.setPropertyResolved(base, property);
/*  78 */       int idx = coerce(property);
/*  79 */       if (idx < 0 || idx >= Array.getLength(base)) {
/*  80 */         return null;
/*     */       }
/*  82 */       return Array.get(base, idx);
/*     */     } 
/*     */     
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/*  90 */     Objects.requireNonNull(context);
/*     */     
/*  92 */     if (base != null && base.getClass().isArray()) {
/*  93 */       context.setPropertyResolved(base, property);
/*     */       
/*  95 */       if (this.readOnly) {
/*  96 */         throw new PropertyNotWritableException(
/*  97 */             Util.message(context, "resolverNotWritable", new Object[] { base.getClass().getName() }));
/*     */       }
/*     */       
/* 100 */       int idx = coerce(property);
/* 101 */       checkBounds(base, idx);
/* 102 */       if (value != null && !Util.isAssignableFrom(value.getClass(), base.getClass().getComponentType())) {
/* 103 */         throw new ClassCastException(Util.message(context, "objectNotAssignable", new Object[] { value.getClass().getName(), base
/* 104 */                 .getClass().getComponentType().getName() }));
/*     */       }
/* 106 */       Array.set(base, idx, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 112 */     Objects.requireNonNull(context);
/*     */     
/* 114 */     if (base != null && base.getClass().isArray()) {
/* 115 */       context.setPropertyResolved(base, property);
/*     */       try {
/* 117 */         int idx = coerce(property);
/* 118 */         checkBounds(base, idx);
/* 119 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 124 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 135 */     if (base != null && base.getClass().isArray()) {
/* 136 */       return Integer.class;
/*     */     }
/* 138 */     return null;
/*     */   }
/*     */   
/*     */   private static void checkBounds(Object base, int idx) {
/* 142 */     if (idx < 0 || idx >= Array.getLength(base)) {
/* 143 */       throw new PropertyNotFoundException((new ArrayIndexOutOfBoundsException(idx)).getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private static int coerce(Object property) {
/* 148 */     if (property instanceof Number) {
/* 149 */       return ((Number)property).intValue();
/*     */     }
/* 151 */     if (property instanceof Character) {
/* 152 */       return ((Character)property).charValue();
/*     */     }
/* 154 */     if (property instanceof Boolean) {
/* 155 */       return ((Boolean)property).booleanValue() ? 1 : 0;
/*     */     }
/* 157 */     if (property instanceof String) {
/* 158 */       return Integer.parseInt((String)property);
/*     */     }
/* 160 */     throw new IllegalArgumentException((property != null) ? property.toString() : "null");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ArrayELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */