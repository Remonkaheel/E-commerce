package jakarta.el;

import java.io.Serializable;

public abstract class Expression implements Serializable {
  private static final long serialVersionUID = -6663767980471823812L;
  
  public abstract String getExpressionString();
  
  public abstract boolean equals(Object paramObject);
  
  public abstract int hashCode();
  
  public abstract boolean isLiteralText();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\Expression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */