/*     */ package jakarta.el;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodReference
/*     */ {
/*     */   private final Object base;
/*     */   private final MethodInfo methodInfo;
/*     */   private final Annotation[] annotations;
/*     */   private final Object[] evaluatedParameters;
/*     */   
/*     */   public MethodReference(Object base, MethodInfo methodInfo, Annotation[] annotations, Object[] evaluatedParameters) {
/*  36 */     this.base = base;
/*  37 */     this.methodInfo = methodInfo;
/*  38 */     this.annotations = annotations;
/*  39 */     this.evaluatedParameters = evaluatedParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBase() {
/*  49 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo() {
/*  61 */     return this.methodInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/*  72 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getEvaluatedParameters() {
/*  83 */     return this.evaluatedParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  89 */     int prime = 31;
/*  90 */     int result = 1;
/*  91 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/*  92 */     result = 31 * result + ((this.base == null) ? 0 : this.base.hashCode());
/*  93 */     result = 31 * result + Arrays.deepHashCode(this.evaluatedParameters);
/*  94 */     result = 31 * result + ((this.methodInfo == null) ? 0 : this.methodInfo.hashCode());
/*  95 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 101 */     if (this == obj) {
/* 102 */       return true;
/*     */     }
/* 104 */     if (obj == null) {
/* 105 */       return false;
/*     */     }
/* 107 */     if (getClass() != obj.getClass()) {
/* 108 */       return false;
/*     */     }
/* 110 */     MethodReference other = (MethodReference)obj;
/* 111 */     if (!Arrays.equals((Object[])this.annotations, (Object[])other.annotations)) {
/* 112 */       return false;
/*     */     }
/* 114 */     if (this.base == null) {
/* 115 */       if (other.base != null) {
/* 116 */         return false;
/*     */       }
/* 118 */     } else if (!this.base.equals(other.base)) {
/* 119 */       return false;
/*     */     } 
/* 121 */     if (!Arrays.deepEquals(this.evaluatedParameters, other.evaluatedParameters)) {
/* 122 */       return false;
/*     */     }
/* 124 */     if (this.methodInfo == null) {
/* 125 */       if (other.methodInfo != null) {
/* 126 */         return false;
/*     */       }
/* 128 */     } else if (!this.methodInfo.equals(other.methodInfo)) {
/* 129 */       return false;
/*     */     } 
/* 131 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\MethodReference.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */