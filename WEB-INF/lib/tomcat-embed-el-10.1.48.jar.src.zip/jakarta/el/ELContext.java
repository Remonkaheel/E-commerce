/*     */ package jakarta.el;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ELContext
/*     */ {
/*     */   private Locale locale;
/*     */   private Map<Class<?>, Object> map;
/*     */   private boolean resolved;
/*  39 */   private ImportHandler importHandler = null;
/*     */   
/*     */   private List<EvaluationListener> listeners;
/*     */   
/*  43 */   private Deque<Map<String, Object>> lambdaArguments = null;
/*     */   
/*     */   public ELContext() {
/*  46 */     this.resolved = false;
/*     */   }
/*     */   
/*     */   private Deque<Map<String, Object>> getLambdaArguments() {
/*  50 */     if (this.lambdaArguments == null) {
/*  51 */       this.lambdaArguments = new ArrayDeque<>(4);
/*     */     }
/*  53 */     return this.lambdaArguments;
/*     */   }
/*     */   
/*     */   public void setPropertyResolved(boolean resolved) {
/*  57 */     this.resolved = resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyResolved(Object base, Object property) {
/*  69 */     setPropertyResolved(true);
/*  70 */     notifyPropertyResolved(base, property);
/*     */   }
/*     */   
/*     */   public boolean isPropertyResolved() {
/*  74 */     return this.resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putContext(Class<?> key, Object contextObject) {
/*  86 */     Objects.requireNonNull(key);
/*  87 */     Objects.requireNonNull(contextObject);
/*     */     
/*  89 */     if (this.map == null) {
/*  90 */       this.map = new HashMap<>();
/*     */     }
/*     */     
/*  93 */     this.map.put(key, contextObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getContext(Class<?> key) {
/* 106 */     Objects.requireNonNull(key);
/* 107 */     if (this.map == null) {
/* 108 */       return null;
/*     */     }
/* 110 */     return this.map.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ELResolver getELResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImportHandler getImportHandler() {
/* 123 */     if (this.importHandler == null) {
/* 124 */       this.importHandler = new ImportHandler();
/*     */     }
/* 126 */     return this.importHandler;
/*     */   }
/*     */   
/*     */   public abstract FunctionMapper getFunctionMapper();
/*     */   
/*     */   public Locale getLocale() {
/* 132 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 136 */     this.locale = locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract VariableMapper getVariableMapper();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEvaluationListener(EvaluationListener listener) {
/* 149 */     if (this.listeners == null) {
/* 150 */       this.listeners = new ArrayList<>();
/*     */     }
/*     */     
/* 153 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EvaluationListener> getEvaluationListeners() {
/* 164 */     return (this.listeners == null) ? Collections.<EvaluationListener>emptyList() : this.listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyBeforeEvaluation(String expression) {
/* 175 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 179 */     for (EvaluationListener listener : this.listeners) {
/*     */       try {
/* 181 */         listener.beforeEvaluation(this, expression);
/* 182 */       } catch (Throwable t) {
/* 183 */         Util.handleThrowable(t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyAfterEvaluation(String expression) {
/* 197 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 201 */     for (EvaluationListener listener : this.listeners) {
/*     */       try {
/* 203 */         listener.afterEvaluation(this, expression);
/* 204 */       } catch (Throwable t) {
/* 205 */         Util.handleThrowable(t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyPropertyResolved(Object base, Object property) {
/* 220 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 224 */     for (EvaluationListener listener : this.listeners) {
/*     */       try {
/* 226 */         listener.propertyResolved(this, base, property);
/* 227 */       } catch (Throwable t) {
/* 228 */         Util.handleThrowable(t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLambdaArgument(String name) {
/* 245 */     for (Map<String, Object> arguments : getLambdaArguments()) {
/* 246 */       if (arguments.containsKey(name)) {
/* 247 */         return true;
/*     */       }
/*     */     } 
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getLambdaArgument(String name) {
/* 263 */     for (Map<String, Object> arguments : getLambdaArguments()) {
/* 264 */       Object result = arguments.get(name);
/* 265 */       if (result != null) {
/* 266 */         return result;
/*     */       }
/*     */     } 
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterLambdaScope(Map<String, Object> arguments) {
/* 281 */     getLambdaArguments().push(arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exitLambdaScope() {
/* 290 */     getLambdaArguments().pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T convertToType(Object obj, Class<T> type) {
/* 308 */     boolean originalResolved = isPropertyResolved();
/* 309 */     setPropertyResolved(false);
/*     */     try {
/* 311 */       ELResolver resolver = getELResolver();
/* 312 */       if (resolver != null) {
/* 313 */         T result = resolver.convertToType(this, obj, type);
/* 314 */         if (isPropertyResolved()) {
/* 315 */           return result;
/*     */         }
/*     */       } 
/*     */     } finally {
/* 319 */       setPropertyResolved(originalResolved);
/*     */     } 
/*     */     
/* 322 */     if (obj instanceof LambdaExpression && isFunctionalInterface(type)) {
/* 323 */       ((LambdaExpression)obj).setELContext(this);
/*     */     }
/*     */     
/* 326 */     return ELManager.getExpressionFactory().coerceToType(obj, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isFunctionalInterface(Class<?> type) {
/* 335 */     if (!type.isInterface()) {
/* 336 */       return false;
/*     */     }
/*     */     
/* 339 */     boolean foundAbstractMethod = false;
/* 340 */     Method[] methods = type.getMethods();
/* 341 */     for (Method method : methods) {
/* 342 */       if (Modifier.isAbstract(method.getModifiers()))
/*     */       {
/*     */         
/* 345 */         if (!overridesObjectMethod(method)) {
/*     */ 
/*     */           
/* 348 */           if (foundAbstractMethod)
/*     */           {
/* 350 */             return false;
/*     */           }
/* 352 */           foundAbstractMethod = true;
/*     */         } 
/*     */       }
/*     */     } 
/* 356 */     return foundAbstractMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean overridesObjectMethod(Method method) {
/* 365 */     if ("equals".equals(method.getName())) {
/* 366 */       if (method.getReturnType().equals(boolean.class) && 
/* 367 */         method.getParameterCount() == 1 && 
/* 368 */         method.getParameterTypes()[0].equals(Object.class)) {
/* 369 */         return true;
/*     */       
/*     */       }
/*     */     }
/* 373 */     else if ("hashCode".equals(method.getName())) {
/* 374 */       if (method.getReturnType().equals(int.class) && 
/* 375 */         method.getParameterCount() == 0) {
/* 376 */         return true;
/*     */       }
/*     */     }
/* 379 */     else if ("toString".equals(method.getName()) && 
/* 380 */       method.getReturnType().equals(String.class) && 
/* 381 */       method.getParameterCount() == 0) {
/* 382 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 387 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ELContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */