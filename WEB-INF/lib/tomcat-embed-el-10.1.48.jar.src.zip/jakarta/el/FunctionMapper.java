package jakarta.el;

import java.lang.reflect.Method;

public abstract class FunctionMapper {
  public abstract Method resolveFunction(String paramString1, String paramString2);
  
  public void mapFunction(String prefix, String localName, Method method) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\FunctionMapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */