/*    */ package jakarta.el;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInfo
/*    */ {
/*    */   private final String name;
/*    */   private final Class<?>[] paramTypes;
/*    */   private final Class<?> returnType;
/*    */   
/*    */   public MethodInfo(String name, Class<?> returnType, Class<?>[] paramTypes) {
/* 30 */     this.name = name;
/* 31 */     this.returnType = returnType;
/* 32 */     this.paramTypes = paramTypes;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 36 */     return this.name;
/*    */   }
/*    */   
/*    */   public Class<?> getReturnType() {
/* 40 */     return this.returnType;
/*    */   }
/*    */   
/*    */   public Class<?>[] getParamTypes() {
/* 44 */     return this.paramTypes;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 49 */     int prime = 31;
/* 50 */     int result = 1;
/* 51 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 52 */     result = 31 * result + Arrays.hashCode((Object[])this.paramTypes);
/* 53 */     result = 31 * result + ((this.returnType == null) ? 0 : this.returnType.hashCode());
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj) {
/* 60 */       return true;
/*    */     }
/* 62 */     if (obj == null) {
/* 63 */       return false;
/*    */     }
/* 65 */     if (getClass() != obj.getClass()) {
/* 66 */       return false;
/*    */     }
/* 68 */     MethodInfo other = (MethodInfo)obj;
/* 69 */     if (this.name == null) {
/* 70 */       if (other.name != null) {
/* 71 */         return false;
/*    */       }
/* 73 */     } else if (!this.name.equals(other.name)) {
/* 74 */       return false;
/*    */     } 
/* 76 */     if (!Arrays.equals((Object[])this.paramTypes, (Object[])other.paramTypes)) {
/* 77 */       return false;
/*    */     }
/* 79 */     if (this.returnType == null) {
/* 80 */       if (other.returnType != null) {
/* 81 */         return false;
/*    */       }
/* 83 */     } else if (!this.returnType.equals(other.returnType)) {
/* 84 */       return false;
/*    */     } 
/* 86 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\MethodInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */