/*    */ package jakarta.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MethodExpression
/*    */   extends Expression
/*    */ {
/*    */   private static final long serialVersionUID = 8163925562047324656L;
/*    */   
/*    */   public abstract MethodInfo getMethodInfo(ELContext paramELContext);
/*    */   
/*    */   public abstract Object invoke(ELContext paramELContext, Object[] paramArrayOfObject);
/*    */   
/*    */   public boolean isParametersProvided() {
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodReference getMethodReference(ELContext context) {
/* 78 */     context.notifyBeforeEvaluation(getExpressionString());
/* 79 */     context.notifyAfterEvaluation(getExpressionString());
/* 80 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\MethodExpression.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */