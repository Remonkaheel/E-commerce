/*    */ package jakarta.el;
/*    */ 
/*    */ import java.beans.FeatureDescriptor;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TypeConverter
/*    */   extends ELResolver
/*    */ {
/*    */   public Object getValue(ELContext context, Object base, Object property) {
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getType(ELContext context, Object base, Object property) {
/* 34 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(ELContext context, Object base, Object property, Object value) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*    */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 55 */     return null;
/*    */   }
/*    */   
/*    */   public abstract <T> T convertToType(ELContext paramELContext, Object paramObject, Class<T> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\TypeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */