/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Objects;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceBundleELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  36 */     Objects.requireNonNull(context);
/*     */     
/*  38 */     if (base instanceof ResourceBundle) {
/*  39 */       context.setPropertyResolved(base, property);
/*     */       
/*  41 */       if (property != null) {
/*     */         try {
/*  43 */           return ((ResourceBundle)base).getObject(property.toString());
/*  44 */         } catch (MissingResourceException mre) {
/*  45 */           return "???" + property.toString() + "???";
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  50 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  55 */     Objects.requireNonNull(context);
/*     */     
/*  57 */     if (base instanceof ResourceBundle) {
/*  58 */       context.setPropertyResolved(base, property);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/*  69 */     Objects.requireNonNull(context);
/*     */     
/*  71 */     if (base instanceof ResourceBundle) {
/*  72 */       context.setPropertyResolved(base, property);
/*  73 */       throw new PropertyNotWritableException(
/*  74 */           Util.message(context, "resolverNotWritable", new Object[] { base.getClass().getName() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/*  80 */     Objects.requireNonNull(context);
/*     */     
/*  82 */     if (base instanceof ResourceBundle) {
/*  83 */       context.setPropertyResolved(base, property);
/*  84 */       return true;
/*     */     } 
/*     */     
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/*  93 */     if (base instanceof ResourceBundle) {
/*  94 */       List<FeatureDescriptor> feats = new ArrayList<>();
/*  95 */       Enumeration<String> e = ((ResourceBundle)base).getKeys();
/*     */ 
/*     */       
/*  98 */       while (e.hasMoreElements()) {
/*  99 */         String key = e.nextElement();
/* 100 */         FeatureDescriptor feat = new FeatureDescriptor();
/* 101 */         feat.setDisplayName(key);
/* 102 */         feat.setShortDescription("");
/* 103 */         feat.setExpert(false);
/* 104 */         feat.setHidden(false);
/* 105 */         feat.setName(key);
/* 106 */         feat.setPreferred(true);
/* 107 */         feat.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 108 */         feat.setValue("type", String.class);
/* 109 */         feats.add(feat);
/*     */       } 
/* 111 */       return feats.iterator();
/*     */     } 
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 118 */     if (base instanceof ResourceBundle) {
/* 119 */       return String.class;
/*     */     }
/* 121 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ResourceBundleELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */