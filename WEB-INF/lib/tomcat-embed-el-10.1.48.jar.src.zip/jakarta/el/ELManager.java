/*    */ package jakarta.el;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ELManager
/*    */ {
/* 27 */   private StandardELContext context = null;
/*    */   
/*    */   public static ExpressionFactory getExpressionFactory() {
/* 30 */     return Util.getExpressionFactory();
/*    */   }
/*    */   
/*    */   public StandardELContext getELContext() {
/* 34 */     if (this.context == null) {
/* 35 */       this.context = new StandardELContext(getExpressionFactory());
/*    */     }
/*    */     
/* 38 */     return this.context;
/*    */   }
/*    */   
/*    */   public ELContext setELContext(ELContext context) {
/* 42 */     StandardELContext oldContext = this.context;
/* 43 */     this.context = new StandardELContext(context);
/* 44 */     return oldContext;
/*    */   }
/*    */   
/*    */   public void addBeanNameResolver(BeanNameResolver beanNameResolver) {
/* 48 */     getELContext().addELResolver(new BeanNameELResolver(beanNameResolver));
/*    */   }
/*    */   
/*    */   public void addELResolver(ELResolver resolver) {
/* 52 */     getELContext().addELResolver(resolver);
/*    */   }
/*    */   
/*    */   public void mapFunction(String prefix, String function, Method method) {
/* 56 */     getELContext().getFunctionMapper().mapFunction(prefix, function, method);
/*    */   }
/*    */   
/*    */   public void setVariable(String variable, ValueExpression expression) {
/* 60 */     getELContext().getVariableMapper().setVariable(variable, expression);
/*    */   }
/*    */   
/*    */   public void importStatic(String staticMemberName) throws ELException {
/* 64 */     getELContext().getImportHandler().importStatic(staticMemberName);
/*    */   }
/*    */   
/*    */   public void importClass(String className) throws ELException {
/* 68 */     getELContext().getImportHandler().importClass(className);
/*    */   }
/*    */   
/*    */   public void importPackage(String packageName) {
/* 72 */     getELContext().getImportHandler().importPackage(packageName);
/*    */   }
/*    */   
/*    */   public Object defineBean(String name, Object bean) {
/* 76 */     Map<String, Object> localBeans = getELContext().getLocalBeans();
/*    */     
/* 78 */     if (bean == null) {
/* 79 */       return localBeans.remove(name);
/*    */     }
/* 81 */     return localBeans.put(name, bean);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addEvaluationListener(EvaluationListener listener) {
/* 86 */     getELContext().addEvaluationListener(listener);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ELManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */