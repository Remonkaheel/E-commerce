/*    */ package jakarta.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyNotWritableException
/*    */   extends ELException
/*    */ {
/*    */   private static final long serialVersionUID = 827987155471214717L;
/*    */   
/*    */   public PropertyNotWritableException() {}
/*    */   
/*    */   public PropertyNotWritableException(String message) {
/* 28 */     super(message);
/*    */   }
/*    */   
/*    */   public PropertyNotWritableException(Throwable cause) {
/* 32 */     super(cause);
/*    */   }
/*    */   
/*    */   public PropertyNotWritableException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\PropertyNotWritableException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */