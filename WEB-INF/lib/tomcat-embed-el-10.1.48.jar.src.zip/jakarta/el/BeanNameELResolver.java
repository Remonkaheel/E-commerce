/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanNameELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private final BeanNameResolver beanNameResolver;
/*     */   
/*     */   public BeanNameELResolver(BeanNameResolver beanNameResolver) {
/*  31 */     this.beanNameResolver = beanNameResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  36 */     Objects.requireNonNull(context);
/*  37 */     if (base != null || !(property instanceof String)) {
/*  38 */       return null;
/*     */     }
/*     */     
/*  41 */     String beanName = (String)property;
/*     */     
/*  43 */     if (this.beanNameResolver.isNameResolved(beanName)) {
/*     */       try {
/*  45 */         Object result = this.beanNameResolver.getBean(beanName);
/*  46 */         context.setPropertyResolved(base, property);
/*  47 */         return result;
/*  48 */       } catch (Throwable t) {
/*  49 */         Util.handleThrowable(t);
/*  50 */         throw new ELException(t);
/*     */       } 
/*     */     }
/*     */     
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/*     */     boolean isReadOnly;
/*  59 */     Objects.requireNonNull(context);
/*  60 */     if (base != null || !(property instanceof String)) {
/*     */       return;
/*     */     }
/*     */     
/*  64 */     String beanName = (String)property;
/*     */     
/*  66 */     boolean isResolved = context.isPropertyResolved();
/*     */ 
/*     */     
/*     */     try {
/*  70 */       isReadOnly = isReadOnly(context, base, property);
/*  71 */     } catch (Throwable t) {
/*  72 */       Util.handleThrowable(t);
/*  73 */       throw new ELException(t);
/*     */     } finally {
/*  75 */       context.setPropertyResolved(isResolved);
/*     */     } 
/*     */     
/*  78 */     if (isReadOnly) {
/*  79 */       throw new PropertyNotWritableException(Util.message(context, "beanNameELResolver.beanReadOnly", new Object[] { beanName }));
/*     */     }
/*     */     
/*  82 */     if (this.beanNameResolver.isNameResolved(beanName) || this.beanNameResolver.canCreateBean(beanName)) {
/*     */       try {
/*  84 */         this.beanNameResolver.setBeanValue(beanName, value);
/*  85 */         context.setPropertyResolved(base, property);
/*  86 */       } catch (Throwable t) {
/*  87 */         Util.handleThrowable(t);
/*  88 */         throw new ELException(t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  95 */     Objects.requireNonNull(context);
/*  96 */     if (base != null || !(property instanceof String)) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     String beanName = (String)property;
/*     */     
/*     */     try {
/* 103 */       if (this.beanNameResolver.isNameResolved(beanName)) {
/* 104 */         Class<?> result = this.beanNameResolver.getBean(beanName).getClass();
/* 105 */         context.setPropertyResolved(base, property);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         if (this.beanNameResolver.isReadOnly((String)property)) {
/* 111 */           return null;
/*     */         }
/*     */         
/* 114 */         return result;
/*     */       } 
/* 116 */     } catch (Throwable t) {
/* 117 */       Util.handleThrowable(t);
/* 118 */       throw new ELException(t);
/*     */     } 
/*     */     
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 126 */     Objects.requireNonNull(context);
/* 127 */     if (base != null || !(property instanceof String))
/*     */     {
/* 129 */       return false;
/*     */     }
/*     */     
/* 132 */     String beanName = (String)property;
/*     */     
/* 134 */     if (this.beanNameResolver.isNameResolved(beanName)) {
/*     */       boolean result;
/*     */       try {
/* 137 */         result = this.beanNameResolver.isReadOnly(beanName);
/* 138 */       } catch (Throwable t) {
/* 139 */         Util.handleThrowable(t);
/* 140 */         throw new ELException(t);
/*     */       } 
/* 142 */       context.setPropertyResolved(base, property);
/* 143 */       return result;
/*     */     } 
/*     */ 
/*     */     
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 158 */     return String.class;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\BeanNameELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */