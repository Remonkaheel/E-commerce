/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapELResolver
/*     */   extends ELResolver
/*     */ {
/*  30 */   private static final Class<?> UNMODIFIABLE = Collections.unmodifiableMap(new HashMap<>()).getClass();
/*     */   
/*     */   private final boolean readOnly;
/*     */   
/*     */   public MapELResolver() {
/*  35 */     this.readOnly = false;
/*     */   }
/*     */   
/*     */   public MapELResolver(boolean readOnly) {
/*  39 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  44 */     Objects.requireNonNull(context);
/*     */     
/*  46 */     if (base instanceof Map) {
/*  47 */       context.setPropertyResolved(base, property);
/*     */       
/*  49 */       Map<?, ?> map = (Map<?, ?>)base;
/*  50 */       if (this.readOnly || map.getClass() == UNMODIFIABLE) {
/*  51 */         return null;
/*     */       }
/*     */       
/*  54 */       return Object.class;
/*     */     } 
/*     */     
/*  57 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  62 */     Objects.requireNonNull(context);
/*     */     
/*  64 */     if (base instanceof Map) {
/*  65 */       context.setPropertyResolved(base, property);
/*  66 */       return ((Map)base).get(property);
/*     */     } 
/*     */     
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/*  74 */     Objects.requireNonNull(context);
/*     */     
/*  76 */     if (base instanceof Map) {
/*  77 */       context.setPropertyResolved(base, property);
/*     */       
/*  79 */       if (this.readOnly) {
/*  80 */         throw new PropertyNotWritableException(
/*  81 */             Util.message(context, "resolverNotWritable", new Object[] { base.getClass().getName() }));
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/*  86 */         Map<Object, Object> map = (Map<Object, Object>)base;
/*  87 */         map.put(property, value);
/*  88 */       } catch (UnsupportedOperationException e) {
/*  89 */         throw new PropertyNotWritableException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/*  96 */     Objects.requireNonNull(context);
/*     */     
/*  98 */     if (base instanceof Map) {
/*  99 */       context.setPropertyResolved(base, property);
/* 100 */       return (this.readOnly || UNMODIFIABLE.equals(base.getClass()));
/*     */     } 
/*     */     
/* 103 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 109 */     if (base instanceof Map) {
/* 110 */       Iterator<?> itr = ((Map)base).keySet().iterator();
/* 111 */       List<FeatureDescriptor> feats = new ArrayList<>();
/*     */ 
/*     */       
/* 114 */       while (itr.hasNext()) {
/* 115 */         Object key = itr.next();
/* 116 */         FeatureDescriptor desc = new FeatureDescriptor();
/* 117 */         desc.setDisplayName(key.toString());
/* 118 */         desc.setShortDescription("");
/* 119 */         desc.setExpert(false);
/* 120 */         desc.setHidden(false);
/* 121 */         desc.setName(key.toString());
/* 122 */         desc.setPreferred(true);
/* 123 */         desc.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 124 */         desc.setValue("type", key.getClass());
/* 125 */         feats.add(desc);
/*     */       } 
/* 127 */       return feats.iterator();
/*     */     } 
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 134 */     if (base instanceof Map) {
/* 135 */       return Object.class;
/*     */     }
/* 137 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\MapELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */