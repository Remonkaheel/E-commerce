/*    */ package jakarta.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ELClass
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   
/*    */   public ELClass(Class<?> clazz) {
/* 27 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public Class<?> getKlass() {
/* 31 */     return this.clazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ELClass.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */