/*    */ package jakarta.el;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ELContextEvent
/*    */   extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1255131906285426769L;
/*    */   
/*    */   public ELContextEvent(ELContext source) {
/* 29 */     super(source);
/*    */   }
/*    */   
/*    */   public ELContext getELContext() {
/* 33 */     return (ELContext)getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ELContextEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */