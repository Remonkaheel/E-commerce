package jakarta.el;

import java.util.EventListener;

public interface ELContextListener extends EventListener {
  void contextCreated(ELContextEvent paramELContextEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ELContextListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */