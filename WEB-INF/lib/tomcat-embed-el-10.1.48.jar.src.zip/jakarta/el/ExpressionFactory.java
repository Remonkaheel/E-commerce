/*     */ package jakarta.el;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExpressionFactory
/*     */ {
/*  44 */   private static final boolean IS_SECURITY_ENABLED = (System.getSecurityManager() != null);
/*     */   
/*     */   private static final String PROPERTY_NAME = "jakarta.el.ExpressionFactory";
/*     */   
/*     */   private static final String PROPERTY_FILE;
/*     */   
/*  50 */   private static final CacheValue nullTcclFactory = new CacheValue();
/*  51 */   private static final Map<CacheKey, CacheValue> factoryCache = new ConcurrentHashMap<>();
/*     */   
/*     */   static {
/*  54 */     if (IS_SECURITY_ENABLED) {
/*     */       
/*  56 */       PROPERTY_FILE = AccessController.<String>doPrivileged(() -> System.getProperty("java.home") + System.getProperty("java.home") + "lib" + File.separator + "el.properties");
/*     */     } else {
/*     */       
/*  59 */       PROPERTY_FILE = System.getProperty("java.home") + System.getProperty("java.home") + "lib" + File.separator + "el.properties";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExpressionFactory newInstance() {
/*  75 */     return newInstance(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExpressionFactory newInstance(Properties properties) {
/*     */     CacheValue cacheValue;
/*     */     Class<?> clazz;
/*  87 */     ExpressionFactory result = null;
/*     */     
/*  89 */     ClassLoader tccl = Util.getContextClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     if (tccl == null) {
/*  95 */       cacheValue = nullTcclFactory;
/*     */     } else {
/*  97 */       CacheKey key = new CacheKey(tccl);
/*  98 */       cacheValue = factoryCache.get(key);
/*  99 */       if (cacheValue == null) {
/* 100 */         CacheValue newCacheValue = new CacheValue();
/* 101 */         cacheValue = factoryCache.putIfAbsent(key, newCacheValue);
/* 102 */         if (cacheValue == null) {
/* 103 */           cacheValue = newCacheValue;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     Lock readLock = cacheValue.getLock().readLock();
/* 109 */     readLock.lock();
/*     */     try {
/* 111 */       clazz = cacheValue.getFactoryClass();
/*     */     } finally {
/* 113 */       readLock.unlock();
/*     */     } 
/*     */     
/* 116 */     if (clazz == null) {
/* 117 */       String className = null;
/*     */       try {
/* 119 */         Lock writeLock = cacheValue.getLock().writeLock();
/* 120 */         writeLock.lock();
/*     */         try {
/* 122 */           className = cacheValue.getFactoryClassName();
/* 123 */           if (className == null) {
/* 124 */             className = discoverClassName(tccl);
/* 125 */             cacheValue.setFactoryClassName(className);
/*     */           } 
/* 127 */           if (tccl == null) {
/* 128 */             clazz = Class.forName(className);
/*     */           } else {
/* 130 */             clazz = tccl.loadClass(className);
/*     */           } 
/* 132 */           cacheValue.setFactoryClass(clazz);
/*     */         } finally {
/* 134 */           writeLock.unlock();
/*     */         } 
/* 136 */       } catch (ClassNotFoundException e) {
/* 137 */         throw new ELException(Util.message(null, "expressionFactory.cannotFind", new Object[] { className }), e);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 142 */       Constructor<?> constructor = null;
/*     */       
/* 144 */       if (properties != null) {
/*     */         try {
/* 146 */           constructor = clazz.getConstructor(new Class[] { Properties.class });
/* 147 */         } catch (SecurityException se) {
/* 148 */           throw new ELException(se);
/* 149 */         } catch (NoSuchMethodException noSuchMethodException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 154 */       if (constructor == null) {
/* 155 */         result = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */       } else {
/* 157 */         result = (ExpressionFactory)constructor.newInstance(new Object[] { properties });
/*     */       }
/*     */     
/* 160 */     } catch (InvocationTargetException e) {
/* 161 */       Throwable cause = e.getCause();
/* 162 */       Util.handleThrowable(cause);
/* 163 */       throw new ELException(Util.message(null, "expressionFactory.cannotCreate", new Object[] { clazz.getName() }), e);
/* 164 */     } catch (ReflectiveOperationException|IllegalArgumentException e) {
/* 165 */       throw new ELException(Util.message(null, "expressionFactory.cannotCreate", new Object[] { clazz.getName() }), e);
/*     */     } 
/*     */     
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ELResolver getStreamELResolver() {
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Method> getInitFunctionMap() {
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CacheKey
/*     */   {
/*     */     private final int hash;
/*     */     
/*     */     private final WeakReference<ClassLoader> ref;
/*     */ 
/*     */     
/*     */     CacheKey(ClassLoader cl) {
/* 243 */       this.hash = cl.hashCode();
/* 244 */       this.ref = new WeakReference<>(cl);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 249 */       return this.hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 254 */       if (obj == this) {
/* 255 */         return true;
/*     */       }
/* 257 */       if (!(obj instanceof CacheKey)) {
/* 258 */         return false;
/*     */       }
/* 260 */       ClassLoader thisCl = this.ref.get();
/* 261 */       if (thisCl == null) {
/* 262 */         return false;
/*     */       }
/* 264 */       return (thisCl == ((CacheKey)obj).ref.get());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CacheValue {
/* 269 */     private final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */     
/*     */     private String className;
/*     */     
/*     */     private WeakReference<Class<?>> ref;
/*     */ 
/*     */     
/*     */     public ReadWriteLock getLock() {
/* 277 */       return this.lock;
/*     */     }
/*     */     
/*     */     public String getFactoryClassName() {
/* 281 */       return this.className;
/*     */     }
/*     */     
/*     */     public void setFactoryClassName(String className) {
/* 285 */       this.className = className;
/*     */     }
/*     */     
/*     */     public Class<?> getFactoryClass() {
/* 289 */       return (this.ref != null) ? this.ref.get() : null;
/*     */     }
/*     */     
/*     */     public void setFactoryClass(Class<?> clazz) {
/* 293 */       this.ref = new WeakReference<>(clazz);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String discoverClassName(ClassLoader tccl) {
/* 305 */     String className = null;
/*     */ 
/*     */     
/* 308 */     className = getClassNameServices(tccl);
/* 309 */     if (className == null) {
/* 310 */       if (IS_SECURITY_ENABLED) {
/*     */         
/* 312 */         className = AccessController.<String>doPrivileged(ExpressionFactory::getClassNameJreDir);
/*     */       } else {
/*     */         
/* 315 */         className = getClassNameJreDir();
/*     */       } 
/*     */     }
/* 318 */     if (className == null) {
/* 319 */       if (IS_SECURITY_ENABLED) {
/*     */         
/* 321 */         className = AccessController.<String>doPrivileged(ExpressionFactory::getClassNameSysProp);
/*     */       } else {
/*     */         
/* 324 */         className = getClassNameSysProp();
/*     */       } 
/*     */     }
/* 327 */     if (className == null)
/*     */     {
/* 329 */       className = "org.apache.el.ExpressionFactoryImpl";
/*     */     }
/* 331 */     return className;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getClassNameServices(ClassLoader tccl) {
/* 336 */     ExpressionFactory result = null;
/*     */     
/* 338 */     ServiceLoader<ExpressionFactory> serviceLoader = ServiceLoader.load(ExpressionFactory.class, tccl);
/* 339 */     Iterator<ExpressionFactory> iter = serviceLoader.iterator();
/* 340 */     while (result == null && iter.hasNext()) {
/* 341 */       result = iter.next();
/*     */     }
/*     */     
/* 344 */     if (result == null) {
/* 345 */       return null;
/*     */     }
/*     */     
/* 348 */     return result.getClass().getName();
/*     */   }
/*     */   
/*     */   private static String getClassNameJreDir() {
/* 352 */     File file = new File(PROPERTY_FILE);
/* 353 */     if (file.canRead()) {
/* 354 */       try { InputStream is = new FileInputStream(file); 
/* 355 */         try { Properties props = new Properties();
/* 356 */           props.load(is);
/* 357 */           String value = props.getProperty("jakarta.el.ExpressionFactory");
/* 358 */           if (value != null && value.trim().length() > 0)
/* 359 */           { String str = value.trim();
/*     */             
/* 361 */             is.close(); return str; }  is.close(); } catch (Throwable throwable) { try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (FileNotFoundException fileNotFoundException)
/*     */       {  }
/* 363 */       catch (IOException ioe)
/* 364 */       { throw new ELException(Util.message(null, "expressionFactory.readFailed", new Object[] { PROPERTY_FILE }), ioe); }
/*     */     
/*     */     }
/* 367 */     return null;
/*     */   }
/*     */   
/*     */   private static String getClassNameSysProp() {
/* 371 */     String value = System.getProperty("jakarta.el.ExpressionFactory");
/* 372 */     if (value != null && value.trim().length() > 0) {
/* 373 */       return value.trim();
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */   
/*     */   public abstract ValueExpression createValueExpression(ELContext paramELContext, String paramString, Class<?> paramClass);
/*     */   
/*     */   public abstract ValueExpression createValueExpression(Object paramObject, Class<?> paramClass);
/*     */   
/*     */   public abstract MethodExpression createMethodExpression(ELContext paramELContext, String paramString, Class<?> paramClass, Class<?>[] paramArrayOfClass);
/*     */   
/*     */   public abstract <T> T coerceToType(Object paramObject, Class<T> paramClass);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ExpressionFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */