/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private static final int CACHE_SIZE;
/*     */   private static final String CACHE_SIZE_PROP = "org.apache.el.BeanELResolver.CACHE_SIZE";
/*     */   private final boolean readOnly;
/*     */   
/*     */   static {
/*  45 */     if (System.getSecurityManager() == null) {
/*  46 */       CACHE_SIZE = Integer.getInteger("org.apache.el.BeanELResolver.CACHE_SIZE", 1000).intValue();
/*     */     }
/*     */     else {
/*     */       
/*  50 */       CACHE_SIZE = ((Integer)AccessController.<Integer>doPrivileged(() -> Integer.getInteger("org.apache.el.BeanELResolver.CACHE_SIZE", 1000))).intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  56 */   private final ConcurrentCache<String, BeanProperties> cache = new ConcurrentCache<>(CACHE_SIZE);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanELResolver() {
/*  62 */     this.readOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanELResolver(boolean readOnly) {
/*  71 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  76 */     Objects.requireNonNull(context);
/*  77 */     if (base == null || property == null) {
/*  78 */       return null;
/*     */     }
/*     */     
/*  81 */     context.setPropertyResolved(base, property);
/*  82 */     BeanProperty beanProperty = property(context, base, property);
/*     */     
/*  84 */     if (this.readOnly || beanProperty.isReadOnly(base)) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     return beanProperty.getPropertyType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  93 */     Objects.requireNonNull(context);
/*  94 */     if (base == null || property == null) {
/*  95 */       return null;
/*     */     }
/*     */     
/*  98 */     context.setPropertyResolved(base, property);
/*  99 */     Method m = property(context, base, property).read(context, base);
/*     */     try {
/* 101 */       return m.invoke(base, (Object[])null);
/* 102 */     } catch (InvocationTargetException e) {
/* 103 */       Throwable cause = e.getCause();
/* 104 */       Util.handleThrowable(cause);
/* 105 */       throw new ELException(
/* 106 */           Util.message(context, "propertyReadError", new Object[] { base.getClass().getName(), property.toString() }), cause);
/* 107 */     } catch (Exception e) {
/* 108 */       throw new ELException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/* 114 */     Objects.requireNonNull(context);
/* 115 */     if (base == null || property == null) {
/*     */       return;
/*     */     }
/*     */     
/* 119 */     context.setPropertyResolved(base, property);
/*     */     
/* 121 */     if (this.readOnly) {
/* 122 */       throw new PropertyNotWritableException(
/* 123 */           Util.message(context, "resolverNotWritable", new Object[] { base.getClass().getName() }));
/*     */     }
/*     */     
/* 126 */     Method m = property(context, base, property).write(context, base);
/*     */     try {
/* 128 */       m.invoke(base, new Object[] { value });
/* 129 */     } catch (InvocationTargetException e) {
/* 130 */       Throwable cause = e.getCause();
/* 131 */       Util.handleThrowable(cause);
/* 132 */       throw new ELException(
/* 133 */           Util.message(context, "propertyWriteError", new Object[] { base.getClass().getName(), property.toString() }), cause);
/* 134 */     } catch (Exception e) {
/* 135 */       throw new ELException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(ELContext context, Object base, Object method, Class<?>[] paramTypes, Object[] params) {
/* 141 */     Objects.requireNonNull(context);
/* 142 */     if (base == null || method == null) {
/* 143 */       return null;
/*     */     }
/*     */     
/* 146 */     ExpressionFactory factory = ELManager.getExpressionFactory();
/*     */     
/* 148 */     String methodName = factory.<String>coerceToType(method, String.class);
/*     */ 
/*     */     
/* 151 */     Method matchingMethod = Util.findMethod(context, base.getClass(), base, methodName, paramTypes, params);
/*     */ 
/*     */     
/* 154 */     Object[] parameters = Util.buildParameters(context, matchingMethod.getParameterTypes(), matchingMethod.isVarArgs(), params);
/*     */     
/* 156 */     Object result = null;
/*     */     try {
/* 158 */       result = matchingMethod.invoke(base, parameters);
/* 159 */     } catch (IllegalArgumentException|IllegalAccessException e) {
/* 160 */       throw new ELException(e);
/* 161 */     } catch (InvocationTargetException e) {
/* 162 */       Throwable cause = e.getCause();
/* 163 */       Util.handleThrowable(cause);
/* 164 */       throw new ELException(cause);
/*     */     } 
/*     */     
/* 167 */     context.setPropertyResolved(base, method);
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 173 */     Objects.requireNonNull(context);
/* 174 */     if (base == null || property == null) {
/* 175 */       return false;
/*     */     }
/*     */     
/* 178 */     context.setPropertyResolved(base, property);
/* 179 */     return (this.readOnly || property(context, base, property).isReadOnly(base));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 185 */     if (base == null) {
/* 186 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 190 */       BeanInfo info = Introspector.getBeanInfo(base.getClass());
/* 191 */       PropertyDescriptor[] pds = info.getPropertyDescriptors();
/* 192 */       for (PropertyDescriptor pd : pds) {
/* 193 */         pd.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 194 */         pd.setValue("type", pd.getPropertyType());
/*     */       } 
/* 196 */       return Arrays.<FeatureDescriptor>asList((FeatureDescriptor[])pds).iterator();
/* 197 */     } catch (IntrospectionException introspectionException) {
/*     */ 
/*     */ 
/*     */       
/* 201 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 206 */     if (base != null) {
/* 207 */       return Object.class;
/*     */     }
/*     */     
/* 210 */     return null;
/*     */   }
/*     */   
/*     */   static final class BeanProperties
/*     */   {
/*     */     private final Map<String, BeanELResolver.BeanProperty> properties;
/*     */     private final Class<?> type;
/*     */     
/*     */     BeanProperties(Class<?> type) throws ELException {
/* 219 */       this.type = type;
/* 220 */       this.properties = new HashMap<>();
/*     */       try {
/* 222 */         BeanInfo info = Introspector.getBeanInfo(this.type);
/* 223 */         PropertyDescriptor[] pds = info.getPropertyDescriptors();
/* 224 */         for (PropertyDescriptor pd : pds) {
/* 225 */           this.properties.put(pd.getName(), new BeanELResolver.BeanProperty(type, pd));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 232 */         populateFromInterfaces(type);
/* 233 */       } catch (IntrospectionException ie) {
/* 234 */         throw new ELException(ie);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void populateFromInterfaces(Class<?> aClass) throws IntrospectionException {
/* 239 */       Class<?>[] interfaces = aClass.getInterfaces();
/* 240 */       if (interfaces.length > 0) {
/* 241 */         for (Class<?> ifs : interfaces) {
/* 242 */           BeanInfo info = Introspector.getBeanInfo(ifs);
/* 243 */           PropertyDescriptor[] pds = info.getPropertyDescriptors();
/* 244 */           for (PropertyDescriptor pd : pds) {
/* 245 */             if (!this.properties.containsKey(pd.getName())) {
/* 246 */               this.properties.put(pd.getName(), new BeanELResolver.BeanProperty(this.type, pd));
/*     */             }
/*     */           } 
/* 249 */           populateFromInterfaces(ifs);
/*     */         } 
/*     */       }
/* 252 */       Class<?> superclass = aClass.getSuperclass();
/* 253 */       if (superclass != null) {
/* 254 */         populateFromInterfaces(superclass);
/*     */       }
/*     */     }
/*     */     
/*     */     private BeanELResolver.BeanProperty get(ELContext ctx, String name) {
/* 259 */       BeanELResolver.BeanProperty property = this.properties.get(name);
/* 260 */       if (property == null) {
/* 261 */         throw new PropertyNotFoundException(Util.message(ctx, "propertyNotFound", new Object[] { this.type.getName(), name }));
/*     */       }
/* 263 */       return property;
/*     */     }
/*     */     
/*     */     private Class<?> getType() {
/* 267 */       return this.type;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BeanProperty
/*     */   {
/*     */     private final Class<?> type;
/*     */     
/*     */     private final Class<?> owner;
/*     */     
/*     */     private final PropertyDescriptor descriptor;
/*     */     private Method read;
/*     */     private Method write;
/*     */     
/*     */     BeanProperty(Class<?> owner, PropertyDescriptor descriptor) {
/* 283 */       this.owner = owner;
/* 284 */       this.descriptor = descriptor;
/* 285 */       this.type = descriptor.getPropertyType();
/*     */     }
/*     */     
/*     */     public Class<?> getPropertyType() {
/* 289 */       return this.type;
/*     */     }
/*     */     
/*     */     public boolean isReadOnly(Object base) {
/* 293 */       return (this.write == null && null == (this
/* 294 */         .write = Util.getMethod(this.owner, base, this.descriptor.getWriteMethod())));
/*     */     }
/*     */     
/*     */     private Method write(ELContext ctx, Object base) {
/* 298 */       if (this.write == null) {
/* 299 */         this.write = Util.getMethod(this.owner, base, this.descriptor.getWriteMethod());
/* 300 */         if (this.write == null) {
/* 301 */           throw new PropertyNotWritableException(Util.message(ctx, "propertyNotWritable", new Object[] { this.owner
/* 302 */                   .getName(), this.descriptor.getName() }));
/*     */         }
/*     */       } 
/* 305 */       return this.write;
/*     */     }
/*     */     
/*     */     private Method read(ELContext ctx, Object base) {
/* 309 */       if (this.read == null) {
/* 310 */         this.read = Util.getMethod(this.owner, base, this.descriptor.getReadMethod());
/* 311 */         if (this.read == null) {
/* 312 */           throw new PropertyNotFoundException(Util.message(ctx, "propertyNotReadable", new Object[] { this.owner
/* 313 */                   .getName(), this.descriptor.getName() }));
/*     */         }
/*     */       } 
/* 316 */       return this.read;
/*     */     }
/*     */   }
/*     */   
/*     */   private BeanProperty property(ELContext ctx, Object base, Object property) {
/* 321 */     Class<?> type = base.getClass();
/* 322 */     String prop = property.toString();
/*     */     
/* 324 */     BeanProperties props = this.cache.get(type.getName());
/* 325 */     if (props == null || type != props.getType()) {
/* 326 */       props = new BeanProperties(type);
/* 327 */       this.cache.put(type.getName(), props);
/*     */     } 
/*     */     
/* 330 */     return props.get(ctx, prop);
/*     */   }
/*     */   
/*     */   private static final class ConcurrentCache<K, V>
/*     */   {
/*     */     private final int size;
/*     */     private final Map<K, V> eden;
/*     */     private final Map<K, V> longterm;
/*     */     
/*     */     ConcurrentCache(int size) {
/* 340 */       this.size = size;
/* 341 */       this.eden = new ConcurrentHashMap<>(size);
/* 342 */       this.longterm = new WeakHashMap<>(size);
/*     */     }
/*     */     
/*     */     public V get(K key) {
/* 346 */       V value = this.eden.get(key);
/* 347 */       if (value == null) {
/* 348 */         synchronized (this.longterm) {
/* 349 */           value = this.longterm.get(key);
/*     */         } 
/* 351 */         if (value != null) {
/* 352 */           this.eden.put(key, value);
/*     */         }
/*     */       } 
/* 355 */       return value;
/*     */     }
/*     */     
/*     */     public void put(K key, V value) {
/* 359 */       if (this.eden.size() >= this.size) {
/* 360 */         synchronized (this.longterm) {
/* 361 */           this.longterm.putAll(this.eden);
/*     */         } 
/* 363 */         this.eden.clear();
/*     */       } 
/* 365 */       this.eden.put(key, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\BeanELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */