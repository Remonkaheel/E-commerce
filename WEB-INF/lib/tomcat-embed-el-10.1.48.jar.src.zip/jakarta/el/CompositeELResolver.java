/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private static final Class<?> SCOPED_ATTRIBUTE_EL_RESOLVER;
/*  29 */   private static final Set<String> KNOWN_NON_TYPE_CONVERTING_RESOLVERS = new HashSet<>();
/*     */   static {
/*  31 */     Class<?> clazz = null;
/*     */     try {
/*  33 */       clazz = Class.forName("jakarta.servlet.jsp.el.ScopedAttributeELResolver");
/*  34 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*  37 */     SCOPED_ATTRIBUTE_EL_RESOLVER = clazz;
/*     */ 
/*     */     
/*  40 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(ArrayELResolver.class.getName());
/*  41 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(BeanELResolver.class.getName());
/*  42 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(BeanNameELResolver.class.getName());
/*  43 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(ListELResolver.class.getName());
/*  44 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(MapELResolver.class.getName());
/*  45 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(ResourceBundleELResolver.class.getName());
/*  46 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add(StaticFieldELResolver.class.getName());
/*     */     
/*  48 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add("jakarta.servlet.jsp.el.ImplicitObjectELResolver");
/*  49 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add("jakarta.servlet.jsp.el.ImportELResolver");
/*  50 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add("jakarta.servlet.jsp.el.NotFoundELResolver");
/*  51 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add("jakarta.servlet.jsp.el.ScopedAttributeELResolver");
/*     */     
/*  53 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add("org.apache.jasper.el.JasperELResolver$GraalBeanELResolver");
/*  54 */     KNOWN_NON_TYPE_CONVERTING_RESOLVERS.add("org.apache.el.stream.StreamELResolverImpl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private int resolversSize = 0;
/*  69 */   private ELResolver[] resolvers = new ELResolver[8];
/*     */   
/*  71 */   private int typeConvertersSize = 0;
/*  72 */   private ELResolver[] typeConverters = new ELResolver[0];
/*     */ 
/*     */   
/*     */   public void add(ELResolver elResolver) {
/*  76 */     Objects.requireNonNull(elResolver);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     if (this.resolversSize >= this.resolvers.length) {
/*  83 */       ELResolver[] nr = new ELResolver[this.resolversSize * 2];
/*  84 */       System.arraycopy(this.resolvers, 0, nr, 0, this.resolversSize);
/*  85 */       this.resolvers = nr;
/*     */     } 
/*  87 */     this.resolvers[this.resolversSize++] = elResolver;
/*     */     
/*  89 */     if (KNOWN_NON_TYPE_CONVERTING_RESOLVERS.contains(elResolver.getClass().getName())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  94 */     if (this.typeConvertersSize == 0) {
/*  95 */       this.typeConverters = new ELResolver[1];
/*  96 */     } else if (this.typeConvertersSize == this.typeConverters.length) {
/*  97 */       ELResolver[] expandedTypeConverters = new ELResolver[this.typeConvertersSize * 2];
/*  98 */       System.arraycopy(this.typeConverters, 0, expandedTypeConverters, 0, this.typeConvertersSize);
/*  99 */       this.typeConverters = expandedTypeConverters;
/*     */     } 
/* 101 */     this.typeConverters[this.typeConvertersSize++] = elResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/* 106 */     context.setPropertyResolved(false);
/* 107 */     int sz = this.resolversSize;
/* 108 */     for (int i = 0; i < sz; i++) {
/* 109 */       Object result = this.resolvers[i].getValue(context, base, property);
/* 110 */       if (context.isPropertyResolved()) {
/* 111 */         return result;
/*     */       }
/*     */     } 
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(ELContext context, Object base, Object method, Class<?>[] paramTypes, Object[] params) {
/* 119 */     context.setPropertyResolved(false);
/* 120 */     int sz = this.resolversSize;
/* 121 */     for (int i = 0; i < sz; i++) {
/* 122 */       Object obj = this.resolvers[i].invoke(context, base, method, paramTypes, params);
/* 123 */       if (context.isPropertyResolved()) {
/* 124 */         return obj;
/*     */       }
/*     */     } 
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/* 132 */     context.setPropertyResolved(false);
/* 133 */     int sz = this.resolversSize;
/* 134 */     for (int i = 0; i < sz; i++) {
/* 135 */       Class<?> type = this.resolvers[i].getType(context, base, property);
/* 136 */       if (context.isPropertyResolved()) {
/* 137 */         if (SCOPED_ATTRIBUTE_EL_RESOLVER != null && SCOPED_ATTRIBUTE_EL_RESOLVER
/* 138 */           .isAssignableFrom(this.resolvers[i].getClass())) {
/*     */ 
/*     */ 
/*     */           
/* 142 */           Object value = this.resolvers[i].getValue(context, base, property);
/* 143 */           if (value != null) {
/* 144 */             return value.getClass();
/*     */           }
/*     */         } 
/* 147 */         return type;
/*     */       } 
/*     */     } 
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/* 155 */     context.setPropertyResolved(false);
/* 156 */     int sz = this.resolversSize;
/* 157 */     for (int i = 0; i < sz; i++) {
/* 158 */       this.resolvers[i].setValue(context, base, property, value);
/* 159 */       if (context.isPropertyResolved()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 167 */     context.setPropertyResolved(false);
/* 168 */     int sz = this.resolversSize;
/* 169 */     for (int i = 0; i < sz; i++) {
/* 170 */       boolean readOnly = this.resolvers[i].isReadOnly(context, base, property);
/* 171 */       if (context.isPropertyResolved()) {
/* 172 */         return readOnly;
/*     */       }
/*     */     } 
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 181 */     return new FeatureIterator(context, base, this.resolvers, this.resolversSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 186 */     Class<?> commonType = null;
/* 187 */     int sz = this.resolversSize;
/* 188 */     for (int i = 0; i < sz; i++) {
/* 189 */       Class<?> type = this.resolvers[i].getCommonPropertyType(context, base);
/* 190 */       if (type != null && (commonType == null || commonType.isAssignableFrom(type))) {
/* 191 */         commonType = type;
/*     */       }
/*     */     } 
/* 194 */     return commonType;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T convertToType(ELContext context, Object obj, Class<T> type) {
/* 199 */     context.setPropertyResolved(false);
/* 200 */     int sz = this.typeConvertersSize;
/* 201 */     for (int i = 0; i < sz; i++) {
/* 202 */       T result = this.typeConverters[i].convertToType(context, obj, type);
/* 203 */       if (context.isPropertyResolved()) {
/* 204 */         return result;
/*     */       }
/*     */     } 
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   private static final class FeatureIterator
/*     */     implements Iterator<FeatureDescriptor>
/*     */   {
/*     */     private final ELContext context;
/*     */     
/*     */     private final Object base;
/*     */     
/*     */     private final ELResolver[] resolvers;
/*     */     
/*     */     private final int size;
/*     */     
/*     */     private Iterator<FeatureDescriptor> itr;
/*     */     private int idx;
/*     */     private FeatureDescriptor next;
/*     */     
/*     */     FeatureIterator(ELContext context, Object base, ELResolver[] resolvers, int size) {
/* 228 */       this.context = context;
/* 229 */       this.base = base;
/* 230 */       this.resolvers = resolvers;
/* 231 */       this.size = size;
/*     */       
/* 233 */       this.idx = 0;
/* 234 */       guaranteeIterator();
/*     */     }
/*     */     
/*     */     private void guaranteeIterator() {
/* 238 */       while (this.itr == null && this.idx < this.size) {
/* 239 */         this.itr = this.resolvers[this.idx].getFeatureDescriptors(this.context, this.base);
/* 240 */         this.idx++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 246 */       if (this.next != null) {
/* 247 */         return true;
/*     */       }
/* 249 */       if (this.itr != null) {
/* 250 */         while (this.next == null && this.itr.hasNext()) {
/* 251 */           this.next = this.itr.next();
/*     */         }
/*     */       } else {
/* 254 */         return false;
/*     */       } 
/* 256 */       if (this.next == null) {
/* 257 */         this.itr = null;
/* 258 */         guaranteeIterator();
/*     */       } 
/* 260 */       return hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public FeatureDescriptor next() {
/* 265 */       if (!hasNext()) {
/* 266 */         throw new NoSuchElementException();
/*     */       }
/* 268 */       FeatureDescriptor result = this.next;
/* 269 */       this.next = null;
/* 270 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 276 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\CompositeELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */