/*    */ package jakarta.el;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.WeakHashMap;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExpressionFactoryCache
/*    */ {
/* 28 */   private final AtomicReference<WeakHashMap<ClassLoader, WeakReference<ExpressionFactory>>> factoryCache = new AtomicReference<>(new WeakHashMap<>());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ExpressionFactory getOrCreateExpressionFactory(ClassLoader cl) {
/*    */     WeakHashMap<ClassLoader, WeakReference<ExpressionFactory>> cache, newCache;
/* 55 */     ExpressionFactory factory = null;
/*    */ 
/*    */     
/*    */     do {
/* 59 */       cache = this.factoryCache.get();
/*    */       
/* 61 */       WeakReference<ExpressionFactory> factoryRef = cache.get(cl);
/*    */       
/* 63 */       if (factoryRef != null) {
/* 64 */         factory = factoryRef.get();
/*    */         
/* 66 */         if (factory != null) {
/* 67 */           return factory;
/*    */         }
/*    */       } 
/*    */ 
/*    */       
/* 72 */       if (factory == null)
/*    */       {
/* 74 */         factory = ExpressionFactory.newInstance();
/*    */       }
/* 76 */       factoryRef = new WeakReference<>(factory);
/* 77 */       newCache = new WeakHashMap<>(cache);
/*    */       
/* 79 */       newCache.put(cl, factoryRef);
/* 80 */     } while (!this.factoryCache.compareAndSet(cache, newCache));
/*    */     
/* 82 */     return factory;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ExpressionFactoryCache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */