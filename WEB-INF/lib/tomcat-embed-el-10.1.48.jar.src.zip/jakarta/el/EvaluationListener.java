package jakarta.el;

public abstract class EvaluationListener {
  public void beforeEvaluation(ELContext context, String expression) {}
  
  public void afterEvaluation(ELContext context, String expression) {}
  
  public void propertyResolved(ELContext context, Object base, Object property) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\EvaluationListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */