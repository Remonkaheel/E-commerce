package jakarta.el;

public abstract class VariableMapper {
  public abstract ValueExpression resolveVariable(String paramString);
  
  public abstract ValueExpression setVariable(String paramString, ValueExpression paramValueExpression);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\VariableMapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */