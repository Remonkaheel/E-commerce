/*    */ package jakarta.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyNotFoundException
/*    */   extends ELException
/*    */ {
/*    */   private static final long serialVersionUID = -3799200961303506745L;
/*    */   
/*    */   public PropertyNotFoundException() {}
/*    */   
/*    */   public PropertyNotFoundException(String message) {
/* 28 */     super(message);
/*    */   }
/*    */   
/*    */   public PropertyNotFoundException(Throwable cause) {
/* 32 */     super(cause);
/*    */   }
/*    */   
/*    */   public PropertyNotFoundException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\PropertyNotFoundException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */