/*    */ package jakarta.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodNotFoundException
/*    */   extends ELException
/*    */ {
/*    */   private static final long serialVersionUID = -3631968116081480328L;
/*    */   
/*    */   public MethodNotFoundException() {}
/*    */   
/*    */   public MethodNotFoundException(String message) {
/* 28 */     super(message);
/*    */   }
/*    */   
/*    */   public MethodNotFoundException(Throwable cause) {
/* 32 */     super(cause);
/*    */   }
/*    */   
/*    */   public MethodNotFoundException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\MethodNotFoundException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */