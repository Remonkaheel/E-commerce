/*     */ package jakarta.el;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardELContext
/*     */   extends ELContext
/*     */ {
/*     */   private final ELContext wrappedContext;
/*     */   private final VariableMapper variableMapper;
/*     */   private final FunctionMapper functionMapper;
/*     */   private final CompositeELResolver standardResolver;
/*     */   private final CompositeELResolver customResolvers;
/*  33 */   private final Map<String, Object> localBeans = new HashMap<>();
/*     */ 
/*     */   
/*     */   public StandardELContext(ExpressionFactory factory) {
/*  37 */     this.wrappedContext = null;
/*  38 */     this.variableMapper = new StandardVariableMapper();
/*  39 */     this.functionMapper = new StandardFunctionMapper(factory.getInitFunctionMap());
/*  40 */     this.standardResolver = new CompositeELResolver();
/*  41 */     this.customResolvers = new CompositeELResolver();
/*     */     
/*  43 */     ELResolver streamResolver = factory.getStreamELResolver();
/*     */ 
/*     */     
/*  46 */     this.standardResolver.add(new BeanNameELResolver(new StandardBeanNameResolver(this.localBeans)));
/*  47 */     this.standardResolver.add(this.customResolvers);
/*  48 */     if (streamResolver != null) {
/*  49 */       this.standardResolver.add(streamResolver);
/*     */     }
/*  51 */     this.standardResolver.add(new StaticFieldELResolver());
/*  52 */     this.standardResolver.add(new MapELResolver());
/*  53 */     this.standardResolver.add(new ResourceBundleELResolver());
/*  54 */     this.standardResolver.add(new ListELResolver());
/*  55 */     this.standardResolver.add(new ArrayELResolver());
/*  56 */     this.standardResolver.add(new BeanELResolver());
/*     */   }
/*     */   
/*     */   public StandardELContext(ELContext context) {
/*  60 */     this.wrappedContext = context;
/*  61 */     this.variableMapper = context.getVariableMapper();
/*  62 */     this.functionMapper = context.getFunctionMapper();
/*  63 */     this.standardResolver = new CompositeELResolver();
/*  64 */     this.customResolvers = new CompositeELResolver();
/*     */ 
/*     */     
/*  67 */     this.standardResolver.add(new BeanNameELResolver(new StandardBeanNameResolver(this.localBeans)));
/*  68 */     this.standardResolver.add(this.customResolvers);
/*     */     
/*  70 */     this.standardResolver.add(context.getELResolver());
/*     */   }
/*     */ 
/*     */   
/*     */   public void putContext(Class<?> key, Object contextObject) {
/*  75 */     if (this.wrappedContext == null) {
/*  76 */       super.putContext(key, contextObject);
/*     */     } else {
/*  78 */       this.wrappedContext.putContext(key, contextObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContext(Class<?> key) {
/*  84 */     if (this.wrappedContext == null) {
/*  85 */       return super.getContext(key);
/*     */     }
/*  87 */     return this.wrappedContext.getContext(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ELResolver getELResolver() {
/*  93 */     return this.standardResolver;
/*     */   }
/*     */   
/*     */   public void addELResolver(ELResolver resolver) {
/*  97 */     this.customResolvers.add(resolver);
/*     */   }
/*     */ 
/*     */   
/*     */   public FunctionMapper getFunctionMapper() {
/* 102 */     return this.functionMapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public VariableMapper getVariableMapper() {
/* 107 */     return this.variableMapper;
/*     */   }
/*     */ 
/*     */   
/*     */   Map<String, Object> getLocalBeans() {
/* 112 */     return this.localBeans;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StandardVariableMapper
/*     */     extends VariableMapper
/*     */   {
/*     */     private Map<String, ValueExpression> vars;
/*     */     
/*     */     public ValueExpression resolveVariable(String variable) {
/* 122 */       if (this.vars == null) {
/* 123 */         return null;
/*     */       }
/* 125 */       return this.vars.get(variable);
/*     */     }
/*     */ 
/*     */     
/*     */     public ValueExpression setVariable(String variable, ValueExpression expression) {
/* 130 */       if (this.vars == null) {
/* 131 */         this.vars = new HashMap<>();
/*     */       }
/* 133 */       if (expression == null) {
/* 134 */         return this.vars.remove(variable);
/*     */       }
/* 136 */       return this.vars.put(variable, expression);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StandardBeanNameResolver
/*     */     extends BeanNameResolver
/*     */   {
/*     */     private final Map<String, Object> beans;
/*     */     
/*     */     StandardBeanNameResolver(Map<String, Object> beans) {
/* 147 */       this.beans = beans;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNameResolved(String beanName) {
/* 152 */       return this.beans.containsKey(beanName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getBean(String beanName) {
/* 157 */       return this.beans.get(beanName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setBeanValue(String beanName, Object value) throws PropertyNotWritableException {
/* 162 */       this.beans.put(beanName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReadOnly(String beanName) {
/* 167 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canCreateBean(String beanName) {
/* 172 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class StandardFunctionMapper
/*     */     extends FunctionMapper
/*     */   {
/* 179 */     private final Map<String, Method> methods = new HashMap<>();
/*     */     
/*     */     StandardFunctionMapper(Map<String, Method> initFunctionMap) {
/* 182 */       if (initFunctionMap != null) {
/* 183 */         this.methods.putAll(initFunctionMap);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Method resolveFunction(String prefix, String localName) {
/* 189 */       String key = prefix + ":" + prefix;
/* 190 */       return this.methods.get(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void mapFunction(String prefix, String localName, Method method) {
/* 195 */       String key = prefix + ":" + prefix;
/* 196 */       if (method == null) {
/* 197 */         this.methods.remove(key);
/*     */       } else {
/* 199 */         this.methods.put(key, method);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\StandardELContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */