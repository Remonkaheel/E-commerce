/*     */ package jakarta.el;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ELProcessor
/*     */ {
/*  29 */   private static final Set<String> PRIMITIVES = new HashSet<>();
/*     */   static {
/*  31 */     PRIMITIVES.add("boolean");
/*  32 */     PRIMITIVES.add("byte");
/*  33 */     PRIMITIVES.add("char");
/*  34 */     PRIMITIVES.add("double");
/*  35 */     PRIMITIVES.add("float");
/*  36 */     PRIMITIVES.add("int");
/*  37 */     PRIMITIVES.add("long");
/*  38 */     PRIMITIVES.add("short");
/*     */   }
/*     */   
/*  41 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  43 */   private final ELManager manager = new ELManager();
/*  44 */   private final ELContext context = this.manager.getELContext();
/*  45 */   private final ExpressionFactory factory = ELManager.getExpressionFactory();
/*     */ 
/*     */   
/*     */   public ELManager getELManager() {
/*  49 */     return this.manager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T eval(String expression) {
/*  55 */     T result = getValue(expression, (Class)Object.class);
/*  56 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getValue(String expression, Class<T> expectedType) {
/*  61 */     ValueExpression ve = this.factory.createValueExpression(this.context, bracket(expression), expectedType);
/*  62 */     return ve.getValue(this.context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(String expression, Object value) {
/*  67 */     ValueExpression ve = this.factory.createValueExpression(this.context, bracket(expression), Object.class);
/*  68 */     ve.setValue(this.context, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVariable(String variable, String expression) {
/*  73 */     if (expression == null) {
/*  74 */       this.manager.setVariable(variable, null);
/*     */     } else {
/*  76 */       ValueExpression ve = this.factory.createValueExpression(this.context, bracket(expression), Object.class);
/*  77 */       this.manager.setVariable(variable, ve);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineFunction(String prefix, String function, String className, String methodName) throws ClassNotFoundException, NoSuchMethodException {
/*  85 */     if (prefix == null || function == null || className == null || methodName == null) {
/*  86 */       throw new NullPointerException(Util.message(this.context, "elProcessor.defineFunctionNullParams", new Object[0]));
/*     */     }
/*     */ 
/*     */     
/*  90 */     Class<?> clazz = this.context.getImportHandler().resolveClass(className);
/*     */     
/*  92 */     if (clazz == null) {
/*  93 */       clazz = Class.forName(className, true, Util.getContextClassLoader());
/*     */     }
/*     */     
/*  96 */     if (!Modifier.isPublic(clazz.getModifiers())) {
/*  97 */       throw new ClassNotFoundException(
/*  98 */           Util.message(this.context, "elProcessor.defineFunctionInvalidClass", new Object[] { className }));
/*     */     }
/*     */     
/* 101 */     MethodSignature sig = new MethodSignature(this.context, methodName, className);
/*     */     
/* 103 */     if (function.length() == 0) {
/* 104 */       function = sig.getName();
/*     */     }
/*     */ 
/*     */     
/* 108 */     Method[] methods = clazz.getMethods();
/*     */     
/* 110 */     for (Method method : methods) {
/* 111 */       if (Modifier.isStatic(method.getModifiers()))
/*     */       {
/*     */         
/* 114 */         if (Util.canAccess(null, method))
/*     */         {
/*     */           
/* 117 */           if (method.getName().equals(sig.getName())) {
/* 118 */             if (sig.getParamTypeNames() == null) {
/*     */ 
/*     */               
/* 121 */               this.manager.mapFunction(prefix, function, method);
/*     */               return;
/*     */             } 
/* 124 */             if ((sig.getParamTypeNames()).length == (method.getParameterTypes()).length) {
/*     */ 
/*     */               
/* 127 */               if ((sig.getParamTypeNames()).length == 0) {
/* 128 */                 this.manager.mapFunction(prefix, function, method);
/*     */                 return;
/*     */               } 
/* 131 */               Class<?>[] types = method.getParameterTypes();
/* 132 */               String[] typeNames = sig.getParamTypeNames();
/* 133 */               if (types.length == typeNames.length) {
/* 134 */                 boolean match = true;
/* 135 */                 for (int i = 0; i < types.length; i++) {
/* 136 */                   if (i == types.length - 1 && method.isVarArgs()) {
/* 137 */                     String typeName = typeNames[i];
/* 138 */                     if (typeName.endsWith("...")) {
/* 139 */                       typeName = typeName.substring(0, typeName.length() - 3);
/* 140 */                       if (!typeName.equals(types[i].getName())) {
/* 141 */                         match = false;
/*     */                       }
/*     */                     } else {
/* 144 */                       match = false;
/*     */                     } 
/* 146 */                   } else if (!types[i].getName().equals(typeNames[i])) {
/* 147 */                     match = false;
/*     */                     break;
/*     */                   } 
/*     */                 } 
/* 151 */                 if (match) {
/* 152 */                   this.manager.mapFunction(prefix, function, method);
/*     */                   return;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }  } 
/*     */       }
/*     */     } 
/* 160 */     throw new NoSuchMethodException(
/* 161 */         Util.message(this.context, "elProcessor.defineFunctionNoMethod", new Object[] { methodName, className }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineFunction(String prefix, String function, Method method) throws NoSuchMethodException {
/* 177 */     if (prefix == null || function == null || method == null) {
/* 178 */       throw new NullPointerException(Util.message(this.context, "elProcessor.defineFunctionNullParams", new Object[0]));
/*     */     }
/*     */     
/* 181 */     int modifiers = method.getModifiers();
/*     */ 
/*     */     
/* 184 */     if (!Modifier.isStatic(modifiers) || !Util.canAccess(null, method)) {
/* 185 */       throw new NoSuchMethodException(Util.message(this.context, "elProcessor.defineFunctionInvalidMethod", new Object[] { method
/* 186 */               .getName(), method.getDeclaringClass().getName() }));
/*     */     }
/*     */     
/* 189 */     this.manager.mapFunction(prefix, function, method);
/*     */   }
/*     */ 
/*     */   
/*     */   public void defineBean(String name, Object bean) {
/* 194 */     this.manager.defineBean(name, bean);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String bracket(String expression) {
/* 199 */     return "${" + expression + "}";
/*     */   }
/*     */ 
/*     */   
/*     */   private static class MethodSignature
/*     */   {
/*     */     private final String name;
/*     */     private final String[] parameterTypeNames;
/*     */     
/*     */     MethodSignature(ELContext context, String methodName, String className) throws NoSuchMethodException {
/* 209 */       int paramIndex = methodName.indexOf('(');
/*     */       
/* 211 */       if (paramIndex == -1) {
/* 212 */         this.name = methodName.trim();
/* 213 */         this.parameterTypeNames = null;
/*     */       } else {
/* 215 */         String returnTypeAndName = methodName.substring(0, paramIndex).trim();
/*     */ 
/*     */ 
/*     */         
/* 219 */         int wsPos = -1;
/* 220 */         for (int i = 0; i < returnTypeAndName.length(); i++) {
/* 221 */           if (Character.isWhitespace(returnTypeAndName.charAt(i))) {
/* 222 */             wsPos = i;
/*     */             break;
/*     */           } 
/*     */         } 
/* 226 */         if (wsPos == -1) {
/* 227 */           throw new NoSuchMethodException();
/*     */         }
/* 229 */         this.name = returnTypeAndName.substring(wsPos).trim();
/*     */         
/* 231 */         String paramString = methodName.substring(paramIndex).trim();
/*     */         
/* 233 */         if (!paramString.endsWith(")")) {
/* 234 */           throw new NoSuchMethodException(Util.message(context, "elProcessor.defineFunctionInvalidParameterList", new Object[] { paramString, methodName, className }));
/*     */         }
/*     */ 
/*     */         
/* 238 */         paramString = paramString.substring(1, paramString.length() - 1).trim();
/* 239 */         if (paramString.length() == 0) {
/* 240 */           this.parameterTypeNames = ELProcessor.EMPTY_STRING_ARRAY;
/*     */         } else {
/* 242 */           this.parameterTypeNames = paramString.split(",");
/* 243 */           ImportHandler importHandler = context.getImportHandler();
/* 244 */           for (int j = 0; j < this.parameterTypeNames.length; j++) {
/* 245 */             String parameterTypeName = this.parameterTypeNames[j].trim();
/* 246 */             int dimension = 0;
/* 247 */             int bracketPos = parameterTypeName.indexOf('[');
/* 248 */             if (bracketPos > -1) {
/* 249 */               String parameterTypeNameOnly = parameterTypeName.substring(0, bracketPos).trim();
/* 250 */               while (bracketPos > -1) {
/* 251 */                 dimension++;
/* 252 */                 bracketPos = parameterTypeName.indexOf('[', bracketPos + 1);
/*     */               } 
/* 254 */               parameterTypeName = parameterTypeNameOnly;
/*     */             } 
/* 256 */             boolean varArgs = false;
/* 257 */             if (parameterTypeName.endsWith("...")) {
/* 258 */               varArgs = true;
/* 259 */               dimension = 1;
/* 260 */               parameterTypeName = parameterTypeName.substring(0, parameterTypeName.length() - 3).trim();
/*     */             } 
/* 262 */             boolean isPrimitive = ELProcessor.PRIMITIVES.contains(parameterTypeName);
/* 263 */             if (isPrimitive && dimension > 0) {
/*     */               
/* 265 */               switch (parameterTypeName) {
/*     */                 case "boolean":
/* 267 */                   parameterTypeName = "Z";
/*     */                   break;
/*     */                 case "byte":
/* 270 */                   parameterTypeName = "B";
/*     */                   break;
/*     */                 case "char":
/* 273 */                   parameterTypeName = "C";
/*     */                   break;
/*     */                 case "double":
/* 276 */                   parameterTypeName = "D";
/*     */                   break;
/*     */                 case "float":
/* 279 */                   parameterTypeName = "F";
/*     */                   break;
/*     */                 case "int":
/* 282 */                   parameterTypeName = "I";
/*     */                   break;
/*     */                 case "long":
/* 285 */                   parameterTypeName = "J";
/*     */                   break;
/*     */                 case "short":
/* 288 */                   parameterTypeName = "S";
/*     */                   break;
/*     */               } 
/*     */ 
/*     */ 
/*     */             
/* 294 */             } else if (!isPrimitive && !parameterTypeName.contains(".")) {
/* 295 */               Class<?> clazz = importHandler.resolveClass(parameterTypeName);
/* 296 */               if (clazz == null) {
/* 297 */                 throw new NoSuchMethodException(
/* 298 */                     Util.message(context, "elProcessor.defineFunctionInvalidParameterTypeName", new Object[] { this.parameterTypeNames[j], methodName, className }));
/*     */               }
/*     */               
/* 301 */               parameterTypeName = clazz.getName();
/*     */             } 
/* 303 */             if (dimension > 0) {
/*     */               
/* 305 */               StringBuilder sb = new StringBuilder();
/* 306 */               for (int k = 0; k < dimension; k++) {
/* 307 */                 sb.append('[');
/*     */               }
/* 309 */               if (!isPrimitive) {
/* 310 */                 sb.append('L');
/*     */               }
/* 312 */               sb.append(parameterTypeName);
/* 313 */               if (!isPrimitive) {
/* 314 */                 sb.append(';');
/*     */               }
/* 316 */               parameterTypeName = sb.toString();
/*     */             } 
/* 318 */             if (varArgs) {
/* 319 */               parameterTypeName = parameterTypeName + "...";
/*     */             }
/* 321 */             this.parameterTypeNames[j] = parameterTypeName;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 329 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] getParamTypeNames() {
/* 337 */       return this.parameterTypeNames;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ELProcessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */