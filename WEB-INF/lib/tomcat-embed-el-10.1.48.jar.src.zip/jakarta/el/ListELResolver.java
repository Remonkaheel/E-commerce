/*     */ package jakarta.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private final boolean readOnly;
/*  32 */   private static final Class<?> UNMODIFIABLE = Collections.unmodifiableList(new ArrayList()).getClass();
/*     */   
/*     */   public ListELResolver() {
/*  35 */     this.readOnly = false;
/*     */   }
/*     */   
/*     */   public ListELResolver(boolean readOnly) {
/*  39 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  44 */     Objects.requireNonNull(context);
/*     */     
/*  46 */     if (base instanceof List) {
/*  47 */       context.setPropertyResolved(base, property);
/*  48 */       List<?> list = (List)base;
/*  49 */       int idx = coerce(property);
/*  50 */       if (idx < 0 || idx >= list.size()) {
/*  51 */         throw new PropertyNotFoundException((new ArrayIndexOutOfBoundsException(idx)).getMessage());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  57 */       if (list.getClass() == UNMODIFIABLE || this.readOnly) {
/*  58 */         return null;
/*     */       }
/*     */       
/*  61 */       return Object.class;
/*     */     } 
/*     */     
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  69 */     Objects.requireNonNull(context);
/*     */     
/*  71 */     if (base instanceof List) {
/*  72 */       context.setPropertyResolved(base, property);
/*  73 */       List<?> list = (List)base;
/*  74 */       int idx = coerce(property);
/*  75 */       if (idx < 0 || idx >= list.size()) {
/*  76 */         return null;
/*     */       }
/*  78 */       return list.get(idx);
/*     */     } 
/*     */     
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/*  86 */     Objects.requireNonNull(context);
/*     */     
/*  88 */     if (base instanceof List) {
/*  89 */       context.setPropertyResolved(base, property);
/*     */       
/*  91 */       List<Object> list = (List<Object>)base;
/*     */       
/*  93 */       if (this.readOnly) {
/*  94 */         throw new PropertyNotWritableException(
/*  95 */             Util.message(context, "resolverNotWritable", new Object[] { base.getClass().getName() }));
/*     */       }
/*     */       
/*  98 */       int idx = coerce(property);
/*     */       try {
/* 100 */         list.set(idx, value);
/* 101 */       } catch (UnsupportedOperationException e) {
/* 102 */         throw new PropertyNotWritableException(e);
/* 103 */       } catch (IndexOutOfBoundsException e) {
/* 104 */         throw new PropertyNotFoundException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 111 */     Objects.requireNonNull(context);
/*     */     
/* 113 */     if (base instanceof List) {
/* 114 */       context.setPropertyResolved(base, property);
/* 115 */       List<?> list = (List)base;
/*     */       try {
/* 117 */         int idx = coerce(property);
/* 118 */         if (idx < 0 || idx >= list.size()) {
/* 119 */           throw new PropertyNotFoundException((new ArrayIndexOutOfBoundsException(idx)).getMessage());
/*     */         }
/* 121 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */       
/* 124 */       return (this.readOnly || UNMODIFIABLE.equals(list.getClass()));
/*     */     } 
/*     */     
/* 127 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "EL 5.0")
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 138 */     if (base instanceof List) {
/* 139 */       return Integer.class;
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */   
/*     */   private static int coerce(Object property) {
/* 145 */     if (property instanceof Number) {
/* 146 */       return ((Number)property).intValue();
/*     */     }
/* 148 */     if (property instanceof Character) {
/* 149 */       return ((Character)property).charValue();
/*     */     }
/* 151 */     if (property instanceof Boolean) {
/* 152 */       return ((Boolean)property).booleanValue() ? 1 : 0;
/*     */     }
/* 154 */     if (property instanceof String) {
/* 155 */       return Integer.parseInt((String)property);
/*     */     }
/* 157 */     throw new IllegalArgumentException((property != null) ? property.toString() : "null");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\jakarta\el\ListELResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */