open module org.apache.tomcat.embed.el {
  requires java.base;
  requires java.desktop;
  
  exports jakarta.el;
  exports org.apache.el;
  exports org.apache.el.lang;
  exports org.apache.el.parser;
  
  uses jakarta.el.ExpressionFactory;
  
  provides jakarta.el.ExpressionFactory with org.apache.el.ExpressionFactoryImpl;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */