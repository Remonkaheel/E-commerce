/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*     */ import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
/*     */ import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupConfigurer;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupViewResolver;
/*     */ import org.springframework.web.servlet.view.script.ScriptTemplateConfigurer;
/*     */ import org.springframework.web.servlet.view.script.ScriptTemplateViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewResolverRegistry
/*     */ {
/*     */   @Nullable
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */   @Nullable
/*     */   private final ApplicationContext applicationContext;
/*     */   @Nullable
/*     */   private ContentNegotiatingViewResolver contentNegotiatingResolver;
/*  64 */   private final List<ViewResolver> viewResolvers = new ArrayList<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Integer order;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ViewResolverRegistry(ContentNegotiationManager contentNegotiationManager, @Nullable ApplicationContext context) {
/*  77 */     this.contentNegotiationManager = contentNegotiationManager;
/*  78 */     this.applicationContext = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasRegistrations() {
/*  86 */     return (this.contentNegotiatingResolver != null || !this.viewResolvers.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableContentNegotiation(View... defaultViews) {
/*  98 */     initContentNegotiatingViewResolver(defaultViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableContentNegotiation(boolean useNotAcceptableStatus, View... defaultViews) {
/* 110 */     ContentNegotiatingViewResolver vr = initContentNegotiatingViewResolver(defaultViews);
/* 111 */     vr.setUseNotAcceptableStatusCode(useNotAcceptableStatus);
/*     */   }
/*     */ 
/*     */   
/*     */   private ContentNegotiatingViewResolver initContentNegotiatingViewResolver(View[] defaultViews) {
/* 116 */     this.order = Integer.valueOf((this.order != null) ? this.order.intValue() : Integer.MIN_VALUE);
/*     */     
/* 118 */     if (this.contentNegotiatingResolver != null) {
/* 119 */       if (!ObjectUtils.isEmpty((Object[])defaultViews) && 
/* 120 */         !CollectionUtils.isEmpty(this.contentNegotiatingResolver.getDefaultViews())) {
/* 121 */         List<View> views = new ArrayList<>(this.contentNegotiatingResolver.getDefaultViews());
/* 122 */         views.addAll(Arrays.asList(defaultViews));
/* 123 */         this.contentNegotiatingResolver.setDefaultViews(views);
/*     */       } 
/*     */     } else {
/*     */       
/* 127 */       this.contentNegotiatingResolver = new ContentNegotiatingViewResolver();
/* 128 */       this.contentNegotiatingResolver.setDefaultViews(Arrays.asList(defaultViews));
/* 129 */       this.contentNegotiatingResolver.setViewResolvers(this.viewResolvers);
/* 130 */       if (this.contentNegotiationManager != null) {
/* 131 */         this.contentNegotiatingResolver.setContentNegotiationManager(this.contentNegotiationManager);
/*     */       }
/*     */     } 
/* 134 */     return this.contentNegotiatingResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlBasedViewResolverRegistration jsp() {
/* 147 */     return jsp("/WEB-INF/", ".jsp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlBasedViewResolverRegistration jsp(String prefix, String suffix) {
/* 159 */     InternalResourceViewResolver resolver = new InternalResourceViewResolver();
/* 160 */     resolver.setPrefix(prefix);
/* 161 */     resolver.setSuffix(suffix);
/* 162 */     this.viewResolvers.add(resolver);
/* 163 */     return new UrlBasedViewResolverRegistration((UrlBasedViewResolver)resolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlBasedViewResolverRegistration freeMarker() {
/* 173 */     if (!checkBeanOfType(FreeMarkerConfigurer.class)) {
/* 174 */       throw new BeanInitializationException("In addition to a FreeMarker view resolver there must also be a single FreeMarkerConfig bean in this web application context (or its parent): FreeMarkerConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 179 */     FreeMarkerRegistration registration = new FreeMarkerRegistration();
/* 180 */     this.viewResolvers.add(registration.getViewResolver());
/* 181 */     return registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlBasedViewResolverRegistration groovy() {
/* 189 */     if (!checkBeanOfType(GroovyMarkupConfigurer.class)) {
/* 190 */       throw new BeanInitializationException("In addition to a Groovy markup view resolver there must also be a single GroovyMarkupConfig bean in this web application context (or its parent): GroovyMarkupConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 195 */     GroovyMarkupRegistration registration = new GroovyMarkupRegistration();
/* 196 */     this.viewResolvers.add(registration.getViewResolver());
/* 197 */     return registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlBasedViewResolverRegistration scriptTemplate() {
/* 205 */     if (!checkBeanOfType(ScriptTemplateConfigurer.class)) {
/* 206 */       throw new BeanInitializationException("In addition to a script template view resolver there must also be a single ScriptTemplateConfig bean in this web application context (or its parent): ScriptTemplateConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 211 */     ScriptRegistration registration = new ScriptRegistration();
/* 212 */     this.viewResolvers.add(registration.getViewResolver());
/* 213 */     return registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beanName() {
/* 221 */     BeanNameViewResolver resolver = new BeanNameViewResolver();
/* 222 */     this.viewResolvers.add(resolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void viewResolver(ViewResolver viewResolver) {
/* 232 */     if (viewResolver instanceof ContentNegotiatingViewResolver) {
/* 233 */       throw new BeanInitializationException("addViewResolver cannot be used to configure a ContentNegotiatingViewResolver. Please use the method enableContentNegotiation instead.");
/*     */     }
/*     */ 
/*     */     
/* 237 */     this.viewResolvers.add(viewResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void order(int order) {
/* 253 */     this.order = Integer.valueOf(order);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkBeanOfType(Class<?> beanType) {
/* 258 */     return (this.applicationContext == null || 
/* 259 */       !ObjectUtils.isEmpty((Object[])BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.applicationContext, beanType, false, false)));
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getOrder() {
/* 264 */     return (this.order != null) ? this.order.intValue() : Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   protected List<ViewResolver> getViewResolvers() {
/* 268 */     if (this.contentNegotiatingResolver != null) {
/* 269 */       return (List)Collections.singletonList(this.contentNegotiatingResolver);
/*     */     }
/*     */     
/* 272 */     return this.viewResolvers;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class FreeMarkerRegistration
/*     */     extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public FreeMarkerRegistration() {
/* 280 */       super((UrlBasedViewResolver)new FreeMarkerViewResolver());
/* 281 */       getViewResolver().setSuffix(".ftl");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class GroovyMarkupRegistration
/*     */     extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public GroovyMarkupRegistration() {
/* 289 */       super((UrlBasedViewResolver)new GroovyMarkupViewResolver());
/* 290 */       getViewResolver().setSuffix(".tpl");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ScriptRegistration
/*     */     extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public ScriptRegistration() {
/* 298 */       super((UrlBasedViewResolver)new ScriptTemplateViewResolver());
/* 299 */       getViewResolver();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\ViewResolverRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */