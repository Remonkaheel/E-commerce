/*      */ package org.springframework.web.servlet.config.annotation;
/*      */ 
/*      */ import jakarta.servlet.ServletContext;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanInitializationException;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.annotation.Qualifier;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.MessageSource;
/*      */ import org.springframework.context.annotation.Bean;
/*      */ import org.springframework.context.annotation.Lazy;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.format.FormatterRegistry;
/*      */ import org.springframework.format.support.DefaultFormattingConversionService;
/*      */ import org.springframework.format.support.FormattingConversionService;
/*      */ import org.springframework.http.MediaType;
/*      */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*      */ import org.springframework.http.converter.HttpMessageConverter;
/*      */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*      */ import org.springframework.http.converter.ResourceRegionHttpMessageConverter;
/*      */ import org.springframework.http.converter.StringHttpMessageConverter;
/*      */ import org.springframework.http.converter.cbor.KotlinSerializationCborHttpMessageConverter;
/*      */ import org.springframework.http.converter.cbor.MappingJackson2CborHttpMessageConverter;
/*      */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*      */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*      */ import org.springframework.http.converter.json.JsonbHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.KotlinSerializationJsonHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*      */ import org.springframework.http.converter.protobuf.KotlinSerializationProtobufHttpMessageConverter;
/*      */ import org.springframework.http.converter.smile.MappingJackson2SmileHttpMessageConverter;
/*      */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*      */ import org.springframework.http.converter.yaml.MappingJackson2YamlHttpMessageConverter;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.PathMatcher;
/*      */ import org.springframework.validation.Errors;
/*      */ import org.springframework.validation.MessageCodesResolver;
/*      */ import org.springframework.validation.Validator;
/*      */ import org.springframework.validation.beanvalidation.OptionalValidatorFactoryBean;
/*      */ import org.springframework.web.ErrorResponse;
/*      */ import org.springframework.web.accept.ContentNegotiationManager;
/*      */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*      */ import org.springframework.web.bind.support.WebBindingInitializer;
/*      */ import org.springframework.web.context.ServletContextAware;
/*      */ import org.springframework.web.cors.CorsConfiguration;
/*      */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*      */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*      */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*      */ import org.springframework.web.servlet.FlashMapManager;
/*      */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*      */ import org.springframework.web.servlet.HandlerInterceptor;
/*      */ import org.springframework.web.servlet.HandlerMapping;
/*      */ import org.springframework.web.servlet.LocaleResolver;
/*      */ import org.springframework.web.servlet.RequestToViewNameTranslator;
/*      */ import org.springframework.web.servlet.ThemeResolver;
/*      */ import org.springframework.web.servlet.ViewResolver;
/*      */ import org.springframework.web.servlet.function.support.HandlerFunctionAdapter;
/*      */ import org.springframework.web.servlet.function.support.RouterFunctionMapping;
/*      */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*      */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*      */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*      */ import org.springframework.web.servlet.handler.HandlerExceptionResolverComposite;
/*      */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*      */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*      */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*      */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*      */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*      */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*      */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*      */ import org.springframework.web.servlet.resource.ResourceUrlProvider;
/*      */ import org.springframework.web.servlet.resource.ResourceUrlProviderExposingInterceptor;
/*      */ import org.springframework.web.servlet.support.SessionFlashMapManager;
/*      */ import org.springframework.web.servlet.theme.FixedThemeResolver;
/*      */ import org.springframework.web.servlet.view.DefaultRequestToViewNameTranslator;
/*      */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*      */ import org.springframework.web.servlet.view.ViewResolverComposite;
/*      */ import org.springframework.web.util.UrlPathHelper;
/*      */ import org.springframework.web.util.pattern.PathPatternParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebMvcConfigurationSupport
/*      */   implements ApplicationContextAware, ServletContextAware
/*      */ {
/*      */   private static final boolean romePresent;
/*      */   private static final boolean jaxb2Present;
/*      */   private static final boolean jackson2Present;
/*      */   private static final boolean jackson2XmlPresent;
/*      */   private static final boolean jackson2SmilePresent;
/*      */   private static final boolean jackson2CborPresent;
/*      */   private static final boolean jackson2YamlPresent;
/*      */   private static final boolean gsonPresent;
/*      */   private static final boolean jsonbPresent;
/*      */   private static final boolean kotlinSerializationCborPresent;
/*      */   private static final boolean kotlinSerializationJsonPresent;
/*      */   private static final boolean kotlinSerializationProtobufPresent;
/*      */   @Nullable
/*      */   private ApplicationContext applicationContext;
/*      */   @Nullable
/*      */   private ServletContext servletContext;
/*      */   @Nullable
/*      */   private List<Object> interceptors;
/*      */   @Nullable
/*      */   private PathMatchConfigurer pathMatchConfigurer;
/*      */   @Nullable
/*      */   private ContentNegotiationManager contentNegotiationManager;
/*      */   @Nullable
/*      */   private List<HandlerMethodArgumentResolver> argumentResolvers;
/*      */   @Nullable
/*      */   private List<HandlerMethodReturnValueHandler> returnValueHandlers;
/*      */   @Nullable
/*      */   private List<HttpMessageConverter<?>> messageConverters;
/*      */   @Nullable
/*      */   private List<ErrorResponse.Interceptor> errorResponseInterceptors;
/*      */   @Nullable
/*      */   private Map<String, CorsConfiguration> corsConfigurations;
/*      */   @Nullable
/*      */   private AsyncSupportConfigurer asyncSupportConfigurer;
/*      */   
/*      */   static {
/*  219 */     ClassLoader classLoader = WebMvcConfigurationSupport.class.getClassLoader();
/*  220 */     romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", classLoader);
/*  221 */     jaxb2Present = ClassUtils.isPresent("jakarta.xml.bind.Binder", classLoader);
/*      */     
/*  223 */     jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", classLoader) && ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", classLoader));
/*  224 */     jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", classLoader);
/*  225 */     jackson2SmilePresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.smile.SmileFactory", classLoader);
/*  226 */     jackson2CborPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.cbor.CBORFactory", classLoader);
/*  227 */     jackson2YamlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.yaml.YAMLFactory", classLoader);
/*  228 */     gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", classLoader);
/*  229 */     jsonbPresent = ClassUtils.isPresent("jakarta.json.bind.Jsonb", classLoader);
/*  230 */     kotlinSerializationCborPresent = ClassUtils.isPresent("kotlinx.serialization.cbor.Cbor", classLoader);
/*  231 */     kotlinSerializationJsonPresent = ClassUtils.isPresent("kotlinx.serialization.json.Json", classLoader);
/*  232 */     kotlinSerializationProtobufPresent = ClassUtils.isPresent("kotlinx.serialization.protobuf.ProtoBuf", classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationContext(@Nullable ApplicationContext applicationContext) {
/*  275 */     this.applicationContext = applicationContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public final ApplicationContext getApplicationContext() {
/*  284 */     return this.applicationContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServletContext(@Nullable ServletContext servletContext) {
/*  293 */     this.servletContext = servletContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public final ServletContext getServletContext() {
/*  302 */     return this.servletContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public RequestMappingHandlerMapping requestMappingHandlerMapping(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider) {
/*  317 */     RequestMappingHandlerMapping mapping = createRequestMappingHandlerMapping();
/*  318 */     mapping.setOrder(0);
/*  319 */     mapping.setContentNegotiationManager(contentNegotiationManager);
/*      */     
/*  321 */     initHandlerMapping((AbstractHandlerMapping)mapping, conversionService, resourceUrlProvider);
/*      */     
/*  323 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*  324 */     if (pathConfig.preferPathMatcher()) {
/*  325 */       Boolean useSuffixPatternMatch = pathConfig.isUseSuffixPatternMatch();
/*  326 */       if (useSuffixPatternMatch != null) {
/*  327 */         mapping.setUseSuffixPatternMatch(useSuffixPatternMatch.booleanValue());
/*      */       }
/*  329 */       Boolean useRegisteredSuffixPatternMatch = pathConfig.isUseRegisteredSuffixPatternMatch();
/*  330 */       if (useRegisteredSuffixPatternMatch != null) {
/*  331 */         mapping.setUseRegisteredSuffixPatternMatch(useRegisteredSuffixPatternMatch.booleanValue());
/*      */       }
/*      */     } 
/*      */     
/*  335 */     Boolean useTrailingSlashMatch = pathConfig.isUseTrailingSlashMatch();
/*  336 */     if (useTrailingSlashMatch != null) {
/*  337 */       mapping.setUseTrailingSlashMatch(useTrailingSlashMatch.booleanValue());
/*      */     }
/*      */     
/*  340 */     if (pathConfig.getPathPrefixes() != null) {
/*  341 */       mapping.setPathPrefixes(pathConfig.getPathPrefixes());
/*      */     }
/*      */     
/*  344 */     return mapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RequestMappingHandlerMapping createRequestMappingHandlerMapping() {
/*  353 */     return new RequestMappingHandlerMapping();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object[] getInterceptors(FormattingConversionService mvcConversionService, ResourceUrlProvider mvcResourceUrlProvider) {
/*  365 */     if (this.interceptors == null) {
/*  366 */       InterceptorRegistry registry = new InterceptorRegistry();
/*  367 */       addInterceptors(registry);
/*  368 */       registry.addInterceptor((HandlerInterceptor)new ConversionServiceExposingInterceptor((ConversionService)mvcConversionService));
/*  369 */       registry.addInterceptor((HandlerInterceptor)new ResourceUrlProviderExposingInterceptor(mvcResourceUrlProvider));
/*  370 */       this.interceptors = registry.getInterceptors();
/*      */     } 
/*  372 */     return this.interceptors.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addInterceptors(InterceptorRegistry registry) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PathMatchConfigurer getPathMatchConfigurer() {
/*  389 */     if (this.pathMatchConfigurer == null) {
/*  390 */       this.pathMatchConfigurer = new PathMatchConfigurer();
/*  391 */       configurePathMatch(this.pathMatchConfigurer);
/*      */     } 
/*  393 */     return this.pathMatchConfigurer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configurePathMatch(PathMatchConfigurer configurer) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public PathPatternParser mvcPatternParser() {
/*  413 */     return getPathMatchConfigurer().getPatternParserOrDefault();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public UrlPathHelper mvcUrlPathHelper() {
/*  426 */     return getPathMatchConfigurer().getUrlPathHelperOrDefault();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public PathMatcher mvcPathMatcher() {
/*  439 */     return getPathMatchConfigurer().getPathMatcherOrDefault();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public ContentNegotiationManager mvcContentNegotiationManager() {
/*  448 */     if (this.contentNegotiationManager == null) {
/*  449 */       ContentNegotiationConfigurer configurer = new ContentNegotiationConfigurer(this.servletContext);
/*  450 */       configurer.mediaTypes(getDefaultMediaTypes());
/*  451 */       configureContentNegotiation(configurer);
/*  452 */       this.contentNegotiationManager = configurer.buildContentNegotiationManager();
/*      */     } 
/*  454 */     return this.contentNegotiationManager;
/*      */   }
/*      */   
/*      */   protected Map<String, MediaType> getDefaultMediaTypes() {
/*  458 */     Map<String, MediaType> map = new HashMap<>(4);
/*  459 */     if (romePresent) {
/*  460 */       map.put("atom", MediaType.APPLICATION_ATOM_XML);
/*  461 */       map.put("rss", MediaType.APPLICATION_RSS_XML);
/*      */     } 
/*  463 */     if (jaxb2Present || jackson2XmlPresent) {
/*  464 */       map.put("xml", MediaType.APPLICATION_XML);
/*      */     }
/*  466 */     if (jackson2Present || gsonPresent || jsonbPresent || kotlinSerializationJsonPresent) {
/*  467 */       map.put("json", MediaType.APPLICATION_JSON);
/*      */     }
/*  469 */     if (jackson2SmilePresent) {
/*  470 */       map.put("smile", MediaType.valueOf("application/x-jackson-smile"));
/*      */     }
/*  472 */     if (jackson2CborPresent || kotlinSerializationCborPresent) {
/*  473 */       map.put("cbor", MediaType.APPLICATION_CBOR);
/*      */     }
/*  475 */     if (jackson2YamlPresent) {
/*  476 */       map.put("yaml", MediaType.APPLICATION_YAML);
/*      */     }
/*  478 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   @Nullable
/*      */   public HandlerMapping viewControllerHandlerMapping(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider) {
/*  499 */     ViewControllerRegistry registry = new ViewControllerRegistry(this.applicationContext);
/*  500 */     addViewControllers(registry);
/*      */     
/*  502 */     SimpleUrlHandlerMapping simpleUrlHandlerMapping = registry.buildHandlerMapping();
/*  503 */     initHandlerMapping((AbstractHandlerMapping)simpleUrlHandlerMapping, conversionService, resourceUrlProvider);
/*  504 */     return (HandlerMapping)simpleUrlHandlerMapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initHandlerMapping(@Nullable AbstractHandlerMapping mapping, FormattingConversionService conversionService, ResourceUrlProvider resourceUrlProvider) {
/*  511 */     if (mapping == null) {
/*      */       return;
/*      */     }
/*  514 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*  515 */     if (pathConfig.preferPathMatcher()) {
/*  516 */       mapping.setPatternParser(null);
/*  517 */       mapping.setUrlPathHelper(pathConfig.getUrlPathHelperOrDefault());
/*  518 */       mapping.setPathMatcher(pathConfig.getPathMatcherOrDefault());
/*      */     }
/*  520 */     else if (pathConfig.getPatternParser() != null) {
/*  521 */       mapping.setPatternParser(pathConfig.getPatternParser());
/*      */     } 
/*  523 */     mapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  524 */     mapping.setCorsConfigurations(getCorsConfigurations());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addViewControllers(ViewControllerRegistry registry) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public BeanNameUrlHandlerMapping beanNameHandlerMapping(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider) {
/*  543 */     BeanNameUrlHandlerMapping mapping = new BeanNameUrlHandlerMapping();
/*  544 */     mapping.setOrder(2);
/*  545 */     initHandlerMapping((AbstractHandlerMapping)mapping, conversionService, resourceUrlProvider);
/*  546 */     return mapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public RouterFunctionMapping routerFunctionMapping(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider) {
/*  566 */     RouterFunctionMapping mapping = new RouterFunctionMapping();
/*  567 */     mapping.setOrder(-1);
/*  568 */     mapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  569 */     mapping.setCorsConfigurations(getCorsConfigurations());
/*  570 */     mapping.setMessageConverters(getMessageConverters());
/*      */     
/*  572 */     PathPatternParser patternParser = getPathMatchConfigurer().getPatternParser();
/*  573 */     if (patternParser != null) {
/*  574 */       mapping.setPatternParser(patternParser);
/*      */     }
/*      */     
/*  577 */     return mapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   @Nullable
/*      */   public HandlerMapping resourceHandlerMapping(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider) {
/*  592 */     Assert.state((this.applicationContext != null), "No ApplicationContext set");
/*  593 */     Assert.state((this.servletContext != null), "No ServletContext set");
/*      */     
/*  595 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*      */ 
/*      */     
/*  598 */     ResourceHandlerRegistry registry = new ResourceHandlerRegistry(this.applicationContext, this.servletContext, contentNegotiationManager, pathConfig.getUrlPathHelper());
/*  599 */     addResourceHandlers(registry);
/*      */     
/*  601 */     AbstractHandlerMapping mapping = registry.getHandlerMapping();
/*  602 */     initHandlerMapping(mapping, conversionService, resourceUrlProvider);
/*  603 */     return (HandlerMapping)mapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addResourceHandlers(ResourceHandlerRegistry registry) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public ResourceUrlProvider mvcResourceUrlProvider() {
/*  619 */     ResourceUrlProvider urlProvider = new ResourceUrlProvider();
/*  620 */     urlProvider.setUrlPathHelper(getPathMatchConfigurer().getUrlPathHelperOrDefault());
/*  621 */     urlProvider.setPathMatcher(getPathMatchConfigurer().getPathMatcherOrDefault());
/*  622 */     return urlProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   @Nullable
/*      */   public HandlerMapping defaultServletHandlerMapping() {
/*  633 */     Assert.state((this.servletContext != null), "No ServletContext set");
/*  634 */     DefaultServletHandlerConfigurer configurer = new DefaultServletHandlerConfigurer(this.servletContext);
/*  635 */     configureDefaultServletHandling(configurer);
/*  636 */     return (HandlerMapping)configurer.buildHandlerMapping();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public RequestMappingHandlerAdapter requestMappingHandlerAdapter(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcValidator") Validator validator) {
/*  662 */     RequestMappingHandlerAdapter adapter = createRequestMappingHandlerAdapter();
/*  663 */     adapter.setContentNegotiationManager(contentNegotiationManager);
/*  664 */     adapter.setMessageConverters(getMessageConverters());
/*  665 */     adapter.setWebBindingInitializer((WebBindingInitializer)getConfigurableWebBindingInitializer(conversionService, validator));
/*  666 */     adapter.setCustomArgumentResolvers(getArgumentResolvers());
/*  667 */     adapter.setCustomReturnValueHandlers(getReturnValueHandlers());
/*  668 */     adapter.setErrorResponseInterceptors(getErrorResponseInterceptors());
/*      */     
/*  670 */     if (jackson2Present) {
/*  671 */       adapter.setRequestBodyAdvice(Collections.singletonList(new JsonViewRequestBodyAdvice()));
/*  672 */       adapter.setResponseBodyAdvice(Collections.singletonList(new JsonViewResponseBodyAdvice()));
/*      */     } 
/*      */     
/*  675 */     AsyncSupportConfigurer configurer = getAsyncSupportConfigurer();
/*  676 */     if (configurer.getTaskExecutor() != null) {
/*  677 */       adapter.setTaskExecutor(configurer.getTaskExecutor());
/*      */     }
/*  679 */     if (configurer.getTimeout() != null) {
/*  680 */       adapter.setAsyncRequestTimeout(configurer.getTimeout().longValue());
/*      */     }
/*  682 */     adapter.setCallableInterceptors(configurer.getCallableInterceptors());
/*  683 */     adapter.setDeferredResultInterceptors(configurer.getDeferredResultInterceptors());
/*      */     
/*  685 */     return adapter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RequestMappingHandlerAdapter createRequestMappingHandlerAdapter() {
/*  694 */     return new RequestMappingHandlerAdapter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public HandlerFunctionAdapter handlerFunctionAdapter() {
/*  704 */     HandlerFunctionAdapter adapter = new HandlerFunctionAdapter();
/*      */     
/*  706 */     AsyncSupportConfigurer configurer = getAsyncSupportConfigurer();
/*  707 */     if (configurer.getTimeout() != null) {
/*  708 */       adapter.setAsyncRequestTimeout(configurer.getTimeout().longValue());
/*      */     }
/*  710 */     return adapter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ConfigurableWebBindingInitializer getConfigurableWebBindingInitializer(FormattingConversionService mvcConversionService, Validator mvcValidator) {
/*  720 */     ConfigurableWebBindingInitializer initializer = new ConfigurableWebBindingInitializer();
/*  721 */     initializer.setConversionService((ConversionService)mvcConversionService);
/*  722 */     initializer.setValidator(mvcValidator);
/*  723 */     MessageCodesResolver messageCodesResolver = getMessageCodesResolver();
/*  724 */     if (messageCodesResolver != null) {
/*  725 */       initializer.setMessageCodesResolver(messageCodesResolver);
/*      */     }
/*  727 */     return initializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected MessageCodesResolver getMessageCodesResolver() {
/*  735 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public FormattingConversionService mvcConversionService() {
/*  744 */     DefaultFormattingConversionService defaultFormattingConversionService = new DefaultFormattingConversionService();
/*  745 */     addFormatters((FormatterRegistry)defaultFormattingConversionService);
/*  746 */     return (FormattingConversionService)defaultFormattingConversionService;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addFormatters(FormatterRegistry registry) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public Validator mvcValidator() {
/*  767 */     Validator validator = getValidator();
/*  768 */     if (validator == null) {
/*  769 */       if (ClassUtils.isPresent("jakarta.validation.Validator", getClass().getClassLoader())) {
/*      */         try {
/*  771 */           OptionalValidatorFactoryBean optionalValidatorFactoryBean = new OptionalValidatorFactoryBean();
/*      */         }
/*  773 */         catch (Throwable ex) {
/*  774 */           throw new BeanInitializationException("Failed to create default validator", ex);
/*      */         } 
/*      */       } else {
/*      */         
/*  778 */         validator = new NoOpValidator();
/*      */       } 
/*      */     }
/*  781 */     return validator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Validator getValidator() {
/*  789 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final List<HandlerMethodArgumentResolver> getArgumentResolvers() {
/*  799 */     if (this.argumentResolvers == null) {
/*  800 */       this.argumentResolvers = new ArrayList<>();
/*  801 */       addArgumentResolvers(this.argumentResolvers);
/*      */     } 
/*  803 */     return this.argumentResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final List<HandlerMethodReturnValueHandler> getReturnValueHandlers() {
/*  825 */     if (this.returnValueHandlers == null) {
/*  826 */       this.returnValueHandlers = new ArrayList<>();
/*  827 */       addReturnValueHandlers(this.returnValueHandlers);
/*      */     } 
/*  829 */     return this.returnValueHandlers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final List<HttpMessageConverter<?>> getMessageConverters() {
/*  852 */     if (this.messageConverters == null) {
/*  853 */       this.messageConverters = new ArrayList<>();
/*  854 */       configureMessageConverters(this.messageConverters);
/*  855 */       if (this.messageConverters.isEmpty()) {
/*  856 */         addDefaultHttpMessageConverters(this.messageConverters);
/*      */       }
/*  858 */       extendMessageConverters(this.messageConverters);
/*      */     } 
/*  860 */     return this.messageConverters;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void extendMessageConverters(List<HttpMessageConverter<?>> converters) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void addDefaultHttpMessageConverters(List<HttpMessageConverter<?>> messageConverters) {
/*  891 */     messageConverters.add(new ByteArrayHttpMessageConverter());
/*  892 */     messageConverters.add(new StringHttpMessageConverter());
/*  893 */     messageConverters.add(new ResourceHttpMessageConverter());
/*  894 */     messageConverters.add(new ResourceRegionHttpMessageConverter());
/*  895 */     messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*      */     
/*  897 */     if (romePresent) {
/*  898 */       messageConverters.add(new AtomFeedHttpMessageConverter());
/*  899 */       messageConverters.add(new RssChannelHttpMessageConverter());
/*      */     } 
/*      */     
/*  902 */     if (jackson2XmlPresent) {
/*  903 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.xml();
/*  904 */       if (this.applicationContext != null) {
/*  905 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  907 */       messageConverters.add(new MappingJackson2XmlHttpMessageConverter(builder.build()));
/*      */     }
/*  909 */     else if (jaxb2Present) {
/*  910 */       messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*      */     } 
/*      */     
/*  913 */     if (kotlinSerializationCborPresent) {
/*  914 */       messageConverters.add(new KotlinSerializationCborHttpMessageConverter());
/*      */     }
/*  916 */     if (kotlinSerializationJsonPresent) {
/*  917 */       messageConverters.add(new KotlinSerializationJsonHttpMessageConverter());
/*      */     }
/*  919 */     if (kotlinSerializationProtobufPresent) {
/*  920 */       messageConverters.add(new KotlinSerializationProtobufHttpMessageConverter());
/*      */     }
/*      */     
/*  923 */     if (jackson2Present) {
/*  924 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.json();
/*  925 */       if (this.applicationContext != null) {
/*  926 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  928 */       messageConverters.add(new MappingJackson2HttpMessageConverter(builder.build()));
/*      */     }
/*  930 */     else if (gsonPresent) {
/*  931 */       messageConverters.add(new GsonHttpMessageConverter());
/*      */     }
/*  933 */     else if (jsonbPresent) {
/*  934 */       messageConverters.add(new JsonbHttpMessageConverter());
/*      */     } 
/*      */     
/*  937 */     if (jackson2SmilePresent) {
/*  938 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.smile();
/*  939 */       if (this.applicationContext != null) {
/*  940 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  942 */       messageConverters.add(new MappingJackson2SmileHttpMessageConverter(builder.build()));
/*      */     } 
/*  944 */     if (jackson2CborPresent) {
/*  945 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.cbor();
/*  946 */       if (this.applicationContext != null) {
/*  947 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  949 */       messageConverters.add(new MappingJackson2CborHttpMessageConverter(builder.build()));
/*      */     } 
/*  951 */     if (jackson2YamlPresent) {
/*  952 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.yaml();
/*  953 */       if (this.applicationContext != null) {
/*  954 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  956 */       messageConverters.add(new MappingJackson2YamlHttpMessageConverter(builder.build()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AsyncSupportConfigurer getAsyncSupportConfigurer() {
/*  966 */     if (this.asyncSupportConfigurer == null) {
/*  967 */       this.asyncSupportConfigurer = new AsyncSupportConfigurer();
/*  968 */       configureAsyncSupport(this.asyncSupportConfigurer);
/*      */     } 
/*  970 */     return this.asyncSupportConfigurer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureAsyncSupport(AsyncSupportConfigurer configurer) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public CompositeUriComponentsContributor mvcUriComponentsContributor(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("requestMappingHandlerAdapter") RequestMappingHandlerAdapter requestMappingHandlerAdapter) {
/*  989 */     return new CompositeUriComponentsContributor(requestMappingHandlerAdapter
/*  990 */         .getArgumentResolvers(), (ConversionService)conversionService);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public HttpRequestHandlerAdapter httpRequestHandlerAdapter() {
/*  999 */     return new HttpRequestHandlerAdapter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public SimpleControllerHandlerAdapter simpleControllerHandlerAdapter() {
/* 1008 */     return new SimpleControllerHandlerAdapter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public HandlerExceptionResolver handlerExceptionResolver(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager) {
/* 1022 */     List<HandlerExceptionResolver> exceptionResolvers = new ArrayList<>();
/* 1023 */     configureHandlerExceptionResolvers(exceptionResolvers);
/* 1024 */     if (exceptionResolvers.isEmpty()) {
/* 1025 */       addDefaultHandlerExceptionResolvers(exceptionResolvers, contentNegotiationManager);
/*      */     }
/* 1027 */     extendHandlerExceptionResolvers(exceptionResolvers);
/* 1028 */     HandlerExceptionResolverComposite composite = new HandlerExceptionResolverComposite();
/* 1029 */     composite.setOrder(0);
/* 1030 */     composite.setExceptionResolvers(exceptionResolvers);
/* 1031 */     return (HandlerExceptionResolver)composite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void addDefaultHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers, ContentNegotiationManager mvcContentNegotiationManager) {
/* 1071 */     ExceptionHandlerExceptionResolver exceptionHandlerResolver = createExceptionHandlerExceptionResolver();
/* 1072 */     exceptionHandlerResolver.setContentNegotiationManager(mvcContentNegotiationManager);
/* 1073 */     exceptionHandlerResolver.setMessageConverters(getMessageConverters());
/* 1074 */     exceptionHandlerResolver.setCustomArgumentResolvers(getArgumentResolvers());
/* 1075 */     exceptionHandlerResolver.setCustomReturnValueHandlers(getReturnValueHandlers());
/* 1076 */     exceptionHandlerResolver.setErrorResponseInterceptors(getErrorResponseInterceptors());
/* 1077 */     if (jackson2Present) {
/* 1078 */       exceptionHandlerResolver.setResponseBodyAdvice(
/* 1079 */           Collections.singletonList(new JsonViewResponseBodyAdvice()));
/*      */     }
/* 1081 */     if (this.applicationContext != null) {
/* 1082 */       exceptionHandlerResolver.setApplicationContext(this.applicationContext);
/*      */     }
/* 1084 */     exceptionHandlerResolver.afterPropertiesSet();
/* 1085 */     exceptionResolvers.add(exceptionHandlerResolver);
/*      */     
/* 1087 */     ResponseStatusExceptionResolver responseStatusResolver = new ResponseStatusExceptionResolver();
/* 1088 */     responseStatusResolver.setMessageSource((MessageSource)this.applicationContext);
/* 1089 */     exceptionResolvers.add(responseStatusResolver);
/*      */     
/* 1091 */     exceptionResolvers.add(new DefaultHandlerExceptionResolver());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ExceptionHandlerExceptionResolver createExceptionHandlerExceptionResolver() {
/* 1100 */     return new ExceptionHandlerExceptionResolver();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final List<ErrorResponse.Interceptor> getErrorResponseInterceptors() {
/* 1110 */     if (this.errorResponseInterceptors == null) {
/* 1111 */       this.errorResponseInterceptors = new ArrayList<>();
/* 1112 */       configureErrorResponseInterceptors(this.errorResponseInterceptors);
/*      */     } 
/* 1114 */     return this.errorResponseInterceptors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureErrorResponseInterceptors(List<ErrorResponse.Interceptor> interceptors) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   public ViewResolver mvcViewResolver(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager) {
/* 1141 */     ViewResolverRegistry registry = new ViewResolverRegistry(contentNegotiationManager, this.applicationContext);
/*      */     
/* 1143 */     configureViewResolvers(registry);
/*      */     
/* 1145 */     if (registry.getViewResolvers().isEmpty() && this.applicationContext != null) {
/* 1146 */       String[] names = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.applicationContext, ViewResolver.class, true, false);
/*      */       
/* 1148 */       if (names.length == 1) {
/* 1149 */         registry.getViewResolvers().add(new InternalResourceViewResolver());
/*      */       }
/*      */     } 
/*      */     
/* 1153 */     ViewResolverComposite composite = new ViewResolverComposite();
/* 1154 */     composite.setOrder(registry.getOrder());
/* 1155 */     composite.setViewResolvers(registry.getViewResolvers());
/* 1156 */     if (this.applicationContext != null) {
/* 1157 */       composite.setApplicationContext(this.applicationContext);
/*      */     }
/* 1159 */     if (this.servletContext != null) {
/* 1160 */       composite.setServletContext(this.servletContext);
/*      */     }
/* 1162 */     return (ViewResolver)composite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configureViewResolvers(ViewResolverRegistry registry) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Map<String, CorsConfiguration> getCorsConfigurations() {
/* 1178 */     if (this.corsConfigurations == null) {
/* 1179 */       CorsRegistry registry = new CorsRegistry();
/* 1180 */       addCorsMappings(registry);
/* 1181 */       this.corsConfigurations = registry.getCorsConfigurations();
/*      */     } 
/* 1183 */     return this.corsConfigurations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addCorsMappings(CorsRegistry registry) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Bean
/*      */   @Lazy
/*      */   public HandlerMappingIntrospector mvcHandlerMappingIntrospector() {
/* 1197 */     return new HandlerMappingIntrospector();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public LocaleResolver localeResolver() {
/* 1202 */     return (LocaleResolver)new AcceptHeaderLocaleResolver();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   @Deprecated
/*      */   public ThemeResolver themeResolver() {
/* 1208 */     return (ThemeResolver)new FixedThemeResolver();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public FlashMapManager flashMapManager() {
/* 1213 */     return (FlashMapManager)new SessionFlashMapManager();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public RequestToViewNameTranslator viewNameTranslator() {
/* 1218 */     return (RequestToViewNameTranslator)new DefaultRequestToViewNameTranslator();
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class NoOpValidator
/*      */     implements Validator
/*      */   {
/*      */     public boolean supports(Class<?> clazz) {
/* 1226 */       return false;
/*      */     }
/*      */     
/*      */     public void validate(@Nullable Object target, Errors errors) {}
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\WebMvcConfigurationSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */