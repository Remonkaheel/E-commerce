/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ public class DelegatingWebMvcConfiguration
/*     */   extends WebMvcConfigurationSupport
/*     */ {
/*  46 */   private final WebMvcConfigurerComposite configurers = new WebMvcConfigurerComposite();
/*     */ 
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setConfigurers(List<WebMvcConfigurer> configurers) {
/*  51 */     if (!CollectionUtils.isEmpty(configurers)) {
/*  52 */       this.configurers.addWebMvcConfigurers(configurers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configurePathMatch(PathMatchConfigurer configurer) {
/*  59 */     this.configurers.configurePathMatch(configurer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
/*  64 */     this.configurers.configureContentNegotiation(configurer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureAsyncSupport(AsyncSupportConfigurer configurer) {
/*  69 */     this.configurers.configureAsyncSupport(configurer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
/*  74 */     this.configurers.configureDefaultServletHandling(configurer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addFormatters(FormatterRegistry registry) {
/*  79 */     this.configurers.addFormatters(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addInterceptors(InterceptorRegistry registry) {
/*  84 */     this.configurers.addInterceptors(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addResourceHandlers(ResourceHandlerRegistry registry) {
/*  89 */     this.configurers.addResourceHandlers(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addCorsMappings(CorsRegistry registry) {
/*  94 */     this.configurers.addCorsMappings(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addViewControllers(ViewControllerRegistry registry) {
/*  99 */     this.configurers.addViewControllers(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureViewResolvers(ViewResolverRegistry registry) {
/* 104 */     this.configurers.configureViewResolvers(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 109 */     this.configurers.addArgumentResolvers(argumentResolvers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {
/* 114 */     this.configurers.addReturnValueHandlers(returnValueHandlers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
/* 119 */     this.configurers.configureMessageConverters(converters);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
/* 124 */     this.configurers.extendMessageConverters(converters);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
/* 129 */     this.configurers.configureHandlerExceptionResolvers(exceptionResolvers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
/* 134 */     this.configurers.extendHandlerExceptionResolvers(exceptionResolvers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void configureErrorResponseInterceptors(List<ErrorResponse.Interceptor> interceptors) {
/* 139 */     this.configurers.addErrorResponseInterceptors(interceptors);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Validator getValidator() {
/* 145 */     return this.configurers.getValidator();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MessageCodesResolver getMessageCodesResolver() {
/* 151 */     return this.configurers.getMessageCodesResolver();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\DelegatingWebMvcConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */