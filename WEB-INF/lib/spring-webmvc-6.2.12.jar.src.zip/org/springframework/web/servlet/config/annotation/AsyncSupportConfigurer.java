/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.DeferredResultProcessingInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncSupportConfigurer
/*     */ {
/*     */   @Nullable
/*     */   private AsyncTaskExecutor taskExecutor;
/*     */   @Nullable
/*     */   private Long timeout;
/*  44 */   private final List<CallableProcessingInterceptor> callableInterceptors = new ArrayList<>();
/*     */   
/*  46 */   private final List<DeferredResultProcessingInterceptor> deferredResultInterceptors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncSupportConfigurer setTaskExecutor(AsyncTaskExecutor taskExecutor) {
/*  62 */     this.taskExecutor = taskExecutor;
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncSupportConfigurer setDefaultTimeout(long timeout) {
/*  76 */     this.timeout = Long.valueOf(timeout);
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncSupportConfigurer registerCallableInterceptors(CallableProcessingInterceptor... interceptors) {
/*  87 */     this.callableInterceptors.addAll(Arrays.asList(interceptors));
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncSupportConfigurer registerDeferredResultInterceptors(DeferredResultProcessingInterceptor... interceptors) {
/*  99 */     this.deferredResultInterceptors.addAll(Arrays.asList(interceptors));
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected AsyncTaskExecutor getTaskExecutor() {
/* 106 */     return this.taskExecutor;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Long getTimeout() {
/* 111 */     return this.timeout;
/*     */   }
/*     */   
/*     */   protected List<CallableProcessingInterceptor> getCallableInterceptors() {
/* 115 */     return this.callableInterceptors;
/*     */   }
/*     */   
/*     */   protected List<DeferredResultProcessingInterceptor> getDeferredResultInterceptors() {
/* 119 */     return this.deferredResultInterceptors;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\AsyncSupportConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */