/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ import org.springframework.web.servlet.view.ViewResolverComposite;
/*     */ import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupViewResolver;
/*     */ import org.springframework.web.servlet.view.script.ScriptTemplateViewResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewResolversBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   public static final String VIEW_RESOLVER_BEAN_NAME = "mvcViewResolver";
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext context) {
/*  74 */     Object source = context.extractSource(element);
/*  75 */     context.pushContainingComponent(new CompositeComponentDefinition(element.getTagName(), source));
/*     */     
/*  77 */     ManagedList<Object> resolvers = new ManagedList(4);
/*  78 */     resolvers.setSource(context.extractSource(element));
/*  79 */     String[] names = { "jsp", "tiles", "bean-name", "freemarker", "groovy", "script-template", "bean", "ref" };
/*     */ 
/*     */     
/*  82 */     for (Element resolverElement : DomUtils.getChildElementsByTagName(element, names)) {
/*  83 */       RootBeanDefinition resolverBeanDef; String name = resolverElement.getLocalName();
/*  84 */       if ("bean".equals(name) || "ref".equals(name)) {
/*  85 */         resolvers.add(context.getDelegate().parsePropertySubElement(resolverElement, null));
/*     */         
/*     */         continue;
/*     */       } 
/*  89 */       if ("jsp".equals(name)) {
/*  90 */         resolverBeanDef = new RootBeanDefinition(InternalResourceViewResolver.class);
/*  91 */         resolverBeanDef.getPropertyValues().add("prefix", "/WEB-INF/");
/*  92 */         resolverBeanDef.getPropertyValues().add("suffix", ".jsp");
/*  93 */         addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */       }
/*  95 */       else if ("freemarker".equals(name)) {
/*  96 */         resolverBeanDef = new RootBeanDefinition(FreeMarkerViewResolver.class);
/*  97 */         resolverBeanDef.getPropertyValues().add("suffix", ".ftl");
/*  98 */         addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */       }
/* 100 */       else if ("groovy".equals(name)) {
/* 101 */         resolverBeanDef = new RootBeanDefinition(GroovyMarkupViewResolver.class);
/* 102 */         resolverBeanDef.getPropertyValues().add("suffix", ".tpl");
/* 103 */         addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */       }
/* 105 */       else if ("script-template".equals(name)) {
/* 106 */         resolverBeanDef = new RootBeanDefinition(ScriptTemplateViewResolver.class);
/* 107 */         addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */       }
/* 109 */       else if ("bean-name".equals(name)) {
/* 110 */         resolverBeanDef = new RootBeanDefinition(BeanNameViewResolver.class);
/*     */       }
/*     */       else {
/*     */         
/* 114 */         throw new IllegalStateException("Unexpected element name: " + name);
/*     */       } 
/* 116 */       resolverBeanDef.setSource(source);
/* 117 */       resolverBeanDef.setRole(2);
/* 118 */       resolvers.add(resolverBeanDef);
/*     */     } 
/*     */     
/* 121 */     String beanName = "mvcViewResolver";
/* 122 */     RootBeanDefinition compositeResolverBeanDef = new RootBeanDefinition(ViewResolverComposite.class);
/* 123 */     compositeResolverBeanDef.setSource(source);
/* 124 */     compositeResolverBeanDef.setRole(2);
/*     */     
/* 126 */     names = new String[] { "content-negotiation" };
/* 127 */     List<Element> contentNegotiationElements = DomUtils.getChildElementsByTagName(element, names);
/* 128 */     if (contentNegotiationElements.isEmpty()) {
/* 129 */       compositeResolverBeanDef.getPropertyValues().add("viewResolvers", resolvers);
/*     */     }
/* 131 */     else if (contentNegotiationElements.size() == 1) {
/* 132 */       BeanDefinition beanDef = createContentNegotiatingViewResolver(contentNegotiationElements.get(0), context);
/* 133 */       beanDef.getPropertyValues().add("viewResolvers", resolvers);
/* 134 */       ManagedList<Object> list = new ManagedList(1);
/* 135 */       list.add(beanDef);
/* 136 */       compositeResolverBeanDef.getPropertyValues().add("order", Integer.valueOf(-2147483648));
/* 137 */       compositeResolverBeanDef.getPropertyValues().add("viewResolvers", list);
/*     */     } else {
/*     */       
/* 140 */       throw new IllegalArgumentException("Only one <content-negotiation> element is allowed.");
/*     */     } 
/*     */     
/* 143 */     if (element.hasAttribute("order")) {
/* 144 */       compositeResolverBeanDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */     }
/*     */     
/* 147 */     context.getReaderContext().getRegistry().registerBeanDefinition(beanName, (BeanDefinition)compositeResolverBeanDef);
/* 148 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)compositeResolverBeanDef, beanName));
/* 149 */     context.popAndRegisterContainingComponent();
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   private void addUrlBasedViewResolverProperties(Element element, RootBeanDefinition beanDefinition) {
/* 154 */     if (element.hasAttribute("prefix")) {
/* 155 */       beanDefinition.getPropertyValues().add("prefix", element.getAttribute("prefix"));
/*     */     }
/* 157 */     if (element.hasAttribute("suffix")) {
/* 158 */       beanDefinition.getPropertyValues().add("suffix", element.getAttribute("suffix"));
/*     */     }
/* 160 */     if (element.hasAttribute("cache-views")) {
/* 161 */       beanDefinition.getPropertyValues().add("cache", element.getAttribute("cache-views"));
/*     */     }
/* 163 */     if (element.hasAttribute("view-class")) {
/* 164 */       beanDefinition.getPropertyValues().add("viewClass", element.getAttribute("view-class"));
/*     */     }
/* 166 */     if (element.hasAttribute("view-names")) {
/* 167 */       beanDefinition.getPropertyValues().add("viewNames", element.getAttribute("view-names"));
/*     */     }
/*     */   }
/*     */   
/*     */   private BeanDefinition createContentNegotiatingViewResolver(Element resolverElement, ParserContext context) {
/* 172 */     RootBeanDefinition beanDef = new RootBeanDefinition(ContentNegotiatingViewResolver.class);
/* 173 */     beanDef.setSource(context.extractSource(resolverElement));
/* 174 */     beanDef.setRole(2);
/* 175 */     MutablePropertyValues values = beanDef.getPropertyValues();
/*     */     
/* 177 */     List<Element> elements = DomUtils.getChildElementsByTagName(resolverElement, "default-views");
/* 178 */     if (!elements.isEmpty()) {
/* 179 */       ManagedList<Object> list = new ManagedList();
/* 180 */       for (Element element : DomUtils.getChildElementsByTagName(elements.get(0), new String[] { "bean", "ref" })) {
/* 181 */         list.add(context.getDelegate().parsePropertySubElement(element, null));
/*     */       }
/* 183 */       values.add("defaultViews", list);
/*     */     } 
/* 185 */     if (resolverElement.hasAttribute("use-not-acceptable")) {
/* 186 */       values.add("useNotAcceptableStatusCode", resolverElement.getAttribute("use-not-acceptable"));
/*     */     }
/* 188 */     Object manager = MvcNamespaceUtils.getContentNegotiationManager(context);
/* 189 */     if (manager != null) {
/* 190 */       values.add("contentNegotiationManager", manager);
/*     */     }
/* 192 */     return (BeanDefinition)beanDef;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\ViewResolversBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */