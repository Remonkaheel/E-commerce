/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WebMvcConfigurerComposite
/*     */   implements WebMvcConfigurer
/*     */ {
/*  41 */   private final List<WebMvcConfigurer> delegates = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public void addWebMvcConfigurers(List<WebMvcConfigurer> configurers) {
/*  45 */     if (!CollectionUtils.isEmpty(configurers)) {
/*  46 */       this.delegates.addAll(configurers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configurePathMatch(PathMatchConfigurer configurer) {
/*  53 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  54 */       delegate.configurePathMatch(configurer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
/*  60 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  61 */       delegate.configureContentNegotiation(configurer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
/*  67 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  68 */       delegate.configureAsyncSupport(configurer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
/*  74 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  75 */       delegate.configureDefaultServletHandling(configurer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFormatters(FormatterRegistry registry) {
/*  81 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  82 */       delegate.addFormatters(registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInterceptors(InterceptorRegistry registry) {
/*  88 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  89 */       delegate.addInterceptors(registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addResourceHandlers(ResourceHandlerRegistry registry) {
/*  95 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  96 */       delegate.addResourceHandlers(registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCorsMappings(CorsRegistry registry) {
/* 102 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 103 */       delegate.addCorsMappings(registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addViewControllers(ViewControllerRegistry registry) {
/* 109 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 110 */       delegate.addViewControllers(registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureViewResolvers(ViewResolverRegistry registry) {
/* 116 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 117 */       delegate.configureViewResolvers(registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 123 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 124 */       delegate.addArgumentResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {
/* 130 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 131 */       delegate.addReturnValueHandlers(returnValueHandlers);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
/* 137 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 138 */       delegate.configureMessageConverters(converters);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
/* 144 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 145 */       delegate.extendMessageConverters(converters);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
/* 151 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 152 */       delegate.configureHandlerExceptionResolvers(exceptionResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
/* 158 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 159 */       delegate.extendHandlerExceptionResolvers(exceptionResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addErrorResponseInterceptors(List<ErrorResponse.Interceptor> interceptors) {
/* 165 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 166 */       delegate.addErrorResponseInterceptors(interceptors);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Validator getValidator() {
/* 173 */     Validator selected = null;
/* 174 */     for (WebMvcConfigurer configurer : this.delegates) {
/* 175 */       Validator validator = configurer.getValidator();
/* 176 */       if (validator != null) {
/* 177 */         if (selected != null) {
/* 178 */           throw new IllegalStateException("No unique Validator found: {" + String.valueOf(selected) + ", " + String.valueOf(validator) + "}");
/*     */         }
/*     */         
/* 181 */         selected = validator;
/*     */       } 
/*     */     } 
/* 184 */     return selected;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MessageCodesResolver getMessageCodesResolver() {
/* 190 */     MessageCodesResolver selected = null;
/* 191 */     for (WebMvcConfigurer configurer : this.delegates) {
/* 192 */       MessageCodesResolver messageCodesResolver = configurer.getMessageCodesResolver();
/* 193 */       if (messageCodesResolver != null) {
/* 194 */         if (selected != null) {
/* 195 */           throw new IllegalStateException("No unique MessageCodesResolver found: {" + String.valueOf(selected) + ", " + String.valueOf(messageCodesResolver) + "}");
/*     */         }
/*     */         
/* 198 */         selected = messageCodesResolver;
/*     */       } 
/*     */     } 
/* 201 */     return selected;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\WebMvcConfigurerComposite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */