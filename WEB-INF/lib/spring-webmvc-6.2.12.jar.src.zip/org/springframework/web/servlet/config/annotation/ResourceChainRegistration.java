/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.concurrent.ConcurrentMapCache;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.servlet.resource.CachingResourceResolver;
/*     */ import org.springframework.web.servlet.resource.CachingResourceTransformer;
/*     */ import org.springframework.web.servlet.resource.CssLinkResourceTransformer;
/*     */ import org.springframework.web.servlet.resource.LiteWebJarsResourceResolver;
/*     */ import org.springframework.web.servlet.resource.PathResourceResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceTransformer;
/*     */ import org.springframework.web.servlet.resource.WebJarsResourceResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceChainRegistration
/*     */ {
/*     */   private static final String DEFAULT_CACHE_NAME = "spring-resource-chain-cache";
/*  47 */   private static final boolean isWebJarAssetLocatorPresent = ClassUtils.isPresent("org.webjars.WebJarAssetLocator", ResourceChainRegistration.class
/*  48 */       .getClassLoader());
/*     */   
/*  50 */   private static final boolean isWebJarVersionLocatorPresent = ClassUtils.isPresent("org.webjars.WebJarVersionLocator", ResourceChainRegistration.class
/*  51 */       .getClassLoader());
/*     */ 
/*     */   
/*  54 */   private final List<ResourceResolver> resolvers = new ArrayList<>(4);
/*     */   
/*  56 */   private final List<ResourceTransformer> transformers = new ArrayList<>(4);
/*     */   
/*     */   private boolean hasVersionResolver;
/*     */   
/*     */   private boolean hasPathResolver;
/*     */   
/*     */   private boolean hasCssLinkTransformer;
/*     */   
/*     */   private boolean hasWebjarsResolver;
/*     */ 
/*     */   
/*     */   public ResourceChainRegistration(boolean cacheResources) {
/*  68 */     this(cacheResources, cacheResources ? (Cache)new ConcurrentMapCache("spring-resource-chain-cache") : null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceChainRegistration(boolean cacheResources, @Nullable Cache cache) {
/*  73 */     Assert.isTrue((!cacheResources || cache != null), "'cache' is required when cacheResources=true");
/*  74 */     if (cacheResources) {
/*  75 */       this.resolvers.add(new CachingResourceResolver(cache));
/*  76 */       this.transformers.add(new CachingResourceTransformer(cache));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceChainRegistration addResolver(ResourceResolver resolver) {
/*  88 */     Assert.notNull(resolver, "The provided ResourceResolver should not be null");
/*  89 */     this.resolvers.add(resolver);
/*  90 */     if (resolver instanceof org.springframework.web.servlet.resource.VersionResourceResolver) {
/*  91 */       this.hasVersionResolver = true;
/*     */     }
/*  93 */     else if (resolver instanceof PathResourceResolver) {
/*  94 */       this.hasPathResolver = true;
/*     */     }
/*  96 */     else if (resolver instanceof WebJarsResourceResolver || resolver instanceof LiteWebJarsResourceResolver) {
/*  97 */       this.hasWebjarsResolver = true;
/*     */     } 
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceChainRegistration addTransformer(ResourceTransformer transformer) {
/* 108 */     Assert.notNull(transformer, "The provided ResourceTransformer should not be null");
/* 109 */     this.transformers.add(transformer);
/* 110 */     if (transformer instanceof CssLinkResourceTransformer) {
/* 111 */       this.hasCssLinkTransformer = true;
/*     */     }
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<ResourceResolver> getResourceResolvers() {
/* 118 */     if (!this.hasPathResolver) {
/* 119 */       List<ResourceResolver> result = new ArrayList<>(this.resolvers);
/* 120 */       if (isWebJarVersionLocatorPresent && !this.hasWebjarsResolver) {
/* 121 */         result.add(new LiteWebJarsResourceResolver());
/*     */       }
/* 123 */       else if (isWebJarAssetLocatorPresent && !this.hasWebjarsResolver) {
/* 124 */         result.add(new WebJarsResourceResolver());
/*     */       } 
/* 126 */       result.add(new PathResourceResolver());
/* 127 */       return result;
/*     */     } 
/* 129 */     return this.resolvers;
/*     */   }
/*     */   
/*     */   protected List<ResourceTransformer> getResourceTransformers() {
/* 133 */     if (this.hasVersionResolver && !this.hasCssLinkTransformer) {
/* 134 */       List<ResourceTransformer> result = new ArrayList<>(this.transformers);
/* 135 */       boolean hasTransformers = !this.transformers.isEmpty();
/* 136 */       boolean hasCaching = (hasTransformers && this.transformers.get(0) instanceof CachingResourceTransformer);
/* 137 */       result.add(hasCaching ? 1 : 0, new CssLinkResourceTransformer());
/* 138 */       return result;
/*     */     } 
/* 140 */     return this.transformers;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\ResourceChainRegistration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */