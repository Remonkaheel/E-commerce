/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MvcNamespaceHandler
/*    */   extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init() {
/* 34 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 35 */     registerBeanDefinitionParser("default-servlet-handler", new DefaultServletHandlerBeanDefinitionParser());
/* 36 */     registerBeanDefinitionParser("interceptors", new InterceptorsBeanDefinitionParser());
/* 37 */     registerBeanDefinitionParser("resources", new ResourcesBeanDefinitionParser());
/* 38 */     registerBeanDefinitionParser("view-controller", new ViewControllerBeanDefinitionParser());
/* 39 */     registerBeanDefinitionParser("redirect-view-controller", new ViewControllerBeanDefinitionParser());
/* 40 */     registerBeanDefinitionParser("status-controller", new ViewControllerBeanDefinitionParser());
/* 41 */     registerBeanDefinitionParser("view-resolvers", new ViewResolversBeanDefinitionParser());
/* 42 */     registerBeanDefinitionParser("freemarker-configurer", (BeanDefinitionParser)new FreeMarkerConfigurerBeanDefinitionParser());
/* 43 */     registerBeanDefinitionParser("groovy-configurer", (BeanDefinitionParser)new GroovyMarkupConfigurerBeanDefinitionParser());
/* 44 */     registerBeanDefinitionParser("script-template-configurer", (BeanDefinitionParser)new ScriptTemplateConfigurerBeanDefinitionParser());
/* 45 */     registerBeanDefinitionParser("cors", new CorsBeanDefinitionParser());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\MvcNamespaceHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */