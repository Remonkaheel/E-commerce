/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import com.fasterxml.jackson.dataformat.cbor.CBORFactory;
/*     */ import com.fasterxml.jackson.dataformat.smile.SmileFactory;
/*     */ import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.format.support.FormattingConversionServiceFactoryBean;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceRegionHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.cbor.MappingJackson2CborHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.smile.MappingJackson2SmileHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.yaml.MappingJackson2YamlHttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*     */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*     */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ServletWebArgumentResolverAdapter;
/*     */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/* 158 */   public static final String HANDLER_MAPPING_BEAN_NAME = RequestMappingHandlerMapping.class.getName();
/*     */   
/* 160 */   public static final String HANDLER_ADAPTER_BEAN_NAME = RequestMappingHandlerAdapter.class.getName();
/*     */   
/*     */   public static final String CONTENT_NEGOTIATION_MANAGER_BEAN_NAME = "mvcContentNegotiationManager";
/*     */   
/*     */   private static final boolean javaxValidationPresent;
/*     */   
/*     */   private static final boolean romePresent;
/*     */   
/*     */   private static final boolean jaxb2Present;
/*     */   
/*     */   private static final boolean jackson2Present;
/*     */   
/*     */   private static final boolean jackson2XmlPresent;
/*     */   
/*     */   private static final boolean jackson2SmilePresent;
/*     */   
/*     */   private static final boolean jackson2CborPresent;
/*     */   
/*     */   private static final boolean jackson2YamlPresent;
/*     */   
/*     */   private static final boolean gsonPresent;
/*     */ 
/*     */   
/*     */   static {
/* 184 */     ClassLoader classLoader = AnnotationDrivenBeanDefinitionParser.class.getClassLoader();
/* 185 */     javaxValidationPresent = ClassUtils.isPresent("jakarta.validation.Validator", classLoader);
/* 186 */     romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", classLoader);
/* 187 */     jaxb2Present = ClassUtils.isPresent("jakarta.xml.bind.Binder", classLoader);
/*     */     
/* 189 */     jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", classLoader) && ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", classLoader));
/* 190 */     jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", classLoader);
/* 191 */     jackson2SmilePresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.smile.SmileFactory", classLoader);
/* 192 */     jackson2CborPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.cbor.CBORFactory", classLoader);
/* 193 */     jackson2YamlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.yaml.YAMLFactory", classLoader);
/* 194 */     gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext context) {
/* 201 */     Object source = context.extractSource(element);
/* 202 */     XmlReaderContext readerContext = context.getReaderContext();
/*     */     
/* 204 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), source);
/* 205 */     context.pushContainingComponent(compDefinition);
/*     */     
/* 207 */     RuntimeBeanReference contentNegotiationManager = getContentNegotiationManager(element, source, context);
/*     */     
/* 209 */     RootBeanDefinition handlerMappingDef = new RootBeanDefinition(RequestMappingHandlerMapping.class);
/* 210 */     handlerMappingDef.setSource(source);
/* 211 */     handlerMappingDef.setRole(2);
/* 212 */     handlerMappingDef.getPropertyValues().add("order", Integer.valueOf(0));
/* 213 */     handlerMappingDef.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/*     */     
/* 215 */     if (element.hasAttribute("enable-matrix-variables")) {
/* 216 */       boolean enableMatrixVariables = Boolean.parseBoolean(element.getAttribute("enable-matrix-variables"));
/* 217 */       handlerMappingDef.getPropertyValues().add("removeSemicolonContent", Boolean.valueOf(!enableMatrixVariables));
/*     */     } 
/*     */     
/* 220 */     configurePathMatchingProperties(handlerMappingDef, element, context);
/* 221 */     readerContext.getRegistry().registerBeanDefinition(HANDLER_MAPPING_BEAN_NAME, (BeanDefinition)handlerMappingDef);
/*     */     
/* 223 */     RuntimeBeanReference corsRef = MvcNamespaceUtils.registerCorsConfigurations(null, context, source);
/* 224 */     handlerMappingDef.getPropertyValues().add("corsConfigurations", corsRef);
/*     */     
/* 226 */     RuntimeBeanReference conversionService = getConversionService(element, source, context);
/* 227 */     RuntimeBeanReference validator = getValidator(element, source, context);
/* 228 */     RuntimeBeanReference messageCodesResolver = getMessageCodesResolver(element);
/*     */     
/* 230 */     RootBeanDefinition bindingDef = new RootBeanDefinition(ConfigurableWebBindingInitializer.class);
/* 231 */     bindingDef.setSource(source);
/* 232 */     bindingDef.setRole(2);
/* 233 */     bindingDef.getPropertyValues().add("conversionService", conversionService);
/* 234 */     bindingDef.getPropertyValues().add("validator", validator);
/* 235 */     bindingDef.getPropertyValues().add("messageCodesResolver", messageCodesResolver);
/*     */     
/* 237 */     ManagedList<?> messageConverters = getMessageConverters(element, source, context);
/* 238 */     ManagedList<?> argumentResolvers = getArgumentResolvers(element, context);
/* 239 */     ManagedList<?> returnValueHandlers = getReturnValueHandlers(element, context);
/* 240 */     String asyncTimeout = getAsyncTimeout(element);
/* 241 */     RuntimeBeanReference asyncExecutor = getAsyncExecutor(element);
/* 242 */     ManagedList<?> callableInterceptors = getInterceptors(element, source, context, "callable-interceptors");
/* 243 */     ManagedList<?> deferredResultInterceptors = getInterceptors(element, source, context, "deferred-result-interceptors");
/*     */     
/* 245 */     RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(RequestMappingHandlerAdapter.class);
/* 246 */     handlerAdapterDef.setSource(source);
/* 247 */     handlerAdapterDef.setRole(2);
/* 248 */     handlerAdapterDef.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 249 */     handlerAdapterDef.getPropertyValues().add("webBindingInitializer", bindingDef);
/* 250 */     handlerAdapterDef.getPropertyValues().add("messageConverters", messageConverters);
/* 251 */     addRequestBodyAdvice(handlerAdapterDef);
/* 252 */     addResponseBodyAdvice(handlerAdapterDef);
/*     */     
/* 254 */     if (element.hasAttribute("ignore-default-model-on-redirect")) {
/* 255 */       Boolean ignoreDefaultModel = Boolean.valueOf(element.getAttribute("ignore-default-model-on-redirect"));
/* 256 */       handlerAdapterDef.getPropertyValues().add("ignoreDefaultModelOnRedirect", ignoreDefaultModel);
/*     */     } 
/* 258 */     if (argumentResolvers != null) {
/* 259 */       handlerAdapterDef.getPropertyValues().add("customArgumentResolvers", argumentResolvers);
/*     */     }
/* 261 */     if (returnValueHandlers != null) {
/* 262 */       handlerAdapterDef.getPropertyValues().add("customReturnValueHandlers", returnValueHandlers);
/*     */     }
/* 264 */     if (asyncTimeout != null) {
/* 265 */       handlerAdapterDef.getPropertyValues().add("asyncRequestTimeout", asyncTimeout);
/*     */     }
/* 267 */     if (asyncExecutor != null) {
/* 268 */       handlerAdapterDef.getPropertyValues().add("taskExecutor", asyncExecutor);
/*     */     }
/*     */     
/* 271 */     handlerAdapterDef.getPropertyValues().add("callableInterceptors", callableInterceptors);
/* 272 */     handlerAdapterDef.getPropertyValues().add("deferredResultInterceptors", deferredResultInterceptors);
/* 273 */     readerContext.getRegistry().registerBeanDefinition(HANDLER_ADAPTER_BEAN_NAME, (BeanDefinition)handlerAdapterDef);
/*     */     
/* 275 */     RootBeanDefinition uriContributorDef = new RootBeanDefinition(CompositeUriComponentsContributorFactoryBean.class);
/*     */     
/* 277 */     uriContributorDef.setSource(source);
/* 278 */     uriContributorDef.getPropertyValues().addPropertyValue("handlerAdapter", handlerAdapterDef);
/* 279 */     uriContributorDef.getPropertyValues().addPropertyValue("conversionService", conversionService);
/* 280 */     String uriContributorName = "mvcUriComponentsContributor";
/* 281 */     readerContext.getRegistry().registerBeanDefinition(uriContributorName, (BeanDefinition)uriContributorDef);
/*     */     
/* 283 */     RootBeanDefinition csInterceptorDef = new RootBeanDefinition(ConversionServiceExposingInterceptor.class);
/* 284 */     csInterceptorDef.setSource(source);
/* 285 */     csInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, conversionService);
/* 286 */     RootBeanDefinition mappedInterceptorDef = new RootBeanDefinition(MappedInterceptor.class);
/* 287 */     mappedInterceptorDef.setSource(source);
/* 288 */     mappedInterceptorDef.setRole(2);
/* 289 */     mappedInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, null);
/* 290 */     mappedInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(1, csInterceptorDef);
/* 291 */     String mappedInterceptorName = readerContext.registerWithGeneratedName((BeanDefinition)mappedInterceptorDef);
/*     */     
/* 293 */     RootBeanDefinition methodExceptionResolver = new RootBeanDefinition(ExceptionHandlerExceptionResolver.class);
/* 294 */     methodExceptionResolver.setSource(source);
/* 295 */     methodExceptionResolver.setRole(2);
/* 296 */     methodExceptionResolver.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 297 */     methodExceptionResolver.getPropertyValues().add("messageConverters", messageConverters);
/* 298 */     methodExceptionResolver.getPropertyValues().add("order", Integer.valueOf(0));
/* 299 */     addResponseBodyAdvice(methodExceptionResolver);
/* 300 */     if (argumentResolvers != null) {
/* 301 */       methodExceptionResolver.getPropertyValues().add("customArgumentResolvers", argumentResolvers);
/*     */     }
/* 303 */     if (returnValueHandlers != null) {
/* 304 */       methodExceptionResolver.getPropertyValues().add("customReturnValueHandlers", returnValueHandlers);
/*     */     }
/* 306 */     String methodExResolverName = readerContext.registerWithGeneratedName((BeanDefinition)methodExceptionResolver);
/*     */     
/* 308 */     RootBeanDefinition statusExceptionResolver = new RootBeanDefinition(ResponseStatusExceptionResolver.class);
/* 309 */     statusExceptionResolver.setSource(source);
/* 310 */     statusExceptionResolver.setRole(2);
/* 311 */     statusExceptionResolver.getPropertyValues().add("order", Integer.valueOf(1));
/* 312 */     String statusExResolverName = readerContext.registerWithGeneratedName((BeanDefinition)statusExceptionResolver);
/*     */     
/* 314 */     RootBeanDefinition defaultExceptionResolver = new RootBeanDefinition(DefaultHandlerExceptionResolver.class);
/* 315 */     defaultExceptionResolver.setSource(source);
/* 316 */     defaultExceptionResolver.setRole(2);
/* 317 */     defaultExceptionResolver.getPropertyValues().add("order", Integer.valueOf(2));
/* 318 */     String defaultExResolverName = readerContext.registerWithGeneratedName((BeanDefinition)defaultExceptionResolver);
/*     */     
/* 320 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)handlerMappingDef, HANDLER_MAPPING_BEAN_NAME));
/* 321 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)handlerAdapterDef, HANDLER_ADAPTER_BEAN_NAME));
/* 322 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)uriContributorDef, uriContributorName));
/* 323 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)mappedInterceptorDef, mappedInterceptorName));
/* 324 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)methodExceptionResolver, methodExResolverName));
/* 325 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)statusExceptionResolver, statusExResolverName));
/* 326 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)defaultExceptionResolver, defaultExResolverName));
/*     */ 
/*     */     
/* 329 */     MvcNamespaceUtils.registerDefaultComponents(context, source);
/*     */     
/* 331 */     context.popAndRegisterContainingComponent();
/*     */     
/* 333 */     return null;
/*     */   }
/*     */   
/*     */   protected void addRequestBodyAdvice(RootBeanDefinition beanDef) {
/* 337 */     if (jackson2Present) {
/* 338 */       beanDef.getPropertyValues().add("requestBodyAdvice", new RootBeanDefinition(JsonViewRequestBodyAdvice.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addResponseBodyAdvice(RootBeanDefinition beanDef) {
/* 344 */     if (jackson2Present) {
/* 345 */       beanDef.getPropertyValues().add("responseBodyAdvice", new RootBeanDefinition(JsonViewResponseBodyAdvice.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private RuntimeBeanReference getConversionService(Element element, @Nullable Object source, ParserContext context) {
/*     */     RuntimeBeanReference conversionServiceRef;
/* 352 */     if (element.hasAttribute("conversion-service")) {
/* 353 */       conversionServiceRef = new RuntimeBeanReference(element.getAttribute("conversion-service"));
/*     */     } else {
/*     */       
/* 356 */       RootBeanDefinition conversionDef = new RootBeanDefinition(FormattingConversionServiceFactoryBean.class);
/* 357 */       conversionDef.setSource(source);
/* 358 */       conversionDef.setRole(2);
/* 359 */       String conversionName = context.getReaderContext().registerWithGeneratedName((BeanDefinition)conversionDef);
/* 360 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)conversionDef, conversionName));
/* 361 */       conversionServiceRef = new RuntimeBeanReference(conversionName);
/*     */     } 
/* 363 */     return conversionServiceRef;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RuntimeBeanReference getValidator(Element element, @Nullable Object source, ParserContext context) {
/* 368 */     if (element.hasAttribute("validator")) {
/* 369 */       return new RuntimeBeanReference(element.getAttribute("validator"));
/*     */     }
/* 371 */     if (javaxValidationPresent) {
/* 372 */       RootBeanDefinition validatorDef = new RootBeanDefinition("org.springframework.validation.beanvalidation.OptionalValidatorFactoryBean");
/*     */       
/* 374 */       validatorDef.setSource(source);
/* 375 */       validatorDef.setRole(2);
/* 376 */       String validatorName = context.getReaderContext().registerWithGeneratedName((BeanDefinition)validatorDef);
/* 377 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)validatorDef, validatorName));
/* 378 */       return new RuntimeBeanReference(validatorName);
/*     */     } 
/*     */     
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RuntimeBeanReference getContentNegotiationManager(Element element, @Nullable Object source, ParserContext context) {
/*     */     RuntimeBeanReference beanRef;
/* 389 */     if (element.hasAttribute("content-negotiation-manager")) {
/* 390 */       String name = element.getAttribute("content-negotiation-manager");
/* 391 */       beanRef = new RuntimeBeanReference(name);
/*     */     } else {
/*     */       
/* 394 */       RootBeanDefinition factoryBeanDef = new RootBeanDefinition(ContentNegotiationManagerFactoryBean.class);
/* 395 */       factoryBeanDef.setSource(source);
/* 396 */       factoryBeanDef.setRole(2);
/* 397 */       factoryBeanDef.getPropertyValues().add("mediaTypes", getDefaultMediaTypes());
/* 398 */       String name = "mvcContentNegotiationManager";
/* 399 */       context.getReaderContext().getRegistry().registerBeanDefinition(name, (BeanDefinition)factoryBeanDef);
/* 400 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)factoryBeanDef, name));
/* 401 */       beanRef = new RuntimeBeanReference(name);
/*     */     } 
/* 403 */     return beanRef;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void configurePathMatchingProperties(RootBeanDefinition handlerMappingDef, Element element, ParserContext context) {
/* 409 */     Element pathMatchingElement = DomUtils.getChildElementByTagName(element, "path-matching");
/* 410 */     Object source = context.extractSource(element);
/* 411 */     if (pathMatchingElement != null) {
/* 412 */       if (pathMatchingElement.hasAttribute("trailing-slash")) {
/* 413 */         boolean useTrailingSlashMatch = Boolean.parseBoolean(pathMatchingElement.getAttribute("trailing-slash"));
/* 414 */         handlerMappingDef.getPropertyValues().add("useTrailingSlashMatch", Boolean.valueOf(useTrailingSlashMatch));
/*     */       } 
/* 416 */       boolean preferPathMatcher = false;
/* 417 */       if (pathMatchingElement.hasAttribute("suffix-pattern")) {
/* 418 */         boolean useSuffixPatternMatch = Boolean.parseBoolean(pathMatchingElement.getAttribute("suffix-pattern"));
/* 419 */         handlerMappingDef.getPropertyValues().add("useSuffixPatternMatch", Boolean.valueOf(useSuffixPatternMatch));
/* 420 */         preferPathMatcher |= useSuffixPatternMatch;
/*     */       } 
/* 422 */       if (pathMatchingElement.hasAttribute("registered-suffixes-only")) {
/* 423 */         boolean useRegisteredSuffixPatternMatch = Boolean.parseBoolean(pathMatchingElement.getAttribute("registered-suffixes-only"));
/* 424 */         handlerMappingDef.getPropertyValues().add("useRegisteredSuffixPatternMatch", Boolean.valueOf(useRegisteredSuffixPatternMatch));
/* 425 */         preferPathMatcher |= useRegisteredSuffixPatternMatch;
/*     */       } 
/*     */       
/* 428 */       RuntimeBeanReference pathHelperRef = null;
/* 429 */       if (pathMatchingElement.hasAttribute("path-helper")) {
/* 430 */         pathHelperRef = new RuntimeBeanReference(pathMatchingElement.getAttribute("path-helper"));
/* 431 */         preferPathMatcher = true;
/*     */       } 
/* 433 */       pathHelperRef = MvcNamespaceUtils.registerUrlPathHelper(pathHelperRef, context, source);
/* 434 */       handlerMappingDef.getPropertyValues().add("urlPathHelper", pathHelperRef);
/*     */       
/* 436 */       RuntimeBeanReference pathMatcherRef = null;
/* 437 */       if (pathMatchingElement.hasAttribute("path-matcher")) {
/* 438 */         pathMatcherRef = new RuntimeBeanReference(pathMatchingElement.getAttribute("path-matcher"));
/* 439 */         preferPathMatcher = true;
/*     */       } 
/* 441 */       if (preferPathMatcher) {
/* 442 */         pathMatcherRef = MvcNamespaceUtils.registerPathMatcher(pathMatcherRef, context, source);
/* 443 */         handlerMappingDef.getPropertyValues().add("pathMatcher", pathMatcherRef);
/* 444 */         handlerMappingDef.getPropertyValues().add("patternParser", null);
/*     */       }
/* 446 */       else if (pathMatchingElement.hasAttribute("pattern-parser")) {
/* 447 */         RuntimeBeanReference patternParserRef = new RuntimeBeanReference(pathMatchingElement.getAttribute("pattern-parser"));
/* 448 */         patternParserRef = MvcNamespaceUtils.registerPatternParser(patternParserRef, context, source);
/* 449 */         handlerMappingDef.getPropertyValues().add("patternParser", patternParserRef);
/*     */       } 
/*     */     } else {
/*     */       
/* 453 */       RuntimeBeanReference pathMatcherRef = MvcNamespaceUtils.registerPathMatcher(null, context, source);
/* 454 */       handlerMappingDef.getPropertyValues().add("pathMatcher", pathMatcherRef);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Properties getDefaultMediaTypes() {
/* 460 */     Properties defaultMediaTypes = new Properties();
/* 461 */     if (romePresent) {
/* 462 */       defaultMediaTypes.put("atom", "application/atom+xml");
/* 463 */       defaultMediaTypes.put("rss", "application/rss+xml");
/*     */     } 
/* 465 */     if (jaxb2Present || jackson2XmlPresent) {
/* 466 */       defaultMediaTypes.put("xml", "application/xml");
/*     */     }
/* 468 */     if (jackson2Present || gsonPresent) {
/* 469 */       defaultMediaTypes.put("json", "application/json");
/*     */     }
/* 471 */     if (jackson2SmilePresent) {
/* 472 */       defaultMediaTypes.put("smile", "application/x-jackson-smile");
/*     */     }
/* 474 */     if (jackson2CborPresent) {
/* 475 */       defaultMediaTypes.put("cbor", "application/cbor");
/*     */     }
/* 477 */     if (jackson2YamlPresent) {
/* 478 */       defaultMediaTypes.put("yaml", "application/yaml");
/*     */     }
/* 480 */     return defaultMediaTypes;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RuntimeBeanReference getMessageCodesResolver(Element element) {
/* 485 */     if (element.hasAttribute("message-codes-resolver")) {
/* 486 */       return new RuntimeBeanReference(element.getAttribute("message-codes-resolver"));
/*     */     }
/*     */     
/* 489 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String getAsyncTimeout(Element element) {
/* 495 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 496 */     return (asyncElement != null) ? asyncElement.getAttribute("default-timeout") : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RuntimeBeanReference getAsyncExecutor(Element element) {
/* 501 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 502 */     if (asyncElement != null && asyncElement.hasAttribute("task-executor")) {
/* 503 */       return new RuntimeBeanReference(asyncElement.getAttribute("task-executor"));
/*     */     }
/* 505 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ManagedList<?> getInterceptors(Element element, @Nullable Object source, ParserContext context, String interceptorElementName) {
/* 511 */     ManagedList<Object> interceptors = new ManagedList();
/* 512 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 513 */     if (asyncElement != null) {
/* 514 */       Element interceptorsElement = DomUtils.getChildElementByTagName(asyncElement, interceptorElementName);
/* 515 */       if (interceptorsElement != null) {
/* 516 */         interceptors.setSource(source);
/* 517 */         for (Element converter : DomUtils.getChildElementsByTagName(interceptorsElement, "bean")) {
/* 518 */           BeanDefinitionHolder beanDef = context.getDelegate().parseBeanDefinitionElement(converter);
/* 519 */           if (beanDef != null) {
/* 520 */             beanDef = context.getDelegate().decorateBeanDefinitionIfRequired(converter, beanDef);
/* 521 */             interceptors.add(beanDef);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 526 */     return interceptors;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ManagedList<?> getArgumentResolvers(Element element, ParserContext context) {
/* 531 */     Element resolversElement = DomUtils.getChildElementByTagName(element, "argument-resolvers");
/* 532 */     if (resolversElement != null) {
/* 533 */       ManagedList<Object> resolvers = extractBeanSubElements(resolversElement, context);
/* 534 */       return wrapLegacyResolvers((List<Object>)resolvers, context);
/*     */     } 
/* 536 */     return null;
/*     */   }
/*     */   
/*     */   private ManagedList<Object> wrapLegacyResolvers(List<Object> list, ParserContext context) {
/* 540 */     ManagedList<Object> result = new ManagedList();
/* 541 */     for (Object object : list) {
/* 542 */       if (object instanceof BeanDefinitionHolder) { BeanDefinitionHolder beanDef = (BeanDefinitionHolder)object;
/* 543 */         String className = beanDef.getBeanDefinition().getBeanClassName();
/* 544 */         Assert.notNull(className, "No resolver class");
/* 545 */         Class<?> clazz = ClassUtils.resolveClassName(className, context.getReaderContext().getBeanClassLoader());
/* 546 */         if (WebArgumentResolver.class.isAssignableFrom(clazz)) {
/* 547 */           RootBeanDefinition adapter = new RootBeanDefinition(ServletWebArgumentResolverAdapter.class);
/* 548 */           adapter.getConstructorArgumentValues().addIndexedArgumentValue(0, beanDef);
/* 549 */           result.add(new BeanDefinitionHolder((BeanDefinition)adapter, beanDef.getBeanName() + "Adapter"));
/*     */           continue;
/*     */         }  }
/*     */       
/* 553 */       result.add(object);
/*     */     } 
/* 555 */     return result;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ManagedList<?> getReturnValueHandlers(Element element, ParserContext context) {
/* 560 */     Element handlers = DomUtils.getChildElementByTagName(element, "return-value-handlers");
/* 561 */     return (handlers != null) ? extractBeanSubElements(handlers, context) : null;
/*     */   }
/*     */   
/*     */   private ManagedList<?> getMessageConverters(Element element, @Nullable Object source, ParserContext context) {
/* 565 */     Element convertersElement = DomUtils.getChildElementByTagName(element, "message-converters");
/* 566 */     ManagedList<Object> messageConverters = new ManagedList();
/* 567 */     if (convertersElement != null) {
/* 568 */       messageConverters.setSource(source);
/* 569 */       for (Element beanElement : DomUtils.getChildElementsByTagName(convertersElement, new String[] { "bean", "ref" })) {
/* 570 */         Object object = context.getDelegate().parsePropertySubElement(beanElement, null);
/* 571 */         messageConverters.add(object);
/*     */       } 
/*     */     } 
/*     */     
/* 575 */     if (convertersElement == null || Boolean.parseBoolean(convertersElement.getAttribute("register-defaults"))) {
/* 576 */       messageConverters.setSource(source);
/* 577 */       messageConverters.add(createConverterDefinition(ByteArrayHttpMessageConverter.class, source));
/*     */       
/* 579 */       RootBeanDefinition stringConverterDef = createConverterDefinition(StringHttpMessageConverter.class, source);
/* 580 */       stringConverterDef.getPropertyValues().add("writeAcceptCharset", Boolean.valueOf(false));
/* 581 */       messageConverters.add(stringConverterDef);
/*     */       
/* 583 */       messageConverters.add(createConverterDefinition(ResourceHttpMessageConverter.class, source));
/* 584 */       messageConverters.add(createConverterDefinition(ResourceRegionHttpMessageConverter.class, source));
/* 585 */       messageConverters.add(createConverterDefinition(AllEncompassingFormHttpMessageConverter.class, source));
/*     */       
/* 587 */       if (romePresent) {
/* 588 */         messageConverters.add(createConverterDefinition(AtomFeedHttpMessageConverter.class, source));
/* 589 */         messageConverters.add(createConverterDefinition(RssChannelHttpMessageConverter.class, source));
/*     */       } 
/*     */       
/* 592 */       if (jackson2XmlPresent) {
/* 593 */         Class<?> type = MappingJackson2XmlHttpMessageConverter.class;
/* 594 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(type, source);
/* 595 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 596 */         jacksonFactoryDef.getPropertyValues().add("createXmlMapper", Boolean.valueOf(true));
/* 597 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 598 */         messageConverters.add(jacksonConverterDef);
/*     */       }
/* 600 */       else if (jaxb2Present) {
/* 601 */         messageConverters.add(createConverterDefinition(Jaxb2RootElementHttpMessageConverter.class, source));
/*     */       } 
/*     */       
/* 604 */       if (jackson2Present) {
/* 605 */         Class<?> type = MappingJackson2HttpMessageConverter.class;
/* 606 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(type, source);
/* 607 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 608 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 609 */         messageConverters.add(jacksonConverterDef);
/*     */       }
/* 611 */       else if (gsonPresent) {
/* 612 */         messageConverters.add(createConverterDefinition(GsonHttpMessageConverter.class, source));
/*     */       } 
/*     */       
/* 615 */       if (jackson2SmilePresent) {
/* 616 */         Class<?> type = MappingJackson2SmileHttpMessageConverter.class;
/* 617 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(type, source);
/* 618 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 619 */         jacksonFactoryDef.getPropertyValues().add("factory", new RootBeanDefinition(SmileFactory.class));
/* 620 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 621 */         messageConverters.add(jacksonConverterDef);
/*     */       } 
/* 623 */       if (jackson2CborPresent) {
/* 624 */         Class<?> type = MappingJackson2CborHttpMessageConverter.class;
/* 625 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(type, source);
/* 626 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 627 */         jacksonFactoryDef.getPropertyValues().add("factory", new RootBeanDefinition(CBORFactory.class));
/* 628 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 629 */         messageConverters.add(jacksonConverterDef);
/*     */       } 
/* 631 */       if (jackson2YamlPresent) {
/* 632 */         Class<?> type = MappingJackson2YamlHttpMessageConverter.class;
/* 633 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(type, source);
/* 634 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 635 */         jacksonFactoryDef.getPropertyValues().add("factory", new RootBeanDefinition(YAMLFactory.class));
/* 636 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 637 */         messageConverters.add(jacksonConverterDef);
/*     */       } 
/*     */     } 
/* 640 */     return messageConverters;
/*     */   }
/*     */   
/*     */   private GenericBeanDefinition createObjectMapperFactoryDefinition(@Nullable Object source) {
/* 644 */     GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 645 */     beanDefinition.setBeanClass(Jackson2ObjectMapperFactoryBean.class);
/* 646 */     beanDefinition.setSource(source);
/* 647 */     beanDefinition.setRole(2);
/* 648 */     return beanDefinition;
/*     */   }
/*     */   
/*     */   private RootBeanDefinition createConverterDefinition(Class<?> converterClass, @Nullable Object source) {
/* 652 */     RootBeanDefinition beanDefinition = new RootBeanDefinition(converterClass);
/* 653 */     beanDefinition.setSource(source);
/* 654 */     beanDefinition.setRole(2);
/* 655 */     return beanDefinition;
/*     */   }
/*     */   
/*     */   private ManagedList<Object> extractBeanSubElements(Element parentElement, ParserContext context) {
/* 659 */     ManagedList<Object> list = new ManagedList();
/* 660 */     list.setSource(context.extractSource(parentElement));
/* 661 */     for (Element beanElement : DomUtils.getChildElementsByTagName(parentElement, new String[] { "bean", "ref" })) {
/* 662 */       Object object = context.getDelegate().parsePropertySubElement(beanElement, null);
/* 663 */       list.add(object);
/*     */     } 
/* 665 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CompositeUriComponentsContributorFactoryBean
/*     */     implements FactoryBean<CompositeUriComponentsContributor>, InitializingBean
/*     */   {
/*     */     @Nullable
/*     */     private RequestMappingHandlerAdapter handlerAdapter;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private ConversionService conversionService;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private CompositeUriComponentsContributor uriComponentsContributor;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setHandlerAdapter(RequestMappingHandlerAdapter handlerAdapter) {
/* 687 */       this.handlerAdapter = handlerAdapter;
/*     */     }
/*     */     
/*     */     public void setConversionService(ConversionService conversionService) {
/* 691 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterPropertiesSet() {
/* 696 */       Assert.state((this.handlerAdapter != null), "No RequestMappingHandlerAdapter set");
/* 697 */       this
/* 698 */         .uriComponentsContributor = new CompositeUriComponentsContributor(this.handlerAdapter.getArgumentResolvers(), this.conversionService);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CompositeUriComponentsContributor getObject() {
/* 704 */       return this.uriComponentsContributor;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 709 */       return CompositeUriComponentsContributor.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSingleton() {
/* 714 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\AnnotationDrivenBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */