/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*     */ import org.springframework.web.servlet.view.RedirectView;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ViewControllerBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String HANDLER_MAPPING_BEAN_NAME = "org.springframework.web.servlet.config.viewControllerHandlerMapping";
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*     */     ManagedMap<String, RootBeanDefinition> managedMap;
/*  66 */     Object source = parserContext.extractSource(element);
/*     */ 
/*     */     
/*  69 */     BeanDefinition hm = registerHandlerMapping(parserContext, source);
/*     */ 
/*     */     
/*  72 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*     */ 
/*     */     
/*  75 */     RootBeanDefinition controller = new RootBeanDefinition(ParameterizableViewController.class);
/*  76 */     controller.setSource(source);
/*     */     
/*  78 */     HttpStatusCode statusCode = null;
/*  79 */     if (element.hasAttribute("status-code")) {
/*  80 */       int statusValue = Integer.parseInt(element.getAttribute("status-code"));
/*  81 */       statusCode = HttpStatusCode.valueOf(statusValue);
/*     */     } 
/*     */     
/*  84 */     String name = element.getLocalName();
/*  85 */     switch (name) {
/*     */       case "view-controller":
/*  87 */         if (element.hasAttribute("view-name")) {
/*  88 */           controller.getPropertyValues().add("viewName", element.getAttribute("view-name"));
/*     */         }
/*  90 */         if (statusCode != null) {
/*  91 */           controller.getPropertyValues().add("statusCode", statusCode);
/*     */         }
/*     */         break;
/*     */       case "redirect-view-controller":
/*  95 */         controller.getPropertyValues().add("view", getRedirectView(element, statusCode, source)); break;
/*     */       case "status-controller":
/*  97 */         controller.getPropertyValues().add("statusCode", statusCode);
/*  98 */         controller.getPropertyValues().add("statusOnly", Boolean.valueOf(true));
/*     */         break;
/*     */       
/*     */       default:
/* 102 */         throw new IllegalStateException("Unexpected tag name: " + name);
/*     */     } 
/*     */     
/* 105 */     Map<String, BeanDefinition> urlMap = (Map<String, BeanDefinition>)hm.getPropertyValues().get("urlMap");
/* 106 */     if (urlMap == null) {
/* 107 */       managedMap = new ManagedMap();
/* 108 */       hm.getPropertyValues().add("urlMap", managedMap);
/*     */     } 
/* 110 */     managedMap.put(element.getAttribute("path"), controller);
/*     */     
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private BeanDefinition registerHandlerMapping(ParserContext context, @Nullable Object source) {
/* 116 */     if (context.getRegistry().containsBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping")) {
/* 117 */       return context.getRegistry().getBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping");
/*     */     }
/* 119 */     RootBeanDefinition beanDef = new RootBeanDefinition(SimpleUrlHandlerMapping.class);
/* 120 */     beanDef.setRole(2);
/* 121 */     context.getRegistry().registerBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping", (BeanDefinition)beanDef);
/* 122 */     context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, "org.springframework.web.servlet.config.viewControllerHandlerMapping"));
/*     */     
/* 124 */     beanDef.setSource(source);
/* 125 */     beanDef.getPropertyValues().add("order", "1");
/* 126 */     MvcNamespaceUtils.configurePathMatching(beanDef, context, source);
/* 127 */     beanDef.getPropertyValues().add("urlPathHelper", MvcNamespaceUtils.registerUrlPathHelper(null, context, source));
/* 128 */     RuntimeBeanReference corsConfigurationsRef = MvcNamespaceUtils.registerCorsConfigurations(null, context, source);
/* 129 */     beanDef.getPropertyValues().add("corsConfigurations", corsConfigurationsRef);
/*     */     
/* 131 */     return (BeanDefinition)beanDef;
/*     */   }
/*     */   
/*     */   private RootBeanDefinition getRedirectView(Element element, @Nullable HttpStatusCode status, @Nullable Object source) {
/* 135 */     RootBeanDefinition redirectView = new RootBeanDefinition(RedirectView.class);
/* 136 */     redirectView.setSource(source);
/* 137 */     redirectView.getConstructorArgumentValues().addIndexedArgumentValue(0, element.getAttribute("redirect-url"));
/*     */     
/* 139 */     if (status != null) {
/* 140 */       redirectView.getPropertyValues().add("statusCode", status);
/*     */     }
/*     */     
/* 143 */     if (element.hasAttribute("context-relative")) {
/* 144 */       redirectView.getPropertyValues().add("contextRelative", element.getAttribute("context-relative"));
/*     */     } else {
/*     */       
/* 147 */       redirectView.getPropertyValues().add("contextRelative", Boolean.valueOf(true));
/*     */     } 
/*     */     
/* 150 */     if (element.hasAttribute("keep-query-params")) {
/* 151 */       redirectView.getPropertyValues().add("propagateQueryParams", element.getAttribute("keep-query-params"));
/*     */     }
/*     */     
/* 154 */     return redirectView;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\ViewControllerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */