/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.springframework.core.OrderComparator;
/*    */ import org.springframework.web.context.request.WebRequestInterceptor;
/*    */ import org.springframework.web.servlet.HandlerInterceptor;
/*    */ import org.springframework.web.servlet.handler.WebRequestHandlerInterceptorAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterceptorRegistry
/*    */ {
/* 38 */   private final List<InterceptorRegistration> registrations = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   private static final Comparator<Object> INTERCEPTOR_ORDER_COMPARATOR;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InterceptorRegistration addInterceptor(HandlerInterceptor interceptor) {
/* 48 */     InterceptorRegistration registration = new InterceptorRegistration(interceptor);
/* 49 */     this.registrations.add(registration);
/* 50 */     return registration;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InterceptorRegistration addWebRequestInterceptor(WebRequestInterceptor interceptor) {
/* 60 */     WebRequestHandlerInterceptorAdapter adapted = new WebRequestHandlerInterceptorAdapter(interceptor);
/* 61 */     InterceptorRegistration registration = new InterceptorRegistration((HandlerInterceptor)adapted);
/* 62 */     this.registrations.add(registration);
/* 63 */     return registration;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected List<Object> getInterceptors() {
/* 70 */     return this.registrations.stream()
/* 71 */       .sorted(INTERCEPTOR_ORDER_COMPARATOR)
/* 72 */       .map(InterceptorRegistration::getInterceptor)
/* 73 */       .toList();
/*    */   }
/*    */ 
/*    */   
/*    */   static {
/* 78 */     INTERCEPTOR_ORDER_COMPARATOR = OrderComparator.INSTANCE.withSourceProvider(object -> {
/*    */           if (object instanceof InterceptorRegistration) {
/*    */             InterceptorRegistration interceptorRegistration = (InterceptorRegistration)object;
/*    */             Objects.requireNonNull(interceptorRegistration);
/*    */             return interceptorRegistration::getOrder;
/*    */           } 
/*    */           return null;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\InterceptorRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */