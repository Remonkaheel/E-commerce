/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FreeMarkerConfigurerBeanDefinitionParser
/*    */   extends AbstractSingleBeanDefinitionParser
/*    */ {
/*    */   public static final String BEAN_NAME = "mvcFreeMarkerConfigurer";
/*    */   
/*    */   protected String getBeanClassName(Element element) {
/* 48 */     return "org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer";
/*    */   }
/*    */ 
/*    */   
/*    */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext) {
/* 53 */     return "mvcFreeMarkerConfigurer";
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
/* 58 */     List<Element> childElements = DomUtils.getChildElementsByTagName(element, "template-loader-path");
/* 59 */     if (!childElements.isEmpty()) {
/* 60 */       List<String> locations = new ArrayList<>(childElements.size());
/* 61 */       for (Element childElement : childElements) {
/* 62 */         locations.add(childElement.getAttribute("location"));
/*    */       }
/* 64 */       builder.addPropertyValue("templateLoaderPaths", StringUtils.toStringArray(locations));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\FreeMarkerConfigurerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */