/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*     */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*     */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*     */ import org.springframework.web.servlet.support.SessionFlashMapManager;
/*     */ import org.springframework.web.servlet.theme.FixedThemeResolver;
/*     */ import org.springframework.web.servlet.view.DefaultRequestToViewNameTranslator;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MvcNamespaceUtils
/*     */ {
/*  57 */   private static final String BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME = BeanNameUrlHandlerMapping.class
/*  58 */     .getName();
/*     */   
/*  60 */   private static final String SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME = SimpleControllerHandlerAdapter.class
/*  61 */     .getName();
/*     */   
/*  63 */   private static final String HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME = HttpRequestHandlerAdapter.class
/*  64 */     .getName();
/*     */   
/*     */   private static final String URL_PATH_HELPER_BEAN_NAME = "mvcUrlPathHelper";
/*     */   
/*     */   private static final String PATH_MATCHER_BEAN_NAME = "mvcPathMatcher";
/*     */   
/*     */   private static final String PATTERN_PARSER_BEAN_NAME = "mvcPatternParser";
/*     */   
/*     */   private static final String CORS_CONFIGURATION_BEAN_NAME = "mvcCorsConfigurations";
/*     */   
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector";
/*     */ 
/*     */   
/*     */   public static void registerDefaultComponents(ParserContext context, @Nullable Object source) {
/*  78 */     registerBeanNameUrlHandlerMapping(context, source);
/*  79 */     registerHttpRequestHandlerAdapter(context, source);
/*  80 */     registerSimpleControllerHandlerAdapter(context, source);
/*  81 */     registerHandlerMappingIntrospector(context, source);
/*  82 */     registerLocaleResolver(context, source);
/*  83 */     registerThemeResolver(context, source);
/*  84 */     registerViewNameTranslator(context, source);
/*  85 */     registerFlashMapManager(context, source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeBeanReference registerUrlPathHelper(@Nullable RuntimeBeanReference urlPathHelperRef, ParserContext context, @Nullable Object source) {
/*  96 */     if (urlPathHelperRef != null) {
/*  97 */       if (context.getRegistry().isAlias("mvcUrlPathHelper")) {
/*  98 */         context.getRegistry().removeAlias("mvcUrlPathHelper");
/*     */       }
/* 100 */       context.getRegistry().registerAlias(urlPathHelperRef.getBeanName(), "mvcUrlPathHelper");
/*     */     }
/* 102 */     else if (!context.getRegistry().isAlias("mvcUrlPathHelper") && 
/* 103 */       !context.getRegistry().containsBeanDefinition("mvcUrlPathHelper")) {
/* 104 */       RootBeanDefinition urlPathHelperDef = new RootBeanDefinition(UrlPathHelper.class);
/* 105 */       urlPathHelperDef.setSource(source);
/* 106 */       urlPathHelperDef.setRole(2);
/* 107 */       context.getRegistry().registerBeanDefinition("mvcUrlPathHelper", (BeanDefinition)urlPathHelperDef);
/* 108 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)urlPathHelperDef, "mvcUrlPathHelper"));
/*     */     } 
/* 110 */     return new RuntimeBeanReference("mvcUrlPathHelper");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static RuntimeBeanReference getCustomPathMatcher(ParserContext context) {
/* 119 */     if (context.getRegistry().isAlias("mvcPathMatcher")) {
/* 120 */       return new RuntimeBeanReference("mvcPathMatcher");
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeBeanReference registerPathMatcher(@Nullable RuntimeBeanReference pathMatcherRef, ParserContext context, @Nullable Object source) {
/* 133 */     if (pathMatcherRef != null) {
/* 134 */       if (context.getRegistry().isAlias("mvcPathMatcher")) {
/* 135 */         context.getRegistry().removeAlias("mvcPathMatcher");
/*     */       }
/* 137 */       if (context.getRegistry().containsBeanDefinition("mvcPathMatcher")) {
/* 138 */         context.getRegistry().removeBeanDefinition("mvcPathMatcher");
/*     */       }
/* 140 */       context.getRegistry().registerAlias(pathMatcherRef.getBeanName(), "mvcPathMatcher");
/*     */     }
/* 142 */     else if (!context.getRegistry().isAlias("mvcPathMatcher") && 
/* 143 */       !context.getRegistry().containsBeanDefinition("mvcPathMatcher")) {
/* 144 */       RootBeanDefinition pathMatcherDef = new RootBeanDefinition(AntPathMatcher.class);
/* 145 */       pathMatcherDef.setSource(source);
/* 146 */       pathMatcherDef.setRole(2);
/* 147 */       context.getRegistry().registerBeanDefinition("mvcPathMatcher", (BeanDefinition)pathMatcherDef);
/* 148 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)pathMatcherDef, "mvcPathMatcher"));
/*     */     } 
/* 150 */     return new RuntimeBeanReference("mvcPathMatcher");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static RuntimeBeanReference getCustomPatternParser(ParserContext context) {
/* 159 */     if (context.getRegistry().isAlias("mvcPatternParser")) {
/* 160 */       return new RuntimeBeanReference("mvcPatternParser");
/*     */     }
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeBeanReference registerPatternParser(@Nullable RuntimeBeanReference patternParserRef, ParserContext context, @Nullable Object source) {
/* 172 */     if (patternParserRef != null) {
/* 173 */       if (context.getRegistry().isAlias("mvcPatternParser")) {
/* 174 */         context.getRegistry().removeAlias("mvcPatternParser");
/*     */       }
/* 176 */       context.getRegistry().registerAlias(patternParserRef.getBeanName(), "mvcPatternParser");
/*     */     }
/* 178 */     else if (!context.getRegistry().isAlias("mvcPatternParser") && 
/* 179 */       !context.getRegistry().containsBeanDefinition("mvcPatternParser")) {
/* 180 */       RootBeanDefinition pathMatcherDef = new RootBeanDefinition(PathPatternParser.class);
/* 181 */       pathMatcherDef.setSource(source);
/* 182 */       pathMatcherDef.setRole(2);
/* 183 */       context.getRegistry().registerBeanDefinition("mvcPatternParser", (BeanDefinition)pathMatcherDef);
/* 184 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)pathMatcherDef, "mvcPatternParser"));
/*     */     } 
/* 186 */     return new RuntimeBeanReference("mvcPatternParser");
/*     */   }
/*     */   
/*     */   static void configurePathMatching(RootBeanDefinition handlerMappingDef, ParserContext context, @Nullable Object source) {
/* 190 */     Assert.isTrue(AbstractHandlerMapping.class.isAssignableFrom(handlerMappingDef.getBeanClass()), () -> "Handler mapping type [" + String.valueOf(handlerMappingDef.getTargetType()) + "] not supported");
/*     */     
/* 192 */     RuntimeBeanReference customPathMatcherRef = getCustomPathMatcher(context);
/* 193 */     RuntimeBeanReference customPatternParserRef = getCustomPatternParser(context);
/* 194 */     if (customPathMatcherRef != null) {
/* 195 */       handlerMappingDef.getPropertyValues().add("pathMatcher", customPathMatcherRef)
/* 196 */         .add("patternParser", null);
/*     */     }
/* 198 */     else if (customPatternParserRef != null) {
/* 199 */       handlerMappingDef.getPropertyValues().add("patternParser", customPatternParserRef);
/*     */     } else {
/*     */       
/* 202 */       handlerMappingDef.getPropertyValues().add("pathMatcher", 
/* 203 */           registerPathMatcher(null, context, source));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerBeanNameUrlHandlerMapping(ParserContext context, @Nullable Object source) {
/* 212 */     if (!context.getRegistry().containsBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME)) {
/* 213 */       RootBeanDefinition mappingDef = new RootBeanDefinition(BeanNameUrlHandlerMapping.class);
/* 214 */       mappingDef.setSource(source);
/* 215 */       mappingDef.setRole(2);
/* 216 */       mappingDef.getPropertyValues().add("order", Integer.valueOf(2));
/* 217 */       RuntimeBeanReference corsRef = registerCorsConfigurations(null, context, source);
/* 218 */       mappingDef.getPropertyValues().add("corsConfigurations", corsRef);
/* 219 */       configurePathMatching(mappingDef, context, source);
/* 220 */       context.getRegistry().registerBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME, (BeanDefinition)mappingDef);
/* 221 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)mappingDef, BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerHttpRequestHandlerAdapter(ParserContext context, @Nullable Object source) {
/* 230 */     if (!context.getRegistry().containsBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME)) {
/* 231 */       RootBeanDefinition adapterDef = new RootBeanDefinition(HttpRequestHandlerAdapter.class);
/* 232 */       adapterDef.setSource(source);
/* 233 */       adapterDef.setRole(2);
/* 234 */       context.getRegistry().registerBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME, (BeanDefinition)adapterDef);
/* 235 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)adapterDef, HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerSimpleControllerHandlerAdapter(ParserContext context, @Nullable Object source) {
/* 244 */     if (!context.getRegistry().containsBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME)) {
/* 245 */       RootBeanDefinition beanDef = new RootBeanDefinition(SimpleControllerHandlerAdapter.class);
/* 246 */       beanDef.setSource(source);
/* 247 */       beanDef.setRole(2);
/* 248 */       context.getRegistry().registerBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME, (BeanDefinition)beanDef);
/* 249 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeBeanReference registerCorsConfigurations(@Nullable Map<String, CorsConfiguration> corsConfigurations, ParserContext context, @Nullable Object source) {
/* 263 */     if (!context.getRegistry().containsBeanDefinition("mvcCorsConfigurations")) {
/* 264 */       RootBeanDefinition corsDef = new RootBeanDefinition(LinkedHashMap.class);
/* 265 */       corsDef.setSource(source);
/* 266 */       corsDef.setRole(2);
/* 267 */       if (corsConfigurations != null) {
/* 268 */         corsDef.getConstructorArgumentValues().addIndexedArgumentValue(0, corsConfigurations);
/*     */       }
/* 270 */       context.getReaderContext().getRegistry().registerBeanDefinition("mvcCorsConfigurations", (BeanDefinition)corsDef);
/* 271 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)corsDef, "mvcCorsConfigurations"));
/*     */     }
/* 273 */     else if (corsConfigurations != null) {
/* 274 */       BeanDefinition corsDef = context.getRegistry().getBeanDefinition("mvcCorsConfigurations");
/* 275 */       corsDef.getConstructorArgumentValues().addIndexedArgumentValue(0, corsConfigurations);
/*     */     } 
/* 277 */     return new RuntimeBeanReference("mvcCorsConfigurations");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerHandlerMappingIntrospector(ParserContext context, @Nullable Object source) {
/* 285 */     if (!context.getRegistry().containsBeanDefinition("mvcHandlerMappingIntrospector")) {
/* 286 */       RootBeanDefinition beanDef = new RootBeanDefinition(HandlerMappingIntrospector.class);
/* 287 */       beanDef.setSource(source);
/* 288 */       beanDef.setRole(2);
/* 289 */       beanDef.setLazyInit(true);
/* 290 */       context.getRegistry().registerBeanDefinition("mvcHandlerMappingIntrospector", (BeanDefinition)beanDef);
/* 291 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, "mvcHandlerMappingIntrospector"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerLocaleResolver(ParserContext context, @Nullable Object source) {
/* 300 */     if (!containsBeanInHierarchy(context, "localeResolver")) {
/* 301 */       RootBeanDefinition beanDef = new RootBeanDefinition(AcceptHeaderLocaleResolver.class);
/* 302 */       beanDef.setSource(source);
/* 303 */       beanDef.setRole(2);
/* 304 */       context.getRegistry().registerBeanDefinition("localeResolver", (BeanDefinition)beanDef);
/* 305 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, "localeResolver"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerThemeResolver(ParserContext context, @Nullable Object source) {
/* 315 */     if (!containsBeanInHierarchy(context, "themeResolver")) {
/* 316 */       RootBeanDefinition beanDef = new RootBeanDefinition(FixedThemeResolver.class);
/* 317 */       beanDef.setSource(source);
/* 318 */       beanDef.setRole(2);
/* 319 */       context.getRegistry().registerBeanDefinition("themeResolver", (BeanDefinition)beanDef);
/* 320 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, "themeResolver"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerViewNameTranslator(ParserContext context, @Nullable Object source) {
/* 329 */     if (!containsBeanInHierarchy(context, "viewNameTranslator")) {
/* 330 */       RootBeanDefinition beanDef = new RootBeanDefinition(DefaultRequestToViewNameTranslator.class);
/* 331 */       beanDef.setSource(source);
/* 332 */       beanDef.setRole(2);
/* 333 */       context.getRegistry().registerBeanDefinition("viewNameTranslator", (BeanDefinition)beanDef);
/*     */       
/* 335 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, "viewNameTranslator"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registerFlashMapManager(ParserContext context, @Nullable Object source) {
/* 345 */     if (!containsBeanInHierarchy(context, "flashMapManager")) {
/* 346 */       RootBeanDefinition beanDef = new RootBeanDefinition(SessionFlashMapManager.class);
/* 347 */       beanDef.setSource(source);
/* 348 */       beanDef.setRole(2);
/* 349 */       context.getRegistry().registerBeanDefinition("flashMapManager", (BeanDefinition)beanDef);
/* 350 */       context.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)beanDef, "flashMapManager"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object getContentNegotiationManager(ParserContext context) {
/* 361 */     String name = AnnotationDrivenBeanDefinitionParser.HANDLER_MAPPING_BEAN_NAME;
/* 362 */     if (context.getRegistry().containsBeanDefinition(name)) {
/* 363 */       BeanDefinition handlerMappingBeanDef = context.getRegistry().getBeanDefinition(name);
/* 364 */       return handlerMappingBeanDef.getPropertyValues().get("contentNegotiationManager");
/*     */     } 
/* 366 */     name = "mvcContentNegotiationManager";
/* 367 */     if (context.getRegistry().containsBeanDefinition(name)) {
/* 368 */       return new RuntimeBeanReference(name);
/*     */     }
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean containsBeanInHierarchy(ParserContext context, String beanName) {
/* 380 */     BeanDefinitionRegistry registry = context.getRegistry();
/* 381 */     BeanFactory beanFactory = (BeanFactory)registry; return (registry instanceof BeanFactory) ? beanFactory.containsBean(beanName) : 
/* 382 */       registry.containsBeanDefinition(beanName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\MvcNamespaceUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */