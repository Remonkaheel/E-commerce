/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathMatchConfigurer
/*     */ {
/*     */   private boolean preferPathMatcher = false;
/*     */   @Nullable
/*     */   private PathPatternParser patternParser;
/*     */   @Nullable
/*     */   private Boolean trailingSlashMatch;
/*     */   @Nullable
/*     */   private Map<String, Predicate<Class<?>>> pathPrefixes;
/*     */   @Nullable
/*     */   private Boolean suffixPatternMatch;
/*     */   @Nullable
/*     */   private Boolean registeredSuffixPatternMatch;
/*     */   @Nullable
/*     */   private UrlPathHelper urlPathHelper;
/*     */   @Nullable
/*     */   private PathMatcher pathMatcher;
/*     */   @Nullable
/*     */   private PathPatternParser defaultPatternParser;
/*     */   @Nullable
/*     */   private UrlPathHelper defaultUrlPathHelper;
/*     */   @Nullable
/*     */   private PathMatcher defaultPathMatcher;
/*     */   
/*     */   public PathMatchConfigurer setPatternParser(@Nullable PathPatternParser patternParser) {
/* 101 */     this.patternParser = patternParser;
/* 102 */     this.preferPathMatcher = (patternParser == null);
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public PathMatchConfigurer setUseTrailingSlashMatch(Boolean trailingSlashMatch) {
/* 116 */     this.trailingSlashMatch = trailingSlashMatch;
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathMatchConfigurer addPathPrefix(String prefix, Predicate<Class<?>> predicate) {
/* 132 */     if (this.pathPrefixes == null) {
/* 133 */       this.pathPrefixes = new LinkedHashMap<>();
/*     */     }
/* 135 */     this.pathPrefixes.put(prefix, predicate);
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PathMatchConfigurer setUseSuffixPatternMatch(@Nullable Boolean suffixPatternMatch) {
/* 153 */     this.suffixPatternMatch = suffixPatternMatch;
/* 154 */     this.preferPathMatcher |= (suffixPatternMatch != null && suffixPatternMatch.booleanValue()) ? 1 : 0;
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PathMatchConfigurer setUseRegisteredSuffixPatternMatch(@Nullable Boolean registeredSuffixPatternMatch) {
/* 175 */     this.registeredSuffixPatternMatch = registeredSuffixPatternMatch;
/* 176 */     this.preferPathMatcher |= (registeredSuffixPatternMatch != null && registeredSuffixPatternMatch.booleanValue()) ? 1 : 0;
/* 177 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathMatchConfigurer setUrlPathHelper(UrlPathHelper urlPathHelper) {
/* 190 */     this.urlPathHelper = urlPathHelper;
/* 191 */     this.preferPathMatcher = true;
/* 192 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathMatchConfigurer setPathMatcher(PathMatcher pathMatcher) {
/* 205 */     this.pathMatcher = pathMatcher;
/* 206 */     this.preferPathMatcher = true;
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean preferPathMatcher() {
/* 221 */     return (this.patternParser == null && this.preferPathMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PathPatternParser getPatternParser() {
/* 230 */     return this.patternParser;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Boolean isUseTrailingSlashMatch() {
/* 236 */     return this.trailingSlashMatch;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Map<String, Predicate<Class<?>>> getPathPrefixes() {
/* 241 */     return this.pathPrefixes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Boolean isUseRegisteredSuffixPatternMatch() {
/* 252 */     return this.registeredSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Boolean isUseSuffixPatternMatch() {
/* 263 */     return this.suffixPatternMatch;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 268 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public PathMatcher getPathMatcher() {
/* 273 */     return this.pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UrlPathHelper getUrlPathHelperOrDefault() {
/* 281 */     if (this.urlPathHelper != null) {
/* 282 */       return this.urlPathHelper;
/*     */     }
/* 284 */     if (this.defaultUrlPathHelper == null) {
/* 285 */       this.defaultUrlPathHelper = new UrlPathHelper();
/*     */     }
/* 287 */     return this.defaultUrlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PathMatcher getPathMatcherOrDefault() {
/* 295 */     if (this.pathMatcher != null) {
/* 296 */       return this.pathMatcher;
/*     */     }
/* 298 */     if (this.defaultPathMatcher == null) {
/* 299 */       this.defaultPathMatcher = (PathMatcher)new AntPathMatcher();
/*     */     }
/* 301 */     return this.defaultPathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathPatternParser getPatternParserOrDefault() {
/* 309 */     if (this.patternParser != null) {
/* 310 */       return this.patternParser;
/*     */     }
/* 312 */     if (this.defaultPatternParser == null) {
/* 313 */       this.defaultPatternParser = new PathPatternParser();
/*     */     }
/* 315 */     return this.defaultPatternParser;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\PathMatchConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */