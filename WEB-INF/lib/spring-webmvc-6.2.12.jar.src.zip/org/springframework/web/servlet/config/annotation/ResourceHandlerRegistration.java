/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHandlerRegistration
/*     */ {
/*     */   private final String[] pathPatterns;
/*  45 */   private final List<String> locationValues = new ArrayList<>();
/*     */   
/*  47 */   private final List<Resource> locationsResources = new ArrayList<>();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Integer cachePeriod;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private CacheControl cacheControl;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ResourceChainRegistration resourceChainRegistration;
/*     */ 
/*     */   
/*     */   private boolean useLastModified = true;
/*     */   
/*     */   @Nullable
/*     */   private Function<Resource, String> etagGenerator;
/*     */   
/*     */   private boolean optimizeLocations = false;
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration(String... pathPatterns) {
/*  71 */     Assert.notEmpty((Object[])pathPatterns, "At least one path pattern is required for resource handling.");
/*  72 */     this.pathPatterns = pathPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration addResourceLocations(String... locations) {
/*  95 */     this.locationValues.addAll(Arrays.asList(locations));
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration addResourceLocations(Resource... locations) {
/* 108 */     this.locationsResources.addAll(Arrays.asList(locations));
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration setCachePeriod(Integer cachePeriod) {
/* 120 */     this.cachePeriod = cachePeriod;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration setCacheControl(CacheControl cacheControl) {
/* 133 */     this.cacheControl = cacheControl;
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration setUseLastModified(boolean useLastModified) {
/* 146 */     this.useLastModified = useLastModified;
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration setEtagGenerator(@Nullable Function<Resource, String> etagGenerator) {
/* 161 */     this.etagGenerator = etagGenerator;
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration setOptimizeLocations(boolean optimizeLocations) {
/* 178 */     this.optimizeLocations = optimizeLocations;
/* 179 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceChainRegistration resourceChain(boolean cacheResources) {
/* 195 */     this.resourceChainRegistration = new ResourceChainRegistration(cacheResources);
/* 196 */     return this.resourceChainRegistration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceChainRegistration resourceChain(boolean cacheResources, Cache cache) {
/* 217 */     this.resourceChainRegistration = new ResourceChainRegistration(cacheResources, cache);
/* 218 */     return this.resourceChainRegistration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getPathPatterns() {
/* 226 */     return this.pathPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceHttpRequestHandler getRequestHandler() {
/* 233 */     ResourceHttpRequestHandler handler = new ResourceHttpRequestHandler();
/* 234 */     if (this.resourceChainRegistration != null) {
/* 235 */       handler.setResourceResolvers(this.resourceChainRegistration.getResourceResolvers());
/* 236 */       handler.setResourceTransformers(this.resourceChainRegistration.getResourceTransformers());
/*     */     } 
/* 238 */     handler.setLocationValues(this.locationValues);
/* 239 */     handler.setLocations(this.locationsResources);
/* 240 */     if (this.cacheControl != null) {
/* 241 */       handler.setCacheControl(this.cacheControl);
/*     */     }
/* 243 */     else if (this.cachePeriod != null) {
/* 244 */       handler.setCacheSeconds(this.cachePeriod.intValue());
/*     */     } 
/* 246 */     handler.setUseLastModified(this.useLastModified);
/* 247 */     handler.setEtagGenerator(this.etagGenerator);
/* 248 */     handler.setOptimizeLocations(this.optimizeLocations);
/* 249 */     return handler;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\ResourceHandlerRegistration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */