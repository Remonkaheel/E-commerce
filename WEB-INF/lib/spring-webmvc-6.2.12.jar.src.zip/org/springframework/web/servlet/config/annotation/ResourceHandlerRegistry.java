/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHandlerRegistry
/*     */ {
/*     */   private final ServletContext servletContext;
/*     */   private final ApplicationContext applicationContext;
/*     */   @Nullable
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */   @Nullable
/*     */   private final UrlPathHelper pathHelper;
/*  75 */   private final List<ResourceHandlerRegistration> registrations = new ArrayList<>();
/*     */   
/*  77 */   private int order = 2147483646;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistry(ApplicationContext applicationContext, ServletContext servletContext) {
/*  86 */     this(applicationContext, servletContext, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistry(ApplicationContext applicationContext, ServletContext servletContext, @Nullable ContentNegotiationManager contentNegotiationManager) {
/*  99 */     this(applicationContext, servletContext, contentNegotiationManager, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistry(ApplicationContext applicationContext, ServletContext servletContext, @Nullable ContentNegotiationManager contentNegotiationManager, @Nullable UrlPathHelper pathHelper) {
/* 111 */     Assert.notNull(applicationContext, "ApplicationContext is required");
/* 112 */     this.applicationContext = applicationContext;
/* 113 */     this.servletContext = servletContext;
/* 114 */     this.contentNegotiationManager = contentNegotiationManager;
/* 115 */     this.pathHelper = pathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistration addResourceHandler(String... pathPatterns) {
/* 130 */     ResourceHandlerRegistration registration = new ResourceHandlerRegistration(pathPatterns);
/* 131 */     this.registrations.add(registration);
/* 132 */     return registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMappingForPattern(String pathPattern) {
/* 139 */     for (ResourceHandlerRegistration registration : this.registrations) {
/* 140 */       if (Arrays.<String>asList(registration.getPathPatterns()).contains(pathPattern)) {
/* 141 */         return true;
/*     */       }
/*     */     } 
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHandlerRegistry setOrder(int order) {
/* 153 */     this.order = order;
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected AbstractHandlerMapping getHandlerMapping() {
/* 163 */     if (this.registrations.isEmpty()) {
/* 164 */       return null;
/*     */     }
/* 166 */     Map<String, HttpRequestHandler> urlMap = new LinkedHashMap<>();
/* 167 */     for (ResourceHandlerRegistration registration : this.registrations) {
/* 168 */       ResourceHttpRequestHandler handler = getRequestHandler(registration);
/* 169 */       for (String pathPattern : registration.getPathPatterns()) {
/* 170 */         urlMap.put(pathPattern, handler);
/*     */       }
/*     */     } 
/* 173 */     return (AbstractHandlerMapping)new SimpleUrlHandlerMapping(urlMap, this.order);
/*     */   }
/*     */ 
/*     */   
/*     */   private ResourceHttpRequestHandler getRequestHandler(ResourceHandlerRegistration registration) {
/* 178 */     ResourceHttpRequestHandler handler = registration.getRequestHandler();
/* 179 */     if (this.pathHelper != null) {
/* 180 */       handler.setUrlPathHelper(this.pathHelper);
/*     */     }
/* 182 */     if (this.contentNegotiationManager != null) {
/* 183 */       handler.setContentNegotiationManager(this.contentNegotiationManager);
/*     */     }
/* 185 */     handler.setServletContext(this.servletContext);
/* 186 */     handler.setApplicationContext(this.applicationContext);
/*     */     try {
/* 188 */       handler.afterPropertiesSet();
/*     */     }
/* 190 */     catch (Throwable ex) {
/* 191 */       throw new BeanInitializationException("Failed to init ResourceHttpRequestHandler", ex);
/*     */     } 
/* 193 */     return handler;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\ResourceHandlerRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */