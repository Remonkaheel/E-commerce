/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorsRegistration
/*     */ {
/*     */   private final String pathPattern;
/*     */   private CorsConfiguration config;
/*     */   
/*     */   public CorsRegistration(String pathPattern) {
/*  43 */     this.pathPattern = pathPattern;
/*     */     
/*  45 */     this.config = (new CorsConfiguration()).applyPermitDefaultValues();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration allowedOrigins(String... origins) {
/*  60 */     this.config.setAllowedOrigins(Arrays.asList(origins));
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration allowedOriginPatterns(String... patterns) {
/*  74 */     this.config.setAllowedOriginPatterns(Arrays.asList(patterns));
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration allowedMethods(String... methods) {
/*  87 */     this.config.setAllowedMethods(Arrays.asList(methods));
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration allowedHeaders(String... headers) {
/* 100 */     this.config.setAllowedHeaders(Arrays.asList(headers));
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration exposedHeaders(String... headers) {
/* 113 */     this.config.setExposedHeaders(Arrays.asList(headers));
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration allowCredentials(boolean allowCredentials) {
/* 131 */     this.config.setAllowCredentials(Boolean.valueOf(allowCredentials));
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration allowPrivateNetwork(boolean allowPrivateNetwork) {
/* 142 */     this.config.setAllowPrivateNetwork(Boolean.valueOf(allowPrivateNetwork));
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration maxAge(long maxAge) {
/* 152 */     this.config.setMaxAge(Long.valueOf(maxAge));
/* 153 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsRegistration combine(CorsConfiguration other) {
/* 164 */     this.config = this.config.combine(other);
/* 165 */     return this;
/*     */   }
/*     */   
/*     */   protected String getPathPattern() {
/* 169 */     return this.pathPattern;
/*     */   }
/*     */   
/*     */   protected CorsConfiguration getCorsConfiguration() {
/* 173 */     return this.config;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\config\annotation\CorsRegistration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */