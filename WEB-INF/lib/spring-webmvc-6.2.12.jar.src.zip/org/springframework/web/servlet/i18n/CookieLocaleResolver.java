/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.time.Duration;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CookieLocaleResolver
/*     */   extends AbstractLocaleContextResolver
/*     */ {
/*  73 */   public static final String LOCALE_REQUEST_ATTRIBUTE_NAME = CookieLocaleResolver.class.getName() + ".LOCALE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final String TIME_ZONE_REQUEST_ATTRIBUTE_NAME = CookieLocaleResolver.class.getName() + ".TIME_ZONE";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final String DEFAULT_COOKIE_NAME = CookieLocaleResolver.class.getName() + ".LOCALE";
/*     */   
/*  91 */   private static final Log logger = LogFactory.getLog(CookieLocaleResolver.class);
/*     */   
/*     */   private ResponseCookie cookie;
/*     */   private boolean languageTagCompliant = true;
/*     */   private boolean rejectInvalidCookies = true;
/*     */   private Function<HttpServletRequest, Locale> defaultLocaleFunction;
/*     */   private Function<HttpServletRequest, TimeZone> defaultTimeZoneFunction;
/*     */   
/*     */   public CookieLocaleResolver(String cookieName) {
/* 100 */     this.defaultLocaleFunction = (request -> {
/*     */         Locale defaultLocale = getDefaultLocale();
/*     */         
/*     */         return (defaultLocale != null) ? defaultLocale : request.getLocale();
/*     */       });
/* 105 */     this.defaultTimeZoneFunction = (request -> getDefaultTimeZone());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     Assert.notNull(cookieName, "'cookieName' must not be null");
/* 114 */     this.cookie = ResponseCookie.from(cookieName).path("/").sameSite("Lax").build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CookieLocaleResolver() {
/* 121 */     this(DEFAULT_COOKIE_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setCookieName(String cookieName) {
/* 132 */     Assert.notNull(cookieName, "cookieName must not be null");
/* 133 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       .cookie = ResponseCookie.from(cookieName).maxAge(this.cookie.getMaxAge()).domain(this.cookie.getDomain()).path(this.cookie.getPath()).secure(this.cookie.isSecure()).httpOnly(this.cookie.isHttpOnly()).sameSite(this.cookie.getSameSite()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieMaxAge(Duration cookieMaxAge) {
/* 152 */     Assert.notNull(cookieMaxAge, "'cookieMaxAge' must not be null");
/* 153 */     this.cookie = this.cookie.mutate().maxAge(cookieMaxAge).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setCookieMaxAge(@Nullable Integer cookieMaxAge) {
/* 162 */     setCookieMaxAge(Duration.ofSeconds((cookieMaxAge != null) ? cookieMaxAge.intValue() : -1L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookiePath(@Nullable String cookiePath) {
/* 171 */     this.cookie = this.cookie.mutate().path(cookiePath).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieDomain(@Nullable String cookieDomain) {
/* 179 */     this.cookie = this.cookie.mutate().domain(cookieDomain).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieSecure(boolean cookieSecure) {
/* 187 */     this.cookie = this.cookie.mutate().secure(cookieSecure).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly) {
/* 195 */     this.cookie = this.cookie.mutate().httpOnly(cookieHttpOnly).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieSameSite(String cookieSameSite) {
/* 205 */     Assert.notNull(cookieSameSite, "cookieSameSite must not be null");
/* 206 */     this.cookie = this.cookie.mutate().sameSite(cookieSameSite).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLanguageTagCompliant(boolean languageTagCompliant) {
/* 223 */     this.languageTagCompliant = languageTagCompliant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLanguageTagCompliant() {
/* 232 */     return this.languageTagCompliant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRejectInvalidCookies(boolean rejectInvalidCookies) {
/* 246 */     this.rejectInvalidCookies = rejectInvalidCookies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRejectInvalidCookies() {
/* 254 */     return this.rejectInvalidCookies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultLocaleFunction(Function<HttpServletRequest, Locale> defaultLocaleFunction) {
/* 270 */     Assert.notNull(defaultLocaleFunction, "defaultLocaleFunction must not be null");
/* 271 */     this.defaultLocaleFunction = defaultLocaleFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTimeZoneFunction(Function<HttpServletRequest, TimeZone> defaultTimeZoneFunction) {
/* 284 */     Assert.notNull(defaultTimeZoneFunction, "defaultTimeZoneFunction must not be null");
/* 285 */     this.defaultTimeZoneFunction = defaultTimeZoneFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale resolveLocale(HttpServletRequest request) {
/* 291 */     parseLocaleCookieIfNecessary(request);
/* 292 */     return (Locale)request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request) {
/* 297 */     parseLocaleCookieIfNecessary(request);
/* 298 */     return (LocaleContext)new TimeZoneAwareLocaleContext()
/*     */       {
/*     */         @Nullable
/*     */         public Locale getLocale() {
/* 302 */           return (Locale)request.getAttribute(CookieLocaleResolver.LOCALE_REQUEST_ATTRIBUTE_NAME);
/*     */         }
/*     */         
/*     */         @Nullable
/*     */         public TimeZone getTimeZone() {
/* 307 */           return (TimeZone)request.getAttribute(CookieLocaleResolver.TIME_ZONE_REQUEST_ATTRIBUTE_NAME);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private void parseLocaleCookieIfNecessary(HttpServletRequest request) {
/* 313 */     if (request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME) == null) {
/* 314 */       Locale locale = null;
/* 315 */       TimeZone timeZone = null;
/*     */ 
/*     */       
/* 318 */       Cookie cookie = WebUtils.getCookie(request, this.cookie.getName());
/* 319 */       if (cookie != null) {
/* 320 */         String value = cookie.getValue();
/* 321 */         String localePart = value;
/* 322 */         String timeZonePart = null;
/* 323 */         int separatorIndex = localePart.indexOf('/');
/* 324 */         if (separatorIndex == -1)
/*     */         {
/* 326 */           separatorIndex = localePart.indexOf(' ');
/*     */         }
/* 328 */         if (separatorIndex >= 0) {
/* 329 */           localePart = value.substring(0, separatorIndex);
/* 330 */           timeZonePart = value.substring(separatorIndex + 1);
/*     */         } 
/*     */         try {
/* 333 */           locale = !"-".equals(localePart) ? parseLocaleValue(localePart) : null;
/* 334 */           if (timeZonePart != null) {
/* 335 */             timeZone = StringUtils.parseTimeZoneString(timeZonePart);
/*     */           }
/*     */         }
/* 338 */         catch (IllegalArgumentException ex) {
/* 339 */           if (isRejectInvalidCookies() && request
/* 340 */             .getAttribute("jakarta.servlet.error.exception") == null) {
/* 341 */             throw new IllegalStateException("Encountered invalid locale cookie '" + this.cookie
/* 342 */                 .getName() + "': [" + value + "] due to: " + ex.getMessage());
/*     */           }
/*     */ 
/*     */           
/* 346 */           if (logger.isDebugEnabled()) {
/* 347 */             logger.debug("Ignoring invalid locale cookie '" + this.cookie.getName() + "': [" + value + "] due to: " + ex
/* 348 */                 .getMessage());
/*     */           }
/*     */         } 
/*     */         
/* 352 */         if (logger.isTraceEnabled()) {
/* 353 */           logger.trace("Parsed cookie value [" + cookie.getValue() + "] into locale '" + String.valueOf(locale) + "'" + (
/* 354 */               (timeZone != null) ? (" and time zone '" + timeZone.getID() + "'") : ""));
/*     */         }
/*     */       } 
/*     */       
/* 358 */       request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, 
/* 359 */           (locale != null) ? locale : this.defaultLocaleFunction.apply(request));
/* 360 */       request.setAttribute(TIME_ZONE_REQUEST_ATTRIBUTE_NAME, 
/* 361 */           (timeZone != null) ? timeZone : this.defaultTimeZoneFunction.apply(request));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocaleContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable LocaleContext localeContext) {
/* 369 */     Assert.notNull(response, "HttpServletResponse is required for CookieLocaleResolver");
/*     */     
/* 371 */     Locale locale = null;
/* 372 */     TimeZone zone = null;
/* 373 */     if (localeContext != null) {
/* 374 */       locale = localeContext.getLocale();
/* 375 */       if (localeContext instanceof TimeZoneAwareLocaleContext) { TimeZoneAwareLocaleContext timeZoneAwareLocaleContext = (TimeZoneAwareLocaleContext)localeContext;
/* 376 */         zone = timeZoneAwareLocaleContext.getTimeZone(); }
/*     */       
/* 378 */       String value = ((locale != null) ? toLocaleValue(locale) : "-") + ((locale != null) ? toLocaleValue(locale) : "-");
/* 379 */       this.cookie = this.cookie.mutate().value(value).build();
/*     */     } 
/* 381 */     response.addHeader("Set-Cookie", this.cookie.toString());
/* 382 */     request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, 
/* 383 */         (locale != null) ? locale : this.defaultLocaleFunction.apply(request));
/* 384 */     request.setAttribute(TIME_ZONE_REQUEST_ATTRIBUTE_NAME, 
/* 385 */         (zone != null) ? zone : this.defaultTimeZoneFunction.apply(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Locale parseLocaleValue(String localeValue) {
/* 400 */     return StringUtils.parseLocale(localeValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toLocaleValue(Locale locale) {
/* 414 */     return isLanguageTagCompliant() ? locale.toLanguageTag() : locale.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request) {
/* 431 */     return this.defaultLocaleFunction.apply(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   @Nullable
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request) {
/* 447 */     return this.defaultTimeZoneFunction.apply(request);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\CookieLocaleResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */