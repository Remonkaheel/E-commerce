/*    */ package org.springframework.web.servlet.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.LocaleResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractLocaleResolver
/*    */   implements LocaleResolver
/*    */ {
/*    */   @Nullable
/*    */   private Locale defaultLocale;
/*    */   
/*    */   public void setDefaultLocale(@Nullable Locale defaultLocale) {
/* 44 */     this.defaultLocale = defaultLocale;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected Locale getDefaultLocale() {
/* 53 */     return this.defaultLocale;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\AbstractLocaleResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */