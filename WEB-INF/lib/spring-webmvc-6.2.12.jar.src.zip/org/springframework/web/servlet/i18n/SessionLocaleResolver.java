/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionLocaleResolver
/*     */   extends AbstractLocaleContextResolver
/*     */ {
/*     */   public SessionLocaleResolver() {
/*  87 */     this.localeAttributeName = LOCALE_SESSION_ATTRIBUTE_NAME;
/*     */     
/*  89 */     this.timeZoneAttributeName = TIME_ZONE_SESSION_ATTRIBUTE_NAME;
/*     */     
/*  91 */     this.defaultLocaleFunction = (request -> {
/*     */         Locale defaultLocale = getDefaultLocale();
/*     */         
/*     */         return (defaultLocale != null) ? defaultLocale : request.getLocale();
/*     */       });
/*  96 */     this.defaultTimeZoneFunction = (request -> getDefaultTimeZone());
/*     */   }
/*     */ 
/*     */   
/*     */   public static final String LOCALE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".LOCALE";
/*     */   public static final String TIME_ZONE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".TIME_ZONE";
/*     */   private String localeAttributeName;
/*     */   
/*     */   public void setLocaleAttributeName(String localeAttributeName) {
/* 105 */     this.localeAttributeName = localeAttributeName;
/*     */   }
/*     */ 
/*     */   
/*     */   private String timeZoneAttributeName;
/*     */   
/*     */   private Function<HttpServletRequest, Locale> defaultLocaleFunction;
/*     */   private Function<HttpServletRequest, TimeZone> defaultTimeZoneFunction;
/*     */   
/*     */   public void setTimeZoneAttributeName(String timeZoneAttributeName) {
/* 115 */     this.timeZoneAttributeName = timeZoneAttributeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultLocaleFunction(Function<HttpServletRequest, Locale> defaultLocaleFunction) {
/* 131 */     Assert.notNull(defaultLocaleFunction, "defaultLocaleFunction must not be null");
/* 132 */     this.defaultLocaleFunction = defaultLocaleFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTimeZoneFunction(Function<HttpServletRequest, TimeZone> defaultTimeZoneFunction) {
/* 145 */     Assert.notNull(defaultTimeZoneFunction, "defaultTimeZoneFunction must not be null");
/* 146 */     this.defaultTimeZoneFunction = defaultTimeZoneFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale resolveLocale(HttpServletRequest request) {
/* 151 */     Locale locale = (Locale)WebUtils.getSessionAttribute(request, this.localeAttributeName);
/* 152 */     if (locale == null) {
/* 153 */       locale = this.defaultLocaleFunction.apply(request);
/*     */     }
/* 155 */     return locale;
/*     */   }
/*     */ 
/*     */   
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request) {
/* 160 */     return (LocaleContext)new TimeZoneAwareLocaleContext()
/*     */       {
/*     */         public Locale getLocale() {
/* 163 */           Locale locale = (Locale)WebUtils.getSessionAttribute(request, SessionLocaleResolver.this.localeAttributeName);
/* 164 */           if (locale == null) {
/* 165 */             locale = SessionLocaleResolver.this.defaultLocaleFunction.apply(request);
/*     */           }
/* 167 */           return locale;
/*     */         }
/*     */         
/*     */         @Nullable
/*     */         public TimeZone getTimeZone() {
/* 172 */           TimeZone timeZone = (TimeZone)WebUtils.getSessionAttribute(request, SessionLocaleResolver.this.timeZoneAttributeName);
/* 173 */           if (timeZone == null) {
/* 174 */             timeZone = SessionLocaleResolver.this.defaultTimeZoneFunction.apply(request);
/*     */           }
/* 176 */           return timeZone;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocaleContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable LocaleContext localeContext) {
/* 185 */     Locale locale = null;
/* 186 */     TimeZone timeZone = null;
/* 187 */     if (localeContext != null) {
/* 188 */       locale = localeContext.getLocale();
/* 189 */       if (localeContext instanceof TimeZoneAwareLocaleContext) { TimeZoneAwareLocaleContext timeZoneAwareLocaleContext = (TimeZoneAwareLocaleContext)localeContext;
/* 190 */         timeZone = timeZoneAwareLocaleContext.getTimeZone(); }
/*     */     
/*     */     } 
/* 193 */     WebUtils.setSessionAttribute(request, this.localeAttributeName, locale);
/* 194 */     WebUtils.setSessionAttribute(request, this.timeZoneAttributeName, timeZone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request) {
/* 213 */     return this.defaultLocaleFunction.apply(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   @Nullable
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request) {
/* 229 */     return this.defaultTimeZoneFunction.apply(request);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\SessionLocaleResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */