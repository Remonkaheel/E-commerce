/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocaleChangeInterceptor
/*     */   implements HandlerInterceptor
/*     */ {
/*     */   public static final String DEFAULT_PARAM_NAME = "locale";
/*  51 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  53 */   private String paramName = "locale";
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String[] httpMethods;
/*     */ 
/*     */   
/*     */   private boolean ignoreInvalidLocale = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParamName(String paramName) {
/*  66 */     this.paramName = paramName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParamName() {
/*  74 */     return this.paramName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpMethods(@Nullable String... httpMethods) {
/*  83 */     this.httpMethods = httpMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getHttpMethods() {
/*  92 */     return this.httpMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreInvalidLocale(boolean ignoreInvalidLocale) {
/* 100 */     this.ignoreInvalidLocale = ignoreInvalidLocale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoreInvalidLocale() {
/* 108 */     return this.ignoreInvalidLocale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException {
/* 116 */     String newLocale = request.getParameter(getParamName());
/* 117 */     if (newLocale != null && 
/* 118 */       checkHttpMethod(request.getMethod())) {
/* 119 */       LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
/* 120 */       if (localeResolver == null) {
/* 121 */         throw new IllegalStateException("No LocaleResolver found: not in a DispatcherServlet request?");
/*     */       }
/*     */       
/*     */       try {
/* 125 */         localeResolver.setLocale(request, response, parseLocaleValue(newLocale));
/*     */       }
/* 127 */       catch (IllegalArgumentException ex) {
/* 128 */         if (isIgnoreInvalidLocale()) {
/* 129 */           if (this.logger.isDebugEnabled()) {
/* 130 */             this.logger.debug("Ignoring invalid locale value [" + newLocale + "]: " + ex.getMessage());
/*     */           }
/*     */         } else {
/*     */           
/* 134 */           throw ex;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   private boolean checkHttpMethod(String currentMethod) {
/* 144 */     String[] configuredMethods = getHttpMethods();
/* 145 */     if (ObjectUtils.isEmpty((Object[])configuredMethods)) {
/* 146 */       return true;
/*     */     }
/* 148 */     for (String configuredMethod : configuredMethods) {
/* 149 */       if (configuredMethod.equalsIgnoreCase(currentMethod)) {
/* 150 */         return true;
/*     */       }
/*     */     } 
/* 153 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Locale parseLocaleValue(String localeValue) {
/* 166 */     return StringUtils.parseLocale(localeValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\LocaleChangeInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */