/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AcceptHeaderLocaleResolver
/*     */   extends AbstractLocaleResolver
/*     */ {
/*  50 */   private final List<Locale> supportedLocales = new ArrayList<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedLocales(List<Locale> locales) {
/*  72 */     this.supportedLocales.clear();
/*  73 */     this.supportedLocales.addAll(locales);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Locale> getSupportedLocales() {
/*  81 */     return this.supportedLocales;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale resolveLocale(HttpServletRequest request) {
/*  87 */     Locale defaultLocale = getDefaultLocale();
/*  88 */     if (defaultLocale != null && request.getHeader("Accept-Language") == null) {
/*  89 */       return defaultLocale;
/*     */     }
/*  91 */     Locale requestLocale = request.getLocale();
/*  92 */     List<Locale> supportedLocales = getSupportedLocales();
/*  93 */     if (supportedLocales.isEmpty() || supportedLocales.contains(requestLocale)) {
/*  94 */       return requestLocale;
/*     */     }
/*  96 */     Locale supportedLocale = findSupportedLocale(request, supportedLocales);
/*  97 */     if (supportedLocale != null) {
/*  98 */       return supportedLocale;
/*     */     }
/* 100 */     return (defaultLocale != null) ? defaultLocale : requestLocale;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Locale findSupportedLocale(HttpServletRequest request, List<Locale> supportedLocales) {
/* 105 */     Enumeration<Locale> requestLocales = request.getLocales();
/* 106 */     Locale languageMatch = null;
/* 107 */     while (requestLocales.hasMoreElements()) {
/* 108 */       Locale locale = requestLocales.nextElement();
/* 109 */       if (supportedLocales.contains(locale)) {
/* 110 */         if (languageMatch == null || languageMatch.getLanguage().equals(locale.getLanguage()))
/*     */         {
/* 112 */           return locale; } 
/*     */         continue;
/*     */       } 
/* 115 */       if (languageMatch == null)
/*     */       {
/* 117 */         for (Locale supportedLocale : supportedLocales) {
/* 118 */           if (!StringUtils.hasLength(supportedLocale.getCountry()) && supportedLocale
/* 119 */             .getLanguage().equals(locale.getLanguage())) {
/* 120 */             languageMatch = supportedLocale;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 126 */     return languageMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocale(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable Locale locale) {
/* 131 */     throw new UnsupportedOperationException("Cannot change HTTP Accept-Language header - use a different locale resolution strategy");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\AcceptHeaderLocaleResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */