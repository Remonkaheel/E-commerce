/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedLocaleResolver
/*     */   extends AbstractLocaleContextResolver
/*     */ {
/*     */   public FixedLocaleResolver() {
/*  51 */     setDefaultLocale(Locale.getDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FixedLocaleResolver(Locale locale) {
/*  59 */     setDefaultLocale(locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FixedLocaleResolver(Locale locale, TimeZone timeZone) {
/*  68 */     setDefaultLocale(locale);
/*  69 */     setDefaultTimeZone(timeZone);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale resolveLocale(HttpServletRequest request) {
/*  75 */     Locale locale = getDefaultLocale();
/*  76 */     if (locale == null) {
/*  77 */       locale = Locale.getDefault();
/*     */     }
/*  79 */     return locale;
/*     */   }
/*     */ 
/*     */   
/*     */   public LocaleContext resolveLocaleContext(HttpServletRequest request) {
/*  84 */     return (LocaleContext)new TimeZoneAwareLocaleContext()
/*     */       {
/*     */         @Nullable
/*     */         public Locale getLocale() {
/*  88 */           return FixedLocaleResolver.this.getDefaultLocale();
/*     */         }
/*     */         
/*     */         @Nullable
/*     */         public TimeZone getTimeZone() {
/*  93 */           return FixedLocaleResolver.this.getDefaultTimeZone();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocaleContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable LocaleContext localeContext) {
/* 102 */     throw new UnsupportedOperationException("Cannot change fixed locale - use a different locale resolution strategy");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\FixedLocaleResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */