/*    */ package org.springframework.web.servlet.i18n;
/*    */ 
/*    */ import java.util.TimeZone;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.LocaleContextResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractLocaleContextResolver
/*    */   extends AbstractLocaleResolver
/*    */   implements LocaleContextResolver
/*    */ {
/*    */   @Nullable
/*    */   private TimeZone defaultTimeZone;
/*    */   
/*    */   public void setDefaultTimeZone(@Nullable TimeZone defaultTimeZone) {
/* 46 */     this.defaultTimeZone = defaultTimeZone;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TimeZone getDefaultTimeZone() {
/* 55 */     return this.defaultTimeZone;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\i18n\AbstractLocaleContextResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */