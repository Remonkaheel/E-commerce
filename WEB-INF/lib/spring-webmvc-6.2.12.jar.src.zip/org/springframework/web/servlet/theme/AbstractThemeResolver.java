/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import org.springframework.web.servlet.ThemeResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.0")
/*    */ public abstract class AbstractThemeResolver
/*    */   implements ThemeResolver
/*    */ {
/*    */   public static final String ORIGINAL_DEFAULT_THEME_NAME = "theme";
/* 38 */   private String defaultThemeName = "theme";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDefaultThemeName(String defaultThemeName) {
/* 46 */     this.defaultThemeName = defaultThemeName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDefaultThemeName() {
/* 53 */     return this.defaultThemeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\theme\AbstractThemeResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */