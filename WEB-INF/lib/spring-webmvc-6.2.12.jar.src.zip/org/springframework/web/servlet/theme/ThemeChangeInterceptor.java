/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.servlet.HandlerInterceptor;
/*    */ import org.springframework.web.servlet.ThemeResolver;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.0")
/*    */ public class ThemeChangeInterceptor
/*    */   implements HandlerInterceptor
/*    */ {
/*    */   public static final String DEFAULT_PARAM_NAME = "theme";
/* 44 */   private String paramName = "theme";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParamName(String paramName) {
/* 52 */     this.paramName = paramName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getParamName() {
/* 60 */     return this.paramName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException {
/* 68 */     String newTheme = request.getParameter(this.paramName);
/* 69 */     if (newTheme != null) {
/* 70 */       ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(request);
/* 71 */       if (themeResolver == null) {
/* 72 */         throw new IllegalStateException("No ThemeResolver found: not in a DispatcherServlet request?");
/*    */       }
/* 74 */       themeResolver.setThemeName(request, response, newTheme);
/*    */     } 
/*    */     
/* 77 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\theme\ThemeChangeInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */