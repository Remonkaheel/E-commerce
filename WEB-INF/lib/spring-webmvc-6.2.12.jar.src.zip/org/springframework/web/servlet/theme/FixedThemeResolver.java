/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.0")
/*    */ public class FixedThemeResolver
/*    */   extends AbstractThemeResolver
/*    */ {
/*    */   public String resolveThemeName(HttpServletRequest request) {
/* 43 */     return getDefaultThemeName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setThemeName(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable String themeName) {
/* 50 */     throw new UnsupportedOperationException("Cannot change theme - use a different theme resolution strategy");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\theme\FixedThemeResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */