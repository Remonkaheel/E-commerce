/*     */ package org.springframework.web.servlet.theme;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.ThemeResolver;
/*     */ import org.springframework.web.util.CookieGenerator;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.0")
/*     */ public class CookieThemeResolver
/*     */   extends CookieGenerator
/*     */   implements ThemeResolver
/*     */ {
/*     */   public static final String ORIGINAL_DEFAULT_THEME_NAME = "theme";
/*  59 */   public static final String THEME_REQUEST_ATTRIBUTE_NAME = CookieThemeResolver.class.getName() + ".THEME";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final String DEFAULT_COOKIE_NAME = CookieThemeResolver.class.getName() + ".THEME";
/*     */ 
/*     */   
/*  67 */   private String defaultThemeName = "theme";
/*     */ 
/*     */   
/*     */   public CookieThemeResolver() {
/*  71 */     setCookieName(DEFAULT_COOKIE_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultThemeName(String defaultThemeName) {
/*  79 */     this.defaultThemeName = defaultThemeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultThemeName() {
/*  86 */     return this.defaultThemeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String resolveThemeName(HttpServletRequest request) {
/*  93 */     String themeName = (String)request.getAttribute(THEME_REQUEST_ATTRIBUTE_NAME);
/*  94 */     if (themeName != null) {
/*  95 */       return themeName;
/*     */     }
/*     */ 
/*     */     
/*  99 */     String cookieName = getCookieName();
/* 100 */     if (cookieName != null) {
/* 101 */       Cookie cookie = WebUtils.getCookie(request, cookieName);
/* 102 */       if (cookie != null) {
/* 103 */         String value = cookie.getValue();
/* 104 */         if (StringUtils.hasText(value)) {
/* 105 */           themeName = value;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 111 */     if (themeName == null) {
/* 112 */       themeName = getDefaultThemeName();
/*     */     }
/* 114 */     request.setAttribute(THEME_REQUEST_ATTRIBUTE_NAME, themeName);
/* 115 */     return themeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThemeName(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable String themeName) {
/* 122 */     Assert.notNull(response, "HttpServletResponse is required for CookieThemeResolver");
/*     */     
/* 124 */     if (StringUtils.hasText(themeName)) {
/*     */       
/* 126 */       request.setAttribute(THEME_REQUEST_ATTRIBUTE_NAME, themeName);
/* 127 */       addCookie(response, themeName);
/*     */     }
/*     */     else {
/*     */       
/* 131 */       request.setAttribute(THEME_REQUEST_ATTRIBUTE_NAME, getDefaultThemeName());
/* 132 */       removeCookie(response);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\theme\CookieThemeResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */