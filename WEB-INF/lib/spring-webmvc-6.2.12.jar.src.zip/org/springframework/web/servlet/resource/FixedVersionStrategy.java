/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedVersionStrategy
/*    */   extends AbstractVersionStrategy
/*    */ {
/*    */   private final String version;
/*    */   
/*    */   public FixedVersionStrategy(String version) {
/* 44 */     super(new AbstractVersionStrategy.PrefixVersionPathStrategy(version));
/* 45 */     this.version = version;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getResourceVersion(Resource resource) {
/* 51 */     return this.version;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\FixedVersionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */