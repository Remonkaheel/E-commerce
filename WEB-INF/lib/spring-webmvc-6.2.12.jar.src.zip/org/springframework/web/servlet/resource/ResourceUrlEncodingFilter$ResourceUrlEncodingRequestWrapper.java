/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceUrlEncodingRequestWrapper
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*     */   @Nullable
/*     */   private ResourceUrlProvider resourceUrlProvider;
/*     */   @Nullable
/*     */   private Integer indexLookupPath;
/*  78 */   private String prefixLookupPath = "";
/*     */   
/*     */   ResourceUrlEncodingRequestWrapper(HttpServletRequest request) {
/*  81 */     super(request);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object value) {
/*  86 */     super.setAttribute(name, value);
/*  87 */     if (ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR.equals(name) && 
/*  88 */       value instanceof ResourceUrlProvider) { ResourceUrlProvider urlProvider = (ResourceUrlProvider)value;
/*  89 */       initLookupPath(urlProvider); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private void initLookupPath(ResourceUrlProvider urlProvider) {
/*  95 */     this.resourceUrlProvider = urlProvider;
/*  96 */     if (this.indexLookupPath == null) {
/*  97 */       UrlPathHelper pathHelper = this.resourceUrlProvider.getUrlPathHelper();
/*  98 */       String requestUri = pathHelper.getRequestUri((HttpServletRequest)this);
/*  99 */       String lookupPath = pathHelper.getLookupPathForRequest((HttpServletRequest)this);
/* 100 */       this.indexLookupPath = Integer.valueOf(requestUri.lastIndexOf(lookupPath));
/* 101 */       if (this.indexLookupPath.intValue() == -1) {
/* 102 */         throw new ResourceUrlEncodingFilter.LookupPathIndexException(lookupPath, requestUri);
/*     */       }
/* 104 */       this.prefixLookupPath = requestUri.substring(0, this.indexLookupPath.intValue());
/* 105 */       if (StringUtils.matchesCharacter(lookupPath, '/') && !StringUtils.matchesCharacter(requestUri, '/')) {
/* 106 */         String contextPath = pathHelper.getContextPath((HttpServletRequest)this);
/* 107 */         if (requestUri.equals(contextPath)) {
/* 108 */           this.indexLookupPath = Integer.valueOf(requestUri.length());
/* 109 */           this.prefixLookupPath = requestUri;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String resolveUrlPath(String url) {
/* 117 */     if (this.resourceUrlProvider == null) {
/* 118 */       ResourceUrlEncodingFilter.logger.trace("ResourceUrlProvider not available via request attribute " + ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR);
/*     */       
/* 120 */       return null;
/*     */     } 
/* 122 */     if (this.indexLookupPath != null && url.startsWith(this.prefixLookupPath)) {
/* 123 */       int suffixIndex = getEndPathIndex(url);
/* 124 */       String suffix = url.substring(suffixIndex);
/* 125 */       String lookupPath = url.substring(this.indexLookupPath.intValue(), suffixIndex);
/* 126 */       lookupPath = this.resourceUrlProvider.getForLookupPath(lookupPath);
/* 127 */       if (lookupPath != null) {
/* 128 */         return this.prefixLookupPath + this.prefixLookupPath + lookupPath;
/*     */       }
/*     */     } 
/* 131 */     return null;
/*     */   }
/*     */   
/*     */   private int getEndPathIndex(String path) {
/* 135 */     int end = path.indexOf('?');
/* 136 */     int fragmentIndex = path.indexOf('#');
/* 137 */     if (fragmentIndex != -1 && (end == -1 || fragmentIndex < end)) {
/* 138 */       end = fragmentIndex;
/*     */     }
/* 140 */     if (end == -1) {
/* 141 */       end = path.length();
/*     */     }
/* 143 */     return end;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceUrlEncodingFilter$ResourceUrlEncodingRequestWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */