/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CssLinkResourceTransformer
/*     */   extends ResourceTransformerSupport
/*     */ {
/*  53 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */   
/*  55 */   private static final Log logger = LogFactory.getLog(CssLinkResourceTransformer.class);
/*     */   
/*  57 */   private final List<LinkParser> linkParsers = new ArrayList<>(2);
/*     */ 
/*     */   
/*     */   public CssLinkResourceTransformer() {
/*  61 */     this.linkParsers.add(new ImportStatementLinkParser());
/*  62 */     this.linkParsers.add(new UrlFunctionLinkParser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource transform(HttpServletRequest request, Resource resource, ResourceTransformerChain transformerChain) throws IOException {
/*  71 */     resource = transformerChain.transform(request, resource);
/*     */     
/*  73 */     String filename = resource.getFilename();
/*  74 */     if (!"css".equals(StringUtils.getFilenameExtension(filename)) || resource instanceof EncodedResourceResolver.EncodedResource)
/*     */     {
/*  76 */       return resource;
/*     */     }
/*     */     
/*  79 */     byte[] bytes = FileCopyUtils.copyToByteArray(resource.getInputStream());
/*  80 */     String content = new String(bytes, DEFAULT_CHARSET);
/*     */     
/*  82 */     SortedSet<ContentChunkInfo> links = new TreeSet<>();
/*  83 */     for (LinkParser parser : this.linkParsers) {
/*  84 */       parser.parse(content, links);
/*     */     }
/*     */     
/*  87 */     if (links.isEmpty()) {
/*  88 */       return resource;
/*     */     }
/*     */     
/*  91 */     int index = 0;
/*  92 */     StringWriter writer = new StringWriter();
/*  93 */     for (ContentChunkInfo linkContentChunkInfo : links) {
/*  94 */       writer.write(content.substring(index, linkContentChunkInfo.getStart()));
/*  95 */       String link = content.substring(linkContentChunkInfo.getStart(), linkContentChunkInfo.getEnd());
/*  96 */       String newLink = null;
/*  97 */       if (!hasScheme(link)) {
/*  98 */         String absolutePath = toAbsolutePath(link, request);
/*  99 */         newLink = resolveUrlPath(absolutePath, request, resource, transformerChain);
/*     */       } 
/* 101 */       writer.write((newLink != null) ? newLink : link);
/* 102 */       index = linkContentChunkInfo.getEnd();
/*     */     } 
/* 104 */     writer.write(content.substring(index));
/*     */     
/* 106 */     return (Resource)new TransformedResource(resource, writer.toString().getBytes(DEFAULT_CHARSET));
/*     */   }
/*     */   
/*     */   private boolean hasScheme(String link) {
/* 110 */     int schemeIndex = link.indexOf(':');
/* 111 */     return ((schemeIndex > 0 && !link.substring(0, schemeIndex).contains("/")) || link.indexOf("//") == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static abstract class AbstractLinkParser
/*     */     implements LinkParser
/*     */   {
/*     */     protected abstract String getKeyword();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void parse(String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> result) {
/* 136 */       int position = 0;
/*     */       while (true) {
/* 138 */         position = content.indexOf(getKeyword(), position);
/* 139 */         if (position == -1) {
/*     */           return;
/*     */         }
/* 142 */         position += getKeyword().length();
/* 143 */         while (Character.isWhitespace(content.charAt(position))) {
/* 144 */           position++;
/*     */         }
/* 146 */         if (content.charAt(position) == '\'') {
/* 147 */           position = extractLink(position, "'", content, result); continue;
/*     */         } 
/* 149 */         if (content.charAt(position) == '"') {
/* 150 */           position = extractLink(position, "\"", content, result);
/*     */           continue;
/*     */         } 
/* 153 */         position = extractLink(position, content, result);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected int extractLink(int index, String endKey, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd) {
/* 159 */       int start = index + 1;
/* 160 */       int end = content.indexOf(endKey, start);
/* 161 */       linksToAdd.add(new CssLinkResourceTransformer.ContentChunkInfo(start, end));
/* 162 */       return end + endKey.length();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract int extractLink(int param1Int, String param1String, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> param1SortedSet);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ImportStatementLinkParser
/*     */     extends AbstractLinkParser
/*     */   {
/*     */     protected String getKeyword() {
/* 177 */       return "@import";
/*     */     }
/*     */ 
/*     */     
/*     */     protected int extractLink(int index, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd) {
/* 182 */       if (!content.startsWith("url(", index))
/*     */       {
/*     */         
/* 185 */         if (CssLinkResourceTransformer.logger.isTraceEnabled())
/* 186 */           CssLinkResourceTransformer.logger.trace("Unexpected syntax for @import link at index " + index); 
/*     */       }
/* 188 */       return index;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class UrlFunctionLinkParser
/*     */     extends AbstractLinkParser
/*     */   {
/*     */     protected String getKeyword() {
/* 197 */       return "url(";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected int extractLink(int index, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd) {
/* 203 */       return extractLink(index - 1, ")", content, linksToAdd);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ContentChunkInfo
/*     */     implements Comparable<ContentChunkInfo>
/*     */   {
/*     */     private final int start;
/*     */     private final int end;
/*     */     
/*     */     ContentChunkInfo(int start, int end) {
/* 215 */       this.start = start;
/* 216 */       this.end = end;
/*     */     }
/*     */     
/*     */     public int getStart() {
/* 220 */       return this.start;
/*     */     }
/*     */     
/*     */     public int getEnd() {
/* 224 */       return this.end;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ContentChunkInfo other) {
/* 229 */       return Integer.compare(this.start, other.start);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 234 */       if (this != other) { if (other instanceof ContentChunkInfo) { ContentChunkInfo that = (ContentChunkInfo)other; if (this.start == that.start && this.end == that.end); }  return false; }
/*     */     
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 240 */       return this.start * 31 + this.end;
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface LinkParser {
/*     */     void parse(String param1String, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> param1SortedSet);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\CssLinkResourceTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */