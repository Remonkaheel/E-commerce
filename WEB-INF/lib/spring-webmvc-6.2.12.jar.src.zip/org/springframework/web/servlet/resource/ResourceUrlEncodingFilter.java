/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUrlEncodingFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  50 */   private static final Log logger = LogFactory.getLog(ResourceUrlEncodingFilter.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/*     */     HttpServletRequest httpRequest;
/*     */     HttpServletResponse httpResponse;
/*  57 */     if (request instanceof HttpServletRequest) { httpRequest = (HttpServletRequest)request; if (response instanceof HttpServletResponse) { httpResponse = (HttpServletResponse)response; }
/*  58 */       else { throw new ServletException("ResourceUrlEncodingFilter only supports HTTP requests"); }  } else { throw new ServletException("ResourceUrlEncodingFilter only supports HTTP requests"); }
/*     */ 
/*     */     
/*  61 */     ResourceUrlEncodingRequestWrapper wrappedRequest = new ResourceUrlEncodingRequestWrapper(httpRequest);
/*     */     
/*  63 */     ResourceUrlEncodingResponseWrapper wrappedResponse = new ResourceUrlEncodingResponseWrapper(wrappedRequest, httpResponse);
/*     */ 
/*     */     
/*  66 */     filterChain.doFilter((ServletRequest)wrappedRequest, (ServletResponse)wrappedResponse);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ResourceUrlEncodingRequestWrapper
/*     */     extends HttpServletRequestWrapper
/*     */   {
/*     */     @Nullable
/*     */     private ResourceUrlProvider resourceUrlProvider;
/*     */     
/*     */     @Nullable
/*     */     private Integer indexLookupPath;
/*  78 */     private String prefixLookupPath = "";
/*     */     
/*     */     ResourceUrlEncodingRequestWrapper(HttpServletRequest request) {
/*  81 */       super(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setAttribute(String name, Object value) {
/*  86 */       super.setAttribute(name, value);
/*  87 */       if (ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR.equals(name) && 
/*  88 */         value instanceof ResourceUrlProvider) { ResourceUrlProvider urlProvider = (ResourceUrlProvider)value;
/*  89 */         initLookupPath(urlProvider); }
/*     */     
/*     */     }
/*     */ 
/*     */     
/*     */     private void initLookupPath(ResourceUrlProvider urlProvider) {
/*  95 */       this.resourceUrlProvider = urlProvider;
/*  96 */       if (this.indexLookupPath == null) {
/*  97 */         UrlPathHelper pathHelper = this.resourceUrlProvider.getUrlPathHelper();
/*  98 */         String requestUri = pathHelper.getRequestUri((HttpServletRequest)this);
/*  99 */         String lookupPath = pathHelper.getLookupPathForRequest((HttpServletRequest)this);
/* 100 */         this.indexLookupPath = Integer.valueOf(requestUri.lastIndexOf(lookupPath));
/* 101 */         if (this.indexLookupPath.intValue() == -1) {
/* 102 */           throw new ResourceUrlEncodingFilter.LookupPathIndexException(lookupPath, requestUri);
/*     */         }
/* 104 */         this.prefixLookupPath = requestUri.substring(0, this.indexLookupPath.intValue());
/* 105 */         if (StringUtils.matchesCharacter(lookupPath, '/') && !StringUtils.matchesCharacter(requestUri, '/')) {
/* 106 */           String contextPath = pathHelper.getContextPath((HttpServletRequest)this);
/* 107 */           if (requestUri.equals(contextPath)) {
/* 108 */             this.indexLookupPath = Integer.valueOf(requestUri.length());
/* 109 */             this.prefixLookupPath = requestUri;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String resolveUrlPath(String url) {
/* 117 */       if (this.resourceUrlProvider == null) {
/* 118 */         ResourceUrlEncodingFilter.logger.trace("ResourceUrlProvider not available via request attribute " + ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR);
/*     */         
/* 120 */         return null;
/*     */       } 
/* 122 */       if (this.indexLookupPath != null && url.startsWith(this.prefixLookupPath)) {
/* 123 */         int suffixIndex = getEndPathIndex(url);
/* 124 */         String suffix = url.substring(suffixIndex);
/* 125 */         String lookupPath = url.substring(this.indexLookupPath.intValue(), suffixIndex);
/* 126 */         lookupPath = this.resourceUrlProvider.getForLookupPath(lookupPath);
/* 127 */         if (lookupPath != null) {
/* 128 */           return this.prefixLookupPath + this.prefixLookupPath + lookupPath;
/*     */         }
/*     */       } 
/* 131 */       return null;
/*     */     }
/*     */     
/*     */     private int getEndPathIndex(String path) {
/* 135 */       int end = path.indexOf('?');
/* 136 */       int fragmentIndex = path.indexOf('#');
/* 137 */       if (fragmentIndex != -1 && (end == -1 || fragmentIndex < end)) {
/* 138 */         end = fragmentIndex;
/*     */       }
/* 140 */       if (end == -1) {
/* 141 */         end = path.length();
/*     */       }
/* 143 */       return end;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ResourceUrlEncodingResponseWrapper
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private final ResourceUrlEncodingFilter.ResourceUrlEncodingRequestWrapper request;
/*     */     
/*     */     ResourceUrlEncodingResponseWrapper(ResourceUrlEncodingFilter.ResourceUrlEncodingRequestWrapper request, HttpServletResponse wrapped) {
/* 153 */       super(wrapped);
/* 154 */       this.request = request;
/*     */     }
/*     */ 
/*     */     
/*     */     public String encodeURL(String url) {
/* 159 */       String urlPath = this.request.resolveUrlPath(url);
/* 160 */       if (urlPath != null) {
/* 161 */         return super.encodeURL(urlPath);
/*     */       }
/* 163 */       return super.encodeURL(url);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class LookupPathIndexException
/*     */     extends IllegalArgumentException
/*     */   {
/*     */     LookupPathIndexException(String lookupPath, String requestUri) {
/* 177 */       super("Failed to find lookupPath '" + lookupPath + "' within requestUri '" + requestUri + "'. This could be because the path has invalid encoded characters or isn't normalized.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceUrlEncodingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */