/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.webjars.WebJarAssetLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2", forRemoval = true)
/*     */ public class WebJarsResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   private static final String WEBJARS_LOCATION = "META-INF/resources/webjars/";
/*  57 */   private static final int WEBJARS_LOCATION_LENGTH = "META-INF/resources/webjars/".length();
/*     */ 
/*     */ 
/*     */   
/*     */   private final WebJarAssetLocator webJarAssetLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebJarsResourceResolver() {
/*  67 */     this(new WebJarAssetLocator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebJarsResourceResolver(WebJarAssetLocator webJarAssetLocator) {
/*  76 */     this.webJarAssetLocator = webJarAssetLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/*  85 */     Resource resolved = chain.resolveResource(request, requestPath, locations);
/*  86 */     if (resolved == null) {
/*  87 */       String webJarResourcePath = findWebJarResourcePath(requestPath);
/*  88 */       if (webJarResourcePath != null) {
/*  89 */         return chain.resolveResource(request, webJarResourcePath, locations);
/*     */       }
/*     */     } 
/*  92 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 100 */     String path = chain.resolveUrlPath(resourceUrlPath, locations);
/* 101 */     if (path == null) {
/* 102 */       String webJarResourcePath = findWebJarResourcePath(resourceUrlPath);
/* 103 */       if (webJarResourcePath != null) {
/* 104 */         return chain.resolveUrlPath(webJarResourcePath, locations);
/*     */       }
/*     */     } 
/* 107 */     return path;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected String findWebJarResourcePath(String path) {
/* 112 */     int startOffset = path.startsWith("/") ? 1 : 0;
/* 113 */     int endOffset = path.indexOf('/', 1);
/* 114 */     if (endOffset != -1) {
/* 115 */       String webjar = path.substring(startOffset, endOffset);
/* 116 */       String partialPath = path.substring(endOffset + 1);
/* 117 */       String webJarPath = this.webJarAssetLocator.getFullPathExact(webjar, partialPath);
/* 118 */       if (webJarPath != null) {
/* 119 */         return webJarPath.substring(WEBJARS_LOCATION_LENGTH);
/*     */       }
/*     */     } 
/* 122 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\WebJarsResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */