package org.springframework.web.servlet.resource;

import org.springframework.lang.Nullable;

public interface VersionPathStrategy {
  @Nullable
  String extractVersion(String paramString);
  
  String removeVersion(String paramString1, String paramString2);
  
  String addVersion(String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\VersionPathStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */