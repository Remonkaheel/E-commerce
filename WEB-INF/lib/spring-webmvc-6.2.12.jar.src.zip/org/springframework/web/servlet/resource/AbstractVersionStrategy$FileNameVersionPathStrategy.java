/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileNameVersionPathStrategy
/*     */   implements VersionPathStrategy
/*     */ {
/* 123 */   private static final Pattern pattern = Pattern.compile("-(\\S*)\\.");
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String extractVersion(String requestPath) {
/* 128 */     Matcher matcher = pattern.matcher(requestPath);
/* 129 */     if (matcher.find()) {
/* 130 */       String match = matcher.group(1);
/* 131 */       return match.contains("-") ? match.substring(match.lastIndexOf('-') + 1) : match;
/*     */     } 
/*     */     
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String removeVersion(String requestPath, String version) {
/* 140 */     return StringUtils.delete(requestPath, "-" + version);
/*     */   }
/*     */ 
/*     */   
/*     */   public String addVersion(String requestPath, String version) {
/* 145 */     String baseFilename = StringUtils.stripFilenameExtension(requestPath);
/* 146 */     String extension = StringUtils.getFilenameExtension(requestPath);
/* 147 */     return baseFilename + "-" + baseFilename + "." + version;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\AbstractVersionStrategy$FileNameVersionPathStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */