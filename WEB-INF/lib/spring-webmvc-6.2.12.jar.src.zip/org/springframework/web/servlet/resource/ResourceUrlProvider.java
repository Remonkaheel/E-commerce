/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.handler.AbstractUrlHandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUrlProvider
/*     */   implements ApplicationListener<ContextRefreshedEvent>, ApplicationContextAware
/*     */ {
/*  56 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*  61 */   private UrlPathHelper urlPathHelper = UrlPathHelper.defaultInstance;
/*     */   
/*  63 */   private PathMatcher pathMatcher = (PathMatcher)new AntPathMatcher();
/*     */   
/*  65 */   private final Map<String, ResourceHttpRequestHandler> handlerMap = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   private boolean autodetect = true;
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  72 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
/*  81 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlPathHelper getUrlPathHelper() {
/*  89 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathMatcher(PathMatcher pathMatcher) {
/*  97 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathMatcher getPathMatcher() {
/* 104 */     return this.pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerMap(@Nullable Map<String, ResourceHttpRequestHandler> handlerMap) {
/* 114 */     if (handlerMap != null) {
/* 115 */       this.handlerMap.clear();
/* 116 */       this.handlerMap.putAll(handlerMap);
/* 117 */       this.autodetect = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ResourceHttpRequestHandler> getHandlerMap() {
/* 126 */     return this.handlerMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutodetect() {
/* 134 */     return this.autodetect;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ContextRefreshedEvent event) {
/* 140 */     if (event.getApplicationContext() == this.applicationContext && isAutodetect()) {
/* 141 */       this.handlerMap.clear();
/* 142 */       detectResourceHandlers(this.applicationContext);
/* 143 */       if (!this.handlerMap.isEmpty()) {
/* 144 */         this.autodetect = false;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void detectResourceHandlers(ApplicationContext appContext) {
/* 151 */     Objects.requireNonNull(AbstractUrlHandlerMapping.class);
/* 152 */     Objects.requireNonNull(AbstractUrlHandlerMapping.class); appContext.getBeanProvider(HandlerMapping.class).orderedStream().filter(AbstractUrlHandlerMapping.class::isInstance).map(AbstractUrlHandlerMapping.class::cast)
/* 153 */       .forEach(mapping -> mapping.getHandlerMap().forEach(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     if (this.handlerMap.isEmpty()) {
/* 160 */       this.logger.trace("No resource handling mappings found");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String getForRequestUrl(HttpServletRequest request, String requestUrl) {
/* 174 */     int prefixIndex = getLookupPathIndex(request);
/* 175 */     int suffixIndex = getEndPathIndex(requestUrl);
/* 176 */     if (prefixIndex >= suffixIndex) {
/* 177 */       return null;
/*     */     }
/* 179 */     String prefix = requestUrl.substring(0, prefixIndex);
/* 180 */     String suffix = requestUrl.substring(suffixIndex);
/* 181 */     String lookupPath = requestUrl.substring(prefixIndex, suffixIndex);
/* 182 */     String resolvedLookupPath = getForLookupPath(lookupPath);
/* 183 */     return (resolvedLookupPath != null) ? (prefix + prefix + resolvedLookupPath) : null;
/*     */   }
/*     */   
/*     */   private int getLookupPathIndex(HttpServletRequest request) {
/* 187 */     UrlPathHelper pathHelper = getUrlPathHelper();
/* 188 */     if (request.getAttribute(UrlPathHelper.PATH_ATTRIBUTE) == null) {
/* 189 */       pathHelper.resolveAndCacheLookupPath(request);
/*     */     }
/* 191 */     String requestUri = pathHelper.getRequestUri(request);
/* 192 */     String lookupPath = UrlPathHelper.getResolvedLookupPath((ServletRequest)request);
/* 193 */     return requestUri.indexOf(lookupPath);
/*     */   }
/*     */   
/*     */   private int getEndPathIndex(String lookupPath) {
/* 197 */     int suffixIndex = lookupPath.length();
/* 198 */     int queryIndex = lookupPath.indexOf('?');
/* 199 */     if (queryIndex > 0) {
/* 200 */       suffixIndex = queryIndex;
/*     */     }
/* 202 */     int hashIndex = lookupPath.indexOf('#');
/* 203 */     if (hashIndex > 0) {
/* 204 */       suffixIndex = Math.min(suffixIndex, hashIndex);
/*     */     }
/* 206 */     return suffixIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String getForLookupPath(String lookupPath) {
/*     */     String previous;
/*     */     do {
/* 227 */       previous = lookupPath;
/* 228 */       lookupPath = StringUtils.replace(lookupPath, "//", "/");
/* 229 */     } while (!lookupPath.equals(previous));
/*     */     
/* 231 */     List<String> matchingPatterns = new ArrayList<>();
/* 232 */     for (String pattern : this.handlerMap.keySet()) {
/* 233 */       if (getPathMatcher().match(pattern, lookupPath)) {
/* 234 */         matchingPatterns.add(pattern);
/*     */       }
/*     */     } 
/*     */     
/* 238 */     if (!matchingPatterns.isEmpty()) {
/* 239 */       Comparator<String> patternComparator = getPathMatcher().getPatternComparator(lookupPath);
/* 240 */       matchingPatterns.sort(patternComparator);
/* 241 */       for (String pattern : matchingPatterns) {
/* 242 */         String pathWithinMapping = getPathMatcher().extractPathWithinPattern(pattern, lookupPath);
/* 243 */         String pathMapping = lookupPath.substring(0, lookupPath.indexOf(pathWithinMapping));
/* 244 */         ResourceHttpRequestHandler handler = this.handlerMap.get(pattern);
/* 245 */         ResourceResolverChain chain = new DefaultResourceResolverChain(handler.getResourceResolvers());
/* 246 */         String resolved = chain.resolveUrlPath(pathWithinMapping, handler.getLocations());
/* 247 */         if (resolved == null) {
/*     */           continue;
/*     */         }
/* 250 */         return pathMapping + pathMapping;
/*     */       } 
/*     */     } 
/*     */     
/* 254 */     if (this.logger.isTraceEnabled()) {
/* 255 */       this.logger.trace("No match for \"" + lookupPath + "\"");
/*     */     }
/*     */     
/* 258 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceUrlProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */