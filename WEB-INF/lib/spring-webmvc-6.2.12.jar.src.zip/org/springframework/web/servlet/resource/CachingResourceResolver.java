/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   public static final String RESOLVED_RESOURCE_CACHE_KEY_PREFIX = "resolvedResource:";
/*     */   public static final String RESOLVED_URL_PATH_CACHE_KEY_PREFIX = "resolvedUrlPath:";
/*     */   private final Cache cache;
/*  60 */   private final List<String> contentCodings = new ArrayList<>(EncodedResourceResolver.DEFAULT_CODINGS);
/*     */ 
/*     */   
/*     */   public CachingResourceResolver(Cache cache) {
/*  64 */     Assert.notNull(cache, "Cache is required");
/*  65 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public CachingResourceResolver(CacheManager cacheManager, String cacheName) {
/*  69 */     Cache cache = cacheManager.getCache(cacheName);
/*  70 */     if (cache == null) {
/*  71 */       throw new IllegalArgumentException("Cache '" + cacheName + "' not found");
/*     */     }
/*  73 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cache getCache() {
/*  81 */     return this.cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentCodings(List<String> codings) {
/*  95 */     Assert.notEmpty(codings, "At least one content coding expected");
/*  96 */     this.contentCodings.clear();
/*  97 */     this.contentCodings.addAll(codings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getContentCodings() {
/* 105 */     return Collections.unmodifiableList(this.contentCodings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 114 */     String key = computeKey(request, requestPath);
/* 115 */     Resource resource = (Resource)this.cache.get(key, Resource.class);
/*     */     
/* 117 */     if (resource != null) {
/* 118 */       if (this.logger.isTraceEnabled()) {
/* 119 */         this.logger.trace("Resource resolved from cache");
/*     */       }
/* 121 */       return resource;
/*     */     } 
/*     */     
/* 124 */     resource = chain.resolveResource(request, requestPath, locations);
/* 125 */     if (resource != null) {
/* 126 */       this.cache.put(key, resource);
/*     */     }
/*     */     
/* 129 */     return resource;
/*     */   }
/*     */   
/*     */   protected String computeKey(@Nullable HttpServletRequest request, String requestPath) {
/* 133 */     if (request != null) {
/* 134 */       String codingKey = getContentCodingKey(request);
/* 135 */       if (StringUtils.hasText(codingKey)) {
/* 136 */         return "resolvedResource:" + requestPath + "+encoding=" + codingKey;
/*     */       }
/*     */     } 
/* 139 */     return "resolvedResource:" + requestPath;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getContentCodingKey(HttpServletRequest request) {
/* 144 */     String header = request.getHeader("Accept-Encoding");
/* 145 */     if (!StringUtils.hasText(header)) {
/* 146 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     Objects.requireNonNull(this.contentCodings); return Arrays.<String>stream(StringUtils.tokenizeToStringArray(header, ",")).map(token -> { int index = token.indexOf(';'); return ((index >= 0) ? token.substring(0, index) : token).trim().toLowerCase(Locale.ROOT); }).filter(this.contentCodings::contains)
/* 154 */       .sorted()
/* 155 */       .collect(Collectors.joining(","));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 163 */     String key = "resolvedUrlPath:" + resourceUrlPath;
/* 164 */     String resolvedUrlPath = (String)this.cache.get(key, String.class);
/*     */     
/* 166 */     if (resolvedUrlPath != null) {
/* 167 */       if (this.logger.isTraceEnabled()) {
/* 168 */         this.logger.trace("Path resolved from cache");
/*     */       }
/* 170 */       return resolvedUrlPath;
/*     */     } 
/*     */     
/* 173 */     resolvedUrlPath = chain.resolveUrlPath(resourceUrlPath, locations);
/* 174 */     if (resolvedUrlPath != null) {
/* 175 */       this.cache.put(key, resolvedUrlPath);
/*     */     }
/*     */     
/* 178 */     return resolvedUrlPath;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\CachingResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */