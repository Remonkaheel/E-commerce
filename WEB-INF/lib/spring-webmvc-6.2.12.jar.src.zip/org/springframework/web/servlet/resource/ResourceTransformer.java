package org.springframework.web.servlet.resource;

import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import org.springframework.core.io.Resource;

@FunctionalInterface
public interface ResourceTransformer {
  Resource transform(HttpServletRequest paramHttpServletRequest, Resource paramResource, ResourceTransformerChain paramResourceTransformerChain) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */