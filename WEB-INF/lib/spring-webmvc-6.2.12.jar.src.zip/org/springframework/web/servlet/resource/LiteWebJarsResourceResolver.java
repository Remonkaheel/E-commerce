/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.webjars.WebJarVersionLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LiteWebJarsResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*  48 */   private static final int WEBJARS_LOCATION_LENGTH = "META-INF/resources/webjars".length() + 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private final WebJarVersionLocator webJarVersionLocator;
/*     */ 
/*     */ 
/*     */   
/*     */   public LiteWebJarsResourceResolver() {
/*  57 */     this.webJarVersionLocator = new WebJarVersionLocator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LiteWebJarsResourceResolver(WebJarVersionLocator webJarVersionLocator) {
/*  65 */     this.webJarVersionLocator = webJarVersionLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/*  74 */     Resource resolved = chain.resolveResource(request, requestPath, locations);
/*  75 */     if (resolved == null) {
/*  76 */       String webJarResourcePath = findWebJarResourcePath(requestPath);
/*  77 */       if (webJarResourcePath != null) {
/*  78 */         return chain.resolveResource(request, webJarResourcePath, locations);
/*     */       }
/*     */     } 
/*  81 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/*  89 */     String path = chain.resolveUrlPath(resourceUrlPath, locations);
/*  90 */     if (path == null) {
/*  91 */       String webJarResourcePath = findWebJarResourcePath(resourceUrlPath);
/*  92 */       if (webJarResourcePath != null) {
/*  93 */         return chain.resolveUrlPath(webJarResourcePath, locations);
/*     */       }
/*     */     } 
/*  96 */     return path;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected String findWebJarResourcePath(String path) {
/* 101 */     int endOffset = path.indexOf('/', 1);
/* 102 */     if (endOffset != -1) {
/* 103 */       int startOffset = path.startsWith("/") ? 1 : 0;
/* 104 */       String webjar = path.substring(startOffset, endOffset);
/* 105 */       String partialPath = path.substring(endOffset + 1);
/* 106 */       String webJarPath = this.webJarVersionLocator.fullPath(webjar, partialPath);
/* 107 */       if (webJarPath != null) {
/* 108 */         return webJarPath.substring(WEBJARS_LOCATION_LENGTH);
/*     */       }
/*     */     } 
/* 111 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\LiteWebJarsResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */