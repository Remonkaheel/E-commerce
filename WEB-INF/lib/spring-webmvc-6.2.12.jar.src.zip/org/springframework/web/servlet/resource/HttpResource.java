package org.springframework.web.servlet.resource;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;

public interface HttpResource extends Resource {
  HttpHeaders getResponseHeaders();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\HttpResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */