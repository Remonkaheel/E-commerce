/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FileNameVersionedResource
/*     */   extends AbstractResource
/*     */   implements HttpResource
/*     */ {
/*     */   private final Resource original;
/*     */   private final String version;
/*     */   
/*     */   public FileNameVersionedResource(Resource original, String version) {
/* 246 */     this.original = original;
/* 247 */     this.version = version;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 252 */     return this.original.exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadable() {
/* 257 */     return this.original.isReadable();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 262 */     return this.original.isOpen();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFile() {
/* 267 */     return this.original.isFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getURL() throws IOException {
/* 272 */     return this.original.getURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() throws IOException {
/* 277 */     return this.original.getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public File getFile() throws IOException {
/* 282 */     return this.original.getFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 287 */     return this.original.getInputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public ReadableByteChannel readableChannel() throws IOException {
/* 292 */     return this.original.readableChannel();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getContentAsByteArray() throws IOException {
/* 297 */     return this.original.getContentAsByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentAsString(Charset charset) throws IOException {
/* 302 */     return this.original.getContentAsString(charset);
/*     */   }
/*     */ 
/*     */   
/*     */   public long contentLength() throws IOException {
/* 307 */     return this.original.contentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public long lastModified() throws IOException {
/* 312 */     return this.original.lastModified();
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource createRelative(String relativePath) throws IOException {
/* 317 */     return this.original.createRelative(relativePath);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getFilename() {
/* 323 */     return this.original.getFilename();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 328 */     return this.original.getDescription();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getResponseHeaders() {
/* 333 */     Resource resource = this.original; HttpResource httpResource = (HttpResource)resource;
/* 334 */     HttpHeaders headers = (resource instanceof HttpResource) ? httpResource.getResponseHeaders() : new HttpHeaders();
/* 335 */     headers.setETag("W/\"" + this.version + "\"");
/* 336 */     return headers;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\VersionResourceResolver$FileNameVersionedResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */