/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractResourceResolver
/*    */   implements ResourceResolver
/*    */ {
/* 37 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Resource resolveResource(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 45 */     return resolveResourceInternal(request, requestPath, locations, chain);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String resolveUrlPath(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 53 */     return resolveUrlPathInternal(resourceUrlPath, locations, chain);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   protected abstract Resource resolveResourceInternal(@Nullable HttpServletRequest paramHttpServletRequest, String paramString, List<? extends Resource> paramList, ResourceResolverChain paramResourceResolverChain);
/*    */   
/*    */   @Nullable
/*    */   protected abstract String resolveUrlPathInternal(String paramString, List<? extends Resource> paramList, ResourceResolverChain paramResourceResolverChain);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\AbstractResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */