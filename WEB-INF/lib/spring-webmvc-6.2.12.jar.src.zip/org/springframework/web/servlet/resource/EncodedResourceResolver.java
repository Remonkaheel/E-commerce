/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncodedResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*  63 */   public static final List<String> DEFAULT_CODINGS = Arrays.asList(new String[] { "br", "gzip" });
/*     */ 
/*     */   
/*  66 */   private final List<String> contentCodings = new ArrayList<>(DEFAULT_CODINGS);
/*     */   
/*  68 */   private final Map<String, String> extensions = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   public EncodedResourceResolver() {
/*  72 */     this.extensions.put("gzip", ".gz");
/*  73 */     this.extensions.put("br", ".br");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentCodings(List<String> codings) {
/*  91 */     Assert.notEmpty(codings, "At least one content coding expected");
/*  92 */     this.contentCodings.clear();
/*  93 */     this.contentCodings.addAll(codings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getContentCodings() {
/* 100 */     return Collections.unmodifiableList(this.contentCodings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtensions(Map<String, String> extensions) {
/* 112 */     extensions.forEach(this::registerExtension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtensions() {
/* 119 */     return Collections.unmodifiableMap(this.extensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerExtension(String coding, String extension) {
/* 128 */     this.extensions.put(coding, extension.startsWith(".") ? extension : ("." + extension));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 137 */     Resource resource = chain.resolveResource(request, requestPath, locations);
/* 138 */     if (resource == null || request == null) {
/* 139 */       return resource;
/*     */     }
/*     */     
/* 142 */     String acceptEncoding = getAcceptEncoding(request);
/* 143 */     if (acceptEncoding == null) {
/* 144 */       return resource;
/*     */     }
/*     */     
/* 147 */     for (String coding : this.contentCodings) {
/* 148 */       if (acceptEncoding.contains(coding)) {
/*     */         try {
/* 150 */           String extension = getExtension(coding);
/* 151 */           Resource encoded = new EncodedResource(resource, coding, extension);
/* 152 */           if (encoded.exists()) {
/* 153 */             return encoded;
/*     */           }
/*     */         }
/* 156 */         catch (IOException ex) {
/* 157 */           if (this.logger.isTraceEnabled()) {
/* 158 */             this.logger.trace("No " + coding + " resource for [" + resource.getFilename() + "]", ex);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 164 */     return resource;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getAcceptEncoding(HttpServletRequest request) {
/* 169 */     String header = request.getHeader("Accept-Encoding");
/* 170 */     return (header != null) ? header.toLowerCase(Locale.ROOT) : null;
/*     */   }
/*     */   
/*     */   private String getExtension(String coding) {
/* 174 */     String extension = this.extensions.get(coding);
/* 175 */     if (extension == null) {
/* 176 */       throw new IllegalStateException("No file extension associated with content coding " + coding);
/*     */     }
/* 178 */     return extension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 186 */     return chain.resolveUrlPath(resourceUrlPath, locations);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class EncodedResource
/*     */     extends AbstractResource
/*     */     implements HttpResource
/*     */   {
/*     */     private final Resource original;
/*     */     
/*     */     private final String coding;
/*     */     
/*     */     private final Resource encoded;
/*     */ 
/*     */     
/*     */     EncodedResource(Resource original, String coding, String extension) throws IOException {
/* 202 */       this.original = original;
/* 203 */       this.coding = coding;
/* 204 */       this.encoded = original.createRelative(original.getFilename() + original.getFilename());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean exists() {
/* 209 */       return this.encoded.exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReadable() {
/* 214 */       return this.encoded.isReadable();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isOpen() {
/* 219 */       return this.encoded.isOpen();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFile() {
/* 224 */       return this.encoded.isFile();
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getURL() throws IOException {
/* 229 */       return this.encoded.getURL();
/*     */     }
/*     */ 
/*     */     
/*     */     public URI getURI() throws IOException {
/* 234 */       return this.encoded.getURI();
/*     */     }
/*     */ 
/*     */     
/*     */     public File getFile() throws IOException {
/* 239 */       return this.encoded.getFile();
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 244 */       return this.encoded.getInputStream();
/*     */     }
/*     */ 
/*     */     
/*     */     public ReadableByteChannel readableChannel() throws IOException {
/* 249 */       return this.encoded.readableChannel();
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getContentAsByteArray() throws IOException {
/* 254 */       return this.encoded.getContentAsByteArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentAsString(Charset charset) throws IOException {
/* 259 */       return this.encoded.getContentAsString(charset);
/*     */     }
/*     */ 
/*     */     
/*     */     public long contentLength() throws IOException {
/* 264 */       return this.encoded.contentLength();
/*     */     }
/*     */ 
/*     */     
/*     */     public long lastModified() throws IOException {
/* 269 */       return this.encoded.lastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException {
/* 274 */       return this.encoded.createRelative(relativePath);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getFilename() {
/* 280 */       return this.original.getFilename();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 285 */       return this.encoded.getDescription();
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getResponseHeaders() {
/*     */       HttpHeaders headers;
/* 291 */       Resource resource = this.original; if (resource instanceof HttpResource) { HttpResource httpResource = (HttpResource)resource;
/* 292 */         headers = httpResource.getResponseHeaders(); }
/*     */       else
/*     */       
/* 295 */       { headers = new HttpHeaders(); }
/*     */       
/* 297 */       headers.add("Content-Encoding", this.coding);
/* 298 */       headers.add("Vary", "Accept-Encoding");
/* 299 */       return headers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\EncodedResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */