/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.util.SortedSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLinkParser
/*     */   implements CssLinkResourceTransformer.LinkParser
/*     */ {
/*     */   protected abstract String getKeyword();
/*     */   
/*     */   public void parse(String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> result) {
/* 136 */     int position = 0;
/*     */     while (true) {
/* 138 */       position = content.indexOf(getKeyword(), position);
/* 139 */       if (position == -1) {
/*     */         return;
/*     */       }
/* 142 */       position += getKeyword().length();
/* 143 */       while (Character.isWhitespace(content.charAt(position))) {
/* 144 */         position++;
/*     */       }
/* 146 */       if (content.charAt(position) == '\'') {
/* 147 */         position = extractLink(position, "'", content, result); continue;
/*     */       } 
/* 149 */       if (content.charAt(position) == '"') {
/* 150 */         position = extractLink(position, "\"", content, result);
/*     */         continue;
/*     */       } 
/* 153 */       position = extractLink(position, content, result);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int extractLink(int index, String endKey, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd) {
/* 159 */     int start = index + 1;
/* 160 */     int end = content.indexOf(endKey, start);
/* 161 */     linksToAdd.add(new CssLinkResourceTransformer.ContentChunkInfo(start, end));
/* 162 */     return end + endKey.length();
/*     */   }
/*     */   
/*     */   protected abstract int extractLink(int paramInt, String paramString, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> paramSortedSet);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\CssLinkResourceTransformer$AbstractLinkParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */