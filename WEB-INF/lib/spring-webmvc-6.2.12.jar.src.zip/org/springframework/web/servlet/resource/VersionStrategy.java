package org.springframework.web.servlet.resource;

import org.springframework.core.io.Resource;

public interface VersionStrategy extends VersionPathStrategy {
  String getResourceVersion(Resource paramResource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\VersionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */