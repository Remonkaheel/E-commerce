package org.springframework.web.servlet.resource;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;

public interface ResourceResolverChain {
  @Nullable
  Resource resolveResource(@Nullable HttpServletRequest paramHttpServletRequest, String paramString, List<? extends Resource> paramList);
  
  @Nullable
  String resolveUrlPath(String paramString, List<? extends Resource> paramList);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceResolverChain.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */