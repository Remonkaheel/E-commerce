/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*  70 */   private final AntPathMatcher pathMatcher = new AntPathMatcher();
/*     */ 
/*     */   
/*  73 */   private final Map<String, VersionStrategy> versionStrategyMap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStrategyMap(Map<String, VersionStrategy> map) {
/*  83 */     this.versionStrategyMap.clear();
/*  84 */     this.versionStrategyMap.putAll(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, VersionStrategy> getStrategyMap() {
/*  91 */     return this.versionStrategyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionResourceResolver addContentVersionStrategy(String... pathPatterns) {
/* 107 */     addVersionStrategy(new ContentVersionStrategy(), pathPatterns);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionResourceResolver addFixedVersionStrategy(String version, String... pathPatterns) {
/* 130 */     List<String> patternsList = Arrays.asList(pathPatterns);
/* 131 */     List<String> prefixedPatterns = new ArrayList<>(pathPatterns.length);
/* 132 */     String versionPrefix = "/" + version;
/* 133 */     for (String pattern : patternsList) {
/* 134 */       prefixedPatterns.add(pattern);
/* 135 */       if (!pattern.startsWith(versionPrefix) && !patternsList.contains(versionPrefix + versionPrefix)) {
/* 136 */         prefixedPatterns.add(versionPrefix + versionPrefix);
/*     */       }
/*     */     } 
/* 139 */     return addVersionStrategy(new FixedVersionStrategy(version), StringUtils.toStringArray(prefixedPatterns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionResourceResolver addVersionStrategy(VersionStrategy strategy, String... pathPatterns) {
/* 152 */     for (String pattern : pathPatterns) {
/* 153 */       getStrategyMap().put(pattern, strategy);
/*     */     }
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 164 */     Resource resolved = chain.resolveResource(request, requestPath, locations);
/* 165 */     if (resolved != null) {
/* 166 */       return resolved;
/*     */     }
/*     */     
/* 169 */     VersionStrategy versionStrategy = getStrategyForPath(requestPath);
/* 170 */     if (versionStrategy == null) {
/* 171 */       return null;
/*     */     }
/*     */     
/* 174 */     String candidateVersion = versionStrategy.extractVersion(requestPath);
/* 175 */     if (!StringUtils.hasLength(candidateVersion)) {
/* 176 */       return null;
/*     */     }
/*     */     
/* 179 */     String simplePath = versionStrategy.removeVersion(requestPath, candidateVersion);
/* 180 */     Resource baseResource = chain.resolveResource(request, simplePath, locations);
/* 181 */     if (baseResource == null) {
/* 182 */       return null;
/*     */     }
/*     */     
/* 185 */     String actualVersion = versionStrategy.getResourceVersion(baseResource);
/* 186 */     if (candidateVersion.equals(actualVersion)) {
/* 187 */       return new FileNameVersionedResource(baseResource, candidateVersion);
/*     */     }
/*     */     
/* 190 */     if (this.logger.isTraceEnabled()) {
/* 191 */       this.logger.trace("Found resource for \"" + requestPath + "\", but version [" + candidateVersion + "] does not match");
/*     */     }
/*     */     
/* 194 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 203 */     String baseUrl = chain.resolveUrlPath(resourceUrlPath, locations);
/* 204 */     if (StringUtils.hasText(baseUrl)) {
/* 205 */       VersionStrategy versionStrategy = getStrategyForPath(resourceUrlPath);
/* 206 */       if (versionStrategy == null) {
/* 207 */         return baseUrl;
/*     */       }
/* 209 */       Resource resource = chain.resolveResource(null, baseUrl, locations);
/* 210 */       Assert.state((resource != null), "Unresolvable resource");
/* 211 */       String version = versionStrategy.getResourceVersion(resource);
/* 212 */       return versionStrategy.addVersion(baseUrl, version);
/*     */     } 
/* 214 */     return baseUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected VersionStrategy getStrategyForPath(String requestPath) {
/* 223 */     String path = "/".concat(requestPath);
/* 224 */     List<String> matchingPatterns = new ArrayList<>();
/* 225 */     for (String pattern : this.versionStrategyMap.keySet()) {
/* 226 */       if (this.pathMatcher.match(pattern, path)) {
/* 227 */         matchingPatterns.add(pattern);
/*     */       }
/*     */     } 
/* 230 */     if (!matchingPatterns.isEmpty()) {
/* 231 */       Comparator<String> comparator = this.pathMatcher.getPatternComparator(path);
/* 232 */       matchingPatterns.sort(comparator);
/* 233 */       return this.versionStrategyMap.get(matchingPatterns.get(0));
/*     */     } 
/* 235 */     return null;
/*     */   }
/*     */   
/*     */   private static class FileNameVersionedResource
/*     */     extends AbstractResource
/*     */     implements HttpResource
/*     */   {
/*     */     private final Resource original;
/*     */     private final String version;
/*     */     
/*     */     public FileNameVersionedResource(Resource original, String version) {
/* 246 */       this.original = original;
/* 247 */       this.version = version;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean exists() {
/* 252 */       return this.original.exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReadable() {
/* 257 */       return this.original.isReadable();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isOpen() {
/* 262 */       return this.original.isOpen();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFile() {
/* 267 */       return this.original.isFile();
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getURL() throws IOException {
/* 272 */       return this.original.getURL();
/*     */     }
/*     */ 
/*     */     
/*     */     public URI getURI() throws IOException {
/* 277 */       return this.original.getURI();
/*     */     }
/*     */ 
/*     */     
/*     */     public File getFile() throws IOException {
/* 282 */       return this.original.getFile();
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 287 */       return this.original.getInputStream();
/*     */     }
/*     */ 
/*     */     
/*     */     public ReadableByteChannel readableChannel() throws IOException {
/* 292 */       return this.original.readableChannel();
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getContentAsByteArray() throws IOException {
/* 297 */       return this.original.getContentAsByteArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentAsString(Charset charset) throws IOException {
/* 302 */       return this.original.getContentAsString(charset);
/*     */     }
/*     */ 
/*     */     
/*     */     public long contentLength() throws IOException {
/* 307 */       return this.original.contentLength();
/*     */     }
/*     */ 
/*     */     
/*     */     public long lastModified() throws IOException {
/* 312 */       return this.original.lastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException {
/* 317 */       return this.original.createRelative(relativePath);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getFilename() {
/* 323 */       return this.original.getFilename();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 328 */       return this.original.getDescription();
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getResponseHeaders() {
/* 333 */       Resource resource = this.original; HttpResource httpResource = (HttpResource)resource;
/* 334 */       HttpHeaders headers = (resource instanceof HttpResource) ? httpResource.getResponseHeaders() : new HttpHeaders();
/* 335 */       headers.setETag("W/\"" + this.version + "\"");
/* 336 */       return headers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\VersionResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */