/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultServletHttpRequestHandler
/*     */   implements HttpRequestHandler, ServletContextAware
/*     */ {
/*     */   private static final String COMMON_DEFAULT_SERVLET_NAME = "default";
/*     */   private static final String GAE_DEFAULT_SERVLET_NAME = "_ah_default";
/*     */   private static final String WEBLOGIC_DEFAULT_SERVLET_NAME = "FileServlet";
/*     */   private static final String WEBSPHERE_DEFAULT_SERVLET_NAME = "SimpleFileServlet";
/*     */   @Nullable
/*     */   private String defaultServletName;
/*     */   @Nullable
/*     */   private ServletContext servletContext;
/*     */   
/*     */   public void setDefaultServletName(String defaultServletName) {
/*  81 */     this.defaultServletName = defaultServletName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/*  91 */     this.servletContext = servletContext;
/*  92 */     if (!StringUtils.hasText(this.defaultServletName)) {
/*  93 */       if (this.servletContext.getNamedDispatcher("default") != null) {
/*  94 */         this.defaultServletName = "default";
/*     */       }
/*  96 */       else if (this.servletContext.getNamedDispatcher("_ah_default") != null) {
/*  97 */         this.defaultServletName = "_ah_default";
/*     */       }
/*  99 */       else if (this.servletContext.getNamedDispatcher("FileServlet") != null) {
/* 100 */         this.defaultServletName = "FileServlet";
/*     */       }
/* 102 */       else if (this.servletContext.getNamedDispatcher("SimpleFileServlet") != null) {
/* 103 */         this.defaultServletName = "SimpleFileServlet";
/*     */       } else {
/*     */         
/* 106 */         throw new IllegalStateException("Unable to locate the default servlet for serving static content. Please set the 'defaultServletName' property explicitly.");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 117 */     Assert.state((this.servletContext != null), "No ServletContext set");
/* 118 */     RequestDispatcher rd = this.servletContext.getNamedDispatcher(this.defaultServletName);
/* 119 */     if (rd == null) {
/* 120 */       throw new IllegalStateException("A RequestDispatcher could not be located for the default servlet '" + this.defaultServletName + "'");
/*     */     }
/*     */     
/* 123 */     if (request.getDispatcherType() != DispatcherType.INCLUDE) {
/* 124 */       rd.forward((ServletRequest)request, (ServletResponse)response);
/*     */     } else {
/*     */       
/* 127 */       rd.include((ServletRequest)request, (ServletResponse)response);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\DefaultServletHttpRequestHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */