/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   @Nullable
/*     */   private Resource[] allowedLocations;
/*  58 */   private final Map<Resource, Charset> locationCharsets = new HashMap<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private UrlPathHelper urlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedLocations(@Nullable Resource... locations) {
/*  82 */     this.allowedLocations = locations;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Resource[] getAllowedLocations() {
/*  87 */     return this.allowedLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocationCharsets(Map<Resource, Charset> locationCharsets) {
/* 100 */     this.locationCharsets.clear();
/* 101 */     this.locationCharsets.putAll(locationCharsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Resource, Charset> getLocationCharsets() {
/* 109 */     return Collections.unmodifiableMap(this.locationCharsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPathHelper(@Nullable UrlPathHelper urlPathHelper) {
/* 119 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 128 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 137 */     return getResource(requestPath, request, locations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveUrlPathInternal(String resourcePath, List<? extends Resource> locations, ResourceResolverChain chain) {
/* 145 */     return (StringUtils.hasText(resourcePath) && 
/* 146 */       getResource(resourcePath, null, locations) != null) ? resourcePath : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Resource getResource(String resourcePath, @Nullable HttpServletRequest request, List<? extends Resource> locations) {
/* 153 */     for (Resource location : locations) {
/*     */       try {
/* 155 */         String pathToUse = encodeOrDecodeIfNecessary(resourcePath, request, location);
/* 156 */         Resource resource = getResource(pathToUse, location);
/* 157 */         if (resource != null) {
/* 158 */           return resource;
/*     */         }
/*     */       }
/* 161 */       catch (IOException ex) {
/* 162 */         if (this.logger.isDebugEnabled()) {
/* 163 */           String error = "Skip location [" + String.valueOf(location) + "] due to error";
/* 164 */           if (this.logger.isTraceEnabled()) {
/* 165 */             this.logger.trace(error, ex);
/*     */             continue;
/*     */           } 
/* 168 */           this.logger.debug(error + ": " + error);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Resource getResource(String resourcePath, Resource location) throws IOException {
/* 186 */     Resource resource = location.createRelative(resourcePath);
/* 187 */     if (resource.isReadable()) {
/* 188 */       if (checkResource(resource, location)) {
/* 189 */         return resource;
/*     */       }
/* 191 */       if (this.logger.isWarnEnabled()) {
/* 192 */         Resource[] allowed = getAllowedLocations();
/* 193 */         this.logger.warn(LogFormatUtils.formatValue("Resource path \"" + resourcePath + "\" was successfully resolved but resource \"" + String.valueOf(resource) + "\" is neither under the current location \"" + String.valueOf(location) + "\" nor under any of the allowed locations " + 
/*     */ 
/*     */ 
/*     */               
/* 197 */               String.valueOf((allowed != null) ? Arrays.<Resource>asList(allowed) : "[]"), -1, true));
/*     */       } 
/*     */     } 
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkResource(Resource resource, Resource location) throws IOException {
/* 214 */     if (ResourceHandlerUtils.isResourceUnderLocation(location, resource)) {
/* 215 */       return true;
/*     */     }
/* 217 */     Resource[] allowedLocations = getAllowedLocations();
/* 218 */     if (allowedLocations != null) {
/* 219 */       for (Resource current : allowedLocations) {
/* 220 */         if (ResourceHandlerUtils.isResourceUnderLocation(current, resource)) {
/* 221 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 225 */     return false;
/*     */   }
/*     */   
/*     */   private String encodeOrDecodeIfNecessary(String path, @Nullable HttpServletRequest request, Resource location) {
/* 229 */     if (request != null) {
/*     */ 
/*     */       
/* 232 */       boolean usesPathPattern = (ServletRequestPathUtils.hasCachedPath((ServletRequest)request) && ServletRequestPathUtils.getCachedPath((ServletRequest)request) instanceof org.springframework.http.server.PathContainer);
/*     */       
/* 234 */       if (shouldDecodeRelativePath(location, usesPathPattern)) {
/* 235 */         return UriUtils.decode(path, StandardCharsets.UTF_8);
/*     */       }
/* 237 */       if (shouldEncodeRelativePath(location, usesPathPattern)) {
/* 238 */         Charset charset = this.locationCharsets.getOrDefault(location, StandardCharsets.UTF_8);
/* 239 */         StringBuilder sb = new StringBuilder();
/* 240 */         StringTokenizer tokenizer = new StringTokenizer(path, "/");
/* 241 */         while (tokenizer.hasMoreTokens()) {
/* 242 */           String value = UriUtils.encode(tokenizer.nextToken(), charset);
/* 243 */           sb.append(value);
/* 244 */           sb.append('/');
/*     */         } 
/* 246 */         if (!path.endsWith("/")) {
/* 247 */           sb.setLength(sb.length() - 1);
/*     */         }
/* 249 */         return sb.toString();
/*     */       } 
/*     */     } 
/* 252 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldDecodeRelativePath(Resource location, boolean usesPathPattern) {
/* 260 */     return (!(location instanceof org.springframework.core.io.UrlResource) && (usesPathPattern || (this.urlPathHelper != null && 
/* 261 */       !this.urlPathHelper.isUrlDecode())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldEncodeRelativePath(Resource location, boolean usesPathPattern) {
/* 269 */     return (location instanceof org.springframework.core.io.UrlResource && !usesPathPattern && this.urlPathHelper != null && this.urlPathHelper
/* 270 */       .isUrlDecode());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\PathResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */