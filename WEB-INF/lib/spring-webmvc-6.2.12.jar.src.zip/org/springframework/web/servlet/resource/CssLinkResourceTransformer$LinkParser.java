package org.springframework.web.servlet.resource;

import java.util.SortedSet;

@FunctionalInterface
public interface LinkParser {
  void parse(String paramString, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> paramSortedSet);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\CssLinkResourceTransformer$LinkParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */