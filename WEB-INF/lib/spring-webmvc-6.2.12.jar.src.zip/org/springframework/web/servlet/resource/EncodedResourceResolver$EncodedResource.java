/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EncodedResource
/*     */   extends AbstractResource
/*     */   implements HttpResource
/*     */ {
/*     */   private final Resource original;
/*     */   private final String coding;
/*     */   private final Resource encoded;
/*     */   
/*     */   EncodedResource(Resource original, String coding, String extension) throws IOException {
/* 202 */     this.original = original;
/* 203 */     this.coding = coding;
/* 204 */     this.encoded = original.createRelative(original.getFilename() + original.getFilename());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 209 */     return this.encoded.exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadable() {
/* 214 */     return this.encoded.isReadable();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 219 */     return this.encoded.isOpen();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFile() {
/* 224 */     return this.encoded.isFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getURL() throws IOException {
/* 229 */     return this.encoded.getURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() throws IOException {
/* 234 */     return this.encoded.getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public File getFile() throws IOException {
/* 239 */     return this.encoded.getFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 244 */     return this.encoded.getInputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public ReadableByteChannel readableChannel() throws IOException {
/* 249 */     return this.encoded.readableChannel();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getContentAsByteArray() throws IOException {
/* 254 */     return this.encoded.getContentAsByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentAsString(Charset charset) throws IOException {
/* 259 */     return this.encoded.getContentAsString(charset);
/*     */   }
/*     */ 
/*     */   
/*     */   public long contentLength() throws IOException {
/* 264 */     return this.encoded.contentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public long lastModified() throws IOException {
/* 269 */     return this.encoded.lastModified();
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource createRelative(String relativePath) throws IOException {
/* 274 */     return this.encoded.createRelative(relativePath);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getFilename() {
/* 280 */     return this.original.getFilename();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 285 */     return this.encoded.getDescription();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getResponseHeaders() {
/*     */     HttpHeaders headers;
/* 291 */     Resource resource = this.original; if (resource instanceof HttpResource) { HttpResource httpResource = (HttpResource)resource;
/* 292 */       headers = httpResource.getResponseHeaders(); }
/*     */     else
/*     */     
/* 295 */     { headers = new HttpHeaders(); }
/*     */     
/* 297 */     headers.add("Content-Encoding", this.coding);
/* 298 */     headers.add("Vary", "Accept-Encoding");
/* 299 */     return headers;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\EncodedResourceResolver$EncodedResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */