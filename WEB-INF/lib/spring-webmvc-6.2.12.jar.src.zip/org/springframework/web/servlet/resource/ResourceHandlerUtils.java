/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceHandlerUtils
/*     */ {
/*  47 */   private static final Log logger = LogFactory.getLog(ResourceHandlerUtils.class);
/*     */ 
/*     */   
/*     */   private static final String FOLDER_SEPARATOR = "/";
/*     */ 
/*     */   
/*     */   private static final String WINDOWS_FOLDER_SEPARATOR = "\\";
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertResourceLocation(@Nullable Resource location) {
/*  58 */     Assert.notNull(location, "Resource location must not be null");
/*     */     try {
/*     */       String path;
/*  61 */       if (location instanceof org.springframework.core.io.PathResource) {
/*     */         return;
/*     */       }
/*  64 */       if (location instanceof FileSystemResource) { FileSystemResource fileSystemResource = (FileSystemResource)location;
/*  65 */         path = fileSystemResource.getPath(); }
/*     */       
/*  67 */       else if (location instanceof ClassPathResource) { ClassPathResource classPathResource = (ClassPathResource)location;
/*  68 */         path = classPathResource.getPath(); }
/*     */       
/*  70 */       else if (location instanceof org.springframework.core.io.UrlResource)
/*  71 */       { path = location.getURL().toExternalForm(); }
/*     */       else
/*     */       
/*  74 */       { path = location.getURL().getPath(); }
/*     */       
/*  76 */       Assert.isTrue((path.endsWith("/") || path.endsWith("\\")), "Resource location does not end with slash: " + path);
/*     */     
/*     */     }
/*  79 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String initLocationPath(String path) {
/*  91 */     String separator = path.contains("/") ? "/" : "\\";
/*  92 */     if (!path.endsWith(separator)) {
/*  93 */       path = path.concat(separator);
/*  94 */       logger.warn("Appended trailing slash to static resource location: " + path);
/*     */     } 
/*  96 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String normalizeInputPath(String path) {
/* 110 */     path = StringUtils.replace(path, "\\", "/");
/* 111 */     path = cleanDuplicateSlashes(path);
/* 112 */     return cleanLeadingSlash(path);
/*     */   }
/*     */   
/*     */   private static String cleanDuplicateSlashes(String path) {
/* 116 */     StringBuilder sb = null;
/* 117 */     char prev = Character.MIN_VALUE;
/* 118 */     for (int i = 0; i < path.length(); i++) {
/* 119 */       char curr = path.charAt(i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     return (sb != null) ? sb.toString() : path;
/*     */   }
/*     */   
/*     */   private static String cleanLeadingSlash(String path) {
/* 139 */     boolean slash = false;
/* 140 */     for (int i = 0; i < path.length(); i++) {
/* 141 */       if (path.charAt(i) == '/') {
/* 142 */         slash = true;
/*     */       }
/* 144 */       else if (path.charAt(i) > ' ' && path.charAt(i) != '') {
/* 145 */         if (i == 0 || (i == 1 && slash)) {
/* 146 */           return path;
/*     */         }
/* 148 */         return slash ? ("/" + path.substring(i)) : path.substring(i);
/*     */       } 
/*     */     } 
/* 151 */     return slash ? "/" : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean shouldIgnoreInputPath(String path) {
/* 160 */     return (!StringUtils.hasText(path) || isInvalidPath(path) || isInvalidEncodedPath(path));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInvalidPath(String path) {
/* 179 */     if (path.contains("WEB-INF") || path.contains("META-INF")) {
/* 180 */       if (logger.isWarnEnabled()) {
/* 181 */         logger.warn(LogFormatUtils.formatValue("Path with \"WEB-INF\" or \"META-INF\": [" + path + "]", -1, true));
/*     */       }
/*     */       
/* 184 */       return true;
/*     */     } 
/* 186 */     if (path.contains(":/")) {
/* 187 */       String relativePath = (path.charAt(0) == '/') ? path.substring(1) : path;
/* 188 */       if (ResourceUtils.isUrl(relativePath) || relativePath.startsWith("url:")) {
/* 189 */         if (logger.isWarnEnabled()) {
/* 190 */           logger.warn(LogFormatUtils.formatValue("Path represents URL or has \"url:\" prefix: [" + path + "]", -1, true));
/*     */         }
/*     */         
/* 193 */         return true;
/*     */       } 
/*     */     } 
/* 196 */     if (path.contains("../")) {
/* 197 */       if (logger.isWarnEnabled()) {
/* 198 */         logger.warn(LogFormatUtils.formatValue("Path contains \"../\" after call to StringUtils#cleanPath: [" + path + "]", -1, true));
/*     */       }
/*     */       
/* 201 */       return true;
/*     */     } 
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInvalidEncodedPath(String path) {
/* 212 */     String decodedPath = decode(path);
/* 213 */     if (decodedPath.contains("%")) {
/* 214 */       decodedPath = decode(decodedPath);
/*     */     }
/* 216 */     if (!StringUtils.hasText(decodedPath)) {
/* 217 */       return true;
/*     */     }
/* 219 */     if (isInvalidPath(decodedPath)) {
/* 220 */       return true;
/*     */     }
/* 222 */     decodedPath = normalizeInputPath(decodedPath);
/* 223 */     return isInvalidPath(decodedPath);
/*     */   }
/*     */   
/*     */   private static String decode(String path) {
/*     */     try {
/* 228 */       return UriUtils.decode(path, StandardCharsets.UTF_8);
/*     */     }
/* 230 */     catch (Exception ex) {
/* 231 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isResourceUnderLocation(Resource location, Resource resource) throws IOException {
/*     */     String resourcePath;
/* 240 */     if (resource.getClass() != location.getClass()) {
/* 241 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (resource instanceof org.springframework.core.io.UrlResource)
/* 248 */     { resourcePath = resource.getURL().toExternalForm();
/* 249 */       locationPath = StringUtils.cleanPath(location.getURL().toString()); }
/*     */     
/* 251 */     else if (resource instanceof ClassPathResource) { ClassPathResource classPathResource = (ClassPathResource)resource;
/* 252 */       resourcePath = classPathResource.getPath();
/* 253 */       locationPath = StringUtils.cleanPath(((ClassPathResource)location).getPath()); }
/*     */     
/* 255 */     else if (resource instanceof ServletContextResource) { ServletContextResource servletContextResource = (ServletContextResource)resource;
/* 256 */       resourcePath = servletContextResource.getPath();
/* 257 */       locationPath = StringUtils.cleanPath(((ServletContextResource)location).getPath()); }
/*     */     else
/*     */     
/* 260 */     { resourcePath = resource.getURL().getPath();
/* 261 */       locationPath = StringUtils.cleanPath(location.getURL().getPath()); }
/*     */ 
/*     */     
/* 264 */     if (locationPath.equals(resourcePath)) {
/* 265 */       return true;
/*     */     }
/* 267 */     String locationPath = (locationPath.endsWith("/") || locationPath.isEmpty()) ? locationPath : (locationPath + "/");
/* 268 */     return (resourcePath.startsWith(locationPath) && !isInvalidEncodedResourcePath(resourcePath));
/*     */   }
/*     */   
/*     */   private static boolean isInvalidEncodedResourcePath(String resourcePath) {
/* 272 */     if (resourcePath.contains("%")) {
/*     */       
/*     */       try {
/* 275 */         String decodedPath = URLDecoder.decode(resourcePath, StandardCharsets.UTF_8);
/* 276 */         if (decodedPath.contains("../") || decodedPath.contains("..\\")) {
/* 277 */           logger.warn(LogFormatUtils.formatValue("Resolved resource path contains encoded \"../\" or \"..\\\": " + resourcePath, -1, true));
/*     */           
/* 279 */           return true;
/*     */         }
/*     */       
/* 282 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*     */     }
/*     */ 
/*     */     
/* 286 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceHandlerUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */