/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.ProblemDetail;
/*    */ import org.springframework.web.ErrorResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoResourceFoundException
/*    */   extends ServletException
/*    */   implements ErrorResponse
/*    */ {
/*    */   private final HttpMethod httpMethod;
/*    */   private final String resourcePath;
/*    */   private final ProblemDetail body;
/*    */   
/*    */   public NoResourceFoundException(HttpMethod httpMethod, String resourcePath) {
/* 49 */     super("No static resource " + resourcePath + ".");
/* 50 */     this.httpMethod = httpMethod;
/* 51 */     this.resourcePath = resourcePath;
/* 52 */     this.body = ProblemDetail.forStatusAndDetail(getStatusCode(), getMessage());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpMethod getHttpMethod() {
/* 60 */     return this.httpMethod;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getResourcePath() {
/* 68 */     return this.resourcePath;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpStatusCode getStatusCode() {
/* 73 */     return (HttpStatusCode)HttpStatus.NOT_FOUND;
/*    */   }
/*    */ 
/*    */   
/*    */   public ProblemDetail getBody() {
/* 78 */     return this.body;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\NoResourceFoundException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */