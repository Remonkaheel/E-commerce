/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceRegionHttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.PathExtensionContentNegotiationStrategy;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHttpRequestHandler
/*     */   extends WebContentGenerator
/*     */   implements HttpRequestHandler, EmbeddedValueResolverAware, InitializingBean, CorsConfigurationSource
/*     */ {
/*  99 */   private static final Log logger = LogFactory.getLog(ResourceHttpRequestHandler.class);
/*     */ 
/*     */   
/*     */   private static final String URL_RESOURCE_CHARSET_PREFIX = "[charset=";
/*     */   
/* 104 */   private final List<String> locationValues = new ArrayList<>(4);
/*     */   
/* 106 */   private final List<Resource> locationResources = new ArrayList<>(4);
/*     */   
/* 108 */   private final List<Resource> locationsToUse = new ArrayList<>(4);
/*     */   
/* 110 */   private final Map<Resource, Charset> locationCharsets = new HashMap<>(4);
/*     */   
/* 112 */   private final List<ResourceResolver> resourceResolvers = new ArrayList<>(4);
/*     */   
/* 114 */   private final List<ResourceTransformer> resourceTransformers = new ArrayList<>(4);
/*     */   
/*     */   @Nullable
/*     */   private ResourceResolverChain resolverChain;
/*     */   
/*     */   @Nullable
/*     */   private ResourceTransformerChain transformerChain;
/*     */   
/*     */   @Nullable
/*     */   private ResourceHttpMessageConverter resourceHttpMessageConverter;
/*     */   
/*     */   @Nullable
/*     */   private ResourceRegionHttpMessageConverter resourceRegionHttpMessageConverter;
/*     */   
/*     */   @Nullable
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   
/* 131 */   private final Map<String, MediaType> mediaTypes = new HashMap<>(4);
/*     */   
/*     */   @Nullable
/*     */   private CorsConfiguration corsConfiguration;
/*     */   
/*     */   @Nullable
/*     */   private UrlPathHelper urlPathHelper;
/*     */   
/*     */   private boolean useLastModified = true;
/*     */   
/*     */   @Nullable
/*     */   private Function<Resource, String> etagGenerator;
/*     */   
/*     */   private boolean optimizeLocations = false;
/*     */   
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   
/*     */   public ResourceHttpRequestHandler() {
/* 151 */     super(new String[] { HttpMethod.GET.name(), HttpMethod.HEAD.name() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocationValues(List<String> locations) {
/* 171 */     Assert.notNull(locations, "Locations list must not be null");
/* 172 */     this.locationValues.clear();
/* 173 */     this.locationValues.addAll(locations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocations(List<Resource> locations) {
/* 181 */     Assert.notNull(locations, "Locations list must not be null");
/* 182 */     this.locationResources.clear();
/* 183 */     for (Resource location : locations) {
/* 184 */       ResourceHandlerUtils.assertResourceLocation(location);
/* 185 */       this.locationResources.add(location);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Resource> getLocations() {
/* 203 */     if (this.locationsToUse.isEmpty())
/*     */     {
/* 205 */       return this.locationResources;
/*     */     }
/* 207 */     return this.locationsToUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceResolvers(@Nullable List<ResourceResolver> resourceResolvers) {
/* 216 */     this.resourceResolvers.clear();
/* 217 */     if (resourceResolvers != null) {
/* 218 */       this.resourceResolvers.addAll(resourceResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResourceResolver> getResourceResolvers() {
/* 226 */     return this.resourceResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceTransformers(@Nullable List<ResourceTransformer> resourceTransformers) {
/* 234 */     this.resourceTransformers.clear();
/* 235 */     if (resourceTransformers != null) {
/* 236 */       this.resourceTransformers.addAll(resourceTransformers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResourceTransformer> getResourceTransformers() {
/* 244 */     return this.resourceTransformers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceHttpMessageConverter(@Nullable ResourceHttpMessageConverter messageConverter) {
/* 253 */     this.resourceHttpMessageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResourceHttpMessageConverter getResourceHttpMessageConverter() {
/* 262 */     return this.resourceHttpMessageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceRegionHttpMessageConverter(@Nullable ResourceRegionHttpMessageConverter messageConverter) {
/* 271 */     this.resourceRegionHttpMessageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResourceRegionHttpMessageConverter getResourceRegionHttpMessageConverter() {
/* 280 */     return this.resourceRegionHttpMessageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setContentNegotiationManager(@Nullable ContentNegotiationManager contentNegotiationManager) {
/* 294 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public ContentNegotiationManager getContentNegotiationManager() {
/* 305 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMediaTypes(Map<String, MediaType> mediaTypes) {
/* 320 */     mediaTypes.forEach((ext, mediaType) -> this.mediaTypes.put(ext.toLowerCase(Locale.ROOT), mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, MediaType> getMediaTypes() {
/* 329 */     return this.mediaTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorsConfiguration(CorsConfiguration corsConfiguration) {
/* 337 */     this.corsConfiguration = corsConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
/* 346 */     return this.corsConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPathHelper(@Nullable UrlPathHelper urlPathHelper) {
/* 356 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 365 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseLastModified(boolean useLastModified) {
/* 377 */     this.useLastModified = useLastModified;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseLastModified() {
/* 386 */     return this.useLastModified;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEtagGenerator(@Nullable Function<Resource, String> etagGenerator) {
/* 399 */     this.etagGenerator = etagGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Function<Resource, String> getEtagGenerator() {
/* 409 */     return this.etagGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptimizeLocations(boolean optimizeLocations) {
/* 423 */     this.optimizeLocations = optimizeLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOptimizeLocations() {
/* 433 */     return this.optimizeLocations;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/* 438 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 444 */     resolveResourceLocations();
/*     */     
/* 446 */     if (this.resourceResolvers.isEmpty()) {
/* 447 */       this.resourceResolvers.add(new PathResourceResolver());
/*     */     }
/*     */     
/* 450 */     initAllowedLocations();
/*     */ 
/*     */     
/* 453 */     this.resolverChain = new DefaultResourceResolverChain(this.resourceResolvers);
/* 454 */     this.transformerChain = new DefaultResourceTransformerChain(this.resolverChain, this.resourceTransformers);
/*     */     
/* 456 */     if (this.resourceHttpMessageConverter == null) {
/* 457 */       this.resourceHttpMessageConverter = new ResourceHttpMessageConverter();
/*     */     }
/* 459 */     if (this.resourceRegionHttpMessageConverter == null) {
/* 460 */       this.resourceRegionHttpMessageConverter = new ResourceRegionHttpMessageConverter();
/*     */     }
/*     */     
/* 463 */     ContentNegotiationManager manager = getContentNegotiationManager();
/* 464 */     if (manager != null) {
/* 465 */       setMediaTypes(manager.getMediaTypeMappings());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 470 */     PathExtensionContentNegotiationStrategy strategy = initContentNegotiationStrategy();
/* 471 */     if (strategy != null) {
/* 472 */       setMediaTypes(strategy.getMediaTypes());
/*     */     }
/*     */   }
/*     */   
/*     */   private void resolveResourceLocations() {
/* 477 */     List<Resource> result = new ArrayList<>();
/* 478 */     if (!this.locationValues.isEmpty()) {
/* 479 */       ApplicationContext applicationContext = obtainApplicationContext();
/* 480 */       for (String location : this.locationValues) {
/* 481 */         if (this.embeddedValueResolver != null) {
/* 482 */           String resolvedLocation = this.embeddedValueResolver.resolveStringValue(location);
/* 483 */           if (resolvedLocation == null) {
/* 484 */             throw new IllegalArgumentException("Location resolved to null: " + location);
/*     */           }
/* 486 */           location = resolvedLocation;
/*     */         } 
/* 488 */         Charset charset = null;
/* 489 */         location = location.trim();
/* 490 */         if (location.startsWith("[charset=")) {
/* 491 */           int endIndex = location.indexOf(']', "[charset=".length());
/* 492 */           if (endIndex == -1) {
/* 493 */             throw new IllegalArgumentException("Invalid charset syntax in location: " + location);
/*     */           }
/* 495 */           String value = location.substring("[charset=".length(), endIndex);
/* 496 */           charset = Charset.forName(value);
/* 497 */           location = location.substring(endIndex + 1);
/*     */         } 
/* 499 */         location = ResourceHandlerUtils.initLocationPath(location);
/* 500 */         Resource resource = applicationContext.getResource(location);
/* 501 */         if (location.equals("/") && !(resource instanceof org.springframework.web.context.support.ServletContextResource)) {
/* 502 */           throw new IllegalStateException("The String-based location \"/\" should be relative to the web application root but resolved to a Resource of type: " + 
/*     */               
/* 504 */               String.valueOf(resource.getClass()) + ". If this is intentional, please pass it as a pre-configured Resource via setLocations.");
/*     */         }
/*     */         
/* 507 */         result.add(resource);
/* 508 */         if (charset != null) {
/* 509 */           if (!(resource instanceof org.springframework.core.io.UrlResource)) {
/* 510 */             throw new IllegalArgumentException("Unexpected charset for non-UrlResource: " + String.valueOf(resource));
/*     */           }
/* 512 */           this.locationCharsets.put(resource, charset);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 517 */     result.addAll(this.locationResources);
/* 518 */     if (isOptimizeLocations()) {
/* 519 */       result = result.stream().filter(Resource::exists).toList();
/*     */     }
/*     */     
/* 522 */     this.locationsToUse.clear();
/* 523 */     this.locationsToUse.addAll(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initAllowedLocations() {
/* 532 */     if (CollectionUtils.isEmpty(getLocations())) {
/*     */       return;
/*     */     }
/* 535 */     for (int i = getResourceResolvers().size() - 1; i >= 0; i--) {
/* 536 */       PathResourceResolver pathResourceResolver = (PathResourceResolver)getResourceResolvers().get(i); if (pathResourceResolver instanceof PathResourceResolver) { PathResourceResolver pathResolver = pathResourceResolver;
/* 537 */         if (ObjectUtils.isEmpty((Object[])pathResolver.getAllowedLocations())) {
/* 538 */           pathResolver.setAllowedLocations(getLocations().<Resource>toArray(new Resource[0]));
/*     */         }
/* 540 */         if (this.urlPathHelper != null) {
/* 541 */           pathResolver.setLocationCharsets(this.locationCharsets);
/* 542 */           pathResolver.setUrlPathHelper(this.urlPathHelper);
/*     */         } 
/*     */         break; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   protected PathExtensionContentNegotiationStrategy initContentNegotiationStrategy() {
/* 561 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 582 */     Resource resource = getResource(request);
/* 583 */     if (resource == null) {
/* 584 */       logger.debug("Resource not found");
/* 585 */       throw new NoResourceFoundException(HttpMethod.valueOf(request.getMethod()), getPath(request));
/*     */     } 
/*     */     
/* 588 */     if (HttpMethod.OPTIONS.matches(request.getMethod())) {
/* 589 */       response.setHeader("Allow", getAllowHeader());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 594 */     checkRequest(request);
/*     */ 
/*     */     
/* 597 */     prepareResponse(response);
/*     */ 
/*     */     
/* 600 */     String eTagValue = (getEtagGenerator() != null) ? getEtagGenerator().apply(resource) : null;
/* 601 */     long lastModified = isUseLastModified() ? resource.lastModified() : -1L;
/* 602 */     if ((new ServletWebRequest(request, response)).checkNotModified(eTagValue, lastModified)) {
/* 603 */       logger.trace("Resource not modified");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 608 */     MediaType mediaType = getMediaType(request, resource);
/* 609 */     setHeaders(response, resource, mediaType);
/*     */ 
/*     */     
/* 612 */     ServletServerHttpResponse outputMessage = new ServletServerHttpResponse(response);
/* 613 */     if (request.getHeader("Range") == null) {
/* 614 */       Assert.state((this.resourceHttpMessageConverter != null), "Not initialized");
/*     */       
/* 616 */       if (HttpMethod.HEAD.matches(request.getMethod())) {
/* 617 */         this.resourceHttpMessageConverter.addDefaultHeaders((HttpOutputMessage)outputMessage, resource, mediaType);
/* 618 */         outputMessage.flush();
/*     */       } else {
/*     */         
/* 621 */         this.resourceHttpMessageConverter.write(resource, mediaType, (HttpOutputMessage)outputMessage);
/*     */       } 
/*     */     } else {
/*     */       
/* 625 */       Assert.state((this.resourceRegionHttpMessageConverter != null), "Not initialized");
/* 626 */       ServletServerHttpRequest inputMessage = new ServletServerHttpRequest(request);
/*     */       try {
/* 628 */         List<HttpRange> httpRanges = inputMessage.getHeaders().getRange();
/* 629 */         response.setStatus(206);
/* 630 */         this.resourceRegionHttpMessageConverter.write(
/* 631 */             HttpRange.toResourceRegions(httpRanges, resource), mediaType, (HttpOutputMessage)outputMessage);
/*     */       }
/* 633 */       catch (IllegalArgumentException ex) {
/* 634 */         response.setContentType(null);
/* 635 */         response.setHeader("Content-Range", "bytes */" + resource.contentLength());
/* 636 */         response.sendError(416);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Resource getResource(HttpServletRequest request) throws IOException {
/* 643 */     String path = getPath(request);
/* 644 */     path = processPath(path);
/* 645 */     if (ResourceHandlerUtils.shouldIgnoreInputPath(path) || isInvalidPath(path)) {
/* 646 */       return null;
/*     */     }
/*     */     
/* 649 */     Assert.state((this.resolverChain != null), "ResourceResolverChain not initialized.");
/* 650 */     Assert.state((this.transformerChain != null), "ResourceTransformerChain not initialized.");
/*     */     
/* 652 */     Resource resource = this.resolverChain.resolveResource(request, path, getLocations());
/* 653 */     if (resource != null) {
/* 654 */       resource = this.transformerChain.transform(request, resource);
/*     */     }
/* 656 */     return resource;
/*     */   }
/*     */   
/*     */   private static String getPath(HttpServletRequest request) {
/* 660 */     String path = (String)request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
/* 661 */     if (path == null) {
/* 662 */       throw new IllegalStateException("Required request attribute '" + HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE + "' is not set");
/*     */     }
/*     */     
/* 665 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String processPath(String path) {
/* 674 */     return ResourceHandlerUtils.normalizeInputPath(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInvalidPath(String path) {
/* 683 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MediaType getMediaType(HttpServletRequest request, Resource resource) {
/* 702 */     MediaType result = null;
/* 703 */     String mimeType = request.getServletContext().getMimeType(resource.getFilename());
/* 704 */     if (StringUtils.hasText(mimeType)) {
/* 705 */       result = MediaType.parseMediaType(mimeType);
/*     */     }
/* 707 */     if (result == null || MediaType.APPLICATION_OCTET_STREAM.equals(result)) {
/* 708 */       MediaType mediaType = null;
/* 709 */       String filename = resource.getFilename();
/* 710 */       String ext = StringUtils.getFilenameExtension(filename);
/* 711 */       if (ext != null) {
/* 712 */         mediaType = this.mediaTypes.get(ext.toLowerCase(Locale.ROOT));
/*     */       }
/* 714 */       if (mediaType == null) {
/* 715 */         List<MediaType> mediaTypes = MediaTypeFactory.getMediaTypes(filename);
/* 716 */         if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 717 */           mediaType = mediaTypes.get(0);
/*     */         }
/*     */       } 
/* 720 */       if (mediaType != null) {
/* 721 */         result = mediaType;
/*     */       }
/*     */     } 
/* 724 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setHeaders(HttpServletResponse response, Resource resource, @Nullable MediaType mediaType) throws IOException {
/* 738 */     if (mediaType != null) {
/* 739 */       response.setContentType(mediaType.toString());
/*     */     }
/*     */     
/* 742 */     if (resource instanceof HttpResource) { HttpResource httpResource = (HttpResource)resource;
/* 743 */       HttpHeaders resourceHeaders = httpResource.getResponseHeaders();
/* 744 */       resourceHeaders.forEach((headerName, headerValues) -> {
/*     */             boolean first = true;
/*     */             
/*     */             for (String headerValue : headerValues) {
/*     */               if (first) {
/*     */                 response.setHeader(headerName, headerValue);
/*     */               } else {
/*     */                 response.addHeader(headerName, headerValue);
/*     */               } 
/*     */               
/*     */               first = false;
/*     */             } 
/*     */           }); }
/*     */     
/* 758 */     response.setHeader("Accept-Ranges", "bytes");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 764 */     return "ResourceHttpRequestHandler " + locationToString(getLocations());
/*     */   }
/*     */   
/*     */   private String locationToString(List<Resource> locations) {
/* 768 */     return locations.toString()
/* 769 */       .replaceAll("class path resource", "classpath")
/* 770 */       .replaceAll("ServletContext resource", "ServletContext");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\ResourceHttpRequestHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */