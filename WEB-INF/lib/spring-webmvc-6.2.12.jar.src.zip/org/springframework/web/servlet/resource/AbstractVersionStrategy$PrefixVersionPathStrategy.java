/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixVersionPathStrategy
/*     */   implements VersionPathStrategy
/*     */ {
/*     */   private final String prefix;
/*     */   
/*     */   public PrefixVersionPathStrategy(String version) {
/*  89 */     Assert.hasText(version, "Version must not be empty");
/*  90 */     this.prefix = version;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String extractVersion(String requestPath) {
/*  96 */     return requestPath.startsWith(this.prefix) ? this.prefix : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String removeVersion(String requestPath, String version) {
/* 101 */     return requestPath.substring(this.prefix.length());
/*     */   }
/*     */ 
/*     */   
/*     */   public String addVersion(String path, String version) {
/* 106 */     if (path.startsWith(".")) {
/* 107 */       return path;
/*     */     }
/*     */     
/* 110 */     return (this.prefix.endsWith("/") || path.startsWith("/")) ? (
/* 111 */       this.prefix + this.prefix) : (this.prefix + "/" + this.prefix);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\resource\AbstractVersionStrategy$PrefixVersionPathStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */