/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.task.TaskDecorator;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractEmitterSubscriber
/*     */   implements Subscriber<Object>, Runnable
/*     */ {
/*     */   private final ResponseBodyEmitter emitter;
/*     */   private final TaskExecutor taskExecutor;
/*     */   @Nullable
/*     */   private Subscription subscription;
/* 272 */   private final AtomicReference<Object> elementRef = new AtomicReference();
/*     */   
/*     */   @Nullable
/*     */   private Throwable error;
/*     */   
/*     */   private volatile boolean terminated;
/*     */   
/* 279 */   private final AtomicLong executing = new AtomicLong();
/*     */ 
/*     */   
/*     */   private volatile boolean done;
/*     */   
/*     */   private final Runnable sendTask;
/*     */ 
/*     */   
/*     */   protected AbstractEmitterSubscriber(ResponseBodyEmitter emitter, TaskExecutor executor, @Nullable TaskDecorator taskDecorator) {
/* 288 */     this.emitter = emitter;
/* 289 */     this.taskExecutor = executor;
/* 290 */     this.sendTask = (taskDecorator != null) ? taskDecorator.decorate(this) : this;
/*     */   }
/*     */   
/*     */   public void connect(ReactiveAdapter adapter, Object returnValue) {
/* 294 */     Publisher<Object> publisher = adapter.toPublisher(returnValue);
/* 295 */     publisher.subscribe(this);
/*     */   }
/*     */   
/*     */   protected ResponseBodyEmitter getEmitter() {
/* 299 */     return this.emitter;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription subscription) {
/* 304 */     this.subscription = subscription;
/* 305 */     this.emitter.onTimeout(() -> {
/*     */           if (ReactiveTypeHandler.logger.isTraceEnabled()) {
/*     */             ReactiveTypeHandler.logger.trace("Connection timeout for " + String.valueOf(this.emitter));
/*     */           }
/*     */           terminate();
/*     */           this.emitter.complete();
/*     */         });
/* 312 */     Objects.requireNonNull(this.emitter); this.emitter.onError(this.emitter::completeWithError);
/* 313 */     subscription.request(1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(Object element) {
/* 318 */     this.elementRef.lazySet(element);
/* 319 */     trySchedule();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable ex) {
/* 324 */     this.error = ex;
/* 325 */     this.terminated = true;
/* 326 */     trySchedule();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 331 */     this.terminated = true;
/* 332 */     trySchedule();
/*     */   }
/*     */   
/*     */   private void trySchedule() {
/* 336 */     if (this.executing.getAndIncrement() == 0L) {
/* 337 */       schedule();
/*     */     }
/*     */   }
/*     */   
/*     */   private void schedule() {
/*     */     try {
/* 343 */       this.taskExecutor.execute(this.sendTask);
/*     */     }
/* 345 */     catch (Throwable ex) {
/*     */       try {
/* 347 */         terminate();
/*     */       } finally {
/*     */         
/* 350 */         this.executing.decrementAndGet();
/* 351 */         this.elementRef.lazySet(null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 358 */     if (this.done) {
/* 359 */       this.elementRef.lazySet(null);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 364 */     boolean isTerminated = this.terminated;
/*     */     
/* 366 */     Object element = this.elementRef.get();
/* 367 */     if (element != null) {
/* 368 */       this.elementRef.lazySet(null);
/* 369 */       Assert.state((this.subscription != null), "No subscription");
/*     */       try {
/* 371 */         send(element);
/* 372 */         this.subscription.request(1L);
/*     */       }
/* 374 */       catch (Throwable ex) {
/* 375 */         if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 376 */           ReactiveTypeHandler.logger.debug("Send for " + String.valueOf(this.emitter) + " failed: " + String.valueOf(ex));
/*     */         }
/* 378 */         terminate();
/*     */         try {
/* 380 */           this.emitter.completeWithError(ex);
/*     */         }
/* 382 */         catch (Exception ex2) {
/* 383 */           if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 384 */             ReactiveTypeHandler.logger.debug("Failure from emitter completeWithError: " + String.valueOf(ex2));
/*     */           }
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 391 */     if (isTerminated) {
/* 392 */       this.done = true;
/* 393 */       Throwable ex = this.error;
/* 394 */       this.error = null;
/* 395 */       if (ex != null) {
/* 396 */         if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 397 */           ReactiveTypeHandler.logger.debug("Publisher for " + String.valueOf(this.emitter) + " failed: " + String.valueOf(ex));
/*     */         }
/*     */         try {
/* 400 */           this.emitter.completeWithError(ex);
/*     */         }
/* 402 */         catch (Exception ex2) {
/* 403 */           if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 404 */             ReactiveTypeHandler.logger.debug("Failure from emitter completeWithError: " + String.valueOf(ex2));
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 409 */         if (ReactiveTypeHandler.logger.isTraceEnabled()) {
/* 410 */           ReactiveTypeHandler.logger.trace("Publisher for " + String.valueOf(this.emitter) + " completed");
/*     */         }
/*     */         try {
/* 413 */           this.emitter.complete();
/*     */         }
/* 415 */         catch (Exception ex2) {
/* 416 */           if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 417 */             ReactiveTypeHandler.logger.debug("Failure from emitter complete: " + String.valueOf(ex2));
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 424 */     if (this.executing.decrementAndGet() != 0L) {
/* 425 */       schedule();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void terminate() {
/* 432 */     this.done = true;
/* 433 */     if (this.subscription != null)
/* 434 */       this.subscription.cancel(); 
/*     */   }
/*     */   
/*     */   protected abstract void send(Object paramObject) throws IOException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ReactiveTypeHandler$AbstractEmitterSubscriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */