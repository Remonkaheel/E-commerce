/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultSseEmitterHandler
/*     */   implements ResponseBodyEmitter.Handler
/*     */ {
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private final ResponseBodyEmitterReturnValueHandler.FragmentHandler fragmentHandler;
/*     */   private final ServerHttpResponse outputMessage;
/*     */   private final DeferredResult<?> deferredResult;
/*     */   
/*     */   public DefaultSseEmitterHandler(List<HttpMessageConverter<?>> messageConverters, ResponseBodyEmitterReturnValueHandler.FragmentHandler fragmentHandler, ServerHttpResponse outputMessage, DeferredResult<?> result) {
/* 287 */     this.messageConverters = messageConverters;
/* 288 */     this.fragmentHandler = fragmentHandler;
/* 289 */     this.outputMessage = outputMessage;
/* 290 */     this.deferredResult = result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void send(Object data, @Nullable MediaType mediaType) throws IOException {
/* 295 */     sendInternal(data, mediaType);
/* 296 */     this.outputMessage.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void send(Set<ResponseBodyEmitter.DataWithMediaType> items) throws IOException {
/* 301 */     for (ResponseBodyEmitter.DataWithMediaType item : items) {
/* 302 */       sendInternal(item.getData(), item.getMediaType());
/*     */     }
/* 304 */     this.outputMessage.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> void sendInternal(T data, @Nullable MediaType mediaType) throws IOException {
/* 309 */     if (data instanceof ModelAndView) { ModelAndView mav = (ModelAndView)data;
/* 310 */       this.fragmentHandler.handle(mav);
/*     */       return; }
/*     */     
/* 313 */     for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 314 */       if (converter.canWrite(data.getClass(), mediaType)) {
/* 315 */         converter.write(data, mediaType, (HttpOutputMessage)this.outputMessage);
/*     */         return;
/*     */       } 
/*     */     } 
/* 319 */     throw new IllegalArgumentException("No suitable converter for " + String.valueOf(data.getClass()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void complete() {
/*     */     try {
/* 325 */       this.outputMessage.flush();
/* 326 */       this.deferredResult.setResult(null);
/*     */     }
/* 328 */     catch (IOException ex) {
/* 329 */       this.deferredResult.setErrorResult(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void completeWithError(Throwable failure) {
/* 335 */     this.deferredResult.setErrorResult(failure);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTimeout(Runnable callback) {
/* 340 */     this.deferredResult.onTimeout(callback);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Consumer<Throwable> callback) {
/* 345 */     this.deferredResult.onError(callback);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCompletion(Runnable callback) {
/* 350 */     this.deferredResult.onCompletion(callback);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitterReturnValueHandler$DefaultSseEmitterHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */