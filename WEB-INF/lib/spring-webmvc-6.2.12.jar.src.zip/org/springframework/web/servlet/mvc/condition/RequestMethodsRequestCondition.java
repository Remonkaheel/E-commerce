/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestMethodsRequestCondition
/*     */   extends AbstractRequestCondition<RequestMethodsRequestCondition>
/*     */ {
/*  51 */   private static final Map<String, RequestMethodsRequestCondition> requestMethodConditionCache = CollectionUtils.newHashMap((RequestMethod.values()).length); static {
/*  52 */     for (RequestMethod method : RequestMethod.values()) {
/*  53 */       requestMethodConditionCache.put(method.name(), new RequestMethodsRequestCondition(new RequestMethod[] { method }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Set<RequestMethod> methods;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMethodsRequestCondition(RequestMethod... requestMethods) {
/*  67 */     this
/*  68 */       .methods = ObjectUtils.isEmpty((Object[])requestMethods) ? Collections.<RequestMethod>emptySet() : new LinkedHashSet<>(Arrays.asList(requestMethods));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestMethodsRequestCondition(Set<RequestMethod> methods) {
/*  75 */     this.methods = methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<RequestMethod> getMethods() {
/*  83 */     return this.methods;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<RequestMethod> getContent() {
/*  88 */     return this.methods;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getToStringInfix() {
/*  93 */     return " || ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMethodsRequestCondition combine(RequestMethodsRequestCondition other) {
/* 102 */     if (isEmpty() && other.isEmpty()) {
/* 103 */       return this;
/*     */     }
/* 105 */     if (other.isEmpty()) {
/* 106 */       return this;
/*     */     }
/* 108 */     if (isEmpty()) {
/* 109 */       return other;
/*     */     }
/* 111 */     Set<RequestMethod> set = new LinkedHashSet<>(this.methods);
/* 112 */     set.addAll(other.methods);
/* 113 */     return new RequestMethodsRequestCondition(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RequestMethodsRequestCondition getMatchingCondition(HttpServletRequest request) {
/* 128 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 129 */       return matchPreFlight(request);
/*     */     }
/*     */     
/* 132 */     if (getMethods().isEmpty()) {
/* 133 */       if (RequestMethod.OPTIONS.name().equals(request.getMethod()) && 
/* 134 */         !DispatcherType.ERROR.equals(request.getDispatcherType()))
/*     */       {
/* 136 */         return null;
/*     */       }
/* 138 */       return this;
/*     */     } 
/*     */     
/* 141 */     return matchRequestMethod(request.getMethod());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private RequestMethodsRequestCondition matchPreFlight(HttpServletRequest request) {
/* 151 */     if (getMethods().isEmpty()) {
/* 152 */       return this;
/*     */     }
/* 154 */     String expectedMethod = request.getHeader("Access-Control-Request-Method");
/* 155 */     return matchRequestMethod(expectedMethod);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RequestMethodsRequestCondition matchRequestMethod(String httpMethodValue) {
/* 160 */     RequestMethod requestMethod = RequestMethod.resolve(httpMethodValue);
/* 161 */     if (requestMethod != null) {
/* 162 */       if (getMethods().contains(requestMethod)) {
/* 163 */         return requestMethodConditionCache.get(httpMethodValue);
/*     */       }
/* 165 */       if (requestMethod.equals(RequestMethod.HEAD) && getMethods().contains(RequestMethod.GET)) {
/* 166 */         return requestMethodConditionCache.get(HttpMethod.GET.name());
/*     */       }
/*     */     } 
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(RequestMethodsRequestCondition other, HttpServletRequest request) {
/* 185 */     if (other.methods.size() != this.methods.size()) {
/* 186 */       return other.methods.size() - this.methods.size();
/*     */     }
/* 188 */     if (this.methods.size() == 1) {
/* 189 */       if (this.methods.contains(RequestMethod.HEAD) && other.methods.contains(RequestMethod.GET)) {
/* 190 */         return -1;
/*     */       }
/* 192 */       if (this.methods.contains(RequestMethod.GET) && other.methods.contains(RequestMethod.HEAD)) {
/* 193 */         return 1;
/*     */       }
/*     */     } 
/* 196 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\RequestMethodsRequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */