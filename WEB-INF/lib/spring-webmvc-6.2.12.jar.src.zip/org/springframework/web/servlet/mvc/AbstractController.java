/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractController
/*     */   extends WebContentGenerator
/*     */   implements Controller
/*     */ {
/*     */   private boolean synchronizeOnSession = false;
/*     */   
/*     */   public AbstractController() {
/* 107 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractController(boolean restrictDefaultSupportedMethods) {
/* 118 */     super(restrictDefaultSupportedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSynchronizeOnSession(boolean synchronizeOnSession) {
/* 142 */     this.synchronizeOnSession = synchronizeOnSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSynchronizeOnSession() {
/* 149 */     return this.synchronizeOnSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 158 */     if (HttpMethod.OPTIONS.matches(request.getMethod())) {
/* 159 */       response.setHeader("Allow", getAllowHeader());
/* 160 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 164 */     checkRequest(request);
/* 165 */     prepareResponse(response);
/*     */ 
/*     */     
/* 168 */     if (this.synchronizeOnSession) {
/* 169 */       HttpSession session = request.getSession(false);
/* 170 */       if (session != null) {
/* 171 */         Object mutex = WebUtils.getSessionMutex(session);
/* 172 */         synchronized (mutex) {
/* 173 */           return handleRequestInternal(request, response);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 178 */     return handleRequestInternal(request, response);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract ModelAndView handleRequestInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws Exception;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\AbstractController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */