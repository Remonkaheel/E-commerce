package org.springframework.web.servlet.mvc;

import jakarta.servlet.http.HttpServletRequest;

@Deprecated
public interface LastModified {
  long getLastModified(HttpServletRequest paramHttpServletRequest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\LastModified.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */