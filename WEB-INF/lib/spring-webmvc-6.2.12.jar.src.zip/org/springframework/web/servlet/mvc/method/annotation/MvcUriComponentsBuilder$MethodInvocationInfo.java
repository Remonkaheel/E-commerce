package org.springframework.web.servlet.mvc.method.annotation;

import java.lang.reflect.Method;

public interface MethodInvocationInfo {
  Class<?> getControllerType();
  
  Method getControllerMethod();
  
  Object[] getArgumentValues();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\MvcUriComponentsBuilder$MethodInvocationInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */