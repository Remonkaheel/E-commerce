package org.springframework.web.servlet.mvc.method.annotation;

import java.io.IOException;
import java.util.Set;
import java.util.function.Consumer;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;

interface Handler {
  void send(Object paramObject, @Nullable MediaType paramMediaType) throws IOException;
  
  void send(Set<ResponseBodyEmitter.DataWithMediaType> paramSet) throws IOException;
  
  void complete();
  
  void completeWithError(Throwable paramThrowable);
  
  void onTimeout(Runnable paramRunnable);
  
  void onError(Consumer<Throwable> paramConsumer);
  
  void onCompletion(Runnable paramRunnable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitter$Handler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */