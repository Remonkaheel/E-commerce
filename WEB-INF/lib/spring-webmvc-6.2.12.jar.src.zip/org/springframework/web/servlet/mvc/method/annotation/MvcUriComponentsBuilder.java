/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotatedMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.SpringObjenesis;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.annotation.RequestParamMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping;
/*     */ import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MvcUriComponentsBuilder
/*     */ {
/*     */   public static final String MVC_URI_COMPONENTS_CONTRIBUTOR_BEAN_NAME = "mvcUriComponentsContributor";
/* 109 */   private static final Log logger = LogFactory.getLog(MvcUriComponentsBuilder.class);
/*     */   
/* 111 */   private static final SpringObjenesis objenesis = new SpringObjenesis();
/*     */   
/* 113 */   private static final PathMatcher pathMatcher = (PathMatcher)new AntPathMatcher();
/*     */   
/* 115 */   private static final ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private static final CompositeUriComponentsContributor defaultUriComponentsContributor = new CompositeUriComponentsContributor(new UriComponentsContributor[] { new PathVariableMethodArgumentResolver(), (UriComponentsContributor)new RequestParamMethodArgumentResolver(false) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final UriComponentsBuilder baseUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MvcUriComponentsBuilder(UriComponentsBuilder baseUrl) {
/* 136 */     Assert.notNull(baseUrl, "'baseUrl' is required");
/* 137 */     this.baseUrl = baseUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MvcUriComponentsBuilder relativeTo(UriComponentsBuilder baseUrl) {
/* 147 */     return new MvcUriComponentsBuilder(baseUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromController(Class<?> controllerType) {
/* 159 */     return fromController(null, controllerType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromController(@Nullable UriComponentsBuilder builder, Class<?> controllerType) {
/* 175 */     builder = getBaseUrlToUse(builder);
/*     */ 
/*     */     
/* 178 */     String prefix = getPathPrefix(controllerType);
/* 179 */     builder.path(prefix);
/*     */     
/* 181 */     String mapping = getClassMapping(controllerType);
/* 182 */     mapping = !StringUtils.hasText(prefix + prefix) ? "/" : mapping;
/* 183 */     builder.path(mapping);
/*     */     
/* 185 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromMethodName(Class<?> controllerType, String methodName, Object... args) {
/* 202 */     Method method = getMethod(controllerType, methodName, args);
/* 203 */     return fromMethodInternal(null, controllerType, method, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromMethodName(UriComponentsBuilder builder, Class<?> controllerType, String methodName, Object... args) {
/* 223 */     Method method = getMethod(controllerType, methodName, args);
/* 224 */     return fromMethodInternal(builder, controllerType, method, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromMethod(Class<?> controllerType, Method method, Object... args) {
/* 242 */     return fromMethodInternal(null, controllerType, method, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromMethod(UriComponentsBuilder baseUrl, @Nullable Class<?> controllerType, Method method, Object... args) {
/* 262 */     return fromMethodInternal(baseUrl, 
/* 263 */         (controllerType != null) ? controllerType : method.getDeclaringClass(), method, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromMethodCall(Object info) {
/* 304 */     Assert.isInstanceOf(MethodInvocationInfo.class, info, "MethodInvocationInfo required");
/* 305 */     MethodInvocationInfo invocationInfo = (MethodInvocationInfo)info;
/* 306 */     Class<?> controllerType = invocationInfo.getControllerType();
/* 307 */     Method method = invocationInfo.getControllerMethod();
/* 308 */     Object[] arguments = invocationInfo.getArgumentValues();
/* 309 */     return fromMethodInternal(null, controllerType, method, arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UriComponentsBuilder fromMethodCall(UriComponentsBuilder builder, Object info) {
/* 324 */     Assert.isInstanceOf(MethodInvocationInfo.class, info, "MethodInvocationInfo required");
/* 325 */     MethodInvocationInfo invocationInfo = (MethodInvocationInfo)info;
/* 326 */     Class<?> controllerType = invocationInfo.getControllerType();
/* 327 */     Method method = invocationInfo.getControllerMethod();
/* 328 */     Object[] arguments = invocationInfo.getArgumentValues();
/* 329 */     return fromMethodInternal(builder, controllerType, method, arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T on(Class<T> controllerType) {
/* 345 */     return controller(controllerType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T controller(Class<T> controllerType) {
/* 367 */     Assert.notNull(controllerType, "'controllerType' must not be null");
/* 368 */     return ControllerMethodInvocationInterceptor.initProxy(controllerType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodArgumentBuilder fromMappingName(String mappingName) {
/* 413 */     return fromMappingName(null, mappingName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodArgumentBuilder fromMappingName(@Nullable UriComponentsBuilder builder, String name) {
/* 430 */     WebApplicationContext wac = getWebApplicationContext();
/* 431 */     Assert.state((wac != null), "No WebApplicationContext");
/* 432 */     Map<String, RequestMappingInfoHandlerMapping> map = wac.getBeansOfType(RequestMappingInfoHandlerMapping.class);
/* 433 */     List<HandlerMethod> handlerMethods = null;
/* 434 */     for (RequestMappingInfoHandlerMapping mapping : map.values()) {
/* 435 */       handlerMethods = mapping.getHandlerMethodsForMappingName(name);
/* 436 */       if (handlerMethods != null) {
/*     */         break;
/*     */       }
/*     */     } 
/* 440 */     if (handlerMethods == null) {
/* 441 */       throw new IllegalArgumentException("Mapping not found: " + name);
/*     */     }
/* 443 */     if (handlerMethods.size() != 1) {
/* 444 */       throw new IllegalArgumentException("No unique match for mapping " + name + ": " + String.valueOf(handlerMethods));
/*     */     }
/*     */     
/* 447 */     HandlerMethod handlerMethod = handlerMethods.get(0);
/* 448 */     Class<?> controllerType = handlerMethod.getBeanType();
/* 449 */     Method method = handlerMethod.getMethod();
/* 450 */     return new MethodArgumentBuilder(builder, controllerType, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UriComponentsBuilder withController(Class<?> controllerType) {
/* 463 */     return fromController(this.baseUrl, controllerType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UriComponentsBuilder withMethodName(Class<?> controllerType, String methodName, Object... args) {
/* 472 */     return fromMethodName(this.baseUrl, controllerType, methodName, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UriComponentsBuilder withMethodCall(Object invocationInfo) {
/* 481 */     return fromMethodCall(this.baseUrl, invocationInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodArgumentBuilder withMappingName(String mappingName) {
/* 490 */     return fromMappingName(this.baseUrl, mappingName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UriComponentsBuilder withMethod(Class<?> controllerType, Method method, Object... args) {
/* 499 */     return fromMethod(this.baseUrl, controllerType, method, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static UriComponentsBuilder fromMethodInternal(@Nullable UriComponentsBuilder builder, Class<?> controllerType, Method method, Object... args) {
/* 506 */     AnnotatedMethod annotatedMethod = new AnnotatedMethod(method);
/* 507 */     builder = getBaseUrlToUse(builder);
/*     */ 
/*     */     
/* 510 */     String prefix = getPathPrefix(controllerType);
/* 511 */     builder.path(prefix);
/*     */     
/* 513 */     String typePath = getClassMapping(controllerType);
/* 514 */     String methodPath = getMethodMapping(annotatedMethod);
/* 515 */     String path = pathMatcher.combine(typePath, methodPath);
/* 516 */     path = PathPatternParser.defaultInstance.initFullPathPattern(path);
/* 517 */     if (!StringUtils.hasText(prefix + prefix)) {
/* 518 */       path = "/";
/*     */     }
/* 520 */     builder.path(path);
/*     */     
/* 522 */     return applyContributors(builder, annotatedMethod, args);
/*     */   }
/*     */   
/*     */   private static UriComponentsBuilder getBaseUrlToUse(@Nullable UriComponentsBuilder baseUrl) {
/* 526 */     return (baseUrl == null) ? 
/* 527 */       (UriComponentsBuilder)ServletUriComponentsBuilder.fromCurrentServletMapping() : 
/* 528 */       baseUrl.cloneBuilder();
/*     */   }
/*     */   
/*     */   private static String getPathPrefix(Class<?> controllerType) {
/* 532 */     WebApplicationContext wac = getWebApplicationContext();
/* 533 */     if (wac != null) {
/* 534 */       Map<String, RequestMappingHandlerMapping> map = wac.getBeansOfType(RequestMappingHandlerMapping.class);
/* 535 */       for (RequestMappingHandlerMapping mapping : map.values()) {
/* 536 */         if (mapping.isHandler(controllerType)) {
/* 537 */           String prefix = mapping.getPathPrefix(controllerType);
/* 538 */           if (prefix != null) {
/* 539 */             return prefix;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 544 */     return "";
/*     */   }
/*     */   
/*     */   private static String getClassMapping(Class<?> controllerType) {
/* 548 */     Assert.notNull(controllerType, "'controllerType' must not be null");
/* 549 */     RequestMapping mapping = (RequestMapping)AnnotatedElementUtils.findMergedAnnotation(controllerType, RequestMapping.class);
/* 550 */     if (mapping == null) {
/* 551 */       return "";
/*     */     }
/* 553 */     return getPathMapping(mapping, controllerType.getName());
/*     */   }
/*     */   
/*     */   private static String getMethodMapping(AnnotatedMethod annotatedMethod) {
/* 557 */     RequestMapping requestMapping = (RequestMapping)annotatedMethod.getMethodAnnotation(RequestMapping.class);
/* 558 */     if (requestMapping == null) {
/* 559 */       throw new IllegalArgumentException("No @RequestMapping on: " + annotatedMethod.getMethod().toGenericString());
/*     */     }
/* 561 */     return getPathMapping(requestMapping, annotatedMethod.getMethod().toGenericString());
/*     */   }
/*     */   
/*     */   private static String getPathMapping(RequestMapping requestMapping, String source) {
/* 565 */     String[] paths = requestMapping.path();
/* 566 */     if (ObjectUtils.isEmpty((Object[])paths) || !StringUtils.hasLength(paths[0])) {
/* 567 */       return "";
/*     */     }
/* 569 */     if (paths.length > 1 && logger.isTraceEnabled()) {
/* 570 */       logger.trace("Using first of multiple paths on " + source);
/*     */     }
/* 572 */     return resolveEmbeddedValue(paths[0]);
/*     */   }
/*     */   
/*     */   private static Method getMethod(Class<?> controllerType, String methodName, Object... args) {
/* 576 */     ReflectionUtils.MethodFilter selector = method -> {
/*     */         String name = method.getName();
/*     */         int argLength = method.getParameterCount();
/* 579 */         return (name.equals(methodName) && argLength == args.length);
/*     */       };
/* 581 */     Set<Method> methods = MethodIntrospector.selectMethods(controllerType, selector);
/* 582 */     if (methods.size() == 1) {
/* 583 */       return methods.iterator().next();
/*     */     }
/* 585 */     if (methods.size() > 1) {
/* 586 */       throw new IllegalArgumentException(String.format("Found two methods named '%s' accepting arguments %s in controller %s: [%s]", new Object[] { methodName, 
/*     */               
/* 588 */               Arrays.asList(args), controllerType.getName(), methods }));
/*     */     }
/*     */     
/* 591 */     throw new IllegalArgumentException("No method named '" + methodName + "' with " + args.length + " arguments found in controller " + controllerType
/* 592 */         .getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static UriComponentsBuilder applyContributors(UriComponentsBuilder builder, AnnotatedMethod annotatedMethod, Object... args) {
/* 599 */     CompositeUriComponentsContributor contributor = getUriComponentsContributor();
/*     */     
/* 601 */     int paramCount = (annotatedMethod.getMethodParameters()).length;
/* 602 */     int argCount = args.length;
/* 603 */     if (paramCount != argCount) {
/* 604 */       throw new IllegalArgumentException("Number of method parameters " + paramCount + " does not match number of argument values " + argCount);
/*     */     }
/*     */ 
/*     */     
/* 608 */     Map<String, Object> uriVars = new HashMap<>();
/* 609 */     for (int i = 0; i < paramCount; i++) {
/* 610 */       MethodParameter param = annotatedMethod.getMethodParameters()[i];
/* 611 */       param.initParameterNameDiscovery(parameterNameDiscoverer);
/* 612 */       contributor.contributeMethodArgument(param, args[i], builder, uriVars);
/*     */     } 
/*     */ 
/*     */     
/* 616 */     return builder.uriVariables(uriVars);
/*     */   }
/*     */   
/*     */   private static CompositeUriComponentsContributor getUriComponentsContributor() {
/* 620 */     WebApplicationContext wac = getWebApplicationContext();
/* 621 */     if (wac != null) {
/*     */       try {
/* 623 */         return (CompositeUriComponentsContributor)wac.getBean("mvcUriComponentsContributor", CompositeUriComponentsContributor.class);
/*     */       }
/* 625 */       catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     }
/*     */ 
/*     */     
/* 629 */     return defaultUriComponentsContributor;
/*     */   }
/*     */   
/*     */   private static String resolveEmbeddedValue(String value) {
/* 633 */     if (value.contains("${")) {
/* 634 */       WebApplicationContext webApplicationContext = getWebApplicationContext();
/* 635 */       if (webApplicationContext != null) {
/* 636 */         AutowireCapableBeanFactory autowireCapableBeanFactory = webApplicationContext.getAutowireCapableBeanFactory(); if (autowireCapableBeanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)autowireCapableBeanFactory;
/* 637 */           String resolvedEmbeddedValue = cbf.resolveEmbeddedValue(value);
/* 638 */           if (resolvedEmbeddedValue != null)
/* 639 */             return resolvedEmbeddedValue;  }
/*     */       
/*     */       } 
/*     */     } 
/* 643 */     return value;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static WebApplicationContext getWebApplicationContext() {
/* 648 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 649 */     if (requestAttributes == null) {
/* 650 */       return null;
/*     */     }
/* 652 */     HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
/* 653 */     String attributeName = DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE;
/* 654 */     WebApplicationContext wac = (WebApplicationContext)request.getAttribute(attributeName);
/* 655 */     if (wac == null) {
/* 656 */       return null;
/*     */     }
/* 658 */     return wac;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface MethodInvocationInfo
/*     */   {
/*     */     Class<?> getControllerType();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getControllerMethod();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object[] getArgumentValues();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ControllerMethodInvocationInterceptor
/*     */     implements MethodInterceptor, InvocationHandler, MethodInvocationInfo
/*     */   {
/*     */     private final Class<?> controllerType;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Method controllerMethod;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Object[] argumentValues;
/*     */ 
/*     */ 
/*     */     
/*     */     ControllerMethodInvocationInterceptor(Class<?> controllerType) {
/* 697 */       this.controllerType = controllerType;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(@Nullable Object obj, Method method, Object[] args, @Nullable MethodProxy proxy) {
/* 703 */       switch (method.getName()) {
/*     */         case "getControllerType":
/* 705 */           return this.controllerType;
/*     */         
/*     */         case "getControllerMethod":
/* 708 */           return this.controllerMethod;
/*     */         
/*     */         case "getArgumentValues":
/* 711 */           return this.argumentValues;
/*     */       } 
/*     */       
/* 714 */       if (ReflectionUtils.isObjectMethod(method)) {
/* 715 */         return ReflectionUtils.invokeMethod(method, obj, args);
/*     */       }
/*     */       
/* 718 */       this.controllerMethod = method;
/* 719 */       this.argumentValues = args;
/* 720 */       Class<?> returnType = method.getReturnType();
/*     */       try {
/* 722 */         return (returnType == void.class) ? null : returnType.cast(initProxy(returnType, this));
/*     */       }
/* 724 */       catch (Throwable ex) {
/* 725 */         throw new IllegalStateException("Failed to create proxy for controller method return type: " + String.valueOf(method), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(Object proxy, Method method, @Nullable Object[] args) {
/* 736 */       return intercept(proxy, method, (args != null) ? args : new Object[0], null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getControllerType() {
/* 741 */       return this.controllerType;
/*     */     }
/*     */ 
/*     */     
/*     */     public Method getControllerMethod() {
/* 746 */       Assert.state((this.controllerMethod != null), "Not initialized yet");
/* 747 */       return this.controllerMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] getArgumentValues() {
/* 752 */       Assert.state((this.argumentValues != null), "Not initialized yet");
/* 753 */       return this.argumentValues;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T> T initProxy(Class<?> controllerType, @Nullable ControllerMethodInvocationInterceptor interceptor) {
/* 762 */       interceptor = (interceptor != null) ? interceptor : new ControllerMethodInvocationInterceptor(controllerType);
/*     */       
/* 764 */       if (controllerType == Object.class) {
/* 765 */         return (T)interceptor;
/*     */       }
/*     */       
/* 768 */       if (controllerType.isInterface()) {
/* 769 */         ClassLoader classLoader = controllerType.getClassLoader();
/* 770 */         if (classLoader == null) {
/*     */           
/* 772 */           classLoader = MvcUriComponentsBuilder.MethodInvocationInfo.class.getClassLoader();
/*     */         }
/* 774 */         else if (classLoader.getParent() == null) {
/*     */           
/* 776 */           ClassLoader miiClassLoader = MvcUriComponentsBuilder.MethodInvocationInfo.class.getClassLoader();
/* 777 */           ClassLoader miiParent = miiClassLoader.getParent();
/* 778 */           while (miiParent != null) {
/* 779 */             if (classLoader == miiParent) {
/*     */ 
/*     */               
/* 782 */               classLoader = miiClassLoader;
/*     */               break;
/*     */             } 
/* 785 */             miiParent = miiParent.getParent();
/*     */           } 
/*     */         } 
/* 788 */         Class<?>[] ifcs = new Class[] { controllerType, MvcUriComponentsBuilder.MethodInvocationInfo.class };
/* 789 */         return (T)Proxy.newProxyInstance(classLoader, ifcs, interceptor);
/*     */       } 
/*     */ 
/*     */       
/* 793 */       Enhancer enhancer = new Enhancer();
/* 794 */       enhancer.setSuperclass(controllerType);
/* 795 */       enhancer.setInterfaces(new Class[] { MvcUriComponentsBuilder.MethodInvocationInfo.class });
/* 796 */       enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 797 */       enhancer.setAttemptLoad(AotDetector.useGeneratedArtifacts());
/* 798 */       enhancer.setCallbackType(MethodInterceptor.class);
/*     */       
/* 800 */       Class<?> proxyClass = enhancer.createClass();
/* 801 */       Object proxy = null;
/*     */       
/* 803 */       if (MvcUriComponentsBuilder.objenesis.isWorthTrying()) {
/*     */         try {
/* 805 */           proxy = MvcUriComponentsBuilder.objenesis.newInstance(proxyClass, enhancer.getUseCache());
/*     */         }
/* 807 */         catch (ObjenesisException ex) {
/* 808 */           MvcUriComponentsBuilder.logger.debug("Failed to create controller proxy, falling back on default constructor", (Throwable)ex);
/*     */         } 
/*     */       }
/*     */       
/* 812 */       if (proxy == null) {
/*     */         try {
/* 814 */           proxy = ReflectionUtils.accessibleConstructor(proxyClass, new Class[0]).newInstance(new Object[0]);
/*     */         }
/* 816 */         catch (Throwable ex) {
/* 817 */           throw new IllegalStateException("Failed to create controller proxy or use default constructor", ex);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 822 */       ((Factory)proxy).setCallbacks(new Callback[] { (Callback)interceptor });
/* 823 */       return (T)proxy;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MethodArgumentBuilder
/*     */   {
/*     */     private final Class<?> controllerType;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Method method;
/*     */ 
/*     */     
/*     */     private final Object[] argumentValues;
/*     */ 
/*     */     
/*     */     private final UriComponentsBuilder baseUrl;
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodArgumentBuilder(Class<?> controllerType, Method method) {
/* 847 */       this(null, controllerType, method);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodArgumentBuilder(@Nullable UriComponentsBuilder baseUrl, Class<?> controllerType, Method method) {
/* 855 */       Assert.notNull(controllerType, "'controllerType' is required");
/* 856 */       Assert.notNull(method, "'method' is required");
/* 857 */       this.baseUrl = (baseUrl != null) ? baseUrl : UriComponentsBuilder.fromPath(getPath());
/* 858 */       this.controllerType = controllerType;
/* 859 */       this.method = method;
/* 860 */       this.argumentValues = new Object[method.getParameterCount()];
/*     */     }
/*     */     
/*     */     private static String getPath() {
/* 864 */       ServletUriComponentsBuilder servletUriComponentsBuilder = ServletUriComponentsBuilder.fromCurrentServletMapping();
/* 865 */       String path = servletUriComponentsBuilder.build().getPath();
/* 866 */       return (path != null) ? path : "";
/*     */     }
/*     */     
/*     */     public MethodArgumentBuilder arg(int index, Object value) {
/* 870 */       this.argumentValues[index] = value;
/* 871 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodArgumentBuilder encode() {
/* 880 */       this.baseUrl.encode();
/* 881 */       return this;
/*     */     }
/*     */     
/*     */     public String build() {
/* 885 */       return MvcUriComponentsBuilder.fromMethodInternal(this.baseUrl, this.controllerType, this.method, this.argumentValues)
/* 886 */         .build().encode().toUriString();
/*     */     }
/*     */     
/*     */     public String buildAndExpand(Object... uriVars) {
/* 890 */       return MvcUriComponentsBuilder.fromMethodInternal(this.baseUrl, this.controllerType, this.method, this.argumentValues)
/* 891 */         .buildAndExpand(uriVars).encode().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\MvcUriComponentsBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */