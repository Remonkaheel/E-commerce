/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.WriteListener;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.task.SyncTaskExecutor;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.server.DelegatingServerHttpResponse;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.filter.ShallowEtagHeaderFilter;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*     */ import org.springframework.web.servlet.view.FragmentsRendering;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseBodyEmitterReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   private final List<HttpMessageConverter<?>> sseMessageConverters;
/*     */   private final ReactiveTypeHandler reactiveHandler;
/*     */   private final List<ViewResolver> viewResolvers;
/*     */   private final LocaleResolver localeResolver;
/*     */   
/*     */   public ResponseBodyEmitterReturnValueHandler(List<HttpMessageConverter<?>> messageConverters) {
/* 112 */     this(messageConverters, 
/* 113 */         ReactiveAdapterRegistry.getSharedInstance(), (TaskExecutor)new SyncTaskExecutor(), new ContentNegotiationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBodyEmitterReturnValueHandler(List<HttpMessageConverter<?>> messageConverters, ReactiveAdapterRegistry registry, TaskExecutor executor, ContentNegotiationManager manager) {
/* 128 */     this(messageConverters, registry, executor, manager, Collections.emptyList(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBodyEmitterReturnValueHandler(List<HttpMessageConverter<?>> messageConverters, ReactiveAdapterRegistry registry, TaskExecutor executor, ContentNegotiationManager manager, List<ViewResolver> viewResolvers, @Nullable LocaleResolver localeResolver) {
/* 146 */     Assert.notEmpty(messageConverters, "HttpMessageConverter List must not be empty");
/* 147 */     this.sseMessageConverters = initSseConverters(messageConverters);
/* 148 */     this.reactiveHandler = new ReactiveTypeHandler(registry, executor, manager, null);
/* 149 */     this.viewResolvers = viewResolvers;
/* 150 */     this.localeResolver = (localeResolver != null) ? localeResolver : (LocaleResolver)new AcceptHeaderLocaleResolver();
/*     */   }
/*     */   
/*     */   private static List<HttpMessageConverter<?>> initSseConverters(List<HttpMessageConverter<?>> converters) {
/* 154 */     for (HttpMessageConverter<?> converter : converters) {
/* 155 */       if (converter.canWrite(String.class, MediaType.TEXT_PLAIN)) {
/* 156 */         return converters;
/*     */       }
/*     */     } 
/* 159 */     List<HttpMessageConverter<?>> result = new ArrayList<>(converters.size() + 1);
/* 160 */     result.add(new StringHttpMessageConverter(StandardCharsets.UTF_8));
/* 161 */     result.addAll(converters);
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsReturnType(MethodParameter returnType) {
/* 170 */     Class<?> bodyType = ResponseEntity.class.isAssignableFrom(returnType.getParameterType()) ? ResolvableType.forMethodParameter(returnType).getGeneric(new int[0]).resolve() : returnType.getParameterType();
/*     */     
/* 172 */     return (bodyType != null && supportsBodyType(bodyType));
/*     */   }
/*     */   
/*     */   boolean supportsBodyType(Class<?> bodyType) {
/* 176 */     return (ResponseBodyEmitter.class.isAssignableFrom(bodyType) || this.reactiveHandler.isReactiveType(bodyType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
/*     */     ResponseBodyEmitter emitter;
/*     */     DefaultSseEmitterHandler emitterHandler;
/* 184 */     if (returnValue == null) {
/* 185 */       mavContainer.setRequestHandled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 189 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/* 190 */     Assert.state((response != null), "No HttpServletResponse");
/* 191 */     ServletServerHttpResponse servletServerHttpResponse = new ServletServerHttpResponse(response);
/* 192 */     MediaType contentType = null;
/*     */     
/* 194 */     if (returnValue instanceof ResponseEntity) { ResponseEntity<?> responseEntity = (ResponseEntity)returnValue;
/* 195 */       response.setStatus(responseEntity.getStatusCode().value());
/* 196 */       servletServerHttpResponse.getHeaders().putAll((Map)responseEntity.getHeaders());
/* 197 */       contentType = responseEntity.getHeaders().getContentType();
/* 198 */       returnValue = responseEntity.getBody();
/* 199 */       returnType = returnType.nested();
/* 200 */       if (returnValue == null) {
/* 201 */         mavContainer.setRequestHandled(true);
/* 202 */         servletServerHttpResponse.flush();
/*     */         
/*     */         return;
/*     */       }  }
/*     */     
/* 207 */     HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 208 */     Assert.state((request != null), "No ServletRequest");
/*     */ 
/*     */     
/* 211 */     if (returnValue instanceof ResponseBodyEmitter) { ResponseBodyEmitter responseBodyEmitter = (ResponseBodyEmitter)returnValue;
/* 212 */       emitter = responseBodyEmitter; }
/*     */     else
/*     */     
/* 215 */     { emitter = this.reactiveHandler.handleValue(returnValue, returnType, contentType, mavContainer, webRequest);
/* 216 */       if (emitter == null) {
/*     */         
/* 218 */         servletServerHttpResponse.getHeaders().forEach((headerName, headerValues) -> {
/*     */               for (String headerValue : headerValues) {
/*     */                 response.addHeader(headerName, headerValue);
/*     */               }
/*     */             });
/*     */         return;
/*     */       }  }
/*     */     
/* 226 */     emitter.extendResponse((ServerHttpResponse)servletServerHttpResponse);
/*     */ 
/*     */     
/* 229 */     ShallowEtagHeaderFilter.disableContentCaching((ServletRequest)request);
/*     */ 
/*     */     
/* 232 */     StreamingServletServerHttpResponse streamingServletServerHttpResponse = new StreamingServletServerHttpResponse((ServerHttpResponse)servletServerHttpResponse);
/*     */ 
/*     */     
/*     */     try {
/* 236 */       DeferredResult<?> result = new DeferredResult(emitter.getTimeout());
/* 237 */       WebAsyncUtils.getAsyncManager((WebRequest)webRequest).startDeferredResultProcessing(result, new Object[] { mavContainer });
/* 238 */       FragmentHandler handler = new FragmentHandler(request, response, this.viewResolvers, this.localeResolver);
/* 239 */       emitterHandler = new DefaultSseEmitterHandler(this.sseMessageConverters, handler, (ServerHttpResponse)streamingServletServerHttpResponse, result);
/*     */     }
/* 241 */     catch (Throwable ex) {
/* 242 */       emitter.initializeWithError(ex);
/* 243 */       throw ex;
/*     */     } 
/*     */     
/* 246 */     emitter.initialize(emitterHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StreamingServletServerHttpResponse
/*     */     extends DelegatingServerHttpResponse
/*     */   {
/* 256 */     private final HttpHeaders mutableHeaders = new HttpHeaders();
/*     */     
/*     */     public StreamingServletServerHttpResponse(ServerHttpResponse delegate) {
/* 259 */       super(delegate);
/* 260 */       this.mutableHeaders.putAll((Map)delegate.getHeaders());
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 265 */       return this.mutableHeaders;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultSseEmitterHandler
/*     */     implements ResponseBodyEmitter.Handler
/*     */   {
/*     */     private final List<HttpMessageConverter<?>> messageConverters;
/*     */ 
/*     */     
/*     */     private final ResponseBodyEmitterReturnValueHandler.FragmentHandler fragmentHandler;
/*     */ 
/*     */     
/*     */     private final ServerHttpResponse outputMessage;
/*     */ 
/*     */     
/*     */     private final DeferredResult<?> deferredResult;
/*     */ 
/*     */     
/*     */     public DefaultSseEmitterHandler(List<HttpMessageConverter<?>> messageConverters, ResponseBodyEmitterReturnValueHandler.FragmentHandler fragmentHandler, ServerHttpResponse outputMessage, DeferredResult<?> result) {
/* 287 */       this.messageConverters = messageConverters;
/* 288 */       this.fragmentHandler = fragmentHandler;
/* 289 */       this.outputMessage = outputMessage;
/* 290 */       this.deferredResult = result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void send(Object data, @Nullable MediaType mediaType) throws IOException {
/* 295 */       sendInternal(data, mediaType);
/* 296 */       this.outputMessage.flush();
/*     */     }
/*     */ 
/*     */     
/*     */     public void send(Set<ResponseBodyEmitter.DataWithMediaType> items) throws IOException {
/* 301 */       for (ResponseBodyEmitter.DataWithMediaType item : items) {
/* 302 */         sendInternal(item.getData(), item.getMediaType());
/*     */       }
/* 304 */       this.outputMessage.flush();
/*     */     }
/*     */ 
/*     */     
/*     */     private <T> void sendInternal(T data, @Nullable MediaType mediaType) throws IOException {
/* 309 */       if (data instanceof ModelAndView) { ModelAndView mav = (ModelAndView)data;
/* 310 */         this.fragmentHandler.handle(mav);
/*     */         return; }
/*     */       
/* 313 */       for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 314 */         if (converter.canWrite(data.getClass(), mediaType)) {
/* 315 */           converter.write(data, mediaType, (HttpOutputMessage)this.outputMessage);
/*     */           return;
/*     */         } 
/*     */       } 
/* 319 */       throw new IllegalArgumentException("No suitable converter for " + String.valueOf(data.getClass()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/*     */       try {
/* 325 */         this.outputMessage.flush();
/* 326 */         this.deferredResult.setResult(null);
/*     */       }
/* 328 */       catch (IOException ex) {
/* 329 */         this.deferredResult.setErrorResult(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void completeWithError(Throwable failure) {
/* 335 */       this.deferredResult.setErrorResult(failure);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onTimeout(Runnable callback) {
/* 340 */       this.deferredResult.onTimeout(callback);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Consumer<Throwable> callback) {
/* 345 */       this.deferredResult.onError(callback);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onCompletion(Runnable callback) {
/* 350 */       this.deferredResult.onCompletion(callback);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FragmentHandler
/*     */   {
/*     */     private final HttpServletRequest request;
/*     */ 
/*     */     
/*     */     private final HttpServletResponse response;
/*     */ 
/*     */     
/*     */     private final List<ViewResolver> viewResolvers;
/*     */ 
/*     */     
/*     */     private final Locale locale;
/*     */ 
/*     */     
/*     */     private final Charset charset;
/*     */     
/*     */     private final ServletRequestAttributes requestAttributes;
/*     */ 
/*     */     
/*     */     public FragmentHandler(HttpServletRequest request, HttpServletResponse response, List<ViewResolver> viewResolvers, LocaleResolver localeResolver) {
/* 376 */       this.request = request;
/* 377 */       this.response = response;
/* 378 */       this.viewResolvers = viewResolvers;
/* 379 */       this.charset = initCharset(response);
/* 380 */       this.locale = localeResolver.resolveLocale(request);
/* 381 */       this.requestAttributes = (ServletRequestAttributes)new ServletWebRequest(this.request);
/*     */     }
/*     */     
/*     */     private static Charset initCharset(HttpServletResponse response) {
/* 385 */       String s = response.getHeader("Content-Type");
/* 386 */       if (StringUtils.hasText(s)) {
/* 387 */         MediaType contentType = MediaType.valueOf(s);
/* 388 */         if (contentType.getCharset() != null) {
/* 389 */           return contentType.getCharset();
/*     */         }
/*     */       } 
/* 392 */       return StandardCharsets.UTF_8;
/*     */     }
/*     */     
/*     */     public void handle(ModelAndView modelAndView) throws IOException {
/* 396 */       RequestContextHolder.setRequestAttributes((RequestAttributes)this.requestAttributes);
/*     */       try {
/* 398 */         ResponseBodyEmitterReturnValueHandler.FragmentHttpServletResponse fragmentResponse = new ResponseBodyEmitterReturnValueHandler.FragmentHttpServletResponse(this.response, this.charset);
/*     */ 
/*     */         
/* 401 */         FragmentsRendering render = FragmentsRendering.with(List.of(modelAndView)).build();
/* 402 */         render.resolveNestedViews(this::resolveViewName, this.locale);
/* 403 */         render.render(modelAndView.getModel(), this.request, (HttpServletResponse)fragmentResponse);
/*     */         
/* 405 */         byte[] content = fragmentResponse.getFragmentContent();
/* 406 */         this.response.getOutputStream().write(content);
/*     */       }
/* 408 */       catch (IOException ex) {
/* 409 */         throw ex;
/*     */       }
/* 411 */       catch (Exception ex) {
/* 412 */         throw new IllegalStateException("Failed to render " + String.valueOf(modelAndView), ex);
/*     */       } finally {
/*     */         
/* 415 */         RequestContextHolder.resetRequestAttributes();
/*     */       } 
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public View resolveViewName(String viewName, Locale locale) throws Exception {
/* 421 */       for (ViewResolver resolver : this.viewResolvers) {
/* 422 */         View view = resolver.resolveViewName(viewName, locale);
/* 423 */         if (view != null) {
/* 424 */           return view;
/*     */         }
/*     */       } 
/* 427 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FragmentHttpServletResponse
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private final ResponseBodyEmitterReturnValueHandler.FragmentServletOutputStream outputStream;
/*     */ 
/*     */     
/*     */     private final PrintWriter writer;
/*     */ 
/*     */     
/*     */     private final Charset charset;
/*     */ 
/*     */     
/*     */     public FragmentHttpServletResponse(HttpServletResponse delegate, Charset charset) {
/* 446 */       super(delegate);
/* 447 */       this.outputStream = new ResponseBodyEmitterReturnValueHandler.FragmentServletOutputStream();
/* 448 */       this.writer = new PrintWriter((OutputStream)this.outputStream);
/* 449 */       this.charset = charset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setContentType(String type) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setCharacterEncoding(String charset) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setContentLength(int len) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public ServletOutputStream getOutputStream() {
/* 469 */       return this.outputStream;
/*     */     }
/*     */ 
/*     */     
/*     */     public PrintWriter getWriter() {
/* 474 */       return this.writer;
/*     */     }
/*     */     
/*     */     public byte[] getFragmentContent() {
/* 478 */       this.writer.flush();
/* 479 */       String content = this.outputStream.toString(this.charset);
/* 480 */       content = content.replace("\n", "\ndata:");
/* 481 */       return content.getBytes(this.charset);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class FragmentServletOutputStream
/*     */     extends ServletOutputStream
/*     */   {
/*     */     private final ByteArrayOutputStream outputStream;
/*     */     
/*     */     private FragmentServletOutputStream() {
/* 491 */       this.outputStream = new ByteArrayOutputStream();
/*     */     }
/*     */     
/*     */     public void write(int b) {
/* 495 */       this.outputStream.write(b);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 500 */       this.outputStream.write(b);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b, int off, int len) {
/* 505 */       this.outputStream.write(b, off, len);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReady() {
/* 510 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setWriteListener(WriteListener writeListener) {
/* 515 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public String toString(Charset charset) {
/* 519 */       return this.outputStream.toString(charset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitterReturnValueHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */