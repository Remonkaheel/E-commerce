/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HeadersRequestCondition
/*     */   extends AbstractRequestCondition<HeadersRequestCondition>
/*     */ {
/*  46 */   private static final HeadersRequestCondition PRE_FLIGHT_MATCH = new HeadersRequestCondition(new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Set<HeaderExpression> expressions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeadersRequestCondition(String... headers) {
/*  60 */     this.expressions = parseExpressions(headers);
/*     */   }
/*     */   
/*     */   private static Set<HeaderExpression> parseExpressions(String... headers) {
/*  64 */     Set<HeaderExpression> result = null;
/*  65 */     if (!ObjectUtils.isEmpty((Object[])headers))
/*  66 */       for (String header : headers) {
/*  67 */         HeaderExpression expr = new HeaderExpression(header);
/*  68 */         if (!"Accept".equalsIgnoreCase(expr.name) && !"Content-Type".equalsIgnoreCase(expr.name)) {
/*     */ 
/*     */           
/*  71 */           result = (result != null) ? result : CollectionUtils.newLinkedHashSet(headers.length);
/*  72 */           result.add(expr);
/*     */         } 
/*     */       }  
/*  75 */     return (result != null) ? result : Collections.<HeaderExpression>emptySet();
/*     */   }
/*     */   
/*     */   private HeadersRequestCondition(Set<HeaderExpression> conditions) {
/*  79 */     this.expressions = conditions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<NameValueExpression<String>> getExpressions() {
/*  87 */     return new LinkedHashSet<>((Collection)this.expressions);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<HeaderExpression> getContent() {
/*  92 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getToStringInfix() {
/*  97 */     return " && ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeadersRequestCondition combine(HeadersRequestCondition other) {
/* 106 */     if (isEmpty() && other.isEmpty()) {
/* 107 */       return this;
/*     */     }
/* 109 */     if (other.isEmpty()) {
/* 110 */       return this;
/*     */     }
/* 112 */     if (isEmpty()) {
/* 113 */       return other;
/*     */     }
/* 115 */     Set<HeaderExpression> set = new LinkedHashSet<>(this.expressions);
/* 116 */     set.addAll(other.expressions);
/* 117 */     return new HeadersRequestCondition(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HeadersRequestCondition getMatchingCondition(HttpServletRequest request) {
/* 127 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 128 */       return PRE_FLIGHT_MATCH;
/*     */     }
/* 130 */     for (HeaderExpression expression : this.expressions) {
/* 131 */       if (!expression.match(request)) {
/* 132 */         return null;
/*     */       }
/*     */     } 
/* 135 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(HeadersRequestCondition other, HttpServletRequest request) {
/* 151 */     int result = other.expressions.size() - this.expressions.size();
/* 152 */     if (result != 0) {
/* 153 */       return result;
/*     */     }
/* 155 */     return (int)(getValueMatchCount(other.expressions) - getValueMatchCount(this.expressions));
/*     */   }
/*     */   
/*     */   private long getValueMatchCount(Set<HeaderExpression> expressions) {
/* 159 */     long count = 0L;
/* 160 */     for (HeaderExpression e : expressions) {
/* 161 */       if (e.getValue() != null && !e.isNegated()) {
/* 162 */         count++;
/*     */       }
/*     */     } 
/* 165 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class HeaderExpression
/*     */     extends AbstractNameValueExpression<String>
/*     */   {
/*     */     HeaderExpression(String expression) {
/* 175 */       super(expression);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isCaseSensitiveName() {
/* 180 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String parseValue(String valueExpression) {
/* 185 */       return valueExpression;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchName(HttpServletRequest request) {
/* 190 */       return (request.getHeader(this.name) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchValue(HttpServletRequest request) {
/* 195 */       return ObjectUtils.nullSafeEquals(this.value, request.getHeader(this.name));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\HeadersRequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */