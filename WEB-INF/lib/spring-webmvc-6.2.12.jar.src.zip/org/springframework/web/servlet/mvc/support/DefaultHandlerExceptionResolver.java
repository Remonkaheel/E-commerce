/*     */ package org.springframework.web.servlet.mvc.support;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.validation.method.MethodValidationException;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingPathVariableException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.context.request.async.AsyncRequestNotUsableException;
/*     */ import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
/*     */ import org.springframework.web.method.annotation.HandlerMethodValidationException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.resource.NoResourceFoundException;
/*     */ import org.springframework.web.util.DisconnectedClientHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHandlerExceptionResolver
/*     */   extends AbstractHandlerExceptionResolver
/*     */ {
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/* 167 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHandlerExceptionResolver() {
/* 174 */     setOrder(2147483647);
/* 175 */     setWarnLogCategory(getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
/*     */     try {
/* 186 */       if (ex instanceof ErrorResponse) { ErrorResponse errorResponse = (ErrorResponse)ex;
/* 187 */         ModelAndView mav = null;
/* 188 */         if (ex instanceof HttpRequestMethodNotSupportedException) { HttpRequestMethodNotSupportedException theEx = (HttpRequestMethodNotSupportedException)ex;
/* 189 */           mav = handleHttpRequestMethodNotSupported(theEx, request, response, handler); }
/*     */         
/* 191 */         else if (ex instanceof HttpMediaTypeNotSupportedException) { HttpMediaTypeNotSupportedException theEx = (HttpMediaTypeNotSupportedException)ex;
/* 192 */           mav = handleHttpMediaTypeNotSupported(theEx, request, response, handler); }
/*     */         
/* 194 */         else if (ex instanceof HttpMediaTypeNotAcceptableException) { HttpMediaTypeNotAcceptableException theEx = (HttpMediaTypeNotAcceptableException)ex;
/* 195 */           mav = handleHttpMediaTypeNotAcceptable(theEx, request, response, handler); }
/*     */         
/* 197 */         else if (ex instanceof MissingPathVariableException) { MissingPathVariableException theEx = (MissingPathVariableException)ex;
/* 198 */           mav = handleMissingPathVariable(theEx, request, response, handler); }
/*     */         
/* 200 */         else if (ex instanceof MissingServletRequestParameterException) { MissingServletRequestParameterException theEx = (MissingServletRequestParameterException)ex;
/* 201 */           mav = handleMissingServletRequestParameter(theEx, request, response, handler); }
/*     */         
/* 203 */         else if (ex instanceof MissingServletRequestPartException) { MissingServletRequestPartException theEx = (MissingServletRequestPartException)ex;
/* 204 */           mav = handleMissingServletRequestPartException(theEx, request, response, handler); }
/*     */         
/* 206 */         else if (ex instanceof ServletRequestBindingException) { ServletRequestBindingException theEx = (ServletRequestBindingException)ex;
/* 207 */           mav = handleServletRequestBindingException(theEx, request, response, handler); }
/*     */         
/* 209 */         else if (ex instanceof MethodArgumentNotValidException) { MethodArgumentNotValidException theEx = (MethodArgumentNotValidException)ex;
/* 210 */           mav = handleMethodArgumentNotValidException(theEx, request, response, handler); }
/*     */         
/* 212 */         else if (ex instanceof HandlerMethodValidationException) { HandlerMethodValidationException theEx = (HandlerMethodValidationException)ex;
/* 213 */           mav = handleHandlerMethodValidationException(theEx, request, response, handler); }
/*     */         
/* 215 */         else if (ex instanceof NoHandlerFoundException) { NoHandlerFoundException theEx = (NoHandlerFoundException)ex;
/* 216 */           mav = handleNoHandlerFoundException(theEx, request, response, handler); }
/*     */         
/* 218 */         else if (ex instanceof NoResourceFoundException) { NoResourceFoundException theEx = (NoResourceFoundException)ex;
/* 219 */           mav = handleNoResourceFoundException(theEx, request, response, handler); }
/*     */         
/* 221 */         else if (ex instanceof AsyncRequestTimeoutException) { AsyncRequestTimeoutException theEx = (AsyncRequestTimeoutException)ex;
/* 222 */           mav = handleAsyncRequestTimeoutException(theEx, request, response, handler); }
/*     */ 
/*     */         
/* 225 */         return (mav != null) ? mav : 
/* 226 */           handleErrorResponse(errorResponse, request, response, handler); }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       if (ex instanceof ConversionNotSupportedException) { ConversionNotSupportedException theEx = (ConversionNotSupportedException)ex;
/* 232 */         return handleConversionNotSupported(theEx, request, response, handler); }
/*     */       
/* 234 */       if (ex instanceof TypeMismatchException) { TypeMismatchException theEx = (TypeMismatchException)ex;
/* 235 */         return handleTypeMismatch(theEx, request, response, handler); }
/*     */       
/* 237 */       if (ex instanceof HttpMessageNotReadableException) { HttpMessageNotReadableException theEx = (HttpMessageNotReadableException)ex;
/* 238 */         return handleHttpMessageNotReadable(theEx, request, response, handler); }
/*     */       
/* 240 */       if (ex instanceof HttpMessageNotWritableException) { HttpMessageNotWritableException theEx = (HttpMessageNotWritableException)ex;
/* 241 */         return handleHttpMessageNotWritable(theEx, request, response, handler); }
/*     */       
/* 243 */       if (ex instanceof MethodValidationException) { MethodValidationException theEx = (MethodValidationException)ex;
/* 244 */         return handleMethodValidationException(theEx, request, response, handler); }
/*     */       
/* 246 */       if (ex instanceof AsyncRequestNotUsableException) {
/* 247 */         return handleAsyncRequestNotUsableException((AsyncRequestNotUsableException)ex, request, response, handler);
/*     */       }
/*     */       
/* 250 */       if (DisconnectedClientHelper.isClientDisconnectedException(ex)) {
/* 251 */         return handleDisconnectedClientException(ex, request, response, handler);
/*     */       }
/*     */     }
/* 254 */     catch (Exception handlerEx) {
/* 255 */       if (this.logger.isWarnEnabled()) {
/* 256 */         this.logger.warn("Failure while trying to resolve exception [" + ex.getClass().getName() + "]", handlerEx);
/*     */       }
/*     */     } 
/*     */     
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 322 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleMissingPathVariable(MissingPathVariableException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 342 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 361 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleMissingServletRequestPartException(MissingServletRequestPartException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 379 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleServletRequestBindingException(ServletRequestBindingException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 399 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleMethodArgumentNotValidException(MethodArgumentNotValidException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleHandlerMethodValidationException(HandlerMethodValidationException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 438 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleNoHandlerFoundException(NoHandlerFoundException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 459 */     pageNotFoundLogger.warn(ex.getMessage());
/* 460 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleNoResourceFoundException(NoResourceFoundException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 480 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleAsyncRequestTimeoutException(AsyncRequestTimeoutException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 501 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleAsyncRequestNotUsableException(AsyncRequestNotUsableException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) {
/* 518 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleDisconnectedClientException(Exception ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) {
/* 538 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleErrorResponse(ErrorResponse errorResponse, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 558 */     if (!response.isCommitted()) {
/* 559 */       HttpHeaders headers = errorResponse.getHeaders();
/* 560 */       headers.forEach((name, values) -> values.forEach(()));
/*     */       
/* 562 */       int status = errorResponse.getStatusCode().value();
/* 563 */       String message = errorResponse.getBody().getDetail();
/* 564 */       if (message != null) {
/* 565 */         response.sendError(status, message);
/*     */       } else {
/*     */         
/* 568 */         response.sendError(status);
/*     */       }
/*     */     
/* 571 */     } else if (this.logger.isWarnEnabled()) {
/* 572 */       this.logger.warn("Ignoring exception, response committed already: " + String.valueOf(errorResponse));
/*     */     } 
/*     */     
/* 575 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleConversionNotSupported(ConversionNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 593 */     sendServerError((Exception)ex, request, response);
/* 594 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleTypeMismatch(TypeMismatchException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 611 */     response.sendError(400);
/* 612 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 631 */     if (!response.isCommitted()) {
/* 632 */       response.sendError(400);
/*     */     }
/* 634 */     else if (this.logger.isWarnEnabled()) {
/* 635 */       this.logger.warn("Ignoring exception, response committed already: " + String.valueOf(ex));
/*     */     } 
/* 637 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 657 */     if (!response.isCommitted()) {
/* 658 */       sendServerError((Exception)ex, request, response);
/*     */     }
/* 660 */     else if (this.logger.isWarnEnabled()) {
/* 661 */       this.logger.warn("Ignoring exception, response committed already: " + String.valueOf(ex));
/*     */     } 
/* 663 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView handleMethodValidationException(MethodValidationException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws IOException {
/* 683 */     sendServerError((Exception)ex, request, response);
/* 684 */     return new ModelAndView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendServerError(Exception ex, HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 694 */     request.setAttribute("jakarta.servlet.error.exception", ex);
/* 695 */     response.sendError(500);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void logException(Exception ex, HttpServletRequest request) {
/* 700 */     if (ex instanceof NoHandlerFoundException || ex instanceof NoResourceFoundException) {
/* 701 */       if (this.logger.isDebugEnabled()) {
/* 702 */         this.logger.debug(buildLogMessage(ex, request));
/*     */       }
/*     */       return;
/*     */     } 
/* 706 */     super.logException(ex, request);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\support\DefaultHandlerExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */