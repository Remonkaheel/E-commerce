/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.filter.ShallowEtagHeaderFilter;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamingResponseBodyReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   public boolean supportsReturnType(MethodParameter returnType) {
/*  50 */     if (StreamingResponseBody.class.isAssignableFrom(returnType.getParameterType())) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (ResponseEntity.class.isAssignableFrom(returnType.getParameterType())) {
/*  54 */       Class<?> bodyType = ResolvableType.forMethodParameter(returnType).getGeneric(new int[0]).resolve();
/*  55 */       return (bodyType != null && StreamingResponseBody.class.isAssignableFrom(bodyType));
/*     */     } 
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
/*  65 */     if (returnValue == null) {
/*  66 */       mavContainer.setRequestHandled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/*  71 */     Assert.state((response != null), "No HttpServletResponse");
/*  72 */     ServletServerHttpResponse servletServerHttpResponse = new ServletServerHttpResponse(response);
/*     */     
/*  74 */     if (returnValue instanceof ResponseEntity) { ResponseEntity<?> responseEntity = (ResponseEntity)returnValue;
/*  75 */       response.setStatus(responseEntity.getStatusCode().value());
/*  76 */       servletServerHttpResponse.getHeaders().putAll((Map)responseEntity.getHeaders());
/*  77 */       returnValue = responseEntity.getBody();
/*  78 */       if (returnValue == null) {
/*  79 */         mavContainer.setRequestHandled(true);
/*  80 */         servletServerHttpResponse.flush();
/*     */         
/*     */         return;
/*     */       }  }
/*     */     
/*  85 */     ServletRequest request = (ServletRequest)webRequest.getNativeRequest(ServletRequest.class);
/*  86 */     Assert.state((request != null), "No ServletRequest");
/*  87 */     ShallowEtagHeaderFilter.disableContentCaching(request);
/*     */     
/*  89 */     Assert.isInstanceOf(StreamingResponseBody.class, returnValue, "StreamingResponseBody expected");
/*  90 */     StreamingResponseBody streamingBody = (StreamingResponseBody)returnValue;
/*     */     
/*  92 */     Callable<Void> callable = new StreamingResponseBodyTask(servletServerHttpResponse.getBody(), streamingBody);
/*  93 */     WebAsyncUtils.getAsyncManager((WebRequest)webRequest).startCallableProcessing(callable, new Object[] { mavContainer });
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StreamingResponseBodyTask
/*     */     implements Callable<Void>
/*     */   {
/*     */     private final OutputStream outputStream;
/*     */     private final StreamingResponseBody streamingBody;
/*     */     
/*     */     public StreamingResponseBodyTask(OutputStream outputStream, StreamingResponseBody streamingBody) {
/* 104 */       this.outputStream = outputStream;
/* 105 */       this.streamingBody = streamingBody;
/*     */     }
/*     */ 
/*     */     
/*     */     public Void call() throws Exception {
/* 110 */       this.streamingBody.writeTo(this.outputStream);
/* 111 */       this.outputStream.flush();
/* 112 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\StreamingResponseBodyReturnValueHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */