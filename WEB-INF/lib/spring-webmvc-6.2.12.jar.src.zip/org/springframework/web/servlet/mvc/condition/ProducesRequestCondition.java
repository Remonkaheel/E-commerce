/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.HttpMediaTypeException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProducesRequestCondition
/*     */   extends AbstractRequestCondition<ProducesRequestCondition>
/*     */ {
/*  53 */   private static final ContentNegotiationManager DEFAULT_CONTENT_NEGOTIATION_MANAGER = new ContentNegotiationManager();
/*     */ 
/*     */   
/*  56 */   private static final ProducesRequestCondition EMPTY_CONDITION = new ProducesRequestCondition(new String[0]);
/*     */ 
/*     */   
/*  59 */   private static final List<ProduceMediaTypeExpression> MEDIA_TYPE_ALL_LIST = Collections.singletonList(new ProduceMediaTypeExpression("*/*"));
/*     */   
/*  61 */   private static final String MEDIA_TYPES_ATTRIBUTE = ProducesRequestCondition.class.getName() + ".MEDIA_TYPES";
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<ProduceMediaTypeExpression> expressions;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProducesRequestCondition(String... produces) {
/*  75 */     this(produces, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProducesRequestCondition(@Nullable String[] produces, @Nullable String[] headers) {
/*  87 */     this(produces, headers, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProducesRequestCondition(@Nullable String[] produces, @Nullable String[] headers, @Nullable ContentNegotiationManager manager) {
/* 100 */     this.expressions = parseExpressions(produces, headers);
/* 101 */     if (this.expressions.size() > 1) {
/* 102 */       Collections.sort(this.expressions);
/*     */     }
/* 104 */     this.contentNegotiationManager = (manager != null) ? manager : DEFAULT_CONTENT_NEGOTIATION_MANAGER;
/*     */   }
/*     */   
/*     */   private List<ProduceMediaTypeExpression> parseExpressions(@Nullable String[] produces, @Nullable String[] headers) {
/* 108 */     Set<ProduceMediaTypeExpression> result = null;
/* 109 */     if (!ObjectUtils.isEmpty((Object[])headers)) {
/* 110 */       for (String header : headers) {
/* 111 */         HeadersRequestCondition.HeaderExpression expr = new HeadersRequestCondition.HeaderExpression(header);
/* 112 */         if ("Accept".equalsIgnoreCase(expr.name) && expr.value != null) {
/* 113 */           for (MediaType mediaType : MediaType.parseMediaTypes(expr.value)) {
/* 114 */             result = (result != null) ? result : new LinkedHashSet<>();
/* 115 */             result.add(new ProduceMediaTypeExpression(mediaType, expr.isNegated));
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 120 */     if (!ObjectUtils.isEmpty((Object[])produces)) {
/* 121 */       for (String produce : produces) {
/* 122 */         result = (result != null) ? result : new LinkedHashSet<>();
/* 123 */         result.add(new ProduceMediaTypeExpression(produce));
/*     */       } 
/*     */     }
/* 126 */     return (result != null) ? new ArrayList<>(result) : Collections.<ProduceMediaTypeExpression>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ProducesRequestCondition(List<ProduceMediaTypeExpression> expressions, ProducesRequestCondition other) {
/* 134 */     this.expressions = expressions;
/* 135 */     this.contentNegotiationManager = other.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MediaTypeExpression> getExpressions() {
/* 143 */     return new LinkedHashSet<>((Collection)this.expressions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MediaType> getProducibleMediaTypes() {
/* 150 */     Set<MediaType> result = new LinkedHashSet<>();
/* 151 */     for (ProduceMediaTypeExpression expression : this.expressions) {
/* 152 */       if (!expression.isNegated()) {
/* 153 */         result.add(expression.getMediaType());
/*     */       }
/*     */     } 
/* 156 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 164 */     return this.expressions.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<ProduceMediaTypeExpression> getContent() {
/* 169 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getToStringInfix() {
/* 174 */     return " || ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProducesRequestCondition combine(ProducesRequestCondition other) {
/* 184 */     return !other.expressions.isEmpty() ? other : this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ProducesRequestCondition getMatchingCondition(HttpServletRequest request) {
/*     */     List<MediaType> acceptedMediaTypes;
/* 200 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 201 */       return EMPTY_CONDITION;
/*     */     }
/* 203 */     if (isEmpty()) {
/* 204 */       return this;
/*     */     }
/*     */     
/*     */     try {
/* 208 */       acceptedMediaTypes = getAcceptedMediaTypes(request);
/*     */     }
/* 210 */     catch (HttpMediaTypeException ex) {
/* 211 */       return null;
/*     */     } 
/* 213 */     List<ProduceMediaTypeExpression> result = getMatchingExpressions(acceptedMediaTypes);
/* 214 */     if (!CollectionUtils.isEmpty(result)) {
/* 215 */       return new ProducesRequestCondition(result, this);
/*     */     }
/* 217 */     if (MediaType.ALL.isPresentIn(acceptedMediaTypes)) {
/* 218 */       return EMPTY_CONDITION;
/*     */     }
/*     */     
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private List<ProduceMediaTypeExpression> getMatchingExpressions(List<MediaType> acceptedMediaTypes) {
/* 227 */     List<ProduceMediaTypeExpression> result = null;
/* 228 */     for (ProduceMediaTypeExpression expression : this.expressions) {
/* 229 */       if (expression.match(acceptedMediaTypes)) {
/* 230 */         result = (result != null) ? result : new ArrayList<>();
/* 231 */         result.add(expression);
/*     */       } 
/*     */     } 
/* 234 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ProducesRequestCondition other, HttpServletRequest request) {
/* 257 */     if (this.expressions.isEmpty() && other.expressions.isEmpty()) {
/* 258 */       return 0;
/*     */     }
/*     */     try {
/* 261 */       List<MediaType> acceptedMediaTypes = getAcceptedMediaTypes(request);
/* 262 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 263 */         int thisIndex = indexOfEqualMediaType(acceptedMediaType);
/* 264 */         int otherIndex = other.indexOfEqualMediaType(acceptedMediaType);
/* 265 */         int result = compareMatchingMediaTypes(this, thisIndex, other, otherIndex);
/* 266 */         if (result != 0) {
/* 267 */           return result;
/*     */         }
/* 269 */         thisIndex = indexOfIncludedMediaType(acceptedMediaType);
/* 270 */         otherIndex = other.indexOfIncludedMediaType(acceptedMediaType);
/* 271 */         result = compareMatchingMediaTypes(this, thisIndex, other, otherIndex);
/* 272 */         if (result != 0) {
/* 273 */           return result;
/*     */         }
/*     */       } 
/* 276 */       return 0;
/*     */     }
/* 278 */     catch (HttpMediaTypeNotAcceptableException ex) {
/*     */       
/* 280 */       throw new IllegalStateException("Cannot compare without having any requested media types", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MediaType> getAcceptedMediaTypes(HttpServletRequest request) throws HttpMediaTypeNotAcceptableException {
/* 288 */     List<MediaType> result = (List<MediaType>)request.getAttribute(MEDIA_TYPES_ATTRIBUTE);
/* 289 */     if (result == null) {
/* 290 */       result = this.contentNegotiationManager.resolveMediaTypes((NativeWebRequest)new ServletWebRequest(request));
/* 291 */       request.setAttribute(MEDIA_TYPES_ATTRIBUTE, result);
/*     */     } 
/* 293 */     return result;
/*     */   }
/*     */   
/*     */   private int indexOfEqualMediaType(MediaType mediaType) {
/* 297 */     for (int i = 0; i < getExpressionsToCompare().size(); i++) {
/* 298 */       MediaType currentMediaType = ((ProduceMediaTypeExpression)getExpressionsToCompare().get(i)).getMediaType();
/* 299 */       if (mediaType.getType().equalsIgnoreCase(currentMediaType.getType()) && mediaType
/* 300 */         .getSubtype().equalsIgnoreCase(currentMediaType.getSubtype())) {
/* 301 */         return i;
/*     */       }
/*     */     } 
/* 304 */     return -1;
/*     */   }
/*     */   
/*     */   private int indexOfIncludedMediaType(MediaType mediaType) {
/* 308 */     for (int i = 0; i < getExpressionsToCompare().size(); i++) {
/* 309 */       if (mediaType.includes(((ProduceMediaTypeExpression)getExpressionsToCompare().get(i)).getMediaType())) {
/* 310 */         return i;
/*     */       }
/*     */     } 
/* 313 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int compareMatchingMediaTypes(ProducesRequestCondition condition1, int index1, ProducesRequestCondition condition2, int index2) {
/* 319 */     int result = 0;
/* 320 */     if (index1 != index2) {
/* 321 */       result = index2 - index1;
/*     */     }
/* 323 */     else if (index1 != -1) {
/* 324 */       ProduceMediaTypeExpression expr1 = condition1.getExpressionsToCompare().get(index1);
/* 325 */       ProduceMediaTypeExpression expr2 = condition2.getExpressionsToCompare().get(index2);
/* 326 */       result = expr1.compareTo(expr2);
/* 327 */       result = (result != 0) ? result : expr1.getMediaType().compareTo((MimeType)expr2.getMediaType());
/*     */     } 
/* 329 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ProduceMediaTypeExpression> getExpressionsToCompare() {
/* 337 */     return this.expressions.isEmpty() ? MEDIA_TYPE_ALL_LIST : this.expressions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearMediaTypesAttribute(HttpServletRequest request) {
/* 348 */     request.removeAttribute(MEDIA_TYPES_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ProduceMediaTypeExpression
/*     */     extends AbstractMediaTypeExpression
/*     */   {
/*     */     ProduceMediaTypeExpression(MediaType mediaType, boolean negated) {
/* 358 */       super(mediaType, negated);
/*     */     }
/*     */     
/*     */     ProduceMediaTypeExpression(String expression) {
/* 362 */       super(expression);
/*     */     }
/*     */     
/*     */     public final boolean match(List<MediaType> acceptedMediaTypes) {
/* 366 */       boolean match = matchMediaType(acceptedMediaTypes);
/* 367 */       return ((!isNegated()) == match);
/*     */     }
/*     */     
/*     */     private boolean matchMediaType(List<MediaType> acceptedMediaTypes) {
/* 371 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 372 */         if (getMediaType().isCompatibleWith(acceptedMediaType) && matchParameters(acceptedMediaType)) {
/* 373 */           return true;
/*     */         }
/*     */       } 
/* 376 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\ProducesRequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */