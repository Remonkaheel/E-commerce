/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.view.FragmentsRendering;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FragmentHandler
/*     */ {
/*     */   private final HttpServletRequest request;
/*     */   private final HttpServletResponse response;
/*     */   private final List<ViewResolver> viewResolvers;
/*     */   private final Locale locale;
/*     */   private final Charset charset;
/*     */   private final ServletRequestAttributes requestAttributes;
/*     */   
/*     */   public FragmentHandler(HttpServletRequest request, HttpServletResponse response, List<ViewResolver> viewResolvers, LocaleResolver localeResolver) {
/* 376 */     this.request = request;
/* 377 */     this.response = response;
/* 378 */     this.viewResolvers = viewResolvers;
/* 379 */     this.charset = initCharset(response);
/* 380 */     this.locale = localeResolver.resolveLocale(request);
/* 381 */     this.requestAttributes = (ServletRequestAttributes)new ServletWebRequest(this.request);
/*     */   }
/*     */   
/*     */   private static Charset initCharset(HttpServletResponse response) {
/* 385 */     String s = response.getHeader("Content-Type");
/* 386 */     if (StringUtils.hasText(s)) {
/* 387 */       MediaType contentType = MediaType.valueOf(s);
/* 388 */       if (contentType.getCharset() != null) {
/* 389 */         return contentType.getCharset();
/*     */       }
/*     */     } 
/* 392 */     return StandardCharsets.UTF_8;
/*     */   }
/*     */   
/*     */   public void handle(ModelAndView modelAndView) throws IOException {
/* 396 */     RequestContextHolder.setRequestAttributes((RequestAttributes)this.requestAttributes);
/*     */     try {
/* 398 */       ResponseBodyEmitterReturnValueHandler.FragmentHttpServletResponse fragmentResponse = new ResponseBodyEmitterReturnValueHandler.FragmentHttpServletResponse(this.response, this.charset);
/*     */ 
/*     */       
/* 401 */       FragmentsRendering render = FragmentsRendering.with(List.of(modelAndView)).build();
/* 402 */       render.resolveNestedViews(this::resolveViewName, this.locale);
/* 403 */       render.render(modelAndView.getModel(), this.request, (HttpServletResponse)fragmentResponse);
/*     */       
/* 405 */       byte[] content = fragmentResponse.getFragmentContent();
/* 406 */       this.response.getOutputStream().write(content);
/*     */     }
/* 408 */     catch (IOException ex) {
/* 409 */       throw ex;
/*     */     }
/* 411 */     catch (Exception ex) {
/* 412 */       throw new IllegalStateException("Failed to render " + String.valueOf(modelAndView), ex);
/*     */     } finally {
/*     */       
/* 415 */       RequestContextHolder.resetRequestAttributes();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public View resolveViewName(String viewName, Locale locale) throws Exception {
/* 421 */     for (ViewResolver resolver : this.viewResolvers) {
/* 422 */       View view = resolver.resolveViewName(viewName, locale);
/* 423 */       if (view != null) {
/* 424 */         return view;
/*     */       }
/*     */     } 
/* 427 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitterReturnValueHandler$FragmentHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */