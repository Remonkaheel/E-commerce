/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.http.RequestEntity;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpEntityMethodProcessor
/*     */   extends AbstractMessageConverterMethodProcessor
/*     */ {
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters) {
/*  83 */     super(converters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, ContentNegotiationManager manager) {
/*  92 */     super(converters, manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, List<Object> requestResponseBodyAdvice) {
/* 104 */     super(converters, (ContentNegotiationManager)null, requestResponseBodyAdvice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, List<Object> requestResponseBodyAdvice) {
/* 115 */     super(converters, manager, requestResponseBodyAdvice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, List<Object> requestResponseBodyAdvice, List<ErrorResponse.Interceptor> interceptors) {
/* 128 */     super(converters, manager, requestResponseBodyAdvice, interceptors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/* 134 */     return (HttpEntity.class == parameter.getParameterType() || RequestEntity.class == parameter
/* 135 */       .getParameterType());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsReturnType(MethodParameter returnType) {
/* 140 */     Class<?> type = returnType.getParameterType();
/* 141 */     return ((HttpEntity.class.isAssignableFrom(type) && !RequestEntity.class.isAssignableFrom(type)) || ErrorResponse.class
/* 142 */       .isAssignableFrom(type) || ProblemDetail.class.isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory) throws IOException, HttpMediaTypeNotSupportedException {
/* 151 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 152 */     Type paramType = getHttpEntityType(parameter);
/* 153 */     if (paramType == null) {
/* 154 */       throw new IllegalArgumentException("HttpEntity parameter '" + parameter.getParameterName() + "' in method " + 
/* 155 */           String.valueOf(parameter.getMethod()) + " is not parameterized");
/*     */     }
/*     */     
/* 158 */     Object body = readWithMessageConverters(webRequest, parameter, paramType);
/* 159 */     if (RequestEntity.class == parameter.getParameterType()) {
/* 160 */       return new RequestEntity(body, (MultiValueMap)inputMessage.getHeaders(), inputMessage
/* 161 */           .getMethod(), inputMessage.getURI());
/*     */     }
/*     */     
/* 164 */     return new HttpEntity(body, (MultiValueMap)inputMessage.getHeaders());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Type getHttpEntityType(MethodParameter parameter) {
/* 170 */     Assert.isAssignable(HttpEntity.class, parameter.getParameterType());
/* 171 */     Type parameterType = parameter.getGenericParameterType();
/* 172 */     if (parameterType instanceof ParameterizedType) { ParameterizedType type = (ParameterizedType)parameterType;
/* 173 */       if ((type.getActualTypeArguments()).length != 1) {
/* 174 */         throw new IllegalArgumentException("Expected single generic parameter on '" + parameter
/* 175 */             .getParameterName() + "' in method " + String.valueOf(parameter.getMethod()));
/*     */       }
/* 177 */       return type.getActualTypeArguments()[0]; }
/*     */     
/* 179 */     if (parameterType instanceof Class) {
/* 180 */       return Object.class;
/*     */     }
/*     */     
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
/*     */     HttpEntity<?> httpEntity;
/* 191 */     mavContainer.setRequestHandled(true);
/* 192 */     if (returnValue == null) {
/*     */       return;
/*     */     }
/*     */     
/* 196 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 197 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/*     */ 
/*     */     
/* 200 */     if (returnValue instanceof ErrorResponse) { ErrorResponse response = (ErrorResponse)returnValue;
/* 201 */       ResponseEntity responseEntity = new ResponseEntity(response.getBody(), (MultiValueMap)response.getHeaders(), response.getStatusCode()); }
/*     */     
/* 203 */     else if (returnValue instanceof ProblemDetail) { ProblemDetail detail = (ProblemDetail)returnValue;
/* 204 */       ResponseEntity responseEntity = ResponseEntity.of(detail).build(); }
/*     */     else
/*     */     
/* 207 */     { Assert.isInstanceOf(HttpEntity.class, returnValue);
/* 208 */       httpEntity = (HttpEntity)returnValue; }
/*     */ 
/*     */     
/* 211 */     Object object = httpEntity.getBody(); if (object instanceof ProblemDetail) { ProblemDetail detail = (ProblemDetail)object;
/* 212 */       if (detail.getInstance() == null) {
/* 213 */         URI path = URI.create(inputMessage.getServletRequest().getRequestURI());
/* 214 */         detail.setInstance(path);
/*     */       } 
/* 216 */       if (this.logger.isWarnEnabled() && httpEntity instanceof ResponseEntity) { ResponseEntity<?> responseEntity = (ResponseEntity)httpEntity;
/* 217 */         if (responseEntity.getStatusCode().value() != detail.getStatus()) {
/* 218 */           this.logger.warn(returnType.getExecutable().toGenericString() + " returned ResponseEntity: " + returnType.getExecutable().toGenericString() + ", but its status doesn't match the ProblemDetail status: " + String.valueOf(responseEntity));
/*     */         } }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 224 */       ErrorResponse response = (ErrorResponse)returnValue; invokeErrorResponseInterceptors(detail, (returnValue instanceof ErrorResponse) ? response : null); }
/*     */ 
/*     */     
/* 227 */     HttpHeaders outputHeaders = outputMessage.getHeaders();
/* 228 */     HttpHeaders entityHeaders = httpEntity.getHeaders();
/* 229 */     if (!entityHeaders.isEmpty()) {
/* 230 */       entityHeaders.forEach((key, value) -> {
/*     */             if ("Vary".equals(key) && outputHeaders.containsKey("Vary")) {
/*     */               List<String> values = getVaryRequestHeadersToAdd(outputHeaders, entityHeaders);
/*     */               
/*     */               if (!values.isEmpty()) {
/*     */                 outputHeaders.setVary(values);
/*     */               }
/*     */             } else {
/*     */               outputHeaders.put(key, value);
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/* 243 */     if (httpEntity instanceof ResponseEntity) { ResponseEntity<?> responseEntity = (ResponseEntity)httpEntity;
/* 244 */       HttpStatusCode returnStatus = responseEntity.getStatusCode();
/* 245 */       outputMessage.getServletResponse().setStatus(returnStatus.value());
/* 246 */       if (returnStatus.value() == HttpStatus.OK.value()) {
/* 247 */         HttpMethod method = inputMessage.getMethod();
/* 248 */         if ((HttpMethod.GET.equals(method) || HttpMethod.HEAD.equals(method)) && 
/* 249 */           isResourceNotModified(inputMessage, outputMessage)) {
/* 250 */           outputMessage.flush();
/*     */           
/*     */           return;
/*     */         } 
/* 254 */       } else if (returnStatus.is3xxRedirection()) {
/* 255 */         String location = outputHeaders.getFirst("Location");
/* 256 */         if (location != null) {
/* 257 */           saveFlashAttributes(mavContainer, webRequest, location);
/*     */         }
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/* 263 */     writeWithMessageConverters(httpEntity.getBody(), returnType, inputMessage, outputMessage);
/*     */ 
/*     */     
/* 266 */     outputMessage.flush();
/*     */   }
/*     */   
/*     */   private List<String> getVaryRequestHeadersToAdd(HttpHeaders responseHeaders, HttpHeaders entityHeaders) {
/* 270 */     List<String> entityHeadersVary = entityHeaders.getVary();
/* 271 */     List<String> vary = responseHeaders.get("Vary");
/* 272 */     if (vary != null) {
/* 273 */       List<String> result = new ArrayList<>(entityHeadersVary);
/* 274 */       for (String header : vary) {
/* 275 */         for (String existing : StringUtils.tokenizeToStringArray(header, ",")) {
/* 276 */           if ("*".equals(existing)) {
/* 277 */             return Collections.emptyList();
/*     */           }
/* 279 */           for (String value : entityHeadersVary) {
/* 280 */             if (value.equalsIgnoreCase(existing)) {
/* 281 */               result.remove(value);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 286 */       return result;
/*     */     } 
/* 288 */     return entityHeadersVary;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isResourceNotModified(ServletServerHttpRequest request, ServletServerHttpResponse response) {
/* 293 */     ServletWebRequest servletWebRequest = new ServletWebRequest(request.getServletRequest(), response.getServletResponse());
/* 294 */     HttpHeaders responseHeaders = response.getHeaders();
/* 295 */     String etag = responseHeaders.getETag();
/* 296 */     long lastModifiedTimestamp = responseHeaders.getLastModified();
/* 297 */     if (request.getMethod() == HttpMethod.GET || request.getMethod() == HttpMethod.HEAD) {
/* 298 */       responseHeaders.remove("ETag");
/* 299 */       responseHeaders.remove("Last-Modified");
/*     */     } 
/*     */     
/* 302 */     return servletWebRequest.checkNotModified(etag, lastModifiedTimestamp);
/*     */   }
/*     */   
/*     */   private void saveFlashAttributes(ModelAndViewContainer mav, NativeWebRequest request, String location) {
/* 306 */     mav.setRedirectModelScenario(true);
/* 307 */     ModelMap model = mav.getModel();
/* 308 */     if (model instanceof RedirectAttributes) { RedirectAttributes redirectAttributes = (RedirectAttributes)model;
/* 309 */       Map<String, ?> flashAttributes = redirectAttributes.getFlashAttributes();
/* 310 */       if (!CollectionUtils.isEmpty(flashAttributes)) {
/* 311 */         HttpServletRequest req = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/* 312 */         HttpServletResponse res = (HttpServletResponse)request.getNativeResponse(HttpServletResponse.class);
/* 313 */         if (req != null) {
/* 314 */           RequestContextUtils.getOutputFlashMap(req).putAll(flashAttributes);
/* 315 */           if (res != null) {
/* 316 */             RequestContextUtils.saveOutputFlashMap(location, req, res);
/*     */           }
/*     */         } 
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> getReturnValueType(@Nullable Object returnValue, MethodParameter returnType) {
/* 325 */     if (returnValue != null) {
/* 326 */       return returnValue.getClass();
/*     */     }
/*     */     
/* 329 */     Type type = getHttpEntityType(returnType);
/* 330 */     type = (type != null) ? type : Object.class;
/* 331 */     return ResolvableType.forMethodParameter(returnType, type).toClass();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\HttpEntityMethodProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */