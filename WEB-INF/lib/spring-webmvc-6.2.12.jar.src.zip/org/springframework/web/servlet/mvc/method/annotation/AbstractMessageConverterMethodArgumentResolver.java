/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.annotation.ValidationAnnotationUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageConverterMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  74 */   private static final Set<HttpMethod> SUPPORTED_METHODS = Set.of(HttpMethod.POST, HttpMethod.PUT, HttpMethod.PATCH);
/*     */   
/*  76 */   private static final Object NO_VALUE = new Object();
/*     */   
/*     */   protected final List<HttpMessageConverter<?>> messageConverters;
/*  79 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final RequestResponseBodyAdviceChain advice;
/*     */   
/*     */   protected enum ConverterType {
/*  83 */     BASE, GENERIC, SMART;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractMessageConverterMethodArgumentResolver(List<HttpMessageConverter<?>> converters) {
/*  92 */     this(converters, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractMessageConverterMethodArgumentResolver(List<HttpMessageConverter<?>> converters, @Nullable List<Object> requestResponseBodyAdvice) {
/* 102 */     Assert.notEmpty(converters, "'messageConverters' must not be empty");
/* 103 */     this.messageConverters = converters;
/* 104 */     this.advice = new RequestResponseBodyAdviceChain(requestResponseBodyAdvice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RequestResponseBodyAdviceChain getAdvice() {
/* 113 */     return this.advice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object readWithMessageConverters(NativeWebRequest webRequest, MethodParameter parameter, Type paramType) throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException {
/* 130 */     ServletServerHttpRequest servletServerHttpRequest = createInputMessage(webRequest);
/* 131 */     return readWithMessageConverters((HttpInputMessage)servletServerHttpRequest, parameter, paramType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <T> Object readWithMessageConverters(HttpInputMessage inputMessage, MethodParameter parameter, Type targetType) throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: invokevirtual getContainingClass : ()Ljava/lang/Class;
/*     */     //   4: astore #4
/*     */     //   6: aload_3
/*     */     //   7: instanceof java/lang/Class
/*     */     //   10: ifeq -> 24
/*     */     //   13: aload_3
/*     */     //   14: checkcast java/lang/Class
/*     */     //   17: astore #6
/*     */     //   19: aload #6
/*     */     //   21: goto -> 25
/*     */     //   24: aconst_null
/*     */     //   25: astore #5
/*     */     //   27: aload_2
/*     */     //   28: invokestatic forMethodParameter : (Lorg/springframework/core/MethodParameter;)Lorg/springframework/core/ResolvableType;
/*     */     //   31: astore #6
/*     */     //   33: aload #5
/*     */     //   35: ifnonnull -> 45
/*     */     //   38: aload #6
/*     */     //   40: invokevirtual resolve : ()Ljava/lang/Class;
/*     */     //   43: astore #5
/*     */     //   45: iconst_0
/*     */     //   46: istore #8
/*     */     //   48: aload_1
/*     */     //   49: invokeinterface getHeaders : ()Lorg/springframework/http/HttpHeaders;
/*     */     //   54: invokevirtual getContentType : ()Lorg/springframework/http/MediaType;
/*     */     //   57: astore #7
/*     */     //   59: goto -> 93
/*     */     //   62: astore #9
/*     */     //   64: new org/springframework/web/HttpMediaTypeNotSupportedException
/*     */     //   67: dup
/*     */     //   68: aload #9
/*     */     //   70: invokevirtual getMessage : ()Ljava/lang/String;
/*     */     //   73: aload_0
/*     */     //   74: aload #5
/*     */     //   76: ifnull -> 84
/*     */     //   79: aload #5
/*     */     //   81: goto -> 86
/*     */     //   84: ldc java/lang/Object
/*     */     //   86: invokevirtual getSupportedMediaTypes : (Ljava/lang/Class;)Ljava/util/List;
/*     */     //   89: invokespecial <init> : (Ljava/lang/String;Ljava/util/List;)V
/*     */     //   92: athrow
/*     */     //   93: aload #7
/*     */     //   95: ifnonnull -> 106
/*     */     //   98: iconst_1
/*     */     //   99: istore #8
/*     */     //   101: getstatic org/springframework/http/MediaType.APPLICATION_OCTET_STREAM : Lorg/springframework/http/MediaType;
/*     */     //   104: astore #7
/*     */     //   106: aload_1
/*     */     //   107: instanceof org/springframework/http/HttpRequest
/*     */     //   110: ifeq -> 129
/*     */     //   113: aload_1
/*     */     //   114: checkcast org/springframework/http/HttpRequest
/*     */     //   117: astore #10
/*     */     //   119: aload #10
/*     */     //   121: invokeinterface getMethod : ()Lorg/springframework/http/HttpMethod;
/*     */     //   126: goto -> 130
/*     */     //   129: aconst_null
/*     */     //   130: astore #9
/*     */     //   132: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver.NO_VALUE : Ljava/lang/Object;
/*     */     //   135: astore #10
/*     */     //   137: aconst_null
/*     */     //   138: astore #11
/*     */     //   140: aconst_null
/*     */     //   141: astore #12
/*     */     //   143: new org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$EmptyBodyCheckingHttpInputMessage
/*     */     //   146: dup
/*     */     //   147: aload_1
/*     */     //   148: invokespecial <init> : (Lorg/springframework/http/HttpInputMessage;)V
/*     */     //   151: astore #11
/*     */     //   153: aload_0
/*     */     //   154: getfield messageConverters : Ljava/util/List;
/*     */     //   157: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   162: astore #13
/*     */     //   164: aload #13
/*     */     //   166: invokeinterface hasNext : ()Z
/*     */     //   171: ifeq -> 471
/*     */     //   174: aload #13
/*     */     //   176: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   181: checkcast org/springframework/http/converter/HttpMessageConverter
/*     */     //   184: astore #14
/*     */     //   186: aload #14
/*     */     //   188: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   191: astore #15
/*     */     //   193: aconst_null
/*     */     //   194: astore #16
/*     */     //   196: aload #14
/*     */     //   198: instanceof org/springframework/http/converter/GenericHttpMessageConverter
/*     */     //   201: ifeq -> 234
/*     */     //   204: aload #14
/*     */     //   206: checkcast org/springframework/http/converter/GenericHttpMessageConverter
/*     */     //   209: astore #17
/*     */     //   211: aload #17
/*     */     //   213: aload_3
/*     */     //   214: aload #4
/*     */     //   216: aload #7
/*     */     //   218: invokeinterface canRead : (Ljava/lang/reflect/Type;Ljava/lang/Class;Lorg/springframework/http/MediaType;)Z
/*     */     //   223: ifeq -> 308
/*     */     //   226: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType.GENERIC : Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType;
/*     */     //   229: astore #16
/*     */     //   231: goto -> 308
/*     */     //   234: aload #14
/*     */     //   236: instanceof org/springframework/http/converter/SmartHttpMessageConverter
/*     */     //   239: ifeq -> 284
/*     */     //   242: aload #14
/*     */     //   244: checkcast org/springframework/http/converter/SmartHttpMessageConverter
/*     */     //   247: astore #18
/*     */     //   249: aload #12
/*     */     //   251: ifnonnull -> 262
/*     */     //   254: aload_0
/*     */     //   255: aload #6
/*     */     //   257: invokevirtual getNestedTypeIfNeeded : (Lorg/springframework/core/ResolvableType;)Lorg/springframework/core/ResolvableType;
/*     */     //   260: astore #12
/*     */     //   262: aload #18
/*     */     //   264: aload #12
/*     */     //   266: aload #7
/*     */     //   268: invokeinterface canRead : (Lorg/springframework/core/ResolvableType;Lorg/springframework/http/MediaType;)Z
/*     */     //   273: ifeq -> 308
/*     */     //   276: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType.SMART : Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType;
/*     */     //   279: astore #16
/*     */     //   281: goto -> 308
/*     */     //   284: aload #5
/*     */     //   286: ifnull -> 308
/*     */     //   289: aload #14
/*     */     //   291: aload #5
/*     */     //   293: aload #7
/*     */     //   295: invokeinterface canRead : (Ljava/lang/Class;Lorg/springframework/http/MediaType;)Z
/*     */     //   300: ifeq -> 308
/*     */     //   303: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType.BASE : Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType;
/*     */     //   306: astore #16
/*     */     //   308: aload #16
/*     */     //   310: ifnull -> 468
/*     */     //   313: aload #11
/*     */     //   315: invokevirtual hasBody : ()Z
/*     */     //   318: ifeq -> 449
/*     */     //   321: aload_0
/*     */     //   322: invokevirtual getAdvice : ()Lorg/springframework/web/servlet/mvc/method/annotation/RequestResponseBodyAdviceChain;
/*     */     //   325: aload #11
/*     */     //   327: aload_2
/*     */     //   328: aload_3
/*     */     //   329: aload #15
/*     */     //   331: invokevirtual beforeBodyRead : (Lorg/springframework/http/HttpInputMessage;Lorg/springframework/core/MethodParameter;Ljava/lang/reflect/Type;Ljava/lang/Class;)Lorg/springframework/http/HttpInputMessage;
/*     */     //   334: astore #17
/*     */     //   336: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$1.$SwitchMap$org$springframework$web$servlet$mvc$method$annotation$AbstractMessageConverterMethodArgumentResolver$ConverterType : [I
/*     */     //   339: aload #16
/*     */     //   341: invokevirtual ordinal : ()I
/*     */     //   344: iaload
/*     */     //   345: tableswitch default -> 372, 1 -> 380, 2 -> 394, 3 -> 412
/*     */     //   372: new java/lang/IncompatibleClassChangeError
/*     */     //   375: dup
/*     */     //   376: invokespecial <init> : ()V
/*     */     //   379: athrow
/*     */     //   380: aload #14
/*     */     //   382: aload #5
/*     */     //   384: aload #17
/*     */     //   386: invokeinterface read : (Ljava/lang/Class;Lorg/springframework/http/HttpInputMessage;)Ljava/lang/Object;
/*     */     //   391: goto -> 427
/*     */     //   394: aload #14
/*     */     //   396: checkcast org/springframework/http/converter/GenericHttpMessageConverter
/*     */     //   399: aload_3
/*     */     //   400: aload #4
/*     */     //   402: aload #17
/*     */     //   404: invokeinterface read : (Ljava/lang/reflect/Type;Ljava/lang/Class;Lorg/springframework/http/HttpInputMessage;)Ljava/lang/Object;
/*     */     //   409: goto -> 427
/*     */     //   412: aload #14
/*     */     //   414: checkcast org/springframework/http/converter/SmartHttpMessageConverter
/*     */     //   417: aload #12
/*     */     //   419: aload #17
/*     */     //   421: aconst_null
/*     */     //   422: invokeinterface read : (Lorg/springframework/core/ResolvableType;Lorg/springframework/http/HttpInputMessage;Ljava/util/Map;)Ljava/lang/Object;
/*     */     //   427: astore #10
/*     */     //   429: aload_0
/*     */     //   430: invokevirtual getAdvice : ()Lorg/springframework/web/servlet/mvc/method/annotation/RequestResponseBodyAdviceChain;
/*     */     //   433: aload #10
/*     */     //   435: aload #17
/*     */     //   437: aload_2
/*     */     //   438: aload_3
/*     */     //   439: aload #15
/*     */     //   441: invokevirtual afterBodyRead : (Ljava/lang/Object;Lorg/springframework/http/HttpInputMessage;Lorg/springframework/core/MethodParameter;Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   444: astore #10
/*     */     //   446: goto -> 471
/*     */     //   449: aload_0
/*     */     //   450: invokevirtual getAdvice : ()Lorg/springframework/web/servlet/mvc/method/annotation/RequestResponseBodyAdviceChain;
/*     */     //   453: aconst_null
/*     */     //   454: aload #11
/*     */     //   456: aload_2
/*     */     //   457: aload_3
/*     */     //   458: aload #15
/*     */     //   460: invokevirtual handleEmptyBody : (Ljava/lang/Object;Lorg/springframework/http/HttpInputMessage;Lorg/springframework/core/MethodParameter;Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   463: astore #10
/*     */     //   465: goto -> 471
/*     */     //   468: goto -> 164
/*     */     //   471: aload #10
/*     */     //   473: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver.NO_VALUE : Ljava/lang/Object;
/*     */     //   476: if_acmpne -> 508
/*     */     //   479: iload #8
/*     */     //   481: ifeq -> 508
/*     */     //   484: aload #11
/*     */     //   486: invokevirtual hasBody : ()Z
/*     */     //   489: ifne -> 508
/*     */     //   492: aload_0
/*     */     //   493: invokevirtual getAdvice : ()Lorg/springframework/web/servlet/mvc/method/annotation/RequestResponseBodyAdviceChain;
/*     */     //   496: aconst_null
/*     */     //   497: aload #11
/*     */     //   499: aload_2
/*     */     //   500: aload_3
/*     */     //   501: ldc org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$NoContentTypeHttpMessageConverter
/*     */     //   503: invokevirtual handleEmptyBody : (Ljava/lang/Object;Lorg/springframework/http/HttpInputMessage;Lorg/springframework/core/MethodParameter;Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   506: astore #10
/*     */     //   508: aload #11
/*     */     //   510: ifnull -> 575
/*     */     //   513: aload #11
/*     */     //   515: invokevirtual hasBody : ()Z
/*     */     //   518: ifeq -> 575
/*     */     //   521: aload_0
/*     */     //   522: aload #11
/*     */     //   524: invokevirtual getBody : ()Ljava/io/InputStream;
/*     */     //   527: invokevirtual closeStreamIfNecessary : (Ljava/io/InputStream;)V
/*     */     //   530: goto -> 575
/*     */     //   533: astore #12
/*     */     //   535: new org/springframework/http/converter/HttpMessageNotReadableException
/*     */     //   538: dup
/*     */     //   539: ldc 'I/O error while reading input message'
/*     */     //   541: aload #12
/*     */     //   543: aload_1
/*     */     //   544: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;Lorg/springframework/http/HttpInputMessage;)V
/*     */     //   547: athrow
/*     */     //   548: astore #19
/*     */     //   550: aload #11
/*     */     //   552: ifnull -> 572
/*     */     //   555: aload #11
/*     */     //   557: invokevirtual hasBody : ()Z
/*     */     //   560: ifeq -> 572
/*     */     //   563: aload_0
/*     */     //   564: aload #11
/*     */     //   566: invokevirtual getBody : ()Ljava/io/InputStream;
/*     */     //   569: invokevirtual closeStreamIfNecessary : (Ljava/io/InputStream;)V
/*     */     //   572: aload #19
/*     */     //   574: athrow
/*     */     //   575: aload #10
/*     */     //   577: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver.NO_VALUE : Ljava/lang/Object;
/*     */     //   580: if_acmpne -> 644
/*     */     //   583: aload #9
/*     */     //   585: ifnull -> 614
/*     */     //   588: getstatic org/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver.SUPPORTED_METHODS : Ljava/util/Set;
/*     */     //   591: aload #9
/*     */     //   593: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   598: ifeq -> 614
/*     */     //   601: iload #8
/*     */     //   603: ifeq -> 616
/*     */     //   606: aload #11
/*     */     //   608: invokevirtual hasBody : ()Z
/*     */     //   611: ifne -> 616
/*     */     //   614: aconst_null
/*     */     //   615: areturn
/*     */     //   616: new org/springframework/web/HttpMediaTypeNotSupportedException
/*     */     //   619: dup
/*     */     //   620: aload #7
/*     */     //   622: aload_0
/*     */     //   623: aload #5
/*     */     //   625: ifnull -> 633
/*     */     //   628: aload #5
/*     */     //   630: goto -> 635
/*     */     //   633: ldc java/lang/Object
/*     */     //   635: invokevirtual getSupportedMediaTypes : (Ljava/lang/Class;)Ljava/util/List;
/*     */     //   638: aload #9
/*     */     //   640: invokespecial <init> : (Lorg/springframework/http/MediaType;Ljava/util/List;Lorg/springframework/http/HttpMethod;)V
/*     */     //   643: athrow
/*     */     //   644: aload #7
/*     */     //   646: astore #12
/*     */     //   648: aload #10
/*     */     //   650: astore #13
/*     */     //   652: aload_0
/*     */     //   653: getfield logger : Lorg/apache/commons/logging/Log;
/*     */     //   656: aload #13
/*     */     //   658: aload #12
/*     */     //   660: <illegal opcode> apply : (Ljava/lang/Object;Lorg/springframework/http/MediaType;)Ljava/util/function/Function;
/*     */     //   665: invokestatic traceDebug : (Lorg/apache/commons/logging/Log;Ljava/util/function/Function;)V
/*     */     //   668: aload #10
/*     */     //   670: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #151	-> 0
/*     */     //   #152	-> 6
/*     */     //   #153	-> 27
/*     */     //   #154	-> 33
/*     */     //   #155	-> 38
/*     */     //   #159	-> 45
/*     */     //   #161	-> 48
/*     */     //   #166	-> 59
/*     */     //   #163	-> 62
/*     */     //   #164	-> 64
/*     */     //   #165	-> 70
/*     */     //   #167	-> 93
/*     */     //   #168	-> 98
/*     */     //   #169	-> 101
/*     */     //   #172	-> 106
/*     */     //   #173	-> 132
/*     */     //   #175	-> 137
/*     */     //   #177	-> 140
/*     */     //   #178	-> 143
/*     */     //   #179	-> 153
/*     */     //   #180	-> 186
/*     */     //   #181	-> 193
/*     */     //   #182	-> 196
/*     */     //   #183	-> 211
/*     */     //   #184	-> 226
/*     */     //   #187	-> 234
/*     */     //   #188	-> 249
/*     */     //   #189	-> 254
/*     */     //   #191	-> 262
/*     */     //   #192	-> 276
/*     */     //   #195	-> 284
/*     */     //   #196	-> 303
/*     */     //   #198	-> 308
/*     */     //   #199	-> 313
/*     */     //   #200	-> 321
/*     */     //   #201	-> 322
/*     */     //   #202	-> 336
/*     */     //   #203	-> 380
/*     */     //   #204	-> 394
/*     */     //   #205	-> 412
/*     */     //   #207	-> 429
/*     */     //   #208	-> 446
/*     */     //   #210	-> 449
/*     */     //   #212	-> 465
/*     */     //   #215	-> 468
/*     */     //   #217	-> 471
/*     */     //   #218	-> 492
/*     */     //   #226	-> 508
/*     */     //   #227	-> 521
/*     */     //   #222	-> 533
/*     */     //   #223	-> 535
/*     */     //   #226	-> 548
/*     */     //   #227	-> 563
/*     */     //   #229	-> 572
/*     */     //   #231	-> 575
/*     */     //   #232	-> 583
/*     */     //   #233	-> 614
/*     */     //   #235	-> 616
/*     */     //   #236	-> 623
/*     */     //   #239	-> 644
/*     */     //   #240	-> 648
/*     */     //   #241	-> 652
/*     */     //   #246	-> 668
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   19	5	6	clazz	Ljava/lang/Class;
/*     */     //   59	3	7	contentType	Lorg/springframework/http/MediaType;
/*     */     //   64	29	9	ex	Lorg/springframework/http/InvalidMediaTypeException;
/*     */     //   119	10	10	httpRequest	Lorg/springframework/http/HttpRequest;
/*     */     //   211	23	17	genericConverter	Lorg/springframework/http/converter/GenericHttpMessageConverter;
/*     */     //   249	35	18	smartConverter	Lorg/springframework/http/converter/SmartHttpMessageConverter;
/*     */     //   336	110	17	msgToUse	Lorg/springframework/http/HttpInputMessage;
/*     */     //   193	275	15	converterClass	Ljava/lang/Class;
/*     */     //   196	272	16	converterTypeToUse	Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$ConverterType;
/*     */     //   186	282	14	converter	Lorg/springframework/http/converter/HttpMessageConverter;
/*     */     //   143	365	12	targetResolvableType	Lorg/springframework/core/ResolvableType;
/*     */     //   535	13	12	ex	Ljava/io/IOException;
/*     */     //   0	671	0	this	Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver;
/*     */     //   0	671	1	inputMessage	Lorg/springframework/http/HttpInputMessage;
/*     */     //   0	671	2	parameter	Lorg/springframework/core/MethodParameter;
/*     */     //   0	671	3	targetType	Ljava/lang/reflect/Type;
/*     */     //   6	665	4	contextClass	Ljava/lang/Class;
/*     */     //   27	644	5	targetClass	Ljava/lang/Class;
/*     */     //   33	638	6	resolvableType	Lorg/springframework/core/ResolvableType;
/*     */     //   93	578	7	contentType	Lorg/springframework/http/MediaType;
/*     */     //   48	623	8	noContentType	Z
/*     */     //   132	539	9	httpMethod	Lorg/springframework/http/HttpMethod;
/*     */     //   137	534	10	body	Ljava/lang/Object;
/*     */     //   140	531	11	message	Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver$EmptyBodyCheckingHttpInputMessage;
/*     */     //   648	23	12	selectedContentType	Lorg/springframework/http/MediaType;
/*     */     //   652	19	13	theBody	Ljava/lang/Object;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   211	23	17	genericConverter	Lorg/springframework/http/converter/GenericHttpMessageConverter<*>;
/*     */     //   249	35	18	smartConverter	Lorg/springframework/http/converter/SmartHttpMessageConverter<*>;
/*     */     //   193	275	15	converterClass	Ljava/lang/Class<Lorg/springframework/http/converter/HttpMessageConverter<*>;>;
/*     */     //   186	282	14	converter	Lorg/springframework/http/converter/HttpMessageConverter<*>;
/*     */     //   6	665	4	contextClass	Ljava/lang/Class<*>;
/*     */     //   27	644	5	targetClass	Ljava/lang/Class<TT;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   48	59	62	org/springframework/http/InvalidMediaTypeException
/*     */     //   140	508	533	java/io/IOException
/*     */     //   140	508	548	finally
/*     */     //   533	550	548	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResolvableType getNestedTypeIfNeeded(ResolvableType type) {
/* 254 */     ResolvableType genericType = type;
/* 255 */     if (Optional.class.isAssignableFrom(genericType.toClass())) {
/* 256 */       genericType = genericType.getNested(2);
/*     */     }
/* 258 */     if (HttpEntity.class.isAssignableFrom(genericType.toClass())) {
/* 259 */       genericType = genericType.getNested(2);
/*     */     }
/* 261 */     return genericType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletServerHttpRequest createInputMessage(NativeWebRequest webRequest) {
/* 271 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 272 */     Assert.state((servletRequest != null), "No HttpServletRequest");
/* 273 */     return new ServletServerHttpRequest(servletRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateIfApplicable(WebDataBinder binder, MethodParameter parameter) {
/* 287 */     Annotation[] annotations = parameter.getParameterAnnotations();
/* 288 */     for (Annotation ann : annotations) {
/* 289 */       Object[] validationHints = ValidationAnnotationUtils.determineValidationHints(ann);
/* 290 */       if (validationHints != null) {
/* 291 */         binder.validate(validationHints);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter parameter) {
/* 305 */     int i = parameter.getParameterIndex();
/* 306 */     Class<?>[] paramTypes = parameter.getExecutable().getParameterTypes();
/* 307 */     boolean hasBindingResult = (paramTypes.length > i + 1 && Errors.class.isAssignableFrom(paramTypes[i + 1]));
/* 308 */     return !hasBindingResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MediaType> getSupportedMediaTypes(Class<?> clazz) {
/* 317 */     Set<MediaType> mediaTypeSet = new LinkedHashSet<>();
/* 318 */     for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 319 */       mediaTypeSet.addAll(converter.getSupportedMediaTypes(clazz));
/*     */     }
/* 321 */     List<MediaType> result = new ArrayList<>(mediaTypeSet);
/* 322 */     MimeTypeUtils.sortBySpecificity(result);
/* 323 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object adaptArgumentIfNecessary(@Nullable Object arg, MethodParameter parameter) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: invokevirtual getParameterType : ()Ljava/lang/Class;
/*     */     //   4: ldc java/util/Optional
/*     */     //   6: if_acmpne -> 62
/*     */     //   9: aload_1
/*     */     //   10: ifnull -> 53
/*     */     //   13: aload_1
/*     */     //   14: instanceof java/util/Collection
/*     */     //   17: ifeq -> 34
/*     */     //   20: aload_1
/*     */     //   21: checkcast java/util/Collection
/*     */     //   24: astore_3
/*     */     //   25: aload_3
/*     */     //   26: invokeinterface isEmpty : ()Z
/*     */     //   31: ifne -> 53
/*     */     //   34: aload_1
/*     */     //   35: instanceof [Ljava/lang/Object;
/*     */     //   38: ifeq -> 57
/*     */     //   41: aload_1
/*     */     //   42: checkcast [Ljava/lang/Object;
/*     */     //   45: astore #4
/*     */     //   47: aload #4
/*     */     //   49: arraylength
/*     */     //   50: ifne -> 57
/*     */     //   53: invokestatic empty : ()Ljava/util/Optional;
/*     */     //   56: areturn
/*     */     //   57: aload_1
/*     */     //   58: invokestatic of : (Ljava/lang/Object;)Ljava/util/Optional;
/*     */     //   61: areturn
/*     */     //   62: aload_1
/*     */     //   63: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #335	-> 0
/*     */     //   #336	-> 9
/*     */     //   #337	-> 41
/*     */     //   #338	-> 53
/*     */     //   #341	-> 57
/*     */     //   #344	-> 62
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   25	9	3	collection	Ljava/util/Collection;
/*     */     //   47	6	4	array	[Ljava/lang/Object;
/*     */     //   0	64	0	this	Lorg/springframework/web/servlet/mvc/method/annotation/AbstractMessageConverterMethodArgumentResolver;
/*     */     //   0	64	1	arg	Ljava/lang/Object;
/*     */     //   0	64	2	parameter	Lorg/springframework/core/MethodParameter;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   25	9	3	collection	Ljava/util/Collection<*>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeStreamIfNecessary(InputStream body) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EmptyBodyCheckingHttpInputMessage
/*     */     implements HttpInputMessage
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final InputStream body;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EmptyBodyCheckingHttpInputMessage(HttpInputMessage inputMessage) throws IOException {
/* 365 */       this.headers = inputMessage.getHeaders();
/* 366 */       InputStream inputStream = inputMessage.getBody();
/* 367 */       if (inputStream.markSupported()) {
/* 368 */         inputStream.mark(1);
/* 369 */         this.body = (inputStream.read() != -1) ? inputStream : null;
/* 370 */         inputStream.reset();
/*     */       } else {
/*     */         
/* 373 */         PushbackInputStream pushbackInputStream = new PushbackInputStream(inputStream);
/* 374 */         int b = pushbackInputStream.read();
/* 375 */         if (b == -1) {
/* 376 */           this.body = null;
/*     */         } else {
/*     */           
/* 379 */           this.body = pushbackInputStream;
/* 380 */           pushbackInputStream.unread(b);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 387 */       return this.headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getBody() {
/* 392 */       return (this.body != null) ? this.body : InputStream.nullInputStream();
/*     */     }
/*     */     
/*     */     public boolean hasBody() {
/* 396 */       return (this.body != null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NoContentTypeHttpMessageConverter
/*     */     implements HttpMessageConverter<String>
/*     */   {
/*     */     public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/* 410 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 415 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<MediaType> getSupportedMediaTypes() {
/* 420 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     public String read(Class<? extends String> clazz, HttpInputMessage inputMessage) {
/* 425 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(String s, @Nullable MediaType contentType, HttpOutputMessage outputMessage) {
/* 430 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\AbstractMessageConverterMethodArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */