/*     */ package org.springframework.web.servlet.mvc.method;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.HeadersRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PathPatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestConditionHolder;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultBuilder
/*     */   implements RequestMappingInfo.Builder
/*     */ {
/*     */   private String[] paths;
/* 618 */   private RequestMethod[] methods = new RequestMethod[0];
/*     */   
/* 620 */   private String[] params = new String[0];
/*     */   
/* 622 */   private String[] headers = new String[0];
/*     */   
/* 624 */   private String[] consumes = new String[0];
/*     */   
/* 626 */   private String[] produces = new String[0];
/*     */   
/*     */   private boolean hasContentType;
/*     */   
/*     */   private boolean hasAccept;
/*     */   
/*     */   @Nullable
/*     */   private String mappingName;
/*     */   
/*     */   @Nullable
/*     */   private RequestCondition<?> customCondition;
/*     */   
/* 638 */   private RequestMappingInfo.BuilderConfiguration options = new RequestMappingInfo.BuilderConfiguration();
/*     */   
/*     */   public DefaultBuilder(String... paths) {
/* 641 */     this.paths = paths;
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestMappingInfo.Builder paths(String... paths) {
/* 646 */     this.paths = paths;
/* 647 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder methods(RequestMethod... methods) {
/* 652 */     this.methods = methods;
/* 653 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder params(String... params) {
/* 658 */     this.params = params;
/* 659 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder headers(String... headers) {
/* 664 */     for (String header : headers) {
/* 665 */       this
/* 666 */         .hasContentType = (this.hasContentType || header.contains("Content-Type") || header.contains("content-type"));
/* 667 */       this
/* 668 */         .hasAccept = (this.hasAccept || header.contains("Accept") || header.contains("accept"));
/*     */     } 
/* 670 */     this.headers = headers;
/* 671 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder consumes(String... consumes) {
/* 676 */     this.consumes = consumes;
/* 677 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder produces(String... produces) {
/* 682 */     this.produces = produces;
/* 683 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder mappingName(String name) {
/* 688 */     this.mappingName = name;
/* 689 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultBuilder customCondition(RequestCondition<?> condition) {
/* 694 */     this.customCondition = condition;
/* 695 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestMappingInfo.Builder options(RequestMappingInfo.BuilderConfiguration options) {
/* 700 */     this.options = options;
/* 701 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMappingInfo build() {
/* 708 */     PathPatternsRequestCondition pathPatternsCondition = null;
/* 709 */     PatternsRequestCondition patternsCondition = null;
/*     */     
/* 711 */     PathPatternParser parser = this.options.getPatternParserToUse();
/*     */     
/* 713 */     if (parser != null) {
/*     */ 
/*     */       
/* 716 */       pathPatternsCondition = ObjectUtils.isEmpty((Object[])this.paths) ? RequestMappingInfo.EMPTY_PATH_PATTERNS : new PathPatternsRequestCondition(parser, this.paths);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 724 */       patternsCondition = ObjectUtils.isEmpty((Object[])this.paths) ? RequestMappingInfo.EMPTY_PATTERNS : new PatternsRequestCondition(this.paths, null, this.options.pathMatcher, this.options.useSuffixPatternMatch(), this.options.useTrailingSlashMatch(), this.options.getFileExtensions());
/*     */     } 
/*     */     
/* 727 */     ContentNegotiationManager manager = this.options.getContentNegotiationManager();
/*     */     
/* 729 */     return new RequestMappingInfo(this.mappingName, pathPatternsCondition, patternsCondition, 
/*     */         
/* 731 */         ObjectUtils.isEmpty((Object[])this.methods) ? 
/* 732 */         RequestMappingInfo.EMPTY_REQUEST_METHODS : new RequestMethodsRequestCondition(this.methods), 
/* 733 */         ObjectUtils.isEmpty((Object[])this.params) ? 
/* 734 */         RequestMappingInfo.EMPTY_PARAMS : new ParamsRequestCondition(this.params), 
/* 735 */         ObjectUtils.isEmpty((Object[])this.headers) ? 
/* 736 */         RequestMappingInfo.EMPTY_HEADERS : new HeadersRequestCondition(this.headers), 
/* 737 */         (ObjectUtils.isEmpty((Object[])this.consumes) && !this.hasContentType) ? 
/* 738 */         RequestMappingInfo.EMPTY_CONSUMES : new ConsumesRequestCondition(this.consumes, this.headers), 
/* 739 */         (ObjectUtils.isEmpty((Object[])this.produces) && !this.hasAccept) ? 
/* 740 */         RequestMappingInfo.EMPTY_PRODUCES : new ProducesRequestCondition(this.produces, this.headers, manager), 
/* 741 */         (this.customCondition != null) ? 
/* 742 */         new RequestConditionHolder(this.customCondition) : RequestMappingInfo.EMPTY_CUSTOM, this.options);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\RequestMappingInfo$DefaultBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */