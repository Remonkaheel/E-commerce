/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotationPredicates;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.annotation.RepeatableContainers;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.annotation.CrossOrigin;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.service.annotation.HttpExchange;
/*     */ import org.springframework.web.servlet.handler.MatchableHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.RequestMatchResult;
/*     */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestMappingHandlerMapping
/*     */   extends RequestMappingInfoHandlerMapping
/*     */   implements MatchableHandlerMapping, EmbeddedValueResolverAware
/*     */ {
/*  87 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  89 */   private static final RequestMethod[] EMPTY_REQUEST_METHOD_ARRAY = new RequestMethod[0];
/*     */ 
/*     */   
/*     */   private boolean defaultPatternParser = true;
/*     */   
/*     */   private boolean useSuffixPatternMatch = false;
/*     */   
/*     */   private boolean useRegisteredSuffixPatternMatch = false;
/*     */   
/*     */   private boolean useTrailingSlashMatch = false;
/*     */   
/* 100 */   private Map<String, Predicate<Class<?>>> pathPrefixes = Collections.emptyMap();
/*     */   
/* 102 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */   
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   
/* 107 */   private RequestMappingInfo.BuilderConfiguration config = new RequestMappingInfo.BuilderConfiguration();
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternParser(@Nullable PathPatternParser patternParser) {
/* 112 */     if (patternParser != null) {
/* 113 */       this.defaultPatternParser = false;
/*     */     }
/* 115 */     super.setPatternParser(patternParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setUseSuffixPatternMatch(boolean useSuffixPatternMatch) {
/* 131 */     this.useSuffixPatternMatch = useSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setUseRegisteredSuffixPatternMatch(boolean useRegisteredSuffixPatternMatch) {
/* 147 */     this.useRegisteredSuffixPatternMatch = useRegisteredSuffixPatternMatch;
/* 148 */     this.useSuffixPatternMatch = (useRegisteredSuffixPatternMatch || this.useSuffixPatternMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public void setUseTrailingSlashMatch(boolean useTrailingSlashMatch) {
/* 161 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/* 162 */     if (getPatternParser() != null) {
/* 163 */       getPatternParser().setMatchOptionalTrailingSeparator(useTrailingSlashMatch);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathPrefixes(Map<String, Predicate<Class<?>>> prefixes) {
/* 179 */     this
/*     */       
/* 181 */       .pathPrefixes = !prefixes.isEmpty() ? Collections.<String, Predicate<Class<?>>>unmodifiableMap(new LinkedHashMap<>(prefixes)) : Collections.<String, Predicate<Class<?>>>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Predicate<Class<?>>> getPathPrefixes() {
/* 189 */     return this.pathPrefixes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager) {
/* 197 */     Assert.notNull(contentNegotiationManager, "ContentNegotiationManager must not be null");
/* 198 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentNegotiationManager getContentNegotiationManager() {
/* 205 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/* 210 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 216 */     this.config = new RequestMappingInfo.BuilderConfiguration();
/* 217 */     this.config.setTrailingSlashMatch(useTrailingSlashMatch());
/* 218 */     this.config.setContentNegotiationManager(getContentNegotiationManager());
/*     */     
/* 220 */     if (getPatternParser() != null && this.defaultPatternParser && (this.useSuffixPatternMatch || this.useRegisteredSuffixPatternMatch))
/*     */     {
/*     */       
/* 223 */       setPatternParser((PathPatternParser)null);
/*     */     }
/*     */     
/* 226 */     if (getPatternParser() != null) {
/* 227 */       this.config.setPatternParser(getPatternParser());
/* 228 */       Assert.isTrue((!this.useSuffixPatternMatch && !this.useRegisteredSuffixPatternMatch), "Suffix pattern matching not supported with PathPatternParser.");
/*     */     }
/*     */     else {
/*     */       
/* 232 */       this.config.setSuffixPatternMatch(useSuffixPatternMatch());
/* 233 */       this.config.setRegisteredSuffixPatternMatch(useRegisteredSuffixPatternMatch());
/* 234 */       this.config.setPathMatcher(getPathMatcher());
/*     */     } 
/*     */     
/* 237 */     super.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean useSuffixPatternMatch() {
/* 248 */     return this.useSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean useRegisteredSuffixPatternMatch() {
/* 258 */     return this.useRegisteredSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useTrailingSlashMatch() {
/* 265 */     return this.useTrailingSlashMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public List<String> getFileExtensions() {
/* 277 */     return this.config.getFileExtensions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMappingInfo.BuilderConfiguration getBuilderConfiguration() {
/* 290 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isHandler(Class<?> beanType) {
/* 300 */     return AnnotatedElementUtils.hasAnnotation(beanType, Controller.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected RequestMappingInfo getMappingForMethod(Method method, Class<?> handlerType) {
/* 315 */     RequestMappingInfo info = createRequestMappingInfo(method);
/* 316 */     if (info != null) {
/* 317 */       RequestMappingInfo typeInfo = createRequestMappingInfo(handlerType);
/* 318 */       if (typeInfo != null) {
/* 319 */         info = typeInfo.combine(info);
/*     */       }
/* 321 */       if (info.isEmptyMapping()) {
/* 322 */         info = info.mutate().paths(new String[] { "", "/" }).options(this.config).build();
/*     */       }
/* 324 */       String prefix = getPathPrefix(handlerType);
/* 325 */       if (prefix != null) {
/* 326 */         info = RequestMappingInfo.paths(new String[] { prefix }).options(this.config).build().combine(info);
/*     */       }
/*     */     } 
/* 329 */     return info;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   String getPathPrefix(Class<?> handlerType) {
/* 334 */     for (Map.Entry<String, Predicate<Class<?>>> entry : this.pathPrefixes.entrySet()) {
/* 335 */       if (((Predicate<Class<?>>)entry.getValue()).test(handlerType)) {
/* 336 */         String prefix = entry.getKey();
/* 337 */         if (this.embeddedValueResolver != null) {
/* 338 */           prefix = this.embeddedValueResolver.resolveStringValue(prefix);
/*     */         }
/* 340 */         return prefix;
/*     */       } 
/*     */     } 
/* 343 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RequestMappingInfo createRequestMappingInfo(AnnotatedElement element) {
/* 348 */     RequestMappingInfo requestMappingInfo = null;
/* 349 */     Class<?> clazz = (Class)element;
/* 350 */     RequestCondition<?> customCondition = (element instanceof Class) ? getCustomTypeCondition(clazz) : getCustomMethodCondition((Method)element);
/*     */     
/* 352 */     List<AnnotationDescriptor> descriptors = getAnnotationDescriptors(element);
/*     */ 
/*     */     
/* 355 */     List<AnnotationDescriptor> requestMappings = descriptors.stream().filter(desc -> desc.annotation instanceof RequestMapping).toList();
/* 356 */     if (!requestMappings.isEmpty()) {
/* 357 */       if (requestMappings.size() > 1 && this.logger.isWarnEnabled()) {
/* 358 */         this.logger.warn("Multiple @RequestMapping annotations found on %s, but only the first will be used: %s"
/* 359 */             .formatted(new Object[] { element, requestMappings }));
/*     */       }
/* 361 */       requestMappingInfo = createRequestMappingInfo((RequestMapping)((AnnotationDescriptor)requestMappings.get(0)).annotation, customCondition);
/*     */     } 
/*     */ 
/*     */     
/* 365 */     List<AnnotationDescriptor> httpExchanges = descriptors.stream().filter(desc -> desc.annotation instanceof HttpExchange).toList();
/* 366 */     if (!httpExchanges.isEmpty()) {
/* 367 */       Assert.state((requestMappingInfo == null), () -> "%s is annotated with @RequestMapping and @HttpExchange annotations, but only one is allowed: %s".formatted(new Object[] { element, Stream.<List>of(new List[] { requestMappings, httpExchanges }).flatMap(Collection::stream).toList() }));
/*     */ 
/*     */       
/* 370 */       Assert.state((httpExchanges.size() == 1), () -> "Multiple @HttpExchange annotations found on %s, but only one is allowed: %s".formatted(new Object[] { element, httpExchanges }));
/*     */ 
/*     */       
/* 373 */       requestMappingInfo = createRequestMappingInfo((HttpExchange)((AnnotationDescriptor)httpExchanges.get(0)).annotation, customCondition);
/*     */     } 
/*     */     
/* 376 */     return requestMappingInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected RequestCondition<?> getCustomTypeCondition(Class<?> handlerType) {
/* 392 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected RequestCondition<?> getCustomMethodCondition(Method method) {
/* 408 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RequestMappingInfo createRequestMappingInfo(RequestMapping requestMapping, @Nullable RequestCondition<?> customCondition) {
/* 427 */     RequestMappingInfo.Builder builder = RequestMappingInfo.paths(resolveEmbeddedValuesInPatterns(requestMapping.path())).methods(requestMapping.method()).params(requestMapping.params()).headers(requestMapping.headers()).consumes(requestMapping.consumes()).produces(requestMapping.produces()).mappingName(requestMapping.name());
/*     */     
/* 429 */     if (customCondition != null) {
/* 430 */       builder.customCondition(customCondition);
/*     */     }
/*     */     
/* 433 */     return builder.options(this.config).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RequestMappingInfo createRequestMappingInfo(HttpExchange httpExchange, @Nullable RequestCondition<?> customCondition) {
/* 451 */     RequestMappingInfo.Builder builder = RequestMappingInfo.paths(resolveEmbeddedValuesInPatterns(toStringArray(httpExchange.value()))).methods(toMethodArray(httpExchange.method())).consumes(toStringArray(httpExchange.contentType())).produces(httpExchange.accept()).headers(httpExchange.headers());
/*     */     
/* 453 */     if (customCondition != null) {
/* 454 */       builder.customCondition(customCondition);
/*     */     }
/*     */     
/* 457 */     return builder.options(this.config).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] resolveEmbeddedValuesInPatterns(String[] patterns) {
/* 465 */     if (this.embeddedValueResolver == null) {
/* 466 */       return patterns;
/*     */     }
/*     */     
/* 469 */     String[] resolvedPatterns = new String[patterns.length];
/* 470 */     for (int i = 0; i < patterns.length; i++) {
/* 471 */       resolvedPatterns[i] = this.embeddedValueResolver.resolveStringValue(patterns[i]);
/*     */     }
/* 473 */     return resolvedPatterns;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String[] toStringArray(String value) {
/* 478 */     (new String[1])[0] = value; return StringUtils.hasText(value) ? new String[1] : EMPTY_STRING_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   private static RequestMethod[] toMethodArray(String method) {
/* 483 */     (new RequestMethod[1])[0] = RequestMethod.valueOf(method); return StringUtils.hasText(method) ? new RequestMethod[1] : EMPTY_REQUEST_METHOD_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerMapping(RequestMappingInfo mapping, Object handler, Method method) {
/* 488 */     super.registerMapping(mapping, handler, method);
/* 489 */     updateConsumesCondition(mapping, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerHandlerMethod(Object handler, Method method, RequestMappingInfo mapping) {
/* 507 */     super.registerHandlerMethod(handler, method, mapping);
/* 508 */     updateConsumesCondition(mapping, method);
/*     */   }
/*     */   
/*     */   private void updateConsumesCondition(RequestMappingInfo info, Method method) {
/* 512 */     ConsumesRequestCondition condition = info.getConsumesCondition();
/* 513 */     if (!condition.isEmpty()) {
/* 514 */       for (Parameter parameter : method.getParameters()) {
/* 515 */         MergedAnnotation<RequestBody> annot = MergedAnnotations.from(parameter).get(RequestBody.class);
/* 516 */         if (annot.isPresent()) {
/* 517 */           condition.setBodyRequired(annot.getBoolean("required"));
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RequestMatchResult match(HttpServletRequest request, String pattern) {
/* 527 */     Assert.state((getPatternParser() == null), "This HandlerMapping uses PathPatterns.");
/* 528 */     RequestMappingInfo info = RequestMappingInfo.paths(new String[] { pattern }).options(this.config).build();
/* 529 */     RequestMappingInfo match = info.getMatchingCondition(request);
/* 530 */     return (match != null && match.getPatternsCondition() != null) ? 
/* 531 */       new RequestMatchResult(match
/* 532 */         .getPatternsCondition().getPatterns().iterator().next(), 
/* 533 */         UrlPathHelper.getResolvedLookupPath((ServletRequest)request), 
/* 534 */         getPathMatcher()) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CorsConfiguration initCorsConfiguration(Object handler, Method method, RequestMappingInfo mappingInfo) {
/* 540 */     HandlerMethod handlerMethod = createHandlerMethod(handler, method);
/* 541 */     Class<?> beanType = handlerMethod.getBeanType();
/* 542 */     CrossOrigin typeAnnotation = (CrossOrigin)AnnotatedElementUtils.findMergedAnnotation(beanType, CrossOrigin.class);
/* 543 */     CrossOrigin methodAnnotation = (CrossOrigin)AnnotatedElementUtils.findMergedAnnotation(method, CrossOrigin.class);
/*     */     
/* 545 */     if (typeAnnotation == null && methodAnnotation == null) {
/* 546 */       return null;
/*     */     }
/*     */     
/* 549 */     CorsConfiguration config = new CorsConfiguration();
/* 550 */     updateCorsConfig(config, typeAnnotation);
/* 551 */     updateCorsConfig(config, methodAnnotation);
/*     */     
/* 553 */     if (CollectionUtils.isEmpty(config.getAllowedMethods())) {
/* 554 */       for (RequestMethod allowedMethod : mappingInfo.getMethodsCondition().getMethods()) {
/* 555 */         config.addAllowedMethod(allowedMethod.name());
/*     */       }
/*     */     }
/* 558 */     return config.applyPermitDefaultValues();
/*     */   }
/*     */   
/*     */   private void updateCorsConfig(CorsConfiguration config, @Nullable CrossOrigin annotation) {
/* 562 */     if (annotation == null) {
/*     */       return;
/*     */     }
/* 565 */     for (String origin : annotation.origins()) {
/* 566 */       config.addAllowedOrigin(resolveCorsAnnotationValue(origin));
/*     */     }
/* 568 */     for (String patterns : annotation.originPatterns()) {
/* 569 */       config.addAllowedOriginPattern(resolveCorsAnnotationValue(patterns));
/*     */     }
/* 571 */     for (RequestMethod method : annotation.methods()) {
/* 572 */       config.addAllowedMethod(method.name());
/*     */     }
/* 574 */     for (String header : annotation.allowedHeaders()) {
/* 575 */       config.addAllowedHeader(resolveCorsAnnotationValue(header));
/*     */     }
/* 577 */     for (String header : annotation.exposedHeaders()) {
/* 578 */       config.addExposedHeader(resolveCorsAnnotationValue(header));
/*     */     }
/*     */     
/* 581 */     String allowCredentials = resolveCorsAnnotationValue(annotation.allowCredentials());
/* 582 */     if ("true".equalsIgnoreCase(allowCredentials)) {
/* 583 */       config.setAllowCredentials(Boolean.valueOf(true));
/*     */     }
/* 585 */     else if ("false".equalsIgnoreCase(allowCredentials)) {
/* 586 */       config.setAllowCredentials(Boolean.valueOf(false));
/*     */     }
/* 588 */     else if (!allowCredentials.isEmpty()) {
/* 589 */       throw new IllegalStateException("@CrossOrigin's allowCredentials value must be \"true\", \"false\", or an empty string (\"\"): current value is [" + allowCredentials + "]");
/*     */     } 
/*     */ 
/*     */     
/* 593 */     String allowPrivateNetwork = resolveCorsAnnotationValue(annotation.allowPrivateNetwork());
/* 594 */     if ("true".equalsIgnoreCase(allowPrivateNetwork)) {
/* 595 */       config.setAllowPrivateNetwork(Boolean.valueOf(true));
/*     */     }
/* 597 */     else if ("false".equalsIgnoreCase(allowPrivateNetwork)) {
/* 598 */       config.setAllowPrivateNetwork(Boolean.valueOf(false));
/*     */     }
/* 600 */     else if (!allowPrivateNetwork.isEmpty()) {
/* 601 */       throw new IllegalStateException("@CrossOrigin's allowPrivateNetwork value must be \"true\", \"false\", or an empty string (\"\"): current value is [" + allowPrivateNetwork + "]");
/*     */     } 
/*     */ 
/*     */     
/* 605 */     if (annotation.maxAge() >= 0L) {
/* 606 */       config.setMaxAge(Long.valueOf(annotation.maxAge()));
/*     */     }
/*     */   }
/*     */   
/*     */   private String resolveCorsAnnotationValue(String value) {
/* 611 */     if (this.embeddedValueResolver != null) {
/* 612 */       String resolved = this.embeddedValueResolver.resolveStringValue(value);
/* 613 */       return (resolved != null) ? resolved : "";
/*     */     } 
/*     */     
/* 616 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<AnnotationDescriptor> getAnnotationDescriptors(AnnotatedElement element) {
/* 621 */     return MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY, RepeatableContainers.none())
/* 622 */       .stream()
/* 623 */       .filter(MergedAnnotationPredicates.typeIn(new Class[] { RequestMapping.class, HttpExchange.class
/* 624 */           })).filter(MergedAnnotationPredicates.firstRunOf(MergedAnnotation::getAggregateIndex))
/* 625 */       .map(AnnotationDescriptor::new)
/* 626 */       .distinct()
/* 627 */       .toList();
/*     */   }
/*     */   
/*     */   private static class AnnotationDescriptor
/*     */   {
/*     */     private final Annotation annotation;
/*     */     private final MergedAnnotation<?> root;
/*     */     
/*     */     AnnotationDescriptor(MergedAnnotation<Annotation> mergedAnnotation) {
/* 636 */       this.annotation = mergedAnnotation.synthesize();
/* 637 */       this.root = mergedAnnotation.getRoot();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 642 */       if (obj instanceof AnnotationDescriptor) { AnnotationDescriptor that = (AnnotationDescriptor)obj; if (this.annotation.equals(that.annotation)); }  return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 647 */       return this.annotation.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 652 */       return this.root.synthesize().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestMappingHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */