/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatternsRequestCondition
/*     */   extends AbstractRequestCondition<PatternsRequestCondition>
/*     */ {
/*  54 */   private static final Set<String> EMPTY_PATH_PATTERN = Collections.singleton("");
/*     */   
/*  56 */   private static final String[] ROOT_PATH_PATTERNS = new String[] { "", "/" };
/*     */ 
/*     */   
/*     */   private final Set<String> patterns;
/*     */   
/*     */   private final PathMatcher pathMatcher;
/*     */   
/*     */   private final boolean useSuffixPatternMatch;
/*     */   
/*     */   private final boolean useTrailingSlashMatch;
/*     */   
/*  67 */   private final List<String> fileExtensions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternsRequestCondition(String... patterns) {
/*  76 */     this(patterns, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternsRequestCondition(String[] patterns, boolean useTrailingSlashMatch, @Nullable PathMatcher pathMatcher) {
/*  87 */     this(patterns, null, pathMatcher, useTrailingSlashMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PatternsRequestCondition(String[] patterns, @Nullable UrlPathHelper urlPathHelper, @Nullable PathMatcher pathMatcher, boolean useTrailingSlashMatch) {
/* 105 */     this(patterns, urlPathHelper, pathMatcher, false, useTrailingSlashMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PatternsRequestCondition(String[] patterns, @Nullable UrlPathHelper urlPathHelper, @Nullable PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch) {
/* 123 */     this(patterns, urlPathHelper, pathMatcher, useSuffixPatternMatch, useTrailingSlashMatch, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PatternsRequestCondition(String[] patterns, @Nullable UrlPathHelper urlPathHelper, @Nullable PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch, @Nullable List<String> fileExtensions) {
/* 142 */     this.patterns = initPatterns(patterns);
/* 143 */     this.pathMatcher = (pathMatcher != null) ? pathMatcher : (PathMatcher)new AntPathMatcher();
/* 144 */     this.useSuffixPatternMatch = useSuffixPatternMatch;
/* 145 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/*     */     
/* 147 */     if (fileExtensions != null) {
/* 148 */       for (String fileExtension : fileExtensions) {
/* 149 */         if (fileExtension.charAt(0) != '.') {
/* 150 */           fileExtension = "." + fileExtension;
/*     */         }
/* 152 */         this.fileExtensions.add(fileExtension);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static Set<String> initPatterns(String[] patterns) {
/* 158 */     if (!hasPattern(patterns)) {
/* 159 */       return EMPTY_PATH_PATTERN;
/*     */     }
/* 161 */     Set<String> result = CollectionUtils.newLinkedHashSet(patterns.length);
/* 162 */     for (String pattern : patterns) {
/* 163 */       pattern = PathPatternParser.defaultInstance.initFullPathPattern(pattern);
/* 164 */       result.add(pattern);
/*     */     } 
/* 166 */     return result;
/*     */   }
/*     */   
/*     */   private static boolean hasPattern(String[] patterns) {
/* 170 */     if (!ObjectUtils.isEmpty((Object[])patterns)) {
/* 171 */       for (String pattern : patterns) {
/* 172 */         if (StringUtils.hasText(pattern)) {
/* 173 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PatternsRequestCondition(Set<String> patterns, PatternsRequestCondition other) {
/* 184 */     this.patterns = patterns;
/* 185 */     this.pathMatcher = other.pathMatcher;
/* 186 */     this.useSuffixPatternMatch = other.useSuffixPatternMatch;
/* 187 */     this.useTrailingSlashMatch = other.useTrailingSlashMatch;
/* 188 */     this.fileExtensions.addAll(other.fileExtensions);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getPatterns() {
/* 193 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<String> getContent() {
/* 198 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getToStringInfix() {
/* 203 */     return " || ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmptyPathMapping() {
/* 210 */     return (this.patterns == EMPTY_PATH_PATTERN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getDirectPaths() {
/* 218 */     if (isEmptyPathMapping()) {
/* 219 */       return EMPTY_PATH_PATTERN;
/*     */     }
/* 221 */     Set<String> result = Collections.emptySet();
/* 222 */     for (String pattern : this.patterns) {
/* 223 */       if (!this.pathMatcher.isPattern(pattern)) {
/* 224 */         result = result.isEmpty() ? new HashSet<>(1) : result;
/* 225 */         result.add(pattern);
/*     */       } 
/*     */     } 
/* 228 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatternsRequestCondition combine(PatternsRequestCondition other) {
/* 242 */     if (isEmptyPathMapping() && other.isEmptyPathMapping()) {
/* 243 */       return new PatternsRequestCondition(ROOT_PATH_PATTERNS);
/*     */     }
/* 245 */     if (other.isEmptyPathMapping()) {
/* 246 */       return this;
/*     */     }
/* 248 */     if (isEmptyPathMapping()) {
/* 249 */       return other;
/*     */     }
/* 251 */     Set<String> result = new LinkedHashSet<>();
/* 252 */     if (!this.patterns.isEmpty() && !other.patterns.isEmpty()) {
/* 253 */       for (String pattern1 : this.patterns) {
/* 254 */         for (String pattern2 : other.patterns) {
/* 255 */           result.add(this.pathMatcher.combine(pattern1, pattern2));
/*     */         }
/*     */       } 
/*     */     }
/* 259 */     return new PatternsRequestCondition(result, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PatternsRequestCondition getMatchingCondition(HttpServletRequest request) {
/* 281 */     String lookupPath = UrlPathHelper.getResolvedLookupPath((ServletRequest)request);
/* 282 */     List<String> matches = getMatchingPatterns(lookupPath);
/* 283 */     return !matches.isEmpty() ? new PatternsRequestCondition(new LinkedHashSet<>(matches), this) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getMatchingPatterns(String lookupPath) {
/* 295 */     List<String> matches = null;
/* 296 */     for (String pattern : this.patterns) {
/* 297 */       String match = getMatchingPattern(pattern, lookupPath);
/* 298 */       if (match != null) {
/* 299 */         matches = (matches != null) ? matches : new ArrayList<>();
/* 300 */         matches.add(match);
/*     */       } 
/*     */     } 
/* 303 */     if (matches == null) {
/* 304 */       return Collections.emptyList();
/*     */     }
/* 306 */     if (matches.size() > 1) {
/* 307 */       matches.sort(this.pathMatcher.getPatternComparator(lookupPath));
/*     */     }
/* 309 */     return matches;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getMatchingPattern(String pattern, String lookupPath) {
/* 314 */     if (pattern.equals(lookupPath)) {
/* 315 */       return pattern;
/*     */     }
/* 317 */     if (this.useSuffixPatternMatch) {
/* 318 */       if (!this.fileExtensions.isEmpty() && lookupPath.indexOf('.') != -1) {
/* 319 */         for (String extension : this.fileExtensions) {
/* 320 */           if (this.pathMatcher.match(pattern + pattern, lookupPath)) {
/* 321 */             return pattern + pattern;
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 326 */         boolean hasSuffix = (pattern.indexOf('.') != -1);
/* 327 */         if (!hasSuffix && this.pathMatcher.match(pattern + ".*", lookupPath)) {
/* 328 */           return pattern + ".*";
/*     */         }
/*     */       } 
/*     */     }
/* 332 */     if (this.pathMatcher.match(pattern, lookupPath)) {
/* 333 */       return pattern;
/*     */     }
/* 335 */     if (this.useTrailingSlashMatch && 
/* 336 */       !pattern.endsWith("/") && this.pathMatcher.match(pattern + "/", lookupPath)) {
/* 337 */       return pattern + "/";
/*     */     }
/*     */     
/* 340 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(PatternsRequestCondition other, HttpServletRequest request) {
/* 356 */     String lookupPath = UrlPathHelper.getResolvedLookupPath((ServletRequest)request);
/* 357 */     Comparator<String> patternComparator = this.pathMatcher.getPatternComparator(lookupPath);
/* 358 */     Iterator<String> iterator = this.patterns.iterator();
/* 359 */     Iterator<String> iteratorOther = other.patterns.iterator();
/* 360 */     while (iterator.hasNext() && iteratorOther.hasNext()) {
/* 361 */       int result = patternComparator.compare(iterator.next(), iteratorOther.next());
/* 362 */       if (result != 0) {
/* 363 */         return result;
/*     */       }
/*     */     } 
/* 366 */     if (iterator.hasNext()) {
/* 367 */       return -1;
/*     */     }
/* 369 */     if (iteratorOther.hasNext()) {
/* 370 */       return 1;
/*     */     }
/*     */     
/* 373 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\PatternsRequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */