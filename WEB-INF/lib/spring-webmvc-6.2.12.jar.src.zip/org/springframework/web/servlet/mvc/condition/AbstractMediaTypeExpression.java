/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractMediaTypeExpression
/*     */   implements MediaTypeExpression, Comparable<AbstractMediaTypeExpression>
/*     */ {
/*     */   private final MediaType mediaType;
/*     */   private final boolean isNegated;
/*     */   
/*     */   AbstractMediaTypeExpression(String expression) {
/*  42 */     if (expression.startsWith("!")) {
/*  43 */       this.isNegated = true;
/*  44 */       expression = expression.substring(1);
/*     */     } else {
/*     */       
/*  47 */       this.isNegated = false;
/*     */     } 
/*  49 */     this.mediaType = MediaType.parseMediaType(expression);
/*     */   }
/*     */   
/*     */   AbstractMediaTypeExpression(MediaType mediaType, boolean negated) {
/*  53 */     this.mediaType = mediaType;
/*  54 */     this.isNegated = negated;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaType getMediaType() {
/*  60 */     return this.mediaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNegated() {
/*  65 */     return this.isNegated;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(AbstractMediaTypeExpression other) {
/*  71 */     MediaType mediaType1 = getMediaType();
/*  72 */     MediaType mediaType2 = other.getMediaType();
/*  73 */     if (mediaType1.isMoreSpecific((MimeType)mediaType2)) {
/*  74 */       return -1;
/*     */     }
/*  76 */     if (mediaType1.isLessSpecific((MimeType)mediaType2)) {
/*  77 */       return 1;
/*     */     }
/*     */     
/*  80 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchParameters(MediaType contentType) {
/*  85 */     for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)getMediaType().getParameters().entrySet()) {
/*  86 */       if (StringUtils.hasText(entry.getValue())) {
/*  87 */         String value = contentType.getParameter(entry.getKey());
/*  88 */         if (StringUtils.hasText(value) && !((String)entry.getValue()).equalsIgnoreCase(value)) {
/*  89 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  98 */     if (this == other) {
/*  99 */       return true;
/*     */     }
/* 101 */     if (other == null || getClass() != other.getClass()) {
/* 102 */       return false;
/*     */     }
/* 104 */     AbstractMediaTypeExpression otherExpr = (AbstractMediaTypeExpression)other;
/* 105 */     return (this.mediaType.equals(otherExpr.mediaType) && this.isNegated == otherExpr.isNegated);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 110 */     return this.mediaType.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 115 */     if (this.isNegated) {
/* 116 */       return "!" + this.mediaType.toString();
/*     */     }
/* 118 */     return this.mediaType.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\AbstractMediaTypeExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */