/*     */ package org.springframework.web.servlet.mvc.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ResponseStatus;
/*     */ import org.springframework.web.server.ResponseStatusException;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseStatusExceptionResolver
/*     */   extends AbstractHandlerExceptionResolver
/*     */   implements MessageSourceAware
/*     */ {
/*     */   @Nullable
/*     */   private MessageSource messageSource;
/*     */   
/*     */   public void setMessageSource(@Nullable MessageSource messageSource) {
/*  65 */     this.messageSource = messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
/*     */     try {
/*  75 */       if (ex instanceof ResponseStatusException) { ResponseStatusException rse = (ResponseStatusException)ex;
/*  76 */         return resolveResponseStatusException(rse, request, response, handler); }
/*     */ 
/*     */       
/*  79 */       ResponseStatus status = (ResponseStatus)AnnotatedElementUtils.findMergedAnnotation(ex.getClass(), ResponseStatus.class);
/*  80 */       if (status != null) {
/*  81 */         return resolveResponseStatus(status, request, response, handler, ex);
/*     */       }
/*     */       
/*  84 */       Throwable throwable = ex.getCause(); if (throwable instanceof Exception) { Exception cause = (Exception)throwable;
/*  85 */         return doResolveException(request, response, handler, cause); }
/*     */ 
/*     */     
/*  88 */     } catch (Exception resolveEx) {
/*  89 */       if (this.logger.isWarnEnabled()) {
/*  90 */         this.logger.warn("Failure while trying to resolve exception [" + ex.getClass().getName() + "]", resolveEx);
/*     */       }
/*     */     } 
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView resolveResponseStatus(ResponseStatus responseStatus, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) throws Exception {
/* 111 */     int statusCode = responseStatus.code().value();
/* 112 */     String reason = responseStatus.reason();
/* 113 */     return applyStatusAndReason(statusCode, reason, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView resolveResponseStatusException(ResponseStatusException ex, HttpServletRequest request, HttpServletResponse response, @Nullable Object handler) throws Exception {
/* 133 */     ex.getHeaders().forEach((name, values) -> values.forEach(()));
/* 134 */     return applyStatusAndReason(ex.getStatusCode().value(), ex.getReason(), response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModelAndView applyStatusAndReason(int statusCode, @Nullable String reason, HttpServletResponse response) throws IOException {
/* 151 */     if (!StringUtils.hasLength(reason)) {
/* 152 */       response.sendError(statusCode);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 157 */       String resolvedReason = (this.messageSource != null) ? this.messageSource.getMessage(reason, null, reason, LocaleContextHolder.getLocale()) : reason;
/* 158 */       response.sendError(statusCode, resolvedReason);
/*     */     } 
/* 160 */     return new ModelAndView();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\annotation\ResponseStatusExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */