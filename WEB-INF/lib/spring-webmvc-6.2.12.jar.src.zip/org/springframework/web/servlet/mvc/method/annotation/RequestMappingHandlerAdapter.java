/*      */ package org.springframework.web.servlet.mvc.method.annotation;
/*      */ 
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import jakarta.servlet.http.HttpSession;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.function.Predicate;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.core.MethodIntrospector;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.core.ParameterNameDiscoverer;
/*      */ import org.springframework.core.ReactiveAdapterRegistry;
/*      */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*      */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*      */ import org.springframework.core.log.LogFormatUtils;
/*      */ import org.springframework.core.task.AsyncTaskExecutor;
/*      */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*      */ import org.springframework.core.task.TaskExecutor;
/*      */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*      */ import org.springframework.http.converter.HttpMessageConverter;
/*      */ import org.springframework.http.converter.StringHttpMessageConverter;
/*      */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.ui.ModelMap;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.validation.method.MethodValidator;
/*      */ import org.springframework.web.ErrorResponse;
/*      */ import org.springframework.web.accept.ContentNegotiationManager;
/*      */ import org.springframework.web.bind.annotation.InitBinder;
/*      */ import org.springframework.web.bind.annotation.ModelAttribute;
/*      */ import org.springframework.web.bind.annotation.RequestMapping;
/*      */ import org.springframework.web.bind.support.DefaultDataBinderFactory;
/*      */ import org.springframework.web.bind.support.DefaultSessionAttributeStore;
/*      */ import org.springframework.web.bind.support.SessionAttributeStore;
/*      */ import org.springframework.web.bind.support.WebBindingInitializer;
/*      */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*      */ import org.springframework.web.context.request.NativeWebRequest;
/*      */ import org.springframework.web.context.request.ServletWebRequest;
/*      */ import org.springframework.web.context.request.async.AsyncWebRequest;
/*      */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*      */ import org.springframework.web.context.request.async.DeferredResultProcessingInterceptor;
/*      */ import org.springframework.web.context.request.async.WebAsyncManager;
/*      */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*      */ import org.springframework.web.method.ControllerAdviceBean;
/*      */ import org.springframework.web.method.HandlerMethod;
/*      */ import org.springframework.web.method.annotation.ErrorsMethodArgumentResolver;
/*      */ import org.springframework.web.method.annotation.ExpressionValueMethodArgumentResolver;
/*      */ import org.springframework.web.method.annotation.HandlerMethodValidator;
/*      */ import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
/*      */ import org.springframework.web.method.annotation.MapMethodProcessor;
/*      */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*      */ import org.springframework.web.method.annotation.ModelFactory;
/*      */ import org.springframework.web.method.annotation.ModelMethodProcessor;
/*      */ import org.springframework.web.method.annotation.RequestHeaderMapMethodArgumentResolver;
/*      */ import org.springframework.web.method.annotation.RequestHeaderMethodArgumentResolver;
/*      */ import org.springframework.web.method.annotation.RequestParamMapMethodArgumentResolver;
/*      */ import org.springframework.web.method.annotation.RequestParamMethodArgumentResolver;
/*      */ import org.springframework.web.method.annotation.SessionAttributesHandler;
/*      */ import org.springframework.web.method.annotation.SessionStatusMethodArgumentResolver;
/*      */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*      */ import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
/*      */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*      */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*      */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*      */ import org.springframework.web.method.support.ModelAndViewContainer;
/*      */ import org.springframework.web.servlet.LocaleResolver;
/*      */ import org.springframework.web.servlet.ModelAndView;
/*      */ import org.springframework.web.servlet.View;
/*      */ import org.springframework.web.servlet.ViewResolver;
/*      */ import org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver;
/*      */ import org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter;
/*      */ import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/*      */ import org.springframework.web.servlet.support.RequestContextUtils;
/*      */ import org.springframework.web.util.WebUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RequestMappingHandlerAdapter
/*      */   extends AbstractHandlerMethodAdapter
/*      */   implements BeanFactoryAware, InitializingBean
/*      */ {
/*      */   public static final ReflectionUtils.MethodFilter INIT_BINDER_METHODS;
/*      */   public static final ReflectionUtils.MethodFilter MODEL_ATTRIBUTE_METHODS;
/*      */   
/*      */   static {
/*  137 */     INIT_BINDER_METHODS = (method -> AnnotatedElementUtils.hasAnnotation(method, InitBinder.class));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  143 */     MODEL_ATTRIBUTE_METHODS = (method -> 
/*  144 */       (!AnnotatedElementUtils.hasAnnotation(method, RequestMapping.class) && AnnotatedElementUtils.hasAnnotation(method, ModelAttribute.class)));
/*      */   }
/*      */ 
/*      */   
/*  148 */   private static final boolean BEAN_VALIDATION_PRESENT = ClassUtils.isPresent("jakarta.validation.Validator", HandlerMethod.class.getClassLoader());
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private List<HandlerMethodArgumentResolver> customArgumentResolvers;
/*      */   
/*      */   @Nullable
/*      */   private HandlerMethodArgumentResolverComposite argumentResolvers;
/*      */   
/*      */   @Nullable
/*      */   private HandlerMethodArgumentResolverComposite initBinderArgumentResolvers;
/*      */   
/*      */   @Nullable
/*      */   private List<HandlerMethodReturnValueHandler> customReturnValueHandlers;
/*      */   
/*      */   @Nullable
/*      */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*      */   
/*      */   @Nullable
/*      */   private List<ModelAndViewResolver> modelAndViewResolvers;
/*      */   
/*  169 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*      */   
/*  171 */   private final List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
/*      */   
/*  173 */   private final List<Object> requestResponseBodyAdvice = new ArrayList();
/*      */   
/*      */   @Nullable
/*      */   private WebBindingInitializer webBindingInitializer;
/*      */   
/*  178 */   private final List<ErrorResponse.Interceptor> errorResponseInterceptors = new ArrayList<>();
/*      */   
/*      */   @Nullable
/*      */   private MethodValidator methodValidator;
/*      */   
/*  183 */   private AsyncTaskExecutor taskExecutor = (AsyncTaskExecutor)new MvcSimpleAsyncTaskExecutor();
/*      */   
/*      */   @Nullable
/*      */   private Long asyncRequestTimeout;
/*      */   
/*  188 */   private CallableProcessingInterceptor[] callableInterceptors = new CallableProcessingInterceptor[0];
/*      */   
/*  190 */   private DeferredResultProcessingInterceptor[] deferredResultInterceptors = new DeferredResultProcessingInterceptor[0];
/*      */   
/*  192 */   private ReactiveAdapterRegistry reactiveAdapterRegistry = ReactiveAdapterRegistry.getSharedInstance();
/*      */   
/*      */   private boolean ignoreDefaultModelOnRedirect = true;
/*      */   
/*  196 */   private int cacheSecondsForSessionAttributeHandlers = 0;
/*      */   
/*      */   private boolean synchronizeOnSession = false;
/*      */   
/*  200 */   private SessionAttributeStore sessionAttributeStore = (SessionAttributeStore)new DefaultSessionAttributeStore();
/*      */   
/*  202 */   private ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*      */   
/*      */   @Nullable
/*      */   private ConfigurableBeanFactory beanFactory;
/*      */   
/*  207 */   private final Map<Class<?>, SessionAttributesHandler> sessionAttributesHandlerCache = new ConcurrentHashMap<>(64);
/*      */   
/*  209 */   private final Map<Class<?>, Set<Method>> initBinderCache = new ConcurrentHashMap<>(64);
/*      */   
/*  211 */   private final Map<ControllerAdviceBean, Set<Method>> initBinderAdviceCache = new LinkedHashMap<>();
/*      */   
/*  213 */   private final Map<Class<?>, Set<Method>> modelAttributeCache = new ConcurrentHashMap<>(64);
/*      */   
/*  215 */   private final Map<ControllerAdviceBean, Set<Method>> modelAttributeAdviceCache = new LinkedHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
/*  224 */     this.customArgumentResolvers = argumentResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public List<HandlerMethodArgumentResolver> getCustomArgumentResolvers() {
/*  232 */     return this.customArgumentResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
/*  240 */     if (argumentResolvers == null) {
/*  241 */       this.argumentResolvers = null;
/*      */     } else {
/*      */       
/*  244 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
/*  245 */       this.argumentResolvers.addResolvers(argumentResolvers);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public List<HandlerMethodArgumentResolver> getArgumentResolvers() {
/*  255 */     return (this.argumentResolvers != null) ? this.argumentResolvers.getResolvers() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitBinderArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
/*  262 */     if (argumentResolvers == null) {
/*  263 */       this.initBinderArgumentResolvers = null;
/*      */     } else {
/*      */       
/*  266 */       this.initBinderArgumentResolvers = new HandlerMethodArgumentResolverComposite();
/*  267 */       this.initBinderArgumentResolvers.addResolvers(argumentResolvers);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public List<HandlerMethodArgumentResolver> getInitBinderArgumentResolvers() {
/*  277 */     return (this.initBinderArgumentResolvers != null) ? this.initBinderArgumentResolvers.getResolvers() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers) {
/*  286 */     this.customReturnValueHandlers = returnValueHandlers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers() {
/*  294 */     return this.customReturnValueHandlers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers) {
/*  302 */     if (returnValueHandlers == null) {
/*  303 */       this.returnValueHandlers = null;
/*      */     } else {
/*      */       
/*  306 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
/*  307 */       this.returnValueHandlers.addHandlers(returnValueHandlers);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public List<HandlerMethodReturnValueHandler> getReturnValueHandlers() {
/*  317 */     return (this.returnValueHandlers != null) ? this.returnValueHandlers.getHandlers() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setModelAndViewResolvers(@Nullable List<ModelAndViewResolver> modelAndViewResolvers) {
/*  335 */     this.modelAndViewResolvers = modelAndViewResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public List<ModelAndViewResolver> getModelAndViewResolvers() {
/*  343 */     return this.modelAndViewResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager) {
/*  351 */     this.contentNegotiationManager = contentNegotiationManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters) {
/*  360 */     this.messageConverters.clear();
/*  361 */     this.messageConverters.addAll(messageConverters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<HttpMessageConverter<?>> getMessageConverters() {
/*  368 */     return this.messageConverters;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestBodyAdvice(@Nullable List<RequestBodyAdvice> requestBodyAdvice) {
/*  377 */     if (requestBodyAdvice != null) {
/*  378 */       this.requestResponseBodyAdvice.addAll(requestBodyAdvice);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResponseBodyAdvice(@Nullable List<ResponseBodyAdvice<?>> responseBodyAdvice) {
/*  388 */     if (responseBodyAdvice != null) {
/*  389 */       this.requestResponseBodyAdvice.addAll(responseBodyAdvice);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWebBindingInitializer(@Nullable WebBindingInitializer webBindingInitializer) {
/*  398 */     this.webBindingInitializer = webBindingInitializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public WebBindingInitializer getWebBindingInitializer() {
/*  406 */     return this.webBindingInitializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setErrorResponseInterceptors(List<ErrorResponse.Interceptor> interceptors) {
/*  417 */     this.errorResponseInterceptors.clear();
/*  418 */     this.errorResponseInterceptors.addAll(interceptors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<ErrorResponse.Interceptor> getErrorResponseInterceptors() {
/*  427 */     return this.errorResponseInterceptors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor) {
/*  439 */     this.taskExecutor = taskExecutor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsyncRequestTimeout(long timeout) {
/*  452 */     this.asyncRequestTimeout = Long.valueOf(timeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallableInterceptors(List<CallableProcessingInterceptor> interceptors) {
/*  460 */     this.callableInterceptors = interceptors.<CallableProcessingInterceptor>toArray(new CallableProcessingInterceptor[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDeferredResultInterceptors(List<DeferredResultProcessingInterceptor> interceptors) {
/*  468 */     this.deferredResultInterceptors = interceptors.<DeferredResultProcessingInterceptor>toArray(new DeferredResultProcessingInterceptor[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReactiveAdapterRegistry(ReactiveAdapterRegistry reactiveAdapterRegistry) {
/*  477 */     this.reactiveAdapterRegistry = reactiveAdapterRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReactiveAdapterRegistry getReactiveAdapterRegistry() {
/*  485 */     return this.reactiveAdapterRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.0")
/*      */   public void setIgnoreDefaultModelOnRedirect(boolean ignoreDefaultModelOnRedirect) {
/*  505 */     this.ignoreDefaultModelOnRedirect = ignoreDefaultModelOnRedirect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionAttributeStore(SessionAttributeStore sessionAttributeStore) {
/*  515 */     this.sessionAttributeStore = sessionAttributeStore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheSecondsForSessionAttributeHandlers(int cacheSecondsForSessionAttributeHandlers) {
/*  535 */     this.cacheSecondsForSessionAttributeHandlers = cacheSecondsForSessionAttributeHandlers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSynchronizeOnSession(boolean synchronizeOnSession) {
/*  557 */     this.synchronizeOnSession = synchronizeOnSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer) {
/*  566 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBeanFactory(BeanFactory beanFactory) {
/*  575 */     if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/*  576 */       this.beanFactory = cbf; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected ConfigurableBeanFactory getBeanFactory() {
/*  585 */     return this.beanFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterPropertiesSet() {
/*  592 */     initControllerAdviceCache();
/*  593 */     initMessageConverters();
/*      */     
/*  595 */     if (this.argumentResolvers == null) {
/*  596 */       List<HandlerMethodArgumentResolver> resolvers = getDefaultArgumentResolvers();
/*  597 */       this.argumentResolvers = (new HandlerMethodArgumentResolverComposite()).addResolvers(resolvers);
/*      */     } 
/*  599 */     if (this.initBinderArgumentResolvers == null) {
/*  600 */       List<HandlerMethodArgumentResolver> resolvers = getDefaultInitBinderArgumentResolvers();
/*  601 */       this.initBinderArgumentResolvers = (new HandlerMethodArgumentResolverComposite()).addResolvers(resolvers);
/*      */     } 
/*  603 */     if (this.returnValueHandlers == null) {
/*  604 */       List<HandlerMethodReturnValueHandler> handlers = getDefaultReturnValueHandlers();
/*  605 */       this.returnValueHandlers = (new HandlerMethodReturnValueHandlerComposite()).addHandlers(handlers);
/*      */     } 
/*  607 */     if (BEAN_VALIDATION_PRESENT) {
/*  608 */       List<HandlerMethodArgumentResolver> resolvers = this.argumentResolvers.getResolvers();
/*  609 */       this.methodValidator = HandlerMethodValidator.from(this.webBindingInitializer, this.parameterNameDiscoverer, 
/*      */           
/*  611 */           methodParamPredicate(resolvers, ModelAttributeMethodProcessor.class), 
/*  612 */           methodParamPredicate(resolvers, RequestParamMethodArgumentResolver.class));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void initMessageConverters() {
/*  617 */     if (!this.messageConverters.isEmpty()) {
/*      */       return;
/*      */     }
/*  620 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/*  621 */     this.messageConverters.add(new StringHttpMessageConverter());
/*      */     
/*  623 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*      */   }
/*      */   
/*      */   private void initControllerAdviceCache() {
/*  627 */     if (getApplicationContext() == null) {
/*      */       return;
/*      */     }
/*      */     
/*  631 */     List<ControllerAdviceBean> adviceBeans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
/*      */     
/*  633 */     List<Object> requestResponseBodyAdviceBeans = new ArrayList();
/*      */     
/*  635 */     for (ControllerAdviceBean adviceBean : adviceBeans) {
/*  636 */       Class<?> beanType = adviceBean.getBeanType();
/*  637 */       if (beanType == null) {
/*  638 */         throw new IllegalStateException("Unresolvable type for ControllerAdviceBean: " + String.valueOf(adviceBean));
/*      */       }
/*  640 */       Set<Method> attrMethods = MethodIntrospector.selectMethods(beanType, MODEL_ATTRIBUTE_METHODS);
/*  641 */       if (!attrMethods.isEmpty()) {
/*  642 */         this.modelAttributeAdviceCache.put(adviceBean, attrMethods);
/*      */       }
/*  644 */       Set<Method> binderMethods = MethodIntrospector.selectMethods(beanType, INIT_BINDER_METHODS);
/*  645 */       if (!binderMethods.isEmpty()) {
/*  646 */         this.initBinderAdviceCache.put(adviceBean, binderMethods);
/*      */       }
/*  648 */       if (RequestBodyAdvice.class.isAssignableFrom(beanType) || ResponseBodyAdvice.class.isAssignableFrom(beanType)) {
/*  649 */         requestResponseBodyAdviceBeans.add(adviceBean);
/*      */       }
/*      */     } 
/*      */     
/*  653 */     if (!requestResponseBodyAdviceBeans.isEmpty()) {
/*  654 */       this.requestResponseBodyAdvice.addAll(0, requestResponseBodyAdviceBeans);
/*      */     }
/*      */     
/*  657 */     if (this.logger.isDebugEnabled()) {
/*  658 */       int modelSize = this.modelAttributeAdviceCache.size();
/*  659 */       int binderSize = this.initBinderAdviceCache.size();
/*  660 */       int reqCount = getBodyAdviceCount(RequestBodyAdvice.class);
/*  661 */       int resCount = getBodyAdviceCount(ResponseBodyAdvice.class);
/*  662 */       if (modelSize == 0 && binderSize == 0 && reqCount == 0 && resCount == 0) {
/*  663 */         this.logger.debug("ControllerAdvice beans: none");
/*      */       } else {
/*      */         
/*  666 */         this.logger.debug("ControllerAdvice beans: " + modelSize + " @ModelAttribute, " + binderSize + " @InitBinder, " + reqCount + " RequestBodyAdvice, " + resCount + " ResponseBodyAdvice");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getBodyAdviceCount(Class<?> adviceType) {
/*  675 */     List<Object> advice = this.requestResponseBodyAdvice;
/*  676 */     return RequestBodyAdvice.class.isAssignableFrom(adviceType) ? 
/*  677 */       RequestResponseBodyAdviceChain.<RequestBodyAdvice>getAdviceByType(advice, RequestBodyAdvice.class).size() : 
/*  678 */       RequestResponseBodyAdviceChain.<ResponseBodyAdvice>getAdviceByType(advice, ResponseBodyAdvice.class).size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers() {
/*  686 */     List<HandlerMethodArgumentResolver> resolvers = new ArrayList<>(30);
/*      */ 
/*      */     
/*  689 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), false));
/*  690 */     resolvers.add(new RequestParamMapMethodArgumentResolver());
/*  691 */     resolvers.add(new PathVariableMethodArgumentResolver());
/*  692 */     resolvers.add(new PathVariableMapMethodArgumentResolver());
/*  693 */     resolvers.add(new MatrixVariableMethodArgumentResolver());
/*  694 */     resolvers.add(new MatrixVariableMapMethodArgumentResolver());
/*  695 */     resolvers.add(new ServletModelAttributeMethodProcessor(false));
/*  696 */     resolvers.add(new RequestResponseBodyMethodProcessor(getMessageConverters(), this.requestResponseBodyAdvice));
/*  697 */     resolvers.add(new RequestPartMethodArgumentResolver(getMessageConverters(), this.requestResponseBodyAdvice));
/*  698 */     resolvers.add(new RequestHeaderMethodArgumentResolver(getBeanFactory()));
/*  699 */     resolvers.add(new RequestHeaderMapMethodArgumentResolver());
/*  700 */     resolvers.add(new ServletCookieValueMethodArgumentResolver(getBeanFactory()));
/*  701 */     resolvers.add(new ExpressionValueMethodArgumentResolver(getBeanFactory()));
/*  702 */     resolvers.add(new SessionAttributeMethodArgumentResolver());
/*  703 */     resolvers.add(new RequestAttributeMethodArgumentResolver());
/*      */ 
/*      */     
/*  706 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/*  707 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/*  708 */     resolvers.add(new HttpEntityMethodProcessor(getMessageConverters(), this.requestResponseBodyAdvice));
/*  709 */     resolvers.add(new RedirectAttributesMethodArgumentResolver());
/*  710 */     resolvers.add(new ModelMethodProcessor());
/*  711 */     resolvers.add(new MapMethodProcessor());
/*  712 */     resolvers.add(new ErrorsMethodArgumentResolver());
/*  713 */     resolvers.add(new SessionStatusMethodArgumentResolver());
/*  714 */     resolvers.add(new UriComponentsBuilderMethodArgumentResolver());
/*  715 */     if (KotlinDetector.isKotlinPresent()) {
/*  716 */       resolvers.add(new ContinuationHandlerMethodArgumentResolver());
/*      */     }
/*      */ 
/*      */     
/*  720 */     if (getCustomArgumentResolvers() != null) {
/*  721 */       resolvers.addAll(getCustomArgumentResolvers());
/*      */     }
/*      */ 
/*      */     
/*  725 */     resolvers.add(new PrincipalMethodArgumentResolver());
/*  726 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), true));
/*  727 */     resolvers.add(new ServletModelAttributeMethodProcessor(true));
/*      */     
/*  729 */     return resolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<HandlerMethodArgumentResolver> getDefaultInitBinderArgumentResolvers() {
/*  737 */     List<HandlerMethodArgumentResolver> resolvers = new ArrayList<>(20);
/*      */ 
/*      */     
/*  740 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), false));
/*  741 */     resolvers.add(new RequestParamMapMethodArgumentResolver());
/*  742 */     resolvers.add(new PathVariableMethodArgumentResolver());
/*  743 */     resolvers.add(new PathVariableMapMethodArgumentResolver());
/*  744 */     resolvers.add(new MatrixVariableMethodArgumentResolver());
/*  745 */     resolvers.add(new MatrixVariableMapMethodArgumentResolver());
/*  746 */     resolvers.add(new ExpressionValueMethodArgumentResolver(getBeanFactory()));
/*  747 */     resolvers.add(new SessionAttributeMethodArgumentResolver());
/*  748 */     resolvers.add(new RequestAttributeMethodArgumentResolver());
/*      */ 
/*      */     
/*  751 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/*  752 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/*      */ 
/*      */     
/*  755 */     if (getCustomArgumentResolvers() != null) {
/*  756 */       resolvers.addAll(getCustomArgumentResolvers());
/*      */     }
/*      */ 
/*      */     
/*  760 */     resolvers.add(new PrincipalMethodArgumentResolver());
/*  761 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), true));
/*      */     
/*  763 */     return resolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers() {
/*  771 */     List<HandlerMethodReturnValueHandler> handlers = new ArrayList<>(20);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  776 */     ResponseBodyEmitterReturnValueHandler responseBodyEmitterHandler = new ResponseBodyEmitterReturnValueHandler(getMessageConverters(), this.reactiveAdapterRegistry, (TaskExecutor)this.taskExecutor, this.contentNegotiationManager, initViewResolvers(), initLocaleResolver());
/*      */     
/*  778 */     HttpEntityMethodProcessor httpEntityMethodProcessor = new HttpEntityMethodProcessor(getMessageConverters(), this.contentNegotiationManager, this.requestResponseBodyAdvice, this.errorResponseInterceptors);
/*      */ 
/*      */ 
/*      */     
/*  782 */     handlers.add(new ModelAndViewMethodReturnValueHandler());
/*  783 */     handlers.add(new ModelMethodProcessor());
/*  784 */     handlers.add(new ViewMethodReturnValueHandler());
/*  785 */     handlers.add(responseBodyEmitterHandler);
/*  786 */     handlers.add(new StreamingResponseBodyReturnValueHandler());
/*  787 */     handlers.add(new ResponseEntityReturnValueHandler(httpEntityMethodProcessor, responseBodyEmitterHandler));
/*  788 */     handlers.add(new HttpHeadersReturnValueHandler());
/*  789 */     handlers.add(new CallableMethodReturnValueHandler());
/*  790 */     handlers.add(new DeferredResultMethodReturnValueHandler());
/*  791 */     handlers.add(new AsyncTaskMethodReturnValueHandler((BeanFactory)this.beanFactory));
/*      */ 
/*      */     
/*  794 */     handlers.add(new ServletModelAttributeMethodProcessor(false));
/*  795 */     handlers.add(new RequestResponseBodyMethodProcessor(getMessageConverters(), this.contentNegotiationManager, this.requestResponseBodyAdvice, this.errorResponseInterceptors));
/*      */ 
/*      */ 
/*      */     
/*  799 */     handlers.add(new ViewNameMethodReturnValueHandler());
/*  800 */     handlers.add(new MapMethodProcessor());
/*      */ 
/*      */     
/*  803 */     if (getCustomReturnValueHandlers() != null) {
/*  804 */       handlers.addAll(getCustomReturnValueHandlers());
/*      */     }
/*      */ 
/*      */     
/*  808 */     if (!CollectionUtils.isEmpty(getModelAndViewResolvers())) {
/*  809 */       handlers.add(new ModelAndViewResolverMethodReturnValueHandler(getModelAndViewResolvers()));
/*      */     } else {
/*      */       
/*  812 */       handlers.add(new ServletModelAttributeMethodProcessor(true));
/*      */     } 
/*      */     
/*  815 */     return handlers;
/*      */   }
/*      */   
/*      */   private List<ViewResolver> initViewResolvers() {
/*  819 */     ConfigurableBeanFactory configurableBeanFactory = getBeanFactory(); if (configurableBeanFactory instanceof ListableBeanFactory) { ListableBeanFactory lbf = (ListableBeanFactory)configurableBeanFactory;
/*      */       
/*  821 */       Map<String, ViewResolver> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(lbf, ViewResolver.class, true, false);
/*  822 */       if (!matchingBeans.isEmpty()) {
/*  823 */         List<ViewResolver> viewResolvers = new ArrayList<>(matchingBeans.values());
/*  824 */         AnnotationAwareOrderComparator.sort(viewResolvers);
/*  825 */         return viewResolvers;
/*      */       }  }
/*      */     
/*  828 */     return Collections.emptyList();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private LocaleResolver initLocaleResolver() {
/*  833 */     if (getBeanFactory() != null) {
/*      */       try {
/*  835 */         return (LocaleResolver)getBeanFactory().getBean("localeResolver", LocaleResolver.class);
/*      */       
/*      */       }
/*  838 */       catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*      */     }
/*      */ 
/*      */     
/*  842 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Predicate<MethodParameter> methodParamPredicate(List<HandlerMethodArgumentResolver> resolvers, Class<?> resolverType) {
/*  848 */     return parameter -> {
/*      */         for (HandlerMethodArgumentResolver resolver : resolvers) {
/*      */           if (resolver.supportsParameter(parameter)) {
/*      */             return resolverType.isInstance(resolver);
/*      */           }
/*      */         } 
/*      */         return false;
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean supportsInternal(HandlerMethod handlerMethod) {
/*  869 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected ModelAndView handleInternal(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod) throws Exception {
/*      */     ModelAndView mav;
/*  878 */     checkRequest(request);
/*      */ 
/*      */     
/*  881 */     if (this.synchronizeOnSession) {
/*  882 */       HttpSession session = request.getSession(false);
/*  883 */       if (session != null) {
/*  884 */         Object mutex = WebUtils.getSessionMutex(session);
/*  885 */         synchronized (mutex) {
/*  886 */           mav = invokeHandlerMethod(request, response, handlerMethod);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  891 */         mav = invokeHandlerMethod(request, response, handlerMethod);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  896 */       mav = invokeHandlerMethod(request, response, handlerMethod);
/*      */     } 
/*      */     
/*  899 */     if (!response.containsHeader("Cache-Control")) {
/*  900 */       if (getSessionAttributesHandler(handlerMethod).hasSessionAttributes()) {
/*  901 */         applyCacheSeconds(response, this.cacheSecondsForSessionAttributeHandlers);
/*      */       } else {
/*      */         
/*  904 */         prepareResponse(response);
/*      */       } 
/*      */     }
/*      */     
/*  908 */     return mav;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long getLastModifiedInternal(HttpServletRequest request, HandlerMethod handlerMethod) {
/*  919 */     return -1L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SessionAttributesHandler getSessionAttributesHandler(HandlerMethod handlerMethod) {
/*  928 */     return this.sessionAttributesHandlerCache.computeIfAbsent(handlerMethod
/*  929 */         .getBeanType(), type -> new SessionAttributesHandler(type, this.sessionAttributeStore));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected ModelAndView invokeHandlerMethod(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod) throws Exception {
/*  944 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager((ServletRequest)request);
/*  945 */     AsyncWebRequest asyncWebRequest = WebAsyncUtils.createAsyncWebRequest(request, response);
/*  946 */     asyncWebRequest.setTimeout(this.asyncRequestTimeout);
/*      */     
/*  948 */     asyncManager.setTaskExecutor(this.taskExecutor);
/*  949 */     asyncManager.setAsyncWebRequest(asyncWebRequest);
/*  950 */     asyncManager.registerCallableInterceptors(this.callableInterceptors);
/*  951 */     asyncManager.registerDeferredResultInterceptors(this.deferredResultInterceptors);
/*      */ 
/*      */     
/*  954 */     response = (HttpServletResponse)asyncWebRequest.getNativeResponse(HttpServletResponse.class);
/*      */ 
/*      */     
/*  957 */     ServletWebRequest webRequest = (asyncWebRequest instanceof ServletWebRequest) ? (ServletWebRequest)asyncWebRequest : new ServletWebRequest(request, response);
/*      */     
/*  959 */     WebDataBinderFactory binderFactory = getDataBinderFactory(handlerMethod);
/*  960 */     ModelFactory modelFactory = getModelFactory(handlerMethod, binderFactory);
/*      */     
/*  962 */     ServletInvocableHandlerMethod invocableMethod = createInvocableHandlerMethod(handlerMethod);
/*  963 */     if (this.argumentResolvers != null) {
/*  964 */       invocableMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/*      */     }
/*  966 */     if (this.returnValueHandlers != null) {
/*  967 */       invocableMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
/*      */     }
/*  969 */     invocableMethod.setDataBinderFactory(binderFactory);
/*  970 */     invocableMethod.setParameterNameDiscoverer(this.parameterNameDiscoverer);
/*  971 */     invocableMethod.setMethodValidator(this.methodValidator);
/*      */     
/*  973 */     ModelAndViewContainer mavContainer = new ModelAndViewContainer();
/*  974 */     mavContainer.addAllAttributes(RequestContextUtils.getInputFlashMap(request));
/*  975 */     modelFactory.initModel((NativeWebRequest)webRequest, mavContainer, (HandlerMethod)invocableMethod);
/*  976 */     mavContainer.setIgnoreDefaultModelOnRedirect(this.ignoreDefaultModelOnRedirect);
/*      */     
/*  978 */     if (asyncManager.hasConcurrentResult()) {
/*  979 */       Object result = asyncManager.getConcurrentResult();
/*  980 */       Object[] resultContext = asyncManager.getConcurrentResultContext();
/*  981 */       Assert.state((resultContext != null && resultContext.length > 0), "Missing result context");
/*  982 */       mavContainer = (ModelAndViewContainer)resultContext[0];
/*  983 */       asyncManager.clearConcurrentResult();
/*  984 */       LogFormatUtils.traceDebug(this.logger, traceOn -> {
/*      */             String formatted = LogFormatUtils.formatValue(result, !traceOn.booleanValue());
/*      */             return "Resume with async result [" + formatted + "]";
/*      */           });
/*  988 */       invocableMethod = invocableMethod.wrapConcurrentResult(result);
/*      */     } 
/*      */     
/*  991 */     invocableMethod.invokeAndHandle(webRequest, mavContainer, new Object[0]);
/*  992 */     if (asyncManager.isConcurrentHandlingStarted()) {
/*  993 */       return null;
/*      */     }
/*      */     
/*  996 */     return getModelAndView(mavContainer, modelFactory, (NativeWebRequest)webRequest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ServletInvocableHandlerMethod createInvocableHandlerMethod(HandlerMethod handlerMethod) {
/* 1006 */     return new ServletInvocableHandlerMethod(handlerMethod);
/*      */   }
/*      */   
/*      */   private ModelFactory getModelFactory(HandlerMethod handlerMethod, WebDataBinderFactory binderFactory) {
/* 1010 */     SessionAttributesHandler sessionAttrHandler = getSessionAttributesHandler(handlerMethod);
/* 1011 */     Class<?> handlerType = handlerMethod.getBeanType();
/* 1012 */     Set<Method> methods = this.modelAttributeCache.get(handlerType);
/* 1013 */     if (methods == null) {
/* 1014 */       methods = MethodIntrospector.selectMethods(handlerType, MODEL_ATTRIBUTE_METHODS);
/* 1015 */       this.modelAttributeCache.put(handlerType, methods);
/*      */     } 
/* 1017 */     List<InvocableHandlerMethod> attrMethods = new ArrayList<>();
/*      */     
/* 1019 */     this.modelAttributeAdviceCache.forEach((controllerAdviceBean, methodSet) -> {
/*      */           if (controllerAdviceBean.isApplicableToBeanType(handlerType)) {
/*      */             Object bean = controllerAdviceBean.resolveBean();
/*      */             for (Method method : methodSet) {
/*      */               attrMethods.add(createModelAttributeMethod(binderFactory, bean, method));
/*      */             }
/*      */           } 
/*      */         });
/* 1027 */     for (Method method : methods) {
/* 1028 */       Object bean = handlerMethod.getBean();
/* 1029 */       attrMethods.add(createModelAttributeMethod(binderFactory, bean, method));
/*      */     } 
/* 1031 */     return new ModelFactory(attrMethods, binderFactory, sessionAttrHandler);
/*      */   }
/*      */   
/*      */   private InvocableHandlerMethod createModelAttributeMethod(WebDataBinderFactory factory, Object bean, Method method) {
/* 1035 */     InvocableHandlerMethod attrMethod = new InvocableHandlerMethod(bean, method);
/* 1036 */     if (this.argumentResolvers != null) {
/* 1037 */       attrMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/*      */     }
/* 1039 */     attrMethod.setParameterNameDiscoverer(this.parameterNameDiscoverer);
/* 1040 */     attrMethod.setDataBinderFactory(factory);
/* 1041 */     return attrMethod;
/*      */   }
/*      */   
/*      */   private WebDataBinderFactory getDataBinderFactory(HandlerMethod handlerMethod) throws Exception {
/* 1045 */     Class<?> handlerType = handlerMethod.getBeanType();
/* 1046 */     Set<Method> methods = this.initBinderCache.get(handlerType);
/* 1047 */     if (methods == null) {
/* 1048 */       methods = MethodIntrospector.selectMethods(handlerType, INIT_BINDER_METHODS);
/* 1049 */       this.initBinderCache.put(handlerType, methods);
/*      */     } 
/* 1051 */     List<InvocableHandlerMethod> initBinderMethods = new ArrayList<>();
/*      */     
/* 1053 */     this.initBinderAdviceCache.forEach((controllerAdviceBean, methodSet) -> {
/*      */           if (controllerAdviceBean.isApplicableToBeanType(handlerType)) {
/*      */             Object bean = controllerAdviceBean.resolveBean();
/*      */             for (Method method : methodSet) {
/*      */               initBinderMethods.add(createInitBinderMethod(bean, method));
/*      */             }
/*      */           } 
/*      */         });
/* 1061 */     for (Method method : methods) {
/* 1062 */       Object bean = handlerMethod.getBean();
/* 1063 */       initBinderMethods.add(createInitBinderMethod(bean, method));
/*      */     } 
/* 1065 */     InitBinderDataBinderFactory initBinderDataBinderFactory = createDataBinderFactory(initBinderMethods);
/* 1066 */     initBinderDataBinderFactory.setMethodValidationApplicable((this.methodValidator != null && handlerMethod.shouldValidateArguments()));
/* 1067 */     return (WebDataBinderFactory)initBinderDataBinderFactory;
/*      */   }
/*      */   
/*      */   private InvocableHandlerMethod createInitBinderMethod(Object bean, Method method) {
/* 1071 */     InvocableHandlerMethod binderMethod = new InvocableHandlerMethod(bean, method);
/* 1072 */     if (this.initBinderArgumentResolvers != null) {
/* 1073 */       binderMethod.setHandlerMethodArgumentResolvers(this.initBinderArgumentResolvers);
/*      */     }
/* 1075 */     binderMethod.setDataBinderFactory((WebDataBinderFactory)new DefaultDataBinderFactory(this.webBindingInitializer));
/* 1076 */     binderMethod.setParameterNameDiscoverer(this.parameterNameDiscoverer);
/* 1077 */     return binderMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InitBinderDataBinderFactory createDataBinderFactory(List<InvocableHandlerMethod> binderMethods) throws Exception {
/* 1091 */     return new ServletRequestDataBinderFactory(binderMethods, getWebBindingInitializer());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private ModelAndView getModelAndView(ModelAndViewContainer mavContainer, ModelFactory modelFactory, NativeWebRequest webRequest) throws Exception {
/* 1098 */     modelFactory.updateModel(webRequest, mavContainer);
/* 1099 */     if (mavContainer.isRequestHandled()) {
/* 1100 */       return null;
/*      */     }
/* 1102 */     ModelMap model = mavContainer.getModel();
/* 1103 */     ModelAndView mav = new ModelAndView(mavContainer.getViewName(), (Map)model, mavContainer.getStatus());
/* 1104 */     if (!mavContainer.isViewReference()) {
/* 1105 */       mav.setView((View)mavContainer.getView());
/*      */     }
/* 1107 */     if (model instanceof RedirectAttributes) { RedirectAttributes redirectAttributes = (RedirectAttributes)model;
/* 1108 */       Map<String, ?> flashAttributes = redirectAttributes.getFlashAttributes();
/* 1109 */       HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 1110 */       if (request != null) {
/* 1111 */         RequestContextUtils.getOutputFlashMap(request).putAll(flashAttributes);
/*      */       } }
/*      */     
/* 1114 */     return mav;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class MvcSimpleAsyncTaskExecutor
/*      */     extends SimpleAsyncTaskExecutor
/*      */   {
/*      */     private static boolean taskExecutorWarning = true;
/*      */ 
/*      */ 
/*      */     
/*      */     MvcSimpleAsyncTaskExecutor() {
/* 1127 */       super("MvcAsync");
/*      */     }
/*      */ 
/*      */     
/*      */     public void execute(Runnable task) {
/* 1132 */       if (taskExecutorWarning && RequestMappingHandlerAdapter.this.logger.isWarnEnabled()) {
/* 1133 */         synchronized (this) {
/* 1134 */           if (taskExecutorWarning) {
/* 1135 */             RequestMappingHandlerAdapter.this.logger.warn("!!!\nPerforming asynchronous handling through the default Spring MVC SimpleAsyncTaskExecutor.\nThis executor is not suitable for production use under load.\nPlease, configure an AsyncTaskExecutor through the WebMvc config.\n-------------------------------\n!!!");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1142 */             taskExecutorWarning = false;
/*      */           } 
/*      */         } 
/*      */       }
/* 1146 */       super.execute(task);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestMappingHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */