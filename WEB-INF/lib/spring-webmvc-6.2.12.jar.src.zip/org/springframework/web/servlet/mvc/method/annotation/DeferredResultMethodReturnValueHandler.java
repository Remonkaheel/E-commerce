/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.concurrent.CompletionStage;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredResultMethodReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   public boolean supportsReturnType(MethodParameter returnType) {
/*  43 */     Class<?> type = returnType.getParameterType();
/*  44 */     return (DeferredResult.class.isAssignableFrom(type) || ListenableFuture.class
/*  45 */       .isAssignableFrom(type) || CompletionStage.class
/*  46 */       .isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
/*     */     DeferredResult<?> result;
/*  54 */     if (returnValue == null) {
/*  55 */       mavContainer.setRequestHandled(true);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  61 */     if (returnValue instanceof DeferredResult) { DeferredResult<?> deferredResult = (DeferredResult)returnValue;
/*  62 */       result = deferredResult; }
/*     */     
/*  64 */     else if (returnValue instanceof ListenableFuture) { ListenableFuture<?> listenableFuture = (ListenableFuture)returnValue;
/*  65 */       result = adaptListenableFuture(listenableFuture); }
/*     */     
/*  67 */     else if (returnValue instanceof CompletionStage) { CompletionStage<?> completionStage = (CompletionStage)returnValue;
/*  68 */       result = adaptCompletionStage(completionStage); }
/*     */     
/*     */     else
/*     */     
/*  72 */     { throw new IllegalStateException("Unexpected return value type: " + String.valueOf(returnValue)); }
/*     */ 
/*     */     
/*  75 */     WebAsyncUtils.getAsyncManager((WebRequest)webRequest).startDeferredResultProcessing(result, new Object[] { mavContainer });
/*     */   }
/*     */ 
/*     */   
/*     */   private DeferredResult<Object> adaptListenableFuture(ListenableFuture<?> future) {
/*  80 */     final DeferredResult<Object> result = new DeferredResult();
/*  81 */     future.addCallback(new ListenableFutureCallback<Object>()
/*     */         {
/*     */           public void onSuccess(@Nullable Object value) {
/*  84 */             result.setResult(value);
/*     */           }
/*     */           
/*     */           public void onFailure(Throwable ex) {
/*  88 */             result.setErrorResult(ex);
/*     */           }
/*     */         });
/*  91 */     return result;
/*     */   }
/*     */   
/*     */   private DeferredResult<Object> adaptCompletionStage(CompletionStage<?> future) {
/*  95 */     DeferredResult<Object> result = new DeferredResult();
/*  96 */     future.whenComplete((value, ex) -> {
/*     */           if (ex != null) {
/*     */             if (ex instanceof java.util.concurrent.CompletionException && ex.getCause() != null) {
/*     */               ex = ex.getCause();
/*     */             }
/*     */             
/*     */             result.setErrorResult(ex);
/*     */           } else {
/*     */             result.setResult(value);
/*     */           } 
/*     */         });
/* 107 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\DeferredResultMethodReturnValueHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */