/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import io.micrometer.context.ContextSnapshot;
/*     */ import io.micrometer.context.ContextSnapshotFactory;
/*     */ import java.io.IOException;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.task.SyncTaskExecutor;
/*     */ import org.springframework.core.task.TaskDecorator;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.core.task.support.ContextPropagatingTaskDecorator;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.codec.ServerSentEvent;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactiveTypeHandler
/*     */ {
/*     */   private static final long STREAMING_TIMEOUT_VALUE = -1L;
/*  82 */   private static final MediaType WILDCARD_SUBTYPE_SUFFIXED_BY_NDJSON = MediaType.valueOf("application/*+x-ndjson");
/*     */   
/*  84 */   private static final boolean isContextPropagationPresent = ClassUtils.isPresent("io.micrometer.context.ContextSnapshot", ReactiveTypeHandler.class
/*  85 */       .getClassLoader());
/*     */   
/*  87 */   private static final Log logger = LogFactory.getLog(ReactiveTypeHandler.class);
/*     */ 
/*     */   
/*     */   private final ReactiveAdapterRegistry adapterRegistry;
/*     */   
/*     */   private final TaskExecutor taskExecutor;
/*     */   
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */   
/*     */   @Nullable
/*     */   private final Object contextSnapshotHelper;
/*     */ 
/*     */   
/*     */   public ReactiveTypeHandler() {
/* 101 */     this(ReactiveAdapterRegistry.getSharedInstance(), (TaskExecutor)new SyncTaskExecutor(), new ContentNegotiationManager(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReactiveTypeHandler(ReactiveAdapterRegistry registry, TaskExecutor executor, ContentNegotiationManager manager, @Nullable Object contextSnapshotFactory) {
/* 108 */     Assert.notNull(registry, "ReactiveAdapterRegistry is required");
/* 109 */     Assert.notNull(executor, "TaskExecutor is required");
/* 110 */     Assert.notNull(manager, "ContentNegotiationManager is required");
/* 111 */     this.adapterRegistry = registry;
/* 112 */     this.taskExecutor = executor;
/* 113 */     this.contentNegotiationManager = manager;
/* 114 */     this.contextSnapshotHelper = initContextSnapshotHelper(contextSnapshotFactory);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static Object initContextSnapshotHelper(@Nullable Object snapshotFactory) {
/* 119 */     if (isContextPropagationPresent) {
/* 120 */       return new ContextSnapshotHelper((ContextSnapshotFactory)snapshotFactory);
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReactiveType(Class<?> type) {
/* 130 */     return (this.adapterRegistry.getAdapter(type) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResponseBodyEmitter handleValue(Object returnValue, MethodParameter returnType, @Nullable MediaType presetContentType, ModelAndViewContainer mav, NativeWebRequest request) throws Exception {
/* 145 */     Assert.notNull(returnValue, "Expected return value");
/* 146 */     Class<?> clazz = returnValue.getClass();
/* 147 */     ReactiveAdapter adapter = this.adapterRegistry.getAdapter(clazz);
/* 148 */     Assert.state((adapter != null), () -> "Unexpected return value type: " + String.valueOf(clazz));
/*     */     
/* 150 */     TaskDecorator taskDecorator = null;
/* 151 */     if (isContextPropagationPresent) {
/* 152 */       ContextSnapshotHelper helper = (ContextSnapshotHelper)this.contextSnapshotHelper;
/* 153 */       Assert.notNull(helper, "No ContextSnapshotHelper");
/* 154 */       returnValue = helper.writeReactorContext(returnValue);
/* 155 */       taskDecorator = helper.getTaskDecorator();
/*     */     } 
/*     */     
/* 158 */     ResolvableType elementType = ResolvableType.forMethodParameter(returnType).getGeneric(new int[0]);
/* 159 */     Class<?> elementClass = elementType.toClass();
/*     */     
/* 161 */     Collection<MediaType> mediaTypes = getMediaTypes(request, presetContentType);
/* 162 */     Optional<MediaType> mediaType = mediaTypes.stream().filter(MimeType::isConcrete).findFirst();
/*     */     
/* 164 */     if (adapter.isMultiValue()) {
/* 165 */       Objects.requireNonNull(MediaType.TEXT_EVENT_STREAM); if (mediaTypes.stream().anyMatch(MediaType.TEXT_EVENT_STREAM::includes) || ServerSentEvent.class
/* 166 */         .isAssignableFrom(elementClass)) {
/* 167 */         SseEmitter emitter = new SseEmitter(Long.valueOf(-1L));
/* 168 */         (new SseEmitterSubscriber(emitter, this.taskExecutor, taskDecorator)).connect(adapter, returnValue);
/* 169 */         return emitter;
/*     */       } 
/* 171 */       if (CharSequence.class.isAssignableFrom(elementClass)) {
/* 172 */         ResponseBodyEmitter emitter = getEmitter(mediaType.orElse(MediaType.TEXT_PLAIN));
/* 173 */         (new TextEmitterSubscriber(emitter, this.taskExecutor)).connect(adapter, returnValue);
/* 174 */         return emitter;
/*     */       } 
/* 176 */       MediaType streamingResponseType = findConcreteJsonStreamMediaType(mediaTypes);
/* 177 */       if (streamingResponseType != null) {
/* 178 */         ResponseBodyEmitter emitter = getEmitter(streamingResponseType);
/* 179 */         (new JsonEmitterSubscriber(emitter, this.taskExecutor)).connect(adapter, returnValue);
/* 180 */         return emitter;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 185 */     DeferredResult<Object> result = new DeferredResult();
/* 186 */     (new DeferredResultSubscriber(result, adapter, elementType)).connect(adapter, returnValue);
/* 187 */     WebAsyncUtils.getAsyncManager((WebRequest)request).startDeferredResultProcessing(result, new Object[] { mav });
/*     */     
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static MediaType findConcreteJsonStreamMediaType(Collection<MediaType> acceptedMediaTypes) {
/* 208 */     for (MediaType acceptedType : acceptedMediaTypes) {
/* 209 */       if (WILDCARD_SUBTYPE_SUFFIXED_BY_NDJSON.includes(acceptedType)) {
/* 210 */         if (acceptedType.isConcrete()) {
/* 211 */           return acceptedType;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 218 */         return MediaType.APPLICATION_NDJSON;
/*     */       } 
/*     */       
/* 221 */       if (MediaType.APPLICATION_NDJSON.includes(acceptedType)) {
/* 222 */         return MediaType.APPLICATION_NDJSON;
/*     */       }
/* 224 */       if (MediaType.APPLICATION_STREAM_JSON.includes(acceptedType)) {
/* 225 */         return MediaType.APPLICATION_STREAM_JSON;
/*     */       }
/*     */     } 
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<MediaType> getMediaTypes(NativeWebRequest request, @Nullable MediaType contentType) throws HttpMediaTypeNotAcceptableException {
/* 235 */     Collection<MediaType> producibleMediaTypes = (Collection<MediaType>)request.getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, 0);
/*     */ 
/*     */ 
/*     */     
/* 239 */     Collection<MediaType> mediaTypes = CollectionUtils.isEmpty(producibleMediaTypes) ? this.contentNegotiationManager.resolveMediaTypes(request) : producibleMediaTypes;
/*     */     
/* 241 */     if (contentType != null) {
/* 242 */       for (MediaType mediaType : mediaTypes) {
/* 243 */         if (mediaType.isConcrete()) {
/* 244 */           return mediaTypes;
/*     */         }
/*     */       } 
/* 247 */       return List.of(contentType);
/*     */     } 
/*     */     
/* 250 */     return mediaTypes;
/*     */   }
/*     */   
/*     */   private ResponseBodyEmitter getEmitter(final MediaType mediaType) {
/* 254 */     return new ResponseBodyEmitter(Long.valueOf(-1L))
/*     */       {
/*     */         protected void extendResponse(ServerHttpResponse outputMessage) {
/* 257 */           outputMessage.getHeaders().setContentType(mediaType);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private static abstract class AbstractEmitterSubscriber
/*     */     implements Subscriber<Object>, Runnable
/*     */   {
/*     */     private final ResponseBodyEmitter emitter;
/*     */     
/*     */     private final TaskExecutor taskExecutor;
/*     */     
/*     */     @Nullable
/*     */     private Subscription subscription;
/* 272 */     private final AtomicReference<Object> elementRef = new AtomicReference();
/*     */     
/*     */     @Nullable
/*     */     private Throwable error;
/*     */     
/*     */     private volatile boolean terminated;
/*     */     
/* 279 */     private final AtomicLong executing = new AtomicLong();
/*     */ 
/*     */     
/*     */     private volatile boolean done;
/*     */     
/*     */     private final Runnable sendTask;
/*     */ 
/*     */     
/*     */     protected AbstractEmitterSubscriber(ResponseBodyEmitter emitter, TaskExecutor executor, @Nullable TaskDecorator taskDecorator) {
/* 288 */       this.emitter = emitter;
/* 289 */       this.taskExecutor = executor;
/* 290 */       this.sendTask = (taskDecorator != null) ? taskDecorator.decorate(this) : this;
/*     */     }
/*     */     
/*     */     public void connect(ReactiveAdapter adapter, Object returnValue) {
/* 294 */       Publisher<Object> publisher = adapter.toPublisher(returnValue);
/* 295 */       publisher.subscribe(this);
/*     */     }
/*     */     
/*     */     protected ResponseBodyEmitter getEmitter() {
/* 299 */       return this.emitter;
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onSubscribe(Subscription subscription) {
/* 304 */       this.subscription = subscription;
/* 305 */       this.emitter.onTimeout(() -> {
/*     */             if (ReactiveTypeHandler.logger.isTraceEnabled()) {
/*     */               ReactiveTypeHandler.logger.trace("Connection timeout for " + String.valueOf(this.emitter));
/*     */             }
/*     */             terminate();
/*     */             this.emitter.complete();
/*     */           });
/* 312 */       Objects.requireNonNull(this.emitter); this.emitter.onError(this.emitter::completeWithError);
/* 313 */       subscription.request(1L);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onNext(Object element) {
/* 318 */       this.elementRef.lazySet(element);
/* 319 */       trySchedule();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onError(Throwable ex) {
/* 324 */       this.error = ex;
/* 325 */       this.terminated = true;
/* 326 */       trySchedule();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onComplete() {
/* 331 */       this.terminated = true;
/* 332 */       trySchedule();
/*     */     }
/*     */     
/*     */     private void trySchedule() {
/* 336 */       if (this.executing.getAndIncrement() == 0L) {
/* 337 */         schedule();
/*     */       }
/*     */     }
/*     */     
/*     */     private void schedule() {
/*     */       try {
/* 343 */         this.taskExecutor.execute(this.sendTask);
/*     */       }
/* 345 */       catch (Throwable ex) {
/*     */         try {
/* 347 */           terminate();
/*     */         } finally {
/*     */           
/* 350 */           this.executing.decrementAndGet();
/* 351 */           this.elementRef.lazySet(null);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 358 */       if (this.done) {
/* 359 */         this.elementRef.lazySet(null);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 364 */       boolean isTerminated = this.terminated;
/*     */       
/* 366 */       Object element = this.elementRef.get();
/* 367 */       if (element != null) {
/* 368 */         this.elementRef.lazySet(null);
/* 369 */         Assert.state((this.subscription != null), "No subscription");
/*     */         try {
/* 371 */           send(element);
/* 372 */           this.subscription.request(1L);
/*     */         }
/* 374 */         catch (Throwable ex) {
/* 375 */           if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 376 */             ReactiveTypeHandler.logger.debug("Send for " + String.valueOf(this.emitter) + " failed: " + String.valueOf(ex));
/*     */           }
/* 378 */           terminate();
/*     */           try {
/* 380 */             this.emitter.completeWithError(ex);
/*     */           }
/* 382 */           catch (Exception ex2) {
/* 383 */             if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 384 */               ReactiveTypeHandler.logger.debug("Failure from emitter completeWithError: " + String.valueOf(ex2));
/*     */             }
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 391 */       if (isTerminated) {
/* 392 */         this.done = true;
/* 393 */         Throwable ex = this.error;
/* 394 */         this.error = null;
/* 395 */         if (ex != null) {
/* 396 */           if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 397 */             ReactiveTypeHandler.logger.debug("Publisher for " + String.valueOf(this.emitter) + " failed: " + String.valueOf(ex));
/*     */           }
/*     */           try {
/* 400 */             this.emitter.completeWithError(ex);
/*     */           }
/* 402 */           catch (Exception ex2) {
/* 403 */             if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 404 */               ReactiveTypeHandler.logger.debug("Failure from emitter completeWithError: " + String.valueOf(ex2));
/*     */             }
/*     */           } 
/*     */         } else {
/*     */           
/* 409 */           if (ReactiveTypeHandler.logger.isTraceEnabled()) {
/* 410 */             ReactiveTypeHandler.logger.trace("Publisher for " + String.valueOf(this.emitter) + " completed");
/*     */           }
/*     */           try {
/* 413 */             this.emitter.complete();
/*     */           }
/* 415 */           catch (Exception ex2) {
/* 416 */             if (ReactiveTypeHandler.logger.isDebugEnabled()) {
/* 417 */               ReactiveTypeHandler.logger.debug("Failure from emitter complete: " + String.valueOf(ex2));
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 424 */       if (this.executing.decrementAndGet() != 0L) {
/* 425 */         schedule();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void terminate() {
/* 432 */       this.done = true;
/* 433 */       if (this.subscription != null)
/* 434 */         this.subscription.cancel(); 
/*     */     }
/*     */     
/*     */     protected abstract void send(Object param1Object) throws IOException;
/*     */   }
/*     */   
/*     */   private static class SseEmitterSubscriber
/*     */     extends AbstractEmitterSubscriber {
/*     */     SseEmitterSubscriber(SseEmitter sseEmitter, TaskExecutor executor, @Nullable TaskDecorator taskDecorator) {
/* 443 */       super(sseEmitter, executor, taskDecorator);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void send(Object element) throws IOException {
/* 448 */       if (element instanceof ServerSentEvent) { ServerSentEvent<?> event = (ServerSentEvent)element;
/* 449 */         ((SseEmitter)getEmitter()).send(adapt(event)); }
/*     */       else
/*     */       
/* 452 */       { getEmitter().send(element, MediaType.APPLICATION_JSON); }
/*     */     
/*     */     }
/*     */     
/*     */     private SseEmitter.SseEventBuilder adapt(ServerSentEvent<?> sse) {
/* 457 */       SseEmitter.SseEventBuilder builder = SseEmitter.event();
/* 458 */       String id = sse.id();
/* 459 */       String event = sse.event();
/* 460 */       Duration retry = sse.retry();
/* 461 */       String comment = sse.comment();
/* 462 */       Object data = sse.data();
/* 463 */       if (id != null) {
/* 464 */         builder.id(id);
/*     */       }
/* 466 */       if (event != null) {
/* 467 */         builder.name(event);
/*     */       }
/* 469 */       if (data != null) {
/* 470 */         builder.data(data);
/*     */       }
/* 472 */       if (retry != null) {
/* 473 */         builder.reconnectTime(retry.toMillis());
/*     */       }
/* 475 */       if (comment != null) {
/* 476 */         builder.comment(comment);
/*     */       }
/* 478 */       return builder;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class JsonEmitterSubscriber
/*     */     extends AbstractEmitterSubscriber
/*     */   {
/*     */     JsonEmitterSubscriber(ResponseBodyEmitter emitter, TaskExecutor executor) {
/* 488 */       super(emitter, executor, null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void send(Object element) throws IOException {
/* 493 */       getEmitter().send(element, MediaType.APPLICATION_JSON);
/* 494 */       getEmitter().send("\n", MediaType.TEXT_PLAIN);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TextEmitterSubscriber
/*     */     extends AbstractEmitterSubscriber
/*     */   {
/*     */     TextEmitterSubscriber(ResponseBodyEmitter emitter, TaskExecutor executor) {
/* 502 */       super(emitter, executor, null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void send(Object element) throws IOException {
/* 507 */       getEmitter().send(element, MediaType.TEXT_PLAIN);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DeferredResultSubscriber
/*     */     implements Subscriber<Object>
/*     */   {
/*     */     private final DeferredResult<Object> result;
/*     */     
/*     */     private final boolean multiValueSource;
/*     */     private final ReactiveTypeHandler.CollectedValuesList values;
/*     */     
/*     */     DeferredResultSubscriber(DeferredResult<Object> result, ReactiveAdapter adapter, ResolvableType elementType) {
/* 521 */       this.result = result;
/* 522 */       this.multiValueSource = adapter.isMultiValue();
/* 523 */       this.values = new ReactiveTypeHandler.CollectedValuesList(elementType);
/*     */     }
/*     */     
/*     */     public void connect(ReactiveAdapter adapter, Object returnValue) {
/* 527 */       Publisher<Object> publisher = adapter.toPublisher(returnValue);
/* 528 */       publisher.subscribe(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/* 533 */       Objects.requireNonNull(subscription); this.result.onTimeout(subscription::cancel);
/* 534 */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object element) {
/* 539 */       this.values.add(element);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable ex) {
/* 544 */       this.result.setErrorResult(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 549 */       if (this.values.size() > 1 || this.multiValueSource) {
/* 550 */         this.result.setResult(this.values);
/*     */       }
/* 552 */       else if (this.values.size() == 1) {
/* 553 */         this.result.setResult(this.values.get(0));
/*     */       } else {
/*     */         
/* 556 */         this.result.setResult(null);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CollectedValuesList
/*     */     extends ArrayList<Object>
/*     */   {
/*     */     private final ResolvableType elementType;
/*     */ 
/*     */ 
/*     */     
/*     */     CollectedValuesList(ResolvableType elementType) {
/* 571 */       this.elementType = elementType;
/*     */     }
/*     */     
/*     */     public ResolvableType getReturnType() {
/* 575 */       return ResolvableType.forClassWithGenerics(List.class, new ResolvableType[] { this.elementType });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ContextSnapshotHelper
/*     */   {
/*     */     private final ContextSnapshotFactory snapshotFactory;
/*     */     
/*     */     private ContextSnapshotHelper(@Nullable ContextSnapshotFactory factory) {
/* 585 */       this.snapshotFactory = (factory != null) ? factory : ContextSnapshotFactory.builder().build();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object writeReactorContext(Object returnValue) {
/* 590 */       if (Mono.class.isAssignableFrom(returnValue.getClass())) {
/* 591 */         ContextSnapshot snapshot = this.snapshotFactory.captureAll(new Object[0]);
/* 592 */         Objects.requireNonNull(snapshot); return ((Mono)returnValue).contextWrite(snapshot::updateContext);
/*     */       } 
/* 594 */       if (Flux.class.isAssignableFrom(returnValue.getClass())) {
/* 595 */         ContextSnapshot snapshot = this.snapshotFactory.captureAll(new Object[0]);
/* 596 */         Objects.requireNonNull(snapshot); return ((Flux)returnValue).contextWrite(snapshot::updateContext);
/*     */       } 
/*     */       
/* 599 */       return returnValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public TaskDecorator getTaskDecorator() {
/* 604 */       return (TaskDecorator)new ContextPropagatingTaskDecorator(this.snapshotFactory);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ReactiveTypeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */