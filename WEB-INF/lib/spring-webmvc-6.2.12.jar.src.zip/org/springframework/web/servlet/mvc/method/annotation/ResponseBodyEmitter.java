/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseBodyEmitter
/*     */ {
/*     */   @Nullable
/*     */   private final Long timeout;
/*     */   @Nullable
/*     */   private Handler handler;
/*  79 */   private final Set<DataWithMediaType> earlySendAttempts = new LinkedHashSet<>(8);
/*     */ 
/*     */   
/*     */   private boolean complete;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Throwable failure;
/*     */   
/*  88 */   private final DefaultCallback timeoutCallback = new DefaultCallback();
/*     */   
/*  90 */   private final ErrorCallback errorCallback = new ErrorCallback();
/*     */   
/*  92 */   private final DefaultCallback completionCallback = new DefaultCallback();
/*     */ 
/*     */   
/*  95 */   protected final Lock writeLock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBodyEmitter() {
/* 102 */     this.timeout = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBodyEmitter(Long timeout) {
/* 113 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Long getTimeout() {
/* 122 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   
/*     */   void initialize(Handler handler) throws IOException {
/* 127 */     this.writeLock.lock();
/*     */     try {
/* 129 */       this.handler = handler;
/*     */       
/*     */       try {
/* 132 */         sendInternal(this.earlySendAttempts);
/*     */       } finally {
/*     */         
/* 135 */         this.earlySendAttempts.clear();
/*     */       } 
/*     */       
/* 138 */       if (this.complete) {
/* 139 */         if (this.failure != null) {
/* 140 */           this.handler.completeWithError(this.failure);
/*     */         } else {
/*     */           
/* 143 */           this.handler.complete();
/*     */         } 
/*     */       } else {
/*     */         
/* 147 */         this.handler.onTimeout(this.timeoutCallback);
/* 148 */         this.handler.onError(this.errorCallback);
/* 149 */         this.handler.onCompletion(this.completionCallback);
/*     */       } 
/*     */     } finally {
/*     */       
/* 153 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void initializeWithError(Throwable ex) {
/* 158 */     this.writeLock.lock();
/*     */     try {
/* 160 */       this.complete = true;
/* 161 */       this.failure = ex;
/* 162 */       this.earlySendAttempts.clear();
/* 163 */       this.errorCallback.accept(ex);
/*     */     } finally {
/*     */       
/* 166 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendResponse(ServerHttpResponse outputMessage) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(Object object) throws IOException {
/* 193 */     send(object, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(Object object, @Nullable MediaType mediaType) throws IOException {
/* 205 */     this.writeLock.lock();
/*     */     try {
/* 207 */       Assert.state(!this.complete, () -> "ResponseBodyEmitter has already completed" + ((this.failure != null) ? (" with error: " + String.valueOf(this.failure)) : ""));
/*     */       
/* 209 */       if (this.handler != null) {
/*     */         try {
/* 211 */           this.handler.send(object, mediaType);
/*     */         }
/* 213 */         catch (IOException ex) {
/* 214 */           throw ex;
/*     */         }
/* 216 */         catch (Throwable ex) {
/* 217 */           throw new IllegalStateException("Failed to send " + String.valueOf(object), ex);
/*     */         } 
/*     */       } else {
/*     */         
/* 221 */         this.earlySendAttempts.add(new DataWithMediaType(object, mediaType));
/*     */       } 
/*     */     } finally {
/*     */       
/* 225 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(Set<DataWithMediaType> items) throws IOException {
/* 239 */     this.writeLock.lock();
/*     */     try {
/* 241 */       Assert.state(!this.complete, () -> "ResponseBodyEmitter has already completed" + ((this.failure != null) ? (" with error: " + String.valueOf(this.failure)) : ""));
/*     */       
/* 243 */       sendInternal(items);
/*     */     } finally {
/*     */       
/* 246 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendInternal(Set<DataWithMediaType> items) throws IOException {
/* 251 */     if (items.isEmpty()) {
/*     */       return;
/*     */     }
/* 254 */     if (this.handler != null) {
/*     */       try {
/* 256 */         this.handler.send(items);
/*     */       }
/* 258 */       catch (IOException ex) {
/* 259 */         throw ex;
/*     */       }
/* 261 */       catch (Throwable ex) {
/* 262 */         throw new IllegalStateException("Failed to send " + String.valueOf(items), ex);
/*     */       } 
/*     */     } else {
/*     */       
/* 266 */       this.earlySendAttempts.addAll(items);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complete() {
/* 279 */     this.writeLock.lock();
/*     */     try {
/* 281 */       this.complete = true;
/* 282 */       if (this.handler != null) {
/* 283 */         this.handler.complete();
/*     */       }
/*     */     } finally {
/*     */       
/* 287 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void completeWithError(Throwable ex) {
/* 303 */     this.writeLock.lock();
/*     */     try {
/* 305 */       this.complete = true;
/* 306 */       this.failure = ex;
/* 307 */       if (this.handler != null) {
/* 308 */         this.handler.completeWithError(ex);
/*     */       }
/*     */     } finally {
/*     */       
/* 312 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onTimeout(Runnable callback) {
/* 322 */     this.writeLock.lock();
/*     */     try {
/* 324 */       this.timeoutCallback.addDelegate(callback);
/*     */     } finally {
/*     */       
/* 327 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onError(Consumer<Throwable> callback) {
/* 339 */     this.writeLock.lock();
/*     */     try {
/* 341 */       this.errorCallback.addDelegate(callback);
/*     */     } finally {
/*     */       
/* 344 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCompletion(Runnable callback) {
/* 356 */     this.writeLock.lock();
/*     */     try {
/* 358 */       this.completionCallback.addDelegate(callback);
/*     */     } finally {
/*     */       
/* 361 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 368 */     return "ResponseBodyEmitter@" + ObjectUtils.getIdentityHexString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DataWithMediaType
/*     */   {
/*     */     private final Object data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final MediaType mediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DataWithMediaType(Object data, @Nullable MediaType mediaType) {
/* 415 */       this.data = data;
/* 416 */       this.mediaType = mediaType;
/*     */     }
/*     */     
/*     */     public Object getData() {
/* 420 */       return this.data;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public MediaType getMediaType() {
/* 425 */       return this.mediaType;
/*     */     }
/*     */   }
/*     */   
/*     */   private class DefaultCallback
/*     */     implements Runnable
/*     */   {
/* 432 */     private List<Runnable> delegates = new ArrayList<>(1);
/*     */     
/*     */     public void addDelegate(Runnable delegate) {
/* 435 */       this.delegates.add(delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 440 */       ResponseBodyEmitter.this.complete = true;
/* 441 */       for (Runnable delegate : this.delegates)
/* 442 */         delegate.run(); 
/*     */     }
/*     */   }
/*     */   
/*     */   private class ErrorCallback implements Consumer<Throwable> {
/*     */     private List<Consumer<Throwable>> delegates;
/*     */     
/*     */     private ErrorCallback() {
/* 450 */       this.delegates = new ArrayList<>(1);
/*     */     }
/*     */     public void addDelegate(Consumer<Throwable> callback) {
/* 453 */       this.delegates.add(callback);
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Throwable t) {
/* 458 */       ResponseBodyEmitter.this.complete = true;
/* 459 */       for (Consumer<Throwable> delegate : this.delegates)
/* 460 */         delegate.accept(t); 
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Handler {
/*     */     void send(Object param1Object, @Nullable MediaType param1MediaType) throws IOException;
/*     */     
/*     */     void send(Set<ResponseBodyEmitter.DataWithMediaType> param1Set) throws IOException;
/*     */     
/*     */     void complete();
/*     */     
/*     */     void completeWithError(Throwable param1Throwable);
/*     */     
/*     */     void onTimeout(Runnable param1Runnable);
/*     */     
/*     */     void onError(Consumer<Throwable> param1Consumer);
/*     */     
/*     */     void onCompletion(Runnable param1Runnable);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */