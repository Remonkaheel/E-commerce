/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SseEmitter
/*     */   extends ResponseBodyEmitter
/*     */ {
/*  45 */   private static final MediaType TEXT_PLAIN = new MediaType("text", "plain", StandardCharsets.UTF_8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SseEmitter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SseEmitter(Long timeout) {
/*  63 */     super(timeout);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendResponse(ServerHttpResponse outputMessage) {
/*  69 */     super.extendResponse(outputMessage);
/*     */     
/*  71 */     HttpHeaders headers = outputMessage.getHeaders();
/*  72 */     if (headers.getContentType() == null) {
/*  73 */       headers.setContentType(MediaType.TEXT_EVENT_STREAM);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(Object object) throws IOException {
/*  93 */     send(object, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(Object object, @Nullable MediaType mediaType) throws IOException {
/* 112 */     send(event().data(object, mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(SseEventBuilder builder) throws IOException {
/* 126 */     Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = builder.build();
/* 127 */     this.writeLock.lock();
/*     */     try {
/* 129 */       send(dataToSend);
/*     */     } finally {
/*     */       
/* 132 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     return "SseEmitter@" + ObjectUtils.getIdentityHexString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SseEventBuilder event() {
/* 143 */     return new SseEventBuilderImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface SseEventBuilder
/*     */   {
/*     */     SseEventBuilder id(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SseEventBuilder name(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SseEventBuilder reconnectTime(long param1Long);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SseEventBuilder comment(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SseEventBuilder data(Object param1Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SseEventBuilder data(Object param1Object, @Nullable MediaType param1MediaType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Set<ResponseBodyEmitter.DataWithMediaType> build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SseEventBuilderImpl
/*     */     implements SseEventBuilder
/*     */   {
/* 196 */     private final Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = new LinkedHashSet<>(4);
/*     */     
/*     */     @Nullable
/*     */     private StringBuilder sb;
/*     */     
/*     */     private boolean hasName;
/*     */ 
/*     */     
/*     */     public SseEmitter.SseEventBuilder id(String id) {
/* 205 */       append("id:").append(id).append('\n');
/* 206 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SseEmitter.SseEventBuilder name(String name) {
/* 211 */       this.hasName = true;
/* 212 */       append("event:").append(name).append('\n');
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SseEmitter.SseEventBuilder reconnectTime(long reconnectTimeMillis) {
/* 218 */       append("retry:").append(String.valueOf(reconnectTimeMillis)).append('\n');
/* 219 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SseEmitter.SseEventBuilder comment(String comment) {
/* 224 */       append(':').append(comment).append('\n');
/* 225 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SseEmitter.SseEventBuilder data(Object object) {
/* 230 */       return data(object, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public SseEmitter.SseEventBuilder data(Object object, @Nullable MediaType mediaType) {
/* 235 */       if (object instanceof ModelAndView) { ModelAndView mav = (ModelAndView)object; if (!this.hasName && mav.getViewName() != null)
/* 236 */           name(mav.getViewName());  }
/*     */       
/* 238 */       append("data:");
/* 239 */       saveAppendedText();
/* 240 */       if (object instanceof String) { String text = (String)object;
/* 241 */         object = StringUtils.replace(text, "\n", "\ndata:"); }
/*     */       
/* 243 */       this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(object, mediaType));
/* 244 */       append('\n');
/* 245 */       return this;
/*     */     }
/*     */     
/*     */     SseEventBuilderImpl append(String text) {
/* 249 */       if (this.sb == null) {
/* 250 */         this.sb = new StringBuilder();
/*     */       }
/* 252 */       this.sb.append(text);
/* 253 */       return this;
/*     */     }
/*     */     
/*     */     SseEventBuilderImpl append(char ch) {
/* 257 */       if (this.sb == null) {
/* 258 */         this.sb = new StringBuilder();
/*     */       }
/* 260 */       this.sb.append(ch);
/* 261 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<ResponseBodyEmitter.DataWithMediaType> build() {
/* 266 */       if (!StringUtils.hasLength(this.sb) && this.dataToSend.isEmpty()) {
/* 267 */         return Collections.emptySet();
/*     */       }
/* 269 */       append('\n');
/* 270 */       saveAppendedText();
/* 271 */       return this.dataToSend;
/*     */     }
/*     */     
/*     */     private void saveAppendedText() {
/* 275 */       if (this.sb != null) {
/* 276 */         this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(this.sb.toString(), SseEmitter.TEXT_PLAIN));
/* 277 */         this.sb = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\SseEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */