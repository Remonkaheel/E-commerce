/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.annotation.ExceptionHandlerMappingInfo;
/*     */ import org.springframework.web.method.annotation.ExceptionHandlerMethodResolver;
/*     */ import org.springframework.web.method.annotation.MapMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelMethodProcessor;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMethodExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.util.DisconnectedClientHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionHandlerExceptionResolver
/*     */   extends AbstractHandlerMethodExceptionResolver
/*     */   implements ApplicationContextAware, InitializingBean
/*     */ {
/*     */   private static final String DISCONNECTED_CLIENT_LOG_CATEGORY = "org.springframework.web.servlet.mvc.method.annotation.DisconnectedClient";
/*  95 */   private static final DisconnectedClientHelper disconnectedClientHelper = new DisconnectedClientHelper("org.springframework.web.servlet.mvc.method.annotation.DisconnectedClient");
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private List<HandlerMethodArgumentResolver> customArgumentResolvers;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private HandlerMethodArgumentResolverComposite argumentResolvers;
/*     */   
/*     */   @Nullable
/*     */   private List<HandlerMethodReturnValueHandler> customReturnValueHandlers;
/*     */   
/*     */   @Nullable
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */   
/* 111 */   private final List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
/*     */   
/* 113 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */   
/* 115 */   private final List<Object> responseBodyAdvice = new ArrayList();
/*     */   
/* 117 */   private final List<ErrorResponse.Interceptor> errorResponseInterceptors = new ArrayList<>();
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/* 122 */   private final Map<Class<?>, ExceptionHandlerMethodResolver> exceptionHandlerCache = new ConcurrentHashMap<>(64);
/*     */ 
/*     */   
/* 125 */   private final Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> exceptionHandlerAdviceCache = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 135 */     this.customArgumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<HandlerMethodArgumentResolver> getCustomArgumentResolvers() {
/* 143 */     return this.customArgumentResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 151 */     if (argumentResolvers == null) {
/* 152 */       this.argumentResolvers = null;
/*     */     } else {
/*     */       
/* 155 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
/* 156 */       this.argumentResolvers.addResolvers(argumentResolvers);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HandlerMethodArgumentResolverComposite getArgumentResolvers() {
/* 166 */     return this.argumentResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers) {
/* 175 */     this.customReturnValueHandlers = returnValueHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers() {
/* 183 */     return this.customReturnValueHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers) {
/* 191 */     if (returnValueHandlers == null) {
/* 192 */       this.returnValueHandlers = null;
/*     */     } else {
/*     */       
/* 195 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
/* 196 */       this.returnValueHandlers.addHandlers(returnValueHandlers);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HandlerMethodReturnValueHandlerComposite getReturnValueHandlers() {
/* 206 */     return this.returnValueHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters) {
/* 214 */     this.messageConverters.clear();
/* 215 */     this.messageConverters.addAll(messageConverters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HttpMessageConverter<?>> getMessageConverters() {
/* 222 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager) {
/* 230 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentNegotiationManager getContentNegotiationManager() {
/* 237 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseBodyAdvice(@Nullable List<ResponseBodyAdvice<?>> responseBodyAdvice) {
/* 247 */     if (responseBodyAdvice != null) {
/* 248 */       this.responseBodyAdvice.addAll(responseBodyAdvice);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorResponseInterceptors(List<ErrorResponse.Interceptor> interceptors) {
/* 260 */     this.errorResponseInterceptors.clear();
/* 261 */     this.errorResponseInterceptors.addAll(interceptors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ErrorResponse.Interceptor> getErrorResponseInterceptors() {
/* 270 */     return this.errorResponseInterceptors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(@Nullable ApplicationContext applicationContext) {
/* 275 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ApplicationContext getApplicationContext() {
/* 280 */     return this.applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 287 */     initExceptionHandlerAdviceCache();
/* 288 */     initMessageConverters();
/*     */     
/* 290 */     if (this.argumentResolvers == null) {
/* 291 */       List<HandlerMethodArgumentResolver> resolvers = getDefaultArgumentResolvers();
/* 292 */       this.argumentResolvers = (new HandlerMethodArgumentResolverComposite()).addResolvers(resolvers);
/*     */     } 
/* 294 */     if (this.returnValueHandlers == null) {
/* 295 */       List<HandlerMethodReturnValueHandler> handlers = getDefaultReturnValueHandlers();
/* 296 */       this.returnValueHandlers = (new HandlerMethodReturnValueHandlerComposite()).addHandlers(handlers);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initMessageConverters() {
/* 301 */     if (!this.messageConverters.isEmpty()) {
/*     */       return;
/*     */     }
/* 304 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 305 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 306 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */   }
/*     */   
/*     */   private void initExceptionHandlerAdviceCache() {
/* 310 */     if (getApplicationContext() == null) {
/*     */       return;
/*     */     }
/*     */     
/* 314 */     List<ControllerAdviceBean> adviceBeans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
/* 315 */     for (ControllerAdviceBean adviceBean : adviceBeans) {
/* 316 */       Class<?> beanType = adviceBean.getBeanType();
/* 317 */       if (beanType == null) {
/* 318 */         throw new IllegalStateException("Unresolvable type for ControllerAdviceBean: " + String.valueOf(adviceBean));
/*     */       }
/* 320 */       ExceptionHandlerMethodResolver resolver = new ExceptionHandlerMethodResolver(beanType);
/* 321 */       if (resolver.hasExceptionMappings()) {
/* 322 */         this.exceptionHandlerAdviceCache.put(adviceBean, resolver);
/*     */       }
/* 324 */       if (ResponseBodyAdvice.class.isAssignableFrom(beanType)) {
/* 325 */         this.responseBodyAdvice.add(adviceBean);
/*     */       }
/*     */     } 
/*     */     
/* 329 */     if (this.logger.isDebugEnabled()) {
/* 330 */       int handlerSize = this.exceptionHandlerAdviceCache.size();
/* 331 */       int adviceSize = this.responseBodyAdvice.size();
/* 332 */       if (handlerSize == 0 && adviceSize == 0) {
/* 333 */         this.logger.debug("ControllerAdvice beans: none");
/*     */       } else {
/*     */         
/* 336 */         this.logger.debug("ControllerAdvice beans: " + handlerSize + " @ExceptionHandler, " + adviceSize + " ResponseBodyAdvice");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> getExceptionHandlerAdviceCache() {
/* 349 */     return Collections.unmodifiableMap(this.exceptionHandlerAdviceCache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers() {
/* 357 */     List<HandlerMethodArgumentResolver> resolvers = new ArrayList<>();
/*     */ 
/*     */     
/* 360 */     resolvers.add(new SessionAttributeMethodArgumentResolver());
/* 361 */     resolvers.add(new RequestAttributeMethodArgumentResolver());
/*     */ 
/*     */     
/* 364 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/* 365 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/* 366 */     resolvers.add(new RedirectAttributesMethodArgumentResolver());
/* 367 */     resolvers.add(new ModelMethodProcessor());
/*     */ 
/*     */     
/* 370 */     if (getCustomArgumentResolvers() != null) {
/* 371 */       resolvers.addAll(getCustomArgumentResolvers());
/*     */     }
/*     */ 
/*     */     
/* 375 */     resolvers.add(new PrincipalMethodArgumentResolver());
/*     */     
/* 377 */     return resolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers() {
/* 385 */     List<HandlerMethodReturnValueHandler> handlers = new ArrayList<>();
/*     */ 
/*     */     
/* 388 */     handlers.add(new ModelAndViewMethodReturnValueHandler());
/* 389 */     handlers.add(new ModelMethodProcessor());
/* 390 */     handlers.add(new ViewMethodReturnValueHandler());
/* 391 */     handlers.add(new HttpEntityMethodProcessor(
/* 392 */           getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice, this.errorResponseInterceptors));
/*     */ 
/*     */ 
/*     */     
/* 396 */     handlers.add(new ServletModelAttributeMethodProcessor(false));
/* 397 */     handlers.add(new RequestResponseBodyMethodProcessor(
/* 398 */           getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice, this.errorResponseInterceptors));
/*     */ 
/*     */ 
/*     */     
/* 402 */     handlers.add(new ViewNameMethodReturnValueHandler());
/* 403 */     handlers.add(new MapMethodProcessor());
/*     */ 
/*     */     
/* 406 */     if (getCustomReturnValueHandlers() != null) {
/* 407 */       handlers.addAll(getCustomReturnValueHandlers());
/*     */     }
/*     */ 
/*     */     
/* 411 */     handlers.add(new ServletModelAttributeMethodProcessor(true));
/*     */     
/* 413 */     return handlers;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasGlobalExceptionHandlers() {
/* 418 */     return !this.exceptionHandlerAdviceCache.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldApplyTo(HttpServletRequest request, @Nullable Object handler) {
/* 423 */     if ((handler instanceof org.springframework.web.servlet.resource.ResourceHttpRequestHandler || handler instanceof org.springframework.web.servlet.function.HandlerFunction) && 
/* 424 */       hasGlobalExceptionHandlers() && !hasHandlerMappings()) {
/* 425 */       return true;
/*     */     }
/*     */     
/* 428 */     return super.shouldApplyTo(request, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView doResolveHandlerMethodException(HttpServletRequest request, HttpServletResponse response, @Nullable HandlerMethod handlerMethod, Exception exception) {
/* 440 */     ServletWebRequest webRequest = new ServletWebRequest(request, response);
/* 441 */     ServletInvocableHandlerMethod exceptionHandlerMethod = getExceptionHandlerMethod(handlerMethod, exception, webRequest);
/*     */     
/* 443 */     if (exceptionHandlerMethod == null) {
/* 444 */       return null;
/*     */     }
/*     */     
/* 447 */     if (this.argumentResolvers != null) {
/* 448 */       exceptionHandlerMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/*     */     }
/* 450 */     if (this.returnValueHandlers != null) {
/* 451 */       exceptionHandlerMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
/*     */     }
/*     */     
/* 454 */     ModelAndViewContainer mavContainer = new ModelAndViewContainer();
/*     */     
/* 456 */     ArrayList<Throwable> exceptions = new ArrayList<>();
/*     */     try {
/* 458 */       if (this.logger.isDebugEnabled()) {
/* 459 */         this.logger.debug("Using @ExceptionHandler " + String.valueOf(exceptionHandlerMethod));
/*     */       }
/*     */       
/* 462 */       Throwable exToExpose = exception;
/* 463 */       while (exToExpose != null) {
/* 464 */         exceptions.add(exToExpose);
/* 465 */         Throwable cause = exToExpose.getCause();
/* 466 */         exToExpose = (cause != exToExpose) ? cause : null;
/*     */       } 
/* 468 */       Object[] arguments = new Object[exceptions.size() + 1];
/* 469 */       exceptions.toArray(arguments);
/* 470 */       arguments[arguments.length - 1] = handlerMethod;
/* 471 */       exceptionHandlerMethod.invokeAndHandle(webRequest, mavContainer, arguments);
/*     */     }
/* 473 */     catch (Throwable invocationEx) {
/* 474 */       if (disconnectedClientHelper.checkAndLogClientDisconnectedException(invocationEx)) {
/* 475 */         return new ModelAndView();
/*     */       }
/*     */ 
/*     */       
/* 479 */       if (!exceptions.contains(invocationEx) && this.logger.isWarnEnabled()) {
/* 480 */         this.logger.warn("Failure in @ExceptionHandler " + String.valueOf(exceptionHandlerMethod), invocationEx);
/*     */       }
/*     */       
/* 483 */       return null;
/*     */     } 
/*     */     
/* 486 */     if (mavContainer.isRequestHandled()) {
/* 487 */       return new ModelAndView();
/*     */     }
/*     */     
/* 490 */     ModelMap model = mavContainer.getModel();
/* 491 */     HttpStatusCode status = mavContainer.getStatus();
/* 492 */     ModelAndView mav = new ModelAndView(mavContainer.getViewName(), (Map)model, status);
/* 493 */     mav.setViewName(mavContainer.getViewName());
/* 494 */     if (!mavContainer.isViewReference()) {
/* 495 */       mav.setView((View)mavContainer.getView());
/*     */     }
/* 497 */     if (model instanceof RedirectAttributes) { RedirectAttributes redirectAttributes = (RedirectAttributes)model;
/* 498 */       Map<String, ?> flashAttributes = redirectAttributes.getFlashAttributes();
/* 499 */       RequestContextUtils.getOutputFlashMap(request).putAll(flashAttributes); }
/*     */     
/* 501 */     return mav;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ServletInvocableHandlerMethod getExceptionHandlerMethod(@Nullable HandlerMethod handlerMethod, Exception exception, ServletWebRequest webRequest) {
/* 520 */     List<MediaType> acceptedMediaTypes = List.of(MediaType.ALL);
/*     */     try {
/* 522 */       acceptedMediaTypes = this.contentNegotiationManager.resolveMediaTypes((NativeWebRequest)webRequest);
/*     */     }
/* 524 */     catch (HttpMediaTypeNotAcceptableException mediaTypeExc) {
/* 525 */       if (this.logger.isDebugEnabled()) {
/* 526 */         this.logger.debug("Could not resolve accepted media types for @ExceptionHandler [" + webRequest.getHeader("Accept") + "]", (Throwable)mediaTypeExc);
/*     */       }
/*     */     } 
/*     */     
/* 530 */     Class<?> handlerType = null;
/*     */     
/* 532 */     if (handlerMethod != null) {
/*     */ 
/*     */       
/* 535 */       handlerType = handlerMethod.getBeanType();
/* 536 */       ExceptionHandlerMethodResolver resolver = this.exceptionHandlerCache.computeIfAbsent(handlerType, ExceptionHandlerMethodResolver::new);
/*     */ 
/*     */       
/* 539 */       for (MediaType mediaType : acceptedMediaTypes) {
/* 540 */         ExceptionHandlerMappingInfo mappingInfo = resolver.resolveExceptionMapping(exception, mediaType);
/* 541 */         if (mappingInfo != null) {
/* 542 */           if (!mappingInfo.getProducibleTypes().isEmpty()) {
/* 543 */             webRequest.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, mappingInfo.getProducibleTypes(), 0);
/*     */           }
/* 545 */           return new ServletInvocableHandlerMethod(handlerMethod.getBean(), mappingInfo.getHandlerMethod(), (MessageSource)this.applicationContext);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 550 */       if (Proxy.isProxyClass(handlerType)) {
/* 551 */         handlerType = AopUtils.getTargetClass(handlerMethod.getBean());
/*     */       }
/*     */     } 
/*     */     
/* 555 */     for (Map.Entry<ControllerAdviceBean, ExceptionHandlerMethodResolver> entry : this.exceptionHandlerAdviceCache.entrySet()) {
/* 556 */       ControllerAdviceBean advice = entry.getKey();
/* 557 */       if (advice.isApplicableToBeanType(handlerType)) {
/* 558 */         ExceptionHandlerMethodResolver resolver = entry.getValue();
/* 559 */         for (MediaType mediaType : acceptedMediaTypes) {
/* 560 */           ExceptionHandlerMappingInfo mappingInfo = resolver.resolveExceptionMapping(exception, mediaType);
/* 561 */           if (mappingInfo != null) {
/* 562 */             if (!mappingInfo.getProducibleTypes().isEmpty()) {
/* 563 */               webRequest.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, mappingInfo.getProducibleTypes(), 0);
/*     */             }
/* 565 */             return new ServletInvocableHandlerMethod(advice.resolveBean(), mappingInfo.getHandlerMethod(), (MessageSource)this.applicationContext);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 571 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ExceptionHandlerExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */