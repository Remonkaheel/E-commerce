/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletModelAttributeMethodProcessor
/*     */   extends ModelAttributeMethodProcessor
/*     */ {
/*     */   public ServletModelAttributeMethodProcessor(boolean annotationNotRequired) {
/*  61 */     super(annotationNotRequired);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final Object createAttribute(String attributeName, MethodParameter parameter, WebDataBinderFactory binderFactory, NativeWebRequest request) throws Exception {
/*  77 */     String value = getRequestValueForAttribute(attributeName, request);
/*  78 */     if (value != null) {
/*  79 */       Object attribute = createAttributeFromRequestValue(value, attributeName, parameter, binderFactory, request);
/*     */       
/*  81 */       if (attribute != null) {
/*  82 */         return attribute;
/*     */       }
/*     */     } 
/*     */     
/*  86 */     return super.createAttribute(attributeName, parameter, binderFactory, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getRequestValueForAttribute(String attributeName, NativeWebRequest request) {
/* 100 */     Map<String, String> variables = getUriTemplateVariables(request);
/* 101 */     String variableValue = variables.get(attributeName);
/* 102 */     if (StringUtils.hasText(variableValue)) {
/* 103 */       return variableValue;
/*     */     }
/* 105 */     String parameterValue = request.getParameter(attributeName);
/* 106 */     if (StringUtils.hasText(parameterValue)) {
/* 107 */       return parameterValue;
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Map<String, String> getUriTemplateVariables(NativeWebRequest request) {
/* 114 */     Map<String, String> variables = (Map<String, String>)request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 0);
/*     */     
/* 116 */     return (variables != null) ? variables : Collections.<String, String>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object createAttributeFromRequestValue(String sourceValue, String attributeName, MethodParameter parameter, WebDataBinderFactory binderFactory, NativeWebRequest request) throws Exception {
/* 137 */     WebDataBinder webDataBinder = binderFactory.createBinder(request, null, attributeName);
/* 138 */     ConversionService conversionService = webDataBinder.getConversionService();
/* 139 */     if (conversionService != null) {
/* 140 */       TypeDescriptor source = TypeDescriptor.valueOf(String.class);
/* 141 */       TypeDescriptor target = new TypeDescriptor(parameter);
/* 142 */       if (conversionService.canConvert(source, target)) {
/* 143 */         return webDataBinder.convertIfNecessary(sourceValue, parameter.getParameterType(), parameter);
/*     */       }
/*     */     } 
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void constructAttribute(WebDataBinder binder, NativeWebRequest request) {
/* 154 */     ServletRequest servletRequest = (ServletRequest)request.getNativeRequest(ServletRequest.class);
/* 155 */     Assert.state((servletRequest != null), "No ServletRequest");
/* 156 */     ServletRequestDataBinder servletBinder = (ServletRequestDataBinder)binder;
/* 157 */     servletBinder.construct(servletRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request) {
/* 165 */     ServletRequest servletRequest = (ServletRequest)request.getNativeRequest(ServletRequest.class);
/* 166 */     Assert.state((servletRequest != null), "No ServletRequest");
/* 167 */     ServletRequestDataBinder servletBinder = (ServletRequestDataBinder)binder;
/* 168 */     servletBinder.bind(servletRequest);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletModelAttributeMethodProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */