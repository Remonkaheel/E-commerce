package org.springframework.web.servlet.mvc.condition;

import org.springframework.lang.Nullable;

public interface NameValueExpression<T> {
  String getName();
  
  @Nullable
  T getValue();
  
  boolean isNegated();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\NameValueExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */