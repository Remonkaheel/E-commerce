/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathPatternsRequestCondition
/*     */   extends AbstractRequestCondition<PathPatternsRequestCondition>
/*     */ {
/*  51 */   private static final SortedSet<PathPattern> EMPTY_PATH_PATTERN = new TreeSet<>(
/*  52 */       Collections.singleton((new PathPatternParser()).parse("")));
/*     */   
/*  54 */   private static final Set<String> EMPTY_PATH = Collections.singleton("");
/*     */   
/*  56 */   private static final SortedSet<PathPattern> ROOT_PATH_PATTERNS = new TreeSet<>(
/*  57 */       List.of((new PathPatternParser()).parse(""), (new PathPatternParser()).parse("/")));
/*     */ 
/*     */ 
/*     */   
/*     */   private final SortedSet<PathPattern> patterns;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathPatternsRequestCondition() {
/*  67 */     this(EMPTY_PATH_PATTERN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathPatternsRequestCondition(PathPatternParser parser, String... patterns) {
/*  74 */     this(parse(parser, patterns));
/*     */   }
/*     */   
/*     */   private static SortedSet<PathPattern> parse(PathPatternParser parser, String... patterns) {
/*  78 */     if (patterns.length == 0 || (patterns.length == 1 && !StringUtils.hasText(patterns[0]))) {
/*  79 */       return EMPTY_PATH_PATTERN;
/*     */     }
/*  81 */     SortedSet<PathPattern> result = new TreeSet<>();
/*  82 */     for (String pattern : patterns) {
/*  83 */       pattern = parser.initFullPathPattern(pattern);
/*  84 */       result.add(parser.parse(pattern));
/*     */     } 
/*  86 */     return result;
/*     */   }
/*     */   
/*     */   private PathPatternsRequestCondition(SortedSet<PathPattern> patterns) {
/*  90 */     this.patterns = patterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<PathPattern> getPatterns() {
/*  98 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<PathPattern> getContent() {
/* 103 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getToStringInfix() {
/* 108 */     return " || ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathPattern getFirstPattern() {
/* 115 */     return this.patterns.first();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmptyPathMapping() {
/* 122 */     return (this.patterns == EMPTY_PATH_PATTERN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getDirectPaths() {
/* 129 */     if (isEmptyPathMapping()) {
/* 130 */       return EMPTY_PATH;
/*     */     }
/* 132 */     Set<String> result = Collections.emptySet();
/* 133 */     for (PathPattern pattern : this.patterns) {
/* 134 */       if (!pattern.hasPatternSyntax()) {
/* 135 */         result = result.isEmpty() ? new HashSet<>(1) : result;
/* 136 */         result.add(pattern.getPatternString());
/*     */       } 
/*     */     } 
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getPatternValues() {
/* 146 */     return isEmptyPathMapping() ? EMPTY_PATH : 
/* 147 */       (Set<String>)getPatterns().stream().map(PathPattern::getPatternString).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathPatternsRequestCondition combine(PathPatternsRequestCondition other) {
/* 161 */     if (isEmptyPathMapping() && other.isEmptyPathMapping()) {
/* 162 */       return new PathPatternsRequestCondition(ROOT_PATH_PATTERNS);
/*     */     }
/* 164 */     if (other.isEmptyPathMapping()) {
/* 165 */       return this;
/*     */     }
/* 167 */     if (isEmptyPathMapping()) {
/* 168 */       return other;
/*     */     }
/*     */     
/* 171 */     SortedSet<PathPattern> combined = new TreeSet<>();
/* 172 */     for (PathPattern pattern1 : this.patterns) {
/* 173 */       for (PathPattern pattern2 : other.patterns) {
/* 174 */         combined.add(pattern1.combine(pattern2));
/*     */       }
/*     */     } 
/* 177 */     return new PathPatternsRequestCondition(combined);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PathPatternsRequestCondition getMatchingCondition(HttpServletRequest request) {
/* 192 */     PathContainer path = ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request).pathWithinApplication();
/* 193 */     SortedSet<PathPattern> matches = getMatchingPatterns(path);
/* 194 */     return (matches != null) ? new PathPatternsRequestCondition(matches) : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private SortedSet<PathPattern> getMatchingPatterns(PathContainer path) {
/* 199 */     TreeSet<PathPattern> result = null;
/* 200 */     for (PathPattern pattern : this.patterns) {
/* 201 */       if (pattern.matches(path)) {
/* 202 */         result = (result != null) ? result : new TreeSet<>();
/* 203 */         result.add(pattern);
/*     */       } 
/*     */     } 
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(PathPatternsRequestCondition other, HttpServletRequest request) {
/* 221 */     Iterator<PathPattern> iterator = this.patterns.iterator();
/* 222 */     Iterator<PathPattern> iteratorOther = other.getPatterns().iterator();
/* 223 */     while (iterator.hasNext() && iteratorOther.hasNext()) {
/* 224 */       int result = PathPattern.SPECIFICITY_COMPARATOR.compare(iterator.next(), iteratorOther.next());
/* 225 */       if (result != 0) {
/* 226 */         return result;
/*     */       }
/*     */     } 
/* 229 */     if (iterator.hasNext()) {
/* 230 */       return -1;
/*     */     }
/* 232 */     if (iteratorOther.hasNext()) {
/* 233 */       return 1;
/*     */     }
/*     */     
/* 236 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\PathPatternsRequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */