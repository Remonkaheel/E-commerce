/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.validation.method.MethodValidationException;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.ErrorResponseException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingPathVariableException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.AsyncRequestNotUsableException;
/*     */ import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
/*     */ import org.springframework.web.method.annotation.HandlerMethodValidationException;
/*     */ import org.springframework.web.multipart.MaxUploadSizeExceededException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.servlet.resource.NoResourceFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResponseEntityExceptionHandler
/*     */   implements MessageSourceAware
/*     */ {
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  86 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private MessageSource messageSource;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 100 */     this.messageSource = messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MessageSource getMessageSource() {
/* 109 */     return this.messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ExceptionHandler({HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class, HttpMediaTypeNotAcceptableException.class, MissingPathVariableException.class, MissingServletRequestParameterException.class, MissingServletRequestPartException.class, ServletRequestBindingException.class, MethodArgumentNotValidException.class, HandlerMethodValidationException.class, NoHandlerFoundException.class, NoResourceFoundException.class, AsyncRequestTimeoutException.class, ErrorResponseException.class, MaxUploadSizeExceededException.class, ConversionNotSupportedException.class, TypeMismatchException.class, HttpMessageNotReadableException.class, HttpMessageNotWritableException.class, MethodValidationException.class, AsyncRequestNotUsableException.class})
/*     */   @Nullable
/*     */   public final ResponseEntity<Object> handleException(Exception ex, WebRequest request) throws Exception {
/* 142 */     if (ex instanceof HttpRequestMethodNotSupportedException) { HttpRequestMethodNotSupportedException subEx = (HttpRequestMethodNotSupportedException)ex;
/* 143 */       return handleHttpRequestMethodNotSupported(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 145 */     if (ex instanceof HttpMediaTypeNotSupportedException) { HttpMediaTypeNotSupportedException subEx = (HttpMediaTypeNotSupportedException)ex;
/* 146 */       return handleHttpMediaTypeNotSupported(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 148 */     if (ex instanceof HttpMediaTypeNotAcceptableException) { HttpMediaTypeNotAcceptableException subEx = (HttpMediaTypeNotAcceptableException)ex;
/* 149 */       return handleHttpMediaTypeNotAcceptable(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 151 */     if (ex instanceof MissingPathVariableException) { MissingPathVariableException subEx = (MissingPathVariableException)ex;
/* 152 */       return handleMissingPathVariable(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 154 */     if (ex instanceof MissingServletRequestParameterException) { MissingServletRequestParameterException subEx = (MissingServletRequestParameterException)ex;
/* 155 */       return handleMissingServletRequestParameter(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 157 */     if (ex instanceof MissingServletRequestPartException) { MissingServletRequestPartException subEx = (MissingServletRequestPartException)ex;
/* 158 */       return handleMissingServletRequestPart(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 160 */     if (ex instanceof ServletRequestBindingException) { ServletRequestBindingException subEx = (ServletRequestBindingException)ex;
/* 161 */       return handleServletRequestBindingException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 163 */     if (ex instanceof MethodArgumentNotValidException) { MethodArgumentNotValidException subEx = (MethodArgumentNotValidException)ex;
/* 164 */       return handleMethodArgumentNotValid(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 166 */     if (ex instanceof HandlerMethodValidationException) { HandlerMethodValidationException subEx = (HandlerMethodValidationException)ex;
/* 167 */       return handleHandlerMethodValidationException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 169 */     if (ex instanceof NoHandlerFoundException) { NoHandlerFoundException subEx = (NoHandlerFoundException)ex;
/* 170 */       return handleNoHandlerFoundException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 172 */     if (ex instanceof NoResourceFoundException) { NoResourceFoundException subEx = (NoResourceFoundException)ex;
/* 173 */       return handleNoResourceFoundException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 175 */     if (ex instanceof AsyncRequestTimeoutException) { AsyncRequestTimeoutException subEx = (AsyncRequestTimeoutException)ex;
/* 176 */       return handleAsyncRequestTimeoutException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 178 */     if (ex instanceof ErrorResponseException) { ErrorResponseException subEx = (ErrorResponseException)ex;
/* 179 */       return handleErrorResponseException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */     
/* 181 */     if (ex instanceof MaxUploadSizeExceededException) { MaxUploadSizeExceededException subEx = (MaxUploadSizeExceededException)ex;
/* 182 */       return handleMaxUploadSizeExceededException(subEx, subEx.getHeaders(), subEx.getStatusCode(), request); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     HttpHeaders headers = new HttpHeaders();
/* 188 */     if (ex instanceof ConversionNotSupportedException) { ConversionNotSupportedException theEx = (ConversionNotSupportedException)ex;
/* 189 */       return handleConversionNotSupported(theEx, headers, (HttpStatusCode)HttpStatus.INTERNAL_SERVER_ERROR, request); }
/*     */     
/* 191 */     if (ex instanceof TypeMismatchException) { TypeMismatchException theEx = (TypeMismatchException)ex;
/* 192 */       return handleTypeMismatch(theEx, headers, (HttpStatusCode)HttpStatus.BAD_REQUEST, request); }
/*     */     
/* 194 */     if (ex instanceof HttpMessageNotReadableException) { HttpMessageNotReadableException theEx = (HttpMessageNotReadableException)ex;
/* 195 */       return handleHttpMessageNotReadable(theEx, headers, (HttpStatusCode)HttpStatus.BAD_REQUEST, request); }
/*     */     
/* 197 */     if (ex instanceof HttpMessageNotWritableException) { HttpMessageNotWritableException theEx = (HttpMessageNotWritableException)ex;
/* 198 */       return handleHttpMessageNotWritable(theEx, headers, (HttpStatusCode)HttpStatus.INTERNAL_SERVER_ERROR, request); }
/*     */     
/* 200 */     if (ex instanceof MethodValidationException) { MethodValidationException theEx = (MethodValidationException)ex;
/* 201 */       return handleMethodValidationException(theEx, headers, HttpStatus.INTERNAL_SERVER_ERROR, request); }
/*     */     
/* 203 */     if (ex instanceof AsyncRequestNotUsableException) { AsyncRequestNotUsableException theEx = (AsyncRequestNotUsableException)ex;
/* 204 */       return handleAsyncRequestNotUsableException(theEx, request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     throw ex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 229 */     pageNotFoundLogger.warn(ex.getMessage());
/* 230 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 247 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 264 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleMissingPathVariable(MissingPathVariableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 282 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 299 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleMissingServletRequestPart(MissingServletRequestPartException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 316 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 333 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 350 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleHandlerMethodValidationException(HandlerMethodValidationException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 368 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 386 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleNoResourceFoundException(NoResourceFoundException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 404 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleAsyncRequestTimeoutException(AsyncRequestTimeoutException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 422 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleErrorResponseException(ErrorResponseException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 440 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleMaxUploadSizeExceededException(MaxUploadSizeExceededException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 458 */     return handleExceptionInternal((Exception)ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleConversionNotSupported(ConversionNotSupportedException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 478 */     Object[] args = { ex.getPropertyName(), ex.getValue() };
/* 479 */     String defaultDetail = "Failed to convert '" + String.valueOf(args[0]) + "' with value: '" + String.valueOf(args[1]) + "'";
/* 480 */     ProblemDetail body = createProblemDetail((Exception)ex, status, defaultDetail, null, args, request);
/*     */     
/* 482 */     return handleExceptionInternal((Exception)ex, body, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 502 */     Object[] args = { ex.getPropertyName(), ex.getValue() };
/* 503 */     String defaultDetail = "Failed to convert '" + String.valueOf(args[0]) + "' with value: '" + String.valueOf(args[1]) + "'";
/* 504 */     String messageCode = ErrorResponse.getDefaultDetailMessageCode(TypeMismatchException.class, null);
/* 505 */     ProblemDetail body = createProblemDetail((Exception)ex, status, defaultDetail, messageCode, args, request);
/*     */     
/* 507 */     return handleExceptionInternal((Exception)ex, body, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 527 */     ProblemDetail body = createProblemDetail((Exception)ex, status, "Failed to read request", null, null, request);
/* 528 */     return handleExceptionInternal((Exception)ex, body, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
/* 548 */     ProblemDetail body = createProblemDetail((Exception)ex, status, "Failed to write request", null, null, request);
/* 549 */     return handleExceptionInternal((Exception)ex, body, headers, status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleMethodValidationException(MethodValidationException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
/* 570 */     ProblemDetail body = createProblemDetail((Exception)ex, (HttpStatusCode)status, "Validation failed", null, null, request);
/* 571 */     return handleExceptionInternal((Exception)ex, body, headers, (HttpStatusCode)status, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleAsyncRequestNotUsableException(AsyncRequestNotUsableException ex, WebRequest request) {
/* 587 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProblemDetail createProblemDetail(Exception ex, HttpStatusCode status, String defaultDetail, @Nullable String detailMessageCode, @Nullable Object[] detailMessageArguments, WebRequest request) {
/* 610 */     ErrorResponse.Builder builder = ErrorResponse.builder(ex, status, defaultDetail);
/* 611 */     if (detailMessageCode != null) {
/* 612 */       builder.detailMessageCode(detailMessageCode);
/*     */     }
/* 614 */     if (detailMessageArguments != null) {
/* 615 */       builder.detailMessageArguments(detailMessageArguments);
/*     */     }
/* 617 */     return builder.build().updateAndGetBody(this.messageSource, LocaleContextHolder.getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleExceptionInternal(Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatusCode statusCode, WebRequest request) {
/* 643 */     if (request instanceof ServletWebRequest) { ServletWebRequest servletWebRequest = (ServletWebRequest)request;
/* 644 */       HttpServletResponse response = servletWebRequest.getResponse();
/* 645 */       if (response != null && response.isCommitted()) {
/* 646 */         if (this.logger.isWarnEnabled()) {
/* 647 */           this.logger.warn("Response already committed. Ignoring: " + String.valueOf(ex));
/*     */         }
/* 649 */         return null;
/*     */       }  }
/*     */ 
/*     */     
/* 653 */     if (body == null && ex instanceof ErrorResponse) { ErrorResponse errorResponse = (ErrorResponse)ex;
/* 654 */       body = errorResponse.updateAndGetBody(this.messageSource, LocaleContextHolder.getLocale()); }
/*     */ 
/*     */     
/* 657 */     if (statusCode.equals(HttpStatus.INTERNAL_SERVER_ERROR) && body == null) {
/* 658 */       request.setAttribute("jakarta.servlet.error.exception", ex, 0);
/*     */     }
/*     */     
/* 661 */     return createResponseEntity(body, headers, statusCode, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResponseEntity<Object> createResponseEntity(@Nullable Object body, HttpHeaders headers, HttpStatusCode statusCode, WebRequest request) {
/* 679 */     return new ResponseEntity(body, (MultiValueMap)headers, statusCode);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseEntityExceptionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */