/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Locale;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractNameValueExpression<T>
/*     */   implements NameValueExpression<T>
/*     */ {
/*     */   protected final String name;
/*     */   @Nullable
/*     */   protected final T value;
/*     */   protected final boolean isNegated;
/*     */   
/*     */   AbstractNameValueExpression(String expression) {
/*  47 */     int separator = expression.indexOf('=');
/*  48 */     if (separator == -1) {
/*  49 */       this.isNegated = expression.startsWith("!");
/*  50 */       this.name = this.isNegated ? expression.substring(1) : expression;
/*  51 */       this.value = null;
/*     */     } else {
/*     */       
/*  54 */       this.isNegated = (separator > 0 && expression.charAt(separator - 1) == '!');
/*  55 */       this.name = this.isNegated ? expression.substring(0, separator - 1) : expression.substring(0, separator);
/*  56 */       this.value = parseValue(expression.substring(separator + 1));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  63 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T getValue() {
/*  69 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNegated() {
/*  74 */     return this.isNegated;
/*     */   }
/*     */   
/*     */   public final boolean match(HttpServletRequest request) {
/*     */     boolean isMatch;
/*  79 */     if (this.value != null) {
/*  80 */       isMatch = matchValue(request);
/*     */     } else {
/*     */       
/*  83 */       isMatch = matchName(request);
/*     */     } 
/*  85 */     return (this.isNegated != isMatch);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract boolean isCaseSensitiveName();
/*     */ 
/*     */   
/*     */   protected abstract T parseValue(String paramString);
/*     */ 
/*     */   
/*     */   protected abstract boolean matchName(HttpServletRequest paramHttpServletRequest);
/*     */   
/*     */   protected abstract boolean matchValue(HttpServletRequest paramHttpServletRequest);
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 100 */     if (this == other) {
/* 101 */       return true;
/*     */     }
/* 103 */     if (other == null || getClass() != other.getClass()) {
/* 104 */       return false;
/*     */     }
/* 106 */     AbstractNameValueExpression<?> that = (AbstractNameValueExpression)other;
/* 107 */     return ((isCaseSensitiveName() ? this.name.equals(that.name) : this.name.equalsIgnoreCase(that.name)) && 
/* 108 */       ObjectUtils.nullSafeEquals(this.value, that.value) && this.isNegated == that.isNegated);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 113 */     int result = isCaseSensitiveName() ? this.name.hashCode() : this.name.toLowerCase(Locale.ROOT).hashCode();
/* 114 */     result = 31 * result + ((this.value != null) ? this.value.hashCode() : 0);
/* 115 */     result = 31 * result + (this.isNegated ? 1 : 0);
/* 116 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     StringBuilder builder = new StringBuilder();
/* 122 */     if (this.value != null) {
/* 123 */       builder.append(this.name);
/* 124 */       if (this.isNegated) {
/* 125 */         builder.append('!');
/*     */       }
/* 127 */       builder.append('=');
/* 128 */       builder.append(this.value);
/*     */     } else {
/*     */       
/* 131 */       if (this.isNegated) {
/* 132 */         builder.append('!');
/*     */       }
/* 134 */       builder.append(this.name);
/*     */     } 
/* 136 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\AbstractNameValueExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */