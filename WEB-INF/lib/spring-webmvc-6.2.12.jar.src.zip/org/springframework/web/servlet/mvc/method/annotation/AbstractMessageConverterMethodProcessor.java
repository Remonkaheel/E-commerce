/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.http.converter.SmartHttpMessageConverter;
/*     */ import org.springframework.http.server.ServerHttpRequest;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageConverterMethodProcessor
/*     */   extends AbstractMessageConverterMethodArgumentResolver
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*  85 */   private static final Set<String> SAFE_EXTENSIONS = Set.of(new String[] { "txt", "text", "yml", "properties", "csv", "json", "xml", "atom", "rss", "png", "jpe", "jpeg", "jpg", "gif", "wbmp", "bmp" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final Set<String> SAFE_MEDIA_BASE_TYPES = Set.of("audio", "image", "video");
/*     */ 
/*     */   
/*  94 */   private static final List<MediaType> ALL_APPLICATION_MEDIA_TYPES = List.of(MediaType.ALL, new MediaType("application"));
/*     */   
/*  96 */   private static final Type RESOURCE_REGION_LIST_TYPE = (new ParameterizedTypeReference<List<ResourceRegion>>() {  }
/*  97 */     ).getType();
/*     */ 
/*     */   
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */ 
/*     */   
/* 103 */   private final List<MediaType> problemMediaTypes = Arrays.asList(new MediaType[] { MediaType.APPLICATION_PROBLEM_JSON, MediaType.APPLICATION_PROBLEM_XML });
/*     */   
/* 105 */   private final List<ErrorResponse.Interceptor> errorResponseInterceptors = new ArrayList<>();
/*     */   
/* 107 */   private final Set<String> safeExtensions = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters) {
/* 114 */     this(converters, (ContentNegotiationManager)null, (List<Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager contentNegotiationManager) {
/* 123 */     this(converters, contentNegotiationManager, (List<Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, @Nullable List<Object> requestResponseBodyAdvice) {
/* 134 */     this(converters, manager, requestResponseBodyAdvice, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, @Nullable List<Object> requestResponseBodyAdvice, List<ErrorResponse.Interceptor> interceptors) {
/* 147 */     super(converters, requestResponseBodyAdvice);
/*     */     
/* 149 */     this.contentNegotiationManager = (manager != null) ? manager : new ContentNegotiationManager();
/* 150 */     this.safeExtensions.addAll(this.contentNegotiationManager.getAllFileExtensions());
/* 151 */     this.safeExtensions.addAll(SAFE_EXTENSIONS);
/* 152 */     this.errorResponseInterceptors.addAll(interceptors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletServerHttpResponse createOutputMessage(NativeWebRequest webRequest) {
/* 162 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/* 163 */     Assert.state((response != null), "No HttpServletResponse");
/* 164 */     return new ServletServerHttpResponse(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeErrorResponseInterceptors(ProblemDetail detail, @Nullable ErrorResponse errorResponse) {
/*     */     try {
/* 173 */       for (ErrorResponse.Interceptor handler : this.errorResponseInterceptors) {
/* 174 */         handler.handleError(detail, errorResponse);
/*     */       }
/*     */     }
/* 177 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> void writeWithMessageConverters(T value, MethodParameter returnType, NativeWebRequest webRequest) throws IOException, HttpMediaTypeNotAcceptableException, HttpMessageNotWritableException {
/* 189 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 190 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/* 191 */     writeWithMessageConverters(value, returnType, inputMessage, outputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> void writeWithMessageConverters(@Nullable T value, MethodParameter returnType, ServletServerHttpRequest inputMessage, ServletServerHttpResponse outputMessage) throws IOException, HttpMediaTypeNotAcceptableException, HttpMessageNotWritableException {
/*     */     Object object;
/*     */     Class<?> clazz;
/*     */     Type type;
/* 216 */     if (value instanceof CharSequence) {
/* 217 */       object = value.toString();
/* 218 */       clazz = String.class;
/* 219 */       type = String.class;
/*     */     } else {
/*     */       
/* 222 */       object = value;
/* 223 */       clazz = getReturnValueType(object, returnType);
/* 224 */       type = GenericTypeResolver.resolveType(getGenericType(returnType), returnType.getContainingClass());
/*     */     } 
/*     */     
/* 227 */     if (isResourceType(value, returnType)) {
/* 228 */       outputMessage.getHeaders().set("Accept-Ranges", "bytes");
/* 229 */       if (value != null && inputMessage.getHeaders().getFirst("Range") != null && outputMessage
/* 230 */         .getServletResponse().getStatus() == 200) {
/* 231 */         Resource resource = (Resource)value;
/*     */         try {
/* 233 */           List<HttpRange> httpRanges = inputMessage.getHeaders().getRange();
/* 234 */           outputMessage.getServletResponse().setStatus(HttpStatus.PARTIAL_CONTENT.value());
/* 235 */           object = HttpRange.toResourceRegions(httpRanges, resource);
/* 236 */           clazz = object.getClass();
/* 237 */           type = RESOURCE_REGION_LIST_TYPE;
/*     */         }
/* 239 */         catch (IllegalArgumentException ex) {
/* 240 */           outputMessage.getHeaders().set("Content-Range", "bytes */" + resource.contentLength());
/* 241 */           outputMessage.getServletResponse().setStatus(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE.value());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     MediaType selectedMediaType = null;
/* 247 */     MediaType contentType = outputMessage.getHeaders().getContentType();
/* 248 */     boolean isContentTypePreset = (contentType != null && contentType.isConcrete());
/* 249 */     if (isContentTypePreset) {
/* 250 */       if (this.logger.isDebugEnabled()) {
/* 251 */         this.logger.debug("Found 'Content-Type:" + String.valueOf(contentType) + "' in response");
/*     */       }
/* 253 */       selectedMediaType = contentType;
/*     */     } else {
/*     */       List<MediaType> acceptableTypes;
/* 256 */       HttpServletRequest request = inputMessage.getServletRequest();
/*     */       
/*     */       try {
/* 259 */         acceptableTypes = getAcceptableMediaTypes(request);
/*     */       }
/* 261 */       catch (HttpMediaTypeNotAcceptableException ex) {
/* 262 */         int series = outputMessage.getServletResponse().getStatus() / 100;
/* 263 */         if (object == null || series == 4 || series == 5) {
/* 264 */           if (this.logger.isDebugEnabled()) {
/* 265 */             this.logger.debug("Ignoring error response content (if any). " + String.valueOf(ex));
/*     */           }
/*     */           return;
/*     */         } 
/* 269 */         throw ex;
/*     */       } 
/*     */       
/* 272 */       List<MediaType> producibleTypes = getProducibleMediaTypes(request, clazz, type);
/* 273 */       if (object != null && producibleTypes.isEmpty()) {
/* 274 */         throw new HttpMessageNotWritableException("No converter found for return value of type: " + String.valueOf(clazz));
/*     */       }
/*     */ 
/*     */       
/* 278 */       List<MediaType> compatibleMediaTypes = new ArrayList<>();
/* 279 */       determineCompatibleMediaTypes(acceptableTypes, producibleTypes, compatibleMediaTypes);
/*     */ 
/*     */       
/* 282 */       if (compatibleMediaTypes.isEmpty() && ProblemDetail.class.isAssignableFrom(clazz)) {
/* 283 */         determineCompatibleMediaTypes(this.problemMediaTypes, producibleTypes, compatibleMediaTypes);
/*     */       }
/*     */       
/* 286 */       if (compatibleMediaTypes.isEmpty()) {
/* 287 */         if (this.logger.isDebugEnabled()) {
/* 288 */           this.logger.debug("No match for " + String.valueOf(acceptableTypes) + ", supported: " + String.valueOf(producibleTypes));
/*     */         }
/* 290 */         if (object != null) {
/* 291 */           throw new HttpMediaTypeNotAcceptableException(producibleTypes);
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 296 */       MimeTypeUtils.sortBySpecificity(compatibleMediaTypes);
/*     */       
/* 298 */       for (MediaType mediaType : compatibleMediaTypes) {
/* 299 */         if (mediaType.isConcrete()) {
/* 300 */           selectedMediaType = mediaType;
/*     */           break;
/*     */         } 
/* 303 */         if (mediaType.isPresentIn(ALL_APPLICATION_MEDIA_TYPES)) {
/* 304 */           selectedMediaType = MediaType.APPLICATION_OCTET_STREAM;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 309 */       if (this.logger.isDebugEnabled()) {
/* 310 */         this.logger.debug("Using '" + String.valueOf(selectedMediaType) + "', given " + String.valueOf(acceptableTypes) + " and supported " + String.valueOf(producibleTypes));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 315 */     if (selectedMediaType != null) {
/* 316 */       selectedMediaType = selectedMediaType.removeQualityValue();
/*     */       
/* 318 */       ResolvableType targetResolvableType = null;
/* 319 */       for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 320 */         AbstractMessageConverterMethodArgumentResolver.ConverterType converterTypeToUse = null;
/* 321 */         if (converter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter genericConverter = (GenericHttpMessageConverter)converter;
/* 322 */           if (genericConverter.canWrite(type, clazz, selectedMediaType)) {
/* 323 */             converterTypeToUse = AbstractMessageConverterMethodArgumentResolver.ConverterType.GENERIC;
/*     */           } }
/*     */         
/* 326 */         else if (converter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter smartConverter = (SmartHttpMessageConverter)converter;
/* 327 */           targetResolvableType = getNestedTypeIfNeeded(ResolvableType.forMethodParameter(returnType));
/* 328 */           if (smartConverter.canWrite(targetResolvableType, clazz, selectedMediaType)) {
/* 329 */             converterTypeToUse = AbstractMessageConverterMethodArgumentResolver.ConverterType.SMART;
/*     */           } }
/*     */         
/* 332 */         else if (converter.canWrite(clazz, selectedMediaType))
/* 333 */         { converterTypeToUse = AbstractMessageConverterMethodArgumentResolver.ConverterType.BASE; }
/*     */         
/* 335 */         if (converterTypeToUse != null) {
/* 336 */           object = getAdvice().beforeBodyWrite(object, returnType, selectedMediaType, (Class)converter
/* 337 */               .getClass(), (ServerHttpRequest)inputMessage, (ServerHttpResponse)outputMessage);
/* 338 */           if (object != null) {
/* 339 */             Object theBody = object;
/* 340 */             LogFormatUtils.traceDebug(this.logger, traceOn -> "Writing [" + LogFormatUtils.formatValue(theBody, !traceOn.booleanValue()) + "]");
/*     */             
/* 342 */             addContentDispositionHeader(inputMessage, outputMessage);
/* 343 */             switch (converterTypeToUse) { case BASE:
/* 344 */                 converter.write(object, selectedMediaType, (HttpOutputMessage)outputMessage); break;
/* 345 */               case GENERIC: ((GenericHttpMessageConverter)converter).write(object, type, selectedMediaType, (HttpOutputMessage)outputMessage); break;
/* 346 */               case SMART: ((SmartHttpMessageConverter)converter).write(object, targetResolvableType, selectedMediaType, (HttpOutputMessage)outputMessage, null);
/*     */                 break; }
/*     */ 
/*     */           
/* 350 */           } else if (this.logger.isDebugEnabled()) {
/* 351 */             this.logger.debug("Nothing to write: null body");
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 359 */     if (object != null) {
/*     */ 
/*     */       
/* 362 */       Set<MediaType> producibleMediaTypes = (Set<MediaType>)inputMessage.getServletRequest().getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/*     */       
/* 364 */       if (isContentTypePreset || !CollectionUtils.isEmpty(producibleMediaTypes)) {
/* 365 */         throw new HttpMessageNotWritableException("No converter for [" + String.valueOf(clazz) + "] with preset Content-Type '" + String.valueOf(contentType) + "'");
/*     */       }
/*     */       
/* 368 */       throw new HttpMediaTypeNotAcceptableException(getSupportedMediaTypes(object.getClass()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getReturnValueType(@Nullable Object value, MethodParameter returnType) {
/* 379 */     return (value != null) ? value.getClass() : returnType.getParameterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isResourceType(@Nullable Object value, MethodParameter returnType) {
/* 386 */     Class<?> clazz = getReturnValueType(value, returnType);
/* 387 */     return (clazz != InputStreamResource.class && Resource.class.isAssignableFrom(clazz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type getGenericType(MethodParameter returnType) {
/* 395 */     if (HttpEntity.class.isAssignableFrom(returnType.getParameterType())) {
/* 396 */       return ResolvableType.forType(returnType.getGenericParameterType()).getGeneric(new int[0]).getType();
/*     */     }
/*     */     
/* 399 */     return returnType.getGenericParameterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MediaType> getProducibleMediaTypes(HttpServletRequest request, Class<?> valueClass) {
/* 409 */     return getProducibleMediaTypes(request, valueClass, (Type)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MediaType> getProducibleMediaTypes(HttpServletRequest request, Class<?> valueClass, @Nullable Type targetType) {
/* 426 */     Set<MediaType> mediaTypes = (Set<MediaType>)request.getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/* 427 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 428 */       return new ArrayList<>(mediaTypes);
/*     */     }
/* 430 */     Set<MediaType> result = new LinkedHashSet<>();
/* 431 */     for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 432 */       if (converter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter<?> genericConverter = (GenericHttpMessageConverter)converter; if (targetType != null) {
/* 433 */           if (genericConverter.canWrite(targetType, valueClass, null))
/* 434 */             result.addAll(converter.getSupportedMediaTypes(valueClass));  continue;
/*     */         }  }
/*     */       
/* 437 */       if (converter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter<?> smartConverter = (SmartHttpMessageConverter)converter; if (targetType != null) {
/* 438 */           ResolvableType resolvableType = ResolvableType.forType(targetType);
/* 439 */           if (smartConverter.canWrite(resolvableType, valueClass, null))
/* 440 */             result.addAll(converter.getSupportedMediaTypes(valueClass));  continue;
/*     */         }  }
/*     */       
/* 443 */       if (converter.canWrite(valueClass, null)) {
/* 444 */         result.addAll(converter.getSupportedMediaTypes(valueClass));
/*     */       }
/*     */     } 
/* 447 */     return result.isEmpty() ? Collections.<MediaType>singletonList(MediaType.ALL) : new ArrayList<>(result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MediaType> getAcceptableMediaTypes(HttpServletRequest request) throws HttpMediaTypeNotAcceptableException {
/* 453 */     return this.contentNegotiationManager.resolveMediaTypes((NativeWebRequest)new ServletWebRequest(request));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void determineCompatibleMediaTypes(List<MediaType> acceptableTypes, List<MediaType> producibleTypes, List<MediaType> mediaTypesToUse) {
/* 459 */     for (MediaType requestedType : acceptableTypes) {
/* 460 */       for (MediaType producibleType : producibleTypes) {
/* 461 */         if (requestedType.isCompatibleWith(producibleType)) {
/* 462 */           mediaTypesToUse.add(getMostSpecificMediaType(requestedType, producibleType));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MediaType getMostSpecificMediaType(MediaType acceptType, MediaType produceType) {
/* 473 */     MediaType produceTypeToUse = produceType.copyQualityValue(acceptType);
/* 474 */     if (acceptType.isLessSpecific((MimeType)produceTypeToUse)) {
/* 475 */       return produceTypeToUse;
/*     */     }
/*     */     
/* 478 */     return acceptType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addContentDispositionHeader(ServletServerHttpRequest request, ServletServerHttpResponse response) {
/* 491 */     HttpHeaders headers = response.getHeaders();
/* 492 */     if (headers.containsKey("Content-Disposition")) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 497 */       int status = response.getServletResponse().getStatus();
/* 498 */       if (status < 200 || (status > 299 && status < 400)) {
/*     */         return;
/*     */       }
/*     */     }
/* 502 */     catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */     
/* 506 */     HttpServletRequest servletRequest = request.getServletRequest();
/* 507 */     String requestUri = UrlPathHelper.rawPathInstance.getOriginatingRequestUri(servletRequest);
/*     */     
/* 509 */     int index = requestUri.lastIndexOf('/') + 1;
/* 510 */     String filename = requestUri.substring(index);
/* 511 */     String pathParams = "";
/*     */     
/* 513 */     index = filename.indexOf(';');
/* 514 */     if (index != -1) {
/* 515 */       pathParams = filename.substring(index);
/* 516 */       filename = filename.substring(0, index);
/*     */     } 
/*     */     
/* 519 */     filename = UrlPathHelper.defaultInstance.decodeRequestString(servletRequest, filename);
/* 520 */     String ext = StringUtils.getFilenameExtension(filename);
/*     */     
/* 522 */     pathParams = UrlPathHelper.defaultInstance.decodeRequestString(servletRequest, pathParams);
/* 523 */     String extInPathParams = StringUtils.getFilenameExtension(pathParams);
/*     */     
/* 525 */     if (!safeExtension(servletRequest, ext) || !safeExtension(servletRequest, extInPathParams)) {
/* 526 */       headers.add("Content-Disposition", "inline;filename=f.txt");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean safeExtension(HttpServletRequest request, @Nullable String extension) {
/* 532 */     if (!StringUtils.hasText(extension)) {
/* 533 */       return true;
/*     */     }
/* 535 */     extension = extension.toLowerCase(Locale.ROOT);
/* 536 */     if (this.safeExtensions.contains(extension)) {
/* 537 */       return true;
/*     */     }
/* 539 */     String pattern = (String)request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
/* 540 */     if (pattern != null && pattern.endsWith("." + extension)) {
/* 541 */       return true;
/*     */     }
/* 543 */     if (extension.equals("html")) {
/* 544 */       String name = HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE;
/* 545 */       Set<MediaType> mediaTypes = (Set<MediaType>)request.getAttribute(name);
/* 546 */       if (!CollectionUtils.isEmpty(mediaTypes) && mediaTypes.contains(MediaType.TEXT_HTML)) {
/* 547 */         return true;
/*     */       }
/*     */     } 
/* 550 */     MediaType mediaType = resolveMediaType((ServletRequest)request, extension);
/* 551 */     return (mediaType != null && safeMediaType(mediaType));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private MediaType resolveMediaType(ServletRequest request, String extension) {
/* 556 */     MediaType result = null;
/* 557 */     String rawMimeType = request.getServletContext().getMimeType("file." + extension);
/* 558 */     if (StringUtils.hasText(rawMimeType)) {
/* 559 */       result = MediaType.parseMediaType(rawMimeType);
/*     */     }
/* 561 */     if (result == null || MediaType.APPLICATION_OCTET_STREAM.equals(result)) {
/* 562 */       result = MediaTypeFactory.getMediaType("file." + extension).orElse(null);
/*     */     }
/* 564 */     return result;
/*     */   }
/*     */   
/*     */   private boolean safeMediaType(MediaType mediaType) {
/* 568 */     return (SAFE_MEDIA_BASE_TYPES.contains(mediaType.getType()) || mediaType
/* 569 */       .getSubtype().endsWith("+xml"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\AbstractMessageConverterMethodProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */