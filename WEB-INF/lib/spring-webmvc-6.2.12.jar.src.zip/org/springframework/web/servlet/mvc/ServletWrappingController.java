/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletConfig;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletWrappingController
/*     */   extends AbstractController
/*     */   implements BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private Class<? extends Servlet> servletClass;
/*     */   @Nullable
/*     */   private String servletName;
/*  95 */   private Properties initParameters = new Properties();
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */   
/*     */   @Nullable
/*     */   private Servlet servletInstance;
/*     */ 
/*     */   
/*     */   public ServletWrappingController() {
/* 105 */     super(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletClass(Class<? extends Servlet> servletClass) {
/* 115 */     this.servletClass = servletClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletName(String servletName) {
/* 123 */     this.servletName = servletName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitParameters(Properties initParameters) {
/* 131 */     this.initParameters = initParameters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String name) {
/* 136 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 146 */     if (this.servletClass == null) {
/* 147 */       throw new IllegalArgumentException("'servletClass' is required");
/*     */     }
/* 149 */     if (this.servletName == null) {
/* 150 */       this.servletName = this.beanName;
/*     */     }
/* 152 */     this.servletInstance = ReflectionUtils.accessibleConstructor(this.servletClass, new Class[0]).newInstance(new Object[0]);
/* 153 */     this.servletInstance.init(new DelegatingServletConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 166 */     Assert.state((this.servletInstance != null), "No Servlet instance");
/* 167 */     this.servletInstance.service((ServletRequest)request, (ServletResponse)response);
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 178 */     if (this.servletInstance != null) {
/* 179 */       this.servletInstance.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class DelegatingServletConfig
/*     */     implements ServletConfig
/*     */   {
/*     */     @Nullable
/*     */     public String getServletName() {
/* 194 */       return ServletWrappingController.this.servletName;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ServletContext getServletContext() {
/* 200 */       return ServletWrappingController.this.getServletContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getInitParameter(String paramName) {
/* 205 */       return ServletWrappingController.this.initParameters.getProperty(paramName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Enumeration<String> getInitParameterNames() {
/* 211 */       return (Enumeration)ServletWrappingController.this.initParameters.keys();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\ServletWrappingController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */