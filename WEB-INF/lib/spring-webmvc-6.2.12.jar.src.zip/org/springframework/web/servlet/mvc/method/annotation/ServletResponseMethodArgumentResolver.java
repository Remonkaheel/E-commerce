/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Writer;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletResponseMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter) {
/* 50 */     Class<?> paramType = parameter.getParameterType();
/* 51 */     return (ServletResponse.class.isAssignableFrom(paramType) || OutputStream.class
/* 52 */       .isAssignableFrom(paramType) || Writer.class
/* 53 */       .isAssignableFrom(paramType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory) throws Exception {
/* 66 */     if (mavContainer != null) {
/* 67 */       mavContainer.setRequestHandled(true);
/*    */     }
/*    */     
/* 70 */     Class<?> paramType = parameter.getParameterType();
/*    */ 
/*    */     
/* 73 */     if (ServletResponse.class.isAssignableFrom(paramType)) {
/* 74 */       return resolveNativeResponse(webRequest, paramType);
/*    */     }
/*    */ 
/*    */     
/* 78 */     return resolveArgument(paramType, resolveNativeResponse(webRequest, ServletResponse.class));
/*    */   }
/*    */   
/*    */   private <T> T resolveNativeResponse(NativeWebRequest webRequest, Class<T> requiredType) {
/* 82 */     T nativeResponse = (T)webRequest.getNativeResponse(requiredType);
/* 83 */     if (nativeResponse == null) {
/* 84 */       throw new IllegalStateException("Current response is not of type [" + requiredType
/* 85 */           .getName() + "]: " + String.valueOf(webRequest));
/*    */     }
/* 87 */     return nativeResponse;
/*    */   }
/*    */   
/*    */   private Object resolveArgument(Class<?> paramType, ServletResponse response) throws IOException {
/* 91 */     if (OutputStream.class.isAssignableFrom(paramType)) {
/* 92 */       return response.getOutputStream();
/*    */     }
/* 94 */     if (Writer.class.isAssignableFrom(paramType)) {
/* 95 */       return response.getWriter();
/*    */     }
/*    */ 
/*    */     
/* 99 */     throw new UnsupportedOperationException("Unknown parameter type: " + String.valueOf(paramType));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletResponseMethodArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */