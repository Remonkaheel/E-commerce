/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizableViewController
/*     */   extends AbstractController
/*     */ {
/*     */   @Nullable
/*     */   private Object view;
/*     */   @Nullable
/*     */   private HttpStatusCode statusCode;
/*     */   private boolean statusOnly;
/*     */   
/*     */   public ParameterizableViewController() {
/*  52 */     super(false);
/*  53 */     setSupportedMethods(new String[] { HttpMethod.GET.name(), HttpMethod.HEAD.name() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewName(@Nullable String viewName) {
/*  62 */     this.view = viewName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getViewName() {
/*  71 */     Object object = this.view; if (object instanceof String) { String viewName = (String)object;
/*  72 */       if (getStatusCode() != null && getStatusCode().is3xxRedirection()) {
/*  73 */         return viewName.startsWith("redirect:") ? viewName : ("redirect:" + viewName);
/*     */       }
/*     */       
/*  76 */       return viewName; }
/*     */ 
/*     */     
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setView(View view) {
/*  88 */     this.view = view;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public View getView() {
/*  98 */     Object object = this.view; View v = (View)object; return (object instanceof View) ? v : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusCode(@Nullable HttpStatusCode statusCode) {
/* 113 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HttpStatusCode getStatusCode() {
/* 122 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusOnly(boolean statusOnly) {
/* 134 */     this.statusOnly = statusOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatusOnly() {
/* 141 */     return this.statusOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 156 */     String viewName = getViewName();
/*     */     
/* 158 */     if (getStatusCode() != null) {
/* 159 */       if (getStatusCode().is3xxRedirection()) {
/* 160 */         request.setAttribute(View.RESPONSE_STATUS_ATTRIBUTE, getStatusCode());
/*     */       } else {
/*     */         
/* 163 */         response.setStatus(getStatusCode().value());
/* 164 */         if (getStatusCode().equals(HttpStatus.NO_CONTENT) && viewName == null) {
/* 165 */           return null;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 170 */     if (isStatusOnly()) {
/* 171 */       return null;
/*     */     }
/*     */     
/* 174 */     ModelAndView modelAndView = new ModelAndView();
/* 175 */     modelAndView.addAllObjects(RequestContextUtils.getInputFlashMap(request));
/* 176 */     if (viewName != null) {
/* 177 */       modelAndView.setViewName(viewName);
/*     */     } else {
/*     */       
/* 180 */       modelAndView.setView(getView());
/*     */     } 
/* 182 */     return modelAndView;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     return "ParameterizableViewController [" + formatStatusAndView() + "]";
/*     */   }
/*     */   
/*     */   private String formatStatusAndView() {
/* 191 */     StringBuilder sb = new StringBuilder();
/* 192 */     if (this.statusCode != null) {
/* 193 */       sb.append("status=").append(this.statusCode);
/*     */     }
/* 195 */     if (this.view != null) {
/* 196 */       sb.append((sb.length() != 0) ? ", " : "");
/* 197 */       String viewName = getViewName();
/* 198 */       sb.append("view=").append((viewName != null) ? ("\"" + viewName + "\"") : this.view);
/*     */     } 
/* 200 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\ParameterizableViewController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */