/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParamExpression
/*     */   extends AbstractNameValueExpression<String>
/*     */ {
/* 156 */   private final Set<String> namesToMatch = new HashSet<>(WebUtils.SUBMIT_IMAGE_SUFFIXES.length + 1);
/*     */ 
/*     */   
/*     */   ParamExpression(String expression) {
/* 160 */     super(expression);
/* 161 */     this.namesToMatch.add(getName());
/* 162 */     for (String suffix : WebUtils.SUBMIT_IMAGE_SUFFIXES) {
/* 163 */       this.namesToMatch.add(getName() + getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCaseSensitiveName() {
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String parseValue(String valueExpression) {
/* 174 */     return valueExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchName(HttpServletRequest request) {
/* 179 */     for (String current : this.namesToMatch) {
/* 180 */       if (request.getParameterMap().get(current) != null) {
/* 181 */         return true;
/*     */       }
/*     */     } 
/* 184 */     return request.getParameterMap().containsKey(this.name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchValue(HttpServletRequest request) {
/* 189 */     return ObjectUtils.nullSafeEquals(this.value, request.getParameter(this.name));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\ParamsRequestCondition$ParamExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */