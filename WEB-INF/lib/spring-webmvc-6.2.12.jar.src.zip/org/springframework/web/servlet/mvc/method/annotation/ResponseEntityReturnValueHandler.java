/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.http.HttpEntity;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResponseEntityReturnValueHandler
/*    */   implements HandlerMethodReturnValueHandler
/*    */ {
/*    */   private final HttpEntityMethodProcessor httpEntityMethodProcessor;
/*    */   private final ResponseBodyEmitterReturnValueHandler responseBodyEmitterHandler;
/*    */   
/*    */   public ResponseEntityReturnValueHandler(HttpEntityMethodProcessor httpEntityMethodProcessor, ResponseBodyEmitterReturnValueHandler responseBodyEmitterHandler) {
/* 54 */     this.httpEntityMethodProcessor = httpEntityMethodProcessor;
/* 55 */     this.responseBodyEmitterHandler = responseBodyEmitterHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supportsReturnType(MethodParameter returnType) {
/* 61 */     return this.httpEntityMethodProcessor.supportsReturnType(returnType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest request) throws Exception {
/* 69 */     if (returnValue instanceof HttpEntity) { HttpEntity<?> httpEntity = (HttpEntity)returnValue;
/* 70 */       Object body = httpEntity.getBody();
/* 71 */       if (body != null && 
/* 72 */         this.responseBodyEmitterHandler.supportsBodyType(body.getClass())) {
/* 73 */         this.responseBodyEmitterHandler.handleReturnValue(returnValue, returnType, mavContainer, request);
/*    */         
/*    */         return;
/*    */       }  }
/*    */ 
/*    */     
/* 79 */     this.httpEntityMethodProcessor.handleReturnValue(returnValue, returnType, mavContainer, request);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseEntityReturnValueHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */