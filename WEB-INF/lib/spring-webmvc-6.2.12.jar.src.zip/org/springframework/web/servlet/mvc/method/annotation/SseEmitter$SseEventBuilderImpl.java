/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SseEventBuilderImpl
/*     */   implements SseEmitter.SseEventBuilder
/*     */ {
/* 196 */   private final Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = new LinkedHashSet<>(4);
/*     */   
/*     */   @Nullable
/*     */   private StringBuilder sb;
/*     */   
/*     */   private boolean hasName;
/*     */ 
/*     */   
/*     */   public SseEmitter.SseEventBuilder id(String id) {
/* 205 */     append("id:").append(id).append('\n');
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SseEmitter.SseEventBuilder name(String name) {
/* 211 */     this.hasName = true;
/* 212 */     append("event:").append(name).append('\n');
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SseEmitter.SseEventBuilder reconnectTime(long reconnectTimeMillis) {
/* 218 */     append("retry:").append(String.valueOf(reconnectTimeMillis)).append('\n');
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SseEmitter.SseEventBuilder comment(String comment) {
/* 224 */     append(':').append(comment).append('\n');
/* 225 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SseEmitter.SseEventBuilder data(Object object) {
/* 230 */     return data(object, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public SseEmitter.SseEventBuilder data(Object object, @Nullable MediaType mediaType) {
/* 235 */     if (object instanceof ModelAndView) { ModelAndView mav = (ModelAndView)object; if (!this.hasName && mav.getViewName() != null)
/* 236 */         name(mav.getViewName());  }
/*     */     
/* 238 */     append("data:");
/* 239 */     saveAppendedText();
/* 240 */     if (object instanceof String) { String text = (String)object;
/* 241 */       object = StringUtils.replace(text, "\n", "\ndata:"); }
/*     */     
/* 243 */     this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(object, mediaType));
/* 244 */     append('\n');
/* 245 */     return this;
/*     */   }
/*     */   
/*     */   SseEventBuilderImpl append(String text) {
/* 249 */     if (this.sb == null) {
/* 250 */       this.sb = new StringBuilder();
/*     */     }
/* 252 */     this.sb.append(text);
/* 253 */     return this;
/*     */   }
/*     */   
/*     */   SseEventBuilderImpl append(char ch) {
/* 257 */     if (this.sb == null) {
/* 258 */       this.sb = new StringBuilder();
/*     */     }
/* 260 */     this.sb.append(ch);
/* 261 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<ResponseBodyEmitter.DataWithMediaType> build() {
/* 266 */     if (!StringUtils.hasLength(this.sb) && this.dataToSend.isEmpty()) {
/* 267 */       return Collections.emptySet();
/*     */     }
/* 269 */     append('\n');
/* 270 */     saveAppendedText();
/* 271 */     return this.dataToSend;
/*     */   }
/*     */   
/*     */   private void saveAppendedText() {
/* 275 */     if (this.sb != null) {
/* 276 */       this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(this.sb.toString(), SseEmitter.TEXT_PLAIN));
/* 277 */       this.sb = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\SseEmitter$SseEventBuilderImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */