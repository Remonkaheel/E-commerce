package org.springframework.web.servlet.mvc.method;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.condition.RequestCondition;

public interface Builder {
  Builder paths(String... paramVarArgs);
  
  Builder methods(RequestMethod... paramVarArgs);
  
  Builder params(String... paramVarArgs);
  
  Builder headers(String... paramVarArgs);
  
  Builder consumes(String... paramVarArgs);
  
  Builder produces(String... paramVarArgs);
  
  Builder mappingName(String paramString);
  
  Builder customCondition(RequestCondition<?> paramRequestCondition);
  
  Builder options(RequestMappingInfo.BuilderConfiguration paramBuilderConfiguration);
  
  RequestMappingInfo build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\RequestMappingInfo$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */