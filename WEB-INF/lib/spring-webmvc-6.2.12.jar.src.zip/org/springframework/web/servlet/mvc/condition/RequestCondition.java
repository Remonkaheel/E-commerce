package org.springframework.web.servlet.mvc.condition;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.lang.Nullable;

public interface RequestCondition<T> {
  T combine(T paramT);
  
  @Nullable
  T getMatchingCondition(HttpServletRequest paramHttpServletRequest);
  
  int compareTo(T paramT, HttpServletRequest paramHttpServletRequest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\RequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */