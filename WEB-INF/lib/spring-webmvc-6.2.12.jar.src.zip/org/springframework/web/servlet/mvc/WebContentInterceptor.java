/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebContentInterceptor
/*     */   extends WebContentGenerator
/*     */   implements HandlerInterceptor
/*     */ {
/*  76 */   private static PathMatcher defaultPathMatcher = (PathMatcher)new AntPathMatcher();
/*     */ 
/*     */   
/*     */   private final PathPatternParser patternParser;
/*     */   
/*  81 */   private PathMatcher pathMatcher = defaultPathMatcher;
/*     */   
/*  83 */   private final Map<PathPattern, Integer> cacheMappings = new HashMap<>();
/*     */   
/*  85 */   private final Map<PathPattern, CacheControl> cacheControlMappings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebContentInterceptor() {
/*  92 */     this(PathPatternParser.defaultInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebContentInterceptor(PathPatternParser parser) {
/* 102 */     super(false);
/* 103 */     this.patternParser = parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setUrlDecode(boolean urlDecode) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathMatcher(PathMatcher pathMatcher) {
/* 153 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 154 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheMappings(Properties cacheMappings) {
/* 173 */     this.cacheMappings.clear();
/* 174 */     Enumeration<?> propNames = cacheMappings.propertyNames();
/* 175 */     while (propNames.hasMoreElements()) {
/* 176 */       String path = (String)propNames.nextElement();
/* 177 */       int cacheSeconds = Integer.parseInt(cacheMappings.getProperty(path));
/* 178 */       this.cacheMappings.put(this.patternParser.parse(path), Integer.valueOf(cacheSeconds));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCacheMapping(CacheControl cacheControl, String... paths) {
/* 200 */     for (String path : paths) {
/* 201 */       this.cacheControlMappings.put(this.patternParser.parse(path), cacheControl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException {
/* 210 */     checkRequest(request);
/*     */     
/* 212 */     Object path = ServletRequestPathUtils.getCachedPath((ServletRequest)request);
/* 213 */     if (this.pathMatcher != defaultPathMatcher) {
/* 214 */       path = path.toString();
/*     */     }
/*     */     
/* 217 */     if (!ObjectUtils.isEmpty(this.cacheControlMappings)) {
/* 218 */       PathContainer pathContainer = (PathContainer)path;
/* 219 */       CacheControl control = (path instanceof PathContainer) ? lookupCacheControl(pathContainer) : lookupCacheControl((String)path);
/* 220 */       if (control != null) {
/* 221 */         if (this.logger.isTraceEnabled()) {
/* 222 */           this.logger.trace("Applying " + String.valueOf(control));
/*     */         }
/* 224 */         applyCacheControl(response, control);
/* 225 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     if (!ObjectUtils.isEmpty(this.cacheMappings)) {
/* 230 */       PathContainer pathContainer = (PathContainer)path;
/* 231 */       Integer cacheSeconds = (path instanceof PathContainer) ? lookupCacheSeconds(pathContainer) : lookupCacheSeconds((String)path);
/* 232 */       if (cacheSeconds != null) {
/* 233 */         if (this.logger.isTraceEnabled()) {
/* 234 */           this.logger.trace("Applying cacheSeconds " + cacheSeconds);
/*     */         }
/* 236 */         applyCacheSeconds(response, cacheSeconds.intValue());
/* 237 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 241 */     prepareResponse(response);
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CacheControl lookupCacheControl(PathContainer path) {
/* 255 */     for (Map.Entry<PathPattern, CacheControl> entry : this.cacheControlMappings.entrySet()) {
/* 256 */       if (((PathPattern)entry.getKey()).matches(path)) {
/* 257 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CacheControl lookupCacheControl(String lookupPath) {
/* 272 */     for (Map.Entry<PathPattern, CacheControl> entry : this.cacheControlMappings.entrySet()) {
/* 273 */       if (this.pathMatcher.match(((PathPattern)entry.getKey()).getPatternString(), lookupPath)) {
/* 274 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 277 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Integer lookupCacheSeconds(PathContainer path) {
/* 289 */     for (Map.Entry<PathPattern, Integer> entry : this.cacheMappings.entrySet()) {
/* 290 */       if (((PathPattern)entry.getKey()).matches(path)) {
/* 291 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 294 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Integer lookupCacheSeconds(String lookupPath) {
/* 306 */     for (Map.Entry<PathPattern, Integer> entry : this.cacheMappings.entrySet()) {
/* 307 */       if (this.pathMatcher.match(((PathPattern)entry.getKey()).getPatternString(), lookupPath)) {
/* 308 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 311 */     return null;
/*     */   }
/*     */   
/*     */   public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {}
/*     */   
/*     */   public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\WebContentInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */