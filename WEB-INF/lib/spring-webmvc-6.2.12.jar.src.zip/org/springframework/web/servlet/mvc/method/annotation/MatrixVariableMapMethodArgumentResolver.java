/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.MatrixVariable;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MatrixVariableMapMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/*  55 */     MatrixVariable matrixVariable = (MatrixVariable)parameter.getParameterAnnotation(MatrixVariable.class);
/*  56 */     return (matrixVariable != null && Map.class.isAssignableFrom(parameter.getParameterType()) && 
/*  57 */       !StringUtils.hasText(matrixVariable.name()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest request, @Nullable WebDataBinderFactory binderFactory) throws Exception {
/*  67 */     Map<String, MultiValueMap<String, String>> matrixVariables = (Map<String, MultiValueMap<String, String>>)request.getAttribute(HandlerMapping.MATRIX_VARIABLES_ATTRIBUTE, 0);
/*     */ 
/*     */     
/*  70 */     MultiValueMap<String, String> map = mapMatrixVariables(parameter, matrixVariables);
/*  71 */     return isSingleValueMap(parameter) ? map.toSingleValueMap() : map;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MultiValueMap<String, String> mapMatrixVariables(MethodParameter parameter, @Nullable Map<String, MultiValueMap<String, String>> matrixVariables) {
/*  77 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*  78 */     if (CollectionUtils.isEmpty(matrixVariables)) {
/*  79 */       return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */     }
/*  81 */     MatrixVariable ann = (MatrixVariable)parameter.getParameterAnnotation(MatrixVariable.class);
/*  82 */     Assert.state((ann != null), "No MatrixVariable annotation");
/*  83 */     String pathVariable = ann.pathVar();
/*     */     
/*  85 */     if (!pathVariable.equals("\n\t\t\n\t\t\n\n\t\t\t\t\n")) {
/*  86 */       MultiValueMap<String, String> mapForPathVariable = matrixVariables.get(pathVariable);
/*  87 */       if (mapForPathVariable == null) {
/*  88 */         return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */       }
/*  90 */       linkedMultiValueMap.putAll((Map)mapForPathVariable);
/*     */     } else {
/*     */       
/*  93 */       for (MultiValueMap<String, String> vars : matrixVariables.values()) {
/*  94 */         vars.forEach((name, values) -> {
/*     */               for (String value : values) {
/*     */                 map.add(name, value);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/* 101 */     return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */   }
/*     */   
/*     */   private boolean isSingleValueMap(MethodParameter parameter) {
/* 105 */     if (!MultiValueMap.class.isAssignableFrom(parameter.getParameterType())) {
/* 106 */       ResolvableType[] genericTypes = ResolvableType.forMethodParameter(parameter).getGenerics();
/* 107 */       if (genericTypes.length == 2) {
/* 108 */         return !List.class.isAssignableFrom(genericTypes[1].toClass());
/*     */       }
/*     */     } 
/* 111 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\MatrixVariableMapMethodArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */