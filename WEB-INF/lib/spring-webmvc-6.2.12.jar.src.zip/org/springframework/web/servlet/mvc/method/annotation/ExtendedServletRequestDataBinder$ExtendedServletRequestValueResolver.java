/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExtendedServletRequestValueResolver
/*     */   extends ServletRequestDataBinder.ServletRequestValueResolver
/*     */ {
/*     */   ExtendedServletRequestValueResolver(ServletRequest request, WebDataBinder dataBinder) {
/* 188 */     super(request, dataBinder);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getRequestParameter(String name, Class<?> type) {
/* 194 */     Object value = super.getRequestParameter(name, type);
/* 195 */     if (value == null) {
/* 196 */       Map<String, String> uriVars = ExtendedServletRequestDataBinder.getUriVars(getRequest());
/* 197 */       if (uriVars != null) {
/* 198 */         value = uriVars.get(name);
/*     */       }
/* 200 */       if (value == null) { ServletRequest servletRequest = getRequest(); if (servletRequest instanceof HttpServletRequest) { HttpServletRequest httpServletRequest = (HttpServletRequest)servletRequest;
/* 201 */           value = ExtendedServletRequestDataBinder.this.getHeaderValue(httpServletRequest, name); }
/*     */          }
/*     */     
/* 204 */     }  return value;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<String> initParameterNames(ServletRequest request) {
/* 209 */     Set<String> set = super.initParameterNames(request);
/* 210 */     Map<String, String> uriVars = ExtendedServletRequestDataBinder.getUriVars(getRequest());
/* 211 */     if (uriVars != null) {
/* 212 */       set.addAll(uriVars.keySet());
/*     */     }
/* 214 */     if (request instanceof HttpServletRequest) { HttpServletRequest httpServletRequest = (HttpServletRequest)request;
/* 215 */       Enumeration<String> enumeration = httpServletRequest.getHeaderNames();
/* 216 */       while (enumeration.hasMoreElements()) {
/* 217 */         String name = enumeration.nextElement();
/* 218 */         if (ExtendedServletRequestDataBinder.this.headerPredicate.test(name)) {
/* 219 */           set.add(ExtendedServletRequestDataBinder.normalizeHeaderName(name));
/*     */         }
/*     */       }  }
/*     */     
/* 223 */     return set;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ExtendedServletRequestDataBinder$ExtendedServletRequestValueResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */