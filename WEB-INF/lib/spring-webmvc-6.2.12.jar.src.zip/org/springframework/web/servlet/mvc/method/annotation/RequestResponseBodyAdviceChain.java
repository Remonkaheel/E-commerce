/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServerHttpRequest;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RequestResponseBodyAdviceChain
/*     */   implements RequestBodyAdvice, ResponseBodyAdvice<Object>
/*     */ {
/*  45 */   private final List<Object> requestBodyAdvice = new ArrayList(4);
/*     */   
/*  47 */   private final List<Object> responseBodyAdvice = new ArrayList(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestResponseBodyAdviceChain(@Nullable List<Object> requestResponseBodyAdvice) {
/*  55 */     this.requestBodyAdvice.addAll(getAdviceByType(requestResponseBodyAdvice, RequestBodyAdvice.class));
/*  56 */     this.responseBodyAdvice.addAll(getAdviceByType(requestResponseBodyAdvice, ResponseBodyAdvice.class));
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> List<T> getAdviceByType(@Nullable List<Object> requestResponseBodyAdvice, Class<T> adviceType) {
/*  61 */     if (requestResponseBodyAdvice != null) {
/*  62 */       List<T> result = new ArrayList<>();
/*  63 */       for (Object advice : requestResponseBodyAdvice) {
/*  64 */         ControllerAdviceBean adviceBean = (ControllerAdviceBean)advice;
/*  65 */         Class<?> beanType = (advice instanceof ControllerAdviceBean) ? adviceBean.getBeanType() : advice.getClass();
/*  66 */         if (beanType != null && adviceType.isAssignableFrom(beanType)) {
/*  67 */           result.add((T)advice);
/*     */         }
/*     */       } 
/*  70 */       return result;
/*     */     } 
/*  72 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(MethodParameter param, Type type, Class<? extends HttpMessageConverter<?>> converterType) {
/*  78 */     throw new UnsupportedOperationException("Not implemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
/*  83 */     throw new UnsupportedOperationException("Not implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpInputMessage beforeBodyRead(HttpInputMessage request, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) throws IOException {
/*  90 */     for (RequestBodyAdvice advice : getMatchingAdvice(parameter, RequestBodyAdvice.class)) {
/*  91 */       if (advice.supports(parameter, targetType, converterType)) {
/*  92 */         request = advice.beforeBodyRead(request, parameter, targetType, converterType);
/*     */       }
/*     */     } 
/*  95 */     return request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
/* 102 */     for (RequestBodyAdvice advice : getMatchingAdvice(parameter, RequestBodyAdvice.class)) {
/* 103 */       if (advice.supports(parameter, targetType, converterType)) {
/* 104 */         body = advice.afterBodyRead(body, inputMessage, parameter, targetType, converterType);
/*     */       }
/*     */     } 
/* 107 */     return body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object beforeBodyWrite(@Nullable Object body, MethodParameter returnType, MediaType contentType, Class<? extends HttpMessageConverter<?>> converterType, ServerHttpRequest request, ServerHttpResponse response) {
/* 116 */     return processBody(body, returnType, contentType, converterType, request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object handleEmptyBody(@Nullable Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
/* 124 */     for (RequestBodyAdvice advice : getMatchingAdvice(parameter, RequestBodyAdvice.class)) {
/* 125 */       if (advice.supports(parameter, targetType, converterType)) {
/* 126 */         body = advice.handleEmptyBody(body, inputMessage, parameter, targetType, converterType);
/*     */       }
/*     */     } 
/* 129 */     return body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private <T> Object processBody(@Nullable Object body, MethodParameter returnType, MediaType contentType, Class<? extends HttpMessageConverter<?>> converterType, ServerHttpRequest request, ServerHttpResponse response) {
/* 139 */     for (ResponseBodyAdvice<?> advice : getMatchingAdvice(returnType, ResponseBodyAdvice.class)) {
/* 140 */       if (advice.supports(returnType, converterType)) {
/* 141 */         body = advice.beforeBodyWrite(body, returnType, contentType, converterType, request, response);
/*     */       }
/*     */     } 
/*     */     
/* 145 */     return body;
/*     */   }
/*     */ 
/*     */   
/*     */   private <A> List<A> getMatchingAdvice(MethodParameter parameter, Class<? extends A> adviceType) {
/* 150 */     List<Object> availableAdvice = getAdvice(adviceType);
/* 151 */     if (CollectionUtils.isEmpty(availableAdvice)) {
/* 152 */       return Collections.emptyList();
/*     */     }
/* 154 */     List<A> result = new ArrayList<>(availableAdvice.size());
/* 155 */     for (Object advice : availableAdvice) {
/* 156 */       if (advice instanceof ControllerAdviceBean) { ControllerAdviceBean adviceBean = (ControllerAdviceBean)advice;
/* 157 */         if (!adviceBean.isApplicableToBeanType(parameter.getContainingClass())) {
/*     */           continue;
/*     */         }
/* 160 */         advice = adviceBean.resolveBean(); }
/*     */       
/* 162 */       if (adviceType.isAssignableFrom(advice.getClass())) {
/* 163 */         result.add((A)advice);
/*     */       }
/*     */     } 
/* 166 */     return result;
/*     */   }
/*     */   
/*     */   private List<Object> getAdvice(Class<?> adviceType) {
/* 170 */     if (RequestBodyAdvice.class == adviceType) {
/* 171 */       return this.requestBodyAdvice;
/*     */     }
/* 173 */     if (ResponseBodyAdvice.class == adviceType) {
/* 174 */       return this.responseBodyAdvice;
/*     */     }
/*     */     
/* 177 */     throw new IllegalArgumentException("Unexpected adviceType: " + String.valueOf(adviceType));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestResponseBodyAdviceChain.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */