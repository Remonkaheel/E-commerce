/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestResponseBodyMethodProcessor
/*     */   extends AbstractMessageConverterMethodProcessor
/*     */ {
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters) {
/*  75 */     super(converters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager) {
/*  87 */     super(converters, manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable List<Object> requestResponseBodyAdvice) {
/*  99 */     super(converters, (ContentNegotiationManager)null, requestResponseBodyAdvice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, @Nullable List<Object> requestResponseBodyAdvice) {
/* 110 */     super(converters, manager, requestResponseBodyAdvice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, List<Object> requestResponseBodyAdvice, List<ErrorResponse.Interceptor> interceptors) {
/* 123 */     super(converters, manager, requestResponseBodyAdvice, interceptors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/* 129 */     return parameter.hasParameterAnnotation(RequestBody.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsReturnType(MethodParameter returnType) {
/* 134 */     return (AnnotatedElementUtils.hasAnnotation(returnType.getContainingClass(), ResponseBody.class) || returnType
/* 135 */       .hasMethodAnnotation(ResponseBody.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory) throws Exception {
/* 149 */     parameter = parameter.nestedIfOptional();
/* 150 */     Object arg = readWithMessageConverters(webRequest, parameter, parameter.getNestedGenericParameterType());
/*     */     
/* 152 */     if (binderFactory != null) {
/* 153 */       String name = Conventions.getVariableNameForParameter(parameter);
/* 154 */       ResolvableType type = ResolvableType.forMethodParameter(parameter);
/* 155 */       WebDataBinder binder = binderFactory.createBinder(webRequest, arg, name, type);
/* 156 */       if (arg != null) {
/* 157 */         validateIfApplicable(binder, parameter);
/* 158 */         if (binder.getBindingResult().hasErrors() && isBindExceptionRequired(binder, parameter)) {
/* 159 */           throw new MethodArgumentNotValidException(parameter, binder.getBindingResult());
/*     */         }
/*     */       } 
/* 162 */       if (mavContainer != null) {
/* 163 */         mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + BindingResult.MODEL_KEY_PREFIX, binder.getBindingResult());
/*     */       }
/*     */     } 
/*     */     
/* 167 */     return adaptArgumentIfNecessary(arg, parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object readWithMessageConverters(NativeWebRequest webRequest, MethodParameter parameter, Type paramType) throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException {
/* 175 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 176 */     Object arg = readWithMessageConverters((HttpInputMessage)inputMessage, parameter, paramType);
/* 177 */     if (arg == null && checkRequired(parameter)) {
/* 178 */       throw new HttpMessageNotReadableException("Required request body is missing: " + parameter
/* 179 */           .getExecutable().toGenericString(), inputMessage);
/*     */     }
/* 181 */     return arg;
/*     */   }
/*     */   
/*     */   protected boolean checkRequired(MethodParameter parameter) {
/* 185 */     RequestBody requestBody = (RequestBody)parameter.getParameterAnnotation(RequestBody.class);
/* 186 */     return (requestBody != null && requestBody.required() && !parameter.isOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws IOException, HttpMediaTypeNotAcceptableException, HttpMessageNotWritableException {
/* 194 */     mavContainer.setRequestHandled(true);
/* 195 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 196 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/*     */     
/* 198 */     if (returnValue instanceof ProblemDetail) { ProblemDetail detail = (ProblemDetail)returnValue;
/* 199 */       outputMessage.setStatusCode(HttpStatusCode.valueOf(detail.getStatus()));
/* 200 */       if (detail.getInstance() == null) {
/* 201 */         URI path = URI.create(inputMessage.getServletRequest().getRequestURI());
/* 202 */         detail.setInstance(path);
/*     */       } 
/* 204 */       invokeErrorResponseInterceptors(detail, (ErrorResponse)null); }
/*     */ 
/*     */ 
/*     */     
/* 208 */     writeWithMessageConverters(returnValue, returnType, inputMessage, outputMessage);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestResponseBodyMethodProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */