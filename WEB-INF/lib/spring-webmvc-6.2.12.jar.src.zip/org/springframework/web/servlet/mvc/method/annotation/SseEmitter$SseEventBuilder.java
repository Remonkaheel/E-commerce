package org.springframework.web.servlet.mvc.method.annotation;

import java.util.Set;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;

public interface SseEventBuilder {
  SseEventBuilder id(String paramString);
  
  SseEventBuilder name(String paramString);
  
  SseEventBuilder reconnectTime(long paramLong);
  
  SseEventBuilder comment(String paramString);
  
  SseEventBuilder data(Object paramObject);
  
  SseEventBuilder data(Object paramObject, @Nullable MediaType paramMediaType);
  
  Set<ResponseBodyEmitter.DataWithMediaType> build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\SseEmitter$SseEventBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */