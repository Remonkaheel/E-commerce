package org.springframework.web.servlet.mvc.method.annotation;

import java.io.IOException;
import java.io.OutputStream;

@FunctionalInterface
public interface StreamingResponseBody {
  void writeTo(OutputStream paramOutputStream) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\StreamingResponseBody.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */