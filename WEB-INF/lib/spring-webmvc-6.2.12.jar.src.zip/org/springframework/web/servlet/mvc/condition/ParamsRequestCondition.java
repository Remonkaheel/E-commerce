/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParamsRequestCondition
/*     */   extends AbstractRequestCondition<ParamsRequestCondition>
/*     */ {
/*     */   private final Set<ParamExpression> expressions;
/*     */   
/*     */   public ParamsRequestCondition(String... params) {
/*  52 */     this.expressions = parseExpressions(params);
/*     */   }
/*     */   
/*     */   private static Set<ParamExpression> parseExpressions(String... params) {
/*  56 */     if (ObjectUtils.isEmpty((Object[])params)) {
/*  57 */       return Collections.emptySet();
/*     */     }
/*  59 */     Set<ParamExpression> expressions = CollectionUtils.newLinkedHashSet(params.length);
/*  60 */     for (String param : params) {
/*  61 */       expressions.add(new ParamExpression(param));
/*     */     }
/*  63 */     return expressions;
/*     */   }
/*     */   
/*     */   private ParamsRequestCondition(Set<ParamExpression> conditions) {
/*  67 */     this.expressions = conditions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<NameValueExpression<String>> getExpressions() {
/*  75 */     return new LinkedHashSet<>((Collection)this.expressions);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<ParamExpression> getContent() {
/*  80 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getToStringInfix() {
/*  85 */     return " && ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParamsRequestCondition combine(ParamsRequestCondition other) {
/*  94 */     if (other.isEmpty()) {
/*  95 */       return this;
/*     */     }
/*  97 */     if (isEmpty()) {
/*  98 */       return other;
/*     */     }
/* 100 */     Set<ParamExpression> set = new LinkedHashSet<>(this.expressions);
/* 101 */     set.addAll(other.expressions);
/* 102 */     return new ParamsRequestCondition(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ParamsRequestCondition getMatchingCondition(HttpServletRequest request) {
/* 112 */     for (ParamExpression expression : this.expressions) {
/* 113 */       if (!expression.match(request)) {
/* 114 */         return null;
/*     */       }
/*     */     } 
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ParamsRequestCondition other, HttpServletRequest request) {
/* 133 */     int result = other.expressions.size() - this.expressions.size();
/* 134 */     if (result != 0) {
/* 135 */       return result;
/*     */     }
/* 137 */     return (int)(getValueMatchCount(other.expressions) - getValueMatchCount(this.expressions));
/*     */   }
/*     */   
/*     */   private long getValueMatchCount(Set<ParamExpression> expressions) {
/* 141 */     long count = 0L;
/* 142 */     for (ParamExpression e : expressions) {
/* 143 */       if (e.getValue() != null && !e.isNegated()) {
/* 144 */         count++;
/*     */       }
/*     */     } 
/* 147 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ParamExpression
/*     */     extends AbstractNameValueExpression<String>
/*     */   {
/* 156 */     private final Set<String> namesToMatch = new HashSet<>(WebUtils.SUBMIT_IMAGE_SUFFIXES.length + 1);
/*     */ 
/*     */     
/*     */     ParamExpression(String expression) {
/* 160 */       super(expression);
/* 161 */       this.namesToMatch.add(getName());
/* 162 */       for (String suffix : WebUtils.SUBMIT_IMAGE_SUFFIXES) {
/* 163 */         this.namesToMatch.add(getName() + getName());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isCaseSensitiveName() {
/* 169 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String parseValue(String valueExpression) {
/* 174 */       return valueExpression;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchName(HttpServletRequest request) {
/* 179 */       for (String current : this.namesToMatch) {
/* 180 */         if (request.getParameterMap().get(current) != null) {
/* 181 */           return true;
/*     */         }
/*     */       } 
/* 184 */       return request.getParameterMap().containsKey(this.name);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchValue(HttpServletRequest request) {
/* 189 */       return ObjectUtils.nullSafeEquals(this.value, request.getParameter(this.name));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\ParamsRequestCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */