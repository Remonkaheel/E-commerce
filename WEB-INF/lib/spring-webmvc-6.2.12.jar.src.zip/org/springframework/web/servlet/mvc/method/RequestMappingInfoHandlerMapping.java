/*     */ package org.springframework.web.servlet.mvc.method;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.observation.ServerRequestObservationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.UnsatisfiedServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.filter.ServerHttpObservationFilter;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMethodMapping;
/*     */ import org.springframework.web.servlet.mvc.condition.NameValueExpression;
/*     */ import org.springframework.web.servlet.mvc.condition.PathPatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestMappingInfoHandlerMapping
/*     */   extends AbstractHandlerMethodMapping<RequestMappingInfo>
/*     */ {
/*     */   private static final Method HTTP_OPTIONS_HANDLE_METHOD;
/*     */   
/*     */   static {
/*     */     try {
/*  74 */       HTTP_OPTIONS_HANDLE_METHOD = HttpOptionsHandler.class.getMethod("handle", new Class[0]);
/*     */     }
/*  76 */     catch (NoSuchMethodException ex) {
/*     */       
/*  78 */       throw new IllegalStateException("Failed to retrieve internal handler method for HTTP OPTIONS", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected RequestMappingInfoHandlerMapping() {
/*  84 */     setHandlerMethodMappingNamingStrategy(new RequestMappingInfoHandlerMethodMappingNamingStrategy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<String> getMappingPathPatterns(RequestMappingInfo info) {
/*  94 */     return info.getPatternValues();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<String> getDirectPaths(RequestMappingInfo info) {
/*  99 */     return info.getDirectPaths();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected RequestMappingInfo getMatchingMapping(RequestMappingInfo info, HttpServletRequest request) {
/* 111 */     return info.getMatchingCondition(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Comparator<RequestMappingInfo> getMappingComparator(HttpServletRequest request) {
/* 119 */     return (info1, info2) -> info1.compareTo(info2, request);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected HandlerMethod getHandlerInternal(HttpServletRequest request) throws Exception {
/* 125 */     request.removeAttribute(PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/*     */     try {
/* 127 */       return super.getHandlerInternal(request);
/*     */     } finally {
/*     */       
/* 130 */       ProducesRequestCondition.clearMediaTypesAttribute(request);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleMatch(RequestMappingInfo info, String lookupPath, HttpServletRequest request) {
/* 142 */     super.handleMatch(info, lookupPath, request);
/*     */     
/* 144 */     RequestCondition<?> condition = info.getActivePatternsCondition();
/* 145 */     if (condition instanceof PathPatternsRequestCondition) { PathPatternsRequestCondition pprc = (PathPatternsRequestCondition)condition;
/* 146 */       extractMatchDetails(pprc, lookupPath, request); }
/*     */     else
/*     */     
/* 149 */     { extractMatchDetails((PatternsRequestCondition)condition, lookupPath, request); }
/*     */ 
/*     */     
/* 152 */     ProducesRequestCondition producesCondition = info.getProducesCondition();
/* 153 */     if (!producesCondition.isEmpty()) {
/* 154 */       Set<MediaType> mediaTypes = producesCondition.getProducibleMediaTypes();
/* 155 */       if (!mediaTypes.isEmpty()) {
/* 156 */         request.setAttribute(PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, mediaTypes);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void extractMatchDetails(PathPatternsRequestCondition condition, String lookupPath, HttpServletRequest request) {
/*     */     PathPattern bestPattern;
/*     */     Map<String, String> uriVariables;
/* 166 */     if (condition.isEmptyPathMapping()) {
/* 167 */       bestPattern = condition.getFirstPattern();
/* 168 */       uriVariables = Collections.emptyMap();
/*     */     } else {
/*     */       
/* 171 */       PathContainer path = ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request).pathWithinApplication();
/* 172 */       bestPattern = condition.getFirstPattern();
/* 173 */       PathPattern.PathMatchInfo result = bestPattern.matchAndExtract(path);
/* 174 */       Assert.notNull(result, () -> "Expected bestPattern: " + String.valueOf(bestPattern) + " to match lookupPath " + String.valueOf(path));
/*     */       
/* 176 */       uriVariables = result.getUriVariables();
/* 177 */       request.setAttribute(MATRIX_VARIABLES_ATTRIBUTE, result.getMatrixVariables());
/*     */     } 
/* 179 */     request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, bestPattern.getPatternString());
/* 180 */     ServerHttpObservationFilter.findObservationContext(request)
/* 181 */       .ifPresent(context -> context.setPathPattern(bestPattern.getPatternString()));
/* 182 */     request.setAttribute(URI_TEMPLATE_VARIABLES_ATTRIBUTE, uriVariables);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void extractMatchDetails(PatternsRequestCondition condition, String lookupPath, HttpServletRequest request) {
/*     */     String bestPattern;
/*     */     Map<String, String> uriVariables;
/* 190 */     if (condition.isEmptyPathMapping()) {
/* 191 */       bestPattern = lookupPath;
/* 192 */       uriVariables = Collections.emptyMap();
/*     */     } else {
/*     */       
/* 195 */       bestPattern = condition.getPatterns().iterator().next();
/* 196 */       uriVariables = getPathMatcher().extractUriTemplateVariables(bestPattern, lookupPath);
/* 197 */       if (!getUrlPathHelper().shouldRemoveSemicolonContent()) {
/* 198 */         request.setAttribute(MATRIX_VARIABLES_ATTRIBUTE, extractMatrixVariables(request, uriVariables));
/*     */       }
/* 200 */       uriVariables = getUrlPathHelper().decodePathVariables(request, uriVariables);
/*     */     } 
/* 202 */     request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, bestPattern);
/* 203 */     ServerHttpObservationFilter.findObservationContext(request)
/* 204 */       .ifPresent(context -> context.setPathPattern(bestPattern));
/* 205 */     request.setAttribute(URI_TEMPLATE_VARIABLES_ATTRIBUTE, uriVariables);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, MultiValueMap<String, String>> extractMatrixVariables(HttpServletRequest request, Map<String, String> uriVariables) {
/* 211 */     Map<String, MultiValueMap<String, String>> result = new LinkedHashMap<>();
/* 212 */     uriVariables.forEach((uriVarKey, uriVarValue) -> {
/*     */           String matrixVariables;
/*     */           
/*     */           int equalsIndex = uriVarValue.indexOf('=');
/*     */           
/*     */           if (equalsIndex == -1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           int semicolonIndex = uriVarValue.indexOf(';');
/*     */           
/*     */           if (semicolonIndex != -1 && semicolonIndex != 0) {
/*     */             uriVariables.put(uriVarKey, uriVarValue.substring(0, semicolonIndex));
/*     */           }
/*     */           
/*     */           if (semicolonIndex == -1 || semicolonIndex == 0 || equalsIndex < semicolonIndex) {
/*     */             matrixVariables = uriVarValue;
/*     */           } else {
/*     */             matrixVariables = uriVarValue.substring(semicolonIndex + 1);
/*     */           } 
/*     */           MultiValueMap<String, String> vars = WebUtils.parseMatrixVariables(matrixVariables);
/*     */           result.put(uriVarKey, getUrlPathHelper().decodeMatrixVariables(request, vars));
/*     */         });
/* 235 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected HandlerMethod handleNoMatch(Set<RequestMappingInfo> infos, String lookupPath, HttpServletRequest request) throws ServletException {
/* 251 */     if (CollectionUtils.isEmpty(infos)) {
/* 252 */       return null;
/*     */     }
/*     */     
/* 255 */     PartialMatchHelper helper = new PartialMatchHelper(infos, request);
/* 256 */     if (helper.isEmpty()) {
/* 257 */       return null;
/*     */     }
/*     */     
/* 260 */     if (helper.hasMethodsMismatch()) {
/* 261 */       Set<String> methods = helper.getAllowedMethods();
/* 262 */       if (HttpMethod.OPTIONS.matches(request.getMethod())) {
/* 263 */         Set<MediaType> mediaTypes = helper.getConsumablePatchMediaTypes();
/* 264 */         HttpOptionsHandler handler = new HttpOptionsHandler(methods, mediaTypes);
/* 265 */         return new HandlerMethod(handler, HTTP_OPTIONS_HANDLE_METHOD);
/*     */       } 
/* 267 */       throw new HttpRequestMethodNotSupportedException(request.getMethod(), methods);
/*     */     } 
/*     */     
/* 270 */     if (helper.hasConsumesMismatch()) {
/* 271 */       Set<MediaType> mediaTypes = helper.getConsumableMediaTypes();
/* 272 */       MediaType contentType = null;
/* 273 */       if (StringUtils.hasLength(request.getContentType())) {
/*     */         try {
/* 275 */           contentType = MediaType.parseMediaType(request.getContentType());
/*     */         }
/* 277 */         catch (InvalidMediaTypeException ex) {
/* 278 */           throw new HttpMediaTypeNotSupportedException(ex.getMessage(), new ArrayList(mediaTypes));
/*     */         } 
/*     */       }
/* 281 */       throw new HttpMediaTypeNotSupportedException(contentType, new ArrayList(mediaTypes), 
/* 282 */           HttpMethod.valueOf(request.getMethod()));
/*     */     } 
/*     */     
/* 285 */     if (helper.hasProducesMismatch()) {
/* 286 */       Set<MediaType> mediaTypes = helper.getProducibleMediaTypes();
/* 287 */       throw new HttpMediaTypeNotAcceptableException(new ArrayList(mediaTypes));
/*     */     } 
/*     */     
/* 290 */     if (helper.hasParamsMismatch()) {
/* 291 */       List<String[]> conditions = helper.getParamConditions();
/* 292 */       throw new UnsatisfiedServletRequestParameterException(conditions, request.getParameterMap());
/*     */     } 
/*     */     
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class PartialMatchHelper
/*     */   {
/* 304 */     private final List<PartialMatch> partialMatches = new ArrayList<>();
/*     */     
/*     */     PartialMatchHelper(Set<RequestMappingInfo> infos, HttpServletRequest request) {
/* 307 */       for (RequestMappingInfo info : infos) {
/* 308 */         if (info.<T>getActivePatternsCondition().getMatchingCondition(request) != null) {
/* 309 */           this.partialMatches.add(new PartialMatch(info, request));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 318 */       return this.partialMatches.isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasMethodsMismatch() {
/* 325 */       for (PartialMatch match : this.partialMatches) {
/* 326 */         if (match.hasMethodsMatch()) {
/* 327 */           return false;
/*     */         }
/*     */       } 
/* 330 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasConsumesMismatch() {
/* 337 */       for (PartialMatch match : this.partialMatches) {
/* 338 */         if (match.hasConsumesMatch()) {
/* 339 */           return false;
/*     */         }
/*     */       } 
/* 342 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasProducesMismatch() {
/* 349 */       for (PartialMatch match : this.partialMatches) {
/* 350 */         if (match.hasProducesMatch()) {
/* 351 */           return false;
/*     */         }
/*     */       } 
/* 354 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasParamsMismatch() {
/* 361 */       for (PartialMatch match : this.partialMatches) {
/* 362 */         if (match.hasParamsMatch()) {
/* 363 */           return false;
/*     */         }
/*     */       } 
/* 366 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<String> getAllowedMethods() {
/* 373 */       Set<String> result = new LinkedHashSet<>();
/* 374 */       for (PartialMatch match : this.partialMatches) {
/* 375 */         for (RequestMethod method : match.getInfo().getMethodsCondition().getMethods()) {
/* 376 */           result.add(method.name());
/*     */         }
/*     */       } 
/* 379 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<MediaType> getConsumableMediaTypes() {
/* 387 */       Set<MediaType> result = new LinkedHashSet<>();
/* 388 */       for (PartialMatch match : this.partialMatches) {
/* 389 */         if (match.hasMethodsMatch()) {
/* 390 */           result.addAll(match.getInfo().getConsumesCondition().getConsumableMediaTypes());
/*     */         }
/*     */       } 
/* 393 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<MediaType> getProducibleMediaTypes() {
/* 401 */       Set<MediaType> result = new LinkedHashSet<>();
/* 402 */       for (PartialMatch match : this.partialMatches) {
/* 403 */         if (match.hasConsumesMatch()) {
/* 404 */           result.addAll(match.getInfo().getProducesCondition().getProducibleMediaTypes());
/*     */         }
/*     */       } 
/* 407 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String[]> getParamConditions() {
/* 415 */       List<String[]> result = (List)new ArrayList<>();
/* 416 */       for (PartialMatch match : this.partialMatches) {
/* 417 */         if (match.hasProducesMatch()) {
/* 418 */           Set<NameValueExpression<String>> set = match.getInfo().getParamsCondition().getExpressions();
/* 419 */           if (!CollectionUtils.isEmpty(set)) {
/* 420 */             int i = 0;
/* 421 */             String[] array = new String[set.size()];
/* 422 */             for (NameValueExpression<String> expression : set) {
/* 423 */               array[i++] = expression.toString();
/*     */             }
/* 425 */             result.add(array);
/*     */           } 
/*     */         } 
/*     */       } 
/* 429 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<MediaType> getConsumablePatchMediaTypes() {
/* 437 */       Set<MediaType> result = new LinkedHashSet<>();
/* 438 */       for (PartialMatch match : this.partialMatches) {
/* 439 */         Set<RequestMethod> methods = match.getInfo().getMethodsCondition().getMethods();
/* 440 */         if (methods.isEmpty() || methods.contains(RequestMethod.PATCH)) {
/* 441 */           result.addAll(match.getInfo().getConsumesCondition().getConsumableMediaTypes());
/*     */         }
/*     */       } 
/* 444 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static class PartialMatch
/*     */     {
/*     */       private final RequestMappingInfo info;
/*     */ 
/*     */       
/*     */       private final boolean methodsMatch;
/*     */ 
/*     */       
/*     */       private final boolean consumesMatch;
/*     */ 
/*     */       
/*     */       private final boolean producesMatch;
/*     */ 
/*     */       
/*     */       private final boolean paramsMatch;
/*     */ 
/*     */ 
/*     */       
/*     */       public PartialMatch(RequestMappingInfo info, HttpServletRequest request) {
/* 469 */         this.info = info;
/* 470 */         this.methodsMatch = (info.getMethodsCondition().getMatchingCondition(request) != null);
/* 471 */         this.consumesMatch = (info.getConsumesCondition().getMatchingCondition(request) != null);
/* 472 */         this.producesMatch = (info.getProducesCondition().getMatchingCondition(request) != null);
/* 473 */         this.paramsMatch = (info.getParamsCondition().getMatchingCondition(request) != null);
/*     */       }
/*     */       
/*     */       public RequestMappingInfo getInfo() {
/* 477 */         return this.info;
/*     */       }
/*     */       
/*     */       public boolean hasMethodsMatch() {
/* 481 */         return this.methodsMatch;
/*     */       }
/*     */       
/*     */       public boolean hasConsumesMatch() {
/* 485 */         return (hasMethodsMatch() && this.consumesMatch);
/*     */       }
/*     */       
/*     */       public boolean hasProducesMatch() {
/* 489 */         return (hasConsumesMatch() && this.producesMatch);
/*     */       }
/*     */       
/*     */       public boolean hasParamsMatch() {
/* 493 */         return (hasProducesMatch() && this.paramsMatch);
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 498 */         return this.info.toString(); } } } private static class PartialMatch { private final RequestMappingInfo info; private final boolean methodsMatch; private final boolean consumesMatch; private final boolean producesMatch; public String toString() { return this.info.toString(); }
/*     */     private final boolean paramsMatch;
/*     */     public PartialMatch(RequestMappingInfo info, HttpServletRequest request) { this.info = info;
/*     */       this.methodsMatch = (info.getMethodsCondition().getMatchingCondition(request) != null);
/*     */       this.consumesMatch = (info.getConsumesCondition().getMatchingCondition(request) != null);
/*     */       this.producesMatch = (info.getProducesCondition().getMatchingCondition(request) != null);
/*     */       this.paramsMatch = (info.getParamsCondition().getMatchingCondition(request) != null); } public RequestMappingInfo getInfo() { return this.info; } public boolean hasMethodsMatch() { return this.methodsMatch; } public boolean hasConsumesMatch() { return (hasMethodsMatch() && this.consumesMatch); } public boolean hasProducesMatch() { return (hasConsumesMatch() && this.producesMatch); } public boolean hasParamsMatch() {
/*     */       return (hasProducesMatch() && this.paramsMatch);
/*     */     } }
/*     */    private static class HttpOptionsHandler
/*     */   {
/* 509 */     private final HttpHeaders headers = new HttpHeaders();
/*     */     
/*     */     public HttpOptionsHandler(Set<String> declaredMethods, Set<MediaType> acceptPatch) {
/* 512 */       this.headers.setAllow(initAllowedHttpMethods(declaredMethods));
/* 513 */       this.headers.setAcceptPatch(new ArrayList<>(acceptPatch));
/*     */     }
/*     */     
/*     */     private static Set<HttpMethod> initAllowedHttpMethods(Set<String> declaredMethods) {
/* 517 */       Set<HttpMethod> result = CollectionUtils.newLinkedHashSet(declaredMethods.size());
/* 518 */       if (declaredMethods.isEmpty()) {
/* 519 */         for (HttpMethod method : HttpMethod.values()) {
/* 520 */           if (method != HttpMethod.TRACE) {
/* 521 */             result.add(method);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 526 */         for (String method : declaredMethods) {
/* 527 */           HttpMethod httpMethod = HttpMethod.valueOf(method);
/* 528 */           result.add(httpMethod);
/* 529 */           if (httpMethod == HttpMethod.GET) {
/* 530 */             result.add(HttpMethod.HEAD);
/*     */           }
/*     */         } 
/* 533 */         result.add(HttpMethod.OPTIONS);
/*     */       } 
/* 535 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders handle() {
/* 540 */       return this.headers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\RequestMappingInfoHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */