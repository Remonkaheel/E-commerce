/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.multipart.support.MultipartResolutionDelegate;
/*     */ import org.springframework.web.multipart.support.RequestPartServletServerHttpRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestPartMethodArgumentResolver
/*     */   extends AbstractMessageConverterMethodArgumentResolver
/*     */ {
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters) {
/*  82 */     super(messageConverters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters, List<Object> requestResponseBodyAdvice) {
/*  92 */     super(messageConverters, requestResponseBodyAdvice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/* 108 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 109 */       return true;
/*     */     }
/*     */     
/* 112 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 113 */       return false;
/*     */     }
/* 115 */     return MultipartResolutionDelegate.isMultipartArgument(parameter.nestedIfOptional());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest request, @Nullable WebDataBinderFactory binderFactory) throws Exception {
/* 124 */     HttpServletRequest servletRequest = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/* 125 */     Assert.state((servletRequest != null), "No HttpServletRequest");
/*     */     
/* 127 */     RequestPart requestPart = (RequestPart)parameter.getParameterAnnotation(RequestPart.class);
/* 128 */     boolean isRequired = ((requestPart == null || requestPart.required()) && !parameter.isOptional());
/*     */     
/* 130 */     String name = getPartName(parameter, requestPart);
/* 131 */     parameter = parameter.nestedIfOptional();
/* 132 */     Object arg = null;
/*     */     
/* 134 */     Object mpArg = MultipartResolutionDelegate.resolveMultipartArgument(name, parameter, servletRequest);
/* 135 */     if (mpArg != MultipartResolutionDelegate.UNRESOLVABLE) {
/* 136 */       arg = mpArg;
/*     */     } else {
/*     */       
/*     */       try {
/* 140 */         RequestPartServletServerHttpRequest requestPartServletServerHttpRequest = new RequestPartServletServerHttpRequest(servletRequest, name);
/* 141 */         arg = readWithMessageConverters((HttpInputMessage)requestPartServletServerHttpRequest, parameter, parameter.getNestedGenericParameterType());
/* 142 */         if (binderFactory != null) {
/* 143 */           ResolvableType type = ResolvableType.forMethodParameter(parameter);
/* 144 */           WebDataBinder binder = binderFactory.createBinder(request, arg, name, type);
/* 145 */           if (arg != null) {
/* 146 */             validateIfApplicable(binder, parameter);
/* 147 */             if (binder.getBindingResult().hasErrors() && isBindExceptionRequired(binder, parameter)) {
/* 148 */               throw new MethodArgumentNotValidException(parameter, binder.getBindingResult());
/*     */             }
/*     */           } 
/* 151 */           if (mavContainer != null) {
/* 152 */             mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + BindingResult.MODEL_KEY_PREFIX, binder.getBindingResult());
/*     */           }
/*     */         }
/*     */       
/* 156 */       } catch (MissingServletRequestPartException|MultipartException ex) {
/* 157 */         if (isRequired) {
/* 158 */           throw ex;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     if (arg == null && isRequired) {
/* 164 */       if (!MultipartResolutionDelegate.isMultipartRequest(servletRequest)) {
/* 165 */         throw new MultipartException("Current request is not a multipart request");
/*     */       }
/*     */       
/* 168 */       throw new MissingServletRequestPartException(name);
/*     */     } 
/*     */     
/* 171 */     return adaptArgumentIfNecessary(arg, parameter);
/*     */   }
/*     */   
/*     */   private String getPartName(MethodParameter methodParam, @Nullable RequestPart requestPart) {
/* 175 */     String partName = (requestPart != null) ? requestPart.name() : "";
/* 176 */     if (partName.isEmpty()) {
/* 177 */       partName = methodParam.getParameterName();
/* 178 */       if (partName == null) {
/* 179 */         throw new IllegalArgumentException("Request part name for argument type [" + methodParam
/* 180 */             .getNestedParameterType().getName() + "] not specified, and parameter name information not found in class file either.");
/*     */       }
/*     */     } 
/*     */     
/* 184 */     return partName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeStreamIfNecessary(InputStream body) {
/*     */     try {
/* 193 */       body.close();
/*     */     }
/* 195 */     catch (IOException iOException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestPartMethodArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */