/*      */ package org.springframework.web.servlet.mvc.method;
/*      */ 
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import org.springframework.http.HttpMethod;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.PathMatcher;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.accept.ContentNegotiationManager;
/*      */ import org.springframework.web.bind.annotation.RequestMethod;
/*      */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.HeadersRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.PathPatternsRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.RequestConditionHolder;
/*      */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*      */ import org.springframework.web.util.UrlPathHelper;
/*      */ import org.springframework.web.util.pattern.PathPatternParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class RequestMappingInfo
/*      */   implements RequestCondition<RequestMappingInfo>
/*      */ {
/*   68 */   private static final PathPatternsRequestCondition EMPTY_PATH_PATTERNS = new PathPatternsRequestCondition();
/*      */   
/*   70 */   private static final PatternsRequestCondition EMPTY_PATTERNS = new PatternsRequestCondition(new String[0]);
/*      */   
/*   72 */   private static final RequestMethodsRequestCondition EMPTY_REQUEST_METHODS = new RequestMethodsRequestCondition(new RequestMethod[0]);
/*      */   
/*   74 */   private static final ParamsRequestCondition EMPTY_PARAMS = new ParamsRequestCondition(new String[0]);
/*      */   
/*   76 */   private static final HeadersRequestCondition EMPTY_HEADERS = new HeadersRequestCondition(new String[0]);
/*      */   
/*   78 */   private static final ConsumesRequestCondition EMPTY_CONSUMES = new ConsumesRequestCondition(new String[0]);
/*      */   
/*   80 */   private static final ProducesRequestCondition EMPTY_PRODUCES = new ProducesRequestCondition(new String[0]);
/*      */   
/*   82 */   private static final RequestConditionHolder EMPTY_CUSTOM = new RequestConditionHolder(null);
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private final String name;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private final PathPatternsRequestCondition pathPatternsCondition;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private final PatternsRequestCondition patternsCondition;
/*      */ 
/*      */   
/*      */   private final RequestMethodsRequestCondition methodsCondition;
/*      */ 
/*      */   
/*      */   private final ParamsRequestCondition paramsCondition;
/*      */ 
/*      */   
/*      */   private final HeadersRequestCondition headersCondition;
/*      */ 
/*      */   
/*      */   private final ConsumesRequestCondition consumesCondition;
/*      */ 
/*      */   
/*      */   private final ProducesRequestCondition producesCondition;
/*      */ 
/*      */   
/*      */   private final RequestConditionHolder customConditionHolder;
/*      */ 
/*      */   
/*      */   private final int hashCode;
/*      */   
/*      */   private final BuilderConfiguration options;
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public RequestMappingInfo(@Nullable String name, @Nullable PatternsRequestCondition patterns, @Nullable RequestMethodsRequestCondition methods, @Nullable ParamsRequestCondition params, @Nullable HeadersRequestCondition headers, @Nullable ConsumesRequestCondition consumes, @Nullable ProducesRequestCondition produces, @Nullable RequestCondition<?> custom) {
/*  122 */     this(name, null, 
/*  123 */         (patterns != null) ? patterns : EMPTY_PATTERNS, 
/*  124 */         (methods != null) ? methods : EMPTY_REQUEST_METHODS, 
/*  125 */         (params != null) ? params : EMPTY_PARAMS, 
/*  126 */         (headers != null) ? headers : EMPTY_HEADERS, 
/*  127 */         (consumes != null) ? consumes : EMPTY_CONSUMES, 
/*  128 */         (produces != null) ? produces : EMPTY_PRODUCES, 
/*  129 */         (custom != null) ? new RequestConditionHolder(custom) : EMPTY_CUSTOM, new BuilderConfiguration());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public RequestMappingInfo(@Nullable PatternsRequestCondition patterns, @Nullable RequestMethodsRequestCondition methods, @Nullable ParamsRequestCondition params, @Nullable HeadersRequestCondition headers, @Nullable ConsumesRequestCondition consumes, @Nullable ProducesRequestCondition produces, @Nullable RequestCondition<?> custom) {
/*  144 */     this(null, patterns, methods, params, headers, consumes, produces, custom);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public RequestMappingInfo(RequestMappingInfo info, @Nullable RequestCondition<?> customRequestCondition) {
/*  153 */     this(info.name, info.patternsCondition, info.methodsCondition, info.paramsCondition, info.headersCondition, info.consumesCondition, info.producesCondition, customRequestCondition);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RequestMappingInfo(@Nullable String name, @Nullable PathPatternsRequestCondition pathPatternsCondition, @Nullable PatternsRequestCondition patternsCondition, RequestMethodsRequestCondition methodsCondition, ParamsRequestCondition paramsCondition, HeadersRequestCondition headersCondition, ConsumesRequestCondition consumesCondition, ProducesRequestCondition producesCondition, RequestConditionHolder customCondition, BuilderConfiguration options) {
/*  165 */     Assert.isTrue((pathPatternsCondition != null || patternsCondition != null), "Neither PathPatterns nor String patterns condition");
/*      */ 
/*      */     
/*  168 */     this.name = StringUtils.hasText(name) ? name : null;
/*  169 */     this.pathPatternsCondition = pathPatternsCondition;
/*  170 */     this.patternsCondition = patternsCondition;
/*  171 */     this.methodsCondition = methodsCondition;
/*  172 */     this.paramsCondition = paramsCondition;
/*  173 */     this.headersCondition = headersCondition;
/*  174 */     this.consumesCondition = consumesCondition;
/*  175 */     this.producesCondition = producesCondition;
/*  176 */     this.customConditionHolder = customCondition;
/*  177 */     this.options = options;
/*      */     
/*  179 */     this.hashCode = calculateHashCode(this.pathPatternsCondition, this.patternsCondition, this.methodsCondition, this.paramsCondition, this.headersCondition, this.consumesCondition, this.producesCondition, this.customConditionHolder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getName() {
/*  191 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public PathPatternsRequestCondition getPathPatternsCondition() {
/*  204 */     return this.pathPatternsCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public PatternsRequestCondition getPatternsCondition() {
/*  215 */     return this.patternsCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> RequestCondition<T> getActivePatternsCondition() {
/*  225 */     if (this.pathPatternsCondition != null) {
/*  226 */       return (RequestCondition<T>)this.pathPatternsCondition;
/*      */     }
/*  228 */     if (this.patternsCondition != null) {
/*  229 */       return (RequestCondition<T>)this.patternsCondition;
/*      */     }
/*      */ 
/*      */     
/*  233 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getDirectPaths() {
/*  242 */     RequestCondition<?> condition = getActivePatternsCondition();
/*  243 */     PathPatternsRequestCondition pprc = (PathPatternsRequestCondition)condition; return (condition instanceof PathPatternsRequestCondition) ? 
/*  244 */       pprc.getDirectPaths() : ((PatternsRequestCondition)condition).getDirectPaths();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getPatternValues() {
/*  253 */     RequestCondition<?> condition = getActivePatternsCondition();
/*  254 */     PathPatternsRequestCondition pprc = (PathPatternsRequestCondition)condition; return (condition instanceof PathPatternsRequestCondition) ? 
/*  255 */       pprc.getPatternValues() : ((PatternsRequestCondition)condition).getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmptyMapping() {
/*  263 */     RequestCondition<?> condition = getActivePatternsCondition();
/*  264 */     PathPatternsRequestCondition pprc = (PathPatternsRequestCondition)condition; return (condition instanceof PathPatternsRequestCondition) ? 
/*  265 */       pprc.isEmptyPathMapping() : ((PatternsRequestCondition)condition).isEmptyPathMapping();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RequestMethodsRequestCondition getMethodsCondition() {
/*  273 */     return this.methodsCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParamsRequestCondition getParamsCondition() {
/*  281 */     return this.paramsCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersRequestCondition getHeadersCondition() {
/*  289 */     return this.headersCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConsumesRequestCondition getConsumesCondition() {
/*  297 */     return this.consumesCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProducesRequestCondition getProducesCondition() {
/*  305 */     return this.producesCondition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public RequestCondition<?> getCustomCondition() {
/*  313 */     return this.customConditionHolder.getCondition();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RequestMappingInfo addCustomCondition(RequestCondition<?> customCondition) {
/*  323 */     return new RequestMappingInfo(this.name, this.pathPatternsCondition, this.patternsCondition, this.methodsCondition, this.paramsCondition, this.headersCondition, this.consumesCondition, this.producesCondition, new RequestConditionHolder(customCondition), this.options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RequestMappingInfo combine(RequestMappingInfo other) {
/*  338 */     String name = combineNames(other);
/*      */ 
/*      */ 
/*      */     
/*  342 */     PathPatternsRequestCondition pathPatterns = (this.pathPatternsCondition != null && other.pathPatternsCondition != null) ? this.pathPatternsCondition.combine(other.pathPatternsCondition) : null;
/*      */ 
/*      */ 
/*      */     
/*  346 */     PatternsRequestCondition patterns = (this.patternsCondition != null && other.patternsCondition != null) ? this.patternsCondition.combine(other.patternsCondition) : null;
/*      */     
/*  348 */     RequestMethodsRequestCondition methods = this.methodsCondition.combine(other.methodsCondition);
/*  349 */     ParamsRequestCondition params = this.paramsCondition.combine(other.paramsCondition);
/*  350 */     HeadersRequestCondition headers = this.headersCondition.combine(other.headersCondition);
/*  351 */     ConsumesRequestCondition consumes = this.consumesCondition.combine(other.consumesCondition);
/*  352 */     ProducesRequestCondition produces = this.producesCondition.combine(other.producesCondition);
/*  353 */     RequestConditionHolder custom = this.customConditionHolder.combine(other.customConditionHolder);
/*      */     
/*  355 */     return new RequestMappingInfo(name, pathPatterns, patterns, methods, params, headers, consumes, produces, custom, this.options);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private String combineNames(RequestMappingInfo other) {
/*  361 */     if (this.name != null && other.name != null) {
/*  362 */       String separator = "#";
/*  363 */       return this.name + this.name + separator;
/*      */     } 
/*  365 */     if (this.name != null) {
/*  366 */       return this.name;
/*      */     }
/*      */     
/*  369 */     return other.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public RequestMappingInfo getMatchingCondition(HttpServletRequest request) {
/*  385 */     RequestMethodsRequestCondition methods = this.methodsCondition.getMatchingCondition(request);
/*  386 */     if (methods == null) {
/*  387 */       return null;
/*      */     }
/*  389 */     ParamsRequestCondition params = this.paramsCondition.getMatchingCondition(request);
/*  390 */     if (params == null) {
/*  391 */       return null;
/*      */     }
/*  393 */     HeadersRequestCondition headers = this.headersCondition.getMatchingCondition(request);
/*  394 */     if (headers == null) {
/*  395 */       return null;
/*      */     }
/*  397 */     ConsumesRequestCondition consumes = this.consumesCondition.getMatchingCondition(request);
/*  398 */     if (consumes == null) {
/*  399 */       return null;
/*      */     }
/*  401 */     ProducesRequestCondition produces = this.producesCondition.getMatchingCondition(request);
/*  402 */     if (produces == null) {
/*  403 */       return null;
/*      */     }
/*  405 */     PathPatternsRequestCondition pathPatterns = null;
/*  406 */     if (this.pathPatternsCondition != null) {
/*  407 */       pathPatterns = this.pathPatternsCondition.getMatchingCondition(request);
/*  408 */       if (pathPatterns == null) {
/*  409 */         return null;
/*      */       }
/*      */     } 
/*  412 */     PatternsRequestCondition patterns = null;
/*  413 */     if (this.patternsCondition != null) {
/*  414 */       patterns = this.patternsCondition.getMatchingCondition(request);
/*  415 */       if (patterns == null) {
/*  416 */         return null;
/*      */       }
/*      */     } 
/*  419 */     RequestConditionHolder custom = this.customConditionHolder.getMatchingCondition(request);
/*  420 */     if (custom == null) {
/*  421 */       return null;
/*      */     }
/*  423 */     return new RequestMappingInfo(this.name, pathPatterns, patterns, methods, params, headers, consumes, produces, custom, this.options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(RequestMappingInfo other, HttpServletRequest request) {
/*  438 */     if (HttpMethod.HEAD.matches(request.getMethod())) {
/*  439 */       int i = this.methodsCondition.compareTo(other.getMethodsCondition(), request);
/*  440 */       if (i != 0) {
/*  441 */         return i;
/*      */       }
/*      */     } 
/*  444 */     int result = getActivePatternsCondition().compareTo(other.getActivePatternsCondition(), request);
/*  445 */     if (result != 0) {
/*  446 */       return result;
/*      */     }
/*  448 */     result = this.paramsCondition.compareTo(other.getParamsCondition(), request);
/*  449 */     if (result != 0) {
/*  450 */       return result;
/*      */     }
/*  452 */     result = this.headersCondition.compareTo(other.getHeadersCondition(), request);
/*  453 */     if (result != 0) {
/*  454 */       return result;
/*      */     }
/*  456 */     result = this.consumesCondition.compareTo(other.getConsumesCondition(), request);
/*  457 */     if (result != 0) {
/*  458 */       return result;
/*      */     }
/*  460 */     result = this.producesCondition.compareTo(other.getProducesCondition(), request);
/*  461 */     if (result != 0) {
/*  462 */       return result;
/*      */     }
/*      */     
/*  465 */     result = this.methodsCondition.compareTo(other.getMethodsCondition(), request);
/*  466 */     if (result != 0) {
/*  467 */       return result;
/*      */     }
/*  469 */     result = this.customConditionHolder.compareTo(other.customConditionHolder, request);
/*  470 */     if (result != 0) {
/*  471 */       return result;
/*      */     }
/*  473 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(@Nullable Object other) {
/*  478 */     if (this != other) { if (other instanceof RequestMappingInfo) { RequestMappingInfo that = (RequestMappingInfo)other;
/*  479 */         if (getActivePatternsCondition().equals(that.getActivePatternsCondition()) && this.methodsCondition
/*  480 */           .equals(that.methodsCondition) && this.paramsCondition
/*  481 */           .equals(that.paramsCondition) && this.headersCondition
/*  482 */           .equals(that.headersCondition) && this.consumesCondition
/*  483 */           .equals(that.consumesCondition) && this.producesCondition
/*  484 */           .equals(that.producesCondition) && this.customConditionHolder
/*  485 */           .equals(that.customConditionHolder)); }
/*      */       
/*      */       return false; }
/*      */   
/*      */   } public int hashCode() {
/*  490 */     return this.hashCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int calculateHashCode(@Nullable PathPatternsRequestCondition pathPatterns, @Nullable PatternsRequestCondition patterns, RequestMethodsRequestCondition methods, ParamsRequestCondition params, HeadersRequestCondition headers, ConsumesRequestCondition consumes, ProducesRequestCondition produces, RequestConditionHolder custom) {
/*  499 */     return ((pathPatterns != null) ? pathPatterns : patterns).hashCode() * 31 + methods
/*  500 */       .hashCode() + params.hashCode() + headers
/*  501 */       .hashCode() + consumes.hashCode() + produces.hashCode() + custom
/*  502 */       .hashCode();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  507 */     StringBuilder builder = new StringBuilder("{");
/*  508 */     if (!this.methodsCondition.isEmpty()) {
/*  509 */       Set<RequestMethod> httpMethods = this.methodsCondition.getMethods();
/*  510 */       builder.append((httpMethods.size() == 1) ? httpMethods.iterator().next() : httpMethods);
/*      */     } 
/*      */ 
/*      */     
/*  514 */     builder.append(' ').append(getActivePatternsCondition());
/*      */     
/*  516 */     if (!this.paramsCondition.isEmpty()) {
/*  517 */       builder.append(", params ").append(this.paramsCondition);
/*      */     }
/*  519 */     if (!this.headersCondition.isEmpty()) {
/*  520 */       builder.append(", headers ").append(this.headersCondition);
/*      */     }
/*  522 */     if (!this.consumesCondition.isEmpty()) {
/*  523 */       builder.append(", consumes ").append(this.consumesCondition);
/*      */     }
/*  525 */     if (!this.producesCondition.isEmpty()) {
/*  526 */       builder.append(", produces ").append(this.producesCondition);
/*      */     }
/*  528 */     if (!this.customConditionHolder.isEmpty()) {
/*  529 */       builder.append(", and ").append(this.customConditionHolder);
/*      */     }
/*  531 */     builder.append('}');
/*  532 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Builder mutate() {
/*  541 */     return new MutateBuilder(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder paths(String... paths) {
/*  551 */     return new DefaultBuilder(paths);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Builder
/*      */   {
/*      */     Builder paths(String... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder methods(RequestMethod... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder params(String... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder headers(String... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder consumes(String... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder produces(String... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder mappingName(String param1String);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder customCondition(RequestCondition<?> param1RequestCondition);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Builder options(RequestMappingInfo.BuilderConfiguration param1BuilderConfiguration);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     RequestMappingInfo build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class DefaultBuilder
/*      */     implements Builder
/*      */   {
/*      */     private String[] paths;
/*      */ 
/*      */ 
/*      */     
/*  618 */     private RequestMethod[] methods = new RequestMethod[0];
/*      */     
/*  620 */     private String[] params = new String[0];
/*      */     
/*  622 */     private String[] headers = new String[0];
/*      */     
/*  624 */     private String[] consumes = new String[0];
/*      */     
/*  626 */     private String[] produces = new String[0];
/*      */     
/*      */     private boolean hasContentType;
/*      */     
/*      */     private boolean hasAccept;
/*      */     
/*      */     @Nullable
/*      */     private String mappingName;
/*      */     
/*      */     @Nullable
/*      */     private RequestCondition<?> customCondition;
/*      */     
/*  638 */     private RequestMappingInfo.BuilderConfiguration options = new RequestMappingInfo.BuilderConfiguration();
/*      */     
/*      */     public DefaultBuilder(String... paths) {
/*  641 */       this.paths = paths;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder paths(String... paths) {
/*  646 */       this.paths = paths;
/*  647 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder methods(RequestMethod... methods) {
/*  652 */       this.methods = methods;
/*  653 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder params(String... params) {
/*  658 */       this.params = params;
/*  659 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder headers(String... headers) {
/*  664 */       for (String header : headers) {
/*  665 */         this
/*  666 */           .hasContentType = (this.hasContentType || header.contains("Content-Type") || header.contains("content-type"));
/*  667 */         this
/*  668 */           .hasAccept = (this.hasAccept || header.contains("Accept") || header.contains("accept"));
/*      */       } 
/*  670 */       this.headers = headers;
/*  671 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder consumes(String... consumes) {
/*  676 */       this.consumes = consumes;
/*  677 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder produces(String... produces) {
/*  682 */       this.produces = produces;
/*  683 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder mappingName(String name) {
/*  688 */       this.mappingName = name;
/*  689 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultBuilder customCondition(RequestCondition<?> condition) {
/*  694 */       this.customCondition = condition;
/*  695 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder options(RequestMappingInfo.BuilderConfiguration options) {
/*  700 */       this.options = options;
/*  701 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RequestMappingInfo build() {
/*  708 */       PathPatternsRequestCondition pathPatternsCondition = null;
/*  709 */       PatternsRequestCondition patternsCondition = null;
/*      */       
/*  711 */       PathPatternParser parser = this.options.getPatternParserToUse();
/*      */       
/*  713 */       if (parser != null) {
/*      */ 
/*      */         
/*  716 */         pathPatternsCondition = ObjectUtils.isEmpty((Object[])this.paths) ? RequestMappingInfo.EMPTY_PATH_PATTERNS : new PathPatternsRequestCondition(parser, this.paths);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  724 */         patternsCondition = ObjectUtils.isEmpty((Object[])this.paths) ? RequestMappingInfo.EMPTY_PATTERNS : new PatternsRequestCondition(this.paths, null, this.options.pathMatcher, this.options.useSuffixPatternMatch(), this.options.useTrailingSlashMatch(), this.options.getFileExtensions());
/*      */       } 
/*      */       
/*  727 */       ContentNegotiationManager manager = this.options.getContentNegotiationManager();
/*      */       
/*  729 */       return new RequestMappingInfo(this.mappingName, pathPatternsCondition, patternsCondition, 
/*      */           
/*  731 */           ObjectUtils.isEmpty((Object[])this.methods) ? 
/*  732 */           RequestMappingInfo.EMPTY_REQUEST_METHODS : new RequestMethodsRequestCondition(this.methods), 
/*  733 */           ObjectUtils.isEmpty((Object[])this.params) ? 
/*  734 */           RequestMappingInfo.EMPTY_PARAMS : new ParamsRequestCondition(this.params), 
/*  735 */           ObjectUtils.isEmpty((Object[])this.headers) ? 
/*  736 */           RequestMappingInfo.EMPTY_HEADERS : new HeadersRequestCondition(this.headers), 
/*  737 */           (ObjectUtils.isEmpty((Object[])this.consumes) && !this.hasContentType) ? 
/*  738 */           RequestMappingInfo.EMPTY_CONSUMES : new ConsumesRequestCondition(this.consumes, this.headers), 
/*  739 */           (ObjectUtils.isEmpty((Object[])this.produces) && !this.hasAccept) ? 
/*  740 */           RequestMappingInfo.EMPTY_PRODUCES : new ProducesRequestCondition(this.produces, this.headers, manager), 
/*  741 */           (this.customCondition != null) ? 
/*  742 */           new RequestConditionHolder(this.customCondition) : RequestMappingInfo.EMPTY_CUSTOM, this.options);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class MutateBuilder
/*      */     implements Builder
/*      */   {
/*      */     @Nullable
/*      */     private String name;
/*      */     
/*      */     @Nullable
/*      */     private PathPatternsRequestCondition pathPatternsCondition;
/*      */     
/*      */     @Nullable
/*      */     private PatternsRequestCondition patternsCondition;
/*      */     
/*      */     private RequestMethodsRequestCondition methodsCondition;
/*      */     
/*      */     private ParamsRequestCondition paramsCondition;
/*      */     
/*      */     private HeadersRequestCondition headersCondition;
/*      */     
/*      */     private ConsumesRequestCondition consumesCondition;
/*      */     
/*      */     private ProducesRequestCondition producesCondition;
/*      */     
/*      */     private RequestConditionHolder customConditionHolder;
/*      */     private RequestMappingInfo.BuilderConfiguration options;
/*      */     
/*      */     public MutateBuilder(RequestMappingInfo other) {
/*  773 */       this.name = other.name;
/*  774 */       this.pathPatternsCondition = other.pathPatternsCondition;
/*  775 */       this.patternsCondition = other.patternsCondition;
/*  776 */       this.methodsCondition = other.methodsCondition;
/*  777 */       this.paramsCondition = other.paramsCondition;
/*  778 */       this.headersCondition = other.headersCondition;
/*  779 */       this.consumesCondition = other.consumesCondition;
/*  780 */       this.producesCondition = other.producesCondition;
/*  781 */       this.customConditionHolder = other.customConditionHolder;
/*  782 */       this.options = other.options;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder paths(String... paths) {
/*  788 */       PathPatternParser parser = this.options.getPatternParserToUse();
/*      */       
/*  790 */       if (parser != null) {
/*  791 */         this
/*  792 */           .pathPatternsCondition = ObjectUtils.isEmpty((Object[])paths) ? RequestMappingInfo.EMPTY_PATH_PATTERNS : new PathPatternsRequestCondition(parser, paths);
/*      */       } else {
/*      */         
/*  795 */         this
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  800 */           .patternsCondition = ObjectUtils.isEmpty((Object[])paths) ? RequestMappingInfo.EMPTY_PATTERNS : new PatternsRequestCondition(paths, null, this.options.getPathMatcher(), this.options.useSuffixPatternMatch(), this.options.useTrailingSlashMatch(), this.options.getFileExtensions());
/*      */       } 
/*  802 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder methods(RequestMethod... methods) {
/*  807 */       this
/*  808 */         .methodsCondition = ObjectUtils.isEmpty((Object[])methods) ? RequestMappingInfo.EMPTY_REQUEST_METHODS : new RequestMethodsRequestCondition(methods);
/*  809 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder params(String... params) {
/*  814 */       this
/*  815 */         .paramsCondition = ObjectUtils.isEmpty((Object[])params) ? RequestMappingInfo.EMPTY_PARAMS : new ParamsRequestCondition(params);
/*  816 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder headers(String... headers) {
/*  821 */       this
/*  822 */         .headersCondition = ObjectUtils.isEmpty((Object[])headers) ? RequestMappingInfo.EMPTY_HEADERS : new HeadersRequestCondition(headers);
/*  823 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder consumes(String... consumes) {
/*  828 */       this
/*  829 */         .consumesCondition = ObjectUtils.isEmpty((Object[])consumes) ? RequestMappingInfo.EMPTY_CONSUMES : new ConsumesRequestCondition(consumes);
/*  830 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder produces(String... produces) {
/*  835 */       this
/*      */         
/*  837 */         .producesCondition = ObjectUtils.isEmpty((Object[])produces) ? RequestMappingInfo.EMPTY_PRODUCES : new ProducesRequestCondition(produces, null, this.options.getContentNegotiationManager());
/*  838 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder mappingName(String name) {
/*  843 */       this.name = name;
/*  844 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder customCondition(RequestCondition<?> condition) {
/*  849 */       this.customConditionHolder = new RequestConditionHolder(condition);
/*  850 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo.Builder options(RequestMappingInfo.BuilderConfiguration options) {
/*  855 */       this.options = options;
/*  856 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestMappingInfo build() {
/*  861 */       return new RequestMappingInfo(this.name, this.pathPatternsCondition, this.patternsCondition, this.methodsCondition, this.paramsCondition, this.headersCondition, this.consumesCondition, this.producesCondition, this.customConditionHolder, this.options);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BuilderConfiguration
/*      */   {
/*  879 */     private static PathPatternParser defaultPatternParser = new PathPatternParser();
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private PathPatternParser patternParser;
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private PathMatcher pathMatcher;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean trailingSlashMatch = false;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean suffixPatternMatch = false;
/*      */ 
/*      */     
/*      */     private boolean registeredSuffixPatternMatch = false;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private ContentNegotiationManager contentNegotiationManager;
/*      */ 
/*      */ 
/*      */     
/*      */     public void setPatternParser(@Nullable PathPatternParser patternParser) {
/*  909 */       this.patternParser = patternParser;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public PathPatternParser getPatternParser() {
/*  919 */       return this.patternParser;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public void setUrlPathHelper(@Nullable UrlPathHelper urlPathHelper) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     @Deprecated
/*      */     public UrlPathHelper getUrlPathHelper() {
/*  942 */       return UrlPathHelper.defaultInstance;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setPathMatcher(@Nullable PathMatcher pathMatcher) {
/*  952 */       this.pathMatcher = pathMatcher;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public PathMatcher getPathMatcher() {
/*  960 */       return this.pathMatcher;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public PathPatternParser getPatternParserToUse() {
/*  971 */       if (this.patternParser == null && this.pathMatcher == null) {
/*  972 */         return defaultPatternParser;
/*      */       }
/*  974 */       return this.patternParser;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.0")
/*      */     public void setTrailingSlashMatch(boolean trailingSlashMatch) {
/*  986 */       this.trailingSlashMatch = trailingSlashMatch;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.0")
/*      */     public boolean useTrailingSlashMatch() {
/*  995 */       return this.trailingSlashMatch;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public void setSuffixPatternMatch(boolean suffixPatternMatch) {
/* 1007 */       this.suffixPatternMatch = suffixPatternMatch;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public boolean useSuffixPatternMatch() {
/* 1017 */       return this.suffixPatternMatch;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public void setRegisteredSuffixPatternMatch(boolean registeredSuffixPatternMatch) {
/* 1032 */       this.registeredSuffixPatternMatch = registeredSuffixPatternMatch;
/* 1033 */       this.suffixPatternMatch = (registeredSuffixPatternMatch || this.suffixPatternMatch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public boolean useRegisteredSuffixPatternMatch() {
/* 1045 */       return this.registeredSuffixPatternMatch;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     @Deprecated
/*      */     public List<String> getFileExtensions() {
/* 1059 */       if (useRegisteredSuffixPatternMatch() && this.contentNegotiationManager != null) {
/* 1060 */         return this.contentNegotiationManager.getAllFileExtensions();
/*      */       }
/* 1062 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager) {
/* 1070 */       this.contentNegotiationManager = contentNegotiationManager;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public ContentNegotiationManager getContentNegotiationManager() {
/* 1079 */       return this.contentNegotiationManager;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\RequestMappingInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */