/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletForwardingController
/*     */   extends AbstractController
/*     */   implements BeanNameAware
/*     */ {
/*     */   @Nullable
/*     */   private String servletName;
/*     */   @Nullable
/*     */   private String beanName;
/*     */   
/*     */   public ServletForwardingController() {
/*  99 */     super(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletName(String servletName) {
/* 109 */     this.servletName = servletName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String name) {
/* 114 */     this.beanName = name;
/* 115 */     if (this.servletName == null) {
/* 116 */       this.servletName = name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 126 */     ServletContext servletContext = getServletContext();
/* 127 */     Assert.state((servletContext != null), "No ServletContext");
/* 128 */     RequestDispatcher rd = servletContext.getNamedDispatcher(this.servletName);
/* 129 */     if (rd == null) {
/* 130 */       throw new ServletException("No servlet with name '" + this.servletName + "' defined in web.xml");
/*     */     }
/*     */ 
/*     */     
/* 134 */     if (useInclude(request, response)) {
/* 135 */       rd.include((ServletRequest)request, (ServletResponse)response);
/* 136 */       if (this.logger.isTraceEnabled()) {
/* 137 */         this.logger.trace("Included servlet [" + this.servletName + "] in ServletForwardingController '" + this.beanName + "'");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 142 */       rd.forward((ServletRequest)request, (ServletResponse)response);
/* 143 */       if (this.logger.isTraceEnabled()) {
/* 144 */         this.logger.trace("Forwarded to servlet [" + this.servletName + "] in ServletForwardingController '" + this.beanName + "'");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean useInclude(HttpServletRequest request, HttpServletResponse response) {
/* 167 */     return (WebUtils.isIncludeRequest((ServletRequest)request) || response.isCommitted());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\ServletForwardingController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */