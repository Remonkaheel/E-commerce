/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotatedMethod;
/*     */ import org.springframework.core.annotation.SynthesizingMethodParameter;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletInvocableHandlerMethod
/*     */   extends InvocableHandlerMethod
/*     */ {
/*  68 */   private static final Method CALLABLE_METHOD = ClassUtils.getMethod(Callable.class, "call", new Class[0]);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletInvocableHandlerMethod(Object handler, Method method) {
/*  78 */     super(handler, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletInvocableHandlerMethod(Object handler, Method method, @Nullable MessageSource messageSource) {
/*  88 */     super(handler, method, messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletInvocableHandlerMethod(HandlerMethod handlerMethod) {
/*  95 */     super(handlerMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerMethodReturnValueHandlers(HandlerMethodReturnValueHandlerComposite returnValueHandlers) {
/* 104 */     this.returnValueHandlers = returnValueHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokeAndHandle(ServletWebRequest webRequest, ModelAndViewContainer mavContainer, Object... providedArgs) throws Exception {
/* 118 */     Object returnValue = invokeForRequest((NativeWebRequest)webRequest, mavContainer, providedArgs);
/* 119 */     setResponseStatus(webRequest);
/*     */     
/* 121 */     if (returnValue == null) {
/* 122 */       if (isRequestNotModified(webRequest) || getResponseStatus() != null || mavContainer.isRequestHandled()) {
/* 123 */         disableContentCachingIfNecessary(webRequest);
/* 124 */         mavContainer.setRequestHandled(true);
/*     */         
/*     */         return;
/*     */       } 
/* 128 */     } else if (StringUtils.hasText(getResponseStatusReason())) {
/* 129 */       mavContainer.setRequestHandled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 133 */     mavContainer.setRequestHandled(false);
/* 134 */     Assert.state((this.returnValueHandlers != null), "No return value handlers");
/*     */     try {
/* 136 */       this.returnValueHandlers.handleReturnValue(returnValue, 
/* 137 */           getReturnValueType(returnValue), mavContainer, (NativeWebRequest)webRequest);
/*     */     }
/* 139 */     catch (Exception ex) {
/* 140 */       if (logger.isTraceEnabled()) {
/* 141 */         logger.trace(formatErrorForReturnValue(returnValue), ex);
/*     */       }
/* 143 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setResponseStatus(ServletWebRequest webRequest) throws IOException {
/* 151 */     HttpStatusCode status = getResponseStatus();
/* 152 */     if (status == null) {
/*     */       return;
/*     */     }
/*     */     
/* 156 */     HttpServletResponse response = webRequest.getResponse();
/* 157 */     if (response != null) {
/* 158 */       String reason = getResponseStatusReason();
/* 159 */       if (StringUtils.hasText(reason)) {
/* 160 */         response.sendError(status.value(), reason);
/*     */       } else {
/*     */         
/* 163 */         response.setStatus(status.value());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 168 */     webRequest.getRequest().setAttribute(View.RESPONSE_STATUS_ATTRIBUTE, status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isRequestNotModified(ServletWebRequest webRequest) {
/* 177 */     return webRequest.isNotModified();
/*     */   }
/*     */   
/*     */   private void disableContentCachingIfNecessary(ServletWebRequest webRequest) {
/* 181 */     if (isRequestNotModified(webRequest)) {
/* 182 */       HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/* 183 */       Assert.notNull(response, "Expected HttpServletResponse");
/* 184 */       if (StringUtils.hasText(response.getHeader("ETag"))) {
/* 185 */         HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 186 */         Assert.notNull(request, "Expected HttpServletRequest");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String formatErrorForReturnValue(@Nullable Object returnValue) {
/* 192 */     return "Error handling return value=[" + String.valueOf(returnValue) + "]" + (
/* 193 */       (returnValue != null) ? (", type=" + returnValue.getClass().getName()) : "") + " in " + 
/* 194 */       toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServletInvocableHandlerMethod wrapConcurrentResult(@Nullable Object result) {
/* 204 */     return new ConcurrentResultHandlerMethod(result, new ConcurrentResultMethodParameter(result));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ConcurrentResultHandlerMethod
/*     */     extends ServletInvocableHandlerMethod
/*     */   {
/*     */     private final MethodParameter returnType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrentResultHandlerMethod(Object result, ServletInvocableHandlerMethod.ConcurrentResultMethodParameter returnType) {
/* 219 */       super(() -> { if (result instanceof Exception) { Exception exception = (Exception)result; throw exception; }  if (result instanceof Throwable) { Throwable throwable = (Throwable)result; throw new ServletException("Async processing failed: " + String.valueOf(result), throwable); }  return result; }ServletInvocableHandlerMethod.CALLABLE_METHOD);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       if (ServletInvocableHandlerMethod.this.returnValueHandlers != null) {
/* 230 */         setHandlerMethodReturnValueHandlers(ServletInvocableHandlerMethod.this.returnValueHandlers);
/*     */       }
/* 232 */       this.returnType = (MethodParameter)returnType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> getBeanType() {
/* 240 */       return ServletInvocableHandlerMethod.this.getBeanType();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodParameter getReturnValueType(@Nullable Object returnValue) {
/* 249 */       return this.returnType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <A extends java.lang.annotation.Annotation> A getMethodAnnotation(Class<A> annotationType) {
/* 258 */       return (A)ServletInvocableHandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <A extends java.lang.annotation.Annotation> boolean hasMethodAnnotation(Class<A> annotationType) {
/* 266 */       return ServletInvocableHandlerMethod.this.hasMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class ConcurrentResultMethodParameter
/*     */     extends AnnotatedMethod.AnnotatedMethodParameter
/*     */   {
/*     */     @Nullable
/*     */     private final Object returnValue;
/*     */ 
/*     */     
/*     */     private final ResolvableType returnType;
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrentResultMethodParameter(Object returnValue) {
/* 284 */       super((AnnotatedMethod)ServletInvocableHandlerMethod.this, -1);
/* 285 */       this.returnValue = returnValue;
/* 286 */       ReactiveTypeHandler.CollectedValuesList cvList = (ReactiveTypeHandler.CollectedValuesList)returnValue; this
/*     */ 
/*     */ 
/*     */         
/* 290 */         .returnType = (returnValue instanceof ReactiveTypeHandler.CollectedValuesList) ? cvList.getReturnType() : (KotlinDetector.isSuspendingFunction(getMethod()) ? ResolvableType.forMethodParameter(ServletInvocableHandlerMethod.this.getReturnType()) : ResolvableType.forType(super.getGenericParameterType()).getGeneric(new int[0]));
/*     */     }
/*     */     
/*     */     public ConcurrentResultMethodParameter(ConcurrentResultMethodParameter original) {
/* 294 */       super((AnnotatedMethod)ServletInvocableHandlerMethod.this, original);
/* 295 */       this.returnValue = original.returnValue;
/* 296 */       this.returnType = original.returnType;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getParameterType() {
/* 301 */       if (this.returnValue != null) {
/* 302 */         return this.returnValue.getClass();
/*     */       }
/* 304 */       if (!ResolvableType.NONE.equals(this.returnType)) {
/* 305 */         return this.returnType.toClass();
/*     */       }
/* 307 */       return super.getParameterType();
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getGenericParameterType() {
/* 312 */       return this.returnType.getType();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T extends java.lang.annotation.Annotation> boolean hasMethodAnnotation(Class<T> annotationType) {
/* 319 */       return (super.hasMethodAnnotation(annotationType) || (annotationType == ResponseBody.class && this.returnValue instanceof ReactiveTypeHandler.CollectedValuesList));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrentResultMethodParameter clone() {
/* 326 */       return new ConcurrentResultMethodParameter(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletInvocableHandlerMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */