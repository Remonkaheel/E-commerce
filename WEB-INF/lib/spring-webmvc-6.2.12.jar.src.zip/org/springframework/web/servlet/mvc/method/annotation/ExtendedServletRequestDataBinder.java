/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedServletRequestDataBinder
/*     */   extends ServletRequestDataBinder
/*     */ {
/*  57 */   private static final Set<String> FILTERED_HEADER_NAMES = Set.of(new String[] { "accept", "authorization", "connection", "cookie", "from", "host", "origin", "priority", "range", "referer", "upgrade" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Predicate<String> headerPredicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedServletRequestDataBinder(@Nullable Object target) {
/*  71 */     super(target);
/*     */     this.headerPredicate = (name -> !FILTERED_HEADER_NAMES.contains(name.toLowerCase(Locale.ROOT)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedServletRequestDataBinder(@Nullable Object target, String objectName) {
/*  82 */     super(target, objectName);
/*     */     this.headerPredicate = (name -> !FILTERED_HEADER_NAMES.contains(name.toLowerCase(Locale.ROOT)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHeaderPredicate(Predicate<String> headerPredicate) {
/*  93 */     this.headerPredicate = this.headerPredicate.and(headerPredicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderPredicate(Predicate<String> headerPredicate) {
/* 105 */     this.headerPredicate = headerPredicate;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletRequestDataBinder.ServletRequestValueResolver createValueResolver(ServletRequest request) {
/* 111 */     return new ExtendedServletRequestValueResolver(request, (WebDataBinder)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addBindValues(MutablePropertyValues mpvs, ServletRequest request) {
/* 119 */     Map<String, String> uriVars = getUriVars(request);
/* 120 */     if (uriVars != null) {
/* 121 */       uriVars.forEach((name, value) -> addValueIfNotPresent(mpvs, "URI variable", name, value));
/*     */     }
/* 123 */     if (request instanceof HttpServletRequest) { HttpServletRequest httpRequest = (HttpServletRequest)request;
/* 124 */       Enumeration<String> names = httpRequest.getHeaderNames();
/* 125 */       while (names.hasMoreElements()) {
/* 126 */         String name = names.nextElement();
/* 127 */         Object value = getHeaderValue(httpRequest, name);
/* 128 */         if (value != null) {
/* 129 */           name = normalizeHeaderName(name);
/* 130 */           addValueIfNotPresent(mpvs, "Header", name, value);
/*     */         } 
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Map<String, String> getUriVars(ServletRequest request) {
/* 139 */     return (Map<String, String>)request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/*     */   }
/*     */   
/*     */   private static void addValueIfNotPresent(MutablePropertyValues mpvs, String label, String name, Object value) {
/* 143 */     if (mpvs.contains(name)) {
/* 144 */       if (logger.isDebugEnabled()) {
/* 145 */         logger.debug(label + " '" + label + "' overridden by request bind value.");
/*     */       }
/*     */     } else {
/*     */       
/* 149 */       mpvs.addPropertyValue(name, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getHeaderValue(HttpServletRequest request, String name) {
/* 155 */     if (!this.headerPredicate.test(name)) {
/* 156 */       return null;
/*     */     }
/*     */     
/* 159 */     Enumeration<String> valuesEnum = request.getHeaders(name);
/* 160 */     if (!valuesEnum.hasMoreElements()) {
/* 161 */       return null;
/*     */     }
/*     */     
/* 164 */     String value = valuesEnum.nextElement();
/* 165 */     if (!valuesEnum.hasMoreElements()) {
/* 166 */       return value;
/*     */     }
/*     */     
/* 169 */     List<Object> values = new ArrayList();
/* 170 */     values.add(value);
/* 171 */     while (valuesEnum.hasMoreElements()) {
/* 172 */       values.add(valuesEnum.nextElement());
/*     */     }
/* 174 */     return values;
/*     */   }
/*     */   
/*     */   private static String normalizeHeaderName(String name) {
/* 178 */     return StringUtils.uncapitalize(name.replace("-", ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ExtendedServletRequestValueResolver
/*     */     extends ServletRequestDataBinder.ServletRequestValueResolver
/*     */   {
/*     */     ExtendedServletRequestValueResolver(ServletRequest request, WebDataBinder dataBinder) {
/* 188 */       super(request, dataBinder);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected Object getRequestParameter(String name, Class<?> type) {
/* 194 */       Object value = super.getRequestParameter(name, type);
/* 195 */       if (value == null) {
/* 196 */         Map<String, String> uriVars = ExtendedServletRequestDataBinder.getUriVars(getRequest());
/* 197 */         if (uriVars != null) {
/* 198 */           value = uriVars.get(name);
/*     */         }
/* 200 */         if (value == null) { ServletRequest servletRequest = getRequest(); if (servletRequest instanceof HttpServletRequest) { HttpServletRequest httpServletRequest = (HttpServletRequest)servletRequest;
/* 201 */             value = ExtendedServletRequestDataBinder.this.getHeaderValue(httpServletRequest, name); }
/*     */            }
/*     */       
/* 204 */       }  return value;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Set<String> initParameterNames(ServletRequest request) {
/* 209 */       Set<String> set = super.initParameterNames(request);
/* 210 */       Map<String, String> uriVars = ExtendedServletRequestDataBinder.getUriVars(getRequest());
/* 211 */       if (uriVars != null) {
/* 212 */         set.addAll(uriVars.keySet());
/*     */       }
/* 214 */       if (request instanceof HttpServletRequest) { HttpServletRequest httpServletRequest = (HttpServletRequest)request;
/* 215 */         Enumeration<String> enumeration = httpServletRequest.getHeaderNames();
/* 216 */         while (enumeration.hasMoreElements()) {
/* 217 */           String name = enumeration.nextElement();
/* 218 */           if (ExtendedServletRequestDataBinder.this.headerPredicate.test(name)) {
/* 219 */             set.add(ExtendedServletRequestDataBinder.normalizeHeaderName(name));
/*     */           }
/*     */         }  }
/*     */       
/* 223 */       return set;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ExtendedServletRequestDataBinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */