/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.PushBuilder;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.security.Principal;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletRequestMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/*  74 */     Class<?> paramType = parameter.getParameterType();
/*  75 */     return (WebRequest.class.isAssignableFrom(paramType) || ServletRequest.class
/*  76 */       .isAssignableFrom(paramType) || MultipartRequest.class
/*  77 */       .isAssignableFrom(paramType) || HttpSession.class
/*  78 */       .isAssignableFrom(paramType) || PushBuilder.class
/*  79 */       .isAssignableFrom(paramType) || (Principal.class
/*  80 */       .isAssignableFrom(paramType) && !parameter.hasParameterAnnotations()) || InputStream.class
/*  81 */       .isAssignableFrom(paramType) || Reader.class
/*  82 */       .isAssignableFrom(paramType) || HttpMethod.class == paramType || Locale.class == paramType || TimeZone.class == paramType || ZoneId.class == paramType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory) throws Exception {
/*  94 */     Class<?> paramType = parameter.getParameterType();
/*     */ 
/*     */     
/*  97 */     if (WebRequest.class.isAssignableFrom(paramType)) {
/*  98 */       if (!paramType.isInstance(webRequest)) {
/*  99 */         throw new IllegalStateException("Current request is not of type [" + paramType
/* 100 */             .getName() + "]: " + String.valueOf(webRequest));
/*     */       }
/* 102 */       return webRequest;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     if (ServletRequest.class.isAssignableFrom(paramType) || MultipartRequest.class.isAssignableFrom(paramType)) {
/* 107 */       return resolveNativeRequest(webRequest, paramType);
/*     */     }
/*     */ 
/*     */     
/* 111 */     return resolveArgument(paramType, resolveNativeRequest(webRequest, HttpServletRequest.class));
/*     */   }
/*     */   
/*     */   private <T> T resolveNativeRequest(NativeWebRequest webRequest, Class<T> requiredType) {
/* 115 */     T nativeRequest = (T)webRequest.getNativeRequest(requiredType);
/* 116 */     if (nativeRequest == null) {
/* 117 */       throw new IllegalStateException("Current request is not of type [" + requiredType
/* 118 */           .getName() + "]: " + String.valueOf(webRequest));
/*     */     }
/* 120 */     return nativeRequest;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object resolveArgument(Class<?> paramType, HttpServletRequest request) throws IOException {
/* 125 */     if (HttpSession.class.isAssignableFrom(paramType)) {
/* 126 */       HttpSession session = request.getSession();
/* 127 */       if (session != null && !paramType.isInstance(session)) {
/* 128 */         throw new IllegalStateException("Current session is not of type [" + paramType
/* 129 */             .getName() + "]: " + String.valueOf(session));
/*     */       }
/* 131 */       return session;
/*     */     } 
/* 133 */     if (PushBuilder.class.isAssignableFrom(paramType)) {
/* 134 */       PushBuilder pushBuilder = request.newPushBuilder();
/* 135 */       if (pushBuilder != null && !paramType.isInstance(pushBuilder)) {
/* 136 */         throw new IllegalStateException("Current push builder is not of type [" + paramType
/* 137 */             .getName() + "]: " + String.valueOf(pushBuilder));
/*     */       }
/* 139 */       return pushBuilder;
/*     */     } 
/* 141 */     if (InputStream.class.isAssignableFrom(paramType)) {
/* 142 */       ServletInputStream servletInputStream = request.getInputStream();
/* 143 */       if (servletInputStream != null && !paramType.isInstance(servletInputStream)) {
/* 144 */         throw new IllegalStateException("Request input stream is not of type [" + paramType
/* 145 */             .getName() + "]: " + String.valueOf(servletInputStream));
/*     */       }
/* 147 */       return servletInputStream;
/*     */     } 
/* 149 */     if (Reader.class.isAssignableFrom(paramType)) {
/* 150 */       Reader reader = request.getReader();
/* 151 */       if (reader != null && !paramType.isInstance(reader)) {
/* 152 */         throw new IllegalStateException("Request body reader is not of type [" + paramType
/* 153 */             .getName() + "]: " + String.valueOf(reader));
/*     */       }
/* 155 */       return reader;
/*     */     } 
/* 157 */     if (Principal.class.isAssignableFrom(paramType)) {
/* 158 */       Principal userPrincipal = request.getUserPrincipal();
/* 159 */       if (userPrincipal != null && !paramType.isInstance(userPrincipal)) {
/* 160 */         throw new IllegalStateException("Current user principal is not of type [" + paramType
/* 161 */             .getName() + "]: " + String.valueOf(userPrincipal));
/*     */       }
/* 163 */       return userPrincipal;
/*     */     } 
/* 165 */     if (HttpMethod.class == paramType) {
/* 166 */       return HttpMethod.valueOf(request.getMethod());
/*     */     }
/* 168 */     if (Locale.class == paramType) {
/* 169 */       return RequestContextUtils.getLocale(request);
/*     */     }
/* 171 */     if (TimeZone.class == paramType) {
/* 172 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 173 */       return (timeZone != null) ? timeZone : TimeZone.getDefault();
/*     */     } 
/* 175 */     if (ZoneId.class == paramType) {
/* 176 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 177 */       return (timeZone != null) ? timeZone.toZoneId() : ZoneId.systemDefault();
/*     */     } 
/*     */ 
/*     */     
/* 181 */     throw new UnsupportedOperationException("Unknown parameter type: " + paramType.getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletRequestMethodArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */