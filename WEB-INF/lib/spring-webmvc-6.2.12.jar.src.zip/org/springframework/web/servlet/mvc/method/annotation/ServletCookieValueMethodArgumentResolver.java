/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.annotation.AbstractCookieValueMethodArgumentResolver;
/*    */ import org.springframework.web.util.UrlPathHelper;
/*    */ import org.springframework.web.util.WebUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletCookieValueMethodArgumentResolver
/*    */   extends AbstractCookieValueMethodArgumentResolver
/*    */ {
/* 40 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*    */ 
/*    */   
/*    */   public ServletCookieValueMethodArgumentResolver(@Nullable ConfigurableBeanFactory beanFactory) {
/* 44 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUrlDecode(boolean urlDecode) {
/* 57 */     this.urlPathHelper.setUrlDecode(urlDecode);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
/* 66 */     this.urlPathHelper = urlPathHelper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected Object resolveName(String cookieName, MethodParameter parameter, NativeWebRequest webRequest) throws Exception {
/* 75 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 76 */     Assert.state((servletRequest != null), "No HttpServletRequest");
/*    */     
/* 78 */     Cookie cookieValue = WebUtils.getCookie(servletRequest, cookieName);
/* 79 */     if (Cookie.class.isAssignableFrom(parameter.getNestedParameterType())) {
/* 80 */       return cookieValue;
/*    */     }
/* 82 */     if (cookieValue != null) {
/* 83 */       return this.urlPathHelper.decodeRequestString(servletRequest, cookieValue.getValue());
/*    */     }
/*    */     
/* 86 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletCookieValueMethodArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */