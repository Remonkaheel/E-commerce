/*     */ package org.springframework.web.servlet.mvc.method;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.servlet.mvc.condition.NameValueExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PartialMatchHelper
/*     */ {
/* 304 */   private final List<PartialMatch> partialMatches = new ArrayList<>();
/*     */   
/*     */   PartialMatchHelper(Set<RequestMappingInfo> infos, HttpServletRequest request) {
/* 307 */     for (RequestMappingInfo info : infos) {
/* 308 */       if (info.<T>getActivePatternsCondition().getMatchingCondition(request) != null) {
/* 309 */         this.partialMatches.add(new PartialMatch(info, request));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 318 */     return this.partialMatches.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMethodsMismatch() {
/* 325 */     for (PartialMatch match : this.partialMatches) {
/* 326 */       if (match.hasMethodsMatch()) {
/* 327 */         return false;
/*     */       }
/*     */     } 
/* 330 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasConsumesMismatch() {
/* 337 */     for (PartialMatch match : this.partialMatches) {
/* 338 */       if (match.hasConsumesMatch()) {
/* 339 */         return false;
/*     */       }
/*     */     } 
/* 342 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProducesMismatch() {
/* 349 */     for (PartialMatch match : this.partialMatches) {
/* 350 */       if (match.hasProducesMatch()) {
/* 351 */         return false;
/*     */       }
/*     */     } 
/* 354 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasParamsMismatch() {
/* 361 */     for (PartialMatch match : this.partialMatches) {
/* 362 */       if (match.hasParamsMatch()) {
/* 363 */         return false;
/*     */       }
/*     */     } 
/* 366 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getAllowedMethods() {
/* 373 */     Set<String> result = new LinkedHashSet<>();
/* 374 */     for (PartialMatch match : this.partialMatches) {
/* 375 */       for (RequestMethod method : match.getInfo().getMethodsCondition().getMethods()) {
/* 376 */         result.add(method.name());
/*     */       }
/*     */     } 
/* 379 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MediaType> getConsumableMediaTypes() {
/* 387 */     Set<MediaType> result = new LinkedHashSet<>();
/* 388 */     for (PartialMatch match : this.partialMatches) {
/* 389 */       if (match.hasMethodsMatch()) {
/* 390 */         result.addAll(match.getInfo().getConsumesCondition().getConsumableMediaTypes());
/*     */       }
/*     */     } 
/* 393 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MediaType> getProducibleMediaTypes() {
/* 401 */     Set<MediaType> result = new LinkedHashSet<>();
/* 402 */     for (PartialMatch match : this.partialMatches) {
/* 403 */       if (match.hasConsumesMatch()) {
/* 404 */         result.addAll(match.getInfo().getProducesCondition().getProducibleMediaTypes());
/*     */       }
/*     */     } 
/* 407 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String[]> getParamConditions() {
/* 415 */     List<String[]> result = (List)new ArrayList<>();
/* 416 */     for (PartialMatch match : this.partialMatches) {
/* 417 */       if (match.hasProducesMatch()) {
/* 418 */         Set<NameValueExpression<String>> set = match.getInfo().getParamsCondition().getExpressions();
/* 419 */         if (!CollectionUtils.isEmpty(set)) {
/* 420 */           int i = 0;
/* 421 */           String[] array = new String[set.size()];
/* 422 */           for (NameValueExpression<String> expression : set) {
/* 423 */             array[i++] = expression.toString();
/*     */           }
/* 425 */           result.add(array);
/*     */         } 
/*     */       } 
/*     */     } 
/* 429 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MediaType> getConsumablePatchMediaTypes() {
/* 437 */     Set<MediaType> result = new LinkedHashSet<>();
/* 438 */     for (PartialMatch match : this.partialMatches) {
/* 439 */       Set<RequestMethod> methods = match.getInfo().getMethodsCondition().getMethods();
/* 440 */       if (methods.isEmpty() || methods.contains(RequestMethod.PATCH)) {
/* 441 */         result.addAll(match.getInfo().getConsumesCondition().getConsumableMediaTypes());
/*     */       }
/*     */     } 
/* 444 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PartialMatch
/*     */   {
/*     */     private final RequestMappingInfo info;
/*     */ 
/*     */     
/*     */     private final boolean methodsMatch;
/*     */ 
/*     */     
/*     */     private final boolean consumesMatch;
/*     */ 
/*     */     
/*     */     private final boolean producesMatch;
/*     */ 
/*     */     
/*     */     private final boolean paramsMatch;
/*     */ 
/*     */ 
/*     */     
/*     */     public PartialMatch(RequestMappingInfo info, HttpServletRequest request) {
/* 469 */       this.info = info;
/* 470 */       this.methodsMatch = (info.getMethodsCondition().getMatchingCondition(request) != null);
/* 471 */       this.consumesMatch = (info.getConsumesCondition().getMatchingCondition(request) != null);
/* 472 */       this.producesMatch = (info.getProducesCondition().getMatchingCondition(request) != null);
/* 473 */       this.paramsMatch = (info.getParamsCondition().getMatchingCondition(request) != null);
/*     */     }
/*     */     
/*     */     public RequestMappingInfo getInfo() {
/* 477 */       return this.info;
/*     */     }
/*     */     
/*     */     public boolean hasMethodsMatch() {
/* 481 */       return this.methodsMatch;
/*     */     }
/*     */     
/*     */     public boolean hasConsumesMatch() {
/* 485 */       return (hasMethodsMatch() && this.consumesMatch);
/*     */     }
/*     */     
/*     */     public boolean hasProducesMatch() {
/* 489 */       return (hasConsumesMatch() && this.producesMatch);
/*     */     }
/*     */     
/*     */     public boolean hasParamsMatch() {
/* 493 */       return (hasProducesMatch() && this.paramsMatch);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 498 */       return this.info.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\RequestMappingInfoHandlerMapping$PartialMatchHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */