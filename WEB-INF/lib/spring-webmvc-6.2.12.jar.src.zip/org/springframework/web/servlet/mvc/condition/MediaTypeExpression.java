package org.springframework.web.servlet.mvc.condition;

import org.springframework.http.MediaType;

public interface MediaTypeExpression {
  MediaType getMediaType();
  
  boolean isNegated();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\condition\MediaTypeExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */