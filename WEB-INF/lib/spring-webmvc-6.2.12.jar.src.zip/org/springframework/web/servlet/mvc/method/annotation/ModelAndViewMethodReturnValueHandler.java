/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.SmartView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.view.FragmentsRendering;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelAndViewMethodReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   @Nullable
/*     */   private String[] redirectPatterns;
/*     */   
/*     */   public void setRedirectPatterns(@Nullable String... redirectPatterns) {
/*  62 */     this.redirectPatterns = redirectPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getRedirectPatterns() {
/*  71 */     return this.redirectPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsReturnType(MethodParameter returnType) {
/*  77 */     Class<?> type = returnType.getParameterType();
/*  78 */     if (Collection.class.isAssignableFrom(type)) {
/*  79 */       type = returnType.nested().getNestedParameterType();
/*     */     }
/*  81 */     return (ModelAndView.class.isAssignableFrom(type) || FragmentsRendering.class.isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
/*  89 */     if (returnValue == null) {
/*  90 */       mavContainer.setRequestHandled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  94 */     if (returnValue instanceof Collection) { Collection<?> mavs = (Collection)returnValue;
/*  95 */       returnValue = FragmentsRendering.with(mavs).build(); }
/*     */ 
/*     */     
/*  98 */     if (returnValue instanceof FragmentsRendering) { FragmentsRendering rendering = (FragmentsRendering)returnValue;
/*  99 */       mavContainer.setView(rendering);
/*     */       
/*     */       return; }
/*     */     
/* 103 */     ModelAndView mav = (ModelAndView)returnValue;
/* 104 */     if (mav.isReference()) {
/* 105 */       String viewName = mav.getViewName();
/* 106 */       mavContainer.setViewName(viewName);
/* 107 */       if (viewName != null && isRedirectViewName(viewName)) {
/* 108 */         mavContainer.setRedirectModelScenario(true);
/*     */       }
/*     */     } else {
/*     */       
/* 112 */       View view = mav.getView();
/* 113 */       mavContainer.setView(view);
/* 114 */       if (view instanceof SmartView) { SmartView smartView = (SmartView)view; if (smartView.isRedirectView())
/* 115 */           mavContainer.setRedirectModelScenario(true);  }
/*     */     
/*     */     } 
/* 118 */     mavContainer.setStatus(mav.getStatus());
/* 119 */     mavContainer.addAllAttributes(mav.getModel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isRedirectViewName(String viewName) {
/* 131 */     return (PatternMatchUtils.simpleMatch(this.redirectPatterns, viewName) || viewName.startsWith("redirect:"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ModelAndViewMethodReturnValueHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */