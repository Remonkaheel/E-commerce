/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.request.AsyncWebRequestInterceptor;
/*    */ import org.springframework.web.context.request.WebRequest;
/*    */ import org.springframework.web.context.request.WebRequestInterceptor;
/*    */ import org.springframework.web.servlet.AsyncHandlerInterceptor;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebRequestHandlerInterceptorAdapter
/*    */   implements AsyncHandlerInterceptor
/*    */ {
/*    */   private final WebRequestInterceptor requestInterceptor;
/*    */   
/*    */   public WebRequestHandlerInterceptorAdapter(WebRequestInterceptor requestInterceptor) {
/* 48 */     Assert.notNull(requestInterceptor, "WebRequestInterceptor must not be null");
/* 49 */     this.requestInterceptor = requestInterceptor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
/* 57 */     this.requestInterceptor.preHandle((WebRequest)new DispatcherServletWebRequest(request, response));
/* 58 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {
/* 65 */     this.requestInterceptor.postHandle((WebRequest)new DispatcherServletWebRequest(request, response), (
/* 66 */         modelAndView != null && !modelAndView.wasCleared()) ? modelAndView.getModelMap() : null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {
/* 73 */     this.requestInterceptor.afterCompletion((WebRequest)new DispatcherServletWebRequest(request, response), ex);
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterConcurrentHandlingStarted(HttpServletRequest request, HttpServletResponse response, Object handler) {
/* 78 */     WebRequestInterceptor webRequestInterceptor = this.requestInterceptor; if (webRequestInterceptor instanceof AsyncWebRequestInterceptor) { AsyncWebRequestInterceptor asyncInterceptor = (AsyncWebRequestInterceptor)webRequestInterceptor;
/* 79 */       DispatcherServletWebRequest webRequest = new DispatcherServletWebRequest(request, response);
/* 80 */       asyncInterceptor.afterConcurrentHandlingStarted((WebRequest)webRequest); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\WebRequestHandlerInterceptorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */