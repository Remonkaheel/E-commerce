/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogDelegateFactory;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.cors.CorsProcessor;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ import org.springframework.web.cors.DefaultCorsProcessor;
/*     */ import org.springframework.web.cors.PreFlightRequestHandler;
/*     */ import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandlerMapping
/*     */   extends WebApplicationObjectSupport
/*     */   implements HandlerMapping, Ordered, BeanNameAware
/*     */ {
/*  83 */   static final String SUPPRESS_LOGGING_ATTRIBUTE = AbstractHandlerMapping.class.getName() + ".SUPPRESS_LOGGING";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   protected final Log mappingsLogger = LogDelegateFactory.getHiddenLog(HandlerMapping.class.getName() + ".Mappings");
/*     */   
/*     */   @Nullable
/*     */   private Object defaultHandler;
/*     */   
/*     */   @Nullable
/*  94 */   private PathPatternParser patternParser = new PathPatternParser();
/*     */ 
/*     */   
/*  97 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */   
/*  99 */   private PathMatcher pathMatcher = (PathMatcher)new AntPathMatcher();
/*     */   
/* 101 */   private final List<Object> interceptors = new ArrayList();
/*     */   
/* 103 */   private final List<HandlerInterceptor> adaptedInterceptors = new ArrayList<>();
/*     */   
/*     */   @Nullable
/*     */   private CorsConfigurationSource corsConfigurationSource;
/*     */   
/* 108 */   private CorsProcessor corsProcessor = (CorsProcessor)new DefaultCorsProcessor();
/*     */   
/* 110 */   private int order = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultHandler(@Nullable Object defaultHandler) {
/* 122 */     this.defaultHandler = defaultHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getDefaultHandler() {
/* 131 */     return this.defaultHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternParser(@Nullable PathPatternParser patternParser) {
/* 167 */     this.patternParser = patternParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PathPatternParser getPatternParser() {
/* 178 */     return this.patternParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath) {
/* 190 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/* 191 */     CorsConfigurationSource corsConfigurationSource = this.corsConfigurationSource; if (corsConfigurationSource instanceof UrlBasedCorsConfigurationSource) { UrlBasedCorsConfigurationSource urlConfigSource = (UrlBasedCorsConfigurationSource)corsConfigurationSource;
/* 192 */       urlConfigSource.setAlwaysUseFullPath(alwaysUseFullPath); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public void setUrlDecode(boolean urlDecode) {
/* 205 */     this.urlPathHelper.setUrlDecode(urlDecode);
/* 206 */     CorsConfigurationSource corsConfigurationSource = this.corsConfigurationSource; if (corsConfigurationSource instanceof UrlBasedCorsConfigurationSource) { UrlBasedCorsConfigurationSource urlConfigSource = (UrlBasedCorsConfigurationSource)corsConfigurationSource;
/* 207 */       urlConfigSource.setUrlDecode(urlDecode); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public void setRemoveSemicolonContent(boolean removeSemicolonContent) {
/* 220 */     this.urlPathHelper.setRemoveSemicolonContent(removeSemicolonContent);
/* 221 */     CorsConfigurationSource corsConfigurationSource = this.corsConfigurationSource; if (corsConfigurationSource instanceof UrlBasedCorsConfigurationSource) { UrlBasedCorsConfigurationSource urlConfigSource = (UrlBasedCorsConfigurationSource)corsConfigurationSource;
/* 222 */       urlConfigSource.setRemoveSemicolonContent(removeSemicolonContent); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
/* 232 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 233 */     this.urlPathHelper = urlPathHelper;
/* 234 */     CorsConfigurationSource corsConfigurationSource = this.corsConfigurationSource; if (corsConfigurationSource instanceof UrlBasedCorsConfigurationSource) { UrlBasedCorsConfigurationSource urlConfigSource = (UrlBasedCorsConfigurationSource)corsConfigurationSource;
/* 235 */       urlConfigSource.setUrlPathHelper(urlPathHelper); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 243 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathMatcher(PathMatcher pathMatcher) {
/* 254 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 255 */     this.pathMatcher = pathMatcher;
/* 256 */     CorsConfigurationSource corsConfigurationSource = this.corsConfigurationSource; if (corsConfigurationSource instanceof UrlBasedCorsConfigurationSource) { UrlBasedCorsConfigurationSource urlConfigSource = (UrlBasedCorsConfigurationSource)corsConfigurationSource;
/* 257 */       urlConfigSource.setPathMatcher(pathMatcher); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathMatcher getPathMatcher() {
/* 265 */     return this.pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterceptors(Object... interceptors) {
/* 281 */     this.interceptors.addAll(Arrays.asList(interceptors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final HandlerInterceptor[] getAdaptedInterceptors() {
/* 293 */     return !this.adaptedInterceptors.isEmpty() ? 
/* 294 */       this.adaptedInterceptors.<HandlerInterceptor>toArray(new HandlerInterceptor[0]) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final MappedInterceptor[] getMappedInterceptors() {
/* 303 */     List<MappedInterceptor> mappedInterceptors = new ArrayList<>(this.adaptedInterceptors.size());
/* 304 */     for (HandlerInterceptor interceptor : this.adaptedInterceptors) {
/* 305 */       if (interceptor instanceof MappedInterceptor) { MappedInterceptor mappedInterceptor = (MappedInterceptor)interceptor;
/* 306 */         mappedInterceptors.add(mappedInterceptor); }
/*     */     
/*     */     } 
/* 309 */     return !mappedInterceptors.isEmpty() ? mappedInterceptors.<MappedInterceptor>toArray(new MappedInterceptor[0]) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorsConfigurations(Map<String, CorsConfiguration> corsConfigurations) {
/*     */     UrlBasedCorsConfigurationSource source;
/* 323 */     if (CollectionUtils.isEmpty(corsConfigurations)) {
/* 324 */       this.corsConfigurationSource = null;
/*     */       
/*     */       return;
/*     */     } 
/* 328 */     if (getPatternParser() != null) {
/* 329 */       source = new UrlBasedCorsConfigurationSource(getPatternParser());
/* 330 */       source.setCorsConfigurations(corsConfigurations);
/*     */     } else {
/*     */       
/* 333 */       source = new UrlBasedCorsConfigurationSource();
/* 334 */       source.setCorsConfigurations(corsConfigurations);
/* 335 */       source.setPathMatcher(this.pathMatcher);
/* 336 */       source.setUrlPathHelper(this.urlPathHelper);
/*     */     } 
/* 338 */     setCorsConfigurationSource((CorsConfigurationSource)source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorsConfigurationSource(CorsConfigurationSource source) {
/* 351 */     Assert.notNull(source, "CorsConfigurationSource must not be null");
/* 352 */     this.corsConfigurationSource = source;
/* 353 */     if (source instanceof UrlBasedCorsConfigurationSource) { UrlBasedCorsConfigurationSource urlConfigSource = (UrlBasedCorsConfigurationSource)source;
/* 354 */       urlConfigSource.setAllowInitLookupPath(false); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CorsConfigurationSource getCorsConfigurationSource() {
/* 365 */     return this.corsConfigurationSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorsProcessor(CorsProcessor corsProcessor) {
/* 375 */     Assert.notNull(corsProcessor, "CorsProcessor must not be null");
/* 376 */     this.corsProcessor = corsProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsProcessor getCorsProcessor() {
/* 383 */     return this.corsProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int order) {
/* 392 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 397 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String name) {
/* 402 */     this.beanName = name;
/*     */   }
/*     */   
/*     */   protected String formatMappingName() {
/* 406 */     return (this.beanName != null) ? ("'" + this.beanName + "'") : getClass().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initApplicationContext() throws BeansException {
/* 417 */     extendInterceptors(this.interceptors);
/* 418 */     detectMappedInterceptors(this.adaptedInterceptors);
/* 419 */     initInterceptors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendInterceptors(List<Object> interceptors) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void detectMappedInterceptors(List<HandlerInterceptor> mappedInterceptors) {
/* 444 */     mappedInterceptors.addAll(BeanFactoryUtils.beansOfTypeIncludingAncestors((ListableBeanFactory)
/* 445 */           obtainApplicationContext(), MappedInterceptor.class, true, false).values());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInterceptors() {
/* 455 */     if (!this.interceptors.isEmpty()) {
/* 456 */       for (int i = 0; i < this.interceptors.size(); i++) {
/* 457 */         Object interceptor = this.interceptors.get(i);
/* 458 */         if (interceptor == null) {
/* 459 */           throw new IllegalArgumentException("Entry number " + i + " in interceptors array is null");
/*     */         }
/* 461 */         this.adaptedInterceptors.add(adaptInterceptor(interceptor));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HandlerInterceptor adaptInterceptor(Object interceptor) {
/* 479 */     if (interceptor instanceof HandlerInterceptor) { HandlerInterceptor handlerInterceptor = (HandlerInterceptor)interceptor;
/* 480 */       return handlerInterceptor; }
/*     */     
/* 482 */     if (interceptor instanceof WebRequestInterceptor) { WebRequestInterceptor webRequestInterceptor = (WebRequestInterceptor)interceptor;
/* 483 */       return (HandlerInterceptor)new WebRequestHandlerInterceptorAdapter(webRequestInterceptor); }
/*     */ 
/*     */     
/* 486 */     throw new IllegalArgumentException("Interceptor type not supported: " + interceptor.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesPathPatterns() {
/* 496 */     return (getPatternParser() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final HandlerExecutionChain getHandler(HttpServletRequest request) throws Exception {
/* 509 */     Object handler = getHandlerInternal(request);
/* 510 */     if (handler == null) {
/* 511 */       handler = getDefaultHandler();
/*     */     }
/* 513 */     if (handler == null) {
/* 514 */       return null;
/*     */     }
/*     */     
/* 517 */     if (handler instanceof String) { String handlerName = (String)handler;
/* 518 */       handler = obtainApplicationContext().getBean(handlerName); }
/*     */ 
/*     */ 
/*     */     
/* 522 */     if (!ServletRequestPathUtils.hasCachedPath((ServletRequest)request)) {
/* 523 */       initLookupPath(request);
/*     */     }
/*     */     
/* 526 */     HandlerExecutionChain executionChain = getHandlerExecutionChain(handler, request);
/*     */     
/* 528 */     if (request.getAttribute(SUPPRESS_LOGGING_ATTRIBUTE) == null) {
/* 529 */       if (this.logger.isTraceEnabled()) {
/* 530 */         this.logger.trace("Mapped to " + String.valueOf(handler));
/*     */       }
/* 532 */       else if (this.logger.isDebugEnabled() && !DispatcherType.ASYNC.equals(request.getDispatcherType())) {
/* 533 */         this.logger.debug("Mapped to " + String.valueOf(executionChain.getHandler()));
/*     */       } 
/*     */     }
/*     */     
/* 537 */     if (hasCorsConfigurationSource(handler) || CorsUtils.isPreFlightRequest(request)) {
/* 538 */       CorsConfiguration config = getCorsConfiguration(handler, request);
/* 539 */       if (getCorsConfigurationSource() != null) {
/* 540 */         CorsConfiguration globalConfig = getCorsConfigurationSource().getCorsConfiguration(request);
/* 541 */         config = (globalConfig != null) ? globalConfig.combine(config) : config;
/*     */       } 
/* 543 */       if (config != null) {
/* 544 */         config.validateAllowCredentials();
/* 545 */         config.validateAllowPrivateNetwork();
/*     */       } 
/* 547 */       executionChain = getCorsHandlerExecutionChain(request, executionChain, config);
/*     */     } 
/*     */     
/* 550 */     return executionChain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Object getHandlerInternal(HttpServletRequest paramHttpServletRequest) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String initLookupPath(HttpServletRequest request) {
/* 585 */     if (usesPathPatterns()) {
/* 586 */       request.removeAttribute(UrlPathHelper.PATH_ATTRIBUTE);
/* 587 */       RequestPath requestPath = getRequestPath(request);
/* 588 */       String lookupPath = requestPath.pathWithinApplication().value();
/* 589 */       return UrlPathHelper.defaultInstance.removeSemicolonContent(lookupPath);
/*     */     } 
/*     */     
/* 592 */     return getUrlPathHelper().resolveAndCacheLookupPath(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestPath getRequestPath(HttpServletRequest request) {
/* 599 */     return (request.getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) ? 
/* 600 */       ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request) : 
/* 601 */       ServletRequestPathUtils.parseAndCache(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HandlerExecutionChain getHandlerExecutionChain(Object handler, HttpServletRequest request) {
/* 625 */     HandlerExecutionChain handlerExecutionChain = (HandlerExecutionChain)handler;
/* 626 */     HandlerExecutionChain chain = (handler instanceof HandlerExecutionChain) ? handlerExecutionChain : new HandlerExecutionChain(handler);
/*     */     
/* 628 */     for (HandlerInterceptor interceptor : this.adaptedInterceptors) {
/* 629 */       if (interceptor instanceof MappedInterceptor) { MappedInterceptor mappedInterceptor = (MappedInterceptor)interceptor;
/* 630 */         if (mappedInterceptor.matches(request)) {
/* 631 */           chain.addInterceptor(mappedInterceptor.getInterceptor());
/*     */         }
/*     */         continue; }
/*     */       
/* 635 */       chain.addInterceptor(interceptor);
/*     */     } 
/*     */     
/* 638 */     return chain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasCorsConfigurationSource(Object handler) {
/* 646 */     if (handler instanceof HandlerExecutionChain) { HandlerExecutionChain handlerExecutionChain = (HandlerExecutionChain)handler;
/* 647 */       handler = handlerExecutionChain.getHandler(); }
/*     */     
/* 649 */     return (handler instanceof CorsConfigurationSource || this.corsConfigurationSource != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CorsConfiguration getCorsConfiguration(Object handler, HttpServletRequest request) {
/* 661 */     Object resolvedHandler = handler;
/* 662 */     if (handler instanceof HandlerExecutionChain) { HandlerExecutionChain handlerExecutionChain = (HandlerExecutionChain)handler;
/* 663 */       resolvedHandler = handlerExecutionChain.getHandler(); }
/*     */     
/* 665 */     if (resolvedHandler instanceof CorsConfigurationSource) { CorsConfigurationSource configSource = (CorsConfigurationSource)resolvedHandler;
/* 666 */       return configSource.getCorsConfiguration(request); }
/*     */     
/* 668 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HandlerExecutionChain getCorsHandlerExecutionChain(HttpServletRequest request, HandlerExecutionChain chain, @Nullable CorsConfiguration config) {
/* 683 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 684 */       PreFlightHttpRequestHandler handler = new PreFlightHttpRequestHandler(config);
/* 685 */       chain.addInterceptor(0, handler);
/* 686 */       return new HandlerExecutionChain(handler, chain.getInterceptors());
/*     */     } 
/*     */     
/* 689 */     chain.addInterceptor(0, new CorsInterceptor(config));
/* 690 */     return chain;
/*     */   }
/*     */ 
/*     */   
/*     */   private class CorsInterceptor
/*     */     implements HandlerInterceptor, CorsConfigurationSource
/*     */   {
/*     */     @Nullable
/*     */     private final CorsConfiguration config;
/*     */     
/*     */     public CorsInterceptor(CorsConfiguration config) {
/* 701 */       this.config = config;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
/* 707 */       return this.config;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
/* 715 */       WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager((ServletRequest)request);
/* 716 */       if (asyncManager.hasConcurrentResult()) {
/* 717 */         return true;
/*     */       }
/*     */       
/* 720 */       return invokeCorsProcessor(request, response);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean invokeCorsProcessor(HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 726 */       return AbstractHandlerMapping.this.corsProcessor.processRequest(this.config, request, response);
/*     */     }
/*     */   }
/*     */   
/*     */   private final class PreFlightHttpRequestHandler
/*     */     extends CorsInterceptor
/*     */     implements HttpRequestHandler, PreFlightRequestHandler
/*     */   {
/*     */     public PreFlightHttpRequestHandler(CorsConfiguration config) {
/* 735 */       super(config);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleRequest(HttpServletRequest request, HttpServletResponse response) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void handlePreFlight(HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 745 */       invokeCorsProcessor(request, response);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\AbstractHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */