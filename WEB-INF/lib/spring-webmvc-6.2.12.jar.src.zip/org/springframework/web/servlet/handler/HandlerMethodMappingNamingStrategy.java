package org.springframework.web.servlet.handler;

import org.springframework.web.method.HandlerMethod;

@FunctionalInterface
public interface HandlerMethodMappingNamingStrategy<T> {
  String getName(HandlerMethod paramHandlerMethod, T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\HandlerMethodMappingNamingStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */