/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ import org.springframework.web.cors.PreFlightRequestHandler;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerMappingIntrospector
/*     */   implements CorsConfigurationSource, PreFlightRequestHandler, ApplicationContextAware, InitializingBean
/*     */ {
/*  97 */   private static final Log logger = LogFactory.getLog(HandlerMappingIntrospector.class.getName());
/*     */   
/*  99 */   private static final String CACHED_RESULT_ATTRIBUTE = HandlerMappingIntrospector.class
/* 100 */     .getName() + ".CachedResult";
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_CACHE_LIMIT = 2048;
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   @Nullable
/*     */   private List<HandlerMapping> handlerMappings;
/*     */   
/* 111 */   private Map<HandlerMapping, PathPatternMatchableHandlerMapping> pathPatternMappings = Collections.emptyMap();
/*     */   
/* 113 */   private int patternCacheLimit = 2048;
/*     */   
/* 115 */   private final CacheResultLogHelper cacheLogHelper = new CacheResultLogHelper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternCacheLimit(int patternCacheLimit) {
/* 126 */     this.patternCacheLimit = patternCacheLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPatternCacheLimit() {
/* 134 */     return this.patternCacheLimit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 139 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 144 */     if (this.handlerMappings == null) {
/* 145 */       Assert.notNull(this.applicationContext, "No ApplicationContext");
/* 146 */       this.handlerMappings = initHandlerMappings(this.applicationContext);
/*     */       
/* 148 */       this
/*     */ 
/*     */         
/* 151 */         .pathPatternMappings = (Map<HandlerMapping, PathPatternMatchableHandlerMapping>)this.handlerMappings.stream().filter(m -> { if (m instanceof MatchableHandlerMapping) { MatchableHandlerMapping hm = (MatchableHandlerMapping)m; if (hm.getPatternParser() != null); }  return false; }).map(hm -> (MatchableHandlerMapping)hm).collect(Collectors.toMap(hm -> hm, delegate -> new PathPatternMatchableHandlerMapping(delegate, getPatternCacheLimit())));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<HandlerMapping> initHandlerMappings(ApplicationContext context) {
/* 159 */     Map<String, HandlerMapping> beans = BeanFactoryUtils.beansOfTypeIncludingAncestors((ListableBeanFactory)context, HandlerMapping.class, true, false);
/*     */     
/* 161 */     if (!beans.isEmpty()) {
/* 162 */       List<HandlerMapping> mappings = new ArrayList<>(beans.values());
/* 163 */       AnnotationAwareOrderComparator.sort(mappings);
/* 164 */       return Collections.unmodifiableList(mappings);
/*     */     } 
/*     */     
/* 167 */     return Collections.unmodifiableList(initFallback(context));
/*     */   }
/*     */   
/*     */   private static List<HandlerMapping> initFallback(ApplicationContext applicationContext) {
/*     */     Properties properties;
/*     */     try {
/* 173 */       ClassPathResource classPathResource = new ClassPathResource("DispatcherServlet.properties", DispatcherServlet.class);
/* 174 */       properties = PropertiesLoaderUtils.loadProperties((Resource)classPathResource);
/*     */     }
/* 176 */     catch (IOException ex) {
/* 177 */       throw new IllegalStateException("Could not load DispatcherServlet.properties: " + ex.getMessage());
/*     */     } 
/*     */     
/* 180 */     String value = properties.getProperty(HandlerMapping.class.getName());
/* 181 */     String[] names = StringUtils.commaDelimitedListToStringArray(value);
/* 182 */     List<HandlerMapping> result = new ArrayList<>(names.length);
/* 183 */     for (String name : names) {
/*     */       try {
/* 185 */         Class<?> clazz = ClassUtils.forName(name, DispatcherServlet.class.getClassLoader());
/* 186 */         Object mapping = applicationContext.getAutowireCapableBeanFactory().createBean(clazz);
/* 187 */         result.add((HandlerMapping)mapping);
/*     */       }
/* 189 */       catch (ClassNotFoundException ex) {
/* 190 */         throw new IllegalStateException("Could not find default HandlerMapping [" + name + "]");
/*     */       } 
/*     */     } 
/* 193 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HandlerMapping> getHandlerMappings() {
/* 201 */     return (this.handlerMappings != null) ? this.handlerMappings : Collections.<HandlerMapping>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allHandlerMappingsUsePathPatternParser() {
/* 211 */     Assert.state((this.handlerMappings != null), "Not yet initialized via afterPropertiesSet.");
/* 212 */     return getHandlerMappings().stream().allMatch(HandlerMapping::usesPathPatterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlePreFlight(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 223 */     Assert.state((this.handlerMappings != null), "Not yet initialized via afterPropertiesSet.");
/* 224 */     Assert.state(CorsUtils.isPreFlightRequest(request), "Not a pre-flight request.");
/* 225 */     RequestPath previousPath = (RequestPath)request.getAttribute(ServletRequestPathUtils.PATH_ATTRIBUTE);
/*     */     try {
/* 227 */       ServletRequestPathUtils.parseAndCache(request);
/* 228 */       for (HandlerMapping mapping : this.handlerMappings) {
/* 229 */         HandlerExecutionChain chain = mapping.getHandler(request);
/* 230 */         if (chain != null) {
/* 231 */           Object handler = chain.getHandler();
/* 232 */           if (handler instanceof PreFlightRequestHandler) { PreFlightRequestHandler preFlightHandler = (PreFlightRequestHandler)handler;
/* 233 */             preFlightHandler.handlePreFlight(request, response);
/*     */             return; }
/*     */           
/* 236 */           throw new IllegalStateException("Expected PreFlightRequestHandler: " + String.valueOf(handler.getClass()));
/*     */         } 
/*     */       } 
/* 239 */       throw new NoHandlerFoundException(request
/* 240 */           .getMethod(), request.getRequestURI(), (new ServletServerHttpRequest(request)).getHeaders());
/*     */     } finally {
/*     */       
/* 243 */       ServletRequestPathUtils.setParsedRequestPath(previousPath, (ServletRequest)request);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Filter createCacheFilter() {
/* 264 */     return (request, response, chain) -> {
/*     */         CachedResult previous = setCache((HttpServletRequest)request);
/*     */         try {
/*     */           chain.doFilter(request, response);
/*     */         } finally {
/*     */           resetCache(request, previous);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CachedResult setCache(HttpServletRequest request) {
/* 286 */     CachedResult previous = (CachedResult)request.getAttribute(CACHED_RESULT_ATTRIBUTE);
/* 287 */     if (previous == null || !previous.matches(request)) {
/* 288 */       CachedResult result; AttributesPreservingRequest attributesPreservingRequest = new AttributesPreservingRequest(request);
/*     */ 
/*     */       
/*     */       try {
/* 292 */         result = doWithHandlerMapping((HttpServletRequest)attributesPreservingRequest, false, (mapping, executionChain) -> {
/*     */               MatchableHandlerMapping matchableMapping = createMatchableHandlerMapping(mapping, wrapped);
/*     */               
/*     */               CorsConfiguration corsConfig = getCorsConfiguration(executionChain, wrapped);
/*     */               return new CachedResult(request, matchableMapping, corsConfig, null, null);
/*     */             });
/* 298 */       } catch (Exception ex) {
/*     */         
/*     */         try {
/* 301 */           AttributesPreservingRequest requestToUse = new AttributesPreservingRequest(request);
/* 302 */           result = doWithHandlerMapping((HttpServletRequest)requestToUse, true, (mapping, executionChain) -> {
/*     */                 CorsConfiguration corsConfig = getCorsConfiguration(executionChain, wrapped);
/*     */                 
/*     */                 return new CachedResult(request, null, corsConfig, ex, null);
/*     */               });
/* 307 */         } catch (Exception ex2) {
/* 308 */           result = new CachedResult(request, null, null, ex, new IllegalStateException(ex2));
/*     */         } 
/*     */       } 
/* 311 */       if (result == null) {
/* 312 */         result = new CachedResult(request, null, null, null, null);
/*     */       }
/* 314 */       request.setAttribute(CACHED_RESULT_ATTRIBUTE, result);
/*     */     } 
/* 316 */     return previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetCache(ServletRequest request, @Nullable CachedResult cachedResult) {
/* 325 */     request.setAttribute(CACHED_RESULT_ATTRIBUTE, cachedResult);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MatchableHandlerMapping getMatchableHandlerMapping(HttpServletRequest request) throws Exception {
/* 339 */     CachedResult result = CachedResult.getResultFor(request);
/* 340 */     if (result != null) {
/* 341 */       return result.getHandlerMapping();
/*     */     }
/* 343 */     this.cacheLogHelper.logHandlerMappingCacheMiss(request);
/* 344 */     AttributesPreservingRequest attributesPreservingRequest = new AttributesPreservingRequest(request);
/* 345 */     return doWithHandlerMapping((HttpServletRequest)attributesPreservingRequest, false, (mapping, executionChain) -> createMatchableHandlerMapping(mapping, requestToUse));
/*     */   }
/*     */ 
/*     */   
/*     */   private MatchableHandlerMapping createMatchableHandlerMapping(HandlerMapping mapping, HttpServletRequest request) {
/* 350 */     if (mapping instanceof MatchableHandlerMapping) {
/* 351 */       PathPatternMatchableHandlerMapping pathPatternMapping = this.pathPatternMappings.get(mapping);
/* 352 */       if (pathPatternMapping != null) {
/* 353 */         RequestPath requestPath = ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request);
/* 354 */         return new LookupPathMatchableHandlerMapping(pathPatternMapping, requestPath);
/*     */       } 
/*     */       
/* 357 */       String lookupPath = (String)request.getAttribute(UrlPathHelper.PATH_ATTRIBUTE);
/* 358 */       return new LookupPathMatchableHandlerMapping((MatchableHandlerMapping)mapping, lookupPath);
/*     */     } 
/*     */     
/* 361 */     throw new IllegalStateException("HandlerMapping is not a MatchableHandlerMapping");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
/* 367 */     CachedResult result = CachedResult.getResultFor(request);
/* 368 */     if (result != null) {
/* 369 */       return result.getCorsConfig();
/*     */     }
/* 371 */     this.cacheLogHelper.logCorsConfigCacheMiss(request);
/*     */     try {
/* 373 */       boolean ignoreException = true;
/* 374 */       AttributesPreservingRequest requestToUse = new AttributesPreservingRequest(request);
/* 375 */       return doWithHandlerMapping((HttpServletRequest)requestToUse, ignoreException, (handlerMapping, executionChain) -> getCorsConfiguration(executionChain, (HttpServletRequest)requestToUse));
/*     */     
/*     */     }
/* 378 */     catch (Exception ex) {
/*     */       
/* 380 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static CorsConfiguration getCorsConfiguration(HandlerExecutionChain chain, HttpServletRequest request) {
/* 386 */     for (HandlerInterceptor interceptor : chain.getInterceptorList()) {
/* 387 */       if (interceptor instanceof CorsConfigurationSource) { CorsConfigurationSource source = (CorsConfigurationSource)interceptor;
/* 388 */         return source.getCorsConfiguration(request); }
/*     */     
/*     */     } 
/* 391 */     Object object = chain.getHandler(); if (object instanceof CorsConfigurationSource) { CorsConfigurationSource source = (CorsConfigurationSource)object;
/* 392 */       return source.getCorsConfiguration(request); }
/*     */     
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private <T> T doWithHandlerMapping(HttpServletRequest request, boolean ignoreException, BiFunction<HandlerMapping, HandlerExecutionChain, T> extractor) throws Exception {
/* 402 */     Assert.state((this.handlerMappings != null), "HandlerMapping's not initialized");
/*     */     
/* 404 */     boolean parsePath = !this.pathPatternMappings.isEmpty();
/* 405 */     RequestPath previousPath = null;
/* 406 */     if (parsePath) {
/* 407 */       previousPath = (RequestPath)request.getAttribute(ServletRequestPathUtils.PATH_ATTRIBUTE);
/* 408 */       ServletRequestPathUtils.parseAndCache(request);
/*     */     } 
/*     */     try {
/* 411 */       for (HandlerMapping handlerMapping : this.handlerMappings) {
/* 412 */         HandlerExecutionChain chain = null;
/*     */         try {
/* 414 */           chain = handlerMapping.getHandler(request);
/*     */         }
/* 416 */         catch (Exception ex) {
/* 417 */           if (!ignoreException) {
/* 418 */             throw ex;
/*     */           }
/*     */         } 
/* 421 */         if (chain == null) {
/*     */           continue;
/*     */         }
/* 424 */         return extractor.apply(handlerMapping, chain);
/*     */       } 
/*     */     } finally {
/*     */       
/* 428 */       if (parsePath) {
/* 429 */         ServletRequestPathUtils.setParsedRequestPath(previousPath, (ServletRequest)request);
/*     */       }
/*     */     } 
/* 432 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class CachedResult
/*     */   {
/*     */     private final DispatcherType dispatcherType;
/*     */ 
/*     */     
/*     */     private final String requestURI;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final MatchableHandlerMapping handlerMapping;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final CorsConfiguration corsConfig;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Exception failure;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final IllegalStateException corsConfigFailure;
/*     */ 
/*     */ 
/*     */     
/*     */     private CachedResult(HttpServletRequest request, @Nullable MatchableHandlerMapping mapping, @Nullable CorsConfiguration config, @Nullable Exception failure, @Nullable IllegalStateException corsConfigFailure) {
/* 464 */       this.dispatcherType = request.getDispatcherType();
/* 465 */       this.requestURI = request.getRequestURI();
/* 466 */       this.handlerMapping = mapping;
/* 467 */       this.corsConfig = config;
/* 468 */       this.failure = failure;
/* 469 */       this.corsConfigFailure = corsConfigFailure;
/*     */     }
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 473 */       return (this.dispatcherType.equals(request.getDispatcherType()) && this.requestURI
/* 474 */         .equals(request.getRequestURI()));
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public MatchableHandlerMapping getHandlerMapping() throws Exception {
/* 479 */       if (this.failure != null) {
/* 480 */         throw this.failure;
/*     */       }
/* 482 */       return this.handlerMapping;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public CorsConfiguration getCorsConfig() {
/* 487 */       if (this.corsConfigFailure != null) {
/* 488 */         throw this.corsConfigFailure;
/*     */       }
/* 490 */       return this.corsConfig;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 495 */       return "CachedResult for " + String.valueOf(this.dispatcherType) + " dispatch to '" + this.requestURI + "'";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public static CachedResult getResultFor(HttpServletRequest request) {
/* 504 */       CachedResult result = (CachedResult)request.getAttribute(HandlerMappingIntrospector.CACHED_RESULT_ATTRIBUTE);
/* 505 */       return (result != null && result.matches(request)) ? result : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CacheResultLogHelper
/*     */   {
/* 513 */     private final Map<String, AtomicInteger> counters = Map.of("MatchableHandlerMapping", new AtomicInteger(), "CorsConfiguration", new AtomicInteger());
/*     */     
/*     */     public void logHandlerMappingCacheMiss(HttpServletRequest request) {
/* 516 */       logCacheMiss("MatchableHandlerMapping", request);
/*     */     }
/*     */     
/*     */     public void logCorsConfigCacheMiss(HttpServletRequest request) {
/* 520 */       logCacheMiss("CorsConfiguration", request);
/*     */     }
/*     */     
/*     */     private void logCacheMiss(String label, HttpServletRequest request) {
/* 524 */       AtomicInteger counter = this.counters.get(label);
/* 525 */       Assert.notNull(counter, "Expected '" + label + "' counter.");
/*     */       
/* 527 */       String message = getLogMessage(label, request);
/*     */       
/* 529 */       if (HandlerMappingIntrospector.logger.isWarnEnabled() && counter.getAndIncrement() == 0) {
/* 530 */         HandlerMappingIntrospector.logger.warn(message + " This is logged once only at WARN level, and every time at TRACE.");
/*     */       }
/* 532 */       else if (HandlerMappingIntrospector.logger.isTraceEnabled()) {
/* 533 */         HandlerMappingIntrospector.logger.trace("No CachedResult, performing " + label + " lookup instead.");
/*     */       } 
/*     */     }
/*     */     
/*     */     private static String getLogMessage(String label, HttpServletRequest request) {
/* 538 */       return "Cache miss for " + String.valueOf(request.getDispatcherType()) + " dispatch to '" + request.getRequestURI() + "' (previous " + 
/* 539 */         String.valueOf(request.getAttribute(HandlerMappingIntrospector.CACHED_RESULT_ATTRIBUTE)) + "). Performing " + label + " lookup.";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AttributesPreservingRequest
/*     */     extends HttpServletRequestWrapper
/*     */   {
/*     */     private final Map<String, Object> attributes;
/*     */ 
/*     */ 
/*     */     
/*     */     AttributesPreservingRequest(HttpServletRequest request) {
/* 554 */       super(request);
/* 555 */       this.attributes = initAttributes(request);
/* 556 */       this.attributes.put(AbstractHandlerMapping.SUPPRESS_LOGGING_ATTRIBUTE, Boolean.TRUE);
/*     */     }
/*     */     
/*     */     private Map<String, Object> initAttributes(HttpServletRequest request) {
/* 560 */       Map<String, Object> map = new HashMap<>();
/* 561 */       Enumeration<String> names = request.getAttributeNames();
/* 562 */       while (names.hasMoreElements()) {
/* 563 */         String name = names.nextElement();
/* 564 */         map.put(name, request.getAttribute(name));
/*     */       } 
/* 566 */       return map;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setAttribute(String name, Object value) {
/* 571 */       this.attributes.put(name, value);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getAttribute(String name) {
/* 577 */       return this.attributes.get(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getAttributeNames() {
/* 582 */       return Collections.enumeration(this.attributes.keySet());
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeAttribute(String name) {
/* 587 */       this.attributes.remove(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LookupPathMatchableHandlerMapping
/*     */     implements MatchableHandlerMapping
/*     */   {
/*     */     private final MatchableHandlerMapping delegate;
/*     */     
/*     */     private final Object lookupPath;
/*     */     private final String pathAttributeName;
/*     */     
/*     */     LookupPathMatchableHandlerMapping(MatchableHandlerMapping delegate, Object lookupPath) {
/* 601 */       this.delegate = delegate;
/* 602 */       this.lookupPath = lookupPath;
/* 603 */       this
/* 604 */         .pathAttributeName = (lookupPath instanceof RequestPath) ? ServletRequestPathUtils.PATH_ATTRIBUTE : UrlPathHelper.PATH_ATTRIBUTE;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public PathPatternParser getPatternParser() {
/* 610 */       return this.delegate.getPatternParser();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public RequestMatchResult match(HttpServletRequest request, String pattern) {
/* 616 */       pattern = initFullPathPattern(pattern);
/* 617 */       Object previousPath = request.getAttribute(this.pathAttributeName);
/* 618 */       request.setAttribute(this.pathAttributeName, this.lookupPath);
/*     */       try {
/* 620 */         return this.delegate.match(request, pattern);
/*     */       } finally {
/*     */         
/* 623 */         request.setAttribute(this.pathAttributeName, previousPath);
/*     */       } 
/*     */     }
/*     */     
/*     */     private String initFullPathPattern(String pattern) {
/* 628 */       PathPatternParser parser = (getPatternParser() != null) ? getPatternParser() : PathPatternParser.defaultInstance;
/* 629 */       return parser.initFullPathPattern(pattern);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public HandlerExecutionChain getHandler(HttpServletRequest request) throws Exception {
/* 635 */       return this.delegate.getHandler(request);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\HandlerMappingIntrospector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */