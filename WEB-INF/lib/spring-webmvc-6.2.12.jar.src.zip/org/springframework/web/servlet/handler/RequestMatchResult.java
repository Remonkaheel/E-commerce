/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestMatchResult
/*     */ {
/*     */   @Nullable
/*     */   private final PathPattern pathPattern;
/*     */   @Nullable
/*     */   private final PathContainer lookupPathContainer;
/*     */   @Nullable
/*     */   private final String pattern;
/*     */   @Nullable
/*     */   private final String lookupPath;
/*     */   @Nullable
/*     */   private final PathMatcher pathMatcher;
/*     */   
/*     */   public RequestMatchResult(PathPattern pathPattern, PathContainer lookupPath) {
/*  61 */     Assert.notNull(pathPattern, "PathPattern is required");
/*  62 */     Assert.notNull(lookupPath, "PathContainer is required");
/*     */     
/*  64 */     this.pattern = null;
/*  65 */     this.lookupPath = null;
/*  66 */     this.pathMatcher = null;
/*     */     
/*  68 */     this.pathPattern = pathPattern;
/*  69 */     this.lookupPathContainer = lookupPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatchResult(String pattern, String lookupPath, PathMatcher pathMatcher) {
/*  80 */     Assert.hasText(pattern, "'matchingPattern' is required");
/*  81 */     Assert.hasText(lookupPath, "'lookupPath' is required");
/*  82 */     Assert.notNull(pathMatcher, "PathMatcher is required");
/*     */     
/*  84 */     this.pattern = pattern;
/*  85 */     this.lookupPath = lookupPath;
/*  86 */     this.pathMatcher = pathMatcher;
/*     */     
/*  88 */     this.pathPattern = null;
/*  89 */     this.lookupPathContainer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> extractUriTemplateVariables() {
/*  99 */     return (this.pathPattern != null) ? 
/* 100 */       this.pathPattern.matchAndExtract(this.lookupPathContainer).getUriVariables() : 
/* 101 */       this.pathMatcher.extractUriTemplateVariables(this.pattern, this.lookupPath);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\RequestMatchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */