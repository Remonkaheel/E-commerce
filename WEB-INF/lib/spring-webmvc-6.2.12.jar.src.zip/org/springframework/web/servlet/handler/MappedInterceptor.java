/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ import org.springframework.web.util.pattern.PatternParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MappedInterceptor
/*     */   implements HandlerInterceptor
/*     */ {
/*  63 */   private static final PathMatcher defaultPathMatcher = (PathMatcher)new AntPathMatcher();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final PatternAdapter[] includePatterns;
/*     */   
/*     */   @Nullable
/*     */   private final PatternAdapter[] excludePatterns;
/*     */   
/*  72 */   private PathMatcher pathMatcher = defaultPathMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HandlerInterceptor interceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedInterceptor(@Nullable String[] includePatterns, @Nullable String[] excludePatterns, HandlerInterceptor interceptor, @Nullable PathPatternParser parser) {
/*  91 */     this.includePatterns = PatternAdapter.initPatterns(includePatterns, parser);
/*  92 */     this.excludePatterns = PatternAdapter.initPatterns(excludePatterns, parser);
/*  93 */     this.interceptor = interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedInterceptor(@Nullable String[] includePatterns, HandlerInterceptor interceptor) {
/* 103 */     this(includePatterns, (String[])null, interceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedInterceptor(@Nullable String[] includePatterns, @Nullable String[] excludePatterns, HandlerInterceptor interceptor) {
/* 114 */     this(includePatterns, excludePatterns, interceptor, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedInterceptor(@Nullable String[] includePatterns, WebRequestInterceptor interceptor) {
/* 123 */     this(includePatterns, (String[])null, interceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappedInterceptor(@Nullable String[] includePatterns, @Nullable String[] excludePatterns, WebRequestInterceptor interceptor) {
/* 134 */     this(includePatterns, excludePatterns, (HandlerInterceptor)new WebRequestHandlerInterceptorAdapter(interceptor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public String[] getPathPatterns() {
/* 147 */     return getIncludePathPatterns();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getIncludePathPatterns() {
/* 157 */     return !ObjectUtils.isEmpty((Object[])this.includePatterns) ? 
/* 158 */       (String[])Arrays.<PatternAdapter>stream(this.includePatterns).map(PatternAdapter::getPatternString).toArray(x$0 -> new String[x$0]) : 
/* 159 */       null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getExcludePathPatterns() {
/* 169 */     return !ObjectUtils.isEmpty((Object[])this.excludePatterns) ? 
/* 170 */       (String[])Arrays.<PatternAdapter>stream(this.excludePatterns).map(PatternAdapter::getPatternString).toArray(x$0 -> new String[x$0]) : 
/* 171 */       null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandlerInterceptor getInterceptor() {
/* 178 */     return this.interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathMatcher(PathMatcher pathMatcher) {
/* 193 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathMatcher getPathMatcher() {
/* 200 */     return this.pathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(HttpServletRequest request) {
/* 212 */     Object path = ServletRequestPathUtils.getCachedPath((ServletRequest)request);
/* 213 */     if (this.pathMatcher != defaultPathMatcher) {
/* 214 */       path = path.toString();
/*     */     }
/* 216 */     boolean isPathContainer = path instanceof PathContainer;
/* 217 */     if (!ObjectUtils.isEmpty((Object[])this.excludePatterns)) {
/* 218 */       for (PatternAdapter adapter : this.excludePatterns) {
/* 219 */         if (adapter.match(path, isPathContainer, this.pathMatcher)) {
/* 220 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/* 224 */     if (ObjectUtils.isEmpty((Object[])this.includePatterns)) {
/* 225 */       return true;
/*     */     }
/* 227 */     for (PatternAdapter adapter : this.includePatterns) {
/* 228 */       if (adapter.match(path, isPathContainer, this.pathMatcher)) {
/* 229 */         return true;
/*     */       }
/*     */     } 
/* 232 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "5.3")
/*     */   public boolean matches(String lookupPath, PathMatcher pathMatcher) {
/* 244 */     pathMatcher = (this.pathMatcher != defaultPathMatcher) ? this.pathMatcher : pathMatcher;
/* 245 */     if (!ObjectUtils.isEmpty((Object[])this.excludePatterns)) {
/* 246 */       for (PatternAdapter adapter : this.excludePatterns) {
/* 247 */         if (pathMatcher.match(adapter.getPatternString(), lookupPath)) {
/* 248 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/* 252 */     if (ObjectUtils.isEmpty((Object[])this.includePatterns)) {
/* 253 */       return true;
/*     */     }
/* 255 */     for (PatternAdapter adapter : this.includePatterns) {
/* 256 */       if (pathMatcher.match(adapter.getPatternString(), lookupPath)) {
/* 257 */         return true;
/*     */       }
/*     */     } 
/* 260 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
/* 270 */     return this.interceptor.preHandle(request, response, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {
/* 277 */     this.interceptor.postHandle(request, response, handler, modelAndView);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {
/* 284 */     this.interceptor.afterCompletion(request, response, handler, ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PatternAdapter
/*     */   {
/*     */     private final String patternString;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final PathPattern pathPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PatternAdapter(String pattern, @Nullable PathPatternParser parser) {
/* 304 */       this.patternString = pattern;
/* 305 */       this.pathPattern = initPathPattern(pattern, parser);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private static PathPattern initPathPattern(String pattern, @Nullable PathPatternParser parser) {
/*     */       try {
/* 311 */         return ((parser != null) ? parser : PathPatternParser.defaultInstance).parse(pattern);
/*     */       }
/* 313 */       catch (PatternParseException ex) {
/* 314 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getPatternString() {
/* 319 */       return this.patternString;
/*     */     }
/*     */     
/*     */     public boolean match(Object path, boolean isPathContainer, PathMatcher pathMatcher) {
/* 323 */       if (isPathContainer) {
/* 324 */         PathContainer pathContainer = (PathContainer)path;
/* 325 */         if (this.pathPattern != null) {
/* 326 */           return this.pathPattern.matches(pathContainer);
/*     */         }
/* 328 */         String lookupPath = pathContainer.value();
/* 329 */         path = UrlPathHelper.defaultInstance.removeSemicolonContent(lookupPath);
/*     */       } 
/* 331 */       return pathMatcher.match(this.patternString, (String)path);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public static PatternAdapter[] initPatterns(@Nullable String[] patterns, @Nullable PathPatternParser parser) {
/* 338 */       if (ObjectUtils.isEmpty((Object[])patterns)) {
/* 339 */         return null;
/*     */       }
/* 341 */       return (PatternAdapter[])Arrays.<String>stream(patterns)
/* 342 */         .map(pattern -> new PatternAdapter(pattern, parser))
/* 343 */         .toArray(x$0 -> new PatternAdapter[x$0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\MappedInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */