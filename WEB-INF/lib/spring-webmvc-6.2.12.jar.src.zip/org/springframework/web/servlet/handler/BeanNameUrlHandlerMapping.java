/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanNameUrlHandlerMapping
/*    */   extends AbstractDetectingUrlHandlerMapping
/*    */ {
/*    */   protected String[] determineUrlsForHandler(String beanName) {
/* 55 */     List<String> urls = new ArrayList<>();
/* 56 */     if (beanName.startsWith("/")) {
/* 57 */       urls.add(beanName);
/*    */     }
/* 59 */     String[] aliases = obtainApplicationContext().getAliases(beanName);
/* 60 */     for (String alias : aliases) {
/* 61 */       if (alias.startsWith("/")) {
/* 62 */         urls.add(alias);
/*    */       }
/*    */     } 
/* 65 */     return StringUtils.toStringArray(urls);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\BeanNameUrlHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */