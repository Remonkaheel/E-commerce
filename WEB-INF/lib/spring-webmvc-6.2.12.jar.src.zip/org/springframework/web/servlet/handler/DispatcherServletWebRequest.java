/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.Locale;
/*    */ import org.springframework.web.context.request.ServletWebRequest;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DispatcherServletWebRequest
/*    */   extends ServletWebRequest
/*    */ {
/*    */   public DispatcherServletWebRequest(HttpServletRequest request) {
/* 45 */     super(request);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DispatcherServletWebRequest(HttpServletRequest request, HttpServletResponse response) {
/* 54 */     super(request, response);
/*    */   }
/*    */ 
/*    */   
/*    */   public Locale getLocale() {
/* 59 */     return RequestContextUtils.getLocale(getRequest());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\DispatcherServletWebRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */