/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.http.server.observation.ServerRequestObservationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.ServerHttpObservationFilter;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUrlHandlerMapping
/*     */   extends AbstractHandlerMapping
/*     */   implements MatchableHandlerMapping
/*     */ {
/*     */   @Nullable
/*     */   private Object rootHandler;
/*     */   private boolean useTrailingSlashMatch = false;
/*     */   private boolean lazyInitHandlers = false;
/*  73 */   private final Map<String, Object> handlerMap = new LinkedHashMap<>();
/*     */   
/*  75 */   private final Map<PathPattern, Object> pathPatternHandlerMap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternParser(@Nullable PathPatternParser patternParser) {
/*  80 */     Assert.state(this.handlerMap.isEmpty(), "PathPatternParser must be set before the initialization of the handler map via ApplicationContextAware#setApplicationContext.");
/*     */ 
/*     */     
/*  83 */     super.setPatternParser(patternParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRootHandler(@Nullable Object rootHandler) {
/*  92 */     this.rootHandler = rootHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getRootHandler() {
/* 101 */     return this.rootHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public void setUseTrailingSlashMatch(boolean useTrailingSlashMatch) {
/* 113 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/* 114 */     if (getPatternParser() != null) {
/* 115 */       getPatternParser().setMatchOptionalTrailingSeparator(useTrailingSlashMatch);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useTrailingSlashMatch() {
/* 123 */     return this.useTrailingSlashMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLazyInitHandlers(boolean lazyInitHandlers) {
/* 137 */     this.lazyInitHandlers = lazyInitHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerHandler(String[] urlPaths, String beanName) throws BeansException, IllegalStateException {
/* 149 */     Assert.notNull(urlPaths, "URL path array must not be null");
/* 150 */     for (String urlPath : urlPaths) {
/* 151 */       registerHandler(urlPath, beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerHandler(String urlPath, Object handler) throws BeansException, IllegalStateException {
/* 165 */     Assert.notNull(urlPath, "URL path must not be null");
/* 166 */     Assert.notNull(handler, "Handler object must not be null");
/* 167 */     Object resolvedHandler = handler;
/*     */ 
/*     */     
/* 170 */     if (!this.lazyInitHandlers && handler instanceof String) { String handlerName = (String)handler;
/* 171 */       ApplicationContext applicationContext = obtainApplicationContext();
/* 172 */       if (applicationContext.isSingleton(handlerName)) {
/* 173 */         resolvedHandler = applicationContext.getBean(handlerName);
/*     */       } }
/*     */ 
/*     */     
/* 177 */     Object mappedHandler = this.handlerMap.get(urlPath);
/* 178 */     if (mappedHandler != null) {
/* 179 */       if (mappedHandler != resolvedHandler) {
/* 180 */         throw new IllegalStateException("Cannot map " + 
/* 181 */             getHandlerDescription(handler) + " to URL path [" + urlPath + "]: There is already " + 
/* 182 */             getHandlerDescription(mappedHandler) + " mapped.");
/*     */       
/*     */       }
/*     */     }
/* 186 */     else if (urlPath.equals("/")) {
/* 187 */       if (this.logger.isTraceEnabled()) {
/* 188 */         this.logger.trace("Root mapping to " + getHandlerDescription(handler));
/*     */       }
/* 190 */       setRootHandler(resolvedHandler);
/*     */     }
/* 192 */     else if (urlPath.equals("/*")) {
/* 193 */       if (this.logger.isTraceEnabled()) {
/* 194 */         this.logger.trace("Default mapping to " + getHandlerDescription(handler));
/*     */       }
/* 196 */       setDefaultHandler(resolvedHandler);
/*     */     } else {
/*     */       
/* 199 */       this.handlerMap.put(urlPath, resolvedHandler);
/* 200 */       if (getPatternParser() != null) {
/* 201 */         this.pathPatternHandlerMap.put(getPatternParser().parse(urlPath), resolvedHandler);
/*     */       }
/* 203 */       if (this.logger.isTraceEnabled()) {
/* 204 */         this.logger.trace("Mapped [" + urlPath + "] onto " + getHandlerDescription(handler));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterHandler(String urlPath) {
/* 216 */     Assert.notNull(urlPath, "URL path must not be null");
/* 217 */     if (urlPath.equals("/")) {
/* 218 */       if (this.logger.isTraceEnabled()) {
/* 219 */         this.logger.trace("Removing root mapping: " + String.valueOf(getRootHandler()));
/*     */       }
/* 221 */       setRootHandler((Object)null);
/*     */     }
/* 223 */     else if (urlPath.equals("/*")) {
/* 224 */       if (this.logger.isTraceEnabled()) {
/* 225 */         this.logger.trace("Removing default mapping: " + String.valueOf(getDefaultHandler()));
/*     */       }
/* 227 */       setDefaultHandler((Object)null);
/*     */     } else {
/*     */       
/* 230 */       Object mappedHandler = this.handlerMap.get(urlPath);
/* 231 */       if (mappedHandler == null) {
/* 232 */         if (this.logger.isTraceEnabled()) {
/* 233 */           this.logger.trace("No mapping for [" + urlPath + "]");
/*     */         }
/*     */       } else {
/*     */         
/* 237 */         if (this.logger.isTraceEnabled()) {
/* 238 */           this.logger.trace("Removing mapping \"" + urlPath + "\": " + getHandlerDescription(mappedHandler));
/*     */         }
/* 240 */         this.handlerMap.remove(urlPath);
/* 241 */         if (getPatternParser() != null) {
/* 242 */           this.pathPatternHandlerMap.remove(getPatternParser().parse(urlPath));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getHandlerDescription(Object handler) {
/* 249 */     return (handler instanceof String) ? ("'" + String.valueOf(handler) + "'") : handler.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getHandlerInternal(HttpServletRequest request) throws Exception {
/*     */     Object handler;
/* 261 */     String lookupPath = initLookupPath(request);
/*     */     
/* 263 */     if (usesPathPatterns()) {
/* 264 */       RequestPath path = ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request);
/* 265 */       handler = lookupHandler(path, lookupPath, request);
/*     */     } else {
/*     */       
/* 268 */       handler = lookupHandler(lookupPath, request);
/*     */     } 
/* 270 */     if (handler == null) {
/*     */ 
/*     */       
/* 273 */       Object rawHandler = null;
/* 274 */       if (StringUtils.matchesCharacter(lookupPath, '/')) {
/* 275 */         rawHandler = getRootHandler();
/*     */       }
/* 277 */       if (rawHandler == null) {
/* 278 */         rawHandler = getDefaultHandler();
/*     */       }
/* 280 */       if (rawHandler != null) {
/*     */         
/* 282 */         if (rawHandler instanceof String) { String handlerName = (String)rawHandler;
/* 283 */           rawHandler = obtainApplicationContext().getBean(handlerName); }
/*     */         
/* 285 */         validateHandler(rawHandler, request);
/* 286 */         handler = buildPathExposingHandler(rawHandler, lookupPath, lookupPath, (Map<String, String>)null);
/*     */       } 
/*     */     } 
/* 289 */     return handler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object lookupHandler(RequestPath path, String lookupPath, HttpServletRequest request) throws Exception {
/* 306 */     Object handler = getDirectMatch(lookupPath, request);
/* 307 */     if (handler != null) {
/* 308 */       return handler;
/*     */     }
/*     */ 
/*     */     
/* 312 */     List<PathPattern> matches = null;
/* 313 */     for (PathPattern pathPattern : this.pathPatternHandlerMap.keySet()) {
/* 314 */       if (pathPattern.matches(path.pathWithinApplication())) {
/* 315 */         matches = (matches != null) ? matches : new ArrayList<>();
/* 316 */         matches.add(pathPattern);
/*     */       } 
/*     */     } 
/* 319 */     if (matches == null) {
/* 320 */       return null;
/*     */     }
/* 322 */     if (matches.size() > 1) {
/* 323 */       matches.sort(PathPattern.SPECIFICITY_COMPARATOR);
/* 324 */       if (this.logger.isTraceEnabled()) {
/* 325 */         this.logger.trace("Matching patterns " + String.valueOf(matches));
/*     */       }
/*     */     } 
/* 328 */     PathPattern pattern = matches.get(0);
/* 329 */     handler = this.pathPatternHandlerMap.get(pattern);
/* 330 */     if (handler instanceof String) { String handlerName = (String)handler;
/* 331 */       handler = obtainApplicationContext().getBean(handlerName); }
/*     */     
/* 333 */     validateHandler(handler, request);
/* 334 */     String pathWithinMapping = pattern.extractPathWithinPattern(path.pathWithinApplication()).value();
/* 335 */     pathWithinMapping = UrlPathHelper.defaultInstance.removeSemicolonContent(pathWithinMapping);
/* 336 */     PathPattern.PathMatchInfo pathMatchInfo = pattern.matchAndExtract((PathContainer)path);
/* 337 */     Map<String, String> uriVariables = (pathMatchInfo != null) ? pathMatchInfo.getUriVariables() : null;
/* 338 */     return buildPathExposingHandler(handler, pattern.getPatternString(), pathWithinMapping, uriVariables);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object lookupHandler(String lookupPath, HttpServletRequest request) throws Exception {
/* 352 */     Object handler = getDirectMatch(lookupPath, request);
/* 353 */     if (handler != null) {
/* 354 */       return handler;
/*     */     }
/*     */ 
/*     */     
/* 358 */     List<String> matchingPatterns = new ArrayList<>();
/* 359 */     for (String registeredPattern : this.handlerMap.keySet()) {
/* 360 */       if (getPathMatcher().match(registeredPattern, lookupPath)) {
/* 361 */         matchingPatterns.add(registeredPattern); continue;
/*     */       } 
/* 363 */       if (useTrailingSlashMatch() && 
/* 364 */         !registeredPattern.endsWith("/") && getPathMatcher().match(registeredPattern + "/", lookupPath)) {
/* 365 */         matchingPatterns.add(registeredPattern + "/");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 370 */     String bestMatch = null;
/* 371 */     Comparator<String> patternComparator = getPathMatcher().getPatternComparator(lookupPath);
/* 372 */     if (!matchingPatterns.isEmpty()) {
/* 373 */       matchingPatterns.sort(patternComparator);
/* 374 */       if (this.logger.isTraceEnabled() && matchingPatterns.size() > 1) {
/* 375 */         this.logger.trace("Matching patterns " + String.valueOf(matchingPatterns));
/*     */       }
/* 377 */       bestMatch = matchingPatterns.get(0);
/*     */     } 
/* 379 */     if (bestMatch != null) {
/* 380 */       handler = this.handlerMap.get(bestMatch);
/* 381 */       if (handler == null) {
/* 382 */         if (bestMatch.endsWith("/")) {
/* 383 */           handler = this.handlerMap.get(bestMatch.substring(0, bestMatch.length() - 1));
/*     */         }
/* 385 */         if (handler == null) {
/* 386 */           throw new IllegalStateException("Could not find handler for best pattern match [" + bestMatch + "]");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 391 */       if (handler instanceof String) { String handlerName = (String)handler;
/* 392 */         handler = obtainApplicationContext().getBean(handlerName); }
/*     */       
/* 394 */       validateHandler(handler, request);
/* 395 */       String pathWithinMapping = getPathMatcher().extractPathWithinPattern(bestMatch, lookupPath);
/*     */ 
/*     */ 
/*     */       
/* 399 */       Map<String, String> uriTemplateVariables = new LinkedHashMap<>();
/* 400 */       for (String matchingPattern : matchingPatterns) {
/* 401 */         if (patternComparator.compare(bestMatch, matchingPattern) == 0) {
/* 402 */           Map<String, String> vars = getPathMatcher().extractUriTemplateVariables(matchingPattern, lookupPath);
/* 403 */           Map<String, String> decodedVars = getUrlPathHelper().decodePathVariables(request, vars);
/* 404 */           uriTemplateVariables.putAll(decodedVars);
/*     */         } 
/*     */       } 
/* 407 */       if (this.logger.isTraceEnabled() && uriTemplateVariables.size() > 0) {
/* 408 */         this.logger.trace("URI variables " + String.valueOf(uriTemplateVariables));
/*     */       }
/* 410 */       return buildPathExposingHandler(handler, bestMatch, pathWithinMapping, uriTemplateVariables);
/*     */     } 
/*     */ 
/*     */     
/* 414 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getDirectMatch(String urlPath, HttpServletRequest request) throws Exception {
/* 419 */     Object handler = this.handlerMap.get(urlPath);
/* 420 */     if (handler != null) {
/*     */       
/* 422 */       if (handler instanceof String) { String handlerName = (String)handler;
/* 423 */         handler = obtainApplicationContext().getBean(handlerName); }
/*     */       
/* 425 */       validateHandler(handler, request);
/* 426 */       return buildPathExposingHandler(handler, urlPath, urlPath, (Map<String, String>)null);
/*     */     } 
/* 428 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateHandler(Object handler, HttpServletRequest request) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object buildPathExposingHandler(Object rawHandler, String bestMatchingPattern, String pathWithinMapping, @Nullable Map<String, String> uriTemplateVariables) {
/* 457 */     HandlerExecutionChain chain = new HandlerExecutionChain(rawHandler);
/* 458 */     chain.addInterceptor(new PathExposingHandlerInterceptor(bestMatchingPattern, pathWithinMapping));
/* 459 */     if (!CollectionUtils.isEmpty(uriTemplateVariables)) {
/* 460 */       chain.addInterceptor(new UriTemplateVariablesHandlerInterceptor(uriTemplateVariables));
/*     */     }
/* 462 */     return chain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void exposePathWithinMapping(String bestMatchingPattern, String pathWithinMapping, HttpServletRequest request) {
/* 474 */     request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, bestMatchingPattern);
/* 475 */     ServerHttpObservationFilter.findObservationContext(request)
/* 476 */       .ifPresent(context -> context.setPathPattern(bestMatchingPattern));
/* 477 */     request.setAttribute(PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, pathWithinMapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void exposeUriTemplateVariables(Map<String, String> uriTemplateVariables, HttpServletRequest request) {
/* 487 */     request.setAttribute(URI_TEMPLATE_VARIABLES_ATTRIBUTE, uriTemplateVariables);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RequestMatchResult match(HttpServletRequest request, String pattern) {
/* 493 */     Assert.state((getPatternParser() == null), "This HandlerMapping uses PathPatterns.");
/* 494 */     String lookupPath = UrlPathHelper.getResolvedLookupPath((ServletRequest)request);
/* 495 */     if (getPathMatcher().match(pattern, lookupPath)) {
/* 496 */       return new RequestMatchResult(pattern, lookupPath, getPathMatcher());
/*     */     }
/* 498 */     if (useTrailingSlashMatch() && 
/* 499 */       !pattern.endsWith("/") && getPathMatcher().match(pattern + "/", lookupPath)) {
/* 500 */       return new RequestMatchResult(pattern + "/", lookupPath, getPathMatcher());
/*     */     }
/*     */     
/* 503 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map<String, Object> getHandlerMap() {
/* 514 */     return Collections.unmodifiableMap(this.handlerMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map<PathPattern, Object> getPathPatternHandlerMap() {
/* 523 */     return this.pathPatternHandlerMap.isEmpty() ? 
/* 524 */       Collections.<PathPattern, Object>emptyMap() : Collections.<PathPattern, Object>unmodifiableMap(this.pathPatternHandlerMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsTypeLevelMappings() {
/* 531 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class PathExposingHandlerInterceptor
/*     */     implements HandlerInterceptor
/*     */   {
/*     */     private final String bestMatchingPattern;
/*     */ 
/*     */     
/*     */     private final String pathWithinMapping;
/*     */ 
/*     */ 
/*     */     
/*     */     public PathExposingHandlerInterceptor(String bestMatchingPattern, String pathWithinMapping) {
/* 547 */       this.bestMatchingPattern = bestMatchingPattern;
/* 548 */       this.pathWithinMapping = pathWithinMapping;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
/* 553 */       AbstractUrlHandlerMapping.this.exposePathWithinMapping(this.bestMatchingPattern, this.pathWithinMapping, request);
/* 554 */       request.setAttribute(HandlerMapping.BEST_MATCHING_HANDLER_ATTRIBUTE, handler);
/* 555 */       request.setAttribute(HandlerMapping.INTROSPECT_TYPE_LEVEL_MAPPING, Boolean.valueOf(AbstractUrlHandlerMapping.this.supportsTypeLevelMappings()));
/* 556 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class UriTemplateVariablesHandlerInterceptor
/*     */     implements HandlerInterceptor
/*     */   {
/*     */     private final Map<String, String> uriTemplateVariables;
/*     */ 
/*     */ 
/*     */     
/*     */     public UriTemplateVariablesHandlerInterceptor(Map<String, String> uriTemplateVariables) {
/* 571 */       this.uriTemplateVariables = uriTemplateVariables;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
/* 576 */       AbstractUrlHandlerMapping.this.exposeUriTemplateVariables(this.uriTemplateVariables, request);
/* 577 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\AbstractUrlHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */