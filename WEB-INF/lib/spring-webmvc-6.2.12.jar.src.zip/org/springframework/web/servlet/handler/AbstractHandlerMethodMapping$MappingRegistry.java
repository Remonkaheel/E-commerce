/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MappingRegistry
/*     */ {
/* 575 */   private final Map<T, AbstractHandlerMethodMapping.MappingRegistration<T>> registry = new HashMap<>();
/*     */   
/* 577 */   private final MultiValueMap<String, T> pathLookup = (MultiValueMap<String, T>)new LinkedMultiValueMap();
/*     */   
/* 579 */   private final Map<String, List<HandlerMethod>> nameLookup = new ConcurrentHashMap<>();
/*     */   
/* 581 */   private final Map<HandlerMethod, CorsConfiguration> corsLookup = new ConcurrentHashMap<>();
/*     */   
/* 583 */   private final ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<T, AbstractHandlerMethodMapping.MappingRegistration<T>> getRegistrations() {
/* 590 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<T> getMappingsByDirectPath(String urlPath) {
/* 599 */     return (List<T>)this.pathLookup.get(urlPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<HandlerMethod> getHandlerMethodsByMappingName(String mappingName) {
/* 607 */     return this.nameLookup.get(mappingName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CorsConfiguration getCorsConfiguration(HandlerMethod handlerMethod) {
/* 615 */     HandlerMethod original = handlerMethod.getResolvedFromHandlerMethod();
/* 616 */     return this.corsLookup.get((original != null) ? original : handlerMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acquireReadLock() {
/* 623 */     this.readWriteLock.readLock().lock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseReadLock() {
/* 630 */     this.readWriteLock.readLock().unlock();
/*     */   }
/*     */   
/*     */   public void register(T mapping, Object handler, Method method) {
/* 634 */     this.readWriteLock.writeLock().lock();
/*     */     try {
/* 636 */       HandlerMethod handlerMethod = AbstractHandlerMethodMapping.this.createHandlerMethod(handler, method);
/* 637 */       validateMethodMapping(handlerMethod, mapping);
/*     */       
/* 639 */       Set<String> directPaths = AbstractHandlerMethodMapping.this.getDirectPaths(mapping);
/* 640 */       for (String path : directPaths) {
/* 641 */         this.pathLookup.add(path, mapping);
/*     */       }
/*     */       
/* 644 */       String name = null;
/* 645 */       if (AbstractHandlerMethodMapping.this.getNamingStrategy() != null) {
/* 646 */         name = AbstractHandlerMethodMapping.this.getNamingStrategy().getName(handlerMethod, mapping);
/* 647 */         addMappingName(name, handlerMethod);
/*     */       } 
/*     */       
/* 650 */       CorsConfiguration corsConfig = AbstractHandlerMethodMapping.this.initCorsConfiguration(handler, method, mapping);
/* 651 */       if (corsConfig != null) {
/* 652 */         corsConfig.validateAllowCredentials();
/* 653 */         corsConfig.validateAllowPrivateNetwork();
/* 654 */         this.corsLookup.put(handlerMethod, corsConfig);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 659 */       handlerMethod = handlerMethod.createWithValidateFlags();
/*     */       
/* 661 */       this.registry.put(mapping, new AbstractHandlerMethodMapping.MappingRegistration<>(mapping, handlerMethod, directPaths, name, (corsConfig != null)));
/*     */     }
/*     */     finally {
/*     */       
/* 665 */       this.readWriteLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateMethodMapping(HandlerMethod handlerMethod, T mapping) {
/* 670 */     AbstractHandlerMethodMapping.MappingRegistration<T> registration = this.registry.get(mapping);
/* 671 */     HandlerMethod existingHandlerMethod = (registration != null) ? registration.getHandlerMethod() : null;
/* 672 */     if (existingHandlerMethod != null && !existingHandlerMethod.equals(handlerMethod)) {
/* 673 */       throw new IllegalStateException("Ambiguous mapping. Cannot map '" + 
/* 674 */           String.valueOf(handlerMethod.getBean()) + "' method \n" + String.valueOf(handlerMethod) + "\nto " + String.valueOf(mapping) + ": There is already '" + 
/*     */           
/* 676 */           String.valueOf(existingHandlerMethod.getBean()) + "' bean method\n" + String.valueOf(existingHandlerMethod) + " mapped.");
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMappingName(String name, HandlerMethod handlerMethod) {
/* 681 */     List<HandlerMethod> oldList = this.nameLookup.get(name);
/* 682 */     if (oldList == null) {
/* 683 */       oldList = Collections.emptyList();
/*     */     }
/*     */     
/* 686 */     for (HandlerMethod current : oldList) {
/* 687 */       if (handlerMethod.equals(current)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 692 */     List<HandlerMethod> newList = new ArrayList<>(oldList.size() + 1);
/* 693 */     newList.addAll(oldList);
/* 694 */     newList.add(handlerMethod);
/* 695 */     this.nameLookup.put(name, newList);
/*     */   }
/*     */   
/*     */   public void unregister(T mapping) {
/* 699 */     this.readWriteLock.writeLock().lock();
/*     */     try {
/* 701 */       AbstractHandlerMethodMapping.MappingRegistration<T> registration = this.registry.remove(mapping);
/* 702 */       if (registration == null) {
/*     */         return;
/*     */       }
/*     */       
/* 706 */       for (String path : registration.getDirectPaths()) {
/* 707 */         List<T> mappings = (List<T>)this.pathLookup.get(path);
/* 708 */         if (mappings != null) {
/* 709 */           mappings.remove(registration.getMapping());
/* 710 */           if (mappings.isEmpty()) {
/* 711 */             this.pathLookup.remove(path);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 716 */       removeMappingName(registration);
/*     */       
/* 718 */       this.corsLookup.remove(registration.getHandlerMethod());
/*     */     } finally {
/*     */       
/* 721 */       this.readWriteLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeMappingName(AbstractHandlerMethodMapping.MappingRegistration<T> definition) {
/* 726 */     String name = definition.getMappingName();
/* 727 */     if (name == null) {
/*     */       return;
/*     */     }
/* 730 */     HandlerMethod handlerMethod = definition.getHandlerMethod();
/* 731 */     List<HandlerMethod> oldList = this.nameLookup.get(name);
/* 732 */     if (oldList == null) {
/*     */       return;
/*     */     }
/* 735 */     if (oldList.size() <= 1) {
/* 736 */       this.nameLookup.remove(name);
/*     */       return;
/*     */     } 
/* 739 */     List<HandlerMethod> newList = new ArrayList<>(oldList.size() - 1);
/* 740 */     for (HandlerMethod current : oldList) {
/* 741 */       if (!current.equals(handlerMethod)) {
/* 742 */         newList.add(current);
/*     */       }
/*     */     } 
/* 745 */     this.nameLookup.put(name, newList);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\AbstractHandlerMethodMapping$MappingRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */