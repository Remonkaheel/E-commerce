/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.util.DisconnectedClientHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandlerExceptionResolver
/*     */   implements HandlerExceptionResolver, Ordered
/*     */ {
/*     */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*     */   private static final String DISCONNECTED_CLIENT_LOG_CATEGORY = "org.springframework.web.servlet.handler.DisconnectedClient";
/*  55 */   private static final DisconnectedClientHelper disconnectedClientHelper = new DisconnectedClientHelper("org.springframework.web.servlet.handler.DisconnectedClient");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  62 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */   @Nullable
/*     */   private Predicate<Object> mappedHandlerPredicate;
/*     */   
/*     */   @Nullable
/*     */   private Set<?> mappedHandlers;
/*     */   
/*     */   @Nullable
/*     */   private Class<?>[] mappedHandlerClasses;
/*     */   
/*     */   @Nullable
/*     */   private Log warnLogger;
/*     */   
/*     */   private boolean preventResponseCaching = false;
/*     */ 
/*     */   
/*     */   public void setOrder(int order) {
/*  80 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  85 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappedHandlerPredicate(Predicate<Object> predicate) {
/*  97 */     this
/*  98 */       .mappedHandlerPredicate = (this.mappedHandlerPredicate != null) ? this.mappedHandlerPredicate.and(predicate) : predicate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappedHandlers(Set<?> mappedHandlers) {
/* 108 */     this.mappedHandlers = mappedHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappedHandlerClasses(Class<?>... mappedHandlerClasses) {
/* 120 */     this.mappedHandlerClasses = mappedHandlerClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMappedHandlerClass(Class<?> mappedHandlerClass) {
/* 130 */     (new Class[1])[0] = mappedHandlerClass; this.mappedHandlerClasses = (this.mappedHandlerClasses != null) ? (Class[])ObjectUtils.addObjectToArray((Object[])this.mappedHandlerClasses, mappedHandlerClass) : new Class[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?>[] getMappedHandlerClasses() {
/* 139 */     return this.mappedHandlerClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWarnLogCategory(String loggerName) {
/* 155 */     this.warnLogger = StringUtils.hasLength(loggerName) ? LogFactory.getLog(loggerName) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreventResponseCaching(boolean preventResponseCaching) {
/* 165 */     this.preventResponseCaching = preventResponseCaching;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
/* 180 */     if (shouldApplyTo(request, handler)) {
/* 181 */       prepareResponse(ex, response);
/* 182 */       ModelAndView result = doResolveException(request, response, handler, ex);
/* 183 */       if (result != null && !disconnectedClientHelper.checkAndLogClientDisconnectedException(ex)) {
/*     */         
/* 185 */         if (this.logger.isDebugEnabled() && (this.warnLogger == null || !this.warnLogger.isWarnEnabled())) {
/* 186 */           this.logger.debug(buildLogMessage(ex, request) + buildLogMessage(ex, request));
/*     */         }
/*     */         
/* 189 */         logException(ex, request);
/*     */       } 
/* 191 */       return result;
/*     */     } 
/*     */     
/* 194 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldApplyTo(HttpServletRequest request, @Nullable Object handler) {
/* 213 */     if (this.mappedHandlerPredicate != null) {
/* 214 */       return this.mappedHandlerPredicate.test(handler);
/*     */     }
/* 216 */     if (handler != null) {
/* 217 */       if (this.mappedHandlers != null && this.mappedHandlers.contains(handler)) {
/* 218 */         return true;
/*     */       }
/* 220 */       if (this.mappedHandlerClasses != null) {
/* 221 */         for (Class<?> handlerClass : this.mappedHandlerClasses) {
/* 222 */           if (handlerClass.isInstance(handler)) {
/* 223 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 228 */     return !hasHandlerMappings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasHandlerMappings() {
/* 238 */     return (this.mappedHandlers != null || this.mappedHandlerClasses != null || this.mappedHandlerPredicate != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logException(Exception ex, HttpServletRequest request) {
/* 253 */     if (this.warnLogger != null && this.warnLogger.isWarnEnabled()) {
/* 254 */       this.warnLogger.warn(buildLogMessage(ex, request));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildLogMessage(Exception ex, HttpServletRequest request) {
/* 265 */     return "Resolved [" + LogFormatUtils.formatValue(ex, -1, true) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareResponse(Exception ex, HttpServletResponse response) {
/* 278 */     if (this.preventResponseCaching) {
/* 279 */       preventCaching(response);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void preventCaching(HttpServletResponse response) {
/* 289 */     response.addHeader("Cache-Control", "no-store");
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract ModelAndView doResolveException(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, @Nullable Object paramObject, Exception paramException);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\AbstractHandlerExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */