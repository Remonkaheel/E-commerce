/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.method.HandlerMethod;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractHandlerMethodExceptionResolver
/*    */   extends AbstractHandlerExceptionResolver
/*    */ {
/*    */   protected boolean shouldApplyTo(HttpServletRequest request, @Nullable Object handler) {
/* 46 */     if (handler instanceof HandlerMethod) { HandlerMethod handlerMethod = (HandlerMethod)handler;
/* 47 */       return super.shouldApplyTo(request, handlerMethod.getBean()); }
/*    */     
/* 49 */     if (handler == null || (hasGlobalExceptionHandlers() && hasHandlerMappings())) {
/* 50 */       return super.shouldApplyTo(request, handler);
/*    */     }
/*    */     
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean hasGlobalExceptionHandlers() {
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected final ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
/* 72 */     HandlerMethod hm = (HandlerMethod)handler, handlerMethod = (handler instanceof HandlerMethod) ? hm : null;
/* 73 */     return doResolveHandlerMethodException(request, response, handlerMethod, ex);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   protected abstract ModelAndView doResolveHandlerMethodException(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, @Nullable HandlerMethod paramHandlerMethod, Exception paramException);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\AbstractHandlerMethodExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */