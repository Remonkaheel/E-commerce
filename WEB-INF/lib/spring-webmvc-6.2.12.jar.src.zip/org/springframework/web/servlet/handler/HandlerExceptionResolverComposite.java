/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandlerExceptionResolverComposite
/*    */   implements HandlerExceptionResolver, Ordered
/*    */ {
/*    */   @Nullable
/*    */   private List<HandlerExceptionResolver> resolvers;
/* 42 */   private int order = Integer.MAX_VALUE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
/* 49 */     this.resolvers = exceptionResolvers;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<HandlerExceptionResolver> getExceptionResolvers() {
/* 56 */     return (this.resolvers != null) ? Collections.<HandlerExceptionResolver>unmodifiableList(this.resolvers) : Collections.<HandlerExceptionResolver>emptyList();
/*    */   }
/*    */   
/*    */   public void setOrder(int order) {
/* 60 */     this.order = order;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 65 */     return this.order;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
/* 78 */     if (this.resolvers != null) {
/* 79 */       for (HandlerExceptionResolver handlerExceptionResolver : this.resolvers) {
/* 80 */         ModelAndView mav = handlerExceptionResolver.resolveException(request, response, handler, ex);
/* 81 */         if (mav != null) {
/* 82 */           return mav;
/*    */         }
/*    */       } 
/*    */     }
/* 86 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\HandlerExceptionResolverComposite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */