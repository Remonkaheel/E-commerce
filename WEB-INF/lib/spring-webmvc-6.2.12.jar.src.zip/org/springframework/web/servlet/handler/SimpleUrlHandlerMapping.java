/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleUrlHandlerMapping
/*     */   extends AbstractUrlHandlerMapping
/*     */ {
/*  60 */   private final Map<String, Object> urlMap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleUrlHandlerMapping(Map<String, ?> urlMap) {
/*  77 */     setUrlMap(urlMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleUrlHandlerMapping(Map<String, ?> urlMap, int order) {
/*  90 */     setUrlMap(urlMap);
/*  91 */     setOrder(order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappings(Properties mappings) {
/* 104 */     CollectionUtils.mergePropertiesIntoMap(mappings, this.urlMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlMap(Map<String, ?> urlMap) {
/* 116 */     this.urlMap.putAll(urlMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ?> getUrlMap() {
/* 127 */     return this.urlMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initApplicationContext() throws BeansException {
/* 137 */     super.initApplicationContext();
/* 138 */     registerHandlers(this.urlMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerHandlers(Map<String, Object> urlMap) throws BeansException {
/* 148 */     if (urlMap.isEmpty()) {
/* 149 */       this.logger.trace("No patterns in " + formatMappingName());
/*     */     } else {
/*     */       
/* 152 */       urlMap.forEach((url, handler) -> {
/*     */             if (!url.startsWith("/")) {
/*     */               url = "/" + url;
/*     */             }
/*     */             
/*     */             if (handler instanceof String) {
/*     */               String handlerName = (String)handler;
/*     */               handler = handlerName.trim();
/*     */             } 
/*     */             registerHandler(url, handler);
/*     */           });
/* 163 */       logMappings();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logMappings() {
/* 168 */     if (this.mappingsLogger.isDebugEnabled()) {
/* 169 */       Map<String, Object> map = new LinkedHashMap<>(getHandlerMap());
/* 170 */       if (getRootHandler() != null) {
/* 171 */         map.put("/", getRootHandler());
/*     */       }
/* 173 */       if (getDefaultHandler() != null) {
/* 174 */         map.put("/**", getDefaultHandler());
/*     */       }
/* 176 */       this.mappingsLogger.debug(formatMappingName() + " " + formatMappingName());
/*     */     }
/* 178 */     else if (this.logger.isDebugEnabled()) {
/* 179 */       List<String> patterns = new ArrayList<>();
/* 180 */       if (getRootHandler() != null) {
/* 181 */         patterns.add("/");
/*     */       }
/* 183 */       if (getDefaultHandler() != null) {
/* 184 */         patterns.add("/**");
/*     */       }
/* 186 */       patterns.addAll(getHandlerMap().keySet());
/* 187 */       this.logger.debug("Patterns " + String.valueOf(patterns) + " in " + formatMappingName());
/*     */     } 
/*     */   }
/*     */   
/*     */   public SimpleUrlHandlerMapping() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\SimpleUrlHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */