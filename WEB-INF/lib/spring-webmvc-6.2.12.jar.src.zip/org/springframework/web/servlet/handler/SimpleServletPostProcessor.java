/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletConfig;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.context.ServletConfigAware;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleServletPostProcessor
/*     */   implements DestructionAwareBeanPostProcessor, ServletContextAware, ServletConfigAware
/*     */ {
/*     */   private boolean useSharedServletConfig = true;
/*     */   @Nullable
/*     */   private ServletContext servletContext;
/*     */   @Nullable
/*     */   private ServletConfig servletConfig;
/*     */   
/*     */   public void setUseSharedServletConfig(boolean useSharedServletConfig) {
/*  89 */     this.useSharedServletConfig = useSharedServletConfig;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/*  94 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletConfig(ServletConfig servletConfig) {
/*  99 */     this.servletConfig = servletConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/* 105 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
/* 110 */     if (bean instanceof Servlet) { Servlet servlet = (Servlet)bean;
/* 111 */       ServletConfig config = this.servletConfig;
/* 112 */       if (config == null || !this.useSharedServletConfig) {
/* 113 */         config = new DelegatingServletConfig(beanName, this.servletContext);
/*     */       }
/*     */       try {
/* 116 */         servlet.init(config);
/*     */       }
/* 118 */       catch (ServletException ex) {
/* 119 */         throw new BeanInitializationException("Servlet.init threw exception", ex);
/*     */       }  }
/*     */     
/* 122 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName) throws BeansException {
/* 127 */     if (bean instanceof Servlet) { Servlet servlet = (Servlet)bean;
/* 128 */       servlet.destroy(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresDestruction(Object bean) {
/* 134 */     return bean instanceof Servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DelegatingServletConfig
/*     */     implements ServletConfig
/*     */   {
/*     */     private final String servletName;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ServletContext servletContext;
/*     */ 
/*     */     
/*     */     public DelegatingServletConfig(String servletName, @Nullable ServletContext servletContext) {
/* 150 */       this.servletName = servletName;
/* 151 */       this.servletContext = servletContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getServletName() {
/* 156 */       return this.servletName;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ServletContext getServletContext() {
/* 162 */       return this.servletContext;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getInitParameter(String paramName) {
/* 168 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getInitParameterNames() {
/* 173 */       return Collections.emptyEnumeration();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\SimpleServletPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */