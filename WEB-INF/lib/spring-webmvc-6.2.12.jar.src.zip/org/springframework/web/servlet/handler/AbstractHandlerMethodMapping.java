/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandlerMethodMapping<T>
/*     */   extends AbstractHandlerMapping
/*     */   implements InitializingBean
/*     */ {
/*     */   private static final String SCOPED_TARGET_NAME_PREFIX = "scopedTarget.";
/*  83 */   private static final HandlerMethod PREFLIGHT_AMBIGUOUS_MATCH = new HandlerMethod(new EmptyHandler(), 
/*  84 */       ClassUtils.getMethod(EmptyHandler.class, "handle", new Class[0]));
/*     */   
/*  86 */   private static final CorsConfiguration ALLOW_CORS_CONFIG = new CorsConfiguration();
/*     */   
/*     */   static {
/*  89 */     ALLOW_CORS_CONFIG.addAllowedOriginPattern("*");
/*  90 */     ALLOW_CORS_CONFIG.addAllowedMethod("*");
/*  91 */     ALLOW_CORS_CONFIG.addAllowedHeader("*");
/*  92 */     ALLOW_CORS_CONFIG.setAllowCredentials(Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean detectHandlerMethodsInAncestorContexts = false;
/*     */   
/*     */   @Nullable
/*     */   private HandlerMethodMappingNamingStrategy<T> namingStrategy;
/*     */   
/* 101 */   private final MappingRegistry mappingRegistry = new MappingRegistry();
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternParser(@Nullable PathPatternParser patternParser) {
/* 106 */     Assert.state(this.mappingRegistry.getRegistrations().isEmpty(), "PathPatternParser must be set before the initialization of request mappings through InitializingBean#afterPropertiesSet.");
/*     */ 
/*     */     
/* 109 */     super.setPatternParser(patternParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDetectHandlerMethodsInAncestorContexts(boolean detectHandlerMethodsInAncestorContexts) {
/* 122 */     this.detectHandlerMethodsInAncestorContexts = detectHandlerMethodsInAncestorContexts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerMethodMappingNamingStrategy(HandlerMethodMappingNamingStrategy<T> namingStrategy) {
/* 133 */     this.namingStrategy = namingStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HandlerMethodMappingNamingStrategy<T> getNamingStrategy() {
/* 141 */     return this.namingStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<T, HandlerMethod> getHandlerMethods() {
/* 148 */     this.mappingRegistry.acquireReadLock();
/*     */     try {
/* 150 */       return (Map)this.mappingRegistry.getRegistrations().entrySet().stream()
/* 151 */         .collect(Collectors.toUnmodifiableMap(Map.Entry::getKey, entry -> ((MappingRegistration)entry.getValue()).handlerMethod));
/*     */     } finally {
/*     */       
/* 154 */       this.mappingRegistry.releaseReadLock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<HandlerMethod> getHandlerMethodsForMappingName(String mappingName) {
/* 167 */     return this.mappingRegistry.getHandlerMethodsByMappingName(mappingName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MappingRegistry getMappingRegistry() {
/* 174 */     return this.mappingRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerMapping(T mapping, Object handler, Method method) {
/* 185 */     if (this.logger.isTraceEnabled()) {
/* 186 */       this.logger.trace("Register \"" + String.valueOf(mapping) + "\" to " + method.toGenericString());
/*     */     }
/* 188 */     this.mappingRegistry.register(mapping, handler, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterMapping(T mapping) {
/* 197 */     if (this.logger.isTraceEnabled()) {
/* 198 */       this.logger.trace("Unregister mapping \"" + String.valueOf(mapping) + "\"");
/*     */     }
/* 200 */     this.mappingRegistry.unregister(mapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 212 */     initHandlerMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initHandlerMethods() {
/* 222 */     for (String beanName : getCandidateBeanNames()) {
/* 223 */       if (!beanName.startsWith("scopedTarget.")) {
/* 224 */         processCandidateBean(beanName);
/*     */       }
/*     */     } 
/* 227 */     handlerMethodsInitialized(getHandlerMethods());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getCandidateBeanNames() {
/* 237 */     return this.detectHandlerMethodsInAncestorContexts ? 
/* 238 */       BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)obtainApplicationContext(), Object.class) : 
/* 239 */       obtainApplicationContext().getBeanNamesForType(Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processCandidateBean(String beanName) {
/* 254 */     Class<?> beanType = null;
/*     */     try {
/* 256 */       beanType = obtainApplicationContext().getType(beanName);
/*     */     }
/* 258 */     catch (Throwable ex) {
/*     */       
/* 260 */       if (this.logger.isTraceEnabled()) {
/* 261 */         this.logger.trace("Could not resolve type for bean '" + beanName + "'", ex);
/*     */       }
/*     */     } 
/* 264 */     if (beanType != null && isHandler(beanType)) {
/* 265 */       detectHandlerMethods(beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void detectHandlerMethods(Object handler) {
/* 275 */     String beanName = (String)handler;
/* 276 */     Class<?> handlerType = (handler instanceof String) ? obtainApplicationContext().getType(beanName) : handler.getClass();
/*     */     
/* 278 */     if (handlerType != null) {
/* 279 */       Class<?> userType = ClassUtils.getUserClass(handlerType);
/* 280 */       Map<Method, T> methods = MethodIntrospector.selectMethods(userType, method -> {
/*     */ 
/*     */             
/*     */             try {
/*     */               return (MethodIntrospector.MetadataLookup)getMappingForMethod(method, userType);
/* 285 */             } catch (Throwable ex) {
/*     */               throw new IllegalStateException("Invalid mapping on handler class [" + userType.getName() + "]: " + String.valueOf(method), ex);
/*     */             } 
/*     */           });
/*     */       
/* 290 */       if (this.logger.isTraceEnabled()) {
/* 291 */         this.logger.trace(formatMappings(userType, methods));
/*     */       }
/* 293 */       else if (this.mappingsLogger.isDebugEnabled()) {
/* 294 */         this.mappingsLogger.debug(formatMappings(userType, methods));
/*     */       } 
/* 296 */       methods.forEach((method, mapping) -> {
/*     */             Method invocableMethod = AopUtils.selectInvocableMethod(method, userType);
/*     */             registerHandlerMethod(handler, invocableMethod, (T)mapping);
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   private String formatMappings(Class<?> userType, Map<Method, T> methods) {
/* 304 */     String packageName = ClassUtils.getPackageName(userType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     String formattedType = StringUtils.hasText(packageName) ? Arrays.<String>stream(packageName.split("\\.")).map(packageSegment -> packageSegment.substring(0, 1)).collect(Collectors.joining(".", "", "." + userType.getSimpleName())) : userType.getSimpleName();
/* 310 */     Function<Method, String> methodFormatter = method -> (String)Arrays.<Class<?>>stream(method.getParameterTypes()).map(Class::getSimpleName).collect(Collectors.joining(",", "(", ")"));
/*     */ 
/*     */     
/* 313 */     return methods.entrySet().stream()
/* 314 */       .map(e -> {
/*     */           Method method = (Method)e.getKey();
/*     */           
/*     */           return String.valueOf(e.getValue()) + ": " + String.valueOf(e.getValue()) + method.getName();
/* 318 */         }).collect(Collectors.joining("\n\t", "\n\t" + formattedType + ":\n\t", ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerHandlerMethod(Object handler, Method method, T mapping) {
/* 331 */     this.mappingRegistry.register(mapping, handler, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HandlerMethod createHandlerMethod(Object handler, Method method) {
/* 341 */     if (handler instanceof String) { String beanName = (String)handler;
/* 342 */       return new HandlerMethod(beanName, (BeanFactory)
/* 343 */           obtainApplicationContext().getAutowireCapableBeanFactory(), (MessageSource)
/* 344 */           obtainApplicationContext(), method); }
/*     */ 
/*     */     
/* 347 */     return new HandlerMethod(handler, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CorsConfiguration initCorsConfiguration(Object handler, Method method, T mapping) {
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handlerMethodsInitialized(Map<T, HandlerMethod> handlerMethods) {
/* 364 */     int total = handlerMethods.size();
/* 365 */     if ((this.logger.isTraceEnabled() && total == 0) || (this.logger.isDebugEnabled() && total > 0)) {
/* 366 */       this.logger.debug("" + total + " mappings in " + total);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected HandlerMethod getHandlerInternal(HttpServletRequest request) throws Exception {
/* 379 */     String lookupPath = initLookupPath(request);
/* 380 */     this.mappingRegistry.acquireReadLock();
/*     */     try {
/* 382 */       HandlerMethod handlerMethod = lookupHandlerMethod(lookupPath, request);
/* 383 */       return (handlerMethod != null) ? handlerMethod.createWithResolvedBean() : null;
/*     */     } finally {
/*     */       
/* 386 */       this.mappingRegistry.releaseReadLock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected HandlerMethod lookupHandlerMethod(String lookupPath, HttpServletRequest request) throws Exception {
/* 401 */     List<Match> matches = new ArrayList<>();
/* 402 */     List<T> directPathMatches = this.mappingRegistry.getMappingsByDirectPath(lookupPath);
/* 403 */     if (directPathMatches != null) {
/* 404 */       addMatchingMappings(directPathMatches, matches, request);
/*     */     }
/* 406 */     if (matches.isEmpty()) {
/* 407 */       addMatchingMappings(this.mappingRegistry.getRegistrations().keySet(), matches, request);
/*     */     }
/* 409 */     if (!matches.isEmpty()) {
/* 410 */       Match bestMatch = matches.get(0);
/* 411 */       if (matches.size() > 1) {
/* 412 */         Comparator<Match> comparator = new MatchComparator(getMappingComparator(request));
/* 413 */         matches.sort(comparator);
/* 414 */         bestMatch = matches.get(0);
/* 415 */         if (this.logger.isTraceEnabled()) {
/* 416 */           this.logger.trace("" + matches.size() + " matching mappings: " + matches.size());
/*     */         }
/* 418 */         if (CorsUtils.isPreFlightRequest(request)) {
/* 419 */           for (Match match : matches) {
/* 420 */             if (match.hasCorsConfig()) {
/* 421 */               return PREFLIGHT_AMBIGUOUS_MATCH;
/*     */             }
/*     */           } 
/*     */         } else {
/*     */           
/* 426 */           Match secondBestMatch = matches.get(1);
/* 427 */           if (comparator.compare(bestMatch, secondBestMatch) == 0) {
/* 428 */             Method m1 = bestMatch.getHandlerMethod().getMethod();
/* 429 */             Method m2 = secondBestMatch.getHandlerMethod().getMethod();
/* 430 */             String uri = request.getRequestURI();
/* 431 */             throw new IllegalStateException("Ambiguous handler methods mapped for '" + uri + "': {" + String.valueOf(m1) + ", " + String.valueOf(m2) + "}");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 436 */       request.setAttribute(BEST_MATCHING_HANDLER_ATTRIBUTE, bestMatch.getHandlerMethod());
/* 437 */       handleMatch(bestMatch.mapping, lookupPath, request);
/* 438 */       return bestMatch.getHandlerMethod();
/*     */     } 
/*     */     
/* 441 */     return handleNoMatch(this.mappingRegistry.getRegistrations().keySet(), lookupPath, request);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addMatchingMappings(Collection<T> mappings, List<Match> matches, HttpServletRequest request) {
/* 447 */     for (T mapping : mappings) {
/* 448 */       T match = getMatchingMapping(mapping, request);
/* 449 */       if (match != null) {
/* 450 */         matches.add(new Match(match, this.mappingRegistry.getRegistrations().get(mapping)));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleMatch(T mapping, String lookupPath, HttpServletRequest request) {
/* 462 */     request.setAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, lookupPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected HandlerMethod handleNoMatch(Set<T> mappings, String lookupPath, HttpServletRequest request) throws Exception {
/* 476 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasCorsConfigurationSource(Object handler) {
/* 481 */     if (!super.hasCorsConfigurationSource(handler)) { if (handler instanceof HandlerMethod) {
/* 482 */         HandlerMethod handlerMethod = (HandlerMethod)handler; if (this.mappingRegistry
/* 483 */           .getCorsConfiguration(handlerMethod) != null);
/*     */       } 
/*     */       return false; }
/*     */   
/*     */   } @Nullable
/*     */   protected CorsConfiguration getCorsConfiguration(Object handler, HttpServletRequest request) {
/* 489 */     CorsConfiguration corsConfig = super.getCorsConfiguration(handler, request);
/* 490 */     if (handler instanceof HandlerMethod) { HandlerMethod handlerMethod = (HandlerMethod)handler;
/* 491 */       if (handlerMethod.equals(PREFLIGHT_AMBIGUOUS_MATCH)) {
/* 492 */         return ALLOW_CORS_CONFIG;
/*     */       }
/*     */       
/* 495 */       CorsConfiguration corsConfigFromMethod = this.mappingRegistry.getCorsConfiguration(handlerMethod);
/* 496 */       corsConfig = (corsConfig != null) ? corsConfig.combine(corsConfigFromMethod) : corsConfigFromMethod; }
/*     */ 
/*     */     
/* 499 */     return corsConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Set<String> getMappingPathPatterns(T mapping) {
/* 530 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<String> getDirectPaths(T mapping) {
/* 538 */     Set<String> urls = Collections.emptySet();
/* 539 */     for (String path : getMappingPathPatterns(mapping)) {
/* 540 */       if (!getPathMatcher().isPattern(path)) {
/* 541 */         urls = urls.isEmpty() ? new HashSet<>(1) : urls;
/* 542 */         urls.add(path);
/*     */       } 
/*     */     } 
/* 545 */     return urls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isHandler(Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract T getMappingForMethod(Method paramMethod, Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract T getMatchingMapping(T paramT, HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Comparator<T> getMappingComparator(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class MappingRegistry
/*     */   {
/* 575 */     private final Map<T, AbstractHandlerMethodMapping.MappingRegistration<T>> registry = new HashMap<>();
/*     */     
/* 577 */     private final MultiValueMap<String, T> pathLookup = (MultiValueMap<String, T>)new LinkedMultiValueMap();
/*     */     
/* 579 */     private final Map<String, List<HandlerMethod>> nameLookup = new ConcurrentHashMap<>();
/*     */     
/* 581 */     private final Map<HandlerMethod, CorsConfiguration> corsLookup = new ConcurrentHashMap<>();
/*     */     
/* 583 */     private final ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<T, AbstractHandlerMethodMapping.MappingRegistration<T>> getRegistrations() {
/* 590 */       return this.registry;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public List<T> getMappingsByDirectPath(String urlPath) {
/* 599 */       return (List<T>)this.pathLookup.get(urlPath);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public List<HandlerMethod> getHandlerMethodsByMappingName(String mappingName) {
/* 607 */       return this.nameLookup.get(mappingName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CorsConfiguration getCorsConfiguration(HandlerMethod handlerMethod) {
/* 615 */       HandlerMethod original = handlerMethod.getResolvedFromHandlerMethod();
/* 616 */       return this.corsLookup.get((original != null) ? original : handlerMethod);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acquireReadLock() {
/* 623 */       this.readWriteLock.readLock().lock();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void releaseReadLock() {
/* 630 */       this.readWriteLock.readLock().unlock();
/*     */     }
/*     */     
/*     */     public void register(T mapping, Object handler, Method method) {
/* 634 */       this.readWriteLock.writeLock().lock();
/*     */       try {
/* 636 */         HandlerMethod handlerMethod = AbstractHandlerMethodMapping.this.createHandlerMethod(handler, method);
/* 637 */         validateMethodMapping(handlerMethod, mapping);
/*     */         
/* 639 */         Set<String> directPaths = AbstractHandlerMethodMapping.this.getDirectPaths(mapping);
/* 640 */         for (String path : directPaths) {
/* 641 */           this.pathLookup.add(path, mapping);
/*     */         }
/*     */         
/* 644 */         String name = null;
/* 645 */         if (AbstractHandlerMethodMapping.this.getNamingStrategy() != null) {
/* 646 */           name = AbstractHandlerMethodMapping.this.getNamingStrategy().getName(handlerMethod, mapping);
/* 647 */           addMappingName(name, handlerMethod);
/*     */         } 
/*     */         
/* 650 */         CorsConfiguration corsConfig = AbstractHandlerMethodMapping.this.initCorsConfiguration(handler, method, mapping);
/* 651 */         if (corsConfig != null) {
/* 652 */           corsConfig.validateAllowCredentials();
/* 653 */           corsConfig.validateAllowPrivateNetwork();
/* 654 */           this.corsLookup.put(handlerMethod, corsConfig);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 659 */         handlerMethod = handlerMethod.createWithValidateFlags();
/*     */         
/* 661 */         this.registry.put(mapping, new AbstractHandlerMethodMapping.MappingRegistration<>(mapping, handlerMethod, directPaths, name, (corsConfig != null)));
/*     */       }
/*     */       finally {
/*     */         
/* 665 */         this.readWriteLock.writeLock().unlock();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void validateMethodMapping(HandlerMethod handlerMethod, T mapping) {
/* 670 */       AbstractHandlerMethodMapping.MappingRegistration<T> registration = this.registry.get(mapping);
/* 671 */       HandlerMethod existingHandlerMethod = (registration != null) ? registration.getHandlerMethod() : null;
/* 672 */       if (existingHandlerMethod != null && !existingHandlerMethod.equals(handlerMethod)) {
/* 673 */         throw new IllegalStateException("Ambiguous mapping. Cannot map '" + 
/* 674 */             String.valueOf(handlerMethod.getBean()) + "' method \n" + String.valueOf(handlerMethod) + "\nto " + String.valueOf(mapping) + ": There is already '" + 
/*     */             
/* 676 */             String.valueOf(existingHandlerMethod.getBean()) + "' bean method\n" + String.valueOf(existingHandlerMethod) + " mapped.");
/*     */       }
/*     */     }
/*     */     
/*     */     private void addMappingName(String name, HandlerMethod handlerMethod) {
/* 681 */       List<HandlerMethod> oldList = this.nameLookup.get(name);
/* 682 */       if (oldList == null) {
/* 683 */         oldList = Collections.emptyList();
/*     */       }
/*     */       
/* 686 */       for (HandlerMethod current : oldList) {
/* 687 */         if (handlerMethod.equals(current)) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */       
/* 692 */       List<HandlerMethod> newList = new ArrayList<>(oldList.size() + 1);
/* 693 */       newList.addAll(oldList);
/* 694 */       newList.add(handlerMethod);
/* 695 */       this.nameLookup.put(name, newList);
/*     */     }
/*     */     
/*     */     public void unregister(T mapping) {
/* 699 */       this.readWriteLock.writeLock().lock();
/*     */       try {
/* 701 */         AbstractHandlerMethodMapping.MappingRegistration<T> registration = this.registry.remove(mapping);
/* 702 */         if (registration == null) {
/*     */           return;
/*     */         }
/*     */         
/* 706 */         for (String path : registration.getDirectPaths()) {
/* 707 */           List<T> mappings = (List<T>)this.pathLookup.get(path);
/* 708 */           if (mappings != null) {
/* 709 */             mappings.remove(registration.getMapping());
/* 710 */             if (mappings.isEmpty()) {
/* 711 */               this.pathLookup.remove(path);
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 716 */         removeMappingName(registration);
/*     */         
/* 718 */         this.corsLookup.remove(registration.getHandlerMethod());
/*     */       } finally {
/*     */         
/* 721 */         this.readWriteLock.writeLock().unlock();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void removeMappingName(AbstractHandlerMethodMapping.MappingRegistration<T> definition) {
/* 726 */       String name = definition.getMappingName();
/* 727 */       if (name == null) {
/*     */         return;
/*     */       }
/* 730 */       HandlerMethod handlerMethod = definition.getHandlerMethod();
/* 731 */       List<HandlerMethod> oldList = this.nameLookup.get(name);
/* 732 */       if (oldList == null) {
/*     */         return;
/*     */       }
/* 735 */       if (oldList.size() <= 1) {
/* 736 */         this.nameLookup.remove(name);
/*     */         return;
/*     */       } 
/* 739 */       List<HandlerMethod> newList = new ArrayList<>(oldList.size() - 1);
/* 740 */       for (HandlerMethod current : oldList) {
/* 741 */         if (!current.equals(handlerMethod)) {
/* 742 */           newList.add(current);
/*     */         }
/*     */       } 
/* 745 */       this.nameLookup.put(name, newList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class MappingRegistration<T>
/*     */   {
/*     */     private final T mapping;
/*     */     
/*     */     private final HandlerMethod handlerMethod;
/*     */     
/*     */     private final Set<String> directPaths;
/*     */     
/*     */     @Nullable
/*     */     private final String mappingName;
/*     */     
/*     */     private final boolean corsConfig;
/*     */ 
/*     */     
/*     */     public MappingRegistration(T mapping, HandlerMethod handlerMethod, @Nullable Set<String> directPaths, @Nullable String mappingName, boolean corsConfig) {
/* 766 */       Assert.notNull(mapping, "Mapping must not be null");
/* 767 */       Assert.notNull(handlerMethod, "HandlerMethod must not be null");
/* 768 */       this.mapping = mapping;
/* 769 */       this.handlerMethod = handlerMethod;
/* 770 */       this.directPaths = (directPaths != null) ? directPaths : Collections.<String>emptySet();
/* 771 */       this.mappingName = mappingName;
/* 772 */       this.corsConfig = corsConfig;
/*     */     }
/*     */     
/*     */     public T getMapping() {
/* 776 */       return this.mapping;
/*     */     }
/*     */     
/*     */     public HandlerMethod getHandlerMethod() {
/* 780 */       return this.handlerMethod;
/*     */     }
/*     */     
/*     */     public Set<String> getDirectPaths() {
/* 784 */       return this.directPaths;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getMappingName() {
/* 789 */       return this.mappingName;
/*     */     }
/*     */     
/*     */     public boolean hasCorsConfig() {
/* 793 */       return this.corsConfig;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Match
/*     */   {
/*     */     private final T mapping;
/*     */ 
/*     */     
/*     */     private final AbstractHandlerMethodMapping.MappingRegistration<T> registration;
/*     */ 
/*     */ 
/*     */     
/*     */     public Match(T mapping, AbstractHandlerMethodMapping.MappingRegistration<T> registration) {
/* 809 */       this.mapping = mapping;
/* 810 */       this.registration = registration;
/*     */     }
/*     */     
/*     */     public HandlerMethod getHandlerMethod() {
/* 814 */       return this.registration.getHandlerMethod();
/*     */     }
/*     */     
/*     */     public boolean hasCorsConfig() {
/* 818 */       return this.registration.hasCorsConfig();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 823 */       return this.mapping.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private class MatchComparator
/*     */     implements Comparator<Match>
/*     */   {
/*     */     private final Comparator<T> comparator;
/*     */     
/*     */     public MatchComparator(Comparator<T> comparator) {
/* 833 */       this.comparator = comparator;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compare(AbstractHandlerMethodMapping<T>.Match match1, AbstractHandlerMethodMapping<T>.Match match2) {
/* 838 */       return this.comparator.compare(match1.mapping, match2.mapping);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EmptyHandler
/*     */   {
/*     */     public void handle() {
/* 847 */       throw new UnsupportedOperationException("Not implemented");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\AbstractHandlerMethodMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */