/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.http.server.PathContainer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.HandlerExecutionChain;
/*    */ import org.springframework.web.util.ServletRequestPathUtils;
/*    */ import org.springframework.web.util.pattern.PathPattern;
/*    */ import org.springframework.web.util.pattern.PathPatternParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PathPatternMatchableHandlerMapping
/*    */   implements MatchableHandlerMapping
/*    */ {
/*    */   private final MatchableHandlerMapping delegate;
/*    */   private final PathPatternParser parser;
/* 46 */   private final Map<String, PathPattern> pathPatternCache = new ConcurrentHashMap<>();
/*    */   
/*    */   private final int cacheLimit;
/*    */ 
/*    */   
/*    */   public PathPatternMatchableHandlerMapping(MatchableHandlerMapping delegate, int cacheLimit) {
/* 52 */     Assert.notNull(delegate, "HandlerMapping to delegate to is required.");
/* 53 */     Assert.notNull(delegate.getPatternParser(), "Expected HandlerMapping configured to use PatternParser.");
/* 54 */     this.delegate = delegate;
/* 55 */     this.parser = delegate.getPatternParser();
/* 56 */     this.cacheLimit = cacheLimit;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public RequestMatchResult match(HttpServletRequest request, String pattern) {
/* 63 */     PathPattern pathPattern = this.pathPatternCache.computeIfAbsent(pattern, value -> {
/*    */           Assert.state((this.pathPatternCache.size() < this.cacheLimit), "Max size for pattern cache exceeded.");
/*    */           return this.parser.parse(pattern);
/*    */         });
/* 67 */     PathContainer path = ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request).pathWithinApplication();
/* 68 */     return pathPattern.matches(path) ? new RequestMatchResult(pathPattern, path) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public HandlerExecutionChain getHandler(HttpServletRequest request) throws Exception {
/* 74 */     return this.delegate.getHandler(request);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\handler\PathPatternMatchableHandlerMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */