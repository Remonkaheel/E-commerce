/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.context.ContextLoader;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ThemeResolver;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestContextUtils
/*     */ {
/*     */   public static final String REQUEST_DATA_VALUE_PROCESSOR_BEAN_NAME = "requestDataValueProcessor";
/*     */   
/*     */   @Nullable
/*     */   public static WebApplicationContext findWebApplicationContext(HttpServletRequest request, @Nullable ServletContext servletContext) {
/*  87 */     WebApplicationContext webApplicationContext = (WebApplicationContext)request.getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */     
/*  89 */     if (webApplicationContext == null) {
/*  90 */       if (servletContext != null) {
/*  91 */         webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
/*     */       }
/*  93 */       if (webApplicationContext == null) {
/*  94 */         webApplicationContext = ContextLoader.getCurrentWebApplicationContext();
/*     */       }
/*     */     } 
/*  97 */     return webApplicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static WebApplicationContext findWebApplicationContext(HttpServletRequest request) {
/* 115 */     return findWebApplicationContext(request, request.getServletContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static LocaleResolver getLocaleResolver(HttpServletRequest request) {
/* 126 */     return (LocaleResolver)request.getAttribute(DispatcherServlet.LOCALE_RESOLVER_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale getLocale(HttpServletRequest request) {
/* 146 */     LocaleResolver localeResolver = getLocaleResolver(request);
/* 147 */     return (localeResolver != null) ? localeResolver.resolveLocale(request) : request.getLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static TimeZone getTimeZone(HttpServletRequest request) {
/* 170 */     LocaleResolver localeResolver = getLocaleResolver(request);
/* 171 */     if (localeResolver instanceof LocaleContextResolver) { LocaleContextResolver localeContextResolver = (LocaleContextResolver)localeResolver;
/* 172 */       LocaleContext localeContext = localeContextResolver.resolveLocaleContext(request);
/* 173 */       if (localeContext instanceof TimeZoneAwareLocaleContext) { TimeZoneAwareLocaleContext timeZoneAwareLocaleContext = (TimeZoneAwareLocaleContext)localeContext;
/* 174 */         return timeZoneAwareLocaleContext.getTimeZone(); }
/*     */        }
/*     */     
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated(since = "6.0")
/*     */   public static ThemeResolver getThemeResolver(HttpServletRequest request) {
/* 190 */     return (ThemeResolver)request.getAttribute(DispatcherServlet.THEME_RESOLVER_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated(since = "6.0")
/*     */   public static ThemeSource getThemeSource(HttpServletRequest request) {
/* 203 */     return (ThemeSource)request.getAttribute(DispatcherServlet.THEME_SOURCE_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated(since = "6.0")
/*     */   public static Theme getTheme(HttpServletRequest request) {
/* 217 */     ThemeResolver themeResolver = getThemeResolver(request);
/* 218 */     ThemeSource themeSource = getThemeSource(request);
/* 219 */     if (themeResolver != null && themeSource != null) {
/* 220 */       String themeName = themeResolver.resolveThemeName(request);
/* 221 */       return themeSource.getTheme(themeName);
/*     */     } 
/*     */     
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Map<String, ?> getInputFlashMap(HttpServletRequest request) {
/* 237 */     return (Map<String, ?>)request.getAttribute(DispatcherServlet.INPUT_FLASH_MAP_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FlashMap getOutputFlashMap(HttpServletRequest request) {
/* 247 */     return (FlashMap)request.getAttribute(DispatcherServlet.OUTPUT_FLASH_MAP_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static FlashMapManager getFlashMapManager(HttpServletRequest request) {
/* 260 */     return (FlashMapManager)request.getAttribute(DispatcherServlet.FLASH_MAP_MANAGER_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveOutputFlashMap(String location, HttpServletRequest request, HttpServletResponse response) {
/* 273 */     FlashMap flashMap = getOutputFlashMap(request);
/* 274 */     if (CollectionUtils.isEmpty((Map)flashMap)) {
/*     */       return;
/*     */     }
/*     */     
/* 278 */     UriComponents uriComponents = UriComponentsBuilder.fromUriString(location).build();
/* 279 */     flashMap.setTargetRequestPath(uriComponents.getPath());
/* 280 */     flashMap.addTargetRequestParams(uriComponents.getQueryParams());
/*     */     
/* 282 */     FlashMapManager manager = getFlashMapManager(request);
/* 283 */     Assert.state((manager != null), "No FlashMapManager. Is this a DispatcherServlet handled request?");
/* 284 */     manager.saveOutputFlashMap(flashMap, request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\RequestContextUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */