package org.springframework.web.servlet.support;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.lang.Nullable;

public interface RequestDataValueProcessor {
  String processAction(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2);
  
  String processFormFieldValue(HttpServletRequest paramHttpServletRequest, @Nullable String paramString1, String paramString2, String paramString3);
  
  @Nullable
  Map<String, String> getExtraHiddenFields(HttpServletRequest paramHttpServletRequest);
  
  String processUrl(HttpServletRequest paramHttpServletRequest, String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\RequestDataValueProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */