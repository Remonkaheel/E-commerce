/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterRegistration;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRegistration;
/*     */ import java.util.EnumSet;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.AbstractContextLoaderInitializer;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.FrameworkServlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDispatcherServletInitializer
/*     */   extends AbstractContextLoaderInitializer
/*     */ {
/*     */   public static final String DEFAULT_SERVLET_NAME = "dispatcher";
/*     */   
/*     */   public void onStartup(ServletContext servletContext) throws ServletException {
/*  64 */     super.onStartup(servletContext);
/*  65 */     registerDispatcherServlet(servletContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerDispatcherServlet(ServletContext servletContext) {
/*  80 */     String servletName = getServletName();
/*  81 */     Assert.state(StringUtils.hasLength(servletName), "getServletName() must not return null or empty");
/*     */     
/*  83 */     WebApplicationContext servletAppContext = createServletApplicationContext();
/*  84 */     Assert.state((servletAppContext != null), "createServletApplicationContext() must not return null");
/*     */     
/*  86 */     FrameworkServlet dispatcherServlet = createDispatcherServlet(servletAppContext);
/*  87 */     Assert.state((dispatcherServlet != null), "createDispatcherServlet(WebApplicationContext) must not return null");
/*  88 */     dispatcherServlet.setContextInitializers((ApplicationContextInitializer[])getServletApplicationContextInitializers());
/*     */     
/*  90 */     ServletRegistration.Dynamic registration = servletContext.addServlet(servletName, (Servlet)dispatcherServlet);
/*  91 */     if (registration == null) {
/*  92 */       throw new IllegalStateException("Failed to register servlet with name '" + servletName + "'. Check if there is another servlet registered under the same name.");
/*     */     }
/*     */ 
/*     */     
/*  96 */     registration.setLoadOnStartup(1);
/*  97 */     registration.addMapping(getServletMappings());
/*  98 */     registration.setAsyncSupported(isAsyncSupported());
/*     */     
/* 100 */     Filter[] filters = getServletFilters();
/* 101 */     if (!ObjectUtils.isEmpty((Object[])filters)) {
/* 102 */       for (Filter filter : filters) {
/* 103 */         registerServletFilter(servletContext, filter);
/*     */       }
/*     */     }
/*     */     
/* 107 */     customizeRegistration(registration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getServletName() {
/* 116 */     return "dispatcher";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract WebApplicationContext createServletApplicationContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FrameworkServlet createDispatcherServlet(WebApplicationContext servletAppContext) {
/* 136 */     return (FrameworkServlet)new DispatcherServlet(servletAppContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ApplicationContextInitializer<?>[] getServletApplicationContextInitializers() {
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String[] getServletMappings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Filter[] getServletFilters() {
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FilterRegistration.Dynamic registerServletFilter(ServletContext servletContext, Filter filter) {
/* 187 */     String filterName = Conventions.getVariableName(filter);
/* 188 */     FilterRegistration.Dynamic registration = servletContext.addFilter(filterName, filter);
/*     */     
/* 190 */     if (registration == null) {
/* 191 */       int counter = 0;
/* 192 */       while (registration == null) {
/* 193 */         if (counter == 100) {
/* 194 */           throw new IllegalStateException("Failed to register filter with name '" + filterName + "'. Check if there is another filter registered under the same name.");
/*     */         }
/*     */         
/* 197 */         registration = servletContext.addFilter(filterName + "#" + filterName, filter);
/* 198 */         counter++;
/*     */       } 
/*     */     } 
/*     */     
/* 202 */     registration.setAsyncSupported(isAsyncSupported());
/* 203 */     registration.addMappingForServletNames(getDispatcherTypes(), false, new String[] { getServletName() });
/* 204 */     return registration;
/*     */   }
/*     */   
/*     */   private EnumSet<DispatcherType> getDispatcherTypes() {
/* 208 */     return isAsyncSupported() ? 
/* 209 */       EnumSet.<DispatcherType>of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE, DispatcherType.ASYNC) : 
/* 210 */       EnumSet.<DispatcherType>of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAsyncSupported() {
/* 219 */     return true;
/*     */   }
/*     */   
/*     */   protected void customizeRegistration(ServletRegistration.Dynamic registration) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\AbstractDispatcherServletInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */