/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.jsp.jstl.core.Config;
/*     */ import jakarta.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.support.MessageSourceResourceBundle;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JstlUtils
/*     */ {
/*     */   public static MessageSource getJstlAwareMessageSource(@Nullable ServletContext servletContext, MessageSource messageSource) {
/*  58 */     if (servletContext != null) {
/*  59 */       String jstlInitParam = servletContext.getInitParameter("jakarta.servlet.jsp.jstl.fmt.localizationContext");
/*  60 */       if (jstlInitParam != null) {
/*     */ 
/*     */ 
/*     */         
/*  64 */         ResourceBundleMessageSource jstlBundleWrapper = new ResourceBundleMessageSource();
/*  65 */         jstlBundleWrapper.setBasename(jstlInitParam);
/*  66 */         jstlBundleWrapper.setParentMessageSource(messageSource);
/*  67 */         return (MessageSource)jstlBundleWrapper;
/*     */       } 
/*     */     } 
/*  70 */     return messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void exposeLocalizationContext(HttpServletRequest request, @Nullable MessageSource messageSource) {
/*  83 */     Locale jstlLocale = RequestContextUtils.getLocale(request);
/*  84 */     Config.set((ServletRequest)request, "jakarta.servlet.jsp.jstl.fmt.locale", jstlLocale);
/*  85 */     TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/*  86 */     if (timeZone != null) {
/*  87 */       Config.set((ServletRequest)request, "jakarta.servlet.jsp.jstl.fmt.timeZone", timeZone);
/*     */     }
/*  89 */     if (messageSource != null) {
/*  90 */       LocalizationContext jstlContext = new SpringLocalizationContext(messageSource, request);
/*  91 */       Config.set((ServletRequest)request, "jakarta.servlet.jsp.jstl.fmt.localizationContext", jstlContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void exposeLocalizationContext(RequestContext requestContext) {
/* 103 */     Config.set((ServletRequest)requestContext.getRequest(), "jakarta.servlet.jsp.jstl.fmt.locale", requestContext.getLocale());
/* 104 */     TimeZone timeZone = requestContext.getTimeZone();
/* 105 */     if (timeZone != null) {
/* 106 */       Config.set((ServletRequest)requestContext.getRequest(), "jakarta.servlet.jsp.jstl.fmt.timeZone", timeZone);
/*     */     }
/* 108 */     MessageSource messageSource = getJstlAwareMessageSource(requestContext
/* 109 */         .getServletContext(), requestContext.getMessageSource());
/* 110 */     LocalizationContext jstlContext = new SpringLocalizationContext(messageSource, requestContext.getRequest());
/* 111 */     Config.set((ServletRequest)requestContext.getRequest(), "jakarta.servlet.jsp.jstl.fmt.localizationContext", jstlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SpringLocalizationContext
/*     */     extends LocalizationContext
/*     */   {
/*     */     private final MessageSource messageSource;
/*     */ 
/*     */     
/*     */     private final HttpServletRequest request;
/*     */ 
/*     */     
/*     */     public SpringLocalizationContext(MessageSource messageSource, HttpServletRequest request) {
/* 126 */       this.messageSource = messageSource;
/* 127 */       this.request = request;
/*     */     }
/*     */ 
/*     */     
/*     */     public ResourceBundle getResourceBundle() {
/* 132 */       HttpSession session = this.request.getSession(false);
/* 133 */       if (session != null) {
/* 134 */         Object lcObject = Config.get(session, "jakarta.servlet.jsp.jstl.fmt.localizationContext");
/* 135 */         if (lcObject instanceof LocalizationContext) { LocalizationContext localizationContext = (LocalizationContext)lcObject;
/* 136 */           ResourceBundle lcBundle = localizationContext.getResourceBundle();
/* 137 */           return (ResourceBundle)new MessageSourceResourceBundle(this.messageSource, getLocale(), lcBundle); }
/*     */       
/*     */       } 
/* 140 */       return (ResourceBundle)new MessageSourceResourceBundle(this.messageSource, getLocale());
/*     */     }
/*     */ 
/*     */     
/*     */     public Locale getLocale() {
/* 145 */       HttpSession session = this.request.getSession(false);
/* 146 */       if (session != null) {
/* 147 */         Object localeObject = Config.get(session, "jakarta.servlet.jsp.jstl.fmt.locale");
/* 148 */         if (localeObject instanceof Locale) { Locale locale = (Locale)localeObject;
/* 149 */           return locale; }
/*     */       
/*     */       } 
/* 152 */       return RequestContextUtils.getLocale(this.request);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\JstlUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */