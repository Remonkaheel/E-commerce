/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.jsp.jstl.core.Config;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.SimpleTimeZoneAwareLocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.ResourceBundleThemeSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.bind.EscapedErrors;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ThemeResolver;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestContext
/*     */ {
/*     */   @Deprecated(since = "6.0")
/*     */   public static final String DEFAULT_THEME_NAME = "theme";
/*  90 */   public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE = RequestContext.class.getName() + ".CONTEXT";
/*     */ 
/*     */   
/*  93 */   protected static final boolean jstlPresent = ClassUtils.isPresent("jakarta.servlet.jsp.jstl.core.Config", RequestContext.class
/*  94 */       .getClassLoader());
/*     */ 
/*     */   
/*     */   private final HttpServletRequest request;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final HttpServletResponse response;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Map<String, Object> model;
/*     */ 
/*     */   
/*     */   private final WebApplicationContext webApplicationContext;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Locale locale;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TimeZone timeZone;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   private Theme theme;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Boolean defaultHtmlEscape;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Boolean responseEncodedHtmlEscape;
/*     */ 
/*     */   
/*     */   private UrlPathHelper urlPathHelper;
/*     */   
/*     */   @Nullable
/*     */   private RequestDataValueProcessor requestDataValueProcessor;
/*     */   
/*     */   @Nullable
/*     */   private Map<String, Errors> errorsMap;
/*     */ 
/*     */   
/*     */   public RequestContext(HttpServletRequest request) {
/* 142 */     this(request, null, request.getServletContext(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestContext(HttpServletRequest request, HttpServletResponse response) {
/* 157 */     this(request, response, request.getServletContext(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestContext(HttpServletRequest request, @Nullable ServletContext servletContext) {
/* 173 */     this(request, null, servletContext, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestContext(HttpServletRequest request, @Nullable Map<String, Object> model) {
/* 188 */     this(request, null, request.getServletContext(), model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable ServletContext servletContext, @Nullable Map<String, Object> model) {
/* 208 */     this.request = request;
/* 209 */     this.response = response;
/* 210 */     this.model = model;
/*     */ 
/*     */ 
/*     */     
/* 214 */     WebApplicationContext wac = (WebApplicationContext)request.getAttribute(WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 215 */     if (wac == null) {
/* 216 */       wac = RequestContextUtils.findWebApplicationContext(request, servletContext);
/* 217 */       if (wac == null) {
/* 218 */         throw new IllegalStateException("No WebApplicationContext found: not in a DispatcherServlet request and no ContextLoaderListener registered?");
/*     */       }
/*     */     } 
/*     */     
/* 222 */     this.webApplicationContext = wac;
/*     */     
/* 224 */     Locale locale = null;
/* 225 */     TimeZone timeZone = null;
/*     */ 
/*     */     
/* 228 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
/* 229 */     if (localeResolver instanceof LocaleContextResolver) { LocaleContextResolver localeContextResolver = (LocaleContextResolver)localeResolver;
/* 230 */       LocaleContext localeContext = localeContextResolver.resolveLocaleContext(request);
/* 231 */       locale = localeContext.getLocale();
/* 232 */       if (localeContext instanceof TimeZoneAwareLocaleContext) { TimeZoneAwareLocaleContext timeZoneAwareLocaleContext = (TimeZoneAwareLocaleContext)localeContext;
/* 233 */         timeZone = timeZoneAwareLocaleContext.getTimeZone(); }
/*     */       
/*     */        }
/* 236 */     else if (localeResolver != null)
/*     */     
/* 238 */     { locale = localeResolver.resolveLocale(request); }
/*     */ 
/*     */     
/* 241 */     this.locale = locale;
/* 242 */     this.timeZone = timeZone;
/*     */ 
/*     */ 
/*     */     
/* 246 */     this.defaultHtmlEscape = WebUtils.getDefaultHtmlEscape(this.webApplicationContext.getServletContext());
/*     */ 
/*     */ 
/*     */     
/* 250 */     this
/* 251 */       .responseEncodedHtmlEscape = WebUtils.getResponseEncodedHtmlEscape(this.webApplicationContext.getServletContext());
/*     */     
/* 253 */     this.urlPathHelper = new UrlPathHelper();
/*     */     
/* 255 */     if (this.webApplicationContext.containsBean("requestDataValueProcessor")) {
/* 256 */       this.requestDataValueProcessor = (RequestDataValueProcessor)this.webApplicationContext.getBean("requestDataValueProcessor", RequestDataValueProcessor.class);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final HttpServletRequest getRequest() {
/* 266 */     return this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final ServletContext getServletContext() {
/* 274 */     return this.webApplicationContext.getServletContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebApplicationContext getWebApplicationContext() {
/* 281 */     return this.webApplicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Map<String, Object> getModel() {
/* 290 */     return this.model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageSource getMessageSource() {
/* 298 */     return (MessageSource)this.webApplicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 309 */     return (this.locale != null) ? this.locale : getFallbackLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TimeZone getTimeZone() {
/* 320 */     return (this.timeZone != null) ? this.timeZone : getFallbackTimeZone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Locale getFallbackLocale() {
/* 331 */     if (jstlPresent) {
/* 332 */       Locale locale = JstlLocaleResolver.getJstlLocale(getRequest(), getServletContext());
/* 333 */       if (locale != null) {
/* 334 */         return locale;
/*     */       }
/*     */     } 
/* 337 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TimeZone getFallbackTimeZone() {
/* 348 */     if (jstlPresent) {
/* 349 */       TimeZone timeZone = JstlLocaleResolver.getJstlTimeZone(getRequest(), getServletContext());
/* 350 */       if (timeZone != null) {
/* 351 */         return timeZone;
/*     */       }
/*     */     } 
/* 354 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeLocale(Locale locale) {
/* 365 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(this.request);
/* 366 */     if (localeResolver == null) {
/* 367 */       throw new IllegalStateException("Cannot change locale if no LocaleResolver configured");
/*     */     }
/* 369 */     localeResolver.setLocale(this.request, this.response, locale);
/* 370 */     this.locale = locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeLocale(Locale locale, TimeZone timeZone) {
/*     */     LocaleContextResolver localeContextResolver;
/* 382 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(this.request);
/* 383 */     if (localeResolver instanceof LocaleContextResolver) { localeContextResolver = (LocaleContextResolver)localeResolver; }
/* 384 */     else { throw new IllegalStateException("Cannot change locale context if no LocaleContextResolver configured"); }
/*     */     
/* 386 */     localeContextResolver.setLocaleContext(this.request, this.response, (LocaleContext)new SimpleTimeZoneAwareLocaleContext(locale, timeZone));
/*     */     
/* 388 */     this.locale = locale;
/* 389 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public Theme getTheme() {
/* 399 */     if (this.theme == null) {
/*     */       
/* 401 */       this.theme = RequestContextUtils.getTheme(this.request);
/* 402 */       if (this.theme == null)
/*     */       {
/* 404 */         this.theme = getFallbackTheme();
/*     */       }
/*     */     } 
/* 407 */     return this.theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Theme getFallbackTheme() {
/*     */     ResourceBundleThemeSource resourceBundleThemeSource;
/* 418 */     ThemeSource themeSource = RequestContextUtils.getThemeSource(getRequest());
/* 419 */     if (themeSource == null) {
/* 420 */       resourceBundleThemeSource = new ResourceBundleThemeSource();
/*     */     }
/* 422 */     Theme theme = resourceBundleThemeSource.getTheme("theme");
/* 423 */     if (theme == null) {
/* 424 */       throw new IllegalStateException("No theme defined and no fallback theme found");
/*     */     }
/* 426 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0")
/*     */   public void changeTheme(@Nullable Theme theme) {
/* 439 */     ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(this.request);
/* 440 */     if (themeResolver == null) {
/* 441 */       throw new IllegalStateException("Cannot change theme if no ThemeResolver configured");
/*     */     }
/* 443 */     themeResolver.setThemeName(this.request, this.response, (theme != null) ? theme.getName() : null);
/* 444 */     this.theme = theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void changeTheme(String themeName) {
/* 457 */     ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(this.request);
/* 458 */     if (themeResolver == null) {
/* 459 */       throw new IllegalStateException("Cannot change theme if no ThemeResolver configured");
/*     */     }
/* 461 */     themeResolver.setThemeName(this.request, this.response, themeName);
/*     */     
/* 463 */     this.theme = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape) {
/* 472 */     this.defaultHtmlEscape = Boolean.valueOf(defaultHtmlEscape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultHtmlEscape() {
/* 479 */     return (this.defaultHtmlEscape != null && this.defaultHtmlEscape.booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Boolean getDefaultHtmlEscape() {
/* 488 */     return this.defaultHtmlEscape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResponseEncodedHtmlEscape() {
/* 498 */     return (this.responseEncodedHtmlEscape == null || this.responseEncodedHtmlEscape.booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Boolean getResponseEncodedHtmlEscape() {
/* 509 */     return this.responseEncodedHtmlEscape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
/* 519 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 520 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 529 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RequestDataValueProcessor getRequestDataValueProcessor() {
/* 539 */     return this.requestDataValueProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextPath() {
/* 551 */     return this.urlPathHelper.getOriginatingContextPath(this.request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextUrl(String relativeUrl) {
/* 560 */     String url = getContextPath() + getContextPath();
/* 561 */     if (this.response != null) {
/* 562 */       url = this.response.encodeURL(url);
/*     */     }
/* 564 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextUrl(String relativeUrl, Map<String, ?> params) {
/* 576 */     String url = getContextPath() + getContextPath();
/* 577 */     url = UriComponentsBuilder.fromUriString(url).buildAndExpand(params).encode().toUri().toASCIIString();
/* 578 */     if (this.response != null) {
/* 579 */       url = this.response.encodeURL(url);
/*     */     }
/* 581 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPathToServlet() {
/* 592 */     String path = this.urlPathHelper.getOriginatingContextPath(this.request);
/* 593 */     if (StringUtils.hasText(this.urlPathHelper.getPathWithinServletMapping(this.request))) {
/* 594 */       path = path + path;
/*     */     }
/* 596 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequestUri() {
/* 609 */     return this.urlPathHelper.getOriginatingRequestUri(this.request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueryString() {
/* 622 */     return this.urlPathHelper.getOriginatingQueryString(this.request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, String defaultMessage) {
/* 632 */     return getMessage(code, null, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable Object[] args, String defaultMessage) {
/* 643 */     return getMessage(code, args, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable List<?> args, String defaultMessage) {
/* 654 */     return getMessage(code, (args != null) ? args.toArray() : null, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable Object[] args, String defaultMessage, boolean htmlEscape) {
/* 666 */     String msg = getMessageSource().getMessage(code, args, defaultMessage, getLocale());
/* 667 */     if (msg == null) {
/* 668 */       return "";
/*     */     }
/* 670 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code) throws NoSuchMessageException {
/* 680 */     return getMessage(code, (Object[])null, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable Object[] args) throws NoSuchMessageException {
/* 691 */     return getMessage(code, args, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable List<?> args) throws NoSuchMessageException {
/* 702 */     return getMessage(code, (args != null) ? args.toArray() : null, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String code, @Nullable Object[] args, boolean htmlEscape) throws NoSuchMessageException {
/* 714 */     String msg = getMessageSource().getMessage(code, args, getLocale());
/* 715 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(MessageSourceResolvable resolvable) throws NoSuchMessageException {
/* 725 */     return getMessage(resolvable, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(MessageSourceResolvable resolvable, boolean htmlEscape) throws NoSuchMessageException {
/* 736 */     String msg = getMessageSource().getMessage(resolvable, getLocale());
/* 737 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(String code, String defaultMessage) {
/* 751 */     String msg = getTheme().getMessageSource().getMessage(code, null, defaultMessage, getLocale());
/* 752 */     return (msg != null) ? msg : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(String code, @Nullable Object[] args, String defaultMessage) {
/* 767 */     String msg = getTheme().getMessageSource().getMessage(code, args, defaultMessage, getLocale());
/* 768 */     return (msg != null) ? msg : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(String code, @Nullable List<?> args, String defaultMessage) {
/* 783 */     String msg = getTheme().getMessageSource().getMessage(code, (args != null) ? args.toArray() : null, defaultMessage, 
/* 784 */         getLocale());
/* 785 */     return (msg != null) ? msg : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(String code) throws NoSuchMessageException {
/* 799 */     return getTheme().getMessageSource().getMessage(code, null, getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(String code, @Nullable Object[] args) throws NoSuchMessageException {
/* 814 */     return getTheme().getMessageSource().getMessage(code, args, getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(String code, @Nullable List<?> args) throws NoSuchMessageException {
/* 829 */     return getTheme().getMessageSource().getMessage(code, (args != null) ? args.toArray() : null, getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getThemeMessage(MessageSourceResolvable resolvable) throws NoSuchMessageException {
/* 843 */     return getTheme().getMessageSource().getMessage(resolvable, getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Errors getErrors(String name) {
/* 853 */     return getErrors(name, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Errors getErrors(String name, boolean htmlEscape) {
/*     */     BindingResult bindingResult;
/*     */     EscapedErrors escapedErrors;
/*     */     Errors errors1;
/* 864 */     if (this.errorsMap == null) {
/* 865 */       this.errorsMap = new HashMap<>();
/*     */     }
/* 867 */     Errors errors = this.errorsMap.get(name);
/* 868 */     boolean put = false;
/* 869 */     if (errors == null) {
/* 870 */       errors = (Errors)getModelObject(BindingResult.MODEL_KEY_PREFIX + BindingResult.MODEL_KEY_PREFIX);
/*     */       
/* 872 */       if (errors instanceof BindException) { BindException bindException = (BindException)errors;
/* 873 */         bindingResult = bindException.getBindingResult(); }
/*     */       
/* 875 */       if (bindingResult == null) {
/* 876 */         return null;
/*     */       }
/* 878 */       put = true;
/*     */     } 
/* 880 */     if (htmlEscape && !(bindingResult instanceof EscapedErrors))
/* 881 */     { escapedErrors = new EscapedErrors((Errors)bindingResult);
/* 882 */       put = true; }
/*     */     
/* 884 */     else if (!htmlEscape && escapedErrors instanceof EscapedErrors) { EscapedErrors escapedErrors1 = escapedErrors;
/* 885 */       errors1 = escapedErrors1.getSource();
/* 886 */       put = true; }
/*     */     
/* 888 */     if (put) {
/* 889 */       this.errorsMap.put(name, errors1);
/*     */     }
/* 891 */     return errors1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getModelObject(String modelName) {
/* 902 */     if (this.model != null) {
/* 903 */       return this.model.get(modelName);
/*     */     }
/*     */     
/* 906 */     return this.request.getAttribute(modelName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindStatus getBindStatus(String path) throws IllegalStateException {
/* 917 */     return new BindStatus(this, path, isDefaultHtmlEscape());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindStatus getBindStatus(String path, boolean htmlEscape) throws IllegalStateException {
/* 928 */     return new BindStatus(this, path, htmlEscape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class JstlLocaleResolver
/*     */   {
/*     */     @Nullable
/*     */     public static Locale getJstlLocale(HttpServletRequest request, @Nullable ServletContext servletContext) {
/* 940 */       Object localeObject = Config.get((ServletRequest)request, "jakarta.servlet.jsp.jstl.fmt.locale");
/* 941 */       if (localeObject == null) {
/* 942 */         HttpSession session = request.getSession(false);
/* 943 */         if (session != null) {
/* 944 */           localeObject = Config.get(session, "jakarta.servlet.jsp.jstl.fmt.locale");
/*     */         }
/* 946 */         if (localeObject == null && servletContext != null) {
/* 947 */           localeObject = Config.get(servletContext, "jakarta.servlet.jsp.jstl.fmt.locale");
/*     */         }
/*     */       } 
/* 950 */       Locale locale = (Locale)localeObject; return (localeObject instanceof Locale) ? locale : null;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static TimeZone getJstlTimeZone(HttpServletRequest request, @Nullable ServletContext servletContext) {
/* 955 */       Object timeZoneObject = Config.get((ServletRequest)request, "jakarta.servlet.jsp.jstl.fmt.timeZone");
/* 956 */       if (timeZoneObject == null) {
/* 957 */         HttpSession session = request.getSession(false);
/* 958 */         if (session != null) {
/* 959 */           timeZoneObject = Config.get(session, "jakarta.servlet.jsp.jstl.fmt.timeZone");
/*     */         }
/* 961 */         if (timeZoneObject == null && servletContext != null) {
/* 962 */           timeZoneObject = Config.get(servletContext, "jakarta.servlet.jsp.jstl.fmt.timeZone");
/*     */         }
/*     */       } 
/* 965 */       TimeZone timeZone = (TimeZone)timeZoneObject; return (timeZoneObject instanceof TimeZone) ? timeZone : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\RequestContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */