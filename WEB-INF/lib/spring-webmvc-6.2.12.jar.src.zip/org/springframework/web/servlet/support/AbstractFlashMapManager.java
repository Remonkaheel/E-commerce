/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFlashMapManager
/*     */   implements FlashMapManager
/*     */ {
/*  49 */   private static final Object DEFAULT_FLASH_MAPS_MUTEX = new Object();
/*     */ 
/*     */   
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  54 */   private int flashMapTimeout = 180;
/*     */   
/*  56 */   private UrlPathHelper urlPathHelper = UrlPathHelper.defaultInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFlashMapTimeout(int flashMapTimeout) {
/*  65 */     this.flashMapTimeout = flashMapTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlashMapTimeout() {
/*  72 */     return this.flashMapTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
/*  79 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/*  80 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlPathHelper getUrlPathHelper() {
/*  87 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final FlashMap retrieveAndUpdate(HttpServletRequest request, HttpServletResponse response) {
/*  94 */     List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/*  95 */     if (CollectionUtils.isEmpty(allFlashMaps)) {
/*  96 */       return null;
/*     */     }
/*     */     
/*  99 */     List<FlashMap> mapsToRemove = getExpiredFlashMaps(allFlashMaps);
/* 100 */     FlashMap match = getMatchingFlashMap(allFlashMaps, request);
/* 101 */     if (match != null) {
/* 102 */       mapsToRemove.add(match);
/*     */     }
/*     */     
/* 105 */     if (!mapsToRemove.isEmpty()) {
/* 106 */       Object mutex = getFlashMapsMutex(request);
/* 107 */       if (mutex != null) {
/* 108 */         synchronized (mutex) {
/* 109 */           allFlashMaps = retrieveFlashMaps(request);
/* 110 */           if (allFlashMaps != null) {
/* 111 */             allFlashMaps.removeAll(mapsToRemove);
/* 112 */             updateFlashMaps(allFlashMaps, request, response);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 117 */         allFlashMaps.removeAll(mapsToRemove);
/* 118 */         updateFlashMaps(allFlashMaps, request, response);
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<FlashMap> getExpiredFlashMaps(List<FlashMap> allMaps) {
/* 129 */     List<FlashMap> result = new ArrayList<>();
/* 130 */     for (FlashMap map : allMaps) {
/* 131 */       if (map.isExpired()) {
/* 132 */         result.add(map);
/*     */       }
/*     */     } 
/* 135 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private FlashMap getMatchingFlashMap(List<FlashMap> allMaps, HttpServletRequest request) {
/* 144 */     List<FlashMap> result = new ArrayList<>();
/* 145 */     for (FlashMap flashMap : allMaps) {
/* 146 */       if (isFlashMapForRequest(flashMap, request)) {
/* 147 */         result.add(flashMap);
/*     */       }
/*     */     } 
/* 150 */     if (!result.isEmpty()) {
/* 151 */       Collections.sort(result);
/* 152 */       if (this.logger.isTraceEnabled()) {
/* 153 */         this.logger.trace("Found " + String.valueOf(result.get(0)));
/*     */       }
/* 155 */       return result.get(0);
/*     */     } 
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFlashMapForRequest(FlashMap flashMap, HttpServletRequest request) {
/* 165 */     String expectedPath = flashMap.getTargetRequestPath();
/* 166 */     if (expectedPath != null) {
/* 167 */       String requestUri = getUrlPathHelper().getOriginatingRequestUri(request);
/* 168 */       if (!requestUri.equals(expectedPath) && !requestUri.equals(expectedPath + "/")) {
/* 169 */         return false;
/*     */       }
/*     */     } 
/* 172 */     MultiValueMap<String, String> actualParams = getOriginatingRequestParams(request);
/* 173 */     MultiValueMap<String, String> expectedParams = flashMap.getTargetRequestParams();
/* 174 */     for (Map.Entry<String, List<String>> entry : (Iterable<Map.Entry<String, List<String>>>)expectedParams.entrySet()) {
/* 175 */       List<String> actualValues = (List<String>)actualParams.get(entry.getKey());
/* 176 */       if (actualValues == null) {
/* 177 */         return false;
/*     */       }
/* 179 */       for (String expectedValue : entry.getValue()) {
/* 180 */         if (!actualValues.contains(expectedValue)) {
/* 181 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 185 */     return true;
/*     */   }
/*     */   
/*     */   private MultiValueMap<String, String> getOriginatingRequestParams(HttpServletRequest request) {
/* 189 */     String query = getUrlPathHelper().getOriginatingQueryString(request);
/* 190 */     return ServletUriComponentsBuilder.fromPath("/").query(query).build().getQueryParams();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void saveOutputFlashMap(FlashMap flashMap, HttpServletRequest request, HttpServletResponse response) {
/* 195 */     if (CollectionUtils.isEmpty((Map)flashMap)) {
/*     */       return;
/*     */     }
/*     */     
/* 199 */     String path = decodeAndNormalizePath(flashMap.getTargetRequestPath(), request);
/* 200 */     flashMap.setTargetRequestPath(path);
/*     */     
/* 202 */     flashMap.startExpirationPeriod(getFlashMapTimeout());
/*     */     
/* 204 */     Object mutex = getFlashMapsMutex(request);
/* 205 */     if (mutex != null) {
/* 206 */       synchronized (mutex) {
/* 207 */         List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/* 208 */         allFlashMaps = (allFlashMaps != null) ? allFlashMaps : new CopyOnWriteArrayList<>();
/* 209 */         allFlashMaps.add(flashMap);
/* 210 */         updateFlashMaps(allFlashMaps, request, response);
/*     */       } 
/*     */     } else {
/*     */       
/* 214 */       List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/* 215 */       allFlashMaps = (allFlashMaps != null) ? allFlashMaps : new ArrayList<>(1);
/* 216 */       allFlashMaps.add(flashMap);
/* 217 */       updateFlashMaps(allFlashMaps, request, response);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String decodeAndNormalizePath(@Nullable String path, HttpServletRequest request) {
/* 223 */     if (StringUtils.hasLength(path)) {
/* 224 */       path = getUrlPathHelper().decodeRequestString(request, path);
/* 225 */       if (path.charAt(0) != '/') {
/* 226 */         String requestUri = getUrlPathHelper().getRequestUri(request);
/* 227 */         path = requestUri.substring(0, requestUri.lastIndexOf('/') + 1) + requestUri.substring(0, requestUri.lastIndexOf('/') + 1);
/* 228 */         path = StringUtils.cleanPath(path);
/*     */       } 
/*     */     } 
/* 231 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract List<FlashMap> retrieveFlashMaps(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void updateFlashMaps(List<FlashMap> paramList, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getFlashMapsMutex(HttpServletRequest request) {
/* 263 */     return DEFAULT_FLASH_MAPS_MUTEX;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\AbstractFlashMapManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */