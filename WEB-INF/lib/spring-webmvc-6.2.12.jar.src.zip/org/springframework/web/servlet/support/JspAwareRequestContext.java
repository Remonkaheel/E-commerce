/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.jsp.PageContext;
/*     */ import jakarta.servlet.jsp.jstl.core.Config;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JspAwareRequestContext
/*     */   extends RequestContext
/*     */ {
/*     */   private final PageContext pageContext;
/*     */   
/*     */   public JspAwareRequestContext(PageContext pageContext) {
/*  52 */     this(pageContext, (Map<String, Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JspAwareRequestContext(PageContext pageContext, @Nullable Map<String, Object> model) {
/*  63 */     super((HttpServletRequest)pageContext.getRequest(), (HttpServletResponse)pageContext.getResponse(), pageContext
/*  64 */         .getServletContext(), model);
/*  65 */     this.pageContext = pageContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PageContext getPageContext() {
/*  74 */     return this.pageContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Locale getFallbackLocale() {
/*  84 */     if (jstlPresent) {
/*  85 */       Locale locale = JstlPageLocaleResolver.getJstlLocale(getPageContext());
/*  86 */       if (locale != null) {
/*  87 */         return locale;
/*     */       }
/*     */     } 
/*  90 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TimeZone getFallbackTimeZone() {
/* 100 */     if (jstlPresent) {
/* 101 */       TimeZone timeZone = JstlPageLocaleResolver.getJstlTimeZone(getPageContext());
/* 102 */       if (timeZone != null) {
/* 103 */         return timeZone;
/*     */       }
/*     */     } 
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class JstlPageLocaleResolver
/*     */   {
/*     */     @Nullable
/*     */     public static Locale getJstlLocale(PageContext pageContext) {
/* 118 */       Object localeObject = Config.find(pageContext, "jakarta.servlet.jsp.jstl.fmt.locale");
/* 119 */       Locale locale = (Locale)localeObject; return (localeObject instanceof Locale) ? locale : null;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static TimeZone getJstlTimeZone(PageContext pageContext) {
/* 124 */       Object timeZoneObject = Config.find(pageContext, "jakarta.servlet.jsp.jstl.fmt.timeZone");
/* 125 */       TimeZone timeZone = (TimeZone)timeZoneObject; return (timeZoneObject instanceof TimeZone) ? timeZone : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\JspAwareRequestContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */