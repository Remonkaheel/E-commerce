/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.jsp.jstl.core.Config;
/*     */ import jakarta.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.support.MessageSourceResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringLocalizationContext
/*     */   extends LocalizationContext
/*     */ {
/*     */   private final MessageSource messageSource;
/*     */   private final HttpServletRequest request;
/*     */   
/*     */   public SpringLocalizationContext(MessageSource messageSource, HttpServletRequest request) {
/* 126 */     this.messageSource = messageSource;
/* 127 */     this.request = request;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceBundle getResourceBundle() {
/* 132 */     HttpSession session = this.request.getSession(false);
/* 133 */     if (session != null) {
/* 134 */       Object lcObject = Config.get(session, "jakarta.servlet.jsp.jstl.fmt.localizationContext");
/* 135 */       if (lcObject instanceof LocalizationContext) { LocalizationContext localizationContext = (LocalizationContext)lcObject;
/* 136 */         ResourceBundle lcBundle = localizationContext.getResourceBundle();
/* 137 */         return (ResourceBundle)new MessageSourceResourceBundle(this.messageSource, getLocale(), lcBundle); }
/*     */     
/*     */     } 
/* 140 */     return (ResourceBundle)new MessageSourceResourceBundle(this.messageSource, getLocale());
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 145 */     HttpSession session = this.request.getSession(false);
/* 146 */     if (session != null) {
/* 147 */       Object localeObject = Config.get(session, "jakarta.servlet.jsp.jstl.fmt.locale");
/* 148 */       if (localeObject instanceof Locale) { Locale locale = (Locale)localeObject;
/* 149 */         return locale; }
/*     */     
/*     */     } 
/* 152 */     return RequestContextUtils.getLocale(this.request);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\JstlUtils$SpringLocalizationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */