/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WebContentGenerator
/*     */   extends WebApplicationObjectSupport
/*     */ {
/*     */   public static final String METHOD_GET = "GET";
/*     */   public static final String METHOD_HEAD = "HEAD";
/*     */   public static final String METHOD_POST = "POST";
/*     */   protected static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*     */   @Nullable
/*     */   private Set<String> supportedMethods;
/*     */   @Nullable
/*     */   private String allowHeader;
/*     */   private boolean requireSession = false;
/*     */   @Nullable
/*     */   private CacheControl cacheControl;
/*  87 */   private int cacheSeconds = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String[] varyByRequestHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebContentGenerator() {
/*  98 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebContentGenerator(boolean restrictDefaultSupportedMethods) {
/* 108 */     if (restrictDefaultSupportedMethods) {
/* 109 */       this.supportedMethods = CollectionUtils.newLinkedHashSet(3);
/* 110 */       this.supportedMethods.add("GET");
/* 111 */       this.supportedMethods.add("HEAD");
/* 112 */       this.supportedMethods.add("POST");
/*     */     } 
/* 114 */     initAllowHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebContentGenerator(String... supportedMethods) {
/* 122 */     setSupportedMethods(supportedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSupportedMethods(@Nullable String... methods) {
/* 132 */     if (!ObjectUtils.isEmpty((Object[])methods)) {
/* 133 */       this.supportedMethods = new LinkedHashSet<>(Arrays.asList(methods));
/*     */     } else {
/*     */       
/* 136 */       this.supportedMethods = null;
/*     */     } 
/* 138 */     initAllowHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String[] getSupportedMethods() {
/* 146 */     return (this.supportedMethods != null) ? StringUtils.toStringArray(this.supportedMethods) : null;
/*     */   }
/*     */   
/*     */   private void initAllowHeader() {
/*     */     Collection<String> allowedMethods;
/* 151 */     if (this.supportedMethods == null) {
/* 152 */       allowedMethods = new ArrayList<>((HttpMethod.values()).length - 1);
/* 153 */       for (HttpMethod method : HttpMethod.values()) {
/* 154 */         if (method != HttpMethod.TRACE) {
/* 155 */           allowedMethods.add(method.name());
/*     */         }
/*     */       }
/*     */     
/* 159 */     } else if (this.supportedMethods.contains(HttpMethod.OPTIONS.name())) {
/* 160 */       allowedMethods = this.supportedMethods;
/*     */     } else {
/*     */       
/* 163 */       allowedMethods = new ArrayList<>(this.supportedMethods);
/* 164 */       allowedMethods.add(HttpMethod.OPTIONS.name());
/*     */     } 
/*     */     
/* 167 */     this.allowHeader = StringUtils.collectionToCommaDelimitedString(allowedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getAllowHeader() {
/* 181 */     return this.allowHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRequireSession(boolean requireSession) {
/* 188 */     this.requireSession = requireSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isRequireSession() {
/* 195 */     return this.requireSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCacheControl(@Nullable CacheControl cacheControl) {
/* 204 */     this.cacheControl = cacheControl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final CacheControl getCacheControl() {
/* 214 */     return this.cacheControl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCacheSeconds(int seconds) {
/* 230 */     this.cacheSeconds = seconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getCacheSeconds() {
/* 237 */     return this.cacheSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVaryByRequestHeaders(@Nullable String... varyByRequestHeaders) {
/* 250 */     this.varyByRequestHeaders = varyByRequestHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String[] getVaryByRequestHeaders() {
/* 259 */     return this.varyByRequestHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void checkRequest(HttpServletRequest request) throws ServletException {
/* 271 */     String method = request.getMethod();
/* 272 */     if (this.supportedMethods != null && !this.supportedMethods.contains(method)) {
/* 273 */       throw new HttpRequestMethodNotSupportedException(method, this.supportedMethods);
/*     */     }
/*     */ 
/*     */     
/* 277 */     if (this.requireSession && request.getSession(false) == null) {
/* 278 */       throw new HttpSessionRequiredException("Pre-existing session required but none found");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void prepareResponse(HttpServletResponse response) {
/* 289 */     if (this.cacheControl != null) {
/* 290 */       if (this.logger.isTraceEnabled()) {
/* 291 */         this.logger.trace("Applying default " + String.valueOf(getCacheControl()));
/*     */       }
/* 293 */       applyCacheControl(response, this.cacheControl);
/*     */     } else {
/*     */       
/* 296 */       if (this.logger.isTraceEnabled()) {
/* 297 */         this.logger.trace("Applying default cacheSeconds=" + this.cacheSeconds);
/*     */       }
/* 299 */       applyCacheSeconds(response, this.cacheSeconds);
/*     */     } 
/* 301 */     if (this.varyByRequestHeaders != null) {
/* 302 */       for (String value : getVaryRequestHeadersToAdd(response, this.varyByRequestHeaders)) {
/* 303 */         response.addHeader("Vary", value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void applyCacheControl(HttpServletResponse response, CacheControl cacheControl) {
/* 315 */     String ccValue = cacheControl.getHeaderValue();
/* 316 */     if (ccValue != null)
/*     */     {
/* 318 */       response.setHeader("Cache-Control", ccValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int cacheSeconds) {
/*     */     CacheControl cControl;
/* 333 */     if (cacheSeconds > 0) {
/* 334 */       cControl = CacheControl.maxAge(cacheSeconds, TimeUnit.SECONDS);
/*     */     }
/* 336 */     else if (cacheSeconds == 0) {
/* 337 */       cControl = CacheControl.noStore();
/*     */     } else {
/*     */       
/* 340 */       cControl = CacheControl.empty();
/*     */     } 
/* 342 */     applyCacheControl(response, cControl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, int cacheSeconds, boolean lastModified) throws ServletException {
/* 359 */     checkRequest(request);
/* 360 */     applyCacheSeconds(response, cacheSeconds);
/*     */   }
/*     */   
/*     */   private Collection<String> getVaryRequestHeadersToAdd(HttpServletResponse response, String[] varyByRequestHeaders) {
/* 364 */     if (!response.containsHeader("Vary")) {
/* 365 */       return Arrays.asList(varyByRequestHeaders);
/*     */     }
/* 367 */     Collection<String> result = new ArrayList<>(varyByRequestHeaders.length);
/* 368 */     Collections.addAll(result, varyByRequestHeaders);
/* 369 */     for (String header : response.getHeaders("Vary")) {
/* 370 */       for (String existing : StringUtils.tokenizeToStringArray(header, ",")) {
/* 371 */         if ("*".equals(existing)) {
/* 372 */           return Collections.emptyList();
/*     */         }
/* 374 */         for (String value : varyByRequestHeaders) {
/* 375 */           if (value.equalsIgnoreCase(existing)) {
/* 376 */             result.remove(value);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 381 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\WebContentGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */