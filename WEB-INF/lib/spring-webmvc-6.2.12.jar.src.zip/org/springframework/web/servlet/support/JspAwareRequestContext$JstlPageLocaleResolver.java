/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import jakarta.servlet.jsp.PageContext;
/*     */ import jakarta.servlet.jsp.jstl.core.Config;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JstlPageLocaleResolver
/*     */ {
/*     */   @Nullable
/*     */   public static Locale getJstlLocale(PageContext pageContext) {
/* 118 */     Object localeObject = Config.find(pageContext, "jakarta.servlet.jsp.jstl.fmt.locale");
/* 119 */     Locale locale = (Locale)localeObject; return (localeObject instanceof Locale) ? locale : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static TimeZone getJstlTimeZone(PageContext pageContext) {
/* 124 */     Object timeZoneObject = Config.find(pageContext, "jakarta.servlet.jsp.jstl.fmt.timeZone");
/* 125 */     TimeZone timeZone = (TimeZone)timeZoneObject; return (timeZoneObject instanceof TimeZone) ? timeZone : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\support\JspAwareRequestContext$JstlPageLocaleResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */