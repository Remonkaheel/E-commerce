/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ import jakarta.servlet.jsp.JspException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HtmlEscapeTag
/*    */   extends RequestContextAwareTag
/*    */ {
/*    */   private boolean defaultHtmlEscape;
/*    */   
/*    */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape) {
/* 65 */     this.defaultHtmlEscape = defaultHtmlEscape;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int doStartTagInternal() throws JspException {
/* 71 */     getRequestContext().setDefaultHtmlEscape(this.defaultHtmlEscape);
/* 72 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\HtmlEscapeTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */