package org.springframework.web.servlet.tags;

import jakarta.servlet.jsp.JspTagException;
import org.springframework.lang.Nullable;

public interface ArgumentAware {
  void addArgument(@Nullable Object paramObject) throws JspTagException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\ArgumentAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */