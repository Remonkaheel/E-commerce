package org.springframework.web.servlet.tags;

import jakarta.servlet.jsp.JspException;
import java.beans.PropertyEditor;
import org.springframework.lang.Nullable;

public interface EditorAwareTag {
  @Nullable
  PropertyEditor getEditor() throws JspException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\EditorAwareTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */