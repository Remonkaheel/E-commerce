/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.tagext.BodyTag;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorsTag
/*     */   extends AbstractHtmlElementBodyTag
/*     */   implements BodyTag
/*     */ {
/*     */   public static final String MESSAGES_ATTRIBUTE = "messages";
/*     */   public static final String SPAN_TAG = "span";
/* 206 */   private String element = "span";
/*     */   
/* 208 */   private String delimiter = "<br/>";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object oldMessages;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean errorMessagesWereExposed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElement(String element) {
/* 224 */     Assert.hasText(element, "'element' cannot be null or blank");
/* 225 */     this.element = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElement() {
/* 232 */     return this.element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelimiter(String delimiter) {
/* 240 */     this.delimiter = delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDelimiter() {
/* 247 */     return this.delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String autogenerateId() throws JspException {
/* 261 */     String path = getPropertyPath();
/* 262 */     if (!StringUtils.hasLength(path) || "*".equals(path)) {
/* 263 */       path = (String)this.pageContext.getAttribute(FormTag.MODEL_ATTRIBUTE_VARIABLE_NAME, 2);
/*     */     }
/*     */     
/* 266 */     return StringUtils.deleteAny(path, "[]") + ".errors";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getName() throws JspException {
/* 277 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldRender() throws JspException {
/*     */     try {
/* 288 */       return getBindStatus().isError();
/*     */     }
/* 290 */     catch (IllegalStateException ex) {
/*     */       
/* 292 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderDefaultContent(TagWriter tagWriter) throws JspException {
/* 298 */     tagWriter.startTag(getElement());
/* 299 */     writeDefaultAttributes(tagWriter);
/* 300 */     String delimiter = ObjectUtils.getDisplayString(evaluate("delimiter", getDelimiter()));
/* 301 */     String[] errorMessages = getBindStatus().getErrorMessages();
/* 302 */     for (int i = 0; i < errorMessages.length; i++) {
/* 303 */       String errorMessage = errorMessages[i];
/* 304 */       if (i > 0) {
/* 305 */         tagWriter.appendValue(delimiter);
/*     */       }
/* 307 */       tagWriter.appendValue(getDisplayString(errorMessage));
/*     */     } 
/* 309 */     tagWriter.endTag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void exposeAttributes() throws JspException {
/* 320 */     List<String> errorMessages = new ArrayList<>(Arrays.asList(getBindStatus().getErrorMessages()));
/* 321 */     this.oldMessages = this.pageContext.getAttribute("messages", 1);
/* 322 */     this.pageContext.setAttribute("messages", errorMessages, 1);
/* 323 */     this.errorMessagesWereExposed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeAttributes() {
/* 333 */     if (this.errorMessagesWereExposed)
/* 334 */       if (this.oldMessages != null) {
/* 335 */         this.pageContext.setAttribute("messages", this.oldMessages, 1);
/* 336 */         this.oldMessages = null;
/*     */       } else {
/*     */         
/* 339 */         this.pageContext.removeAttribute("messages", 1);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\ErrorsTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */