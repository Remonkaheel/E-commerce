/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.JspTagException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageTag
/*     */   extends HtmlEscapingAwareTag
/*     */   implements ArgumentAware
/*     */ {
/*     */   public static final String DEFAULT_ARGUMENT_SEPARATOR = ",";
/*     */   @Nullable
/*     */   private MessageSourceResolvable message;
/*     */   @Nullable
/*     */   private String code;
/*     */   @Nullable
/*     */   private Object arguments;
/* 165 */   private String argumentSeparator = ",";
/*     */   
/* 167 */   private List<Object> nestedArguments = Collections.emptyList();
/*     */   
/*     */   @Nullable
/*     */   private String text;
/*     */   
/*     */   @Nullable
/*     */   private String var;
/*     */   
/* 175 */   private String scope = "page";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean javaScriptEscape = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessage(MessageSourceResolvable message) {
/* 186 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCode(String code) {
/* 193 */     this.code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArguments(Object arguments) {
/* 202 */     this.arguments = arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArgumentSeparator(String argumentSeparator) {
/* 211 */     this.argumentSeparator = argumentSeparator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addArgument(@Nullable Object argument) throws JspTagException {
/* 216 */     this.nestedArguments.add(argument);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 223 */     this.text = text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 233 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/* 244 */     this.scope = scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape) throws JspException {
/* 252 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int doStartTagInternal() throws JspException, IOException {
/* 258 */     this.nestedArguments = new ArrayList();
/* 259 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/* 274 */       String msg = resolveMessage();
/*     */ 
/*     */       
/* 277 */       msg = htmlEscape(msg);
/* 278 */       msg = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(msg) : msg;
/*     */ 
/*     */       
/* 281 */       if (this.var != null) {
/* 282 */         this.pageContext.setAttribute(this.var, msg, TagUtils.getScope(this.scope));
/*     */       } else {
/*     */         
/* 285 */         writeMessage(msg);
/*     */       } 
/*     */       
/* 288 */       return 6;
/*     */     }
/* 290 */     catch (IOException ex) {
/* 291 */       throw new JspTagException(ex.getMessage(), ex);
/*     */     }
/* 293 */     catch (NoSuchMessageException ex) {
/* 294 */       throw new JspTagException(getNoSuchMessageExceptionDescription(ex));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 300 */     super.release();
/* 301 */     this.arguments = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolveMessage() throws JspException, NoSuchMessageException {
/* 311 */     MessageSource messageSource = getMessageSource();
/*     */ 
/*     */     
/* 314 */     if (this.message != null)
/*     */     {
/* 316 */       return messageSource.getMessage(this.message, getRequestContext().getLocale());
/*     */     }
/*     */     
/* 319 */     if (this.code != null || this.text != null) {
/*     */       
/* 321 */       Object[] argumentsArray = resolveArguments(this.arguments);
/* 322 */       if (!this.nestedArguments.isEmpty()) {
/* 323 */         argumentsArray = appendArguments(argumentsArray, this.nestedArguments.toArray());
/*     */       }
/*     */       
/* 326 */       if (this.text != null) {
/*     */         
/* 328 */         String msg = messageSource.getMessage(this.code, argumentsArray, this.text, 
/* 329 */             getRequestContext().getLocale());
/* 330 */         return (msg != null) ? msg : "";
/*     */       } 
/*     */ 
/*     */       
/* 334 */       return messageSource.getMessage(this.code, argumentsArray, 
/* 335 */           getRequestContext().getLocale());
/*     */     } 
/*     */ 
/*     */     
/* 339 */     throw new JspTagException("No resolvable message");
/*     */   }
/*     */   
/*     */   private Object[] appendArguments(@Nullable Object[] sourceArguments, Object[] additionalArguments) {
/* 343 */     if (ObjectUtils.isEmpty(sourceArguments)) {
/* 344 */       return additionalArguments;
/*     */     }
/* 346 */     Object[] arguments = new Object[sourceArguments.length + additionalArguments.length];
/* 347 */     System.arraycopy(sourceArguments, 0, arguments, 0, sourceArguments.length);
/* 348 */     System.arraycopy(additionalArguments, 0, arguments, sourceArguments.length, additionalArguments.length);
/* 349 */     return arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object[] resolveArguments(@Nullable Object arguments) throws JspException {
/* 361 */     if (arguments instanceof String) { String string = (String)arguments;
/* 362 */       return (Object[])StringUtils.delimitedListToStringArray(string, this.argumentSeparator); }
/*     */     
/* 364 */     if (arguments instanceof Object[]) { Object[] array = (Object[])arguments;
/* 365 */       return array; }
/*     */     
/* 367 */     if (arguments instanceof Collection) { Collection<?> collection = (Collection)arguments;
/* 368 */       return collection.toArray(); }
/*     */     
/* 370 */     if (arguments != null)
/*     */     {
/* 372 */       return new Object[] { arguments };
/*     */     }
/*     */     
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeMessage(String msg) throws IOException {
/* 386 */     this.pageContext.getOut().write(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MessageSource getMessageSource() {
/* 393 */     return getRequestContext().getMessageSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getNoSuchMessageExceptionDescription(NoSuchMessageException ex) {
/* 401 */     return ex.getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\MessageTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */