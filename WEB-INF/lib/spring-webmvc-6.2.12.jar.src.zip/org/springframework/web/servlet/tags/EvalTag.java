/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.PageContext;
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.context.expression.EnvironmentAccessor;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EvalTag
/*     */   extends HtmlEscapingAwareTag
/*     */ {
/*     */   private static final String EVALUATION_CONTEXT_PAGE_ATTRIBUTE = "org.springframework.web.servlet.tags.EVALUATION_CONTEXT";
/* 114 */   private final ExpressionParser expressionParser = (ExpressionParser)new SpelExpressionParser();
/*     */   
/*     */   @Nullable
/*     */   private Expression expression;
/*     */   
/*     */   @Nullable
/*     */   private String var;
/*     */   
/* 122 */   private int scope = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean javaScriptEscape = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(String expression) {
/* 131 */     this.expression = this.expressionParser.parseExpression(expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 139 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/* 147 */     this.scope = TagUtils.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape) throws JspException {
/* 155 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTagInternal() throws JspException {
/* 161 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 167 */     EvaluationContext evaluationContext = (EvaluationContext)this.pageContext.getAttribute("org.springframework.web.servlet.tags.EVALUATION_CONTEXT");
/* 168 */     if (evaluationContext == null) {
/* 169 */       evaluationContext = createEvaluationContext(this.pageContext);
/* 170 */       this.pageContext.setAttribute("org.springframework.web.servlet.tags.EVALUATION_CONTEXT", evaluationContext);
/*     */     } 
/* 172 */     if (this.var != null) {
/* 173 */       Object result = (this.expression != null) ? this.expression.getValue(evaluationContext) : null;
/* 174 */       this.pageContext.setAttribute(this.var, result, this.scope);
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 179 */         String result = (this.expression != null) ? (String)this.expression.getValue(evaluationContext, String.class) : null;
/* 180 */         result = ObjectUtils.getDisplayString(result);
/* 181 */         result = htmlEscape(result);
/* 182 */         result = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(result) : result;
/* 183 */         this.pageContext.getOut().print(result);
/*     */       }
/* 185 */       catch (IOException ex) {
/* 186 */         throw new JspException(ex);
/*     */       } 
/*     */     } 
/* 189 */     return 6;
/*     */   }
/*     */   
/*     */   private EvaluationContext createEvaluationContext(PageContext pageContext) {
/* 193 */     StandardEvaluationContext context = new StandardEvaluationContext();
/* 194 */     context.addPropertyAccessor(new JspPropertyAccessor(pageContext));
/* 195 */     context.addPropertyAccessor((PropertyAccessor)new MapAccessor());
/* 196 */     context.addPropertyAccessor((PropertyAccessor)new EnvironmentAccessor());
/* 197 */     context.setBeanResolver((BeanResolver)new BeanFactoryResolver((BeanFactory)getRequestContext().getWebApplicationContext()));
/* 198 */     ConversionService conversionService = getConversionService(pageContext);
/* 199 */     if (conversionService != null) {
/* 200 */       context.setTypeConverter((TypeConverter)new StandardTypeConverter(conversionService));
/*     */     }
/* 202 */     return (EvaluationContext)context;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ConversionService getConversionService(PageContext pageContext) {
/* 207 */     return (ConversionService)pageContext.getRequest().getAttribute(ConversionService.class.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JspPropertyAccessor
/*     */     implements PropertyAccessor
/*     */   {
/*     */     private final PageContext pageContext;
/*     */     
/*     */     @Nullable
/*     */     private final ELContext elContext;
/*     */ 
/*     */     
/*     */     public JspPropertyAccessor(PageContext pageContext) {
/* 221 */       this.pageContext = pageContext;
/* 222 */       this.elContext = pageContext.getELContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?>[] getSpecificTargetClasses() {
/* 228 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 233 */       return (target == null && (
/* 234 */         resolveImplicitVariable(name) != null || this.pageContext.findAttribute(name) != null));
/*     */     }
/*     */ 
/*     */     
/*     */     public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 239 */       Object implicitVar = resolveImplicitVariable(name);
/* 240 */       if (implicitVar != null) {
/* 241 */         return new TypedValue(implicitVar);
/*     */       }
/* 243 */       return new TypedValue(this.pageContext.findAttribute(name));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) {
/* 248 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) {
/* 253 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private Object resolveImplicitVariable(String name) throws AccessException {
/* 258 */       if (this.elContext == null) {
/* 259 */         return null;
/*     */       }
/*     */       try {
/* 262 */         return this.elContext.getELResolver().getValue(this.elContext, null, name);
/*     */       }
/* 264 */       catch (Exception ex) {
/* 265 */         throw new AccessException("Unexpected exception occurred accessing '" + name + "' as an implicit variable", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\EvalTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */