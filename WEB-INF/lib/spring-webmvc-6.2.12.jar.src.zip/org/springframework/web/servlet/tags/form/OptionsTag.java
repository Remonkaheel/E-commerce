/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.tagext.Tag;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsTag
/*     */   extends AbstractHtmlElementTag
/*     */ {
/*     */   @Nullable
/*     */   private Object items;
/*     */   @Nullable
/*     */   private String itemValue;
/*     */   @Nullable
/*     */   private String itemLabel;
/*     */   private boolean disabled;
/*     */   
/*     */   public void setItems(Object items) {
/* 227 */     this.items = items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getItems() {
/* 237 */     return this.items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemValue(String itemValue) {
/* 247 */     Assert.hasText(itemValue, "'itemValue' must not be empty");
/* 248 */     this.itemValue = itemValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getItemValue() {
/* 257 */     return this.itemValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabel(String itemLabel) {
/* 265 */     Assert.hasText(itemLabel, "'itemLabel' must not be empty");
/* 266 */     this.itemLabel = itemLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getItemLabel() {
/* 275 */     return this.itemLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisabled(boolean disabled) {
/* 282 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDisabled() {
/* 289 */     return this.disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int writeTagContent(TagWriter tagWriter) throws JspException {
/* 295 */     SelectTag selectTag = getSelectTag();
/* 296 */     Object items = getItems();
/* 297 */     Object itemsObject = null;
/* 298 */     if (items != null) {
/* 299 */       itemsObject = (items instanceof String) ? evaluate("items", items) : items;
/*     */     } else {
/*     */       
/* 302 */       Class<?> selectTagBoundType = selectTag.getBindStatus().getValueType();
/* 303 */       if (selectTagBoundType != null && selectTagBoundType.isEnum()) {
/* 304 */         itemsObject = selectTagBoundType.getEnumConstants();
/*     */       }
/*     */     } 
/* 307 */     if (itemsObject != null) {
/* 308 */       String selectName = selectTag.getName();
/* 309 */       String itemValue = getItemValue();
/* 310 */       String itemLabel = getItemLabel();
/*     */       
/* 312 */       String valueProperty = (itemValue != null) ? ObjectUtils.getDisplayString(evaluate("itemValue", itemValue)) : null;
/*     */       
/* 314 */       String labelProperty = (itemLabel != null) ? ObjectUtils.getDisplayString(evaluate("itemLabel", itemLabel)) : null;
/* 315 */       OptionsWriter optionWriter = new OptionsWriter(selectName, itemsObject, valueProperty, labelProperty);
/* 316 */       optionWriter.writeOptions(tagWriter);
/*     */     } 
/* 318 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveId() throws JspException {
/* 328 */     Object id = evaluate("id", getId());
/* 329 */     if (id != null) {
/* 330 */       String idString = id.toString();
/* 331 */       return StringUtils.hasText(idString) ? TagIdGenerator.nextId(idString, this.pageContext) : null;
/*     */     } 
/* 333 */     return null;
/*     */   }
/*     */   
/*     */   private SelectTag getSelectTag() {
/* 337 */     TagUtils.assertHasAncestorOfType((Tag)this, SelectTag.class, "options", "select");
/* 338 */     return (SelectTag)findAncestorWithClass((Tag)this, SelectTag.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BindStatus getBindStatus() {
/* 343 */     return (BindStatus)this.pageContext.getAttribute("org.springframework.web.servlet.tags.form.SelectTag.listValue");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class OptionsWriter
/*     */     extends OptionWriter
/*     */   {
/*     */     @Nullable
/*     */     private final String selectName;
/*     */ 
/*     */ 
/*     */     
/*     */     public OptionsWriter(String selectName, @Nullable Object optionSource, @Nullable String valueProperty, String labelProperty) {
/* 358 */       super(optionSource, OptionsTag.this.getBindStatus(), valueProperty, labelProperty, OptionsTag.this.isHtmlEscape());
/* 359 */       this.selectName = selectName;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isOptionDisabled() throws JspException {
/* 364 */       return OptionsTag.this.isDisabled();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void writeCommonAttributes(TagWriter tagWriter) throws JspException {
/* 369 */       OptionsTag.this.writeOptionalAttribute(tagWriter, "id", OptionsTag.this.resolveId());
/* 370 */       OptionsTag.this.writeOptionalAttributes(tagWriter);
/*     */     }
/*     */ 
/*     */     
/*     */     protected String processOptionValue(String value) {
/* 375 */       return OptionsTag.this.processFieldValue(this.selectName, value, "option");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\OptionsTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */