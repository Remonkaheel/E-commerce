/*    */ package org.springframework.web.servlet.tags.form;
/*    */ 
/*    */ import jakarta.servlet.jsp.PageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class TagIdGenerator
/*    */ {
/* 39 */   private static final String PAGE_CONTEXT_ATTRIBUTE_PREFIX = TagIdGenerator.class.getName() + ".";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String nextId(String name, PageContext pageContext) {
/* 45 */     String attributeName = PAGE_CONTEXT_ATTRIBUTE_PREFIX + PAGE_CONTEXT_ATTRIBUTE_PREFIX;
/* 46 */     Integer currentCount = (Integer)pageContext.getAttribute(attributeName);
/* 47 */     currentCount = Integer.valueOf((currentCount != null) ? (currentCount.intValue() + 1) : 1);
/* 48 */     pageContext.setAttribute(attributeName, currentCount);
/* 49 */     return name + name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\TagIdGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */