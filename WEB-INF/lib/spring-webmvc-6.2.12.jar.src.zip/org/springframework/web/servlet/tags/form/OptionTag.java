/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.tagext.BodyContent;
/*     */ import jakarta.servlet.jsp.tagext.BodyTag;
/*     */ import jakarta.servlet.jsp.tagext.Tag;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionTag
/*     */   extends AbstractHtmlElementBodyTag
/*     */   implements BodyTag
/*     */ {
/*     */   public static final String VALUE_VARIABLE_NAME = "value";
/*     */   public static final String DISPLAY_VALUE_VARIABLE_NAME = "displayValue";
/*     */   private static final String SELECTED_ATTRIBUTE = "selected";
/*     */   private static final String VALUE_ATTRIBUTE = "value";
/*     */   private static final String DISABLED_ATTRIBUTE = "disabled";
/*     */   @Nullable
/*     */   private Object value;
/*     */   @Nullable
/*     */   private String label;
/*     */   @Nullable
/*     */   private Object oldValue;
/*     */   @Nullable
/*     */   private Object oldDisplayValue;
/*     */   private boolean disabled;
/*     */   
/*     */   public void setValue(Object value) {
/* 252 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getValue() {
/* 260 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisabled(boolean disabled) {
/* 267 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDisabled() {
/* 274 */     return this.disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/* 282 */     this.label = label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getLabel() {
/* 290 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderDefaultContent(TagWriter tagWriter) throws JspException {
/* 296 */     Object value = this.pageContext.getAttribute("value");
/* 297 */     String label = getLabelValue(value);
/* 298 */     renderOption(value, label, tagWriter);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderFromBodyContent(BodyContent bodyContent, TagWriter tagWriter) throws JspException {
/* 303 */     Object value = this.pageContext.getAttribute("value");
/* 304 */     String label = bodyContent.getString();
/* 305 */     renderOption(value, label, tagWriter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onWriteTagContent() {
/* 313 */     assertUnderSelectTag();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void exposeAttributes() throws JspException {
/* 318 */     Object value = resolveValue();
/* 319 */     this.oldValue = this.pageContext.getAttribute("value");
/* 320 */     this.pageContext.setAttribute("value", value);
/* 321 */     this.oldDisplayValue = this.pageContext.getAttribute("displayValue");
/* 322 */     this.pageContext.setAttribute("displayValue", getDisplayString(value, getBindStatus().getEditor()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected BindStatus getBindStatus() {
/* 327 */     return (BindStatus)this.pageContext.getAttribute("org.springframework.web.servlet.tags.form.SelectTag.listValue");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void removeAttributes() {
/* 332 */     if (this.oldValue != null) {
/* 333 */       this.pageContext.setAttribute("value", this.oldValue);
/* 334 */       this.oldValue = null;
/*     */     } else {
/*     */       
/* 337 */       this.pageContext.removeAttribute("value");
/*     */     } 
/*     */     
/* 340 */     if (this.oldDisplayValue != null) {
/* 341 */       this.pageContext.setAttribute("displayValue", this.oldDisplayValue);
/* 342 */       this.oldDisplayValue = null;
/*     */     } else {
/*     */       
/* 345 */       this.pageContext.removeAttribute("displayValue");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderOption(Object value, String label, TagWriter tagWriter) throws JspException {
/* 350 */     tagWriter.startTag("option");
/* 351 */     writeOptionalAttribute(tagWriter, "id", resolveId());
/* 352 */     writeOptionalAttributes(tagWriter);
/* 353 */     String renderedValue = getDisplayString(value, getBindStatus().getEditor());
/* 354 */     renderedValue = processFieldValue(getSelectTag().getName(), renderedValue, "option");
/* 355 */     tagWriter.writeAttribute("value", renderedValue);
/* 356 */     if (isSelected(value)) {
/* 357 */       tagWriter.writeAttribute("selected", "selected");
/*     */     }
/* 359 */     if (isDisabled()) {
/* 360 */       tagWriter.writeAttribute("disabled", "disabled");
/*     */     }
/* 362 */     tagWriter.appendValue(label);
/* 363 */     tagWriter.endTag();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String autogenerateId() throws JspException {
/* 369 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLabelValue(Object resolvedValue) throws JspException {
/* 379 */     String label = getLabel();
/* 380 */     Object labelObj = (label == null) ? resolvedValue : evaluate("label", label);
/* 381 */     return getDisplayString(labelObj, getBindStatus().getEditor());
/*     */   }
/*     */   
/*     */   private void assertUnderSelectTag() {
/* 385 */     TagUtils.assertHasAncestorOfType((Tag)this, SelectTag.class, "option", "select");
/*     */   }
/*     */   
/*     */   private SelectTag getSelectTag() {
/* 389 */     return (SelectTag)findAncestorWithClass((Tag)this, SelectTag.class);
/*     */   }
/*     */   
/*     */   private boolean isSelected(Object resolvedValue) {
/* 393 */     return SelectedValueComparator.isSelected(getBindStatus(), resolvedValue);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object resolveValue() throws JspException {
/* 398 */     return evaluate("value", getValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\OptionTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */