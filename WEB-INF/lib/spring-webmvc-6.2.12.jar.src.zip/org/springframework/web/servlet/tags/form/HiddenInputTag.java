/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HiddenInputTag
/*     */   extends AbstractHtmlElementTag
/*     */ {
/*     */   public static final String DISABLED_ATTRIBUTE = "disabled";
/*     */   private boolean disabled;
/*     */   
/*     */   public void setDisabled(boolean disabled) {
/*  83 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisabled() {
/*  90 */     return this.disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidDynamicAttribute(String localName, Object value) {
/*  99 */     return !"type".equals(localName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int writeTagContent(TagWriter tagWriter) throws JspException {
/* 110 */     tagWriter.startTag("input");
/* 111 */     writeDefaultAttributes(tagWriter);
/* 112 */     tagWriter.writeAttribute("type", "hidden");
/* 113 */     if (isDisabled()) {
/* 114 */       tagWriter.writeAttribute("disabled", "disabled");
/*     */     }
/* 116 */     String value = getDisplayString(getBoundValue(), getPropertyEditor());
/* 117 */     tagWriter.writeAttribute("value", processFieldValue(getName(), value, "hidden"));
/* 118 */     tagWriter.endTag();
/* 119 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\HiddenInputTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */