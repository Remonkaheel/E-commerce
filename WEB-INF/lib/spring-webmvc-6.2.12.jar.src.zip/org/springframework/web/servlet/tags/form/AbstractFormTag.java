/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import java.beans.PropertyEditor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.tags.HtmlEscapingAwareTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFormTag
/*     */   extends HtmlEscapingAwareTag
/*     */ {
/*     */   @Nullable
/*     */   protected Object evaluate(String attributeName, @Nullable Object value) throws JspException {
/*  51 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void writeOptionalAttribute(TagWriter tagWriter, String attributeName, @Nullable String value) throws JspException {
/*  65 */     if (value != null) {
/*  66 */       tagWriter.writeOptionalAttributeValue(attributeName, getDisplayString(evaluate(attributeName, value)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TagWriter createTagWriter() {
/*  77 */     return new TagWriter(this.pageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int doStartTagInternal() throws Exception {
/*  87 */     return writeTagContent(createTagWriter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDisplayString(@Nullable Object value) {
/*  95 */     String displayString = ValueFormatter.getDisplayString(value, false);
/*  96 */     return isHtmlEscape() ? htmlEscape(displayString) : displayString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDisplayString(@Nullable Object value, @Nullable PropertyEditor propertyEditor) {
/* 106 */     String displayString = ValueFormatter.getDisplayString(value, propertyEditor, false);
/* 107 */     return isHtmlEscape() ? htmlEscape(displayString) : displayString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDefaultHtmlEscape() {
/* 115 */     Boolean defaultHtmlEscape = getRequestContext().getDefaultHtmlEscape();
/* 116 */     return (defaultHtmlEscape == null || defaultHtmlEscape.booleanValue());
/*     */   }
/*     */   
/*     */   protected abstract int writeTagContent(TagWriter paramTagWriter) throws JspException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\AbstractFormTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */