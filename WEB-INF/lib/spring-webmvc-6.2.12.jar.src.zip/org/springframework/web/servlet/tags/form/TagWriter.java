/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.PageContext;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagWriter
/*     */ {
/*     */   private final SafeWriter writer;
/*  50 */   private final Deque<TagStateEntry> tagState = new ArrayDeque<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagWriter(PageContext pageContext) {
/*  59 */     Assert.notNull(pageContext, "PageContext must not be null");
/*  60 */     this.writer = new SafeWriter(pageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagWriter(Writer writer) {
/*  69 */     Assert.notNull(writer, "Writer must not be null");
/*  70 */     this.writer = new SafeWriter(writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startTag(String tagName) throws JspException {
/*  80 */     if (inTag()) {
/*  81 */       closeTagAndMarkAsBlock();
/*     */     }
/*  83 */     push(tagName);
/*  84 */     this.writer.append("<").append(tagName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAttribute(String attributeName, String attributeValue) throws JspException {
/*  94 */     if (currentState().isBlockTag()) {
/*  95 */       throw new IllegalStateException("Cannot write attributes after opening tag is closed.");
/*     */     }
/*  97 */     this.writer.append(" ").append(attributeName).append("=\"")
/*  98 */       .append(attributeValue).append("\"");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAttribute(String attributeName) throws JspException {
/* 107 */     if (currentState().isBlockTag()) {
/* 108 */       throw new IllegalStateException("Cannot write attributes after opening tag is closed.");
/*     */     }
/* 110 */     this.writer.append(" ").append(attributeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeOptionalAttributeValue(String attributeName, @Nullable String attributeValue) throws JspException {
/* 119 */     if (StringUtils.hasText(attributeValue)) {
/* 120 */       writeAttribute(attributeName, attributeValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendValue(String value) throws JspException {
/* 130 */     if (!inTag()) {
/* 131 */       throw new IllegalStateException("Cannot write tag value. No open tag available.");
/*     */     }
/* 133 */     closeTagAndMarkAsBlock();
/* 134 */     this.writer.append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forceBlock() throws JspException {
/* 145 */     if (currentState().isBlockTag()) {
/*     */       return;
/*     */     }
/* 148 */     closeTagAndMarkAsBlock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endTag() throws JspException {
/* 157 */     endTag(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endTag(boolean enforceClosingTag) throws JspException {
/* 168 */     if (!inTag()) {
/* 169 */       throw new IllegalStateException("Cannot write end of tag. No open tag available.");
/*     */     }
/* 171 */     boolean renderClosingTag = true;
/* 172 */     if (!currentState().isBlockTag())
/*     */     {
/* 174 */       if (enforceClosingTag) {
/* 175 */         this.writer.append(">");
/*     */       } else {
/*     */         
/* 178 */         this.writer.append("/>");
/* 179 */         renderClosingTag = false;
/*     */       } 
/*     */     }
/* 182 */     if (renderClosingTag) {
/* 183 */       this.writer.append("</").append(currentState().getTagName()).append(">");
/*     */     }
/* 185 */     this.tagState.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void push(String tagName) {
/* 193 */     this.tagState.push(new TagStateEntry(tagName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeTagAndMarkAsBlock() throws JspException {
/* 200 */     if (!currentState().isBlockTag()) {
/* 201 */       currentState().markAsBlockTag();
/* 202 */       this.writer.append(">");
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean inTag() {
/* 207 */     return !this.tagState.isEmpty();
/*     */   }
/*     */   
/*     */   private TagStateEntry currentState() {
/* 211 */     return this.tagState.element();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TagStateEntry
/*     */   {
/*     */     private final String tagName;
/*     */ 
/*     */     
/*     */     private boolean blockTag;
/*     */ 
/*     */     
/*     */     public TagStateEntry(String tagName) {
/* 225 */       this.tagName = tagName;
/*     */     }
/*     */     
/*     */     public String getTagName() {
/* 229 */       return this.tagName;
/*     */     }
/*     */     
/*     */     public void markAsBlockTag() {
/* 233 */       this.blockTag = true;
/*     */     }
/*     */     
/*     */     public boolean isBlockTag() {
/* 237 */       return this.blockTag;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class SafeWriter
/*     */   {
/*     */     @Nullable
/*     */     private PageContext pageContext;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Writer writer;
/*     */ 
/*     */ 
/*     */     
/*     */     public SafeWriter(PageContext pageContext) {
/* 255 */       this.pageContext = pageContext;
/*     */     }
/*     */     
/*     */     public SafeWriter(Writer writer) {
/* 259 */       this.writer = writer;
/*     */     }
/*     */     
/*     */     public SafeWriter append(String value) throws JspException {
/*     */       try {
/* 264 */         getWriterToUse().write(String.valueOf(value));
/* 265 */         return this;
/*     */       }
/* 267 */       catch (IOException ex) {
/* 268 */         throw new JspException("Unable to write to JspWriter", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private Writer getWriterToUse() {
/* 273 */       Writer writer = (this.pageContext != null) ? (Writer)this.pageContext.getOut() : this.writer;
/* 274 */       Assert.state((writer != null), "No Writer available");
/* 275 */       return writer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\TagWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */