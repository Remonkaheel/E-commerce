/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.JspTagException;
/*     */ import jakarta.servlet.jsp.tagext.TagSupport;
/*     */ import jakarta.servlet.jsp.tagext.TryCatchFinally;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.support.JspAwareRequestContext;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestContextAwareTag
/*     */   extends TagSupport
/*     */   implements TryCatchFinally
/*     */ {
/*     */   public static final String REQUEST_CONTEXT_PAGE_ATTRIBUTE = "org.springframework.web.servlet.tags.REQUEST_CONTEXT";
/*  61 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private RequestContext requestContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int doStartTag() throws JspException {
/*     */     try {
/*  77 */       this.requestContext = (RequestContext)this.pageContext.getAttribute("org.springframework.web.servlet.tags.REQUEST_CONTEXT");
/*  78 */       if (this.requestContext == null) {
/*  79 */         this.requestContext = (RequestContext)new JspAwareRequestContext(this.pageContext);
/*  80 */         this.pageContext.setAttribute("org.springframework.web.servlet.tags.REQUEST_CONTEXT", this.requestContext);
/*     */       } 
/*  82 */       return doStartTagInternal();
/*     */     }
/*  84 */     catch (JspException|RuntimeException ex) {
/*  85 */       this.logger.error(ex.getMessage(), ex);
/*  86 */       throw ex;
/*     */     }
/*  88 */     catch (Exception ex) {
/*  89 */       this.logger.error(ex.getMessage(), ex);
/*  90 */       throw new JspTagException(ex.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final RequestContext getRequestContext() {
/*  98 */     Assert.state((this.requestContext != null), "No current RequestContext");
/*  99 */     return this.requestContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int doStartTagInternal() throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCatch(Throwable throwable) throws Throwable {
/* 114 */     throw throwable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void doFinally() {
/* 119 */     this.requestContext = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\RequestContextAwareTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */