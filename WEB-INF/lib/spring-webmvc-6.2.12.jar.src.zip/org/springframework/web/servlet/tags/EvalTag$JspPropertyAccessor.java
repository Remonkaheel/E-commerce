/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import jakarta.el.ELContext;
/*     */ import jakarta.servlet.jsp.PageContext;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JspPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   private final PageContext pageContext;
/*     */   @Nullable
/*     */   private final ELContext elContext;
/*     */   
/*     */   public JspPropertyAccessor(PageContext pageContext) {
/* 221 */     this.pageContext = pageContext;
/* 222 */     this.elContext = pageContext.getELContext();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?>[] getSpecificTargetClasses() {
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 233 */     return (target == null && (
/* 234 */       resolveImplicitVariable(name) != null || this.pageContext.findAttribute(name) != null));
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 239 */     Object implicitVar = resolveImplicitVariable(name);
/* 240 */     if (implicitVar != null) {
/* 241 */       return new TypedValue(implicitVar);
/*     */     }
/* 243 */     return new TypedValue(this.pageContext.findAttribute(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) {
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) {
/* 253 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object resolveImplicitVariable(String name) throws AccessException {
/* 258 */     if (this.elContext == null) {
/* 259 */       return null;
/*     */     }
/*     */     try {
/* 262 */       return this.elContext.getELResolver().getValue(this.elContext, null, name);
/*     */     }
/* 264 */     catch (Exception ex) {
/* 265 */       throw new AccessException("Unexpected exception occurred accessing '" + name + "' as an implicit variable", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\EvalTag$JspPropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */