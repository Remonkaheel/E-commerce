/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HtmlEscapingAwareTag
/*     */   extends RequestContextAwareTag
/*     */ {
/*     */   @Nullable
/*     */   private Boolean htmlEscape;
/*     */   
/*     */   public void setHtmlEscape(boolean htmlEscape) throws JspException {
/*  54 */     this.htmlEscape = Boolean.valueOf(htmlEscape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isHtmlEscape() {
/*  63 */     if (this.htmlEscape != null) {
/*  64 */       return this.htmlEscape.booleanValue();
/*     */     }
/*     */     
/*  67 */     return isDefaultHtmlEscape();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDefaultHtmlEscape() {
/*  78 */     return getRequestContext().isDefaultHtmlEscape();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isResponseEncodedHtmlEscape() {
/*  90 */     return getRequestContext().isResponseEncodedHtmlEscape();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String htmlEscape(String content) {
/* 104 */     String out = content;
/* 105 */     if (isHtmlEscape()) {
/* 106 */       if (isResponseEncodedHtmlEscape()) {
/* 107 */         out = HtmlUtils.htmlEscape(content, this.pageContext.getResponse().getCharacterEncoding());
/*     */       } else {
/*     */         
/* 110 */         out = HtmlUtils.htmlEscape(content);
/*     */       } 
/*     */     }
/* 113 */     return out;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\HtmlEscapingAwareTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */