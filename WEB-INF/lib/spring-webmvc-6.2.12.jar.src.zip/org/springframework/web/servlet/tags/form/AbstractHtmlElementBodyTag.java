/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import jakarta.servlet.jsp.tagext.BodyContent;
/*     */ import jakarta.servlet.jsp.tagext.BodyTag;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHtmlElementBodyTag
/*     */   extends AbstractHtmlElementTag
/*     */   implements BodyTag
/*     */ {
/*     */   @Nullable
/*     */   private BodyContent bodyContent;
/*     */   @Nullable
/*     */   private TagWriter tagWriter;
/*     */   
/*     */   protected int writeTagContent(TagWriter tagWriter) throws JspException {
/*  50 */     onWriteTagContent();
/*  51 */     this.tagWriter = tagWriter;
/*  52 */     if (shouldRender()) {
/*  53 */       exposeAttributes();
/*  54 */       return 2;
/*     */     } 
/*     */     
/*  57 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  69 */     if (shouldRender()) {
/*  70 */       Assert.state((this.tagWriter != null), "No TagWriter set");
/*  71 */       if (this.bodyContent != null && StringUtils.hasText(this.bodyContent.getString())) {
/*  72 */         renderFromBodyContent(this.bodyContent, this.tagWriter);
/*     */       } else {
/*     */         
/*  75 */         renderDefaultContent(this.tagWriter);
/*     */       } 
/*     */     } 
/*  78 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderFromBodyContent(BodyContent bodyContent, TagWriter tagWriter) throws JspException {
/*  88 */     flushBufferedBodyContent(bodyContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFinally() {
/*  96 */     super.doFinally();
/*  97 */     removeAttributes();
/*  98 */     this.tagWriter = null;
/*  99 */     this.bodyContent = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onWriteTagContent() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldRender() throws JspException {
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void exposeAttributes() throws JspException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeAttributes() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void flushBufferedBodyContent(BodyContent bodyContent) throws JspException {
/*     */     try {
/* 143 */       bodyContent.writeOut((Writer)bodyContent.getEnclosingWriter());
/*     */     }
/* 145 */     catch (IOException ex) {
/* 146 */       throw new JspException("Unable to write buffered body content.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void renderDefaultContent(TagWriter paramTagWriter) throws JspException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doInitBody() throws JspException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBodyContent(BodyContent bodyContent) {
/* 164 */     this.bodyContent = bodyContent;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\AbstractHtmlElementBodyTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */