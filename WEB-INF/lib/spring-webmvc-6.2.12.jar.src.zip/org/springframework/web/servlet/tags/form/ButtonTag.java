/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonTag
/*     */   extends AbstractHtmlElementTag
/*     */ {
/*     */   public static final String DISABLED_ATTRIBUTE = "disabled";
/*     */   @Nullable
/*     */   private TagWriter tagWriter;
/*     */   @Nullable
/*     */   private String name;
/*     */   @Nullable
/*     */   private String value;
/*     */   private boolean disabled;
/*     */   
/*     */   public void setName(String name) {
/*  97 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getName() {
/* 106 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable String value) {
/* 113 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getValue() {
/* 121 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisabled(boolean disabled) {
/* 128 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisabled() {
/* 135 */     return this.disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int writeTagContent(TagWriter tagWriter) throws JspException {
/* 141 */     tagWriter.startTag("button");
/* 142 */     writeDefaultAttributes(tagWriter);
/* 143 */     tagWriter.writeAttribute("type", getType());
/* 144 */     writeValue(tagWriter);
/* 145 */     if (isDisabled()) {
/* 146 */       tagWriter.writeAttribute("disabled", "disabled");
/*     */     }
/* 148 */     tagWriter.forceBlock();
/* 149 */     this.tagWriter = tagWriter;
/* 150 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeValue(TagWriter tagWriter) throws JspException {
/* 159 */     String valueToUse = (getValue() != null) ? getValue() : getDefaultValue();
/* 160 */     tagWriter.writeAttribute("value", processFieldValue(getName(), valueToUse, getType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDefaultValue() {
/* 168 */     return "Submit";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getType() {
/* 177 */     return "submit";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 185 */     Assert.state((this.tagWriter != null), "No TagWriter set");
/* 186 */     this.tagWriter.endTag();
/* 187 */     return 6;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\ButtonTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */