/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import jakarta.servlet.jsp.JspException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMultiCheckedElementTag
/*     */   extends AbstractCheckedElementTag
/*     */ {
/*     */   private static final String SPAN_TAG = "span";
/*     */   @Nullable
/*     */   private Object items;
/*     */   @Nullable
/*     */   private String itemValue;
/*     */   @Nullable
/*     */   private String itemLabel;
/*  74 */   private String element = "span";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String delimiter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItems(Object items) {
/*  90 */     Assert.notNull(items, "'items' must not be null");
/*  91 */     this.items = items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getItems() {
/* 100 */     return this.items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemValue(String itemValue) {
/* 109 */     Assert.hasText(itemValue, "'itemValue' must not be empty");
/* 110 */     this.itemValue = itemValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getItemValue() {
/* 119 */     return this.itemValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabel(String itemLabel) {
/* 128 */     Assert.hasText(itemLabel, "'itemLabel' must not be empty");
/* 129 */     this.itemLabel = itemLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getItemLabel() {
/* 138 */     return this.itemLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelimiter(String delimiter) {
/* 147 */     this.delimiter = delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getDelimiter() {
/* 156 */     return this.delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElement(String element) {
/* 165 */     Assert.hasText(element, "'element' cannot be null or blank");
/* 166 */     this.element = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElement() {
/* 174 */     return this.element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveId() throws JspException {
/* 185 */     Object id = evaluate("id", getId());
/* 186 */     if (id != null) {
/* 187 */       String idString = id.toString();
/* 188 */       return StringUtils.hasText(idString) ? TagIdGenerator.nextId(idString, this.pageContext) : null;
/*     */     } 
/* 190 */     return autogenerateId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int writeTagContent(TagWriter tagWriter) throws JspException {
/* 201 */     Object items = getItems();
/* 202 */     Object itemsObject = (items instanceof String) ? evaluate("items", items) : items;
/*     */     
/* 204 */     String itemValue = getItemValue();
/* 205 */     String itemLabel = getItemLabel();
/*     */     
/* 207 */     String valueProperty = (itemValue != null) ? ObjectUtils.getDisplayString(evaluate("itemValue", itemValue)) : null;
/*     */     
/* 209 */     String labelProperty = (itemLabel != null) ? ObjectUtils.getDisplayString(evaluate("itemLabel", itemLabel)) : null;
/*     */     
/* 211 */     Class<?> boundType = getBindStatus().getValueType();
/* 212 */     if (itemsObject == null && boundType != null && boundType.isEnum()) {
/* 213 */       itemsObject = boundType.getEnumConstants();
/*     */     }
/*     */     
/* 216 */     if (itemsObject == null) {
/* 217 */       throw new IllegalArgumentException("Attribute 'items' is required and must be a Collection, an Array or a Map");
/*     */     }
/*     */     
/* 220 */     if (itemsObject instanceof Object[]) { Object[] itemsArray = (Object[])itemsObject;
/* 221 */       for (int itemIndex = 0; itemIndex < itemsArray.length; itemIndex++) {
/* 222 */         Object item = itemsArray[itemIndex];
/* 223 */         writeObjectEntry(tagWriter, valueProperty, labelProperty, item, itemIndex);
/*     */       }
/*     */        }
/* 226 */     else if (itemsObject instanceof Collection) { Collection<?> optionCollection = (Collection)itemsObject;
/* 227 */       int itemIndex = 0;
/* 228 */       for (Iterator<?> it = optionCollection.iterator(); it.hasNext(); itemIndex++) {
/* 229 */         Object item = it.next();
/* 230 */         writeObjectEntry(tagWriter, valueProperty, labelProperty, item, itemIndex);
/*     */       }
/*     */        }
/* 233 */     else if (itemsObject instanceof Map) { Map<?, ?> optionMap = (Map<?, ?>)itemsObject;
/* 234 */       int itemIndex = 0;
/* 235 */       for (Iterator<Map.Entry> it = optionMap.entrySet().iterator(); it.hasNext(); itemIndex++) {
/* 236 */         Map.Entry<?, ?> entry = it.next();
/* 237 */         writeMapEntry(tagWriter, valueProperty, labelProperty, entry, itemIndex);
/*     */       }  }
/*     */     else
/*     */     
/* 241 */     { throw new IllegalArgumentException("Attribute 'items' must be an array, a Collection or a Map"); }
/*     */ 
/*     */     
/* 244 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeObjectEntry(TagWriter tagWriter, @Nullable String valueProperty, @Nullable String labelProperty, Object item, int itemIndex) throws JspException {
/*     */     Object renderValue;
/* 250 */     BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(item);
/*     */     
/* 252 */     if (valueProperty != null)
/* 253 */     { renderValue = wrapper.getPropertyValue(valueProperty); }
/*     */     
/* 255 */     else if (item instanceof Enum) { Enum<?> enumValue = (Enum)item;
/* 256 */       renderValue = enumValue.name(); }
/*     */     else
/*     */     
/* 259 */     { renderValue = item; }
/*     */     
/* 261 */     Object renderLabel = (labelProperty != null) ? wrapper.getPropertyValue(labelProperty) : item;
/* 262 */     writeElementTag(tagWriter, item, renderValue, renderLabel, itemIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeMapEntry(TagWriter tagWriter, @Nullable String valueProperty, @Nullable String labelProperty, Map.Entry<?, ?> entry, int itemIndex) throws JspException {
/* 268 */     Object mapKey = entry.getKey();
/* 269 */     Object mapValue = entry.getValue();
/* 270 */     BeanWrapper mapKeyWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mapKey);
/* 271 */     BeanWrapper mapValueWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mapValue);
/*     */     
/* 273 */     Object renderValue = (valueProperty != null) ? mapKeyWrapper.getPropertyValue(valueProperty) : mapKey.toString();
/*     */     
/* 275 */     Object renderLabel = (labelProperty != null) ? mapValueWrapper.getPropertyValue(labelProperty) : mapValue.toString();
/* 276 */     writeElementTag(tagWriter, mapKey, renderValue, renderLabel, itemIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeElementTag(TagWriter tagWriter, Object item, @Nullable Object value, @Nullable Object label, int itemIndex) throws JspException {
/* 282 */     tagWriter.startTag(getElement());
/* 283 */     if (itemIndex > 0) {
/* 284 */       Object resolvedDelimiter = evaluate("delimiter", getDelimiter());
/* 285 */       if (resolvedDelimiter != null) {
/* 286 */         tagWriter.appendValue(resolvedDelimiter.toString());
/*     */       }
/*     */     } 
/* 289 */     tagWriter.startTag("input");
/* 290 */     String id = resolveId();
/* 291 */     Assert.state((id != null), "Attribute 'id' is required");
/* 292 */     writeOptionalAttribute(tagWriter, "id", id);
/* 293 */     writeOptionalAttribute(tagWriter, "name", getName());
/* 294 */     writeOptionalAttributes(tagWriter);
/* 295 */     tagWriter.writeAttribute("type", getInputType());
/* 296 */     renderFromValue(item, value, tagWriter);
/* 297 */     tagWriter.endTag();
/* 298 */     tagWriter.startTag("label");
/* 299 */     tagWriter.writeAttribute("for", id);
/* 300 */     tagWriter.appendValue(convertToDisplayString(label));
/* 301 */     tagWriter.endTag();
/* 302 */     tagWriter.endTag();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\tags\form\AbstractMultiCheckedElementTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */