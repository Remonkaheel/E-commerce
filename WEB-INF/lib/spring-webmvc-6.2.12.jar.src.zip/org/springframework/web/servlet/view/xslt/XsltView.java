/*     */ package org.springframework.web.servlet.view.xslt;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.TransformerFactoryConfigurationError;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.SimpleTransformErrorListener;
/*     */ import org.springframework.util.xml.TransformerUtils;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XsltView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*     */   @Nullable
/*     */   private Class<? extends TransformerFactory> transformerFactoryClass;
/*     */   @Nullable
/*     */   private String sourceKey;
/*     */   @Nullable
/*     */   private URIResolver uriResolver;
/*  89 */   private ErrorListener errorListener = (ErrorListener)new SimpleTransformErrorListener(this.logger);
/*     */ 
/*     */   
/*     */   private boolean indent = true;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Properties outputProperties;
/*     */ 
/*     */   
/*     */   private boolean cacheTemplates = true;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TransformerFactory transformerFactory;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Templates cachedTemplates;
/*     */ 
/*     */   
/*     */   public void setTransformerFactoryClass(Class<? extends TransformerFactory> transformerFactoryClass) {
/* 111 */     this.transformerFactoryClass = transformerFactoryClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceKey(String sourceKey) {
/* 124 */     this.sourceKey = sourceKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUriResolver(URIResolver uriResolver) {
/* 132 */     this.uriResolver = uriResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorListener(@Nullable ErrorListener errorListener) {
/* 145 */     this.errorListener = (errorListener != null) ? errorListener : (ErrorListener)new SimpleTransformErrorListener(this.logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndent(boolean indent) {
/* 156 */     this.indent = indent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputProperties(Properties outputProperties) {
/* 166 */     this.outputProperties = outputProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheTemplates(boolean cacheTemplates) {
/* 175 */     this.cacheTemplates = cacheTemplates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initApplicationContext() throws BeansException {
/* 184 */     this.transformerFactory = newTransformerFactory(this.transformerFactoryClass);
/* 185 */     this.transformerFactory.setErrorListener(this.errorListener);
/* 186 */     if (this.uriResolver != null) {
/* 187 */       this.transformerFactory.setURIResolver(this.uriResolver);
/*     */     }
/* 189 */     if (this.cacheTemplates) {
/* 190 */       this.cachedTemplates = loadTemplates();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TransformerFactory newTransformerFactory(@Nullable Class<? extends TransformerFactory> transformerFactoryClass) {
/* 210 */     if (transformerFactoryClass != null) {
/*     */       try {
/* 212 */         return ReflectionUtils.accessibleConstructor(transformerFactoryClass, new Class[0]).newInstance(new Object[0]);
/*     */       }
/* 214 */       catch (Exception ex) {
/* 215 */         throw new TransformerFactoryConfigurationError(ex, "Could not instantiate TransformerFactory");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     return TransformerFactory.newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TransformerFactory getTransformerFactory() {
/* 231 */     Assert.state((this.transformerFactory != null), "No TransformerFactory available");
/* 232 */     return this.transformerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 241 */     Templates templates = this.cachedTemplates;
/* 242 */     if (templates == null) {
/* 243 */       templates = loadTemplates();
/*     */     }
/*     */     
/* 246 */     Transformer transformer = createTransformer(templates);
/* 247 */     configureTransformer(model, response, transformer);
/* 248 */     configureResponse(model, response, transformer);
/* 249 */     Source source = null;
/*     */     try {
/* 251 */       source = locateSource(model);
/* 252 */       if (source == null) {
/* 253 */         throw new IllegalArgumentException("Unable to locate Source object in model: " + String.valueOf(model));
/*     */       }
/* 255 */       transformer.transform(source, createResult(response));
/*     */     } finally {
/*     */       
/* 258 */       closeSourceIfNecessary(source);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Result createResult(HttpServletResponse response) throws Exception {
/* 271 */     return new StreamResult((OutputStream)response.getOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Source locateSource(Map<String, Object> model) throws Exception {
/* 288 */     if (this.sourceKey != null) {
/* 289 */       return convertSource(model.get(this.sourceKey));
/*     */     }
/* 291 */     Object source = CollectionUtils.findValueOfType(model.values(), getSourceTypes());
/* 292 */     return (source != null) ? convertSource(source) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?>[] getSourceTypes() {
/* 303 */     return new Class[] { Source.class, Document.class, Node.class, Reader.class, InputStream.class, Resource.class };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Source convertSource(@Nullable Object sourceObject) throws Exception {
/* 314 */     if (sourceObject instanceof Source) { Source source = (Source)sourceObject;
/* 315 */       return source; }
/*     */     
/* 317 */     if (sourceObject instanceof Document) { Document document = (Document)sourceObject;
/* 318 */       return new DOMSource(document.getDocumentElement()); }
/*     */     
/* 320 */     if (sourceObject instanceof Node) { Node node = (Node)sourceObject;
/* 321 */       return new DOMSource(node); }
/*     */     
/* 323 */     if (sourceObject instanceof Reader) { Reader reader = (Reader)sourceObject;
/* 324 */       return new StreamSource(reader); }
/*     */     
/* 326 */     if (sourceObject instanceof InputStream) { InputStream inputStream = (InputStream)sourceObject;
/* 327 */       return new StreamSource(inputStream); }
/*     */     
/* 329 */     if (sourceObject instanceof Resource) { Resource resource = (Resource)sourceObject;
/* 330 */       return new StreamSource(resource.getInputStream(), resource.getURI().toASCIIString()); }
/*     */ 
/*     */     
/* 333 */     throw new IllegalArgumentException("Value '" + String.valueOf(sourceObject) + "' cannot be converted to XSLT Source");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureTransformer(Map<String, Object> model, HttpServletResponse response, Transformer transformer) {
/* 354 */     copyModelParameters(model, transformer);
/* 355 */     copyOutputProperties(transformer);
/* 356 */     configureIndentation(transformer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void configureIndentation(Transformer transformer) {
/* 366 */     if (this.indent) {
/* 367 */       TransformerUtils.enableIndenting(transformer);
/*     */     } else {
/*     */       
/* 370 */       TransformerUtils.disableIndenting(transformer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void copyOutputProperties(Transformer transformer) {
/* 381 */     if (this.outputProperties != null) {
/* 382 */       Enumeration<?> en = this.outputProperties.propertyNames();
/* 383 */       while (en.hasMoreElements()) {
/* 384 */         String name = (String)en.nextElement();
/* 385 */         transformer.setOutputProperty(name, this.outputProperties.getProperty(name));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void copyModelParameters(Map<String, Object> model, Transformer transformer) {
/* 398 */     Objects.requireNonNull(transformer); model.forEach(transformer::setParameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureResponse(Map<String, Object> model, HttpServletResponse response, Transformer transformer) {
/* 413 */     String contentType = getContentType();
/* 414 */     String mediaType = transformer.getOutputProperty("media-type");
/* 415 */     String encoding = transformer.getOutputProperty("encoding");
/* 416 */     if (StringUtils.hasText(mediaType)) {
/* 417 */       contentType = mediaType;
/*     */     }
/* 419 */     if (StringUtils.hasText(encoding))
/*     */     {
/* 421 */       if (contentType != null && !contentType.toLowerCase(Locale.ROOT).contains(";charset=")) {
/* 422 */         contentType = contentType + ";charset=" + contentType;
/*     */       }
/*     */     }
/* 425 */     response.setContentType(contentType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Templates loadTemplates() throws ApplicationContextException {
/* 432 */     Source stylesheetSource = getStylesheetSource();
/*     */     try {
/* 434 */       return getTransformerFactory().newTemplates(stylesheetSource);
/*     */     }
/* 436 */     catch (TransformerConfigurationException ex) {
/* 437 */       throw new ApplicationContextException("Cannot load stylesheet from '" + getUrl() + "'", ex);
/*     */     } finally {
/*     */       
/* 440 */       closeSourceIfNecessary(stylesheetSource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Transformer createTransformer(Templates templates) throws TransformerConfigurationException {
/* 453 */     Transformer transformer = templates.newTransformer();
/* 454 */     if (this.uriResolver != null) {
/* 455 */       transformer.setURIResolver(this.uriResolver);
/*     */     }
/* 457 */     return transformer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Source getStylesheetSource() {
/* 465 */     String url = getUrl();
/* 466 */     Assert.state((url != null), "'url' not set");
/*     */     
/* 468 */     if (this.logger.isDebugEnabled()) {
/* 469 */       this.logger.debug("Applying stylesheet [" + url + "]");
/*     */     }
/*     */     try {
/* 472 */       Resource resource = obtainApplicationContext().getResource(url);
/* 473 */       return new StreamSource(resource.getInputStream(), resource.getURI().toASCIIString());
/*     */     }
/* 475 */     catch (IOException ex) {
/* 476 */       throw new ApplicationContextException("Cannot load XSLT stylesheet from '" + url + "'", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeSourceIfNecessary(@Nullable Source source) {
/* 486 */     if (source instanceof StreamSource) { StreamSource streamSource = (StreamSource)source;
/* 487 */       if (streamSource.getReader() != null) {
/*     */         try {
/* 489 */           streamSource.getReader().close();
/*     */         }
/* 491 */         catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 495 */       if (streamSource.getInputStream() != null)
/*     */         try {
/* 497 */           streamSource.getInputStream().close();
/*     */         }
/* 499 */         catch (IOException iOException) {}  }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\xslt\XsltView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */