package org.springframework.web.servlet.view;

import java.util.Locale;
import org.springframework.web.servlet.View;

@FunctionalInterface
public interface CacheFilter {
  boolean filter(View paramView, String paramString, Locale paramLocale);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\AbstractCachingViewResolver$CacheFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */