/*     */ package org.springframework.web.servlet.view.freemarker;
/*     */ 
/*     */ import freemarker.cache.ClassTemplateLoader;
/*     */ import freemarker.cache.TemplateLoader;
/*     */ import freemarker.ext.jakarta.jsp.TaglibFactory;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.TemplateException;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FreeMarkerConfigurer
/*     */   extends FreeMarkerConfigurationFactory
/*     */   implements FreeMarkerConfig, InitializingBean, ResourceLoaderAware, ServletContextAware
/*     */ {
/*     */   @Nullable
/*     */   private Configuration configuration;
/*     */   @Nullable
/*     */   private TaglibFactory taglibFactory;
/*     */   
/*     */   public void setConfiguration(Configuration configuration) {
/*  98 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/* 106 */     this.taglibFactory = new TaglibFactory(servletContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws IOException, TemplateException {
/* 121 */     if (this.configuration == null) {
/* 122 */       this.configuration = createConfiguration();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessTemplateLoaders(List<TemplateLoader> templateLoaders) {
/* 132 */     templateLoaders.add(new ClassTemplateLoader(FreeMarkerConfigurer.class, ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration getConfiguration() {
/* 141 */     Assert.state((this.configuration != null), "No Configuration available");
/* 142 */     return this.configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaglibFactory getTaglibFactory() {
/* 150 */     Assert.state((this.taglibFactory != null), "No TaglibFactory available");
/* 151 */     return this.taglibFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */