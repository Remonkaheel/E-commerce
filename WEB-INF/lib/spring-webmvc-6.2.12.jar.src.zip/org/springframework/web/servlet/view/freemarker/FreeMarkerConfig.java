package org.springframework.web.servlet.view.freemarker;

import freemarker.ext.jakarta.jsp.TaglibFactory;
import freemarker.template.Configuration;

public interface FreeMarkerConfig {
  Configuration getConfiguration();
  
  TaglibFactory getTaglibFactory();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */