/*     */ package org.springframework.web.servlet.view.xml;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonView;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.dataformat.xml.XmlMapper;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.view.json.AbstractJackson2View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingJackson2XmlView
/*     */   extends AbstractJackson2View
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/xml";
/*     */   @Nullable
/*     */   private String modelKey;
/*     */   
/*     */   public MappingJackson2XmlView() {
/*  63 */     super(Jackson2ObjectMapperBuilder.xml().build(), "application/xml");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingJackson2XmlView(XmlMapper xmlMapper) {
/*  72 */     super((ObjectMapper)xmlMapper, "application/xml");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModelKey(String modelKey) {
/*  78 */     this.modelKey = modelKey;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object filterModel(Map<String, Object> model) {
/*  83 */     Object value = null;
/*  84 */     if (this.modelKey != null) {
/*  85 */       value = model.get(this.modelKey);
/*  86 */       if (value == null) {
/*  87 */         throw new IllegalStateException("Model contains no object with key [" + this.modelKey + "]");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  92 */       for (Map.Entry<String, Object> entry : model.entrySet()) {
/*  93 */         if (!(entry.getValue() instanceof org.springframework.validation.BindingResult) && !((String)entry.getKey()).equals(JsonView.class.getName())) {
/*  94 */           if (value != null) {
/*  95 */             throw new IllegalStateException("Model contains more than one object to render, only one is supported");
/*     */           }
/*  97 */           value = entry.getValue();
/*     */         } 
/*     */       } 
/*     */     } 
/* 101 */     Assert.state((value != null), "Model contains no object to render");
/* 102 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\xml\MappingJackson2XmlView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */