/*     */ package org.springframework.web.servlet.view.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonView;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingJackson2JsonView
/*     */   extends AbstractJackson2View
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/json";
/*     */   @Nullable
/*     */   private String jsonPrefix;
/*     */   @Nullable
/*     */   private Set<String> modelKeys;
/*     */   private boolean extractValueFromSingleKeyModel = false;
/*     */   
/*     */   public MappingJackson2JsonView() {
/*  75 */     super(Jackson2ObjectMapperBuilder.json().build(), "application/json");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingJackson2JsonView(ObjectMapper objectMapper) {
/*  84 */     super(objectMapper, "application/json");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJsonPrefix(String jsonPrefix) {
/*  94 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefixJson(boolean prefixJson) {
/* 106 */     this.jsonPrefix = prefixJson ? ")]}', " : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setModelKey(String modelKey) {
/* 111 */     this.modelKeys = Collections.singleton(modelKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModelKeys(@Nullable Set<String> modelKeys) {
/* 119 */     this.modelKeys = modelKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Set<String> getModelKeys() {
/* 127 */     return this.modelKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtractValueFromSingleKeyModel(boolean extractValueFromSingleKeyModel) {
/* 139 */     this.extractValueFromSingleKeyModel = extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object filterModel(Map<String, Object> model) {
/* 152 */     Map<String, Object> result = CollectionUtils.newHashMap(model.size());
/* 153 */     Set<String> modelKeys = !CollectionUtils.isEmpty(this.modelKeys) ? this.modelKeys : model.keySet();
/* 154 */     model.forEach((clazz, value) -> {
/*     */           if (!(value instanceof org.springframework.validation.BindingResult) && modelKeys.contains(clazz) && !clazz.equals(JsonView.class.getName()) && !clazz.equals(FilterProvider.class.getName())) {
/*     */             result.put(clazz, value);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 161 */     return (this.extractValueFromSingleKeyModel && result.size() == 1) ? result.values().iterator().next() : result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writePrefix(JsonGenerator generator, Object object) throws IOException {
/* 166 */     if (this.jsonPrefix != null)
/* 167 */       generator.writeRaw(this.jsonPrefix); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\json\MappingJackson2JsonView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */