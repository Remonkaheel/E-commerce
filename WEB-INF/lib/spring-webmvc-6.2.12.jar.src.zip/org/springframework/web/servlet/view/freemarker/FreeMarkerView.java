/*     */ package org.springframework.web.servlet.view.freemarker;
/*     */ 
/*     */ import freemarker.core.Environment;
/*     */ import freemarker.core.ParseException;
/*     */ import freemarker.ext.jakarta.jsp.TaglibFactory;
/*     */ import freemarker.ext.jakarta.servlet.AllHttpScopesHashModel;
/*     */ import freemarker.ext.jakarta.servlet.HttpRequestHashModel;
/*     */ import freemarker.ext.jakarta.servlet.HttpRequestParametersHashModel;
/*     */ import freemarker.ext.jakarta.servlet.HttpSessionHashModel;
/*     */ import freemarker.ext.jakarta.servlet.ServletContextHashModel;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.DefaultObjectWrapperBuilder;
/*     */ import freemarker.template.ObjectWrapper;
/*     */ import freemarker.template.SimpleHash;
/*     */ import freemarker.template.Template;
/*     */ import freemarker.template.TemplateException;
/*     */ import jakarta.servlet.GenericServlet;
/*     */ import jakarta.servlet.ServletConfig;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FreeMarkerView
/*     */   extends AbstractTemplateView
/*     */ {
/*     */   @Nullable
/*     */   private String encoding;
/*     */   @Nullable
/*     */   private Configuration configuration;
/*     */   @Nullable
/*     */   private TaglibFactory taglibFactory;
/*     */   @Nullable
/*     */   private ServletContextHashModel servletContextHashModel;
/*     */   
/*     */   public void setEncoding(@Nullable String encoding) {
/* 144 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(@Nullable Charset charset) {
/* 155 */     this.encoding = (charset != null) ? charset.name() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getEncoding() {
/* 167 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfiguration(@Nullable Configuration configuration) {
/* 180 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Configuration getConfiguration() {
/* 188 */     return this.configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configuration obtainConfiguration() {
/* 198 */     Configuration configuration = getConfiguration();
/* 199 */     Assert.state((configuration != null), "No Configuration set");
/* 200 */     return configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initServletContext(ServletContext servletContext) throws BeansException {
/* 214 */     if (getConfiguration() != null) {
/* 215 */       this.taglibFactory = new TaglibFactory(servletContext);
/*     */     } else {
/*     */       
/* 218 */       FreeMarkerConfig config = autodetectConfiguration();
/* 219 */       setConfiguration(config.getConfiguration());
/* 220 */       this.taglibFactory = config.getTaglibFactory();
/*     */     } 
/*     */     
/* 223 */     GenericServlet servlet = new GenericServletAdapter();
/*     */     try {
/* 225 */       servlet.init(new DelegatingServletConfig());
/*     */     }
/* 227 */     catch (ServletException ex) {
/* 228 */       throw new BeanInitializationException("Initialization of GenericServlet adapter failed", ex);
/*     */     } 
/* 230 */     this.servletContextHashModel = new ServletContextHashModel(servlet, getObjectWrapper());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FreeMarkerConfig autodetectConfiguration() throws BeansException {
/*     */     try {
/* 242 */       return (FreeMarkerConfig)BeanFactoryUtils.beanOfTypeIncludingAncestors((ListableBeanFactory)
/* 243 */           obtainApplicationContext(), FreeMarkerConfig.class, true, false);
/*     */     }
/* 245 */     catch (NoSuchBeanDefinitionException ex) {
/* 246 */       throw new ApplicationContextException("Must define a single FreeMarkerConfig bean in this web application context (may be inherited): FreeMarkerConfigurer is the usual implementation. This bean may be given any name.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectWrapper getObjectWrapper() {
/* 259 */     ObjectWrapper ow = obtainConfiguration().getObjectWrapper();
/* 260 */     return (ow != null) ? ow : 
/* 261 */       (ObjectWrapper)(new DefaultObjectWrapperBuilder(Configuration.DEFAULT_INCOMPATIBLE_IMPROVEMENTS)).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkResource(Locale locale) throws Exception {
/* 271 */     String url = getUrl();
/* 272 */     Assert.state((url != null), "'url' not set");
/*     */ 
/*     */     
/*     */     try {
/* 276 */       getTemplate(url, locale);
/* 277 */       return true;
/*     */     }
/* 279 */     catch (FileNotFoundException ex) {
/*     */       
/* 281 */       return false;
/*     */     }
/* 283 */     catch (ParseException ex) {
/* 284 */       throw new ApplicationContextException("Failed to parse [" + url + "]", ex);
/*     */     }
/* 286 */     catch (IOException ex) {
/* 287 */       throw new ApplicationContextException("Failed to load [" + url + "]", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 301 */     exposeHelpers(model, request);
/* 302 */     doRender(model, request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void exposeHelpers(Map<String, Object> model, HttpServletRequest request) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doRender(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 345 */     exposeModelAsRequestAttributes(model, request);
/*     */     
/* 347 */     SimpleHash fmModel = buildTemplateModel(model, request, response);
/*     */ 
/*     */     
/* 350 */     Locale locale = RequestContextUtils.getLocale(request);
/* 351 */     processTemplate(getTemplate(locale), fmModel, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimpleHash buildTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) {
/* 365 */     AllHttpScopesHashModel fmModel = new AllHttpScopesHashModel(getObjectWrapper(), getServletContext(), request);
/* 366 */     fmModel.put("JspTaglibs", this.taglibFactory);
/* 367 */     fmModel.put("Application", this.servletContextHashModel);
/* 368 */     fmModel.put("Session", buildSessionModel(request, response));
/* 369 */     fmModel.put("Request", new HttpRequestHashModel(request, response, getObjectWrapper()));
/* 370 */     fmModel.put("RequestParameters", new HttpRequestParametersHashModel(request));
/* 371 */     fmModel.putAll(model);
/* 372 */     return (SimpleHash)fmModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpSessionHashModel buildSessionModel(HttpServletRequest request, HttpServletResponse response) {
/* 383 */     HttpSession session = request.getSession(false);
/* 384 */     if (session != null) {
/* 385 */       return new HttpSessionHashModel(session, getObjectWrapper());
/*     */     }
/*     */     
/* 388 */     return new HttpSessionHashModel(null, request, response, getObjectWrapper());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Template getTemplate(Locale locale) throws IOException {
/* 404 */     String url = getUrl();
/* 405 */     Assert.state((url != null), "'url' not set");
/* 406 */     return getTemplate(url, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Template getTemplate(String name, Locale locale) throws IOException {
/* 422 */     return (getEncoding() != null) ? 
/* 423 */       obtainConfiguration().getTemplate(name, locale, getEncoding()) : 
/* 424 */       obtainConfiguration().getTemplate(name, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processTemplate(Template template, SimpleHash model, HttpServletResponse response) throws IOException, TemplateException {
/* 445 */     Environment env = template.createProcessingEnvironment(model, response.getWriter());
/* 446 */     env.setOutputEncoding(response.getCharacterEncoding());
/* 447 */     env.process();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class GenericServletAdapter
/*     */     extends GenericServlet
/*     */   {
/*     */     public void service(ServletRequest servletRequest, ServletResponse servletResponse) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class DelegatingServletConfig
/*     */     implements ServletConfig
/*     */   {
/*     */     @Nullable
/*     */     public String getServletName() {
/* 474 */       return FreeMarkerView.this.getBeanName();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ServletContext getServletContext() {
/* 480 */       return FreeMarkerView.this.getServletContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getInitParameter(String paramName) {
/* 486 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getInitParameterNames() {
/* 491 */       return Collections.enumeration(Collections.emptySet());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */