/*     */ package org.springframework.web.servlet.view.script;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.script.Invocable;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import javax.script.SimpleBindings;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.scripting.support.StandardScriptEvalException;
/*     */ import org.springframework.scripting.support.StandardScriptUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptTemplateView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/html";
/*  82 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_RESOURCE_LOADER_PATH = "classpath:";
/*     */   
/*  87 */   private static final ThreadLocal<Map<Object, ScriptEngine>> enginesHolder = (ThreadLocal<Map<Object, ScriptEngine>>)new NamedThreadLocal("ScriptTemplateView engines");
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ScriptEngine engine;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Supplier<ScriptEngine> engineSupplier;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String engineName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Boolean sharedEngine;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String[] scripts;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String renderObject;
/*     */   
/*     */   @Nullable
/*     */   private String renderFunction;
/*     */   
/*     */   @Nullable
/*     */   private Charset charset;
/*     */   
/*     */   @Nullable
/*     */   private String[] resourceLoaderPaths;
/*     */   
/*     */   @Nullable
/*     */   private volatile ScriptEngineManager scriptEngineManager;
/*     */ 
/*     */   
/*     */   public ScriptTemplateView() {
/* 127 */     setContentType(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptTemplateView(String url) {
/* 135 */     super(url);
/* 136 */     setContentType(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEngine(ScriptEngine engine) {
/* 144 */     this.engine = engine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEngineSupplier(Supplier<ScriptEngine> engineSupplier) {
/* 152 */     this.engineSupplier = engineSupplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEngineName(String engineName) {
/* 159 */     this.engineName = engineName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSharedEngine(Boolean sharedEngine) {
/* 166 */     this.sharedEngine = sharedEngine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScripts(String... scripts) {
/* 173 */     this.scripts = scripts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderObject(String renderObject) {
/* 180 */     this.renderObject = renderObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderFunction(String functionName) {
/* 187 */     this.renderFunction = functionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(Charset charset) {
/* 194 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLoaderPath(String resourceLoaderPath) {
/* 201 */     String[] paths = StringUtils.commaDelimitedListToStringArray(resourceLoaderPath);
/* 202 */     this.resourceLoaderPaths = new String[paths.length + 1];
/* 203 */     this.resourceLoaderPaths[0] = "";
/* 204 */     for (int i = 0; i < paths.length; i++) {
/* 205 */       String path = paths[i];
/* 206 */       if (!path.endsWith("/") && !path.endsWith(":")) {
/* 207 */         path = path + "/";
/*     */       }
/* 209 */       this.resourceLoaderPaths[i + 1] = path;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initApplicationContext(ApplicationContext context) {
/* 216 */     super.initApplicationContext(context);
/*     */     
/* 218 */     ScriptTemplateConfig viewConfig = autodetectViewConfig();
/* 219 */     if (this.engine == null && viewConfig.getEngine() != null) {
/* 220 */       this.engine = viewConfig.getEngine();
/*     */     }
/* 222 */     if (this.engineSupplier == null && viewConfig.getEngineSupplier() != null) {
/* 223 */       this.engineSupplier = viewConfig.getEngineSupplier();
/*     */     }
/* 225 */     if (this.engineName == null && viewConfig.getEngineName() != null) {
/* 226 */       this.engineName = viewConfig.getEngineName();
/*     */     }
/* 228 */     if (this.scripts == null && viewConfig.getScripts() != null) {
/* 229 */       this.scripts = viewConfig.getScripts();
/*     */     }
/* 231 */     if (this.renderObject == null && viewConfig.getRenderObject() != null) {
/* 232 */       this.renderObject = viewConfig.getRenderObject();
/*     */     }
/* 234 */     if (this.renderFunction == null && viewConfig.getRenderFunction() != null) {
/* 235 */       this.renderFunction = viewConfig.getRenderFunction();
/*     */     }
/* 237 */     if (getContentType() == null) {
/* 238 */       setContentType((viewConfig.getContentType() != null) ? viewConfig.getContentType() : "text/html");
/*     */     }
/* 240 */     if (this.charset == null) {
/* 241 */       this.charset = (viewConfig.getCharset() != null) ? viewConfig.getCharset() : DEFAULT_CHARSET;
/*     */     }
/* 243 */     if (this.resourceLoaderPaths == null) {
/* 244 */       String resourceLoaderPath = viewConfig.getResourceLoaderPath();
/* 245 */       setResourceLoaderPath((resourceLoaderPath != null) ? resourceLoaderPath : "classpath:");
/*     */     } 
/* 247 */     if (this.sharedEngine == null && viewConfig.isSharedEngine() != null) {
/* 248 */       this.sharedEngine = viewConfig.isSharedEngine();
/*     */     }
/*     */     
/* 251 */     int engineCount = 0;
/* 252 */     if (this.engine != null) {
/* 253 */       engineCount++;
/*     */     }
/* 255 */     if (this.engineSupplier != null) {
/* 256 */       engineCount++;
/*     */     }
/* 258 */     if (this.engineName != null) {
/* 259 */       engineCount++;
/*     */     }
/* 261 */     Assert.isTrue((engineCount == 1), "You should define either 'engine', 'engineSupplier', or 'engineName'.");
/*     */ 
/*     */     
/* 264 */     if (Boolean.FALSE.equals(this.sharedEngine)) {
/* 265 */       Assert.isTrue((this.engine == null), "When 'sharedEngine' is set to false, you should specify the script engine using 'engineName' or 'engineSupplier', not 'engine'.");
/*     */ 
/*     */     
/*     */     }
/* 269 */     else if (this.engine != null) {
/* 270 */       loadScripts(this.engine);
/*     */     }
/* 272 */     else if (this.engineName != null) {
/* 273 */       setEngine(createEngineFromName(this.engineName));
/*     */     } else {
/*     */       
/* 276 */       setEngine(createEngineFromSupplier());
/*     */     } 
/*     */     
/* 279 */     if (this.renderFunction != null && this.engine != null) {
/* 280 */       Assert.isInstanceOf(Invocable.class, this.engine, "ScriptEngine must implement Invocable when 'renderFunction' is specified");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected ScriptEngine getEngine() {
/* 286 */     if (Boolean.FALSE.equals(this.sharedEngine)) {
/* 287 */       Map<Object, ScriptEngine> engines = enginesHolder.get();
/* 288 */       if (engines == null) {
/* 289 */         engines = new HashMap<>(4);
/* 290 */         enginesHolder.set(engines);
/*     */       } 
/* 292 */       String name = (this.engineName != null) ? this.engineName : "";
/* 293 */       Object engineKey = !ObjectUtils.isEmpty((Object[])this.scripts) ? new EngineKey(name, this.scripts) : name;
/* 294 */       ScriptEngine engine = engines.get(engineKey);
/* 295 */       if (engine == null) {
/* 296 */         if (this.engineName != null) {
/* 297 */           engine = createEngineFromName(this.engineName);
/*     */         } else {
/*     */           
/* 300 */           engine = createEngineFromSupplier();
/*     */         } 
/* 302 */         engines.put(engineKey, engine);
/*     */       } 
/* 304 */       return engine;
/*     */     } 
/*     */ 
/*     */     
/* 308 */     Assert.state((this.engine != null), "No shared engine available");
/* 309 */     return this.engine;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ScriptEngine createEngineFromName(String engineName) {
/* 314 */     ScriptEngineManager scriptEngineManager = this.scriptEngineManager;
/* 315 */     if (scriptEngineManager == null) {
/* 316 */       scriptEngineManager = new ScriptEngineManager(obtainApplicationContext().getClassLoader());
/* 317 */       this.scriptEngineManager = scriptEngineManager;
/*     */     } 
/*     */     
/* 320 */     ScriptEngine engine = StandardScriptUtils.retrieveEngineByName(scriptEngineManager, engineName);
/* 321 */     loadScripts(engine);
/* 322 */     return engine;
/*     */   }
/*     */   
/*     */   private ScriptEngine createEngineFromSupplier() {
/* 326 */     Assert.state((this.engineSupplier != null), "No engine supplier available");
/* 327 */     ScriptEngine engine = this.engineSupplier.get();
/* 328 */     if (this.renderFunction != null) {
/* 329 */       Assert.isInstanceOf(Invocable.class, engine, "ScriptEngine must implement Invocable when 'renderFunction' is specified");
/*     */     }
/*     */     
/* 332 */     loadScripts(engine);
/* 333 */     return engine;
/*     */   }
/*     */   
/*     */   protected void loadScripts(ScriptEngine engine) {
/* 337 */     if (!ObjectUtils.isEmpty((Object[])this.scripts)) {
/* 338 */       for (String script : this.scripts) {
/* 339 */         Resource resource = getResource(script);
/* 340 */         if (resource == null) {
/* 341 */           throw new IllegalStateException("Script resource [" + script + "] not found");
/*     */         }
/*     */         try {
/* 344 */           engine.eval(new InputStreamReader(resource.getInputStream()));
/*     */         }
/* 346 */         catch (Throwable ex) {
/* 347 */           throw new IllegalStateException("Failed to evaluate script [" + script + "]", ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Resource getResource(String location) {
/* 355 */     if (this.resourceLoaderPaths != null) {
/* 356 */       for (String path : this.resourceLoaderPaths) {
/* 357 */         Resource resource = obtainApplicationContext().getResource(path + path);
/* 358 */         if (resource.exists()) {
/* 359 */           return resource;
/*     */         }
/*     */       } 
/*     */     }
/* 363 */     return null;
/*     */   }
/*     */   
/*     */   protected ScriptTemplateConfig autodetectViewConfig() throws BeansException {
/*     */     try {
/* 368 */       return (ScriptTemplateConfig)BeanFactoryUtils.beanOfTypeIncludingAncestors((ListableBeanFactory)
/* 369 */           obtainApplicationContext(), ScriptTemplateConfig.class, true, false);
/*     */     }
/* 371 */     catch (NoSuchBeanDefinitionException ex) {
/* 372 */       throw new ApplicationContextException("Expected a single ScriptTemplateConfig bean in the current Servlet web application context or the parent root context: ScriptTemplateConfigurer is the usual implementation. This bean may have any name.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkResource(Locale locale) throws Exception {
/* 381 */     String url = getUrl();
/* 382 */     Assert.state((url != null), "'url' not set");
/* 383 */     return (getResource(url) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response) {
/* 388 */     super.prepareResponse(request, response);
/*     */     
/* 390 */     setResponseContentType(request, response);
/* 391 */     if (this.charset != null) {
/* 392 */       response.setCharacterEncoding(this.charset.name());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/*     */       Object html;
/* 401 */       ScriptEngine engine = getEngine();
/* 402 */       String url = getUrl();
/* 403 */       Assert.state((url != null), "'url' not set");
/* 404 */       String template = getTemplate(url);
/*     */       
/* 406 */       Function<String, String> templateLoader = path -> {
/*     */           
/*     */           try {
/*     */             return getTemplate(path);
/* 410 */           } catch (IOException ex) {
/*     */             throw new IllegalStateException(ex);
/*     */           } 
/*     */         };
/*     */       
/* 415 */       Locale locale = RequestContextUtils.getLocale(request);
/* 416 */       RenderingContext context = new RenderingContext(obtainApplicationContext(), locale, templateLoader, url);
/*     */ 
/*     */       
/* 419 */       if (this.renderFunction == null) {
/* 420 */         SimpleBindings bindings = new SimpleBindings();
/* 421 */         bindings.putAll(model);
/* 422 */         model.put("renderingContext", context);
/* 423 */         html = engine.eval(template, bindings);
/*     */       }
/* 425 */       else if (this.renderObject != null) {
/* 426 */         Object thiz = engine.eval(this.renderObject);
/* 427 */         html = ((Invocable)engine).invokeMethod(thiz, this.renderFunction, new Object[] { template, model, context });
/*     */       } else {
/*     */         
/* 430 */         html = ((Invocable)engine).invokeFunction(this.renderFunction, new Object[] { template, model, context });
/*     */       } 
/*     */       
/* 433 */       response.getWriter().write(String.valueOf(html));
/*     */     }
/* 435 */     catch (ScriptException ex) {
/* 436 */       throw new ServletException("Failed to render script template", new StandardScriptEvalException(ex));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String getTemplate(String path) throws IOException {
/* 441 */     Resource resource = getResource(path);
/* 442 */     if (resource == null) {
/* 443 */       throw new IllegalStateException("Template resource [" + path + "] not found");
/*     */     }
/*     */ 
/*     */     
/* 447 */     InputStreamReader reader = (this.charset != null) ? new InputStreamReader(resource.getInputStream(), this.charset) : new InputStreamReader(resource.getInputStream());
/* 448 */     return FileCopyUtils.copyToString(reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EngineKey
/*     */   {
/*     */     private final String engineName;
/*     */ 
/*     */     
/*     */     private final String[] scripts;
/*     */ 
/*     */ 
/*     */     
/*     */     public EngineKey(String engineName, String[] scripts) {
/* 464 */       this.engineName = engineName;
/* 465 */       this.scripts = scripts;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 470 */       if (this != other) { if (other instanceof EngineKey) { EngineKey that = (EngineKey)other; if (this.engineName
/* 471 */             .equals(that.engineName) && 
/* 472 */             Arrays.equals((Object[])this.scripts, (Object[])that.scripts)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 477 */       return this.engineName.hashCode() * 29 + Arrays.hashCode((Object[])this.scripts);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\script\ScriptTemplateView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */