package org.springframework.web.servlet.view.script;

import java.nio.charset.Charset;
import java.util.function.Supplier;
import javax.script.ScriptEngine;
import org.springframework.lang.Nullable;

public interface ScriptTemplateConfig {
  @Nullable
  ScriptEngine getEngine();
  
  @Nullable
  Supplier<ScriptEngine> getEngineSupplier();
  
  @Nullable
  String getEngineName();
  
  @Nullable
  Boolean isSharedEngine();
  
  @Nullable
  String[] getScripts();
  
  @Nullable
  String getRenderObject();
  
  @Nullable
  String getRenderFunction();
  
  @Nullable
  String getContentType();
  
  @Nullable
  Charset getCharset();
  
  @Nullable
  String getResourceLoaderPath();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\script\ScriptTemplateConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */