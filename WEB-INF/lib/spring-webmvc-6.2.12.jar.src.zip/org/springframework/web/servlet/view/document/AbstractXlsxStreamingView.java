/*    */ package org.springframework.web.servlet.view.document;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.apache.poi.ss.usermodel.Workbook;
/*    */ import org.apache.poi.xssf.streaming.SXSSFWorkbook;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXlsxStreamingView
/*    */   extends AbstractXlsxView
/*    */ {
/*    */   protected SXSSFWorkbook createWorkbook(Map<String, Object> model, HttpServletRequest request) {
/* 44 */     return new SXSSFWorkbook();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderWorkbook(Workbook workbook, HttpServletResponse response) throws IOException {
/* 53 */     super.renderWorkbook(workbook, response);
/*    */ 
/*    */     
/* 56 */     ((SXSSFWorkbook)workbook).dispose();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\document\AbstractXlsxStreamingView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */