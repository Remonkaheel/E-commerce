package org.springframework.web.servlet.view.freemarker;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

class GenericServletAdapter extends GenericServlet {
  public void service(ServletRequest servletRequest, ServletResponse servletResponse) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerView$GenericServletAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */