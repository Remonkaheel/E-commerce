/*     */ package org.springframework.web.servlet.view.xml;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarshallingView
/*     */   extends AbstractView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/xml";
/*     */   @Nullable
/*     */   private Marshaller marshaller;
/*     */   @Nullable
/*     */   private String modelKey;
/*     */   
/*     */   public MarshallingView() {
/*  68 */     setContentType("application/xml");
/*  69 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarshallingView(Marshaller marshaller) {
/*  76 */     this();
/*  77 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  78 */     this.marshaller = marshaller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarshaller(Marshaller marshaller) {
/*  86 */     this.marshaller = marshaller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModelKey(String modelKey) {
/*  95 */     this.modelKey = modelKey;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initApplicationContext() {
/* 100 */     Assert.state((this.marshaller != null), "Property 'marshaller' is required");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 108 */     Object toBeMarshalled = locateToBeMarshalled(model);
/* 109 */     if (toBeMarshalled == null) {
/* 110 */       throw new IllegalStateException("Unable to locate object to be marshalled in model: " + String.valueOf(model));
/*     */     }
/*     */     
/* 113 */     Assert.state((this.marshaller != null), "No Marshaller set");
/* 114 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
/* 115 */     this.marshaller.marshal(toBeMarshalled, new StreamResult(baos));
/*     */     
/* 117 */     setResponseContentType(request, response);
/* 118 */     response.setContentLength(baos.size());
/* 119 */     baos.writeTo((OutputStream)response.getOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object locateToBeMarshalled(Map<String, Object> model) throws IllegalStateException {
/* 135 */     if (this.modelKey != null) {
/* 136 */       Object value = model.get(this.modelKey);
/* 137 */       if (value == null) {
/* 138 */         throw new IllegalStateException("Model contains no object with key [" + this.modelKey + "]");
/*     */       }
/* 140 */       if (!isEligibleForMarshalling(this.modelKey, value)) {
/* 141 */         throw new IllegalStateException("Model object [" + String.valueOf(value) + "] retrieved via key [" + this.modelKey + "] is not supported by the Marshaller");
/*     */       }
/*     */       
/* 144 */       return value;
/*     */     } 
/* 146 */     for (Map.Entry<String, Object> entry : model.entrySet()) {
/* 147 */       Object value = entry.getValue();
/* 148 */       if (value != null && (model.size() == 1 || !(value instanceof org.springframework.validation.BindingResult)) && 
/* 149 */         isEligibleForMarshalling(entry.getKey(), value)) {
/* 150 */         return value;
/*     */       }
/*     */     } 
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEligibleForMarshalling(String modelKey, Object value) {
/* 167 */     Assert.state((this.marshaller != null), "No Marshaller set");
/* 168 */     Class<?> classToCheck = value.getClass();
/* 169 */     if (value instanceof JAXBElement) { JAXBElement<?> jaxbElement = (JAXBElement)value;
/* 170 */       classToCheck = jaxbElement.getDeclaredType(); }
/*     */     
/* 172 */     return this.marshaller.supports(classToCheck);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\xml\MarshallingView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */