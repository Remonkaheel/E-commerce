/*     */ package org.springframework.web.servlet.view.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonView;
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.converter.json.MappingJacksonValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJackson2View
/*     */   extends AbstractView
/*     */ {
/*     */   private ObjectMapper objectMapper;
/*  54 */   private JsonEncoding encoding = JsonEncoding.UTF8;
/*     */   
/*     */   @Nullable
/*     */   private Boolean prettyPrint;
/*     */   
/*     */   private boolean disableCaching = true;
/*     */   
/*     */   protected boolean updateContentLength = false;
/*     */ 
/*     */   
/*     */   protected AbstractJackson2View(ObjectMapper objectMapper, String contentType) {
/*  65 */     this.objectMapper = objectMapper;
/*  66 */     configurePrettyPrint();
/*  67 */     setContentType(contentType);
/*  68 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectMapper(ObjectMapper objectMapper) {
/*  79 */     this.objectMapper = objectMapper;
/*  80 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectMapper getObjectMapper() {
/*  87 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncoding(JsonEncoding encoding) {
/*  95 */     Assert.notNull(encoding, "'encoding' must not be null");
/*  96 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonEncoding getEncoding() {
/* 103 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrettyPrint(boolean prettyPrint) {
/* 116 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 117 */     configurePrettyPrint();
/*     */   }
/*     */   
/*     */   private void configurePrettyPrint() {
/* 121 */     if (this.prettyPrint != null) {
/* 122 */       this.objectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisableCaching(boolean disableCaching) {
/* 131 */     this.disableCaching = disableCaching;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdateContentLength(boolean updateContentLength) {
/* 141 */     this.updateContentLength = updateContentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response) {
/* 146 */     setResponseContentType(request, response);
/* 147 */     response.setCharacterEncoding(this.encoding.getJavaName());
/* 148 */     if (this.disableCaching) {
/* 149 */       response.addHeader("Cache-Control", "no-store");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     ServletOutputStream servletOutputStream;
/* 157 */     ByteArrayOutputStream temporaryStream = null;
/*     */ 
/*     */     
/* 160 */     if (this.updateContentLength) {
/* 161 */       temporaryStream = createTemporaryOutputStream();
/* 162 */       OutputStream stream = temporaryStream;
/*     */     } else {
/*     */       
/* 165 */       servletOutputStream = response.getOutputStream();
/*     */     } 
/*     */     
/* 168 */     Object value = filterAndWrapModel(model, request);
/* 169 */     writeContent((OutputStream)servletOutputStream, value);
/*     */     
/* 171 */     if (temporaryStream != null) {
/* 172 */       writeToResponse(response, temporaryStream);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object filterAndWrapModel(Map<String, Object> model, HttpServletRequest request) {
/* 183 */     Object value = filterModel(model);
/* 184 */     Class<?> serializationView = (Class)model.get(JsonView.class.getName());
/* 185 */     FilterProvider filters = (FilterProvider)model.get(FilterProvider.class.getName());
/* 186 */     if (serializationView != null || filters != null) {
/* 187 */       MappingJacksonValue container = new MappingJacksonValue(value);
/* 188 */       if (serializationView != null) {
/* 189 */         container.setSerializationView(serializationView);
/*     */       }
/* 191 */       if (filters != null) {
/* 192 */         container.setFilters(filters);
/*     */       }
/* 194 */       value = container;
/*     */     } 
/* 196 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeContent(OutputStream stream, Object object) throws IOException {
/* 206 */     JsonGenerator generator = this.objectMapper.getFactory().createGenerator(stream, this.encoding); try {
/* 207 */       writePrefix(generator, object);
/*     */       
/* 209 */       Object value = object;
/* 210 */       Class<?> serializationView = null;
/* 211 */       FilterProvider filters = null;
/*     */       
/* 213 */       if (value instanceof MappingJacksonValue) { MappingJacksonValue container = (MappingJacksonValue)value;
/* 214 */         value = container.getValue();
/* 215 */         serializationView = container.getSerializationView();
/* 216 */         filters = container.getFilters(); }
/*     */ 
/*     */ 
/*     */       
/* 220 */       ObjectWriter objectWriter = (serializationView != null) ? this.objectMapper.writerWithView(serializationView) : this.objectMapper.writer();
/* 221 */       if (filters != null) {
/* 222 */         objectWriter = objectWriter.with(filters);
/*     */       }
/* 224 */       objectWriter.writeValue(generator, value);
/*     */       
/* 226 */       writeSuffix(generator, object);
/* 227 */       generator.flush();
/* 228 */       if (generator != null) generator.close(); 
/*     */     } catch (Throwable throwable) {
/*     */       if (generator != null)
/*     */         try {
/*     */           generator.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract void setModelKey(String paramString);
/*     */   
/*     */   protected abstract Object filterModel(Map<String, Object> paramMap);
/*     */   
/*     */   protected void writePrefix(JsonGenerator generator, Object object) throws IOException {}
/*     */   
/*     */   protected void writeSuffix(JsonGenerator generator, Object object) throws IOException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\json\AbstractJackson2View.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */