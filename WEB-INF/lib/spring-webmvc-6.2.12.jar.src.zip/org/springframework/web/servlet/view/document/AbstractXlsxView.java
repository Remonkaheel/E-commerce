/*    */ package org.springframework.web.servlet.view.document;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Map;
/*    */ import org.apache.poi.ss.usermodel.Workbook;
/*    */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXlsxView
/*    */   extends AbstractXlsView
/*    */ {
/*    */   public AbstractXlsxView() {
/* 43 */     setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Workbook createWorkbook(Map<String, Object> model, HttpServletRequest request) {
/* 51 */     return (Workbook)new XSSFWorkbook();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\document\AbstractXlsxView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */