/*    */ package org.springframework.web.servlet.view;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.web.servlet.View;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends LinkedHashMap<Object, View>
/*    */ {
/*    */   null(int initialCapacity, float loadFactor, boolean accessOrder) {
/* 82 */     super(initialCapacity, loadFactor, accessOrder);
/*    */   }
/*    */   protected boolean removeEldestEntry(Map.Entry<Object, View> eldest) {
/* 85 */     if (size() > AbstractCachingViewResolver.this.getCacheLimit()) {
/* 86 */       AbstractCachingViewResolver.this.viewAccessCache.remove(eldest.getKey());
/* 87 */       return true;
/*    */     } 
/*    */     
/* 90 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\AbstractCachingViewResolver$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */