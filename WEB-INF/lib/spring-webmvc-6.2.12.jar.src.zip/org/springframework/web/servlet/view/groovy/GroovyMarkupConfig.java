package org.springframework.web.servlet.view.groovy;

import groovy.text.markup.MarkupTemplateEngine;

public interface GroovyMarkupConfig {
  MarkupTemplateEngine getTemplateEngine();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\groovy\GroovyMarkupConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */