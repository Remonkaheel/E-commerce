/*     */ package org.springframework.web.servlet.view.freemarker;
/*     */ 
/*     */ import freemarker.template.Configuration;
/*     */ import java.util.Locale;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FreeMarkerViewResolver
/*     */   extends AbstractTemplateViewResolver
/*     */ {
/*     */   public FreeMarkerViewResolver() {
/*  70 */     setViewClass(requiredViewClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FreeMarkerViewResolver(String prefix, String suffix) {
/*  81 */     this();
/*  82 */     setPrefix(prefix);
/*  83 */     setSuffix(suffix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> requiredViewClass() {
/*  92 */     return FreeMarkerView.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractUrlBasedView instantiateView() {
/*  97 */     return (getViewClass() == FreeMarkerView.class) ? (AbstractUrlBasedView)new FreeMarkerView() : super.instantiateView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected View loadView(String viewName, Locale locale) throws Exception {
/* 110 */     View view = super.loadView(viewName, locale);
/* 111 */     if (view instanceof FreeMarkerView) { FreeMarkerView freeMarkerView = (FreeMarkerView)view;
/* 112 */       postProcessView(freeMarkerView); }
/*     */     
/* 114 */     return view;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessView(FreeMarkerView freeMarkerView) {
/* 138 */     if (getContentType() != null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 143 */     String encoding = freeMarkerView.getEncoding();
/* 144 */     if (encoding == null) {
/*     */ 
/*     */       
/* 147 */       Configuration configuration = freeMarkerView.obtainConfiguration();
/* 148 */       if (configuration.isDefaultEncodingExplicitlySet()) {
/* 149 */         encoding = configuration.getDefaultEncoding();
/*     */       }
/*     */     } 
/* 152 */     if (StringUtils.hasText(encoding)) {
/* 153 */       String contentType = "text/html;charset=" + encoding;
/* 154 */       if (this.logger.isDebugEnabled()) {
/* 155 */         this.logger.debug("Setting Content-Type for view [%s] to: %s".formatted(new Object[] { freeMarkerView, contentType }));
/*     */       }
/* 157 */       freeMarkerView.setContentType(contentType);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerViewResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */