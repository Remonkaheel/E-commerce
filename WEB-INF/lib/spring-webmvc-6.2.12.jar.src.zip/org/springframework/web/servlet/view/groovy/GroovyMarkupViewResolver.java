/*    */ package org.springframework.web.servlet.view.groovy;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroovyMarkupViewResolver
/*    */   extends AbstractTemplateViewResolver
/*    */ {
/*    */   public GroovyMarkupViewResolver() {
/* 47 */     setViewClass(requiredViewClass());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GroovyMarkupViewResolver(String prefix, String suffix) {
/* 58 */     this();
/* 59 */     setPrefix(prefix);
/* 60 */     setSuffix(suffix);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<?> requiredViewClass() {
/* 66 */     return GroovyMarkupView.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected AbstractUrlBasedView instantiateView() {
/* 71 */     return (getViewClass() == GroovyMarkupView.class) ? (AbstractUrlBasedView)new GroovyMarkupView() : super.instantiateView();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getCacheKey(String viewName, Locale locale) {
/* 79 */     return viewName + "_" + viewName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\view\groovy\GroovyMarkupViewResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */