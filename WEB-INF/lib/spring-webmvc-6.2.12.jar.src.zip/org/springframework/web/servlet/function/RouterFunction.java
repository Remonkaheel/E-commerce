/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface RouterFunction<T extends ServerResponse>
/*     */ {
/*     */   Optional<HandlerFunction<T>> route(ServerRequest paramServerRequest);
/*     */   
/*     */   default RouterFunction<T> and(RouterFunction<T> other) {
/*  55 */     return new RouterFunctions.SameComposedRouterFunction<>(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RouterFunction<?> andOther(RouterFunction<?> other) {
/*  68 */     return new RouterFunctions.DifferentComposedRouterFunction(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RouterFunction<T> andRoute(RequestPredicate predicate, HandlerFunction<T> handlerFunction) {
/*  83 */     return and(RouterFunctions.route(predicate, handlerFunction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RouterFunction<T> andNest(RequestPredicate predicate, RouterFunction<T> routerFunction) {
/*  98 */     return and(RouterFunctions.nest(predicate, routerFunction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <S extends ServerResponse> RouterFunction<S> filter(HandlerFilterFunction<T, S> filterFunction) {
/* 109 */     return new RouterFunctions.FilteredRouterFunction<>(this, filterFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void accept(RouterFunctions.Visitor visitor) {
/* 120 */     visitor.unknown(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RouterFunction<T> withAttribute(String name, Object value) {
/* 131 */     Assert.hasLength(name, "Name must not be empty");
/* 132 */     Assert.notNull(value, "Value must not be null");
/*     */     
/* 134 */     Map<String, Object> attributes = new LinkedHashMap<>();
/* 135 */     attributes.put(name, value);
/* 136 */     return new RouterFunctions.AttributesRouterFunction<>(this, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RouterFunction<T> withAttributes(Consumer<Map<String, Object>> attributesConsumer) {
/* 150 */     Assert.notNull(attributesConsumer, "AttributesConsumer must not be null");
/*     */     
/* 152 */     Map<String, Object> attributes = new LinkedHashMap<>();
/* 153 */     attributesConsumer.accept(attributes);
/* 154 */     return new RouterFunctions.AttributesRouterFunction<>(this, attributes);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */