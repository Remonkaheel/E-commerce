/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceHandlerFunction
/*     */   implements HandlerFunction<ServerResponse>
/*     */ {
/*  43 */   private static final Set<HttpMethod> SUPPORTED_METHODS = Set.of(HttpMethod.GET, HttpMethod.HEAD, HttpMethod.OPTIONS);
/*     */ 
/*     */   
/*     */   private final Resource resource;
/*     */   
/*     */   private final BiConsumer<Resource, HttpHeaders> headersConsumer;
/*     */ 
/*     */   
/*     */   public ResourceHandlerFunction(Resource resource, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/*  52 */     this.resource = resource;
/*  53 */     this.headersConsumer = headersConsumer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerResponse handle(ServerRequest request) {
/*  59 */     HttpMethod method = request.method();
/*  60 */     if (HttpMethod.GET.equals(method)) {
/*  61 */       return EntityResponse.<Resource>fromObject(this.resource)
/*  62 */         .headers(headers -> this.headersConsumer.accept(this.resource, headers))
/*  63 */         .build();
/*     */     }
/*  65 */     if (HttpMethod.HEAD.equals(method)) {
/*  66 */       Resource headResource = new HeadMethodResource(this.resource);
/*  67 */       return EntityResponse.<Resource>fromObject(headResource)
/*  68 */         .headers(headers -> this.headersConsumer.accept(this.resource, headers))
/*  69 */         .build();
/*     */     } 
/*  71 */     if (HttpMethod.OPTIONS.equals(method)) {
/*  72 */       return ServerResponse.ok()
/*  73 */         .allow(SUPPORTED_METHODS).build();
/*     */     }
/*  75 */     return ServerResponse.status((HttpStatusCode)HttpStatus.METHOD_NOT_ALLOWED)
/*  76 */       .allow(SUPPORTED_METHODS).build();
/*     */   }
/*     */   
/*     */   private static class HeadMethodResource
/*     */     implements Resource
/*     */   {
/*  82 */     private static final byte[] EMPTY = new byte[0];
/*     */     
/*     */     private final Resource delegate;
/*     */     
/*     */     public HeadMethodResource(Resource delegate) {
/*  87 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/*  92 */       return new ByteArrayInputStream(EMPTY);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean exists() {
/*  99 */       return this.delegate.exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getURL() throws IOException {
/* 104 */       return this.delegate.getURL();
/*     */     }
/*     */ 
/*     */     
/*     */     public URI getURI() throws IOException {
/* 109 */       return this.delegate.getURI();
/*     */     }
/*     */ 
/*     */     
/*     */     public File getFile() throws IOException {
/* 114 */       return this.delegate.getFile();
/*     */     }
/*     */ 
/*     */     
/*     */     public long contentLength() throws IOException {
/* 119 */       return this.delegate.contentLength();
/*     */     }
/*     */ 
/*     */     
/*     */     public long lastModified() throws IOException {
/* 124 */       return this.delegate.lastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException {
/* 129 */       return this.delegate.createRelative(relativePath);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getFilename() {
/* 135 */       return this.delegate.getFilename();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 140 */       return this.delegate.getDescription();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ResourceHandlerFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */