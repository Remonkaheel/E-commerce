/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface RequestPredicate
/*    */ {
/*    */   boolean test(ServerRequest paramServerRequest);
/*    */   
/*    */   default RequestPredicate and(RequestPredicate other) {
/* 50 */     return new RequestPredicates.AndRequestPredicate(this, other);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default RequestPredicate negate() {
/* 58 */     return new RequestPredicates.NegateRequestPredicate(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default RequestPredicate or(RequestPredicate other) {
/* 69 */     return new RequestPredicates.OrRequestPredicate(this, other);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Optional<ServerRequest> nest(ServerRequest request) {
/* 84 */     return test(request) ? Optional.<ServerRequest>of(request) : Optional.<ServerRequest>empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default void accept(RequestPredicates.Visitor visitor) {
/* 95 */     visitor.unknown(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RequestPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */