/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.PublishedApi;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000¢\001\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\t\n\002\020\021\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\006\n\002\030\002\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\003\n\002\b\t\n\002\030\002\n\002\b\004\n\002\020\b\n\002\030\002\n\002\b\006\n\002\020%\n\002\b\007\030\0002\0020\001B \b\000\022\027\020\002\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005¢\006\002\020\006J\032\020\016\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\016\032\0020\0222\006\020\023\032\0020\024J\"\020\016\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\016\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\016\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\032\020\026\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\026\032\0020\0222\006\020\023\032\0020\024J\"\020\026\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\026\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\026\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\032\020\027\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\027\032\0020\0222\006\020\023\032\0020\024J\"\020\027\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\027\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\027\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\032\020\030\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\030\032\0020\0222\006\020\023\032\0020\024J\"\020\030\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\030\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\030\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\032\020\031\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\031\032\0020\0222\006\020\023\032\0020\024J\"\020\031\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\031\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\031\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\032\020\032\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\032\032\0020\0222\006\020\023\032\0020\024J\"\020\032\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\032\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\032\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\032\020\033\032\0020\0042\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020\033\032\0020\0222\006\020\023\032\0020\024J\"\020\033\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J*\020\033\032\0020\0042\006\020\023\032\0020\0242\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\"\020\033\032\0020\0042\006\020\025\032\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\037\020\034\032\0020\0222\022\020\035\032\n\022\006\b\001\022\0020\0370\036\"\0020\037¢\006\002\020 J\"\020\034\032\0020\0042\006\020\035\032\0020\0372\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020!\032\n \t*\004\030\0010\"0\"J\024\020#\032\0020\0042\f\020$\032\b\022\004\022\0020\0210%J \020&\032\0020\0042\030\020'\032\024\022\004\022\0020\020\022\004\022\0020\021\022\004\022\0020\0210(J\016\020)\032\n \t*\004\030\0010\"0\"J\032\020*\032\0020\0042\022\020+\032\016\022\004\022\0020\020\022\004\022\0020\0200\003J\023\020,\032\b\022\004\022\0020\0210%H\000¢\006\002\b-J\037\020.\032\0020\0222\022\020/\032\n\022\006\b\001\022\0020\0370\036\"\0020\037¢\006\002\020 J\"\020.\032\0020\0042\006\020\035\032\0020\0372\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\026\0200\032\n \t*\004\030\0010\"0\"2\006\0201\032\00202J,\0203\032\0020\0042$\0204\032 \022\004\022\0020\020\022\020\022\016\022\004\022\0020\020\022\004\022\0020\0210\003\022\004\022\0020\0210(J\026\0205\032\n \t*\004\030\0010\"0\"2\006\0206\032\0020\021J\032\0207\032\0020\0222\022\0208\032\016\022\004\022\00209\022\004\022\0020:0\003J.\0207\032\0020\0042\022\0208\032\016\022\004\022\00209\022\004\022\0020:0\0032\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020;\032\0020\0222\006\020<\032\0020=J\"\020;\032\0020\0042\006\020<\032\0020=2\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\026\020>\032\022\022\002\b\003 \t*\b\022\002\b\003\030\0010?0?J\026\020@\032\022\022\002\b\003 \t*\b\022\002\b\003\030\0010?0?J\016\020A\032\n \t*\004\030\0010\"0\"J4\020B\032\0020\0042\022\020\025\032\016\022\004\022\0020C\022\004\022\0020:0\0032\030\020D\032\024\022\004\022\0020C\022\004\022\0020\020\022\004\022\0020\0210(J4\020B\032\0020\004\"\n\b\000\020E\030\001*\0020C2\032\b\b\020D\032\024\022\004\022\0020C\022\004\022\0020\020\022\004\022\0020\0210(H\bø\001\000J\"\020F\032\0020\0222\006\020G\032\0020\0242\022\020\025\032\016\022\004\022\0020\024\022\004\022\0020:0\003J6\020F\032\0020\0042\006\020G\032\0020\0242\022\020\025\032\016\022\004\022\0020\024\022\004\022\0020:0\0032\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020H\032\0020\0222\006\020\023\032\0020\024J\"\020H\032\0020\0042\006\020\023\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\034\020I\032\0020\0222\024\020\025\032\020\022\006\022\004\030\0010\024\022\004\022\0020:0\003J0\020I\032\0020\0042\024\020\025\032\020\022\006\022\004\030\0010\024\022\004\022\0020:0\0032\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\016\020I\032\0020\0222\006\020J\032\0020\024J\"\020I\032\0020\0042\006\020J\032\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003J\026\020K\032\n \t*\004\030\0010\"0\"2\006\0201\032\00202J\026\020L\032\0020\0042\006\020\025\032\0020\0222\006\020L\032\0020MJ\034\020N\032\0020\0042\024\020O\032\020\022\004\022\0020\020\022\006\022\004\030\0010M0\003J\026\020N\032\0020\0042\006\020H\032\0020\0242\006\0201\032\0020MJ\026\020P\032\n \t*\004\030\0010\"0\"2\006\0201\032\00202J\026\020Q\032\n \t*\004\030\0010\"0\"2\006\020Q\032\0020RJ\026\020Q\032\n \t*\004\030\0010\"0\"2\006\020Q\032\0020SJ\026\020T\032\n \t*\004\030\0010\"0\"2\006\0201\032\00202J\016\020U\032\n \t*\004\030\0010\"0\"J\026\020V\032\0020\0042\006\020G\032\0020\0242\006\020W\032\0020\001J&\020X\032\0020\0042\036\020Y\032\032\022\020\022\016\022\004\022\0020\024\022\004\022\0020\0010Z\022\004\022\0020\0040\003J\025\020[\032\0020\022*\0020\0242\006\0206\032\0020\022H\004J\025\020[\032\0020\022*\0020\0222\006\0206\032\0020\024H\004J\025\020[\032\0020\022*\0020\0222\006\0206\032\0020\022H\004J!\020\\\032\0020\004*\0020\0242\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003H\002J!\020\\\032\0020\004*\0020\0222\022\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0210\003H\002J#\020]\032\0020\004*\0020\0242\027\020^\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005J#\020]\032\0020\004*\0020\0222\027\020^\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005J\r\020_\032\0020\022*\0020\022H\002J\025\020`\032\0020\022*\0020\0242\006\0206\032\0020\022H\004J\025\020`\032\0020\022*\0020\0222\006\0206\032\0020\024H\004J\025\020`\032\0020\022*\0020\0222\006\0206\032\0020\022H\004R$\020\007\032\n \t*\004\030\0010\b0\b8\000X\004¢\006\016\n\000\022\004\b\n\020\013\032\004\b\f\020\rR\037\020\002\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005X\004¢\006\002\n\000\002\007\n\005\b20\001¨\006a"}, d2 = {"Lorg/springframework/web/servlet/function/RouterFunctionDsl;", "", "init", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function1;)V", "builder", "Lorg/springframework/web/servlet/function/RouterFunctions$Builder;", "kotlin.jvm.PlatformType", "getBuilder$annotations", "()V", "getBuilder", "()Lorg/springframework/web/servlet/function/RouterFunctions$Builder;", "DELETE", "f", "Lorg/springframework/web/servlet/function/ServerRequest;", "Lorg/springframework/web/servlet/function/ServerResponse;", "Lorg/springframework/web/servlet/function/RequestPredicate;", "pattern", "", "predicate", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT", "accept", "mediaType", "", "Lorg/springframework/http/MediaType;", "([Lorg/springframework/http/MediaType;)Lorg/springframework/web/servlet/function/RequestPredicate;", "accepted", "Lorg/springframework/web/servlet/function/ServerResponse$BodyBuilder;", "add", "routerFunction", "Lorg/springframework/web/servlet/function/RouterFunction;", "after", "responseProcessor", "Lkotlin/Function2;", "badRequest", "before", "requestProcessor", "build", "build$spring_webmvc", "contentType", "mediaTypes", "created", "location", "Ljava/net/URI;", "filter", "filterFunction", "from", "other", "headers", "headersPredicate", "Lorg/springframework/web/servlet/function/ServerRequest$Headers;", "", "method", "httpMethod", "Lorg/springframework/http/HttpMethod;", "noContent", "Lorg/springframework/web/servlet/function/ServerResponse$HeadersBuilder;", "notFound", "ok", "onError", "", "responseProvider", "E", "param", "name", "path", "pathExtension", "extension", "permanentRedirect", "resource", "Lorg/springframework/core/io/Resource;", "resources", "lookupFunction", "seeOther", "status", "", "Lorg/springframework/http/HttpStatusCode;", "temporaryRedirect", "unprocessableEntity", "withAttribute", "value", "withAttributes", "attributesConsumer", "", "and", "invoke", "nest", "r", "not", "or", "spring-webmvc"})
/*     */ public final class RouterFunctionDsl
/*     */ {
/*     */   @NotNull
/*     */   private final Function1<RouterFunctionDsl, Unit> init;
/*     */   private final RouterFunctions.Builder builder;
/*     */   
/*     */   public RouterFunctionDsl(@NotNull Function1<RouterFunctionDsl, Unit> init) {
/*  62 */     this.init = init;
/*     */ 
/*     */     
/*  65 */     this.builder = RouterFunctions.route(); } public final RouterFunctions.Builder getBuilder() { return this.builder; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate and(@NotNull RequestPredicate $this$and, @NotNull String other) {
/*  75 */     Intrinsics.checkNotNullParameter($this$and, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); Intrinsics.checkNotNullExpressionValue($this$and.and(path(other)), "this.and(path(other))"); return $this$and.and(path(other));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate or(@NotNull RequestPredicate $this$or, @NotNull String other) {
/*  85 */     Intrinsics.checkNotNullParameter($this$or, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); Intrinsics.checkNotNullExpressionValue($this$or.or(path(other)), "this.or(path(other))"); return $this$or.or(path(other));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate and(@NotNull String $this$and, @NotNull RequestPredicate other) {
/*  95 */     Intrinsics.checkNotNullParameter($this$and, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); Intrinsics.checkNotNullExpressionValue(path($this$and).and(other), "path(this).and(other)"); return path($this$and).and(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate or(@NotNull String $this$or, @NotNull RequestPredicate other) {
/* 105 */     Intrinsics.checkNotNullParameter($this$or, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); Intrinsics.checkNotNullExpressionValue(path($this$or).or(other), "path(this).or(other)"); return path($this$or).or(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate and(@NotNull RequestPredicate $this$and, @NotNull RequestPredicate other) {
/* 113 */     Intrinsics.checkNotNullParameter($this$and, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); Intrinsics.checkNotNullExpressionValue($this$and.and(other), "this.and(other)"); return $this$and.and(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate or(@NotNull RequestPredicate $this$or, @NotNull RequestPredicate other) {
/* 121 */     Intrinsics.checkNotNullParameter($this$or, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); Intrinsics.checkNotNullExpressionValue($this$or.or(other), "this.or(other)"); return $this$or.or(other);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate not(@NotNull RequestPredicate $this$not) {
/* 126 */     Intrinsics.checkNotNullParameter($this$not, "<this>"); Intrinsics.checkNotNullExpressionValue($this$not.negate(), "this.negate()"); return $this$not.negate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void nest(@NotNull RequestPredicate $this$nest, @NotNull Function1 r) {
/* 135 */     Intrinsics.checkNotNullParameter($this$nest, "<this>"); Intrinsics.checkNotNullParameter(r, "r"); this.builder.nest($this$nest, new RouterFunctionDsl(r)::build$spring_webmvc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void nest(@NotNull String $this$nest, @NotNull Function1<? super RouterFunctionDsl, Unit> r) {
/* 146 */     Intrinsics.checkNotNullParameter($this$nest, "<this>"); Intrinsics.checkNotNullParameter(r, "r"); nest(path($this$nest), r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void GET(@NotNull Function1 f) {
/* 153 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.GET(f::GET$lambda$0); } private static final ServerResponse GET$lambda$0(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void GET(@NotNull String pattern, @NotNull Function1 f) {
/* 162 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.GET(pattern, f::GET$lambda$1); } private static final ServerResponse GET$lambda$1(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void GET(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 172 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.GET(predicate, f::GET$lambda$2); } private static final ServerResponse GET$lambda$2(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void GET(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 183 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.GET(pattern, predicate, f::GET$lambda$3); } private static final ServerResponse GET$lambda$3(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate GET(@NotNull String pattern) {
/* 191 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.GET(pattern), "GET(pattern)"); return RequestPredicates.GET(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void HEAD(@NotNull Function1 f) {
/* 198 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.HEAD(f::HEAD$lambda$4); } private static final ServerResponse HEAD$lambda$4(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void HEAD(@NotNull String pattern, @NotNull Function1 f) {
/* 207 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.HEAD(pattern, f::HEAD$lambda$5); } private static final ServerResponse HEAD$lambda$5(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void HEAD(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 217 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.HEAD(predicate, f::HEAD$lambda$6); } private static final ServerResponse HEAD$lambda$6(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void HEAD(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 228 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.HEAD(pattern, predicate, f::HEAD$lambda$7); } private static final ServerResponse HEAD$lambda$7(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate HEAD(@NotNull String pattern) {
/* 236 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.HEAD(pattern), "HEAD(pattern)"); return RequestPredicates.HEAD(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void POST(@NotNull Function1 f) {
/* 243 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.POST(f::POST$lambda$8); } private static final ServerResponse POST$lambda$8(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void POST(@NotNull String pattern, @NotNull Function1 f) {
/* 252 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.POST(pattern, f::POST$lambda$9); } private static final ServerResponse POST$lambda$9(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void POST(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 262 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.POST(predicate, f::POST$lambda$10); } private static final ServerResponse POST$lambda$10(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void POST(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 273 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.POST(pattern, predicate, f::POST$lambda$11); } private static final ServerResponse POST$lambda$11(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate POST(@NotNull String pattern) {
/* 281 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.POST(pattern), "POST(pattern)"); return RequestPredicates.POST(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PUT(@NotNull Function1 f) {
/* 288 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.PUT(f::PUT$lambda$12); } private static final ServerResponse PUT$lambda$12(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PUT(@NotNull String pattern, @NotNull Function1 f) {
/* 297 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.PUT(pattern, f::PUT$lambda$13); } private static final ServerResponse PUT$lambda$13(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PUT(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 307 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.PUT(predicate, f::PUT$lambda$14); } private static final ServerResponse PUT$lambda$14(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PUT(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 318 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.PUT(pattern, predicate, f::PUT$lambda$15); } private static final ServerResponse PUT$lambda$15(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate PUT(@NotNull String pattern) {
/* 326 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.PUT(pattern), "PUT(pattern)"); return RequestPredicates.PUT(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PATCH(@NotNull Function1 f) {
/* 333 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.PATCH(f::PATCH$lambda$16); } private static final ServerResponse PATCH$lambda$16(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PATCH(@NotNull String pattern, @NotNull Function1 f) {
/* 342 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.PATCH(pattern, f::PATCH$lambda$17); } private static final ServerResponse PATCH$lambda$17(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PATCH(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 352 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.PATCH(predicate, f::PATCH$lambda$18); } private static final ServerResponse PATCH$lambda$18(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void PATCH(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 363 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.PATCH(pattern, predicate, f::PATCH$lambda$19); } private static final ServerResponse PATCH$lambda$19(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate PATCH(@NotNull String pattern) {
/* 373 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.PATCH(pattern), "PATCH(pattern)"); return RequestPredicates.PATCH(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void DELETE(@NotNull Function1 f) {
/* 380 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.DELETE(f::DELETE$lambda$20); } private static final ServerResponse DELETE$lambda$20(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void DELETE(@NotNull String pattern, @NotNull Function1 f) {
/* 389 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.DELETE(pattern, f::DELETE$lambda$21); } private static final ServerResponse DELETE$lambda$21(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void DELETE(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 399 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.DELETE(predicate, f::DELETE$lambda$22); } private static final ServerResponse DELETE$lambda$22(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void DELETE(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 410 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.DELETE(pattern, predicate, f::DELETE$lambda$23); } private static final ServerResponse DELETE$lambda$23(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate DELETE(@NotNull String pattern) {
/* 420 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.DELETE(pattern), "DELETE(pattern)"); return RequestPredicates.DELETE(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void OPTIONS(@NotNull Function1 f) {
/* 427 */     Intrinsics.checkNotNullParameter(f, "f"); this.builder.OPTIONS(f::OPTIONS$lambda$24); } private static final ServerResponse OPTIONS$lambda$24(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void OPTIONS(@NotNull String pattern, @NotNull Function1 f) {
/* 436 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.OPTIONS(pattern, f::OPTIONS$lambda$25); } private static final ServerResponse OPTIONS$lambda$25(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void OPTIONS(@NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 446 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.OPTIONS(predicate, f::OPTIONS$lambda$26); } private static final ServerResponse OPTIONS$lambda$26(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void OPTIONS(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1 f) {
/* 457 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.OPTIONS(pattern, predicate, f::OPTIONS$lambda$27); } private static final ServerResponse OPTIONS$lambda$27(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate OPTIONS(@NotNull String pattern) {
/* 467 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.OPTIONS(pattern), "OPTIONS(pattern)"); return RequestPredicates.OPTIONS(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void accept(@NotNull MediaType mediaType, @NotNull Function1 f) {
/* 474 */     Intrinsics.checkNotNullParameter(mediaType, "mediaType"); Intrinsics.checkNotNullParameter(f, "f"); MediaType[] arrayOfMediaType = new MediaType[1]; arrayOfMediaType[0] = mediaType; this.builder.add(RouterFunctions.route(RequestPredicates.accept(arrayOfMediaType), f::accept$lambda$28)); } private static final ServerResponse accept$lambda$28(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate accept(@NotNull MediaType... mediaType) {
/* 484 */     Intrinsics.checkNotNullParameter(mediaType, "mediaType"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.accept(Arrays.copyOf(mediaType, mediaType.length)), "accept(*mediaType)"); return RequestPredicates.accept(Arrays.copyOf(mediaType, mediaType.length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void contentType(@NotNull MediaType mediaType, @NotNull Function1 f) {
/* 491 */     Intrinsics.checkNotNullParameter(mediaType, "mediaType"); Intrinsics.checkNotNullParameter(f, "f"); MediaType[] arrayOfMediaType = new MediaType[1]; arrayOfMediaType[0] = mediaType; this.builder.add(RouterFunctions.route(RequestPredicates.contentType(arrayOfMediaType), f::contentType$lambda$29)); } private static final ServerResponse contentType$lambda$29(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate contentType(@NotNull MediaType... mediaTypes) {
/* 501 */     Intrinsics.checkNotNullParameter(mediaTypes, "mediaTypes"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.contentType(Arrays.copyOf(mediaTypes, mediaTypes.length)), "contentType(*mediaTypes)"); return RequestPredicates.contentType(Arrays.copyOf(mediaTypes, mediaTypes.length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void headers(@NotNull Function1 headersPredicate, @NotNull Function1 f) {
/* 508 */     Intrinsics.checkNotNullParameter(headersPredicate, "headersPredicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.headers(headersPredicate::headers$lambda$30), f::headers$lambda$31)); } private static final boolean headers$lambda$30(Function1 $tmp0, ServerRequest.Headers p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); } private static final ServerResponse headers$lambda$31(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate headers(@NotNull Function1 headersPredicate) {
/* 517 */     Intrinsics.checkNotNullParameter(headersPredicate, "headersPredicate"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.headers(headersPredicate::headers$lambda$32), "headers(headersPredicate)"); return RequestPredicates.headers(headersPredicate::headers$lambda$32); } private static final boolean headers$lambda$32(Function1 $tmp0, ServerRequest.Headers p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void method(@NotNull HttpMethod httpMethod, @NotNull Function1 f) {
/* 524 */     Intrinsics.checkNotNullParameter(httpMethod, "httpMethod"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.method(httpMethod), f::method$lambda$33)); } private static final ServerResponse method$lambda$33(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate method(@NotNull HttpMethod httpMethod) {
/* 532 */     Intrinsics.checkNotNullParameter(httpMethod, "httpMethod"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.method(httpMethod), "method(httpMethod)"); return RequestPredicates.method(httpMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void path(@NotNull String pattern, @NotNull Function1 f) {
/* 539 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.path(pattern), f::path$lambda$34)); } private static final ServerResponse path$lambda$34(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate path(@NotNull String pattern) {
/* 546 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.path(pattern), "path(pattern)"); return RequestPredicates.path(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void pathExtension(@NotNull String extension, @NotNull Function1 f) {
/* 553 */     Intrinsics.checkNotNullParameter(extension, "extension"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.pathExtension(extension), f::pathExtension$lambda$35)); } private static final ServerResponse pathExtension$lambda$35(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate pathExtension(@NotNull String extension) {
/* 561 */     Intrinsics.checkNotNullParameter(extension, "extension"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.pathExtension(extension), "pathExtension(extension)"); return RequestPredicates.pathExtension(extension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void pathExtension(@NotNull Function1 predicate, @NotNull Function1 f) {
/* 568 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.pathExtension(predicate::pathExtension$lambda$36), f::pathExtension$lambda$37)); } private static final boolean pathExtension$lambda$36(Function1 $tmp0, String p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); } private static final ServerResponse pathExtension$lambda$37(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate pathExtension(@NotNull Function1 predicate) {
/* 577 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.pathExtension(predicate::pathExtension$lambda$38), "pathExtension(predicate)"); return RequestPredicates.pathExtension(predicate::pathExtension$lambda$38); } private static final boolean pathExtension$lambda$38(Function1 $tmp0, String p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void param(@NotNull String name, @NotNull Function1 predicate, @NotNull Function1 f) {
/* 584 */     Intrinsics.checkNotNullParameter(name, "name"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.param(name, predicate::param$lambda$39), f::param$lambda$40)); } private static final boolean param$lambda$39(Function1 $tmp0, String p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); } private static final ServerResponse param$lambda$40(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate param(@NotNull String name, @NotNull Function1 predicate) {
/* 596 */     Intrinsics.checkNotNullParameter(name, "name"); Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullExpressionValue(RequestPredicates.param(name, predicate::param$lambda$41), "param(name, predicate)"); return RequestPredicates.param(name, predicate::param$lambda$41); } private static final boolean param$lambda$41(Function1 $tmp0, String p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void invoke(@NotNull RequestPredicate $this$invoke, @NotNull Function1 f) {
/* 603 */     Intrinsics.checkNotNullParameter($this$invoke, "<this>"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route($this$invoke, f::invoke$lambda$42)); } private static final ServerResponse invoke$lambda$42(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void invoke(@NotNull String $this$invoke, @NotNull Function1 f) {
/* 612 */     Intrinsics.checkNotNullParameter($this$invoke, "<this>"); Intrinsics.checkNotNullParameter(f, "f"); this.builder.add(RouterFunctions.route(RequestPredicates.path($this$invoke), f::invoke$lambda$43)); } private static final ServerResponse invoke$lambda$43(Function1 $tmp0, ServerRequest request) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(request); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void resource(@NotNull RequestPredicate predicate, @NotNull Resource resource) {
/* 621 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(resource, "resource"); this.builder.resource(predicate, resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void resources(@NotNull String path, @NotNull Resource location) {
/* 629 */     Intrinsics.checkNotNullParameter(path, "path"); Intrinsics.checkNotNullParameter(location, "location"); this.builder.resources(path, location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void resources(@NotNull Function1 lookupFunction) {
/* 638 */     Intrinsics.checkNotNullParameter(lookupFunction, "lookupFunction"); this.builder.resources(lookupFunction::resources$lambda$44); } private static final Optional resources$lambda$44(Function1 $lookupFunction, ServerRequest it) {
/* 639 */     Intrinsics.checkNotNullParameter($lookupFunction, "$lookupFunction"); Intrinsics.checkNotNullExpressionValue(it, "it"); return Optional.ofNullable($lookupFunction.invoke(it));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(@NotNull RouterFunction<ServerResponse> routerFunction) {
/* 649 */     Intrinsics.checkNotNullParameter(routerFunction, "routerFunction"); this.builder.add(routerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void filter(@NotNull Function2 filterFunction) {
/* 660 */     Intrinsics.checkNotNullParameter(filterFunction, "filterFunction"); this.builder.filter(filterFunction::filter$lambda$45);
/* 661 */   } private static final ServerResponse filter$lambda$45(Function2 $filterFunction, ServerRequest request, HandlerFunction<ServerResponse> next) { Intrinsics.checkNotNullParameter($filterFunction, "$filterFunction"); Intrinsics.checkNotNullExpressionValue(request, "request"); return (ServerResponse)$filterFunction.invoke(request, new RouterFunctionDsl$filter$1$1(next)); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Lorg/springframework/web/servlet/function/ServerResponse;", "handlerRequest", "Lorg/springframework/web/servlet/function/ServerRequest;", "invoke"}) static final class RouterFunctionDsl$filter$1$1 extends Lambda implements Function1<ServerRequest, ServerResponse> { @NotNull
/* 662 */     public final ServerResponse invoke(@NotNull ServerRequest handlerRequest) { Intrinsics.checkNotNullParameter(handlerRequest, "handlerRequest"); Intrinsics.checkNotNullExpressionValue(this.$next.handle(handlerRequest), "next.handle(handlerRequest)"); return this.$next.handle(handlerRequest); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     RouterFunctionDsl$filter$1$1(HandlerFunction<ServerResponse> $next) {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void before(@NotNull Function1 requestProcessor) {
/* 675 */     Intrinsics.checkNotNullParameter(requestProcessor, "requestProcessor"); this.builder.before(requestProcessor::before$lambda$46); } private static final ServerRequest before$lambda$46(Function1 $tmp0, ServerRequest p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerRequest)$tmp0.invoke(p0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void after(@NotNull Function2 responseProcessor) {
/* 686 */     Intrinsics.checkNotNullParameter(responseProcessor, "responseProcessor"); this.builder.after(responseProcessor::after$lambda$47); } private static final ServerResponse after$lambda$47(Function2 $tmp0, ServerRequest p0, ServerResponse p1) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(p0, p1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onError(@NotNull Function1 predicate, @NotNull Function2 responseProvider) {
/* 697 */     Intrinsics.checkNotNullParameter(predicate, "predicate"); Intrinsics.checkNotNullParameter(responseProvider, "responseProvider"); this.builder.onError(predicate::onError$lambda$48, responseProvider::onError$lambda$49); } private static final boolean onError$lambda$48(Function1 $tmp0, Throwable p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return ((Boolean)$tmp0.invoke(p0)).booleanValue(); } private static final ServerResponse onError$lambda$49(Function2 $tmp0, Throwable p0, ServerRequest p1) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (ServerResponse)$tmp0.invoke(p0, p1); }
/*     */ 
/*     */   
/*     */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\020\003\n\002\b\003\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\0032\016\020\004\032\n \005*\004\030\0010\0030\003H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "E", "", "it", "kotlin.jvm.PlatformType", "test"})
/*     */   @SourceDebugExtension({"SMAP\nRouterFunctionDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RouterFunctionDsl.kt\norg/springframework/web/servlet/function/RouterFunctionDsl$onError$1\n*L\n1#1,817:1\n*E\n"})
/*     */   public static final class RouterFunctionDsl$onError$1<T>
/*     */     implements Predicate
/*     */   {
/*     */     public static final RouterFunctionDsl$onError$1<T> INSTANCE = new RouterFunctionDsl$onError$1();
/*     */     
/*     */     public final boolean test(Throwable it) {
/* 708 */       Intrinsics.reifiedOperationMarker(3, "E"); return it instanceof Throwable;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void withAttribute(@NotNull String name, @NotNull Object value) {
/* 718 */     Intrinsics.checkNotNullParameter(name, "name"); Intrinsics.checkNotNullParameter(value, "value"); this.builder.withAttribute(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void withAttributes(@NotNull Function1 attributesConsumer) {
/* 732 */     Intrinsics.checkNotNullParameter(attributesConsumer, "attributesConsumer"); this.builder.withAttributes(attributesConsumer::withAttributes$lambda$50); } private static final void withAttributes$lambda$50(Function1 $tmp0, Map p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); $tmp0.invoke(p0); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final RouterFunction<ServerResponse> build$spring_webmvc() {
/* 739 */     this.init.invoke(this);
/* 740 */     Intrinsics.checkNotNullExpressionValue(this.builder.build(), "builder.build()"); return this.builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder from(@NotNull ServerResponse other) {
/* 747 */     Intrinsics.checkNotNullParameter(other, "other"); return ServerResponse.from(other);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder created(@NotNull URI location) {
/* 753 */     Intrinsics.checkNotNullParameter(location, "location"); return ServerResponse.created(location);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder ok() {
/* 758 */     return ServerResponse.ok();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.HeadersBuilder<?> noContent() {
/* 763 */     return ServerResponse.noContent();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder accepted() {
/* 768 */     return ServerResponse.accepted();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder permanentRedirect(@NotNull URI location) {
/* 773 */     Intrinsics.checkNotNullParameter(location, "location"); return ServerResponse.permanentRedirect(location);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder temporaryRedirect(@NotNull URI location) {
/* 778 */     Intrinsics.checkNotNullParameter(location, "location"); return ServerResponse.temporaryRedirect(location);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder seeOther(@NotNull URI location) {
/* 783 */     Intrinsics.checkNotNullParameter(location, "location"); return ServerResponse.seeOther(location);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder badRequest() {
/* 788 */     return ServerResponse.badRequest();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.HeadersBuilder<?> notFound() {
/* 793 */     return ServerResponse.notFound();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder unprocessableEntity() {
/* 798 */     return ServerResponse.unprocessableEntity();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder status(@NotNull HttpStatusCode status) {
/* 803 */     Intrinsics.checkNotNullParameter(status, "status"); return ServerResponse.status(status);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerResponse.BodyBuilder status(int status) {
/* 808 */     return ServerResponse.status(status);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunctionDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */