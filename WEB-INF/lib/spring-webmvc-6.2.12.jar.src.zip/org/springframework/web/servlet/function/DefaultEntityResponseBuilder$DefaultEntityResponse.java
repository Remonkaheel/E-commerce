/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.SmartHttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultEntityResponse<T>
/*     */   extends AbstractServerResponse
/*     */   implements EntityResponse<T>
/*     */ {
/*     */   private final T entity;
/*     */   private final Type entityType;
/*     */   
/*     */   public DefaultEntityResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, T entity, Type entityType) {
/* 252 */     super(statusCode, headers, cookies);
/* 253 */     this.entity = entity;
/* 254 */     this.entityType = entityType;
/*     */   }
/*     */ 
/*     */   
/*     */   public T entity() {
/* 259 */     return this.entity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ModelAndView writeToInternal(HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context) throws ServletException, IOException {
/* 268 */     writeEntityWithMessageConverters(this.entity, servletRequest, servletResponse, context);
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeEntityWithMessageConverters(Object entity, HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/* 277 */     ServletServerHttpResponse serverResponse = new ServletServerHttpResponse(response);
/* 278 */     MediaType contentType = getContentType(response);
/* 279 */     Class<?> entityClass = entity.getClass();
/* 280 */     Type entityType = this.entityType;
/*     */     
/* 282 */     if (entityClass != InputStreamResource.class && Resource.class.isAssignableFrom(entityClass)) {
/* 283 */       serverResponse.getHeaders().set("Accept-Ranges", "bytes");
/* 284 */       String rangeHeader = request.getHeader("Range");
/* 285 */       if (rangeHeader != null) {
/* 286 */         Resource resource = (Resource)entity;
/*     */         try {
/* 288 */           List<HttpRange> httpRanges = HttpRange.parseRanges(rangeHeader);
/* 289 */           serverResponse.getServletResponse().setStatus(HttpStatus.PARTIAL_CONTENT.value());
/* 290 */           entity = HttpRange.toResourceRegions(httpRanges, resource);
/* 291 */           entityClass = entity.getClass();
/* 292 */           entityType = DefaultEntityResponseBuilder.RESOURCE_REGION_LIST_TYPE;
/*     */         }
/* 294 */         catch (IllegalArgumentException ex) {
/* 295 */           serverResponse.getHeaders().set("Content-Range", "bytes */" + resource.contentLength());
/* 296 */           serverResponse.getServletResponse().setStatus(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE.value());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     for (HttpMessageConverter<?> messageConverter : context.messageConverters()) {
/* 302 */       if (messageConverter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/* 303 */         if (genericMessageConverter.canWrite(entityType, entityClass, contentType)) {
/* 304 */           genericMessageConverter.write(entity, entityType, contentType, (HttpOutputMessage)serverResponse); return;
/*     */         } 
/*     */         continue; }
/*     */       
/* 308 */       if (messageConverter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter smartMessageConverter = (SmartHttpMessageConverter)messageConverter;
/* 309 */         ResolvableType resolvableType = ResolvableType.forType(entityType);
/* 310 */         if (smartMessageConverter.canWrite(resolvableType, entityClass, contentType)) {
/* 311 */           smartMessageConverter.write(entity, resolvableType, contentType, (HttpOutputMessage)serverResponse, null); return;
/*     */         } 
/*     */         continue; }
/*     */       
/* 315 */       if (messageConverter.canWrite(entityClass, contentType)) {
/* 316 */         messageConverter.write(entity, contentType, (HttpOutputMessage)serverResponse);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 321 */     List<MediaType> producibleMediaTypes = producibleMediaTypes(context.messageConverters(), entityClass);
/* 322 */     throw new HttpMediaTypeNotAcceptableException(producibleMediaTypes);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static MediaType getContentType(HttpServletResponse response) {
/*     */     try {
/* 328 */       return MediaType.parseMediaType(response.getContentType()).removeQualityValue();
/*     */     }
/* 330 */     catch (InvalidMediaTypeException ex) {
/* 331 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void tryWriteEntityWithMessageConverters(Object entity, HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/*     */     try {
/* 338 */       writeEntityWithMessageConverters(entity, request, response, context);
/*     */     }
/* 340 */     catch (IOException|ServletException ex) {
/* 341 */       handleError(ex, request, response, context);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<MediaType> producibleMediaTypes(List<HttpMessageConverter<?>> messageConverters, Class<?> entityClass) {
/* 349 */     return messageConverters.stream()
/* 350 */       .filter(messageConverter -> messageConverter.canWrite(entityClass, null))
/* 351 */       .flatMap(messageConverter -> messageConverter.getSupportedMediaTypes(entityClass).stream())
/* 352 */       .toList();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultEntityResponseBuilder$DefaultEntityResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */