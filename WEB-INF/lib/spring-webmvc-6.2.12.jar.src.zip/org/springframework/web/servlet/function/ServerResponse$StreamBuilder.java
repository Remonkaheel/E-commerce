package org.springframework.web.servlet.function;

import java.io.IOException;
import java.util.function.Consumer;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;

public interface StreamBuilder {
  void error(Throwable paramThrowable);
  
  void complete();
  
  StreamBuilder onTimeout(Runnable paramRunnable);
  
  StreamBuilder onError(Consumer<Throwable> paramConsumer);
  
  StreamBuilder onComplete(Runnable paramRunnable);
  
  StreamBuilder write(Object paramObject) throws IOException;
  
  StreamBuilder write(Object paramObject, @Nullable MediaType paramMediaType) throws IOException;
  
  void flush() throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse$StreamBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */