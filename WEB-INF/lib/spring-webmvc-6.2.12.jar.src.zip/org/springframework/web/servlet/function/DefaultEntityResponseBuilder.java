/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.time.Instant;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletionStage;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.SmartHttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultEntityResponseBuilder<T>
/*     */   implements EntityResponse.Builder<T>
/*     */ {
/*  77 */   private static final Type RESOURCE_REGION_LIST_TYPE = (new ParameterizedTypeReference<List<ResourceRegion>>() {  }
/*  78 */     ).getType();
/*     */ 
/*     */   
/*     */   private final T entity;
/*     */   
/*     */   private final Type entityType;
/*     */   
/*  85 */   private HttpStatusCode status = (HttpStatusCode)HttpStatus.OK;
/*     */   
/*  87 */   private final HttpHeaders headers = new HttpHeaders();
/*     */   
/*  89 */   private final MultiValueMap<String, Cookie> cookies = (MultiValueMap<String, Cookie>)new LinkedMultiValueMap();
/*     */ 
/*     */   
/*     */   private DefaultEntityResponseBuilder(T entity, @Nullable Type entityType) {
/*  93 */     this.entity = entity;
/*  94 */     this.entityType = (entityType != null) ? entityType : entity.getClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> status(HttpStatusCode status) {
/*  99 */     Assert.notNull(status, "HttpStatusCode must not be null");
/* 100 */     this.status = status;
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> status(int status) {
/* 106 */     return status(HttpStatusCode.valueOf(status));
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> cookie(Cookie cookie) {
/* 111 */     Assert.notNull(cookie, "Cookie must not be null");
/* 112 */     this.cookies.add(cookie.getName(), cookie);
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> cookies(Consumer<MultiValueMap<String, Cookie>> cookiesConsumer) {
/* 119 */     Assert.notNull(cookiesConsumer, "cookiesConsumer must not be null");
/* 120 */     cookiesConsumer.accept(this.cookies);
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> header(String headerName, String... headerValues) {
/* 126 */     Assert.notNull(headerName, "headerName must not be null");
/* 127 */     for (String headerValue : headerValues) {
/* 128 */       this.headers.add(headerName, headerValue);
/*     */     }
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> headers(Consumer<HttpHeaders> headersConsumer) {
/* 135 */     Assert.notNull(headersConsumer, "headersConsumer must not be null");
/* 136 */     headersConsumer.accept(this.headers);
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> allow(HttpMethod... allowedMethods) {
/* 142 */     Assert.notNull(allowedMethods, "allowedMethods must not be null");
/* 143 */     this.headers.setAllow(new LinkedHashSet(Arrays.asList((Object[])allowedMethods)));
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> allow(Set<HttpMethod> allowedMethods) {
/* 149 */     Assert.notNull(allowedMethods, "allowedMethods must not be null");
/* 150 */     this.headers.setAllow(allowedMethods);
/* 151 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> contentLength(long contentLength) {
/* 156 */     this.headers.setContentLength(contentLength);
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> contentType(MediaType contentType) {
/* 162 */     Assert.notNull(contentType, "contentType must not be null");
/* 163 */     this.headers.setContentType(contentType);
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> eTag(String tag) {
/* 169 */     this.headers.setETag(tag);
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> lastModified(ZonedDateTime lastModified) {
/* 175 */     Assert.notNull(lastModified, "lastModified must not be null");
/* 176 */     this.headers.setLastModified(lastModified);
/* 177 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> lastModified(Instant lastModified) {
/* 182 */     Assert.notNull(lastModified, "lastModified must not be null");
/* 183 */     this.headers.setLastModified(lastModified);
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> location(URI location) {
/* 189 */     Assert.notNull(location, "location must not be null");
/* 190 */     this.headers.setLocation(location);
/* 191 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> cacheControl(CacheControl cacheControl) {
/* 196 */     Assert.notNull(cacheControl, "cacheControl must not be null");
/* 197 */     this.headers.setCacheControl(cacheControl);
/* 198 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityResponse.Builder<T> varyBy(String... requestHeaders) {
/* 203 */     this.headers.setVary(Arrays.asList(requestHeaders));
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityResponse<T> build() {
/* 210 */     T t = this.entity; if (t instanceof CompletionStage) { CompletionStage<?> completionStage = (CompletionStage)t;
/* 211 */       return new CompletionStageEntityResponse(this.status, this.headers, this.cookies, completionStage, this.entityType); }
/*     */ 
/*     */     
/* 214 */     if (DefaultAsyncServerResponse.reactiveStreamsPresent) {
/* 215 */       ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(this.entity.getClass());
/* 216 */       if (adapter != null) {
/* 217 */         Publisher<T> publisher = adapter.toPublisher(this.entity);
/* 218 */         return (EntityResponse<T>)new PublisherEntityResponse<>(this.status, this.headers, this.cookies, publisher, this.entityType);
/*     */       } 
/*     */     } 
/* 221 */     return new DefaultEntityResponse<>(this.status, this.headers, this.cookies, this.entity, this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> EntityResponse.Builder<T> fromObject(T t) {
/* 229 */     return new DefaultEntityResponseBuilder<>(t, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> EntityResponse.Builder<T> fromObject(T t, ParameterizedTypeReference<?> bodyType) {
/* 236 */     return new DefaultEntityResponseBuilder<>(t, bodyType.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultEntityResponse<T>
/*     */     extends AbstractServerResponse
/*     */     implements EntityResponse<T>
/*     */   {
/*     */     private final T entity;
/*     */ 
/*     */     
/*     */     private final Type entityType;
/*     */ 
/*     */     
/*     */     public DefaultEntityResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, T entity, Type entityType) {
/* 252 */       super(statusCode, headers, cookies);
/* 253 */       this.entity = entity;
/* 254 */       this.entityType = entityType;
/*     */     }
/*     */ 
/*     */     
/*     */     public T entity() {
/* 259 */       return this.entity;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected ModelAndView writeToInternal(HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context) throws ServletException, IOException {
/* 268 */       writeEntityWithMessageConverters(this.entity, servletRequest, servletResponse, context);
/* 269 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void writeEntityWithMessageConverters(Object entity, HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/* 277 */       ServletServerHttpResponse serverResponse = new ServletServerHttpResponse(response);
/* 278 */       MediaType contentType = getContentType(response);
/* 279 */       Class<?> entityClass = entity.getClass();
/* 280 */       Type entityType = this.entityType;
/*     */       
/* 282 */       if (entityClass != InputStreamResource.class && Resource.class.isAssignableFrom(entityClass)) {
/* 283 */         serverResponse.getHeaders().set("Accept-Ranges", "bytes");
/* 284 */         String rangeHeader = request.getHeader("Range");
/* 285 */         if (rangeHeader != null) {
/* 286 */           Resource resource = (Resource)entity;
/*     */           try {
/* 288 */             List<HttpRange> httpRanges = HttpRange.parseRanges(rangeHeader);
/* 289 */             serverResponse.getServletResponse().setStatus(HttpStatus.PARTIAL_CONTENT.value());
/* 290 */             entity = HttpRange.toResourceRegions(httpRanges, resource);
/* 291 */             entityClass = entity.getClass();
/* 292 */             entityType = DefaultEntityResponseBuilder.RESOURCE_REGION_LIST_TYPE;
/*     */           }
/* 294 */           catch (IllegalArgumentException ex) {
/* 295 */             serverResponse.getHeaders().set("Content-Range", "bytes */" + resource.contentLength());
/* 296 */             serverResponse.getServletResponse().setStatus(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE.value());
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 301 */       for (HttpMessageConverter<?> messageConverter : context.messageConverters()) {
/* 302 */         if (messageConverter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/* 303 */           if (genericMessageConverter.canWrite(entityType, entityClass, contentType)) {
/* 304 */             genericMessageConverter.write(entity, entityType, contentType, (HttpOutputMessage)serverResponse); return;
/*     */           } 
/*     */           continue; }
/*     */         
/* 308 */         if (messageConverter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter smartMessageConverter = (SmartHttpMessageConverter)messageConverter;
/* 309 */           ResolvableType resolvableType = ResolvableType.forType(entityType);
/* 310 */           if (smartMessageConverter.canWrite(resolvableType, entityClass, contentType)) {
/* 311 */             smartMessageConverter.write(entity, resolvableType, contentType, (HttpOutputMessage)serverResponse, null); return;
/*     */           } 
/*     */           continue; }
/*     */         
/* 315 */         if (messageConverter.canWrite(entityClass, contentType)) {
/* 316 */           messageConverter.write(entity, contentType, (HttpOutputMessage)serverResponse);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 321 */       List<MediaType> producibleMediaTypes = producibleMediaTypes(context.messageConverters(), entityClass);
/* 322 */       throw new HttpMediaTypeNotAcceptableException(producibleMediaTypes);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private static MediaType getContentType(HttpServletResponse response) {
/*     */       try {
/* 328 */         return MediaType.parseMediaType(response.getContentType()).removeQualityValue();
/*     */       }
/* 330 */       catch (InvalidMediaTypeException ex) {
/* 331 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void tryWriteEntityWithMessageConverters(Object entity, HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/*     */       try {
/* 338 */         writeEntityWithMessageConverters(entity, request, response, context);
/*     */       }
/* 340 */       catch (IOException|ServletException ex) {
/* 341 */         handleError(ex, request, response, context);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static List<MediaType> producibleMediaTypes(List<HttpMessageConverter<?>> messageConverters, Class<?> entityClass) {
/* 349 */       return messageConverters.stream()
/* 350 */         .filter(messageConverter -> messageConverter.canWrite(entityClass, null))
/* 351 */         .flatMap(messageConverter -> messageConverter.getSupportedMediaTypes(entityClass).stream())
/* 352 */         .toList();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CompletionStageEntityResponse<T>
/*     */     extends DefaultEntityResponse<CompletionStage<T>>
/*     */   {
/*     */     public CompletionStageEntityResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, CompletionStage<T> entity, Type entityType) {
/* 366 */       super(statusCode, headers, cookies, entity, entityType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected ModelAndView writeToInternal(HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context) throws ServletException, IOException {
/* 374 */       DeferredResult<ServerResponse> deferredResult = createDeferredResult(servletRequest, servletResponse, context);
/* 375 */       DefaultAsyncServerResponse.writeAsync(servletRequest, servletResponse, deferredResult);
/* 376 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private DeferredResult<ServerResponse> createDeferredResult(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) {
/* 382 */       DeferredResult<ServerResponse> result = new DeferredResult();
/* 383 */       entity().whenComplete((value, ex) -> {
/*     */             if (ex != null) {
/*     */               if (ex instanceof java.util.concurrent.CompletionException && ex.getCause() != null) {
/*     */                 ex = ex.getCause();
/*     */               }
/*     */               
/*     */               ServerResponse errorResponse = errorResponse(ex, request);
/*     */               
/*     */               if (errorResponse != null) {
/*     */                 result.setResult(errorResponse);
/*     */               } else {
/*     */                 result.setErrorResult(ex);
/*     */               } 
/*     */             } else {
/*     */               try {
/*     */                 tryWriteEntityWithMessageConverters(value, request, response, context);
/*     */                 
/*     */                 result.setResult(null);
/* 401 */               } catch (ServletException|IOException writeException) {
/*     */                 result.setErrorResult(writeException);
/*     */               } 
/*     */             } 
/*     */           });
/* 406 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PublisherEntityResponse<T>
/*     */     extends DefaultEntityResponse<Publisher<T>>
/*     */   {
/*     */     public PublisherEntityResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, Publisher<T> entity, Type entityType) {
/* 420 */       super(statusCode, headers, cookies, entity, entityType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected ModelAndView writeToInternal(HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context) throws ServletException, IOException {
/* 428 */       DeferredResult<?> deferredResult = new DeferredResult();
/* 429 */       DefaultAsyncServerResponse.writeAsync(servletRequest, servletResponse, deferredResult);
/*     */       
/* 431 */       entity().subscribe(new DeferredResultSubscriber(servletRequest, servletResponse, context, deferredResult));
/* 432 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private class DeferredResultSubscriber
/*     */       implements Subscriber<T>
/*     */     {
/*     */       private final HttpServletRequest servletRequest;
/*     */ 
/*     */       
/*     */       private final HttpServletResponse servletResponse;
/*     */       
/*     */       private final ServerResponse.Context context;
/*     */       
/*     */       private final DeferredResult<?> deferredResult;
/*     */       
/*     */       @Nullable
/*     */       private Subscription subscription;
/*     */ 
/*     */       
/*     */       public DeferredResultSubscriber(HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context, DeferredResult<?> deferredResult) {
/* 454 */         this.servletRequest = servletRequest;
/* 455 */         this.servletResponse = (HttpServletResponse)new DefaultEntityResponseBuilder.PublisherEntityResponse.NoContentLengthResponseWrapper(servletResponse);
/* 456 */         this.context = context;
/* 457 */         this.deferredResult = deferredResult;
/*     */       }
/*     */ 
/*     */       
/*     */       public void onSubscribe(Subscription s) {
/* 462 */         if (this.subscription == null) {
/* 463 */           this.subscription = s;
/* 464 */           this.subscription.request(1L);
/*     */         } else {
/*     */           
/* 467 */           s.cancel();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public void onNext(T t) {
/* 473 */         Assert.state((this.subscription != null), "No subscription");
/*     */         try {
/* 475 */           DefaultEntityResponseBuilder.PublisherEntityResponse.this.tryWriteEntityWithMessageConverters(t, this.servletRequest, this.servletResponse, this.context);
/* 476 */           this.servletResponse.getOutputStream().flush();
/* 477 */           this.subscription.request(1L);
/*     */         }
/* 479 */         catch (ServletException|IOException ex) {
/* 480 */           this.subscription.cancel();
/* 481 */           this.deferredResult.setErrorResult(ex);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public void onError(Throwable t) {
/*     */         try {
/* 488 */           DefaultEntityResponseBuilder.PublisherEntityResponse.this.handleError(t, this.servletRequest, this.servletResponse, this.context);
/*     */         }
/* 490 */         catch (ServletException|IOException handlingThrowable) {
/* 491 */           this.deferredResult.setErrorResult(handlingThrowable);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public void onComplete() {
/*     */         try {
/* 498 */           this.servletResponse.getOutputStream().flush();
/* 499 */           this.deferredResult.setResult(null);
/*     */         }
/* 501 */         catch (IOException ex) {
/* 502 */           this.deferredResult.setErrorResult(ex);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private static class NoContentLengthResponseWrapper
/*     */       extends HttpServletResponseWrapper
/*     */     {
/*     */       public NoContentLengthResponseWrapper(HttpServletResponse response) {
/* 512 */         super(response);
/*     */       }
/*     */ 
/*     */       
/*     */       public void addIntHeader(String name, int value) {
/* 517 */         if (!"Content-Length".equals(name))
/* 518 */           super.addIntHeader(name, value); 
/*     */       }
/*     */       
/*     */       public void setContentLength(int len) {}
/*     */       public void setContentLengthLong(long len) {}
/*     */       
/* 524 */       public void addHeader(String name, String value) { if (!"Content-Length".equals(name))
/* 525 */           super.addHeader(name, value);  } } } private class DeferredResultSubscriber implements Subscriber<T> { private final HttpServletRequest servletRequest; private final HttpServletResponse servletResponse; private final ServerResponse.Context context; private final DeferredResult<?> deferredResult; @Nullable private Subscription subscription; public DeferredResultSubscriber(HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context, DeferredResult<?> deferredResult) { this.servletRequest = servletRequest; this.servletResponse = (HttpServletResponse)new DefaultEntityResponseBuilder.PublisherEntityResponse.NoContentLengthResponseWrapper(servletResponse); this.context = context; this.deferredResult = deferredResult; } public void onSubscribe(Subscription s) { if (this.subscription == null) { this.subscription = s; this.subscription.request(1L); } else { s.cancel(); }  } public void onNext(T t) { Assert.state((this.subscription != null), "No subscription"); try { this.this$0.tryWriteEntityWithMessageConverters(t, this.servletRequest, this.servletResponse, this.context); this.servletResponse.getOutputStream().flush(); this.subscription.request(1L); } catch (ServletException|IOException ex) { this.subscription.cancel(); this.deferredResult.setErrorResult(ex); }  } public void onError(Throwable t) { try { this.this$0.handleError(t, this.servletRequest, this.servletResponse, this.context); } catch (ServletException|IOException handlingThrowable) { this.deferredResult.setErrorResult(handlingThrowable); }  } public void onComplete() { try { this.servletResponse.getOutputStream().flush(); this.deferredResult.setResult(null); } catch (IOException ex) { this.deferredResult.setErrorResult(ex); }  } } private static class NoContentLengthResponseWrapper extends HttpServletResponseWrapper { public void addHeader(String name, String value) { if (!"Content-Length".equals(name)) super.addHeader(name, value);  }
/*     */ 
/*     */     
/*     */     public NoContentLengthResponseWrapper(HttpServletResponse response) {
/*     */       super(response);
/*     */     }
/*     */     
/*     */     public void addIntHeader(String name, int value) {
/*     */       if (!"Content-Length".equals(name))
/*     */         super.addIntHeader(name, value); 
/*     */     }
/*     */     
/*     */     public void setContentLength(int len) {}
/*     */     
/*     */     public void setContentLengthLong(long len) {} }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultEntityResponseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */