package org.springframework.web.servlet.function;

import java.util.Set;
import org.springframework.http.HttpMethod;

public interface Visitor {
  void method(Set<HttpMethod> paramSet);
  
  void path(String paramString);
  
  void pathExtension(String paramString);
  
  void header(String paramString1, String paramString2);
  
  void param(String paramString1, String paramString2);
  
  void startAnd();
  
  void and();
  
  void endAnd();
  
  void startOr();
  
  void or();
  
  void endOr();
  
  void startNegate();
  
  void endNegate();
  
  void unknown(RequestPredicate paramRequestPredicate);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RequestPredicates$Visitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */