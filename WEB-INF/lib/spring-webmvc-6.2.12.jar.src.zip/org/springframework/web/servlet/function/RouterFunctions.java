/*      */ package org.springframework.web.servlet.function;
/*      */ 
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.http.HttpHeaders;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.web.util.pattern.PathPatternParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class RouterFunctions
/*      */ {
/*   53 */   private static final Log logger = LogFactory.getLog(RouterFunctions.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   58 */   public static final String REQUEST_ATTRIBUTE = RouterFunctions.class.getName() + ".request";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   64 */   public static final String URI_TEMPLATE_VARIABLES_ATTRIBUTE = RouterFunctions.class
/*   65 */     .getName() + ".uriTemplateVariables";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   71 */   public static final String MATCHING_PATTERN_ATTRIBUTE = RouterFunctions.class
/*   72 */     .getName() + ".matchingPattern";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Builder route() {
/*   80 */     return new RouterFunctionBuilder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ServerResponse> RouterFunction<T> route(RequestPredicate predicate, HandlerFunction<T> handlerFunction) {
/*  101 */     return new DefaultRouterFunction<>(predicate, handlerFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ServerResponse> RouterFunction<T> nest(RequestPredicate predicate, RouterFunction<T> routerFunction) {
/*  129 */     return new DefaultNestedRouterFunction<>(predicate, routerFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RouterFunction<ServerResponse> resource(RequestPredicate predicate, Resource resource) {
/*  145 */     return resources(new PredicateResourceLookupFunction(predicate, resource), (consumerResource, httpHeaders) -> {
/*      */         
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RouterFunction<ServerResponse> resource(RequestPredicate predicate, Resource resource, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/*  164 */     return resources(new PredicateResourceLookupFunction(predicate, resource), headersConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RouterFunction<ServerResponse> resources(String pattern, Resource location) {
/*  181 */     return resources(resourceLookupFunction(pattern, location), (resource, httpHeaders) -> {
/*      */         
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RouterFunction<ServerResponse> resources(String pattern, Resource location, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/*  202 */     return resources(resourceLookupFunction(pattern, location), headersConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Function<ServerRequest, Optional<Resource>> resourceLookupFunction(String pattern, Resource location) {
/*  222 */     return new PathResourceLookupFunction(pattern, location);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RouterFunction<ServerResponse> resources(Function<ServerRequest, Optional<Resource>> lookupFunction) {
/*  233 */     return new ResourcesRouterFunction(lookupFunction, (resource, httpHeaders) -> {
/*      */         
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RouterFunction<ServerResponse> resources(Function<ServerRequest, Optional<Resource>> lookupFunction, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/*  248 */     return new ResourcesRouterFunction(lookupFunction, headersConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ServerResponse> RouterFunction<T> changeParser(RouterFunction<T> routerFunction, PathPatternParser parser) {
/*  264 */     Assert.notNull(routerFunction, "RouterFunction must not be null");
/*  265 */     Assert.notNull(parser, "Parser must not be null");
/*      */     
/*  267 */     ChangePathPatternParserVisitor visitor = new ChangePathPatternParserVisitor(parser);
/*  268 */     routerFunction.accept(visitor);
/*  269 */     return routerFunction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class AbstractRouterFunction<T extends ServerResponse>
/*      */     implements RouterFunction<T>
/*      */   {
/*      */     public String toString() {
/* 1011 */       ToStringVisitor visitor = new ToStringVisitor();
/* 1012 */       accept(visitor);
/* 1013 */       return visitor.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class SameComposedRouterFunction<T extends ServerResponse>
/*      */     extends AbstractRouterFunction<T>
/*      */   {
/*      */     private final RouterFunction<T> first;
/*      */ 
/*      */     
/*      */     private final RouterFunction<T> second;
/*      */ 
/*      */ 
/*      */     
/*      */     public SameComposedRouterFunction(RouterFunction<T> first, RouterFunction<T> second) {
/* 1031 */       this.first = first;
/* 1032 */       this.second = second;
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<T>> route(ServerRequest request) {
/* 1037 */       Optional<HandlerFunction<T>> firstRoute = this.first.route(request);
/* 1038 */       if (firstRoute.isPresent()) {
/* 1039 */         return firstRoute;
/*      */       }
/*      */       
/* 1042 */       return this.second.route(request);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1048 */       this.first.accept(visitor);
/* 1049 */       this.second.accept(visitor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class DifferentComposedRouterFunction
/*      */     extends AbstractRouterFunction<ServerResponse>
/*      */   {
/*      */     private final RouterFunction<?> first;
/*      */ 
/*      */     
/*      */     private final RouterFunction<?> second;
/*      */ 
/*      */ 
/*      */     
/*      */     public DifferentComposedRouterFunction(RouterFunction<?> first, RouterFunction<?> second) {
/* 1066 */       this.first = first;
/* 1067 */       this.second = second;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<ServerResponse>> route(ServerRequest request) {
/* 1073 */       Optional<? extends HandlerFunction<?>> firstRoute = this.first.route(request);
/* 1074 */       if (firstRoute.isPresent()) {
/* 1075 */         return (Optional)firstRoute;
/*      */       }
/*      */       
/* 1078 */       Optional<? extends HandlerFunction<?>> secondRoute = this.second.route(request);
/* 1079 */       return (Optional)secondRoute;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1085 */       this.first.accept(visitor);
/* 1086 */       this.second.accept(visitor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class FilteredRouterFunction<T extends ServerResponse, S extends ServerResponse>
/*      */     implements RouterFunction<S>
/*      */   {
/*      */     private final RouterFunction<T> routerFunction;
/*      */ 
/*      */ 
/*      */     
/*      */     private final HandlerFilterFunction<T, S> filterFunction;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FilteredRouterFunction(RouterFunction<T> routerFunction, HandlerFilterFunction<T, S> filterFunction) {
/* 1107 */       this.routerFunction = routerFunction;
/* 1108 */       this.filterFunction = filterFunction;
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<S>> route(ServerRequest request) {
/* 1113 */       Objects.requireNonNull(this.filterFunction); return this.routerFunction.route(request).map(this.filterFunction::apply);
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1118 */       this.routerFunction.accept(visitor);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1123 */       return this.routerFunction.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class DefaultRouterFunction<T extends ServerResponse>
/*      */     extends AbstractRouterFunction<T>
/*      */   {
/*      */     private final RequestPredicate predicate;
/*      */     private final HandlerFunction<T> handlerFunction;
/*      */     
/*      */     public DefaultRouterFunction(RequestPredicate predicate, HandlerFunction<T> handlerFunction) {
/* 1135 */       Assert.notNull(predicate, "Predicate must not be null");
/* 1136 */       Assert.notNull(handlerFunction, "HandlerFunction must not be null");
/* 1137 */       this.predicate = predicate;
/* 1138 */       this.handlerFunction = handlerFunction;
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<T>> route(ServerRequest request) {
/* 1143 */       if (this.predicate.test(request)) {
/* 1144 */         if (RouterFunctions.logger.isTraceEnabled()) {
/* 1145 */           RouterFunctions.logger.trace(String.format("Predicate \"%s\" matches against \"%s\"", new Object[] { this.predicate, request }));
/*      */         }
/* 1147 */         return Optional.of(this.handlerFunction);
/*      */       } 
/*      */       
/* 1150 */       return Optional.empty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1156 */       visitor.route(this.predicate, this.handlerFunction);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class DefaultNestedRouterFunction<T extends ServerResponse>
/*      */     extends AbstractRouterFunction<T>
/*      */   {
/*      */     private final RequestPredicate predicate;
/*      */     private final RouterFunction<T> routerFunction;
/*      */     
/*      */     public DefaultNestedRouterFunction(RequestPredicate predicate, RouterFunction<T> routerFunction) {
/* 1168 */       Assert.notNull(predicate, "Predicate must not be null");
/* 1169 */       Assert.notNull(routerFunction, "RouterFunction must not be null");
/* 1170 */       this.predicate = predicate;
/* 1171 */       this.routerFunction = routerFunction;
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<T>> route(ServerRequest serverRequest) {
/* 1176 */       return this.predicate.nest(serverRequest)
/* 1177 */         .<Optional<HandlerFunction<T>>>map(nestedRequest -> {
/*      */             if (RouterFunctions.logger.isTraceEnabled()) {
/*      */               RouterFunctions.logger.trace(String.format("Nested predicate \"%s\" matches against \"%s\"", new Object[] { this.predicate, serverRequest }));
/*      */             }
/*      */             
/*      */             Optional<HandlerFunction<T>> result = this.routerFunction.route(nestedRequest);
/*      */             
/*      */             if (result.isPresent() && nestedRequest != serverRequest) {
/*      */               Map<String, Object> newAttributes = new LinkedHashMap<>(nestedRequest.attributes());
/*      */               
/*      */               Map<String, Object> oldAttributes = serverRequest.attributes();
/*      */               
/*      */               oldAttributes.clear();
/*      */               
/*      */               oldAttributes.putAll(newAttributes);
/*      */             } 
/*      */             
/*      */             return result;
/* 1195 */           }).orElseGet(Optional::empty);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1201 */       visitor.startNested(this.predicate);
/* 1202 */       this.routerFunction.accept(visitor);
/* 1203 */       visitor.endNested(this.predicate);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class ResourcesRouterFunction
/*      */     extends AbstractRouterFunction<ServerResponse>
/*      */   {
/*      */     private final Function<ServerRequest, Optional<Resource>> lookupFunction;
/*      */     
/*      */     private final BiConsumer<Resource, HttpHeaders> headersConsumer;
/*      */ 
/*      */     
/*      */     public ResourcesRouterFunction(Function<ServerRequest, Optional<Resource>> lookupFunction, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/* 1217 */       Assert.notNull(lookupFunction, "Lookup function must not be null");
/* 1218 */       Assert.notNull(headersConsumer, "Headers consumer must not be null");
/* 1219 */       this.lookupFunction = lookupFunction;
/* 1220 */       this.headersConsumer = headersConsumer;
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<ServerResponse>> route(ServerRequest request) {
/* 1225 */       return ((Optional)this.lookupFunction.apply(request)).map(resource -> new ResourceHandlerFunction(resource, this.headersConsumer));
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1230 */       visitor.resources(this.lookupFunction);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class AttributesRouterFunction<T extends ServerResponse>
/*      */     extends AbstractRouterFunction<T>
/*      */   {
/*      */     private final RouterFunction<T> delegate;
/*      */     private final Map<String, Object> attributes;
/*      */     
/*      */     public AttributesRouterFunction(RouterFunction<T> delegate, Map<String, Object> attributes) {
/* 1242 */       this.delegate = delegate;
/* 1243 */       this.attributes = initAttributes(attributes);
/*      */     }
/*      */     
/*      */     private static Map<String, Object> initAttributes(Map<String, Object> attributes) {
/* 1247 */       if (attributes.isEmpty()) {
/* 1248 */         return Collections.emptyMap();
/*      */       }
/*      */       
/* 1251 */       return Collections.unmodifiableMap(new LinkedHashMap<>(attributes));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Optional<HandlerFunction<T>> route(ServerRequest request) {
/* 1257 */       return this.delegate.route(request);
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RouterFunctions.Visitor visitor) {
/* 1262 */       visitor.attributes(this.attributes);
/* 1263 */       this.delegate.accept(visitor);
/*      */     }
/*      */ 
/*      */     
/*      */     public RouterFunction<T> withAttribute(String name, Object value) {
/* 1268 */       Assert.hasLength(name, "Name must not be empty");
/* 1269 */       Assert.notNull(value, "Value must not be null");
/*      */       
/* 1271 */       Map<String, Object> attributes = new LinkedHashMap<>(this.attributes);
/* 1272 */       attributes.put(name, value);
/* 1273 */       return new AttributesRouterFunction(this.delegate, attributes);
/*      */     }
/*      */ 
/*      */     
/*      */     public RouterFunction<T> withAttributes(Consumer<Map<String, Object>> attributesConsumer) {
/* 1278 */       Assert.notNull(attributesConsumer, "AttributesConsumer must not be null");
/*      */       
/* 1280 */       Map<String, Object> attributes = new LinkedHashMap<>(this.attributes);
/* 1281 */       attributesConsumer.accept(attributes);
/* 1282 */       return new AttributesRouterFunction(this.delegate, attributes);
/*      */     }
/*      */   }
/*      */   
/*      */   public static interface Visitor {
/*      */     void startNested(RequestPredicate param1RequestPredicate);
/*      */     
/*      */     void endNested(RequestPredicate param1RequestPredicate);
/*      */     
/*      */     void route(RequestPredicate param1RequestPredicate, HandlerFunction<?> param1HandlerFunction);
/*      */     
/*      */     void resources(Function<ServerRequest, Optional<Resource>> param1Function);
/*      */     
/*      */     void attributes(Map<String, Object> param1Map);
/*      */     
/*      */     void unknown(RouterFunction<?> param1RouterFunction);
/*      */   }
/*      */   
/*      */   public static interface Builder {
/*      */     Builder GET(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder GET(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder GET(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder GET(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder HEAD(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder HEAD(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder HEAD(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder HEAD(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder POST(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder POST(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder POST(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder POST(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PUT(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PUT(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PUT(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PUT(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PATCH(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PATCH(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PATCH(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder PATCH(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder DELETE(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder DELETE(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder DELETE(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder DELETE(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder OPTIONS(HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder OPTIONS(String param1String, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder OPTIONS(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder OPTIONS(String param1String, RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder route(RequestPredicate param1RequestPredicate, HandlerFunction<ServerResponse> param1HandlerFunction);
/*      */     
/*      */     Builder add(RouterFunction<ServerResponse> param1RouterFunction);
/*      */     
/*      */     Builder resource(RequestPredicate param1RequestPredicate, Resource param1Resource);
/*      */     
/*      */     Builder resource(RequestPredicate param1RequestPredicate, Resource param1Resource, BiConsumer<Resource, HttpHeaders> param1BiConsumer);
/*      */     
/*      */     Builder resources(String param1String, Resource param1Resource);
/*      */     
/*      */     Builder resources(String param1String, Resource param1Resource, BiConsumer<Resource, HttpHeaders> param1BiConsumer);
/*      */     
/*      */     Builder resources(Function<ServerRequest, Optional<Resource>> param1Function);
/*      */     
/*      */     Builder resources(Function<ServerRequest, Optional<Resource>> param1Function, BiConsumer<Resource, HttpHeaders> param1BiConsumer);
/*      */     
/*      */     Builder nest(RequestPredicate param1RequestPredicate, Supplier<RouterFunction<ServerResponse>> param1Supplier);
/*      */     
/*      */     Builder nest(RequestPredicate param1RequestPredicate, Consumer<Builder> param1Consumer);
/*      */     
/*      */     Builder path(String param1String, Supplier<RouterFunction<ServerResponse>> param1Supplier);
/*      */     
/*      */     Builder path(String param1String, Consumer<Builder> param1Consumer);
/*      */     
/*      */     Builder filter(HandlerFilterFunction<ServerResponse, ServerResponse> param1HandlerFilterFunction);
/*      */     
/*      */     Builder before(Function<ServerRequest, ServerRequest> param1Function);
/*      */     
/*      */     Builder after(BiFunction<ServerRequest, ServerResponse, ServerResponse> param1BiFunction);
/*      */     
/*      */     Builder onError(Predicate<Throwable> param1Predicate, BiFunction<Throwable, ServerRequest, ServerResponse> param1BiFunction);
/*      */     
/*      */     Builder onError(Class<? extends Throwable> param1Class, BiFunction<Throwable, ServerRequest, ServerResponse> param1BiFunction);
/*      */     
/*      */     Builder withAttribute(String param1String, Object param1Object);
/*      */     
/*      */     Builder withAttributes(Consumer<Map<String, Object>> param1Consumer);
/*      */     
/*      */     RouterFunction<ServerResponse> build();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunctions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */