/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.Part;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.time.Instant;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalLong;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.SmartHttpMessageConverter;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultServerRequest
/*     */   implements ServerRequest
/*     */ {
/*     */   private final ServletServerHttpRequest serverHttpRequest;
/*     */   private final RequestPath requestPath;
/*     */   private final ServerRequest.Headers headers;
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private final MultiValueMap<String, String> params;
/*     */   private final Map<String, Object> attributes;
/*     */   @Nullable
/*     */   private MultiValueMap<String, Part> parts;
/*     */   
/*     */   public DefaultServerRequest(HttpServletRequest servletRequest, List<HttpMessageConverter<?>> messageConverters) {
/* 109 */     this.serverHttpRequest = new ServletServerHttpRequest(servletRequest);
/* 110 */     this.messageConverters = List.copyOf(messageConverters);
/*     */     
/* 112 */     this.headers = new DefaultRequestHeaders(this.serverHttpRequest.getHeaders());
/* 113 */     this.params = CollectionUtils.toMultiValueMap(new ServletParametersMap(servletRequest));
/* 114 */     this.attributes = new ServletAttributesMap(servletRequest);
/*     */ 
/*     */ 
/*     */     
/* 118 */     this
/*     */       
/* 120 */       .requestPath = ServletRequestPathUtils.hasParsedRequestPath((ServletRequest)servletRequest) ? ServletRequestPathUtils.getParsedRequestPath((ServletRequest)servletRequest) : ServletRequestPathUtils.parseAndCache(servletRequest);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod method() {
/* 125 */     return HttpMethod.valueOf(servletRequest().getMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String methodName() {
/* 131 */     return servletRequest().getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI uri() {
/* 136 */     return this.serverHttpRequest.getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public UriBuilder uriBuilder() {
/* 141 */     return (UriBuilder)ServletUriComponentsBuilder.fromRequest(servletRequest());
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestPath requestPath() {
/* 146 */     return this.requestPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Headers headers() {
/* 151 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, Cookie> cookies() {
/* 156 */     Cookie[] cookies = servletRequest().getCookies();
/* 157 */     if (cookies == null) {
/* 158 */       cookies = new Cookie[0];
/*     */     }
/* 160 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap(cookies.length);
/* 161 */     for (Cookie cookie : cookies) {
/* 162 */       linkedMultiValueMap.add(cookie.getName(), cookie);
/*     */     }
/* 164 */     return (MultiValueMap<String, Cookie>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest servletRequest() {
/* 169 */     return this.serverHttpRequest.getServletRequest();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<InetSocketAddress> remoteAddress() {
/* 174 */     return Optional.of(this.serverHttpRequest.getRemoteAddress());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<HttpMessageConverter<?>> messageConverters() {
/* 179 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T body(Class<T> bodyType) throws IOException, ServletException {
/* 184 */     return bodyInternal(bodyType, bodyType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T body(ParameterizedTypeReference<T> bodyType) throws IOException, ServletException {
/* 189 */     Type type = bodyType.getType();
/* 190 */     return bodyInternal(type, bodyClass(type));
/*     */   }
/*     */   
/*     */   static Class<?> bodyClass(Type type) {
/* 194 */     if (type instanceof Class) { Class<?> clazz = (Class)type;
/* 195 */       return clazz; }
/*     */     
/* 197 */     if (type instanceof ParameterizedType) { ParameterizedType parameterizedType = (ParameterizedType)type;
/* 198 */       Type type1 = parameterizedType.getRawType(); if (type1 instanceof Class) { Class<?> rawType = (Class)type1;
/* 199 */         return rawType; }
/*     */        }
/* 201 */      return Object.class;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T bodyInternal(Type bodyType, Class<?> bodyClass) throws ServletException, IOException {
/* 206 */     MediaType contentType = this.headers.contentType().orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */     
/* 208 */     for (HttpMessageConverter<?> messageConverter : this.messageConverters) {
/* 209 */       if (messageConverter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter<?> genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/* 210 */         if (genericMessageConverter.canRead(bodyType, bodyClass, contentType))
/* 211 */           return (T)genericMessageConverter.read(bodyType, bodyClass, (HttpInputMessage)this.serverHttpRequest); 
/*     */         continue; }
/*     */       
/* 214 */       if (messageConverter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter<?> smartMessageConverter = (SmartHttpMessageConverter)messageConverter;
/* 215 */         ResolvableType resolvableType = ResolvableType.forType(bodyType);
/* 216 */         if (smartMessageConverter.canRead(resolvableType, contentType))
/* 217 */           return (T)smartMessageConverter.read(resolvableType, (HttpInputMessage)this.serverHttpRequest, null); 
/*     */         continue; }
/*     */       
/* 220 */       if (messageConverter.canRead(bodyClass, contentType)) {
/* 221 */         HttpMessageConverter<T> theConverter = (HttpMessageConverter)messageConverter;
/*     */         
/* 223 */         Class<? extends T> clazz = (Class)bodyClass;
/* 224 */         return (T)theConverter.read(clazz, (HttpInputMessage)this.serverHttpRequest);
/*     */       } 
/*     */     } 
/* 227 */     throw new HttpMediaTypeNotSupportedException(contentType, getSupportedMediaTypes(bodyClass), method());
/*     */   }
/*     */   
/*     */   private List<MediaType> getSupportedMediaTypes(Class<?> bodyClass) {
/* 231 */     List<MediaType> result = new ArrayList<>(this.messageConverters.size());
/* 232 */     for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 233 */       result.addAll(converter.getSupportedMediaTypes(bodyClass));
/*     */     }
/* 235 */     MimeTypeUtils.sortBySpecificity(result);
/* 236 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bind(Class<T> bindType, Consumer<WebDataBinder> dataBinderCustomizer) throws BindException {
/* 242 */     Assert.notNull(bindType, "BindType must not be null");
/* 243 */     Assert.notNull(dataBinderCustomizer, "DataBinderCustomizer must not be null");
/*     */     
/* 245 */     ServletRequestDataBinder dataBinder = new ServletRequestDataBinder(null);
/* 246 */     dataBinder.setTargetType(ResolvableType.forClass(bindType));
/* 247 */     dataBinderCustomizer.accept(dataBinder);
/*     */     
/* 249 */     HttpServletRequest servletRequest = servletRequest();
/* 250 */     dataBinder.construct((ServletRequest)servletRequest);
/* 251 */     dataBinder.bind((ServletRequest)servletRequest);
/*     */     
/* 253 */     BindingResult bindingResult = dataBinder.getBindingResult();
/* 254 */     if (bindingResult.hasErrors()) {
/* 255 */       throw new BindException(bindingResult);
/*     */     }
/*     */     
/* 258 */     T result = (T)bindingResult.getTarget();
/* 259 */     if (result != null) {
/* 260 */       return result;
/*     */     }
/*     */     
/* 263 */     throw new IllegalStateException("Binding result has neither target nor errors");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Object> attribute(String name) {
/* 270 */     return Optional.ofNullable(servletRequest().getAttribute(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> attributes() {
/* 275 */     return this.attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> param(String name) {
/* 280 */     return Optional.ofNullable(servletRequest().getParameter(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, String> params() {
/* 285 */     return this.params;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, Part> multipartData() throws IOException, ServletException {
/* 290 */     MultiValueMap<String, Part> result = this.parts;
/* 291 */     if (result == null) {
/*     */       
/* 293 */       result = (MultiValueMap<String, Part>)servletRequest().getParts().stream().collect(Collectors.groupingBy(Part::getName, LinkedMultiValueMap::new, 
/*     */             
/* 295 */             Collectors.toList()));
/* 296 */       this.parts = result;
/*     */     } 
/* 298 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> pathVariables() {
/* 305 */     Map<String, String> pathVariables = (Map<String, String>)servletRequest().getAttribute(RouterFunctions.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/* 306 */     if (pathVariables != null) {
/* 307 */       return pathVariables;
/*     */     }
/*     */     
/* 310 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpSession session() {
/* 316 */     return servletRequest().getSession(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Principal> principal() {
/* 321 */     return Optional.ofNullable(this.serverHttpRequest.getPrincipal());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 326 */     return String.format("HTTP %s %s", new Object[] { method(), path() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Optional<ServerResponse> checkNotModified(HttpServletRequest servletRequest, @Nullable Instant lastModified, @Nullable String etag) {
/* 332 */     long lastModifiedTimestamp = -1L;
/* 333 */     if (lastModified != null && lastModified.isAfter(Instant.EPOCH)) {
/* 334 */       lastModifiedTimestamp = lastModified.toEpochMilli();
/*     */     }
/*     */     
/* 337 */     CheckNotModifiedResponse response = new CheckNotModifiedResponse();
/* 338 */     ServletWebRequest servletWebRequest = new ServletWebRequest(servletRequest, response);
/* 339 */     if (servletWebRequest.checkNotModified(etag, lastModifiedTimestamp)) {
/* 340 */       return Optional.of(ServerResponse.status(response.status)
/* 341 */           .headers(headers -> headers.addAll((MultiValueMap)response.headers))
/* 342 */           .build());
/*     */     }
/*     */     
/* 345 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultRequestHeaders
/*     */     implements ServerRequest.Headers
/*     */   {
/*     */     private final HttpHeaders httpHeaders;
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultRequestHeaders(HttpHeaders httpHeaders) {
/* 358 */       this.httpHeaders = HttpHeaders.readOnlyHttpHeaders(httpHeaders);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<MediaType> accept() {
/* 363 */       return this.httpHeaders.getAccept();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Charset> acceptCharset() {
/* 368 */       return this.httpHeaders.getAcceptCharset();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Locale.LanguageRange> acceptLanguage() {
/* 373 */       return this.httpHeaders.getAcceptLanguage();
/*     */     }
/*     */ 
/*     */     
/*     */     public OptionalLong contentLength() {
/* 378 */       long value = this.httpHeaders.getContentLength();
/* 379 */       return (value != -1L) ? OptionalLong.of(value) : OptionalLong.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<MediaType> contentType() {
/* 384 */       return Optional.ofNullable(this.httpHeaders.getContentType());
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public InetSocketAddress host() {
/* 390 */       return this.httpHeaders.getHost();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<HttpRange> range() {
/* 395 */       return this.httpHeaders.getRange();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> header(String headerName) {
/* 400 */       List<String> headerValues = this.httpHeaders.get(headerName);
/* 401 */       return (headerValues != null) ? headerValues : Collections.<String>emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders asHttpHeaders() {
/* 406 */       return this.httpHeaders;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 411 */       return this.httpHeaders.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ServletParametersMap
/*     */     extends AbstractMap<String, List<String>>
/*     */   {
/*     */     private final HttpServletRequest servletRequest;
/*     */     
/*     */     private ServletParametersMap(HttpServletRequest servletRequest) {
/* 421 */       this.servletRequest = servletRequest;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, List<String>>> entrySet() {
/* 426 */       return (Set<Map.Entry<String, List<String>>>)this.servletRequest.getParameterMap().entrySet().stream()
/* 427 */         .map(entry -> {
/*     */             List<String> value = Arrays.asList((String[])entry.getValue());
/*     */             
/*     */             return new AbstractMap.SimpleImmutableEntry<>((String)entry.getKey(), value);
/* 431 */           }).collect(Collectors.toSet());
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 436 */       return this.servletRequest.getParameterMap().size();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> get(Object key) {
/* 441 */       String name = (String)key;
/* 442 */       String[] parameterValues = this.servletRequest.getParameterValues(name);
/* 443 */       if (!ObjectUtils.isEmpty((Object[])parameterValues)) {
/* 444 */         return Arrays.asList(parameterValues);
/*     */       }
/*     */       
/* 447 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> put(String key, List<String> value) {
/* 453 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> remove(Object key) {
/* 458 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 463 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ServletAttributesMap
/*     */     extends AbstractMap<String, Object>
/*     */   {
/*     */     private final HttpServletRequest servletRequest;
/*     */     
/*     */     private ServletAttributesMap(HttpServletRequest servletRequest) {
/* 473 */       this.servletRequest = servletRequest;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsKey(Object key) {
/* 478 */       String name = (String)key;
/* 479 */       return (this.servletRequest.getAttribute(name) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 484 */       List<String> attributeNames = Collections.list(this.servletRequest.getAttributeNames());
/* 485 */       Objects.requireNonNull(this.servletRequest); attributeNames.forEach(this.servletRequest::removeAttribute);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet() {
/* 490 */       return new AbstractSet<Map.Entry<String, Object>>()
/*     */         {
/*     */           public Iterator<Map.Entry<String, Object>> iterator() {
/* 493 */             return new Iterator<Map.Entry<String, Object>>()
/*     */               {
/* 495 */                 private final Iterator<String> attributes = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttributeNames().asIterator();
/*     */ 
/*     */                 
/*     */                 public boolean hasNext() {
/* 499 */                   return this.attributes.hasNext();
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public Map.Entry<String, Object> next() {
/* 504 */                   String attribute = this.attributes.next();
/* 505 */                   Object value = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttribute(attribute);
/* 506 */                   return new AbstractMap.SimpleImmutableEntry<>(attribute, value);
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isEmpty() {
/* 513 */             return DefaultServerRequest.ServletAttributesMap.this.isEmpty();
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/* 518 */             return DefaultServerRequest.ServletAttributesMap.this.size();
/*     */           }
/*     */           
/*     */           public boolean contains(Object o) {
/*     */             Map.Entry<?, ?> entry;
/* 523 */             if (o instanceof Map.Entry) { entry = (Map.Entry<?, ?>)o; }
/* 524 */             else { return false; }
/*     */             
/* 526 */             String attribute = (String)entry.getKey();
/* 527 */             Object value = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttribute(attribute);
/* 528 */             return (value != null && value.equals(entry.getValue()));
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean addAll(Collection<? extends Map.Entry<String, Object>> c) {
/* 533 */             throw new UnsupportedOperationException();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean remove(Object o) {
/* 538 */             throw new UnsupportedOperationException();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean removeAll(Collection<?> c) {
/* 543 */             throw new UnsupportedOperationException();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean retainAll(Collection<?> c) {
/* 548 */             throw new UnsupportedOperationException();
/*     */           }
/*     */ 
/*     */           
/*     */           public void clear() {
/* 553 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public Object get(Object key) {
/* 560 */       String name = (String)key;
/* 561 */       return this.servletRequest.getAttribute(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object put(String key, Object value) {
/* 566 */       Object oldValue = this.servletRequest.getAttribute(key);
/* 567 */       this.servletRequest.setAttribute(key, value);
/* 568 */       return oldValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object remove(Object key) {
/* 573 */       String name = (String)key;
/* 574 */       Object value = this.servletRequest.getAttribute(name);
/* 575 */       this.servletRequest.removeAttribute(name);
/* 576 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 581 */       Enumeration<String> attributes = this.servletRequest.getAttributeNames();
/* 582 */       int size = 0;
/* 583 */       while (attributes.hasMoreElements()) {
/* 584 */         size++;
/* 585 */         attributes.nextElement();
/*     */       } 
/* 587 */       return size;
/*     */     }
/*     */     
/*     */     public boolean isEmpty()
/*     */     {
/* 592 */       return !this.servletRequest.getAttributeNames().hasMoreElements(); }
/*     */   }
/*     */   class null extends AbstractSet<Map.Entry<String, Object>> {
/*     */     public Iterator<Map.Entry<String, Object>> iterator() { return new Iterator<Map.Entry<String, Object>>() { private final Iterator<String> attributes = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttributeNames().asIterator();
/*     */           public boolean hasNext() { return this.attributes.hasNext(); }
/*     */           public Map.Entry<String, Object> next() { String attribute = this.attributes.next(); Object value = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttribute(attribute); return new AbstractMap.SimpleImmutableEntry<>(attribute, value); } }
/*     */         ; }
/*     */     public boolean isEmpty() { return DefaultServerRequest.ServletAttributesMap.this.isEmpty(); }
/*     */     public int size() { return DefaultServerRequest.ServletAttributesMap.this.size(); }
/*     */     public boolean contains(Object o) { Map.Entry<?, ?> entry; if (o instanceof Map.Entry) { entry = (Map.Entry<?, ?>)o; } else { return false; }  String attribute = (String)entry.getKey(); Object value = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttribute(attribute); return (value != null && value.equals(entry.getValue())); } public boolean addAll(Collection<? extends Map.Entry<String, Object>> c) { throw new UnsupportedOperationException(); } public boolean remove(Object o) { throw new UnsupportedOperationException(); } public boolean removeAll(Collection<?> c) { throw new UnsupportedOperationException(); } public boolean retainAll(Collection<?> c) { throw new UnsupportedOperationException(); } public void clear() { throw new UnsupportedOperationException(); }
/*     */   } class null implements Iterator<Map.Entry<String, Object>> {
/*     */     private final Iterator<String> attributes = this.this$1.this$0.servletRequest.getAttributeNames().asIterator(); public boolean hasNext() { return this.attributes.hasNext(); } public Map.Entry<String, Object> next() { String attribute = this.attributes.next(); Object value = this.this$1.this$0.servletRequest.getAttribute(attribute); return new AbstractMap.SimpleImmutableEntry<>(attribute, value); }
/*     */   } private static final class CheckNotModifiedResponse implements HttpServletResponse {
/* 605 */     private final HttpHeaders headers; private CheckNotModifiedResponse() { this.headers = new HttpHeaders();
/*     */       
/* 607 */       this.status = 200; }
/*     */     
/*     */     private int status;
/*     */     public boolean containsHeader(String name) {
/* 611 */       return this.headers.containsKey(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setDateHeader(String name, long date) {
/* 616 */       this.headers.setDate(name, date);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setHeader(String name, String value) {
/* 621 */       this.headers.set(name, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addHeader(String name, String value) {
/* 626 */       this.headers.add(name, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setStatus(int sc) {
/* 631 */       this.status = sc;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getStatus() {
/* 636 */       return this.status;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getHeader(String name) {
/* 642 */       return this.headers.getFirst(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<String> getHeaders(String name) {
/* 647 */       List<String> result = this.headers.get(name);
/* 648 */       return (result != null) ? result : Collections.<String>emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<String> getHeaderNames() {
/* 653 */       return this.headers.keySet();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addCookie(Cookie cookie) {
/* 661 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String encodeURL(String url) {
/* 666 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String encodeRedirectURL(String url) {
/* 671 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void sendError(int sc, String msg) throws IOException {
/* 676 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void sendError(int sc) throws IOException {
/* 681 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void sendRedirect(String location) throws IOException {
/* 686 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void sendRedirect(String location, int sc, boolean clearBuffer) throws IOException {
/* 691 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void addDateHeader(String name, long date) {
/* 696 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setIntHeader(String name, int value) {
/* 701 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void addIntHeader(String name, int value) {
/* 706 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getCharacterEncoding() {
/* 712 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentType() {
/* 717 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ServletOutputStream getOutputStream() throws IOException {
/* 722 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public PrintWriter getWriter() throws IOException {
/* 727 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setCharacterEncoding(String charset) {
/* 732 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setContentLength(int len) {
/* 737 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setContentLengthLong(long len) {
/* 742 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setContentType(String type) {
/* 747 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setBufferSize(int size) {
/* 752 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getBufferSize() {
/* 757 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void flushBuffer() throws IOException {
/* 762 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void resetBuffer() {
/* 767 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCommitted() {
/* 772 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void reset() {
/* 777 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLocale(Locale loc) {
/* 782 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Locale getLocale() {
/* 787 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultServerRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */