/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PredicateResourceLookupFunction
/*    */   implements Function<ServerRequest, Optional<Resource>>
/*    */ {
/*    */   private final RequestPredicate predicate;
/*    */   private final Resource resource;
/*    */   
/*    */   public PredicateResourceLookupFunction(RequestPredicate predicate, Resource resource) {
/* 39 */     Assert.notNull(predicate, "'predicate' must not be null");
/* 40 */     Assert.notNull(resource, "'resource' must not be null");
/* 41 */     this.predicate = predicate;
/* 42 */     this.resource = resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<Resource> apply(ServerRequest serverRequest) {
/* 47 */     return this.predicate.test(serverRequest) ? Optional.<Resource>of(this.resource) : Optional.<Resource>empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\PredicateResourceLookupFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */