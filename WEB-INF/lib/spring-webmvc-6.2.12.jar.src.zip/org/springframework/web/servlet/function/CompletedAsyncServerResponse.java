/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CompletedAsyncServerResponse
/*    */   implements AsyncServerResponse
/*    */ {
/*    */   private final ServerResponse serverResponse;
/*    */   
/*    */   CompletedAsyncServerResponse(ServerResponse serverResponse) {
/* 45 */     Assert.notNull(serverResponse, "ServerResponse must not be null");
/* 46 */     this.serverResponse = serverResponse;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ServerResponse block() {
/* 52 */     return this.serverResponse;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpStatusCode statusCode() {
/* 57 */     return this.serverResponse.statusCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public int rawStatusCode() {
/* 64 */     return this.serverResponse.rawStatusCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders headers() {
/* 69 */     return this.serverResponse.headers();
/*    */   }
/*    */ 
/*    */   
/*    */   public MultiValueMap<String, Cookie> cookies() {
/* 74 */     return this.serverResponse.cookies();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public ModelAndView writeTo(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/* 82 */     return this.serverResponse.writeTo(request, response, context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\CompletedAsyncServerResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */