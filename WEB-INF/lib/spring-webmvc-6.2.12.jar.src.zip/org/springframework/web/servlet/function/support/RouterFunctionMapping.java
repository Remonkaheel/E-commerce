/*     */ package org.springframework.web.servlet.function.support;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.server.observation.ServerRequestObservationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.filter.ServerHttpObservationFilter;
/*     */ import org.springframework.web.servlet.function.HandlerFunction;
/*     */ import org.springframework.web.servlet.function.RouterFunction;
/*     */ import org.springframework.web.servlet.function.RouterFunctions;
/*     */ import org.springframework.web.servlet.function.ServerRequest;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.MatchableHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.RequestMatchResult;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RouterFunctionMapping
/*     */   extends AbstractHandlerMapping
/*     */   implements InitializingBean, MatchableHandlerMapping
/*     */ {
/*     */   @Nullable
/*     */   private RouterFunction<?> routerFunction;
/*  63 */   private List<HttpMessageConverter<?>> messageConverters = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean detectHandlerFunctionsInAncestorContexts = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctionMapping(RouterFunction<?> routerFunction) {
/*  82 */     this.routerFunction = routerFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRouterFunction(@Nullable RouterFunction<?> routerFunction) {
/*  91 */     this.routerFunction = routerFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RouterFunction<?> getRouterFunction() {
/* 103 */     return this.routerFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters) {
/* 111 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDetectHandlerFunctionsInAncestorContexts(boolean detectHandlerFunctionsInAncestorContexts) {
/* 123 */     this.detectHandlerFunctionsInAncestorContexts = detectHandlerFunctionsInAncestorContexts;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 129 */     if (this.routerFunction == null) {
/* 130 */       initRouterFunctions();
/*     */     }
/* 132 */     if (CollectionUtils.isEmpty(this.messageConverters)) {
/* 133 */       initMessageConverters();
/*     */     }
/* 135 */     if (this.routerFunction != null) {
/* 136 */       PathPatternParser patternParser = getPatternParser();
/* 137 */       if (patternParser == null) {
/* 138 */         patternParser = new PathPatternParser();
/* 139 */         setPatternParser(patternParser);
/*     */       } 
/* 141 */       RouterFunctions.changeParser(this.routerFunction, patternParser);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initRouterFunctions() {
/* 154 */     List<RouterFunction<?>> routerFunctions = (List<RouterFunction<?>>)obtainApplicationContext().getBeanProvider(RouterFunction.class).orderedStream().map(router -> router).collect(Collectors.toList());
/*     */     
/* 156 */     ApplicationContext parentContext = obtainApplicationContext().getParent();
/* 157 */     if (parentContext != null && !this.detectHandlerFunctionsInAncestorContexts) {
/* 158 */       Objects.requireNonNull(routerFunctions); parentContext.getBeanProvider(RouterFunction.class).stream().forEach(routerFunctions::remove);
/*     */     } 
/*     */     
/* 161 */     this.routerFunction = routerFunctions.stream().reduce(RouterFunction::andOther).orElse(null);
/* 162 */     logRouterFunctions(routerFunctions);
/*     */   }
/*     */   
/*     */   private void logRouterFunctions(List<RouterFunction<?>> routerFunctions) {
/* 166 */     if (this.mappingsLogger.isDebugEnabled()) {
/* 167 */       routerFunctions.forEach(function -> this.mappingsLogger.debug("Mapped " + String.valueOf(function)));
/*     */     }
/* 169 */     else if (this.logger.isDebugEnabled()) {
/* 170 */       int total = routerFunctions.size();
/* 171 */       String message = "" + total + " RouterFunction(s) in " + total;
/* 172 */       if (this.logger.isTraceEnabled()) {
/* 173 */         if (total > 0) {
/* 174 */           routerFunctions.forEach(function -> this.logger.trace("Mapped " + String.valueOf(function)));
/*     */         } else {
/*     */           
/* 177 */           this.logger.trace(message);
/*     */         }
/*     */       
/* 180 */       } else if (total > 0) {
/* 181 */         this.logger.debug(message);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initMessageConverters() {
/* 190 */     List<HttpMessageConverter<?>> messageConverters = new ArrayList<>(4);
/* 191 */     messageConverters.add(new ByteArrayHttpMessageConverter());
/* 192 */     messageConverters.add(new StringHttpMessageConverter());
/* 193 */     messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */     
/* 195 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getHandlerInternal(HttpServletRequest servletRequest) throws Exception {
/* 202 */     if (this.routerFunction != null) {
/* 203 */       ServerRequest request = ServerRequest.create(servletRequest, this.messageConverters);
/* 204 */       HandlerFunction<?> handlerFunction = this.routerFunction.route(request).orElse(null);
/* 205 */       setAttributes(servletRequest, request, handlerFunction);
/* 206 */       return handlerFunction;
/*     */     } 
/*     */     
/* 209 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setAttributes(HttpServletRequest servletRequest, ServerRequest request, @Nullable HandlerFunction<?> handlerFunction) {
/* 217 */     PathPattern matchingPattern = (PathPattern)servletRequest.getAttribute(RouterFunctions.MATCHING_PATTERN_ATTRIBUTE);
/* 218 */     if (matchingPattern != null) {
/* 219 */       servletRequest.removeAttribute(RouterFunctions.MATCHING_PATTERN_ATTRIBUTE);
/* 220 */       servletRequest.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, matchingPattern.getPatternString());
/* 221 */       ServerHttpObservationFilter.findObservationContext(request.servletRequest())
/* 222 */         .ifPresent(context -> context.setPathPattern(matchingPattern.getPatternString()));
/*     */     } 
/* 224 */     servletRequest.setAttribute(BEST_MATCHING_HANDLER_ATTRIBUTE, handlerFunction);
/* 225 */     servletRequest.setAttribute(RouterFunctions.REQUEST_ATTRIBUTE, request);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RequestMatchResult match(HttpServletRequest request, String pattern) {
/* 231 */     throw new UnsupportedOperationException("This HandlerMapping uses PathPatterns");
/*     */   }
/*     */   
/*     */   public RouterFunctionMapping() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\support\RouterFunctionMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */