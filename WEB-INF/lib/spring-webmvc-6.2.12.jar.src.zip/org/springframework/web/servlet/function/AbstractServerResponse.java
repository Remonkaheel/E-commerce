/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractServerResponse
/*     */   extends ErrorHandlingServerResponse
/*     */ {
/*  46 */   private static final Set<HttpMethod> SAFE_METHODS = Set.of(HttpMethod.GET, HttpMethod.HEAD);
/*     */ 
/*     */   
/*     */   private final HttpStatusCode statusCode;
/*     */   
/*     */   private final HttpHeaders headers;
/*     */   
/*     */   private final MultiValueMap<String, Cookie> cookies;
/*     */ 
/*     */   
/*     */   protected AbstractServerResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies) {
/*  57 */     this.statusCode = statusCode;
/*  58 */     this.headers = HttpHeaders.readOnlyHttpHeaders(headers);
/*  59 */     this
/*  60 */       .cookies = CollectionUtils.unmodifiableMultiValueMap((MultiValueMap)new LinkedMultiValueMap((Map)cookies));
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpStatusCode statusCode() {
/*  65 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int rawStatusCode() {
/*  72 */     return this.statusCode.value();
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpHeaders headers() {
/*  77 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, Cookie> cookies() {
/*  82 */     return this.cookies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ModelAndView writeTo(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/*     */     try {
/*  91 */       writeStatusAndHeaders(response);
/*     */       
/*  93 */       long lastModified = headers().getLastModified();
/*  94 */       ServletWebRequest servletWebRequest = new ServletWebRequest(request, response);
/*  95 */       HttpMethod httpMethod = HttpMethod.valueOf(request.getMethod());
/*  96 */       if (SAFE_METHODS.contains(httpMethod) && servletWebRequest
/*  97 */         .checkNotModified(headers().getETag(), lastModified)) {
/*  98 */         return null;
/*     */       }
/*     */       
/* 101 */       return writeToInternal(request, response, context);
/*     */     
/*     */     }
/* 104 */     catch (Throwable throwable) {
/* 105 */       return handleError(throwable, request, response, context);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeStatusAndHeaders(HttpServletResponse response) {
/* 110 */     response.setStatus(this.statusCode.value());
/* 111 */     writeHeaders(response);
/* 112 */     writeCookies(response);
/*     */   }
/*     */   
/*     */   private void writeHeaders(HttpServletResponse servletResponse) {
/* 116 */     this.headers.forEach((headerName, headerValues) -> {
/*     */           for (String headerValue : headerValues) {
/*     */             servletResponse.addHeader(headerName, headerValue);
/*     */           }
/*     */         });
/*     */     
/* 122 */     if (servletResponse.getContentType() == null && this.headers.getContentType() != null) {
/* 123 */       servletResponse.setContentType(this.headers.getContentType().toString());
/*     */     }
/* 125 */     if (servletResponse.getCharacterEncoding() == null && this.headers
/* 126 */       .getContentType() != null && this.headers
/* 127 */       .getContentType().getCharset() != null) {
/* 128 */       servletResponse.setCharacterEncoding(this.headers.getContentType().getCharset().name());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeCookies(HttpServletResponse servletResponse) {
/* 135 */     Objects.requireNonNull(servletResponse); this.cookies.values().stream().flatMap(Collection::stream).forEach(servletResponse::addCookie);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract ModelAndView writeToInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ServerResponse.Context paramContext) throws Exception;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\AbstractServerResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */