package org.springframework.web.servlet.function;

import jakarta.servlet.http.Cookie;
import java.util.Collection;
import java.util.Map;
import java.util.function.Consumer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.lang.Nullable;
import org.springframework.util.MultiValueMap;

public interface Builder {
  Builder modelAttribute(Object paramObject);
  
  Builder modelAttribute(String paramString, @Nullable Object paramObject);
  
  Builder modelAttributes(Object... paramVarArgs);
  
  Builder modelAttributes(Collection<?> paramCollection);
  
  Builder modelAttributes(Map<String, ?> paramMap);
  
  Builder header(String paramString, String... paramVarArgs);
  
  Builder headers(Consumer<HttpHeaders> paramConsumer);
  
  Builder status(HttpStatusCode paramHttpStatusCode);
  
  Builder status(int paramInt);
  
  Builder cookie(Cookie paramCookie);
  
  Builder cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
  
  RenderingResponse build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RenderingResponse$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */