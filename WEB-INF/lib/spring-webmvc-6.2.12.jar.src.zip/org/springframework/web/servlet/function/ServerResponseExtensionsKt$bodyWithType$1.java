package org.springframework.web.servlet.function;

import kotlin.Metadata;
import kotlin.jvm.internal.SourceDebugExtension;
import org.springframework.core.ParameterizedTypeReference;

@Metadata(mv = {1, 7, 0}, k = 1, xi = 176, d1 = {"\000\013\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001¨\006\002"}, d2 = {"org/springframework/web/servlet/function/ServerResponseExtensionsKt$bodyWithType$1", "Lorg/springframework/core/ParameterizedTypeReference;", "spring-webmvc"})
@SourceDebugExtension({"SMAP\nServerResponseExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ServerResponseExtensions.kt\norg/springframework/web/servlet/function/ServerResponseExtensionsKt$bodyWithType$1\n*L\n1#1,30:1\n*E\n"})
public final class ServerResponseExtensionsKt$bodyWithType$1 extends ParameterizedTypeReference<T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponseExtensionsKt$bodyWithType$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */