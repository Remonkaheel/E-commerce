/*     */ package org.springframework.web.servlet.function.support;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.async.AsyncWebRequest;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.servlet.HandlerAdapter;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.function.HandlerFunction;
/*     */ import org.springframework.web.servlet.function.RouterFunctions;
/*     */ import org.springframework.web.servlet.function.ServerRequest;
/*     */ import org.springframework.web.servlet.function.ServerResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerFunctionAdapter
/*     */   implements HandlerAdapter, Ordered
/*     */ {
/*  50 */   private static final Log logger = LogFactory.getLog(HandlerFunctionAdapter.class);
/*     */   
/*  52 */   private int order = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Long asyncRequestTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int order) {
/*  63 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  68 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsyncRequestTimeout(long timeout) {
/*  83 */     this.asyncRequestTimeout = Long.valueOf(timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Object handler) {
/*  88 */     return handler instanceof HandlerFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ModelAndView handle(HttpServletRequest servletRequest, HttpServletResponse servletResponse, Object handler) throws Exception {
/*     */     ServerResponse serverResponse;
/*  97 */     WebAsyncManager asyncManager = getWebAsyncManager(servletRequest, servletResponse);
/*  98 */     servletResponse = getWrappedResponse(asyncManager);
/*     */     
/* 100 */     ServerRequest serverRequest = getServerRequest(servletRequest);
/*     */ 
/*     */     
/* 103 */     if (asyncManager.hasConcurrentResult()) {
/* 104 */       serverResponse = handleAsync(asyncManager);
/*     */     } else {
/*     */       
/* 107 */       HandlerFunction<?> handlerFunction = (HandlerFunction)handler;
/* 108 */       serverResponse = handlerFunction.handle(serverRequest);
/*     */     } 
/*     */     
/* 111 */     if (serverResponse != null) {
/* 112 */       return serverResponse.writeTo(servletRequest, servletResponse, new ServerRequestContext(serverRequest));
/*     */     }
/*     */     
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private WebAsyncManager getWebAsyncManager(HttpServletRequest servletRequest, HttpServletResponse servletResponse) {
/* 120 */     AsyncWebRequest asyncWebRequest = WebAsyncUtils.createAsyncWebRequest(servletRequest, servletResponse);
/* 121 */     asyncWebRequest.setTimeout(this.asyncRequestTimeout);
/*     */     
/* 123 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager((ServletRequest)servletRequest);
/* 124 */     asyncManager.setAsyncWebRequest(asyncWebRequest);
/* 125 */     return asyncManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static HttpServletResponse getWrappedResponse(WebAsyncManager asyncManager) {
/* 135 */     AsyncWebRequest asyncRequest = asyncManager.getAsyncWebRequest();
/* 136 */     Assert.notNull(asyncRequest, "No AsyncWebRequest");
/*     */     
/* 138 */     HttpServletResponse servletResponse = (HttpServletResponse)asyncRequest.getNativeResponse(HttpServletResponse.class);
/* 139 */     Assert.notNull(servletResponse, "No HttpServletResponse");
/*     */     
/* 141 */     return servletResponse;
/*     */   }
/*     */ 
/*     */   
/*     */   private ServerRequest getServerRequest(HttpServletRequest servletRequest) {
/* 146 */     ServerRequest serverRequest = (ServerRequest)servletRequest.getAttribute(RouterFunctions.REQUEST_ATTRIBUTE);
/* 147 */     Assert.state((serverRequest != null), () -> "Required attribute '" + RouterFunctions.REQUEST_ATTRIBUTE + "' is missing");
/*     */     
/* 149 */     return serverRequest;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ServerResponse handleAsync(WebAsyncManager asyncManager) throws Exception {
/* 154 */     Object result = asyncManager.getConcurrentResult();
/* 155 */     asyncManager.clearConcurrentResult();
/* 156 */     LogFormatUtils.traceDebug(logger, traceOn -> {
/*     */           String formatted = LogFormatUtils.formatValue(result, !traceOn.booleanValue());
/*     */           return "Resume with async result [" + formatted + "]";
/*     */         });
/* 160 */     if (result instanceof ServerResponse) { ServerResponse response = (ServerResponse)result;
/* 161 */       return response; }
/*     */     
/* 163 */     if (result instanceof Exception) { Exception exception = (Exception)result;
/* 164 */       throw exception; }
/*     */     
/* 166 */     if (result instanceof Throwable) { Throwable throwable = (Throwable)result;
/* 167 */       throw new ServletException("Async processing failed", throwable); }
/*     */     
/* 169 */     if (result == null) {
/* 170 */       return null;
/*     */     }
/*     */     
/* 173 */     throw new IllegalArgumentException("Unknown result from WebAsyncManager: [" + String.valueOf(result) + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastModified(HttpServletRequest request, Object handler) {
/* 180 */     return -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ServerRequestContext
/*     */     implements ServerResponse.Context
/*     */   {
/*     */     private final ServerRequest serverRequest;
/*     */     
/*     */     public ServerRequestContext(ServerRequest serverRequest) {
/* 190 */       this.serverRequest = serverRequest;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<HttpMessageConverter<?>> messageConverters() {
/* 195 */       return this.serverRequest.messageConverters();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\support\HandlerFunctionAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */