/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ErrorHandlingServerResponse
/*     */   implements ServerResponse
/*     */ {
/*  42 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  44 */   private final List<ErrorHandler<?>> errorHandlers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final <T extends ServerResponse> void addErrorHandler(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, T> errorHandler) {
/*  50 */     Assert.notNull(predicate, "Predicate must not be null");
/*  51 */     Assert.notNull(errorHandler, "ErrorHandler must not be null");
/*  52 */     this.errorHandlers.add(new ErrorHandler(predicate, errorHandler));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final ModelAndView handleError(Throwable t, HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context) throws ServletException, IOException {
/*  59 */     ServerResponse serverResponse = errorResponse(t, servletRequest);
/*  60 */     if (serverResponse != null) {
/*  61 */       return serverResponse.writeTo(servletRequest, servletResponse, context);
/*     */     }
/*  63 */     if (t instanceof ServletException) { ServletException servletException = (ServletException)t;
/*  64 */       throw servletException; }
/*     */     
/*  66 */     if (t instanceof IOException) { IOException ioException = (IOException)t;
/*  67 */       throw ioException; }
/*     */ 
/*     */     
/*  70 */     throw new ServletException(t);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final ServerResponse errorResponse(Throwable t, HttpServletRequest servletRequest) {
/*  76 */     for (ErrorHandler<?> errorHandler : this.errorHandlers) {
/*  77 */       if (errorHandler.test(t)) {
/*     */         
/*  79 */         ServerRequest serverRequest = (ServerRequest)servletRequest.getAttribute(RouterFunctions.REQUEST_ATTRIBUTE);
/*  80 */         return (ServerResponse)errorHandler.handle(t, serverRequest);
/*     */       } 
/*     */     } 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ErrorHandler<T extends ServerResponse>
/*     */   {
/*     */     private final Predicate<Throwable> predicate;
/*     */     private final BiFunction<Throwable, ServerRequest, T> responseProvider;
/*     */     
/*     */     public ErrorHandler(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, T> responseProvider) {
/*  93 */       Assert.notNull(predicate, "Predicate must not be null");
/*  94 */       Assert.notNull(responseProvider, "ResponseProvider must not be null");
/*  95 */       this.predicate = predicate;
/*  96 */       this.responseProvider = responseProvider;
/*     */     }
/*     */     
/*     */     public boolean test(Throwable t) {
/* 100 */       return this.predicate.test(t);
/*     */     }
/*     */     
/*     */     public T handle(Throwable t, ServerRequest serverRequest) {
/* 104 */       return this.responseProvider.apply(t, serverRequest);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ErrorHandlingServerResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */