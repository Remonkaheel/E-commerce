package org.springframework.web.servlet.function;

import org.springframework.web.util.pattern.PathPatternParser;

public interface Target {
  void changeParser(PathPatternParser paramPathPatternParser);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ChangePathPatternParserVisitor$Target.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */