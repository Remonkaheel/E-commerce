/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ServletAttributesMap
/*     */   extends AbstractMap<String, Object>
/*     */ {
/*     */   private final HttpServletRequest servletRequest;
/*     */   
/*     */   private ServletAttributesMap(HttpServletRequest servletRequest) {
/* 473 */     this.servletRequest = servletRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 478 */     String name = (String)key;
/* 479 */     return (this.servletRequest.getAttribute(name) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 484 */     List<String> attributeNames = Collections.list(this.servletRequest.getAttributeNames());
/* 485 */     Objects.requireNonNull(this.servletRequest); attributeNames.forEach(this.servletRequest::removeAttribute);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 490 */     return new AbstractSet<Map.Entry<String, Object>>()
/*     */       {
/*     */         public Iterator<Map.Entry<String, Object>> iterator() {
/* 493 */           return new Iterator<Map.Entry<String, Object>>()
/*     */             {
/* 495 */               private final Iterator<String> attributes = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttributeNames().asIterator();
/*     */ 
/*     */               
/*     */               public boolean hasNext() {
/* 499 */                 return this.attributes.hasNext();
/*     */               }
/*     */ 
/*     */               
/*     */               public Map.Entry<String, Object> next() {
/* 504 */                 String attribute = this.attributes.next();
/* 505 */                 Object value = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttribute(attribute);
/* 506 */                 return new AbstractMap.SimpleImmutableEntry<>(attribute, value);
/*     */               }
/*     */             };
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isEmpty() {
/* 513 */           return DefaultServerRequest.ServletAttributesMap.this.isEmpty();
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 518 */           return DefaultServerRequest.ServletAttributesMap.this.size();
/*     */         }
/*     */         
/*     */         public boolean contains(Object o) {
/*     */           Map.Entry<?, ?> entry;
/* 523 */           if (o instanceof Map.Entry) { entry = (Map.Entry<?, ?>)o; }
/* 524 */           else { return false; }
/*     */           
/* 526 */           String attribute = (String)entry.getKey();
/* 527 */           Object value = DefaultServerRequest.ServletAttributesMap.this.servletRequest.getAttribute(attribute);
/* 528 */           return (value != null && value.equals(entry.getValue()));
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean addAll(Collection<? extends Map.Entry<String, Object>> c) {
/* 533 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean remove(Object o) {
/* 538 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean removeAll(Collection<?> c) {
/* 543 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean retainAll(Collection<?> c) {
/* 548 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         
/*     */         public void clear() {
/* 553 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 560 */     String name = (String)key;
/* 561 */     return this.servletRequest.getAttribute(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(String key, Object value) {
/* 566 */     Object oldValue = this.servletRequest.getAttribute(key);
/* 567 */     this.servletRequest.setAttribute(key, value);
/* 568 */     return oldValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 573 */     String name = (String)key;
/* 574 */     Object value = this.servletRequest.getAttribute(name);
/* 575 */     this.servletRequest.removeAttribute(name);
/* 576 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 581 */     Enumeration<String> attributes = this.servletRequest.getAttributeNames();
/* 582 */     int size = 0;
/* 583 */     while (attributes.hasMoreElements()) {
/* 584 */       size++;
/* 585 */       attributes.nextElement();
/*     */     } 
/* 587 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 592 */     return !this.servletRequest.getAttributeNames().hasMoreElements();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultServerRequest$ServletAttributesMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */