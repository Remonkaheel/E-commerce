package org.springframework.web.servlet.function;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.core.io.Resource;

public interface Visitor {
  void startNested(RequestPredicate paramRequestPredicate);
  
  void endNested(RequestPredicate paramRequestPredicate);
  
  void route(RequestPredicate paramRequestPredicate, HandlerFunction<?> paramHandlerFunction);
  
  void resources(Function<ServerRequest, Optional<Resource>> paramFunction);
  
  void attributes(Map<String, Object> paramMap);
  
  void unknown(RouterFunction<?> paramRouterFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunctions$Visitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */