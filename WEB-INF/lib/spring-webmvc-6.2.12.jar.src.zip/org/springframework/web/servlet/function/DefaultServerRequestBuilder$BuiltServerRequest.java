/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.Part;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.security.Principal;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.SmartHttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.util.UriBuilder;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BuiltServerRequest
/*     */   implements ServerRequest
/*     */ {
/*     */   private final HttpMethod method;
/*     */   private final URI uri;
/*     */   private final HttpHeaders headers;
/*     */   private final HttpServletRequest servletRequest;
/*     */   private final MultiValueMap<String, Cookie> cookies;
/*     */   private final Map<String, Object> attributes;
/*     */   private final byte[] body;
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private final MultiValueMap<String, String> params;
/*     */   @Nullable
/*     */   private final InetSocketAddress remoteAddress;
/*     */   
/*     */   public BuiltServerRequest(HttpServletRequest servletRequest, HttpMethod method, URI uri, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, Map<String, Object> attributes, MultiValueMap<String, String> params, @Nullable InetSocketAddress remoteAddress, byte[] body, List<HttpMessageConverter<?>> messageConverters) {
/* 239 */     this.servletRequest = servletRequest;
/* 240 */     this.method = method;
/* 241 */     this.uri = uri;
/* 242 */     this.headers = new HttpHeaders((MultiValueMap)headers);
/* 243 */     this.cookies = (MultiValueMap<String, Cookie>)new LinkedMultiValueMap((Map)cookies);
/* 244 */     this.attributes = new LinkedHashMap<>(attributes);
/* 245 */     this.params = (MultiValueMap<String, String>)new LinkedMultiValueMap((Map)params);
/* 246 */     this.remoteAddress = remoteAddress;
/* 247 */     this.body = body;
/* 248 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod method() {
/* 253 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String methodName() {
/* 259 */     return this.method.name();
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, Part> multipartData() throws IOException, ServletException {
/* 264 */     return (MultiValueMap<String, Part>)servletRequest().getParts().stream()
/* 265 */       .collect(Collectors.groupingBy(Part::getName, LinkedMultiValueMap::new, 
/*     */           
/* 267 */           Collectors.toList()));
/*     */   }
/*     */ 
/*     */   
/*     */   public URI uri() {
/* 272 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public UriBuilder uriBuilder() {
/* 277 */     return (UriBuilder)UriComponentsBuilder.fromUri(this.uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Headers headers() {
/* 282 */     return new DefaultServerRequest.DefaultRequestHeaders(this.headers);
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, Cookie> cookies() {
/* 287 */     return this.cookies;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<InetSocketAddress> remoteAddress() {
/* 292 */     return Optional.ofNullable(this.remoteAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<HttpMessageConverter<?>> messageConverters() {
/* 297 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T body(Class<T> bodyType) throws IOException, ServletException {
/* 302 */     return bodyInternal(bodyType, bodyType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T body(ParameterizedTypeReference<T> bodyType) throws IOException, ServletException {
/* 307 */     Type type = bodyType.getType();
/* 308 */     return bodyInternal(type, DefaultServerRequest.bodyClass(type));
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T bodyInternal(Type bodyType, Class<?> bodyClass) throws ServletException, IOException {
/* 313 */     HttpInputMessage inputMessage = new BuiltInputMessage();
/* 314 */     MediaType contentType = headers().contentType().orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */     
/* 316 */     for (HttpMessageConverter<?> messageConverter : this.messageConverters) {
/* 317 */       if (messageConverter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter<?> genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/* 318 */         if (genericMessageConverter.canRead(bodyType, bodyClass, contentType))
/* 319 */           return (T)genericMessageConverter.read(bodyType, bodyClass, inputMessage); 
/*     */         continue; }
/*     */       
/* 322 */       if (messageConverter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter<?> smartMessageConverter = (SmartHttpMessageConverter)messageConverter;
/* 323 */         ResolvableType resolvableType = ResolvableType.forType(bodyType);
/* 324 */         if (smartMessageConverter.canRead(resolvableType, contentType))
/* 325 */           return (T)smartMessageConverter.read(resolvableType, inputMessage, null); 
/*     */         continue; }
/*     */       
/* 328 */       if (messageConverter.canRead(bodyClass, contentType)) {
/* 329 */         HttpMessageConverter<T> theConverter = (HttpMessageConverter)messageConverter;
/*     */         
/* 331 */         Class<? extends T> clazz = (Class)bodyClass;
/* 332 */         return (T)theConverter.read(clazz, inputMessage);
/*     */       } 
/*     */     } 
/* 335 */     throw new HttpMediaTypeNotSupportedException(contentType, Collections.emptyList(), method());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T bind(Class<T> bindType, Consumer<WebDataBinder> dataBinderCustomizer) throws BindException {
/* 341 */     Assert.notNull(bindType, "BindType must not be null");
/* 342 */     Assert.notNull(dataBinderCustomizer, "DataBinderCustomizer must not be null");
/*     */     
/* 344 */     ServletRequestDataBinder dataBinder = new ServletRequestDataBinder(null);
/* 345 */     dataBinder.setTargetType(ResolvableType.forClass(bindType));
/* 346 */     dataBinderCustomizer.accept(dataBinder);
/*     */     
/* 348 */     HttpServletRequest servletRequest = servletRequest();
/* 349 */     dataBinder.construct((ServletRequest)servletRequest);
/* 350 */     dataBinder.bind((ServletRequest)servletRequest);
/*     */     
/* 352 */     BindingResult bindingResult = dataBinder.getBindingResult();
/* 353 */     if (bindingResult.hasErrors()) {
/* 354 */       throw new BindException(bindingResult);
/*     */     }
/*     */     
/* 357 */     T result = (T)bindingResult.getTarget();
/* 358 */     if (result != null) {
/* 359 */       return result;
/*     */     }
/*     */     
/* 362 */     throw new IllegalStateException("Binding result has neither target nor errors");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> attributes() {
/* 369 */     return this.attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, String> params() {
/* 374 */     return this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> pathVariables() {
/* 381 */     Map<String, String> pathVariables = (Map<String, String>)attributes().get(RouterFunctions.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/* 382 */     if (pathVariables != null) {
/* 383 */       return pathVariables;
/*     */     }
/*     */     
/* 386 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpSession session() {
/* 392 */     return this.servletRequest.getSession();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Principal> principal() {
/* 397 */     return Optional.ofNullable(this.servletRequest.getUserPrincipal());
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest servletRequest() {
/* 402 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   private class BuiltInputMessage
/*     */     implements HttpInputMessage
/*     */   {
/*     */     public InputStream getBody() throws IOException {
/* 410 */       return (InputStream)new DefaultServerRequestBuilder.BodyInputStream(DefaultServerRequestBuilder.BuiltServerRequest.this.body);
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 415 */       return DefaultServerRequestBuilder.BuiltServerRequest.this.headers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultServerRequestBuilder$BuiltServerRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */