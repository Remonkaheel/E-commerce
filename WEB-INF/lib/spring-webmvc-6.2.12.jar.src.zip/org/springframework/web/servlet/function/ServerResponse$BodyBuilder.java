package org.springframework.web.servlet.function;

import java.util.Map;
import java.util.function.Consumer;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;

public interface BodyBuilder extends ServerResponse.HeadersBuilder<ServerResponse.BodyBuilder> {
  BodyBuilder contentLength(long paramLong);
  
  BodyBuilder contentType(MediaType paramMediaType);
  
  ServerResponse body(Object paramObject);
  
  <T> ServerResponse body(T paramT, ParameterizedTypeReference<T> paramParameterizedTypeReference);
  
  ServerResponse render(String paramString, Object... paramVarArgs);
  
  ServerResponse render(String paramString, Map<String, ?> paramMap);
  
  ServerResponse stream(Consumer<ServerResponse.StreamBuilder> paramConsumer);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse$BodyBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */