/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ErrorHandler<T extends ServerResponse>
/*     */ {
/*     */   private final Predicate<Throwable> predicate;
/*     */   private final BiFunction<Throwable, ServerRequest, T> responseProvider;
/*     */   
/*     */   public ErrorHandler(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, T> responseProvider) {
/*  93 */     Assert.notNull(predicate, "Predicate must not be null");
/*  94 */     Assert.notNull(responseProvider, "ResponseProvider must not be null");
/*  95 */     this.predicate = predicate;
/*  96 */     this.responseProvider = responseProvider;
/*     */   }
/*     */   
/*     */   public boolean test(Throwable t) {
/* 100 */     return this.predicate.test(t);
/*     */   }
/*     */   
/*     */   public T handle(Throwable t, ServerRequest serverRequest) {
/* 104 */     return this.responseProvider.apply(t, serverRequest);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ErrorHandlingServerResponse$ErrorHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */