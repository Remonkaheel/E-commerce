package org.springframework.web.servlet.function;

import java.util.List;
import org.springframework.http.converter.HttpMessageConverter;

public interface Context {
  List<HttpMessageConverter<?>> messageConverters();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse$Context.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */