package org.springframework.web.servlet.function;

import java.util.function.BiFunction;
import kotlin.Metadata;
import kotlin.jvm.functions.Function2;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunctionDslKt$sam$i$java_util_function_BiFunction$0.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */