/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RenderingResponse
/*    */   extends ServerResponse
/*    */ {
/*    */   String name();
/*    */   
/*    */   Map<String, Object> model();
/*    */   
/*    */   static Builder from(RenderingResponse other) {
/* 57 */     return new DefaultRenderingResponseBuilder(other);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Builder create(String name) {
/* 66 */     return new DefaultRenderingResponseBuilder(name);
/*    */   }
/*    */   
/*    */   public static interface Builder {
/*    */     Builder modelAttribute(Object param1Object);
/*    */     
/*    */     Builder modelAttribute(String param1String, @Nullable Object param1Object);
/*    */     
/*    */     Builder modelAttributes(Object... param1VarArgs);
/*    */     
/*    */     Builder modelAttributes(Collection<?> param1Collection);
/*    */     
/*    */     Builder modelAttributes(Map<String, ?> param1Map);
/*    */     
/*    */     Builder header(String param1String, String... param1VarArgs);
/*    */     
/*    */     Builder headers(Consumer<HttpHeaders> param1Consumer);
/*    */     
/*    */     Builder status(HttpStatusCode param1HttpStatusCode);
/*    */     
/*    */     Builder status(int param1Int);
/*    */     
/*    */     Builder cookie(Cookie param1Cookie);
/*    */     
/*    */     Builder cookies(Consumer<MultiValueMap<String, Cookie>> param1Consumer);
/*    */     
/*    */     RenderingResponse build();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RenderingResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */