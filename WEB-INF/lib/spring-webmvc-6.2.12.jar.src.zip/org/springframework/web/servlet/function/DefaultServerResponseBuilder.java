/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.net.URI;
/*     */ import java.time.Instant;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultServerResponseBuilder
/*     */   implements ServerResponse.BodyBuilder
/*     */ {
/*     */   private final HttpStatusCode statusCode;
/*  54 */   private final HttpHeaders headers = new HttpHeaders();
/*     */   
/*  56 */   private final MultiValueMap<String, Cookie> cookies = (MultiValueMap<String, Cookie>)new LinkedMultiValueMap();
/*     */ 
/*     */   
/*     */   public DefaultServerResponseBuilder(ServerResponse other) {
/*  60 */     Assert.notNull(other, "ServerResponse must not be null");
/*  61 */     this.statusCode = other.statusCode();
/*  62 */     this.headers.addAll((MultiValueMap)other.headers());
/*  63 */     this.cookies.addAll(other.cookies());
/*     */   }
/*     */   
/*     */   public DefaultServerResponseBuilder(HttpStatusCode status) {
/*  67 */     Assert.notNull(status, "HttpStatusCode must not be null");
/*  68 */     this.statusCode = status;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder header(String headerName, String... headerValues) {
/*  73 */     Assert.notNull(headerName, "HeaderName must not be null");
/*  74 */     for (String headerValue : headerValues) {
/*  75 */       this.headers.add(headerName, headerValue);
/*     */     }
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder headers(Consumer<HttpHeaders> headersConsumer) {
/*  82 */     Assert.notNull(headersConsumer, "HeaderConsumer must not be null");
/*  83 */     headersConsumer.accept(this.headers);
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder cookie(Cookie cookie) {
/*  89 */     Assert.notNull(cookie, "Cookie must not be null");
/*  90 */     this.cookies.add(cookie.getName(), cookie);
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder cookies(Consumer<MultiValueMap<String, Cookie>> cookiesConsumer) {
/*  96 */     Assert.notNull(cookiesConsumer, "CookiesConsumer must not be null");
/*  97 */     cookiesConsumer.accept(this.cookies);
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder allow(HttpMethod... allowedMethods) {
/* 103 */     Assert.notNull(allowedMethods, "Http AllowedMethods must not be null");
/* 104 */     this.headers.setAllow(new LinkedHashSet(Arrays.asList((Object[])allowedMethods)));
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder allow(Set<HttpMethod> allowedMethods) {
/* 110 */     Assert.notNull(allowedMethods, "Http AllowedMethods must not be null");
/* 111 */     this.headers.setAllow(allowedMethods);
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder contentLength(long contentLength) {
/* 117 */     this.headers.setContentLength(contentLength);
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder contentType(MediaType contentType) {
/* 123 */     Assert.notNull(contentType, "ContentType must not be null");
/* 124 */     this.headers.setContentType(contentType);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder eTag(String tag) {
/* 130 */     this.headers.setETag(tag);
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder lastModified(ZonedDateTime lastModified) {
/* 136 */     this.headers.setLastModified(lastModified);
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder lastModified(Instant lastModified) {
/* 142 */     this.headers.setLastModified(lastModified);
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder location(URI location) {
/* 148 */     this.headers.setLocation(location);
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder cacheControl(CacheControl cacheControl) {
/* 154 */     this.headers.setCacheControl(cacheControl);
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.BodyBuilder varyBy(String... requestHeaders) {
/* 160 */     this.headers.setVary(Arrays.asList(requestHeaders));
/* 161 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse build() {
/* 166 */     return build((request, response) -> null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse build(ServerResponse.HeadersBuilder.WriteFunction writeFunction) {
/* 171 */     return new WriteFunctionResponse(this.statusCode, this.headers, this.cookies, writeFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse body(Object body) {
/* 176 */     return DefaultEntityResponseBuilder.<Object>fromObject(body)
/* 177 */       .status(this.statusCode)
/* 178 */       .headers(headers -> headers.putAll((Map)this.headers))
/* 179 */       .cookies(cookies -> cookies.addAll(this.cookies))
/* 180 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> ServerResponse body(T body, ParameterizedTypeReference<T> bodyType) {
/* 185 */     return DefaultEntityResponseBuilder.<T>fromObject(body, bodyType)
/* 186 */       .status(this.statusCode)
/* 187 */       .headers(headers -> headers.putAll((Map)this.headers))
/* 188 */       .cookies(cookies -> cookies.addAll(this.cookies))
/* 189 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse render(String name, Object... modelAttributes) {
/* 194 */     return (new DefaultRenderingResponseBuilder(name))
/* 195 */       .status(this.statusCode)
/* 196 */       .headers(headers -> headers.putAll((Map)this.headers))
/* 197 */       .cookies(cookies -> cookies.addAll(this.cookies))
/* 198 */       .modelAttributes(modelAttributes)
/* 199 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse render(String name, Map<String, ?> model) {
/* 204 */     return (new DefaultRenderingResponseBuilder(name))
/* 205 */       .status(this.statusCode)
/* 206 */       .headers(headers -> headers.putAll((Map)this.headers))
/* 207 */       .cookies(cookies -> cookies.addAll(this.cookies))
/* 208 */       .modelAttributes(model)
/* 209 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse stream(Consumer<ServerResponse.StreamBuilder> streamConsumer) {
/* 214 */     return StreamingServerResponse.create(this.statusCode, this.headers, this.cookies, streamConsumer, null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class WriteFunctionResponse
/*     */     extends AbstractServerResponse
/*     */   {
/*     */     private final ServerResponse.HeadersBuilder.WriteFunction writeFunction;
/*     */     
/*     */     public WriteFunctionResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, ServerResponse.HeadersBuilder.WriteFunction writeFunction) {
/* 224 */       super(statusCode, headers, cookies);
/* 225 */       Assert.notNull(writeFunction, "WriteFunction must not be null");
/* 226 */       this.writeFunction = writeFunction;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected ModelAndView writeToInternal(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws Exception {
/* 234 */       return this.writeFunction.write(request, response);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultServerResponseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */