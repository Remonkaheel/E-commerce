package org.springframework.web.servlet.function;

import jakarta.servlet.http.Cookie;
import java.net.URI;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.Set;
import java.util.function.Consumer;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;

public interface Builder<T> {
  Builder<T> header(String paramString, String... paramVarArgs);
  
  Builder<T> headers(Consumer<HttpHeaders> paramConsumer);
  
  Builder<T> status(HttpStatusCode paramHttpStatusCode);
  
  Builder<T> status(int paramInt);
  
  Builder<T> cookie(Cookie paramCookie);
  
  Builder<T> cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
  
  Builder<T> allow(HttpMethod... paramVarArgs);
  
  Builder<T> allow(Set<HttpMethod> paramSet);
  
  Builder<T> eTag(String paramString);
  
  Builder<T> lastModified(ZonedDateTime paramZonedDateTime);
  
  Builder<T> lastModified(Instant paramInstant);
  
  Builder<T> location(URI paramURI);
  
  Builder<T> cacheControl(CacheControl paramCacheControl);
  
  Builder<T> varyBy(String... paramVarArgs);
  
  Builder<T> contentLength(long paramLong);
  
  Builder<T> contentType(MediaType paramMediaType);
  
  EntityResponse<T> build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\EntityResponse$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */