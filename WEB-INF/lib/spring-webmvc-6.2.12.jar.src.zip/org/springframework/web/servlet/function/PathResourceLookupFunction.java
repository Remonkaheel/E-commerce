/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.UncheckedIOException;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.http.server.PathContainer;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.resource.ResourceHandlerUtils;
/*    */ import org.springframework.web.util.UriUtils;
/*    */ import org.springframework.web.util.pattern.PathPattern;
/*    */ import org.springframework.web.util.pattern.PathPatternParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PathResourceLookupFunction
/*    */   implements Function<ServerRequest, Optional<Resource>>
/*    */ {
/*    */   private final PathPattern pattern;
/*    */   private final Resource location;
/*    */   
/*    */   public PathResourceLookupFunction(String pattern, Resource location) {
/* 49 */     Assert.hasLength(pattern, "'pattern' must not be empty");
/* 50 */     ResourceHandlerUtils.assertResourceLocation(location);
/* 51 */     this.pattern = PathPatternParser.defaultInstance.parse(pattern);
/* 52 */     this.location = location;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Resource> apply(ServerRequest request) {
/* 58 */     PathContainer pathContainer = request.requestPath().pathWithinApplication();
/* 59 */     if (!this.pattern.matches(pathContainer)) {
/* 60 */       return Optional.empty();
/*    */     }
/*    */     
/* 63 */     pathContainer = this.pattern.extractPathWithinPattern(pathContainer);
/* 64 */     String path = ResourceHandlerUtils.normalizeInputPath(pathContainer.value());
/* 65 */     if (ResourceHandlerUtils.shouldIgnoreInputPath(path)) {
/* 66 */       return Optional.empty();
/*    */     }
/*    */     
/* 69 */     if (!(this.location instanceof org.springframework.core.io.UrlResource)) {
/* 70 */       path = UriUtils.decode(path, StandardCharsets.UTF_8);
/*    */     }
/*    */     
/*    */     try {
/* 74 */       Resource resource = this.location.createRelative(path);
/* 75 */       if (resource.isReadable() && ResourceHandlerUtils.isResourceUnderLocation(this.location, resource)) {
/* 76 */         return Optional.of(resource);
/*    */       }
/*    */       
/* 79 */       return Optional.empty();
/*    */     
/*    */     }
/* 82 */     catch (IOException ex) {
/* 83 */       throw new UncheckedIOException(ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return String.valueOf(this.pattern) + " -> " + String.valueOf(this.pattern);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\PathResourceLookupFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */