/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.ErrorResponse;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ServerResponse
/*     */ {
/*     */   static BodyBuilder from(ServerResponse other) {
/* 106 */     return new DefaultServerResponseBuilder(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ServerResponse from(ErrorResponse response) {
/* 116 */     return status(response.getStatusCode())
/* 117 */       .headers(headers -> headers.putAll((Map)response.getHeaders()))
/* 118 */       .body(response.getBody());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder status(HttpStatusCode status) {
/* 127 */     return new DefaultServerResponseBuilder(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder status(int status) {
/* 136 */     return new DefaultServerResponseBuilder(HttpStatusCode.valueOf(status));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder ok() {
/* 144 */     return status((HttpStatusCode)HttpStatus.OK);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder created(URI location) {
/* 154 */     BodyBuilder builder = status((HttpStatusCode)HttpStatus.CREATED);
/* 155 */     return builder.location(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder accepted() {
/* 163 */     return status((HttpStatusCode)HttpStatus.ACCEPTED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HeadersBuilder<?> noContent() {
/* 171 */     return status((HttpStatusCode)HttpStatus.NO_CONTENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder seeOther(URI location) {
/* 181 */     BodyBuilder builder = status((HttpStatusCode)HttpStatus.SEE_OTHER);
/* 182 */     return builder.location(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder temporaryRedirect(URI location) {
/* 192 */     BodyBuilder builder = status((HttpStatusCode)HttpStatus.TEMPORARY_REDIRECT);
/* 193 */     return builder.location(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder permanentRedirect(URI location) {
/* 203 */     BodyBuilder builder = status((HttpStatusCode)HttpStatus.PERMANENT_REDIRECT);
/* 204 */     return builder.location(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder badRequest() {
/* 212 */     return status((HttpStatusCode)HttpStatus.BAD_REQUEST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HeadersBuilder<?> notFound() {
/* 220 */     return status((HttpStatusCode)HttpStatus.NOT_FOUND);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BodyBuilder unprocessableEntity() {
/* 229 */     return status((HttpStatusCode)HttpStatus.UNPROCESSABLE_ENTITY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ServerResponse async(Object asyncResponse) {
/* 249 */     return AsyncServerResponse.create(asyncResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ServerResponse async(Object asyncResponse, Duration timeout) {
/* 270 */     return AsyncServerResponse.create(asyncResponse, timeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ServerResponse sse(Consumer<SseBuilder> consumer) {
/* 299 */     return SseServerResponse.create(consumer, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ServerResponse sse(Consumer<SseBuilder> consumer, Duration timeout) {
/* 329 */     return SseServerResponse.create(consumer, timeout);
/*     */   }
/*     */   
/*     */   HttpStatusCode statusCode();
/*     */   
/*     */   @Deprecated(since = "6.0", forRemoval = true)
/*     */   int rawStatusCode();
/*     */   
/*     */   HttpHeaders headers();
/*     */   
/*     */   MultiValueMap<String, Cookie> cookies();
/*     */   
/*     */   @Nullable
/*     */   ModelAndView writeTo(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Context paramContext) throws ServletException, IOException;
/*     */   
/*     */   public static interface BodyBuilder extends HeadersBuilder<BodyBuilder> {
/*     */     BodyBuilder contentLength(long param1Long);
/*     */     
/*     */     BodyBuilder contentType(MediaType param1MediaType);
/*     */     
/*     */     ServerResponse body(Object param1Object);
/*     */     
/*     */     <T> ServerResponse body(T param1T, ParameterizedTypeReference<T> param1ParameterizedTypeReference);
/*     */     
/*     */     ServerResponse render(String param1String, Object... param1VarArgs);
/*     */     
/*     */     ServerResponse render(String param1String, Map<String, ?> param1Map);
/*     */     
/*     */     ServerResponse stream(Consumer<ServerResponse.StreamBuilder> param1Consumer);
/*     */   }
/*     */   
/*     */   public static interface HeadersBuilder<B extends HeadersBuilder<B>> {
/*     */     B header(String param1String, String... param1VarArgs);
/*     */     
/*     */     B headers(Consumer<HttpHeaders> param1Consumer);
/*     */     
/*     */     B cookie(Cookie param1Cookie);
/*     */     
/*     */     B cookies(Consumer<MultiValueMap<String, Cookie>> param1Consumer);
/*     */     
/*     */     B allow(HttpMethod... param1VarArgs);
/*     */     
/*     */     B allow(Set<HttpMethod> param1Set);
/*     */     
/*     */     B eTag(String param1String);
/*     */     
/*     */     B lastModified(ZonedDateTime param1ZonedDateTime);
/*     */     
/*     */     B lastModified(Instant param1Instant);
/*     */     
/*     */     B location(URI param1URI);
/*     */     
/*     */     B cacheControl(CacheControl param1CacheControl);
/*     */     
/*     */     B varyBy(String... param1VarArgs);
/*     */     
/*     */     ServerResponse build();
/*     */     
/*     */     ServerResponse build(WriteFunction param1WriteFunction);
/*     */     
/*     */     @FunctionalInterface
/*     */     public static interface WriteFunction {
/*     */       @Nullable
/*     */       ModelAndView write(HttpServletRequest param2HttpServletRequest, HttpServletResponse param2HttpServletResponse) throws Exception;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Context {
/*     */     List<HttpMessageConverter<?>> messageConverters();
/*     */   }
/*     */   
/*     */   public static interface StreamBuilder {
/*     */     void error(Throwable param1Throwable);
/*     */     
/*     */     void complete();
/*     */     
/*     */     StreamBuilder onTimeout(Runnable param1Runnable);
/*     */     
/*     */     StreamBuilder onError(Consumer<Throwable> param1Consumer);
/*     */     
/*     */     StreamBuilder onComplete(Runnable param1Runnable);
/*     */     
/*     */     StreamBuilder write(Object param1Object) throws IOException;
/*     */     
/*     */     StreamBuilder write(Object param1Object, @Nullable MediaType param1MediaType) throws IOException;
/*     */     
/*     */     void flush() throws IOException;
/*     */   }
/*     */   
/*     */   public static interface SseBuilder {
/*     */     void error(Throwable param1Throwable);
/*     */     
/*     */     void complete();
/*     */     
/*     */     SseBuilder onTimeout(Runnable param1Runnable);
/*     */     
/*     */     SseBuilder onError(Consumer<Throwable> param1Consumer);
/*     */     
/*     */     SseBuilder onComplete(Runnable param1Runnable);
/*     */     
/*     */     void send(Object param1Object) throws IOException;
/*     */     
/*     */     void send() throws IOException;
/*     */     
/*     */     SseBuilder id(String param1String);
/*     */     
/*     */     SseBuilder event(String param1String);
/*     */     
/*     */     SseBuilder retry(Duration param1Duration);
/*     */     
/*     */     SseBuilder comment(String param1String);
/*     */     
/*     */     void data(Object param1Object) throws IOException;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface WriteFunction {
/*     */     @Nullable
/*     */     ModelAndView write(HttpServletRequest param1HttpServletRequest, HttpServletResponse param1HttpServletResponse) throws Exception;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */