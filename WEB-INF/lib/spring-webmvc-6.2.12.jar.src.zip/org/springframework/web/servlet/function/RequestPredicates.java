/*      */ package org.springframework.web.servlet.function;
/*      */ 
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.http.Cookie;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpSession;
/*      */ import jakarta.servlet.http.Part;
/*      */ import java.io.IOException;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.URI;
/*      */ import java.security.Principal;
/*      */ import java.time.Instant;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.ParameterizedTypeReference;
/*      */ import org.springframework.http.HttpMethod;
/*      */ import org.springframework.http.MediaType;
/*      */ import org.springframework.http.converter.HttpMessageConverter;
/*      */ import org.springframework.http.server.PathContainer;
/*      */ import org.springframework.http.server.RequestPath;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.MimeTypeUtils;
/*      */ import org.springframework.util.MultiValueMap;
/*      */ import org.springframework.validation.BindException;
/*      */ import org.springframework.web.bind.WebDataBinder;
/*      */ import org.springframework.web.cors.CorsUtils;
/*      */ import org.springframework.web.util.UriBuilder;
/*      */ import org.springframework.web.util.UriUtils;
/*      */ import org.springframework.web.util.pattern.PathPattern;
/*      */ import org.springframework.web.util.pattern.PathPatternParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class RequestPredicates
/*      */ {
/*   74 */   private static final Log logger = LogFactory.getLog(RequestPredicates.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate all() {
/*   82 */     return request -> true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate method(HttpMethod httpMethod) {
/*   92 */     Assert.notNull(httpMethod, "HttpMethod must not be null");
/*   93 */     return new SingleHttpMethodPredicate(httpMethod);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate methods(HttpMethod... httpMethods) {
/*  103 */     Assert.notEmpty((Object[])httpMethods, "HttpMethods must not be empty");
/*  104 */     if (httpMethods.length == 1) {
/*  105 */       return new SingleHttpMethodPredicate(httpMethods[0]);
/*      */     }
/*      */     
/*  108 */     return new MultipleHttpMethodsPredicate(httpMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate path(String pattern) {
/*  120 */     Assert.notNull(pattern, "'pattern' must not be null");
/*  121 */     PathPatternParser parser = PathPatternParser.defaultInstance;
/*  122 */     pattern = parser.initFullPathPattern(pattern);
/*  123 */     return pathPredicates(parser).apply(pattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Function<String, RequestPredicate> pathPredicates(PathPatternParser patternParser) {
/*  136 */     Assert.notNull(patternParser, "PathPatternParser must not be null");
/*  137 */     return pattern -> new PathPatternPredicate(patternParser.parse(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate headers(Predicate<ServerRequest.Headers> headersPredicate) {
/*  147 */     return new HeadersPredicate(headersPredicate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate contentType(MediaType... mediaTypes) {
/*  158 */     Assert.notEmpty((Object[])mediaTypes, "'mediaTypes' must not be empty");
/*  159 */     if (mediaTypes.length == 1) {
/*  160 */       return new SingleContentTypePredicate(mediaTypes[0]);
/*      */     }
/*      */     
/*  163 */     return new MultipleContentTypesPredicate(mediaTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate accept(MediaType... mediaTypes) {
/*  175 */     Assert.notEmpty((Object[])mediaTypes, "'mediaTypes' must not be empty");
/*  176 */     if (mediaTypes.length == 1) {
/*  177 */       return new SingleAcceptPredicate(mediaTypes[0]);
/*      */     }
/*      */     
/*  180 */     return new MultipleAcceptsPredicate(mediaTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate GET(String pattern) {
/*  193 */     return method(HttpMethod.GET).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate HEAD(String pattern) {
/*  205 */     return method(HttpMethod.HEAD).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate POST(String pattern) {
/*  217 */     return method(HttpMethod.POST).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate PUT(String pattern) {
/*  229 */     return method(HttpMethod.PUT).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate PATCH(String pattern) {
/*  241 */     return method(HttpMethod.PATCH).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate DELETE(String pattern) {
/*  253 */     return method(HttpMethod.DELETE).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate OPTIONS(String pattern) {
/*  265 */     return method(HttpMethod.OPTIONS).and(path(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate pathExtension(String extension) {
/*  274 */     Assert.notNull(extension, "'extension' must not be null");
/*  275 */     return new PathExtensionPredicate(extension);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate pathExtension(Predicate<String> extensionPredicate) {
/*  286 */     return new PathExtensionPredicate(extensionPredicate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate param(String name, String value) {
/*  298 */     return new ParamPredicate(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RequestPredicate param(String name, Predicate<String> predicate) {
/*  310 */     return new ParamPredicate(name, predicate);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void traceMatch(String prefix, Object desired, @Nullable Object actual, boolean match) {
/*  315 */     if (logger.isTraceEnabled()) {
/*  316 */       logger.trace(String.format("%s \"%s\" %s against value \"%s\"", new Object[] { prefix, desired, 
/*  317 */               match ? "matches" : "does not match", actual }));
/*      */     }
/*      */   }
/*      */   
/*      */   private static PathPattern mergePatterns(@Nullable PathPattern oldPattern, PathPattern newPattern) {
/*  322 */     if (oldPattern != null) {
/*  323 */       return oldPattern.combine(newPattern);
/*      */     }
/*      */     
/*  326 */     return newPattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static abstract class RequestModifyingPredicate
/*      */     implements RequestPredicate
/*      */   {
/*      */     public static RequestModifyingPredicate of(final RequestPredicate requestPredicate) {
/*  446 */       if (requestPredicate instanceof RequestModifyingPredicate) { RequestModifyingPredicate modifyingPredicate = (RequestModifyingPredicate)requestPredicate;
/*  447 */         return modifyingPredicate; }
/*      */ 
/*      */       
/*  450 */       return new RequestModifyingPredicate()
/*      */         {
/*      */           protected RequestPredicates.RequestModifyingPredicate.Result testInternal(ServerRequest request) {
/*  453 */             return RequestPredicates.RequestModifyingPredicate.Result.of(requestPredicate.test(request));
/*      */           }
/*      */         };
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean test(ServerRequest request) {
/*  462 */       Result result = testInternal(request);
/*  463 */       boolean value = result.value();
/*  464 */       if (value) {
/*  465 */         result.modifyAttributes(request.attributes());
/*      */       }
/*  467 */       return value;
/*      */     }
/*      */ 
/*      */     
/*      */     protected abstract Result testInternal(ServerRequest param1ServerRequest);
/*      */     
/*      */     protected static final class Result
/*      */     {
/*  475 */       private static final Result TRUE = new Result(true, null);
/*      */       
/*  477 */       private static final Result FALSE = new Result(false, null);
/*      */ 
/*      */       
/*      */       private final boolean value;
/*      */       
/*      */       @Nullable
/*      */       private final Consumer<Map<String, Object>> modifyAttributes;
/*      */ 
/*      */       
/*      */       private Result(boolean value, @Nullable Consumer<Map<String, Object>> modifyAttributes) {
/*  487 */         this.value = value;
/*  488 */         this.modifyAttributes = modifyAttributes;
/*      */       }
/*      */ 
/*      */       
/*      */       public static Result of(boolean value) {
/*  493 */         return of(value, null);
/*      */       }
/*      */       
/*      */       public static Result of(boolean value, @Nullable Consumer<Map<String, Object>> modifyAttributes) {
/*  497 */         if (modifyAttributes == null) {
/*  498 */           return value ? TRUE : FALSE;
/*      */         }
/*      */         
/*  501 */         return new Result(value, modifyAttributes);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean value() {
/*  507 */         return this.value;
/*      */       }
/*      */       
/*      */       public void modifyAttributes(Map<String, Object> attributes) {
/*  511 */         if (this.modifyAttributes != null) {
/*  512 */           this.modifyAttributes.accept(attributes);
/*      */         }
/*      */       }
/*      */       
/*      */       public boolean modifiesAttributes() {
/*  517 */         return (this.modifyAttributes != null); } } } class null extends RequestModifyingPredicate { protected RequestPredicates.RequestModifyingPredicate.Result testInternal(ServerRequest request) { return RequestPredicates.RequestModifyingPredicate.Result.of(requestPredicate.test(request)); } } protected static final class Result { private static final Result TRUE = new Result(true, null); private static final Result FALSE = new Result(false, null); public boolean modifiesAttributes() { return (this.modifyAttributes != null); }
/*      */     private final boolean value; @Nullable
/*      */     private final Consumer<Map<String, Object>> modifyAttributes; private Result(boolean value, @Nullable Consumer<Map<String, Object>> modifyAttributes) { this.value = value;
/*      */       this.modifyAttributes = modifyAttributes; } public static Result of(boolean value) { return of(value, null); } public static Result of(boolean value, @Nullable Consumer<Map<String, Object>> modifyAttributes) { if (modifyAttributes == null)
/*      */         return value ? TRUE : FALSE; 
/*      */       return new Result(value, modifyAttributes); } public boolean value() { return this.value; } public void modifyAttributes(Map<String, Object> attributes) {
/*      */       if (this.modifyAttributes != null)
/*      */         this.modifyAttributes.accept(attributes); 
/*      */     } }
/*      */    private static class SingleHttpMethodPredicate implements RequestPredicate
/*      */   {
/*      */     public SingleHttpMethodPredicate(HttpMethod httpMethod) {
/*  529 */       this.httpMethod = httpMethod;
/*      */     }
/*      */     private final HttpMethod httpMethod;
/*      */     
/*      */     public boolean test(ServerRequest request) {
/*  534 */       HttpMethod method = method(request);
/*  535 */       boolean match = this.httpMethod.equals(method);
/*  536 */       RequestPredicates.traceMatch("Method", this.httpMethod, method, match);
/*  537 */       return match;
/*      */     }
/*      */     
/*      */     static HttpMethod method(ServerRequest request) {
/*  541 */       if (CorsUtils.isPreFlightRequest(request.servletRequest())) {
/*      */         
/*  543 */         String accessControlRequestMethod = request.headers().firstHeader("Access-Control-Request-Method");
/*  544 */         if (accessControlRequestMethod != null) {
/*  545 */           return HttpMethod.valueOf(accessControlRequestMethod);
/*      */         }
/*      */       } 
/*  548 */       return request.method();
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  553 */       visitor.method(Set.of(this.httpMethod));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  558 */       return this.httpMethod.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class MultipleHttpMethodsPredicate
/*      */     implements RequestPredicate
/*      */   {
/*      */     private final Set<HttpMethod> httpMethods;
/*      */     
/*      */     public MultipleHttpMethodsPredicate(HttpMethod[] httpMethods) {
/*  568 */       this.httpMethods = new LinkedHashSet<>(Arrays.asList(httpMethods));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean test(ServerRequest request) {
/*  573 */       HttpMethod method = RequestPredicates.SingleHttpMethodPredicate.method(request);
/*  574 */       boolean match = this.httpMethods.contains(method);
/*  575 */       RequestPredicates.traceMatch("Method", this.httpMethods, method, match);
/*  576 */       return match;
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  581 */       visitor.method(Collections.unmodifiableSet(this.httpMethods));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  586 */       return this.httpMethods.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class PathPatternPredicate
/*      */     extends RequestModifyingPredicate
/*      */     implements ChangePathPatternParserVisitor.Target
/*      */   {
/*      */     private PathPattern pattern;
/*      */     
/*      */     public PathPatternPredicate(PathPattern pattern) {
/*  598 */       Assert.notNull(pattern, "'pattern' must not be null");
/*  599 */       this.pattern = pattern;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected RequestPredicates.RequestModifyingPredicate.Result testInternal(ServerRequest request) {
/*  605 */       PathContainer pathContainer = request.requestPath().pathWithinApplication();
/*  606 */       PathPattern.PathMatchInfo info = this.pattern.matchAndExtract(pathContainer);
/*  607 */       RequestPredicates.traceMatch("Pattern", this.pattern.getPatternString(), request.path(), (info != null));
/*  608 */       if (info != null) {
/*  609 */         return RequestPredicates.RequestModifyingPredicate.Result.of(true, attributes -> modifyAttributes(attributes, request, info.getUriVariables()));
/*      */       }
/*      */       
/*  612 */       return RequestPredicates.RequestModifyingPredicate.Result.of(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void modifyAttributes(Map<String, Object> attributes, ServerRequest request, Map<String, String> variables) {
/*  619 */       Map<String, String> pathVariables = CollectionUtils.compositeMap(request.pathVariables(), variables);
/*      */       
/*  621 */       attributes.put(RouterFunctions.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 
/*  622 */           Collections.unmodifiableMap(pathVariables));
/*      */       
/*  624 */       PathPattern pattern = RequestPredicates.mergePatterns((PathPattern)attributes
/*  625 */           .get(RouterFunctions.MATCHING_PATTERN_ATTRIBUTE), this.pattern);
/*      */ 
/*      */       
/*  628 */       attributes.put(RouterFunctions.MATCHING_PATTERN_ATTRIBUTE, pattern);
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<ServerRequest> nest(ServerRequest request) {
/*  633 */       return Optional.<PathPattern.PathRemainingMatchInfo>ofNullable(this.pattern.matchStartOfPath(request.requestPath().pathWithinApplication()))
/*  634 */         .map(info -> new RequestPredicates.NestedPathPatternServerRequestWrapper(request, info, this.pattern));
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  639 */       visitor.path(this.pattern.getPatternString());
/*      */     }
/*      */ 
/*      */     
/*      */     public void changeParser(PathPatternParser parser) {
/*  644 */       String patternString = this.pattern.getPatternString();
/*  645 */       this.pattern = parser.parse(patternString);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  650 */       return this.pattern.getPatternString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class HeadersPredicate
/*      */     implements RequestPredicate
/*      */   {
/*      */     private final Predicate<ServerRequest.Headers> headersPredicate;
/*      */     
/*      */     public HeadersPredicate(Predicate<ServerRequest.Headers> headersPredicate) {
/*  660 */       Assert.notNull(headersPredicate, "Predicate must not be null");
/*  661 */       this.headersPredicate = headersPredicate;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean test(ServerRequest request) {
/*  666 */       if (CorsUtils.isPreFlightRequest(request.servletRequest())) {
/*  667 */         return true;
/*      */       }
/*      */       
/*  670 */       return this.headersPredicate.test(request.headers());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  676 */       return this.headersPredicate.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SingleContentTypePredicate
/*      */     extends HeadersPredicate
/*      */   {
/*      */     private final MediaType mediaType;
/*      */     
/*      */     public SingleContentTypePredicate(MediaType mediaType) {
/*  686 */       super(headers -> {
/*      */             MediaType contentType = headers.contentType().orElse(MediaType.APPLICATION_OCTET_STREAM);
/*      */             boolean match = mediaType.includes(contentType);
/*      */             RequestPredicates.traceMatch("Content-Type", mediaType, contentType, match);
/*      */             return match;
/*      */           });
/*  692 */       this.mediaType = mediaType;
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  697 */       visitor.header("Content-Type", this.mediaType.toString());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  702 */       return "Content-Type: " + String.valueOf(this.mediaType);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class MultipleContentTypesPredicate
/*      */     extends HeadersPredicate
/*      */   {
/*      */     private final MediaType[] mediaTypes;
/*      */     
/*      */     public MultipleContentTypesPredicate(MediaType[] mediaTypes) {
/*  712 */       super(headers -> {
/*      */             MediaType contentType = headers.contentType().orElse(MediaType.APPLICATION_OCTET_STREAM);
/*      */             boolean match = false;
/*      */             for (MediaType mediaType : mediaTypes) {
/*      */               if (mediaType.includes(contentType)) {
/*      */                 match = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */             RequestPredicates.traceMatch("Content-Type", mediaTypes, contentType, match);
/*      */             return match;
/*      */           });
/*  724 */       this.mediaTypes = mediaTypes;
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  729 */       visitor.header("Content-Type", Arrays.toString((Object[])this.mediaTypes));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  734 */       return "Content-Type: " + Arrays.toString((Object[])this.mediaTypes);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SingleAcceptPredicate
/*      */     extends HeadersPredicate
/*      */   {
/*      */     private final MediaType mediaType;
/*      */     
/*      */     public SingleAcceptPredicate(MediaType mediaType) {
/*  744 */       super(headers -> {
/*      */             List<MediaType> acceptedMediaTypes = acceptedMediaTypes(headers);
/*      */             boolean match = false;
/*      */             for (MediaType acceptedMediaType : acceptedMediaTypes) {
/*      */               if (acceptedMediaType.isCompatibleWith(mediaType)) {
/*      */                 match = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */             RequestPredicates.traceMatch("Accept", mediaType, acceptedMediaTypes, match);
/*      */             return match;
/*      */           });
/*  756 */       this.mediaType = mediaType;
/*      */     }
/*      */     
/*      */     static List<MediaType> acceptedMediaTypes(ServerRequest.Headers headers) {
/*  760 */       List<MediaType> acceptedMediaTypes = headers.accept();
/*  761 */       if (acceptedMediaTypes.isEmpty()) {
/*  762 */         acceptedMediaTypes = Collections.singletonList(MediaType.ALL);
/*      */       } else {
/*      */         
/*  765 */         MimeTypeUtils.sortBySpecificity(acceptedMediaTypes);
/*      */       } 
/*  767 */       return acceptedMediaTypes;
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  772 */       visitor.header("Accept", this.mediaType.toString());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  777 */       return "Accept: " + String.valueOf(this.mediaType);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class MultipleAcceptsPredicate
/*      */     extends HeadersPredicate
/*      */   {
/*      */     private final MediaType[] mediaTypes;
/*      */     
/*      */     public MultipleAcceptsPredicate(MediaType[] mediaTypes) {
/*  787 */       super(headers -> {
/*      */             List<MediaType> acceptedMediaTypes = RequestPredicates.SingleAcceptPredicate.acceptedMediaTypes(headers);
/*      */             
/*      */             boolean match = false;
/*      */             label15: for (MediaType acceptedMediaType : acceptedMediaTypes) {
/*      */               for (MediaType mediaType : mediaTypes) {
/*      */                 if (acceptedMediaType.isCompatibleWith(mediaType)) {
/*      */                   match = true;
/*      */                   break label15;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             RequestPredicates.traceMatch("Accept", mediaTypes, acceptedMediaTypes, match);
/*      */             return match;
/*      */           });
/*  802 */       this.mediaTypes = mediaTypes;
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  807 */       visitor.header("Accept", Arrays.toString((Object[])this.mediaTypes));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  812 */       return "Accept: " + Arrays.toString((Object[])this.mediaTypes);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class PathExtensionPredicate
/*      */     implements RequestPredicate
/*      */   {
/*      */     private final Predicate<String> extensionPredicate;
/*      */     @Nullable
/*      */     private final String extension;
/*      */     
/*      */     public PathExtensionPredicate(Predicate<String> extensionPredicate) {
/*  825 */       Assert.notNull(extensionPredicate, "Predicate must not be null");
/*  826 */       this.extensionPredicate = extensionPredicate;
/*  827 */       this.extension = null;
/*      */     }
/*      */     
/*      */     public PathExtensionPredicate(String extension) {
/*  831 */       Assert.notNull(extension, "Extension must not be null");
/*      */       
/*  833 */       this.extensionPredicate = (s -> {
/*      */           boolean match = extension.equalsIgnoreCase(s);
/*      */           RequestPredicates.traceMatch("Extension", extension, s, match);
/*      */           return match;
/*      */         });
/*  838 */       this.extension = extension;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean test(ServerRequest request) {
/*  843 */       String pathExtension = UriUtils.extractFileExtension(request.path());
/*  844 */       return (pathExtension != null && this.extensionPredicate.test(pathExtension));
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  849 */       visitor.pathExtension(
/*  850 */           (this.extension != null) ? 
/*  851 */           this.extension : 
/*  852 */           this.extensionPredicate.toString());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  857 */       return String.format("*.%s", new Object[] {
/*  858 */             (this.extension != null) ? 
/*  859 */             this.extension : 
/*  860 */             this.extensionPredicate
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class ParamPredicate
/*      */     implements RequestPredicate
/*      */   {
/*      */     private final String name;
/*      */     private final Predicate<String> valuePredicate;
/*      */     @Nullable
/*      */     private final String value;
/*      */     
/*      */     public ParamPredicate(String name, Predicate<String> valuePredicate) {
/*  875 */       Assert.notNull(name, "Name must not be null");
/*  876 */       Assert.notNull(valuePredicate, "Predicate must not be null");
/*  877 */       this.name = name;
/*  878 */       this.valuePredicate = valuePredicate;
/*  879 */       this.value = null;
/*      */     }
/*      */     
/*      */     public ParamPredicate(String name, String value) {
/*  883 */       Assert.notNull(name, "Name must not be null");
/*  884 */       Assert.notNull(value, "Value must not be null");
/*  885 */       this.name = name;
/*  886 */       Objects.requireNonNull(value); this.valuePredicate = value::equals;
/*  887 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean test(ServerRequest request) {
/*  892 */       Optional<String> s = request.param(this.name);
/*  893 */       return s.filter(this.valuePredicate).isPresent();
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  898 */       visitor.param(this.name, 
/*  899 */           (this.value != null) ? 
/*  900 */           this.value : 
/*  901 */           this.valuePredicate.toString());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  906 */       return String.format("?%s %s", new Object[] { this.name, 
/*  907 */             (this.value != null) ? 
/*  908 */             this.value : 
/*  909 */             this.valuePredicate });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class AndRequestPredicate
/*      */     extends RequestModifyingPredicate
/*      */     implements ChangePathPatternParserVisitor.Target
/*      */   {
/*      */     private final RequestPredicate left;
/*      */ 
/*      */     
/*      */     private final RequestPredicates.RequestModifyingPredicate leftModifying;
/*      */ 
/*      */     
/*      */     private final RequestPredicate right;
/*      */     
/*      */     private final RequestPredicates.RequestModifyingPredicate rightModifying;
/*      */ 
/*      */     
/*      */     public AndRequestPredicate(RequestPredicate left, RequestPredicate right) {
/*  931 */       Assert.notNull(left, "Left RequestPredicate must not be null");
/*  932 */       Assert.notNull(right, "Right RequestPredicate must not be null");
/*  933 */       this.left = left;
/*  934 */       this.leftModifying = of(left);
/*  935 */       this.right = right;
/*  936 */       this.rightModifying = of(right);
/*      */     }
/*      */ 
/*      */     
/*      */     protected RequestPredicates.RequestModifyingPredicate.Result testInternal(ServerRequest request) {
/*      */       ServerRequest rightRequest;
/*  942 */       RequestPredicates.RequestModifyingPredicate.Result leftResult = this.leftModifying.testInternal(request);
/*  943 */       if (!leftResult.value()) {
/*  944 */         return leftResult;
/*      */       }
/*      */ 
/*      */       
/*  948 */       if (leftResult.modifiesAttributes()) {
/*  949 */         Map<String, Object> leftAttributes = new LinkedHashMap<>(2);
/*  950 */         leftResult.modifyAttributes(leftAttributes);
/*  951 */         rightRequest = new RequestPredicates.ExtendedAttributesServerRequestWrapper(request, leftAttributes);
/*      */       } else {
/*      */         
/*  954 */         rightRequest = request;
/*      */       } 
/*  956 */       RequestPredicates.RequestModifyingPredicate.Result rightResult = this.rightModifying.testInternal(rightRequest);
/*  957 */       if (!rightResult.value()) {
/*  958 */         return rightResult;
/*      */       }
/*  960 */       return RequestPredicates.RequestModifyingPredicate.Result.of(true, attributes -> {
/*      */             leftResult.modifyAttributes(attributes);
/*      */             rightResult.modifyAttributes(attributes);
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<ServerRequest> nest(ServerRequest request) {
/*  968 */       Objects.requireNonNull(this.right); return this.left.nest(request).flatMap(this.right::nest);
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/*  973 */       visitor.startAnd();
/*  974 */       this.left.accept(visitor);
/*  975 */       visitor.and();
/*  976 */       this.right.accept(visitor);
/*  977 */       visitor.endAnd();
/*      */     }
/*      */ 
/*      */     
/*      */     public void changeParser(PathPatternParser parser) {
/*  982 */       RequestPredicate requestPredicate = this.left; if (requestPredicate instanceof ChangePathPatternParserVisitor.Target) { ChangePathPatternParserVisitor.Target target = (ChangePathPatternParserVisitor.Target)requestPredicate;
/*  983 */         target.changeParser(parser); }
/*      */       
/*  985 */       requestPredicate = this.right; if (requestPredicate instanceof ChangePathPatternParserVisitor.Target) { ChangePathPatternParserVisitor.Target target = (ChangePathPatternParserVisitor.Target)requestPredicate;
/*  986 */         target.changeParser(parser); }
/*      */     
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  992 */       return String.format("(%s && %s)", new Object[] { this.left, this.right });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class NegateRequestPredicate
/*      */     extends RequestModifyingPredicate
/*      */     implements ChangePathPatternParserVisitor.Target
/*      */   {
/*      */     private final RequestPredicate delegate;
/*      */ 
/*      */     
/*      */     private final RequestPredicates.RequestModifyingPredicate delegateModifying;
/*      */ 
/*      */     
/*      */     public NegateRequestPredicate(RequestPredicate delegate) {
/* 1009 */       Assert.notNull(delegate, "Delegate must not be null");
/* 1010 */       this.delegate = delegate;
/* 1011 */       this.delegateModifying = of(delegate);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected RequestPredicates.RequestModifyingPredicate.Result testInternal(ServerRequest request) {
/* 1017 */       RequestPredicates.RequestModifyingPredicate.Result result = this.delegateModifying.testInternal(request);
/* 1018 */       Objects.requireNonNull(result); return RequestPredicates.RequestModifyingPredicate.Result.of(!result.value(), result::modifyAttributes);
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/* 1023 */       visitor.startNegate();
/* 1024 */       this.delegate.accept(visitor);
/* 1025 */       visitor.endNegate();
/*      */     }
/*      */ 
/*      */     
/*      */     public void changeParser(PathPatternParser parser) {
/* 1030 */       RequestPredicate requestPredicate = this.delegate; if (requestPredicate instanceof ChangePathPatternParserVisitor.Target) { ChangePathPatternParserVisitor.Target target = (ChangePathPatternParserVisitor.Target)requestPredicate;
/* 1031 */         target.changeParser(parser); }
/*      */     
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1037 */       return "!" + this.delegate.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class OrRequestPredicate
/*      */     extends RequestModifyingPredicate
/*      */     implements ChangePathPatternParserVisitor.Target
/*      */   {
/*      */     private final RequestPredicate left;
/*      */ 
/*      */     
/*      */     private final RequestPredicates.RequestModifyingPredicate leftModifying;
/*      */ 
/*      */     
/*      */     private final RequestPredicate right;
/*      */     
/*      */     private final RequestPredicates.RequestModifyingPredicate rightModifying;
/*      */ 
/*      */     
/*      */     public OrRequestPredicate(RequestPredicate left, RequestPredicate right) {
/* 1059 */       Assert.notNull(left, "Left RequestPredicate must not be null");
/* 1060 */       Assert.notNull(right, "Right RequestPredicate must not be null");
/* 1061 */       this.left = left;
/* 1062 */       this.leftModifying = of(left);
/* 1063 */       this.right = right;
/* 1064 */       this.rightModifying = of(right);
/*      */     }
/*      */ 
/*      */     
/*      */     protected RequestPredicates.RequestModifyingPredicate.Result testInternal(ServerRequest request) {
/* 1069 */       RequestPredicates.RequestModifyingPredicate.Result leftResult = this.leftModifying.testInternal(request);
/* 1070 */       if (leftResult.value()) {
/* 1071 */         return leftResult;
/*      */       }
/*      */       
/* 1074 */       return this.rightModifying.testInternal(request);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Optional<ServerRequest> nest(ServerRequest request) {
/* 1080 */       Optional<ServerRequest> leftResult = this.left.nest(request);
/* 1081 */       if (leftResult.isPresent()) {
/* 1082 */         return leftResult;
/*      */       }
/*      */       
/* 1085 */       return this.right.nest(request);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(RequestPredicates.Visitor visitor) {
/* 1091 */       visitor.startOr();
/* 1092 */       this.left.accept(visitor);
/* 1093 */       visitor.or();
/* 1094 */       this.right.accept(visitor);
/* 1095 */       visitor.endOr();
/*      */     }
/*      */ 
/*      */     
/*      */     public void changeParser(PathPatternParser parser) {
/* 1100 */       RequestPredicate requestPredicate = this.left; if (requestPredicate instanceof ChangePathPatternParserVisitor.Target) { ChangePathPatternParserVisitor.Target target = (ChangePathPatternParserVisitor.Target)requestPredicate;
/* 1101 */         target.changeParser(parser); }
/*      */       
/* 1103 */       requestPredicate = this.right; if (requestPredicate instanceof ChangePathPatternParserVisitor.Target) { ChangePathPatternParserVisitor.Target target = (ChangePathPatternParserVisitor.Target)requestPredicate;
/* 1104 */         target.changeParser(parser); }
/*      */     
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1110 */       return String.format("(%s || %s)", new Object[] { this.left, this.right });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static abstract class DelegatingServerRequest
/*      */     implements ServerRequest
/*      */   {
/*      */     private final ServerRequest delegate;
/*      */ 
/*      */     
/*      */     protected DelegatingServerRequest(ServerRequest delegate) {
/* 1122 */       Assert.notNull(delegate, "Delegate must not be null");
/* 1123 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     
/*      */     public HttpMethod method() {
/* 1128 */       return this.delegate.method();
/*      */     }
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public String methodName() {
/* 1134 */       return this.delegate.methodName();
/*      */     }
/*      */ 
/*      */     
/*      */     public URI uri() {
/* 1139 */       return this.delegate.uri();
/*      */     }
/*      */ 
/*      */     
/*      */     public UriBuilder uriBuilder() {
/* 1144 */       return this.delegate.uriBuilder();
/*      */     }
/*      */ 
/*      */     
/*      */     public String path() {
/* 1149 */       return this.delegate.path();
/*      */     }
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public PathContainer pathContainer() {
/* 1155 */       return this.delegate.pathContainer();
/*      */     }
/*      */ 
/*      */     
/*      */     public RequestPath requestPath() {
/* 1160 */       return this.delegate.requestPath();
/*      */     }
/*      */ 
/*      */     
/*      */     public ServerRequest.Headers headers() {
/* 1165 */       return this.delegate.headers();
/*      */     }
/*      */ 
/*      */     
/*      */     public MultiValueMap<String, Cookie> cookies() {
/* 1170 */       return this.delegate.cookies();
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<InetSocketAddress> remoteAddress() {
/* 1175 */       return this.delegate.remoteAddress();
/*      */     }
/*      */ 
/*      */     
/*      */     public List<HttpMessageConverter<?>> messageConverters() {
/* 1180 */       return this.delegate.messageConverters();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T body(Class<T> bodyType) throws ServletException, IOException {
/* 1185 */       return this.delegate.body(bodyType);
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T body(ParameterizedTypeReference<T> bodyType) throws ServletException, IOException {
/* 1190 */       return this.delegate.body(bodyType);
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T bind(Class<T> bindType) throws BindException {
/* 1195 */       return this.delegate.bind(bindType);
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T bind(Class<T> bindType, Consumer<WebDataBinder> dataBinderCustomizer) throws BindException {
/* 1200 */       return this.delegate.bind(bindType, dataBinderCustomizer);
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<Object> attribute(String name) {
/* 1205 */       return this.delegate.attribute(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, Object> attributes() {
/* 1210 */       return this.delegate.attributes();
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<String> param(String name) {
/* 1215 */       return this.delegate.param(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public MultiValueMap<String, String> params() {
/* 1220 */       return this.delegate.params();
/*      */     }
/*      */ 
/*      */     
/*      */     public MultiValueMap<String, Part> multipartData() throws IOException, ServletException {
/* 1225 */       return this.delegate.multipartData();
/*      */     }
/*      */ 
/*      */     
/*      */     public String pathVariable(String name) {
/* 1230 */       return this.delegate.pathVariable(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, String> pathVariables() {
/* 1235 */       return this.delegate.pathVariables();
/*      */     }
/*      */ 
/*      */     
/*      */     public HttpSession session() {
/* 1240 */       return this.delegate.session();
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<Principal> principal() {
/* 1245 */       return this.delegate.principal();
/*      */     }
/*      */ 
/*      */     
/*      */     public HttpServletRequest servletRequest() {
/* 1250 */       return this.delegate.servletRequest();
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<ServerResponse> checkNotModified(Instant lastModified) {
/* 1255 */       return this.delegate.checkNotModified(lastModified);
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<ServerResponse> checkNotModified(String etag) {
/* 1260 */       return this.delegate.checkNotModified(etag);
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<ServerResponse> checkNotModified(Instant lastModified, String etag) {
/* 1265 */       return this.delegate.checkNotModified(lastModified, etag);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1270 */       return this.delegate.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class ExtendedAttributesServerRequestWrapper
/*      */     extends DelegatingServerRequest
/*      */   {
/*      */     private final Map<String, Object> attributes;
/*      */     
/*      */     public ExtendedAttributesServerRequestWrapper(ServerRequest delegate, Map<String, Object> newAttributes) {
/* 1281 */       super(delegate);
/* 1282 */       Assert.notNull(newAttributes, "NewAttributes must not be null");
/* 1283 */       Map<String, Object> oldAttributes = delegate.attributes();
/* 1284 */       Objects.requireNonNull(newAttributes);
/* 1285 */       Objects.requireNonNull(newAttributes); this.attributes = CollectionUtils.compositeMap(newAttributes, oldAttributes, newAttributes::put, newAttributes::putAll);
/*      */     }
/*      */ 
/*      */     
/*      */     public Optional<Object> attribute(String name) {
/* 1290 */       return Optional.ofNullable(this.attributes.get(name));
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, Object> attributes() {
/* 1295 */       return this.attributes;
/*      */     }
/*      */ 
/*      */     
/*      */     public String pathVariable(String name) {
/* 1300 */       Map<String, String> pathVariables = pathVariables();
/* 1301 */       if (pathVariables.containsKey(name)) {
/* 1302 */         return pathVariables.get(name);
/*      */       }
/*      */       
/* 1305 */       throw new IllegalArgumentException("No path variable with name \"" + name + "\" available");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, String> pathVariables() {
/* 1312 */       return (Map<String, String>)this.attributes.getOrDefault(RouterFunctions.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 
/* 1313 */           Collections.emptyMap());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class NestedPathPatternServerRequestWrapper
/*      */     extends ExtendedAttributesServerRequestWrapper
/*      */   {
/*      */     private final RequestPath requestPath;
/*      */ 
/*      */     
/*      */     public NestedPathPatternServerRequestWrapper(ServerRequest request, PathPattern.PathRemainingMatchInfo info, PathPattern pattern) {
/* 1325 */       super(request, mergeAttributes(request, info.getUriVariables(), pattern));
/* 1326 */       this.requestPath = requestPath(request.requestPath(), info);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static Map<String, Object> mergeAttributes(ServerRequest request, Map<String, String> newPathVariables, PathPattern newPathPattern) {
/* 1333 */       Map<String, String> pathVariables, oldPathVariables = request.pathVariables();
/*      */       
/* 1335 */       if (oldPathVariables.isEmpty()) {
/* 1336 */         pathVariables = newPathVariables;
/*      */       } else {
/*      */         
/* 1339 */         pathVariables = CollectionUtils.compositeMap(oldPathVariables, newPathVariables);
/*      */       } 
/*      */ 
/*      */       
/* 1343 */       PathPattern oldPathPattern = (PathPattern)request.attribute(RouterFunctions.MATCHING_PATTERN_ATTRIBUTE).orElse(null);
/* 1344 */       PathPattern pathPattern = RequestPredicates.mergePatterns(oldPathPattern, newPathPattern);
/*      */       
/* 1346 */       Map<String, Object> result = CollectionUtils.newLinkedHashMap(2);
/* 1347 */       result.put(RouterFunctions.URI_TEMPLATE_VARIABLES_ATTRIBUTE, pathVariables);
/* 1348 */       result.put(RouterFunctions.MATCHING_PATTERN_ATTRIBUTE, pathPattern);
/* 1349 */       return result;
/*      */     }
/*      */     
/*      */     private static RequestPath requestPath(RequestPath original, PathPattern.PathRemainingMatchInfo info) {
/* 1353 */       StringBuilder contextPath = new StringBuilder(original.contextPath().value());
/* 1354 */       contextPath.append(info.getPathMatched().value());
/* 1355 */       int length = contextPath.length();
/* 1356 */       if (length > 0 && contextPath.charAt(length - 1) == '/') {
/* 1357 */         contextPath.setLength(length - 1);
/*      */       }
/* 1359 */       return original.modifyContextPath(contextPath.toString());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public RequestPath requestPath() {
/* 1365 */       return this.requestPath;
/*      */     }
/*      */ 
/*      */     
/*      */     public String path() {
/* 1370 */       return this.requestPath.pathWithinApplication().value();
/*      */     }
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public PathContainer pathContainer() {
/* 1376 */       return (PathContainer)this.requestPath;
/*      */     }
/*      */   }
/*      */   
/*      */   public static interface Visitor {
/*      */     void method(Set<HttpMethod> param1Set);
/*      */     
/*      */     void path(String param1String);
/*      */     
/*      */     void pathExtension(String param1String);
/*      */     
/*      */     void header(String param1String1, String param1String2);
/*      */     
/*      */     void param(String param1String1, String param1String2);
/*      */     
/*      */     void startAnd();
/*      */     
/*      */     void and();
/*      */     
/*      */     void endAnd();
/*      */     
/*      */     void startOr();
/*      */     
/*      */     void or();
/*      */     
/*      */     void endOr();
/*      */     
/*      */     void startNegate();
/*      */     
/*      */     void endNegate();
/*      */     
/*      */     void unknown(RequestPredicate param1RequestPredicate);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RequestPredicates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */