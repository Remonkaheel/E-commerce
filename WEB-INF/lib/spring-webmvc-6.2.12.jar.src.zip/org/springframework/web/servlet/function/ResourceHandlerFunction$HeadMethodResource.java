/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HeadMethodResource
/*     */   implements Resource
/*     */ {
/*  82 */   private static final byte[] EMPTY = new byte[0];
/*     */   
/*     */   private final Resource delegate;
/*     */   
/*     */   public HeadMethodResource(Resource delegate) {
/*  87 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  92 */     return new ByteArrayInputStream(EMPTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists() {
/*  99 */     return this.delegate.exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getURL() throws IOException {
/* 104 */     return this.delegate.getURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() throws IOException {
/* 109 */     return this.delegate.getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public File getFile() throws IOException {
/* 114 */     return this.delegate.getFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public long contentLength() throws IOException {
/* 119 */     return this.delegate.contentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public long lastModified() throws IOException {
/* 124 */     return this.delegate.lastModified();
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource createRelative(String relativePath) throws IOException {
/* 129 */     return this.delegate.createRelative(relativePath);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getFilename() {
/* 135 */     return this.delegate.getFilename();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 140 */     return this.delegate.getDescription();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ResourceHandlerFunction$HeadMethodResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */