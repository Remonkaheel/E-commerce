package org.springframework.web.servlet.function;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.net.URI;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.Set;
import java.util.function.Consumer;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.lang.Nullable;
import org.springframework.util.MultiValueMap;
import org.springframework.web.servlet.ModelAndView;

public interface HeadersBuilder<B extends ServerResponse.HeadersBuilder<B>> {
  B header(String paramString, String... paramVarArgs);
  
  B headers(Consumer<HttpHeaders> paramConsumer);
  
  B cookie(Cookie paramCookie);
  
  B cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
  
  B allow(HttpMethod... paramVarArgs);
  
  B allow(Set<HttpMethod> paramSet);
  
  B eTag(String paramString);
  
  B lastModified(ZonedDateTime paramZonedDateTime);
  
  B lastModified(Instant paramInstant);
  
  B location(URI paramURI);
  
  B cacheControl(CacheControl paramCacheControl);
  
  B varyBy(String... paramVarArgs);
  
  ServerResponse build();
  
  ServerResponse build(WriteFunction paramWriteFunction);
  
  @FunctionalInterface
  public static interface WriteFunction {
    @Nullable
    ModelAndView write(HttpServletRequest param2HttpServletRequest, HttpServletResponse param2HttpServletResponse) throws Exception;
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse$HeadersBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */