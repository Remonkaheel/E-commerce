package org.springframework.web.servlet.function;

import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;

public interface Builder {
  Builder GET(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder GET(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder GET(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder GET(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder HEAD(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder HEAD(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder HEAD(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder HEAD(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder POST(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder POST(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder POST(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder POST(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PUT(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PUT(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PUT(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PUT(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PATCH(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PATCH(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PATCH(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder PATCH(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder DELETE(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder DELETE(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder DELETE(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder DELETE(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder OPTIONS(HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder OPTIONS(String paramString, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder OPTIONS(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder OPTIONS(String paramString, RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder route(RequestPredicate paramRequestPredicate, HandlerFunction<ServerResponse> paramHandlerFunction);
  
  Builder add(RouterFunction<ServerResponse> paramRouterFunction);
  
  Builder resource(RequestPredicate paramRequestPredicate, Resource paramResource);
  
  Builder resource(RequestPredicate paramRequestPredicate, Resource paramResource, BiConsumer<Resource, HttpHeaders> paramBiConsumer);
  
  Builder resources(String paramString, Resource paramResource);
  
  Builder resources(String paramString, Resource paramResource, BiConsumer<Resource, HttpHeaders> paramBiConsumer);
  
  Builder resources(Function<ServerRequest, Optional<Resource>> paramFunction);
  
  Builder resources(Function<ServerRequest, Optional<Resource>> paramFunction, BiConsumer<Resource, HttpHeaders> paramBiConsumer);
  
  Builder nest(RequestPredicate paramRequestPredicate, Supplier<RouterFunction<ServerResponse>> paramSupplier);
  
  Builder nest(RequestPredicate paramRequestPredicate, Consumer<Builder> paramConsumer);
  
  Builder path(String paramString, Supplier<RouterFunction<ServerResponse>> paramSupplier);
  
  Builder path(String paramString, Consumer<Builder> paramConsumer);
  
  Builder filter(HandlerFilterFunction<ServerResponse, ServerResponse> paramHandlerFilterFunction);
  
  Builder before(Function<ServerRequest, ServerRequest> paramFunction);
  
  Builder after(BiFunction<ServerRequest, ServerResponse, ServerResponse> paramBiFunction);
  
  Builder onError(Predicate<Throwable> paramPredicate, BiFunction<Throwable, ServerRequest, ServerResponse> paramBiFunction);
  
  Builder onError(Class<? extends Throwable> paramClass, BiFunction<Throwable, ServerRequest, ServerResponse> paramBiFunction);
  
  Builder withAttribute(String paramString, Object paramObject);
  
  Builder withAttributes(Consumer<Map<String, Object>> paramConsumer);
  
  RouterFunction<ServerResponse> build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunctions$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */