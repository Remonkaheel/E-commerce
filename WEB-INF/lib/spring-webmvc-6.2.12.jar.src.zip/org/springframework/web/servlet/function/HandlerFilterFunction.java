/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface HandlerFilterFunction<T extends ServerResponse, R extends ServerResponse>
/*     */ {
/*     */   default HandlerFilterFunction<T, R> andThen(HandlerFilterFunction<T, T> after) {
/*  56 */     Assert.notNull(after, "HandlerFilterFunction must not be null");
/*  57 */     return (request, next) -> {
/*     */         HandlerFunction<T> nextHandler = ();
/*     */         return (ServerResponse)filter(request, nextHandler);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default HandlerFunction<R> apply(HandlerFunction<T> handler) {
/*  69 */     Assert.notNull(handler, "HandlerFunction must not be null");
/*  70 */     return request -> filter(request, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends ServerResponse> HandlerFilterFunction<T, T> ofRequestProcessor(Function<ServerRequest, ServerRequest> requestProcessor) {
/*  82 */     Assert.notNull(requestProcessor, "Function must not be null");
/*  83 */     return (request, next) -> next.handle(requestProcessor.apply(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends ServerResponse, R extends ServerResponse> HandlerFilterFunction<T, R> ofResponseProcessor(BiFunction<ServerRequest, T, R> responseProcessor) {
/*  95 */     Assert.notNull(responseProcessor, "Function must not be null");
/*  96 */     return (request, next) -> (ServerResponse)responseProcessor.apply(request, next.handle(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends ServerResponse> HandlerFilterFunction<T, T> ofErrorHandler(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, T> errorHandler) {
/* 109 */     Assert.notNull(predicate, "Predicate must not be null");
/* 110 */     Assert.notNull(errorHandler, "ErrorHandler must not be null");
/*     */     
/* 112 */     return (request, next) -> {
/*     */         try {
/*     */           T t = (T)next.handle(request);
/*     */           if (t instanceof ErrorHandlingServerResponse) {
/*     */             ErrorHandlingServerResponse response = (ErrorHandlingServerResponse)t;
/*     */             response.addErrorHandler(predicate, errorHandler);
/*     */           } 
/*     */           return (ServerResponse)t;
/* 120 */         } catch (Throwable throwable) {
/*     */           if (predicate.test(throwable))
/*     */             return errorHandler.apply(throwable, request); 
/*     */           throw throwable;
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   R filter(ServerRequest paramServerRequest, HandlerFunction<T> paramHandlerFunction) throws Exception;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\HandlerFilterFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */