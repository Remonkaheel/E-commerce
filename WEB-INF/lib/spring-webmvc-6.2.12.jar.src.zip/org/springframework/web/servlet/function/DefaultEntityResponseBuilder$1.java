package org.springframework.web.servlet.function;

import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.support.ResourceRegion;

class null extends ParameterizedTypeReference<List<ResourceRegion>> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultEntityResponseBuilder$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */