/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.security.Principal;
/*    */ import java.util.OptionalLong;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.core.ParameterizedTypeReference;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\0004\n\000\n\002\020\000\n\002\030\002\n\000\n\002\020\016\n\002\b\004\n\002\020\t\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\032\024\020\000\032\004\030\0010\001*\0020\0022\006\020\003\032\0020\004\032\036\020\005\032\002H\006\"\n\b\000\020\006\030\001*\0020\001*\0020\002H\b¢\006\002\020\007\032\021\020\b\032\004\030\0010\t*\0020\n¢\006\002\020\013\032\f\020\f\032\004\030\0010\r*\0020\n\032\024\020\016\032\004\030\0010\004*\0020\0022\006\020\003\032\0020\004\032\f\020\017\032\004\030\0010\020*\0020\002\032\f\020\021\032\004\030\0010\022*\0020\002¨\006\023"}, d2 = {"attributeOrNull", "", "Lorg/springframework/web/servlet/function/ServerRequest;", "name", "", "body", "T", "(Lorg/springframework/web/servlet/function/ServerRequest;)Ljava/lang/Object;", "contentLengthOrNull", "", "Lorg/springframework/web/servlet/function/ServerRequest$Headers;", "(Lorg/springframework/web/servlet/function/ServerRequest$Headers;)Ljava/lang/Long;", "contentTypeOrNull", "Lorg/springframework/http/MediaType;", "paramOrNull", "principalOrNull", "Ljava/security/Principal;", "remoteAddressOrNull", "Ljava/net/InetSocketAddress;", "spring-webmvc"})
/*    */ @SourceDebugExtension({"SMAP\nServerRequestExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ServerRequestExtensions.kt\norg/springframework/web/servlet/function/ServerRequestExtensionsKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,81:1\n1#2:82\n*E\n"})
/*    */ public final class ServerRequestExtensionsKt
/*    */ {
/*    */   @Nullable
/*    */   public static final InetSocketAddress remoteAddressOrNull(@NotNull ServerRequest $this$remoteAddressOrNull) {
/* 30 */     Intrinsics.checkNotNullParameter($this$remoteAddressOrNull, "<this>"); return $this$remoteAddressOrNull.remoteAddress().orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Metadata(mv = {1, 7, 0}, k = 1, xi = 176, d1 = {"\000\013\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001¨\006\002"}, d2 = {"org/springframework/web/servlet/function/ServerRequestExtensionsKt$body$1", "Lorg/springframework/core/ParameterizedTypeReference;", "spring-webmvc"})
/*    */   @SourceDebugExtension({"SMAP\nServerRequestExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ServerRequestExtensions.kt\norg/springframework/web/servlet/function/ServerRequestExtensionsKt$body$1\n*L\n1#1,81:1\n*E\n"})
/*    */   public static final class ServerRequestExtensionsKt$body$1
/*    */     extends ParameterizedTypeReference<T> {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static final Object attributeOrNull(@NotNull ServerRequest $this$attributeOrNull, @NotNull String name) {
/* 48 */     Intrinsics.checkNotNullParameter($this$attributeOrNull, "<this>"); Intrinsics.checkNotNullParameter(name, "name"); return $this$attributeOrNull.attribute(name).orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static final String paramOrNull(@NotNull ServerRequest $this$paramOrNull, @NotNull String name) {
/* 56 */     Intrinsics.checkNotNullParameter($this$paramOrNull, "<this>"); Intrinsics.checkNotNullParameter(name, "name"); return $this$paramOrNull.param(name).orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static final Principal principalOrNull(@NotNull ServerRequest $this$principalOrNull) {
/* 64 */     Intrinsics.checkNotNullParameter($this$principalOrNull, "<this>"); return $this$principalOrNull.principal().orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static final Long contentLengthOrNull(@NotNull ServerRequest.Headers $this$contentLengthOrNull) {
/* 72 */     Intrinsics.checkNotNullParameter($this$contentLengthOrNull, "<this>"); OptionalLong it = $this$contentLengthOrNull.contentLength();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     int $i$a$-let-ServerRequestExtensionsKt$contentLengthOrNull$1 = 0;
/*    */     return it.isPresent() ? Long.valueOf(it.getAsLong()) : null;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public static final MediaType contentTypeOrNull(@NotNull ServerRequest.Headers $this$contentTypeOrNull) {
/*    */     Intrinsics.checkNotNullParameter($this$contentTypeOrNull, "<this>");
/*    */     return $this$contentTypeOrNull.contentType().orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerRequestExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */