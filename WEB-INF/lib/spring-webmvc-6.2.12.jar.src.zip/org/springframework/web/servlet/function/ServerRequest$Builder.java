package org.springframework.web.servlet.function;

import jakarta.servlet.http.Cookie;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.Map;
import java.util.function.Consumer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.MultiValueMap;

public interface Builder {
  Builder method(HttpMethod paramHttpMethod);
  
  Builder uri(URI paramURI);
  
  Builder header(String paramString, String... paramVarArgs);
  
  Builder headers(Consumer<HttpHeaders> paramConsumer);
  
  Builder cookie(String paramString, String... paramVarArgs);
  
  Builder cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
  
  Builder body(byte[] paramArrayOfbyte);
  
  Builder body(String paramString);
  
  Builder attribute(String paramString, Object paramObject);
  
  Builder attributes(Consumer<Map<String, Object>> paramConsumer);
  
  Builder param(String paramString, String... paramVarArgs);
  
  Builder params(Consumer<MultiValueMap<String, String>> paramConsumer);
  
  Builder remoteAddress(InetSocketAddress paramInetSocketAddress);
  
  ServerRequest build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerRequest$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */