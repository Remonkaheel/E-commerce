package org.springframework.web.servlet.function;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.springframework.core.ParameterizedTypeReference;

@Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\026\n\000\n\002\030\002\n\002\b\002\n\002\020\000\n\002\030\002\n\002\b\003\032.\020\000\032\n \002*\004\030\0010\0010\001\"\n\b\000\020\003\030\001*\0020\004*\0020\0052\006\020\006\032\002H\003H\b¢\006\002\020\007¨\006\b"}, d2 = {"bodyWithType", "Lorg/springframework/web/servlet/function/ServerResponse;", "kotlin.jvm.PlatformType", "T", "", "Lorg/springframework/web/servlet/function/ServerResponse$BodyBuilder;", "body", "(Lorg/springframework/web/servlet/function/ServerResponse$BodyBuilder;Ljava/lang/Object;)Lorg/springframework/web/servlet/function/ServerResponse;", "spring-webmvc"})
public final class ServerResponseExtensionsKt {
  @Metadata(mv = {1, 7, 0}, k = 1, xi = 176, d1 = {"\000\013\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001¨\006\002"}, d2 = {"org/springframework/web/servlet/function/ServerResponseExtensionsKt$bodyWithType$1", "Lorg/springframework/core/ParameterizedTypeReference;", "spring-webmvc"})
  @SourceDebugExtension({"SMAP\nServerResponseExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ServerResponseExtensions.kt\norg/springframework/web/servlet/function/ServerResponseExtensionsKt$bodyWithType$1\n*L\n1#1,30:1\n*E\n"})
  public static final class ServerResponseExtensionsKt$bodyWithType$1 extends ParameterizedTypeReference<T> {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponseExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */