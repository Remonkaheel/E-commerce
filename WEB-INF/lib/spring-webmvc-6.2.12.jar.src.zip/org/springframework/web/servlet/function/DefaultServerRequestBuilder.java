/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ReadListener;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.Part;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.SmartHttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.util.UriBuilder;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultServerRequestBuilder
/*     */   implements ServerRequest.Builder
/*     */ {
/*     */   private final HttpServletRequest servletRequest;
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private HttpMethod method;
/*     */   private URI uri;
/*  81 */   private final HttpHeaders headers = new HttpHeaders();
/*     */   
/*  83 */   private final MultiValueMap<String, Cookie> cookies = (MultiValueMap<String, Cookie>)new LinkedMultiValueMap();
/*     */   
/*  85 */   private final Map<String, Object> attributes = new LinkedHashMap<>();
/*     */   
/*  87 */   private final MultiValueMap<String, String> params = (MultiValueMap<String, String>)new LinkedMultiValueMap();
/*     */   
/*     */   @Nullable
/*     */   private InetSocketAddress remoteAddress;
/*     */   
/*  92 */   private byte[] body = new byte[0];
/*     */ 
/*     */   
/*     */   public DefaultServerRequestBuilder(ServerRequest other) {
/*  96 */     Assert.notNull(other, "ServerRequest must not be null");
/*  97 */     this.servletRequest = other.servletRequest();
/*  98 */     this.messageConverters = new ArrayList<>(other.messageConverters());
/*  99 */     this.method = other.method();
/* 100 */     this.uri = other.uri();
/* 101 */     headers(headers -> headers.addAll((MultiValueMap)other.headers().asHttpHeaders()));
/* 102 */     cookies(cookies -> cookies.addAll(other.cookies()));
/* 103 */     attributes(attributes -> attributes.putAll(other.attributes()));
/* 104 */     params(params -> params.addAll(other.params()));
/* 105 */     this.remoteAddress = other.remoteAddress().orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder method(HttpMethod method) {
/* 110 */     Assert.notNull(method, "HttpMethod must not be null");
/* 111 */     this.method = method;
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder uri(URI uri) {
/* 117 */     Assert.notNull(uri, "URI must not be null");
/* 118 */     this.uri = uri;
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder header(String headerName, String... headerValues) {
/* 124 */     Assert.notNull(headerName, "Header name must not be null");
/* 125 */     for (String headerValue : headerValues) {
/* 126 */       this.headers.add(headerName, headerValue);
/*     */     }
/* 128 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder headers(Consumer<HttpHeaders> headersConsumer) {
/* 133 */     Assert.notNull(headersConsumer, "Headers consumer must not be null");
/* 134 */     headersConsumer.accept(this.headers);
/* 135 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder cookie(String name, String... values) {
/* 140 */     Assert.notNull(name, "Cookie name must not be null");
/* 141 */     for (String value : values) {
/* 142 */       this.cookies.add(name, new Cookie(name, value));
/*     */     }
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder cookies(Consumer<MultiValueMap<String, Cookie>> cookiesConsumer) {
/* 149 */     Assert.notNull(cookiesConsumer, "Cookies consumer must not be null");
/* 150 */     cookiesConsumer.accept(this.cookies);
/* 151 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder body(byte[] body) {
/* 156 */     Assert.notNull(body, "Body must not be null");
/* 157 */     this.body = body;
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder body(String body) {
/* 163 */     Assert.notNull(body, "Body must not be null");
/* 164 */     return body(body.getBytes(StandardCharsets.UTF_8));
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder attribute(String name, Object value) {
/* 169 */     Assert.notNull(name, "Name must not be null");
/* 170 */     this.attributes.put(name, value);
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder attributes(Consumer<Map<String, Object>> attributesConsumer) {
/* 176 */     Assert.notNull(attributesConsumer, "Attributes consumer must not be null");
/* 177 */     attributesConsumer.accept(this.attributes);
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder param(String name, String... values) {
/* 183 */     Assert.notNull(name, "Name must not be null");
/* 184 */     for (String value : values) {
/* 185 */       this.params.add(name, value);
/*     */     }
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder params(Consumer<MultiValueMap<String, String>> paramsConsumer) {
/* 192 */     Assert.notNull(paramsConsumer, "Parameters consumer must not be null");
/* 193 */     paramsConsumer.accept(this.params);
/* 194 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerRequest.Builder remoteAddress(@Nullable InetSocketAddress remoteAddress) {
/* 199 */     this.remoteAddress = remoteAddress;
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerRequest build() {
/* 206 */     return new BuiltServerRequest(this.servletRequest, this.method, this.uri, this.headers, this.cookies, this.attributes, this.params, this.remoteAddress, this.body, this.messageConverters);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BuiltServerRequest
/*     */     implements ServerRequest
/*     */   {
/*     */     private final HttpMethod method;
/*     */ 
/*     */     
/*     */     private final URI uri;
/*     */ 
/*     */     
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     private final HttpServletRequest servletRequest;
/*     */     
/*     */     private final MultiValueMap<String, Cookie> cookies;
/*     */     
/*     */     private final Map<String, Object> attributes;
/*     */     
/*     */     private final byte[] body;
/*     */     
/*     */     private final List<HttpMessageConverter<?>> messageConverters;
/*     */     
/*     */     private final MultiValueMap<String, String> params;
/*     */     
/*     */     @Nullable
/*     */     private final InetSocketAddress remoteAddress;
/*     */ 
/*     */     
/*     */     public BuiltServerRequest(HttpServletRequest servletRequest, HttpMethod method, URI uri, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, Map<String, Object> attributes, MultiValueMap<String, String> params, @Nullable InetSocketAddress remoteAddress, byte[] body, List<HttpMessageConverter<?>> messageConverters) {
/* 239 */       this.servletRequest = servletRequest;
/* 240 */       this.method = method;
/* 241 */       this.uri = uri;
/* 242 */       this.headers = new HttpHeaders((MultiValueMap)headers);
/* 243 */       this.cookies = (MultiValueMap<String, Cookie>)new LinkedMultiValueMap((Map)cookies);
/* 244 */       this.attributes = new LinkedHashMap<>(attributes);
/* 245 */       this.params = (MultiValueMap<String, String>)new LinkedMultiValueMap((Map)params);
/* 246 */       this.remoteAddress = remoteAddress;
/* 247 */       this.body = body;
/* 248 */       this.messageConverters = messageConverters;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpMethod method() {
/* 253 */       return this.method;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public String methodName() {
/* 259 */       return this.method.name();
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiValueMap<String, Part> multipartData() throws IOException, ServletException {
/* 264 */       return (MultiValueMap<String, Part>)servletRequest().getParts().stream()
/* 265 */         .collect(Collectors.groupingBy(Part::getName, LinkedMultiValueMap::new, 
/*     */             
/* 267 */             Collectors.toList()));
/*     */     }
/*     */ 
/*     */     
/*     */     public URI uri() {
/* 272 */       return this.uri;
/*     */     }
/*     */ 
/*     */     
/*     */     public UriBuilder uriBuilder() {
/* 277 */       return (UriBuilder)UriComponentsBuilder.fromUri(this.uri);
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerRequest.Headers headers() {
/* 282 */       return new DefaultServerRequest.DefaultRequestHeaders(this.headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiValueMap<String, Cookie> cookies() {
/* 287 */       return this.cookies;
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<InetSocketAddress> remoteAddress() {
/* 292 */       return Optional.ofNullable(this.remoteAddress);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<HttpMessageConverter<?>> messageConverters() {
/* 297 */       return this.messageConverters;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T body(Class<T> bodyType) throws IOException, ServletException {
/* 302 */       return bodyInternal(bodyType, bodyType);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T body(ParameterizedTypeReference<T> bodyType) throws IOException, ServletException {
/* 307 */       Type type = bodyType.getType();
/* 308 */       return bodyInternal(type, DefaultServerRequest.bodyClass(type));
/*     */     }
/*     */ 
/*     */     
/*     */     private <T> T bodyInternal(Type bodyType, Class<?> bodyClass) throws ServletException, IOException {
/* 313 */       HttpInputMessage inputMessage = new BuiltInputMessage();
/* 314 */       MediaType contentType = headers().contentType().orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */       
/* 316 */       for (HttpMessageConverter<?> messageConverter : this.messageConverters) {
/* 317 */         if (messageConverter instanceof GenericHttpMessageConverter) { GenericHttpMessageConverter<?> genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/* 318 */           if (genericMessageConverter.canRead(bodyType, bodyClass, contentType))
/* 319 */             return (T)genericMessageConverter.read(bodyType, bodyClass, inputMessage); 
/*     */           continue; }
/*     */         
/* 322 */         if (messageConverter instanceof SmartHttpMessageConverter) { SmartHttpMessageConverter<?> smartMessageConverter = (SmartHttpMessageConverter)messageConverter;
/* 323 */           ResolvableType resolvableType = ResolvableType.forType(bodyType);
/* 324 */           if (smartMessageConverter.canRead(resolvableType, contentType))
/* 325 */             return (T)smartMessageConverter.read(resolvableType, inputMessage, null); 
/*     */           continue; }
/*     */         
/* 328 */         if (messageConverter.canRead(bodyClass, contentType)) {
/* 329 */           HttpMessageConverter<T> theConverter = (HttpMessageConverter)messageConverter;
/*     */           
/* 331 */           Class<? extends T> clazz = (Class)bodyClass;
/* 332 */           return (T)theConverter.read(clazz, inputMessage);
/*     */         } 
/*     */       } 
/* 335 */       throw new HttpMediaTypeNotSupportedException(contentType, Collections.emptyList(), method());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> T bind(Class<T> bindType, Consumer<WebDataBinder> dataBinderCustomizer) throws BindException {
/* 341 */       Assert.notNull(bindType, "BindType must not be null");
/* 342 */       Assert.notNull(dataBinderCustomizer, "DataBinderCustomizer must not be null");
/*     */       
/* 344 */       ServletRequestDataBinder dataBinder = new ServletRequestDataBinder(null);
/* 345 */       dataBinder.setTargetType(ResolvableType.forClass(bindType));
/* 346 */       dataBinderCustomizer.accept(dataBinder);
/*     */       
/* 348 */       HttpServletRequest servletRequest = servletRequest();
/* 349 */       dataBinder.construct((ServletRequest)servletRequest);
/* 350 */       dataBinder.bind((ServletRequest)servletRequest);
/*     */       
/* 352 */       BindingResult bindingResult = dataBinder.getBindingResult();
/* 353 */       if (bindingResult.hasErrors()) {
/* 354 */         throw new BindException(bindingResult);
/*     */       }
/*     */       
/* 357 */       T result = (T)bindingResult.getTarget();
/* 358 */       if (result != null) {
/* 359 */         return result;
/*     */       }
/*     */       
/* 362 */       throw new IllegalStateException("Binding result has neither target nor errors");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<String, Object> attributes() {
/* 369 */       return this.attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiValueMap<String, String> params() {
/* 374 */       return this.params;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<String, String> pathVariables() {
/* 381 */       Map<String, String> pathVariables = (Map<String, String>)attributes().get(RouterFunctions.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/* 382 */       if (pathVariables != null) {
/* 383 */         return pathVariables;
/*     */       }
/*     */       
/* 386 */       return Collections.emptyMap();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public HttpSession session() {
/* 392 */       return this.servletRequest.getSession();
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<Principal> principal() {
/* 397 */       return Optional.ofNullable(this.servletRequest.getUserPrincipal());
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpServletRequest servletRequest() {
/* 402 */       return this.servletRequest;
/*     */     }
/*     */ 
/*     */     
/*     */     private class BuiltInputMessage
/*     */       implements HttpInputMessage
/*     */     {
/*     */       public InputStream getBody() throws IOException {
/* 410 */         return (InputStream)new DefaultServerRequestBuilder.BodyInputStream(DefaultServerRequestBuilder.BuiltServerRequest.this.body);
/*     */       }
/*     */       
/*     */       public HttpHeaders getHeaders()
/*     */       {
/* 415 */         return DefaultServerRequestBuilder.BuiltServerRequest.this.headers; } } } private class BuiltInputMessage implements HttpInputMessage { public HttpHeaders getHeaders() { return this.this$0.headers; }
/*     */ 
/*     */     
/*     */     public InputStream getBody() throws IOException {
/*     */       return (InputStream)new DefaultServerRequestBuilder.BodyInputStream(this.this$0.body);
/*     */     } }
/*     */   
/*     */   private static class BodyInputStream extends ServletInputStream {
/*     */     private final InputStream delegate;
/*     */     
/*     */     public BodyInputStream(byte[] body) {
/* 426 */       this.delegate = new ByteArrayInputStream(body);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFinished() {
/* 431 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isReady() {
/* 436 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setReadListener(ReadListener readListener) {
/* 441 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 446 */       return this.delegate.read();
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 451 */       return this.delegate.read(b, off, len);
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b) throws IOException {
/* 456 */       return this.delegate.read(b);
/*     */     }
/*     */ 
/*     */     
/*     */     public long skip(long n) throws IOException {
/* 461 */       return this.delegate.skip(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/* 466 */       return this.delegate.available();
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 471 */       this.delegate.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void mark(int readlimit) {
/* 476 */       this.delegate.mark(readlimit);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void reset() throws IOException {
/* 481 */       this.delegate.reset();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean markSupported() {
/* 486 */       return this.delegate.markSupported();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultServerRequestBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */