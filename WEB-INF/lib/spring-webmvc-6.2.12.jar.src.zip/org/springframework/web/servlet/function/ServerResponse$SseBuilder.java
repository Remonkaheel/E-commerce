package org.springframework.web.servlet.function;

import java.io.IOException;
import java.time.Duration;
import java.util.function.Consumer;

public interface SseBuilder {
  void error(Throwable paramThrowable);
  
  void complete();
  
  SseBuilder onTimeout(Runnable paramRunnable);
  
  SseBuilder onError(Consumer<Throwable> paramConsumer);
  
  SseBuilder onComplete(Runnable paramRunnable);
  
  void send(Object paramObject) throws IOException;
  
  void send() throws IOException;
  
  SseBuilder id(String paramString);
  
  SseBuilder event(String paramString);
  
  SseBuilder retry(Duration paramDuration);
  
  SseBuilder comment(String paramString);
  
  void data(Object paramObject) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse$SseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */