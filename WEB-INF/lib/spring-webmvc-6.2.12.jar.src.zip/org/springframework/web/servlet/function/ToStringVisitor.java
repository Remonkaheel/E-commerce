/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ToStringVisitor
/*     */   implements RouterFunctions.Visitor, RequestPredicates.Visitor
/*     */ {
/*  36 */   private final StringBuilder builder = new StringBuilder();
/*     */   
/*  38 */   private int indent = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startNested(RequestPredicate predicate) {
/*  45 */     indent();
/*  46 */     predicate.accept(this);
/*  47 */     this.builder.append(" => {\n");
/*  48 */     this.indent++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endNested(RequestPredicate predicate) {
/*  53 */     this.indent--;
/*  54 */     indent();
/*  55 */     this.builder.append("}\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public void route(RequestPredicate predicate, HandlerFunction<?> handlerFunction) {
/*  60 */     indent();
/*  61 */     predicate.accept(this);
/*  62 */     this.builder.append(" -> ");
/*  63 */     this.builder.append(handlerFunction).append('\n');
/*     */   }
/*     */ 
/*     */   
/*     */   public void resources(Function<ServerRequest, Optional<Resource>> lookupFunction) {
/*  68 */     indent();
/*  69 */     this.builder.append(lookupFunction).append('\n');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void attributes(Map<String, Object> attributes) {}
/*     */ 
/*     */   
/*     */   public void unknown(RouterFunction<?> routerFunction) {
/*  78 */     indent();
/*  79 */     this.builder.append(routerFunction);
/*     */   }
/*     */   
/*     */   private void indent() {
/*  83 */     this.builder.append(" ".repeat(Math.max(0, this.indent)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void method(Set<HttpMethod> methods) {
/*  91 */     if (methods.size() == 1) {
/*  92 */       this.builder.append(methods.iterator().next());
/*     */     } else {
/*     */       
/*  95 */       this.builder.append(methods);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void path(String pattern) {
/* 101 */     this.builder.append(pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pathExtension(String extension) {
/* 106 */     this.builder.append(String.format("*.%s", new Object[] { extension }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void header(String name, String value) {
/* 111 */     this.builder.append(String.format("%s: %s", new Object[] { name, value }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void param(String name, String value) {
/* 116 */     this.builder.append(String.format("?%s == %s", new Object[] { name, value }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void startAnd() {
/* 121 */     this.builder.append('(');
/*     */   }
/*     */ 
/*     */   
/*     */   public void and() {
/* 126 */     this.builder.append(" && ");
/*     */   }
/*     */ 
/*     */   
/*     */   public void endAnd() {
/* 131 */     this.builder.append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public void startOr() {
/* 136 */     this.builder.append('(');
/*     */   }
/*     */ 
/*     */   
/*     */   public void or() {
/* 141 */     this.builder.append(" || ");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endOr() {
/* 147 */     this.builder.append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public void startNegate() {
/* 152 */     this.builder.append("!(");
/*     */   }
/*     */ 
/*     */   
/*     */   public void endNegate() {
/* 157 */     this.builder.append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public void unknown(RequestPredicate predicate) {
/* 162 */     this.builder.append(predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     String result = this.builder.toString();
/* 168 */     if (result.endsWith("\n")) {
/* 169 */       result = result.substring(0, result.length() - 1);
/*     */     }
/* 171 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ToStringVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */