/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.Part;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.time.Instant;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalLong;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ServerRequest
/*     */ {
/*     */   default String path() {
/*  97 */     return requestPath().pathWithinApplication().value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default PathContainer pathContainer() {
/* 106 */     return (PathContainer)requestPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RequestPath requestPath() {
/* 114 */     return ServletRequestPathUtils.getParsedRequestPath((ServletRequest)servletRequest());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T bind(Class<T> bindType) throws BindException {
/* 162 */     return bind(bindType, dataBinder -> {
/*     */         
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<Object> attribute(String name) {
/* 183 */     Map<String, Object> attributes = attributes();
/* 184 */     if (attributes.containsKey(name)) {
/* 185 */       return Optional.of(attributes.get(name));
/*     */     }
/*     */     
/* 188 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<String> param(String name) {
/* 206 */     List<String> paramValues = (List<String>)params().get(name);
/* 207 */     if (CollectionUtils.isEmpty(paramValues)) {
/* 208 */       return Optional.empty();
/*     */     }
/*     */     
/* 211 */     String value = paramValues.get(0);
/* 212 */     if (value == null) {
/* 213 */       value = "";
/*     */     }
/* 215 */     return Optional.of(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String pathVariable(String name) {
/* 244 */     Map<String, String> pathVariables = pathVariables();
/* 245 */     if (pathVariables.containsKey(name)) {
/* 246 */       return pathVariables.get(name);
/*     */     }
/*     */     
/* 249 */     throw new IllegalArgumentException("No path variable with name \"" + name + "\" available");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<ServerResponse> checkNotModified(Instant lastModified) {
/* 307 */     Assert.notNull(lastModified, "LastModified must not be null");
/* 308 */     return DefaultServerRequest.checkNotModified(servletRequest(), lastModified, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<ServerResponse> checkNotModified(String etag) {
/* 342 */     Assert.notNull(etag, "Etag must not be null");
/* 343 */     return DefaultServerRequest.checkNotModified(servletRequest(), null, etag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<ServerResponse> checkNotModified(Instant lastModified, String etag) {
/* 375 */     Assert.notNull(lastModified, "LastModified must not be null");
/* 376 */     Assert.notNull(etag, "Etag must not be null");
/* 377 */     return DefaultServerRequest.checkNotModified(servletRequest(), lastModified, etag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ServerRequest create(HttpServletRequest servletRequest, List<HttpMessageConverter<?>> messageReaders) {
/* 391 */     return new DefaultServerRequest(servletRequest, messageReaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder from(ServerRequest other) {
/* 400 */     return new DefaultServerRequestBuilder(other);
/*     */   }
/*     */   
/*     */   HttpMethod method();
/*     */   
/*     */   @Deprecated
/*     */   String methodName();
/*     */   
/*     */   URI uri();
/*     */   
/*     */   UriBuilder uriBuilder();
/*     */   
/*     */   Headers headers();
/*     */   
/*     */   MultiValueMap<String, Cookie> cookies();
/*     */   
/*     */   Optional<InetSocketAddress> remoteAddress();
/*     */   
/*     */   List<HttpMessageConverter<?>> messageConverters();
/*     */   
/*     */   <T> T body(Class<T> paramClass) throws ServletException, IOException;
/*     */   
/*     */   <T> T body(ParameterizedTypeReference<T> paramParameterizedTypeReference) throws ServletException, IOException;
/*     */   
/*     */   <T> T bind(Class<T> paramClass, Consumer<WebDataBinder> paramConsumer) throws BindException;
/*     */   
/*     */   Map<String, Object> attributes();
/*     */   
/*     */   MultiValueMap<String, String> params();
/*     */   
/*     */   MultiValueMap<String, Part> multipartData() throws IOException, ServletException;
/*     */   
/*     */   Map<String, String> pathVariables();
/*     */   
/*     */   HttpSession session();
/*     */   
/*     */   Optional<Principal> principal();
/*     */   
/*     */   HttpServletRequest servletRequest();
/*     */   
/*     */   public static interface Builder {
/*     */     Builder method(HttpMethod param1HttpMethod);
/*     */     
/*     */     Builder uri(URI param1URI);
/*     */     
/*     */     Builder header(String param1String, String... param1VarArgs);
/*     */     
/*     */     Builder headers(Consumer<HttpHeaders> param1Consumer);
/*     */     
/*     */     Builder cookie(String param1String, String... param1VarArgs);
/*     */     
/*     */     Builder cookies(Consumer<MultiValueMap<String, Cookie>> param1Consumer);
/*     */     
/*     */     Builder body(byte[] param1ArrayOfbyte);
/*     */     
/*     */     Builder body(String param1String);
/*     */     
/*     */     Builder attribute(String param1String, Object param1Object);
/*     */     
/*     */     Builder attributes(Consumer<Map<String, Object>> param1Consumer);
/*     */     
/*     */     Builder param(String param1String, String... param1VarArgs);
/*     */     
/*     */     Builder params(Consumer<MultiValueMap<String, String>> param1Consumer);
/*     */     
/*     */     Builder remoteAddress(InetSocketAddress param1InetSocketAddress);
/*     */     
/*     */     ServerRequest build(); }
/*     */   
/*     */   public static interface Headers {
/*     */     @Nullable
/*     */     default String firstHeader(String headerName) {
/* 472 */       List<String> list = header(headerName);
/* 473 */       return list.isEmpty() ? null : list.get(0);
/*     */     }
/*     */     
/*     */     List<MediaType> accept();
/*     */     
/*     */     List<Charset> acceptCharset();
/*     */     
/*     */     List<Locale.LanguageRange> acceptLanguage();
/*     */     
/*     */     OptionalLong contentLength();
/*     */     
/*     */     Optional<MediaType> contentType();
/*     */     
/*     */     @Nullable
/*     */     InetSocketAddress host();
/*     */     
/*     */     List<HttpRange> range();
/*     */     
/*     */     List<String> header(String param1String);
/*     */     
/*     */     HttpHeaders asHttpHeaders();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */