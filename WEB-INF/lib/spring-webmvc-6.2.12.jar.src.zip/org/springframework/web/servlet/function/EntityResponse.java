/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import java.net.URI;
/*    */ import java.time.Instant;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.core.ParameterizedTypeReference;
/*    */ import org.springframework.http.CacheControl;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface EntityResponse<T>
/*    */   extends ServerResponse
/*    */ {
/*    */   T entity();
/*    */   
/*    */   static <T> Builder<T> fromObject(T t) {
/* 59 */     return DefaultEntityResponseBuilder.fromObject(t);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Builder<T> fromObject(T t, ParameterizedTypeReference<T> entityType) {
/* 70 */     return DefaultEntityResponseBuilder.fromObject(t, entityType);
/*    */   }
/*    */   
/*    */   public static interface Builder<T> {
/*    */     Builder<T> header(String param1String, String... param1VarArgs);
/*    */     
/*    */     Builder<T> headers(Consumer<HttpHeaders> param1Consumer);
/*    */     
/*    */     Builder<T> status(HttpStatusCode param1HttpStatusCode);
/*    */     
/*    */     Builder<T> status(int param1Int);
/*    */     
/*    */     Builder<T> cookie(Cookie param1Cookie);
/*    */     
/*    */     Builder<T> cookies(Consumer<MultiValueMap<String, Cookie>> param1Consumer);
/*    */     
/*    */     Builder<T> allow(HttpMethod... param1VarArgs);
/*    */     
/*    */     Builder<T> allow(Set<HttpMethod> param1Set);
/*    */     
/*    */     Builder<T> eTag(String param1String);
/*    */     
/*    */     Builder<T> lastModified(ZonedDateTime param1ZonedDateTime);
/*    */     
/*    */     Builder<T> lastModified(Instant param1Instant);
/*    */     
/*    */     Builder<T> location(URI param1URI);
/*    */     
/*    */     Builder<T> cacheControl(CacheControl param1CacheControl);
/*    */     
/*    */     Builder<T> varyBy(String... param1VarArgs);
/*    */     
/*    */     Builder<T> contentLength(long param1Long);
/*    */     
/*    */     Builder<T> contentType(MediaType param1MediaType);
/*    */     
/*    */     EntityResponse<T> build();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\EntityResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */