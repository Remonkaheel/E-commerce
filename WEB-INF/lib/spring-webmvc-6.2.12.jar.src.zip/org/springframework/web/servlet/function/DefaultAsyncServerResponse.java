/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.context.request.async.AsyncWebRequest;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultAsyncServerResponse
/*     */   extends ErrorHandlingServerResponse
/*     */   implements AsyncServerResponse
/*     */ {
/*  52 */   static final boolean reactiveStreamsPresent = ClassUtils.isPresent("org.reactivestreams.Publisher", DefaultAsyncServerResponse.class
/*  53 */       .getClassLoader());
/*     */   
/*     */   private final CompletableFuture<ServerResponse> futureResponse;
/*     */   
/*     */   @Nullable
/*     */   private final Duration timeout;
/*     */ 
/*     */   
/*     */   DefaultAsyncServerResponse(CompletableFuture<ServerResponse> futureResponse, @Nullable Duration timeout) {
/*  62 */     this.futureResponse = futureResponse;
/*  63 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerResponse block() {
/*     */     try {
/*  70 */       if (this.timeout != null) {
/*  71 */         return this.futureResponse.get(this.timeout.toMillis(), TimeUnit.MILLISECONDS);
/*     */       }
/*     */       
/*  74 */       return this.futureResponse.get();
/*     */     
/*     */     }
/*  77 */     catch (InterruptedException|java.util.concurrent.ExecutionException|java.util.concurrent.TimeoutException ex) {
/*  78 */       throw new IllegalStateException("Failed to get future response", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode statusCode() {
/*  84 */     return delegate(ServerResponse::statusCode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int rawStatusCode() {
/*  91 */     return ((Integer)delegate(ServerResponse::rawStatusCode)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders headers() {
/*  96 */     return delegate(ServerResponse::headers);
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, Cookie> cookies() {
/* 101 */     return delegate(ServerResponse::cookies);
/*     */   }
/*     */   
/*     */   private <R> R delegate(Function<ServerResponse, R> function) {
/* 105 */     ServerResponse response = this.futureResponse.getNow(null);
/* 106 */     if (response != null) {
/* 107 */       return function.apply(response);
/*     */     }
/*     */     
/* 110 */     throw new IllegalStateException("Future ServerResponse has not yet completed");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ModelAndView writeTo(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) throws ServletException, IOException {
/* 119 */     writeAsync(request, response, createDeferredResult(request));
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeAsync(HttpServletRequest request, HttpServletResponse response, DeferredResult<?> deferredResult) throws ServletException, IOException {
/* 126 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager((ServletRequest)request);
/* 127 */     AsyncWebRequest asyncWebRequest = WebAsyncUtils.createAsyncWebRequest(request, response);
/* 128 */     asyncManager.setAsyncWebRequest(asyncWebRequest);
/*     */     try {
/* 130 */       asyncManager.startDeferredResultProcessing(deferredResult, new Object[0]);
/*     */     }
/* 132 */     catch (IOException|ServletException ex) {
/* 133 */       throw ex;
/*     */     }
/* 135 */     catch (Exception ex) {
/* 136 */       throw new ServletException("Async processing failed", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private DeferredResult<ServerResponse> createDeferredResult(HttpServletRequest request) {
/*     */     DeferredResult<ServerResponse> result;
/* 143 */     if (this.timeout != null) {
/* 144 */       result = new DeferredResult(Long.valueOf(this.timeout.toMillis()));
/*     */     } else {
/*     */       
/* 147 */       result = new DeferredResult();
/*     */     } 
/* 149 */     this.futureResponse.whenComplete((value, ex) -> {
/*     */           if (ex != null) {
/*     */             if (ex instanceof java.util.concurrent.CompletionException && ex.getCause() != null) {
/*     */               ex = ex.getCause();
/*     */             }
/*     */             
/*     */             ServerResponse errorResponse = errorResponse(ex, request);
/*     */             
/*     */             if (errorResponse != null) {
/*     */               result.setResult(errorResponse);
/*     */             } else {
/*     */               result.setErrorResult(ex);
/*     */             } 
/*     */           } else {
/*     */             result.setResult(value);
/*     */           } 
/*     */         });
/* 166 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultAsyncServerResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */