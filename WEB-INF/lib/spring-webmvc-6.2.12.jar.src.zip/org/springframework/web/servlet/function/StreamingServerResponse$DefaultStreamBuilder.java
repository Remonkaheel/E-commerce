/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.DelegatingServerHttpResponse;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultStreamBuilder
/*     */   implements ServerResponse.StreamBuilder
/*     */ {
/*     */   private final ServerHttpResponse outputMessage;
/*     */   private final DeferredResult<?> deferredResult;
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private final HttpHeaders httpHeaders;
/*     */   private boolean sendFailed;
/*     */   
/*     */   public DefaultStreamBuilder(HttpServletResponse response, ServerResponse.Context context, DeferredResult<?> deferredResult, HttpHeaders httpHeaders) {
/* 100 */     this.outputMessage = (ServerHttpResponse)new ServletServerHttpResponse(response);
/* 101 */     this.deferredResult = deferredResult;
/* 102 */     this.messageConverters = context.messageConverters();
/* 103 */     this.httpHeaders = httpHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.StreamBuilder write(Object object) throws IOException {
/* 108 */     write(object, null);
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.StreamBuilder write(Object object, @Nullable MediaType mediaType) throws IOException {
/* 114 */     Assert.notNull(object, "data must not be null");
/*     */     try {
/* 116 */       if (object instanceof byte[]) { byte[] bytes = (byte[])object;
/* 117 */         this.outputMessage.getBody().write(bytes); }
/*     */       
/* 119 */       else if (object instanceof String) { String str = (String)object;
/* 120 */         this.outputMessage.getBody().write(str.getBytes(StandardCharsets.UTF_8)); }
/*     */       else
/*     */       
/* 123 */       { writeObject(object, mediaType); }
/*     */ 
/*     */     
/* 126 */     } catch (IOException ex) {
/* 127 */       this.sendFailed = true;
/* 128 */       throw ex;
/*     */     } 
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeObject(Object data, @Nullable MediaType mediaType) throws IOException {
/* 135 */     Class<?> elementClass = data.getClass();
/* 136 */     for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 137 */       if (converter.canWrite(elementClass, mediaType)) {
/* 138 */         HttpMessageConverter<Object> objectConverter = (HttpMessageConverter)converter;
/* 139 */         MutableHeadersServerHttpResponse mutableHeadersServerHttpResponse = new MutableHeadersServerHttpResponse(this.outputMessage, this.httpHeaders);
/* 140 */         objectConverter.write(data, mediaType, (HttpOutputMessage)mutableHeadersServerHttpResponse);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 148 */     if (this.sendFailed) {
/*     */       return;
/*     */     }
/*     */     try {
/* 152 */       this.outputMessage.flush();
/*     */     }
/* 154 */     catch (IOException ex) {
/* 155 */       this.sendFailed = true;
/* 156 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Throwable t) {
/* 162 */     if (this.sendFailed) {
/*     */       return;
/*     */     }
/* 165 */     this.deferredResult.setErrorResult(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void complete() {
/* 170 */     if (this.sendFailed) {
/*     */       return;
/*     */     }
/*     */     try {
/* 174 */       this.outputMessage.flush();
/* 175 */       this.deferredResult.setResult(null);
/*     */     }
/* 177 */     catch (IOException ex) {
/* 178 */       this.deferredResult.setErrorResult(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.StreamBuilder onTimeout(Runnable onTimeout) {
/* 184 */     this.deferredResult.onTimeout(onTimeout);
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.StreamBuilder onError(Consumer<Throwable> onError) {
/* 190 */     this.deferredResult.onError(onError);
/* 191 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.StreamBuilder onComplete(Runnable onCompletion) {
/* 196 */     this.deferredResult.onCompletion(onCompletion);
/* 197 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MutableHeadersServerHttpResponse
/*     */     extends DelegatingServerHttpResponse
/*     */   {
/* 206 */     private final HttpHeaders mutableHeaders = new HttpHeaders();
/*     */     
/*     */     public MutableHeadersServerHttpResponse(ServerHttpResponse delegate, HttpHeaders headers) {
/* 209 */       super(delegate);
/* 210 */       this.mutableHeaders.putAll((Map)delegate.getHeaders());
/* 211 */       this.mutableHeaders.putAll((Map)headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 216 */       return this.mutableHeaders;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\StreamingServerResponse$DefaultStreamBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */