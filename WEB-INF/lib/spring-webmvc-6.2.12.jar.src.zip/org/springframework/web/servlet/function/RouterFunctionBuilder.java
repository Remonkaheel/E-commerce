/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RouterFunctionBuilder
/*     */   implements RouterFunctions.Builder
/*     */ {
/*  45 */   private final List<RouterFunction<ServerResponse>> routerFunctions = new ArrayList<>();
/*     */   
/*  47 */   private final List<HandlerFilterFunction<ServerResponse, ServerResponse>> filterFunctions = new ArrayList<>();
/*     */   
/*  49 */   private final List<HandlerFilterFunction<ServerResponse, ServerResponse>> errorHandlers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder add(RouterFunction<ServerResponse> routerFunction) {
/*  54 */     Assert.notNull(routerFunction, "RouterFunction must not be null");
/*  55 */     this.routerFunctions.add(routerFunction);
/*  56 */     return this;
/*     */   }
/*     */   
/*     */   private RouterFunctions.Builder add(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/*  60 */     this.routerFunctions.add(RouterFunctions.route(predicate, handlerFunction));
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder GET(HandlerFunction<ServerResponse> handlerFunction) {
/*  68 */     return add(RequestPredicates.method(HttpMethod.GET), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder GET(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/*  73 */     return add(RequestPredicates.method(HttpMethod.GET).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder GET(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/*  78 */     return add(RequestPredicates.GET(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder GET(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/*  85 */     return add(RequestPredicates.GET(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder HEAD(HandlerFunction<ServerResponse> handlerFunction) {
/*  92 */     return add(RequestPredicates.method(HttpMethod.HEAD), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder HEAD(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/*  97 */     return add(RequestPredicates.method(HttpMethod.HEAD).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder HEAD(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/* 102 */     return add(RequestPredicates.HEAD(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder HEAD(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 109 */     return add(RequestPredicates.HEAD(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder POST(HandlerFunction<ServerResponse> handlerFunction) {
/* 116 */     return add(RequestPredicates.method(HttpMethod.POST), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder POST(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 121 */     return add(RequestPredicates.method(HttpMethod.POST).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder POST(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/* 126 */     return add(RequestPredicates.POST(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder POST(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 133 */     return add(RequestPredicates.POST(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PUT(HandlerFunction<ServerResponse> handlerFunction) {
/* 140 */     return add(RequestPredicates.method(HttpMethod.PUT), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PUT(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 145 */     return add(RequestPredicates.method(HttpMethod.PUT).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PUT(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/* 150 */     return add(RequestPredicates.PUT(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PUT(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 157 */     return add(RequestPredicates.PUT(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PATCH(HandlerFunction<ServerResponse> handlerFunction) {
/* 164 */     return add(RequestPredicates.method(HttpMethod.PATCH), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PATCH(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 169 */     return add(RequestPredicates.method(HttpMethod.PATCH).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PATCH(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/* 174 */     return add(RequestPredicates.PATCH(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder PATCH(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 181 */     return add(RequestPredicates.PATCH(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder DELETE(HandlerFunction<ServerResponse> handlerFunction) {
/* 188 */     return add(RequestPredicates.method(HttpMethod.DELETE), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder DELETE(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 193 */     return add(RequestPredicates.method(HttpMethod.DELETE).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder DELETE(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/* 198 */     return add(RequestPredicates.DELETE(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder DELETE(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 205 */     return add(RequestPredicates.DELETE(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder OPTIONS(HandlerFunction<ServerResponse> handlerFunction) {
/* 212 */     return add(RequestPredicates.method(HttpMethod.OPTIONS), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder OPTIONS(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 217 */     return add(RequestPredicates.method(HttpMethod.OPTIONS).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder OPTIONS(String pattern, HandlerFunction<ServerResponse> handlerFunction) {
/* 222 */     return add(RequestPredicates.OPTIONS(pattern), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder OPTIONS(String pattern, RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 229 */     return add(RequestPredicates.OPTIONS(pattern).and(predicate), handlerFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder route(RequestPredicate predicate, HandlerFunction<ServerResponse> handlerFunction) {
/* 237 */     return add(RouterFunctions.route(predicate, handlerFunction));
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder resource(RequestPredicate predicate, Resource resource) {
/* 242 */     return add(RouterFunctions.resource(predicate, resource));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder resource(RequestPredicate predicate, Resource resource, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/* 248 */     return add(RouterFunctions.resource(predicate, resource, headersConsumer));
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder resources(String pattern, Resource location) {
/* 253 */     return add(RouterFunctions.resources(pattern, location));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder resources(String pattern, Resource location, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/* 260 */     return add(RouterFunctions.resources(pattern, location, headersConsumer));
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder resources(Function<ServerRequest, Optional<Resource>> lookupFunction) {
/* 265 */     return add(RouterFunctions.resources(lookupFunction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder resources(Function<ServerRequest, Optional<Resource>> lookupFunction, BiConsumer<Resource, HttpHeaders> headersConsumer) {
/* 272 */     return add(RouterFunctions.resources(lookupFunction, headersConsumer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder nest(RequestPredicate predicate, Consumer<RouterFunctions.Builder> builderConsumer) {
/* 279 */     Assert.notNull(builderConsumer, "Consumer must not be null");
/*     */     
/* 281 */     RouterFunctionBuilder nestedBuilder = new RouterFunctionBuilder();
/* 282 */     builderConsumer.accept(nestedBuilder);
/* 283 */     RouterFunction<ServerResponse> nestedRoute = nestedBuilder.build();
/* 284 */     this.routerFunctions.add(RouterFunctions.nest(predicate, nestedRoute));
/* 285 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder nest(RequestPredicate predicate, Supplier<RouterFunction<ServerResponse>> routerFunctionSupplier) {
/* 292 */     Assert.notNull(routerFunctionSupplier, "RouterFunction Supplier must not be null");
/*     */     
/* 294 */     RouterFunction<ServerResponse> nestedRoute = routerFunctionSupplier.get();
/* 295 */     this.routerFunctions.add(RouterFunctions.nest(predicate, nestedRoute));
/* 296 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder path(String pattern, Consumer<RouterFunctions.Builder> builderConsumer) {
/* 303 */     return nest(RequestPredicates.path(pattern), builderConsumer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder path(String pattern, Supplier<RouterFunction<ServerResponse>> routerFunctionSupplier) {
/* 310 */     return nest(RequestPredicates.path(pattern), routerFunctionSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder filter(HandlerFilterFunction<ServerResponse, ServerResponse> filterFunction) {
/* 315 */     Assert.notNull(filterFunction, "HandlerFilterFunction must not be null");
/*     */     
/* 317 */     this.filterFunctions.add(filterFunction);
/* 318 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder before(Function<ServerRequest, ServerRequest> requestProcessor) {
/* 323 */     Assert.notNull(requestProcessor, "RequestProcessor must not be null");
/* 324 */     return filter(HandlerFilterFunction.ofRequestProcessor(requestProcessor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder after(BiFunction<ServerRequest, ServerResponse, ServerResponse> responseProcessor) {
/* 331 */     Assert.notNull(responseProcessor, "ResponseProcessor must not be null");
/* 332 */     return filter(HandlerFilterFunction.ofResponseProcessor(responseProcessor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder onError(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, ServerResponse> responseProvider) {
/* 339 */     Assert.notNull(predicate, "Predicate must not be null");
/* 340 */     Assert.notNull(responseProvider, "ResponseProvider must not be null");
/*     */     
/* 342 */     this.errorHandlers.add(0, HandlerFilterFunction.ofErrorHandler(predicate, responseProvider));
/* 343 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder onError(Class<? extends Throwable> exceptionType, BiFunction<Throwable, ServerRequest, ServerResponse> responseProvider) {
/* 349 */     Assert.notNull(exceptionType, "ExceptionType must not be null");
/* 350 */     Assert.notNull(responseProvider, "ResponseProvider must not be null");
/*     */     
/* 352 */     Objects.requireNonNull(exceptionType); return onError(exceptionType::isInstance, responseProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder withAttribute(String name, Object value) {
/* 357 */     Assert.hasLength(name, "Name must not be empty");
/* 358 */     Assert.notNull(value, "Value must not be null");
/*     */     
/* 360 */     if (this.routerFunctions.isEmpty()) {
/* 361 */       throw new IllegalStateException("attributes can only be called after any other method (GET, path, etc.)");
/*     */     }
/* 363 */     int lastIdx = this.routerFunctions.size() - 1;
/*     */     
/* 365 */     RouterFunction<ServerResponse> attributed = ((RouterFunction<ServerResponse>)this.routerFunctions.get(lastIdx)).withAttribute(name, value);
/* 366 */     this.routerFunctions.set(lastIdx, attributed);
/* 367 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunctions.Builder withAttributes(Consumer<Map<String, Object>> attributesConsumer) {
/* 372 */     Assert.notNull(attributesConsumer, "AttributesConsumer must not be null");
/*     */     
/* 374 */     if (this.routerFunctions.isEmpty()) {
/* 375 */       throw new IllegalStateException("attributes can only be called after any other method (GET, path, etc.)");
/*     */     }
/* 377 */     int lastIdx = this.routerFunctions.size() - 1;
/*     */     
/* 379 */     RouterFunction<ServerResponse> attributed = ((RouterFunction<ServerResponse>)this.routerFunctions.get(lastIdx)).withAttributes(attributesConsumer);
/* 380 */     this.routerFunctions.set(lastIdx, attributed);
/* 381 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RouterFunction<ServerResponse> build() {
/* 386 */     if (this.routerFunctions.isEmpty()) {
/* 387 */       throw new IllegalStateException("No routes registered. Register a route with GET(), POST(), etc.");
/*     */     }
/* 389 */     RouterFunction<ServerResponse> result = new BuiltRouterFunction(this.routerFunctions);
/*     */     
/* 391 */     if (this.filterFunctions.isEmpty() && this.errorHandlers.isEmpty()) {
/* 392 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 398 */     HandlerFilterFunction<ServerResponse, ServerResponse> filter = (HandlerFilterFunction<ServerResponse, ServerResponse>)Stream.concat(this.filterFunctions.stream(), this.errorHandlers.stream()).reduce(HandlerFilterFunction::andThen).orElseThrow(IllegalStateException::new);
/*     */     
/* 400 */     return result.filter(filter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BuiltRouterFunction
/*     */     extends RouterFunctions.AbstractRouterFunction<ServerResponse>
/*     */   {
/*     */     private final List<RouterFunction<ServerResponse>> routerFunctions;
/*     */ 
/*     */ 
/*     */     
/*     */     public BuiltRouterFunction(List<RouterFunction<ServerResponse>> routerFunctions) {
/* 413 */       Assert.notEmpty(routerFunctions, "RouterFunctions must not be empty");
/* 414 */       this.routerFunctions = new ArrayList<>(routerFunctions);
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<HandlerFunction<ServerResponse>> route(ServerRequest request) {
/* 419 */       for (RouterFunction<ServerResponse> routerFunction : this.routerFunctions) {
/* 420 */         Optional<HandlerFunction<ServerResponse>> result = routerFunction.route(request);
/* 421 */         if (result.isPresent()) {
/* 422 */           return result;
/*     */         }
/*     */       } 
/* 425 */       return Optional.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(RouterFunctions.Visitor visitor) {
/* 430 */       this.routerFunctions.forEach(routerFunction -> routerFunction.accept(visitor));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\RouterFunctionBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */