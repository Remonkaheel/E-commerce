package org.springframework.web.servlet.function;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.ModelAndView;

@FunctionalInterface
public interface WriteFunction {
  @Nullable
  ModelAndView write(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\ServerResponse$HeadersBuilder$WriteFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */