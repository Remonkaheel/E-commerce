/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.DelegatingServerHttpResponse;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultSseBuilder
/*     */   implements ServerResponse.SseBuilder
/*     */ {
/* 109 */   private static final byte[] NL_NL = new byte[] { 10, 10 };
/*     */ 
/*     */   
/*     */   private final ServerHttpResponse outputMessage;
/*     */   
/*     */   private final DeferredResult<?> deferredResult;
/*     */   
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   
/*     */   private final HttpHeaders httpHeaders;
/*     */   
/* 120 */   private final StringBuilder builder = new StringBuilder();
/*     */ 
/*     */   
/*     */   private boolean sendFailed;
/*     */ 
/*     */   
/*     */   public DefaultSseBuilder(HttpServletResponse response, ServerResponse.Context context, DeferredResult<?> deferredResult, HttpHeaders httpHeaders) {
/* 127 */     this.outputMessage = (ServerHttpResponse)new ServletServerHttpResponse(response);
/* 128 */     this.deferredResult = deferredResult;
/* 129 */     this.messageConverters = context.messageConverters();
/* 130 */     this.httpHeaders = httpHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void send(Object object) throws IOException {
/* 135 */     data(object);
/*     */   }
/*     */ 
/*     */   
/*     */   public void send() throws IOException {
/* 140 */     this.builder.append('\n');
/*     */     try {
/* 142 */       OutputStream body = this.outputMessage.getBody();
/* 143 */       body.write(builderBytes());
/* 144 */       body.flush();
/*     */     }
/* 146 */     catch (IOException ex) {
/* 147 */       this.sendFailed = true;
/* 148 */       throw ex;
/*     */     } finally {
/*     */       
/* 151 */       this.builder.setLength(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder id(String id) {
/* 157 */     Assert.hasLength(id, "Id must not be empty");
/* 158 */     return field("id", id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder event(String eventName) {
/* 163 */     Assert.hasLength(eventName, "Name must not be empty");
/* 164 */     return field("event", eventName);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder retry(Duration duration) {
/* 169 */     Assert.notNull(duration, "Duration must not be null");
/* 170 */     String millis = Long.toString(duration.toMillis());
/* 171 */     return field("retry", millis);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder comment(String comment) {
/* 176 */     String[] lines = comment.split("\n");
/* 177 */     for (String line : lines) {
/* 178 */       field("", line);
/*     */     }
/* 180 */     return this;
/*     */   }
/*     */   
/*     */   private ServerResponse.SseBuilder field(String name, String value) {
/* 184 */     this.builder.append(name).append(':').append(value).append('\n');
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void data(Object object) throws IOException {
/* 190 */     Assert.notNull(object, "Object must not be null");
/*     */     
/* 192 */     if (object instanceof String) { String text = (String)object;
/* 193 */       writeString(text); }
/*     */     else
/*     */     
/* 196 */     { writeObject(object); }
/*     */   
/*     */   }
/*     */   
/*     */   private void writeString(String string) throws IOException {
/* 201 */     String[] lines = string.split("\n");
/* 202 */     for (String line : lines) {
/* 203 */       field("data", line);
/*     */     }
/* 205 */     send();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeObject(Object data) throws IOException {
/* 210 */     this.builder.append("data:");
/*     */     try {
/* 212 */       this.outputMessage.getBody().write(builderBytes());
/*     */       
/* 214 */       Class<?> dataClass = data.getClass();
/* 215 */       for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 216 */         if (converter.canWrite(dataClass, MediaType.APPLICATION_JSON)) {
/* 217 */           HttpMessageConverter<Object> objectConverter = (HttpMessageConverter)converter;
/* 218 */           MutableHeadersServerHttpResponse mutableHeadersServerHttpResponse = new MutableHeadersServerHttpResponse(this.outputMessage, this.httpHeaders);
/* 219 */           objectConverter.write(data, MediaType.APPLICATION_JSON, (HttpOutputMessage)mutableHeadersServerHttpResponse);
/* 220 */           this.outputMessage.getBody().write(NL_NL);
/* 221 */           this.outputMessage.flush();
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 226 */     } catch (IOException ex) {
/* 227 */       this.sendFailed = true;
/* 228 */       throw ex;
/*     */     } finally {
/*     */       
/* 231 */       this.builder.setLength(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private byte[] builderBytes() {
/* 236 */     return this.builder.toString().getBytes(StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Throwable t) {
/* 241 */     if (this.sendFailed) {
/*     */       return;
/*     */     }
/* 244 */     this.deferredResult.setErrorResult(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void complete() {
/* 249 */     if (this.sendFailed) {
/*     */       return;
/*     */     }
/*     */     try {
/* 253 */       this.outputMessage.flush();
/* 254 */       this.deferredResult.setResult(null);
/*     */     }
/* 256 */     catch (IOException ex) {
/* 257 */       this.deferredResult.setErrorResult(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder onTimeout(Runnable onTimeout) {
/* 263 */     this.deferredResult.onTimeout(onTimeout);
/* 264 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder onError(Consumer<Throwable> onError) {
/* 269 */     this.deferredResult.onError(onError);
/* 270 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerResponse.SseBuilder onComplete(Runnable onCompletion) {
/* 275 */     this.deferredResult.onCompletion(onCompletion);
/* 276 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MutableHeadersServerHttpResponse
/*     */     extends DelegatingServerHttpResponse
/*     */   {
/* 286 */     private final HttpHeaders mutableHeaders = new HttpHeaders();
/*     */     
/*     */     public MutableHeadersServerHttpResponse(ServerHttpResponse delegate, HttpHeaders headers) {
/* 289 */       super(delegate);
/* 290 */       this.mutableHeaders.putAll((Map)delegate.getHeaders());
/* 291 */       this.mutableHeaders.putAll((Map)headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 296 */       return this.mutableHeaders;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\SseServerResponse$DefaultSseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */