/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultRenderingResponseBuilder
/*     */   implements RenderingResponse.Builder
/*     */ {
/*     */   private final String name;
/*  50 */   private HttpStatusCode status = (HttpStatusCode)HttpStatus.OK;
/*     */   
/*  52 */   private final HttpHeaders headers = new HttpHeaders();
/*     */   
/*  54 */   private final MultiValueMap<String, Cookie> cookies = (MultiValueMap<String, Cookie>)new LinkedMultiValueMap();
/*     */   
/*  56 */   private final Map<String, Object> model = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   public DefaultRenderingResponseBuilder(RenderingResponse other) {
/*  60 */     Assert.notNull(other, "RenderingResponse must not be null");
/*  61 */     this.name = other.name();
/*  62 */     this.status = other.statusCode();
/*  63 */     this.headers.putAll((Map)other.headers());
/*  64 */     this.model.putAll(other.model());
/*     */   }
/*     */   
/*     */   public DefaultRenderingResponseBuilder(String name) {
/*  68 */     Assert.notNull(name, "Name must not be null");
/*  69 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder status(HttpStatusCode status) {
/*  75 */     Assert.notNull(status, "HttpStatusCode must not be null");
/*  76 */     this.status = status;
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder status(int status) {
/*  82 */     return status(HttpStatusCode.valueOf(status));
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder cookie(Cookie cookie) {
/*  87 */     Assert.notNull(cookie, "Cookie must not be null");
/*  88 */     this.cookies.add(cookie.getName(), cookie);
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder cookies(Consumer<MultiValueMap<String, Cookie>> cookiesConsumer) {
/*  94 */     cookiesConsumer.accept(this.cookies);
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder modelAttribute(Object attribute) {
/* 100 */     Assert.notNull(attribute, "Attribute must not be null");
/* 101 */     if (attribute instanceof Collection) { Collection<?> collection = (Collection)attribute; if (collection.isEmpty())
/* 102 */         return this;  }
/*     */     
/* 104 */     return modelAttribute(Conventions.getVariableName(attribute), attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder modelAttribute(String name, @Nullable Object value) {
/* 109 */     Assert.notNull(name, "Name must not be null");
/* 110 */     this.model.put(name, value);
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder modelAttributes(Object... attributes) {
/* 116 */     modelAttributes(Arrays.asList(attributes));
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder modelAttributes(Collection<?> attributes) {
/* 122 */     attributes.forEach(this::modelAttribute);
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder modelAttributes(Map<String, ?> attributes) {
/* 128 */     this.model.putAll(attributes);
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder header(String headerName, String... headerValues) {
/* 134 */     for (String headerValue : headerValues) {
/* 135 */       this.headers.add(headerName, headerValue);
/*     */     }
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse.Builder headers(Consumer<HttpHeaders> headersConsumer) {
/* 142 */     headersConsumer.accept(this.headers);
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderingResponse build() {
/* 148 */     return new DefaultRenderingResponse(this.status, this.headers, this.cookies, this.name, this.model);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class DefaultRenderingResponse
/*     */     extends AbstractServerResponse
/*     */     implements RenderingResponse
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final Map<String, Object> model;
/*     */     
/*     */     public DefaultRenderingResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, Cookie> cookies, String name, Map<String, Object> model) {
/* 161 */       super(statusCode, headers, cookies);
/* 162 */       this.name = name;
/* 163 */       this.model = Collections.unmodifiableMap(new LinkedHashMap<>(model));
/*     */     }
/*     */ 
/*     */     
/*     */     public String name() {
/* 168 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, Object> model() {
/* 173 */       return this.model;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ModelAndView writeToInternal(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context) {
/* 180 */       ModelAndView mav = new ModelAndView(this.name, statusCode());
/* 181 */       mav.addAllObjects(this.model);
/* 182 */       return mav;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\DefaultRenderingResponseBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */