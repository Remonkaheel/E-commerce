/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AsyncServerResponse
/*     */   extends ServerResponse
/*     */ {
/*     */   ServerResponse block();
/*     */   
/*     */   static AsyncServerResponse create(Object asyncResponse) {
/*  60 */     return createInternal(asyncResponse, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AsyncServerResponse create(Object asyncResponse, Duration timeout) {
/*  76 */     return createInternal(asyncResponse, timeout);
/*     */   }
/*     */   
/*     */   private static AsyncServerResponse createInternal(Object asyncResponse, @Nullable Duration timeout) {
/*  80 */     Assert.notNull(asyncResponse, "AsyncResponse must not be null");
/*     */     
/*  82 */     CompletableFuture<ServerResponse> futureResponse = toCompletableFuture(asyncResponse);
/*  83 */     if (futureResponse.isDone() && 
/*  84 */       !futureResponse.isCancelled() && 
/*  85 */       !futureResponse.isCompletedExceptionally()) {
/*     */       
/*     */       try {
/*  88 */         ServerResponse completedResponse = futureResponse.get();
/*  89 */         return new CompletedAsyncServerResponse(completedResponse);
/*     */       }
/*  91 */       catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {}
/*     */     }
/*     */ 
/*     */     
/*  95 */     return new DefaultAsyncServerResponse(futureResponse, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   private static CompletableFuture<ServerResponse> toCompletableFuture(Object obj) {
/* 100 */     if (obj instanceof CompletableFuture) { CompletableFuture<?> futureResponse = (CompletableFuture)obj;
/* 101 */       return (CompletableFuture)futureResponse; }
/*     */     
/* 103 */     if (DefaultAsyncServerResponse.reactiveStreamsPresent) {
/* 104 */       ReactiveAdapterRegistry registry = ReactiveAdapterRegistry.getSharedInstance();
/* 105 */       ReactiveAdapter publisherAdapter = registry.getAdapter(obj.getClass());
/* 106 */       if (publisherAdapter != null) {
/* 107 */         Publisher<ServerResponse> publisher = publisherAdapter.toPublisher(obj);
/* 108 */         ReactiveAdapter futureAdapter = registry.getAdapter(CompletableFuture.class);
/* 109 */         if (futureAdapter != null) {
/* 110 */           return (CompletableFuture<ServerResponse>)futureAdapter.fromPublisher(publisher);
/*     */         }
/*     */       } 
/*     */     } 
/* 114 */     throw new IllegalArgumentException("Asynchronous type not supported: " + String.valueOf(obj.getClass()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\AsyncServerResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */