package org.springframework.web.servlet.function;

@FunctionalInterface
public interface HandlerFunction<T extends ServerResponse> {
  T handle(ServerRequest paramServerRequest) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-webmvc-6.2.12.jar!\org\springframework\web\servlet\function\HandlerFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */