package org.springframework.expression;

import org.springframework.lang.Nullable;

public interface TargetedAccessor {
  @Nullable
  Class<?>[] getSpecificTargetClasses();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\TargetedAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */