package org.springframework.expression;

import org.springframework.lang.Nullable;

public interface TypeComparator {
  boolean canCompare(@Nullable Object paramObject1, @Nullable Object paramObject2);
  
  int compare(@Nullable Object paramObject1, @Nullable Object paramObject2) throws EvaluationException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\TypeComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */