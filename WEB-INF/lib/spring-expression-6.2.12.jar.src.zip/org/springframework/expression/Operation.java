/*    */ package org.springframework.expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Operation
/*    */ {
/* 31 */   ADD,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   SUBTRACT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   DIVIDE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   MULTIPLY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   MODULUS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   POWER;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\Operation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */