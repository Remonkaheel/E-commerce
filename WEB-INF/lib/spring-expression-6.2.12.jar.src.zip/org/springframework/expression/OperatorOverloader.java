package org.springframework.expression;

import org.springframework.lang.Nullable;

public interface OperatorOverloader {
  boolean overridesOperation(Operation paramOperation, @Nullable Object paramObject1, @Nullable Object paramObject2) throws EvaluationException;
  
  Object operate(Operation paramOperation, @Nullable Object paramObject1, @Nullable Object paramObject2) throws EvaluationException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\OperatorOverloader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */