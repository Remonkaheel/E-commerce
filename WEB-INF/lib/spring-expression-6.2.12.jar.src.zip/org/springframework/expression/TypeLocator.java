package org.springframework.expression;

@FunctionalInterface
public interface TypeLocator {
  Class<?> findType(String paramString) throws EvaluationException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\TypeLocator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */