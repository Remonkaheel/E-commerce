/*    */ package org.springframework.expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ParserContext
/*    */ {
/* 63 */   public static final ParserContext TEMPLATE_EXPRESSION = new ParserContext()
/*    */     {
/*    */       public boolean isTemplate()
/*    */       {
/* 67 */         return true;
/*    */       }
/*    */ 
/*    */       
/*    */       public String getExpressionPrefix() {
/* 72 */         return "#{";
/*    */       }
/*    */ 
/*    */       
/*    */       public String getExpressionSuffix() {
/* 77 */         return "}";
/*    */       }
/*    */     };
/*    */   
/*    */   boolean isTemplate();
/*    */   
/*    */   String getExpressionPrefix();
/*    */   
/*    */   String getExpressionSuffix();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\ParserContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */