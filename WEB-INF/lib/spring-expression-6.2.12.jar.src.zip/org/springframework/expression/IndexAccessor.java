package org.springframework.expression;

import org.springframework.lang.Nullable;

public interface IndexAccessor extends TargetedAccessor {
  boolean canRead(EvaluationContext paramEvaluationContext, Object paramObject1, Object paramObject2) throws AccessException;
  
  TypedValue read(EvaluationContext paramEvaluationContext, Object paramObject1, Object paramObject2) throws AccessException;
  
  boolean canWrite(EvaluationContext paramEvaluationContext, Object paramObject1, Object paramObject2) throws AccessException;
  
  void write(EvaluationContext paramEvaluationContext, Object paramObject1, Object paramObject2, @Nullable Object paramObject3) throws AccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\IndexAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */