/*     */ package org.springframework.expression;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypedValue
/*     */ {
/*  38 */   public static final TypedValue NULL = new TypedValue(null);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Object value;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypeDescriptor typeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue(@Nullable Object value) {
/*  54 */     this.value = value;
/*  55 */     this.typeDescriptor = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue(@Nullable Object value, @Nullable TypeDescriptor typeDescriptor) {
/*  65 */     this.value = value;
/*  66 */     this.typeDescriptor = typeDescriptor;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue() {
/*  72 */     return this.value;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public TypeDescriptor getTypeDescriptor() {
/*  77 */     if (this.typeDescriptor == null && this.value != null) {
/*  78 */       this.typeDescriptor = TypeDescriptor.forObject(this.value);
/*     */     }
/*  80 */     return this.typeDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  87 */     if (this != other) { if (other instanceof TypedValue) { TypedValue that = (TypedValue)other;
/*  88 */         if (ObjectUtils.nullSafeEquals(this.value, that.value) && ((this.typeDescriptor == null && that.typeDescriptor == null) || 
/*     */           
/*  90 */           ObjectUtils.nullSafeEquals(getTypeDescriptor(), that.getTypeDescriptor()))); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  95 */     return ObjectUtils.nullSafeHashCode(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return "TypedValue: '" + String.valueOf(this.value) + "' of [" + String.valueOf(getTypeDescriptor()) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\TypedValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */