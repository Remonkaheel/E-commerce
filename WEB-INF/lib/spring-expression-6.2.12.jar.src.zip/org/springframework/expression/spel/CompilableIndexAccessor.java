package org.springframework.expression.spel;

import org.springframework.asm.MethodVisitor;
import org.springframework.asm.Opcodes;
import org.springframework.expression.IndexAccessor;

public interface CompilableIndexAccessor extends IndexAccessor, Opcodes {
  boolean isCompilable();
  
  Class<?> getIndexedValueType();
  
  void generateCode(SpelNode paramSpelNode, MethodVisitor paramMethodVisitor, CodeFlow paramCodeFlow);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\CompilableIndexAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */