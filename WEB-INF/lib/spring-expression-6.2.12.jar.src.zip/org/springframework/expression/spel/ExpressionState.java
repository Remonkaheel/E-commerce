/*     */ package org.springframework.expression.spel;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionState
/*     */ {
/*     */   private final EvaluationContext relatedContext;
/*     */   private final TypedValue rootObject;
/*     */   private final SpelParserConfiguration configuration;
/*     */   @Nullable
/*     */   private Deque<TypedValue> contextObjects;
/*     */   @Nullable
/*     */   private Deque<VariableScope> variableScopes;
/*     */   @Nullable
/*     */   private Deque<TypedValue> scopeRootObjects;
/*     */   
/*     */   public ExpressionState(EvaluationContext context) {
/*  82 */     this(context, context.getRootObject(), new SpelParserConfiguration(false, false));
/*     */   }
/*     */   
/*     */   public ExpressionState(EvaluationContext context, SpelParserConfiguration configuration) {
/*  86 */     this(context, context.getRootObject(), configuration);
/*     */   }
/*     */   
/*     */   public ExpressionState(EvaluationContext context, TypedValue rootObject) {
/*  90 */     this(context, rootObject, new SpelParserConfiguration(false, false));
/*     */   }
/*     */   
/*     */   public ExpressionState(EvaluationContext context, TypedValue rootObject, SpelParserConfiguration configuration) {
/*  94 */     Assert.notNull(context, "EvaluationContext must not be null");
/*  95 */     Assert.notNull(rootObject, "'rootObject' must not be null");
/*  96 */     Assert.notNull(configuration, "SpelParserConfiguration must not be null");
/*  97 */     this.relatedContext = context;
/*  98 */     this.rootObject = rootObject;
/*  99 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getActiveContextObject() {
/* 107 */     if (CollectionUtils.isEmpty(this.contextObjects)) {
/* 108 */       return this.rootObject;
/*     */     }
/* 110 */     return this.contextObjects.element();
/*     */   }
/*     */   
/*     */   public void pushActiveContextObject(TypedValue obj) {
/* 114 */     initContextObjects().push(obj);
/*     */   }
/*     */   
/*     */   public void popActiveContextObject() {
/*     */     try {
/* 119 */       initContextObjects().pop();
/*     */     }
/* 121 */     catch (NoSuchElementException ex) {
/* 122 */       throw new IllegalStateException("Cannot pop active context object: stack is empty");
/*     */     } 
/*     */   }
/*     */   
/*     */   public TypedValue getRootContextObject() {
/* 127 */     return this.rootObject;
/*     */   }
/*     */   
/*     */   public TypedValue getScopeRootContextObject() {
/* 131 */     if (CollectionUtils.isEmpty(this.scopeRootObjects)) {
/* 132 */       return this.rootObject;
/*     */     }
/* 134 */     return this.scopeRootObjects.element();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue assignVariable(String name, Supplier<TypedValue> valueSupplier) {
/* 149 */     return this.relatedContext.assignVariable(name, valueSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariable(String name, @Nullable Object value) {
/* 161 */     this.relatedContext.setVariable(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue lookupVariable(String name) {
/* 173 */     Object value = this.relatedContext.lookupVariable(name);
/* 174 */     return (value != null) ? new TypedValue(value) : TypedValue.NULL;
/*     */   }
/*     */   
/*     */   public TypeComparator getTypeComparator() {
/* 178 */     return this.relatedContext.getTypeComparator();
/*     */   }
/*     */   
/*     */   public Class<?> findType(String type) throws EvaluationException {
/* 182 */     return this.relatedContext.getTypeLocator().findType(type);
/*     */   }
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 186 */     return this.relatedContext.getTypeConverter();
/*     */   }
/*     */   
/*     */   public Object convertValue(Object value, TypeDescriptor targetTypeDescriptor) throws EvaluationException {
/* 190 */     Object result = this.relatedContext.getTypeConverter().convertValue(value, 
/* 191 */         TypeDescriptor.forObject(value), targetTypeDescriptor);
/* 192 */     if (result == null) {
/* 193 */       throw new IllegalStateException("Null conversion result for value [" + String.valueOf(value) + "]");
/*     */     }
/* 195 */     return result;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object convertValue(TypedValue value, TypeDescriptor targetTypeDescriptor) throws EvaluationException {
/* 200 */     Object val = value.getValue();
/* 201 */     return this.relatedContext.getTypeConverter().convertValue(val, 
/* 202 */         TypeDescriptor.forObject(val), targetTypeDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterScope() {
/* 210 */     initVariableScopes().push(new VariableScope());
/* 211 */     initScopeRootObjects().push(getActiveContextObject());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public void enterScope(String name, Object value) {
/* 224 */     initVariableScopes().push(new VariableScope(name, value));
/* 225 */     initScopeRootObjects().push(getActiveContextObject());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public void enterScope(@Nullable Map<String, Object> variables) {
/* 237 */     initVariableScopes().push(new VariableScope(variables));
/* 238 */     initScopeRootObjects().push(getActiveContextObject());
/*     */   }
/*     */   
/*     */   public void exitScope() {
/* 242 */     initVariableScopes().pop();
/* 243 */     initScopeRootObjects().pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public void setLocalVariable(String name, Object value) {
/* 257 */     ((VariableScope)initVariableScopes().element()).setVariable(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   @Nullable
/*     */   public Object lookupLocalVariable(String name) {
/* 270 */     for (VariableScope scope : initVariableScopes()) {
/* 271 */       if (scope.definesVariable(name)) {
/* 272 */         return scope.lookupVariable(name);
/*     */       }
/*     */     } 
/* 275 */     return null;
/*     */   }
/*     */   
/*     */   private Deque<TypedValue> initContextObjects() {
/* 279 */     if (this.contextObjects == null) {
/* 280 */       this.contextObjects = new ArrayDeque<>();
/*     */     }
/* 282 */     return this.contextObjects;
/*     */   }
/*     */   
/*     */   private Deque<TypedValue> initScopeRootObjects() {
/* 286 */     if (this.scopeRootObjects == null) {
/* 287 */       this.scopeRootObjects = new ArrayDeque<>();
/*     */     }
/* 289 */     return this.scopeRootObjects;
/*     */   }
/*     */   
/*     */   private Deque<VariableScope> initVariableScopes() {
/* 293 */     if (this.variableScopes == null) {
/* 294 */       this.variableScopes = new ArrayDeque<>();
/*     */       
/* 296 */       this.variableScopes.add(new VariableScope());
/*     */     } 
/* 298 */     return this.variableScopes;
/*     */   }
/*     */   
/*     */   public TypedValue operate(Operation op, @Nullable Object left, @Nullable Object right) throws EvaluationException {
/* 302 */     OperatorOverloader overloader = this.relatedContext.getOperatorOverloader();
/* 303 */     if (overloader.overridesOperation(op, left, right)) {
/* 304 */       Object returnValue = overloader.operate(op, left, right);
/* 305 */       return new TypedValue(returnValue);
/*     */     } 
/*     */     
/* 308 */     String leftType = (left == null) ? "null" : left.getClass().getName();
/* 309 */     String rightType = (right == null) ? "null" : right.getClass().getName();
/* 310 */     throw new SpelEvaluationException(SpelMessage.OPERATOR_NOT_SUPPORTED_BETWEEN_TYPES, new Object[] { op, leftType, rightType });
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors() {
/* 315 */     return this.relatedContext.getPropertyAccessors();
/*     */   }
/*     */   
/*     */   public EvaluationContext getEvaluationContext() {
/* 319 */     return this.relatedContext;
/*     */   }
/*     */   
/*     */   public SpelParserConfiguration getConfiguration() {
/* 323 */     return this.configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class VariableScope
/*     */   {
/* 336 */     private final Map<String, Object> variables = new HashMap<>();
/*     */ 
/*     */     
/*     */     VariableScope() {}
/*     */     
/*     */     VariableScope(String name, Object value) {
/* 342 */       this.variables.put(name, value);
/*     */     }
/*     */     
/*     */     VariableScope(@Nullable Map<String, Object> variables) {
/* 346 */       if (variables != null) {
/* 347 */         this.variables.putAll(variables);
/*     */       }
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     Object lookupVariable(String name) {
/* 353 */       return this.variables.get(name);
/*     */     }
/*     */     
/*     */     void setVariable(String name, Object value) {
/* 357 */       this.variables.put(name, value);
/*     */     }
/*     */     
/*     */     boolean definesVariable(String name) {
/* 361 */       return this.variables.containsKey(name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ExpressionState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */