/*     */ package org.springframework.expression.spel;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpelParserConfiguration
/*     */ {
/*     */   public static final int DEFAULT_MAX_EXPRESSION_LENGTH = 10000;
/*     */   public static final String SPRING_EXPRESSION_COMPILER_MODE_PROPERTY_NAME = "spring.expression.compiler.mode";
/*     */   private static final SpelCompilerMode defaultCompilerMode;
/*     */   private final SpelCompilerMode compilerMode;
/*     */   @Nullable
/*     */   private final ClassLoader compilerClassLoader;
/*     */   private final boolean autoGrowNullReferences;
/*     */   private final boolean autoGrowCollections;
/*     */   private final int maximumAutoGrowSize;
/*     */   private final int maximumExpressionLength;
/*     */   
/*     */   static {
/*  49 */     String compilerMode = SpringProperties.getProperty("spring.expression.compiler.mode");
/*     */     
/*  51 */     defaultCompilerMode = (compilerMode != null) ? SpelCompilerMode.valueOf(compilerMode.toUpperCase(Locale.ROOT)) : SpelCompilerMode.OFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelParserConfiguration() {
/*  73 */     this(null, null, false, false, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelParserConfiguration(@Nullable SpelCompilerMode compilerMode, @Nullable ClassLoader compilerClassLoader) {
/*  82 */     this(compilerMode, compilerClassLoader, false, false, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelParserConfiguration(boolean autoGrowNullReferences, boolean autoGrowCollections) {
/*  92 */     this(null, null, autoGrowNullReferences, autoGrowCollections, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelParserConfiguration(boolean autoGrowNullReferences, boolean autoGrowCollections, int maximumAutoGrowSize) {
/* 102 */     this(null, null, autoGrowNullReferences, autoGrowCollections, maximumAutoGrowSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelParserConfiguration(@Nullable SpelCompilerMode compilerMode, @Nullable ClassLoader compilerClassLoader, boolean autoGrowNullReferences, boolean autoGrowCollections, int maximumAutoGrowSize) {
/* 116 */     this(compilerMode, compilerClassLoader, autoGrowNullReferences, autoGrowCollections, maximumAutoGrowSize, 10000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelParserConfiguration(@Nullable SpelCompilerMode compilerMode, @Nullable ClassLoader compilerClassLoader, boolean autoGrowNullReferences, boolean autoGrowCollections, int maximumAutoGrowSize, int maximumExpressionLength) {
/* 134 */     this.compilerMode = (compilerMode != null) ? compilerMode : defaultCompilerMode;
/* 135 */     this.compilerClassLoader = compilerClassLoader;
/* 136 */     this.autoGrowNullReferences = autoGrowNullReferences;
/* 137 */     this.autoGrowCollections = autoGrowCollections;
/* 138 */     this.maximumAutoGrowSize = maximumAutoGrowSize;
/* 139 */     this.maximumExpressionLength = maximumExpressionLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelCompilerMode getCompilerMode() {
/* 147 */     return this.compilerMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getCompilerClassLoader() {
/* 155 */     return this.compilerClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoGrowNullReferences() {
/* 162 */     return this.autoGrowNullReferences;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoGrowCollections() {
/* 169 */     return this.autoGrowCollections;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumAutoGrowSize() {
/* 176 */     return this.maximumAutoGrowSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumExpressionLength() {
/* 184 */     return this.maximumExpressionLength;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\SpelParserConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */