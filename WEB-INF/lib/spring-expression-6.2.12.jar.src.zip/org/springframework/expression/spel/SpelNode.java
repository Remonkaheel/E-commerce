/*     */ package org.springframework.expression.spel;
/*     */ 
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface SpelNode
/*     */ {
/*     */   @Nullable
/*     */   Object getValue(ExpressionState paramExpressionState) throws EvaluationException;
/*     */   
/*     */   TypedValue getTypedValue(ExpressionState paramExpressionState) throws EvaluationException;
/*     */   
/*     */   boolean isWritable(ExpressionState paramExpressionState) throws EvaluationException;
/*     */   
/*     */   void setValue(ExpressionState paramExpressionState, @Nullable Object paramObject) throws EvaluationException;
/*     */   
/*     */   String toStringAST();
/*     */   
/*     */   int getChildCount();
/*     */   
/*     */   SpelNode getChild(int paramInt);
/*     */   
/*     */   @Nullable
/*     */   Class<?> getObjectClass(@Nullable Object paramObject);
/*     */   
/*     */   int getStartPosition();
/*     */   
/*     */   int getEndPosition();
/*     */   
/*     */   default boolean isCompilable() {
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void generateCode(MethodVisitor methodVisitor, CodeFlow codeFlow) {
/* 147 */     throw new IllegalStateException(getClass().getName() + " does not support bytecode generation");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\SpelNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */