/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodType;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReflectionHelper
/*     */ {
/*     */   @Nullable
/*     */   static ArgumentsMatchKind compareArguments(List<TypeDescriptor> expectedArgTypes, List<TypeDescriptor> suppliedArgTypes, TypeConverter typeConverter) {
/*  64 */     Assert.isTrue((expectedArgTypes.size() == suppliedArgTypes.size()), "Expected argument types and supplied argument types should be lists of the same size");
/*     */ 
/*     */     
/*  67 */     ArgumentsMatchKind match = ArgumentsMatchKind.EXACT;
/*  68 */     for (int i = 0; i < expectedArgTypes.size() && match != null; i++) {
/*  69 */       TypeDescriptor suppliedArg = suppliedArgTypes.get(i);
/*  70 */       TypeDescriptor expectedArg = expectedArgTypes.get(i);
/*     */       
/*  72 */       if (suppliedArg == null) {
/*  73 */         if (expectedArg.isPrimitive()) {
/*  74 */           match = null;
/*     */         }
/*     */       }
/*  77 */       else if (!expectedArg.equals(suppliedArg)) {
/*  78 */         if (suppliedArg.isAssignableTo(expectedArg)) {
/*  79 */           if (match != ArgumentsMatchKind.REQUIRES_CONVERSION) {
/*  80 */             match = ArgumentsMatchKind.CLOSE;
/*     */           }
/*     */         }
/*  83 */         else if (typeConverter.canConvert(suppliedArg, expectedArg)) {
/*  84 */           match = ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */         } else {
/*     */           
/*  87 */           match = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*  91 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTypeDifferenceWeight(List<TypeDescriptor> paramTypes, List<TypeDescriptor> argTypes) {
/*  98 */     int result = 0;
/*  99 */     for (int i = 0; i < paramTypes.size(); i++) {
/* 100 */       TypeDescriptor paramType = paramTypes.get(i);
/* 101 */       TypeDescriptor argType = (i < argTypes.size()) ? argTypes.get(i) : null;
/* 102 */       if (argType == null) {
/* 103 */         if (paramType.isPrimitive()) {
/* 104 */           return Integer.MAX_VALUE;
/*     */         }
/*     */       } else {
/*     */         
/* 108 */         Class<?> paramTypeClazz = paramType.getType();
/* 109 */         if (!ClassUtils.isAssignable(paramTypeClazz, argType.getType())) {
/* 110 */           return Integer.MAX_VALUE;
/*     */         }
/* 112 */         if (paramTypeClazz.isPrimitive()) {
/* 113 */           paramTypeClazz = Object.class;
/*     */         }
/* 115 */         Class<?> superClass = argType.getType().getSuperclass();
/* 116 */         while (superClass != null) {
/* 117 */           if (paramTypeClazz.equals(superClass)) {
/* 118 */             result += 2;
/* 119 */             superClass = null; continue;
/*     */           } 
/* 121 */           if (ClassUtils.isAssignable(paramTypeClazz, superClass)) {
/* 122 */             result += 2;
/* 123 */             superClass = superClass.getSuperclass();
/*     */             continue;
/*     */           } 
/* 126 */           superClass = null;
/*     */         } 
/*     */         
/* 129 */         if (paramTypeClazz.isInterface()) {
/* 130 */           result++;
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static ArgumentsMatchKind compareArgumentsVarargs(List<TypeDescriptor> expectedArgTypes, List<TypeDescriptor> suppliedArgTypes, TypeConverter typeConverter) {
/* 153 */     Assert.isTrue(!CollectionUtils.isEmpty(expectedArgTypes), "Expected arguments must at least include one array (the varargs parameter)");
/*     */     
/* 155 */     Assert.isTrue(((TypeDescriptor)expectedArgTypes.get(expectedArgTypes.size() - 1)).isArray(), "Final expected argument should be array type (the varargs parameter)");
/*     */ 
/*     */     
/* 158 */     ArgumentsMatchKind match = ArgumentsMatchKind.EXACT;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     int argCountUpToVarargs = expectedArgTypes.size() - 1;
/* 164 */     for (int i = 0; i < argCountUpToVarargs && match != null; i++) {
/* 165 */       TypeDescriptor suppliedArg = suppliedArgTypes.get(i);
/* 166 */       TypeDescriptor expectedArg = expectedArgTypes.get(i);
/* 167 */       if (suppliedArg == null) {
/* 168 */         if (expectedArg.isPrimitive()) {
/* 169 */           match = null;
/*     */         
/*     */         }
/*     */       }
/* 173 */       else if (!expectedArg.equals(suppliedArg)) {
/* 174 */         if (suppliedArg.isAssignableTo(expectedArg)) {
/* 175 */           if (match != ArgumentsMatchKind.REQUIRES_CONVERSION) {
/* 176 */             match = ArgumentsMatchKind.CLOSE;
/*     */           }
/*     */         }
/* 179 */         else if (typeConverter.canConvert(suppliedArg, expectedArg)) {
/* 180 */           match = ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */         } else {
/*     */           
/* 183 */           match = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (match == null) {
/* 191 */       return null;
/*     */     }
/*     */     
/* 194 */     if (suppliedArgTypes.size() != expectedArgTypes.size() || 
/* 195 */       !((TypeDescriptor)expectedArgTypes.get(expectedArgTypes.size() - 1)).equals(suppliedArgTypes
/* 196 */         .get(suppliedArgTypes.size() - 1))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       TypeDescriptor varargsDesc = expectedArgTypes.get(expectedArgTypes.size() - 1);
/* 204 */       TypeDescriptor componentTypeDesc = varargsDesc.getElementTypeDescriptor();
/* 205 */       Assert.state((componentTypeDesc != null), "Component type must not be null for a varargs array");
/* 206 */       Class<?> varargsComponentType = componentTypeDesc.getType();
/*     */ 
/*     */       
/* 209 */       for (int j = expectedArgTypes.size() - 1; j < suppliedArgTypes.size(); j++) {
/* 210 */         TypeDescriptor suppliedArg = suppliedArgTypes.get(j);
/* 211 */         if (suppliedArg == null) {
/* 212 */           if (varargsComponentType.isPrimitive()) {
/* 213 */             match = null;
/*     */           
/*     */           }
/*     */         }
/* 217 */         else if (varargsComponentType != suppliedArg.getType()) {
/* 218 */           if (ClassUtils.isAssignable(varargsComponentType, suppliedArg.getType())) {
/* 219 */             if (match != ArgumentsMatchKind.REQUIRES_CONVERSION) {
/* 220 */               match = ArgumentsMatchKind.CLOSE;
/*     */             }
/*     */           }
/* 223 */           else if (typeConverter.canConvert(suppliedArg, TypeDescriptor.valueOf(varargsComponentType))) {
/* 224 */             match = ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */           } else {
/*     */             
/* 227 */             match = null;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 234 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean convertAllArguments(TypeConverter converter, Object[] arguments, Method method) throws SpelEvaluationException {
/* 257 */     Integer varargsPosition = method.isVarArgs() ? Integer.valueOf(method.getParameterCount() - 1) : null;
/* 258 */     return convertArguments(converter, arguments, method, varargsPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean convertArguments(TypeConverter converter, Object[] arguments, Executable executable, @Nullable Integer varargsPosition) throws EvaluationException {
/*     */     int i;
/* 276 */     boolean conversionOccurred = false;
/* 277 */     if (varargsPosition == null) {
/* 278 */       for (int j = 0; j < arguments.length; j++) {
/* 279 */         TypeDescriptor targetType = new TypeDescriptor(MethodParameter.forExecutable(executable, j));
/* 280 */         Object argument = arguments[j];
/* 281 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 282 */         arguments[j] = converter.convertValue(argument, sourceType, targetType);
/* 283 */         i = conversionOccurred | ((argument != arguments[j]) ? 1 : 0);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 288 */       for (int j = 0; j < varargsPosition.intValue(); j++) {
/* 289 */         TypeDescriptor typeDescriptor1 = new TypeDescriptor(MethodParameter.forExecutable(executable, j));
/* 290 */         Object argument = arguments[j];
/* 291 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 292 */         arguments[j] = converter.convertValue(argument, sourceType, typeDescriptor1);
/* 293 */         i |= (argument != arguments[j]) ? 1 : 0;
/*     */       } 
/*     */       
/* 296 */       MethodParameter methodParam = MethodParameter.forExecutable(executable, varargsPosition.intValue());
/* 297 */       TypeDescriptor targetType = new TypeDescriptor(methodParam);
/* 298 */       TypeDescriptor componentTypeDesc = targetType.getElementTypeDescriptor();
/* 299 */       Assert.state((componentTypeDesc != null), "Component type must not be null for a varargs array");
/*     */ 
/*     */       
/* 302 */       if (varargsPosition.intValue() == arguments.length - 1) {
/* 303 */         Object argument = arguments[varargsPosition.intValue()];
/* 304 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 305 */         if (argument == null) {
/*     */           
/* 307 */           if (componentTypeDesc.getObjectType() == Optional.class) {
/* 308 */             arguments[varargsPosition.intValue()] = Optional.empty();
/* 309 */             i = 1;
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 318 */         else if (!sourceType.isAssignableTo(componentTypeDesc) || (sourceType
/* 319 */           .isArray() && !sourceType.isAssignableTo(targetType)) || argument instanceof List) {
/*     */ 
/*     */ 
/*     */           
/* 323 */           TypeDescriptor targetTypeToUse = (sourceType.isArray() || argument instanceof List || converter.canConvert(sourceType, targetType)) ? targetType : componentTypeDesc;
/* 324 */           arguments[varargsPosition.intValue()] = converter.convertValue(argument, sourceType, targetTypeToUse);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 332 */         if (argument != arguments[varargsPosition.intValue()] && 
/* 333 */           !isFirstEntryInArray(argument, arguments[varargsPosition.intValue()])) {
/* 334 */           i = 1;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 339 */         for (int k = varargsPosition.intValue(); k < arguments.length; k++) {
/* 340 */           Object argument = arguments[k];
/* 341 */           TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 342 */           arguments[k] = converter.convertValue(argument, sourceType, componentTypeDesc);
/* 343 */           i |= (argument != arguments[k]) ? 1 : 0;
/*     */         } 
/*     */       } 
/*     */     } 
/* 347 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean convertAllMethodHandleArguments(TypeConverter converter, Object[] arguments, MethodHandle methodHandle, @Nullable Integer varargsPosition) throws EvaluationException {
/*     */     int i;
/* 366 */     boolean conversionOccurred = false;
/* 367 */     MethodType methodHandleType = methodHandle.type();
/* 368 */     if (varargsPosition == null) {
/* 369 */       for (int j = 0; j < arguments.length; j++) {
/* 370 */         Class<?> argumentClass = methodHandleType.parameterType(j);
/* 371 */         ResolvableType resolvableType = ResolvableType.forClass(argumentClass);
/* 372 */         TypeDescriptor targetType = new TypeDescriptor(resolvableType, argumentClass, null);
/*     */         
/* 374 */         Object argument = arguments[j];
/* 375 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 376 */         arguments[j] = converter.convertValue(argument, sourceType, targetType);
/* 377 */         i = conversionOccurred | ((argument != arguments[j]) ? 1 : 0);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 382 */       for (int j = 0; j < varargsPosition.intValue(); j++) {
/* 383 */         Class<?> argumentClass = methodHandleType.parameterType(j);
/* 384 */         ResolvableType resolvableType = ResolvableType.forClass(argumentClass);
/* 385 */         TypeDescriptor targetType = new TypeDescriptor(resolvableType, argumentClass, null);
/*     */         
/* 387 */         Object argument = arguments[j];
/* 388 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 389 */         arguments[j] = converter.convertValue(argument, sourceType, targetType);
/* 390 */         i |= (argument != arguments[j]) ? 1 : 0;
/*     */       } 
/*     */       
/* 393 */       Class<?> varargsArrayClass = methodHandleType.lastParameterType();
/*     */ 
/*     */ 
/*     */       
/* 397 */       Class<?> varargsComponentClass = ClassUtils.resolvePrimitiveIfNecessary(varargsArrayClass.componentType());
/* 398 */       TypeDescriptor varargsArrayType = TypeDescriptor.array(TypeDescriptor.valueOf(varargsComponentClass));
/* 399 */       TypeDescriptor varargsComponentType = varargsArrayType.getElementTypeDescriptor();
/* 400 */       Assert.state((varargsComponentType != null), "Component type must not be null for a varargs array");
/*     */ 
/*     */       
/* 403 */       if (varargsPosition.intValue() == arguments.length - 1) {
/* 404 */         Object argument = arguments[varargsPosition.intValue()];
/* 405 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 406 */         if (argument == null) {
/*     */           
/* 408 */           if (varargsComponentType.getObjectType() == Optional.class) {
/* 409 */             arguments[varargsPosition.intValue()] = Optional.empty();
/* 410 */             i = 1;
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 419 */         else if (!sourceType.isAssignableTo(varargsComponentType) || (sourceType
/* 420 */           .isArray() && !sourceType.isAssignableTo(varargsArrayType)) || argument instanceof List) {
/*     */ 
/*     */ 
/*     */           
/* 424 */           TypeDescriptor targetTypeToUse = (sourceType.isArray() || argument instanceof List || converter.canConvert(sourceType, varargsArrayType)) ? varargsArrayType : varargsComponentType;
/* 425 */           arguments[varargsPosition.intValue()] = converter.convertValue(argument, sourceType, targetTypeToUse);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 433 */         if (argument != arguments[varargsPosition.intValue()] && 
/* 434 */           !isFirstEntryInArray(argument, arguments[varargsPosition.intValue()])) {
/* 435 */           i = 1;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 440 */         for (int k = varargsPosition.intValue(); k < arguments.length; k++) {
/* 441 */           Object argument = arguments[k];
/* 442 */           TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 443 */           arguments[k] = converter.convertValue(argument, sourceType, varargsComponentType);
/* 444 */           i |= (argument != arguments[k]) ? 1 : 0;
/*     */         } 
/*     */       } 
/*     */     } 
/* 448 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isFirstEntryInArray(Object value, @Nullable Object possibleArray) {
/* 458 */     if (possibleArray == null) {
/* 459 */       return false;
/*     */     }
/* 461 */     Class<?> type = possibleArray.getClass();
/* 462 */     if (!type.isArray() || Array.getLength(possibleArray) == 0 || 
/* 463 */       !ClassUtils.isAssignableValue(type.componentType(), value)) {
/* 464 */       return false;
/*     */     }
/* 466 */     Object arrayValue = Array.get(possibleArray, 0);
/* 467 */     return type.componentType().isPrimitive() ? arrayValue.equals(value) : ((arrayValue == value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object[] setupArgumentsForVarargsInvocation(Class<?>[] requiredParameterTypes, Object... args) {
/* 482 */     Assert.notEmpty((Object[])requiredParameterTypes, "Required parameter types array must not be empty");
/*     */     
/* 484 */     int parameterCount = requiredParameterTypes.length;
/* 485 */     Class<?> lastRequiredParameterType = requiredParameterTypes[parameterCount - 1];
/* 486 */     Assert.isTrue(lastRequiredParameterType.isArray(), "The last required parameter type must be an array to support varargs invocation");
/*     */ 
/*     */     
/* 489 */     int argumentCount = args.length;
/* 490 */     Object lastArgument = (argumentCount > 0) ? args[argumentCount - 1] : null;
/*     */ 
/*     */     
/* 493 */     if (parameterCount != argumentCount || !lastRequiredParameterType.isInstance(lastArgument)) {
/*     */       
/* 495 */       Object[] newArgs = new Object[parameterCount];
/*     */       
/* 497 */       System.arraycopy(args, 0, newArgs, 0, newArgs.length - 1);
/*     */ 
/*     */ 
/*     */       
/* 501 */       int varargsArraySize = 0;
/* 502 */       if (argumentCount >= parameterCount) {
/* 503 */         varargsArraySize = argumentCount - parameterCount - 1;
/*     */       }
/* 505 */       Class<?> componentType = lastRequiredParameterType.componentType();
/* 506 */       Object varargsArray = Array.newInstance(componentType, varargsArraySize);
/* 507 */       for (int i = 0; i < varargsArraySize; i++) {
/* 508 */         Array.set(varargsArray, i, args[parameterCount - 1 + i]);
/*     */       }
/*     */       
/* 511 */       newArgs[newArgs.length - 1] = varargsArray;
/* 512 */       return newArgs;
/*     */     } 
/*     */     
/* 515 */     return args;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum ArgumentsMatchKind
/*     */   {
/* 529 */     EXACT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 534 */     CLOSE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 539 */     REQUIRES_CONVERSION;
/*     */     
/*     */     public boolean isExactMatch() {
/* 542 */       return (this == EXACT);
/*     */     }
/*     */     
/*     */     public boolean isCloseMatch() {
/* 546 */       return (this == CLOSE);
/*     */     }
/*     */     
/*     */     public boolean isMatchRequiringConversion() {
/* 550 */       return (this == REQUIRES_CONVERSION);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectionHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */