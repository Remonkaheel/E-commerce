/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KMutableProperty;
/*     */ import kotlin.reflect.KProperty;
/*     */ import kotlin.reflect.full.KClasses;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.Property;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompilablePropertyAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectivePropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*  74 */   private static final Set<Class<?>> ANY_TYPES = Collections.emptySet();
/*     */   
/*  76 */   private static final Set<Class<?>> BOOLEAN_TYPES = Set.of(Boolean.class, boolean.class);
/*     */   
/*     */   private final boolean allowWrite;
/*     */   
/*  80 */   private final Map<PropertyCacheKey, InvokerPair> readerCache = new ConcurrentHashMap<>(64);
/*     */   
/*  82 */   private final Map<PropertyCacheKey, Member> writerCache = new ConcurrentHashMap<>(64);
/*     */   
/*  84 */   private final Map<PropertyCacheKey, TypeDescriptor> typeDescriptorCache = new ConcurrentHashMap<>(64);
/*     */   
/*  86 */   private final Map<Class<?>, Method[]> sortedMethodsCache = (Map)new ConcurrentHashMap<>(64);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectivePropertyAccessor() {
/*  94 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectivePropertyAccessor(boolean allowWrite) {
/* 104 */     this.allowWrite = allowWrite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?>[] getSpecificTargetClasses() {
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 119 */     if (target == null) {
/* 120 */       return false;
/*     */     }
/*     */     
/* 123 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/* 124 */     if (type.isArray() && name.equals("length")) {
/* 125 */       return true;
/*     */     }
/*     */     
/* 128 */     PropertyCacheKey cacheKey = new PropertyCacheKey(type, name, target instanceof Class);
/* 129 */     if (this.readerCache.containsKey(cacheKey)) {
/* 130 */       return true;
/*     */     }
/*     */     
/* 133 */     Method method = findGetterForProperty(name, type, target);
/* 134 */     if (method != null) {
/*     */ 
/*     */       
/* 137 */       Property property = new Property(type, method, null);
/* 138 */       TypeDescriptor typeDescriptor = new TypeDescriptor(property);
/* 139 */       Method methodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, type);
/* 140 */       this.readerCache.put(cacheKey, new InvokerPair(methodToInvoke, typeDescriptor));
/* 141 */       this.typeDescriptorCache.put(cacheKey, typeDescriptor);
/* 142 */       return true;
/*     */     } 
/*     */     
/* 145 */     Field field = findField(name, type, target);
/* 146 */     if (field != null) {
/* 147 */       TypeDescriptor typeDescriptor = new TypeDescriptor(field);
/* 148 */       this.readerCache.put(cacheKey, new InvokerPair(field, typeDescriptor));
/* 149 */       this.typeDescriptorCache.put(cacheKey, typeDescriptor);
/* 150 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 154 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 160 */     Assert.state((target != null), "Target must not be null");
/* 161 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/*     */     
/* 163 */     if (type.isArray() && name.equals("length")) {
/* 164 */       if (target instanceof Class) {
/* 165 */         throw new AccessException("Cannot access length on array class itself");
/*     */       }
/* 167 */       return new TypedValue(Integer.valueOf(Array.getLength(target)));
/*     */     } 
/*     */     
/* 170 */     PropertyCacheKey cacheKey = new PropertyCacheKey(type, name, target instanceof Class);
/* 171 */     InvokerPair invoker = this.readerCache.get(cacheKey);
/*     */     
/* 173 */     if (invoker == null || invoker.member instanceof Method) {
/* 174 */       Method method = (invoker != null) ? (Method)invoker.member : null;
/* 175 */       Method methodToInvoke = method;
/* 176 */       if (method == null) {
/* 177 */         method = findGetterForProperty(name, type, target);
/* 178 */         if (method != null) {
/*     */ 
/*     */           
/* 181 */           Property property = new Property(type, method, null);
/* 182 */           TypeDescriptor typeDescriptor = new TypeDescriptor(property);
/* 183 */           methodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, type);
/* 184 */           invoker = new InvokerPair(methodToInvoke, typeDescriptor);
/* 185 */           this.readerCache.put(cacheKey, invoker);
/*     */         } 
/*     */       } 
/* 188 */       if (methodToInvoke != null) {
/*     */         try {
/* 190 */           ReflectionUtils.makeAccessible(methodToInvoke);
/* 191 */           Object value = methodToInvoke.invoke(target, new Object[0]);
/* 192 */           return new TypedValue(value, invoker.typeDescriptor.narrow(value));
/*     */         }
/* 194 */         catch (Exception ex) {
/* 195 */           throw new AccessException("Unable to access property '" + name + "' through getter method", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 200 */     if (invoker == null || invoker.member instanceof Field) {
/* 201 */       Field field = (invoker == null) ? null : (Field)invoker.member;
/* 202 */       if (field == null) {
/* 203 */         field = findField(name, type, target);
/* 204 */         if (field != null) {
/* 205 */           invoker = new InvokerPair(field, new TypeDescriptor(field));
/* 206 */           this.readerCache.put(cacheKey, invoker);
/*     */         } 
/*     */       } 
/* 209 */       if (field != null) {
/*     */         try {
/* 211 */           ReflectionUtils.makeAccessible(field);
/* 212 */           Object value = field.get(target);
/* 213 */           return new TypedValue(value, invoker.typeDescriptor.narrow(value));
/*     */         }
/* 215 */         catch (Exception ex) {
/* 216 */           throw new AccessException("Unable to access field '" + name + "'", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 221 */     throw new AccessException("Neither getter method nor field found for property '" + name + "'");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 226 */     if (!this.allowWrite || target == null) {
/* 227 */       return false;
/*     */     }
/*     */     
/* 230 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/* 231 */     PropertyCacheKey cacheKey = new PropertyCacheKey(type, name, target instanceof Class);
/* 232 */     if (this.writerCache.containsKey(cacheKey)) {
/* 233 */       return true;
/*     */     }
/*     */     
/* 236 */     Method method = findSetterForProperty(name, type, target);
/* 237 */     if (method != null) {
/*     */       
/* 239 */       Property property = new Property(type, null, method);
/* 240 */       TypeDescriptor typeDescriptor = new TypeDescriptor(property);
/* 241 */       method = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, type);
/* 242 */       this.writerCache.put(cacheKey, method);
/* 243 */       this.typeDescriptorCache.put(cacheKey, typeDescriptor);
/* 244 */       return true;
/*     */     } 
/*     */     
/* 247 */     Field field = findField(name, type, target);
/* 248 */     if (field != null) {
/* 249 */       this.writerCache.put(cacheKey, field);
/* 250 */       this.typeDescriptorCache.put(cacheKey, new TypeDescriptor(field));
/* 251 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 255 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) throws AccessException {
/* 262 */     if (!this.allowWrite) {
/* 263 */       throw new AccessException("PropertyAccessor for property '" + name + "' on target [" + String.valueOf(target) + "] does not allow write operations");
/*     */     }
/*     */ 
/*     */     
/* 267 */     Assert.state((target != null), "Target must not be null");
/* 268 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/*     */     
/* 270 */     Object possiblyConvertedNewValue = newValue;
/* 271 */     TypeDescriptor typeDescriptor = getTypeDescriptor(context, target, name);
/* 272 */     if (typeDescriptor != null) {
/*     */       try {
/* 274 */         possiblyConvertedNewValue = context.getTypeConverter().convertValue(newValue, 
/* 275 */             TypeDescriptor.forObject(newValue), typeDescriptor);
/*     */       }
/* 277 */       catch (EvaluationException evaluationException) {
/* 278 */         throw new AccessException("Type conversion failure", evaluationException);
/*     */       } 
/*     */     }
/*     */     
/* 282 */     PropertyCacheKey cacheKey = new PropertyCacheKey(type, name, target instanceof Class);
/* 283 */     Member cachedMember = this.writerCache.get(cacheKey);
/*     */     
/* 285 */     if (cachedMember == null || cachedMember instanceof Method) {
/* 286 */       Method method = (Method)cachedMember;
/* 287 */       if (method == null) {
/* 288 */         method = findSetterForProperty(name, type, target);
/* 289 */         if (method != null) {
/* 290 */           method = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, type);
/* 291 */           cachedMember = method;
/* 292 */           this.writerCache.put(cacheKey, cachedMember);
/*     */         } 
/*     */       } 
/* 295 */       if (method != null) {
/*     */         try {
/* 297 */           ReflectionUtils.makeAccessible(method);
/* 298 */           method.invoke(target, new Object[] { possiblyConvertedNewValue });
/*     */           
/*     */           return;
/* 301 */         } catch (Exception ex) {
/* 302 */           throw new AccessException("Unable to access property '" + name + "' through setter method", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 307 */     if (cachedMember == null || cachedMember instanceof Field) {
/* 308 */       Field field = (Field)cachedMember;
/* 309 */       if (field == null) {
/* 310 */         field = findField(name, type, target);
/* 311 */         if (field != null) {
/* 312 */           cachedMember = field;
/* 313 */           this.writerCache.put(cacheKey, cachedMember);
/*     */         } 
/*     */       } 
/* 316 */       if (field != null) {
/*     */         try {
/* 318 */           ReflectionUtils.makeAccessible(field);
/* 319 */           field.set(target, possiblyConvertedNewValue);
/*     */           
/*     */           return;
/* 322 */         } catch (Exception ex) {
/* 323 */           throw new AccessException("Unable to access field '" + name + "'", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 328 */     throw new AccessException("Neither setter method nor field found for property '" + name + "'");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypeDescriptor getTypeDescriptor(EvaluationContext context, Object target, String name) {
/* 334 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/*     */     
/* 336 */     if (type.isArray() && name.equals("length")) {
/* 337 */       return TypeDescriptor.valueOf(int.class);
/*     */     }
/* 339 */     PropertyCacheKey cacheKey = new PropertyCacheKey(type, name, target instanceof Class);
/* 340 */     TypeDescriptor typeDescriptor = this.typeDescriptorCache.get(cacheKey);
/* 341 */     if (typeDescriptor == null) {
/*     */       
/*     */       try {
/* 344 */         if (canRead(context, target, name) || canWrite(context, target, name)) {
/* 345 */           typeDescriptor = this.typeDescriptorCache.get(cacheKey);
/*     */         }
/*     */       }
/* 348 */       catch (AccessException accessException) {}
/*     */     }
/*     */ 
/*     */     
/* 352 */     return typeDescriptor;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Method findGetterForProperty(String propertyName, Class<?> clazz, Object target) {
/* 357 */     boolean targetIsAClass = target instanceof Class;
/* 358 */     Method method = findGetterForProperty(propertyName, clazz, targetIsAClass);
/* 359 */     if (method == null && targetIsAClass)
/*     */     {
/* 361 */       method = findGetterForProperty(propertyName, Class.class, false);
/*     */     }
/* 363 */     return method;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Method findSetterForProperty(String propertyName, Class<?> clazz, Object target) {
/* 368 */     Method method = findSetterForProperty(propertyName, clazz, target instanceof Class);
/*     */ 
/*     */     
/* 371 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Method findGetterForProperty(String propertyName, Class<?> clazz, boolean mustBeStatic) {
/* 379 */     Method method = findMethodForProperty(getPropertyMethodSuffixes(propertyName), "get", clazz, mustBeStatic, 0, ANY_TYPES);
/*     */     
/* 381 */     if (method == null) {
/* 382 */       method = findMethodForProperty(getPropertyMethodSuffixes(propertyName), "is", clazz, mustBeStatic, 0, BOOLEAN_TYPES);
/*     */       
/* 384 */       if (method == null)
/*     */       {
/* 386 */         method = findMethodForProperty(new String[] { propertyName }, "", clazz, mustBeStatic, 0, ANY_TYPES);
/*     */       }
/*     */     } 
/*     */     
/* 390 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Method findSetterForProperty(String propertyName, Class<?> clazz, boolean mustBeStatic) {
/* 398 */     return findMethodForProperty(getPropertyMethodSuffixes(propertyName), "set", clazz, mustBeStatic, 1, ANY_TYPES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Method findMethodForProperty(String[] methodSuffixes, String prefix, Class<?> clazz, boolean mustBeStatic, int numberOfParams, Set<Class<?>> requiredReturnTypes) {
/* 406 */     Method[] methods = getSortedMethods(clazz);
/* 407 */     for (String methodSuffix : methodSuffixes) {
/* 408 */       for (Method method : methods) {
/* 409 */         if (isCandidateForProperty(method, clazz) && (method
/* 410 */           .getName().equals(prefix + prefix) || isKotlinProperty(method, methodSuffix)) && method
/* 411 */           .getParameterCount() == numberOfParams && (!mustBeStatic || 
/* 412 */           Modifier.isStatic(method.getModifiers())) && (requiredReturnTypes
/* 413 */           .isEmpty() || requiredReturnTypes.contains(method.getReturnType()))) {
/* 414 */           return method;
/*     */         }
/*     */       } 
/*     */     } 
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method[] getSortedMethods(Class<?> clazz) {
/* 425 */     return this.sortedMethodsCache.computeIfAbsent(clazz, key -> {
/*     */           Method[] methods = key.getMethods();
/*     */           Arrays.sort(methods, ());
/*     */           return methods;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCandidateForProperty(Method method, Class<?> targetClass) {
/* 442 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getPropertyMethodSuffixes(String propertyName) {
/* 452 */     String suffix = getPropertyMethodSuffix(propertyName);
/* 453 */     if (suffix.length() > 0 && Character.isUpperCase(suffix.charAt(0))) {
/* 454 */       return new String[] { suffix };
/*     */     }
/* 456 */     return new String[] { suffix, StringUtils.capitalize(suffix) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPropertyMethodSuffix(String propertyName) {
/* 464 */     if (propertyName.length() > 1 && Character.isUpperCase(propertyName.charAt(1))) {
/* 465 */       return propertyName;
/*     */     }
/* 467 */     return StringUtils.capitalize(propertyName);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Field findField(String name, Class<?> clazz, Object target) {
/* 472 */     Field field = findField(name, clazz, target instanceof Class);
/* 473 */     if (field == null && target instanceof Class) {
/* 474 */       field = findField(name, target.getClass(), false);
/*     */     }
/* 476 */     return field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Field findField(String name, Class<?> clazz, boolean mustBeStatic) {
/* 484 */     Field[] fields = clazz.getFields();
/* 485 */     for (Field field : fields) {
/* 486 */       if (field.getName().equals(name) && (!mustBeStatic || Modifier.isStatic(field.getModifiers()))) {
/* 487 */         return field;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 492 */     if (clazz.getSuperclass() != null) {
/* 493 */       Field field = findField(name, clazz.getSuperclass(), mustBeStatic);
/* 494 */       if (field != null) {
/* 495 */         return field;
/*     */       }
/*     */     } 
/* 498 */     for (Class<?> implementedInterface : clazz.getInterfaces()) {
/* 499 */       Field field = findField(name, implementedInterface, mustBeStatic);
/* 500 */       if (field != null) {
/* 501 */         return field;
/*     */       }
/*     */     } 
/* 504 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyAccessor createOptimalAccessor(EvaluationContext context, @Nullable Object target, String name) {
/* 522 */     if (target == null) {
/* 523 */       return this;
/*     */     }
/* 525 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/* 526 */     if (type.isArray()) {
/* 527 */       return this;
/*     */     }
/*     */     
/* 530 */     PropertyCacheKey cacheKey = new PropertyCacheKey(type, name, target instanceof Class);
/* 531 */     InvokerPair invokerPair = this.readerCache.get(cacheKey);
/*     */     
/* 533 */     if (invokerPair == null || invokerPair.member instanceof Method) {
/* 534 */       Method method = (invokerPair != null) ? (Method)invokerPair.member : null;
/* 535 */       if (method == null) {
/* 536 */         method = findGetterForProperty(name, type, target);
/* 537 */         if (method != null) {
/* 538 */           TypeDescriptor typeDescriptor = new TypeDescriptor(new MethodParameter(method, -1));
/* 539 */           Method methodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, type);
/* 540 */           ReflectionUtils.makeAccessible(methodToInvoke);
/* 541 */           invokerPair = new InvokerPair(methodToInvoke, typeDescriptor);
/* 542 */           this.readerCache.put(cacheKey, invokerPair);
/*     */         } 
/*     */       } 
/* 545 */       if (method != null) {
/* 546 */         return (PropertyAccessor)new OptimalPropertyAccessor(invokerPair);
/*     */       }
/*     */     } 
/*     */     
/* 550 */     if (invokerPair == null || invokerPair.member instanceof Field) {
/* 551 */       Field field = (invokerPair != null) ? (Field)invokerPair.member : null;
/* 552 */       if (field == null) {
/* 553 */         field = findField(name, type, target instanceof Class);
/* 554 */         if (field != null) {
/* 555 */           ReflectionUtils.makeAccessible(field);
/* 556 */           invokerPair = new InvokerPair(field, new TypeDescriptor(field));
/* 557 */           this.readerCache.put(cacheKey, invokerPair);
/*     */         } 
/*     */       } 
/* 560 */       if (field != null) {
/* 561 */         return (PropertyAccessor)new OptimalPropertyAccessor(invokerPair);
/*     */       }
/*     */     } 
/*     */     
/* 565 */     return this;
/*     */   }
/*     */   
/*     */   private static boolean isKotlinProperty(Method method, String methodSuffix) {
/* 569 */     Class<?> clazz = method.getDeclaringClass();
/* 570 */     return (KotlinDetector.isKotlinReflectPresent() && 
/* 571 */       KotlinDetector.isKotlinType(clazz) && 
/* 572 */       KotlinDelegate.isKotlinProperty(method, methodSuffix));
/*     */   } private static final class InvokerPair extends Record {
/*     */     private final Member member; private final TypeDescriptor typeDescriptor; public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$InvokerPair;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #580	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$InvokerPair;
/*     */     }
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$InvokerPair;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #580	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$InvokerPair;
/*     */     }
/* 580 */     private InvokerPair(Member member, TypeDescriptor typeDescriptor) { this.member = member; this.typeDescriptor = typeDescriptor; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$InvokerPair;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #580	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$InvokerPair;
/* 580 */       //   0	8	1	o	Ljava/lang/Object; } public Member member() { return this.member; } public TypeDescriptor typeDescriptor() { return this.typeDescriptor; }
/*     */      }
/*     */   private static final class PropertyCacheKey extends Record implements Comparable<PropertyCacheKey> { private final Class<?> clazz; private final String property; private final boolean targetIsClass;
/* 583 */     private PropertyCacheKey(Class<?> clazz, String property, boolean targetIsClass) { this.clazz = clazz; this.property = property; this.targetIsClass = targetIsClass; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$PropertyCacheKey;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #583	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$PropertyCacheKey; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$PropertyCacheKey;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #583	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$PropertyCacheKey; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$PropertyCacheKey;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #583	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/expression/spel/support/ReflectivePropertyAccessor$PropertyCacheKey;
/* 583 */       //   0	8	1	o	Ljava/lang/Object; } public Class<?> clazz() { return this.clazz; } public String property() { return this.property; } public boolean targetIsClass() { return this.targetIsClass; }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(PropertyCacheKey other) {
/* 588 */       int result = this.clazz.getName().compareTo(other.clazz.getName());
/* 589 */       if (result == 0) {
/* 590 */         result = this.property.compareTo(other.property);
/*     */       }
/* 592 */       return result;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class OptimalPropertyAccessor
/*     */     implements CompilablePropertyAccessor
/*     */   {
/*     */     private final Member member;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescriptor typeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     OptimalPropertyAccessor(ReflectivePropertyAccessor.InvokerPair invokerPair) {
/* 617 */       this.member = invokerPair.member;
/* 618 */       this.typeDescriptor = invokerPair.typeDescriptor;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?>[] getSpecificTargetClasses() {
/* 624 */       throw new UnsupportedOperationException("Should not be called on an OptimalPropertyAccessor");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 629 */       if (target == null) {
/* 630 */         return false;
/*     */       }
/* 632 */       Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/* 633 */       if (type.isArray()) {
/* 634 */         return false;
/*     */       }
/*     */       
/* 637 */       Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/* 638 */         String getterName = "get" + StringUtils.capitalize(name);
/* 639 */         if (getterName.equals(method.getName())) {
/* 640 */           return true;
/*     */         }
/* 642 */         getterName = "is" + StringUtils.capitalize(name);
/* 643 */         if (getterName.equals(method.getName())) {
/* 644 */           return true;
/*     */         } }
/*     */       
/* 647 */       return this.member.getName().equals(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 652 */       Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/*     */         try {
/* 654 */           ReflectionUtils.makeAccessible(method);
/* 655 */           Object value = method.invoke(target, new Object[0]);
/* 656 */           return new TypedValue(value, this.typeDescriptor.narrow(value));
/*     */         }
/* 658 */         catch (Exception ex) {
/* 659 */           throw new AccessException("Unable to access property '" + name + "' through getter method", ex);
/*     */         }  }
/*     */ 
/*     */       
/* 663 */       Field field = (Field)this.member;
/*     */       try {
/* 665 */         ReflectionUtils.makeAccessible(field);
/* 666 */         Object value = field.get(target);
/* 667 */         return new TypedValue(value, this.typeDescriptor.narrow(value));
/*     */       }
/* 669 */       catch (Exception ex) {
/* 670 */         throw new AccessException("Unable to access field '" + name + "'", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) {
/* 677 */       throw new UnsupportedOperationException("Should not be called on an OptimalPropertyAccessor");
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) {
/* 682 */       throw new UnsupportedOperationException("Should not be called on an OptimalPropertyAccessor");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCompilable() {
/* 687 */       return (Modifier.isPublic(this.member.getModifiers()) && 
/* 688 */         Modifier.isPublic(this.member.getDeclaringClass().getModifiers()));
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getPropertyType() {
/* 693 */       Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/* 694 */         return method.getReturnType(); }
/*     */ 
/*     */       
/* 697 */       return ((Field)this.member).getType();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void generateCode(String propertyName, MethodVisitor mv, CodeFlow cf) {
/* 703 */       Class<?> publicDeclaringClass = this.member.getDeclaringClass();
/* 704 */       Assert.state(Modifier.isPublic(publicDeclaringClass.getModifiers()), () -> "Failed to find public declaring class for: " + String.valueOf(this.member));
/*     */ 
/*     */       
/* 707 */       String classDesc = publicDeclaringClass.getName().replace('.', '/');
/* 708 */       boolean isStatic = Modifier.isStatic(this.member.getModifiers());
/* 709 */       String descriptor = cf.lastDescriptor();
/*     */       
/* 711 */       if (!isStatic) {
/* 712 */         if (descriptor == null) {
/* 713 */           cf.loadTarget(mv);
/*     */         }
/* 715 */         if (descriptor == null || !classDesc.equals(descriptor.substring(1))) {
/* 716 */           mv.visitTypeInsn(192, classDesc);
/*     */         
/*     */         }
/*     */       }
/* 720 */       else if (descriptor != null) {
/*     */ 
/*     */         
/* 723 */         mv.visitInsn(87);
/*     */       } 
/*     */ 
/*     */       
/* 727 */       Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/* 728 */         boolean isInterface = publicDeclaringClass.isInterface();
/* 729 */         int opcode = isStatic ? 184 : (isInterface ? 185 : 182);
/* 730 */         mv.visitMethodInsn(opcode, classDesc, method.getName(), 
/* 731 */             CodeFlow.createSignatureDescriptor(method), isInterface); }
/*     */       else
/*     */       
/* 734 */       { mv.visitFieldInsn(isStatic ? 178 : 180, classDesc, this.member.getName(), 
/* 735 */             CodeFlow.toJvmDescriptor(((Field)this.member).getType())); }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     public static boolean isKotlinProperty(Method method, String methodSuffix) {
/* 746 */       KClass<?> kClass = JvmClassMappingKt.getKotlinClass(method.getDeclaringClass());
/* 747 */       for (KProperty<?> property : (Iterable<KProperty<?>>)KClasses.getMemberProperties(kClass)) {
/* 748 */         if (methodSuffix.equalsIgnoreCase(property.getName())) {
/* 749 */           if (!method.equals(ReflectJvmMapping.getJavaGetter(property))) { if (property instanceof KMutableProperty)
/* 750 */             { KMutableProperty<?> mutableProperty = (KMutableProperty)property; if (method
/* 751 */                 .equals(ReflectJvmMapping.getJavaSetter(mutableProperty)))
/* 752 */                 return true;  }  continue; }  return true;
/*     */         } 
/*     */       } 
/* 755 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectivePropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */