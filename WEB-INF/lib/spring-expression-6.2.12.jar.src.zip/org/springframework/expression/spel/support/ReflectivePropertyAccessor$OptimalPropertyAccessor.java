/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompilablePropertyAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OptimalPropertyAccessor
/*     */   implements CompilablePropertyAccessor
/*     */ {
/*     */   private final Member member;
/*     */   private final TypeDescriptor typeDescriptor;
/*     */   
/*     */   OptimalPropertyAccessor(ReflectivePropertyAccessor.InvokerPair invokerPair) {
/* 617 */     this.member = invokerPair.member;
/* 618 */     this.typeDescriptor = invokerPair.typeDescriptor;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?>[] getSpecificTargetClasses() {
/* 624 */     throw new UnsupportedOperationException("Should not be called on an OptimalPropertyAccessor");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 629 */     if (target == null) {
/* 630 */       return false;
/*     */     }
/* 632 */     Class<?> clazz = (Class)target, type = (target instanceof Class) ? clazz : target.getClass();
/* 633 */     if (type.isArray()) {
/* 634 */       return false;
/*     */     }
/*     */     
/* 637 */     Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/* 638 */       String getterName = "get" + StringUtils.capitalize(name);
/* 639 */       if (getterName.equals(method.getName())) {
/* 640 */         return true;
/*     */       }
/* 642 */       getterName = "is" + StringUtils.capitalize(name);
/* 643 */       if (getterName.equals(method.getName())) {
/* 644 */         return true;
/*     */       } }
/*     */     
/* 647 */     return this.member.getName().equals(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue read(EvaluationContext context, @Nullable Object target, String name) throws AccessException {
/* 652 */     Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/*     */       try {
/* 654 */         ReflectionUtils.makeAccessible(method);
/* 655 */         Object value = method.invoke(target, new Object[0]);
/* 656 */         return new TypedValue(value, this.typeDescriptor.narrow(value));
/*     */       }
/* 658 */       catch (Exception ex) {
/* 659 */         throw new AccessException("Unable to access property '" + name + "' through getter method", ex);
/*     */       }  }
/*     */ 
/*     */     
/* 663 */     Field field = (Field)this.member;
/*     */     try {
/* 665 */       ReflectionUtils.makeAccessible(field);
/* 666 */       Object value = field.get(target);
/* 667 */       return new TypedValue(value, this.typeDescriptor.narrow(value));
/*     */     }
/* 669 */     catch (Exception ex) {
/* 670 */       throw new AccessException("Unable to access field '" + name + "'", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(EvaluationContext context, @Nullable Object target, String name) {
/* 677 */     throw new UnsupportedOperationException("Should not be called on an OptimalPropertyAccessor");
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(EvaluationContext context, @Nullable Object target, String name, @Nullable Object newValue) {
/* 682 */     throw new UnsupportedOperationException("Should not be called on an OptimalPropertyAccessor");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 687 */     return (Modifier.isPublic(this.member.getModifiers()) && 
/* 688 */       Modifier.isPublic(this.member.getDeclaringClass().getModifiers()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getPropertyType() {
/* 693 */     Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/* 694 */       return method.getReturnType(); }
/*     */ 
/*     */     
/* 697 */     return ((Field)this.member).getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(String propertyName, MethodVisitor mv, CodeFlow cf) {
/* 703 */     Class<?> publicDeclaringClass = this.member.getDeclaringClass();
/* 704 */     Assert.state(Modifier.isPublic(publicDeclaringClass.getModifiers()), () -> "Failed to find public declaring class for: " + String.valueOf(this.member));
/*     */ 
/*     */     
/* 707 */     String classDesc = publicDeclaringClass.getName().replace('.', '/');
/* 708 */     boolean isStatic = Modifier.isStatic(this.member.getModifiers());
/* 709 */     String descriptor = cf.lastDescriptor();
/*     */     
/* 711 */     if (!isStatic) {
/* 712 */       if (descriptor == null) {
/* 713 */         cf.loadTarget(mv);
/*     */       }
/* 715 */       if (descriptor == null || !classDesc.equals(descriptor.substring(1))) {
/* 716 */         mv.visitTypeInsn(192, classDesc);
/*     */       
/*     */       }
/*     */     }
/* 720 */     else if (descriptor != null) {
/*     */ 
/*     */       
/* 723 */       mv.visitInsn(87);
/*     */     } 
/*     */ 
/*     */     
/* 727 */     Member member = this.member; if (member instanceof Method) { Method method = (Method)member;
/* 728 */       boolean isInterface = publicDeclaringClass.isInterface();
/* 729 */       int opcode = isStatic ? 184 : (isInterface ? 185 : 182);
/* 730 */       mv.visitMethodInsn(opcode, classDesc, method.getName(), 
/* 731 */           CodeFlow.createSignatureDescriptor(method), isInterface); }
/*     */     else
/*     */     
/* 734 */     { mv.visitFieldInsn(isStatic ? 178 : 180, classDesc, this.member.getName(), 
/* 735 */           CodeFlow.toJvmDescriptor(((Field)this.member).getType())); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectivePropertyAccessor$OptimalPropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */