/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardTypeComparator
/*     */   implements TypeComparator
/*     */ {
/*  40 */   static final StandardTypeComparator INSTANCE = new StandardTypeComparator();
/*     */ 
/*     */   
/*     */   public boolean canCompare(@Nullable Object left, @Nullable Object right) {
/*  44 */     if (left == null || right == null) {
/*  45 */       return true;
/*     */     }
/*  47 */     if (left instanceof Number && right instanceof Number) {
/*  48 */       return true;
/*     */     }
/*  50 */     if (left instanceof Comparable && right instanceof Comparable) {
/*  51 */       Class<?> ancestor = ClassUtils.determineCommonAncestor(left.getClass(), right.getClass());
/*  52 */       return (ancestor != null && Comparable.class.isAssignableFrom(ancestor));
/*     */     } 
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(@Nullable Object left, @Nullable Object right) throws SpelEvaluationException {
/*  61 */     if (left == null) {
/*  62 */       return (right == null) ? 0 : -1;
/*     */     }
/*  64 */     if (right == null) {
/*  65 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*  69 */     if (left instanceof Number) { Number leftNumber = (Number)left; if (right instanceof Number) { Number rightNumber = (Number)right;
/*  70 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/*  71 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/*  72 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/*  73 */           return leftBigDecimal.compareTo(rightBigDecimal);
/*     */         } 
/*  75 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/*  76 */           return Double.compare(leftNumber.doubleValue(), rightNumber.doubleValue());
/*     */         }
/*  78 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/*  79 */           return Float.compare(leftNumber.floatValue(), rightNumber.floatValue());
/*     */         }
/*  81 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/*  82 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/*  83 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/*  84 */           return leftBigInteger.compareTo(rightBigInteger);
/*     */         } 
/*  86 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/*  87 */           return Long.compare(leftNumber.longValue(), rightNumber.longValue());
/*     */         }
/*  89 */         if (leftNumber instanceof Integer || rightNumber instanceof Integer) {
/*  90 */           return Integer.compare(leftNumber.intValue(), rightNumber.intValue());
/*     */         }
/*  92 */         if (leftNumber instanceof Short || rightNumber instanceof Short) {
/*  93 */           return Short.compare(leftNumber.shortValue(), rightNumber.shortValue());
/*     */         }
/*  95 */         if (leftNumber instanceof Byte || rightNumber instanceof Byte) {
/*  96 */           return Byte.compare(leftNumber.byteValue(), rightNumber.byteValue());
/*     */         }
/*     */ 
/*     */         
/* 100 */         return Double.compare(leftNumber.doubleValue(), rightNumber.doubleValue()); }
/*     */        }
/*     */ 
/*     */     
/*     */     try {
/* 105 */       if (left instanceof Comparable) { Comparable<Object> comparable = (Comparable)left;
/* 106 */         return comparable.compareTo(right); }
/*     */ 
/*     */     
/* 109 */     } catch (ClassCastException ex) {
/* 110 */       throw new SpelEvaluationException(ex, SpelMessage.NOT_COMPARABLE, new Object[] { left.getClass(), right.getClass() });
/*     */     } 
/*     */     
/* 113 */     throw new SpelEvaluationException(SpelMessage.NOT_COMPARABLE, new Object[] { left.getClass(), right.getClass() });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\StandardTypeComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */