/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardTypeLocator
/*     */   implements TypeLocator
/*     */ {
/*     */   @Nullable
/*     */   private final ClassLoader classLoader;
/*  52 */   private final List<String> importPrefixes = new ArrayList<>(1);
/*     */   
/*  54 */   private final Map<String, Class<?>> typeCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardTypeLocator() {
/*  66 */     this(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardTypeLocator(@Nullable ClassLoader classLoader) {
/*  77 */     this.classLoader = classLoader;
/*     */     
/*  79 */     registerImport("java.lang");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerImport(String prefix) {
/*  89 */     this.importPrefixes.add(prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeImport(String prefix) {
/*  97 */     this.importPrefixes.remove(prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getImportPrefixes() {
/* 105 */     return Collections.unmodifiableList(this.importPrefixes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findType(String typeName) throws EvaluationException {
/* 118 */     Class<?> cachedType = this.typeCache.get(typeName);
/* 119 */     if (cachedType != null) {
/* 120 */       return cachedType;
/*     */     }
/* 122 */     Class<?> loadedType = loadType(typeName);
/* 123 */     if (loadedType != null)
/* 124 */     { ClassLoader classLoader = this.classLoader; if (classLoader instanceof SmartClassLoader) { SmartClassLoader scl = (SmartClassLoader)classLoader; if (!scl.isClassReloadable(loadedType))
/* 125 */         { this.typeCache.put(typeName, loadedType);
/*     */           
/* 127 */           return loadedType; }  return loadedType; }
/*     */        }
/* 129 */     else { throw new SpelEvaluationException(SpelMessage.TYPE_NOT_FOUND, new Object[] { typeName }); }
/*     */     
/*     */     this.typeCache.put(typeName, loadedType);
/*     */     return loadedType; } @Nullable
/*     */   private Class<?> loadType(String typeName) {
/*     */     try {
/* 135 */       return ClassUtils.forName(typeName, this.classLoader);
/*     */     }
/* 137 */     catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */       
/* 140 */       for (String prefix : this.importPrefixes) {
/*     */         try {
/* 142 */           String nameToLookup = prefix + "." + prefix;
/* 143 */           return ClassUtils.forName(nameToLookup, this.classLoader);
/*     */         }
/* 145 */         catch (ClassNotFoundException classNotFoundException1) {}
/*     */       } 
/*     */ 
/*     */       
/* 149 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\StandardTypeLocator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */