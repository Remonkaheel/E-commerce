/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.MethodFilter;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveMethodResolver
/*     */   implements MethodResolver
/*     */ {
/*     */   private final boolean useDistance;
/*     */   @Nullable
/*     */   private Map<Class<?>, MethodFilter> filters;
/*     */   
/*     */   public ReflectiveMethodResolver() {
/*  67 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveMethodResolver(boolean useDistance) {
/*  81 */     this.useDistance = useDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerMethodFilter(Class<?> type, @Nullable MethodFilter filter) {
/*  92 */     if (this.filters == null) {
/*  93 */       this.filters = new HashMap<>();
/*     */     }
/*  95 */     if (filter != null) {
/*  96 */       this.filters.put(type, filter);
/*     */     } else {
/*     */       
/*  99 */       this.filters.remove(type);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MethodExecutor resolve(EvaluationContext context, Object targetObject, String name, List<TypeDescriptor> argumentTypes) throws AccessException {
/*     */     try {
/* 121 */       TypeConverter typeConverter = context.getTypeConverter();
/* 122 */       Class<?> clazz = (Class)targetObject, type = (targetObject instanceof Class) ? clazz : targetObject.getClass();
/* 123 */       ArrayList<Method> methods = new ArrayList<>(getMethods(type, targetObject));
/* 124 */       methods.removeIf(method -> !method.getName().equals(name));
/*     */ 
/*     */       
/* 127 */       MethodFilter filter = (this.filters != null) ? this.filters.get(type) : null;
/* 128 */       if (filter != null) {
/* 129 */         List<Method> filtered = filter.filter(methods);
/* 130 */         ArrayList<Method> arrayList = (ArrayList<Method>)filtered; methods = (filtered instanceof ArrayList) ? arrayList : new ArrayList<>(filtered);
/*     */       } 
/*     */ 
/*     */       
/* 134 */       if (methods.size() > 1) {
/* 135 */         methods.sort((m1, m2) -> {
/*     */               int m1pl = m1.getParameterCount();
/*     */               
/*     */               int m2pl = m2.getParameterCount();
/*     */               
/* 140 */               return (m1pl == m2pl) ? ((!m1.isVarArgs() && m2.isVarArgs()) ? -1 : (
/*     */ 
/*     */                 
/* 143 */                 (m1.isVarArgs() && !m2.isVarArgs()) ? 1 : 0)) : Integer.compare(m1pl, m2pl);
/*     */             });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 155 */       for (int i = 0; i < methods.size(); i++) {
/* 156 */         methods.set(i, BridgeMethodResolver.findBridgedMethod(methods.get(i)));
/*     */       }
/*     */ 
/*     */       
/* 160 */       Set<Method> methodsToIterate = new LinkedHashSet<>(methods);
/*     */       
/* 162 */       Method closeMatch = null;
/* 163 */       int closeMatchDistance = Integer.MAX_VALUE;
/* 164 */       Method matchRequiringConversion = null;
/* 165 */       boolean multipleOptions = false;
/*     */       
/* 167 */       for (Method method : methodsToIterate) {
/* 168 */         int paramCount = method.getParameterCount();
/* 169 */         List<TypeDescriptor> paramDescriptors = new ArrayList<>(paramCount);
/* 170 */         for (int j = 0; j < paramCount; j++) {
/* 171 */           paramDescriptors.add(new TypeDescriptor(new MethodParameter(method, j)));
/*     */         }
/* 173 */         ReflectionHelper.ArgumentsMatchKind matchKind = null;
/* 174 */         if (method.isVarArgs() && argumentTypes.size() >= paramCount - 1) {
/*     */           
/* 176 */           matchKind = ReflectionHelper.compareArgumentsVarargs(paramDescriptors, argumentTypes, typeConverter);
/*     */         }
/* 178 */         else if (paramCount == argumentTypes.size()) {
/*     */           
/* 180 */           matchKind = ReflectionHelper.compareArguments(paramDescriptors, argumentTypes, typeConverter);
/*     */         } 
/* 182 */         if (matchKind != null) {
/* 183 */           if (matchKind.isExactMatch()) {
/* 184 */             return new ReflectiveMethodExecutor(method, type);
/*     */           }
/* 186 */           if (matchKind.isCloseMatch()) {
/* 187 */             if (this.useDistance) {
/* 188 */               int matchDistance = ReflectionHelper.getTypeDifferenceWeight(paramDescriptors, argumentTypes);
/* 189 */               if (closeMatch == null || matchDistance < closeMatchDistance) {
/*     */                 
/* 191 */                 closeMatch = method;
/* 192 */                 closeMatchDistance = matchDistance;
/*     */               } 
/*     */               
/*     */               continue;
/*     */             } 
/* 197 */             if (closeMatch == null) {
/* 198 */               closeMatch = method;
/*     */             }
/*     */             continue;
/*     */           } 
/* 202 */           if (matchKind.isMatchRequiringConversion()) {
/* 203 */             if (matchRequiringConversion != null) {
/* 204 */               multipleOptions = true;
/*     */             }
/* 206 */             matchRequiringConversion = method;
/*     */           } 
/*     */         } 
/*     */       } 
/* 210 */       if (closeMatch != null) {
/* 211 */         return new ReflectiveMethodExecutor(closeMatch, type);
/*     */       }
/* 213 */       if (matchRequiringConversion != null) {
/* 214 */         if (multipleOptions) {
/* 215 */           throw new SpelEvaluationException(SpelMessage.MULTIPLE_POSSIBLE_METHODS, new Object[] { name });
/*     */         }
/* 217 */         return new ReflectiveMethodExecutor(matchRequiringConversion, type);
/*     */       } 
/*     */       
/* 220 */       return null;
/*     */     
/*     */     }
/* 223 */     catch (EvaluationException ex) {
/* 224 */       throw new AccessException("Failed to resolve method", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Set<Method> getMethods(Class<?> type, Object targetObject) {
/* 229 */     if (targetObject instanceof Class) {
/* 230 */       Set<Method> set = new LinkedHashSet<>();
/*     */       
/* 232 */       for (Method method : getMethods(type)) {
/* 233 */         if (Modifier.isStatic(method.getModifiers())) {
/* 234 */           set.add(method);
/*     */         }
/*     */       } 
/*     */       
/* 238 */       Collections.addAll(set, getMethods(Class.class));
/* 239 */       return set;
/*     */     } 
/* 241 */     if (Proxy.isProxyClass(type)) {
/* 242 */       Set<Method> set = new LinkedHashSet<>();
/*     */       
/* 244 */       for (Class<?> ifc : type.getInterfaces()) {
/* 245 */         for (Method method : getMethods(ifc)) {
/* 246 */           if (isCandidateForInvocation(method, type)) {
/* 247 */             set.add(method);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 252 */       for (Method method : getMethods(Object.class)) {
/* 253 */         if (isCandidateForInvocation(method, type)) {
/* 254 */           set.add(method);
/*     */         }
/*     */       } 
/* 257 */       return set;
/*     */     } 
/*     */     
/* 260 */     Set<Method> result = new LinkedHashSet<>();
/* 261 */     for (Method method : getMethods(type)) {
/* 262 */       if (isCandidateForInvocation(method, type)) {
/* 263 */         result.add(method);
/*     */       }
/*     */     } 
/* 266 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method[] getMethods(Class<?> type) {
/* 279 */     return type.getMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCandidateForInvocation(Method method, Class<?> targetClass) {
/* 292 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectiveMethodResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */