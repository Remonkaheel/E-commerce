/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompilableIndexAccessor;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveIndexAccessor
/*     */   implements CompilableIndexAccessor
/*     */ {
/*     */   private final Class<?> targetType;
/*     */   private final Class<?> indexType;
/*     */   private final Method readMethod;
/*     */   private final Method readMethodToInvoke;
/*     */   @Nullable
/*     */   private final Method writeMethodToInvoke;
/*     */   
/*     */   public ReflectiveIndexAccessor(Class<?> targetType, Class<?> indexType, String readMethodName) {
/* 132 */     this(targetType, indexType, readMethodName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveIndexAccessor(Class<?> targetType, Class<?> indexType, String readMethodName, @Nullable String writeMethodName) {
/* 151 */     this.targetType = targetType;
/* 152 */     this.indexType = indexType;
/*     */     
/*     */     try {
/* 155 */       this.readMethod = targetType.getMethod(readMethodName, new Class[] { indexType });
/*     */     }
/* 157 */     catch (Exception ex) {
/* 158 */       throw new IllegalArgumentException("Failed to find public read-method '%s(%s)' in class '%s'."
/* 159 */           .formatted(new Object[] { readMethodName, getName(indexType), getName(targetType) }));
/*     */     } 
/*     */     
/* 162 */     this.readMethodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(this.readMethod, targetType);
/* 163 */     ReflectionUtils.makeAccessible(this.readMethodToInvoke);
/*     */     
/* 165 */     if (writeMethodName != null) {
/* 166 */       Method writeMethod; Class<?> indexedValueType = this.readMethod.getReturnType();
/*     */       
/*     */       try {
/* 169 */         writeMethod = targetType.getMethod(writeMethodName, new Class[] { indexType, indexedValueType });
/*     */       }
/* 171 */       catch (Exception ex) {
/* 172 */         throw new IllegalArgumentException("Failed to find public write-method '%s(%s, %s)' in class '%s'."
/* 173 */             .formatted(new Object[] { writeMethodName, getName(indexType), getName(indexedValueType), 
/* 174 */                 getName(targetType) }));
/*     */       } 
/* 176 */       this.writeMethodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(writeMethod, targetType);
/* 177 */       ReflectionUtils.makeAccessible(this.writeMethodToInvoke);
/*     */     } else {
/*     */       
/* 180 */       this.writeMethodToInvoke = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] getSpecificTargetClasses() {
/* 190 */     return new Class[] { this.targetType };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, Object target, Object index) {
/* 202 */     return (ClassUtils.isAssignableValue(this.targetType, target) && 
/* 203 */       ClassUtils.isAssignableValue(this.indexType, index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue read(EvaluationContext context, Object target, Object index) {
/* 212 */     Object value = ReflectionUtils.invokeMethod(this.readMethodToInvoke, target, new Object[] { index });
/* 213 */     return new TypedValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(EvaluationContext context, Object target, Object index) {
/* 222 */     return (this.writeMethodToInvoke != null && canRead(context, target, index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(EvaluationContext context, Object target, Object index, @Nullable Object newValue) {
/* 232 */     Assert.state((this.writeMethodToInvoke != null), "Write-method cannot be null");
/* 233 */     ReflectionUtils.invokeMethod(this.writeMethodToInvoke, target, new Object[] { index, newValue });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 238 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getIndexedValueType() {
/* 246 */     return this.readMethod.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(SpelNode index, MethodVisitor mv, CodeFlow cf) {
/* 252 */     Class<?> publicDeclaringClass = this.readMethodToInvoke.getDeclaringClass();
/* 253 */     Assert.state(Modifier.isPublic(publicDeclaringClass.getModifiers()), () -> "Failed to find public declaring class for read-method: " + String.valueOf(this.readMethod));
/*     */     
/* 255 */     String classDesc = publicDeclaringClass.getName().replace('.', '/');
/*     */ 
/*     */     
/* 258 */     String lastDesc = cf.lastDescriptor();
/* 259 */     if (lastDesc == null || !classDesc.equals(lastDesc.substring(1))) {
/* 260 */       mv.visitTypeInsn(192, classDesc);
/*     */     }
/*     */ 
/*     */     
/* 264 */     cf.generateCodeForArgument(mv, index, this.indexType);
/*     */ 
/*     */     
/* 267 */     String methodName = this.readMethod.getName();
/* 268 */     String methodDescr = CodeFlow.createSignatureDescriptor(this.readMethod);
/* 269 */     boolean isInterface = publicDeclaringClass.isInterface();
/* 270 */     int opcode = isInterface ? 185 : 182;
/* 271 */     mv.visitMethodInsn(opcode, classDesc, methodName, methodDescr, isInterface);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getName(Class<?> clazz) {
/* 276 */     String canonicalName = clazz.getCanonicalName();
/* 277 */     return (canonicalName != null) ? canonicalName : clazz.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectiveIndexAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */