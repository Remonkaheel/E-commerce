/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveMethodExecutor
/*     */   implements MethodExecutor
/*     */ {
/*     */   private final Method originalMethod;
/*     */   private final Method methodToInvoke;
/*     */   @Nullable
/*     */   private final Integer varargsPosition;
/*     */   @Nullable
/*     */   private final Class<?> publicDeclaringClass;
/*     */   private boolean argumentConversionOccurred = false;
/*     */   
/*     */   public ReflectiveMethodExecutor(Method method) {
/*  63 */     this(method, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveMethodExecutor(Method method, @Nullable Class<?> targetClass) {
/*  73 */     this.originalMethod = method;
/*  74 */     this.methodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, targetClass);
/*  75 */     Class<?> declaringClass = this.methodToInvoke.getDeclaringClass();
/*  76 */     this.publicDeclaringClass = Modifier.isPublic(declaringClass.getModifiers()) ? declaringClass : null;
/*  77 */     this.varargsPosition = method.isVarArgs() ? Integer.valueOf(method.getParameterCount() - 1) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Method getMethod() {
/*  85 */     return this.originalMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPublicDeclaringClass() {
/*  98 */     return this.publicDeclaringClass;
/*     */   }
/*     */   
/*     */   public boolean didArgumentConversionOccur() {
/* 102 */     return this.argumentConversionOccurred;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue execute(EvaluationContext context, Object target, Object... arguments) throws AccessException {
/*     */     try {
/* 109 */       this.argumentConversionOccurred = ReflectionHelper.convertArguments(context
/* 110 */           .getTypeConverter(), arguments, this.originalMethod, this.varargsPosition);
/* 111 */       if (this.originalMethod.isVarArgs()) {
/* 112 */         arguments = ReflectionHelper.setupArgumentsForVarargsInvocation(this.originalMethod
/* 113 */             .getParameterTypes(), arguments);
/*     */       }
/* 115 */       ReflectionUtils.makeAccessible(this.methodToInvoke);
/* 116 */       Object value = this.methodToInvoke.invoke(target, arguments);
/* 117 */       return new TypedValue(value, (new TypeDescriptor(new MethodParameter(this.originalMethod, -1))).narrow(value));
/*     */     }
/* 119 */     catch (Exception ex) {
/* 120 */       throw new AccessException("Problem invoking method: " + String.valueOf(this.methodToInvoke), ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectiveMethodExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */