/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.IndexAccessor;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleEvaluationContext
/*     */   implements EvaluationContext
/*     */ {
/*     */   private static final TypeLocator typeNotFoundTypeLocator;
/*     */   private final TypedValue rootObject;
/*     */   private final List<PropertyAccessor> propertyAccessors;
/*     */   private final List<IndexAccessor> indexAccessors;
/*     */   private final List<MethodResolver> methodResolvers;
/*     */   private final TypeConverter typeConverter;
/*     */   
/*     */   static {
/* 103 */     typeNotFoundTypeLocator = (typeName -> {
/*     */         throw new SpelEvaluationException(SpelMessage.TYPE_NOT_FOUND, new Object[] { typeName });
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private final TypeComparator typeComparator = StandardTypeComparator.INSTANCE;
/*     */   
/* 120 */   private final OperatorOverloader operatorOverloader = StandardOperatorOverloader.INSTANCE;
/*     */   
/* 122 */   private final Map<String, Object> variables = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean assignmentEnabled;
/*     */ 
/*     */ 
/*     */   
/*     */   private SimpleEvaluationContext(List<PropertyAccessor> propertyAccessors, List<IndexAccessor> indexAccessors, List<MethodResolver> resolvers, @Nullable TypeConverter converter, @Nullable TypedValue rootObject, boolean assignmentEnabled) {
/* 131 */     this.propertyAccessors = propertyAccessors;
/* 132 */     this.indexAccessors = indexAccessors;
/* 133 */     this.methodResolvers = resolvers;
/* 134 */     this.typeConverter = (converter != null) ? converter : new StandardTypeConverter();
/* 135 */     this.rootObject = (rootObject != null) ? rootObject : TypedValue.NULL;
/* 136 */     this.assignmentEnabled = assignmentEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getRootObject() {
/* 145 */     return this.rootObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors() {
/* 154 */     return this.propertyAccessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IndexAccessor> getIndexAccessors() {
/* 164 */     return this.indexAccessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MethodResolver> getMethodResolvers() {
/* 173 */     return this.methodResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanResolver getBeanResolver() {
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeLocator getTypeLocator() {
/* 193 */     return typeNotFoundTypeLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 204 */     return this.typeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeComparator getTypeComparator() {
/* 212 */     return this.typeComparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OperatorOverloader getOperatorOverloader() {
/* 220 */     return this.operatorOverloader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue assignVariable(String name, Supplier<TypedValue> valueSupplier) {
/* 231 */     throw new SpelEvaluationException(SpelMessage.VARIABLE_ASSIGNMENT_NOT_SUPPORTED, new Object[] { "#" + name });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariable(String name, @Nullable Object value) {
/* 248 */     this.variables.put(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object lookupVariable(String name) {
/* 262 */     return this.variables.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAssignmentEnabled() {
/* 277 */     return this.assignmentEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forPropertyAccessors(PropertyAccessor... accessors) {
/* 296 */     for (PropertyAccessor accessor : accessors) {
/* 297 */       if (accessor.getClass() == ReflectivePropertyAccessor.class) {
/* 298 */         throw new IllegalArgumentException("SimpleEvaluationContext is not designed for use with a plain ReflectivePropertyAccessor. Consider using DataBindingPropertyAccessor or a custom subclass.");
/*     */       }
/*     */     } 
/*     */     
/* 302 */     return new Builder(accessors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forReadOnlyDataBinding() {
/* 316 */     return (new Builder(new PropertyAccessor[] { DataBindingPropertyAccessor.forReadOnlyAccess() })).withAssignmentDisabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forReadWriteDataBinding() {
/* 332 */     return new Builder(new PropertyAccessor[] { DataBindingPropertyAccessor.forReadWriteAccess() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final List<PropertyAccessor> propertyAccessors;
/*     */ 
/*     */     
/* 343 */     private List<IndexAccessor> indexAccessors = Collections.emptyList();
/*     */     
/* 345 */     private List<MethodResolver> resolvers = Collections.emptyList();
/*     */     
/*     */     @Nullable
/*     */     private TypeConverter typeConverter;
/*     */     
/*     */     @Nullable
/*     */     private TypedValue rootObject;
/*     */     
/*     */     private boolean assignmentEnabled = true;
/*     */ 
/*     */     
/*     */     private Builder(PropertyAccessor... accessors) {
/* 357 */       this.propertyAccessors = Arrays.asList(accessors);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withAssignmentDisabled() {
/* 367 */       this.assignmentEnabled = false;
/* 368 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withIndexAccessors(IndexAccessor... indexAccessors) {
/* 377 */       this.indexAccessors = Arrays.asList(indexAccessors);
/* 378 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withMethodResolvers(MethodResolver... resolvers) {
/* 389 */       for (MethodResolver resolver : resolvers) {
/* 390 */         if (resolver.getClass() == ReflectiveMethodResolver.class) {
/* 391 */           throw new IllegalArgumentException("SimpleEvaluationContext is not designed for use with a plain ReflectiveMethodResolver. Consider using DataBindingMethodResolver or a custom subclass.");
/*     */         }
/*     */       } 
/*     */       
/* 395 */       this.resolvers = Arrays.asList(resolvers);
/* 396 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withInstanceMethods() {
/* 408 */       this.resolvers = Collections.singletonList(DataBindingMethodResolver.forInstanceMethodInvocation());
/* 409 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withConversionService(ConversionService conversionService) {
/* 420 */       this.typeConverter = new StandardTypeConverter(conversionService);
/* 421 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withTypeConverter(TypeConverter converter) {
/* 432 */       this.typeConverter = converter;
/* 433 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withRootObject(Object rootObject) {
/* 443 */       this.rootObject = new TypedValue(rootObject);
/* 444 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withTypedRootObject(Object rootObject, TypeDescriptor typeDescriptor) {
/* 454 */       this.rootObject = new TypedValue(rootObject, typeDescriptor);
/* 455 */       return this;
/*     */     }
/*     */     
/*     */     public SimpleEvaluationContext build() {
/* 459 */       return new SimpleEvaluationContext(this.propertyAccessors, this.indexAccessors, this.resolvers, this.typeConverter, this.rootObject, this.assignmentEnabled);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\SimpleEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */