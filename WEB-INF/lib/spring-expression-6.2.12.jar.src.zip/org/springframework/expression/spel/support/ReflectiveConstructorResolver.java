/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.ConstructorExecutor;
/*     */ import org.springframework.expression.ConstructorResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveConstructorResolver
/*     */   implements ConstructorResolver
/*     */ {
/*     */   @Nullable
/*     */   public ConstructorExecutor resolve(EvaluationContext context, String typeName, List<TypeDescriptor> argumentTypes) throws AccessException {
/*     */     try {
/*  64 */       TypeConverter typeConverter = context.getTypeConverter();
/*  65 */       Class<?> type = context.getTypeLocator().findType(typeName);
/*  66 */       Constructor[] arrayOfConstructor = (Constructor[])type.getConstructors();
/*     */       
/*  68 */       Arrays.sort(arrayOfConstructor, Comparator.comparingInt(Constructor::getParameterCount));
/*     */       
/*  70 */       Constructor<?> closeMatch = null;
/*  71 */       Constructor<?> matchRequiringConversion = null;
/*     */       
/*  73 */       for (Constructor<?> ctor : arrayOfConstructor) {
/*  74 */         int paramCount = ctor.getParameterCount();
/*  75 */         List<TypeDescriptor> paramDescriptors = new ArrayList<>(paramCount);
/*  76 */         for (int i = 0; i < paramCount; i++) {
/*  77 */           paramDescriptors.add(new TypeDescriptor(new MethodParameter(ctor, i)));
/*     */         }
/*  79 */         ReflectionHelper.ArgumentsMatchKind matchKind = null;
/*  80 */         if (ctor.isVarArgs() && argumentTypes.size() >= paramCount - 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  87 */           matchKind = ReflectionHelper.compareArgumentsVarargs(paramDescriptors, argumentTypes, typeConverter);
/*     */         }
/*  89 */         else if (paramCount == argumentTypes.size()) {
/*     */           
/*  91 */           matchKind = ReflectionHelper.compareArguments(paramDescriptors, argumentTypes, typeConverter);
/*     */         } 
/*  93 */         if (matchKind != null) {
/*  94 */           if (matchKind.isExactMatch()) {
/*  95 */             return new ReflectiveConstructorExecutor(ctor);
/*     */           }
/*  97 */           if (matchKind.isCloseMatch()) {
/*  98 */             closeMatch = ctor;
/*     */           }
/* 100 */           else if (matchKind.isMatchRequiringConversion()) {
/* 101 */             matchRequiringConversion = ctor;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 106 */       if (closeMatch != null) {
/* 107 */         return new ReflectiveConstructorExecutor(closeMatch);
/*     */       }
/* 109 */       if (matchRequiringConversion != null) {
/* 110 */         return new ReflectiveConstructorExecutor(matchRequiringConversion);
/*     */       }
/*     */       
/* 113 */       return null;
/*     */     
/*     */     }
/* 116 */     catch (EvaluationException ex) {
/* 117 */       throw new AccessException("Failed to resolve constructor", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\ReflectiveConstructorResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */