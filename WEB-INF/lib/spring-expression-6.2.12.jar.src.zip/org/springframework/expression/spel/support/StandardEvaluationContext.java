/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.ConstructorResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.IndexAccessor;
/*     */ import org.springframework.expression.MethodFilter;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardEvaluationContext
/*     */   implements EvaluationContext
/*     */ {
/*     */   private TypedValue rootObject;
/*     */   @Nullable
/*     */   private volatile List<PropertyAccessor> propertyAccessors;
/*     */   @Nullable
/*     */   private volatile List<IndexAccessor> indexAccessors;
/*     */   @Nullable
/*     */   private volatile List<ConstructorResolver> constructorResolvers;
/*     */   @Nullable
/*     */   private volatile List<MethodResolver> methodResolvers;
/*     */   @Nullable
/*     */   private volatile ReflectiveMethodResolver reflectiveMethodResolver;
/*     */   @Nullable
/*     */   private BeanResolver beanResolver;
/*     */   @Nullable
/*     */   private TypeLocator typeLocator;
/*     */   @Nullable
/*     */   private TypeConverter typeConverter;
/* 108 */   private TypeComparator typeComparator = StandardTypeComparator.INSTANCE;
/*     */   
/* 110 */   private OperatorOverloader operatorOverloader = StandardOperatorOverloader.INSTANCE;
/*     */   
/* 112 */   private final Map<String, Object> variables = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardEvaluationContext() {
/* 119 */     this.rootObject = TypedValue.NULL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardEvaluationContext(@Nullable Object rootObject) {
/* 128 */     this.rootObject = new TypedValue(rootObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRootObject(@Nullable Object rootObject, TypeDescriptor typeDescriptor) {
/* 139 */     this.rootObject = new TypedValue(rootObject, typeDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRootObject(@Nullable Object rootObject) {
/* 148 */     this.rootObject = (rootObject != null) ? new TypedValue(rootObject) : TypedValue.NULL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getRootObject() {
/* 157 */     return this.rootObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyAccessors(List<PropertyAccessor> propertyAccessors) {
/* 165 */     this.propertyAccessors = propertyAccessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors() {
/* 173 */     return initPropertyAccessors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyAccessor(PropertyAccessor propertyAccessor) {
/* 184 */     addBeforeDefault(initPropertyAccessors(), propertyAccessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removePropertyAccessor(PropertyAccessor propertyAccessor) {
/* 197 */     return initPropertyAccessors().remove(propertyAccessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndexAccessors(List<IndexAccessor> indexAccessors) {
/* 209 */     this.indexAccessors = indexAccessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IndexAccessor> getIndexAccessors() {
/* 221 */     return initIndexAccessors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIndexAccessor(IndexAccessor indexAccessor) {
/* 233 */     initIndexAccessors().add(indexAccessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeIndexAccessor(IndexAccessor indexAccessor) {
/* 247 */     return initIndexAccessors().remove(indexAccessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConstructorResolvers(List<ConstructorResolver> constructorResolvers) {
/* 255 */     this.constructorResolvers = constructorResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ConstructorResolver> getConstructorResolvers() {
/* 263 */     return initConstructorResolvers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConstructorResolver(ConstructorResolver constructorResolver) {
/* 274 */     addBeforeDefault(initConstructorResolvers(), constructorResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeConstructorResolver(ConstructorResolver constructorResolver) {
/* 287 */     return initConstructorResolvers().remove(constructorResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethodResolvers(List<MethodResolver> methodResolvers) {
/* 295 */     this.methodResolvers = methodResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MethodResolver> getMethodResolvers() {
/* 303 */     return initMethodResolvers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMethodResolver(MethodResolver methodResolver) {
/* 314 */     addBeforeDefault(initMethodResolvers(), methodResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeMethodResolver(MethodResolver methodResolver) {
/* 327 */     return initMethodResolvers().remove(methodResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanResolver(@Nullable BeanResolver beanResolver) {
/* 334 */     this.beanResolver = beanResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanResolver getBeanResolver() {
/* 343 */     return this.beanResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeLocator(TypeLocator typeLocator) {
/* 359 */     Assert.notNull(typeLocator, "TypeLocator must not be null");
/* 360 */     this.typeLocator = typeLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeLocator getTypeLocator() {
/* 371 */     if (this.typeLocator == null) {
/* 372 */       this.typeLocator = new StandardTypeLocator();
/*     */     }
/* 374 */     return this.typeLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeConverter(TypeConverter typeConverter) {
/* 381 */     Assert.notNull(typeConverter, "TypeConverter must not be null");
/* 382 */     this.typeConverter = typeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 390 */     if (this.typeConverter == null) {
/* 391 */       this.typeConverter = new StandardTypeConverter();
/*     */     }
/* 393 */     return this.typeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeComparator(TypeComparator typeComparator) {
/* 400 */     Assert.notNull(typeComparator, "TypeComparator must not be null");
/* 401 */     this.typeComparator = typeComparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeComparator getTypeComparator() {
/* 409 */     return this.typeComparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperatorOverloader(OperatorOverloader operatorOverloader) {
/* 416 */     Assert.notNull(operatorOverloader, "OperatorOverloader must not be null");
/* 417 */     this.operatorOverloader = operatorOverloader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OperatorOverloader getOperatorOverloader() {
/* 425 */     return this.operatorOverloader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariable(@Nullable String name, @Nullable Object value) {
/* 452 */     if (name != null) {
/* 453 */       if (value != null) {
/* 454 */         this.variables.put(name, value);
/*     */       } else {
/*     */         
/* 457 */         this.variables.remove(name);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariables(Map<String, Object> variables) {
/* 472 */     variables.forEach(this::setVariable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerFunction(String name, Method method) {
/* 485 */     this.variables.put(name, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerFunction(String name, MethodHandle methodHandle) {
/* 499 */     this.variables.put(name, methodHandle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object lookupVariable(String name) {
/* 513 */     return this.variables.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerMethodFilter(Class<?> type, MethodFilter filter) throws IllegalStateException {
/* 526 */     initMethodResolvers();
/* 527 */     ReflectiveMethodResolver resolver = this.reflectiveMethodResolver;
/* 528 */     if (resolver == null) {
/* 529 */       throw new IllegalStateException("Method filter cannot be set as the reflective method resolver is not in use");
/*     */     }
/*     */     
/* 532 */     resolver.registerMethodFilter(type, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyDelegatesTo(StandardEvaluationContext evaluationContext) {
/* 546 */     evaluationContext.setConstructorResolvers(new ArrayList<>(getConstructorResolvers()));
/* 547 */     evaluationContext.setMethodResolvers(new ArrayList<>(getMethodResolvers()));
/* 548 */     evaluationContext.setPropertyAccessors(new ArrayList<>(getPropertyAccessors()));
/* 549 */     evaluationContext.setIndexAccessors(new ArrayList<>(getIndexAccessors()));
/* 550 */     evaluationContext.setTypeLocator(getTypeLocator());
/* 551 */     evaluationContext.setTypeConverter(getTypeConverter());
/*     */     
/* 553 */     evaluationContext.beanResolver = this.beanResolver;
/* 554 */     evaluationContext.operatorOverloader = this.operatorOverloader;
/* 555 */     evaluationContext.reflectiveMethodResolver = this.reflectiveMethodResolver;
/* 556 */     evaluationContext.typeComparator = this.typeComparator;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<PropertyAccessor> initPropertyAccessors() {
/* 561 */     List<PropertyAccessor> accessors = this.propertyAccessors;
/* 562 */     if (accessors == null) {
/* 563 */       accessors = new ArrayList<>(5);
/* 564 */       accessors.add(new ReflectivePropertyAccessor());
/* 565 */       this.propertyAccessors = accessors;
/*     */     } 
/* 567 */     return accessors;
/*     */   }
/*     */   
/*     */   private List<IndexAccessor> initIndexAccessors() {
/* 571 */     List<IndexAccessor> accessors = this.indexAccessors;
/* 572 */     if (accessors == null) {
/* 573 */       accessors = new ArrayList<>(5);
/* 574 */       this.indexAccessors = accessors;
/*     */     } 
/* 576 */     return accessors;
/*     */   }
/*     */   
/*     */   private List<ConstructorResolver> initConstructorResolvers() {
/* 580 */     List<ConstructorResolver> resolvers = this.constructorResolvers;
/* 581 */     if (resolvers == null) {
/* 582 */       resolvers = new ArrayList<>(1);
/* 583 */       resolvers.add(new ReflectiveConstructorResolver());
/* 584 */       this.constructorResolvers = resolvers;
/*     */     } 
/* 586 */     return resolvers;
/*     */   }
/*     */   
/*     */   private List<MethodResolver> initMethodResolvers() {
/* 590 */     List<MethodResolver> resolvers = this.methodResolvers;
/* 591 */     if (resolvers == null) {
/* 592 */       resolvers = new ArrayList<>(1);
/* 593 */       this.reflectiveMethodResolver = new ReflectiveMethodResolver();
/* 594 */       resolvers.add(this.reflectiveMethodResolver);
/* 595 */       this.methodResolvers = resolvers;
/*     */     } 
/* 597 */     return resolvers;
/*     */   }
/*     */   
/*     */   private static <T> void addBeforeDefault(List<T> list, T element) {
/* 601 */     list.add(list.size() - 1, element);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\support\StandardEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */