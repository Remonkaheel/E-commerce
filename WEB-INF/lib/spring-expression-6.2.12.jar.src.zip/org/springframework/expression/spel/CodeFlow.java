/*      */ package org.springframework.expression.spel;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Deque;
/*      */ import java.util.List;
/*      */ import org.springframework.asm.ClassWriter;
/*      */ import org.springframework.asm.MethodVisitor;
/*      */ import org.springframework.asm.Opcodes;
/*      */ import org.springframework.lang.Contract;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CodeFlow
/*      */   implements Opcodes
/*      */ {
/*      */   private final String className;
/*      */   private final ClassWriter classWriter;
/*      */   private final Deque<List<String>> compilationScopes;
/*      */   @Nullable
/*      */   private List<FieldAdder> fieldAdders;
/*      */   @Nullable
/*      */   private List<ClinitAdder> clinitAdders;
/*   88 */   private int nextFieldId = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   94 */   private int nextFreeVariableId = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CodeFlow(String className, ClassWriter classWriter) {
/*  103 */     this.className = className;
/*  104 */     this.classWriter = classWriter;
/*  105 */     this.compilationScopes = new ArrayDeque<>();
/*  106 */     this.compilationScopes.add(new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadTarget(MethodVisitor mv) {
/*  116 */     mv.visitVarInsn(25, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadEvaluationContext(MethodVisitor mv) {
/*  126 */     mv.visitVarInsn(25, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pushDescriptor(@Nullable String descriptor) {
/*  134 */     if (descriptor != null) {
/*  135 */       ((List<String>)this.compilationScopes.element()).add(descriptor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterCompilationScope() {
/*  145 */     this.compilationScopes.push(new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitCompilationScope() {
/*  154 */     this.compilationScopes.pop();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String lastDescriptor() {
/*  162 */     return (String)CollectionUtils.lastElement(this.compilationScopes.peek());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unboxBooleanIfNecessary(MethodVisitor mv) {
/*  171 */     if ("Ljava/lang/Boolean".equals(lastDescriptor())) {
/*  172 */       mv.visitMethodInsn(182, "java/lang/Boolean", "booleanValue", "()Z", false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finish() {
/*  182 */     if (this.fieldAdders != null) {
/*  183 */       for (FieldAdder fieldAdder : this.fieldAdders) {
/*  184 */         fieldAdder.generateField(this.classWriter, this);
/*      */       }
/*      */     }
/*  187 */     if (this.clinitAdders != null) {
/*  188 */       MethodVisitor mv = this.classWriter.visitMethod(9, "<clinit>", "()V", null, null);
/*  189 */       mv.visitCode();
/*  190 */       this.nextFreeVariableId = 0;
/*  191 */       for (ClinitAdder clinitAdder : this.clinitAdders) {
/*  192 */         clinitAdder.generateCode(mv, this);
/*      */       }
/*  194 */       mv.visitInsn(177);
/*  195 */       mv.visitMaxs(0, 0);
/*  196 */       mv.visitEnd();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerNewField(FieldAdder fieldAdder) {
/*  206 */     if (this.fieldAdders == null) {
/*  207 */       this.fieldAdders = new ArrayList<>();
/*      */     }
/*  209 */     this.fieldAdders.add(fieldAdder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerNewClinit(ClinitAdder clinitAdder) {
/*  218 */     if (this.clinitAdders == null) {
/*  219 */       this.clinitAdders = new ArrayList<>();
/*      */     }
/*  221 */     this.clinitAdders.add(clinitAdder);
/*      */   }
/*      */   
/*      */   public int nextFieldId() {
/*  225 */     return this.nextFieldId++;
/*      */   }
/*      */   
/*      */   public int nextFreeVariableId() {
/*  229 */     return this.nextFreeVariableId++;
/*      */   }
/*      */   
/*      */   public String getClassName() {
/*  233 */     return this.className;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCodeForArgument(MethodVisitor methodVisitor, SpelNode argument, Class<?> requiredType) {
/*  259 */     generateCodeForArgument(methodVisitor, argument, toDescriptor(requiredType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCodeForArgument(MethodVisitor methodVisitor, SpelNode argument, String requiredTypeDesc) {
/*  283 */     enterCompilationScope();
/*  284 */     argument.generateCode(methodVisitor, this);
/*  285 */     String lastDesc = lastDescriptor();
/*  286 */     Assert.state((lastDesc != null), "No last descriptor");
/*  287 */     boolean primitiveOnStack = isPrimitive(lastDesc);
/*      */     
/*  289 */     if (primitiveOnStack && requiredTypeDesc.charAt(0) == 'L') {
/*  290 */       insertBoxIfNecessary(methodVisitor, lastDesc.charAt(0));
/*      */     
/*      */     }
/*  293 */     else if (requiredTypeDesc.length() == 1 && !primitiveOnStack) {
/*  294 */       insertUnboxInsns(methodVisitor, requiredTypeDesc.charAt(0), lastDesc);
/*      */     
/*      */     }
/*  297 */     else if (!requiredTypeDesc.equals(lastDesc)) {
/*      */       
/*  299 */       insertCheckCast(methodVisitor, requiredTypeDesc);
/*      */     } 
/*  301 */     exitCompilationScope();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertUnboxInsns(MethodVisitor mv, char ch, @Nullable String stackDescriptor) {
/*  313 */     if (stackDescriptor == null) {
/*      */       return;
/*      */     }
/*  316 */     switch (ch) {
/*      */       case 'Z':
/*  318 */         if (!stackDescriptor.equals("Ljava/lang/Boolean")) {
/*  319 */           mv.visitTypeInsn(192, "java/lang/Boolean");
/*      */         }
/*  321 */         mv.visitMethodInsn(182, "java/lang/Boolean", "booleanValue", "()Z", false);
/*      */         return;
/*      */       case 'B':
/*  324 */         if (!stackDescriptor.equals("Ljava/lang/Byte")) {
/*  325 */           mv.visitTypeInsn(192, "java/lang/Byte");
/*      */         }
/*  327 */         mv.visitMethodInsn(182, "java/lang/Byte", "byteValue", "()B", false);
/*      */         return;
/*      */       case 'C':
/*  330 */         if (!stackDescriptor.equals("Ljava/lang/Character")) {
/*  331 */           mv.visitTypeInsn(192, "java/lang/Character");
/*      */         }
/*  333 */         mv.visitMethodInsn(182, "java/lang/Character", "charValue", "()C", false);
/*      */         return;
/*      */       case 'D':
/*  336 */         if (!stackDescriptor.equals("Ljava/lang/Double")) {
/*  337 */           mv.visitTypeInsn(192, "java/lang/Double");
/*      */         }
/*  339 */         mv.visitMethodInsn(182, "java/lang/Double", "doubleValue", "()D", false);
/*      */         return;
/*      */       case 'F':
/*  342 */         if (!stackDescriptor.equals("Ljava/lang/Float")) {
/*  343 */           mv.visitTypeInsn(192, "java/lang/Float");
/*      */         }
/*  345 */         mv.visitMethodInsn(182, "java/lang/Float", "floatValue", "()F", false);
/*      */         return;
/*      */       case 'I':
/*  348 */         if (!stackDescriptor.equals("Ljava/lang/Integer")) {
/*  349 */           mv.visitTypeInsn(192, "java/lang/Integer");
/*      */         }
/*  351 */         mv.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I", false);
/*      */         return;
/*      */       case 'J':
/*  354 */         if (!stackDescriptor.equals("Ljava/lang/Long")) {
/*  355 */           mv.visitTypeInsn(192, "java/lang/Long");
/*      */         }
/*  357 */         mv.visitMethodInsn(182, "java/lang/Long", "longValue", "()J", false);
/*      */         return;
/*      */       case 'S':
/*  360 */         if (!stackDescriptor.equals("Ljava/lang/Short")) {
/*  361 */           mv.visitTypeInsn(192, "java/lang/Short");
/*      */         }
/*  363 */         mv.visitMethodInsn(182, "java/lang/Short", "shortValue", "()S", false);
/*      */         return;
/*      */     } 
/*  366 */     throw new IllegalArgumentException("Unboxing should not be attempted for descriptor '" + ch + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertUnboxNumberInsns(MethodVisitor mv, char targetDescriptor, @Nullable String stackDescriptor) {
/*  379 */     if (stackDescriptor == null) {
/*      */       return;
/*      */     }
/*      */     
/*  383 */     switch (targetDescriptor) {
/*      */       case 'D':
/*  385 */         if (stackDescriptor.equals("Ljava/lang/Object")) {
/*  386 */           mv.visitTypeInsn(192, "java/lang/Number");
/*      */         }
/*  388 */         mv.visitMethodInsn(182, "java/lang/Number", "doubleValue", "()D", false);
/*      */         return;
/*      */       case 'F':
/*  391 */         if (stackDescriptor.equals("Ljava/lang/Object")) {
/*  392 */           mv.visitTypeInsn(192, "java/lang/Number");
/*      */         }
/*  394 */         mv.visitMethodInsn(182, "java/lang/Number", "floatValue", "()F", false);
/*      */         return;
/*      */       case 'J':
/*  397 */         if (stackDescriptor.equals("Ljava/lang/Object")) {
/*  398 */           mv.visitTypeInsn(192, "java/lang/Number");
/*      */         }
/*  400 */         mv.visitMethodInsn(182, "java/lang/Number", "longValue", "()J", false);
/*      */         return;
/*      */       case 'I':
/*  403 */         if (stackDescriptor.equals("Ljava/lang/Object")) {
/*  404 */           mv.visitTypeInsn(192, "java/lang/Number");
/*      */         }
/*  406 */         mv.visitMethodInsn(182, "java/lang/Number", "intValue", "()I", false);
/*      */         return;
/*      */     } 
/*      */     
/*  410 */     throw new IllegalArgumentException("Unboxing should not be attempted for descriptor '" + targetDescriptor + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertAnyNecessaryTypeConversionBytecodes(MethodVisitor mv, char targetDescriptor, String stackDescriptor) {
/*  422 */     if (!isPrimitive(stackDescriptor)) {
/*      */       return;
/*      */     }
/*  425 */     char stackTop = stackDescriptor.charAt(0);
/*  426 */     switch (stackTop) { case 'B': case 'C': case 'I':
/*      */       case 'S':
/*  428 */         switch (targetDescriptor) { case 'D':
/*  429 */             mv.visitInsn(135); break;
/*  430 */           case 'F': mv.visitInsn(134); break;
/*  431 */           case 'J': mv.visitInsn(133); break;
/*      */           case 'I':
/*      */             break; }
/*  434 */          throw new IllegalStateException("Cannot get from " + stackTop + " to " + targetDescriptor);
/*      */ 
/*      */       
/*      */       case 'J':
/*  438 */         switch (targetDescriptor) { case 'D':
/*  439 */             mv.visitInsn(138); break;
/*  440 */           case 'F': mv.visitInsn(137); break;
/*      */           case 'J': break;
/*  442 */           case 'I': mv.visitInsn(136); break; }
/*      */         
/*  444 */         throw new IllegalStateException("Cannot get from " + stackTop + " to " + targetDescriptor);
/*      */ 
/*      */       
/*      */       case 'F':
/*  448 */         switch (targetDescriptor) { case 'D':
/*  449 */             mv.visitInsn(141); break;
/*      */           case 'F': break;
/*  451 */           case 'J': mv.visitInsn(140); break;
/*  452 */           case 'I': mv.visitInsn(139); break; }
/*      */         
/*  454 */         throw new IllegalStateException("Cannot get from " + stackTop + " to " + targetDescriptor);
/*      */ 
/*      */       
/*      */       case 'D':
/*  458 */         switch (targetDescriptor) { case 'D': break;
/*      */           case 'F':
/*  460 */             mv.visitInsn(144); break;
/*  461 */           case 'J': mv.visitInsn(143); break;
/*  462 */           case 'I': mv.visitInsn(142); break; }
/*      */         
/*  464 */         throw new IllegalStateException("Cannot get from " + stackDescriptor + " to " + targetDescriptor); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createSignatureDescriptor(Method method) {
/*  480 */     Class<?>[] params = method.getParameterTypes();
/*  481 */     StringBuilder sb = new StringBuilder();
/*  482 */     sb.append('(');
/*  483 */     for (Class<?> param : params) {
/*  484 */       sb.append(toJvmDescriptor(param));
/*      */     }
/*  486 */     sb.append(')');
/*  487 */     sb.append(toJvmDescriptor(method.getReturnType()));
/*  488 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createSignatureDescriptor(Constructor<?> ctor) {
/*  501 */     Class<?>[] params = ctor.getParameterTypes();
/*  502 */     StringBuilder sb = new StringBuilder();
/*  503 */     sb.append('(');
/*  504 */     for (Class<?> param : params) {
/*  505 */       sb.append(toJvmDescriptor(param));
/*      */     }
/*  507 */     sb.append(")V");
/*  508 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toJvmDescriptor(Class<?> clazz) {
/*  520 */     StringBuilder sb = new StringBuilder();
/*  521 */     if (clazz.isArray()) {
/*  522 */       while (clazz.isArray()) {
/*  523 */         sb.append('[');
/*  524 */         clazz = clazz.componentType();
/*      */       } 
/*      */     }
/*  527 */     if (clazz.isPrimitive()) {
/*  528 */       if (clazz == boolean.class) {
/*  529 */         sb.append('Z');
/*      */       }
/*  531 */       else if (clazz == byte.class) {
/*  532 */         sb.append('B');
/*      */       }
/*  534 */       else if (clazz == char.class) {
/*  535 */         sb.append('C');
/*      */       }
/*  537 */       else if (clazz == double.class) {
/*  538 */         sb.append('D');
/*      */       }
/*  540 */       else if (clazz == float.class) {
/*  541 */         sb.append('F');
/*      */       }
/*  543 */       else if (clazz == int.class) {
/*  544 */         sb.append('I');
/*      */       }
/*  546 */       else if (clazz == long.class) {
/*  547 */         sb.append('J');
/*      */       }
/*  549 */       else if (clazz == short.class) {
/*  550 */         sb.append('S');
/*      */       }
/*  552 */       else if (clazz == void.class) {
/*  553 */         sb.append('V');
/*      */       } 
/*      */     } else {
/*      */       
/*  557 */       sb.append('L');
/*  558 */       sb.append(clazz.getName().replace('.', '/'));
/*  559 */       sb.append(';');
/*      */     } 
/*  561 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toDescriptorFromObject(@Nullable Object value) {
/*  571 */     if (value == null) {
/*  572 */       return "Ljava/lang/Object";
/*      */     }
/*      */     
/*  575 */     return toDescriptor(value.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Contract("null -> false")
/*      */   public static boolean isBooleanCompatible(@Nullable String descriptor) {
/*  586 */     return (descriptor != null && (descriptor.equals("Z") || descriptor.equals("Ljava/lang/Boolean")));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Contract("null -> false")
/*      */   public static boolean isPrimitive(@Nullable String descriptor) {
/*  596 */     return (descriptor != null && descriptor.length() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Contract("null -> false")
/*      */   public static boolean isPrimitiveArray(@Nullable String descriptor) {
/*  606 */     if (descriptor == null) {
/*  607 */       return false;
/*      */     }
/*  609 */     boolean primitive = true;
/*  610 */     for (int i = 0, max = descriptor.length(); i < max; ) {
/*  611 */       char ch = descriptor.charAt(i);
/*  612 */       if (ch == '[') {
/*      */         i++; continue;
/*      */       } 
/*  615 */       primitive = (ch != 'L');
/*      */     } 
/*      */     
/*  618 */     return primitive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean areBoxingCompatible(String desc1, String desc2) {
/*  627 */     if (desc1.equals(desc2)) {
/*  628 */       return true;
/*      */     }
/*  630 */     if (desc1.length() == 1) {
/*  631 */       return checkPairs(desc1, desc2);
/*      */     }
/*  633 */     if (desc2.length() == 1) {
/*  634 */       return checkPairs(desc2, desc1);
/*      */     }
/*  636 */     return false;
/*      */   }
/*      */   
/*      */   private static boolean checkPairs(String desc1, String desc2) {
/*  640 */     switch (desc1) { case "Z": case "D": case "F": case "I": case "J":  }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Contract("null -> false")
/*      */   public static boolean isPrimitiveOrUnboxableSupportedNumberOrBoolean(@Nullable String descriptor) {
/*  659 */     if (descriptor == null) {
/*  660 */       return false;
/*      */     }
/*  662 */     if (isPrimitiveOrUnboxableSupportedNumber(descriptor)) {
/*  663 */       return true;
/*      */     }
/*  665 */     return ("Z".equals(descriptor) || descriptor.equals("Ljava/lang/Boolean"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Contract("null -> false")
/*      */   public static boolean isPrimitiveOrUnboxableSupportedNumber(@Nullable String descriptor) {
/*  677 */     if (descriptor == null) {
/*  678 */       return false;
/*      */     }
/*  680 */     if (descriptor.length() == 1) {
/*  681 */       return "DFIJ".contains(descriptor);
/*      */     }
/*  683 */     if (descriptor.startsWith("Ljava/lang/")) {
/*  684 */       String name = descriptor.substring("Ljava/lang/".length());
/*  685 */       return (name.equals("Double") || name.equals("Float") || name.equals("Integer") || name.equals("Long"));
/*      */     } 
/*  687 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIntegerForNumericOp(Number number) {
/*  697 */     return (number instanceof Integer || number instanceof Short || number instanceof Byte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char toPrimitiveTargetDesc(String descriptor) {
/*  706 */     if (descriptor.length() == 1) {
/*  707 */       return descriptor.charAt(0);
/*      */     }
/*  709 */     switch (descriptor) { case "Ljava/lang/Double": 
/*      */       case "Ljava/lang/Float": 
/*      */       case "Ljava/lang/Integer": 
/*      */       case "Ljava/lang/Long": 
/*      */       case "Ljava/lang/Boolean": 
/*      */       case "Ljava/lang/Character": 
/*      */       case "Ljava/lang/Byte":
/*      */       
/*      */       case "Ljava/lang/Short":
/*  718 */        }  throw new IllegalStateException("No primitive for '" + descriptor + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertCheckCast(MethodVisitor mv, @Nullable String descriptor) {
/*  728 */     if (descriptor != null && descriptor.length() != 1) {
/*  729 */       if (descriptor.charAt(0) == '[') {
/*  730 */         if (isPrimitiveArray(descriptor)) {
/*  731 */           mv.visitTypeInsn(192, descriptor);
/*      */         } else {
/*      */           
/*  734 */           mv.visitTypeInsn(192, descriptor + ";");
/*      */         }
/*      */       
/*      */       }
/*  738 */       else if (!descriptor.equals("Ljava/lang/Object")) {
/*      */         
/*  740 */         mv.visitTypeInsn(192, descriptor.substring(1));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertBoxIfNecessary(MethodVisitor mv, @Nullable String descriptor) {
/*  753 */     if (descriptor != null && descriptor.length() == 1) {
/*  754 */       insertBoxIfNecessary(mv, descriptor.charAt(0));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertBoxIfNecessary(MethodVisitor mv, char ch) {
/*  765 */     switch (ch)
/*      */     { case 'Z':
/*  767 */         mv.visitMethodInsn(184, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", false);
/*      */       case 'B':
/*  769 */         mv.visitMethodInsn(184, "java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;", false);
/*      */       case 'C':
/*  771 */         mv.visitMethodInsn(184, "java/lang/Character", "valueOf", "(C)Ljava/lang/Character;", false);
/*      */       case 'D':
/*  773 */         mv.visitMethodInsn(184, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;", false);
/*      */       case 'F':
/*  775 */         mv.visitMethodInsn(184, "java/lang/Float", "valueOf", "(F)Ljava/lang/Float;", false);
/*      */       case 'I':
/*  777 */         mv.visitMethodInsn(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;", false);
/*      */       case 'J':
/*  779 */         mv.visitMethodInsn(184, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;", false);
/*      */       case 'S':
/*  781 */         mv.visitMethodInsn(184, "java/lang/Short", "valueOf", "(S)Ljava/lang/Short;", false);
/*      */       case 'L':
/*      */       case 'V':
/*      */       case '[':
/*  785 */         return; }  throw new IllegalArgumentException("Boxing should not be attempted for descriptor '" + ch + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toDescriptor(Class<?> type) {
/*  796 */     String name = type.getName();
/*  797 */     if (type.isPrimitive()) {
/*  798 */       switch (name.length()) {
/*      */         case 3:
/*  800 */           return "I";
/*      */         case 4:
/*  802 */           switch (name) { case "byte": 
/*      */             case "char": 
/*      */             case "long":
/*      */             
/*      */             case "void":
/*  807 */              }  throw new IllegalArgumentException("Unknown primitive type: " + name);
/*      */         
/*      */         case 5:
/*  810 */           if (name.equals("float")) {
/*  811 */             return "F";
/*      */           }
/*  813 */           if (name.equals("short")) {
/*  814 */             return "S";
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  843 */           return "";case 6: if (name.equals("double")) return "D";  return "";case 7: if (name.equals("boolean")) return "Z";  return "";
/*      */       } 
/*      */       throw new IllegalArgumentException("Unknown primitive type: " + name);
/*      */     } 
/*      */     if (name.charAt(0) != '[')
/*      */       return "L" + type.getName().replace('.', '/'); 
/*      */     if (name.endsWith(";"))
/*      */       return name.substring(0, name.length() - 1).replace('.', '/'); 
/*      */     return name;
/*      */   } public static String[] toParamDescriptors(Method method) {
/*  853 */     return toDescriptors(method.getParameterTypes());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] toParamDescriptors(Constructor<?> ctor) {
/*  863 */     return toDescriptors(ctor.getParameterTypes());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] toDescriptors(Class<?>[] types) {
/*  872 */     int typesCount = types.length;
/*  873 */     String[] descriptors = new String[typesCount];
/*  874 */     for (int p = 0; p < typesCount; p++) {
/*  875 */       descriptors[p] = toDescriptor(types[p]);
/*      */     }
/*  877 */     return descriptors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertOptimalLoad(MethodVisitor mv, int value) {
/*  886 */     if (value < 6) {
/*  887 */       mv.visitInsn(3 + value);
/*      */     }
/*  889 */     else if (value < 127) {
/*  890 */       mv.visitIntInsn(16, value);
/*      */     }
/*  892 */     else if (value < 32767) {
/*  893 */       mv.visitIntInsn(17, value);
/*      */     } else {
/*      */       
/*  896 */       mv.visitLdcInsn(Integer.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertArrayStore(MethodVisitor mv, String arrayComponentType) {
/*  908 */     if (arrayComponentType.length() == 1) {
/*  909 */       char componentType = arrayComponentType.charAt(0);
/*  910 */       switch (componentType) { case 'B': case 'Z':
/*  911 */           mv.visitInsn(84); return;
/*  912 */         case 'I': mv.visitInsn(79); return;
/*  913 */         case 'J': mv.visitInsn(80); return;
/*  914 */         case 'F': mv.visitInsn(81); return;
/*  915 */         case 'D': mv.visitInsn(82); return;
/*  916 */         case 'C': mv.visitInsn(85); return;
/*  917 */         case 'S': mv.visitInsn(86); return; }
/*  918 */        throw new IllegalArgumentException("Unexpected array component type " + componentType);
/*      */     } 
/*      */ 
/*      */     
/*  922 */     mv.visitInsn(83);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int arrayCodeFor(String arrayType) {
/*  932 */     switch (arrayType.charAt(0)) { case 'I': 
/*      */       case 'J': 
/*      */       case 'F': 
/*      */       case 'D': 
/*      */       case 'B': 
/*      */       case 'C': 
/*      */       case 'S':
/*      */       
/*      */       case 'Z':
/*  941 */        }  throw new IllegalArgumentException("Unexpected array type " + arrayType.charAt(0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isReferenceTypeArray(String arrayType) {
/*  949 */     int length = arrayType.length();
/*  950 */     for (int i = 0; i < length; ) {
/*  951 */       char ch = arrayType.charAt(i);
/*  952 */       if (ch == '[') {
/*      */         i++; continue;
/*      */       } 
/*  955 */       return (ch == 'L');
/*      */     } 
/*  957 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertNewArrayCode(MethodVisitor mv, int size, String arrayType) {
/*  969 */     insertOptimalLoad(mv, size);
/*  970 */     if (arrayType.length() == 1) {
/*  971 */       mv.visitIntInsn(188, arrayCodeFor(arrayType));
/*      */     
/*      */     }
/*  974 */     else if (arrayType.charAt(0) == '[') {
/*      */ 
/*      */       
/*  977 */       if (isReferenceTypeArray(arrayType)) {
/*  978 */         mv.visitTypeInsn(189, arrayType + ";");
/*      */       } else {
/*      */         
/*  981 */         mv.visitTypeInsn(189, arrayType);
/*      */       } 
/*      */     } else {
/*      */       
/*  985 */       mv.visitTypeInsn(189, arrayType.substring(1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void insertNumericUnboxOrPrimitiveTypeCoercion(MethodVisitor mv, @Nullable String stackDescriptor, char targetDescriptor) {
/* 1002 */     if (!isPrimitive(stackDescriptor)) {
/* 1003 */       insertUnboxNumberInsns(mv, targetDescriptor, stackDescriptor);
/*      */     } else {
/*      */       
/* 1006 */       insertAnyNecessaryTypeConversionBytecodes(mv, targetDescriptor, stackDescriptor);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static String toBoxedDescriptor(String primitiveDescriptor) {
/* 1011 */     switch (primitiveDescriptor.charAt(0)) { case 'I': 
/*      */       case 'J': 
/*      */       case 'F': 
/*      */       case 'D': 
/*      */       case 'B': 
/*      */       case 'C': 
/*      */       case 'S':
/*      */       
/*      */       case 'Z':
/* 1020 */        }  throw new IllegalArgumentException("Unexpected non primitive descriptor " + primitiveDescriptor);
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface FieldAdder {
/*      */     void generateField(ClassWriter param1ClassWriter, CodeFlow param1CodeFlow);
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface ClinitAdder {
/*      */     void generateCode(MethodVisitor param1MethodVisitor, CodeFlow param1CodeFlow);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\CodeFlow.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */