/*      */ package org.springframework.expression.spel.ast;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.function.Supplier;
/*      */ import org.springframework.asm.Label;
/*      */ import org.springframework.asm.MethodVisitor;
/*      */ import org.springframework.core.convert.TypeDescriptor;
/*      */ import org.springframework.expression.AccessException;
/*      */ import org.springframework.expression.EvaluationContext;
/*      */ import org.springframework.expression.EvaluationException;
/*      */ import org.springframework.expression.IndexAccessor;
/*      */ import org.springframework.expression.PropertyAccessor;
/*      */ import org.springframework.expression.TypeConverter;
/*      */ import org.springframework.expression.TypedValue;
/*      */ import org.springframework.expression.spel.CodeFlow;
/*      */ import org.springframework.expression.spel.CompilableIndexAccessor;
/*      */ import org.springframework.expression.spel.CompilablePropertyAccessor;
/*      */ import org.springframework.expression.spel.ExpressionState;
/*      */ import org.springframework.expression.spel.SpelEvaluationException;
/*      */ import org.springframework.expression.spel.SpelMessage;
/*      */ import org.springframework.expression.spel.support.ReflectivePropertyAccessor;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Indexer
/*      */   extends SpelNodeImpl
/*      */ {
/*      */   private final boolean nullSafe;
/*      */   @Nullable
/*      */   private IndexedType indexedType;
/*      */   @Nullable
/*      */   private volatile String originalPrimitiveExitTypeDescriptor;
/*      */   @Nullable
/*      */   private volatile String arrayTypeDescriptor;
/*      */   @Nullable
/*      */   private volatile CachedPropertyState cachedPropertyReadState;
/*      */   @Nullable
/*      */   private volatile CachedPropertyState cachedPropertyWriteState;
/*      */   @Nullable
/*      */   private volatile CachedIndexState cachedIndexReadState;
/*      */   @Nullable
/*      */   private volatile CachedIndexState cachedIndexWriteState;
/*      */   
/*      */   private enum IndexedType
/*      */   {
/*   82 */     ARRAY, LIST, MAP, STRING, OBJECT, CUSTOM;
/*      */   }
/*      */   
/*      */   private enum AccessMode {
/*   86 */     READ(true, false),
/*      */     
/*   88 */     WRITE(false, true),
/*      */     
/*   90 */     READ_WRITE(true, true);
/*      */     
/*      */     private final boolean supportsReads;
/*      */     private final boolean supportsWrites;
/*      */     
/*      */     AccessMode(boolean supportsReads, boolean supportsWrites) {
/*   96 */       this.supportsReads = supportsReads;
/*   97 */       this.supportsWrites = supportsWrites;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.2", forRemoval = true)
/*      */   public Indexer(int startPos, int endPos, SpelNodeImpl indexExpression) {
/*  134 */     this(false, startPos, endPos, indexExpression);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Indexer(boolean nullSafe, int startPos, int endPos, SpelNodeImpl indexExpression) {
/*  143 */     super(startPos, endPos, new SpelNodeImpl[] { indexExpression });
/*  144 */     this.nullSafe = nullSafe;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isNullSafe() {
/*  154 */     return this.nullSafe;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  159 */     return getValueRef(state, AccessMode.READ).getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypedValue setValueInternal(ExpressionState state, Supplier<TypedValue> valueSupplier) throws EvaluationException {
/*  166 */     TypedValue typedValue = valueSupplier.get();
/*  167 */     getValueRef(state, AccessMode.WRITE).setValue(typedValue.getValue());
/*  168 */     return typedValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWritable(ExpressionState expressionState) throws SpelEvaluationException {
/*  173 */     return getValueRef(expressionState, AccessMode.WRITE).isWritable();
/*      */   }
/*      */ 
/*      */   
/*      */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/*  178 */     return getValueRef(state, AccessMode.READ_WRITE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ValueRef getValueRef(ExpressionState state, AccessMode accessMode) throws EvaluationException {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: invokevirtual getActiveContextObject : ()Lorg/springframework/expression/TypedValue;
/*      */     //   4: astore_3
/*      */     //   5: aload_3
/*      */     //   6: invokevirtual getValue : ()Ljava/lang/Object;
/*      */     //   9: astore #4
/*      */     //   11: aload #4
/*      */     //   13: ifnonnull -> 46
/*      */     //   16: aload_0
/*      */     //   17: getfield nullSafe : Z
/*      */     //   20: ifeq -> 27
/*      */     //   23: getstatic org/springframework/expression/spel/ast/ValueRef$NullValueRef.INSTANCE : Lorg/springframework/expression/spel/ast/ValueRef$NullValueRef;
/*      */     //   26: areturn
/*      */     //   27: new org/springframework/expression/spel/SpelEvaluationException
/*      */     //   30: dup
/*      */     //   31: aload_0
/*      */     //   32: invokevirtual getStartPosition : ()I
/*      */     //   35: getstatic org/springframework/expression/spel/SpelMessage.CANNOT_INDEX_INTO_NULL_VALUE : Lorg/springframework/expression/spel/SpelMessage;
/*      */     //   38: iconst_0
/*      */     //   39: anewarray java/lang/Object
/*      */     //   42: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*      */     //   45: athrow
/*      */     //   46: aload_3
/*      */     //   47: invokevirtual getTypeDescriptor : ()Lorg/springframework/core/convert/TypeDescriptor;
/*      */     //   50: astore #5
/*      */     //   52: aload #4
/*      */     //   54: instanceof java/util/Map
/*      */     //   57: ifeq -> 104
/*      */     //   60: aload_0
/*      */     //   61: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*      */     //   64: iconst_0
/*      */     //   65: aaload
/*      */     //   66: astore #9
/*      */     //   68: aload #9
/*      */     //   70: instanceof org/springframework/expression/spel/ast/PropertyOrFieldReference
/*      */     //   73: ifeq -> 104
/*      */     //   76: aload #9
/*      */     //   78: checkcast org/springframework/expression/spel/ast/PropertyOrFieldReference
/*      */     //   81: astore #8
/*      */     //   83: aload #8
/*      */     //   85: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   88: astore #7
/*      */     //   90: new org/springframework/expression/TypedValue
/*      */     //   93: dup
/*      */     //   94: aload #7
/*      */     //   96: invokespecial <init> : (Ljava/lang/Object;)V
/*      */     //   99: astore #6
/*      */     //   101: goto -> 162
/*      */     //   104: aload_1
/*      */     //   105: aload_1
/*      */     //   106: invokevirtual getRootContextObject : ()Lorg/springframework/expression/TypedValue;
/*      */     //   109: invokevirtual pushActiveContextObject : (Lorg/springframework/expression/TypedValue;)V
/*      */     //   112: aload_0
/*      */     //   113: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*      */     //   116: iconst_0
/*      */     //   117: aaload
/*      */     //   118: aload_1
/*      */     //   119: invokevirtual getValueInternal : (Lorg/springframework/expression/spel/ExpressionState;)Lorg/springframework/expression/TypedValue;
/*      */     //   122: astore #6
/*      */     //   124: aload #6
/*      */     //   126: invokevirtual getValue : ()Ljava/lang/Object;
/*      */     //   129: astore #7
/*      */     //   131: aload #7
/*      */     //   133: ifnull -> 140
/*      */     //   136: iconst_1
/*      */     //   137: goto -> 141
/*      */     //   140: iconst_0
/*      */     //   141: ldc 'No index'
/*      */     //   143: invokestatic state : (ZLjava/lang/String;)V
/*      */     //   146: aload_1
/*      */     //   147: invokevirtual popActiveContextObject : ()V
/*      */     //   150: goto -> 162
/*      */     //   153: astore #10
/*      */     //   155: aload_1
/*      */     //   156: invokevirtual popActiveContextObject : ()V
/*      */     //   159: aload #10
/*      */     //   161: athrow
/*      */     //   162: aload #5
/*      */     //   164: ifnull -> 171
/*      */     //   167: iconst_1
/*      */     //   168: goto -> 172
/*      */     //   171: iconst_0
/*      */     //   172: ldc 'No type descriptor'
/*      */     //   174: invokestatic state : (ZLjava/lang/String;)V
/*      */     //   177: aload #4
/*      */     //   179: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   182: invokevirtual isArray : ()Z
/*      */     //   185: ifeq -> 222
/*      */     //   188: aload_1
/*      */     //   189: aload #7
/*      */     //   191: invokestatic convertIndexToInt : (Lorg/springframework/expression/spel/ExpressionState;Ljava/lang/Object;)I
/*      */     //   194: istore #8
/*      */     //   196: aload_0
/*      */     //   197: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.ARRAY : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   200: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   203: new org/springframework/expression/spel/ast/Indexer$ArrayIndexingValueRef
/*      */     //   206: dup
/*      */     //   207: aload_0
/*      */     //   208: aload_1
/*      */     //   209: invokevirtual getTypeConverter : ()Lorg/springframework/expression/TypeConverter;
/*      */     //   212: aload #4
/*      */     //   214: iload #8
/*      */     //   216: aload #5
/*      */     //   218: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Lorg/springframework/expression/TypeConverter;Ljava/lang/Object;ILorg/springframework/core/convert/TypeDescriptor;)V
/*      */     //   221: areturn
/*      */     //   222: aload #4
/*      */     //   224: instanceof java/util/List
/*      */     //   227: ifeq -> 285
/*      */     //   230: aload #4
/*      */     //   232: checkcast java/util/List
/*      */     //   235: astore #8
/*      */     //   237: aload_1
/*      */     //   238: aload #7
/*      */     //   240: invokestatic convertIndexToInt : (Lorg/springframework/expression/spel/ExpressionState;Ljava/lang/Object;)I
/*      */     //   243: istore #9
/*      */     //   245: aload_0
/*      */     //   246: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.LIST : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   249: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   252: new org/springframework/expression/spel/ast/Indexer$CollectionIndexingValueRef
/*      */     //   255: dup
/*      */     //   256: aload_0
/*      */     //   257: aload #8
/*      */     //   259: iload #9
/*      */     //   261: aload #5
/*      */     //   263: aload_1
/*      */     //   264: invokevirtual getTypeConverter : ()Lorg/springframework/expression/TypeConverter;
/*      */     //   267: aload_1
/*      */     //   268: invokevirtual getConfiguration : ()Lorg/springframework/expression/spel/SpelParserConfiguration;
/*      */     //   271: invokevirtual isAutoGrowCollections : ()Z
/*      */     //   274: aload_1
/*      */     //   275: invokevirtual getConfiguration : ()Lorg/springframework/expression/spel/SpelParserConfiguration;
/*      */     //   278: invokevirtual getMaximumAutoGrowSize : ()I
/*      */     //   281: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Ljava/util/Collection;ILorg/springframework/core/convert/TypeDescriptor;Lorg/springframework/expression/TypeConverter;ZI)V
/*      */     //   284: areturn
/*      */     //   285: aload #4
/*      */     //   287: instanceof java/util/Map
/*      */     //   290: ifeq -> 352
/*      */     //   293: aload #4
/*      */     //   295: checkcast java/util/Map
/*      */     //   298: astore #8
/*      */     //   300: aload #7
/*      */     //   302: astore #9
/*      */     //   304: aload #5
/*      */     //   306: invokevirtual getMapKeyTypeDescriptor : ()Lorg/springframework/core/convert/TypeDescriptor;
/*      */     //   309: astore #10
/*      */     //   311: aload #10
/*      */     //   313: ifnull -> 326
/*      */     //   316: aload_1
/*      */     //   317: aload #9
/*      */     //   319: aload #10
/*      */     //   321: invokevirtual convertValue : (Ljava/lang/Object;Lorg/springframework/core/convert/TypeDescriptor;)Ljava/lang/Object;
/*      */     //   324: astore #9
/*      */     //   326: aload_0
/*      */     //   327: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.MAP : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   330: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   333: new org/springframework/expression/spel/ast/Indexer$MapIndexingValueRef
/*      */     //   336: dup
/*      */     //   337: aload_0
/*      */     //   338: aload_1
/*      */     //   339: invokevirtual getTypeConverter : ()Lorg/springframework/expression/TypeConverter;
/*      */     //   342: aload #8
/*      */     //   344: aload #9
/*      */     //   346: aload #5
/*      */     //   348: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Lorg/springframework/expression/TypeConverter;Ljava/util/Map;Ljava/lang/Object;Lorg/springframework/core/convert/TypeDescriptor;)V
/*      */     //   351: areturn
/*      */     //   352: aload #4
/*      */     //   354: instanceof java/lang/String
/*      */     //   357: ifeq -> 397
/*      */     //   360: aload #4
/*      */     //   362: checkcast java/lang/String
/*      */     //   365: astore #8
/*      */     //   367: aload_1
/*      */     //   368: aload #7
/*      */     //   370: invokestatic convertIndexToInt : (Lorg/springframework/expression/spel/ExpressionState;Ljava/lang/Object;)I
/*      */     //   373: istore #9
/*      */     //   375: aload_0
/*      */     //   376: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.STRING : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   379: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   382: new org/springframework/expression/spel/ast/Indexer$StringIndexingValueRef
/*      */     //   385: dup
/*      */     //   386: aload_0
/*      */     //   387: aload #8
/*      */     //   389: iload #9
/*      */     //   391: aload #5
/*      */     //   393: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Ljava/lang/String;ILorg/springframework/core/convert/TypeDescriptor;)V
/*      */     //   396: areturn
/*      */     //   397: aload_1
/*      */     //   398: invokevirtual getEvaluationContext : ()Lorg/springframework/expression/EvaluationContext;
/*      */     //   401: astore #8
/*      */     //   403: aload #4
/*      */     //   405: aload #8
/*      */     //   407: invokeinterface getIndexAccessors : ()Ljava/util/List;
/*      */     //   412: invokestatic getAccessorsToTry : (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List;
/*      */     //   415: astore #9
/*      */     //   417: aload_2
/*      */     //   418: getfield supportsReads : Z
/*      */     //   421: ifeq -> 540
/*      */     //   424: aload #9
/*      */     //   426: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   431: astore #10
/*      */     //   433: aload #10
/*      */     //   435: invokeinterface hasNext : ()Z
/*      */     //   440: ifeq -> 498
/*      */     //   443: aload #10
/*      */     //   445: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   450: checkcast org/springframework/expression/IndexAccessor
/*      */     //   453: astore #11
/*      */     //   455: aload #11
/*      */     //   457: aload #8
/*      */     //   459: aload #4
/*      */     //   461: aload #7
/*      */     //   463: invokeinterface canRead : (Lorg/springframework/expression/EvaluationContext;Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   468: ifeq -> 495
/*      */     //   471: aload_0
/*      */     //   472: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.CUSTOM : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   475: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   478: new org/springframework/expression/spel/ast/Indexer$IndexAccessorValueRef
/*      */     //   481: dup
/*      */     //   482: aload_0
/*      */     //   483: aload #4
/*      */     //   485: aload #7
/*      */     //   487: aload #8
/*      */     //   489: aload #5
/*      */     //   491: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Ljava/lang/Object;Ljava/lang/Object;Lorg/springframework/expression/EvaluationContext;Lorg/springframework/core/convert/TypeDescriptor;)V
/*      */     //   494: areturn
/*      */     //   495: goto -> 433
/*      */     //   498: goto -> 540
/*      */     //   501: astore #10
/*      */     //   503: new org/springframework/expression/spel/SpelEvaluationException
/*      */     //   506: dup
/*      */     //   507: aload_0
/*      */     //   508: invokevirtual getStartPosition : ()I
/*      */     //   511: aload #10
/*      */     //   513: getstatic org/springframework/expression/spel/SpelMessage.EXCEPTION_DURING_INDEX_READ : Lorg/springframework/expression/spel/SpelMessage;
/*      */     //   516: iconst_2
/*      */     //   517: anewarray java/lang/Object
/*      */     //   520: dup
/*      */     //   521: iconst_0
/*      */     //   522: aload #7
/*      */     //   524: aastore
/*      */     //   525: dup
/*      */     //   526: iconst_1
/*      */     //   527: aload #4
/*      */     //   529: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   532: invokevirtual getTypeName : ()Ljava/lang/String;
/*      */     //   535: aastore
/*      */     //   536: invokespecial <init> : (ILjava/lang/Throwable;Lorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*      */     //   539: athrow
/*      */     //   540: aload_2
/*      */     //   541: getfield supportsWrites : Z
/*      */     //   544: ifeq -> 663
/*      */     //   547: aload #9
/*      */     //   549: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   554: astore #10
/*      */     //   556: aload #10
/*      */     //   558: invokeinterface hasNext : ()Z
/*      */     //   563: ifeq -> 621
/*      */     //   566: aload #10
/*      */     //   568: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   573: checkcast org/springframework/expression/IndexAccessor
/*      */     //   576: astore #11
/*      */     //   578: aload #11
/*      */     //   580: aload #8
/*      */     //   582: aload #4
/*      */     //   584: aload #7
/*      */     //   586: invokeinterface canWrite : (Lorg/springframework/expression/EvaluationContext;Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   591: ifeq -> 618
/*      */     //   594: aload_0
/*      */     //   595: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.CUSTOM : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   598: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   601: new org/springframework/expression/spel/ast/Indexer$IndexAccessorValueRef
/*      */     //   604: dup
/*      */     //   605: aload_0
/*      */     //   606: aload #4
/*      */     //   608: aload #7
/*      */     //   610: aload #8
/*      */     //   612: aload #5
/*      */     //   614: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Ljava/lang/Object;Ljava/lang/Object;Lorg/springframework/expression/EvaluationContext;Lorg/springframework/core/convert/TypeDescriptor;)V
/*      */     //   617: areturn
/*      */     //   618: goto -> 556
/*      */     //   621: goto -> 663
/*      */     //   624: astore #10
/*      */     //   626: new org/springframework/expression/spel/SpelEvaluationException
/*      */     //   629: dup
/*      */     //   630: aload_0
/*      */     //   631: invokevirtual getStartPosition : ()I
/*      */     //   634: aload #10
/*      */     //   636: getstatic org/springframework/expression/spel/SpelMessage.EXCEPTION_DURING_INDEX_WRITE : Lorg/springframework/expression/spel/SpelMessage;
/*      */     //   639: iconst_2
/*      */     //   640: anewarray java/lang/Object
/*      */     //   643: dup
/*      */     //   644: iconst_0
/*      */     //   645: aload #7
/*      */     //   647: aastore
/*      */     //   648: dup
/*      */     //   649: iconst_1
/*      */     //   650: aload #4
/*      */     //   652: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   655: invokevirtual getTypeName : ()Ljava/lang/String;
/*      */     //   658: aastore
/*      */     //   659: invokespecial <init> : (ILjava/lang/Throwable;Lorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*      */     //   662: athrow
/*      */     //   663: aload #4
/*      */     //   665: instanceof java/util/Collection
/*      */     //   668: ifeq -> 719
/*      */     //   671: aload #4
/*      */     //   673: checkcast java/util/Collection
/*      */     //   676: astore #10
/*      */     //   678: aload_1
/*      */     //   679: aload #7
/*      */     //   681: invokestatic convertIndexToInt : (Lorg/springframework/expression/spel/ExpressionState;Ljava/lang/Object;)I
/*      */     //   684: istore #11
/*      */     //   686: new org/springframework/expression/spel/ast/Indexer$CollectionIndexingValueRef
/*      */     //   689: dup
/*      */     //   690: aload_0
/*      */     //   691: aload #10
/*      */     //   693: iload #11
/*      */     //   695: aload #5
/*      */     //   697: aload_1
/*      */     //   698: invokevirtual getTypeConverter : ()Lorg/springframework/expression/TypeConverter;
/*      */     //   701: aload_1
/*      */     //   702: invokevirtual getConfiguration : ()Lorg/springframework/expression/spel/SpelParserConfiguration;
/*      */     //   705: invokevirtual isAutoGrowCollections : ()Z
/*      */     //   708: aload_1
/*      */     //   709: invokevirtual getConfiguration : ()Lorg/springframework/expression/spel/SpelParserConfiguration;
/*      */     //   712: invokevirtual getMaximumAutoGrowSize : ()I
/*      */     //   715: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Ljava/util/Collection;ILorg/springframework/core/convert/TypeDescriptor;Lorg/springframework/expression/TypeConverter;ZI)V
/*      */     //   718: areturn
/*      */     //   719: aload #6
/*      */     //   721: invokevirtual getTypeDescriptor : ()Lorg/springframework/core/convert/TypeDescriptor;
/*      */     //   724: astore #10
/*      */     //   726: aload #10
/*      */     //   728: ifnull -> 770
/*      */     //   731: ldc java/lang/String
/*      */     //   733: aload #10
/*      */     //   735: invokevirtual getType : ()Ljava/lang/Class;
/*      */     //   738: if_acmpne -> 770
/*      */     //   741: aload_0
/*      */     //   742: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.OBJECT : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   745: putfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   748: new org/springframework/expression/spel/ast/Indexer$PropertyAccessorValueRef
/*      */     //   751: dup
/*      */     //   752: aload_0
/*      */     //   753: aload #4
/*      */     //   755: aload #7
/*      */     //   757: checkcast java/lang/String
/*      */     //   760: aload_1
/*      */     //   761: invokevirtual getEvaluationContext : ()Lorg/springframework/expression/EvaluationContext;
/*      */     //   764: aload #5
/*      */     //   766: invokespecial <init> : (Lorg/springframework/expression/spel/ast/Indexer;Ljava/lang/Object;Ljava/lang/String;Lorg/springframework/expression/EvaluationContext;Lorg/springframework/core/convert/TypeDescriptor;)V
/*      */     //   769: areturn
/*      */     //   770: new org/springframework/expression/spel/SpelEvaluationException
/*      */     //   773: dup
/*      */     //   774: aload_0
/*      */     //   775: invokevirtual getStartPosition : ()I
/*      */     //   778: getstatic org/springframework/expression/spel/SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE : Lorg/springframework/expression/spel/SpelMessage;
/*      */     //   781: iconst_1
/*      */     //   782: anewarray java/lang/Object
/*      */     //   785: dup
/*      */     //   786: iconst_0
/*      */     //   787: aload #5
/*      */     //   789: aastore
/*      */     //   790: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*      */     //   793: athrow
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #182	-> 0
/*      */     //   #183	-> 5
/*      */     //   #185	-> 11
/*      */     //   #186	-> 16
/*      */     //   #187	-> 23
/*      */     //   #190	-> 27
/*      */     //   #193	-> 46
/*      */     //   #198	-> 52
/*      */     //   #199	-> 83
/*      */     //   #200	-> 90
/*      */     //   #206	-> 104
/*      */     //   #207	-> 112
/*      */     //   #208	-> 124
/*      */     //   #209	-> 131
/*      */     //   #212	-> 146
/*      */     //   #213	-> 150
/*      */     //   #212	-> 153
/*      */     //   #213	-> 159
/*      */     //   #217	-> 162
/*      */     //   #220	-> 177
/*      */     //   #221	-> 188
/*      */     //   #222	-> 196
/*      */     //   #223	-> 203
/*      */     //   #227	-> 222
/*      */     //   #228	-> 237
/*      */     //   #229	-> 245
/*      */     //   #230	-> 252
/*      */     //   #231	-> 264
/*      */     //   #232	-> 275
/*      */     //   #230	-> 284
/*      */     //   #236	-> 285
/*      */     //   #237	-> 300
/*      */     //   #238	-> 304
/*      */     //   #239	-> 311
/*      */     //   #240	-> 316
/*      */     //   #242	-> 326
/*      */     //   #243	-> 333
/*      */     //   #247	-> 352
/*      */     //   #248	-> 367
/*      */     //   #249	-> 375
/*      */     //   #250	-> 382
/*      */     //   #254	-> 397
/*      */     //   #255	-> 403
/*      */     //   #256	-> 407
/*      */     //   #257	-> 417
/*      */     //   #259	-> 424
/*      */     //   #260	-> 455
/*      */     //   #261	-> 471
/*      */     //   #262	-> 478
/*      */     //   #264	-> 495
/*      */     //   #270	-> 498
/*      */     //   #266	-> 501
/*      */     //   #267	-> 503
/*      */     //   #268	-> 508
/*      */     //   #269	-> 529
/*      */     //   #272	-> 540
/*      */     //   #274	-> 547
/*      */     //   #275	-> 578
/*      */     //   #276	-> 594
/*      */     //   #277	-> 601
/*      */     //   #279	-> 618
/*      */     //   #285	-> 621
/*      */     //   #281	-> 624
/*      */     //   #282	-> 626
/*      */     //   #283	-> 631
/*      */     //   #284	-> 652
/*      */     //   #289	-> 663
/*      */     //   #290	-> 678
/*      */     //   #291	-> 686
/*      */     //   #292	-> 698
/*      */     //   #293	-> 709
/*      */     //   #291	-> 718
/*      */     //   #297	-> 719
/*      */     //   #298	-> 726
/*      */     //   #299	-> 741
/*      */     //   #300	-> 748
/*      */     //   #301	-> 761
/*      */     //   #300	-> 769
/*      */     //   #304	-> 770
/*      */     //   #305	-> 775
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   101	3	6	indexValue	Lorg/springframework/expression/TypedValue;
/*      */     //   90	14	7	index	Ljava/lang/Object;
/*      */     //   83	21	8	reference	Lorg/springframework/expression/spel/ast/PropertyOrFieldReference;
/*      */     //   124	29	6	indexValue	Lorg/springframework/expression/TypedValue;
/*      */     //   131	22	7	index	Ljava/lang/Object;
/*      */     //   196	26	8	intIndex	I
/*      */     //   245	40	9	intIndex	I
/*      */     //   237	48	8	list	Ljava/util/List;
/*      */     //   304	48	9	key	Ljava/lang/Object;
/*      */     //   311	41	10	mapKeyTypeDescriptor	Lorg/springframework/core/convert/TypeDescriptor;
/*      */     //   300	52	8	map	Ljava/util/Map;
/*      */     //   375	22	9	intIndex	I
/*      */     //   367	30	8	string	Ljava/lang/String;
/*      */     //   455	40	11	indexAccessor	Lorg/springframework/expression/IndexAccessor;
/*      */     //   503	37	10	ex	Ljava/lang/Exception;
/*      */     //   578	40	11	indexAccessor	Lorg/springframework/expression/IndexAccessor;
/*      */     //   626	37	10	ex	Ljava/lang/Exception;
/*      */     //   686	33	11	intIndex	I
/*      */     //   678	41	10	collection	Ljava/util/Collection;
/*      */     //   0	794	0	this	Lorg/springframework/expression/spel/ast/Indexer;
/*      */     //   0	794	1	state	Lorg/springframework/expression/spel/ExpressionState;
/*      */     //   0	794	2	accessMode	Lorg/springframework/expression/spel/ast/Indexer$AccessMode;
/*      */     //   5	789	3	context	Lorg/springframework/expression/TypedValue;
/*      */     //   11	783	4	target	Ljava/lang/Object;
/*      */     //   52	742	5	targetDescriptor	Lorg/springframework/core/convert/TypeDescriptor;
/*      */     //   162	632	6	indexValue	Lorg/springframework/expression/TypedValue;
/*      */     //   162	632	7	index	Ljava/lang/Object;
/*      */     //   403	391	8	evalContext	Lorg/springframework/expression/EvaluationContext;
/*      */     //   417	377	9	accessorsToTry	Ljava/util/List;
/*      */     //   726	68	10	valueType	Lorg/springframework/core/convert/TypeDescriptor;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   237	48	8	list	Ljava/util/List<*>;
/*      */     //   300	52	8	map	Ljava/util/Map<**>;
/*      */     //   678	41	10	collection	Ljava/util/Collection<*>;
/*      */     //   417	377	9	accessorsToTry	Ljava/util/List<Lorg/springframework/expression/IndexAccessor;>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   104	146	153	finally
/*      */     //   153	155	153	finally
/*      */     //   424	494	501	java/lang/Exception
/*      */     //   495	498	501	java/lang/Exception
/*      */     //   547	617	624	java/lang/Exception
/*      */     //   618	621	624	java/lang/Exception
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCompilable() {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield exitTypeDescriptor : Ljava/lang/String;
/*      */     //   4: ifnonnull -> 9
/*      */     //   7: iconst_0
/*      */     //   8: ireturn
/*      */     //   9: aload_0
/*      */     //   10: getfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   13: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.ARRAY : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   16: if_acmpne -> 32
/*      */     //   19: aload_0
/*      */     //   20: getfield arrayTypeDescriptor : Ljava/lang/String;
/*      */     //   23: ifnull -> 30
/*      */     //   26: iconst_1
/*      */     //   27: goto -> 31
/*      */     //   30: iconst_0
/*      */     //   31: ireturn
/*      */     //   32: aload_0
/*      */     //   33: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*      */     //   36: iconst_0
/*      */     //   37: aaload
/*      */     //   38: astore_1
/*      */     //   39: aload_0
/*      */     //   40: getfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   43: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.LIST : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   46: if_acmpne -> 54
/*      */     //   49: aload_1
/*      */     //   50: invokevirtual isCompilable : ()Z
/*      */     //   53: ireturn
/*      */     //   54: aload_0
/*      */     //   55: getfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   58: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.MAP : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   61: if_acmpne -> 84
/*      */     //   64: aload_1
/*      */     //   65: instanceof org/springframework/expression/spel/ast/PropertyOrFieldReference
/*      */     //   68: ifne -> 78
/*      */     //   71: aload_1
/*      */     //   72: invokevirtual isCompilable : ()Z
/*      */     //   75: ifeq -> 82
/*      */     //   78: iconst_1
/*      */     //   79: goto -> 83
/*      */     //   82: iconst_0
/*      */     //   83: ireturn
/*      */     //   84: aload_0
/*      */     //   85: getfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   88: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.OBJECT : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   91: if_acmpne -> 145
/*      */     //   94: aload_0
/*      */     //   95: getfield cachedPropertyReadState : Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;
/*      */     //   98: astore_2
/*      */     //   99: aload_1
/*      */     //   100: instanceof org/springframework/expression/spel/ast/StringLiteral
/*      */     //   103: ifeq -> 143
/*      */     //   106: aload_2
/*      */     //   107: ifnull -> 143
/*      */     //   110: aload_2
/*      */     //   111: getfield accessor : Lorg/springframework/expression/PropertyAccessor;
/*      */     //   114: astore #4
/*      */     //   116: aload #4
/*      */     //   118: instanceof org/springframework/expression/spel/CompilablePropertyAccessor
/*      */     //   121: ifeq -> 143
/*      */     //   124: aload #4
/*      */     //   126: checkcast org/springframework/expression/spel/CompilablePropertyAccessor
/*      */     //   129: astore_3
/*      */     //   130: aload_3
/*      */     //   131: invokeinterface isCompilable : ()Z
/*      */     //   136: ifeq -> 143
/*      */     //   139: iconst_1
/*      */     //   140: goto -> 144
/*      */     //   143: iconst_0
/*      */     //   144: ireturn
/*      */     //   145: aload_0
/*      */     //   146: getfield indexedType : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   149: getstatic org/springframework/expression/spel/ast/Indexer$IndexedType.CUSTOM : Lorg/springframework/expression/spel/ast/Indexer$IndexedType;
/*      */     //   152: if_acmpne -> 206
/*      */     //   155: aload_0
/*      */     //   156: getfield cachedIndexReadState : Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;
/*      */     //   159: astore_2
/*      */     //   160: aload_2
/*      */     //   161: ifnull -> 204
/*      */     //   164: aload_2
/*      */     //   165: getfield accessor : Lorg/springframework/expression/IndexAccessor;
/*      */     //   168: astore #4
/*      */     //   170: aload #4
/*      */     //   172: instanceof org/springframework/expression/spel/CompilableIndexAccessor
/*      */     //   175: ifeq -> 204
/*      */     //   178: aload #4
/*      */     //   180: checkcast org/springframework/expression/spel/CompilableIndexAccessor
/*      */     //   183: astore_3
/*      */     //   184: aload_3
/*      */     //   185: invokeinterface isCompilable : ()Z
/*      */     //   190: ifeq -> 204
/*      */     //   193: aload_1
/*      */     //   194: invokevirtual isCompilable : ()Z
/*      */     //   197: ifeq -> 204
/*      */     //   200: iconst_1
/*      */     //   201: goto -> 205
/*      */     //   204: iconst_0
/*      */     //   205: ireturn
/*      */     //   206: iconst_0
/*      */     //   207: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #310	-> 0
/*      */     //   #311	-> 7
/*      */     //   #313	-> 9
/*      */     //   #314	-> 19
/*      */     //   #316	-> 32
/*      */     //   #317	-> 39
/*      */     //   #318	-> 49
/*      */     //   #320	-> 54
/*      */     //   #321	-> 64
/*      */     //   #323	-> 84
/*      */     //   #326	-> 94
/*      */     //   #328	-> 99
/*      */     //   #329	-> 131
/*      */     //   #327	-> 144
/*      */     //   #331	-> 145
/*      */     //   #332	-> 155
/*      */     //   #335	-> 160
/*      */     //   #334	-> 164
/*      */     //   #335	-> 185
/*      */     //   #333	-> 205
/*      */     //   #337	-> 206
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   130	13	3	cpa	Lorg/springframework/expression/spel/CompilablePropertyAccessor;
/*      */     //   99	46	2	cachedPropertyReadState	Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;
/*      */     //   184	20	3	cia	Lorg/springframework/expression/spel/CompilableIndexAccessor;
/*      */     //   160	46	2	cachedIndexReadState	Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;
/*      */     //   0	208	0	this	Lorg/springframework/expression/spel/ast/Indexer;
/*      */     //   39	169	1	index	Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  342 */     String exitTypeDescriptor = this.exitTypeDescriptor;
/*  343 */     String descriptor = cf.lastDescriptor();
/*  344 */     if (descriptor == null)
/*      */     {
/*  346 */       cf.loadTarget(mv);
/*      */     }
/*      */     
/*  349 */     Label skipIfNull = null;
/*  350 */     if (this.nullSafe) {
/*  351 */       mv.visitInsn(89);
/*  352 */       skipIfNull = new Label();
/*  353 */       Label continueLabel = new Label();
/*  354 */       mv.visitJumpInsn(199, continueLabel);
/*  355 */       CodeFlow.insertCheckCast(mv, exitTypeDescriptor);
/*  356 */       mv.visitJumpInsn(167, skipIfNull);
/*  357 */       mv.visitLabel(continueLabel);
/*      */     } 
/*      */     
/*  360 */     SpelNodeImpl index = this.children[0];
/*      */     
/*  362 */     if (this.indexedType == IndexedType.ARRAY) {
/*  363 */       String arrayTypeDescriptor = this.arrayTypeDescriptor;
/*  364 */       Assert.state((exitTypeDescriptor != null && arrayTypeDescriptor != null), "Array not compilable without descriptors");
/*      */       
/*  366 */       CodeFlow.insertCheckCast(mv, arrayTypeDescriptor);
/*  367 */       switch (arrayTypeDescriptor) { case "[D": 
/*      */         case "[F": 
/*      */         case "[J": 
/*      */         case "[I": 
/*      */         case "[S": 
/*      */         case "[B": case "[Z": 
/*      */         case "[C": 
/*      */         default:
/*  375 */           break; }  int insn = 50;
/*      */ 
/*      */       
/*  378 */       generateIndexCode(mv, cf, index, int.class);
/*  379 */       mv.visitInsn(insn);
/*      */     
/*      */     }
/*  382 */     else if (this.indexedType == IndexedType.LIST) {
/*  383 */       mv.visitTypeInsn(192, "java/util/List");
/*  384 */       generateIndexCode(mv, cf, index, int.class);
/*  385 */       mv.visitMethodInsn(185, "java/util/List", "get", "(I)Ljava/lang/Object;", true);
/*      */     
/*      */     }
/*  388 */     else if (this.indexedType == IndexedType.MAP) {
/*  389 */       mv.visitTypeInsn(192, "java/util/Map");
/*      */ 
/*      */       
/*  392 */       if (index instanceof PropertyOrFieldReference) { PropertyOrFieldReference reference = (PropertyOrFieldReference)index;
/*  393 */         String mapKeyName = reference.getName();
/*  394 */         mv.visitLdcInsn(mapKeyName); }
/*      */       else
/*      */       
/*  397 */       { generateIndexCode(mv, cf, index, Object.class); }
/*      */       
/*  399 */       mv.visitMethodInsn(185, "java/util/Map", "get", "(Ljava/lang/Object;)Ljava/lang/Object;", true);
/*      */ 
/*      */     
/*      */     }
/*  403 */     else if (this.indexedType == IndexedType.OBJECT) {
/*  404 */       StringLiteral stringLiteral; CompilablePropertyAccessor compilablePropertyAccessor; if (index instanceof StringLiteral) { stringLiteral = (StringLiteral)index; }
/*  405 */       else { throw new IllegalStateException("Index expression must be a StringLiteral, but was: " + index
/*  406 */             .getClass().getName()); }
/*      */ 
/*      */       
/*  409 */       CachedPropertyState cachedPropertyReadState = this.cachedPropertyReadState;
/*  410 */       Assert.state((cachedPropertyReadState != null), "No cached PropertyAccessor for reading");
/*  411 */       PropertyAccessor propertyAccessor = cachedPropertyReadState.accessor; if (propertyAccessor instanceof CompilablePropertyAccessor) { compilablePropertyAccessor = (CompilablePropertyAccessor)propertyAccessor; }
/*  412 */       else { throw new IllegalStateException("Cached PropertyAccessor must be a CompilablePropertyAccessor, but was: " + cachedPropertyReadState.accessor
/*      */             
/*  414 */             .getClass().getName()); }
/*      */       
/*  416 */       String propertyName = (String)stringLiteral.getLiteralValue().getValue();
/*  417 */       Assert.state((propertyName != null), "No property name");
/*  418 */       compilablePropertyAccessor.generateCode(propertyName, mv, cf);
/*      */     
/*      */     }
/*  421 */     else if (this.indexedType == IndexedType.CUSTOM) {
/*  422 */       CompilableIndexAccessor compilableIndexAccessor; CachedIndexState cachedIndexReadState = this.cachedIndexReadState;
/*  423 */       Assert.state((cachedIndexReadState != null), "No cached IndexAccessor for reading");
/*  424 */       IndexAccessor indexAccessor = cachedIndexReadState.accessor; if (indexAccessor instanceof CompilableIndexAccessor) { compilableIndexAccessor = (CompilableIndexAccessor)indexAccessor; }
/*  425 */       else { throw new IllegalStateException("Cached IndexAccessor must be a CompilableIndexAccessor, but was: " + cachedIndexReadState.accessor
/*      */             
/*  427 */             .getClass().getName()); }
/*      */       
/*  429 */       compilableIndexAccessor.generateCode(index, mv, cf);
/*      */     } 
/*      */     
/*  432 */     cf.pushDescriptor(exitTypeDescriptor);
/*      */     
/*  434 */     if (skipIfNull != null) {
/*  435 */       if (this.originalPrimitiveExitTypeDescriptor != null)
/*      */       {
/*      */ 
/*      */         
/*  439 */         CodeFlow.insertBoxIfNecessary(mv, this.originalPrimitiveExitTypeDescriptor);
/*      */       }
/*  441 */       mv.visitLabel(skipIfNull);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void generateIndexCode(MethodVisitor mv, CodeFlow cf, SpelNodeImpl indexNode, Class<?> indexType) {
/*  446 */     cf.generateCodeForArgument(mv, indexNode, indexType);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toStringAST() {
/*  451 */     return "[" + getChild(0).toStringAST() + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setExitTypeDescriptor(String descriptor) {
/*  459 */     if (this.nullSafe && CodeFlow.isPrimitive(descriptor)) {
/*  460 */       this.originalPrimitiveExitTypeDescriptor = descriptor;
/*  461 */       this.exitTypeDescriptor = CodeFlow.toBoxedDescriptor(descriptor);
/*      */     } else {
/*      */       
/*  464 */       this.exitTypeDescriptor = descriptor;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int convertIndexToInt(ExpressionState state, Object index) {
/*  469 */     return ((Integer)state.convertValue(index, TypeDescriptor.valueOf(Integer.class))).intValue();
/*      */   }
/*      */   
/*      */   private static Class<?> getObjectType(Object obj) {
/*  473 */     Class<?> clazz = (Class)obj; return (obj instanceof Class) ? clazz : obj.getClass();
/*      */   }
/*      */   private static final class CachedPropertyState extends Record { private final PropertyAccessor accessor; private final Class<?> targetType;
/*      */     private final String name;
/*      */     
/*      */     public final String toString() {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> toString : (Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;)Ljava/lang/String;
/*      */       //   6: areturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #486	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;
/*      */     }
/*      */     
/*      */     public final int hashCode() {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> hashCode : (Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;)I
/*      */       //   6: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #486	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;
/*      */     }
/*      */     
/*  486 */     private CachedPropertyState(PropertyAccessor accessor, Class<?> targetType, String name) { this.accessor = accessor; this.targetType = targetType; this.name = name; } public final boolean equals(Object o) { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: aload_1
/*      */       //   2: <illegal opcode> equals : (Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;Ljava/lang/Object;)Z
/*      */       //   7: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #486	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	8	0	this	Lorg/springframework/expression/spel/ast/Indexer$CachedPropertyState;
/*  486 */       //   0	8	1	o	Ljava/lang/Object; } public PropertyAccessor accessor() { return this.accessor; } public Class<?> targetType() { return this.targetType; } public String name() { return this.name; }
/*      */      }
/*      */   
/*      */   private static final class CachedIndexState extends Record { private final IndexAccessor accessor; private final Class<?> targetType;
/*      */     private final Object index;
/*      */     
/*      */     public final String toString() {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> toString : (Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;)Ljava/lang/String;
/*      */       //   6: areturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #500	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;
/*      */     }
/*      */     
/*      */     public final int hashCode() {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> hashCode : (Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;)I
/*      */       //   6: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #500	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;
/*      */     }
/*      */     
/*  500 */     private CachedIndexState(IndexAccessor accessor, Class<?> targetType, Object index) { this.accessor = accessor; this.targetType = targetType; this.index = index; } public final boolean equals(Object o) { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: aload_1
/*      */       //   2: <illegal opcode> equals : (Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;Ljava/lang/Object;)Z
/*      */       //   7: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #500	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	8	0	this	Lorg/springframework/expression/spel/ast/Indexer$CachedIndexState;
/*  500 */       //   0	8	1	o	Ljava/lang/Object; } public IndexAccessor accessor() { return this.accessor; } public Class<?> targetType() { return this.targetType; } public Object index() { return this.index; }
/*      */      }
/*      */ 
/*      */ 
/*      */   
/*      */   private class ArrayIndexingValueRef
/*      */     implements ValueRef
/*      */   {
/*      */     private final TypeConverter typeConverter;
/*      */     private final Object array;
/*      */     private final int index;
/*      */     private final TypeDescriptor typeDescriptor;
/*      */     
/*      */     ArrayIndexingValueRef(TypeConverter typeConverter, Object array, int index, TypeDescriptor typeDescriptor) {
/*  514 */       this.typeConverter = typeConverter;
/*  515 */       this.array = array;
/*  516 */       this.index = index;
/*  517 */       this.typeDescriptor = typeDescriptor;
/*      */     }
/*      */ 
/*      */     
/*      */     public TypedValue getValue() {
/*  522 */       Object arrayElement = getArrayElement(this.array, this.index);
/*  523 */       return new TypedValue(arrayElement, this.typeDescriptor.elementTypeDescriptor(arrayElement));
/*      */     }
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable Object newValue) {
/*  528 */       TypeDescriptor elementType = this.typeDescriptor.getElementTypeDescriptor();
/*  529 */       Assert.state((elementType != null), "No element type");
/*  530 */       setArrayElement(this.typeConverter, this.array, this.index, newValue, elementType.getType());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isWritable() {
/*  535 */       return true;
/*      */     }
/*      */     
/*      */     private Object getArrayElement(Object ctx, int idx) throws SpelEvaluationException {
/*  539 */       Class<?> arrayComponentType = ctx.getClass().componentType();
/*  540 */       if (arrayComponentType == boolean.class) {
/*  541 */         boolean[] arrayOfBoolean = (boolean[])ctx;
/*  542 */         checkAccess(arrayOfBoolean.length, idx);
/*  543 */         Indexer.this.setExitTypeDescriptor("Z");
/*  544 */         Indexer.this.arrayTypeDescriptor = "[Z";
/*  545 */         return Boolean.valueOf(arrayOfBoolean[idx]);
/*      */       } 
/*  547 */       if (arrayComponentType == byte.class) {
/*  548 */         byte[] arrayOfByte = (byte[])ctx;
/*  549 */         checkAccess(arrayOfByte.length, idx);
/*  550 */         Indexer.this.setExitTypeDescriptor("B");
/*  551 */         Indexer.this.arrayTypeDescriptor = "[B";
/*  552 */         return Byte.valueOf(arrayOfByte[idx]);
/*      */       } 
/*  554 */       if (arrayComponentType == char.class) {
/*  555 */         char[] arrayOfChar = (char[])ctx;
/*  556 */         checkAccess(arrayOfChar.length, idx);
/*  557 */         Indexer.this.setExitTypeDescriptor("C");
/*  558 */         Indexer.this.arrayTypeDescriptor = "[C";
/*  559 */         return Character.valueOf(arrayOfChar[idx]);
/*      */       } 
/*  561 */       if (arrayComponentType == double.class) {
/*  562 */         double[] arrayOfDouble = (double[])ctx;
/*  563 */         checkAccess(arrayOfDouble.length, idx);
/*  564 */         Indexer.this.setExitTypeDescriptor("D");
/*  565 */         Indexer.this.arrayTypeDescriptor = "[D";
/*  566 */         return Double.valueOf(arrayOfDouble[idx]);
/*      */       } 
/*  568 */       if (arrayComponentType == float.class) {
/*  569 */         float[] arrayOfFloat = (float[])ctx;
/*  570 */         checkAccess(arrayOfFloat.length, idx);
/*  571 */         Indexer.this.setExitTypeDescriptor("F");
/*  572 */         Indexer.this.arrayTypeDescriptor = "[F";
/*  573 */         return Float.valueOf(arrayOfFloat[idx]);
/*      */       } 
/*  575 */       if (arrayComponentType == int.class) {
/*  576 */         int[] arrayOfInt = (int[])ctx;
/*  577 */         checkAccess(arrayOfInt.length, idx);
/*  578 */         Indexer.this.setExitTypeDescriptor("I");
/*  579 */         Indexer.this.arrayTypeDescriptor = "[I";
/*  580 */         return Integer.valueOf(arrayOfInt[idx]);
/*      */       } 
/*  582 */       if (arrayComponentType == long.class) {
/*  583 */         long[] arrayOfLong = (long[])ctx;
/*  584 */         checkAccess(arrayOfLong.length, idx);
/*  585 */         Indexer.this.setExitTypeDescriptor("J");
/*  586 */         Indexer.this.arrayTypeDescriptor = "[J";
/*  587 */         return Long.valueOf(arrayOfLong[idx]);
/*      */       } 
/*  589 */       if (arrayComponentType == short.class) {
/*  590 */         short[] arrayOfShort = (short[])ctx;
/*  591 */         checkAccess(arrayOfShort.length, idx);
/*  592 */         Indexer.this.setExitTypeDescriptor("S");
/*  593 */         Indexer.this.arrayTypeDescriptor = "[S";
/*  594 */         return Short.valueOf(arrayOfShort[idx]);
/*      */       } 
/*      */       
/*  597 */       Object[] array = (Object[])ctx;
/*  598 */       checkAccess(array.length, idx);
/*  599 */       Object retValue = array[idx];
/*  600 */       Indexer.this.exitTypeDescriptor = CodeFlow.toDescriptor(arrayComponentType);
/*  601 */       Indexer.this.arrayTypeDescriptor = CodeFlow.toDescriptor(array.getClass());
/*  602 */       return retValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setArrayElement(TypeConverter converter, Object ctx, int idx, @Nullable Object newValue, Class<?> arrayComponentType) throws EvaluationException {
/*  609 */       if (arrayComponentType == boolean.class) {
/*  610 */         boolean[] array = (boolean[])ctx;
/*  611 */         checkAccess(array.length, idx);
/*  612 */         array[idx] = ((Boolean)convertValue(converter, newValue, (Class)boolean.class)).booleanValue();
/*      */       }
/*  614 */       else if (arrayComponentType == byte.class) {
/*  615 */         byte[] array = (byte[])ctx;
/*  616 */         checkAccess(array.length, idx);
/*  617 */         array[idx] = ((Byte)convertValue(converter, newValue, (Class)byte.class)).byteValue();
/*      */       }
/*  619 */       else if (arrayComponentType == char.class) {
/*  620 */         char[] array = (char[])ctx;
/*  621 */         checkAccess(array.length, idx);
/*  622 */         array[idx] = ((Character)convertValue(converter, newValue, (Class)char.class)).charValue();
/*      */       }
/*  624 */       else if (arrayComponentType == double.class) {
/*  625 */         double[] array = (double[])ctx;
/*  626 */         checkAccess(array.length, idx);
/*  627 */         array[idx] = ((Double)convertValue(converter, newValue, (Class)double.class)).doubleValue();
/*      */       }
/*  629 */       else if (arrayComponentType == float.class) {
/*  630 */         float[] array = (float[])ctx;
/*  631 */         checkAccess(array.length, idx);
/*  632 */         array[idx] = ((Float)convertValue(converter, newValue, (Class)float.class)).floatValue();
/*      */       }
/*  634 */       else if (arrayComponentType == int.class) {
/*  635 */         int[] array = (int[])ctx;
/*  636 */         checkAccess(array.length, idx);
/*  637 */         array[idx] = ((Integer)convertValue(converter, newValue, (Class)int.class)).intValue();
/*      */       }
/*  639 */       else if (arrayComponentType == long.class) {
/*  640 */         long[] array = (long[])ctx;
/*  641 */         checkAccess(array.length, idx);
/*  642 */         array[idx] = ((Long)convertValue(converter, newValue, (Class)long.class)).longValue();
/*      */       }
/*  644 */       else if (arrayComponentType == short.class) {
/*  645 */         short[] array = (short[])ctx;
/*  646 */         checkAccess(array.length, idx);
/*  647 */         array[idx] = ((Short)convertValue(converter, newValue, (Class)short.class)).shortValue();
/*      */       } else {
/*      */         
/*  650 */         Object[] array = (Object[])ctx;
/*  651 */         checkAccess(array.length, idx);
/*  652 */         array[idx] = convertValue(converter, newValue, arrayComponentType);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void checkAccess(int arrayLength, int index) throws SpelEvaluationException {
/*  657 */       if (index >= arrayLength) {
/*  658 */         throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.ARRAY_INDEX_OUT_OF_BOUNDS, new Object[] {
/*  659 */               Integer.valueOf(arrayLength), Integer.valueOf(index)
/*      */             });
/*      */       }
/*      */     }
/*      */     
/*      */     private static <T> T convertValue(TypeConverter converter, @Nullable Object value, Class<T> targetType) {
/*  665 */       T result = (T)converter.convertValue(value, 
/*  666 */           TypeDescriptor.forObject(value), TypeDescriptor.valueOf(targetType));
/*  667 */       if (result == null) {
/*  668 */         throw new IllegalStateException("Null conversion result for index [" + String.valueOf(value) + "]");
/*      */       }
/*  670 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class MapIndexingValueRef
/*      */     implements ValueRef
/*      */   {
/*      */     private final TypeConverter typeConverter;
/*      */ 
/*      */     
/*      */     private final Map map;
/*      */     
/*      */     @Nullable
/*      */     private final Object key;
/*      */     
/*      */     private final TypeDescriptor mapEntryDescriptor;
/*      */ 
/*      */     
/*      */     public MapIndexingValueRef(TypeConverter typeConverter, @Nullable Map map, Object key, TypeDescriptor mapEntryDescriptor) {
/*  691 */       this.typeConverter = typeConverter;
/*  692 */       this.map = map;
/*  693 */       this.key = key;
/*  694 */       this.mapEntryDescriptor = mapEntryDescriptor;
/*      */     }
/*      */ 
/*      */     
/*      */     public TypedValue getValue() {
/*  699 */       Object value = this.map.get(this.key);
/*  700 */       Indexer.this.exitTypeDescriptor = CodeFlow.toDescriptor(Object.class);
/*  701 */       return new TypedValue(value, this.mapEntryDescriptor.getMapValueTypeDescriptor(value));
/*      */     }
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable Object newValue) {
/*  706 */       if (this.mapEntryDescriptor.getMapValueTypeDescriptor() != null) {
/*  707 */         newValue = this.typeConverter.convertValue(newValue, TypeDescriptor.forObject(newValue), this.mapEntryDescriptor
/*  708 */             .getMapValueTypeDescriptor());
/*      */       }
/*  710 */       this.map.put(this.key, newValue);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isWritable() {
/*  715 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class PropertyAccessorValueRef
/*      */     implements ValueRef
/*      */   {
/*      */     private final Object targetObject;
/*      */     
/*      */     private final String name;
/*      */     
/*      */     private final EvaluationContext evaluationContext;
/*      */     
/*      */     private final TypeDescriptor targetObjectTypeDescriptor;
/*      */ 
/*      */     
/*      */     public PropertyAccessorValueRef(Object targetObject, String name, EvaluationContext evaluationContext, TypeDescriptor targetObjectTypeDescriptor) {
/*  733 */       this.targetObject = targetObject;
/*  734 */       this.name = name;
/*  735 */       this.evaluationContext = evaluationContext;
/*  736 */       this.targetObjectTypeDescriptor = targetObjectTypeDescriptor;
/*      */     }
/*      */ 
/*      */     
/*      */     public TypedValue getValue() {
/*  741 */       Class<?> targetType = Indexer.getObjectType(this.targetObject);
/*      */       try {
/*  743 */         Indexer.CachedPropertyState cachedPropertyReadState = Indexer.this.cachedPropertyReadState;
/*  744 */         if (cachedPropertyReadState != null) {
/*  745 */           String cachedPropertyName = cachedPropertyReadState.name;
/*  746 */           Class<?> cachedTargetType = cachedPropertyReadState.targetType;
/*      */           
/*  748 */           if (cachedPropertyName.equals(this.name) && cachedTargetType.equals(targetType)) {
/*  749 */             PropertyAccessor accessor = cachedPropertyReadState.accessor;
/*  750 */             return accessor.read(this.evaluationContext, this.targetObject, this.name);
/*      */           } 
/*      */ 
/*      */           
/*  754 */           Indexer.this.cachedPropertyReadState = null;
/*      */         } 
/*      */         
/*  757 */         List<PropertyAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(targetType, this.evaluationContext.getPropertyAccessors());
/*  758 */         for (PropertyAccessor accessor : accessorsToTry) {
/*  759 */           if (accessor.canRead(this.evaluationContext, this.targetObject, this.name)) {
/*  760 */             if (accessor instanceof ReflectivePropertyAccessor) { ReflectivePropertyAccessor reflectivePropertyAccessor = (ReflectivePropertyAccessor)accessor;
/*  761 */               accessor = reflectivePropertyAccessor.createOptimalAccessor(this.evaluationContext, this.targetObject, this.name); }
/*      */ 
/*      */             
/*  764 */             TypedValue result = accessor.read(this.evaluationContext, this.targetObject, this.name);
/*  765 */             Indexer.this.cachedPropertyReadState = new Indexer.CachedPropertyState(accessor, targetType, this.name);
/*  766 */             if (accessor instanceof CompilablePropertyAccessor) { CompilablePropertyAccessor compilablePropertyAccessor = (CompilablePropertyAccessor)accessor;
/*  767 */               Indexer.this.setExitTypeDescriptor(CodeFlow.toDescriptor(compilablePropertyAccessor.getPropertyType())); }
/*      */             
/*  769 */             return result;
/*      */           }
/*      */         
/*      */         } 
/*  773 */       } catch (AccessException ex) {
/*  774 */         throw new SpelEvaluationException(Indexer.this.getStartPosition(), ex, SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.targetObjectTypeDescriptor
/*  775 */               .toString() });
/*      */       } 
/*  777 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.targetObjectTypeDescriptor
/*  778 */             .toString() });
/*      */     }
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable Object newValue) {
/*  783 */       Class<?> targetType = Indexer.getObjectType(this.targetObject);
/*      */       try {
/*  785 */         Indexer.CachedPropertyState cachedPropertyWriteState = Indexer.this.cachedPropertyWriteState;
/*  786 */         if (cachedPropertyWriteState != null) {
/*  787 */           String cachedPropertyName = cachedPropertyWriteState.name;
/*  788 */           Class<?> cachedTargetType = cachedPropertyWriteState.targetType;
/*      */           
/*  790 */           if (cachedPropertyName.equals(this.name) && cachedTargetType.equals(targetType)) {
/*  791 */             PropertyAccessor accessor = cachedPropertyWriteState.accessor;
/*  792 */             accessor.write(this.evaluationContext, this.targetObject, this.name, newValue);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  797 */           Indexer.this.cachedPropertyWriteState = null;
/*      */         } 
/*      */         
/*  800 */         List<PropertyAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(targetType, this.evaluationContext.getPropertyAccessors());
/*  801 */         for (PropertyAccessor accessor : accessorsToTry) {
/*  802 */           if (accessor.canWrite(this.evaluationContext, this.targetObject, this.name)) {
/*  803 */             accessor.write(this.evaluationContext, this.targetObject, this.name, newValue);
/*  804 */             Indexer.this.cachedPropertyWriteState = new Indexer.CachedPropertyState(accessor, targetType, this.name);
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*  809 */       } catch (AccessException ex) {
/*  810 */         throw new SpelEvaluationException(Indexer.this.getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_PROPERTY_WRITE, new Object[] { this.name, ex
/*  811 */               .getMessage() });
/*      */       } 
/*  813 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.targetObjectTypeDescriptor
/*  814 */             .toString() });
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isWritable() {
/*  819 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class CollectionIndexingValueRef
/*      */     implements ValueRef
/*      */   {
/*      */     private final Collection collection;
/*      */     
/*      */     private final int index;
/*      */     
/*      */     private final TypeDescriptor collectionEntryDescriptor;
/*      */     
/*      */     private final TypeConverter typeConverter;
/*      */     
/*      */     private final boolean growCollection;
/*      */     
/*      */     private final int maximumSize;
/*      */ 
/*      */     
/*      */     public CollectionIndexingValueRef(Collection collection, int index, TypeDescriptor collectionEntryDescriptor, TypeConverter typeConverter, boolean growCollection, int maximumSize) {
/*  842 */       this.collection = collection;
/*  843 */       this.index = index;
/*  844 */       this.collectionEntryDescriptor = collectionEntryDescriptor;
/*  845 */       this.typeConverter = typeConverter;
/*  846 */       this.growCollection = growCollection;
/*  847 */       this.maximumSize = maximumSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public TypedValue getValue() {
/*  852 */       growCollectionIfNecessary();
/*  853 */       Collection collection = this.collection; if (collection instanceof List) { List list = (List)collection;
/*  854 */         Object o = list.get(this.index);
/*  855 */         Indexer.this.exitTypeDescriptor = CodeFlow.toDescriptor(Object.class);
/*  856 */         return new TypedValue(o, this.collectionEntryDescriptor.elementTypeDescriptor(o)); }
/*      */ 
/*      */       
/*  859 */       int pos = 0;
/*  860 */       for (Object o : this.collection) {
/*  861 */         if (pos == this.index) {
/*  862 */           return new TypedValue(o, this.collectionEntryDescriptor.elementTypeDescriptor(o));
/*      */         }
/*  864 */         pos++;
/*      */       } 
/*  866 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.COLLECTION_INDEX_OUT_OF_BOUNDS, new Object[] {
/*  867 */             Integer.valueOf(this.collection.size()), Integer.valueOf(this.index) });
/*      */     }
/*      */     
/*      */     public void setValue(@Nullable Object newValue) {
/*      */       List<Object> list;
/*  872 */       Collection collection = this.collection; if (collection instanceof List) { list = (List)collection; }
/*  873 */       else { throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.collectionEntryDescriptor
/*  874 */               .toString() }); }
/*      */ 
/*      */       
/*  877 */       growCollectionIfNecessary();
/*  878 */       if (this.collectionEntryDescriptor.getElementTypeDescriptor() != null) {
/*  879 */         newValue = this.typeConverter.convertValue(newValue, TypeDescriptor.forObject(newValue), this.collectionEntryDescriptor
/*  880 */             .getElementTypeDescriptor());
/*      */       }
/*  882 */       list.set(this.index, newValue);
/*      */     }
/*      */     
/*      */     private void growCollectionIfNecessary() {
/*  886 */       if (this.index >= this.collection.size()) {
/*  887 */         if (!this.growCollection)
/*  888 */           throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.COLLECTION_INDEX_OUT_OF_BOUNDS, new Object[] {
/*  889 */                 Integer.valueOf(this.collection.size()), Integer.valueOf(this.index)
/*      */               }); 
/*  891 */         if (this.index >= this.maximumSize) {
/*  892 */           throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.UNABLE_TO_GROW_COLLECTION, new Object[0]);
/*      */         }
/*  894 */         if (this.collectionEntryDescriptor.getElementTypeDescriptor() == null) {
/*  895 */           throw new SpelEvaluationException(Indexer.this
/*  896 */               .getStartPosition(), SpelMessage.UNABLE_TO_GROW_COLLECTION_UNKNOWN_ELEMENT_TYPE, new Object[0]);
/*      */         }
/*  898 */         TypeDescriptor elementType = this.collectionEntryDescriptor.getElementTypeDescriptor();
/*      */         try {
/*  900 */           Constructor<?> ctor = getDefaultConstructor(elementType.getType());
/*  901 */           int newElements = this.index - this.collection.size();
/*  902 */           while (newElements >= 0)
/*      */           {
/*  904 */             this.collection.add((ctor != null) ? (T)ctor.newInstance(new Object[0]) : null);
/*  905 */             newElements--;
/*      */           }
/*      */         
/*  908 */         } catch (Throwable ex) {
/*  909 */           throw new SpelEvaluationException(Indexer.this.getStartPosition(), ex, SpelMessage.UNABLE_TO_GROW_COLLECTION, new Object[0]);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isWritable() {
/*  916 */       return this.collection instanceof List;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     private static Constructor<?> getDefaultConstructor(Class<?> type) {
/*      */       try {
/*  922 */         return ReflectionUtils.accessibleConstructor(type, new Class[0]);
/*      */       }
/*  924 */       catch (Throwable ex) {
/*  925 */         return null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class StringIndexingValueRef
/*      */     implements ValueRef
/*      */   {
/*      */     private final String target;
/*      */     
/*      */     private final int index;
/*      */     private final TypeDescriptor typeDescriptor;
/*      */     
/*      */     public StringIndexingValueRef(String target, int index, TypeDescriptor typeDescriptor) {
/*  940 */       this.target = target;
/*  941 */       this.index = index;
/*  942 */       this.typeDescriptor = typeDescriptor;
/*      */     }
/*      */ 
/*      */     
/*      */     public TypedValue getValue() {
/*  947 */       if (this.index >= this.target.length())
/*  948 */         throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.STRING_INDEX_OUT_OF_BOUNDS, new Object[] {
/*  949 */               Integer.valueOf(this.target.length()), Integer.valueOf(this.index)
/*      */             }); 
/*  951 */       return new TypedValue(String.valueOf(this.target.charAt(this.index)));
/*      */     }
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable Object newValue) {
/*  956 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.typeDescriptor
/*  957 */             .toString() });
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isWritable() {
/*  962 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class IndexAccessorValueRef
/*      */     implements ValueRef
/*      */   {
/*      */     private final Object target;
/*      */     
/*      */     private final Object index;
/*      */     
/*      */     private final EvaluationContext evaluationContext;
/*      */     
/*      */     private final TypeDescriptor typeDescriptor;
/*      */ 
/*      */     
/*      */     IndexAccessorValueRef(Object target, Object index, EvaluationContext evaluationContext, TypeDescriptor typeDescriptor) {
/*  981 */       this.target = target;
/*  982 */       this.index = index;
/*  983 */       this.evaluationContext = evaluationContext;
/*  984 */       this.typeDescriptor = typeDescriptor;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public TypedValue getValue() {
/*  990 */       Class<?> targetType = Indexer.getObjectType(this.target);
/*  991 */       Exception exception = null;
/*      */       try {
/*  993 */         Indexer.CachedIndexState cachedIndexReadState = Indexer.this.cachedIndexReadState;
/*  994 */         if (cachedIndexReadState != null) {
/*  995 */           Object cachedIndex = cachedIndexReadState.index;
/*  996 */           Class<?> cachedTargetType = cachedIndexReadState.targetType;
/*      */           
/*  998 */           if (cachedIndex.equals(this.index) && cachedTargetType.equals(targetType)) {
/*  999 */             IndexAccessor accessor = cachedIndexReadState.accessor;
/* 1000 */             if (this.evaluationContext.getIndexAccessors().contains(accessor)) {
/*      */               try {
/* 1002 */                 return accessor.read(this.evaluationContext, this.target, this.index);
/*      */               }
/* 1004 */               catch (Exception ex) {
/*      */ 
/*      */ 
/*      */                 
/* 1008 */                 exception = ex;
/*      */               } 
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 1014 */           Indexer.this.cachedIndexReadState = null;
/*      */         } 
/*      */         
/* 1017 */         List<IndexAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(this.target, this.evaluationContext.getIndexAccessors());
/* 1018 */         for (IndexAccessor indexAccessor : accessorsToTry) {
/* 1019 */           if (indexAccessor.canRead(this.evaluationContext, this.target, this.index)) {
/* 1020 */             TypedValue result = indexAccessor.read(this.evaluationContext, this.target, this.index);
/* 1021 */             Indexer.this.cachedIndexReadState = new Indexer.CachedIndexState(indexAccessor, targetType, this.index);
/* 1022 */             if (indexAccessor instanceof CompilableIndexAccessor) { CompilableIndexAccessor compilableIndexAccessor = (CompilableIndexAccessor)indexAccessor;
/* 1023 */               Indexer.this.setExitTypeDescriptor(CodeFlow.toDescriptor(compilableIndexAccessor.getIndexedValueType())); }
/*      */             
/* 1025 */             return result;
/*      */           }
/*      */         
/*      */         } 
/* 1029 */       } catch (Exception ex) {
/* 1030 */         exception = ex;
/*      */       } 
/*      */       
/* 1033 */       if (exception != null) {
/* 1034 */         throw new SpelEvaluationException(Indexer.this
/* 1035 */             .getStartPosition(), exception, SpelMessage.EXCEPTION_DURING_INDEX_READ, new Object[] { this.index, this.typeDescriptor
/* 1036 */               .toString() });
/*      */       }
/* 1038 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.typeDescriptor
/* 1039 */             .toString() });
/*      */     }
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable Object newValue) {
/* 1044 */       Class<?> targetType = Indexer.getObjectType(this.target);
/* 1045 */       Exception exception = null;
/*      */       try {
/* 1047 */         Indexer.CachedIndexState cachedIndexWriteState = Indexer.this.cachedIndexWriteState;
/* 1048 */         if (cachedIndexWriteState != null) {
/* 1049 */           Object cachedIndex = cachedIndexWriteState.index;
/* 1050 */           Class<?> cachedTargetType = cachedIndexWriteState.targetType;
/*      */           
/* 1052 */           if (cachedIndex.equals(this.index) && cachedTargetType.equals(targetType)) {
/* 1053 */             IndexAccessor accessor = cachedIndexWriteState.accessor;
/* 1054 */             if (this.evaluationContext.getIndexAccessors().contains(accessor)) {
/*      */               try {
/* 1056 */                 accessor.write(this.evaluationContext, this.target, this.index, newValue);
/*      */                 
/*      */                 return;
/* 1059 */               } catch (Exception ex) {
/*      */ 
/*      */ 
/*      */                 
/* 1063 */                 exception = ex;
/*      */               } 
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 1069 */           Indexer.this.cachedIndexWriteState = null;
/*      */         } 
/*      */         
/* 1072 */         List<IndexAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(this.target, this.evaluationContext.getIndexAccessors());
/* 1073 */         for (IndexAccessor indexAccessor : accessorsToTry) {
/* 1074 */           if (indexAccessor.canWrite(this.evaluationContext, this.target, this.index)) {
/* 1075 */             indexAccessor.write(this.evaluationContext, this.target, this.index, newValue);
/* 1076 */             Indexer.this.cachedIndexWriteState = new Indexer.CachedIndexState(indexAccessor, targetType, this.index);
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/* 1081 */       } catch (Exception ex) {
/* 1082 */         exception = ex;
/*      */       } 
/*      */       
/* 1085 */       if (exception != null) {
/* 1086 */         throw new SpelEvaluationException(Indexer.this
/* 1087 */             .getStartPosition(), exception, SpelMessage.EXCEPTION_DURING_INDEX_WRITE, new Object[] { this.index, this.typeDescriptor
/* 1088 */               .toString() });
/*      */       }
/* 1090 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.INDEXING_NOT_SUPPORTED_FOR_TYPE, new Object[] { this.typeDescriptor
/* 1091 */             .toString() });
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isWritable() {
/* 1096 */       return true;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Indexer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */