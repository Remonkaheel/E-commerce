/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringJoiner;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.ConstructorExecutor;
/*     */ import org.springframework.expression.ConstructorResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.common.ExpressionUtils;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.ReflectiveConstructorExecutor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private static final int MAX_ARRAY_ELEMENTS = 262144;
/*     */   private final boolean isArrayConstructor;
/*     */   @Nullable
/*     */   private final SpelNodeImpl[] dimensions;
/*     */   @Nullable
/*     */   private volatile ConstructorExecutor cachedExecutor;
/*     */   
/*     */   public ConstructorReference(int startPos, int endPos, SpelNodeImpl... arguments) {
/*  90 */     super(startPos, endPos, arguments);
/*  91 */     this.isArrayConstructor = false;
/*  92 */     this.dimensions = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstructorReference(int startPos, int endPos, SpelNodeImpl[] dimensions, SpelNodeImpl... arguments) {
/* 102 */     super(startPos, endPos, arguments);
/* 103 */     this.isArrayConstructor = true;
/* 104 */     this.dimensions = dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 113 */     if (this.isArrayConstructor) {
/* 114 */       return createArray(state);
/*     */     }
/*     */     
/* 117 */     return createNewInstance(state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue createNewInstance(ExpressionState state) throws EvaluationException {
/* 128 */     Object[] arguments = new Object[getChildCount() - 1];
/* 129 */     List<TypeDescriptor> argumentTypes = new ArrayList<>(getChildCount() - 1);
/* 130 */     for (int i = 0; i < arguments.length; i++) {
/* 131 */       TypedValue childValue = this.children[i + 1].getValueInternal(state);
/* 132 */       Object value = childValue.getValue();
/* 133 */       arguments[i] = value;
/* 134 */       argumentTypes.add(TypeDescriptor.forObject(value));
/*     */     } 
/*     */     
/* 137 */     ConstructorExecutor executorToUse = this.cachedExecutor;
/* 138 */     if (executorToUse != null) {
/*     */       try {
/* 140 */         return executorToUse.execute(state.getEvaluationContext(), arguments);
/*     */       }
/* 142 */       catch (AccessException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 153 */         Throwable throwable = ex.getCause(); if (throwable instanceof InvocationTargetException) { InvocationTargetException cause = (InvocationTargetException)throwable;
/*     */           
/* 155 */           Throwable rootCause = cause.getCause();
/* 156 */           if (rootCause instanceof RuntimeException) { RuntimeException runtimeException = (RuntimeException)rootCause;
/* 157 */             throw runtimeException; }
/*     */ 
/*     */           
/* 160 */           String str = (String)this.children[0].getValueInternal(state).getValue();
/* 161 */           throw new SpelEvaluationException(getStartPosition(), rootCause, SpelMessage.CONSTRUCTOR_INVOCATION_PROBLEM, new Object[] { str, 
/*     */                 
/* 163 */                 FormatHelper.formatMethodForMessage("", argumentTypes) }); }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 168 */         this.cachedExecutor = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 173 */     String typeName = (String)this.children[0].getValueInternal(state).getValue();
/* 174 */     Assert.state((typeName != null), "No type name");
/* 175 */     executorToUse = findExecutorForConstructor(typeName, argumentTypes, state);
/*     */     try {
/* 177 */       this.cachedExecutor = executorToUse;
/* 178 */       if (executorToUse instanceof ReflectiveConstructorExecutor) { ReflectiveConstructorExecutor reflectiveConstructorExecutor = (ReflectiveConstructorExecutor)executorToUse;
/* 179 */         this.exitTypeDescriptor = CodeFlow.toDescriptor(reflectiveConstructorExecutor
/* 180 */             .getConstructor().getDeclaringClass()); }
/*     */ 
/*     */       
/* 183 */       return executorToUse.execute(state.getEvaluationContext(), arguments);
/*     */     }
/* 185 */     catch (AccessException ex) {
/* 186 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.CONSTRUCTOR_INVOCATION_PROBLEM, new Object[] { typeName, 
/*     */             
/* 188 */             FormatHelper.formatMethodForMessage("", argumentTypes) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConstructorExecutor findExecutorForConstructor(String typeName, List<TypeDescriptor> argumentTypes, ExpressionState state) throws SpelEvaluationException {
/* 204 */     EvaluationContext evalContext = state.getEvaluationContext();
/* 205 */     List<ConstructorResolver> ctorResolvers = evalContext.getConstructorResolvers();
/* 206 */     for (ConstructorResolver ctorResolver : ctorResolvers) {
/*     */       try {
/* 208 */         ConstructorExecutor ce = ctorResolver.resolve(state.getEvaluationContext(), typeName, argumentTypes);
/* 209 */         if (ce != null) {
/* 210 */           return ce;
/*     */         }
/*     */       }
/* 213 */       catch (AccessException ex) {
/* 214 */         throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.CONSTRUCTOR_INVOCATION_PROBLEM, new Object[] { typeName, 
/*     */               
/* 216 */               FormatHelper.formatMethodForMessage("", argumentTypes) });
/*     */       } 
/*     */     } 
/* 219 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.CONSTRUCTOR_NOT_FOUND, new Object[] { typeName, 
/* 220 */           FormatHelper.formatMethodForMessage("", argumentTypes) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 225 */     StringBuilder sb = new StringBuilder("new ");
/* 226 */     sb.append(getChild(0).toStringAST());
/*     */ 
/*     */     
/* 229 */     if (this.isArrayConstructor) {
/* 230 */       if (hasInitializer())
/*     */       {
/* 232 */         InlineList initializer = (InlineList)getChild(1);
/* 233 */         sb.append("[] ").append(initializer.toStringAST());
/*     */       }
/* 235 */       else if (this.dimensions != null)
/*     */       {
/* 237 */         for (SpelNodeImpl dimension : this.dimensions) {
/* 238 */           sb.append('[').append(dimension.toStringAST()).append(']');
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 245 */       StringJoiner sj = new StringJoiner(",", "(", ")");
/* 246 */       int count = getChildCount();
/* 247 */       for (int i = 1; i < count; i++) {
/* 248 */         sj.add(getChild(i).toStringAST());
/*     */       }
/* 250 */       sb.append(sj.toString());
/*     */     } 
/*     */     
/* 253 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue createArray(ExpressionState state) throws EvaluationException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: iconst_0
/*     */     //   2: invokevirtual getChild : (I)Lorg/springframework/expression/spel/SpelNode;
/*     */     //   5: aload_1
/*     */     //   6: invokeinterface getValue : (Lorg/springframework/expression/spel/ExpressionState;)Ljava/lang/Object;
/*     */     //   11: astore_2
/*     */     //   12: aload_2
/*     */     //   13: instanceof java/lang/String
/*     */     //   16: ifeq -> 27
/*     */     //   19: aload_2
/*     */     //   20: checkcast java/lang/String
/*     */     //   23: astore_3
/*     */     //   24: goto -> 70
/*     */     //   27: new org/springframework/expression/spel/SpelEvaluationException
/*     */     //   30: dup
/*     */     //   31: aload_0
/*     */     //   32: iconst_0
/*     */     //   33: invokevirtual getChild : (I)Lorg/springframework/expression/spel/SpelNode;
/*     */     //   36: invokeinterface getStartPosition : ()I
/*     */     //   41: getstatic org/springframework/expression/spel/SpelMessage.TYPE_NAME_EXPECTED_FOR_ARRAY_CONSTRUCTION : Lorg/springframework/expression/spel/SpelMessage;
/*     */     //   44: iconst_1
/*     */     //   45: anewarray java/lang/Object
/*     */     //   48: dup
/*     */     //   49: iconst_0
/*     */     //   50: aload_2
/*     */     //   51: ifnull -> 61
/*     */     //   54: aload_2
/*     */     //   55: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   58: goto -> 62
/*     */     //   61: aconst_null
/*     */     //   62: invokestatic formatClassNameForMessage : (Ljava/lang/Class;)Ljava/lang/String;
/*     */     //   65: aastore
/*     */     //   66: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*     */     //   69: athrow
/*     */     //   70: aload_1
/*     */     //   71: invokevirtual getEvaluationContext : ()Lorg/springframework/expression/EvaluationContext;
/*     */     //   74: invokeinterface getConstructorResolvers : ()Ljava/util/List;
/*     */     //   79: invokeinterface isEmpty : ()Z
/*     */     //   84: ifeq -> 120
/*     */     //   87: new org/springframework/expression/spel/SpelEvaluationException
/*     */     //   90: dup
/*     */     //   91: aload_0
/*     */     //   92: invokevirtual getStartPosition : ()I
/*     */     //   95: getstatic org/springframework/expression/spel/SpelMessage.CONSTRUCTOR_NOT_FOUND : Lorg/springframework/expression/spel/SpelMessage;
/*     */     //   98: iconst_2
/*     */     //   99: anewarray java/lang/Object
/*     */     //   102: dup
/*     */     //   103: iconst_0
/*     */     //   104: aload_3
/*     */     //   105: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   110: aastore
/*     */     //   111: dup
/*     */     //   112: iconst_1
/*     */     //   113: ldc '[]'
/*     */     //   115: aastore
/*     */     //   116: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*     */     //   119: athrow
/*     */     //   120: aload_3
/*     */     //   121: invokestatic forName : (Ljava/lang/String;)Lorg/springframework/expression/spel/ast/TypeCode;
/*     */     //   124: astore #5
/*     */     //   126: aload #5
/*     */     //   128: getstatic org/springframework/expression/spel/ast/TypeCode.OBJECT : Lorg/springframework/expression/spel/ast/TypeCode;
/*     */     //   131: if_acmpne -> 144
/*     */     //   134: aload_1
/*     */     //   135: aload_3
/*     */     //   136: invokevirtual findType : (Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   139: astore #4
/*     */     //   141: goto -> 151
/*     */     //   144: aload #5
/*     */     //   146: invokevirtual getType : ()Ljava/lang/Class;
/*     */     //   149: astore #4
/*     */     //   151: aconst_null
/*     */     //   152: astore #6
/*     */     //   154: aload_0
/*     */     //   155: invokevirtual hasInitializer : ()Z
/*     */     //   158: ifne -> 372
/*     */     //   161: aload_0
/*     */     //   162: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   165: ifnull -> 705
/*     */     //   168: aload_0
/*     */     //   169: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   172: astore #7
/*     */     //   174: aload #7
/*     */     //   176: arraylength
/*     */     //   177: istore #8
/*     */     //   179: iconst_0
/*     */     //   180: istore #9
/*     */     //   182: iload #9
/*     */     //   184: iload #8
/*     */     //   186: if_icmpge -> 226
/*     */     //   189: aload #7
/*     */     //   191: iload #9
/*     */     //   193: aaload
/*     */     //   194: astore #10
/*     */     //   196: aload #10
/*     */     //   198: ifnonnull -> 220
/*     */     //   201: new org/springframework/expression/spel/SpelEvaluationException
/*     */     //   204: dup
/*     */     //   205: aload_0
/*     */     //   206: invokevirtual getStartPosition : ()I
/*     */     //   209: getstatic org/springframework/expression/spel/SpelMessage.MISSING_ARRAY_DIMENSION : Lorg/springframework/expression/spel/SpelMessage;
/*     */     //   212: iconst_0
/*     */     //   213: anewarray java/lang/Object
/*     */     //   216: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*     */     //   219: athrow
/*     */     //   220: iinc #9, 1
/*     */     //   223: goto -> 182
/*     */     //   226: aload_1
/*     */     //   227: invokevirtual getEvaluationContext : ()Lorg/springframework/expression/EvaluationContext;
/*     */     //   230: invokeinterface getTypeConverter : ()Lorg/springframework/expression/TypeConverter;
/*     */     //   235: astore #7
/*     */     //   237: aload_0
/*     */     //   238: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   241: arraylength
/*     */     //   242: iconst_1
/*     */     //   243: if_icmpne -> 286
/*     */     //   246: aload_0
/*     */     //   247: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   250: iconst_0
/*     */     //   251: aaload
/*     */     //   252: aload_1
/*     */     //   253: invokevirtual getTypedValue : (Lorg/springframework/expression/spel/ExpressionState;)Lorg/springframework/expression/TypedValue;
/*     */     //   256: astore #8
/*     */     //   258: aload #7
/*     */     //   260: aload #8
/*     */     //   262: invokestatic toInt : (Lorg/springframework/expression/TypeConverter;Lorg/springframework/expression/TypedValue;)I
/*     */     //   265: istore #9
/*     */     //   267: aload_0
/*     */     //   268: iload #9
/*     */     //   270: i2l
/*     */     //   271: invokevirtual checkNumElements : (J)V
/*     */     //   274: aload #4
/*     */     //   276: iload #9
/*     */     //   278: invokestatic newInstance : (Ljava/lang/Class;I)Ljava/lang/Object;
/*     */     //   281: astore #6
/*     */     //   283: goto -> 369
/*     */     //   286: aload_0
/*     */     //   287: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   290: arraylength
/*     */     //   291: newarray int
/*     */     //   293: astore #8
/*     */     //   295: lconst_1
/*     */     //   296: lstore #9
/*     */     //   298: iconst_0
/*     */     //   299: istore #11
/*     */     //   301: iload #11
/*     */     //   303: aload_0
/*     */     //   304: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   307: arraylength
/*     */     //   308: if_icmpge -> 360
/*     */     //   311: aload_0
/*     */     //   312: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   315: iload #11
/*     */     //   317: aaload
/*     */     //   318: aload_1
/*     */     //   319: invokevirtual getTypedValue : (Lorg/springframework/expression/spel/ExpressionState;)Lorg/springframework/expression/TypedValue;
/*     */     //   322: astore #12
/*     */     //   324: aload #7
/*     */     //   326: aload #12
/*     */     //   328: invokestatic toInt : (Lorg/springframework/expression/TypeConverter;Lorg/springframework/expression/TypedValue;)I
/*     */     //   331: istore #13
/*     */     //   333: aload #8
/*     */     //   335: iload #11
/*     */     //   337: iload #13
/*     */     //   339: iastore
/*     */     //   340: lload #9
/*     */     //   342: iload #13
/*     */     //   344: i2l
/*     */     //   345: lmul
/*     */     //   346: lstore #9
/*     */     //   348: aload_0
/*     */     //   349: lload #9
/*     */     //   351: invokevirtual checkNumElements : (J)V
/*     */     //   354: iinc #11, 1
/*     */     //   357: goto -> 301
/*     */     //   360: aload #4
/*     */     //   362: aload #8
/*     */     //   364: invokestatic newInstance : (Ljava/lang/Class;[I)Ljava/lang/Object;
/*     */     //   367: astore #6
/*     */     //   369: goto -> 705
/*     */     //   372: aload_0
/*     */     //   373: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   376: ifnull -> 388
/*     */     //   379: aload_0
/*     */     //   380: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   383: arraylength
/*     */     //   384: iconst_1
/*     */     //   385: if_icmple -> 407
/*     */     //   388: new org/springframework/expression/spel/SpelEvaluationException
/*     */     //   391: dup
/*     */     //   392: aload_0
/*     */     //   393: invokevirtual getStartPosition : ()I
/*     */     //   396: getstatic org/springframework/expression/spel/SpelMessage.MULTIDIM_ARRAY_INITIALIZER_NOT_SUPPORTED : Lorg/springframework/expression/spel/SpelMessage;
/*     */     //   399: iconst_0
/*     */     //   400: anewarray java/lang/Object
/*     */     //   403: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*     */     //   406: athrow
/*     */     //   407: aload_1
/*     */     //   408: invokevirtual getEvaluationContext : ()Lorg/springframework/expression/EvaluationContext;
/*     */     //   411: invokeinterface getTypeConverter : ()Lorg/springframework/expression/TypeConverter;
/*     */     //   416: astore #7
/*     */     //   418: aload_0
/*     */     //   419: iconst_1
/*     */     //   420: invokevirtual getChild : (I)Lorg/springframework/expression/spel/SpelNode;
/*     */     //   423: checkcast org/springframework/expression/spel/ast/InlineList
/*     */     //   426: astore #8
/*     */     //   428: aload_0
/*     */     //   429: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   432: iconst_0
/*     */     //   433: aaload
/*     */     //   434: ifnull -> 487
/*     */     //   437: aload_0
/*     */     //   438: getfield dimensions : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   441: iconst_0
/*     */     //   442: aaload
/*     */     //   443: aload_1
/*     */     //   444: invokevirtual getTypedValue : (Lorg/springframework/expression/spel/ExpressionState;)Lorg/springframework/expression/TypedValue;
/*     */     //   447: astore #9
/*     */     //   449: aload #7
/*     */     //   451: aload #9
/*     */     //   453: invokestatic toInt : (Lorg/springframework/expression/TypeConverter;Lorg/springframework/expression/TypedValue;)I
/*     */     //   456: istore #10
/*     */     //   458: iload #10
/*     */     //   460: aload #8
/*     */     //   462: invokevirtual getChildCount : ()I
/*     */     //   465: if_icmpeq -> 487
/*     */     //   468: new org/springframework/expression/spel/SpelEvaluationException
/*     */     //   471: dup
/*     */     //   472: aload_0
/*     */     //   473: invokevirtual getStartPosition : ()I
/*     */     //   476: getstatic org/springframework/expression/spel/SpelMessage.INITIALIZER_LENGTH_INCORRECT : Lorg/springframework/expression/spel/SpelMessage;
/*     */     //   479: iconst_0
/*     */     //   480: anewarray java/lang/Object
/*     */     //   483: invokespecial <init> : (ILorg/springframework/expression/spel/SpelMessage;[Ljava/lang/Object;)V
/*     */     //   486: athrow
/*     */     //   487: getstatic org/springframework/expression/spel/ast/ConstructorReference$1.$SwitchMap$org$springframework$expression$spel$ast$TypeCode : [I
/*     */     //   490: aload #5
/*     */     //   492: invokevirtual ordinal : ()I
/*     */     //   495: iaload
/*     */     //   496: tableswitch default -> 685, 1 -> 548, 2 -> 565, 3 -> 580, 4 -> 595, 5 -> 610, 6 -> 625, 7 -> 640, 8 -> 655, 9 -> 670
/*     */     //   548: aload_0
/*     */     //   549: aload_1
/*     */     //   550: aload #7
/*     */     //   552: aload #8
/*     */     //   554: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   557: aload #4
/*     */     //   559: invokevirtual createReferenceTypeArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   562: goto -> 703
/*     */     //   565: aload_0
/*     */     //   566: aload_1
/*     */     //   567: aload #7
/*     */     //   569: aload #8
/*     */     //   571: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   574: invokevirtual createBooleanArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[Z
/*     */     //   577: goto -> 703
/*     */     //   580: aload_0
/*     */     //   581: aload_1
/*     */     //   582: aload #7
/*     */     //   584: aload #8
/*     */     //   586: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   589: invokevirtual createCharArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[C
/*     */     //   592: goto -> 703
/*     */     //   595: aload_0
/*     */     //   596: aload_1
/*     */     //   597: aload #7
/*     */     //   599: aload #8
/*     */     //   601: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   604: invokevirtual createByteArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[B
/*     */     //   607: goto -> 703
/*     */     //   610: aload_0
/*     */     //   611: aload_1
/*     */     //   612: aload #7
/*     */     //   614: aload #8
/*     */     //   616: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   619: invokevirtual createShortArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[S
/*     */     //   622: goto -> 703
/*     */     //   625: aload_0
/*     */     //   626: aload_1
/*     */     //   627: aload #7
/*     */     //   629: aload #8
/*     */     //   631: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   634: invokevirtual createIntArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[I
/*     */     //   637: goto -> 703
/*     */     //   640: aload_0
/*     */     //   641: aload_1
/*     */     //   642: aload #7
/*     */     //   644: aload #8
/*     */     //   646: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   649: invokevirtual createLongArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[J
/*     */     //   652: goto -> 703
/*     */     //   655: aload_0
/*     */     //   656: aload_1
/*     */     //   657: aload #7
/*     */     //   659: aload #8
/*     */     //   661: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   664: invokevirtual createFloatArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[F
/*     */     //   667: goto -> 703
/*     */     //   670: aload_0
/*     */     //   671: aload_1
/*     */     //   672: aload #7
/*     */     //   674: aload #8
/*     */     //   676: getfield children : [Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   679: invokevirtual createDoubleArray : (Lorg/springframework/expression/spel/ExpressionState;Lorg/springframework/expression/TypeConverter;[Lorg/springframework/expression/spel/ast/SpelNodeImpl;)[D
/*     */     //   682: goto -> 703
/*     */     //   685: new java/lang/IllegalStateException
/*     */     //   688: dup
/*     */     //   689: aload #5
/*     */     //   691: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   694: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   699: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   702: athrow
/*     */     //   703: astore #6
/*     */     //   705: new org/springframework/expression/TypedValue
/*     */     //   708: dup
/*     */     //   709: aload #6
/*     */     //   711: invokespecial <init> : (Ljava/lang/Object;)V
/*     */     //   714: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #264	-> 0
/*     */     //   #265	-> 12
/*     */     //   #266	-> 27
/*     */     //   #269	-> 50
/*     */     //   #268	-> 62
/*     */     //   #272	-> 70
/*     */     //   #274	-> 87
/*     */     //   #279	-> 120
/*     */     //   #280	-> 126
/*     */     //   #281	-> 134
/*     */     //   #284	-> 144
/*     */     //   #287	-> 151
/*     */     //   #288	-> 154
/*     */     //   #290	-> 161
/*     */     //   #291	-> 168
/*     */     //   #292	-> 196
/*     */     //   #293	-> 201
/*     */     //   #291	-> 220
/*     */     //   #296	-> 226
/*     */     //   #297	-> 237
/*     */     //   #299	-> 246
/*     */     //   #300	-> 258
/*     */     //   #301	-> 267
/*     */     //   #302	-> 274
/*     */     //   #303	-> 283
/*     */     //   #306	-> 286
/*     */     //   #307	-> 295
/*     */     //   #308	-> 298
/*     */     //   #309	-> 311
/*     */     //   #310	-> 324
/*     */     //   #311	-> 333
/*     */     //   #312	-> 340
/*     */     //   #313	-> 348
/*     */     //   #308	-> 354
/*     */     //   #315	-> 360
/*     */     //   #317	-> 369
/*     */     //   #321	-> 372
/*     */     //   #324	-> 388
/*     */     //   #327	-> 407
/*     */     //   #328	-> 418
/*     */     //   #330	-> 428
/*     */     //   #331	-> 437
/*     */     //   #332	-> 449
/*     */     //   #333	-> 458
/*     */     //   #334	-> 468
/*     */     //   #337	-> 487
/*     */     //   #338	-> 548
/*     */     //   #339	-> 565
/*     */     //   #340	-> 580
/*     */     //   #341	-> 595
/*     */     //   #342	-> 610
/*     */     //   #343	-> 625
/*     */     //   #344	-> 640
/*     */     //   #345	-> 655
/*     */     //   #346	-> 670
/*     */     //   #347	-> 685
/*     */     //   #350	-> 705
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   24	3	3	type	Ljava/lang/String;
/*     */     //   141	3	4	componentType	Ljava/lang/Class;
/*     */     //   196	24	10	dimension	Lorg/springframework/expression/spel/ast/SpelNodeImpl;
/*     */     //   258	25	8	o	Lorg/springframework/expression/TypedValue;
/*     */     //   267	16	9	arraySize	I
/*     */     //   324	30	12	o	Lorg/springframework/expression/TypedValue;
/*     */     //   333	21	13	arraySize	I
/*     */     //   301	59	11	d	I
/*     */     //   295	74	8	dims	[I
/*     */     //   298	71	9	numElements	J
/*     */     //   237	132	7	typeConverter	Lorg/springframework/expression/TypeConverter;
/*     */     //   449	38	9	dValue	Lorg/springframework/expression/TypedValue;
/*     */     //   458	29	10	i	I
/*     */     //   418	287	7	typeConverter	Lorg/springframework/expression/TypeConverter;
/*     */     //   428	277	8	initializer	Lorg/springframework/expression/spel/ast/InlineList;
/*     */     //   0	715	0	this	Lorg/springframework/expression/spel/ast/ConstructorReference;
/*     */     //   0	715	1	state	Lorg/springframework/expression/spel/ExpressionState;
/*     */     //   12	703	2	intendedArrayType	Ljava/lang/Object;
/*     */     //   70	645	3	type	Ljava/lang/String;
/*     */     //   151	564	4	componentType	Ljava/lang/Class;
/*     */     //   126	589	5	arrayTypeCode	Lorg/springframework/expression/spel/ast/TypeCode;
/*     */     //   154	561	6	newArray	Ljava/lang/Object;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   141	3	4	componentType	Ljava/lang/Class<*>;
/*     */     //   151	564	4	componentType	Ljava/lang/Class<*>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkNumElements(long numElements) {
/* 354 */     if (numElements >= 262144L) {
/* 355 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.MAX_ARRAY_ELEMENTS_THRESHOLD_EXCEEDED, new Object[] {
/* 356 */             Integer.valueOf(262144)
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Object createReferenceTypeArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children, Class<?> componentType) {
/* 363 */     Object[] array = (Object[])Array.newInstance(componentType, children.length);
/* 364 */     TypeDescriptor targetType = TypeDescriptor.valueOf(componentType);
/* 365 */     for (int i = 0; i < array.length; i++) {
/* 366 */       Object value = children[i].getValue(state);
/* 367 */       array[i] = typeConverter.convertValue(value, TypeDescriptor.forObject(value), targetType);
/*     */     } 
/* 369 */     return array;
/*     */   }
/*     */   
/*     */   private boolean[] createBooleanArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children) {
/* 373 */     boolean[] array = new boolean[children.length];
/* 374 */     for (int i = 0; i < array.length; i++) {
/* 375 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 376 */       array[i] = ExpressionUtils.toBoolean(typeConverter, typedValue);
/*     */     } 
/* 378 */     return array;
/*     */   }
/*     */   
/*     */   private char[] createCharArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children) {
/* 382 */     char[] array = new char[children.length];
/* 383 */     for (int i = 0; i < array.length; i++) {
/* 384 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 385 */       array[i] = ExpressionUtils.toChar(typeConverter, typedValue);
/*     */     } 
/* 387 */     return array;
/*     */   }
/*     */   
/*     */   private byte[] createByteArray(ExpressionState state, TypeConverter converter, SpelNodeImpl[] children) {
/* 391 */     byte[] array = new byte[children.length];
/* 392 */     for (int i = 0; i < array.length; i++) {
/* 393 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 394 */       array[i] = ExpressionUtils.toByte(converter, typedValue);
/*     */     } 
/* 396 */     return array;
/*     */   }
/*     */   
/*     */   private short[] createShortArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children) {
/* 400 */     short[] array = new short[children.length];
/* 401 */     for (int i = 0; i < array.length; i++) {
/* 402 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 403 */       array[i] = ExpressionUtils.toShort(typeConverter, typedValue);
/*     */     } 
/* 405 */     return array;
/*     */   }
/*     */   
/*     */   private int[] createIntArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children) {
/* 409 */     int[] array = new int[children.length];
/* 410 */     for (int i = 0; i < array.length; i++) {
/* 411 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 412 */       array[i] = ExpressionUtils.toInt(typeConverter, typedValue);
/*     */     } 
/* 414 */     return array;
/*     */   }
/*     */   
/*     */   private long[] createLongArray(ExpressionState state, TypeConverter converter, SpelNodeImpl[] children) {
/* 418 */     long[] array = new long[children.length];
/* 419 */     for (int i = 0; i < array.length; i++) {
/* 420 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 421 */       array[i] = ExpressionUtils.toLong(converter, typedValue);
/*     */     } 
/* 423 */     return array;
/*     */   }
/*     */   
/*     */   private float[] createFloatArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children) {
/* 427 */     float[] array = new float[children.length];
/* 428 */     for (int i = 0; i < array.length; i++) {
/* 429 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 430 */       array[i] = ExpressionUtils.toFloat(typeConverter, typedValue);
/*     */     } 
/* 432 */     return array;
/*     */   }
/*     */   
/*     */   private double[] createDoubleArray(ExpressionState state, TypeConverter typeConverter, SpelNodeImpl[] children) {
/* 436 */     double[] array = new double[children.length];
/* 437 */     for (int i = 0; i < array.length; i++) {
/* 438 */       TypedValue typedValue = children[i].getTypedValue(state);
/* 439 */       array[i] = ExpressionUtils.toDouble(typeConverter, typedValue);
/*     */     } 
/* 441 */     return array;
/*     */   }
/*     */   
/*     */   private boolean hasInitializer() {
/* 445 */     return (getChildCount() > 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 450 */     ConstructorExecutor constructorExecutor = this.cachedExecutor; if (constructorExecutor instanceof ReflectiveConstructorExecutor) { ReflectiveConstructorExecutor executor = (ReflectiveConstructorExecutor)constructorExecutor; if (this.exitTypeDescriptor != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 455 */         for (int i = 1; i < this.children.length; i++) {
/* 456 */           if (!this.children[i].isCompilable()) {
/* 457 */             return false;
/*     */           }
/*     */         } 
/*     */         
/* 461 */         Constructor<?> constructor = executor.getConstructor();
/* 462 */         return (Modifier.isPublic(constructor.getModifiers()) && 
/* 463 */           Modifier.isPublic(constructor.getDeclaringClass().getModifiers()));
/*     */       }  }
/*     */     
/*     */     return false;
/*     */   } public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 468 */     ReflectiveConstructorExecutor executor = (ReflectiveConstructorExecutor)this.cachedExecutor;
/* 469 */     Assert.state((executor != null), "No cached executor");
/*     */     
/* 471 */     Constructor<?> constructor = executor.getConstructor();
/* 472 */     String classDesc = constructor.getDeclaringClass().getName().replace('.', '/');
/* 473 */     mv.visitTypeInsn(187, classDesc);
/* 474 */     mv.visitInsn(89);
/*     */ 
/*     */     
/* 477 */     SpelNodeImpl[] arguments = new SpelNodeImpl[this.children.length - 1];
/* 478 */     System.arraycopy(this.children, 1, arguments, 0, this.children.length - 1);
/* 479 */     generateCodeForArguments(mv, cf, constructor, arguments);
/* 480 */     mv.visitMethodInsn(183, classDesc, "<init>", CodeFlow.createSignatureDescriptor(constructor), false);
/* 481 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\ConstructorReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */