/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Selection
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   public static final int ALL = 0;
/*     */   public static final int FIRST = 1;
/*     */   public static final int LAST = 2;
/*     */   private final int variant;
/*     */   private final boolean nullSafe;
/*     */   
/*     */   public Selection(boolean nullSafe, int variant, int startPos, int endPos, SpelNodeImpl expression) {
/*  75 */     super(startPos, endPos, new SpelNodeImpl[] { expression });
/*  76 */     this.nullSafe = nullSafe;
/*  77 */     this.variant = variant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isNullSafe() {
/*  87 */     return this.nullSafe;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  92 */     return getValueRef(state).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/*  97 */     TypedValue op = state.getActiveContextObject();
/*  98 */     Object operand = op.getValue();
/*  99 */     SpelNodeImpl selectionCriteria = this.children[0];
/*     */     
/* 101 */     if (operand instanceof Map) { Map<?, ?> mapdata = (Map<?, ?>)operand;
/* 102 */       Map<Object, Object> result = new HashMap<>();
/* 103 */       Object lastKey = null;
/*     */       
/* 105 */       for (Map.Entry<?, ?> entry : mapdata.entrySet()) {
/*     */         try {
/* 107 */           TypedValue kvPair = new TypedValue(entry);
/* 108 */           state.pushActiveContextObject(kvPair);
/* 109 */           state.enterScope();
/* 110 */           Object val = selectionCriteria.getValueInternal(state).getValue();
/* 111 */           if (val instanceof Boolean) { Boolean b = (Boolean)val;
/* 112 */             if (b.booleanValue()) {
/* 113 */               result.put(entry.getKey(), entry.getValue());
/* 114 */               if (this.variant == 1) {
/* 115 */                 return new ValueRef.TypedValueHolderValueRef(new TypedValue(result), this);
/*     */               }
/* 117 */               lastKey = entry.getKey();
/*     */             }  }
/*     */           else
/*     */           
/* 121 */           { throw new SpelEvaluationException(selectionCriteria.getStartPosition(), SpelMessage.RESULT_OF_SELECTION_CRITERIA_IS_NOT_BOOLEAN, new Object[0]); }
/*     */ 
/*     */         
/*     */         } finally {
/*     */           
/* 126 */           state.popActiveContextObject();
/* 127 */           state.exitScope();
/*     */         } 
/*     */       } 
/*     */       
/* 131 */       if ((this.variant == 1 || this.variant == 2) && result.isEmpty()) {
/* 132 */         return new ValueRef.TypedValueHolderValueRef(TypedValue.NULL, this);
/*     */       }
/*     */       
/* 135 */       if (this.variant == 2) {
/* 136 */         Map<Object, Object> resultMap = new HashMap<>();
/* 137 */         Object lastValue = result.get(lastKey);
/* 138 */         resultMap.put(lastKey, lastValue);
/* 139 */         return new ValueRef.TypedValueHolderValueRef(new TypedValue(resultMap), this);
/*     */       } 
/*     */       
/* 142 */       return new ValueRef.TypedValueHolderValueRef(new TypedValue(result), this); }
/*     */ 
/*     */     
/* 145 */     if (operand instanceof Iterable || ObjectUtils.isArray(operand)) {
/* 146 */       Iterable<?> iterable = (Iterable)operand;
/* 147 */       Iterable<?> data = (operand instanceof Iterable) ? iterable : Arrays.asList(ObjectUtils.toObjectArray(operand));
/*     */       
/* 149 */       List<Object> result = new ArrayList();
/* 150 */       for (Object element : data) {
/*     */         try {
/* 152 */           state.pushActiveContextObject(new TypedValue(element));
/* 153 */           state.enterScope();
/* 154 */           Object val = selectionCriteria.getValueInternal(state).getValue();
/* 155 */           if (val instanceof Boolean) { Boolean b = (Boolean)val;
/* 156 */             if (b.booleanValue()) {
/* 157 */               if (this.variant == 1) {
/* 158 */                 return new ValueRef.TypedValueHolderValueRef(new TypedValue(element), this);
/*     */               }
/* 160 */               result.add(element);
/*     */             }  }
/*     */           else
/*     */           
/* 164 */           { throw new SpelEvaluationException(selectionCriteria.getStartPosition(), SpelMessage.RESULT_OF_SELECTION_CRITERIA_IS_NOT_BOOLEAN, new Object[0]); }
/*     */ 
/*     */         
/*     */         } finally {
/*     */           
/* 169 */           state.exitScope();
/* 170 */           state.popActiveContextObject();
/*     */         } 
/*     */       } 
/*     */       
/* 174 */       if ((this.variant == 1 || this.variant == 2) && result.isEmpty()) {
/* 175 */         return ValueRef.NullValueRef.INSTANCE;
/*     */       }
/*     */       
/* 178 */       if (this.variant == 2) {
/* 179 */         return new ValueRef.TypedValueHolderValueRef(new TypedValue(CollectionUtils.lastElement(result)), this);
/*     */       }
/*     */       
/* 182 */       if (operand instanceof Iterable) {
/* 183 */         return new ValueRef.TypedValueHolderValueRef(new TypedValue(result), this);
/*     */       }
/*     */       
/* 186 */       Class<?> elementType = null;
/* 187 */       TypeDescriptor typeDesc = op.getTypeDescriptor();
/* 188 */       if (typeDesc != null) {
/* 189 */         TypeDescriptor elementTypeDesc = typeDesc.getElementTypeDescriptor();
/* 190 */         if (elementTypeDesc != null) {
/* 191 */           elementType = ClassUtils.resolvePrimitiveIfNecessary(elementTypeDesc.getType());
/*     */         }
/*     */       } 
/* 194 */       Assert.state((elementType != null), "Unresolvable element type");
/*     */       
/* 196 */       Object resultArray = Array.newInstance(elementType, result.size());
/* 197 */       System.arraycopy(result.toArray(), 0, resultArray, 0, result.size());
/* 198 */       return new ValueRef.TypedValueHolderValueRef(new TypedValue(resultArray), this);
/*     */     } 
/*     */     
/* 201 */     if (operand == null) {
/* 202 */       if (this.nullSafe) {
/* 203 */         return ValueRef.NullValueRef.INSTANCE;
/*     */       }
/* 205 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.INVALID_TYPE_FOR_SELECTION, new Object[] { "null" });
/*     */     } 
/*     */     
/* 208 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.INVALID_TYPE_FOR_SELECTION, new Object[] { operand
/* 209 */           .getClass().getName() });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 214 */     return prefix() + prefix() + "]";
/*     */   }
/*     */   
/*     */   private String prefix() {
/* 218 */     switch (this.variant) { case 0: case 1: case 2:  }  return 
/*     */ 
/*     */ 
/*     */       
/* 222 */       "";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Selection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */