/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompoundExpression
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   public CompoundExpression(int startPos, int endPos, SpelNodeImpl... expressionComponents) {
/*  44 */     super(startPos, endPos, expressionComponents);
/*  45 */     if (expressionComponents.length < 2) {
/*  46 */       throw new IllegalStateException("Do not build compound expressions with less than two entries: " + expressionComponents.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/*  54 */     if (getChildCount() == 1) {
/*  55 */       return this.children[0].getValueRef(state);
/*     */     }
/*     */     
/*  58 */     SpelNodeImpl nextNode = this.children[0];
/*     */     try {
/*  60 */       TypedValue result = nextNode.getValueInternal(state);
/*  61 */       int cc = getChildCount();
/*  62 */       for (int i = 1; i < cc - 1; i++) {
/*     */         
/*  64 */         try { state.pushActiveContextObject(result);
/*  65 */           nextNode = this.children[i];
/*  66 */           result = nextNode.getValueInternal(state);
/*     */ 
/*     */           
/*  69 */           state.popActiveContextObject(); } finally { state.popActiveContextObject(); }
/*     */       
/*     */       } 
/*     */       try {
/*  73 */         state.pushActiveContextObject(result);
/*  74 */         nextNode = this.children[cc - 1];
/*  75 */         return nextNode.getValueRef(state);
/*     */       } finally {
/*     */         
/*  78 */         state.popActiveContextObject();
/*     */       }
/*     */     
/*  81 */     } catch (SpelEvaluationException ex) {
/*     */       
/*  83 */       ex.setPosition(nextNode.getStartPosition());
/*  84 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  96 */     ValueRef ref = getValueRef(state);
/*  97 */     TypedValue result = ref.getValue();
/*  98 */     this.exitTypeDescriptor = (this.children[this.children.length - 1]).exitTypeDescriptor;
/*  99 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue setValueInternal(ExpressionState state, Supplier<TypedValue> valueSupplier) throws EvaluationException {
/* 106 */     TypedValue typedValue = valueSupplier.get();
/* 107 */     getValueRef(state).setValue(typedValue.getValue());
/* 108 */     return typedValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(ExpressionState state) throws EvaluationException {
/* 113 */     return getValueRef(state).isWritable();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 118 */     StringBuilder sb = new StringBuilder();
/* 119 */     for (int i = 0; i < getChildCount(); i++) {
/* 120 */       sb.append(getChild(i).toStringAST());
/* 121 */       if (i < getChildCount() - 1) {
/* 122 */         SpelNodeImpl nextChild = this.children[i + 1];
/* 123 */         if (nextChild.isNullSafe()) {
/* 124 */           sb.append("?.");
/*     */ 
/*     */         
/*     */         }
/* 128 */         else if (!(nextChild instanceof Indexer)) {
/* 129 */           sb.append('.');
/*     */         } 
/*     */       } 
/*     */     } 
/* 133 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 138 */     for (SpelNodeImpl child : this.children) {
/* 139 */       if (!child.isCompilable()) {
/* 140 */         return false;
/*     */       }
/*     */     } 
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 148 */     for (SpelNodeImpl child : this.children) {
/* 149 */       child.generateCode(mv, cf);
/*     */     }
/* 151 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\CompoundExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */