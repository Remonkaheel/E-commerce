/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.expression.spel.ExpressionState;
/*    */ import org.springframework.expression.spel.SpelEvaluationException;
/*    */ import org.springframework.expression.spel.SpelMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Assign
/*    */   extends SpelNodeImpl
/*    */ {
/*    */   public Assign(int startPos, int endPos, SpelNodeImpl... operands) {
/* 38 */     super(startPos, endPos, operands);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 44 */     if (!state.getEvaluationContext().isAssignmentEnabled()) {
/* 45 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.NOT_ASSIGNABLE, new Object[] { toStringAST() });
/*    */     }
/* 47 */     return this.children[0].setValueInternal(state, () -> this.children[1].getValueInternal(state));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toStringAST() {
/* 52 */     return getChild(0).toStringAST() + "=" + getChild(0).toStringAST();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Assign.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */