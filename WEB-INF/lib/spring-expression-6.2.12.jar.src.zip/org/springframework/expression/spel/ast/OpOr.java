/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ import org.springframework.lang.Contract;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpOr
/*     */   extends Operator
/*     */ {
/*     */   public OpOr(int startPos, int endPos, SpelNodeImpl... operands) {
/*  41 */     super("or", startPos, endPos, operands);
/*  42 */     this.exitTypeDescriptor = "Z";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  48 */     if (getBooleanValue(state, getLeftOperand()))
/*     */     {
/*  50 */       return BooleanTypedValue.TRUE;
/*     */     }
/*  52 */     return BooleanTypedValue.forValue(getBooleanValue(state, getRightOperand()));
/*     */   }
/*     */   
/*     */   private boolean getBooleanValue(ExpressionState state, SpelNodeImpl operand) {
/*     */     try {
/*  57 */       Boolean value = operand.<Boolean>getValue(state, Boolean.class);
/*  58 */       assertValueNotNull(value);
/*  59 */       return value.booleanValue();
/*     */     }
/*  61 */     catch (SpelEvaluationException ee) {
/*  62 */       ee.setPosition(operand.getStartPosition());
/*  63 */       throw ee;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Contract("null -> fail")
/*     */   private void assertValueNotNull(@Nullable Boolean value) {
/*  69 */     if (value == null) {
/*  70 */       throw new SpelEvaluationException(SpelMessage.TYPE_CONVERSION_ERROR, new Object[] { "null", "boolean" });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  76 */     SpelNodeImpl left = getLeftOperand();
/*  77 */     SpelNodeImpl right = getRightOperand();
/*  78 */     return (left.isCompilable() && right.isCompilable() && 
/*  79 */       CodeFlow.isBooleanCompatible(left.exitTypeDescriptor) && 
/*  80 */       CodeFlow.isBooleanCompatible(right.exitTypeDescriptor));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  86 */     Label elseTarget = new Label();
/*  87 */     Label endOfIf = new Label();
/*  88 */     cf.enterCompilationScope();
/*  89 */     getLeftOperand().generateCode(mv, cf);
/*  90 */     cf.unboxBooleanIfNecessary(mv);
/*  91 */     cf.exitCompilationScope();
/*  92 */     mv.visitJumpInsn(153, elseTarget);
/*  93 */     mv.visitLdcInsn(Integer.valueOf(1));
/*  94 */     mv.visitJumpInsn(167, endOfIf);
/*  95 */     mv.visitLabel(elseTarget);
/*  96 */     cf.enterCompilationScope();
/*  97 */     getRightOperand().generateCode(mv, cf);
/*  98 */     cf.unboxBooleanIfNecessary(mv);
/*  99 */     cf.exitCompilationScope();
/* 100 */     mv.visitLabel(endOfIf);
/* 101 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpOr.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */