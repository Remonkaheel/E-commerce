/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompilablePropertyAccessor;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.ReflectivePropertyAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyOrFieldReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final boolean nullSafe;
/*     */   private final String name;
/*     */   @Nullable
/*     */   private String originalPrimitiveExitTypeDescriptor;
/*     */   @Nullable
/*     */   private volatile PropertyAccessor cachedReadAccessor;
/*     */   @Nullable
/*     */   private volatile PropertyAccessor cachedWriteAccessor;
/*     */   
/*     */   public PropertyOrFieldReference(boolean nullSafe, String propertyOrFieldName, int startPos, int endPos) {
/*  70 */     super(startPos, endPos, new SpelNodeImpl[0]);
/*  71 */     this.nullSafe = nullSafe;
/*  72 */     this.name = propertyOrFieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNullSafe() {
/*  81 */     return this.nullSafe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  88 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/*  94 */     return new AccessorValueRef(this, state.getActiveContextObject(), state.getEvaluationContext(), state
/*  95 */         .getConfiguration().isAutoGrowNullReferences());
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 100 */     TypedValue tv = getValueInternal(state.getActiveContextObject(), state.getEvaluationContext(), state
/* 101 */         .getConfiguration().isAutoGrowNullReferences());
/* 102 */     PropertyAccessor accessorToUse = this.cachedReadAccessor;
/* 103 */     if (accessorToUse instanceof CompilablePropertyAccessor) { CompilablePropertyAccessor compilablePropertyAccessor = (CompilablePropertyAccessor)accessorToUse;
/* 104 */       setExitTypeDescriptor(CodeFlow.toDescriptor(compilablePropertyAccessor.getPropertyType())); }
/*     */     
/* 106 */     return tv;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue getValueInternal(TypedValue contextObject, EvaluationContext evalContext, boolean isAutoGrowNullReferences) throws EvaluationException {
/* 112 */     TypedValue result = readProperty(contextObject, evalContext, this.name);
/*     */ 
/*     */     
/* 115 */     if (result.getValue() == null && isAutoGrowNullReferences && 
/* 116 */       nextChildIs(new Class[] { Indexer.class, PropertyOrFieldReference.class })) {
/* 117 */       TypeDescriptor resultDescriptor = result.getTypeDescriptor();
/* 118 */       Assert.state((resultDescriptor != null), "No result type");
/*     */       
/* 120 */       if (List.class == resultDescriptor.getType()) {
/* 121 */         if (isWritableProperty(this.name, contextObject, evalContext)) {
/* 122 */           List<?> newList = new ArrayList();
/* 123 */           writeProperty(contextObject, evalContext, this.name, newList);
/* 124 */           result = readProperty(contextObject, evalContext, this.name);
/*     */         }
/*     */       
/* 127 */       } else if (Map.class == resultDescriptor.getType()) {
/* 128 */         if (isWritableProperty(this.name, contextObject, evalContext)) {
/* 129 */           Map<?, ?> newMap = new HashMap<>();
/* 130 */           writeProperty(contextObject, evalContext, this.name, newMap);
/* 131 */           result = readProperty(contextObject, evalContext, this.name);
/*     */         } 
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 137 */           if (isWritableProperty(this.name, contextObject, evalContext)) {
/* 138 */             Class<?> clazz = resultDescriptor.getType();
/* 139 */             Object newObject = ReflectionUtils.accessibleConstructor(clazz, new Class[0]).newInstance(new Object[0]);
/* 140 */             writeProperty(contextObject, evalContext, this.name, newObject);
/* 141 */             result = readProperty(contextObject, evalContext, this.name);
/*     */           }
/*     */         
/* 144 */         } catch (InvocationTargetException ex) {
/* 145 */           throw new SpelEvaluationException(getStartPosition(), ex.getTargetException(), SpelMessage.UNABLE_TO_DYNAMICALLY_CREATE_OBJECT, new Object[] { resultDescriptor
/* 146 */                 .getType() });
/*     */         }
/* 148 */         catch (Throwable ex) {
/* 149 */           throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.UNABLE_TO_DYNAMICALLY_CREATE_OBJECT, new Object[] { resultDescriptor
/* 150 */                 .getType() });
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue setValueInternal(ExpressionState state, Supplier<TypedValue> valueSupplier) throws EvaluationException {
/* 161 */     TypedValue typedValue = valueSupplier.get();
/* 162 */     writeProperty(state.getActiveContextObject(), state.getEvaluationContext(), this.name, typedValue.getValue());
/* 163 */     return typedValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(ExpressionState state) throws EvaluationException {
/* 168 */     return isWritableProperty(this.name, state.getActiveContextObject(), state.getEvaluationContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 173 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue readProperty(TypedValue contextObject, EvaluationContext evalContext, String name) throws EvaluationException {
/* 184 */     Object targetObject = contextObject.getValue();
/* 185 */     if (targetObject == null && isNullSafe()) {
/* 186 */       return TypedValue.NULL;
/*     */     }
/*     */     
/* 189 */     PropertyAccessor accessorToUse = this.cachedReadAccessor;
/* 190 */     if (accessorToUse != null) {
/* 191 */       if (evalContext.getPropertyAccessors().contains(accessorToUse)) {
/*     */         try {
/* 193 */           return accessorToUse.read(evalContext, targetObject, name);
/*     */         }
/* 195 */         catch (Exception exception) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 200 */       this.cachedReadAccessor = null;
/*     */     } 
/*     */ 
/*     */     
/* 204 */     List<PropertyAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(targetObject, evalContext.getPropertyAccessors());
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 209 */       for (PropertyAccessor accessor : accessorsToTry) {
/* 210 */         if (accessor.canRead(evalContext, targetObject, name)) {
/* 211 */           if (accessor instanceof ReflectivePropertyAccessor) { ReflectivePropertyAccessor reflectivePropertyAccessor = (ReflectivePropertyAccessor)accessor;
/* 212 */             accessor = reflectivePropertyAccessor.createOptimalAccessor(evalContext, targetObject, name); }
/*     */ 
/*     */           
/* 215 */           this.cachedReadAccessor = accessor;
/* 216 */           return accessor.read(evalContext, targetObject, name);
/*     */         }
/*     */       
/*     */       } 
/* 220 */     } catch (Exception ex) {
/* 221 */       throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_DURING_PROPERTY_READ, new Object[] { name, ex.getMessage() });
/*     */     } 
/*     */     
/* 224 */     if (contextObject.getValue() == null) {
/* 225 */       throw new SpelEvaluationException(SpelMessage.PROPERTY_OR_FIELD_NOT_READABLE_ON_NULL, new Object[] { name });
/*     */     }
/*     */     
/* 228 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.PROPERTY_OR_FIELD_NOT_READABLE, new Object[] { name, 
/* 229 */           FormatHelper.formatClassNameForMessage(getObjectClass(contextObject.getValue())) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeProperty(TypedValue contextObject, EvaluationContext evalContext, String name, @Nullable Object newValue) throws EvaluationException {
/* 237 */     Object targetObject = contextObject.getValue();
/* 238 */     if (targetObject == null) {
/* 239 */       if (isNullSafe()) {
/*     */         return;
/*     */       }
/* 242 */       throw new SpelEvaluationException(
/* 243 */           getStartPosition(), SpelMessage.PROPERTY_OR_FIELD_NOT_WRITABLE_ON_NULL, new Object[] { name });
/*     */     } 
/*     */     
/* 246 */     PropertyAccessor accessorToUse = this.cachedWriteAccessor;
/* 247 */     if (accessorToUse != null) {
/* 248 */       if (evalContext.getPropertyAccessors().contains(accessorToUse)) {
/*     */         try {
/* 250 */           accessorToUse.write(evalContext, targetObject, name, newValue);
/*     */           
/*     */           return;
/* 253 */         } catch (Exception exception) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 258 */       this.cachedWriteAccessor = null;
/*     */     } 
/*     */ 
/*     */     
/* 262 */     List<PropertyAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(targetObject, evalContext.getPropertyAccessors());
/*     */     try {
/* 264 */       for (PropertyAccessor accessor : accessorsToTry) {
/* 265 */         if (accessor.canWrite(evalContext, targetObject, name)) {
/* 266 */           this.cachedWriteAccessor = accessor;
/* 267 */           accessor.write(evalContext, targetObject, name, newValue);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 272 */     } catch (AccessException ex) {
/* 273 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_PROPERTY_WRITE, new Object[] { name, ex
/* 274 */             .getMessage() });
/*     */     } 
/*     */     
/* 277 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.PROPERTY_OR_FIELD_NOT_WRITABLE, new Object[] { name, 
/* 278 */           FormatHelper.formatClassNameForMessage(getObjectClass(targetObject)) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritableProperty(String name, TypedValue contextObject, EvaluationContext evalContext) throws EvaluationException {
/* 284 */     Object targetObject = contextObject.getValue();
/* 285 */     if (targetObject != null) {
/*     */       
/* 287 */       List<PropertyAccessor> accessorsToTry = AccessorUtils.getAccessorsToTry(targetObject, evalContext.getPropertyAccessors());
/* 288 */       for (PropertyAccessor accessor : accessorsToTry) {
/*     */         try {
/* 290 */           if (accessor.canWrite(evalContext, targetObject, name)) {
/* 291 */             return true;
/*     */           }
/*     */         }
/* 294 */         catch (AccessException accessException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 299 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 304 */     PropertyAccessor propertyAccessor = this.cachedReadAccessor; if (propertyAccessor instanceof CompilablePropertyAccessor) { CompilablePropertyAccessor compilablePropertyAccessor = (CompilablePropertyAccessor)propertyAccessor; if (compilablePropertyAccessor
/* 305 */         .isCompilable()); }
/*     */     
/*     */     return false;
/*     */   } public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*     */     CompilablePropertyAccessor compilablePropertyAccessor;
/* 310 */     PropertyAccessor accessorToUse = this.cachedReadAccessor;
/* 311 */     if (accessorToUse instanceof CompilablePropertyAccessor) { compilablePropertyAccessor = (CompilablePropertyAccessor)accessorToUse; }
/* 312 */     else { throw new IllegalStateException("Property accessor is not compilable: " + String.valueOf(accessorToUse)); }
/*     */ 
/*     */     
/* 315 */     Label skipIfNull = null;
/* 316 */     if (isNullSafe()) {
/* 317 */       mv.visitInsn(89);
/* 318 */       skipIfNull = new Label();
/* 319 */       Label continueLabel = new Label();
/* 320 */       mv.visitJumpInsn(199, continueLabel);
/* 321 */       CodeFlow.insertCheckCast(mv, this.exitTypeDescriptor);
/* 322 */       mv.visitJumpInsn(167, skipIfNull);
/* 323 */       mv.visitLabel(continueLabel);
/*     */     } 
/*     */     
/* 326 */     compilablePropertyAccessor.generateCode(this.name, mv, cf);
/* 327 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */     
/* 329 */     if (this.originalPrimitiveExitTypeDescriptor != null)
/*     */     {
/*     */ 
/*     */       
/* 333 */       CodeFlow.insertBoxIfNecessary(mv, this.originalPrimitiveExitTypeDescriptor);
/*     */     }
/* 335 */     if (skipIfNull != null) {
/* 336 */       mv.visitLabel(skipIfNull);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setExitTypeDescriptor(String descriptor) {
/* 344 */     if (isNullSafe() && CodeFlow.isPrimitive(descriptor)) {
/* 345 */       this.originalPrimitiveExitTypeDescriptor = descriptor;
/* 346 */       this.exitTypeDescriptor = CodeFlow.toBoxedDescriptor(descriptor);
/*     */     } else {
/*     */       
/* 349 */       this.exitTypeDescriptor = descriptor;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AccessorValueRef
/*     */     implements ValueRef
/*     */   {
/*     */     private final PropertyOrFieldReference ref;
/*     */     
/*     */     private final TypedValue contextObject;
/*     */     
/*     */     private final EvaluationContext evalContext;
/*     */     
/*     */     private final boolean autoGrowNullReferences;
/*     */ 
/*     */     
/*     */     public AccessorValueRef(PropertyOrFieldReference propertyOrFieldReference, TypedValue activeContextObject, EvaluationContext evalContext, boolean autoGrowNullReferences) {
/* 367 */       this.ref = propertyOrFieldReference;
/* 368 */       this.contextObject = activeContextObject;
/* 369 */       this.evalContext = evalContext;
/* 370 */       this.autoGrowNullReferences = autoGrowNullReferences;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TypedValue getValue() {
/* 376 */       TypedValue value = this.ref.getValueInternal(this.contextObject, this.evalContext, this.autoGrowNullReferences);
/* 377 */       PropertyAccessor propertyAccessor = this.ref.cachedReadAccessor; if (propertyAccessor instanceof CompilablePropertyAccessor) { CompilablePropertyAccessor compilablePropertyAccessor = (CompilablePropertyAccessor)propertyAccessor;
/* 378 */         this.ref.setExitTypeDescriptor(CodeFlow.toDescriptor(compilablePropertyAccessor.getPropertyType())); }
/*     */       
/* 380 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(@Nullable Object newValue) {
/* 385 */       this.ref.writeProperty(this.contextObject, this.evalContext, this.ref.name, newValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWritable() {
/* 390 */       return this.ref.isWritableProperty(this.ref.name, this.contextObject, this.evalContext);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\PropertyOrFieldReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */