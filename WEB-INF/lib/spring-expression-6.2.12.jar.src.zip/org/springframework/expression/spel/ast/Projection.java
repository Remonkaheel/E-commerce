/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Projection
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final boolean nullSafe;
/*     */   
/*     */   public Projection(boolean nullSafe, int startPos, int endPos, SpelNodeImpl expression) {
/*  53 */     super(startPos, endPos, new SpelNodeImpl[] { expression });
/*  54 */     this.nullSafe = nullSafe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isNullSafe() {
/*  64 */     return this.nullSafe;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  69 */     return getValueRef(state).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/*  74 */     TypedValue op = state.getActiveContextObject();
/*  75 */     Object operand = op.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     if (operand instanceof Map) { Map<?, ?> mapData = (Map<?, ?>)operand;
/*  82 */       List<Object> result = new ArrayList();
/*  83 */       for (Map.Entry<?, ?> entry : mapData.entrySet()) {
/*     */         try {
/*  85 */           state.pushActiveContextObject(new TypedValue(entry));
/*  86 */           state.enterScope();
/*  87 */           result.add(this.children[0].getValueInternal(state).getValue());
/*     */         } finally {
/*     */           
/*  90 */           state.popActiveContextObject();
/*  91 */           state.exitScope();
/*     */         } 
/*     */       } 
/*  94 */       return new ValueRef.TypedValueHolderValueRef(new TypedValue(result), this); }
/*     */ 
/*     */     
/*  97 */     boolean operandIsArray = ObjectUtils.isArray(operand);
/*  98 */     if (operand instanceof Iterable || operandIsArray) {
/*  99 */       Iterable<?> iterable = (Iterable)operand;
/* 100 */       Iterable<?> data = (operand instanceof Iterable) ? iterable : Arrays.asList(ObjectUtils.toObjectArray(operand));
/*     */       
/* 102 */       List<Object> result = new ArrayList();
/* 103 */       Class<?> arrayElementType = null;
/* 104 */       for (Object element : data) {
/*     */         try {
/* 106 */           state.pushActiveContextObject(new TypedValue(element));
/* 107 */           state.enterScope();
/* 108 */           Object value = this.children[0].getValueInternal(state).getValue();
/* 109 */           if (value != null && operandIsArray) {
/* 110 */             arrayElementType = determineCommonType(arrayElementType, value.getClass());
/*     */           }
/* 112 */           result.add(value);
/*     */         } finally {
/*     */           
/* 115 */           state.exitScope();
/* 116 */           state.popActiveContextObject();
/*     */         } 
/*     */       } 
/*     */       
/* 120 */       if (operandIsArray) {
/* 121 */         if (arrayElementType == null) {
/* 122 */           arrayElementType = Object.class;
/*     */         }
/* 124 */         Object resultArray = Array.newInstance(arrayElementType, result.size());
/* 125 */         System.arraycopy(result.toArray(), 0, resultArray, 0, result.size());
/* 126 */         return new ValueRef.TypedValueHolderValueRef(new TypedValue(resultArray), this);
/*     */       } 
/*     */       
/* 129 */       return new ValueRef.TypedValueHolderValueRef(new TypedValue(result), this);
/*     */     } 
/*     */     
/* 132 */     if (operand == null) {
/* 133 */       if (this.nullSafe) {
/* 134 */         return ValueRef.NullValueRef.INSTANCE;
/*     */       }
/* 136 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.PROJECTION_NOT_SUPPORTED_ON_TYPE, new Object[] { "null" });
/*     */     } 
/*     */     
/* 139 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.PROJECTION_NOT_SUPPORTED_ON_TYPE, new Object[] { operand
/* 140 */           .getClass().getName() });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 145 */     return "![" + getChild(0).toStringAST() + "]";
/*     */   }
/*     */   
/*     */   private Class<?> determineCommonType(@Nullable Class<?> oldType, Class<?> newType) {
/* 149 */     if (oldType == null) {
/* 150 */       return newType;
/*     */     }
/* 152 */     if (oldType.isAssignableFrom(newType)) {
/* 153 */       return oldType;
/*     */     }
/* 155 */     Class<?> nextType = newType;
/* 156 */     while (nextType != Object.class) {
/* 157 */       if (nextType.isAssignableFrom(oldType)) {
/* 158 */         return nextType;
/*     */       }
/* 160 */       nextType = nextType.getSuperclass();
/*     */     } 
/* 162 */     for (Class<?> nextInterface : (Iterable<Class<?>>)ClassUtils.getAllInterfacesForClassAsSet(newType)) {
/* 163 */       if (nextInterface.isAssignableFrom(oldType)) {
/* 164 */         return nextInterface;
/*     */       }
/*     */     } 
/* 167 */     return Object.class;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Projection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */