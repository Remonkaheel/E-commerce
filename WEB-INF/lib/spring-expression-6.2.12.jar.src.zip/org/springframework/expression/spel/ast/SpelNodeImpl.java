/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Opcodes;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.common.ExpressionUtils;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpelNodeImpl
/*     */   implements SpelNode, Opcodes
/*     */ {
/*  51 */   private static final SpelNodeImpl[] NO_CHILDREN = new SpelNodeImpl[0];
/*     */ 
/*     */   
/*     */   private final int startPos;
/*     */   
/*     */   private final int endPos;
/*     */   
/*  58 */   protected SpelNodeImpl[] children = NO_CHILDREN;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SpelNodeImpl parent;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected volatile String exitTypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelNodeImpl(int startPos, int endPos, @Nullable SpelNodeImpl... operands) {
/*  77 */     this.startPos = startPos;
/*  78 */     this.endPos = endPos;
/*  79 */     if (!ObjectUtils.isEmpty((Object[])operands)) {
/*  80 */       this.children = operands;
/*  81 */       for (SpelNodeImpl operand : operands) {
/*  82 */         Assert.notNull(operand, "Operand must not be null");
/*  83 */         operand.parent = this;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean nextChildIs(Class<?>... classes) {
/*  93 */     if (this.parent != null) {
/*  94 */       SpelNodeImpl[] peers = this.parent.children;
/*  95 */       for (int i = 0, max = peers.length; i < max; i++) {
/*  96 */         if (this == peers[i]) {
/*  97 */           if (i + 1 >= max) {
/*  98 */             return false;
/*     */           }
/* 100 */           Class<?> peerClass = peers[i + 1].getClass();
/* 101 */           for (Class<?> desiredClass : classes) {
/* 102 */             if (peerClass == desiredClass) {
/* 103 */               return true;
/*     */             }
/*     */           } 
/* 106 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Object getValue(ExpressionState expressionState) throws EvaluationException {
/* 116 */     return getValueInternal(expressionState).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypedValue getTypedValue(ExpressionState expressionState) throws EvaluationException {
/* 121 */     return getValueInternal(expressionState);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable(ExpressionState expressionState) throws EvaluationException {
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(ExpressionState expressionState, @Nullable Object newValue) throws EvaluationException {
/* 132 */     setValueInternal(expressionState, () -> new TypedValue(newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue setValueInternal(ExpressionState expressionState, Supplier<TypedValue> valueSupplier) throws EvaluationException {
/* 154 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.SETVALUE_NOT_SUPPORTED, new Object[] { getClass().getName() });
/*     */   }
/*     */ 
/*     */   
/*     */   public SpelNode getChild(int index) {
/* 159 */     return this.children[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 164 */     return this.children.length;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectClass(@Nullable Object obj) {
/* 170 */     if (obj == null) {
/* 171 */       return null;
/*     */     }
/* 173 */     Class<?> clazz = (Class)obj; return (obj instanceof Class) ? clazz : obj.getClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStartPosition() {
/* 178 */     return this.startPos;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEndPosition() {
/* 183 */     return this.endPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNullSafe() {
/* 193 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getExitDescriptor() {
/* 198 */     return this.exitTypeDescriptor;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected final <T> T getValue(ExpressionState state, Class<T> desiredReturnType) throws EvaluationException {
/* 203 */     return (T)ExpressionUtils.convertTypedValue(state.getEvaluationContext(), getValueInternal(state), desiredReturnType);
/*     */   }
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/* 207 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.NOT_ASSIGNABLE, new Object[] { toStringAST() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2")
/*     */   protected static void generateCodeForArguments(MethodVisitor mv, CodeFlow cf, Member member, SpelNodeImpl[] arguments) {
/* 230 */     if (member instanceof Executable) { Executable executable = (Executable)member;
/* 231 */       generateCodeForArguments(mv, cf, executable, arguments); }
/*     */     
/* 233 */     throw new IllegalArgumentException("The supplied member must be an instance of java.lang.reflect.Executable: " + String.valueOf(member));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void generateCodeForArguments(MethodVisitor mv, CodeFlow cf, Executable executable, SpelNodeImpl[] arguments) {
/* 254 */     Class<?>[] parameterTypes = executable.getParameterTypes();
/* 255 */     String[] parameterDescriptors = CodeFlow.toDescriptors(parameterTypes);
/* 256 */     int parameterCount = parameterTypes.length;
/*     */     
/* 258 */     if (executable.isVarArgs()) {
/*     */ 
/*     */ 
/*     */       
/* 262 */       int varargsIndex = parameterCount - 1;
/* 263 */       int argumentCount = arguments.length;
/* 264 */       int p = 0;
/*     */ 
/*     */       
/* 267 */       for (p = 0; p < varargsIndex; p++) {
/* 268 */         cf.generateCodeForArgument(mv, arguments[p], parameterDescriptors[p]);
/*     */       }
/*     */       
/* 271 */       SpelNodeImpl lastArgument = (argumentCount != 0) ? arguments[argumentCount - 1] : null;
/* 272 */       ClassLoader classLoader = executable.getDeclaringClass().getClassLoader();
/*     */       
/* 274 */       Class<?> lastArgumentType = (lastArgument != null) ? loadClassForExitDescriptor(lastArgument.getExitDescriptor(), classLoader) : null;
/* 275 */       Class<?> lastParameterType = parameterTypes[varargsIndex];
/*     */ 
/*     */ 
/*     */       
/* 279 */       if (lastArgument != null && lastArgumentType != null && lastParameterType.isAssignableFrom(lastArgumentType)) {
/* 280 */         cf.generateCodeForArgument(mv, lastArgument, parameterDescriptors[p]);
/*     */       } else {
/*     */         
/* 283 */         String arrayComponentType = parameterDescriptors[varargsIndex];
/*     */         
/* 285 */         arrayComponentType = arrayComponentType.substring(1);
/*     */         
/* 287 */         CodeFlow.insertNewArrayCode(mv, argumentCount - p, arrayComponentType);
/*     */         
/* 289 */         int arrayIndex = 0;
/* 290 */         while (p < argumentCount) {
/* 291 */           mv.visitInsn(89);
/* 292 */           CodeFlow.insertOptimalLoad(mv, arrayIndex++);
/* 293 */           cf.generateCodeForArgument(mv, arguments[p++], arrayComponentType);
/* 294 */           CodeFlow.insertArrayStore(mv, arrayComponentType);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 299 */       for (int i = 0; i < parameterCount; i++) {
/* 300 */         cf.generateCodeForArgument(mv, arguments[i], parameterDescriptors[i]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static Class<?> loadClassForExitDescriptor(@Nullable String exitDescriptor, ClassLoader classLoader) {
/* 307 */     if (!StringUtils.hasText(exitDescriptor)) {
/* 308 */       return null;
/*     */     }
/* 310 */     String typeDescriptor = exitDescriptor;
/*     */ 
/*     */     
/* 313 */     if (typeDescriptor.length() > 1) {
/* 314 */       typeDescriptor = typeDescriptor + ";";
/*     */     }
/* 316 */     String className = Type.getType(typeDescriptor).getClassName();
/* 317 */     return ClassUtils.resolveClassName(className, classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2")
/*     */   protected static void generateCodeForArgument(MethodVisitor mv, CodeFlow cf, SpelNodeImpl argument, String paramDesc) {
/* 330 */     cf.generateCodeForArgument(mv, argument, paramDesc);
/*     */   }
/*     */   
/*     */   public abstract TypedValue getValueInternal(ExpressionState paramExpressionState) throws EvaluationException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\SpelNodeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */