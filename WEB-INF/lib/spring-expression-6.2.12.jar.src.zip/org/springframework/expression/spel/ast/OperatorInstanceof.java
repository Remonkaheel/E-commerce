/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OperatorInstanceof
/*     */   extends Operator
/*     */ {
/*     */   @Nullable
/*     */   private Class<?> type;
/*     */   
/*     */   public OperatorInstanceof(int startPos, int endPos, SpelNodeImpl... operands) {
/*  45 */     super("instanceof", startPos, endPos, operands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*     */     BooleanTypedValue result;
/*     */     Class<?> rightClass;
/*  59 */     SpelNodeImpl rightOperand = getRightOperand();
/*  60 */     TypedValue left = getLeftOperand().getValueInternal(state);
/*  61 */     TypedValue right = rightOperand.getValueInternal(state);
/*  62 */     Object leftValue = left.getValue();
/*  63 */     Object rightValue = right.getValue();
/*     */     
/*  65 */     if (rightValue instanceof Class) { rightClass = (Class)rightValue; }
/*  66 */     else { throw new SpelEvaluationException(getRightOperand().getStartPosition(), SpelMessage.INSTANCEOF_OPERATOR_NEEDS_CLASS_OPERAND, new Object[] {
/*     */             
/*  68 */             (rightValue == null) ? "null" : rightValue.getClass().getName() }); }
/*     */     
/*  70 */     if (leftValue == null) {
/*  71 */       result = BooleanTypedValue.FALSE;
/*     */     } else {
/*     */       
/*  74 */       result = BooleanTypedValue.forValue(rightClass.isAssignableFrom(leftValue.getClass()));
/*     */     } 
/*  76 */     this.type = rightClass;
/*  77 */     if (rightOperand instanceof TypeReference)
/*     */     {
/*     */       
/*  80 */       this.exitTypeDescriptor = "Z";
/*     */     }
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  87 */     return (this.exitTypeDescriptor != null && getLeftOperand().isCompilable());
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  92 */     getLeftOperand().generateCode(mv, cf);
/*  93 */     CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor());
/*  94 */     Assert.state((this.type != null), "No type available");
/*  95 */     if (this.type.isPrimitive()) {
/*     */ 
/*     */       
/*  98 */       mv.visitInsn(87);
/*  99 */       mv.visitInsn(3);
/*     */     } else {
/*     */       
/* 102 */       mv.visitTypeInsn(193, Type.getInternalName(this.type));
/*     */     } 
/* 104 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OperatorInstanceof.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */