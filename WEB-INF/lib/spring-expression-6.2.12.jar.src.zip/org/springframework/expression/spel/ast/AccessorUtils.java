/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.expression.TargetedAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AccessorUtils
/*     */ {
/*     */   static <T extends TargetedAccessor> List<T> getAccessorsToTry(@Nullable Object targetObject, List<T> accessors) {
/*  51 */     Class<?> targetType = (targetObject != null) ? targetObject.getClass() : null;
/*  52 */     return getAccessorsToTry(targetType, accessors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends TargetedAccessor> List<T> getAccessorsToTry(@Nullable Class<?> targetType, List<T> accessors) {
/*  79 */     if (accessors.isEmpty()) {
/*  80 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  83 */     List<T> exactMatches = new ArrayList<>();
/*  84 */     List<T> inexactMatches = new ArrayList<>();
/*  85 */     List<T> genericMatches = new ArrayList<>();
/*  86 */     for (TargetedAccessor targetedAccessor : accessors) {
/*  87 */       Class<?>[] targets = targetedAccessor.getSpecificTargetClasses();
/*  88 */       if (ObjectUtils.isEmpty((Object[])targets)) {
/*     */         
/*  90 */         genericMatches.add((T)targetedAccessor); continue;
/*     */       } 
/*  92 */       if (targetType != null) {
/*  93 */         for (Class<?> clazz : targets) {
/*  94 */           if (clazz == targetType) {
/*  95 */             exactMatches.add((T)targetedAccessor);
/*     */           }
/*  97 */           else if (clazz.isAssignableFrom(targetType)) {
/*  98 */             inexactMatches.add((T)targetedAccessor);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 104 */     int size = exactMatches.size() + inexactMatches.size() + genericMatches.size();
/* 105 */     if (size == 0) {
/* 106 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 109 */     List<T> result = new ArrayList<>(size);
/* 110 */     result.addAll(exactMatches);
/* 111 */     result.addAll(inexactMatches);
/* 112 */     result.addAll(genericMatches);
/* 113 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\AccessorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */