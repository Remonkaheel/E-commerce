/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import org.springframework.asm.MethodVisitor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.expression.spel.CodeFlow;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringLiteral
/*    */   extends Literal
/*    */ {
/*    */   private final TypedValue value;
/*    */   
/*    */   public StringLiteral(String payload, int startPos, int endPos, String value) {
/* 38 */     super(payload, startPos, endPos);
/*    */ 
/*    */     
/* 41 */     char quoteCharacter = value.charAt(0);
/*    */ 
/*    */     
/* 44 */     String valueWithinQuotes = value.substring(1, value.length() - 1);
/*    */ 
/*    */     
/* 47 */     if (quoteCharacter == '\'') {
/* 48 */       valueWithinQuotes = StringUtils.replace(valueWithinQuotes, "''", "'");
/*    */     } else {
/*    */       
/* 51 */       valueWithinQuotes = StringUtils.replace(valueWithinQuotes, "\"\"", "\"");
/*    */     } 
/*    */     
/* 54 */     this.value = new TypedValue(valueWithinQuotes);
/* 55 */     this.exitTypeDescriptor = "Ljava/lang/String";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypedValue getLiteralValue() {
/* 61 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     String ast = String.valueOf(getLiteralValue().getValue());
/* 67 */     ast = StringUtils.replace(ast, "'", "''");
/* 68 */     return "'" + ast + "'";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCompilable() {
/* 73 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 78 */     mv.visitLdcInsn(this.value.getValue());
/* 79 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\StringLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */