/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypedValueHolderValueRef
/*     */   implements ValueRef
/*     */ {
/*     */   private final TypedValue typedValue;
/*     */   private final SpelNodeImpl node;
/*     */   
/*     */   public TypedValueHolderValueRef(TypedValue typedValue, SpelNodeImpl node) {
/*  95 */     this.typedValue = typedValue;
/*  96 */     this.node = node;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValue() {
/* 101 */     return this.typedValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable Object newValue) {
/* 106 */     throw new SpelEvaluationException(this.node
/* 107 */         .getStartPosition(), SpelMessage.NOT_ASSIGNABLE, new Object[] { this.node.toStringAST() });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 112 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\ValueRef$TypedValueHolderValueRef.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */