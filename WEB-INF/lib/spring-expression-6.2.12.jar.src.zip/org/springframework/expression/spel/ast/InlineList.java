/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.StringJoiner;
/*     */ import org.springframework.asm.ClassWriter;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InlineList
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   @Nullable
/*     */   private final TypedValue constant;
/*     */   
/*     */   public InlineList(int startPos, int endPos, SpelNodeImpl... args) {
/*  50 */     super(startPos, endPos, args);
/*  51 */     this.constant = computeConstantValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypedValue computeConstantValue() {
/*  63 */     for (int c = 0, max = getChildCount(); c < max; c++) {
/*  64 */       SpelNode child = getChild(c);
/*  65 */       if (!(child instanceof Literal)) {
/*  66 */         if (child instanceof InlineList) { InlineList inlineList = (InlineList)child;
/*  67 */           if (!inlineList.isConstant()) {
/*  68 */             return null;
/*     */           } }
/*     */         
/*  71 */         else if (child instanceof OpMinus) { OpMinus opMinus = (OpMinus)child; if (!opMinus.isNegativeNumberLiteral())
/*  72 */             return null;  } else { return null; }
/*     */       
/*     */       }
/*     */     } 
/*     */     
/*  77 */     List<Object> constantList = new ArrayList();
/*  78 */     int childcount = getChildCount();
/*  79 */     ExpressionState expressionState = new ExpressionState((EvaluationContext)new StandardEvaluationContext());
/*  80 */     for (int i = 0; i < childcount; i++) {
/*  81 */       SpelNode child = getChild(i);
/*  82 */       if (child instanceof Literal) { Literal literal = (Literal)child;
/*  83 */         constantList.add(literal.getLiteralValue().getValue()); }
/*     */       
/*  85 */       else if (child instanceof InlineList) { InlineList inlineList = (InlineList)child;
/*  86 */         constantList.add(inlineList.getConstantValue()); }
/*     */       
/*  88 */       else if (child instanceof OpMinus)
/*  89 */       { constantList.add(child.getValue(expressionState)); }
/*     */     
/*     */     } 
/*  92 */     return new TypedValue(Collections.unmodifiableList(constantList));
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState expressionState) throws EvaluationException {
/*  97 */     if (this.constant != null) {
/*  98 */       return this.constant;
/*     */     }
/*     */     
/* 101 */     int childCount = getChildCount();
/* 102 */     List<Object> returnValue = new ArrayList(childCount);
/* 103 */     for (int c = 0; c < childCount; c++) {
/* 104 */       returnValue.add(getChild(c).getValue(expressionState));
/*     */     }
/* 106 */     return new TypedValue(returnValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 112 */     StringJoiner sj = new StringJoiner(",", "{", "}");
/*     */     
/* 114 */     for (int c = 0; c < getChildCount(); c++) {
/* 115 */       sj.add(getChild(c).toStringAST());
/*     */     }
/* 117 */     return sj.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConstant() {
/* 124 */     return (this.constant != null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<Object> getConstantValue() {
/* 130 */     Assert.state((this.constant != null), "No constant");
/* 131 */     return (List<Object>)this.constant.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 136 */     return isConstant();
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow codeflow) {
/* 141 */     String constantFieldName = "inlineList$" + codeflow.nextFieldId();
/* 142 */     String className = codeflow.getClassName();
/*     */     
/* 144 */     codeflow.registerNewField((cw, cflow) -> cw.visitField(26, constantFieldName, "Ljava/util/List;", null, null));
/*     */ 
/*     */     
/* 147 */     codeflow.registerNewClinit((mVisitor, cflow) -> generateClinitCode(className, constantFieldName, mVisitor, cflow, false));
/*     */ 
/*     */     
/* 150 */     mv.visitFieldInsn(178, className, constantFieldName, "Ljava/util/List;");
/* 151 */     codeflow.pushDescriptor("Ljava/util/List");
/*     */   }
/*     */   
/*     */   void generateClinitCode(String clazzname, String constantFieldName, MethodVisitor mv, CodeFlow codeflow, boolean nested) {
/* 155 */     mv.visitTypeInsn(187, "java/util/ArrayList");
/* 156 */     mv.visitInsn(89);
/* 157 */     mv.visitMethodInsn(183, "java/util/ArrayList", "<init>", "()V", false);
/* 158 */     if (!nested) {
/* 159 */       mv.visitFieldInsn(179, clazzname, constantFieldName, "Ljava/util/List;");
/*     */     }
/* 161 */     int childCount = getChildCount();
/* 162 */     for (int c = 0; c < childCount; c++) {
/* 163 */       if (!nested) {
/* 164 */         mv.visitFieldInsn(178, clazzname, constantFieldName, "Ljava/util/List;");
/*     */       } else {
/*     */         
/* 167 */         mv.visitInsn(89);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 172 */       SpelNodeImpl spelNodeImpl = this.children[c]; if (spelNodeImpl instanceof InlineList) { InlineList inlineList = (InlineList)spelNodeImpl;
/* 173 */         inlineList.generateClinitCode(clazzname, constantFieldName, mv, codeflow, true); }
/*     */       else
/*     */       
/* 176 */       { this.children[c].generateCode(mv, codeflow);
/* 177 */         String lastDesc = codeflow.lastDescriptor();
/* 178 */         if (CodeFlow.isPrimitive(lastDesc)) {
/* 179 */           CodeFlow.insertBoxIfNecessary(mv, lastDesc.charAt(0));
/*     */         } }
/*     */       
/* 182 */       mv.visitMethodInsn(185, "java/util/List", "add", "(Ljava/lang/Object;)Z", true);
/* 183 */       mv.visitInsn(87);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\InlineList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */