/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Locale;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final int dimensions;
/*     */   @Nullable
/*     */   private transient Class<?> type;
/*     */   
/*     */   public TypeReference(int startPos, int endPos, SpelNodeImpl qualifiedId) {
/*  47 */     this(startPos, endPos, qualifiedId, 0);
/*     */   }
/*     */   
/*     */   public TypeReference(int startPos, int endPos, SpelNodeImpl qualifiedId, int dims) {
/*  51 */     super(startPos, endPos, new SpelNodeImpl[] { qualifiedId });
/*  52 */     this.dimensions = dims;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  59 */     String typeName = (String)this.children[0].getValueInternal(state).getValue();
/*  60 */     Assert.state((typeName != null), "No type name");
/*  61 */     if (!typeName.contains(".") && Character.isLowerCase(typeName.charAt(0))) {
/*  62 */       TypeCode tc = TypeCode.valueOf(typeName.toUpperCase(Locale.ROOT));
/*  63 */       if (tc != TypeCode.OBJECT) {
/*     */         
/*  65 */         Class<?> clazz1 = makeArrayIfNecessary(tc.getType());
/*  66 */         this.exitTypeDescriptor = "Ljava/lang/Class";
/*  67 */         this.type = clazz1;
/*  68 */         return new TypedValue(clazz1);
/*     */       } 
/*     */     } 
/*  71 */     Class<?> clazz = state.findType(typeName);
/*  72 */     clazz = makeArrayIfNecessary(clazz);
/*  73 */     this.exitTypeDescriptor = "Ljava/lang/Class";
/*  74 */     this.type = clazz;
/*  75 */     return new TypedValue(clazz);
/*     */   }
/*     */   
/*     */   private Class<?> makeArrayIfNecessary(Class<?> clazz) {
/*  79 */     if (this.dimensions < 1) {
/*  80 */       return clazz;
/*     */     }
/*  82 */     int[] dims = new int[this.dimensions];
/*  83 */     Object array = Array.newInstance(clazz, dims);
/*  84 */     return array.getClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/*  89 */     StringBuilder sb = new StringBuilder("T(");
/*  90 */     sb.append(getChild(0).toStringAST());
/*  91 */     sb.append("[]".repeat(this.dimensions));
/*  92 */     sb.append(')');
/*  93 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  98 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 104 */     Assert.state((this.type != null), "No type available");
/* 105 */     if (this.type.isPrimitive()) {
/* 106 */       if (this.type == boolean.class) {
/* 107 */         mv.visitFieldInsn(178, "java/lang/Boolean", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 109 */       else if (this.type == byte.class) {
/* 110 */         mv.visitFieldInsn(178, "java/lang/Byte", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 112 */       else if (this.type == char.class) {
/* 113 */         mv.visitFieldInsn(178, "java/lang/Character", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 115 */       else if (this.type == double.class) {
/* 116 */         mv.visitFieldInsn(178, "java/lang/Double", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 118 */       else if (this.type == float.class) {
/* 119 */         mv.visitFieldInsn(178, "java/lang/Float", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 121 */       else if (this.type == int.class) {
/* 122 */         mv.visitFieldInsn(178, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 124 */       else if (this.type == long.class) {
/* 125 */         mv.visitFieldInsn(178, "java/lang/Long", "TYPE", "Ljava/lang/Class;");
/*     */       }
/* 127 */       else if (this.type == short.class) {
/* 128 */         mv.visitFieldInsn(178, "java/lang/Short", "TYPE", "Ljava/lang/Class;");
/*     */       } 
/*     */     } else {
/*     */       
/* 132 */       mv.visitLdcInsn(Type.getType(this.type));
/*     */     } 
/* 134 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\TypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */