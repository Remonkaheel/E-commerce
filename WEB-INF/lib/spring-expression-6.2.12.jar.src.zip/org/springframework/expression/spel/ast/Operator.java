/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.NumberUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Operator
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final String operatorName;
/*     */   @Nullable
/*     */   protected String leftActualDescriptor;
/*     */   @Nullable
/*     */   protected String rightActualDescriptor;
/*     */   
/*     */   public Operator(String payload, int startPos, int endPos, SpelNodeImpl... operands) {
/*  58 */     super(startPos, endPos, operands);
/*  59 */     this.operatorName = payload;
/*     */   }
/*     */ 
/*     */   
/*     */   public SpelNodeImpl getLeftOperand() {
/*  64 */     return this.children[0];
/*     */   }
/*     */   
/*     */   public SpelNodeImpl getRightOperand() {
/*  68 */     return this.children[1];
/*     */   }
/*     */   
/*     */   public final String getOperatorName() {
/*  72 */     return this.operatorName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/*  81 */     StringBuilder sb = new StringBuilder("(");
/*  82 */     sb.append(getChild(0).toStringAST());
/*  83 */     for (int i = 1; i < getChildCount(); i++) {
/*  84 */       sb.append(' ').append(getOperatorName()).append(' ');
/*  85 */       sb.append(getChild(i).toStringAST());
/*     */     } 
/*  87 */     sb.append(')');
/*  88 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCompilableOperatorUsingNumerics() {
/*  93 */     SpelNodeImpl left = getLeftOperand();
/*  94 */     SpelNodeImpl right = getRightOperand();
/*  95 */     if (!left.isCompilable() || !right.isCompilable()) {
/*  96 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 100 */     String leftDesc = left.exitTypeDescriptor;
/* 101 */     String rightDesc = right.exitTypeDescriptor;
/* 102 */     DescriptorComparison dc = DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/* 104 */     return (dc.areNumbers && dc.areCompatible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateComparisonCode(MethodVisitor mv, CodeFlow cf, int compInstruction1, int compInstruction2) {
/* 112 */     SpelNodeImpl left = getLeftOperand();
/* 113 */     SpelNodeImpl right = getRightOperand();
/* 114 */     String leftDesc = left.exitTypeDescriptor;
/* 115 */     String rightDesc = right.exitTypeDescriptor;
/* 116 */     Label elseTarget = new Label();
/* 117 */     Label endOfIf = new Label();
/* 118 */     boolean unboxLeft = !CodeFlow.isPrimitive(leftDesc);
/* 119 */     boolean unboxRight = !CodeFlow.isPrimitive(rightDesc);
/* 120 */     DescriptorComparison dc = DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/* 122 */     char targetType = dc.compatibleType;
/*     */     
/* 124 */     cf.enterCompilationScope();
/* 125 */     left.generateCode(mv, cf);
/* 126 */     cf.exitCompilationScope();
/* 127 */     if (CodeFlow.isPrimitive(leftDesc)) {
/* 128 */       CodeFlow.insertBoxIfNecessary(mv, leftDesc);
/* 129 */       unboxLeft = true;
/*     */     } 
/*     */     
/* 132 */     cf.enterCompilationScope();
/* 133 */     right.generateCode(mv, cf);
/* 134 */     cf.exitCompilationScope();
/* 135 */     if (CodeFlow.isPrimitive(rightDesc)) {
/* 136 */       CodeFlow.insertBoxIfNecessary(mv, rightDesc);
/* 137 */       unboxRight = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 142 */     Label rightIsNonNull = new Label();
/* 143 */     mv.visitInsn(89);
/* 144 */     mv.visitJumpInsn(199, rightIsNonNull);
/*     */     
/* 146 */     mv.visitInsn(95);
/* 147 */     Label leftNotNullRightIsNull = new Label();
/* 148 */     mv.visitJumpInsn(199, leftNotNullRightIsNull);
/*     */     
/* 150 */     mv.visitInsn(87);
/*     */     
/* 152 */     switch (compInstruction1) {
/*     */       case 156:
/*     */       case 158:
/* 155 */         mv.visitInsn(3);
/*     */         break;
/*     */       case 155:
/*     */       case 157:
/* 159 */         mv.visitInsn(4);
/*     */         break;
/*     */       default:
/* 162 */         throw new IllegalStateException("Unsupported: " + compInstruction1);
/*     */     } 
/* 164 */     mv.visitJumpInsn(167, endOfIf);
/* 165 */     mv.visitLabel(leftNotNullRightIsNull);
/*     */     
/* 167 */     mv.visitInsn(87);
/*     */     
/* 169 */     switch (compInstruction1) {
/*     */       case 156:
/*     */       case 157:
/* 172 */         mv.visitInsn(3);
/*     */         break;
/*     */       case 155:
/*     */       case 158:
/* 176 */         mv.visitInsn(4);
/*     */         break;
/*     */       default:
/* 179 */         throw new IllegalStateException("Unsupported: " + compInstruction1);
/*     */     } 
/* 181 */     mv.visitJumpInsn(167, endOfIf);
/*     */     
/* 183 */     mv.visitLabel(rightIsNonNull);
/*     */     
/* 185 */     mv.visitInsn(95);
/* 186 */     mv.visitInsn(89);
/* 187 */     Label neitherRightNorLeftAreNull = new Label();
/* 188 */     mv.visitJumpInsn(199, neitherRightNorLeftAreNull);
/*     */     
/* 190 */     mv.visitInsn(88);
/* 191 */     switch (compInstruction1) {
/*     */       case 156:
/*     */       case 157:
/* 194 */         mv.visitInsn(4);
/*     */         break;
/*     */       case 155:
/*     */       case 158:
/* 198 */         mv.visitInsn(3);
/*     */         break;
/*     */       default:
/* 201 */         throw new IllegalStateException("Unsupported: " + compInstruction1);
/*     */     } 
/* 203 */     mv.visitJumpInsn(167, endOfIf);
/* 204 */     mv.visitLabel(neitherRightNorLeftAreNull);
/*     */     
/* 206 */     if (unboxLeft) {
/* 207 */       CodeFlow.insertUnboxInsns(mv, targetType, leftDesc);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (targetType == 'D' || targetType == 'J') {
/* 213 */       mv.visitInsn(93);
/* 214 */       mv.visitInsn(88);
/*     */     } else {
/*     */       
/* 217 */       mv.visitInsn(95);
/*     */     } 
/*     */     
/* 220 */     if (unboxRight) {
/* 221 */       CodeFlow.insertUnboxInsns(mv, targetType, rightDesc);
/*     */     }
/*     */ 
/*     */     
/* 225 */     if (targetType == 'D') {
/* 226 */       mv.visitInsn(152);
/* 227 */       mv.visitJumpInsn(compInstruction1, elseTarget);
/*     */     }
/* 229 */     else if (targetType == 'F') {
/* 230 */       mv.visitInsn(150);
/* 231 */       mv.visitJumpInsn(compInstruction1, elseTarget);
/*     */     }
/* 233 */     else if (targetType == 'J') {
/* 234 */       mv.visitInsn(148);
/* 235 */       mv.visitJumpInsn(compInstruction1, elseTarget);
/*     */     }
/* 237 */     else if (targetType == 'I') {
/* 238 */       mv.visitJumpInsn(compInstruction2, elseTarget);
/*     */     } else {
/*     */       
/* 241 */       throw new IllegalStateException("Unexpected descriptor " + leftDesc);
/*     */     } 
/*     */ 
/*     */     
/* 245 */     mv.visitInsn(4);
/* 246 */     mv.visitJumpInsn(167, endOfIf);
/* 247 */     mv.visitLabel(elseTarget);
/* 248 */     mv.visitInsn(3);
/* 249 */     mv.visitLabel(endOfIf);
/* 250 */     cf.pushDescriptor("Z");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalityCheck(EvaluationContext context, @Nullable Object left, @Nullable Object right) {
/* 264 */     if (left instanceof Number) { Number leftNumber = (Number)left; if (right instanceof Number) { Number rightNumber = (Number)right;
/* 265 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/* 266 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/* 267 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/* 268 */           return (leftBigDecimal.compareTo(rightBigDecimal) == 0);
/*     */         } 
/* 270 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/* 271 */           return (leftNumber.doubleValue() == rightNumber.doubleValue());
/*     */         }
/* 273 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/* 274 */           return (leftNumber.floatValue() == rightNumber.floatValue());
/*     */         }
/* 276 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/* 277 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/* 278 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/* 279 */           return (leftBigInteger.compareTo(rightBigInteger) == 0);
/*     */         } 
/* 281 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/* 282 */           return (leftNumber.longValue() == rightNumber.longValue());
/*     */         }
/* 284 */         if (leftNumber instanceof Integer || rightNumber instanceof Integer) {
/* 285 */           return (leftNumber.intValue() == rightNumber.intValue());
/*     */         }
/* 287 */         if (leftNumber instanceof Short || rightNumber instanceof Short) {
/* 288 */           return (leftNumber.shortValue() == rightNumber.shortValue());
/*     */         }
/* 290 */         if (leftNumber instanceof Byte || rightNumber instanceof Byte) {
/* 291 */           return (leftNumber.byteValue() == rightNumber.byteValue());
/*     */         }
/*     */ 
/*     */         
/* 295 */         return (leftNumber.doubleValue() == rightNumber.doubleValue()); }
/*     */        }
/*     */ 
/*     */     
/* 299 */     if (left instanceof CharSequence && right instanceof CharSequence) {
/* 300 */       return left.toString().equals(right.toString());
/*     */     }
/*     */     
/* 303 */     if (left instanceof Boolean && right instanceof Boolean) {
/* 304 */       return left.equals(right);
/*     */     }
/*     */     
/* 307 */     if (ObjectUtils.nullSafeEquals(left, right)) {
/* 308 */       return true;
/*     */     }
/*     */     
/* 311 */     if (context.getTypeComparator().canCompare(left, right)) {
/* 312 */       return (context.getTypeComparator().compare(left, right) == 0);
/*     */     }
/*     */     
/* 315 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class DescriptorComparison
/*     */   {
/* 325 */     static final DescriptorComparison NOT_NUMBERS = new DescriptorComparison(false, false, ' ');
/*     */     
/* 327 */     static final DescriptorComparison INCOMPATIBLE_NUMBERS = new DescriptorComparison(true, false, ' ');
/*     */     
/*     */     final boolean areNumbers;
/*     */     
/*     */     final boolean areCompatible;
/*     */     
/*     */     final char compatibleType;
/*     */     
/*     */     private DescriptorComparison(boolean areNumbers, boolean areCompatible, char compatibleType) {
/* 336 */       this.areNumbers = areNumbers;
/* 337 */       this.areCompatible = areCompatible;
/* 338 */       this.compatibleType = compatibleType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static DescriptorComparison checkNumericCompatibility(@Nullable String leftDeclaredDescriptor, @Nullable String rightDeclaredDescriptor, @Nullable String leftActualDescriptor, @Nullable String rightActualDescriptor) {
/* 360 */       String ld = leftDeclaredDescriptor;
/* 361 */       String rd = rightDeclaredDescriptor;
/*     */       
/* 363 */       boolean leftNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(ld);
/* 364 */       boolean rightNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(rd);
/*     */ 
/*     */       
/* 367 */       if (!leftNumeric && !ObjectUtils.nullSafeEquals(ld, leftActualDescriptor)) {
/* 368 */         ld = leftActualDescriptor;
/* 369 */         leftNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(ld);
/*     */       } 
/* 371 */       if (!rightNumeric && !ObjectUtils.nullSafeEquals(rd, rightActualDescriptor)) {
/* 372 */         rd = rightActualDescriptor;
/* 373 */         rightNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(rd);
/*     */       } 
/*     */       
/* 376 */       if (leftNumeric && rightNumeric) {
/* 377 */         if (CodeFlow.areBoxingCompatible(ld, rd)) {
/* 378 */           return new DescriptorComparison(true, true, CodeFlow.toPrimitiveTargetDesc(ld));
/*     */         }
/*     */         
/* 381 */         return INCOMPATIBLE_NUMBERS;
/*     */       } 
/*     */ 
/*     */       
/* 385 */       return NOT_NUMBERS;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Operator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */