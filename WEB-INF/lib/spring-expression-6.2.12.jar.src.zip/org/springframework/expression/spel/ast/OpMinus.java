/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpMinus
/*     */   extends Operator
/*     */ {
/*     */   public OpMinus(int startPos, int endPos, SpelNodeImpl... operands) {
/*  53 */     super("-", startPos, endPos, operands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNegativeNumberLiteral() {
/*  64 */     if (this.children.length == 1) { SpelNodeImpl spelNodeImpl = this.children[0]; if (spelNodeImpl instanceof Literal) { Literal literal = (Literal)spelNodeImpl; if (literal
/*  65 */           .isNumberLiteral()); }
/*     */        }
/*     */     
/*     */     return false;
/*     */   } public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  70 */     SpelNodeImpl leftOp = getLeftOperand();
/*     */     
/*  72 */     if (this.children.length < 2) {
/*  73 */       Object operand = leftOp.getValueInternal(state).getValue();
/*  74 */       if (operand instanceof Number) { Number number = (Number)operand;
/*  75 */         if (number instanceof BigDecimal) { BigDecimal bigDecimal = (BigDecimal)number;
/*  76 */           return new TypedValue(bigDecimal.negate()); }
/*     */         
/*  78 */         if (number instanceof BigInteger) { BigInteger bigInteger = (BigInteger)number;
/*  79 */           return new TypedValue(bigInteger.negate()); }
/*     */         
/*  81 */         if (number instanceof Double) {
/*  82 */           this.exitTypeDescriptor = "D";
/*  83 */           return new TypedValue(Double.valueOf(0.0D - number.doubleValue()));
/*     */         } 
/*  85 */         if (number instanceof Float) {
/*  86 */           this.exitTypeDescriptor = "F";
/*  87 */           return new TypedValue(Float.valueOf(0.0F - number.floatValue()));
/*     */         } 
/*  89 */         if (number instanceof Long) {
/*  90 */           this.exitTypeDescriptor = "J";
/*  91 */           return new TypedValue(Long.valueOf(0L - number.longValue()));
/*     */         } 
/*  93 */         if (number instanceof Integer) {
/*  94 */           this.exitTypeDescriptor = "I";
/*  95 */           return new TypedValue(Integer.valueOf(0 - number.intValue()));
/*     */         } 
/*  97 */         if (number instanceof Short) {
/*  98 */           return new TypedValue(Integer.valueOf(0 - number.shortValue()));
/*     */         }
/* 100 */         if (number instanceof Byte) {
/* 101 */           return new TypedValue(Integer.valueOf(0 - number.byteValue()));
/*     */         }
/*     */ 
/*     */         
/* 105 */         return new TypedValue(Double.valueOf(0.0D - number.doubleValue())); }
/*     */ 
/*     */       
/* 108 */       return state.operate(Operation.SUBTRACT, operand, null);
/*     */     } 
/*     */     
/* 111 */     Object left = leftOp.getValueInternal(state).getValue();
/* 112 */     Object right = getRightOperand().getValueInternal(state).getValue();
/*     */     
/* 114 */     if (left instanceof Number) { Number leftNumber = (Number)left; if (right instanceof Number) { Number rightNumber = (Number)right;
/* 115 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/* 116 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/* 117 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/* 118 */           return new TypedValue(leftBigDecimal.subtract(rightBigDecimal));
/*     */         } 
/* 120 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/* 121 */           this.exitTypeDescriptor = "D";
/* 122 */           return new TypedValue(Double.valueOf(leftNumber.doubleValue() - rightNumber.doubleValue()));
/*     */         } 
/* 124 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/* 125 */           this.exitTypeDescriptor = "F";
/* 126 */           return new TypedValue(Float.valueOf(leftNumber.floatValue() - rightNumber.floatValue()));
/*     */         } 
/* 128 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/* 129 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/* 130 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/* 131 */           return new TypedValue(leftBigInteger.subtract(rightBigInteger));
/*     */         } 
/* 133 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/* 134 */           this.exitTypeDescriptor = "J";
/* 135 */           return new TypedValue(Long.valueOf(leftNumber.longValue() - rightNumber.longValue()));
/*     */         } 
/* 137 */         if (CodeFlow.isIntegerForNumericOp(leftNumber) || CodeFlow.isIntegerForNumericOp(rightNumber)) {
/* 138 */           this.exitTypeDescriptor = "I";
/* 139 */           return new TypedValue(Integer.valueOf(leftNumber.intValue() - rightNumber.intValue()));
/*     */         } 
/*     */ 
/*     */         
/* 143 */         return new TypedValue(Double.valueOf(leftNumber.doubleValue() - rightNumber.doubleValue())); }
/*     */        }
/*     */ 
/*     */     
/* 147 */     if (left instanceof String) { String theString = (String)left; if (right instanceof Integer) { Integer theInteger = (Integer)right; if (theString.length() == 1)
/*     */         {
/* 149 */           return new TypedValue(Character.toString((char)(theString.charAt(0) - theInteger.intValue()))); }  }
/*     */        }
/*     */     
/* 152 */     return state.operate(Operation.SUBTRACT, left, right);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 157 */     if (this.children.length < 2) {
/* 158 */       return "-" + getLeftOperand().toStringAST();
/*     */     }
/* 160 */     return super.toStringAST();
/*     */   }
/*     */ 
/*     */   
/*     */   public SpelNodeImpl getRightOperand() {
/* 165 */     if (this.children.length < 2) {
/* 166 */       throw new IllegalStateException("No right operand");
/*     */     }
/* 168 */     return this.children[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 173 */     if (!getLeftOperand().isCompilable()) {
/* 174 */       return false;
/*     */     }
/* 176 */     if (this.children.length > 1 && 
/* 177 */       !getRightOperand().isCompilable()) {
/* 178 */       return false;
/*     */     }
/*     */     
/* 181 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 186 */     getLeftOperand().generateCode(mv, cf);
/* 187 */     String leftDesc = (getLeftOperand()).exitTypeDescriptor;
/* 188 */     String exitDesc = this.exitTypeDescriptor;
/* 189 */     Assert.state((exitDesc != null), "No exit type descriptor");
/* 190 */     char targetDesc = exitDesc.charAt(0);
/* 191 */     CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, leftDesc, targetDesc);
/* 192 */     if (this.children.length > 1) {
/* 193 */       cf.enterCompilationScope();
/* 194 */       getRightOperand().generateCode(mv, cf);
/* 195 */       String rightDesc = (getRightOperand()).exitTypeDescriptor;
/* 196 */       cf.exitCompilationScope();
/* 197 */       CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, rightDesc, targetDesc);
/* 198 */       switch (targetDesc) { case 'I':
/* 199 */           mv.visitInsn(100); break;
/* 200 */         case 'J': mv.visitInsn(101); break;
/* 201 */         case 'F': mv.visitInsn(102); break;
/* 202 */         case 'D': mv.visitInsn(103); break;
/* 203 */         default: throw new IllegalStateException("Unrecognized exit type descriptor: '" + this.exitTypeDescriptor + "'"); }
/*     */ 
/*     */ 
/*     */     
/*     */     } else {
/* 208 */       switch (targetDesc) { case 'I':
/* 209 */           mv.visitInsn(116); break;
/* 210 */         case 'J': mv.visitInsn(117); break;
/* 211 */         case 'F': mv.visitInsn(118); break;
/* 212 */         case 'D': mv.visitInsn(119); break;
/* 213 */         default: throw new IllegalStateException("Unrecognized exit type descriptor: '" + this.exitTypeDescriptor + "'"); }
/*     */ 
/*     */     
/*     */     } 
/* 217 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpMinus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */