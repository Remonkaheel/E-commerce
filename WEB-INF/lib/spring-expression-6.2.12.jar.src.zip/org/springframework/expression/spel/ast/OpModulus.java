/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpModulus
/*     */   extends Operator
/*     */ {
/*     */   public OpModulus(int startPos, int endPos, SpelNodeImpl... operands) {
/*  42 */     super("%", startPos, endPos, operands);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  48 */     Object leftOperand = getLeftOperand().getValueInternal(state).getValue();
/*  49 */     Object rightOperand = getRightOperand().getValueInternal(state).getValue();
/*     */     
/*  51 */     if (leftOperand instanceof Number) { Number leftNumber = (Number)leftOperand; if (rightOperand instanceof Number) { Number rightNumber = (Number)rightOperand;
/*  52 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/*  53 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/*  54 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/*  55 */           return new TypedValue(leftBigDecimal.remainder(rightBigDecimal));
/*     */         } 
/*  57 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/*  58 */           this.exitTypeDescriptor = "D";
/*  59 */           return new TypedValue(Double.valueOf(leftNumber.doubleValue() % rightNumber.doubleValue()));
/*     */         } 
/*  61 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/*  62 */           this.exitTypeDescriptor = "F";
/*  63 */           return new TypedValue(Float.valueOf(leftNumber.floatValue() % rightNumber.floatValue()));
/*     */         } 
/*  65 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/*  66 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/*  67 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/*  68 */           return new TypedValue(leftBigInteger.remainder(rightBigInteger));
/*     */         } 
/*  70 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/*  71 */           this.exitTypeDescriptor = "J";
/*  72 */           return new TypedValue(Long.valueOf(leftNumber.longValue() % rightNumber.longValue()));
/*     */         } 
/*  74 */         if (CodeFlow.isIntegerForNumericOp(leftNumber) || CodeFlow.isIntegerForNumericOp(rightNumber)) {
/*  75 */           this.exitTypeDescriptor = "I";
/*  76 */           return new TypedValue(Integer.valueOf(leftNumber.intValue() % rightNumber.intValue()));
/*     */         } 
/*     */ 
/*     */         
/*  80 */         return new TypedValue(Double.valueOf(leftNumber.doubleValue() % rightNumber.doubleValue())); }
/*     */        }
/*     */ 
/*     */     
/*  84 */     return state.operate(Operation.MODULUS, leftOperand, rightOperand);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  89 */     if (!getLeftOperand().isCompilable()) {
/*  90 */       return false;
/*     */     }
/*  92 */     if (this.children.length > 1 && 
/*  93 */       !getRightOperand().isCompilable()) {
/*  94 */       return false;
/*     */     }
/*     */     
/*  97 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 102 */     getLeftOperand().generateCode(mv, cf);
/* 103 */     String leftDesc = (getLeftOperand()).exitTypeDescriptor;
/* 104 */     String exitDesc = this.exitTypeDescriptor;
/* 105 */     Assert.state((exitDesc != null), "No exit type descriptor");
/* 106 */     char targetDesc = exitDesc.charAt(0);
/* 107 */     CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, leftDesc, targetDesc);
/* 108 */     if (this.children.length > 1) {
/* 109 */       cf.enterCompilationScope();
/* 110 */       getRightOperand().generateCode(mv, cf);
/* 111 */       String rightDesc = (getRightOperand()).exitTypeDescriptor;
/* 112 */       cf.exitCompilationScope();
/* 113 */       CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, rightDesc, targetDesc);
/* 114 */       switch (targetDesc) { case 'I':
/* 115 */           mv.visitInsn(112); break;
/* 116 */         case 'J': mv.visitInsn(113); break;
/* 117 */         case 'F': mv.visitInsn(114); break;
/* 118 */         case 'D': mv.visitInsn(115); break;
/* 119 */         default: throw new IllegalStateException("Unrecognized exit type descriptor: '" + this.exitTypeDescriptor + "'"); }
/*     */ 
/*     */     
/*     */     } 
/* 123 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpModulus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */