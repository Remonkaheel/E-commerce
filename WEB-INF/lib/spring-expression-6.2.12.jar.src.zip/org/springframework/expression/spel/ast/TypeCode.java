/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TypeCode
/*     */ {
/*  31 */   OBJECT(Object.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   BOOLEAN(boolean.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   CHAR(char.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   BYTE(byte.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   SHORT(short.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   INT(int.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   LONG(long.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   FLOAT(float.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   DOUBLE(double.class);
/*     */ 
/*     */   
/*     */   private final Class<?> type;
/*     */ 
/*     */   
/*     */   TypeCode(Class<?> type) {
/*  78 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/*  83 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static TypeCode forName(String name) {
/*  88 */     for (TypeCode typeCode : values()) {
/*  89 */       if (typeCode.name().equalsIgnoreCase(name)) {
/*  90 */         return typeCode;
/*     */       }
/*     */     } 
/*  93 */     return OBJECT;
/*     */   }
/*     */   
/*     */   public static TypeCode forClass(Class<?> clazz) {
/*  97 */     for (TypeCode typeCode : values()) {
/*  98 */       if (typeCode.getType() == clazz) {
/*  99 */         return typeCode;
/*     */       }
/*     */     } 
/* 102 */     return OBJECT;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\TypeCode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */