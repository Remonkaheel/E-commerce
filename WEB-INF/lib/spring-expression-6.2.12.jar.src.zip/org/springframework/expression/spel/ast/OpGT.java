/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpGT
/*     */   extends Operator
/*     */ {
/*     */   public OpGT(int startPos, int endPos, SpelNodeImpl... operands) {
/*  40 */     super(">", startPos, endPos, operands);
/*  41 */     this.exitTypeDescriptor = "Z";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  47 */     Object left = getLeftOperand().getValueInternal(state).getValue();
/*  48 */     Object right = getRightOperand().getValueInternal(state).getValue();
/*     */     
/*  50 */     this.leftActualDescriptor = CodeFlow.toDescriptorFromObject(left);
/*  51 */     this.rightActualDescriptor = CodeFlow.toDescriptorFromObject(right);
/*     */     
/*  53 */     if (left instanceof Number) { Number leftNumber = (Number)left; if (right instanceof Number) { Number rightNumber = (Number)right;
/*  54 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/*  55 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/*  56 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/*  57 */           return BooleanTypedValue.forValue((leftBigDecimal.compareTo(rightBigDecimal) > 0));
/*     */         } 
/*  59 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/*  60 */           return BooleanTypedValue.forValue((leftNumber.doubleValue() > rightNumber.doubleValue()));
/*     */         }
/*  62 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/*  63 */           return BooleanTypedValue.forValue((leftNumber.floatValue() > rightNumber.floatValue()));
/*     */         }
/*  65 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/*  66 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/*  67 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/*  68 */           return BooleanTypedValue.forValue((leftBigInteger.compareTo(rightBigInteger) > 0));
/*     */         } 
/*  70 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/*  71 */           return BooleanTypedValue.forValue((leftNumber.longValue() > rightNumber.longValue()));
/*     */         }
/*  73 */         if (leftNumber instanceof Integer || rightNumber instanceof Integer) {
/*  74 */           return BooleanTypedValue.forValue((leftNumber.intValue() > rightNumber.intValue()));
/*     */         }
/*  76 */         if (leftNumber instanceof Short || rightNumber instanceof Short) {
/*  77 */           return BooleanTypedValue.forValue((leftNumber.shortValue() > rightNumber.shortValue()));
/*     */         }
/*  79 */         if (leftNumber instanceof Byte || rightNumber instanceof Byte) {
/*  80 */           return BooleanTypedValue.forValue((leftNumber.byteValue() > rightNumber.byteValue()));
/*     */         }
/*     */ 
/*     */         
/*  84 */         return BooleanTypedValue.forValue((leftNumber.doubleValue() > rightNumber.doubleValue())); }
/*     */        }
/*     */ 
/*     */     
/*  88 */     if (left instanceof CharSequence && right instanceof CharSequence) {
/*  89 */       left = left.toString();
/*  90 */       right = right.toString();
/*     */     } 
/*     */     
/*  93 */     return BooleanTypedValue.forValue((state.getTypeComparator().compare(left, right) > 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  98 */     return isCompilableOperatorUsingNumerics();
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 103 */     generateComparisonCode(mv, cf, 158, 164);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpGT.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */