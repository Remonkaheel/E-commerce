/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpNE
/*     */   extends Operator
/*     */ {
/*     */   public OpNE(int startPos, int endPos, SpelNodeImpl... operands) {
/*  36 */     super("!=", startPos, endPos, operands);
/*  37 */     this.exitTypeDescriptor = "Z";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  43 */     Object leftValue = getLeftOperand().getValueInternal(state).getValue();
/*  44 */     Object rightValue = getRightOperand().getValueInternal(state).getValue();
/*  45 */     this.leftActualDescriptor = CodeFlow.toDescriptorFromObject(leftValue);
/*  46 */     this.rightActualDescriptor = CodeFlow.toDescriptorFromObject(rightValue);
/*  47 */     return BooleanTypedValue.forValue(!equalityCheck(state.getEvaluationContext(), leftValue, rightValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  54 */     SpelNodeImpl left = getLeftOperand();
/*  55 */     SpelNodeImpl right = getRightOperand();
/*  56 */     if (!left.isCompilable() || !right.isCompilable()) {
/*  57 */       return false;
/*     */     }
/*     */     
/*  60 */     String leftDesc = left.exitTypeDescriptor;
/*  61 */     String rightDesc = right.exitTypeDescriptor;
/*  62 */     Operator.DescriptorComparison dc = Operator.DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/*  64 */     return (!dc.areNumbers || dc.areCompatible);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  69 */     cf.loadEvaluationContext(mv);
/*  70 */     String leftDesc = (getLeftOperand()).exitTypeDescriptor;
/*  71 */     String rightDesc = (getRightOperand()).exitTypeDescriptor;
/*     */     
/*  73 */     cf.enterCompilationScope();
/*  74 */     getLeftOperand().generateCode(mv, cf);
/*  75 */     cf.exitCompilationScope();
/*  76 */     if (CodeFlow.isPrimitive(leftDesc)) {
/*  77 */       CodeFlow.insertBoxIfNecessary(mv, leftDesc.charAt(0));
/*     */     }
/*  79 */     cf.enterCompilationScope();
/*  80 */     getRightOperand().generateCode(mv, cf);
/*  81 */     cf.exitCompilationScope();
/*  82 */     if (CodeFlow.isPrimitive(rightDesc)) {
/*  83 */       CodeFlow.insertBoxIfNecessary(mv, rightDesc.charAt(0));
/*     */     }
/*     */     
/*  86 */     String operatorClassName = Operator.class.getName().replace('.', '/');
/*  87 */     String evaluationContextClassName = EvaluationContext.class.getName().replace('.', '/');
/*  88 */     mv.visitMethodInsn(184, operatorClassName, "equalityCheck", "(L" + evaluationContextClassName + ";Ljava/lang/Object;Ljava/lang/Object;)Z", false);
/*     */ 
/*     */ 
/*     */     
/*  92 */     Label notZero = new Label();
/*  93 */     Label end = new Label();
/*  94 */     mv.visitJumpInsn(154, notZero);
/*  95 */     mv.visitInsn(4);
/*  96 */     mv.visitJumpInsn(167, end);
/*  97 */     mv.visitLabel(notZero);
/*  98 */     mv.visitInsn(3);
/*  99 */     mv.visitLabel(end);
/*     */     
/* 101 */     cf.pushDescriptor("Z");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpNE.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */