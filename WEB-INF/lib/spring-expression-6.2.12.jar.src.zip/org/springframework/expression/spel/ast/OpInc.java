/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpInc
/*     */   extends Operator
/*     */ {
/*     */   private static final String INC = "++";
/*     */   private final boolean postfix;
/*     */   
/*     */   public OpInc(int startPos, int endPos, boolean postfix, SpelNodeImpl... operands) {
/*  48 */     super("++", startPos, endPos, operands);
/*  49 */     this.postfix = postfix;
/*  50 */     Assert.notEmpty((Object[])operands, "Operands must not be empty");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  56 */     if (!state.getEvaluationContext().isAssignmentEnabled()) {
/*  57 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.OPERAND_NOT_INCREMENTABLE, new Object[] { toStringAST() });
/*     */     }
/*     */     
/*  60 */     SpelNodeImpl operand = getLeftOperand();
/*  61 */     ValueRef valueRef = operand.getValueRef(state);
/*     */     
/*  63 */     TypedValue typedValue = valueRef.getValue();
/*  64 */     Object value = typedValue.getValue();
/*  65 */     TypedValue returnValue = typedValue;
/*  66 */     TypedValue newValue = null;
/*     */     
/*  68 */     if (value instanceof Number) { Number op1 = (Number)value;
/*  69 */       if (op1 instanceof BigDecimal) { BigDecimal bigDecimal = (BigDecimal)op1;
/*  70 */         newValue = new TypedValue(bigDecimal.add(BigDecimal.ONE), typedValue.getTypeDescriptor()); }
/*     */       
/*  72 */       else if (op1 instanceof Double)
/*  73 */       { newValue = new TypedValue(Double.valueOf(op1.doubleValue() + 1.0D), typedValue.getTypeDescriptor()); }
/*     */       
/*  75 */       else if (op1 instanceof Float)
/*  76 */       { newValue = new TypedValue(Float.valueOf(op1.floatValue() + 1.0F), typedValue.getTypeDescriptor()); }
/*     */       
/*  78 */       else if (op1 instanceof BigInteger) { BigInteger bigInteger = (BigInteger)op1;
/*  79 */         newValue = new TypedValue(bigInteger.add(BigInteger.ONE), typedValue.getTypeDescriptor()); }
/*     */       
/*  81 */       else if (op1 instanceof Long)
/*  82 */       { newValue = new TypedValue(Long.valueOf(op1.longValue() + 1L), typedValue.getTypeDescriptor()); }
/*     */       
/*  84 */       else if (op1 instanceof Integer)
/*  85 */       { newValue = new TypedValue(Integer.valueOf(op1.intValue() + 1), typedValue.getTypeDescriptor()); }
/*     */       
/*  87 */       else if (op1 instanceof Short)
/*  88 */       { newValue = new TypedValue(Integer.valueOf(op1.shortValue() + 1), typedValue.getTypeDescriptor()); }
/*     */       
/*  90 */       else if (op1 instanceof Byte)
/*  91 */       { newValue = new TypedValue(Integer.valueOf(op1.byteValue() + 1), typedValue.getTypeDescriptor()); }
/*     */       
/*     */       else
/*     */       
/*  95 */       { newValue = new TypedValue(Double.valueOf(op1.doubleValue() + 1.0D), typedValue.getTypeDescriptor()); }
/*     */        }
/*     */ 
/*     */     
/*  99 */     if (newValue == null) {
/*     */       try {
/* 101 */         newValue = state.operate(Operation.ADD, returnValue.getValue(), Integer.valueOf(1));
/*     */       }
/* 103 */       catch (SpelEvaluationException ex) {
/* 104 */         if (ex.getMessageCode() == SpelMessage.OPERATOR_NOT_SUPPORTED_BETWEEN_TYPES)
/*     */         {
/* 106 */           throw new SpelEvaluationException(operand.getStartPosition(), SpelMessage.OPERAND_NOT_INCREMENTABLE, new Object[] { operand
/* 107 */                 .toStringAST() });
/*     */         }
/* 109 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 115 */       valueRef.setValue(newValue.getValue());
/*     */     }
/* 117 */     catch (SpelEvaluationException see) {
/*     */       
/* 119 */       if (see.getMessageCode() == SpelMessage.SETVALUE_NOT_SUPPORTED) {
/* 120 */         throw new SpelEvaluationException(operand.getStartPosition(), SpelMessage.OPERAND_NOT_INCREMENTABLE, new Object[0]);
/*     */       }
/*     */       
/* 123 */       throw see;
/*     */     } 
/*     */ 
/*     */     
/* 127 */     if (!this.postfix)
/*     */     {
/* 129 */       returnValue = newValue;
/*     */     }
/*     */     
/* 132 */     return returnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 137 */     String ast = getLeftOperand().toStringAST();
/* 138 */     return this.postfix ? (ast + "++") : ("++" + ast);
/*     */   }
/*     */ 
/*     */   
/*     */   public SpelNodeImpl getRightOperand() {
/* 143 */     throw new IllegalStateException("No right operand");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpInc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */