/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.StringJoiner;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.ExpressionInvocationTargetException;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.ReflectiveMethodExecutor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final boolean nullSafe;
/*     */   private final String name;
/*     */   @Nullable
/*     */   private Character originalPrimitiveExitTypeDescriptor;
/*     */   @Nullable
/*     */   private volatile CachedMethodExecutor cachedExecutor;
/*     */   
/*     */   public MethodReference(boolean nullSafe, String methodName, int startPos, int endPos, SpelNodeImpl... arguments) {
/*  70 */     super(startPos, endPos, arguments);
/*  71 */     this.name = methodName;
/*  72 */     this.nullSafe = nullSafe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isNullSafe() {
/*  82 */     return this.nullSafe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/*  89 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/*  94 */     Object[] arguments = getArguments(state);
/*  95 */     if (state.getActiveContextObject().getValue() == null) {
/*  96 */       throwIfNotNullSafe(getArgumentTypes(arguments));
/*  97 */       return ValueRef.NullValueRef.INSTANCE;
/*     */     } 
/*  99 */     return new MethodValueRef(state, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 104 */     EvaluationContext evaluationContext = state.getEvaluationContext();
/* 105 */     Object value = state.getActiveContextObject().getValue();
/* 106 */     TypeDescriptor targetType = state.getActiveContextObject().getTypeDescriptor();
/* 107 */     Object[] arguments = getArguments(state);
/* 108 */     TypedValue result = getValueInternal(evaluationContext, value, targetType, arguments);
/* 109 */     updateExitTypeDescriptor();
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue getValueInternal(EvaluationContext evaluationContext, @Nullable Object value, @Nullable TypeDescriptor targetType, Object[] arguments) {
/* 116 */     List<TypeDescriptor> argumentTypes = getArgumentTypes(arguments);
/* 117 */     if (value == null) {
/* 118 */       throwIfNotNullSafe(argumentTypes);
/* 119 */       return TypedValue.NULL;
/*     */     } 
/*     */     
/* 122 */     MethodExecutor executorToUse = getCachedExecutor(evaluationContext, value, targetType, argumentTypes);
/* 123 */     if (executorToUse != null) {
/*     */       try {
/* 125 */         return executorToUse.execute(evaluationContext, value, arguments);
/*     */       }
/* 127 */       catch (AccessException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 139 */         throwSimpleExceptionIfPossible(value, ex);
/*     */ 
/*     */ 
/*     */         
/* 143 */         this.cachedExecutor = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 148 */     executorToUse = findAccessorForMethod(argumentTypes, value, evaluationContext);
/*     */     
/* 150 */     Class<?> clazz = (Class)value; this.cachedExecutor = new CachedMethodExecutor(executorToUse, (value instanceof Class) ? clazz : null, targetType, argumentTypes);
/*     */     try {
/* 152 */       return executorToUse.execute(evaluationContext, value, arguments);
/*     */     }
/* 154 */     catch (AccessException ex) {
/*     */       
/* 156 */       throwSimpleExceptionIfPossible(value, ex);
/* 157 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_METHOD_INVOCATION, new Object[] { this.name, value
/*     */             
/* 159 */             .getClass().getName(), ex.getMessage() });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void throwIfNotNullSafe(List<TypeDescriptor> argumentTypes) {
/* 164 */     if (!this.nullSafe)
/* 165 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.METHOD_CALL_ON_NULL_OBJECT_NOT_ALLOWED, new Object[] {
/*     */             
/* 167 */             FormatHelper.formatMethodForMessage(this.name, argumentTypes)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private Object[] getArguments(ExpressionState state) {
/* 172 */     Object[] arguments = new Object[getChildCount()];
/* 173 */     for (int i = 0; i < arguments.length; i++) {
/*     */ 
/*     */       
/* 176 */       try { state.pushActiveContextObject(state.getScopeRootContextObject());
/* 177 */         arguments[i] = this.children[i].getValueInternal(state).getValue();
/*     */ 
/*     */         
/* 180 */         state.popActiveContextObject(); } finally { state.popActiveContextObject(); }
/*     */     
/*     */     } 
/* 183 */     return arguments;
/*     */   }
/*     */   
/*     */   private List<TypeDescriptor> getArgumentTypes(Object... arguments) {
/* 187 */     List<TypeDescriptor> descriptors = new ArrayList<>(arguments.length);
/* 188 */     for (Object argument : arguments) {
/* 189 */       descriptors.add(TypeDescriptor.forObject(argument));
/*     */     }
/* 191 */     return Collections.unmodifiableList(descriptors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private MethodExecutor getCachedExecutor(EvaluationContext evaluationContext, Object value, @Nullable TypeDescriptor target, List<TypeDescriptor> argumentTypes) {
/* 198 */     List<MethodResolver> methodResolvers = evaluationContext.getMethodResolvers();
/* 199 */     if (methodResolvers.size() != 1 || !(methodResolvers.get(0) instanceof org.springframework.expression.spel.support.ReflectiveMethodResolver))
/*     */     {
/* 201 */       return null;
/*     */     }
/*     */     
/* 204 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 205 */     if (executorToCheck != null && executorToCheck.isSuitable(value, target, argumentTypes)) {
/* 206 */       return executorToCheck.get();
/*     */     }
/* 208 */     this.cachedExecutor = null;
/* 209 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodExecutor findAccessorForMethod(List<TypeDescriptor> argumentTypes, Object targetObject, EvaluationContext evaluationContext) throws SpelEvaluationException {
/* 215 */     AccessException accessException = null;
/* 216 */     for (MethodResolver methodResolver : evaluationContext.getMethodResolvers()) {
/*     */       try {
/* 218 */         MethodExecutor methodExecutor = methodResolver.resolve(evaluationContext, targetObject, this.name, argumentTypes);
/*     */         
/* 220 */         if (methodExecutor != null) {
/* 221 */           return methodExecutor;
/*     */         }
/*     */       }
/* 224 */       catch (AccessException ex) {
/* 225 */         accessException = ex;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 230 */     String method = FormatHelper.formatMethodForMessage(this.name, argumentTypes);
/*     */     
/* 232 */     Class<?> clazz = (Class)targetObject; String className = FormatHelper.formatClassNameForMessage((targetObject instanceof Class) ? clazz : targetObject.getClass());
/* 233 */     if (accessException != null) {
/* 234 */       throw new SpelEvaluationException(
/* 235 */           getStartPosition(), accessException, SpelMessage.PROBLEM_LOCATING_METHOD, new Object[] { method, className });
/*     */     }
/*     */     
/* 238 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.METHOD_NOT_FOUND, new Object[] { method, className });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void throwSimpleExceptionIfPossible(Object value, AccessException ex) {
/* 247 */     Throwable throwable = ex.getCause(); if (throwable instanceof InvocationTargetException) { InvocationTargetException cause = (InvocationTargetException)throwable;
/* 248 */       Throwable rootCause = cause.getCause();
/* 249 */       if (rootCause instanceof RuntimeException) { RuntimeException runtimeException = (RuntimeException)rootCause;
/* 250 */         throw runtimeException; }
/*     */       
/* 252 */       throw new ExpressionInvocationTargetException(getStartPosition(), "A problem occurred when trying to execute method '" + this.name + "' on object of type [" + value
/*     */           
/* 254 */           .getClass().getName() + "]", rootCause); }
/*     */   
/*     */   }
/*     */   
/*     */   private void updateExitTypeDescriptor() {
/* 259 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 260 */     if (executorToCheck != null) { MethodExecutor methodExecutor = executorToCheck.get(); if (methodExecutor instanceof ReflectiveMethodExecutor) { ReflectiveMethodExecutor reflectiveMethodExecutor = (ReflectiveMethodExecutor)methodExecutor;
/* 261 */         Method method = reflectiveMethodExecutor.getMethod();
/* 262 */         String descriptor = CodeFlow.toDescriptor(method.getReturnType());
/* 263 */         if (this.nullSafe && CodeFlow.isPrimitive(descriptor) && descriptor.charAt(0) != 'V') {
/* 264 */           this.originalPrimitiveExitTypeDescriptor = Character.valueOf(descriptor.charAt(0));
/* 265 */           this.exitTypeDescriptor = CodeFlow.toBoxedDescriptor(descriptor);
/*     */         } else {
/*     */           
/* 268 */           this.exitTypeDescriptor = descriptor;
/*     */         }  }
/*     */        }
/*     */   
/*     */   }
/*     */   
/*     */   public String toStringAST() {
/* 275 */     StringJoiner sj = new StringJoiner(",", "(", ")");
/* 276 */     for (int i = 0; i < getChildCount(); i++) {
/* 277 */       sj.add(getChild(i).toStringAST());
/*     */     }
/* 279 */     return this.name + this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*     */     ReflectiveMethodExecutor executor;
/* 288 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 289 */     if (executorToCheck != null && !executorToCheck.hasProxyTarget())
/* 290 */     { MethodExecutor methodExecutor = executorToCheck.get(); if (methodExecutor instanceof ReflectiveMethodExecutor) { executor = (ReflectiveMethodExecutor)methodExecutor; }
/* 291 */       else { return false; }  } else { return false; }
/*     */ 
/*     */     
/* 294 */     for (SpelNodeImpl child : this.children) {
/* 295 */       if (!child.isCompilable()) {
/* 296 */         return false;
/*     */       }
/*     */     } 
/* 299 */     if (executor.didArgumentConversionOccur()) {
/* 300 */       return false;
/*     */     }
/*     */     
/* 303 */     Method method = executor.getMethod();
/* 304 */     return (Modifier.isPublic(method.getModifiers()) && executor.getPublicDeclaringClass() != null);
/*     */   }
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*     */     ReflectiveMethodExecutor methodExecutor;
/* 309 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 310 */     if (executorToCheck != null) { MethodExecutor methodExecutor1 = executorToCheck.get(); if (methodExecutor1 instanceof ReflectiveMethodExecutor) { methodExecutor = (ReflectiveMethodExecutor)methodExecutor1; }
/* 311 */       else { throw new IllegalStateException("No applicable cached executor found: " + String.valueOf(executorToCheck)); }  } else { throw new IllegalStateException("No applicable cached executor found: " + String.valueOf(executorToCheck)); }
/*     */     
/* 313 */     Method method = methodExecutor.getMethod();
/*     */     
/* 315 */     Class<?> publicDeclaringClass = methodExecutor.getPublicDeclaringClass();
/* 316 */     Assert.state((publicDeclaringClass != null), () -> "Failed to find public declaring class for method: " + String.valueOf(method));
/*     */ 
/*     */     
/* 319 */     String classDesc = publicDeclaringClass.getName().replace('.', '/');
/* 320 */     boolean isStatic = Modifier.isStatic(method.getModifiers());
/* 321 */     String descriptor = cf.lastDescriptor();
/*     */     
/* 323 */     if (descriptor == null && !isStatic)
/*     */     {
/* 325 */       cf.loadTarget(mv);
/*     */     }
/*     */     
/* 328 */     Label skipIfNull = null;
/* 329 */     if (this.nullSafe && (descriptor != null || !isStatic)) {
/* 330 */       skipIfNull = new Label();
/* 331 */       Label continueLabel = new Label();
/* 332 */       mv.visitInsn(89);
/* 333 */       mv.visitJumpInsn(199, continueLabel);
/* 334 */       CodeFlow.insertCheckCast(mv, this.exitTypeDescriptor);
/* 335 */       mv.visitJumpInsn(167, skipIfNull);
/* 336 */       mv.visitLabel(continueLabel);
/*     */     } 
/*     */     
/* 339 */     if (descriptor != null && isStatic)
/*     */     {
/*     */       
/* 342 */       mv.visitInsn(87);
/*     */     }
/*     */     
/* 345 */     if (CodeFlow.isPrimitive(descriptor)) {
/* 346 */       CodeFlow.insertBoxIfNecessary(mv, descriptor.charAt(0));
/*     */     }
/*     */     
/* 349 */     if (!isStatic && (descriptor == null || !descriptor.substring(1).equals(classDesc))) {
/* 350 */       CodeFlow.insertCheckCast(mv, "L" + classDesc);
/*     */     }
/*     */     
/* 353 */     generateCodeForArguments(mv, cf, method, this.children);
/* 354 */     boolean isInterface = publicDeclaringClass.isInterface();
/* 355 */     int opcode = isStatic ? 184 : (isInterface ? 185 : 182);
/* 356 */     mv.visitMethodInsn(opcode, classDesc, method.getName(), CodeFlow.createSignatureDescriptor(method), isInterface);
/*     */     
/* 358 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */     
/* 360 */     if (this.originalPrimitiveExitTypeDescriptor != null)
/*     */     {
/*     */       
/* 363 */       CodeFlow.insertBoxIfNecessary(mv, this.originalPrimitiveExitTypeDescriptor.charValue());
/*     */     }
/*     */     
/* 366 */     if (skipIfNull != null) {
/* 367 */       if ("V".equals(this.exitTypeDescriptor))
/*     */       {
/*     */         
/* 370 */         mv.visitInsn(1);
/*     */       }
/* 372 */       mv.visitLabel(skipIfNull);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private class MethodValueRef
/*     */     implements ValueRef
/*     */   {
/*     */     private final EvaluationContext evaluationContext;
/*     */     
/*     */     @Nullable
/*     */     private final Object value;
/*     */     
/*     */     @Nullable
/*     */     private final TypeDescriptor targetType;
/*     */     private final Object[] arguments;
/*     */     
/*     */     public MethodValueRef(ExpressionState state, Object[] arguments) {
/* 390 */       this.evaluationContext = state.getEvaluationContext();
/* 391 */       this.value = state.getActiveContextObject().getValue();
/* 392 */       this.targetType = state.getActiveContextObject().getTypeDescriptor();
/* 393 */       this.arguments = arguments;
/*     */     }
/*     */ 
/*     */     
/*     */     public TypedValue getValue() {
/* 398 */       TypedValue result = MethodReference.this.getValueInternal(this.evaluationContext, this.value, this.targetType, this.arguments);
/*     */       
/* 400 */       MethodReference.this.updateExitTypeDescriptor();
/* 401 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(@Nullable Object newValue) {
/* 406 */       throw new IllegalAccessError();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWritable() {
/* 411 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CachedMethodExecutor
/*     */   {
/*     */     private final MethodExecutor methodExecutor;
/*     */     
/*     */     @Nullable
/*     */     private final Class<?> staticClass;
/*     */     
/*     */     @Nullable
/*     */     private final TypeDescriptor target;
/*     */     
/*     */     private final List<TypeDescriptor> argumentTypes;
/*     */ 
/*     */     
/*     */     public CachedMethodExecutor(MethodExecutor methodExecutor, @Nullable Class<?> staticClass, @Nullable TypeDescriptor target, List<TypeDescriptor> argumentTypes) {
/* 431 */       this.methodExecutor = methodExecutor;
/* 432 */       this.staticClass = staticClass;
/* 433 */       this.target = target;
/* 434 */       this.argumentTypes = argumentTypes;
/*     */     }
/*     */     
/*     */     public boolean isSuitable(Object value, @Nullable TypeDescriptor target, List<TypeDescriptor> argumentTypes) {
/* 438 */       return ((this.staticClass == null || this.staticClass == value) && 
/* 439 */         ObjectUtils.nullSafeEquals(this.target, target) && this.argumentTypes.equals(argumentTypes));
/*     */     }
/*     */     
/*     */     public boolean hasProxyTarget() {
/* 443 */       return (this.target != null && Proxy.isProxyClass(this.target.getType()));
/*     */     }
/*     */     
/*     */     public MethodExecutor get() {
/* 447 */       return this.methodExecutor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\MethodReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */