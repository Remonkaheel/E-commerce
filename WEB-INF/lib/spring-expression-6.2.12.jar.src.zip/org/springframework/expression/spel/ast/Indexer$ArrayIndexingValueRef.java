/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArrayIndexingValueRef
/*     */   implements ValueRef
/*     */ {
/*     */   private final TypeConverter typeConverter;
/*     */   private final Object array;
/*     */   private final int index;
/*     */   private final TypeDescriptor typeDescriptor;
/*     */   
/*     */   ArrayIndexingValueRef(TypeConverter typeConverter, Object array, int index, TypeDescriptor typeDescriptor) {
/* 514 */     this.typeConverter = typeConverter;
/* 515 */     this.array = array;
/* 516 */     this.index = index;
/* 517 */     this.typeDescriptor = typeDescriptor;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValue() {
/* 522 */     Object arrayElement = getArrayElement(this.array, this.index);
/* 523 */     return new TypedValue(arrayElement, this.typeDescriptor.elementTypeDescriptor(arrayElement));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable Object newValue) {
/* 528 */     TypeDescriptor elementType = this.typeDescriptor.getElementTypeDescriptor();
/* 529 */     Assert.state((elementType != null), "No element type");
/* 530 */     setArrayElement(this.typeConverter, this.array, this.index, newValue, elementType.getType());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 535 */     return true;
/*     */   }
/*     */   
/*     */   private Object getArrayElement(Object ctx, int idx) throws SpelEvaluationException {
/* 539 */     Class<?> arrayComponentType = ctx.getClass().componentType();
/* 540 */     if (arrayComponentType == boolean.class) {
/* 541 */       boolean[] arrayOfBoolean = (boolean[])ctx;
/* 542 */       checkAccess(arrayOfBoolean.length, idx);
/* 543 */       Indexer.this.setExitTypeDescriptor("Z");
/* 544 */       Indexer.this.arrayTypeDescriptor = "[Z";
/* 545 */       return Boolean.valueOf(arrayOfBoolean[idx]);
/*     */     } 
/* 547 */     if (arrayComponentType == byte.class) {
/* 548 */       byte[] arrayOfByte = (byte[])ctx;
/* 549 */       checkAccess(arrayOfByte.length, idx);
/* 550 */       Indexer.this.setExitTypeDescriptor("B");
/* 551 */       Indexer.this.arrayTypeDescriptor = "[B";
/* 552 */       return Byte.valueOf(arrayOfByte[idx]);
/*     */     } 
/* 554 */     if (arrayComponentType == char.class) {
/* 555 */       char[] arrayOfChar = (char[])ctx;
/* 556 */       checkAccess(arrayOfChar.length, idx);
/* 557 */       Indexer.this.setExitTypeDescriptor("C");
/* 558 */       Indexer.this.arrayTypeDescriptor = "[C";
/* 559 */       return Character.valueOf(arrayOfChar[idx]);
/*     */     } 
/* 561 */     if (arrayComponentType == double.class) {
/* 562 */       double[] arrayOfDouble = (double[])ctx;
/* 563 */       checkAccess(arrayOfDouble.length, idx);
/* 564 */       Indexer.this.setExitTypeDescriptor("D");
/* 565 */       Indexer.this.arrayTypeDescriptor = "[D";
/* 566 */       return Double.valueOf(arrayOfDouble[idx]);
/*     */     } 
/* 568 */     if (arrayComponentType == float.class) {
/* 569 */       float[] arrayOfFloat = (float[])ctx;
/* 570 */       checkAccess(arrayOfFloat.length, idx);
/* 571 */       Indexer.this.setExitTypeDescriptor("F");
/* 572 */       Indexer.this.arrayTypeDescriptor = "[F";
/* 573 */       return Float.valueOf(arrayOfFloat[idx]);
/*     */     } 
/* 575 */     if (arrayComponentType == int.class) {
/* 576 */       int[] arrayOfInt = (int[])ctx;
/* 577 */       checkAccess(arrayOfInt.length, idx);
/* 578 */       Indexer.this.setExitTypeDescriptor("I");
/* 579 */       Indexer.this.arrayTypeDescriptor = "[I";
/* 580 */       return Integer.valueOf(arrayOfInt[idx]);
/*     */     } 
/* 582 */     if (arrayComponentType == long.class) {
/* 583 */       long[] arrayOfLong = (long[])ctx;
/* 584 */       checkAccess(arrayOfLong.length, idx);
/* 585 */       Indexer.this.setExitTypeDescriptor("J");
/* 586 */       Indexer.this.arrayTypeDescriptor = "[J";
/* 587 */       return Long.valueOf(arrayOfLong[idx]);
/*     */     } 
/* 589 */     if (arrayComponentType == short.class) {
/* 590 */       short[] arrayOfShort = (short[])ctx;
/* 591 */       checkAccess(arrayOfShort.length, idx);
/* 592 */       Indexer.this.setExitTypeDescriptor("S");
/* 593 */       Indexer.this.arrayTypeDescriptor = "[S";
/* 594 */       return Short.valueOf(arrayOfShort[idx]);
/*     */     } 
/*     */     
/* 597 */     Object[] array = (Object[])ctx;
/* 598 */     checkAccess(array.length, idx);
/* 599 */     Object retValue = array[idx];
/* 600 */     Indexer.this.exitTypeDescriptor = CodeFlow.toDescriptor(arrayComponentType);
/* 601 */     Indexer.this.arrayTypeDescriptor = CodeFlow.toDescriptor(array.getClass());
/* 602 */     return retValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setArrayElement(TypeConverter converter, Object ctx, int idx, @Nullable Object newValue, Class<?> arrayComponentType) throws EvaluationException {
/* 609 */     if (arrayComponentType == boolean.class) {
/* 610 */       boolean[] array = (boolean[])ctx;
/* 611 */       checkAccess(array.length, idx);
/* 612 */       array[idx] = ((Boolean)convertValue(converter, newValue, (Class)boolean.class)).booleanValue();
/*     */     }
/* 614 */     else if (arrayComponentType == byte.class) {
/* 615 */       byte[] array = (byte[])ctx;
/* 616 */       checkAccess(array.length, idx);
/* 617 */       array[idx] = ((Byte)convertValue(converter, newValue, (Class)byte.class)).byteValue();
/*     */     }
/* 619 */     else if (arrayComponentType == char.class) {
/* 620 */       char[] array = (char[])ctx;
/* 621 */       checkAccess(array.length, idx);
/* 622 */       array[idx] = ((Character)convertValue(converter, newValue, (Class)char.class)).charValue();
/*     */     }
/* 624 */     else if (arrayComponentType == double.class) {
/* 625 */       double[] array = (double[])ctx;
/* 626 */       checkAccess(array.length, idx);
/* 627 */       array[idx] = ((Double)convertValue(converter, newValue, (Class)double.class)).doubleValue();
/*     */     }
/* 629 */     else if (arrayComponentType == float.class) {
/* 630 */       float[] array = (float[])ctx;
/* 631 */       checkAccess(array.length, idx);
/* 632 */       array[idx] = ((Float)convertValue(converter, newValue, (Class)float.class)).floatValue();
/*     */     }
/* 634 */     else if (arrayComponentType == int.class) {
/* 635 */       int[] array = (int[])ctx;
/* 636 */       checkAccess(array.length, idx);
/* 637 */       array[idx] = ((Integer)convertValue(converter, newValue, (Class)int.class)).intValue();
/*     */     }
/* 639 */     else if (arrayComponentType == long.class) {
/* 640 */       long[] array = (long[])ctx;
/* 641 */       checkAccess(array.length, idx);
/* 642 */       array[idx] = ((Long)convertValue(converter, newValue, (Class)long.class)).longValue();
/*     */     }
/* 644 */     else if (arrayComponentType == short.class) {
/* 645 */       short[] array = (short[])ctx;
/* 646 */       checkAccess(array.length, idx);
/* 647 */       array[idx] = ((Short)convertValue(converter, newValue, (Class)short.class)).shortValue();
/*     */     } else {
/*     */       
/* 650 */       Object[] array = (Object[])ctx;
/* 651 */       checkAccess(array.length, idx);
/* 652 */       array[idx] = convertValue(converter, newValue, arrayComponentType);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkAccess(int arrayLength, int index) throws SpelEvaluationException {
/* 657 */     if (index >= arrayLength) {
/* 658 */       throw new SpelEvaluationException(Indexer.this.getStartPosition(), SpelMessage.ARRAY_INDEX_OUT_OF_BOUNDS, new Object[] {
/* 659 */             Integer.valueOf(arrayLength), Integer.valueOf(index)
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T> T convertValue(TypeConverter converter, @Nullable Object value, Class<T> targetType) {
/* 665 */     T result = (T)converter.convertValue(value, 
/* 666 */         TypeDescriptor.forObject(value), TypeDescriptor.valueOf(targetType));
/* 667 */     if (result == null) {
/* 668 */       throw new IllegalStateException("Null conversion result for index [" + String.valueOf(value) + "]");
/*     */     }
/* 670 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Indexer$ArrayIndexingValueRef.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */