/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.StringJoiner;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class FormatHelper
/*    */ {
/*    */   static String formatMethodForMessage(String name, List<TypeDescriptor> argumentTypes) {
/* 40 */     StringJoiner sj = new StringJoiner(",", "(", ")");
/* 41 */     for (TypeDescriptor typeDescriptor : argumentTypes) {
/* 42 */       String className = (typeDescriptor != null) ? formatClassNameForMessage(typeDescriptor.getType()) : "null";
/* 43 */       sj.add(className);
/*    */     } 
/* 45 */     return name + name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String formatClassNameForMessage(@Nullable Class<?> clazz) {
/* 55 */     return (clazz != null) ? clazz.getTypeName() : "null";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\FormatHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */