/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.TypeComparator;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.expression.spel.ExpressionState;
/*    */ import org.springframework.expression.spel.SpelEvaluationException;
/*    */ import org.springframework.expression.spel.SpelMessage;
/*    */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperatorBetween
/*    */   extends Operator
/*    */ {
/*    */   public OperatorBetween(int startPos, int endPos, SpelNodeImpl... operands) {
/* 46 */     super("between", startPos, endPos, operands);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 60 */     Object left = getLeftOperand().getValueInternal(state).getValue();
/* 61 */     Object right = getRightOperand().getValueInternal(state).getValue();
/* 62 */     if (right instanceof List) { List<?> list = (List)right; if (list.size() == 2) {
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 67 */         Object low = list.get(0);
/* 68 */         Object high = list.get(1);
/* 69 */         TypeComparator comp = state.getTypeComparator();
/*    */         try {
/* 71 */           return BooleanTypedValue.forValue((comp.compare(left, low) >= 0 && comp.compare(left, high) <= 0));
/*    */         }
/* 73 */         catch (SpelEvaluationException ex) {
/* 74 */           ex.setPosition(getStartPosition());
/* 75 */           throw ex;
/*    */         } 
/*    */       }  }
/*    */     
/*    */     throw new SpelEvaluationException(getRightOperand().getStartPosition(), SpelMessage.BETWEEN_RIGHT_OPERAND_MUST_BE_TWO_ELEMENT_LIST, new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OperatorBetween.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */