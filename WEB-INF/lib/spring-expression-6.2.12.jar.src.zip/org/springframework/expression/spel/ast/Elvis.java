/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Elvis
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   public Elvis(int startPos, int endPos, SpelNodeImpl... args) {
/*  41 */     super(startPos, endPos, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  54 */     TypedValue value = this.children[0].getValueInternal(state);
/*     */     
/*  56 */     if (value.getValue() != null && !"".equals(value.getValue())) {
/*  57 */       return value;
/*     */     }
/*     */     
/*  60 */     TypedValue result = this.children[1].getValueInternal(state);
/*  61 */     computeExitTypeDescriptor();
/*  62 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/*  68 */     return "(" + getChild(0).toStringAST() + " ?: " + getChild(1).toStringAST() + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  73 */     SpelNodeImpl condition = this.children[0];
/*  74 */     SpelNodeImpl ifNullValue = this.children[1];
/*  75 */     return (condition.isCompilable() && ifNullValue.isCompilable() && condition.exitTypeDescriptor != null && ifNullValue.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  82 */     computeExitTypeDescriptor();
/*  83 */     cf.enterCompilationScope();
/*  84 */     this.children[0].generateCode(mv, cf);
/*  85 */     String lastDesc = cf.lastDescriptor();
/*  86 */     Assert.state((lastDesc != null), "No last descriptor");
/*  87 */     CodeFlow.insertBoxIfNecessary(mv, lastDesc.charAt(0));
/*  88 */     cf.exitCompilationScope();
/*  89 */     Label elseTarget = new Label();
/*  90 */     Label endOfIf = new Label();
/*  91 */     mv.visitInsn(89);
/*  92 */     mv.visitJumpInsn(198, elseTarget);
/*     */     
/*  94 */     mv.visitInsn(89);
/*  95 */     mv.visitLdcInsn("");
/*  96 */     mv.visitInsn(95);
/*  97 */     mv.visitMethodInsn(182, "java/lang/String", "equals", "(Ljava/lang/Object;)Z", false);
/*  98 */     mv.visitJumpInsn(153, endOfIf);
/*  99 */     mv.visitLabel(elseTarget);
/* 100 */     mv.visitInsn(87);
/* 101 */     cf.enterCompilationScope();
/* 102 */     this.children[1].generateCode(mv, cf);
/* 103 */     if (!CodeFlow.isPrimitive(this.exitTypeDescriptor)) {
/* 104 */       lastDesc = cf.lastDescriptor();
/* 105 */       Assert.state((lastDesc != null), "No last descriptor");
/* 106 */       CodeFlow.insertBoxIfNecessary(mv, lastDesc.charAt(0));
/*     */     } 
/* 108 */     cf.exitCompilationScope();
/* 109 */     mv.visitLabel(endOfIf);
/* 110 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */   
/*     */   private void computeExitTypeDescriptor() {
/* 114 */     if (this.exitTypeDescriptor == null && (this.children[0]).exitTypeDescriptor != null && (this.children[1]).exitTypeDescriptor != null) {
/*     */       
/* 116 */       String conditionDescriptor = (this.children[0]).exitTypeDescriptor;
/* 117 */       String ifNullValueDescriptor = (this.children[1]).exitTypeDescriptor;
/* 118 */       if (ObjectUtils.nullSafeEquals(conditionDescriptor, ifNullValueDescriptor)) {
/* 119 */         this.exitTypeDescriptor = conditionDescriptor;
/*     */       }
/*     */       else {
/*     */         
/* 123 */         this.exitTypeDescriptor = "Ljava/lang/Object";
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Elvis.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */