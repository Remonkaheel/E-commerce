/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private static final String THIS = "this";
/*     */   private static final String ROOT = "root";
/*     */   private final String name;
/*     */   
/*     */   public VariableReference(String variableName, int startPos, int endPos) {
/*  52 */     super(startPos, endPos, new SpelNodeImpl[0]);
/*  53 */     this.name = variableName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueRef getValueRef(ExpressionState state) throws SpelEvaluationException {
/*  59 */     if ("this".equals(this.name)) {
/*  60 */       return new ValueRef.TypedValueHolderValueRef(state.getActiveContextObject(), this);
/*     */     }
/*  62 */     if ("root".equals(this.name)) {
/*  63 */       return new ValueRef.TypedValueHolderValueRef(state.getRootContextObject(), this);
/*     */     }
/*  65 */     TypedValue result = state.lookupVariable(this.name);
/*     */ 
/*     */     
/*  68 */     return new VariableRef(this.name, result, state.getEvaluationContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws SpelEvaluationException {
/*     */     TypedValue result;
/*  74 */     if ("this".equals(this.name)) {
/*  75 */       result = state.getActiveContextObject();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  80 */       if (result != state.getRootContextObject()) {
/*  81 */         return result;
/*     */       }
/*     */     }
/*  84 */     else if ("root".equals(this.name)) {
/*  85 */       result = state.getRootContextObject();
/*     */     } else {
/*     */       
/*  88 */       result = state.lookupVariable(this.name);
/*     */     } 
/*  90 */     setExitTypeDescriptor(result.getValue());
/*     */ 
/*     */ 
/*     */     
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setExitTypeDescriptor(@Nullable Object value) {
/* 110 */     if (value == null || !Modifier.isPublic(value.getClass().getModifiers())) {
/* 111 */       this.exitTypeDescriptor = "Ljava/lang/Object";
/*     */     } else {
/*     */       
/* 114 */       this.exitTypeDescriptor = CodeFlow.toDescriptorFromObject(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue setValueInternal(ExpressionState state, Supplier<TypedValue> valueSupplier) throws EvaluationException {
/* 122 */     return state.assignVariable(this.name, valueSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 127 */     return "#" + this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(ExpressionState expressionState) throws SpelEvaluationException {
/* 132 */     return (!"this".equals(this.name) && !"root".equals(this.name));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 137 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 142 */     if ("this".equals(this.name) || "root".equals(this.name)) {
/* 143 */       mv.visitVarInsn(25, 1);
/*     */     } else {
/*     */       
/* 146 */       mv.visitVarInsn(25, 2);
/* 147 */       mv.visitLdcInsn(this.name);
/* 148 */       mv.visitMethodInsn(185, "org/springframework/expression/EvaluationContext", "lookupVariable", "(Ljava/lang/String;)Ljava/lang/Object;", true);
/*     */     } 
/*     */     
/* 151 */     CodeFlow.insertCheckCast(mv, this.exitTypeDescriptor);
/* 152 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class VariableRef
/*     */     implements ValueRef
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final TypedValue value;
/*     */     private final EvaluationContext evaluationContext;
/*     */     
/*     */     public VariableRef(String name, TypedValue value, EvaluationContext evaluationContext) {
/* 165 */       this.name = name;
/* 166 */       this.value = value;
/* 167 */       this.evaluationContext = evaluationContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public TypedValue getValue() {
/* 172 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(@Nullable Object newValue) {
/* 177 */       this.evaluationContext.setVariable(this.name, newValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWritable() {
/* 182 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\VariableReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */