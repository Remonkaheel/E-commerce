/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ import org.springframework.lang.Contract;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpAnd
/*     */   extends Operator
/*     */ {
/*     */   public OpAnd(int startPos, int endPos, SpelNodeImpl... operands) {
/*  42 */     super("and", startPos, endPos, operands);
/*  43 */     this.exitTypeDescriptor = "Z";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  49 */     if (!getBooleanValue(state, getLeftOperand()))
/*     */     {
/*  51 */       return (TypedValue)BooleanTypedValue.FALSE;
/*     */     }
/*  53 */     return (TypedValue)BooleanTypedValue.forValue(getBooleanValue(state, getRightOperand()));
/*     */   }
/*     */   
/*     */   private boolean getBooleanValue(ExpressionState state, SpelNodeImpl operand) {
/*     */     try {
/*  58 */       Boolean value = operand.<Boolean>getValue(state, Boolean.class);
/*  59 */       assertValueNotNull(value);
/*  60 */       return value.booleanValue();
/*     */     }
/*  62 */     catch (SpelEvaluationException ex) {
/*  63 */       ex.setPosition(operand.getStartPosition());
/*  64 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Contract("null -> fail")
/*     */   private void assertValueNotNull(@Nullable Boolean value) {
/*  70 */     if (value == null) {
/*  71 */       throw new SpelEvaluationException(SpelMessage.TYPE_CONVERSION_ERROR, new Object[] { "null", "boolean" });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  77 */     SpelNodeImpl left = getLeftOperand();
/*  78 */     SpelNodeImpl right = getRightOperand();
/*  79 */     return (left.isCompilable() && right.isCompilable() && 
/*  80 */       CodeFlow.isBooleanCompatible(left.exitTypeDescriptor) && 
/*  81 */       CodeFlow.isBooleanCompatible(right.exitTypeDescriptor));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  87 */     Label elseTarget = new Label();
/*  88 */     Label endOfIf = new Label();
/*  89 */     cf.enterCompilationScope();
/*  90 */     getLeftOperand().generateCode(mv, cf);
/*  91 */     cf.unboxBooleanIfNecessary(mv);
/*  92 */     cf.exitCompilationScope();
/*  93 */     mv.visitJumpInsn(154, elseTarget);
/*  94 */     mv.visitLdcInsn(Integer.valueOf(0));
/*  95 */     mv.visitJumpInsn(167, endOfIf);
/*  96 */     mv.visitLabel(elseTarget);
/*  97 */     cf.enterCompilationScope();
/*  98 */     getRightOperand().generateCode(mv, cf);
/*  99 */     cf.unboxBooleanIfNecessary(mv);
/* 100 */     cf.exitCompilationScope();
/* 101 */     mv.visitLabel(endOfIf);
/* 102 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpAnd.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */