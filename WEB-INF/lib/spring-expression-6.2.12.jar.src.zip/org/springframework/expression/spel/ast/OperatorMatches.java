/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OperatorMatches
/*     */   extends Operator
/*     */ {
/*     */   private static final int PATTERN_ACCESS_THRESHOLD = 1000000;
/*     */   private static final int MAX_REGEX_LENGTH = 1000;
/*     */   private final ConcurrentMap<String, Pattern> patternCache;
/*     */   
/*     */   @Deprecated(since = "5.2.23")
/*     */   public OperatorMatches(int startPos, int endPos, SpelNodeImpl... operands) {
/*  63 */     this(new ConcurrentHashMap<>(), startPos, endPos, operands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OperatorMatches(ConcurrentMap<String, Pattern> patternCache, int startPos, int endPos, SpelNodeImpl... operands) {
/*  71 */     super("matches", startPos, endPos, operands);
/*  72 */     this.patternCache = patternCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*     */     String regex;
/*  85 */     SpelNodeImpl leftOp = getLeftOperand();
/*  86 */     SpelNodeImpl rightOp = getRightOperand();
/*     */     
/*  88 */     String input = leftOp.<String>getValue(state, String.class);
/*  89 */     if (input == null) {
/*  90 */       throw new SpelEvaluationException(leftOp.getStartPosition(), SpelMessage.INVALID_FIRST_OPERAND_FOR_MATCHES_OPERATOR, new Object[] { null });
/*     */     }
/*     */ 
/*     */     
/*  94 */     Object right = rightOp.getValue(state);
/*  95 */     if (right instanceof String) { regex = (String)right; }
/*  96 */     else { throw new SpelEvaluationException(rightOp.getStartPosition(), SpelMessage.INVALID_SECOND_OPERAND_FOR_MATCHES_OPERATOR, new Object[] { right }); }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 101 */       Pattern pattern = this.patternCache.get(regex);
/* 102 */       if (pattern == null) {
/* 103 */         checkRegexLength(regex);
/* 104 */         pattern = Pattern.compile(regex);
/* 105 */         this.patternCache.putIfAbsent(regex, pattern);
/*     */       } 
/* 107 */       Matcher matcher = pattern.matcher(new MatcherInput(input, new AccessCount()));
/* 108 */       return BooleanTypedValue.forValue(matcher.matches());
/*     */     }
/* 110 */     catch (PatternSyntaxException ex) {
/* 111 */       throw new SpelEvaluationException(rightOp
/* 112 */           .getStartPosition(), ex, SpelMessage.INVALID_PATTERN, new Object[] { right });
/*     */     }
/* 114 */     catch (IllegalStateException ex) {
/* 115 */       throw new SpelEvaluationException(rightOp
/* 116 */           .getStartPosition(), ex, SpelMessage.FLAWED_PATTERN, new Object[] { right });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkRegexLength(String regex) {
/* 121 */     if (regex.length() > 1000) {
/* 122 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.MAX_REGEX_LENGTH_EXCEEDED, new Object[] {
/* 123 */             Integer.valueOf(1000)
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AccessCount
/*     */   {
/*     */     private int count;
/*     */     
/*     */     public void check() throws IllegalStateException {
/* 133 */       if (this.count++ > 1000000) {
/* 134 */         throw new IllegalStateException("Pattern access threshold exceeded");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class MatcherInput
/*     */     implements CharSequence
/*     */   {
/*     */     private final CharSequence value;
/*     */     private final OperatorMatches.AccessCount access;
/*     */     
/*     */     public MatcherInput(CharSequence value, OperatorMatches.AccessCount access) {
/* 147 */       this.value = value;
/* 148 */       this.access = access;
/*     */     }
/*     */ 
/*     */     
/*     */     public char charAt(int index) {
/* 153 */       this.access.check();
/* 154 */       return this.value.charAt(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence subSequence(int start, int end) {
/* 159 */       return new MatcherInput(this.value.subSequence(start, end), this.access);
/*     */     }
/*     */ 
/*     */     
/*     */     public int length() {
/* 164 */       return this.value.length();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 169 */       return this.value.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OperatorMatches.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */