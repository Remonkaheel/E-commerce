/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InlineMap
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   @Nullable
/*     */   private final TypedValue constant;
/*     */   
/*     */   public InlineMap(int startPos, int endPos, SpelNodeImpl... args) {
/*  47 */     super(startPos, endPos, args);
/*  48 */     this.constant = computeConstantValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypedValue computeConstantValue() {
/*  60 */     for (int c = 0, max = getChildCount(); c < max; c++) {
/*  61 */       SpelNode child = getChild(c);
/*  62 */       if (!(child instanceof Literal)) {
/*  63 */         if (child instanceof InlineList) { InlineList inlineList = (InlineList)child;
/*  64 */           if (!inlineList.isConstant()) {
/*  65 */             return null;
/*     */           } }
/*     */         
/*  68 */         else if (child instanceof InlineMap) { InlineMap inlineMap = (InlineMap)child;
/*  69 */           if (!inlineMap.isConstant()) {
/*  70 */             return null;
/*     */           } }
/*     */         
/*  73 */         else if (c % 2 != 0 || !(child instanceof PropertyOrFieldReference))
/*  74 */         { if (child instanceof OpMinus) { OpMinus opMinus = (OpMinus)child; if (!opMinus.isNegativeNumberLiteral())
/*  75 */               return null;  } else { return null; }
/*     */            }
/*     */       
/*     */       }
/*     */     } 
/*     */     
/*  81 */     Map<Object, Object> constantMap = new LinkedHashMap<>();
/*  82 */     int childCount = getChildCount();
/*  83 */     ExpressionState expressionState = new ExpressionState((EvaluationContext)new StandardEvaluationContext());
/*  84 */     for (int i = 0; i < childCount; i++) {
/*  85 */       Object key; SpelNode keyChild = getChild(i++);
/*     */       
/*  87 */       if (keyChild instanceof Literal) { Literal literal = (Literal)keyChild;
/*  88 */         key = literal.getLiteralValue().getValue(); }
/*     */       
/*  90 */       else if (keyChild instanceof PropertyOrFieldReference) { PropertyOrFieldReference propertyOrFieldReference = (PropertyOrFieldReference)keyChild;
/*  91 */         key = propertyOrFieldReference.getName(); }
/*     */       
/*  93 */       else if (keyChild instanceof OpMinus)
/*  94 */       { key = keyChild.getValue(expressionState); }
/*     */       else
/*     */       
/*  97 */       { return null; }
/*     */ 
/*     */       
/* 100 */       SpelNode valueChild = getChild(i);
/* 101 */       Object<Object> value = null;
/* 102 */       if (valueChild instanceof Literal) { Literal literal = (Literal)valueChild;
/* 103 */         value = (Object<Object>)literal.getLiteralValue().getValue(); }
/*     */       
/* 105 */       else if (valueChild instanceof InlineList) { InlineList inlineList = (InlineList)valueChild;
/* 106 */         value = (Object<Object>)inlineList.getConstantValue(); }
/*     */       
/* 108 */       else if (valueChild instanceof InlineMap) { InlineMap inlineMap = (InlineMap)valueChild;
/* 109 */         value = (Object)inlineMap.getConstantValue(); }
/*     */       
/* 111 */       else if (valueChild instanceof OpMinus)
/* 112 */       { value = (Object<Object>)valueChild.getValue(expressionState); }
/*     */       
/* 114 */       constantMap.put(key, value);
/*     */     } 
/* 116 */     return new TypedValue(Collections.unmodifiableMap(constantMap));
/*     */   }
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState expressionState) throws EvaluationException {
/* 121 */     if (this.constant != null) {
/* 122 */       return this.constant;
/*     */     }
/*     */     
/* 125 */     Map<Object, Object> returnValue = new LinkedHashMap<>();
/* 126 */     int childcount = getChildCount();
/* 127 */     for (int c = 0; c < childcount; c++) {
/* 128 */       SpelNode keyChild = getChild(c++);
/* 129 */       Object key = null;
/* 130 */       if (keyChild instanceof PropertyOrFieldReference) { PropertyOrFieldReference reference = (PropertyOrFieldReference)keyChild;
/* 131 */         key = reference.getName(); }
/*     */       else
/*     */       
/* 134 */       { key = keyChild.getValue(expressionState); }
/*     */       
/* 136 */       Object value = getChild(c).getValue(expressionState);
/* 137 */       returnValue.put(key, value);
/*     */     } 
/* 139 */     return new TypedValue(returnValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 145 */     StringBuilder sb = new StringBuilder("{");
/* 146 */     for (int c = 0; c < getChildCount(); c++) {
/* 147 */       if (c > 0) {
/* 148 */         sb.append(',');
/*     */       }
/* 150 */       sb.append(getChild(c++).toStringAST());
/* 151 */       sb.append(':');
/* 152 */       sb.append(getChild(c).toStringAST());
/*     */     } 
/* 154 */     sb.append('}');
/* 155 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConstant() {
/* 162 */     return (this.constant != null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Map<Object, Object> getConstantValue() {
/* 168 */     Assert.state((this.constant != null), "No constant");
/* 169 */     return (Map<Object, Object>)this.constant.getValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\InlineMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */