/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpPlus
/*     */   extends Operator
/*     */ {
/*     */   private static final int MAX_CONCATENATED_STRING_LENGTH = 100000;
/*     */   
/*     */   public OpPlus(int startPos, int endPos, SpelNodeImpl... operands) {
/*  64 */     super("+", startPos, endPos, operands);
/*  65 */     Assert.notEmpty((Object[])operands, "Operands must not be empty");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  71 */     SpelNodeImpl leftOp = getLeftOperand();
/*     */     
/*  73 */     if (this.children.length < 2) {
/*  74 */       Object operandOne = leftOp.getValueInternal(state).getValue();
/*  75 */       if (operandOne instanceof Number) {
/*  76 */         if (operandOne instanceof Double) {
/*  77 */           this.exitTypeDescriptor = "D";
/*     */         }
/*  79 */         else if (operandOne instanceof Float) {
/*  80 */           this.exitTypeDescriptor = "F";
/*     */         }
/*  82 */         else if (operandOne instanceof Long) {
/*  83 */           this.exitTypeDescriptor = "J";
/*     */         }
/*  85 */         else if (operandOne instanceof Integer) {
/*  86 */           this.exitTypeDescriptor = "I";
/*     */         } 
/*  88 */         return new TypedValue(operandOne);
/*     */       } 
/*  90 */       return state.operate(Operation.ADD, operandOne, null);
/*     */     } 
/*     */     
/*  93 */     TypedValue operandOneValue = leftOp.getValueInternal(state);
/*  94 */     Object leftOperand = operandOneValue.getValue();
/*  95 */     TypedValue operandTwoValue = getRightOperand().getValueInternal(state);
/*  96 */     Object rightOperand = operandTwoValue.getValue();
/*     */     
/*  98 */     if (leftOperand instanceof Number) { Number leftNumber = (Number)leftOperand; if (rightOperand instanceof Number) { Number rightNumber = (Number)rightOperand;
/*  99 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/* 100 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/* 101 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/* 102 */           return new TypedValue(leftBigDecimal.add(rightBigDecimal));
/*     */         } 
/* 104 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/* 105 */           this.exitTypeDescriptor = "D";
/* 106 */           return new TypedValue(Double.valueOf(leftNumber.doubleValue() + rightNumber.doubleValue()));
/*     */         } 
/* 108 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/* 109 */           this.exitTypeDescriptor = "F";
/* 110 */           return new TypedValue(Float.valueOf(leftNumber.floatValue() + rightNumber.floatValue()));
/*     */         } 
/* 112 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/* 113 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/* 114 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/* 115 */           return new TypedValue(leftBigInteger.add(rightBigInteger));
/*     */         } 
/* 117 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/* 118 */           this.exitTypeDescriptor = "J";
/* 119 */           return new TypedValue(Long.valueOf(leftNumber.longValue() + rightNumber.longValue()));
/*     */         } 
/* 121 */         if (CodeFlow.isIntegerForNumericOp(leftNumber) || CodeFlow.isIntegerForNumericOp(rightNumber)) {
/* 122 */           this.exitTypeDescriptor = "I";
/* 123 */           return new TypedValue(Integer.valueOf(leftNumber.intValue() + rightNumber.intValue()));
/*     */         } 
/*     */ 
/*     */         
/* 127 */         return new TypedValue(Double.valueOf(leftNumber.doubleValue() + rightNumber.doubleValue())); }
/*     */        }
/*     */ 
/*     */     
/* 131 */     if (leftOperand instanceof String) { String leftString = (String)leftOperand; if (rightOperand instanceof String) { String rightString = (String)rightOperand;
/* 132 */         this.exitTypeDescriptor = "Ljava/lang/String";
/* 133 */         checkStringLength(leftString);
/* 134 */         checkStringLength(rightString);
/* 135 */         return concatenate(leftString, rightString); }
/*     */        }
/*     */     
/* 138 */     if (leftOperand instanceof String) { String leftString = (String)leftOperand;
/* 139 */       checkStringLength(leftString);
/* 140 */       String rightString = (rightOperand == null) ? "null" : convertTypedValueToString(operandTwoValue, state);
/* 141 */       checkStringLength(rightString);
/* 142 */       return concatenate(leftString, rightString); }
/*     */ 
/*     */     
/* 145 */     if (rightOperand instanceof String) { String rightString = (String)rightOperand;
/* 146 */       checkStringLength(rightString);
/* 147 */       String leftString = (leftOperand == null) ? "null" : convertTypedValueToString(operandOneValue, state);
/* 148 */       checkStringLength(leftString);
/* 149 */       return concatenate(leftString, rightString); }
/*     */ 
/*     */     
/* 152 */     return state.operate(Operation.ADD, leftOperand, rightOperand);
/*     */   }
/*     */   
/*     */   private void checkStringLength(String string) {
/* 156 */     if (string.length() > 100000)
/* 157 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.MAX_CONCATENATED_STRING_LENGTH_EXCEEDED, new Object[] {
/* 158 */             Integer.valueOf(100000)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private TypedValue concatenate(String leftString, String rightString) {
/* 163 */     String result = leftString + leftString;
/* 164 */     checkStringLength(result);
/* 165 */     return new TypedValue(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 170 */     if (this.children.length < 2) {
/* 171 */       return "+" + getLeftOperand().toStringAST();
/*     */     }
/* 173 */     return super.toStringAST();
/*     */   }
/*     */ 
/*     */   
/*     */   public SpelNodeImpl getRightOperand() {
/* 178 */     if (this.children.length < 2) {
/* 179 */       throw new IllegalStateException("No right operand");
/*     */     }
/* 181 */     return this.children[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String convertTypedValueToString(TypedValue value, ExpressionState state) {
/* 192 */     TypeConverter typeConverter = state.getEvaluationContext().getTypeConverter();
/* 193 */     TypeDescriptor typeDescriptor = TypeDescriptor.valueOf(String.class);
/* 194 */     if (typeConverter.canConvert(value.getTypeDescriptor(), typeDescriptor)) {
/* 195 */       return String.valueOf(typeConverter.convertValue(value.getValue(), value
/* 196 */             .getTypeDescriptor(), typeDescriptor));
/*     */     }
/* 198 */     return String.valueOf(value.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 203 */     if (!getLeftOperand().isCompilable()) {
/* 204 */       return false;
/*     */     }
/* 206 */     if (this.children.length > 1 && 
/* 207 */       !getRightOperand().isCompilable()) {
/* 208 */       return false;
/*     */     }
/*     */     
/* 211 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void walk(MethodVisitor mv, CodeFlow cf, @Nullable SpelNodeImpl operand) {
/* 219 */     if (operand instanceof OpPlus) { OpPlus plus = (OpPlus)operand;
/* 220 */       walk(mv, cf, plus.getLeftOperand());
/* 221 */       walk(mv, cf, plus.getRightOperand()); }
/*     */     
/* 223 */     else if (operand != null)
/* 224 */     { cf.enterCompilationScope();
/* 225 */       operand.generateCode(mv, cf);
/* 226 */       if (!"Ljava/lang/String".equals(cf.lastDescriptor())) {
/* 227 */         mv.visitTypeInsn(192, "java/lang/String");
/*     */       }
/* 229 */       cf.exitCompilationScope();
/* 230 */       mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 236 */     if ("Ljava/lang/String".equals(this.exitTypeDescriptor)) {
/* 237 */       mv.visitTypeInsn(187, "java/lang/StringBuilder");
/* 238 */       mv.visitInsn(89);
/* 239 */       mv.visitMethodInsn(183, "java/lang/StringBuilder", "<init>", "()V", false);
/* 240 */       walk(mv, cf, getLeftOperand());
/* 241 */       walk(mv, cf, getRightOperand());
/* 242 */       mv.visitMethodInsn(182, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;", false);
/*     */     } else {
/*     */       
/* 245 */       this.children[0].generateCode(mv, cf);
/* 246 */       String leftDesc = (this.children[0]).exitTypeDescriptor;
/* 247 */       String exitDesc = this.exitTypeDescriptor;
/* 248 */       Assert.state((exitDesc != null), "No exit type descriptor");
/* 249 */       char targetDesc = exitDesc.charAt(0);
/* 250 */       CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, leftDesc, targetDesc);
/* 251 */       if (this.children.length > 1) {
/* 252 */         cf.enterCompilationScope();
/* 253 */         this.children[1].generateCode(mv, cf);
/* 254 */         String rightDesc = (this.children[1]).exitTypeDescriptor;
/* 255 */         cf.exitCompilationScope();
/* 256 */         CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, rightDesc, targetDesc);
/* 257 */         switch (targetDesc) { case 'I':
/* 258 */             mv.visitInsn(96); break;
/* 259 */           case 'J': mv.visitInsn(97); break;
/* 260 */           case 'F': mv.visitInsn(98); break;
/* 261 */           case 'D': mv.visitInsn(99); break;
/* 262 */           default: throw new IllegalStateException("Unrecognized exit type descriptor: '" + this.exitTypeDescriptor + "'"); }
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 267 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpPlus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */