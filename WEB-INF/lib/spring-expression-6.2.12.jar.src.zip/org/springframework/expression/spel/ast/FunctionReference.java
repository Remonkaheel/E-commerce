/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodType;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.StringJoiner;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.support.ReflectionHelper;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final String name;
/*     */   @Nullable
/*     */   private volatile Method method;
/*     */   
/*     */   public FunctionReference(String functionName, int startPos, int endPos, SpelNodeImpl... arguments) {
/*  70 */     super(startPos, endPos, arguments);
/*  71 */     this.name = functionName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  77 */     TypedValue value = state.lookupVariable(this.name);
/*  78 */     if (value == TypedValue.NULL) {
/*  79 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.FUNCTION_NOT_DEFINED, new Object[] { this.name });
/*     */     }
/*  81 */     Object function = value.getValue();
/*     */ 
/*     */ 
/*     */     
/*  85 */     if (function instanceof Method) { Method javaMethod = (Method)function;
/*     */       try {
/*  87 */         return executeFunctionViaMethod(state, javaMethod);
/*     */       }
/*  89 */       catch (SpelEvaluationException ex) {
/*  90 */         ex.setPosition(getStartPosition());
/*  91 */         throw ex;
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (function instanceof MethodHandle) { MethodHandle methodHandle = (MethodHandle)function;
/*     */       try {
/*  98 */         return executeFunctionViaMethodHandle(state, methodHandle);
/*     */       }
/* 100 */       catch (SpelEvaluationException ex) {
/* 101 */         ex.setPosition(getStartPosition());
/* 102 */         throw ex;
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/* 107 */     throw new SpelEvaluationException(SpelMessage.FUNCTION_REFERENCE_CANNOT_BE_INVOKED, new Object[] { this.name, value
/* 108 */           .getClass() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue executeFunctionViaMethod(ExpressionState state, Method method) throws EvaluationException {
/* 119 */     Object[] functionArgs = getArguments(state);
/*     */     
/* 121 */     if (!method.isVarArgs()) {
/* 122 */       int declaredParamCount = method.getParameterCount();
/* 123 */       if (declaredParamCount != functionArgs.length) {
/* 124 */         throw new SpelEvaluationException(SpelMessage.INCORRECT_NUMBER_OF_ARGUMENTS_TO_FUNCTION, new Object[] { this.name, 
/* 125 */               Integer.valueOf(functionArgs.length), Integer.valueOf(declaredParamCount) });
/*     */       }
/*     */     } 
/* 128 */     if (!Modifier.isStatic(method.getModifiers())) {
/* 129 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.FUNCTION_MUST_BE_STATIC, new Object[] {
/* 130 */             ClassUtils.getQualifiedMethodName(method), this.name
/*     */           });
/*     */     }
/*     */     
/* 134 */     TypeConverter converter = state.getEvaluationContext().getTypeConverter();
/* 135 */     boolean argumentConversionOccurred = ReflectionHelper.convertAllArguments(converter, functionArgs, method);
/* 136 */     if (method.isVarArgs()) {
/* 137 */       functionArgs = ReflectionHelper.setupArgumentsForVarargsInvocation(method
/* 138 */           .getParameterTypes(), functionArgs);
/*     */     }
/* 140 */     boolean compilable = false;
/*     */     
/*     */     try {
/* 143 */       ReflectionUtils.makeAccessible(method);
/* 144 */       Object result = method.invoke(method.getClass(), functionArgs);
/* 145 */       compilable = !argumentConversionOccurred;
/* 146 */       return new TypedValue(result, (new TypeDescriptor(new MethodParameter(method, -1))).narrow(result));
/*     */     }
/* 148 */     catch (Exception ex) {
/* 149 */       if (ex instanceof InvocationTargetException) { InvocationTargetException ite = (InvocationTargetException)ex; if (ite.getCause() != null); }
/* 150 */        Throwable cause = ex;
/* 151 */       throw new SpelEvaluationException(getStartPosition(), cause, SpelMessage.EXCEPTION_DURING_FUNCTION_CALL, new Object[] { this.name, cause
/* 152 */             .getMessage() });
/*     */     } finally {
/*     */       
/* 155 */       if (compilable) {
/* 156 */         this.exitTypeDescriptor = CodeFlow.toDescriptor(method.getReturnType());
/* 157 */         this.method = method;
/*     */       } else {
/*     */         
/* 160 */         this.exitTypeDescriptor = null;
/* 161 */         this.method = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedValue executeFunctionViaMethodHandle(ExpressionState state, MethodHandle methodHandle) throws EvaluationException {
/* 178 */     Object[] functionArgs = getArguments(state);
/* 179 */     MethodType declaredParams = methodHandle.type();
/* 180 */     int spelParamCount = functionArgs.length;
/* 181 */     int declaredParamCount = declaredParams.parameterCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     boolean isSuspectedVarargs = declaredParams.lastParameterType().isArray();
/*     */     
/* 189 */     if (isSuspectedVarargs) {
/* 190 */       if (spelParamCount < declaredParamCount - 1)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 196 */         throw new SpelEvaluationException(SpelMessage.INCORRECT_NUMBER_OF_ARGUMENTS_TO_FUNCTION, new Object[] { this.name, 
/* 197 */               Integer.valueOf(spelParamCount), "" + declaredParamCount - 1 + " or more" });
/*     */       }
/*     */     }
/* 200 */     else if (spelParamCount != declaredParamCount) {
/*     */ 
/*     */       
/* 203 */       throw new SpelEvaluationException(SpelMessage.INCORRECT_NUMBER_OF_ARGUMENTS_TO_FUNCTION, new Object[] { this.name, 
/* 204 */             Integer.valueOf(spelParamCount), Integer.valueOf(declaredParamCount) });
/*     */     } 
/*     */ 
/*     */     
/* 208 */     if (declaredParamCount == 0) {
/*     */       try {
/* 210 */         return new TypedValue(methodHandle.invoke());
/*     */       }
/* 212 */       catch (Throwable ex) {
/* 213 */         throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_FUNCTION_CALL, new Object[] { this.name, ex
/* 214 */               .getMessage() });
/*     */       }
/*     */       finally {
/*     */         
/* 218 */         this.exitTypeDescriptor = null;
/* 219 */         this.method = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 224 */     Integer varArgPosition = null;
/* 225 */     if (isSuspectedVarargs) {
/* 226 */       varArgPosition = Integer.valueOf(declaredParamCount - 1);
/*     */     }
/* 228 */     TypeConverter converter = state.getEvaluationContext().getTypeConverter();
/* 229 */     ReflectionHelper.convertAllMethodHandleArguments(converter, functionArgs, methodHandle, varArgPosition);
/*     */     
/* 231 */     if (isSuspectedVarargs) {
/* 232 */       if (declaredParamCount == 1 && !methodHandle.isVarargsCollector()) {
/*     */ 
/*     */ 
/*     */         
/* 236 */         functionArgs = ReflectionHelper.setupArgumentsForVarargsInvocation(methodHandle
/* 237 */             .type().parameterArray(), functionArgs);
/*     */       }
/* 239 */       else if (spelParamCount == declaredParamCount) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 246 */         int actualVarargsIndex = functionArgs.length - 1;
/* 247 */         if (actualVarargsIndex >= 0) { Object object = functionArgs[actualVarargsIndex]; if (object instanceof Object[]) { Object[] argsToUnpack = (Object[])object;
/* 248 */             Object[] newArgs = new Object[actualVarargsIndex + argsToUnpack.length];
/* 249 */             System.arraycopy(functionArgs, 0, newArgs, 0, actualVarargsIndex);
/* 250 */             System.arraycopy(argsToUnpack, 0, newArgs, actualVarargsIndex, argsToUnpack.length);
/* 251 */             functionArgs = newArgs; }
/*     */            }
/*     */       
/*     */       } 
/*     */     }
/*     */     try {
/* 257 */       return new TypedValue(methodHandle.invokeWithArguments(functionArgs));
/*     */     }
/* 259 */     catch (Throwable ex) {
/* 260 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_FUNCTION_CALL, new Object[] { this.name, ex
/* 261 */             .getMessage() });
/*     */     }
/*     */     finally {
/*     */       
/* 265 */       this.exitTypeDescriptor = null;
/* 266 */       this.method = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 272 */     StringJoiner sj = new StringJoiner(",", "(", ")");
/* 273 */     for (int i = 0; i < getChildCount(); i++) {
/* 274 */       sj.add(getChild(i).toStringAST());
/*     */     }
/* 276 */     return "#" + this.name + String.valueOf(sj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object[] getArguments(ExpressionState state) throws EvaluationException {
/* 285 */     Object[] arguments = new Object[getChildCount()];
/* 286 */     for (int i = 0; i < arguments.length; i++) {
/* 287 */       arguments[i] = this.children[i].getValueInternal(state).getValue();
/*     */     }
/* 289 */     return arguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/* 294 */     Method method = this.method;
/* 295 */     if (method == null) {
/* 296 */       return false;
/*     */     }
/* 298 */     int methodModifiers = method.getModifiers();
/* 299 */     if (!Modifier.isStatic(methodModifiers) || !Modifier.isPublic(methodModifiers) || 
/* 300 */       !Modifier.isPublic(method.getDeclaringClass().getModifiers())) {
/* 301 */       return false;
/*     */     }
/* 303 */     for (SpelNodeImpl child : this.children) {
/* 304 */       if (!child.isCompilable()) {
/* 305 */         return false;
/*     */       }
/*     */     } 
/* 308 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 313 */     Method method = this.method;
/* 314 */     Assert.state((method != null), "No method handle");
/* 315 */     String classDesc = method.getDeclaringClass().getName().replace('.', '/');
/* 316 */     generateCodeForArguments(mv, cf, method, this.children);
/* 317 */     mv.visitMethodInsn(184, classDesc, method.getName(), 
/* 318 */         CodeFlow.createSignatureDescriptor(method), false);
/* 319 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\FunctionReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */