/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import org.springframework.asm.MethodVisitor;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.expression.spel.CodeFlow;
/*    */ import org.springframework.expression.spel.ExpressionState;
/*    */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpEQ
/*    */   extends Operator
/*    */ {
/*    */   public OpEQ(int startPos, int endPos, SpelNodeImpl... operands) {
/* 35 */     super("==", startPos, endPos, operands);
/* 36 */     this.exitTypeDescriptor = "Z";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 42 */     Object left = getLeftOperand().getValueInternal(state).getValue();
/* 43 */     Object right = getRightOperand().getValueInternal(state).getValue();
/* 44 */     this.leftActualDescriptor = CodeFlow.toDescriptorFromObject(left);
/* 45 */     this.rightActualDescriptor = CodeFlow.toDescriptorFromObject(right);
/* 46 */     return BooleanTypedValue.forValue(equalityCheck(state.getEvaluationContext(), left, right));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCompilable() {
/* 53 */     SpelNodeImpl left = getLeftOperand();
/* 54 */     SpelNodeImpl right = getRightOperand();
/* 55 */     if (!left.isCompilable() || !right.isCompilable()) {
/* 56 */       return false;
/*    */     }
/*    */     
/* 59 */     String leftDesc = left.exitTypeDescriptor;
/* 60 */     String rightDesc = right.exitTypeDescriptor;
/* 61 */     Operator.DescriptorComparison dc = Operator.DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*    */     
/* 63 */     return (!dc.areNumbers || dc.areCompatible);
/*    */   }
/*    */ 
/*    */   
/*    */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 68 */     cf.loadEvaluationContext(mv);
/* 69 */     String leftDesc = (getLeftOperand()).exitTypeDescriptor;
/* 70 */     String rightDesc = (getRightOperand()).exitTypeDescriptor;
/*    */     
/* 72 */     cf.enterCompilationScope();
/* 73 */     getLeftOperand().generateCode(mv, cf);
/* 74 */     cf.exitCompilationScope();
/* 75 */     if (CodeFlow.isPrimitive(leftDesc)) {
/* 76 */       CodeFlow.insertBoxIfNecessary(mv, leftDesc.charAt(0));
/*    */     }
/* 78 */     cf.enterCompilationScope();
/* 79 */     getRightOperand().generateCode(mv, cf);
/* 80 */     cf.exitCompilationScope();
/* 81 */     if (CodeFlow.isPrimitive(rightDesc)) {
/* 82 */       CodeFlow.insertBoxIfNecessary(mv, rightDesc.charAt(0));
/*    */     }
/*    */     
/* 85 */     String operatorClassName = Operator.class.getName().replace('.', '/');
/* 86 */     String evaluationContextClassName = EvaluationContext.class.getName().replace('.', '/');
/* 87 */     mv.visitMethodInsn(184, operatorClassName, "equalityCheck", "(L" + evaluationContextClassName + ";Ljava/lang/Object;Ljava/lang/Object;)Z", false);
/*    */     
/* 89 */     cf.pushDescriptor("Z");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpEQ.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */