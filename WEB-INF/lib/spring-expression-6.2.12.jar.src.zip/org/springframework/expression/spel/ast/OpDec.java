/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpDec
/*     */   extends Operator
/*     */ {
/*     */   private static final String DEC = "--";
/*     */   private final boolean postfix;
/*     */   
/*     */   public OpDec(int startPos, int endPos, boolean postfix, SpelNodeImpl... operands) {
/*  48 */     super("--", startPos, endPos, operands);
/*  49 */     this.postfix = postfix;
/*  50 */     Assert.notEmpty((Object[])operands, "Operands must not be empty");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  56 */     if (!state.getEvaluationContext().isAssignmentEnabled()) {
/*  57 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.OPERAND_NOT_DECREMENTABLE, new Object[] { toStringAST() });
/*     */     }
/*     */     
/*  60 */     SpelNodeImpl operand = getLeftOperand();
/*     */ 
/*     */     
/*  63 */     ValueRef lvalue = operand.getValueRef(state);
/*     */     
/*  65 */     TypedValue operandTypedValue = lvalue.getValue();
/*  66 */     Object operandValue = operandTypedValue.getValue();
/*  67 */     TypedValue returnValue = operandTypedValue;
/*  68 */     TypedValue newValue = null;
/*     */     
/*  70 */     if (operandValue instanceof Number) { Number op1 = (Number)operandValue;
/*  71 */       if (op1 instanceof BigDecimal) { BigDecimal bigDecimal = (BigDecimal)op1;
/*  72 */         newValue = new TypedValue(bigDecimal.subtract(BigDecimal.ONE), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  74 */       else if (op1 instanceof Double)
/*  75 */       { newValue = new TypedValue(Double.valueOf(op1.doubleValue() - 1.0D), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  77 */       else if (op1 instanceof Float)
/*  78 */       { newValue = new TypedValue(Float.valueOf(op1.floatValue() - 1.0F), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  80 */       else if (op1 instanceof BigInteger) { BigInteger bigInteger = (BigInteger)op1;
/*  81 */         newValue = new TypedValue(bigInteger.subtract(BigInteger.ONE), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  83 */       else if (op1 instanceof Long)
/*  84 */       { newValue = new TypedValue(Long.valueOf(op1.longValue() - 1L), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  86 */       else if (op1 instanceof Integer)
/*  87 */       { newValue = new TypedValue(Integer.valueOf(op1.intValue() - 1), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  89 */       else if (op1 instanceof Short)
/*  90 */       { newValue = new TypedValue(Integer.valueOf(op1.shortValue() - 1), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*  92 */       else if (op1 instanceof Byte)
/*  93 */       { newValue = new TypedValue(Integer.valueOf(op1.byteValue() - 1), operandTypedValue.getTypeDescriptor()); }
/*     */       
/*     */       else
/*     */       
/*  97 */       { newValue = new TypedValue(Double.valueOf(op1.doubleValue() - 1.0D), operandTypedValue.getTypeDescriptor()); }
/*     */        }
/*     */ 
/*     */     
/* 101 */     if (newValue == null) {
/*     */       try {
/* 103 */         newValue = state.operate(Operation.SUBTRACT, returnValue.getValue(), Integer.valueOf(1));
/*     */       }
/* 105 */       catch (SpelEvaluationException ex) {
/* 106 */         if (ex.getMessageCode() == SpelMessage.OPERATOR_NOT_SUPPORTED_BETWEEN_TYPES)
/*     */         {
/* 108 */           throw new SpelEvaluationException(operand.getStartPosition(), SpelMessage.OPERAND_NOT_DECREMENTABLE, new Object[] { operand
/* 109 */                 .toStringAST() });
/*     */         }
/*     */         
/* 112 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 119 */       lvalue.setValue(newValue.getValue());
/*     */     }
/* 121 */     catch (SpelEvaluationException see) {
/*     */       
/* 123 */       if (see.getMessageCode() == SpelMessage.SETVALUE_NOT_SUPPORTED) {
/* 124 */         throw new SpelEvaluationException(operand.getStartPosition(), SpelMessage.OPERAND_NOT_DECREMENTABLE, new Object[0]);
/*     */       }
/*     */ 
/*     */       
/* 128 */       throw see;
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (!this.postfix)
/*     */     {
/* 134 */       returnValue = newValue;
/*     */     }
/*     */     
/* 137 */     return returnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 142 */     String ast = getLeftOperand().toStringAST();
/* 143 */     return this.postfix ? (ast + "--") : ("--" + ast);
/*     */   }
/*     */ 
/*     */   
/*     */   public SpelNodeImpl getRightOperand() {
/* 148 */     throw new IllegalStateException("No right operand");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpDec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */