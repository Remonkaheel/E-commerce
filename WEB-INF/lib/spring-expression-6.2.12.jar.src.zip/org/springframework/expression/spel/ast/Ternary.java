/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ternary
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   public Ternary(int startPos, int endPos, SpelNodeImpl... args) {
/*  41 */     super(startPos, endPos, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  54 */     Boolean value = this.children[0].<Boolean>getValue(state, Boolean.class);
/*  55 */     if (value == null) {
/*  56 */       throw new SpelEvaluationException(getChild(0).getStartPosition(), SpelMessage.TYPE_CONVERSION_ERROR, new Object[] { "null", "boolean" });
/*     */     }
/*     */     
/*  59 */     TypedValue result = this.children[value.booleanValue() ? 1 : 2].getValueInternal(state);
/*  60 */     computeExitTypeDescriptor();
/*  61 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/*  66 */     return "(" + getChild(0).toStringAST() + " ? " + getChild(1).toStringAST() + " : " + getChild(2).toStringAST() + ")";
/*     */   }
/*     */   
/*     */   private void computeExitTypeDescriptor() {
/*  70 */     if (this.exitTypeDescriptor == null && (this.children[1]).exitTypeDescriptor != null && (this.children[2]).exitTypeDescriptor != null) {
/*     */       
/*  72 */       String leftDescriptor = (this.children[1]).exitTypeDescriptor;
/*  73 */       String rightDescriptor = (this.children[2]).exitTypeDescriptor;
/*  74 */       if (ObjectUtils.nullSafeEquals(leftDescriptor, rightDescriptor)) {
/*  75 */         this.exitTypeDescriptor = leftDescriptor;
/*     */       }
/*     */       else {
/*     */         
/*  79 */         this.exitTypeDescriptor = "Ljava/lang/Object";
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  86 */     SpelNodeImpl condition = this.children[0];
/*  87 */     SpelNodeImpl left = this.children[1];
/*  88 */     SpelNodeImpl right = this.children[2];
/*  89 */     return (condition.isCompilable() && left.isCompilable() && right.isCompilable() && 
/*  90 */       CodeFlow.isBooleanCompatible(condition.exitTypeDescriptor) && left.exitTypeDescriptor != null && right.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/*  97 */     computeExitTypeDescriptor();
/*  98 */     cf.enterCompilationScope();
/*  99 */     this.children[0].generateCode(mv, cf);
/* 100 */     String lastDesc = cf.lastDescriptor();
/* 101 */     Assert.state((lastDesc != null), "No last descriptor");
/* 102 */     if (!CodeFlow.isPrimitive(lastDesc)) {
/* 103 */       CodeFlow.insertUnboxInsns(mv, 'Z', lastDesc);
/*     */     }
/* 105 */     cf.exitCompilationScope();
/* 106 */     Label elseTarget = new Label();
/* 107 */     Label endOfIf = new Label();
/* 108 */     mv.visitJumpInsn(153, elseTarget);
/* 109 */     cf.enterCompilationScope();
/* 110 */     this.children[1].generateCode(mv, cf);
/* 111 */     if (!CodeFlow.isPrimitive(this.exitTypeDescriptor)) {
/* 112 */       lastDesc = cf.lastDescriptor();
/* 113 */       Assert.state((lastDesc != null), "No last descriptor");
/* 114 */       CodeFlow.insertBoxIfNecessary(mv, lastDesc.charAt(0));
/*     */     } 
/* 116 */     cf.exitCompilationScope();
/* 117 */     mv.visitJumpInsn(167, endOfIf);
/* 118 */     mv.visitLabel(elseTarget);
/* 119 */     cf.enterCompilationScope();
/* 120 */     this.children[2].generateCode(mv, cf);
/* 121 */     if (!CodeFlow.isPrimitive(this.exitTypeDescriptor)) {
/* 122 */       lastDesc = cf.lastDescriptor();
/* 123 */       Assert.state((lastDesc != null), "No last descriptor");
/* 124 */       CodeFlow.insertBoxIfNecessary(mv, lastDesc.charAt(0));
/*     */     } 
/* 126 */     cf.exitCompilationScope();
/* 127 */     mv.visitLabel(endOfIf);
/* 128 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Ternary.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */