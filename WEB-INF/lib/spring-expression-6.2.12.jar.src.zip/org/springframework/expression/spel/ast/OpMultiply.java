/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpMultiply
/*     */   extends Operator
/*     */ {
/*     */   private static final int MAX_REPEATED_TEXT_SIZE = 256;
/*     */   
/*     */   public OpMultiply(int startPos, int endPos, SpelNodeImpl... operands) {
/*  65 */     super("*", startPos, endPos, operands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  81 */     Object leftOperand = getLeftOperand().getValueInternal(state).getValue();
/*  82 */     Object rightOperand = getRightOperand().getValueInternal(state).getValue();
/*     */     
/*  84 */     if (leftOperand instanceof Number) { Number leftNumber = (Number)leftOperand; if (rightOperand instanceof Number) { Number rightNumber = (Number)rightOperand;
/*  85 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/*  86 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/*  87 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/*  88 */           return new TypedValue(leftBigDecimal.multiply(rightBigDecimal));
/*     */         } 
/*  90 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/*  91 */           this.exitTypeDescriptor = "D";
/*  92 */           return new TypedValue(Double.valueOf(leftNumber.doubleValue() * rightNumber.doubleValue()));
/*     */         } 
/*  94 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/*  95 */           this.exitTypeDescriptor = "F";
/*  96 */           return new TypedValue(Float.valueOf(leftNumber.floatValue() * rightNumber.floatValue()));
/*     */         } 
/*  98 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/*  99 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/* 100 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/* 101 */           return new TypedValue(leftBigInteger.multiply(rightBigInteger));
/*     */         } 
/* 103 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/* 104 */           this.exitTypeDescriptor = "J";
/* 105 */           return new TypedValue(Long.valueOf(leftNumber.longValue() * rightNumber.longValue()));
/*     */         } 
/* 107 */         if (CodeFlow.isIntegerForNumericOp(leftNumber) || CodeFlow.isIntegerForNumericOp(rightNumber)) {
/* 108 */           this.exitTypeDescriptor = "I";
/* 109 */           return new TypedValue(Integer.valueOf(leftNumber.intValue() * rightNumber.intValue()));
/*     */         } 
/*     */ 
/*     */         
/* 113 */         return new TypedValue(Double.valueOf(leftNumber.doubleValue() * rightNumber.doubleValue())); }
/*     */        }
/*     */ 
/*     */     
/* 117 */     if (leftOperand instanceof String) { String text = (String)leftOperand; if (rightOperand instanceof Integer) { Integer count = (Integer)rightOperand;
/* 118 */         checkRepeatedTextSize(text, count.intValue());
/* 119 */         return new TypedValue(text.repeat(count.intValue())); }
/*     */        }
/*     */     
/* 122 */     return state.operate(Operation.MULTIPLY, leftOperand, rightOperand);
/*     */   }
/*     */   
/*     */   private void checkRepeatedTextSize(String text, int count) {
/* 126 */     if (count < 0)
/* 127 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.NEGATIVE_REPEATED_TEXT_COUNT, new Object[] {
/* 128 */             Integer.valueOf(count)
/*     */           }); 
/* 130 */     int result = text.length() * count;
/* 131 */     if (result < 0 || result > 256) {
/* 132 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.MAX_REPEATED_TEXT_SIZE_EXCEEDED, new Object[] {
/* 133 */             Integer.valueOf(256)
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCompilable() {
/* 139 */     if (!getLeftOperand().isCompilable()) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (this.children.length > 1 && 
/* 143 */       !getRightOperand().isCompilable()) {
/* 144 */       return false;
/*     */     }
/*     */     
/* 147 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 152 */     getLeftOperand().generateCode(mv, cf);
/* 153 */     String leftDesc = (getLeftOperand()).exitTypeDescriptor;
/* 154 */     String exitDesc = this.exitTypeDescriptor;
/* 155 */     Assert.state((exitDesc != null), "No exit type descriptor");
/* 156 */     char targetDesc = exitDesc.charAt(0);
/* 157 */     CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, leftDesc, targetDesc);
/* 158 */     if (this.children.length > 1) {
/* 159 */       cf.enterCompilationScope();
/* 160 */       getRightOperand().generateCode(mv, cf);
/* 161 */       String rightDesc = (getRightOperand()).exitTypeDescriptor;
/* 162 */       cf.exitCompilationScope();
/* 163 */       CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, rightDesc, targetDesc);
/* 164 */       switch (targetDesc) { case 'I':
/* 165 */           mv.visitInsn(104); break;
/* 166 */         case 'J': mv.visitInsn(105); break;
/* 167 */         case 'F': mv.visitInsn(106); break;
/* 168 */         case 'D': mv.visitInsn(107); break;
/* 169 */         default: throw new IllegalStateException("Unrecognized exit type descriptor: '" + this.exitTypeDescriptor + "'"); }
/*     */ 
/*     */     
/*     */     } 
/* 173 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpMultiply.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */