/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.math.RoundingMode;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpDivide
/*     */   extends Operator
/*     */ {
/*     */   public OpDivide(int startPos, int endPos, SpelNodeImpl... operands) {
/*  44 */     super("/", startPos, endPos, operands);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/*  50 */     Object leftOperand = getLeftOperand().getValueInternal(state).getValue();
/*  51 */     Object rightOperand = getRightOperand().getValueInternal(state).getValue();
/*     */     
/*  53 */     if (leftOperand instanceof Number) { Number leftNumber = (Number)leftOperand; if (rightOperand instanceof Number) { Number rightNumber = (Number)rightOperand;
/*  54 */         if (leftNumber instanceof BigDecimal || rightNumber instanceof BigDecimal) {
/*  55 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/*  56 */           BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/*  57 */           int scale = Math.max(leftBigDecimal.scale(), rightBigDecimal.scale());
/*  58 */           return new TypedValue(leftBigDecimal.divide(rightBigDecimal, scale, RoundingMode.HALF_EVEN));
/*     */         } 
/*  60 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/*  61 */           this.exitTypeDescriptor = "D";
/*  62 */           return new TypedValue(Double.valueOf(leftNumber.doubleValue() / rightNumber.doubleValue()));
/*     */         } 
/*  64 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/*  65 */           this.exitTypeDescriptor = "F";
/*  66 */           return new TypedValue(Float.valueOf(leftNumber.floatValue() / rightNumber.floatValue()));
/*     */         } 
/*  68 */         if (leftNumber instanceof BigInteger || rightNumber instanceof BigInteger) {
/*  69 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/*  70 */           BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/*  71 */           return new TypedValue(leftBigInteger.divide(rightBigInteger));
/*     */         } 
/*  73 */         if (leftNumber instanceof Long || rightNumber instanceof Long) {
/*  74 */           this.exitTypeDescriptor = "J";
/*  75 */           return new TypedValue(Long.valueOf(leftNumber.longValue() / rightNumber.longValue()));
/*     */         } 
/*  77 */         if (CodeFlow.isIntegerForNumericOp(leftNumber) || CodeFlow.isIntegerForNumericOp(rightNumber)) {
/*  78 */           this.exitTypeDescriptor = "I";
/*  79 */           return new TypedValue(Integer.valueOf(leftNumber.intValue() / rightNumber.intValue()));
/*     */         } 
/*     */ 
/*     */         
/*  83 */         return new TypedValue(Double.valueOf(leftNumber.doubleValue() / rightNumber.doubleValue())); }
/*     */        }
/*     */ 
/*     */     
/*  87 */     return state.operate(Operation.DIVIDE, leftOperand, rightOperand);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompilable() {
/*  92 */     if (!getLeftOperand().isCompilable()) {
/*  93 */       return false;
/*     */     }
/*  95 */     if (this.children.length > 1 && 
/*  96 */       !getRightOperand().isCompilable()) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     return (this.exitTypeDescriptor != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf) {
/* 105 */     getLeftOperand().generateCode(mv, cf);
/* 106 */     String leftDesc = (getLeftOperand()).exitTypeDescriptor;
/* 107 */     String exitDesc = this.exitTypeDescriptor;
/* 108 */     Assert.state((exitDesc != null), "No exit type descriptor");
/* 109 */     char targetDesc = exitDesc.charAt(0);
/* 110 */     CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, leftDesc, targetDesc);
/* 111 */     if (this.children.length > 1) {
/* 112 */       cf.enterCompilationScope();
/* 113 */       getRightOperand().generateCode(mv, cf);
/* 114 */       String rightDesc = (getRightOperand()).exitTypeDescriptor;
/* 115 */       cf.exitCompilationScope();
/* 116 */       CodeFlow.insertNumericUnboxOrPrimitiveTypeCoercion(mv, rightDesc, targetDesc);
/* 117 */       switch (targetDesc) { case 'I':
/* 118 */           mv.visitInsn(108); break;
/* 119 */         case 'J': mv.visitInsn(109); break;
/* 120 */         case 'F': mv.visitInsn(110); break;
/* 121 */         case 'D': mv.visitInsn(111); break;
/* 122 */         default: throw new IllegalStateException("Unrecognized exit type descriptor: '" + this.exitTypeDescriptor + "'"); }
/*     */ 
/*     */     
/*     */     } 
/* 126 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OpDivide.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */