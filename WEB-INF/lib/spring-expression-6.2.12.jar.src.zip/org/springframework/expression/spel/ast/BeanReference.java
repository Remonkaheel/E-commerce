/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.BeanResolver;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.expression.spel.ExpressionState;
/*    */ import org.springframework.expression.spel.SpelEvaluationException;
/*    */ import org.springframework.expression.spel.SpelMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanReference
/*    */   extends SpelNodeImpl
/*    */ {
/*    */   private static final String FACTORY_BEAN_PREFIX = "&";
/*    */   private final String beanName;
/*    */   
/*    */   public BeanReference(int startPos, int endPos, String beanName) {
/* 45 */     super(startPos, endPos, new SpelNodeImpl[0]);
/* 46 */     this.beanName = beanName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getName() {
/* 57 */     return this.beanName;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 62 */     BeanResolver beanResolver = state.getEvaluationContext().getBeanResolver();
/* 63 */     if (beanResolver == null) {
/* 64 */       throw new SpelEvaluationException(
/* 65 */           getStartPosition(), SpelMessage.NO_BEAN_RESOLVER_REGISTERED, new Object[] { this.beanName });
/*    */     }
/*    */     
/*    */     try {
/* 69 */       return new TypedValue(beanResolver.resolve(state.getEvaluationContext(), this.beanName));
/*    */     }
/* 71 */     catch (AccessException ex) {
/* 72 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_BEAN_RESOLUTION, new Object[] { this.beanName, ex
/* 73 */             .getMessage() });
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toStringAST() {
/* 79 */     StringBuilder sb = new StringBuilder();
/* 80 */     if (!this.beanName.startsWith("&")) {
/* 81 */       sb.append('@');
/*    */     }
/* 83 */     if (!this.beanName.contains(".")) {
/* 84 */       sb.append(this.beanName);
/*    */     } else {
/*    */       
/* 87 */       sb.append('\'').append(this.beanName).append('\'');
/*    */     } 
/* 89 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\BeanReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */