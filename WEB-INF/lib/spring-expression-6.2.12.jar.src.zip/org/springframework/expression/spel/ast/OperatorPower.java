/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.Operation;
/*    */ import org.springframework.expression.TypedValue;
/*    */ import org.springframework.expression.spel.ExpressionState;
/*    */ import org.springframework.util.NumberUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperatorPower
/*    */   extends Operator
/*    */ {
/*    */   public OperatorPower(int startPos, int endPos, SpelNodeImpl... operands) {
/* 38 */     super("^", startPos, endPos, operands);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException {
/* 44 */     SpelNodeImpl leftOp = getLeftOperand();
/* 45 */     SpelNodeImpl rightOp = getRightOperand();
/*    */     
/* 47 */     Object leftOperand = leftOp.getValueInternal(state).getValue();
/* 48 */     Object rightOperand = rightOp.getValueInternal(state).getValue();
/*    */     
/* 50 */     if (leftOperand instanceof Number) { Number leftNumber = (Number)leftOperand; if (rightOperand instanceof Number) { Number rightNumber = (Number)rightOperand;
/* 51 */         if (leftNumber instanceof BigDecimal) {
/* 52 */           BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/* 53 */           return new TypedValue(leftBigDecimal.pow(rightNumber.intValue()));
/*    */         } 
/* 55 */         if (leftNumber instanceof BigInteger) {
/* 56 */           BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/* 57 */           return new TypedValue(leftBigInteger.pow(rightNumber.intValue()));
/*    */         } 
/* 59 */         if (leftNumber instanceof Double || rightNumber instanceof Double) {
/* 60 */           return new TypedValue(Double.valueOf(Math.pow(leftNumber.doubleValue(), rightNumber.doubleValue())));
/*    */         }
/* 62 */         if (leftNumber instanceof Float || rightNumber instanceof Float) {
/* 63 */           return new TypedValue(Double.valueOf(Math.pow(leftNumber.floatValue(), rightNumber.floatValue())));
/*    */         }
/*    */         
/* 66 */         double d = Math.pow(leftNumber.doubleValue(), rightNumber.doubleValue());
/* 67 */         if (d > 2.147483647E9D || leftNumber instanceof Long || rightNumber instanceof Long) {
/* 68 */           return new TypedValue(Long.valueOf((long)d));
/*    */         }
/*    */         
/* 71 */         return new TypedValue(Integer.valueOf((int)d)); }
/*    */        }
/*    */ 
/*    */     
/* 75 */     return state.operate(Operation.POWER, leftOperand, rightOperand);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\OperatorPower.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */