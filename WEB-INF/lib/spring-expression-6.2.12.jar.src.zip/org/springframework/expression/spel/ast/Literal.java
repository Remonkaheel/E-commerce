/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.InternalParseException;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelParseException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Literal
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   @Nullable
/*     */   private final String originalValue;
/*     */   
/*     */   public Literal(@Nullable String originalValue, int startPos, int endPos) {
/*  41 */     super(startPos, endPos, new SpelNodeImpl[0]);
/*  42 */     this.originalValue = originalValue;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String getOriginalValue() {
/*  48 */     return this.originalValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypedValue getValueInternal(ExpressionState state) throws SpelEvaluationException {
/*  53 */     return getLiteralValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNumberLiteral() {
/*  62 */     return (this instanceof IntLiteral || this instanceof LongLiteral || this instanceof FloatLiteral || this instanceof RealLiteral);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  70 */     return String.valueOf(getLiteralValue().getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/*  75 */     return toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract TypedValue getLiteralValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Literal getIntLiteral(String numberToken, int startPos, int endPos, int radix) {
/*     */     try {
/*  92 */       int value = Integer.parseInt(numberToken, radix);
/*  93 */       return new IntLiteral(numberToken, startPos, endPos, value);
/*     */     }
/*  95 */     catch (NumberFormatException ex) {
/*  96 */       throw new InternalParseException(new SpelParseException(startPos, ex, SpelMessage.NOT_AN_INTEGER, new Object[] { numberToken }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Literal getLongLiteral(String numberToken, int startPos, int endPos, int radix) {
/*     */     try {
/* 102 */       long value = Long.parseLong(numberToken, radix);
/* 103 */       return new LongLiteral(numberToken, startPos, endPos, value);
/*     */     }
/* 105 */     catch (NumberFormatException ex) {
/* 106 */       throw new InternalParseException(new SpelParseException(startPos, ex, SpelMessage.NOT_A_LONG, new Object[] { numberToken }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Literal getRealLiteral(String numberToken, int startPos, int endPos, boolean isFloat) {
/*     */     try {
/* 112 */       if (isFloat) {
/* 113 */         float f = Float.parseFloat(numberToken);
/* 114 */         return new FloatLiteral(numberToken, startPos, endPos, f);
/*     */       } 
/*     */       
/* 117 */       double value = Double.parseDouble(numberToken);
/* 118 */       return new RealLiteral(numberToken, startPos, endPos, value);
/*     */     
/*     */     }
/* 121 */     catch (NumberFormatException ex) {
/* 122 */       throw new InternalParseException(new SpelParseException(startPos, ex, SpelMessage.NOT_A_REAL, new Object[] { numberToken }));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\ast\Literal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */