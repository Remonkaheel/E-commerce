/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.asm.ClassWriter;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Opcodes;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompiledExpression;
/*     */ import org.springframework.expression.spel.ast.SpelNodeImpl;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpelCompiler
/*     */   implements Opcodes
/*     */ {
/*     */   private static final int CLASSES_DEFINED_LIMIT = 100;
/*  73 */   private static final Log logger = LogFactory.getLog(SpelCompiler.class);
/*     */ 
/*     */ 
/*     */   
/*  77 */   private static final Map<ClassLoader, SpelCompiler> compilers = (Map<ClassLoader, SpelCompiler>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ChildClassLoader childClassLoader;
/*     */ 
/*     */   
/*  84 */   private final AtomicInteger suffixId = new AtomicInteger(0);
/*     */ 
/*     */   
/*     */   private SpelCompiler(@Nullable ClassLoader classloader) {
/*  88 */     this.childClassLoader = new ChildClassLoader(classloader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CompiledExpression compile(SpelNodeImpl expression) {
/* 103 */     if (expression.isCompilable()) {
/* 104 */       if (logger.isDebugEnabled()) {
/* 105 */         logger.debug("SpEL: compiling " + expression.toStringAST());
/*     */       }
/* 107 */       Class<? extends CompiledExpression> clazz = createExpressionClass(expression);
/* 108 */       if (clazz != null) {
/*     */         try {
/* 110 */           return ReflectionUtils.accessibleConstructor(clazz, new Class[0]).newInstance(new Object[0]);
/*     */         }
/* 112 */         catch (Throwable ex) {
/* 113 */           throw new IllegalStateException("Failed to instantiate CompiledExpression for expression: " + expression
/* 114 */               .toStringAST(), ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 119 */     if (logger.isDebugEnabled()) {
/* 120 */       logger.debug("SpEL: unable to compile " + expression.toStringAST());
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   private String getNextSuffix() {
/* 126 */     return "%05d".formatted(new Object[] { Integer.valueOf(this.suffixId.incrementAndGet()) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Class<? extends CompiledExpression> createExpressionClass(SpelNodeImpl expressionToCompile) {
/* 140 */     String className = "org/springframework/expression/spel/generated/CompiledExpression" + getNextSuffix();
/* 141 */     String evaluationContextClass = "org/springframework/expression/EvaluationContext";
/* 142 */     ClassWriter cw = new ExpressionClassWriter();
/* 143 */     cw.visit(52, 1, className, null, "org/springframework/expression/spel/CompiledExpression", null);
/*     */ 
/*     */     
/* 146 */     MethodVisitor mv = cw.visitMethod(1, "<init>", "()V", null, null);
/* 147 */     mv.visitCode();
/* 148 */     mv.visitVarInsn(25, 0);
/* 149 */     mv.visitMethodInsn(183, "org/springframework/expression/spel/CompiledExpression", "<init>", "()V", false);
/*     */     
/* 151 */     mv.visitInsn(177);
/* 152 */     mv.visitMaxs(1, 1);
/* 153 */     mv.visitEnd();
/*     */ 
/*     */     
/* 156 */     mv = cw.visitMethod(1, "getValue", "(Ljava/lang/Object;L" + evaluationContextClass + ";)Ljava/lang/Object;", null, new String[] { "org/springframework/expression/EvaluationException" });
/*     */ 
/*     */     
/* 159 */     mv.visitCode();
/*     */     
/* 161 */     CodeFlow cf = new CodeFlow(className, cw);
/*     */ 
/*     */     
/*     */     try {
/* 165 */       expressionToCompile.generateCode(mv, cf);
/*     */     }
/* 167 */     catch (IllegalStateException ex) {
/* 168 */       if (logger.isDebugEnabled()) {
/* 169 */         logger.debug(expressionToCompile.getClass().getSimpleName() + ".generateCode opted out of compilation: " + expressionToCompile.getClass().getSimpleName());
/*     */       }
/*     */       
/* 172 */       return null;
/*     */     } 
/*     */     
/* 175 */     CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor());
/* 176 */     if ("V".equals(cf.lastDescriptor())) {
/* 177 */       mv.visitInsn(1);
/*     */     }
/* 179 */     mv.visitInsn(176);
/*     */     
/* 181 */     mv.visitMaxs(0, 0);
/* 182 */     mv.visitEnd();
/* 183 */     cw.visitEnd();
/*     */     
/* 185 */     cf.finish();
/*     */     
/* 187 */     byte[] data = cw.toByteArray();
/*     */ 
/*     */     
/* 190 */     return loadClass(StringUtils.replace(className, "/", "."), data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<? extends CompiledExpression> loadClass(String name, byte[] bytes) {
/* 224 */     ChildClassLoader ccl = this.childClassLoader;
/* 225 */     if (ccl.getClassesDefinedCount() >= 100) {
/* 226 */       synchronized (this) {
/* 227 */         ChildClassLoader currentCcl = this.childClassLoader;
/* 228 */         if (ccl == currentCcl) {
/*     */           
/* 230 */           ccl = new ChildClassLoader(ccl.getParent());
/* 231 */           this.childClassLoader = ccl;
/*     */         }
/*     */         else {
/*     */           
/* 235 */           ccl = currentCcl;
/*     */         } 
/*     */       } 
/*     */     }
/* 239 */     return (Class)ccl.defineClass(name, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpelCompiler getCompiler(@Nullable ClassLoader classLoader) {
/* 251 */     ClassLoader clToUse = (classLoader != null) ? classLoader : ClassUtils.getDefaultClassLoader();
/*     */     
/* 253 */     SpelCompiler compiler = compilers.get(clToUse);
/* 254 */     if (compiler == null)
/*     */     {
/* 256 */       synchronized (compilers) {
/* 257 */         return compilers.computeIfAbsent(clToUse, SpelCompiler::new);
/*     */       } 
/*     */     }
/* 260 */     return compiler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean compile(Expression expression) {
/* 272 */     if (expression instanceof SpelExpression) { SpelExpression spelExpression = (SpelExpression)expression; if (spelExpression.compileExpression()); }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void revertToInterpreted(Expression expression) {
/* 281 */     if (expression instanceof SpelExpression) { SpelExpression spelExpression = (SpelExpression)expression;
/* 282 */       spelExpression.revertToInterpreted(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ChildClassLoader
/*     */     extends URLClassLoader
/*     */   {
/* 292 */     private static final URL[] NO_URLS = new URL[0];
/*     */     
/* 294 */     private final AtomicInteger classesDefinedCount = new AtomicInteger();
/*     */     
/*     */     public ChildClassLoader(@Nullable ClassLoader classLoader) {
/* 297 */       super(NO_URLS, classLoader);
/*     */     }
/*     */     
/*     */     public Class<?> defineClass(String name, byte[] bytes) {
/* 301 */       Class<?> clazz = defineClass(name, bytes, 0, bytes.length);
/* 302 */       this.classesDefinedCount.incrementAndGet();
/* 303 */       return clazz;
/*     */     }
/*     */     
/*     */     public int getClassesDefinedCount() {
/* 307 */       return this.classesDefinedCount.get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ExpressionClassWriter
/*     */     extends ClassWriter
/*     */   {
/*     */     public ExpressionClassWriter() {
/* 318 */       super(3);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getClassLoader() {
/* 323 */       return SpelCompiler.this.childClassLoader;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\standard\SpelCompiler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */