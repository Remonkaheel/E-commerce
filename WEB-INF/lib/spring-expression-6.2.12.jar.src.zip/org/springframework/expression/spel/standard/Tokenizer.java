/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.springframework.expression.spel.InternalParseException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Tokenizer
/*     */ {
/*  47 */   private static final String[] ALTERNATIVE_OPERATOR_NAMES = new String[] { "DIV", "EQ", "GE", "GT", "LE", "LT", "MOD", "NE", "NOT" };
/*     */ 
/*     */   
/*  50 */   private static final byte[] FLAGS = new byte[256];
/*     */   private static final byte IS_DIGIT = 1;
/*     */   private static final byte IS_HEXDIGIT = 2;
/*     */   private final String expressionString;
/*     */   
/*     */   static {
/*     */     int ch;
/*  57 */     for (ch = 48; ch <= 57; ch++) {
/*  58 */       FLAGS[ch] = (byte)(FLAGS[ch] | 0x3);
/*     */     }
/*  60 */     for (ch = 65; ch <= 70; ch++) {
/*  61 */       FLAGS[ch] = (byte)(FLAGS[ch] | 0x2);
/*     */     }
/*  63 */     for (ch = 97; ch <= 102; ch++) {
/*  64 */       FLAGS[ch] = (byte)(FLAGS[ch] | 0x2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final char[] charsToProcess;
/*     */ 
/*     */   
/*     */   private int pos;
/*     */   
/*     */   private final int max;
/*     */   
/*  77 */   private final List<Token> tokens = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public Tokenizer(String inputData) {
/*  81 */     this.expressionString = inputData;
/*  82 */     this.charsToProcess = (inputData + "\000").toCharArray();
/*  83 */     this.max = this.charsToProcess.length;
/*  84 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Token> process() {
/*  89 */     while (this.pos < this.max) {
/*  90 */       char ch = this.charsToProcess[this.pos];
/*  91 */       if (isAlphabetic(ch)) {
/*  92 */         lexIdentifier();
/*     */         continue;
/*     */       } 
/*  95 */       switch (ch) {
/*     */         case '+':
/*  97 */           if (isTwoCharToken(TokenKind.INC)) {
/*  98 */             pushPairToken(TokenKind.INC);
/*     */             continue;
/*     */           } 
/* 101 */           pushCharToken(TokenKind.PLUS);
/*     */           continue;
/*     */         
/*     */         case '_':
/* 105 */           lexIdentifier();
/*     */           continue;
/*     */         case '-':
/* 108 */           if (isTwoCharToken(TokenKind.DEC)) {
/* 109 */             pushPairToken(TokenKind.DEC);
/*     */             continue;
/*     */           } 
/* 112 */           pushCharToken(TokenKind.MINUS);
/*     */           continue;
/*     */         
/*     */         case ':':
/* 116 */           pushCharToken(TokenKind.COLON);
/*     */           continue;
/*     */         case '.':
/* 119 */           pushCharToken(TokenKind.DOT);
/*     */           continue;
/*     */         case ',':
/* 122 */           pushCharToken(TokenKind.COMMA);
/*     */           continue;
/*     */         case '*':
/* 125 */           pushCharToken(TokenKind.STAR);
/*     */           continue;
/*     */         case '/':
/* 128 */           pushCharToken(TokenKind.DIV);
/*     */           continue;
/*     */         case '%':
/* 131 */           pushCharToken(TokenKind.MOD);
/*     */           continue;
/*     */         case '(':
/* 134 */           pushCharToken(TokenKind.LPAREN);
/*     */           continue;
/*     */         case ')':
/* 137 */           pushCharToken(TokenKind.RPAREN);
/*     */           continue;
/*     */         case '[':
/* 140 */           pushCharToken(TokenKind.LSQUARE);
/*     */           continue;
/*     */         case '#':
/* 143 */           pushCharToken(TokenKind.HASH);
/*     */           continue;
/*     */         case ']':
/* 146 */           pushCharToken(TokenKind.RSQUARE);
/*     */           continue;
/*     */         case '{':
/* 149 */           pushCharToken(TokenKind.LCURLY);
/*     */           continue;
/*     */         case '}':
/* 152 */           pushCharToken(TokenKind.RCURLY);
/*     */           continue;
/*     */         case '@':
/* 155 */           pushCharToken(TokenKind.BEAN_REF);
/*     */           continue;
/*     */         case '^':
/* 158 */           if (isTwoCharToken(TokenKind.SELECT_FIRST)) {
/* 159 */             pushPairToken(TokenKind.SELECT_FIRST);
/*     */             continue;
/*     */           } 
/* 162 */           pushCharToken(TokenKind.POWER);
/*     */           continue;
/*     */         
/*     */         case '!':
/* 166 */           if (isTwoCharToken(TokenKind.NE)) {
/* 167 */             pushPairToken(TokenKind.NE); continue;
/*     */           } 
/* 169 */           if (isTwoCharToken(TokenKind.PROJECT)) {
/* 170 */             pushPairToken(TokenKind.PROJECT);
/*     */             continue;
/*     */           } 
/* 173 */           pushCharToken(TokenKind.NOT);
/*     */           continue;
/*     */         
/*     */         case '=':
/* 177 */           if (isTwoCharToken(TokenKind.EQ)) {
/* 178 */             pushPairToken(TokenKind.EQ);
/*     */             continue;
/*     */           } 
/* 181 */           pushCharToken(TokenKind.ASSIGN);
/*     */           continue;
/*     */         
/*     */         case '&':
/* 185 */           if (isTwoCharToken(TokenKind.SYMBOLIC_AND)) {
/* 186 */             pushPairToken(TokenKind.SYMBOLIC_AND);
/*     */             continue;
/*     */           } 
/* 189 */           pushCharToken(TokenKind.FACTORY_BEAN_REF);
/*     */           continue;
/*     */         
/*     */         case '|':
/* 193 */           if (!isTwoCharToken(TokenKind.SYMBOLIC_OR)) {
/* 194 */             raiseParseException(this.pos, SpelMessage.MISSING_CHARACTER, new Object[] { "|" });
/*     */           }
/* 196 */           pushPairToken(TokenKind.SYMBOLIC_OR);
/*     */           continue;
/*     */         case '?':
/* 199 */           if (isTwoCharToken(TokenKind.SELECT)) {
/* 200 */             pushPairToken(TokenKind.SELECT); continue;
/*     */           } 
/* 202 */           if (isTwoCharToken(TokenKind.ELVIS)) {
/* 203 */             pushPairToken(TokenKind.ELVIS); continue;
/*     */           } 
/* 205 */           if (isTwoCharToken(TokenKind.SAFE_NAVI)) {
/* 206 */             pushPairToken(TokenKind.SAFE_NAVI);
/*     */             continue;
/*     */           } 
/* 209 */           pushCharToken(TokenKind.QMARK);
/*     */           continue;
/*     */         
/*     */         case '$':
/* 213 */           if (isTwoCharToken(TokenKind.SELECT_LAST)) {
/* 214 */             pushPairToken(TokenKind.SELECT_LAST);
/*     */             continue;
/*     */           } 
/* 217 */           lexIdentifier();
/*     */           continue;
/*     */         
/*     */         case '>':
/* 221 */           if (isTwoCharToken(TokenKind.GE)) {
/* 222 */             pushPairToken(TokenKind.GE);
/*     */             continue;
/*     */           } 
/* 225 */           pushCharToken(TokenKind.GT);
/*     */           continue;
/*     */         
/*     */         case '<':
/* 229 */           if (isTwoCharToken(TokenKind.LE)) {
/* 230 */             pushPairToken(TokenKind.LE);
/*     */             continue;
/*     */           } 
/* 233 */           pushCharToken(TokenKind.LT);
/*     */           continue;
/*     */         
/*     */         case '0':
/*     */         case '1':
/*     */         case '2':
/*     */         case '3':
/*     */         case '4':
/*     */         case '5':
/*     */         case '6':
/*     */         case '7':
/*     */         case '8':
/*     */         case '9':
/* 246 */           lexNumericLiteral((ch == '0'));
/*     */           continue;
/*     */         
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\r':
/*     */         case ' ':
/* 253 */           this.pos++;
/*     */           continue;
/*     */         case '\'':
/* 256 */           lexQuotedStringLiteral();
/*     */           continue;
/*     */         case '"':
/* 259 */           lexDoubleQuotedStringLiteral();
/*     */           continue;
/*     */         
/*     */         case '\000':
/* 263 */           this.pos++;
/*     */           continue;
/*     */         case '\\':
/* 266 */           raiseParseException(this.pos, SpelMessage.UNEXPECTED_ESCAPE_CHAR, new Object[0]);
/*     */           continue;
/*     */       } 
/* 269 */       raiseParseException(this.pos + 1, SpelMessage.UNSUPPORTED_CHARACTER, new Object[] { Character.valueOf(ch), Integer.valueOf(ch) });
/*     */     } 
/*     */ 
/*     */     
/* 273 */     return this.tokens;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void lexQuotedStringLiteral() {
/* 279 */     int start = this.pos;
/* 280 */     boolean terminated = false;
/* 281 */     while (!terminated) {
/* 282 */       this.pos++;
/* 283 */       char ch = this.charsToProcess[this.pos];
/* 284 */       if (ch == '\'')
/*     */       {
/* 286 */         if (this.charsToProcess[this.pos + 1] == '\'') {
/* 287 */           this.pos++;
/*     */         } else {
/*     */           
/* 290 */           terminated = true;
/*     */         } 
/*     */       }
/* 293 */       if (isExhausted()) {
/* 294 */         raiseParseException(start, SpelMessage.NON_TERMINATING_QUOTED_STRING, new Object[0]);
/*     */       }
/*     */     } 
/* 297 */     this.pos++;
/* 298 */     this.tokens.add(new Token(TokenKind.LITERAL_STRING, subarray(start, this.pos), start, this.pos));
/*     */   }
/*     */ 
/*     */   
/*     */   private void lexDoubleQuotedStringLiteral() {
/* 303 */     int start = this.pos;
/* 304 */     boolean terminated = false;
/* 305 */     while (!terminated) {
/* 306 */       this.pos++;
/* 307 */       char ch = this.charsToProcess[this.pos];
/* 308 */       if (ch == '"')
/*     */       {
/* 310 */         if (this.charsToProcess[this.pos + 1] == '"') {
/* 311 */           this.pos++;
/*     */         } else {
/*     */           
/* 314 */           terminated = true;
/*     */         } 
/*     */       }
/* 317 */       if (isExhausted()) {
/* 318 */         raiseParseException(start, SpelMessage.NON_TERMINATING_DOUBLE_QUOTED_STRING, new Object[0]);
/*     */       }
/*     */     } 
/* 321 */     this.pos++;
/* 322 */     this.tokens.add(new Token(TokenKind.LITERAL_STRING, subarray(start, this.pos), start, this.pos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void lexNumericLiteral(boolean firstCharIsZero) {
/* 342 */     boolean isReal = false;
/* 343 */     int start = this.pos;
/* 344 */     char ch = this.charsToProcess[this.pos + 1];
/* 345 */     boolean isHex = (ch == 'x' || ch == 'X');
/*     */ 
/*     */     
/* 348 */     if (firstCharIsZero && isHex) {
/* 349 */       this.pos++;
/*     */       while (true) {
/* 351 */         this.pos++;
/*     */         
/* 353 */         if (!isHexadecimalDigit(this.charsToProcess[this.pos])) {
/* 354 */           if (isChar('L', 'l')) {
/* 355 */             pushHexIntToken(subarray(start + 2, this.pos), true, start, this.pos);
/* 356 */             this.pos++;
/*     */           } else {
/*     */             
/* 359 */             pushHexIntToken(subarray(start + 2, this.pos), false, start, this.pos);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     do {
/* 368 */       this.pos++;
/*     */     }
/* 370 */     while (isDigit(this.charsToProcess[this.pos]));
/*     */ 
/*     */     
/* 373 */     ch = this.charsToProcess[this.pos];
/* 374 */     if (ch == '.') {
/* 375 */       isReal = true;
/* 376 */       int dotpos = this.pos;
/*     */       
/*     */       while (true) {
/* 379 */         this.pos++;
/*     */         
/* 381 */         if (!isDigit(this.charsToProcess[this.pos])) {
/* 382 */           if (this.pos == dotpos + 1) {
/*     */ 
/*     */ 
/*     */             
/* 386 */             this.pos = dotpos;
/* 387 */             pushIntToken(subarray(start, this.pos), false, start, this.pos); return;
/*     */           }  break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 392 */     int endOfNumber = this.pos;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 397 */     if (isChar('L', 'l')) {
/* 398 */       if (isReal) {
/* 399 */         raiseParseException(start, SpelMessage.REAL_CANNOT_BE_LONG, new Object[0]);
/*     */       }
/* 401 */       pushIntToken(subarray(start, endOfNumber), true, start, endOfNumber);
/* 402 */       this.pos++;
/*     */     } else {
/* 404 */       if (isExponentChar(this.charsToProcess[this.pos])) {
/* 405 */         isReal = true;
/* 406 */         this.pos++;
/* 407 */         char possibleSign = this.charsToProcess[this.pos];
/* 408 */         if (isSign(possibleSign)) {
/* 409 */           this.pos++;
/*     */         }
/*     */ 
/*     */         
/*     */         while (true) {
/* 414 */           this.pos++;
/*     */           
/* 416 */           if (!isDigit(this.charsToProcess[this.pos])) {
/* 417 */             boolean bool = false;
/* 418 */             if (isFloatSuffix(this.charsToProcess[this.pos])) {
/* 419 */               bool = true;
/* 420 */               endOfNumber = ++this.pos;
/*     */             }
/* 422 */             else if (isDoubleSuffix(this.charsToProcess[this.pos])) {
/* 423 */               endOfNumber = ++this.pos;
/*     */             } 
/* 425 */             pushRealToken(subarray(start, this.pos), bool, start, this.pos); return;
/*     */           } 
/*     */         } 
/* 428 */       }  ch = this.charsToProcess[this.pos];
/* 429 */       boolean isFloat = false;
/* 430 */       if (isFloatSuffix(ch)) {
/* 431 */         isReal = true;
/* 432 */         isFloat = true;
/* 433 */         endOfNumber = ++this.pos;
/*     */       }
/* 435 */       else if (isDoubleSuffix(ch)) {
/* 436 */         isReal = true;
/* 437 */         endOfNumber = ++this.pos;
/*     */       } 
/* 439 */       if (isReal) {
/* 440 */         pushRealToken(subarray(start, endOfNumber), isFloat, start, endOfNumber);
/*     */       } else {
/*     */         
/* 443 */         pushIntToken(subarray(start, endOfNumber), false, start, endOfNumber);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void lexIdentifier() {
/* 449 */     int start = this.pos;
/*     */     while (true) {
/* 451 */       this.pos++;
/*     */       
/* 453 */       if (!isIdentifier(this.charsToProcess[this.pos])) {
/* 454 */         char[] subarray = subarray(start, this.pos);
/*     */ 
/*     */ 
/*     */         
/* 458 */         if (subarray.length == 2 || subarray.length == 3) {
/* 459 */           String asString = (new String(subarray)).toUpperCase(Locale.ROOT);
/* 460 */           int idx = Arrays.binarySearch((Object[])ALTERNATIVE_OPERATOR_NAMES, asString);
/* 461 */           if (idx >= 0) {
/* 462 */             pushOneCharOrTwoCharToken(TokenKind.valueOf(asString), start, subarray);
/*     */             return;
/*     */           } 
/*     */         } 
/* 466 */         this.tokens.add(new Token(TokenKind.IDENTIFIER, subarray, start, this.pos));
/*     */         return;
/*     */       } 
/*     */     }  } private void pushIntToken(char[] data, boolean isLong, int start, int end) {
/* 470 */     if (isLong) {
/* 471 */       this.tokens.add(new Token(TokenKind.LITERAL_LONG, data, start, end));
/*     */     } else {
/*     */       
/* 474 */       this.tokens.add(new Token(TokenKind.LITERAL_INT, data, start, end));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void pushHexIntToken(char[] data, boolean isLong, int start, int end) {
/* 479 */     if (data.length == 0) {
/* 480 */       if (isLong) {
/* 481 */         raiseParseException(start, SpelMessage.NOT_A_LONG, new Object[] { this.expressionString.substring(start, end + 1) });
/*     */       } else {
/*     */         
/* 484 */         raiseParseException(start, SpelMessage.NOT_AN_INTEGER, new Object[] { this.expressionString.substring(start, end) });
/*     */       } 
/*     */     }
/* 487 */     if (isLong) {
/* 488 */       this.tokens.add(new Token(TokenKind.LITERAL_HEXLONG, data, start, end));
/*     */     } else {
/*     */       
/* 491 */       this.tokens.add(new Token(TokenKind.LITERAL_HEXINT, data, start, end));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void pushRealToken(char[] data, boolean isFloat, int start, int end) {
/* 496 */     if (isFloat) {
/* 497 */       this.tokens.add(new Token(TokenKind.LITERAL_REAL_FLOAT, data, start, end));
/*     */     } else {
/*     */       
/* 500 */       this.tokens.add(new Token(TokenKind.LITERAL_REAL, data, start, end));
/*     */     } 
/*     */   }
/*     */   
/*     */   private char[] subarray(int start, int end) {
/* 505 */     return Arrays.copyOfRange(this.charsToProcess, start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isTwoCharToken(TokenKind kind) {
/* 512 */     return (kind.tokenChars.length == 2 && this.charsToProcess[this.pos] == kind.tokenChars[0] && this.charsToProcess[this.pos + 1] == kind.tokenChars[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pushCharToken(TokenKind kind) {
/* 521 */     this.tokens.add(new Token(kind, this.pos, this.pos + 1));
/* 522 */     this.pos++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pushPairToken(TokenKind kind) {
/* 529 */     this.tokens.add(new Token(kind, this.pos, this.pos + 2));
/* 530 */     this.pos += 2;
/*     */   }
/*     */   
/*     */   private void pushOneCharOrTwoCharToken(TokenKind kind, int pos, char[] data) {
/* 534 */     this.tokens.add(new Token(kind, data, pos, pos + kind.getLength()));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isIdentifier(char ch) {
/* 539 */     return (isAlphabetic(ch) || isDigit(ch) || ch == '_' || ch == '$');
/*     */   }
/*     */   
/*     */   private boolean isChar(char a, char b) {
/* 543 */     char ch = this.charsToProcess[this.pos];
/* 544 */     return (ch == a || ch == b);
/*     */   }
/*     */   
/*     */   private boolean isExponentChar(char ch) {
/* 548 */     return (ch == 'e' || ch == 'E');
/*     */   }
/*     */   
/*     */   private boolean isFloatSuffix(char ch) {
/* 552 */     return (ch == 'f' || ch == 'F');
/*     */   }
/*     */   
/*     */   private boolean isDoubleSuffix(char ch) {
/* 556 */     return (ch == 'd' || ch == 'D');
/*     */   }
/*     */   
/*     */   private boolean isSign(char ch) {
/* 560 */     return (ch == '+' || ch == '-');
/*     */   }
/*     */   
/*     */   private boolean isDigit(char ch) {
/* 564 */     if (ch > 'ÿ') {
/* 565 */       return false;
/*     */     }
/* 567 */     return ((FLAGS[ch] & 0x1) != 0);
/*     */   }
/*     */   
/*     */   private boolean isAlphabetic(char ch) {
/* 571 */     return Character.isLetter(ch);
/*     */   }
/*     */   
/*     */   private boolean isHexadecimalDigit(char ch) {
/* 575 */     if (ch > 'ÿ') {
/* 576 */       return false;
/*     */     }
/* 578 */     return ((FLAGS[ch] & 0x2) != 0);
/*     */   }
/*     */   
/*     */   private boolean isExhausted() {
/* 582 */     return (this.pos == this.max - 1);
/*     */   }
/*     */   
/*     */   private void raiseParseException(int start, SpelMessage msg, Object... inserts) {
/* 586 */     throw new InternalParseException(new SpelParseException(this.expressionString, start, msg, inserts));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\standard\Tokenizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */