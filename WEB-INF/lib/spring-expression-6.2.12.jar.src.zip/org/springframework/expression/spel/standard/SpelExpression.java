/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.common.ExpressionUtils;
/*     */ import org.springframework.expression.spel.CompiledExpression;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelCompilerMode;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.SpelParserConfiguration;
/*     */ import org.springframework.expression.spel.ast.SpelNodeImpl;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpelExpression
/*     */   implements Expression
/*     */ {
/*     */   private static final int INTERPRETED_COUNT_THRESHOLD = 100;
/*     */   private static final int FAILED_ATTEMPTS_THRESHOLD = 100;
/*     */   private final String expression;
/*     */   private final SpelNodeImpl ast;
/*     */   private final SpelParserConfiguration configuration;
/*     */   @Nullable
/*     */   private EvaluationContext evaluationContext;
/*     */   @Nullable
/*     */   private volatile CompiledExpression compiledAst;
/*  75 */   private final AtomicInteger interpretedCount = new AtomicInteger();
/*     */ 
/*     */ 
/*     */   
/*  79 */   private final AtomicInteger failedAttempts = new AtomicInteger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelExpression(String expression, SpelNodeImpl ast, SpelParserConfiguration configuration) {
/*  86 */     this.expression = expression;
/*  87 */     this.ast = ast;
/*  88 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEvaluationContext(EvaluationContext evaluationContext) {
/*  97 */     this.evaluationContext = evaluationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationContext getEvaluationContext() {
/* 105 */     if (this.evaluationContext == null) {
/* 106 */       this.evaluationContext = (EvaluationContext)new StandardEvaluationContext();
/*     */     }
/* 108 */     return this.evaluationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 116 */     return this.expression;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue() throws EvaluationException {
/* 122 */     CompiledExpression compiledAst = this.compiledAst;
/* 123 */     if (compiledAst != null) {
/*     */       try {
/* 125 */         EvaluationContext context = getEvaluationContext();
/* 126 */         return compiledAst.getValue(context.getRootObject().getValue(), context);
/*     */       }
/* 128 */       catch (Throwable ex) {
/*     */         
/* 130 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 131 */           this.compiledAst = null;
/* 132 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 136 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 141 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), this.configuration);
/* 142 */     Object result = this.ast.getValue(expressionState);
/* 143 */     checkCompile(expressionState);
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(@Nullable Class<T> expectedResultType) throws EvaluationException {
/* 151 */     CompiledExpression compiledAst = this.compiledAst;
/* 152 */     if (compiledAst != null) {
/*     */       try {
/* 154 */         EvaluationContext context = getEvaluationContext();
/* 155 */         Object result = compiledAst.getValue(context.getRootObject().getValue(), context);
/* 156 */         if (expectedResultType == null) {
/* 157 */           return (T)result;
/*     */         }
/*     */         
/* 160 */         return (T)ExpressionUtils.convertTypedValue(
/* 161 */             getEvaluationContext(), new TypedValue(result), expectedResultType);
/*     */       
/*     */       }
/* 164 */       catch (Throwable ex) {
/*     */         
/* 166 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 167 */           this.compiledAst = null;
/* 168 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 172 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 177 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), this.configuration);
/* 178 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 179 */     checkCompile(expressionState);
/* 180 */     return (T)ExpressionUtils.convertTypedValue(expressionState
/* 181 */         .getEvaluationContext(), typedResultValue, expectedResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue(@Nullable Object rootObject) throws EvaluationException {
/* 187 */     CompiledExpression compiledAst = this.compiledAst;
/* 188 */     if (compiledAst != null) {
/*     */       try {
/* 190 */         return compiledAst.getValue(rootObject, getEvaluationContext());
/*     */       }
/* 192 */       catch (Throwable ex) {
/*     */         
/* 194 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 195 */           this.compiledAst = null;
/* 196 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 200 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 206 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration);
/* 207 */     Object result = this.ast.getValue(expressionState);
/* 208 */     checkCompile(expressionState);
/* 209 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(@Nullable Object rootObject, @Nullable Class<T> expectedResultType) throws EvaluationException {
/* 216 */     CompiledExpression compiledAst = this.compiledAst;
/* 217 */     if (compiledAst != null) {
/*     */       try {
/* 219 */         Object result = compiledAst.getValue(rootObject, getEvaluationContext());
/* 220 */         if (expectedResultType == null) {
/* 221 */           return (T)result;
/*     */         }
/*     */         
/* 224 */         return (T)ExpressionUtils.convertTypedValue(
/* 225 */             getEvaluationContext(), new TypedValue(result), expectedResultType);
/*     */       
/*     */       }
/* 228 */       catch (Throwable ex) {
/*     */         
/* 230 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 231 */           this.compiledAst = null;
/* 232 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 236 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 242 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration);
/* 243 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 244 */     checkCompile(expressionState);
/* 245 */     return (T)ExpressionUtils.convertTypedValue(expressionState
/* 246 */         .getEvaluationContext(), typedResultValue, expectedResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue(EvaluationContext context) throws EvaluationException {
/* 252 */     Assert.notNull(context, "EvaluationContext must not be null");
/*     */     
/* 254 */     CompiledExpression compiledAst = this.compiledAst;
/* 255 */     if (compiledAst != null) {
/*     */       try {
/* 257 */         return compiledAst.getValue(context.getRootObject().getValue(), context);
/*     */       }
/* 259 */       catch (Throwable ex) {
/*     */         
/* 261 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 262 */           this.compiledAst = null;
/* 263 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 267 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 272 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 273 */     Object result = this.ast.getValue(expressionState);
/* 274 */     checkCompile(expressionState);
/* 275 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(EvaluationContext context, @Nullable Class<T> expectedResultType) throws EvaluationException {
/* 282 */     Assert.notNull(context, "EvaluationContext must not be null");
/*     */     
/* 284 */     CompiledExpression compiledAst = this.compiledAst;
/* 285 */     if (compiledAst != null) {
/*     */       try {
/* 287 */         Object result = compiledAst.getValue(context.getRootObject().getValue(), context);
/* 288 */         if (expectedResultType != null) {
/* 289 */           return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(result), expectedResultType);
/*     */         }
/*     */         
/* 292 */         return (T)result;
/*     */       
/*     */       }
/* 295 */       catch (Throwable ex) {
/*     */         
/* 297 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 298 */           this.compiledAst = null;
/* 299 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 303 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 308 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 309 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 310 */     checkCompile(expressionState);
/* 311 */     return (T)ExpressionUtils.convertTypedValue(context, typedResultValue, expectedResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 317 */     Assert.notNull(context, "EvaluationContext must not be null");
/*     */     
/* 319 */     CompiledExpression compiledAst = this.compiledAst;
/* 320 */     if (compiledAst != null) {
/*     */       try {
/* 322 */         return compiledAst.getValue(rootObject, context);
/*     */       }
/* 324 */       catch (Throwable ex) {
/*     */         
/* 326 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 327 */           this.compiledAst = null;
/* 328 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 332 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 337 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 338 */     Object result = this.ast.getValue(expressionState);
/* 339 */     checkCompile(expressionState);
/* 340 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(EvaluationContext context, @Nullable Object rootObject, @Nullable Class<T> expectedResultType) throws EvaluationException {
/* 349 */     Assert.notNull(context, "EvaluationContext must not be null");
/*     */     
/* 351 */     CompiledExpression compiledAst = this.compiledAst;
/* 352 */     if (compiledAst != null) {
/*     */       try {
/* 354 */         Object result = compiledAst.getValue(rootObject, context);
/* 355 */         if (expectedResultType != null) {
/* 356 */           return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(result), expectedResultType);
/*     */         }
/*     */         
/* 359 */         return (T)result;
/*     */       
/*     */       }
/* 362 */       catch (Throwable ex) {
/*     */         
/* 364 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 365 */           this.compiledAst = null;
/* 366 */           this.interpretedCount.set(0);
/*     */         }
/*     */         else {
/*     */           
/* 370 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 375 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 376 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 377 */     checkCompile(expressionState);
/* 378 */     return (T)ExpressionUtils.convertTypedValue(context, typedResultValue, expectedResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getValueType() throws EvaluationException {
/* 384 */     return getValueType(getEvaluationContext());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getValueType(@Nullable Object rootObject) throws EvaluationException {
/* 390 */     return getValueType(getEvaluationContext(), rootObject);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getValueType(EvaluationContext context) throws EvaluationException {
/* 396 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 397 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 398 */     TypeDescriptor typeDescriptor = this.ast.getValueInternal(expressionState).getTypeDescriptor();
/* 399 */     return (typeDescriptor != null) ? typeDescriptor.getType() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getValueType(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 405 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 406 */     TypeDescriptor typeDescriptor = this.ast.getValueInternal(expressionState).getTypeDescriptor();
/* 407 */     return (typeDescriptor != null) ? typeDescriptor.getType() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeDescriptor getValueTypeDescriptor() throws EvaluationException {
/* 413 */     return getValueTypeDescriptor(getEvaluationContext());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeDescriptor getValueTypeDescriptor(@Nullable Object rootObject) throws EvaluationException {
/* 420 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration);
/* 421 */     return this.ast.getValueInternal(expressionState).getTypeDescriptor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context) throws EvaluationException {
/* 427 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 428 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 429 */     return this.ast.getValueInternal(expressionState).getTypeDescriptor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 437 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 438 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 439 */     return this.ast.getValueInternal(expressionState).getTypeDescriptor();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(@Nullable Object rootObject) throws EvaluationException {
/* 444 */     return this.ast.isWritable(new ExpressionState(
/* 445 */           getEvaluationContext(), toTypedValue(rootObject), this.configuration));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(EvaluationContext context) throws EvaluationException {
/* 450 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 451 */     return this.ast.isWritable(new ExpressionState(context, this.configuration));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 456 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 457 */     return this.ast.isWritable(new ExpressionState(context, toTypedValue(rootObject), this.configuration));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable Object rootObject, @Nullable Object value) throws EvaluationException {
/* 462 */     this.ast.setValue(new ExpressionState(
/* 463 */           getEvaluationContext(), toTypedValue(rootObject), this.configuration), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext context, @Nullable Object value) throws EvaluationException {
/* 468 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 469 */     this.ast.setValue(new ExpressionState(context, this.configuration), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext context, @Nullable Object rootObject, @Nullable Object value) throws EvaluationException {
/* 476 */     Assert.notNull(context, "EvaluationContext must not be null");
/* 477 */     this.ast.setValue(new ExpressionState(context, toTypedValue(rootObject), this.configuration), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCompile(ExpressionState expressionState) {
/* 487 */     this.interpretedCount.incrementAndGet();
/* 488 */     SpelCompilerMode compilerMode = expressionState.getConfiguration().getCompilerMode();
/* 489 */     if (compilerMode != SpelCompilerMode.OFF) {
/* 490 */       if (compilerMode == SpelCompilerMode.IMMEDIATE) {
/* 491 */         if (this.interpretedCount.get() > 1) {
/* 492 */           compileExpression();
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 497 */       else if (this.interpretedCount.get() > 100) {
/* 498 */         compileExpression();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean compileExpression() {
/* 511 */     CompiledExpression compiledAst = this.compiledAst;
/* 512 */     if (compiledAst != null)
/*     */     {
/* 514 */       return true;
/*     */     }
/* 516 */     if (this.failedAttempts.get() > 100)
/*     */     {
/* 518 */       return false;
/*     */     }
/*     */     
/* 521 */     synchronized (this) {
/* 522 */       if (this.compiledAst != null)
/*     */       {
/* 524 */         return true;
/*     */       }
/*     */       try {
/* 527 */         SpelCompiler compiler = SpelCompiler.getCompiler(this.configuration.getCompilerClassLoader());
/* 528 */         compiledAst = compiler.compile(this.ast);
/* 529 */         if (compiledAst != null) {
/*     */           
/* 531 */           this.compiledAst = compiledAst;
/* 532 */           return true;
/*     */         } 
/*     */ 
/*     */         
/* 536 */         this.failedAttempts.incrementAndGet();
/* 537 */         return false;
/*     */       
/*     */       }
/* 540 */       catch (Exception ex) {
/*     */         
/* 542 */         this.failedAttempts.incrementAndGet();
/*     */ 
/*     */         
/* 545 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 546 */           this.compiledAst = null;
/* 547 */           this.interpretedCount.set(0);
/* 548 */           return false;
/*     */         } 
/*     */ 
/*     */         
/* 552 */         throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_COMPILING_EXPRESSION, new Object[0]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void revertToInterpreted() {
/* 564 */     this.compiledAst = null;
/* 565 */     this.interpretedCount.set(0);
/* 566 */     this.failedAttempts.set(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelNode getAST() {
/* 573 */     return (SpelNode)this.ast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringAST() {
/* 583 */     return this.ast.toStringAST();
/*     */   }
/*     */   
/*     */   private TypedValue toTypedValue(@Nullable Object object) {
/* 587 */     return (object != null) ? new TypedValue(object) : TypedValue.NULL;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\standard\SpelExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */