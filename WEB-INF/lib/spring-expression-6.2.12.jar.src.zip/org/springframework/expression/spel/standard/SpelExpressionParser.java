/*    */ package org.springframework.expression.spel.standard;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.expression.ParserContext;
/*    */ import org.springframework.expression.common.TemplateAwareExpressionParser;
/*    */ import org.springframework.expression.spel.SpelParserConfiguration;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpelExpressionParser
/*    */   extends TemplateAwareExpressionParser
/*    */ {
/*    */   private final SpelParserConfiguration configuration;
/*    */   
/*    */   public SpelExpressionParser() {
/* 43 */     this.configuration = new SpelParserConfiguration();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpelExpressionParser(SpelParserConfiguration configuration) {
/* 51 */     Assert.notNull(configuration, "SpelParserConfiguration must not be null");
/* 52 */     this.configuration = configuration;
/*    */   }
/*    */ 
/*    */   
/*    */   public SpelExpression parseRaw(String expressionString) throws ParseException {
/* 57 */     Assert.hasText(expressionString, "'expressionString' must not be null or blank");
/* 58 */     return doParseExpression(expressionString, (ParserContext)null);
/*    */   }
/*    */ 
/*    */   
/*    */   protected SpelExpression doParseExpression(String expressionString, @Nullable ParserContext context) throws ParseException {
/* 63 */     return (new InternalSpelExpressionParser(this.configuration)).doParseExpression(expressionString, context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\standard\SpelExpressionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */