/*      */ package org.springframework.expression.spel.standard;
/*      */ 
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Deque;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.regex.Pattern;
/*      */ import org.springframework.expression.Expression;
/*      */ import org.springframework.expression.ParseException;
/*      */ import org.springframework.expression.ParserContext;
/*      */ import org.springframework.expression.common.TemplateAwareExpressionParser;
/*      */ import org.springframework.expression.spel.InternalParseException;
/*      */ import org.springframework.expression.spel.SpelEvaluationException;
/*      */ import org.springframework.expression.spel.SpelMessage;
/*      */ import org.springframework.expression.spel.SpelParseException;
/*      */ import org.springframework.expression.spel.SpelParserConfiguration;
/*      */ import org.springframework.expression.spel.ast.Assign;
/*      */ import org.springframework.expression.spel.ast.BeanReference;
/*      */ import org.springframework.expression.spel.ast.BooleanLiteral;
/*      */ import org.springframework.expression.spel.ast.CompoundExpression;
/*      */ import org.springframework.expression.spel.ast.ConstructorReference;
/*      */ import org.springframework.expression.spel.ast.Elvis;
/*      */ import org.springframework.expression.spel.ast.FunctionReference;
/*      */ import org.springframework.expression.spel.ast.Identifier;
/*      */ import org.springframework.expression.spel.ast.Indexer;
/*      */ import org.springframework.expression.spel.ast.InlineList;
/*      */ import org.springframework.expression.spel.ast.InlineMap;
/*      */ import org.springframework.expression.spel.ast.Literal;
/*      */ import org.springframework.expression.spel.ast.MethodReference;
/*      */ import org.springframework.expression.spel.ast.NullLiteral;
/*      */ import org.springframework.expression.spel.ast.OpAnd;
/*      */ import org.springframework.expression.spel.ast.OpDec;
/*      */ import org.springframework.expression.spel.ast.OpDivide;
/*      */ import org.springframework.expression.spel.ast.OpEQ;
/*      */ import org.springframework.expression.spel.ast.OpGE;
/*      */ import org.springframework.expression.spel.ast.OpGT;
/*      */ import org.springframework.expression.spel.ast.OpInc;
/*      */ import org.springframework.expression.spel.ast.OpLE;
/*      */ import org.springframework.expression.spel.ast.OpLT;
/*      */ import org.springframework.expression.spel.ast.OpMinus;
/*      */ import org.springframework.expression.spel.ast.OpModulus;
/*      */ import org.springframework.expression.spel.ast.OpMultiply;
/*      */ import org.springframework.expression.spel.ast.OpNE;
/*      */ import org.springframework.expression.spel.ast.OpOr;
/*      */ import org.springframework.expression.spel.ast.OpPlus;
/*      */ import org.springframework.expression.spel.ast.OperatorBetween;
/*      */ import org.springframework.expression.spel.ast.OperatorInstanceof;
/*      */ import org.springframework.expression.spel.ast.OperatorMatches;
/*      */ import org.springframework.expression.spel.ast.OperatorNot;
/*      */ import org.springframework.expression.spel.ast.OperatorPower;
/*      */ import org.springframework.expression.spel.ast.Projection;
/*      */ import org.springframework.expression.spel.ast.PropertyOrFieldReference;
/*      */ import org.springframework.expression.spel.ast.QualifiedIdentifier;
/*      */ import org.springframework.expression.spel.ast.Selection;
/*      */ import org.springframework.expression.spel.ast.SpelNodeImpl;
/*      */ import org.springframework.expression.spel.ast.StringLiteral;
/*      */ import org.springframework.expression.spel.ast.Ternary;
/*      */ import org.springframework.expression.spel.ast.TypeReference;
/*      */ import org.springframework.expression.spel.ast.VariableReference;
/*      */ import org.springframework.lang.Contract;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class InternalSpelExpressionParser
/*      */   extends TemplateAwareExpressionParser
/*      */ {
/*   95 */   private static final Pattern VALID_QUALIFIED_ID_PATTERN = Pattern.compile("[\\p{L}\\p{N}_$]+");
/*      */ 
/*      */   
/*      */   private final SpelParserConfiguration configuration;
/*      */   
/*  100 */   private final Deque<SpelNodeImpl> constructedNodes = new ArrayDeque<>();
/*      */ 
/*      */   
/*  103 */   private final ConcurrentMap<String, Pattern> patternCache = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*  106 */   private String expressionString = "";
/*      */ 
/*      */   
/*  109 */   private List<Token> tokenStream = Collections.emptyList();
/*      */ 
/*      */ 
/*      */   
/*      */   private int tokenStreamLength;
/*      */ 
/*      */ 
/*      */   
/*      */   private int tokenStreamPointer;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InternalSpelExpressionParser(SpelParserConfiguration configuration) {
/*  123 */     this.configuration = configuration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SpelExpression doParseExpression(String expressionString, @Nullable ParserContext context) throws ParseException {
/*  131 */     checkExpressionLength(expressionString);
/*      */     
/*      */     try {
/*  134 */       this.expressionString = expressionString;
/*  135 */       Tokenizer tokenizer = new Tokenizer(expressionString);
/*  136 */       this.tokenStream = tokenizer.process();
/*  137 */       this.tokenStreamLength = this.tokenStream.size();
/*  138 */       this.tokenStreamPointer = 0;
/*  139 */       this.constructedNodes.clear();
/*  140 */       SpelNodeImpl ast = eatExpression();
/*  141 */       if (ast == null) {
/*  142 */         throw new SpelParseException(this.expressionString, 0, SpelMessage.OOD, new Object[0]);
/*      */       }
/*  144 */       Token t = peekToken();
/*  145 */       if (t != null) {
/*  146 */         throw new SpelParseException(this.expressionString, t.startPos, SpelMessage.MORE_INPUT, new Object[] { toString(nextToken()) });
/*      */       }
/*  148 */       return new SpelExpression(expressionString, ast, this.configuration);
/*      */     }
/*  150 */     catch (InternalParseException ex) {
/*  151 */       throw ex.getCause();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkExpressionLength(String string) {
/*  156 */     int maxLength = this.configuration.getMaximumExpressionLength();
/*  157 */     if (string.length() > maxLength) {
/*  158 */       throw new SpelEvaluationException(SpelMessage.MAX_EXPRESSION_LENGTH_EXCEEDED, new Object[] { Integer.valueOf(maxLength) });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatExpression() {
/*      */     NullLiteral nullLiteral;
/*  171 */     SpelNodeImpl expr = eatLogicalOrExpression();
/*  172 */     Token t = peekToken();
/*  173 */     if (t != null) {
/*  174 */       if (t.kind == TokenKind.ASSIGN) {
/*  175 */         if (expr == null) {
/*  176 */           nullLiteral = new NullLiteral(t.startPos - 1, t.endPos - 1);
/*      */         }
/*  178 */         nextToken();
/*  179 */         SpelNodeImpl assignedValue = eatLogicalOrExpression();
/*  180 */         return (SpelNodeImpl)new Assign(t.startPos, t.endPos, new SpelNodeImpl[] { (SpelNodeImpl)nullLiteral, assignedValue });
/*      */       } 
/*  182 */       if (t.kind == TokenKind.ELVIS) {
/*  183 */         NullLiteral nullLiteral1; if (nullLiteral == null) {
/*  184 */           nullLiteral = new NullLiteral(t.startPos - 1, t.endPos - 2);
/*      */         }
/*  186 */         nextToken();
/*  187 */         SpelNodeImpl valueIfNull = eatExpression();
/*  188 */         if (valueIfNull == null) {
/*  189 */           nullLiteral1 = new NullLiteral(t.startPos + 1, t.endPos + 1);
/*      */         }
/*  191 */         return (SpelNodeImpl)new Elvis(t.startPos, t.endPos, new SpelNodeImpl[] { (SpelNodeImpl)nullLiteral, (SpelNodeImpl)nullLiteral1 });
/*      */       } 
/*  193 */       if (t.kind == TokenKind.QMARK) {
/*  194 */         if (nullLiteral == null) {
/*  195 */           nullLiteral = new NullLiteral(t.startPos - 1, t.endPos - 1);
/*      */         }
/*  197 */         nextToken();
/*  198 */         SpelNodeImpl ifTrueExprValue = eatExpression();
/*  199 */         eatToken(TokenKind.COLON);
/*  200 */         SpelNodeImpl ifFalseExprValue = eatExpression();
/*  201 */         return (SpelNodeImpl)new Ternary(t.startPos, t.endPos, new SpelNodeImpl[] { (SpelNodeImpl)nullLiteral, ifTrueExprValue, ifFalseExprValue });
/*      */       } 
/*      */     } 
/*  204 */     return (SpelNodeImpl)nullLiteral;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatLogicalOrExpression() {
/*      */     OpOr opOr;
/*  210 */     SpelNodeImpl expr = eatLogicalAndExpression();
/*  211 */     while (peekIdentifierToken("or") || peekToken(TokenKind.SYMBOLIC_OR)) {
/*  212 */       Token t = takeToken();
/*  213 */       SpelNodeImpl rhExpr = eatLogicalAndExpression();
/*  214 */       checkOperands(t, expr, rhExpr);
/*  215 */       opOr = new OpOr(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */     } 
/*  217 */     return (SpelNodeImpl)opOr;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatLogicalAndExpression() {
/*      */     OpAnd opAnd;
/*  223 */     SpelNodeImpl expr = eatRelationalExpression();
/*  224 */     while (peekIdentifierToken("and") || peekToken(TokenKind.SYMBOLIC_AND)) {
/*  225 */       Token t = takeToken();
/*  226 */       SpelNodeImpl rhExpr = eatRelationalExpression();
/*  227 */       checkOperands(t, expr, rhExpr);
/*  228 */       opAnd = new OpAnd(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */     } 
/*  230 */     return (SpelNodeImpl)opAnd;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatRelationalExpression() {
/*  236 */     SpelNodeImpl expr = eatSumExpression();
/*  237 */     Token relationalOperatorToken = maybeEatRelationalOperator();
/*  238 */     if (relationalOperatorToken != null) {
/*  239 */       Token t = takeToken();
/*  240 */       SpelNodeImpl rhExpr = eatSumExpression();
/*  241 */       checkOperands(t, expr, rhExpr);
/*  242 */       TokenKind tk = relationalOperatorToken.kind;
/*      */       
/*  244 */       if (relationalOperatorToken.isNumericRelationalOperator()) {
/*  245 */         if (tk == TokenKind.GT) {
/*  246 */           return (SpelNodeImpl)new OpGT(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  248 */         if (tk == TokenKind.LT) {
/*  249 */           return (SpelNodeImpl)new OpLT(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  251 */         if (tk == TokenKind.LE) {
/*  252 */           return (SpelNodeImpl)new OpLE(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  254 */         if (tk == TokenKind.GE) {
/*  255 */           return (SpelNodeImpl)new OpGE(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  257 */         if (tk == TokenKind.EQ) {
/*  258 */           return (SpelNodeImpl)new OpEQ(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  260 */         if (tk == TokenKind.NE) {
/*  261 */           return (SpelNodeImpl)new OpNE(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*      */       } 
/*      */       
/*  265 */       if (tk == TokenKind.INSTANCEOF) {
/*  266 */         return (SpelNodeImpl)new OperatorInstanceof(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*  268 */       if (tk == TokenKind.MATCHES) {
/*  269 */         return (SpelNodeImpl)new OperatorMatches(this.patternCache, t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*  271 */       if (tk == TokenKind.BETWEEN) {
/*  272 */         return (SpelNodeImpl)new OperatorBetween(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */     } 
/*  275 */     return expr;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatSumExpression() {
/*      */     OpMinus opMinus;
/*  282 */     SpelNodeImpl expr = eatProductExpression();
/*  283 */     while (peekToken(TokenKind.PLUS, TokenKind.MINUS, TokenKind.INC)) {
/*  284 */       OpPlus opPlus; Token t = takeToken();
/*  285 */       SpelNodeImpl rhExpr = eatProductExpression();
/*  286 */       checkRightOperand(t, rhExpr);
/*  287 */       if (t.kind == TokenKind.PLUS) {
/*  288 */         opPlus = new OpPlus(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr }); continue;
/*      */       } 
/*  290 */       if (t.kind == TokenKind.MINUS) {
/*  291 */         opMinus = new OpMinus(t.startPos, t.endPos, new SpelNodeImpl[] { (SpelNodeImpl)opPlus, rhExpr });
/*      */       }
/*      */     } 
/*  294 */     return (SpelNodeImpl)opMinus;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatProductExpression() {
/*      */     OpModulus opModulus;
/*  300 */     SpelNodeImpl expr = eatPowerIncDecExpression();
/*  301 */     while (peekToken(TokenKind.STAR, TokenKind.DIV, TokenKind.MOD)) {
/*  302 */       OpMultiply opMultiply; OpDivide opDivide; Token t = takeToken();
/*  303 */       SpelNodeImpl rhExpr = eatPowerIncDecExpression();
/*  304 */       checkOperands(t, expr, rhExpr);
/*  305 */       if (t.kind == TokenKind.STAR) {
/*  306 */         opMultiply = new OpMultiply(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr }); continue;
/*      */       } 
/*  308 */       if (t.kind == TokenKind.DIV) {
/*  309 */         opDivide = new OpDivide(t.startPos, t.endPos, new SpelNodeImpl[] { (SpelNodeImpl)opMultiply, rhExpr }); continue;
/*      */       } 
/*  311 */       if (t.kind == TokenKind.MOD) {
/*  312 */         opModulus = new OpModulus(t.startPos, t.endPos, new SpelNodeImpl[] { (SpelNodeImpl)opDivide, rhExpr });
/*      */       }
/*      */     } 
/*  315 */     return (SpelNodeImpl)opModulus;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatPowerIncDecExpression() {
/*  322 */     SpelNodeImpl expr = eatUnaryExpression();
/*  323 */     if (peekToken(TokenKind.POWER)) {
/*  324 */       Token t = takeToken();
/*  325 */       SpelNodeImpl rhExpr = eatUnaryExpression();
/*  326 */       checkRightOperand(t, rhExpr);
/*  327 */       return (SpelNodeImpl)new OperatorPower(t.startPos, t.endPos, new SpelNodeImpl[] { expr, rhExpr });
/*      */     } 
/*  329 */     if (expr != null && peekToken(TokenKind.INC, TokenKind.DEC)) {
/*  330 */       Token t = takeToken();
/*  331 */       if (t.getKind() == TokenKind.INC) {
/*  332 */         return (SpelNodeImpl)new OpInc(t.startPos, t.endPos, true, new SpelNodeImpl[] { expr });
/*      */       }
/*  334 */       return (SpelNodeImpl)new OpDec(t.startPos, t.endPos, true, new SpelNodeImpl[] { expr });
/*      */     } 
/*  336 */     return expr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatUnaryExpression() {
/*  343 */     if (peekToken(TokenKind.NOT, TokenKind.PLUS, TokenKind.MINUS)) {
/*  344 */       Token t = takeToken();
/*  345 */       SpelNodeImpl expr = eatUnaryExpression();
/*  346 */       if (expr == null) {
/*  347 */         throw internalException(t.startPos, SpelMessage.OOD, new Object[0]);
/*      */       }
/*  349 */       if (t.kind == TokenKind.NOT) {
/*  350 */         return (SpelNodeImpl)new OperatorNot(t.startPos, t.endPos, expr);
/*      */       }
/*  352 */       if (t.kind == TokenKind.PLUS) {
/*  353 */         return (SpelNodeImpl)new OpPlus(t.startPos, t.endPos, new SpelNodeImpl[] { expr });
/*      */       }
/*  355 */       if (t.kind == TokenKind.MINUS) {
/*  356 */         return (SpelNodeImpl)new OpMinus(t.startPos, t.endPos, new SpelNodeImpl[] { expr });
/*      */       }
/*      */     } 
/*  359 */     if (peekToken(TokenKind.INC, TokenKind.DEC)) {
/*  360 */       Token t = takeToken();
/*  361 */       SpelNodeImpl expr = eatUnaryExpression();
/*  362 */       if (t.getKind() == TokenKind.INC) {
/*  363 */         return (SpelNodeImpl)new OpInc(t.startPos, t.endPos, false, new SpelNodeImpl[] { expr });
/*      */       }
/*  365 */       if (t.kind == TokenKind.DEC) {
/*  366 */         return (SpelNodeImpl)new OpDec(t.startPos, t.endPos, false, new SpelNodeImpl[] { expr });
/*      */       }
/*      */     } 
/*  369 */     return eatPrimaryExpression();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatPrimaryExpression() {
/*  375 */     SpelNodeImpl start = eatStartNode();
/*  376 */     List<SpelNodeImpl> nodes = null;
/*  377 */     SpelNodeImpl node = eatNode();
/*  378 */     while (node != null) {
/*  379 */       if (nodes == null) {
/*  380 */         nodes = new ArrayList<>(4);
/*  381 */         nodes.add(start);
/*      */       } 
/*  383 */       nodes.add(node);
/*  384 */       node = eatNode();
/*      */     } 
/*  386 */     if (start == null || nodes == null) {
/*  387 */       return start;
/*      */     }
/*  389 */     return (SpelNodeImpl)new CompoundExpression(start.getStartPosition(), ((SpelNodeImpl)nodes.get(nodes.size() - 1)).getEndPosition(), nodes
/*  390 */         .<SpelNodeImpl>toArray(new SpelNodeImpl[0]));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatNode() {
/*  396 */     return peekToken(TokenKind.DOT, TokenKind.SAFE_NAVI) ? eatDottedNode() : eatNonDottedNode();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatNonDottedNode() {
/*  402 */     if (peekToken(TokenKind.LSQUARE) && 
/*  403 */       maybeEatIndexer(false)) {
/*  404 */       return pop();
/*      */     }
/*      */     
/*  407 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SpelNodeImpl eatDottedNode() {
/*  420 */     Token t = takeToken();
/*  421 */     boolean nullSafeNavigation = (t.kind == TokenKind.SAFE_NAVI);
/*  422 */     if (maybeEatMethodOrProperty(nullSafeNavigation) || maybeEatFunctionOrVar() || 
/*  423 */       maybeEatProjection(nullSafeNavigation) || maybeEatSelection(nullSafeNavigation) || 
/*  424 */       maybeEatIndexer(nullSafeNavigation)) {
/*  425 */       return pop();
/*      */     }
/*  427 */     if (peekToken() == null) {
/*  428 */       throw internalException(t.startPos, SpelMessage.OOD, new Object[0]);
/*      */     }
/*      */     
/*  431 */     throw internalException(t.startPos, SpelMessage.UNEXPECTED_DATA_AFTER_DOT, new Object[] { toString(peekToken()) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maybeEatFunctionOrVar() {
/*  442 */     if (!peekToken(TokenKind.HASH)) {
/*  443 */       return false;
/*      */     }
/*  445 */     Token t = takeToken();
/*  446 */     Token functionOrVariableName = eatToken(TokenKind.IDENTIFIER);
/*  447 */     SpelNodeImpl[] args = maybeEatMethodArgs();
/*  448 */     if (args == null) {
/*  449 */       push((SpelNodeImpl)new VariableReference(functionOrVariableName.stringValue(), t.startPos, functionOrVariableName.endPos));
/*      */       
/*  451 */       return true;
/*      */     } 
/*      */     
/*  454 */     push((SpelNodeImpl)new FunctionReference(functionOrVariableName.stringValue(), t.startPos, functionOrVariableName.endPos, args));
/*      */     
/*  456 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl[] maybeEatMethodArgs() {
/*  462 */     if (!peekToken(TokenKind.LPAREN)) {
/*  463 */       return null;
/*      */     }
/*  465 */     List<SpelNodeImpl> args = new ArrayList<>();
/*  466 */     consumeArguments(args);
/*  467 */     eatToken(TokenKind.RPAREN);
/*  468 */     return args.<SpelNodeImpl>toArray(new SpelNodeImpl[0]);
/*      */   }
/*      */   
/*      */   private void eatConstructorArgs(List<SpelNodeImpl> accumulatedArguments) {
/*  472 */     if (!peekToken(TokenKind.LPAREN)) {
/*  473 */       throw internalException(positionOf(peekToken()), SpelMessage.MISSING_CONSTRUCTOR_ARGS, new Object[0]);
/*      */     }
/*  475 */     consumeArguments(accumulatedArguments);
/*  476 */     eatToken(TokenKind.RPAREN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void consumeArguments(List<SpelNodeImpl> accumulatedArguments) {
/*  483 */     Token next, t = peekToken();
/*  484 */     if (t == null) {
/*      */       return;
/*      */     }
/*  487 */     int pos = t.startPos;
/*      */     
/*      */     do {
/*  490 */       nextToken();
/*  491 */       t = peekToken();
/*  492 */       if (t == null) {
/*  493 */         throw internalException(pos, SpelMessage.RUN_OUT_OF_ARGUMENTS, new Object[0]);
/*      */       }
/*  495 */       if (t.kind != TokenKind.RPAREN) {
/*  496 */         accumulatedArguments.add(eatExpression());
/*      */       }
/*  498 */       next = peekToken();
/*      */     }
/*  500 */     while (next != null && next.kind == TokenKind.COMMA);
/*      */     
/*  502 */     if (next == null) {
/*  503 */       throw internalException(pos, SpelMessage.RUN_OUT_OF_ARGUMENTS, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   private int positionOf(@Nullable Token t) {
/*  508 */     if (t == null)
/*      */     {
/*      */       
/*  511 */       return this.expressionString.length();
/*      */     }
/*  513 */     return t.startPos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private SpelNodeImpl eatStartNode() {
/*  529 */     if (maybeEatLiteral()) {
/*  530 */       return pop();
/*      */     }
/*  532 */     if (maybeEatParenExpression()) {
/*  533 */       return pop();
/*      */     }
/*  535 */     if (maybeEatTypeReference() || maybeEatNullReference() || maybeEatConstructorReference() || 
/*  536 */       maybeEatMethodOrProperty(false) || maybeEatFunctionOrVar()) {
/*  537 */       return pop();
/*      */     }
/*  539 */     if (maybeEatBeanReference()) {
/*  540 */       return pop();
/*      */     }
/*  542 */     if (maybeEatProjection(false) || maybeEatSelection(false) || maybeEatIndexer(false)) {
/*  543 */       return pop();
/*      */     }
/*  545 */     if (maybeEatInlineListOrMap()) {
/*  546 */       return pop();
/*      */     }
/*      */     
/*  549 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maybeEatBeanReference() {
/*  556 */     if (peekToken(TokenKind.BEAN_REF) || peekToken(TokenKind.FACTORY_BEAN_REF)) {
/*  557 */       BeanReference beanReference; Token beanRefToken = takeToken();
/*  558 */       Token beanNameToken = null;
/*  559 */       String beanName = null;
/*  560 */       if (peekToken(TokenKind.IDENTIFIER)) {
/*  561 */         beanNameToken = eatToken(TokenKind.IDENTIFIER);
/*  562 */         beanName = beanNameToken.stringValue();
/*      */       }
/*  564 */       else if (peekToken(TokenKind.LITERAL_STRING)) {
/*  565 */         beanNameToken = eatToken(TokenKind.LITERAL_STRING);
/*  566 */         beanName = beanNameToken.stringValue();
/*  567 */         beanName = beanName.substring(1, beanName.length() - 1);
/*      */       } else {
/*      */         
/*  570 */         throw internalException(beanRefToken.startPos, SpelMessage.INVALID_BEAN_REFERENCE, new Object[0]);
/*      */       } 
/*      */       
/*  573 */       if (beanRefToken.getKind() == TokenKind.FACTORY_BEAN_REF) {
/*  574 */         String beanNameString = String.valueOf(TokenKind.FACTORY_BEAN_REF.tokenChars) + String.valueOf(TokenKind.FACTORY_BEAN_REF.tokenChars);
/*  575 */         beanReference = new BeanReference(beanRefToken.startPos, beanNameToken.endPos, beanNameString);
/*      */       } else {
/*      */         
/*  578 */         beanReference = new BeanReference(beanNameToken.startPos, beanNameToken.endPos, beanName);
/*      */       } 
/*  580 */       this.constructedNodes.push(beanReference);
/*  581 */       return true;
/*      */     } 
/*  583 */     return false;
/*      */   }
/*      */   
/*      */   private boolean maybeEatTypeReference() {
/*  587 */     if (peekToken(TokenKind.IDENTIFIER)) {
/*  588 */       Token typeName = peekToken();
/*  589 */       if (typeName == null || !"T".equals(typeName.stringValue())) {
/*  590 */         return false;
/*      */       }
/*      */       
/*  593 */       Token t = takeToken();
/*  594 */       if (peekToken(TokenKind.RSQUARE)) {
/*      */         
/*  596 */         push((SpelNodeImpl)new PropertyOrFieldReference(false, t.stringValue(), t.startPos, t.endPos));
/*  597 */         return true;
/*      */       } 
/*  599 */       eatToken(TokenKind.LPAREN);
/*  600 */       SpelNodeImpl node = eatPossiblyQualifiedId();
/*      */ 
/*      */       
/*  603 */       int dims = 0;
/*  604 */       while (peekToken(TokenKind.LSQUARE, true)) {
/*  605 */         eatToken(TokenKind.RSQUARE);
/*  606 */         dims++;
/*      */       } 
/*  608 */       eatToken(TokenKind.RPAREN);
/*  609 */       this.constructedNodes.push(new TypeReference(typeName.startPos, typeName.endPos, node, dims));
/*  610 */       return true;
/*      */     } 
/*  612 */     return false;
/*      */   }
/*      */   
/*      */   private boolean maybeEatNullReference() {
/*  616 */     if (peekToken(TokenKind.IDENTIFIER)) {
/*  617 */       Token nullToken = peekToken();
/*  618 */       if (nullToken == null || !"null".equalsIgnoreCase(nullToken.stringValue())) {
/*  619 */         return false;
/*      */       }
/*  621 */       nextToken();
/*  622 */       this.constructedNodes.push(new NullLiteral(nullToken.startPos, nullToken.endPos));
/*  623 */       return true;
/*      */     } 
/*  625 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean maybeEatProjection(boolean nullSafeNavigation) {
/*  630 */     Token t = peekToken();
/*  631 */     if (t == null || !peekToken(TokenKind.PROJECT, true)) {
/*  632 */       return false;
/*      */     }
/*  634 */     SpelNodeImpl expr = eatExpression();
/*  635 */     if (expr == null) {
/*  636 */       throw internalException(t.startPos, SpelMessage.OOD, new Object[0]);
/*      */     }
/*  638 */     eatToken(TokenKind.RSQUARE);
/*  639 */     this.constructedNodes.push(new Projection(nullSafeNavigation, t.startPos, t.endPos, expr));
/*  640 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean maybeEatInlineListOrMap() {
/*      */     InlineMap inlineMap;
/*  646 */     Token t = peekToken();
/*  647 */     if (t == null || !peekToken(TokenKind.LCURLY, true)) {
/*  648 */       return false;
/*      */     }
/*  650 */     SpelNodeImpl expr = null;
/*  651 */     Token closingCurly = peekToken();
/*  652 */     if (closingCurly != null && peekToken(TokenKind.RCURLY, true))
/*      */     
/*  654 */     { InlineList inlineList = new InlineList(t.startPos, closingCurly.endPos, new SpelNodeImpl[0]); }
/*      */     
/*  656 */     else if (peekToken(TokenKind.COLON, true))
/*  657 */     { closingCurly = eatToken(TokenKind.RCURLY);
/*      */       
/*  659 */       inlineMap = new InlineMap(t.startPos, closingCurly.endPos, new SpelNodeImpl[0]); }
/*      */     else
/*      */     
/*  662 */     { SpelNodeImpl firstExpression = eatExpression();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  667 */       if (peekToken(TokenKind.RCURLY))
/*  668 */       { List<SpelNodeImpl> elements = new ArrayList<>();
/*  669 */         elements.add(firstExpression);
/*  670 */         closingCurly = eatToken(TokenKind.RCURLY);
/*  671 */         InlineList inlineList = new InlineList(t.startPos, closingCurly.endPos, elements.<SpelNodeImpl>toArray(new SpelNodeImpl[0])); }
/*      */       else
/*  673 */       { if (peekToken(TokenKind.COMMA, true))
/*  674 */         { List<SpelNodeImpl> elements = new ArrayList<>();
/*  675 */           elements.add(firstExpression);
/*      */           while (true)
/*  677 */           { elements.add(eatExpression());
/*      */             
/*  679 */             if (!peekToken(TokenKind.COMMA, true))
/*  680 */             { closingCurly = eatToken(TokenKind.RCURLY);
/*  681 */               InlineList inlineList = new InlineList(t.startPos, closingCurly.endPos, elements.<SpelNodeImpl>toArray(new SpelNodeImpl[0]));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  700 */               this.constructedNodes.push(inlineList);
/*  701 */               return true; }  }  }  if (peekToken(TokenKind.COLON, true)) { List<SpelNodeImpl> elements = new ArrayList<>(); elements.add(firstExpression); elements.add(eatExpression()); while (peekToken(TokenKind.COMMA, true)) { elements.add(eatExpression()); eatToken(TokenKind.COLON); elements.add(eatExpression()); }  closingCurly = eatToken(TokenKind.RCURLY); inlineMap = new InlineMap(t.startPos, closingCurly.endPos, elements.<SpelNodeImpl>toArray(new SpelNodeImpl[0])); } else { throw internalException(t.startPos, SpelMessage.OOD, new Object[0]); }  }  }  this.constructedNodes.push(inlineMap); return true;
/*      */   }
/*      */   
/*      */   private boolean maybeEatIndexer(boolean nullSafeNavigation) {
/*  705 */     Token t = peekToken();
/*  706 */     if (t == null || !peekToken(TokenKind.LSQUARE, true)) {
/*  707 */       return false;
/*      */     }
/*  709 */     SpelNodeImpl expr = eatExpression();
/*  710 */     if (expr == null) {
/*  711 */       throw internalException(t.startPos, SpelMessage.MISSING_SELECTION_EXPRESSION, new Object[0]);
/*      */     }
/*  713 */     eatToken(TokenKind.RSQUARE);
/*  714 */     this.constructedNodes.push(new Indexer(nullSafeNavigation, t.startPos, t.endPos, expr));
/*  715 */     return true;
/*      */   }
/*      */   
/*      */   private boolean maybeEatSelection(boolean nullSafeNavigation) {
/*  719 */     Token t = peekToken();
/*  720 */     if (t == null || !peekSelectToken()) {
/*  721 */       return false;
/*      */     }
/*  723 */     nextToken();
/*  724 */     SpelNodeImpl expr = eatExpression();
/*  725 */     if (expr == null) {
/*  726 */       throw internalException(t.startPos, SpelMessage.MISSING_SELECTION_EXPRESSION, new Object[0]);
/*      */     }
/*  728 */     eatToken(TokenKind.RSQUARE);
/*  729 */     if (t.kind == TokenKind.SELECT_FIRST) {
/*  730 */       this.constructedNodes.push(new Selection(nullSafeNavigation, 1, t.startPos, t.endPos, expr));
/*      */     }
/*  732 */     else if (t.kind == TokenKind.SELECT_LAST) {
/*  733 */       this.constructedNodes.push(new Selection(nullSafeNavigation, 2, t.startPos, t.endPos, expr));
/*      */     } else {
/*      */       
/*  736 */       this.constructedNodes.push(new Selection(nullSafeNavigation, 0, t.startPos, t.endPos, expr));
/*      */     } 
/*  738 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SpelNodeImpl eatPossiblyQualifiedId() {
/*  745 */     Deque<SpelNodeImpl> qualifiedIdPieces = new ArrayDeque<>();
/*  746 */     Token node = peekToken();
/*  747 */     while (isValidQualifiedId(node)) {
/*  748 */       nextToken();
/*  749 */       if (node.kind != TokenKind.DOT) {
/*  750 */         qualifiedIdPieces.add(new Identifier(node.stringValue(), node.startPos, node.endPos));
/*      */       }
/*  752 */       node = peekToken();
/*      */     } 
/*  754 */     if (qualifiedIdPieces.isEmpty()) {
/*  755 */       if (node == null) {
/*  756 */         throw internalException(this.expressionString.length(), SpelMessage.OOD, new Object[0]);
/*      */       }
/*  758 */       throw internalException(node.startPos, SpelMessage.NOT_EXPECTED_TOKEN, new Object[] { "qualified ID", node
/*  759 */             .getKind().toString().toLowerCase(Locale.ROOT) });
/*      */     } 
/*  761 */     return (SpelNodeImpl)new QualifiedIdentifier(((SpelNodeImpl)qualifiedIdPieces.getFirst()).getStartPosition(), ((SpelNodeImpl)qualifiedIdPieces
/*  762 */         .getLast()).getEndPosition(), (SpelNodeImpl[])qualifiedIdPieces.toArray((Object[])new SpelNodeImpl[0]));
/*      */   }
/*      */   
/*      */   @Contract("null -> false")
/*      */   private boolean isValidQualifiedId(@Nullable Token node) {
/*  767 */     if (node == null || node.kind == TokenKind.LITERAL_STRING) {
/*  768 */       return false;
/*      */     }
/*  770 */     if (node.kind == TokenKind.DOT || node.kind == TokenKind.IDENTIFIER) {
/*  771 */       return true;
/*      */     }
/*  773 */     String value = node.stringValue();
/*  774 */     return (StringUtils.hasLength(value) && VALID_QUALIFIED_ID_PATTERN.matcher(value).matches());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maybeEatMethodOrProperty(boolean nullSafeNavigation) {
/*  781 */     if (peekToken(TokenKind.IDENTIFIER)) {
/*  782 */       Token methodOrPropertyName = takeToken();
/*  783 */       SpelNodeImpl[] args = maybeEatMethodArgs();
/*  784 */       if (args == null) {
/*      */         
/*  786 */         push((SpelNodeImpl)new PropertyOrFieldReference(nullSafeNavigation, methodOrPropertyName.stringValue(), methodOrPropertyName.startPos, methodOrPropertyName.endPos));
/*      */         
/*  788 */         return true;
/*      */       } 
/*      */       
/*  791 */       push((SpelNodeImpl)new MethodReference(nullSafeNavigation, methodOrPropertyName.stringValue(), methodOrPropertyName.startPos, methodOrPropertyName.endPos, args));
/*      */       
/*  793 */       return true;
/*      */     } 
/*  795 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maybeEatConstructorReference() {
/*  801 */     if (peekIdentifierToken("new")) {
/*  802 */       Token newToken = takeToken();
/*      */       
/*  804 */       if (peekToken(TokenKind.RSQUARE)) {
/*      */         
/*  806 */         push((SpelNodeImpl)new PropertyOrFieldReference(false, newToken.stringValue(), newToken.startPos, newToken.endPos));
/*  807 */         return true;
/*      */       } 
/*  809 */       SpelNodeImpl possiblyQualifiedConstructorName = eatPossiblyQualifiedId();
/*  810 */       List<SpelNodeImpl> nodes = new ArrayList<>();
/*  811 */       nodes.add(possiblyQualifiedConstructorName);
/*  812 */       if (peekToken(TokenKind.LSQUARE)) {
/*      */         
/*  814 */         List<SpelNodeImpl> dimensions = new ArrayList<>();
/*  815 */         while (peekToken(TokenKind.LSQUARE, true)) {
/*  816 */           if (!peekToken(TokenKind.RSQUARE)) {
/*  817 */             dimensions.add(eatExpression());
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  822 */             dimensions.add(null);
/*      */           } 
/*  824 */           eatToken(TokenKind.RSQUARE);
/*      */         } 
/*  826 */         if (maybeEatInlineListOrMap()) {
/*  827 */           nodes.add(pop());
/*      */         }
/*  829 */         push((SpelNodeImpl)new ConstructorReference(newToken.startPos, newToken.endPos, dimensions
/*  830 */               .<SpelNodeImpl>toArray(new SpelNodeImpl[0]), nodes.<SpelNodeImpl>toArray(new SpelNodeImpl[0])));
/*      */       }
/*      */       else {
/*      */         
/*  834 */         eatConstructorArgs(nodes);
/*  835 */         push((SpelNodeImpl)new ConstructorReference(newToken.startPos, newToken.endPos, nodes.<SpelNodeImpl>toArray(new SpelNodeImpl[0])));
/*      */       } 
/*  837 */       return true;
/*      */     } 
/*  839 */     return false;
/*      */   }
/*      */   
/*      */   private void push(SpelNodeImpl newNode) {
/*  843 */     this.constructedNodes.push(newNode);
/*      */   }
/*      */   
/*      */   private SpelNodeImpl pop() {
/*  847 */     return this.constructedNodes.pop();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maybeEatLiteral() {
/*  859 */     Token t = peekToken();
/*  860 */     if (t == null) {
/*  861 */       return false;
/*      */     }
/*  863 */     if (t.kind == TokenKind.LITERAL_INT) {
/*  864 */       push((SpelNodeImpl)Literal.getIntLiteral(t.stringValue(), t.startPos, t.endPos, 10));
/*      */     }
/*  866 */     else if (t.kind == TokenKind.LITERAL_LONG) {
/*  867 */       push((SpelNodeImpl)Literal.getLongLiteral(t.stringValue(), t.startPos, t.endPos, 10));
/*      */     }
/*  869 */     else if (t.kind == TokenKind.LITERAL_HEXINT) {
/*  870 */       push((SpelNodeImpl)Literal.getIntLiteral(t.stringValue(), t.startPos, t.endPos, 16));
/*      */     }
/*  872 */     else if (t.kind == TokenKind.LITERAL_HEXLONG) {
/*  873 */       push((SpelNodeImpl)Literal.getLongLiteral(t.stringValue(), t.startPos, t.endPos, 16));
/*      */     }
/*  875 */     else if (t.kind == TokenKind.LITERAL_REAL) {
/*  876 */       push((SpelNodeImpl)Literal.getRealLiteral(t.stringValue(), t.startPos, t.endPos, false));
/*      */     }
/*  878 */     else if (t.kind == TokenKind.LITERAL_REAL_FLOAT) {
/*  879 */       push((SpelNodeImpl)Literal.getRealLiteral(t.stringValue(), t.startPos, t.endPos, true));
/*      */     }
/*  881 */     else if (peekIdentifierToken("true")) {
/*  882 */       push((SpelNodeImpl)new BooleanLiteral(t.stringValue(), t.startPos, t.endPos, true));
/*      */     }
/*  884 */     else if (peekIdentifierToken("false")) {
/*  885 */       push((SpelNodeImpl)new BooleanLiteral(t.stringValue(), t.startPos, t.endPos, false));
/*      */     }
/*  887 */     else if (t.kind == TokenKind.LITERAL_STRING) {
/*  888 */       push((SpelNodeImpl)new StringLiteral(t.stringValue(), t.startPos, t.endPos, t.stringValue()));
/*      */     } else {
/*      */       
/*  891 */       return false;
/*      */     } 
/*  893 */     nextToken();
/*  894 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean maybeEatParenExpression() {
/*  899 */     if (peekToken(TokenKind.LPAREN)) {
/*  900 */       Token t = nextToken();
/*  901 */       if (t == null) {
/*  902 */         return false;
/*      */       }
/*  904 */       SpelNodeImpl expr = eatExpression();
/*  905 */       if (expr == null) {
/*  906 */         throw internalException(t.startPos, SpelMessage.OOD, new Object[0]);
/*      */       }
/*  908 */       eatToken(TokenKind.RPAREN);
/*  909 */       push(expr);
/*  910 */       return true;
/*      */     } 
/*      */     
/*  913 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Token maybeEatRelationalOperator() {
/*  922 */     Token t = peekToken();
/*  923 */     if (t == null) {
/*  924 */       return null;
/*      */     }
/*  926 */     if (t.isNumericRelationalOperator()) {
/*  927 */       return t;
/*      */     }
/*  929 */     if (t.isIdentifier()) {
/*  930 */       String idString = t.stringValue();
/*  931 */       if (idString.equalsIgnoreCase("instanceof")) {
/*  932 */         return t.asInstanceOfToken();
/*      */       }
/*  934 */       if (idString.equalsIgnoreCase("matches")) {
/*  935 */         return t.asMatchesToken();
/*      */       }
/*  937 */       if (idString.equalsIgnoreCase("between")) {
/*  938 */         return t.asBetweenToken();
/*      */       }
/*      */     } 
/*  941 */     return null;
/*      */   }
/*      */   
/*      */   private Token eatToken(TokenKind expectedKind) {
/*  945 */     Token t = nextToken();
/*  946 */     if (t == null) {
/*  947 */       int pos = this.expressionString.length();
/*  948 */       throw internalException(pos, SpelMessage.OOD, new Object[0]);
/*      */     } 
/*  950 */     if (t.kind != expectedKind) {
/*  951 */       throw internalException(t.startPos, SpelMessage.NOT_EXPECTED_TOKEN, new Object[] { expectedKind
/*  952 */             .toString().toLowerCase(Locale.ROOT), t.getKind().toString().toLowerCase(Locale.ROOT) });
/*      */     }
/*  954 */     return t;
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind desiredTokenKind) {
/*  958 */     return peekToken(desiredTokenKind, false);
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind desiredTokenKind, boolean consumeIfMatched) {
/*  962 */     Token t = peekToken();
/*  963 */     if (t == null) {
/*  964 */       return false;
/*      */     }
/*  966 */     if (t.kind == desiredTokenKind) {
/*  967 */       if (consumeIfMatched) {
/*  968 */         this.tokenStreamPointer++;
/*      */       }
/*  970 */       return true;
/*      */     } 
/*      */     
/*  973 */     if (desiredTokenKind == TokenKind.IDENTIFIER)
/*      */     {
/*      */ 
/*      */       
/*  977 */       if (t.kind.ordinal() >= TokenKind.DIV.ordinal() && t.kind.ordinal() <= TokenKind.NOT.ordinal() && t.data != null)
/*      */       {
/*      */         
/*  980 */         return true;
/*      */       }
/*      */     }
/*  983 */     return false;
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind possible1, TokenKind possible2) {
/*  987 */     Token t = peekToken();
/*  988 */     if (t == null) {
/*  989 */       return false;
/*      */     }
/*  991 */     return (t.kind == possible1 || t.kind == possible2);
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind possible1, TokenKind possible2, TokenKind possible3) {
/*  995 */     Token t = peekToken();
/*  996 */     if (t == null) {
/*  997 */       return false;
/*      */     }
/*  999 */     return (t.kind == possible1 || t.kind == possible2 || t.kind == possible3);
/*      */   }
/*      */   
/*      */   private boolean peekIdentifierToken(String identifierString) {
/* 1003 */     Token t = peekToken();
/* 1004 */     if (t == null) {
/* 1005 */       return false;
/*      */     }
/* 1007 */     return (t.kind == TokenKind.IDENTIFIER && identifierString.equalsIgnoreCase(t.stringValue()));
/*      */   }
/*      */   
/*      */   private boolean peekSelectToken() {
/* 1011 */     Token t = peekToken();
/* 1012 */     if (t == null) {
/* 1013 */       return false;
/*      */     }
/* 1015 */     return (t.kind == TokenKind.SELECT || t.kind == TokenKind.SELECT_FIRST || t.kind == TokenKind.SELECT_LAST);
/*      */   }
/*      */   
/*      */   private Token takeToken() {
/* 1019 */     if (this.tokenStreamPointer >= this.tokenStreamLength) {
/* 1020 */       throw new IllegalStateException("No token");
/*      */     }
/* 1022 */     return this.tokenStream.get(this.tokenStreamPointer++);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Token nextToken() {
/* 1027 */     if (this.tokenStreamPointer >= this.tokenStreamLength) {
/* 1028 */       return null;
/*      */     }
/* 1030 */     return this.tokenStream.get(this.tokenStreamPointer++);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Token peekToken() {
/* 1035 */     if (this.tokenStreamPointer >= this.tokenStreamLength) {
/* 1036 */       return null;
/*      */     }
/* 1038 */     return this.tokenStream.get(this.tokenStreamPointer);
/*      */   }
/*      */   
/*      */   public String toString(@Nullable Token t) {
/* 1042 */     if (t == null) {
/* 1043 */       return "";
/*      */     }
/* 1045 */     if (t.getKind().hasPayload()) {
/* 1046 */       return t.stringValue();
/*      */     }
/* 1048 */     return t.kind.toString().toLowerCase(Locale.ROOT);
/*      */   }
/*      */   
/*      */   @Contract("_, null, _ -> fail; _, _, null -> fail")
/*      */   private void checkOperands(Token token, @Nullable SpelNodeImpl left, @Nullable SpelNodeImpl right) {
/* 1053 */     checkLeftOperand(token, left);
/* 1054 */     checkRightOperand(token, right);
/*      */   }
/*      */   
/*      */   @Contract("_, null -> fail")
/*      */   private void checkLeftOperand(Token token, @Nullable SpelNodeImpl operandExpression) {
/* 1059 */     if (operandExpression == null) {
/* 1060 */       throw internalException(token.startPos, SpelMessage.LEFT_OPERAND_PROBLEM, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   @Contract("_, null -> fail")
/*      */   private void checkRightOperand(Token token, @Nullable SpelNodeImpl operandExpression) {
/* 1066 */     if (operandExpression == null) {
/* 1067 */       throw internalException(token.startPos, SpelMessage.RIGHT_OPERAND_PROBLEM, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   private InternalParseException internalException(int startPos, SpelMessage message, Object... inserts) {
/* 1072 */     return new InternalParseException(new SpelParseException(this.expressionString, startPos, message, inserts));
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\standard\InternalSpelExpressionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */