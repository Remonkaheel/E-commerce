/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Token
/*     */ {
/*     */   final TokenKind kind;
/*     */   @Nullable
/*     */   final String data;
/*     */   final int startPos;
/*     */   final int endPos;
/*     */   
/*     */   Token(TokenKind tokenKind, int startPos, int endPos) {
/*  48 */     this(tokenKind, null, startPos, endPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Token(TokenKind tokenKind, @Nullable char[] tokenData, int startPos, int endPos) {
/*  59 */     this.kind = tokenKind;
/*  60 */     this.data = (tokenData != null) ? new String(tokenData) : null;
/*  61 */     this.startPos = startPos;
/*  62 */     this.endPos = endPos;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenKind getKind() {
/*  67 */     return this.kind;
/*     */   }
/*     */   
/*     */   public boolean isIdentifier() {
/*  71 */     return (this.kind == TokenKind.IDENTIFIER);
/*     */   }
/*     */   
/*     */   public boolean isNumericRelationalOperator() {
/*  75 */     return (this.kind == TokenKind.GT || this.kind == TokenKind.GE || this.kind == TokenKind.LT || this.kind == TokenKind.LE || this.kind == TokenKind.EQ || this.kind == TokenKind.NE);
/*     */   }
/*     */ 
/*     */   
/*     */   public String stringValue() {
/*  80 */     return (this.data != null) ? this.data : "";
/*     */   }
/*     */   
/*     */   public Token asInstanceOfToken() {
/*  84 */     return new Token(TokenKind.INSTANCEOF, this.startPos, this.endPos);
/*     */   }
/*     */   
/*     */   public Token asMatchesToken() {
/*  88 */     return new Token(TokenKind.MATCHES, this.startPos, this.endPos);
/*     */   }
/*     */   
/*     */   public Token asBetweenToken() {
/*  92 */     return new Token(TokenKind.BETWEEN, this.startPos, this.endPos);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuilder sb = new StringBuilder();
/*  99 */     sb.append('[').append(this.kind);
/* 100 */     if (this.kind.hasPayload()) {
/* 101 */       sb.append(':').append(this.data);
/*     */     }
/* 103 */     sb.append(']');
/* 104 */     sb.append('(').append(this.startPos).append(',').append(this.endPos).append(')');
/* 105 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\standard\Token.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */