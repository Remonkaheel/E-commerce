/*    */ package org.springframework.expression.spel;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalParseException
/*    */   extends RuntimeException
/*    */ {
/*    */   public InternalParseException(@Nullable SpelParseException cause) {
/* 32 */     super((Throwable)cause);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SpelParseException getCause() {
/* 38 */     return (SpelParseException)super.getCause();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\InternalParseException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */