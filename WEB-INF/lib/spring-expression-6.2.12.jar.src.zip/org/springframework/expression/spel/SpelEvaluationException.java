/*    */ package org.springframework.expression.spel;
/*    */ 
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpelEvaluationException
/*    */   extends EvaluationException
/*    */ {
/*    */   private final SpelMessage message;
/*    */   @Nullable
/*    */   private final Object[] inserts;
/*    */   
/*    */   public SpelEvaluationException(SpelMessage message, @Nullable Object... inserts) {
/* 44 */     super(message.formatMessage(inserts));
/* 45 */     this.message = message;
/* 46 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelEvaluationException(int position, SpelMessage message, @Nullable Object... inserts) {
/* 50 */     super(position, message.formatMessage(inserts));
/* 51 */     this.message = message;
/* 52 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelEvaluationException(int position, @Nullable Throwable cause, SpelMessage message, @Nullable Object... inserts) {
/* 56 */     super(position, message.formatMessage(inserts), cause);
/* 57 */     this.message = message;
/* 58 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelEvaluationException(@Nullable Throwable cause, SpelMessage message, @Nullable Object... inserts) {
/* 62 */     super(message.formatMessage(inserts), cause);
/* 63 */     this.message = message;
/* 64 */     this.inserts = inserts;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPosition(int position) {
/* 72 */     this.position = position;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpelMessage getMessageCode() {
/* 79 */     return this.message;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object[] getInserts() {
/* 87 */     return this.inserts;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\SpelEvaluationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */