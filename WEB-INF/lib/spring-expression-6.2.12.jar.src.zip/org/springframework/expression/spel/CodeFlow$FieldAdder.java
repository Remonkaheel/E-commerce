package org.springframework.expression.spel;

import org.springframework.asm.ClassWriter;

@FunctionalInterface
public interface FieldAdder {
  void generateField(ClassWriter paramClassWriter, CodeFlow paramCodeFlow);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\spel\CodeFlow$FieldAdder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */