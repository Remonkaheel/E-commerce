package org.springframework.expression;

import org.springframework.lang.Nullable;

public interface PropertyAccessor extends TargetedAccessor {
  boolean canRead(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, String paramString) throws AccessException;
  
  TypedValue read(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, String paramString) throws AccessException;
  
  boolean canWrite(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, String paramString) throws AccessException;
  
  void write(EvaluationContext paramEvaluationContext, @Nullable Object paramObject1, String paramString, @Nullable Object paramObject2) throws AccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\PropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */