package org.springframework.expression;

import java.lang.reflect.Method;
import java.util.List;

@FunctionalInterface
public interface MethodFilter {
  List<Method> filter(List<Method> paramList);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\MethodFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */