package org.springframework.expression;

@FunctionalInterface
public interface BeanResolver {
  Object resolve(EvaluationContext paramEvaluationContext, String paramString) throws AccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\BeanResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */