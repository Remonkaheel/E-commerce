/*     */ package org.springframework.expression.common;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParseException;
/*     */ import org.springframework.expression.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TemplateAwareExpressionParser
/*     */   implements ExpressionParser
/*     */ {
/*     */   public Expression parseExpression(String expressionString) throws ParseException {
/*  48 */     return parseExpression(expressionString, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression parseExpression(String expressionString, @Nullable ParserContext context) throws ParseException {
/*  53 */     if (context != null && context.isTemplate()) {
/*  54 */       Assert.notNull(expressionString, "'expressionString' must not be null");
/*  55 */       return parseTemplate(expressionString, context);
/*     */     } 
/*     */     
/*  58 */     Assert.hasText(expressionString, "'expressionString' must not be null or blank");
/*  59 */     return doParseExpression(expressionString, context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Expression parseTemplate(String expressionString, ParserContext context) throws ParseException {
/*  65 */     if (expressionString.isEmpty()) {
/*  66 */       return new LiteralExpression("");
/*     */     }
/*     */     
/*  69 */     Expression[] expressions = parseExpressions(expressionString, context);
/*  70 */     if (expressions.length == 1) {
/*  71 */       return expressions[0];
/*     */     }
/*     */     
/*  74 */     return new CompositeStringExpression(expressionString, expressions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Expression[] parseExpressions(String expressionString, ParserContext context) throws ParseException {
/*  97 */     List<Expression> expressions = new ArrayList<>();
/*  98 */     String prefix = context.getExpressionPrefix();
/*  99 */     String suffix = context.getExpressionSuffix();
/* 100 */     int startIdx = 0;
/*     */     
/* 102 */     while (startIdx < expressionString.length()) {
/* 103 */       int prefixIndex = expressionString.indexOf(prefix, startIdx);
/* 104 */       if (prefixIndex >= startIdx) {
/*     */         
/* 106 */         if (prefixIndex > startIdx) {
/* 107 */           expressions.add(new LiteralExpression(expressionString.substring(startIdx, prefixIndex)));
/*     */         }
/* 109 */         int afterPrefixIndex = prefixIndex + prefix.length();
/* 110 */         int suffixIndex = skipToCorrectEndSuffix(suffix, expressionString, afterPrefixIndex);
/* 111 */         if (suffixIndex == -1) {
/* 112 */           throw new ParseException(expressionString, prefixIndex, "No ending suffix '" + suffix + "' for expression starting at character " + prefixIndex + ": " + expressionString
/*     */               
/* 114 */               .substring(prefixIndex));
/*     */         }
/* 116 */         if (suffixIndex == afterPrefixIndex) {
/* 117 */           throw new ParseException(expressionString, prefixIndex, "No expression defined within delimiter '" + prefix + suffix + "' at character " + prefixIndex);
/*     */         }
/*     */ 
/*     */         
/* 121 */         String expr = expressionString.substring(prefixIndex + prefix.length(), suffixIndex);
/* 122 */         expr = expr.trim();
/* 123 */         if (expr.isEmpty()) {
/* 124 */           throw new ParseException(expressionString, prefixIndex, "No expression defined within delimiter '" + prefix + suffix + "' at character " + prefixIndex);
/*     */         }
/*     */ 
/*     */         
/* 128 */         expressions.add(doParseExpression(expr, context));
/* 129 */         startIdx = suffixIndex + suffix.length();
/*     */         
/*     */         continue;
/*     */       } 
/* 133 */       expressions.add(new LiteralExpression(expressionString.substring(startIdx)));
/* 134 */       startIdx = expressionString.length();
/*     */     } 
/*     */ 
/*     */     
/* 138 */     return expressions.<Expression>toArray(new Expression[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSuffixHere(String expressionString, int pos, String suffix) {
/* 149 */     int suffixPosition = 0;
/* 150 */     for (int i = 0; i < suffix.length() && pos < expressionString.length(); i++) {
/* 151 */       if (expressionString.charAt(pos++) != suffix.charAt(suffixPosition++)) {
/* 152 */         return false;
/*     */       }
/*     */     } 
/* 155 */     if (suffixPosition != suffix.length())
/*     */     {
/* 157 */       return false;
/*     */     }
/* 159 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int skipToCorrectEndSuffix(String suffix, String expressionString, int afterPrefixIndex) throws ParseException {
/* 177 */     int pos = afterPrefixIndex;
/* 178 */     int maxlen = expressionString.length();
/* 179 */     int nextSuffix = expressionString.indexOf(suffix, afterPrefixIndex);
/* 180 */     if (nextSuffix == -1) {
/* 181 */       return -1;
/*     */     }
/* 183 */     Deque<Bracket> stack = new ArrayDeque<>();
/* 184 */     while (pos < maxlen && (
/* 185 */       !isSuffixHere(expressionString, pos, suffix) || !stack.isEmpty())) {
/*     */       Bracket p;
/*     */       int endLiteral;
/* 188 */       char ch = expressionString.charAt(pos);
/* 189 */       switch (ch) { case '(': case '[':
/*     */         case '{':
/* 191 */           stack.push(new Bracket(ch, pos)); break;
/*     */         case ')': case ']':
/*     */         case '}':
/* 194 */           if (stack.isEmpty()) {
/* 195 */             throw new ParseException(expressionString, pos, "Found closing '" + ch + "' at position " + pos + " without an opening '" + 
/*     */                 
/* 197 */                 Bracket.theOpenBracketFor(ch) + "'");
/*     */           }
/* 199 */           p = stack.pop();
/* 200 */           if (!p.compatibleWithCloseBracket(ch)) {
/* 201 */             throw new ParseException(expressionString, pos, "Found closing '" + ch + "' at position " + pos + " but most recent opening is '" + p.bracket + "' at position " + p.pos);
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case '"':
/*     */         case '\'':
/* 208 */           endLiteral = expressionString.indexOf(ch, pos + 1);
/* 209 */           if (endLiteral == -1) {
/* 210 */             throw new ParseException(expressionString, pos, "Found non terminating string literal starting at position " + pos);
/*     */           }
/*     */           
/* 213 */           pos = endLiteral;
/*     */           break; }
/*     */       
/* 216 */       pos++;
/*     */     } 
/* 218 */     if (!stack.isEmpty()) {
/* 219 */       Bracket p = stack.pop();
/* 220 */       throw new ParseException(expressionString, p.pos, "Missing closing '" + 
/* 221 */           Bracket.theCloseBracketFor(p.bracket) + "' for '" + p.bracket + "' at position " + p.pos);
/*     */     } 
/* 223 */     if (!isSuffixHere(expressionString, pos, suffix)) {
/* 224 */       return -1;
/*     */     }
/* 226 */     return pos;
/*     */   }
/*     */   
/*     */   protected abstract Expression doParseExpression(String paramString, @Nullable ParserContext paramParserContext) throws ParseException;
/*     */   
/*     */   private static final class Bracket extends Record {
/*     */     private final char bracket;
/*     */     private final int pos;
/*     */     
/*     */     public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/expression/common/TemplateAwareExpressionParser$Bracket;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #247	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/expression/common/TemplateAwareExpressionParser$Bracket;
/*     */     }
/*     */     
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/expression/common/TemplateAwareExpressionParser$Bracket;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #247	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/expression/common/TemplateAwareExpressionParser$Bracket;
/*     */     }
/*     */     
/*     */     public final boolean equals(Object o) {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/expression/common/TemplateAwareExpressionParser$Bracket;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #247	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/expression/common/TemplateAwareExpressionParser$Bracket;
/*     */       //   0	8	1	o	Ljava/lang/Object;
/*     */     }
/*     */     
/* 247 */     private Bracket(char bracket, int pos) { this.bracket = bracket; this.pos = pos; } public char bracket() { return this.bracket; } public int pos() { return this.pos; }
/*     */     
/*     */     boolean compatibleWithCloseBracket(char closeBracket) {
/* 250 */       switch (this.bracket) { case '{': return 
/* 251 */             (closeBracket == '}');
/* 252 */         case '[': return (closeBracket == ']'); }
/* 253 */        return (closeBracket == ')');
/*     */     }
/*     */ 
/*     */     
/*     */     static char theOpenBracketFor(char closeBracket) {
/* 258 */       switch (closeBracket) { case '}': case ']':  }  return 
/*     */ 
/*     */         
/* 261 */         '(';
/*     */     }
/*     */ 
/*     */     
/*     */     static char theCloseBracketFor(char openBracket) {
/* 266 */       switch (openBracket) { case '{': case '[':  }  return 
/*     */ 
/*     */         
/* 269 */         ')';
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\common\TemplateAwareExpressionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */