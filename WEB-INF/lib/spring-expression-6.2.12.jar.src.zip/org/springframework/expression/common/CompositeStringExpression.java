/*     */ package org.springframework.expression.common;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeStringExpression
/*     */   implements Expression
/*     */ {
/*     */   private final String expressionString;
/*     */   private final Expression[] expressions;
/*     */   
/*     */   public CompositeStringExpression(String expressionString, Expression[] expressions) {
/*  54 */     this.expressionString = expressionString;
/*  55 */     this.expressions = expressions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getExpressionString() {
/*  61 */     return this.expressionString;
/*     */   }
/*     */   
/*     */   public final Expression[] getExpressions() {
/*  65 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() throws EvaluationException {
/*  70 */     StringBuilder sb = new StringBuilder();
/*  71 */     for (Expression expression : this.expressions) {
/*  72 */       String value = (String)expression.getValue(String.class);
/*  73 */       if (value != null) {
/*  74 */         sb.append(value);
/*     */       }
/*     */     } 
/*  77 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(@Nullable Class<T> expectedResultType) throws EvaluationException {
/*  83 */     String value = getValue();
/*  84 */     return ExpressionUtils.convertTypedValue(null, new TypedValue(value), expectedResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(@Nullable Object rootObject) throws EvaluationException {
/*  89 */     StringBuilder sb = new StringBuilder();
/*  90 */     for (Expression expression : this.expressions) {
/*  91 */       String value = (String)expression.getValue(rootObject, String.class);
/*  92 */       if (value != null) {
/*  93 */         sb.append(value);
/*     */       }
/*     */     } 
/*  96 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(@Nullable Object rootObject, @Nullable Class<T> desiredResultType) throws EvaluationException {
/* 102 */     String value = getValue(rootObject);
/* 103 */     return ExpressionUtils.convertTypedValue(null, new TypedValue(value), desiredResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(EvaluationContext context) throws EvaluationException {
/* 108 */     StringBuilder sb = new StringBuilder();
/* 109 */     for (Expression expression : this.expressions) {
/* 110 */       String value = (String)expression.getValue(context, String.class);
/* 111 */       if (value != null) {
/* 112 */         sb.append(value);
/*     */       }
/*     */     } 
/* 115 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(EvaluationContext context, @Nullable Class<T> expectedResultType) throws EvaluationException {
/* 123 */     String value = getValue(context);
/* 124 */     return ExpressionUtils.convertTypedValue(context, new TypedValue(value), expectedResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 129 */     StringBuilder sb = new StringBuilder();
/* 130 */     for (Expression expression : this.expressions) {
/* 131 */       String value = (String)expression.getValue(context, rootObject, String.class);
/* 132 */       if (value != null) {
/* 133 */         sb.append(value);
/*     */       }
/*     */     } 
/* 136 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(EvaluationContext context, @Nullable Object rootObject, @Nullable Class<T> desiredResultType) throws EvaluationException {
/* 144 */     String value = getValue(context, rootObject);
/* 145 */     return ExpressionUtils.convertTypedValue(context, new TypedValue(value), desiredResultType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getValueType() {
/* 150 */     return String.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context) {
/* 155 */     return String.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getValueType(@Nullable Object rootObject) throws EvaluationException {
/* 160 */     return String.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 165 */     return String.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor() {
/* 170 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(@Nullable Object rootObject) throws EvaluationException {
/* 175 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context) {
/* 180 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 187 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(@Nullable Object rootObject) throws EvaluationException {
/* 192 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(EvaluationContext context) {
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(EvaluationContext context, @Nullable Object rootObject) throws EvaluationException {
/* 202 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable Object rootObject, @Nullable Object value) throws EvaluationException {
/* 207 */     throw new EvaluationException(this.expressionString, "Cannot call setValue on a composite expression");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext context, @Nullable Object value) throws EvaluationException {
/* 212 */     throw new EvaluationException(this.expressionString, "Cannot call setValue on a composite expression");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext context, @Nullable Object rootObject, @Nullable Object value) throws EvaluationException {
/* 217 */     throw new EvaluationException(this.expressionString, "Cannot call setValue on a composite expression");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\common\CompositeStringExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */