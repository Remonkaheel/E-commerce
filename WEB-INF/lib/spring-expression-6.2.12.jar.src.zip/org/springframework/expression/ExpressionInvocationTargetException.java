/*    */ package org.springframework.expression;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionInvocationTargetException
/*    */   extends EvaluationException
/*    */ {
/*    */   public ExpressionInvocationTargetException(int position, String message, @Nullable Throwable cause) {
/* 34 */     super(position, message, cause);
/*    */   }
/*    */   
/*    */   public ExpressionInvocationTargetException(int position, String message) {
/* 38 */     super(position, message);
/*    */   }
/*    */   
/*    */   public ExpressionInvocationTargetException(String expressionString, String message) {
/* 42 */     super(expressionString, message);
/*    */   }
/*    */   
/*    */   public ExpressionInvocationTargetException(String message, @Nullable Throwable cause) {
/* 46 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ExpressionInvocationTargetException(String message) {
/* 50 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-expression-6.2.12.jar!\org\springframework\expression\ExpressionInvocationTargetException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */