package org.springframework.asm;

public final class SpringAsmInfo {
  public static final int ASM_VERSION = 17432576;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\asm\SpringAsmInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */