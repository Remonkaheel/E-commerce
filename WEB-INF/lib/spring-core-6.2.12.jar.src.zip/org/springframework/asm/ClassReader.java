/*      */ package org.springframework.asm;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassReader
/*      */ {
/*      */   public static final int SKIP_CODE = 1;
/*      */   public static final int SKIP_DEBUG = 2;
/*      */   public static final int SKIP_FRAMES = 4;
/*      */   public static final int EXPAND_FRAMES = 8;
/*      */   static final int EXPAND_ASM_INSNS = 256;
/*      */   private static final int MAX_BUFFER_SIZE = 1048576;
/*      */   private static final int INPUT_STREAM_DATA_CHUNK_SIZE = 4096;
/*      */   @Deprecated
/*      */   public final byte[] b;
/*      */   public final int header;
/*      */   final byte[] classFileBuffer;
/*      */   private final int[] cpInfoOffsets;
/*      */   private final String[] constantUtf8Values;
/*      */   private final ConstantDynamic[] constantDynamicValues;
/*      */   private final int[] bootstrapMethodOffsets;
/*      */   private final int maxStringLength;
/*      */   
/*      */   public ClassReader(byte[] classFile) {
/*  166 */     this(classFile, 0, classFile.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassReader(byte[] classFileBuffer, int classFileOffset, int classFileLength) {
/*  180 */     this(classFileBuffer, classFileOffset, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ClassReader(byte[] classFileBuffer, int classFileOffset, boolean checkClassVersion) {
/*  194 */     this.classFileBuffer = classFileBuffer;
/*  195 */     this.b = classFileBuffer;
/*      */ 
/*      */     
/*  198 */     if (checkClassVersion && readShort(classFileOffset + 6) > 69) {
/*  199 */       throw new IllegalArgumentException("Unsupported class file major version " + 
/*  200 */           readShort(classFileOffset + 6));
/*      */     }
/*      */ 
/*      */     
/*  204 */     int constantPoolCount = readUnsignedShort(classFileOffset + 8);
/*  205 */     this.cpInfoOffsets = new int[constantPoolCount];
/*  206 */     this.constantUtf8Values = new String[constantPoolCount];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     int currentCpInfoIndex = 1;
/*  212 */     int currentCpInfoOffset = classFileOffset + 10;
/*  213 */     int currentMaxStringLength = 0;
/*  214 */     boolean hasBootstrapMethods = false;
/*  215 */     boolean hasConstantDynamic = false;
/*      */     
/*  217 */     while (currentCpInfoIndex < constantPoolCount) {
/*  218 */       int cpInfoSize; this.cpInfoOffsets[currentCpInfoIndex++] = currentCpInfoOffset + 1;
/*      */       
/*  220 */       switch (classFileBuffer[currentCpInfoOffset]) {
/*      */         case 3:
/*      */         case 4:
/*      */         case 9:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*  227 */           cpInfoSize = 5;
/*      */           break;
/*      */         case 17:
/*  230 */           cpInfoSize = 5;
/*  231 */           hasBootstrapMethods = true;
/*  232 */           hasConstantDynamic = true;
/*      */           break;
/*      */         case 18:
/*  235 */           cpInfoSize = 5;
/*  236 */           hasBootstrapMethods = true;
/*      */           break;
/*      */         case 5:
/*      */         case 6:
/*  240 */           cpInfoSize = 9;
/*  241 */           currentCpInfoIndex++;
/*      */           break;
/*      */         case 1:
/*  244 */           cpInfoSize = 3 + readUnsignedShort(currentCpInfoOffset + 1);
/*  245 */           if (cpInfoSize > currentMaxStringLength)
/*      */           {
/*      */ 
/*      */             
/*  249 */             currentMaxStringLength = cpInfoSize;
/*      */           }
/*      */           break;
/*      */         case 15:
/*  253 */           cpInfoSize = 4;
/*      */           break;
/*      */         case 7:
/*      */         case 8:
/*      */         case 16:
/*      */         case 19:
/*      */         case 20:
/*  260 */           cpInfoSize = 3;
/*      */           break;
/*      */         default:
/*  263 */           throw new IllegalArgumentException();
/*      */       } 
/*  265 */       currentCpInfoOffset += cpInfoSize;
/*      */     } 
/*  267 */     this.maxStringLength = currentMaxStringLength;
/*      */     
/*  269 */     this.header = currentCpInfoOffset;
/*      */ 
/*      */     
/*  272 */     this.constantDynamicValues = hasConstantDynamic ? new ConstantDynamic[constantPoolCount] : null;
/*      */ 
/*      */     
/*  275 */     this
/*  276 */       .bootstrapMethodOffsets = hasBootstrapMethods ? readBootstrapMethodsAttribute(currentMaxStringLength) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassReader(InputStream inputStream) throws IOException {
/*  288 */     this(readStream(inputStream, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassReader(String className) throws IOException {
/*  299 */     this(
/*  300 */         readStream(
/*  301 */           ClassLoader.getSystemResourceAsStream(className.replace('.', '/') + ".class"), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static byte[] readStream(InputStream inputStream, boolean close) throws IOException {
/*  315 */     if (inputStream == null) {
/*  316 */       throw new IOException("Class not found");
/*      */     }
/*  318 */     int bufferSize = computeBufferSize(inputStream); try {
/*  319 */       ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  335 */       if (close) {
/*  336 */         inputStream.close();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int computeBufferSize(InputStream inputStream) throws IOException {
/*  342 */     int expectedLength = inputStream.available();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  348 */     if (expectedLength < 256) {
/*  349 */       return 4096;
/*      */     }
/*  351 */     return Math.min(expectedLength, 1048576);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAccess() {
/*  366 */     return readUnsignedShort(this.header);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/*  377 */     return readClass(this.header + 2, new char[this.maxStringLength]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSuperName() {
/*  389 */     return readClass(this.header + 4, new char[this.maxStringLength]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getInterfaces() {
/*  401 */     int currentOffset = this.header + 6;
/*  402 */     int interfacesCount = readUnsignedShort(currentOffset);
/*  403 */     String[] interfaces = new String[interfacesCount];
/*  404 */     if (interfacesCount > 0) {
/*  405 */       char[] charBuffer = new char[this.maxStringLength];
/*  406 */       for (int i = 0; i < interfacesCount; i++) {
/*  407 */         currentOffset += 2;
/*  408 */         interfaces[i] = readClass(currentOffset, charBuffer);
/*      */       } 
/*      */     } 
/*  411 */     return interfaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accept(ClassVisitor classVisitor, int parsingOptions) {
/*  427 */     accept(classVisitor, new Attribute[0], parsingOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accept(ClassVisitor classVisitor, Attribute[] attributePrototypes, int parsingOptions) {
/*  448 */     Context context = new Context();
/*  449 */     context.attributePrototypes = attributePrototypes;
/*  450 */     context.parsingOptions = parsingOptions;
/*  451 */     context.charBuffer = new char[this.maxStringLength];
/*      */ 
/*      */     
/*  454 */     char[] charBuffer = context.charBuffer;
/*  455 */     int currentOffset = this.header;
/*  456 */     int accessFlags = readUnsignedShort(currentOffset);
/*  457 */     String thisClass = readClass(currentOffset + 2, charBuffer);
/*  458 */     String superClass = readClass(currentOffset + 4, charBuffer);
/*  459 */     String[] interfaces = new String[readUnsignedShort(currentOffset + 6)];
/*  460 */     currentOffset += 8;
/*  461 */     for (int i = 0; i < interfaces.length; i++) {
/*  462 */       interfaces[i] = readClass(currentOffset, charBuffer);
/*  463 */       currentOffset += 2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  469 */     int innerClassesOffset = 0;
/*      */     
/*  471 */     int enclosingMethodOffset = 0;
/*      */     
/*  473 */     String signature = null;
/*      */     
/*  475 */     String sourceFile = null;
/*      */     
/*  477 */     String sourceDebugExtension = null;
/*      */     
/*  479 */     int runtimeVisibleAnnotationsOffset = 0;
/*      */     
/*  481 */     int runtimeInvisibleAnnotationsOffset = 0;
/*      */     
/*  483 */     int runtimeVisibleTypeAnnotationsOffset = 0;
/*      */     
/*  485 */     int runtimeInvisibleTypeAnnotationsOffset = 0;
/*      */     
/*  487 */     int moduleOffset = 0;
/*      */     
/*  489 */     int modulePackagesOffset = 0;
/*      */     
/*  491 */     String moduleMainClass = null;
/*      */     
/*  493 */     String nestHostClass = null;
/*      */     
/*  495 */     int nestMembersOffset = 0;
/*      */     
/*  497 */     int permittedSubclassesOffset = 0;
/*      */     
/*  499 */     int recordOffset = 0;
/*      */ 
/*      */     
/*  502 */     Attribute attributes = null;
/*      */     
/*  504 */     int currentAttributeOffset = getFirstAttributeOffset();
/*  505 */     for (int j = readUnsignedShort(currentAttributeOffset - 2); j > 0; j--) {
/*      */       
/*  507 */       String attributeName = readUTF8(currentAttributeOffset, charBuffer);
/*  508 */       int attributeLength = readInt(currentAttributeOffset + 2);
/*  509 */       currentAttributeOffset += 6;
/*      */ 
/*      */       
/*  512 */       if ("SourceFile".equals(attributeName)) {
/*  513 */         sourceFile = readUTF8(currentAttributeOffset, charBuffer);
/*  514 */       } else if ("InnerClasses".equals(attributeName)) {
/*  515 */         innerClassesOffset = currentAttributeOffset;
/*  516 */       } else if ("EnclosingMethod".equals(attributeName)) {
/*  517 */         enclosingMethodOffset = currentAttributeOffset;
/*  518 */       } else if ("NestHost".equals(attributeName)) {
/*  519 */         nestHostClass = readClass(currentAttributeOffset, charBuffer);
/*  520 */       } else if ("NestMembers".equals(attributeName)) {
/*  521 */         nestMembersOffset = currentAttributeOffset;
/*  522 */       } else if ("PermittedSubclasses".equals(attributeName)) {
/*  523 */         permittedSubclassesOffset = currentAttributeOffset;
/*  524 */       } else if ("Signature".equals(attributeName)) {
/*  525 */         signature = readUTF8(currentAttributeOffset, charBuffer);
/*  526 */       } else if ("RuntimeVisibleAnnotations".equals(attributeName)) {
/*  527 */         runtimeVisibleAnnotationsOffset = currentAttributeOffset;
/*  528 */       } else if ("RuntimeVisibleTypeAnnotations".equals(attributeName)) {
/*  529 */         runtimeVisibleTypeAnnotationsOffset = currentAttributeOffset;
/*  530 */       } else if ("Deprecated".equals(attributeName)) {
/*  531 */         accessFlags |= 0x20000;
/*  532 */       } else if ("Synthetic".equals(attributeName)) {
/*  533 */         accessFlags |= 0x1000;
/*  534 */       } else if ("SourceDebugExtension".equals(attributeName)) {
/*  535 */         if (attributeLength > this.classFileBuffer.length - currentAttributeOffset) {
/*  536 */           throw new IllegalArgumentException();
/*      */         }
/*      */         
/*  539 */         sourceDebugExtension = readUtf(currentAttributeOffset, attributeLength, new char[attributeLength]);
/*  540 */       } else if ("RuntimeInvisibleAnnotations".equals(attributeName)) {
/*  541 */         runtimeInvisibleAnnotationsOffset = currentAttributeOffset;
/*  542 */       } else if ("RuntimeInvisibleTypeAnnotations".equals(attributeName)) {
/*  543 */         runtimeInvisibleTypeAnnotationsOffset = currentAttributeOffset;
/*  544 */       } else if ("Record".equals(attributeName)) {
/*  545 */         recordOffset = currentAttributeOffset;
/*  546 */         accessFlags |= 0x10000;
/*  547 */       } else if ("Module".equals(attributeName)) {
/*  548 */         moduleOffset = currentAttributeOffset;
/*  549 */       } else if ("ModuleMainClass".equals(attributeName)) {
/*  550 */         moduleMainClass = readClass(currentAttributeOffset, charBuffer);
/*  551 */       } else if ("ModulePackages".equals(attributeName)) {
/*  552 */         modulePackagesOffset = currentAttributeOffset;
/*  553 */       } else if (!"BootstrapMethods".equals(attributeName)) {
/*      */ 
/*      */         
/*  556 */         Attribute attribute = readAttribute(attributePrototypes, attributeName, currentAttributeOffset, attributeLength, charBuffer, -1, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  564 */         attribute.nextAttribute = attributes;
/*  565 */         attributes = attribute;
/*      */       } 
/*  567 */       currentAttributeOffset += attributeLength;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  572 */     classVisitor.visit(
/*  573 */         readInt(this.cpInfoOffsets[1] - 7), accessFlags, thisClass, signature, superClass, interfaces);
/*      */ 
/*      */     
/*  576 */     if ((parsingOptions & 0x2) == 0 && (sourceFile != null || sourceDebugExtension != null))
/*      */     {
/*  578 */       classVisitor.visitSource(sourceFile, sourceDebugExtension);
/*      */     }
/*      */ 
/*      */     
/*  582 */     if (moduleOffset != 0) {
/*  583 */       readModuleAttributes(classVisitor, context, moduleOffset, modulePackagesOffset, moduleMainClass);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  588 */     if (nestHostClass != null) {
/*  589 */       classVisitor.visitNestHost(nestHostClass);
/*      */     }
/*      */ 
/*      */     
/*  593 */     if (enclosingMethodOffset != 0) {
/*  594 */       String className = readClass(enclosingMethodOffset, charBuffer);
/*  595 */       int methodIndex = readUnsignedShort(enclosingMethodOffset + 2);
/*  596 */       String name = (methodIndex == 0) ? null : readUTF8(this.cpInfoOffsets[methodIndex], charBuffer);
/*  597 */       String type = (methodIndex == 0) ? null : readUTF8(this.cpInfoOffsets[methodIndex] + 2, charBuffer);
/*  598 */       classVisitor.visitOuterClass(className, name, type);
/*      */     } 
/*      */ 
/*      */     
/*  602 */     if (runtimeVisibleAnnotationsOffset != 0) {
/*  603 */       int numAnnotations = readUnsignedShort(runtimeVisibleAnnotationsOffset);
/*  604 */       int currentAnnotationOffset = runtimeVisibleAnnotationsOffset + 2;
/*  605 */       while (numAnnotations-- > 0) {
/*      */         
/*  607 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/*  608 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/*  611 */         currentAnnotationOffset = readElementValues(classVisitor
/*  612 */             .visitAnnotation(annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  620 */     if (runtimeInvisibleAnnotationsOffset != 0) {
/*  621 */       int numAnnotations = readUnsignedShort(runtimeInvisibleAnnotationsOffset);
/*  622 */       int currentAnnotationOffset = runtimeInvisibleAnnotationsOffset + 2;
/*  623 */       while (numAnnotations-- > 0) {
/*      */         
/*  625 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/*  626 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/*  629 */         currentAnnotationOffset = readElementValues(classVisitor
/*  630 */             .visitAnnotation(annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  638 */     if (runtimeVisibleTypeAnnotationsOffset != 0) {
/*  639 */       int numAnnotations = readUnsignedShort(runtimeVisibleTypeAnnotationsOffset);
/*  640 */       int currentAnnotationOffset = runtimeVisibleTypeAnnotationsOffset + 2;
/*  641 */       while (numAnnotations-- > 0) {
/*      */         
/*  643 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/*  645 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/*  646 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/*  649 */         currentAnnotationOffset = readElementValues(classVisitor
/*  650 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  662 */     if (runtimeInvisibleTypeAnnotationsOffset != 0) {
/*  663 */       int numAnnotations = readUnsignedShort(runtimeInvisibleTypeAnnotationsOffset);
/*  664 */       int currentAnnotationOffset = runtimeInvisibleTypeAnnotationsOffset + 2;
/*  665 */       while (numAnnotations-- > 0) {
/*      */         
/*  667 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/*  669 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/*  670 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/*  673 */         currentAnnotationOffset = readElementValues(classVisitor
/*  674 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  686 */     while (attributes != null) {
/*      */       
/*  688 */       Attribute nextAttribute = attributes.nextAttribute;
/*  689 */       attributes.nextAttribute = null;
/*  690 */       classVisitor.visitAttribute(attributes);
/*  691 */       attributes = nextAttribute;
/*      */     } 
/*      */ 
/*      */     
/*  695 */     if (nestMembersOffset != 0) {
/*  696 */       int numberOfNestMembers = readUnsignedShort(nestMembersOffset);
/*  697 */       int currentNestMemberOffset = nestMembersOffset + 2;
/*  698 */       while (numberOfNestMembers-- > 0) {
/*  699 */         classVisitor.visitNestMember(readClass(currentNestMemberOffset, charBuffer));
/*  700 */         currentNestMemberOffset += 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  705 */     if (permittedSubclassesOffset != 0) {
/*  706 */       int numberOfPermittedSubclasses = readUnsignedShort(permittedSubclassesOffset);
/*  707 */       int currentPermittedSubclassesOffset = permittedSubclassesOffset + 2;
/*  708 */       while (numberOfPermittedSubclasses-- > 0) {
/*  709 */         classVisitor.visitPermittedSubclass(
/*  710 */             readClass(currentPermittedSubclassesOffset, charBuffer));
/*  711 */         currentPermittedSubclassesOffset += 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  716 */     if (innerClassesOffset != 0) {
/*  717 */       int numberOfClasses = readUnsignedShort(innerClassesOffset);
/*  718 */       int currentClassesOffset = innerClassesOffset + 2;
/*  719 */       while (numberOfClasses-- > 0) {
/*  720 */         classVisitor.visitInnerClass(
/*  721 */             readClass(currentClassesOffset, charBuffer), 
/*  722 */             readClass(currentClassesOffset + 2, charBuffer), 
/*  723 */             readUTF8(currentClassesOffset + 4, charBuffer), 
/*  724 */             readUnsignedShort(currentClassesOffset + 6));
/*  725 */         currentClassesOffset += 8;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  730 */     if (recordOffset != 0) {
/*  731 */       int recordComponentsCount = readUnsignedShort(recordOffset);
/*  732 */       recordOffset += 2;
/*  733 */       while (recordComponentsCount-- > 0) {
/*  734 */         recordOffset = readRecordComponent(classVisitor, context, recordOffset);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  739 */     int fieldsCount = readUnsignedShort(currentOffset);
/*  740 */     currentOffset += 2;
/*  741 */     while (fieldsCount-- > 0) {
/*  742 */       currentOffset = readField(classVisitor, context, currentOffset);
/*      */     }
/*  744 */     int methodsCount = readUnsignedShort(currentOffset);
/*  745 */     currentOffset += 2;
/*  746 */     while (methodsCount-- > 0) {
/*  747 */       currentOffset = readMethod(classVisitor, context, currentOffset);
/*      */     }
/*      */ 
/*      */     
/*  751 */     classVisitor.visitEnd();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readModuleAttributes(ClassVisitor classVisitor, Context context, int moduleOffset, int modulePackagesOffset, String moduleMainClass) {
/*  776 */     char[] buffer = context.charBuffer;
/*      */ 
/*      */     
/*  779 */     int currentOffset = moduleOffset;
/*  780 */     String moduleName = readModule(currentOffset, buffer);
/*  781 */     int moduleFlags = readUnsignedShort(currentOffset + 2);
/*  782 */     String moduleVersion = readUTF8(currentOffset + 4, buffer);
/*  783 */     currentOffset += 6;
/*  784 */     ModuleVisitor moduleVisitor = classVisitor.visitModule(moduleName, moduleFlags, moduleVersion);
/*  785 */     if (moduleVisitor == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  790 */     if (moduleMainClass != null) {
/*  791 */       moduleVisitor.visitMainClass(moduleMainClass);
/*      */     }
/*      */ 
/*      */     
/*  795 */     if (modulePackagesOffset != 0) {
/*  796 */       int packageCount = readUnsignedShort(modulePackagesOffset);
/*  797 */       int currentPackageOffset = modulePackagesOffset + 2;
/*  798 */       while (packageCount-- > 0) {
/*  799 */         moduleVisitor.visitPackage(readPackage(currentPackageOffset, buffer));
/*  800 */         currentPackageOffset += 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  805 */     int requiresCount = readUnsignedShort(currentOffset);
/*  806 */     currentOffset += 2;
/*  807 */     while (requiresCount-- > 0) {
/*      */       
/*  809 */       String requires = readModule(currentOffset, buffer);
/*  810 */       int requiresFlags = readUnsignedShort(currentOffset + 2);
/*  811 */       String requiresVersion = readUTF8(currentOffset + 4, buffer);
/*  812 */       currentOffset += 6;
/*  813 */       moduleVisitor.visitRequire(requires, requiresFlags, requiresVersion);
/*      */     } 
/*      */ 
/*      */     
/*  817 */     int exportsCount = readUnsignedShort(currentOffset);
/*  818 */     currentOffset += 2;
/*  819 */     while (exportsCount-- > 0) {
/*      */ 
/*      */       
/*  822 */       String exports = readPackage(currentOffset, buffer);
/*  823 */       int exportsFlags = readUnsignedShort(currentOffset + 2);
/*  824 */       int exportsToCount = readUnsignedShort(currentOffset + 4);
/*  825 */       currentOffset += 6;
/*  826 */       String[] exportsTo = null;
/*  827 */       if (exportsToCount != 0) {
/*  828 */         exportsTo = new String[exportsToCount];
/*  829 */         for (int i = 0; i < exportsToCount; i++) {
/*  830 */           exportsTo[i] = readModule(currentOffset, buffer);
/*  831 */           currentOffset += 2;
/*      */         } 
/*      */       } 
/*  834 */       moduleVisitor.visitExport(exports, exportsFlags, exportsTo);
/*      */     } 
/*      */ 
/*      */     
/*  838 */     int opensCount = readUnsignedShort(currentOffset);
/*  839 */     currentOffset += 2;
/*  840 */     while (opensCount-- > 0) {
/*      */       
/*  842 */       String opens = readPackage(currentOffset, buffer);
/*  843 */       int opensFlags = readUnsignedShort(currentOffset + 2);
/*  844 */       int opensToCount = readUnsignedShort(currentOffset + 4);
/*  845 */       currentOffset += 6;
/*  846 */       String[] opensTo = null;
/*  847 */       if (opensToCount != 0) {
/*  848 */         opensTo = new String[opensToCount];
/*  849 */         for (int i = 0; i < opensToCount; i++) {
/*  850 */           opensTo[i] = readModule(currentOffset, buffer);
/*  851 */           currentOffset += 2;
/*      */         } 
/*      */       } 
/*  854 */       moduleVisitor.visitOpen(opens, opensFlags, opensTo);
/*      */     } 
/*      */ 
/*      */     
/*  858 */     int usesCount = readUnsignedShort(currentOffset);
/*  859 */     currentOffset += 2;
/*  860 */     while (usesCount-- > 0) {
/*  861 */       moduleVisitor.visitUse(readClass(currentOffset, buffer));
/*  862 */       currentOffset += 2;
/*      */     } 
/*      */ 
/*      */     
/*  866 */     int providesCount = readUnsignedShort(currentOffset);
/*  867 */     currentOffset += 2;
/*  868 */     while (providesCount-- > 0) {
/*      */       
/*  870 */       String provides = readClass(currentOffset, buffer);
/*  871 */       int providesWithCount = readUnsignedShort(currentOffset + 2);
/*  872 */       currentOffset += 4;
/*  873 */       String[] providesWith = new String[providesWithCount];
/*  874 */       for (int i = 0; i < providesWithCount; i++) {
/*  875 */         providesWith[i] = readClass(currentOffset, buffer);
/*  876 */         currentOffset += 2;
/*      */       } 
/*  878 */       moduleVisitor.visitProvide(provides, providesWith);
/*      */     } 
/*      */ 
/*      */     
/*  882 */     moduleVisitor.visitEnd();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readRecordComponent(ClassVisitor classVisitor, Context context, int recordComponentOffset) {
/*  895 */     char[] charBuffer = context.charBuffer;
/*      */     
/*  897 */     int currentOffset = recordComponentOffset;
/*  898 */     String name = readUTF8(currentOffset, charBuffer);
/*  899 */     String descriptor = readUTF8(currentOffset + 2, charBuffer);
/*  900 */     currentOffset += 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  907 */     String signature = null;
/*      */     
/*  909 */     int runtimeVisibleAnnotationsOffset = 0;
/*      */     
/*  911 */     int runtimeInvisibleAnnotationsOffset = 0;
/*      */     
/*  913 */     int runtimeVisibleTypeAnnotationsOffset = 0;
/*      */     
/*  915 */     int runtimeInvisibleTypeAnnotationsOffset = 0;
/*      */ 
/*      */     
/*  918 */     Attribute attributes = null;
/*      */     
/*  920 */     int attributesCount = readUnsignedShort(currentOffset);
/*  921 */     currentOffset += 2;
/*  922 */     while (attributesCount-- > 0) {
/*      */       
/*  924 */       String attributeName = readUTF8(currentOffset, charBuffer);
/*  925 */       int attributeLength = readInt(currentOffset + 2);
/*  926 */       currentOffset += 6;
/*      */ 
/*      */       
/*  929 */       if ("Signature".equals(attributeName)) {
/*  930 */         signature = readUTF8(currentOffset, charBuffer);
/*  931 */       } else if ("RuntimeVisibleAnnotations".equals(attributeName)) {
/*  932 */         runtimeVisibleAnnotationsOffset = currentOffset;
/*  933 */       } else if ("RuntimeVisibleTypeAnnotations".equals(attributeName)) {
/*  934 */         runtimeVisibleTypeAnnotationsOffset = currentOffset;
/*  935 */       } else if ("RuntimeInvisibleAnnotations".equals(attributeName)) {
/*  936 */         runtimeInvisibleAnnotationsOffset = currentOffset;
/*  937 */       } else if ("RuntimeInvisibleTypeAnnotations".equals(attributeName)) {
/*  938 */         runtimeInvisibleTypeAnnotationsOffset = currentOffset;
/*      */       } else {
/*      */         
/*  941 */         Attribute attribute = readAttribute(context.attributePrototypes, attributeName, currentOffset, attributeLength, charBuffer, -1, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  949 */         attribute.nextAttribute = attributes;
/*  950 */         attributes = attribute;
/*      */       } 
/*  952 */       currentOffset += attributeLength;
/*      */     } 
/*      */ 
/*      */     
/*  956 */     RecordComponentVisitor recordComponentVisitor = classVisitor.visitRecordComponent(name, descriptor, signature);
/*  957 */     if (recordComponentVisitor == null) {
/*  958 */       return currentOffset;
/*      */     }
/*      */ 
/*      */     
/*  962 */     if (runtimeVisibleAnnotationsOffset != 0) {
/*  963 */       int numAnnotations = readUnsignedShort(runtimeVisibleAnnotationsOffset);
/*  964 */       int currentAnnotationOffset = runtimeVisibleAnnotationsOffset + 2;
/*  965 */       while (numAnnotations-- > 0) {
/*      */         
/*  967 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/*  968 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/*  971 */         currentAnnotationOffset = readElementValues(recordComponentVisitor
/*  972 */             .visitAnnotation(annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  980 */     if (runtimeInvisibleAnnotationsOffset != 0) {
/*  981 */       int numAnnotations = readUnsignedShort(runtimeInvisibleAnnotationsOffset);
/*  982 */       int currentAnnotationOffset = runtimeInvisibleAnnotationsOffset + 2;
/*  983 */       while (numAnnotations-- > 0) {
/*      */         
/*  985 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/*  986 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/*  989 */         currentAnnotationOffset = readElementValues(recordComponentVisitor
/*  990 */             .visitAnnotation(annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     if (runtimeVisibleTypeAnnotationsOffset != 0) {
/*  999 */       int numAnnotations = readUnsignedShort(runtimeVisibleTypeAnnotationsOffset);
/* 1000 */       int currentAnnotationOffset = runtimeVisibleTypeAnnotationsOffset + 2;
/* 1001 */       while (numAnnotations-- > 0) {
/*      */         
/* 1003 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/* 1005 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1006 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1009 */         currentAnnotationOffset = readElementValues(recordComponentVisitor
/* 1010 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1022 */     if (runtimeInvisibleTypeAnnotationsOffset != 0) {
/* 1023 */       int numAnnotations = readUnsignedShort(runtimeInvisibleTypeAnnotationsOffset);
/* 1024 */       int currentAnnotationOffset = runtimeInvisibleTypeAnnotationsOffset + 2;
/* 1025 */       while (numAnnotations-- > 0) {
/*      */         
/* 1027 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/* 1029 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1030 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1033 */         currentAnnotationOffset = readElementValues(recordComponentVisitor
/* 1034 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1046 */     while (attributes != null) {
/*      */       
/* 1048 */       Attribute nextAttribute = attributes.nextAttribute;
/* 1049 */       attributes.nextAttribute = null;
/* 1050 */       recordComponentVisitor.visitAttribute(attributes);
/* 1051 */       attributes = nextAttribute;
/*      */     } 
/*      */ 
/*      */     
/* 1055 */     recordComponentVisitor.visitEnd();
/* 1056 */     return currentOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readField(ClassVisitor classVisitor, Context context, int fieldInfoOffset) {
/* 1069 */     char[] charBuffer = context.charBuffer;
/*      */ 
/*      */     
/* 1072 */     int currentOffset = fieldInfoOffset;
/* 1073 */     int accessFlags = readUnsignedShort(currentOffset);
/* 1074 */     String name = readUTF8(currentOffset + 2, charBuffer);
/* 1075 */     String descriptor = readUTF8(currentOffset + 4, charBuffer);
/* 1076 */     currentOffset += 6;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1081 */     Object constantValue = null;
/*      */     
/* 1083 */     String signature = null;
/*      */     
/* 1085 */     int runtimeVisibleAnnotationsOffset = 0;
/*      */     
/* 1087 */     int runtimeInvisibleAnnotationsOffset = 0;
/*      */     
/* 1089 */     int runtimeVisibleTypeAnnotationsOffset = 0;
/*      */     
/* 1091 */     int runtimeInvisibleTypeAnnotationsOffset = 0;
/*      */ 
/*      */     
/* 1094 */     Attribute attributes = null;
/*      */     
/* 1096 */     int attributesCount = readUnsignedShort(currentOffset);
/* 1097 */     currentOffset += 2;
/* 1098 */     while (attributesCount-- > 0) {
/*      */       
/* 1100 */       String attributeName = readUTF8(currentOffset, charBuffer);
/* 1101 */       int attributeLength = readInt(currentOffset + 2);
/* 1102 */       currentOffset += 6;
/*      */ 
/*      */       
/* 1105 */       if ("ConstantValue".equals(attributeName)) {
/* 1106 */         int constantvalueIndex = readUnsignedShort(currentOffset);
/* 1107 */         constantValue = (constantvalueIndex == 0) ? null : readConst(constantvalueIndex, charBuffer);
/* 1108 */       } else if ("Signature".equals(attributeName)) {
/* 1109 */         signature = readUTF8(currentOffset, charBuffer);
/* 1110 */       } else if ("Deprecated".equals(attributeName)) {
/* 1111 */         accessFlags |= 0x20000;
/* 1112 */       } else if ("Synthetic".equals(attributeName)) {
/* 1113 */         accessFlags |= 0x1000;
/* 1114 */       } else if ("RuntimeVisibleAnnotations".equals(attributeName)) {
/* 1115 */         runtimeVisibleAnnotationsOffset = currentOffset;
/* 1116 */       } else if ("RuntimeVisibleTypeAnnotations".equals(attributeName)) {
/* 1117 */         runtimeVisibleTypeAnnotationsOffset = currentOffset;
/* 1118 */       } else if ("RuntimeInvisibleAnnotations".equals(attributeName)) {
/* 1119 */         runtimeInvisibleAnnotationsOffset = currentOffset;
/* 1120 */       } else if ("RuntimeInvisibleTypeAnnotations".equals(attributeName)) {
/* 1121 */         runtimeInvisibleTypeAnnotationsOffset = currentOffset;
/*      */       } else {
/*      */         
/* 1124 */         Attribute attribute = readAttribute(context.attributePrototypes, attributeName, currentOffset, attributeLength, charBuffer, -1, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1132 */         attribute.nextAttribute = attributes;
/* 1133 */         attributes = attribute;
/*      */       } 
/* 1135 */       currentOffset += attributeLength;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1140 */     FieldVisitor fieldVisitor = classVisitor.visitField(accessFlags, name, descriptor, signature, constantValue);
/* 1141 */     if (fieldVisitor == null) {
/* 1142 */       return currentOffset;
/*      */     }
/*      */ 
/*      */     
/* 1146 */     if (runtimeVisibleAnnotationsOffset != 0) {
/* 1147 */       int numAnnotations = readUnsignedShort(runtimeVisibleAnnotationsOffset);
/* 1148 */       int currentAnnotationOffset = runtimeVisibleAnnotationsOffset + 2;
/* 1149 */       while (numAnnotations-- > 0) {
/*      */         
/* 1151 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1152 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1155 */         currentAnnotationOffset = readElementValues(fieldVisitor
/* 1156 */             .visitAnnotation(annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1164 */     if (runtimeInvisibleAnnotationsOffset != 0) {
/* 1165 */       int numAnnotations = readUnsignedShort(runtimeInvisibleAnnotationsOffset);
/* 1166 */       int currentAnnotationOffset = runtimeInvisibleAnnotationsOffset + 2;
/* 1167 */       while (numAnnotations-- > 0) {
/*      */         
/* 1169 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1170 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1173 */         currentAnnotationOffset = readElementValues(fieldVisitor
/* 1174 */             .visitAnnotation(annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1182 */     if (runtimeVisibleTypeAnnotationsOffset != 0) {
/* 1183 */       int numAnnotations = readUnsignedShort(runtimeVisibleTypeAnnotationsOffset);
/* 1184 */       int currentAnnotationOffset = runtimeVisibleTypeAnnotationsOffset + 2;
/* 1185 */       while (numAnnotations-- > 0) {
/*      */         
/* 1187 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/* 1189 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1190 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1193 */         currentAnnotationOffset = readElementValues(fieldVisitor
/* 1194 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1206 */     if (runtimeInvisibleTypeAnnotationsOffset != 0) {
/* 1207 */       int numAnnotations = readUnsignedShort(runtimeInvisibleTypeAnnotationsOffset);
/* 1208 */       int currentAnnotationOffset = runtimeInvisibleTypeAnnotationsOffset + 2;
/* 1209 */       while (numAnnotations-- > 0) {
/*      */         
/* 1211 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/* 1213 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1214 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1217 */         currentAnnotationOffset = readElementValues(fieldVisitor
/* 1218 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1230 */     while (attributes != null) {
/*      */       
/* 1232 */       Attribute nextAttribute = attributes.nextAttribute;
/* 1233 */       attributes.nextAttribute = null;
/* 1234 */       fieldVisitor.visitAttribute(attributes);
/* 1235 */       attributes = nextAttribute;
/*      */     } 
/*      */ 
/*      */     
/* 1239 */     fieldVisitor.visitEnd();
/* 1240 */     return currentOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readMethod(ClassVisitor classVisitor, Context context, int methodInfoOffset) {
/* 1253 */     char[] charBuffer = context.charBuffer;
/*      */ 
/*      */     
/* 1256 */     int currentOffset = methodInfoOffset;
/* 1257 */     context.currentMethodAccessFlags = readUnsignedShort(currentOffset);
/* 1258 */     context.currentMethodName = readUTF8(currentOffset + 2, charBuffer);
/* 1259 */     context.currentMethodDescriptor = readUTF8(currentOffset + 4, charBuffer);
/* 1260 */     currentOffset += 6;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1265 */     int codeOffset = 0;
/*      */     
/* 1267 */     int exceptionsOffset = 0;
/*      */     
/* 1269 */     String[] exceptions = null;
/*      */     
/* 1271 */     boolean synthetic = false;
/*      */     
/* 1273 */     int signatureIndex = 0;
/*      */     
/* 1275 */     int runtimeVisibleAnnotationsOffset = 0;
/*      */     
/* 1277 */     int runtimeInvisibleAnnotationsOffset = 0;
/*      */     
/* 1279 */     int runtimeVisibleParameterAnnotationsOffset = 0;
/*      */     
/* 1281 */     int runtimeInvisibleParameterAnnotationsOffset = 0;
/*      */     
/* 1283 */     int runtimeVisibleTypeAnnotationsOffset = 0;
/*      */     
/* 1285 */     int runtimeInvisibleTypeAnnotationsOffset = 0;
/*      */     
/* 1287 */     int annotationDefaultOffset = 0;
/*      */     
/* 1289 */     int methodParametersOffset = 0;
/*      */ 
/*      */     
/* 1292 */     Attribute attributes = null;
/*      */     
/* 1294 */     int attributesCount = readUnsignedShort(currentOffset);
/* 1295 */     currentOffset += 2;
/* 1296 */     while (attributesCount-- > 0) {
/*      */       
/* 1298 */       String attributeName = readUTF8(currentOffset, charBuffer);
/* 1299 */       int attributeLength = readInt(currentOffset + 2);
/* 1300 */       currentOffset += 6;
/*      */ 
/*      */       
/* 1303 */       if ("Code".equals(attributeName)) {
/* 1304 */         if ((context.parsingOptions & 0x1) == 0) {
/* 1305 */           codeOffset = currentOffset;
/*      */         }
/* 1307 */       } else if ("Exceptions".equals(attributeName)) {
/* 1308 */         exceptionsOffset = currentOffset;
/* 1309 */         exceptions = new String[readUnsignedShort(exceptionsOffset)];
/* 1310 */         int currentExceptionOffset = exceptionsOffset + 2;
/* 1311 */         for (int i = 0; i < exceptions.length; i++) {
/* 1312 */           exceptions[i] = readClass(currentExceptionOffset, charBuffer);
/* 1313 */           currentExceptionOffset += 2;
/*      */         } 
/* 1315 */       } else if ("Signature".equals(attributeName)) {
/* 1316 */         signatureIndex = readUnsignedShort(currentOffset);
/* 1317 */       } else if ("Deprecated".equals(attributeName)) {
/* 1318 */         context.currentMethodAccessFlags |= 0x20000;
/* 1319 */       } else if ("RuntimeVisibleAnnotations".equals(attributeName)) {
/* 1320 */         runtimeVisibleAnnotationsOffset = currentOffset;
/* 1321 */       } else if ("RuntimeVisibleTypeAnnotations".equals(attributeName)) {
/* 1322 */         runtimeVisibleTypeAnnotationsOffset = currentOffset;
/* 1323 */       } else if ("AnnotationDefault".equals(attributeName)) {
/* 1324 */         annotationDefaultOffset = currentOffset;
/* 1325 */       } else if ("Synthetic".equals(attributeName)) {
/* 1326 */         synthetic = true;
/* 1327 */         context.currentMethodAccessFlags |= 0x1000;
/* 1328 */       } else if ("RuntimeInvisibleAnnotations".equals(attributeName)) {
/* 1329 */         runtimeInvisibleAnnotationsOffset = currentOffset;
/* 1330 */       } else if ("RuntimeInvisibleTypeAnnotations".equals(attributeName)) {
/* 1331 */         runtimeInvisibleTypeAnnotationsOffset = currentOffset;
/* 1332 */       } else if ("RuntimeVisibleParameterAnnotations".equals(attributeName)) {
/* 1333 */         runtimeVisibleParameterAnnotationsOffset = currentOffset;
/* 1334 */       } else if ("RuntimeInvisibleParameterAnnotations".equals(attributeName)) {
/* 1335 */         runtimeInvisibleParameterAnnotationsOffset = currentOffset;
/* 1336 */       } else if ("MethodParameters".equals(attributeName)) {
/* 1337 */         methodParametersOffset = currentOffset;
/*      */       } else {
/*      */         
/* 1340 */         Attribute attribute = readAttribute(context.attributePrototypes, attributeName, currentOffset, attributeLength, charBuffer, -1, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1348 */         attribute.nextAttribute = attributes;
/* 1349 */         attributes = attribute;
/*      */       } 
/* 1351 */       currentOffset += attributeLength;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1356 */     MethodVisitor methodVisitor = classVisitor.visitMethod(context.currentMethodAccessFlags, context.currentMethodName, context.currentMethodDescriptor, 
/*      */ 
/*      */ 
/*      */         
/* 1360 */         (signatureIndex == 0) ? null : readUtf(signatureIndex, charBuffer), exceptions);
/*      */     
/* 1362 */     if (methodVisitor == null) {
/* 1363 */       return currentOffset;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1370 */     if (methodVisitor instanceof MethodWriter) {
/* 1371 */       MethodWriter methodWriter = (MethodWriter)methodVisitor;
/* 1372 */       if (methodWriter.canCopyMethodAttributes(this, synthetic, ((context.currentMethodAccessFlags & 0x20000) != 0), 
/*      */ 
/*      */ 
/*      */           
/* 1376 */           readUnsignedShort(methodInfoOffset + 4), signatureIndex, exceptionsOffset)) {
/*      */ 
/*      */         
/* 1379 */         methodWriter.setMethodAttributesSource(methodInfoOffset, currentOffset - methodInfoOffset);
/* 1380 */         return currentOffset;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1385 */     if (methodParametersOffset != 0 && (context.parsingOptions & 0x2) == 0) {
/* 1386 */       int parametersCount = readByte(methodParametersOffset);
/* 1387 */       int currentParameterOffset = methodParametersOffset + 1;
/* 1388 */       while (parametersCount-- > 0) {
/*      */         
/* 1390 */         methodVisitor.visitParameter(
/* 1391 */             readUTF8(currentParameterOffset, charBuffer), 
/* 1392 */             readUnsignedShort(currentParameterOffset + 2));
/* 1393 */         currentParameterOffset += 4;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1398 */     if (annotationDefaultOffset != 0) {
/* 1399 */       AnnotationVisitor annotationVisitor = methodVisitor.visitAnnotationDefault();
/* 1400 */       readElementValue(annotationVisitor, annotationDefaultOffset, null, charBuffer);
/* 1401 */       if (annotationVisitor != null) {
/* 1402 */         annotationVisitor.visitEnd();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1407 */     if (runtimeVisibleAnnotationsOffset != 0) {
/* 1408 */       int numAnnotations = readUnsignedShort(runtimeVisibleAnnotationsOffset);
/* 1409 */       int currentAnnotationOffset = runtimeVisibleAnnotationsOffset + 2;
/* 1410 */       while (numAnnotations-- > 0) {
/*      */         
/* 1412 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1413 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1416 */         currentAnnotationOffset = readElementValues(methodVisitor
/* 1417 */             .visitAnnotation(annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1425 */     if (runtimeInvisibleAnnotationsOffset != 0) {
/* 1426 */       int numAnnotations = readUnsignedShort(runtimeInvisibleAnnotationsOffset);
/* 1427 */       int currentAnnotationOffset = runtimeInvisibleAnnotationsOffset + 2;
/* 1428 */       while (numAnnotations-- > 0) {
/*      */         
/* 1430 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1431 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1434 */         currentAnnotationOffset = readElementValues(methodVisitor
/* 1435 */             .visitAnnotation(annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1443 */     if (runtimeVisibleTypeAnnotationsOffset != 0) {
/* 1444 */       int numAnnotations = readUnsignedShort(runtimeVisibleTypeAnnotationsOffset);
/* 1445 */       int currentAnnotationOffset = runtimeVisibleTypeAnnotationsOffset + 2;
/* 1446 */       while (numAnnotations-- > 0) {
/*      */         
/* 1448 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/* 1450 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1451 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1454 */         currentAnnotationOffset = readElementValues(methodVisitor
/* 1455 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1467 */     if (runtimeInvisibleTypeAnnotationsOffset != 0) {
/* 1468 */       int numAnnotations = readUnsignedShort(runtimeInvisibleTypeAnnotationsOffset);
/* 1469 */       int currentAnnotationOffset = runtimeInvisibleTypeAnnotationsOffset + 2;
/* 1470 */       while (numAnnotations-- > 0) {
/*      */         
/* 1472 */         currentAnnotationOffset = readTypeAnnotationTarget(context, currentAnnotationOffset);
/*      */         
/* 1474 */         String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 1475 */         currentAnnotationOffset += 2;
/*      */ 
/*      */         
/* 1478 */         currentAnnotationOffset = readElementValues(methodVisitor
/* 1479 */             .visitTypeAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1491 */     if (runtimeVisibleParameterAnnotationsOffset != 0) {
/* 1492 */       readParameterAnnotations(methodVisitor, context, runtimeVisibleParameterAnnotationsOffset, true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1497 */     if (runtimeInvisibleParameterAnnotationsOffset != 0) {
/* 1498 */       readParameterAnnotations(methodVisitor, context, runtimeInvisibleParameterAnnotationsOffset, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1503 */     while (attributes != null) {
/*      */       
/* 1505 */       Attribute nextAttribute = attributes.nextAttribute;
/* 1506 */       attributes.nextAttribute = null;
/* 1507 */       methodVisitor.visitAttribute(attributes);
/* 1508 */       attributes = nextAttribute;
/*      */     } 
/*      */ 
/*      */     
/* 1512 */     if (codeOffset != 0) {
/* 1513 */       methodVisitor.visitCode();
/* 1514 */       readCode(methodVisitor, context, codeOffset);
/*      */     } 
/*      */ 
/*      */     
/* 1518 */     methodVisitor.visitEnd();
/* 1519 */     return currentOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readCode(MethodVisitor methodVisitor, Context context, int codeOffset) {
/* 1536 */     int currentOffset = codeOffset;
/*      */ 
/*      */     
/* 1539 */     byte[] classBuffer = this.classFileBuffer;
/* 1540 */     char[] charBuffer = context.charBuffer;
/* 1541 */     int maxStack = readUnsignedShort(currentOffset);
/* 1542 */     int maxLocals = readUnsignedShort(currentOffset + 2);
/* 1543 */     int codeLength = readInt(currentOffset + 4);
/* 1544 */     currentOffset += 8;
/* 1545 */     if (codeLength > this.classFileBuffer.length - currentOffset) {
/* 1546 */       throw new IllegalArgumentException();
/*      */     }
/*      */ 
/*      */     
/* 1550 */     int bytecodeStartOffset = currentOffset;
/* 1551 */     int bytecodeEndOffset = currentOffset + codeLength;
/* 1552 */     Label[] labels = context.currentMethodLabels = new Label[codeLength + 1];
/* 1553 */     while (currentOffset < bytecodeEndOffset) {
/* 1554 */       int numTableEntries, numSwitchCases, bytecodeOffset = currentOffset - bytecodeStartOffset;
/* 1555 */       int opcode = classBuffer[currentOffset] & 0xFF;
/* 1556 */       switch (opcode) {
/*      */         case 0:
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/*      */         case 9:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 13:
/*      */         case 14:
/*      */         case 15:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 46:
/*      */         case 47:
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 53:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 62:
/*      */         case 63:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 97:
/*      */         case 98:
/*      */         case 99:
/*      */         case 100:
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/*      */         case 113:
/*      */         case 114:
/*      */         case 115:
/*      */         case 116:
/*      */         case 117:
/*      */         case 118:
/*      */         case 119:
/*      */         case 120:
/*      */         case 121:
/*      */         case 122:
/*      */         case 123:
/*      */         case 124:
/*      */         case 125:
/*      */         case 126:
/*      */         case 127:
/*      */         case 128:
/*      */         case 129:
/*      */         case 130:
/*      */         case 131:
/*      */         case 133:
/*      */         case 134:
/*      */         case 135:
/*      */         case 136:
/*      */         case 137:
/*      */         case 138:
/*      */         case 139:
/*      */         case 140:
/*      */         case 141:
/*      */         case 142:
/*      */         case 143:
/*      */         case 144:
/*      */         case 145:
/*      */         case 146:
/*      */         case 147:
/*      */         case 148:
/*      */         case 149:
/*      */         case 150:
/*      */         case 151:
/*      */         case 152:
/*      */         case 172:
/*      */         case 173:
/*      */         case 174:
/*      */         case 175:
/*      */         case 176:
/*      */         case 177:
/*      */         case 190:
/*      */         case 191:
/*      */         case 194:
/*      */         case 195:
/* 1704 */           currentOffset++;
/*      */           continue;
/*      */         case 153:
/*      */         case 154:
/*      */         case 155:
/*      */         case 156:
/*      */         case 157:
/*      */         case 158:
/*      */         case 159:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/*      */         case 163:
/*      */         case 164:
/*      */         case 165:
/*      */         case 166:
/*      */         case 167:
/*      */         case 168:
/*      */         case 198:
/*      */         case 199:
/* 1724 */           createLabel(bytecodeOffset + readShort(currentOffset + 1), labels);
/* 1725 */           currentOffset += 3;
/*      */           continue;
/*      */         case 202:
/*      */         case 203:
/*      */         case 204:
/*      */         case 205:
/*      */         case 206:
/*      */         case 207:
/*      */         case 208:
/*      */         case 209:
/*      */         case 210:
/*      */         case 211:
/*      */         case 212:
/*      */         case 213:
/*      */         case 214:
/*      */         case 215:
/*      */         case 216:
/*      */         case 217:
/*      */         case 218:
/*      */         case 219:
/* 1745 */           createLabel(bytecodeOffset + readUnsignedShort(currentOffset + 1), labels);
/* 1746 */           currentOffset += 3;
/*      */           continue;
/*      */         case 200:
/*      */         case 201:
/*      */         case 220:
/* 1751 */           createLabel(bytecodeOffset + readInt(currentOffset + 1), labels);
/* 1752 */           currentOffset += 5;
/*      */           continue;
/*      */         case 196:
/* 1755 */           switch (classBuffer[currentOffset + 1] & 0xFF) {
/*      */             case 21:
/*      */             case 22:
/*      */             case 23:
/*      */             case 24:
/*      */             case 25:
/*      */             case 54:
/*      */             case 55:
/*      */             case 56:
/*      */             case 57:
/*      */             case 58:
/*      */             case 169:
/* 1767 */               currentOffset += 4;
/*      */               continue;
/*      */             case 132:
/* 1770 */               currentOffset += 6;
/*      */               continue;
/*      */           } 
/* 1773 */           throw new IllegalArgumentException();
/*      */ 
/*      */ 
/*      */         
/*      */         case 170:
/* 1778 */           currentOffset += 4 - (bytecodeOffset & 0x3);
/*      */           
/* 1780 */           createLabel(bytecodeOffset + readInt(currentOffset), labels);
/* 1781 */           numTableEntries = readInt(currentOffset + 8) - readInt(currentOffset + 4) + 1;
/* 1782 */           currentOffset += 12;
/*      */           
/* 1784 */           while (numTableEntries-- > 0) {
/* 1785 */             createLabel(bytecodeOffset + readInt(currentOffset), labels);
/* 1786 */             currentOffset += 4;
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 171:
/* 1791 */           currentOffset += 4 - (bytecodeOffset & 0x3);
/*      */           
/* 1793 */           createLabel(bytecodeOffset + readInt(currentOffset), labels);
/* 1794 */           numSwitchCases = readInt(currentOffset + 4);
/* 1795 */           currentOffset += 8;
/*      */           
/* 1797 */           while (numSwitchCases-- > 0) {
/* 1798 */             createLabel(bytecodeOffset + readInt(currentOffset + 4), labels);
/* 1799 */             currentOffset += 8;
/*      */           } 
/*      */           continue;
/*      */         case 16:
/*      */         case 18:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 169:
/*      */         case 188:
/* 1816 */           currentOffset += 2;
/*      */           continue;
/*      */         case 17:
/*      */         case 19:
/*      */         case 20:
/*      */         case 132:
/*      */         case 178:
/*      */         case 179:
/*      */         case 180:
/*      */         case 181:
/*      */         case 182:
/*      */         case 183:
/*      */         case 184:
/*      */         case 187:
/*      */         case 189:
/*      */         case 192:
/*      */         case 193:
/* 1833 */           currentOffset += 3;
/*      */           continue;
/*      */         case 185:
/*      */         case 186:
/* 1837 */           currentOffset += 5;
/*      */           continue;
/*      */         case 197:
/* 1840 */           currentOffset += 4;
/*      */           continue;
/*      */       } 
/* 1843 */       throw new IllegalArgumentException();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1849 */     int exceptionTableLength = readUnsignedShort(currentOffset);
/* 1850 */     currentOffset += 2;
/* 1851 */     while (exceptionTableLength-- > 0) {
/* 1852 */       Label start = createLabel(readUnsignedShort(currentOffset), labels);
/* 1853 */       Label end = createLabel(readUnsignedShort(currentOffset + 2), labels);
/* 1854 */       Label handler = createLabel(readUnsignedShort(currentOffset + 4), labels);
/* 1855 */       String catchType = readUTF8(this.cpInfoOffsets[readUnsignedShort(currentOffset + 6)], charBuffer);
/* 1856 */       currentOffset += 8;
/* 1857 */       methodVisitor.visitTryCatchBlock(start, end, handler, catchType);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1866 */     int stackMapFrameOffset = 0;
/*      */     
/* 1868 */     int stackMapTableEndOffset = 0;
/*      */     
/* 1870 */     boolean compressedFrames = true;
/*      */     
/* 1872 */     int localVariableTableOffset = 0;
/*      */     
/* 1874 */     int localVariableTypeTableOffset = 0;
/*      */ 
/*      */     
/* 1877 */     int[] visibleTypeAnnotationOffsets = null;
/*      */ 
/*      */     
/* 1880 */     int[] invisibleTypeAnnotationOffsets = null;
/*      */ 
/*      */     
/* 1883 */     Attribute attributes = null;
/*      */     
/* 1885 */     int attributesCount = readUnsignedShort(currentOffset);
/* 1886 */     currentOffset += 2;
/* 1887 */     while (attributesCount-- > 0) {
/*      */       
/* 1889 */       String attributeName = readUTF8(currentOffset, charBuffer);
/* 1890 */       int attributeLength = readInt(currentOffset + 2);
/* 1891 */       currentOffset += 6;
/* 1892 */       if ("LocalVariableTable".equals(attributeName)) {
/* 1893 */         if ((context.parsingOptions & 0x2) == 0) {
/* 1894 */           localVariableTableOffset = currentOffset;
/*      */           
/* 1896 */           int currentLocalVariableTableOffset = currentOffset;
/* 1897 */           int localVariableTableLength = readUnsignedShort(currentLocalVariableTableOffset);
/* 1898 */           currentLocalVariableTableOffset += 2;
/* 1899 */           while (localVariableTableLength-- > 0) {
/* 1900 */             int startPc = readUnsignedShort(currentLocalVariableTableOffset);
/* 1901 */             createDebugLabel(startPc, labels);
/* 1902 */             int length = readUnsignedShort(currentLocalVariableTableOffset + 2);
/* 1903 */             createDebugLabel(startPc + length, labels);
/*      */             
/* 1905 */             currentLocalVariableTableOffset += 10;
/*      */           } 
/*      */         } 
/* 1908 */       } else if ("LocalVariableTypeTable".equals(attributeName)) {
/* 1909 */         localVariableTypeTableOffset = currentOffset;
/*      */       
/*      */       }
/* 1912 */       else if ("LineNumberTable".equals(attributeName)) {
/* 1913 */         if ((context.parsingOptions & 0x2) == 0) {
/*      */           
/* 1915 */           int currentLineNumberTableOffset = currentOffset;
/* 1916 */           int lineNumberTableLength = readUnsignedShort(currentLineNumberTableOffset);
/* 1917 */           currentLineNumberTableOffset += 2;
/* 1918 */           while (lineNumberTableLength-- > 0) {
/* 1919 */             int startPc = readUnsignedShort(currentLineNumberTableOffset);
/* 1920 */             int lineNumber = readUnsignedShort(currentLineNumberTableOffset + 2);
/* 1921 */             currentLineNumberTableOffset += 4;
/* 1922 */             createDebugLabel(startPc, labels);
/* 1923 */             labels[startPc].addLineNumber(lineNumber);
/*      */           } 
/*      */         } 
/* 1926 */       } else if ("RuntimeVisibleTypeAnnotations".equals(attributeName)) {
/*      */         
/* 1928 */         visibleTypeAnnotationOffsets = readTypeAnnotations(methodVisitor, context, currentOffset, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1935 */       else if ("RuntimeInvisibleTypeAnnotations".equals(attributeName)) {
/*      */         
/* 1937 */         invisibleTypeAnnotationOffsets = readTypeAnnotations(methodVisitor, context, currentOffset, false);
/*      */       }
/* 1939 */       else if ("StackMapTable".equals(attributeName)) {
/* 1940 */         if ((context.parsingOptions & 0x4) == 0) {
/* 1941 */           stackMapFrameOffset = currentOffset + 2;
/* 1942 */           stackMapTableEndOffset = currentOffset + attributeLength;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1953 */       else if ("StackMap".equals(attributeName)) {
/* 1954 */         if ((context.parsingOptions & 0x4) == 0) {
/* 1955 */           stackMapFrameOffset = currentOffset + 2;
/* 1956 */           stackMapTableEndOffset = currentOffset + attributeLength;
/* 1957 */           compressedFrames = false;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1965 */         Attribute attribute = readAttribute(context.attributePrototypes, attributeName, currentOffset, attributeLength, charBuffer, codeOffset, labels);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1973 */         attribute.nextAttribute = attributes;
/* 1974 */         attributes = attribute;
/*      */       } 
/* 1976 */       currentOffset += attributeLength;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1981 */     boolean expandFrames = ((context.parsingOptions & 0x8) != 0);
/* 1982 */     if (stackMapFrameOffset != 0) {
/*      */ 
/*      */ 
/*      */       
/* 1986 */       context.currentFrameOffset = -1;
/* 1987 */       context.currentFrameType = 0;
/* 1988 */       context.currentFrameLocalCount = 0;
/* 1989 */       context.currentFrameLocalCountDelta = 0;
/* 1990 */       context.currentFrameLocalTypes = new Object[maxLocals];
/* 1991 */       context.currentFrameStackCount = 0;
/* 1992 */       context.currentFrameStackTypes = new Object[maxStack];
/* 1993 */       if (expandFrames) {
/* 1994 */         computeImplicitFrame(context);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2003 */       for (int offset = stackMapFrameOffset; offset < stackMapTableEndOffset - 2; offset++) {
/* 2004 */         if (classBuffer[offset] == 8) {
/* 2005 */           int potentialBytecodeOffset = readUnsignedShort(offset + 1);
/* 2006 */           if (potentialBytecodeOffset >= 0 && potentialBytecodeOffset < codeLength && (classBuffer[bytecodeStartOffset + potentialBytecodeOffset] & 0xFF) == 187)
/*      */           {
/*      */ 
/*      */             
/* 2010 */             createLabel(potentialBytecodeOffset, labels);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2015 */     if (expandFrames && (context.parsingOptions & 0x100) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2022 */       methodVisitor.visitFrame(-1, maxLocals, null, 0, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2030 */     int currentVisibleTypeAnnotationIndex = 0;
/*      */ 
/*      */     
/* 2033 */     int currentVisibleTypeAnnotationBytecodeOffset = getTypeAnnotationBytecodeOffset(visibleTypeAnnotationOffsets, 0);
/*      */ 
/*      */     
/* 2036 */     int currentInvisibleTypeAnnotationIndex = 0;
/*      */ 
/*      */     
/* 2039 */     int currentInvisibleTypeAnnotationBytecodeOffset = getTypeAnnotationBytecodeOffset(invisibleTypeAnnotationOffsets, 0);
/*      */ 
/*      */     
/* 2042 */     boolean insertFrame = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2048 */     int wideJumpOpcodeDelta = ((context.parsingOptions & 0x100) == 0) ? 33 : 0;
/*      */     
/* 2050 */     currentOffset = bytecodeStartOffset;
/* 2051 */     while (currentOffset < bytecodeEndOffset) {
/* 2052 */       Label target, defaultLabel; int cpInfoOffset, low, numPairs, nameAndTypeCpInfoOffset, high, keys[]; String owner, name; Label[] table, values; String str1, descriptor; int i; String str2; int bootstrapMethodOffset; Handle handle; Object[] bootstrapMethodArguments; int j, currentBytecodeOffset = currentOffset - bytecodeStartOffset;
/* 2053 */       readBytecodeInstructionOffset(currentBytecodeOffset);
/*      */ 
/*      */       
/* 2056 */       Label currentLabel = labels[currentBytecodeOffset];
/* 2057 */       if (currentLabel != null) {
/* 2058 */         currentLabel.accept(methodVisitor, ((context.parsingOptions & 0x2) == 0));
/*      */       }
/*      */ 
/*      */       
/* 2062 */       while (stackMapFrameOffset != 0 && (context.currentFrameOffset == currentBytecodeOffset || context.currentFrameOffset == -1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2067 */         if (context.currentFrameOffset != -1) {
/* 2068 */           if (!compressedFrames || expandFrames) {
/* 2069 */             methodVisitor.visitFrame(-1, context.currentFrameLocalCount, context.currentFrameLocalTypes, context.currentFrameStackCount, context.currentFrameStackTypes);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 2076 */             methodVisitor.visitFrame(context.currentFrameType, context.currentFrameLocalCountDelta, context.currentFrameLocalTypes, context.currentFrameStackCount, context.currentFrameStackTypes);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2085 */           insertFrame = false;
/*      */         } 
/* 2087 */         if (stackMapFrameOffset < stackMapTableEndOffset) {
/*      */           
/* 2089 */           stackMapFrameOffset = readStackMapFrame(stackMapFrameOffset, compressedFrames, expandFrames, context); continue;
/*      */         } 
/* 2091 */         stackMapFrameOffset = 0;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2097 */       if (insertFrame) {
/* 2098 */         if ((context.parsingOptions & 0x8) != 0) {
/* 2099 */           methodVisitor.visitFrame(256, 0, null, 0, null);
/*      */         }
/* 2101 */         insertFrame = false;
/*      */       } 
/*      */ 
/*      */       
/* 2105 */       int opcode = classBuffer[currentOffset] & 0xFF;
/* 2106 */       switch (opcode) {
/*      */         case 0:
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/*      */         case 9:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 13:
/*      */         case 14:
/*      */         case 15:
/*      */         case 46:
/*      */         case 47:
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 53:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 97:
/*      */         case 98:
/*      */         case 99:
/*      */         case 100:
/*      */         case 101:
/*      */         case 102:
/*      */         case 103:
/*      */         case 104:
/*      */         case 105:
/*      */         case 106:
/*      */         case 107:
/*      */         case 108:
/*      */         case 109:
/*      */         case 110:
/*      */         case 111:
/*      */         case 112:
/*      */         case 113:
/*      */         case 114:
/*      */         case 115:
/*      */         case 116:
/*      */         case 117:
/*      */         case 118:
/*      */         case 119:
/*      */         case 120:
/*      */         case 121:
/*      */         case 122:
/*      */         case 123:
/*      */         case 124:
/*      */         case 125:
/*      */         case 126:
/*      */         case 127:
/*      */         case 128:
/*      */         case 129:
/*      */         case 130:
/*      */         case 131:
/*      */         case 133:
/*      */         case 134:
/*      */         case 135:
/*      */         case 136:
/*      */         case 137:
/*      */         case 138:
/*      */         case 139:
/*      */         case 140:
/*      */         case 141:
/*      */         case 142:
/*      */         case 143:
/*      */         case 144:
/*      */         case 145:
/*      */         case 146:
/*      */         case 147:
/*      */         case 148:
/*      */         case 149:
/*      */         case 150:
/*      */         case 151:
/*      */         case 152:
/*      */         case 172:
/*      */         case 173:
/*      */         case 174:
/*      */         case 175:
/*      */         case 176:
/*      */         case 177:
/*      */         case 190:
/*      */         case 191:
/*      */         case 194:
/*      */         case 195:
/* 2214 */           methodVisitor.visitInsn(opcode);
/* 2215 */           currentOffset++;
/*      */           break;
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/* 2237 */           opcode -= 26;
/* 2238 */           methodVisitor.visitVarInsn(21 + (opcode >> 2), opcode & 0x3);
/* 2239 */           currentOffset++;
/*      */           break;
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 62:
/*      */         case 63:
/*      */         case 64:
/*      */         case 65:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/* 2261 */           opcode -= 59;
/* 2262 */           methodVisitor.visitVarInsn(54 + (opcode >> 2), opcode & 0x3);
/* 2263 */           currentOffset++;
/*      */           break;
/*      */         case 153:
/*      */         case 154:
/*      */         case 155:
/*      */         case 156:
/*      */         case 157:
/*      */         case 158:
/*      */         case 159:
/*      */         case 160:
/*      */         case 161:
/*      */         case 162:
/*      */         case 163:
/*      */         case 164:
/*      */         case 165:
/*      */         case 166:
/*      */         case 167:
/*      */         case 168:
/*      */         case 198:
/*      */         case 199:
/* 2283 */           methodVisitor.visitJumpInsn(opcode, labels[currentBytecodeOffset + 
/* 2284 */                 readShort(currentOffset + 1)]);
/* 2285 */           currentOffset += 3;
/*      */           break;
/*      */         case 200:
/*      */         case 201:
/* 2289 */           methodVisitor.visitJumpInsn(opcode - wideJumpOpcodeDelta, labels[currentBytecodeOffset + 
/*      */                 
/* 2291 */                 readInt(currentOffset + 1)]);
/* 2292 */           currentOffset += 5;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 202:
/*      */         case 203:
/*      */         case 204:
/*      */         case 205:
/*      */         case 206:
/*      */         case 207:
/*      */         case 208:
/*      */         case 209:
/*      */         case 210:
/*      */         case 211:
/*      */         case 212:
/*      */         case 213:
/*      */         case 214:
/*      */         case 215:
/*      */         case 216:
/*      */         case 217:
/*      */         case 218:
/*      */         case 219:
/* 2322 */           opcode = (opcode < 218) ? (opcode - 49) : (opcode - 20);
/* 2323 */           target = labels[currentBytecodeOffset + readUnsignedShort(currentOffset + 1)];
/* 2324 */           if (opcode == 167 || opcode == 168) {
/*      */             
/* 2326 */             methodVisitor.visitJumpInsn(opcode + 33, target);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 2331 */             opcode = (opcode < 167) ? ((opcode + 1 ^ 0x1) - 1) : (opcode ^ 0x1);
/* 2332 */             Label endif = createLabel(currentBytecodeOffset + 3, labels);
/* 2333 */             methodVisitor.visitJumpInsn(opcode, endif);
/* 2334 */             methodVisitor.visitJumpInsn(200, target);
/*      */ 
/*      */             
/* 2337 */             insertFrame = true;
/*      */           } 
/* 2339 */           currentOffset += 3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 220:
/* 2344 */           methodVisitor.visitJumpInsn(200, labels[currentBytecodeOffset + 
/* 2345 */                 readInt(currentOffset + 1)]);
/*      */ 
/*      */ 
/*      */           
/* 2349 */           insertFrame = true;
/* 2350 */           currentOffset += 5;
/*      */           break;
/*      */         case 196:
/* 2353 */           opcode = classBuffer[currentOffset + 1] & 0xFF;
/* 2354 */           if (opcode == 132) {
/* 2355 */             methodVisitor.visitIincInsn(
/* 2356 */                 readUnsignedShort(currentOffset + 2), readShort(currentOffset + 4));
/* 2357 */             currentOffset += 6; break;
/*      */           } 
/* 2359 */           methodVisitor.visitVarInsn(opcode, readUnsignedShort(currentOffset + 2));
/* 2360 */           currentOffset += 4;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 170:
/* 2366 */           currentOffset += 4 - (currentBytecodeOffset & 0x3);
/*      */           
/* 2368 */           defaultLabel = labels[currentBytecodeOffset + readInt(currentOffset)];
/* 2369 */           low = readInt(currentOffset + 4);
/* 2370 */           high = readInt(currentOffset + 8);
/* 2371 */           currentOffset += 12;
/* 2372 */           table = new Label[high - low + 1];
/* 2373 */           for (i = 0; i < table.length; i++) {
/* 2374 */             table[i] = labels[currentBytecodeOffset + readInt(currentOffset)];
/* 2375 */             currentOffset += 4;
/*      */           } 
/* 2377 */           methodVisitor.visitTableSwitchInsn(low, high, defaultLabel, table);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 171:
/* 2383 */           currentOffset += 4 - (currentBytecodeOffset & 0x3);
/*      */           
/* 2385 */           defaultLabel = labels[currentBytecodeOffset + readInt(currentOffset)];
/* 2386 */           numPairs = readInt(currentOffset + 4);
/* 2387 */           currentOffset += 8;
/* 2388 */           keys = new int[numPairs];
/* 2389 */           values = new Label[numPairs];
/* 2390 */           for (i = 0; i < numPairs; i++) {
/* 2391 */             keys[i] = readInt(currentOffset);
/* 2392 */             values[i] = labels[currentBytecodeOffset + readInt(currentOffset + 4)];
/* 2393 */             currentOffset += 8;
/*      */           } 
/* 2395 */           methodVisitor.visitLookupSwitchInsn(defaultLabel, keys, values);
/*      */           break;
/*      */         
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 169:
/* 2409 */           methodVisitor.visitVarInsn(opcode, classBuffer[currentOffset + 1] & 0xFF);
/* 2410 */           currentOffset += 2;
/*      */           break;
/*      */         case 16:
/*      */         case 188:
/* 2414 */           methodVisitor.visitIntInsn(opcode, classBuffer[currentOffset + 1]);
/* 2415 */           currentOffset += 2;
/*      */           break;
/*      */         case 17:
/* 2418 */           methodVisitor.visitIntInsn(opcode, readShort(currentOffset + 1));
/* 2419 */           currentOffset += 3;
/*      */           break;
/*      */         case 18:
/* 2422 */           methodVisitor.visitLdcInsn(readConst(classBuffer[currentOffset + 1] & 0xFF, charBuffer));
/* 2423 */           currentOffset += 2;
/*      */           break;
/*      */         case 19:
/*      */         case 20:
/* 2427 */           methodVisitor.visitLdcInsn(readConst(readUnsignedShort(currentOffset + 1), charBuffer));
/* 2428 */           currentOffset += 3;
/*      */           break;
/*      */         
/*      */         case 178:
/*      */         case 179:
/*      */         case 180:
/*      */         case 181:
/*      */         case 182:
/*      */         case 183:
/*      */         case 184:
/*      */         case 185:
/* 2439 */           cpInfoOffset = this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)];
/* 2440 */           nameAndTypeCpInfoOffset = this.cpInfoOffsets[readUnsignedShort(cpInfoOffset + 2)];
/* 2441 */           owner = readClass(cpInfoOffset, charBuffer);
/* 2442 */           str1 = readUTF8(nameAndTypeCpInfoOffset, charBuffer);
/* 2443 */           str2 = readUTF8(nameAndTypeCpInfoOffset + 2, charBuffer);
/* 2444 */           if (opcode < 182) {
/* 2445 */             methodVisitor.visitFieldInsn(opcode, owner, str1, str2);
/*      */           } else {
/* 2447 */             boolean isInterface = (classBuffer[cpInfoOffset - 1] == 11);
/*      */             
/* 2449 */             methodVisitor.visitMethodInsn(opcode, owner, str1, str2, isInterface);
/*      */           } 
/* 2451 */           if (opcode == 185) {
/* 2452 */             currentOffset += 5; break;
/*      */           } 
/* 2454 */           currentOffset += 3;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 186:
/* 2460 */           cpInfoOffset = this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)];
/* 2461 */           nameAndTypeCpInfoOffset = this.cpInfoOffsets[readUnsignedShort(cpInfoOffset + 2)];
/* 2462 */           name = readUTF8(nameAndTypeCpInfoOffset, charBuffer);
/* 2463 */           descriptor = readUTF8(nameAndTypeCpInfoOffset + 2, charBuffer);
/* 2464 */           bootstrapMethodOffset = this.bootstrapMethodOffsets[readUnsignedShort(cpInfoOffset)];
/*      */           
/* 2466 */           handle = (Handle)readConst(readUnsignedShort(bootstrapMethodOffset), charBuffer);
/*      */           
/* 2468 */           bootstrapMethodArguments = new Object[readUnsignedShort(bootstrapMethodOffset + 2)];
/* 2469 */           bootstrapMethodOffset += 4;
/* 2470 */           for (j = 0; j < bootstrapMethodArguments.length; j++) {
/* 2471 */             bootstrapMethodArguments[j] = 
/* 2472 */               readConst(readUnsignedShort(bootstrapMethodOffset), charBuffer);
/* 2473 */             bootstrapMethodOffset += 2;
/*      */           } 
/* 2475 */           methodVisitor.visitInvokeDynamicInsn(name, descriptor, handle, bootstrapMethodArguments);
/*      */           
/* 2477 */           currentOffset += 5;
/*      */           break;
/*      */         
/*      */         case 187:
/*      */         case 189:
/*      */         case 192:
/*      */         case 193:
/* 2484 */           methodVisitor.visitTypeInsn(opcode, readClass(currentOffset + 1, charBuffer));
/* 2485 */           currentOffset += 3;
/*      */           break;
/*      */         case 132:
/* 2488 */           methodVisitor.visitIincInsn(classBuffer[currentOffset + 1] & 0xFF, classBuffer[currentOffset + 2]);
/*      */           
/* 2490 */           currentOffset += 3;
/*      */           break;
/*      */         case 197:
/* 2493 */           methodVisitor.visitMultiANewArrayInsn(
/* 2494 */               readClass(currentOffset + 1, charBuffer), classBuffer[currentOffset + 3] & 0xFF);
/* 2495 */           currentOffset += 4;
/*      */           break;
/*      */         default:
/* 2498 */           throw new AssertionError();
/*      */       } 
/*      */ 
/*      */       
/* 2502 */       while (visibleTypeAnnotationOffsets != null && currentVisibleTypeAnnotationIndex < visibleTypeAnnotationOffsets.length && currentVisibleTypeAnnotationBytecodeOffset <= currentBytecodeOffset) {
/*      */ 
/*      */         
/* 2505 */         if (currentVisibleTypeAnnotationBytecodeOffset == currentBytecodeOffset) {
/*      */ 
/*      */           
/* 2508 */           int currentAnnotationOffset = readTypeAnnotationTarget(context, visibleTypeAnnotationOffsets[currentVisibleTypeAnnotationIndex]);
/*      */ 
/*      */           
/* 2511 */           String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 2512 */           currentAnnotationOffset += 2;
/*      */           
/* 2514 */           readElementValues(methodVisitor
/* 2515 */               .visitInsnAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, true), currentAnnotationOffset, true, charBuffer);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2525 */         currentVisibleTypeAnnotationBytecodeOffset = getTypeAnnotationBytecodeOffset(visibleTypeAnnotationOffsets, ++currentVisibleTypeAnnotationIndex);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2530 */       while (invisibleTypeAnnotationOffsets != null && currentInvisibleTypeAnnotationIndex < invisibleTypeAnnotationOffsets.length && currentInvisibleTypeAnnotationBytecodeOffset <= currentBytecodeOffset) {
/*      */ 
/*      */         
/* 2533 */         if (currentInvisibleTypeAnnotationBytecodeOffset == currentBytecodeOffset) {
/*      */ 
/*      */           
/* 2536 */           int currentAnnotationOffset = readTypeAnnotationTarget(context, invisibleTypeAnnotationOffsets[currentInvisibleTypeAnnotationIndex]);
/*      */ 
/*      */           
/* 2539 */           String annotationDescriptor = readUTF8(currentAnnotationOffset, charBuffer);
/* 2540 */           currentAnnotationOffset += 2;
/*      */           
/* 2542 */           readElementValues(methodVisitor
/* 2543 */               .visitInsnAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, annotationDescriptor, false), currentAnnotationOffset, true, charBuffer);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2553 */         currentInvisibleTypeAnnotationBytecodeOffset = getTypeAnnotationBytecodeOffset(invisibleTypeAnnotationOffsets, ++currentInvisibleTypeAnnotationIndex);
/*      */       } 
/*      */     } 
/*      */     
/* 2557 */     if (labels[codeLength] != null) {
/* 2558 */       methodVisitor.visitLabel(labels[codeLength]);
/*      */     }
/*      */ 
/*      */     
/* 2562 */     if (localVariableTableOffset != 0 && (context.parsingOptions & 0x2) == 0) {
/*      */       
/* 2564 */       int[] typeTable = null;
/* 2565 */       if (localVariableTypeTableOffset != 0) {
/* 2566 */         typeTable = new int[readUnsignedShort(localVariableTypeTableOffset) * 3];
/* 2567 */         currentOffset = localVariableTypeTableOffset + 2;
/* 2568 */         int typeTableIndex = typeTable.length;
/* 2569 */         while (typeTableIndex > 0) {
/*      */           
/* 2571 */           typeTable[--typeTableIndex] = currentOffset + 6;
/* 2572 */           typeTable[--typeTableIndex] = readUnsignedShort(currentOffset + 8);
/* 2573 */           typeTable[--typeTableIndex] = readUnsignedShort(currentOffset);
/* 2574 */           currentOffset += 10;
/*      */         } 
/*      */       } 
/* 2577 */       int localVariableTableLength = readUnsignedShort(localVariableTableOffset);
/* 2578 */       currentOffset = localVariableTableOffset + 2;
/* 2579 */       while (localVariableTableLength-- > 0) {
/* 2580 */         int startPc = readUnsignedShort(currentOffset);
/* 2581 */         int length = readUnsignedShort(currentOffset + 2);
/* 2582 */         String name = readUTF8(currentOffset + 4, charBuffer);
/* 2583 */         String descriptor = readUTF8(currentOffset + 6, charBuffer);
/* 2584 */         int index = readUnsignedShort(currentOffset + 8);
/* 2585 */         currentOffset += 10;
/* 2586 */         String signature = null;
/* 2587 */         if (typeTable != null) {
/* 2588 */           for (int i = 0; i < typeTable.length; i += 3) {
/* 2589 */             if (typeTable[i] == startPc && typeTable[i + 1] == index) {
/* 2590 */               signature = readUTF8(typeTable[i + 2], charBuffer);
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/* 2595 */         methodVisitor.visitLocalVariable(name, descriptor, signature, labels[startPc], labels[startPc + length], index);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2601 */     if (visibleTypeAnnotationOffsets != null) {
/* 2602 */       for (int typeAnnotationOffset : visibleTypeAnnotationOffsets) {
/* 2603 */         int targetType = readByte(typeAnnotationOffset);
/* 2604 */         if (targetType == 64 || targetType == 65) {
/*      */ 
/*      */           
/* 2607 */           currentOffset = readTypeAnnotationTarget(context, typeAnnotationOffset);
/*      */           
/* 2609 */           String annotationDescriptor = readUTF8(currentOffset, charBuffer);
/* 2610 */           currentOffset += 2;
/*      */           
/* 2612 */           readElementValues(methodVisitor
/* 2613 */               .visitLocalVariableAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, context.currentLocalVariableAnnotationRangeStarts, context.currentLocalVariableAnnotationRangeEnds, context.currentLocalVariableAnnotationRangeIndices, annotationDescriptor, true), currentOffset, true, charBuffer);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2629 */     if (invisibleTypeAnnotationOffsets != null) {
/* 2630 */       for (int typeAnnotationOffset : invisibleTypeAnnotationOffsets) {
/* 2631 */         int targetType = readByte(typeAnnotationOffset);
/* 2632 */         if (targetType == 64 || targetType == 65) {
/*      */ 
/*      */           
/* 2635 */           currentOffset = readTypeAnnotationTarget(context, typeAnnotationOffset);
/*      */           
/* 2637 */           String annotationDescriptor = readUTF8(currentOffset, charBuffer);
/* 2638 */           currentOffset += 2;
/*      */           
/* 2640 */           readElementValues(methodVisitor
/* 2641 */               .visitLocalVariableAnnotation(context.currentTypeAnnotationTarget, context.currentTypeAnnotationTargetPath, context.currentLocalVariableAnnotationRangeStarts, context.currentLocalVariableAnnotationRangeEnds, context.currentLocalVariableAnnotationRangeIndices, annotationDescriptor, false), currentOffset, true, charBuffer);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2657 */     while (attributes != null) {
/*      */       
/* 2659 */       Attribute nextAttribute = attributes.nextAttribute;
/* 2660 */       attributes.nextAttribute = null;
/* 2661 */       methodVisitor.visitAttribute(attributes);
/* 2662 */       attributes = nextAttribute;
/*      */     } 
/*      */ 
/*      */     
/* 2666 */     methodVisitor.visitMaxs(maxStack, maxLocals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readBytecodeInstructionOffset(int bytecodeOffset) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Label readLabel(int bytecodeOffset, Label[] labels) {
/* 2695 */     if (bytecodeOffset >= labels.length) {
/* 2696 */       return new Label();
/*      */     }
/*      */     
/* 2699 */     if (labels[bytecodeOffset] == null) {
/* 2700 */       labels[bytecodeOffset] = new Label();
/*      */     }
/* 2702 */     return labels[bytecodeOffset];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Label createLabel(int bytecodeOffset, Label[] labels) {
/* 2715 */     Label label = readLabel(bytecodeOffset, labels);
/* 2716 */     label.flags = (short)(label.flags & 0xFFFFFFFE);
/* 2717 */     return label;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createDebugLabel(int bytecodeOffset, Label[] labels) {
/* 2729 */     if (labels[bytecodeOffset] == null) {
/* 2730 */       (readLabel(bytecodeOffset, labels)).flags = (short)((readLabel(bytecodeOffset, labels)).flags | 0x1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] readTypeAnnotations(MethodVisitor methodVisitor, Context context, int runtimeTypeAnnotationsOffset, boolean visible) {
/* 2757 */     char[] charBuffer = context.charBuffer;
/* 2758 */     int currentOffset = runtimeTypeAnnotationsOffset;
/*      */     
/* 2760 */     int[] typeAnnotationsOffsets = new int[readUnsignedShort(currentOffset)];
/* 2761 */     currentOffset += 2;
/*      */     
/* 2763 */     for (int i = 0; i < typeAnnotationsOffsets.length; i++) {
/* 2764 */       int tableLength; typeAnnotationsOffsets[i] = currentOffset;
/*      */ 
/*      */       
/* 2767 */       int targetType = readInt(currentOffset);
/* 2768 */       switch (targetType >>> 24) {
/*      */ 
/*      */         
/*      */         case 64:
/*      */         case 65:
/* 2773 */           tableLength = readUnsignedShort(currentOffset + 1);
/* 2774 */           currentOffset += 3;
/* 2775 */           while (tableLength-- > 0) {
/* 2776 */             int startPc = readUnsignedShort(currentOffset);
/* 2777 */             int length = readUnsignedShort(currentOffset + 2);
/*      */             
/* 2779 */             currentOffset += 6;
/* 2780 */             createLabel(startPc, context.currentMethodLabels);
/* 2781 */             createLabel(startPc + length, context.currentMethodLabels);
/*      */           } 
/*      */           break;
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/* 2789 */           currentOffset += 4;
/*      */           break;
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */         case 23:
/*      */         case 66:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/* 2800 */           currentOffset += 3;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 2810 */           throw new IllegalArgumentException();
/*      */       } 
/*      */ 
/*      */       
/* 2814 */       int pathLength = readByte(currentOffset);
/* 2815 */       if (targetType >>> 24 == 66) {
/*      */         
/* 2817 */         TypePath path = (pathLength == 0) ? null : new TypePath(this.classFileBuffer, currentOffset);
/* 2818 */         currentOffset += 1 + 2 * pathLength;
/*      */         
/* 2820 */         String annotationDescriptor = readUTF8(currentOffset, charBuffer);
/* 2821 */         currentOffset += 2;
/*      */ 
/*      */         
/* 2824 */         currentOffset = readElementValues(methodVisitor
/* 2825 */             .visitTryCatchAnnotation(targetType & 0xFFFFFF00, path, annotationDescriptor, visible), currentOffset, true, charBuffer);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 2834 */         currentOffset += 3 + 2 * pathLength;
/*      */ 
/*      */ 
/*      */         
/* 2838 */         currentOffset = readElementValues(null, currentOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */     
/* 2842 */     return typeAnnotationsOffsets;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getTypeAnnotationBytecodeOffset(int[] typeAnnotationOffsets, int typeAnnotationIndex) {
/* 2857 */     if (typeAnnotationOffsets == null || typeAnnotationIndex >= typeAnnotationOffsets.length || 
/*      */       
/* 2859 */       readByte(typeAnnotationOffsets[typeAnnotationIndex]) < 67) {
/* 2860 */       return -1;
/*      */     }
/* 2862 */     return readUnsignedShort(typeAnnotationOffsets[typeAnnotationIndex] + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readTypeAnnotationTarget(Context context, int typeAnnotationOffset) {
/* 2876 */     int tableLength, i, currentOffset = typeAnnotationOffset;
/*      */     
/* 2878 */     int targetType = readInt(typeAnnotationOffset);
/* 2879 */     switch (targetType >>> 24) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 22:
/* 2883 */         targetType &= 0xFFFF0000;
/* 2884 */         currentOffset += 2;
/*      */         break;
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/* 2889 */         targetType &= 0xFF000000;
/* 2890 */         currentOffset++;
/*      */         break;
/*      */       case 64:
/*      */       case 65:
/* 2894 */         targetType &= 0xFF000000;
/* 2895 */         tableLength = readUnsignedShort(currentOffset + 1);
/* 2896 */         currentOffset += 3;
/* 2897 */         context.currentLocalVariableAnnotationRangeStarts = new Label[tableLength];
/* 2898 */         context.currentLocalVariableAnnotationRangeEnds = new Label[tableLength];
/* 2899 */         context.currentLocalVariableAnnotationRangeIndices = new int[tableLength];
/* 2900 */         for (i = 0; i < tableLength; i++) {
/* 2901 */           int startPc = readUnsignedShort(currentOffset);
/* 2902 */           int length = readUnsignedShort(currentOffset + 2);
/* 2903 */           int index = readUnsignedShort(currentOffset + 4);
/* 2904 */           currentOffset += 6;
/* 2905 */           context.currentLocalVariableAnnotationRangeStarts[i] = 
/* 2906 */             createLabel(startPc, context.currentMethodLabels);
/* 2907 */           context.currentLocalVariableAnnotationRangeEnds[i] = 
/* 2908 */             createLabel(startPc + length, context.currentMethodLabels);
/* 2909 */           context.currentLocalVariableAnnotationRangeIndices[i] = index;
/*      */         } 
/*      */         break;
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/* 2917 */         targetType &= 0xFF0000FF;
/* 2918 */         currentOffset += 4;
/*      */         break;
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 23:
/*      */       case 66:
/* 2925 */         targetType &= 0xFFFFFF00;
/* 2926 */         currentOffset += 3;
/*      */         break;
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/* 2932 */         targetType &= 0xFF000000;
/* 2933 */         currentOffset += 3;
/*      */         break;
/*      */       default:
/* 2936 */         throw new IllegalArgumentException();
/*      */     } 
/* 2938 */     context.currentTypeAnnotationTarget = targetType;
/*      */     
/* 2940 */     int pathLength = readByte(currentOffset);
/* 2941 */     context
/* 2942 */       .currentTypeAnnotationTargetPath = (pathLength == 0) ? null : new TypePath(this.classFileBuffer, currentOffset);
/*      */     
/* 2944 */     return currentOffset + 1 + 2 * pathLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readParameterAnnotations(MethodVisitor methodVisitor, Context context, int runtimeParameterAnnotationsOffset, boolean visible) {
/* 2963 */     int currentOffset = runtimeParameterAnnotationsOffset;
/* 2964 */     int numParameters = this.classFileBuffer[currentOffset++] & 0xFF;
/* 2965 */     methodVisitor.visitAnnotableParameterCount(numParameters, visible);
/* 2966 */     char[] charBuffer = context.charBuffer;
/* 2967 */     for (int i = 0; i < numParameters; i++) {
/* 2968 */       int numAnnotations = readUnsignedShort(currentOffset);
/* 2969 */       currentOffset += 2;
/* 2970 */       while (numAnnotations-- > 0) {
/*      */         
/* 2972 */         String annotationDescriptor = readUTF8(currentOffset, charBuffer);
/* 2973 */         currentOffset += 2;
/*      */ 
/*      */         
/* 2976 */         currentOffset = readElementValues(methodVisitor
/* 2977 */             .visitParameterAnnotation(i, annotationDescriptor, visible), currentOffset, true, charBuffer);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readElementValues(AnnotationVisitor annotationVisitor, int annotationOffset, boolean named, char[] charBuffer) {
/* 3004 */     int currentOffset = annotationOffset;
/*      */     
/* 3006 */     int numElementValuePairs = readUnsignedShort(currentOffset);
/* 3007 */     currentOffset += 2;
/* 3008 */     if (named) {
/*      */       
/* 3010 */       while (numElementValuePairs-- > 0) {
/* 3011 */         String elementName = readUTF8(currentOffset, charBuffer);
/*      */         
/* 3013 */         currentOffset = readElementValue(annotationVisitor, currentOffset + 2, elementName, charBuffer);
/*      */       } 
/*      */     } else {
/*      */       
/* 3017 */       while (numElementValuePairs-- > 0)
/*      */       {
/* 3019 */         currentOffset = readElementValue(annotationVisitor, currentOffset, null, charBuffer);
/*      */       }
/*      */     } 
/* 3022 */     if (annotationVisitor != null) {
/* 3023 */       annotationVisitor.visitEnd();
/*      */     }
/* 3025 */     return currentOffset;
/*      */   }
/*      */   
/*      */   private int readElementValue(AnnotationVisitor annotationVisitor, int elementValueOffset, String elementName, char[] charBuffer) {
/*      */     int numValues;
/*      */     byte[] byteValues;
/*      */     int i;
/*      */     boolean[] booleanValues;
/*      */     int j;
/*      */     short[] shortValues;
/*      */     int k;
/*      */     char[] charValues;
/*      */     int m, intValues[], n;
/*      */     long[] longValues;
/*      */     int i1;
/*      */     float[] floatValues;
/*      */     int i2;
/*      */     double[] doubleValues;
/* 3043 */     int i3, currentOffset = elementValueOffset;
/* 3044 */     if (annotationVisitor == null) {
/* 3045 */       switch (this.classFileBuffer[currentOffset] & 0xFF) {
/*      */         case 101:
/* 3047 */           return currentOffset + 5;
/*      */         case 64:
/* 3049 */           return readElementValues(null, currentOffset + 3, true, charBuffer);
/*      */         case 91:
/* 3051 */           return readElementValues(null, currentOffset + 1, false, charBuffer);
/*      */       } 
/* 3053 */       return currentOffset + 3;
/*      */     } 
/*      */     
/* 3056 */     switch (this.classFileBuffer[currentOffset++] & 0xFF) {
/*      */       case 66:
/* 3058 */         annotationVisitor.visit(elementName, 
/* 3059 */             Byte.valueOf((byte)readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset)])));
/* 3060 */         currentOffset += 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3204 */         return currentOffset;case 67: annotationVisitor.visit(elementName, Character.valueOf((char)readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset)]))); currentOffset += 2; return currentOffset;case 68: case 70: case 73: case 74: annotationVisitor.visit(elementName, readConst(readUnsignedShort(currentOffset), charBuffer)); currentOffset += 2; return currentOffset;case 83: annotationVisitor.visit(elementName, Short.valueOf((short)readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset)]))); currentOffset += 2; return currentOffset;case 90: annotationVisitor.visit(elementName, (readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset)]) == 0) ? Boolean.FALSE : Boolean.TRUE); currentOffset += 2; return currentOffset;case 115: annotationVisitor.visit(elementName, readUTF8(currentOffset, charBuffer)); currentOffset += 2; return currentOffset;case 101: annotationVisitor.visitEnum(elementName, readUTF8(currentOffset, charBuffer), readUTF8(currentOffset + 2, charBuffer)); currentOffset += 4; return currentOffset;case 99: annotationVisitor.visit(elementName, Type.getType(readUTF8(currentOffset, charBuffer))); currentOffset += 2; return currentOffset;case 64: currentOffset = readElementValues(annotationVisitor.visitAnnotation(elementName, readUTF8(currentOffset, charBuffer)), currentOffset + 2, true, charBuffer); return currentOffset;case 91: numValues = readUnsignedShort(currentOffset); currentOffset += 2; if (numValues == 0) return readElementValues(annotationVisitor.visitArray(elementName), currentOffset - 2, false, charBuffer);  switch (this.classFileBuffer[currentOffset] & 0xFF) { case 66: byteValues = new byte[numValues]; for (i = 0; i < numValues; i++) { byteValues[i] = (byte)readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)]); currentOffset += 3; }  annotationVisitor.visit(elementName, byteValues); return currentOffset;case 90: booleanValues = new boolean[numValues]; for (j = 0; j < numValues; j++) { booleanValues[j] = (readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)]) != 0); currentOffset += 3; }  annotationVisitor.visit(elementName, booleanValues); return currentOffset;case 83: shortValues = new short[numValues]; for (k = 0; k < numValues; k++) { shortValues[k] = (short)readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)]); currentOffset += 3; }  annotationVisitor.visit(elementName, shortValues); return currentOffset;case 67: charValues = new char[numValues]; for (m = 0; m < numValues; m++) { charValues[m] = (char)readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)]); currentOffset += 3; }  annotationVisitor.visit(elementName, charValues); return currentOffset;case 73: intValues = new int[numValues]; for (n = 0; n < numValues; n++) { intValues[n] = readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)]); currentOffset += 3; }  annotationVisitor.visit(elementName, intValues); return currentOffset;case 74: longValues = new long[numValues]; for (i1 = 0; i1 < numValues; i1++) { longValues[i1] = readLong(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)]); currentOffset += 3; }  annotationVisitor.visit(elementName, longValues); return currentOffset;case 70: floatValues = new float[numValues]; for (i2 = 0; i2 < numValues; i2++) { floatValues[i2] = Float.intBitsToFloat(readInt(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)])); currentOffset += 3; }  annotationVisitor.visit(elementName, floatValues); return currentOffset;case 68: doubleValues = new double[numValues]; for (i3 = 0; i3 < numValues; i3++) { doubleValues[i3] = Double.longBitsToDouble(readLong(this.cpInfoOffsets[readUnsignedShort(currentOffset + 1)])); currentOffset += 3; }  annotationVisitor.visit(elementName, doubleValues); return currentOffset; }  currentOffset = readElementValues(annotationVisitor.visitArray(elementName), currentOffset - 2, false, charBuffer); return currentOffset;
/*      */     } 
/*      */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void computeImplicitFrame(Context context) {
/* 3218 */     String methodDescriptor = context.currentMethodDescriptor;
/* 3219 */     Object[] locals = context.currentFrameLocalTypes;
/* 3220 */     int numLocal = 0;
/* 3221 */     if ((context.currentMethodAccessFlags & 0x8) == 0) {
/* 3222 */       if ("<init>".equals(context.currentMethodName)) {
/* 3223 */         locals[numLocal++] = Opcodes.UNINITIALIZED_THIS;
/*      */       } else {
/* 3225 */         locals[numLocal++] = readClass(this.header + 2, context.charBuffer);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3230 */     int currentMethodDescritorOffset = 1;
/*      */     while (true) {
/* 3232 */       int currentArgumentDescriptorStartOffset = currentMethodDescritorOffset;
/* 3233 */       switch (methodDescriptor.charAt(currentMethodDescritorOffset++)) {
/*      */         case 'B':
/*      */         case 'C':
/*      */         case 'I':
/*      */         case 'S':
/*      */         case 'Z':
/* 3239 */           locals[numLocal++] = Opcodes.INTEGER;
/*      */           continue;
/*      */         case 'F':
/* 3242 */           locals[numLocal++] = Opcodes.FLOAT;
/*      */           continue;
/*      */         case 'J':
/* 3245 */           locals[numLocal++] = Opcodes.LONG;
/*      */           continue;
/*      */         case 'D':
/* 3248 */           locals[numLocal++] = Opcodes.DOUBLE;
/*      */           continue;
/*      */         case '[':
/* 3251 */           while (methodDescriptor.charAt(currentMethodDescritorOffset) == '[') {
/* 3252 */             currentMethodDescritorOffset++;
/*      */           }
/* 3254 */           if (methodDescriptor.charAt(currentMethodDescritorOffset) == 'L') {
/* 3255 */             currentMethodDescritorOffset++;
/* 3256 */             while (methodDescriptor.charAt(currentMethodDescritorOffset) != ';') {
/* 3257 */               currentMethodDescritorOffset++;
/*      */             }
/*      */           } 
/* 3260 */           locals[numLocal++] = methodDescriptor
/* 3261 */             .substring(currentArgumentDescriptorStartOffset, ++currentMethodDescritorOffset);
/*      */           continue;
/*      */         
/*      */         case 'L':
/* 3265 */           while (methodDescriptor.charAt(currentMethodDescritorOffset) != ';') {
/* 3266 */             currentMethodDescritorOffset++;
/*      */           }
/* 3268 */           locals[numLocal++] = methodDescriptor
/* 3269 */             .substring(currentArgumentDescriptorStartOffset + 1, currentMethodDescritorOffset++); continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 3273 */     context.currentFrameLocalCount = numLocal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readStackMapFrame(int stackMapFrameOffset, boolean compressed, boolean expand, Context context) {
/* 3298 */     int frameType, offsetDelta, currentOffset = stackMapFrameOffset;
/* 3299 */     char[] charBuffer = context.charBuffer;
/* 3300 */     Label[] labels = context.currentMethodLabels;
/*      */     
/* 3302 */     if (compressed) {
/*      */       
/* 3304 */       frameType = this.classFileBuffer[currentOffset++] & 0xFF;
/*      */     } else {
/* 3306 */       frameType = 255;
/* 3307 */       context.currentFrameOffset = -1;
/*      */     } 
/*      */     
/* 3310 */     context.currentFrameLocalCountDelta = 0;
/* 3311 */     if (frameType < 64) {
/* 3312 */       offsetDelta = frameType;
/* 3313 */       context.currentFrameType = 3;
/* 3314 */       context.currentFrameStackCount = 0;
/* 3315 */     } else if (frameType < 128) {
/* 3316 */       offsetDelta = frameType - 64;
/*      */       
/* 3318 */       currentOffset = readVerificationTypeInfo(currentOffset, context.currentFrameStackTypes, 0, charBuffer, labels);
/*      */       
/* 3320 */       context.currentFrameType = 4;
/* 3321 */       context.currentFrameStackCount = 1;
/* 3322 */     } else if (frameType >= 247) {
/* 3323 */       offsetDelta = readUnsignedShort(currentOffset);
/* 3324 */       currentOffset += 2;
/* 3325 */       if (frameType == 247) {
/*      */         
/* 3327 */         currentOffset = readVerificationTypeInfo(currentOffset, context.currentFrameStackTypes, 0, charBuffer, labels);
/*      */         
/* 3329 */         context.currentFrameType = 4;
/* 3330 */         context.currentFrameStackCount = 1;
/* 3331 */       } else if (frameType >= 248 && frameType < 251) {
/* 3332 */         context.currentFrameType = 2;
/* 3333 */         context.currentFrameLocalCountDelta = 251 - frameType;
/* 3334 */         context.currentFrameLocalCount -= context.currentFrameLocalCountDelta;
/* 3335 */         context.currentFrameStackCount = 0;
/* 3336 */       } else if (frameType == 251) {
/* 3337 */         context.currentFrameType = 3;
/* 3338 */         context.currentFrameStackCount = 0;
/* 3339 */       } else if (frameType < 255) {
/* 3340 */         int local = expand ? context.currentFrameLocalCount : 0;
/* 3341 */         for (int k = frameType - 251; k > 0; k--)
/*      */         {
/* 3343 */           currentOffset = readVerificationTypeInfo(currentOffset, context.currentFrameLocalTypes, local++, charBuffer, labels);
/*      */         }
/*      */         
/* 3346 */         context.currentFrameType = 1;
/* 3347 */         context.currentFrameLocalCountDelta = frameType - 251;
/* 3348 */         context.currentFrameLocalCount += context.currentFrameLocalCountDelta;
/* 3349 */         context.currentFrameStackCount = 0;
/*      */       } else {
/* 3351 */         int numberOfLocals = readUnsignedShort(currentOffset);
/* 3352 */         currentOffset += 2;
/* 3353 */         context.currentFrameType = 0;
/* 3354 */         context.currentFrameLocalCountDelta = numberOfLocals;
/* 3355 */         context.currentFrameLocalCount = numberOfLocals;
/* 3356 */         for (int local = 0; local < numberOfLocals; local++)
/*      */         {
/* 3358 */           currentOffset = readVerificationTypeInfo(currentOffset, context.currentFrameLocalTypes, local, charBuffer, labels);
/*      */         }
/*      */         
/* 3361 */         int numberOfStackItems = readUnsignedShort(currentOffset);
/* 3362 */         currentOffset += 2;
/* 3363 */         context.currentFrameStackCount = numberOfStackItems;
/* 3364 */         for (int stack = 0; stack < numberOfStackItems; stack++)
/*      */         {
/* 3366 */           currentOffset = readVerificationTypeInfo(currentOffset, context.currentFrameStackTypes, stack, charBuffer, labels);
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 3371 */       throw new IllegalArgumentException();
/*      */     } 
/* 3373 */     context.currentFrameOffset += offsetDelta + 1;
/* 3374 */     createLabel(context.currentFrameOffset, labels);
/* 3375 */     return currentOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readVerificationTypeInfo(int verificationTypeInfoOffset, Object[] frame, int index, char[] charBuffer, Label[] labels) {
/* 3398 */     int currentOffset = verificationTypeInfoOffset;
/* 3399 */     int tag = this.classFileBuffer[currentOffset++] & 0xFF;
/* 3400 */     switch (tag) {
/*      */       case 0:
/* 3402 */         frame[index] = Opcodes.TOP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3433 */         return currentOffset;case 1: frame[index] = Opcodes.INTEGER; return currentOffset;case 2: frame[index] = Opcodes.FLOAT; return currentOffset;case 3: frame[index] = Opcodes.DOUBLE; return currentOffset;case 4: frame[index] = Opcodes.LONG; return currentOffset;case 5: frame[index] = Opcodes.NULL; return currentOffset;case 6: frame[index] = Opcodes.UNINITIALIZED_THIS; return currentOffset;case 7: frame[index] = readClass(currentOffset, charBuffer); currentOffset += 2; return currentOffset;case 8: frame[index] = createLabel(readUnsignedShort(currentOffset), labels); currentOffset += 2; return currentOffset;
/*      */     } 
/*      */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getFirstAttributeOffset() {
/* 3450 */     int currentOffset = this.header + 8 + readUnsignedShort(this.header + 6) * 2;
/*      */ 
/*      */     
/* 3453 */     int fieldsCount = readUnsignedShort(currentOffset);
/* 3454 */     currentOffset += 2;
/*      */     
/* 3456 */     while (fieldsCount-- > 0) {
/*      */ 
/*      */ 
/*      */       
/* 3460 */       int attributesCount = readUnsignedShort(currentOffset + 6);
/* 3461 */       currentOffset += 8;
/*      */       
/* 3463 */       while (attributesCount-- > 0)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 3468 */         currentOffset += 6 + readInt(currentOffset + 2);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3473 */     int methodsCount = readUnsignedShort(currentOffset);
/* 3474 */     currentOffset += 2;
/* 3475 */     while (methodsCount-- > 0) {
/* 3476 */       int attributesCount = readUnsignedShort(currentOffset + 6);
/* 3477 */       currentOffset += 8;
/* 3478 */       while (attributesCount-- > 0) {
/* 3479 */         currentOffset += 6 + readInt(currentOffset + 2);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3484 */     return currentOffset + 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] readBootstrapMethodsAttribute(int maxStringLength) {
/* 3495 */     char[] charBuffer = new char[maxStringLength];
/* 3496 */     int currentAttributeOffset = getFirstAttributeOffset();
/* 3497 */     for (int i = readUnsignedShort(currentAttributeOffset - 2); i > 0; i--) {
/*      */       
/* 3499 */       String attributeName = readUTF8(currentAttributeOffset, charBuffer);
/* 3500 */       int attributeLength = readInt(currentAttributeOffset + 2);
/* 3501 */       currentAttributeOffset += 6;
/* 3502 */       if ("BootstrapMethods".equals(attributeName)) {
/*      */         
/* 3504 */         int[] result = new int[readUnsignedShort(currentAttributeOffset)];
/*      */         
/* 3506 */         int currentBootstrapMethodOffset = currentAttributeOffset + 2;
/* 3507 */         for (int j = 0; j < result.length; j++) {
/* 3508 */           result[j] = currentBootstrapMethodOffset;
/*      */ 
/*      */           
/* 3511 */           currentBootstrapMethodOffset += 4 + 
/* 3512 */             readUnsignedShort(currentBootstrapMethodOffset + 2) * 2;
/*      */         } 
/* 3514 */         return result;
/*      */       } 
/* 3516 */       currentAttributeOffset += attributeLength;
/*      */     } 
/* 3518 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Attribute readAttribute(Attribute[] attributePrototypes, String type, int offset, int length, char[] charBuffer, int codeAttributeOffset, Label[] labels) {
/* 3549 */     for (Attribute attributePrototype : attributePrototypes) {
/* 3550 */       if (attributePrototype.type.equals(type)) {
/* 3551 */         return attributePrototype.read(this, offset, length, charBuffer, codeAttributeOffset, labels);
/*      */       }
/*      */     } 
/*      */     
/* 3555 */     return (new Attribute(type)).read(this, offset, length, null, -1, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getItemCount() {
/* 3568 */     return this.cpInfoOffsets.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getItem(int constantPoolEntryIndex) {
/* 3582 */     return this.cpInfoOffsets[constantPoolEntryIndex];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxStringLength() {
/* 3593 */     return this.maxStringLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readByte(int offset) {
/* 3604 */     return this.classFileBuffer[offset] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] readBytes(int offset, int length) {
/* 3616 */     byte[] result = new byte[length];
/* 3617 */     System.arraycopy(this.classFileBuffer, offset, result, 0, length);
/* 3618 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readUnsignedShort(int offset) {
/* 3629 */     byte[] classBuffer = this.classFileBuffer;
/* 3630 */     return (classBuffer[offset] & 0xFF) << 8 | classBuffer[offset + 1] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short readShort(int offset) {
/* 3641 */     byte[] classBuffer = this.classFileBuffer;
/* 3642 */     return (short)((classBuffer[offset] & 0xFF) << 8 | classBuffer[offset + 1] & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readInt(int offset) {
/* 3653 */     byte[] classBuffer = this.classFileBuffer;
/* 3654 */     return (classBuffer[offset] & 0xFF) << 24 | (classBuffer[offset + 1] & 0xFF) << 16 | (classBuffer[offset + 2] & 0xFF) << 8 | classBuffer[offset + 3] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long readLong(int offset) {
/* 3668 */     long l1 = readInt(offset);
/* 3669 */     long l0 = readInt(offset + 4) & 0xFFFFFFFFL;
/* 3670 */     return l1 << 32L | l0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readUTF8(int offset, char[] charBuffer) {
/* 3686 */     int constantPoolEntryIndex = readUnsignedShort(offset);
/* 3687 */     if (offset == 0 || constantPoolEntryIndex == 0) {
/* 3688 */       return null;
/*      */     }
/* 3690 */     return readUtf(constantPoolEntryIndex, charBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final String readUtf(int constantPoolEntryIndex, char[] charBuffer) {
/* 3703 */     String value = this.constantUtf8Values[constantPoolEntryIndex];
/* 3704 */     if (value != null) {
/* 3705 */       return value;
/*      */     }
/* 3707 */     int cpInfoOffset = this.cpInfoOffsets[constantPoolEntryIndex];
/* 3708 */     this.constantUtf8Values[constantPoolEntryIndex] = 
/* 3709 */       readUtf(cpInfoOffset + 2, readUnsignedShort(cpInfoOffset), charBuffer); return readUtf(cpInfoOffset + 2, readUnsignedShort(cpInfoOffset), charBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String readUtf(int utfOffset, int utfLength, char[] charBuffer) {
/* 3722 */     int currentOffset = utfOffset;
/* 3723 */     int endOffset = currentOffset + utfLength;
/* 3724 */     int strLength = 0;
/* 3725 */     byte[] classBuffer = this.classFileBuffer;
/* 3726 */     while (currentOffset < endOffset) {
/* 3727 */       int currentByte = classBuffer[currentOffset++];
/* 3728 */       if ((currentByte & 0x80) == 0) {
/* 3729 */         charBuffer[strLength++] = (char)(currentByte & 0x7F); continue;
/* 3730 */       }  if ((currentByte & 0xE0) == 192) {
/* 3731 */         charBuffer[strLength++] = (char)(((currentByte & 0x1F) << 6) + (classBuffer[currentOffset++] & 0x3F));
/*      */         continue;
/*      */       } 
/* 3734 */       charBuffer[strLength++] = (char)(((currentByte & 0xF) << 12) + ((classBuffer[currentOffset++] & 0x3F) << 6) + (classBuffer[currentOffset++] & 0x3F));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3741 */     return new String(charBuffer, 0, strLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String readStringish(int offset, char[] charBuffer) {
/* 3760 */     return readUTF8(this.cpInfoOffsets[readUnsignedShort(offset)], charBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readClass(int offset, char[] charBuffer) {
/* 3775 */     return readStringish(offset, charBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readModule(int offset, char[] charBuffer) {
/* 3790 */     return readStringish(offset, charBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readPackage(int offset, char[] charBuffer) {
/* 3805 */     return readStringish(offset, charBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConstantDynamic readConstantDynamic(int constantPoolEntryIndex, char[] charBuffer) {
/* 3819 */     ConstantDynamic constantDynamic = this.constantDynamicValues[constantPoolEntryIndex];
/* 3820 */     if (constantDynamic != null) {
/* 3821 */       return constantDynamic;
/*      */     }
/* 3823 */     int cpInfoOffset = this.cpInfoOffsets[constantPoolEntryIndex];
/* 3824 */     int nameAndTypeCpInfoOffset = this.cpInfoOffsets[readUnsignedShort(cpInfoOffset + 2)];
/* 3825 */     String name = readUTF8(nameAndTypeCpInfoOffset, charBuffer);
/* 3826 */     String descriptor = readUTF8(nameAndTypeCpInfoOffset + 2, charBuffer);
/* 3827 */     int bootstrapMethodOffset = this.bootstrapMethodOffsets[readUnsignedShort(cpInfoOffset)];
/* 3828 */     Handle handle = (Handle)readConst(readUnsignedShort(bootstrapMethodOffset), charBuffer);
/* 3829 */     Object[] bootstrapMethodArguments = new Object[readUnsignedShort(bootstrapMethodOffset + 2)];
/* 3830 */     bootstrapMethodOffset += 4;
/* 3831 */     for (int i = 0; i < bootstrapMethodArguments.length; i++) {
/* 3832 */       bootstrapMethodArguments[i] = readConst(readUnsignedShort(bootstrapMethodOffset), charBuffer);
/* 3833 */       bootstrapMethodOffset += 2;
/*      */     } 
/* 3835 */     this.constantDynamicValues[constantPoolEntryIndex] = new ConstantDynamic(name, descriptor, handle, bootstrapMethodArguments); return new ConstantDynamic(name, descriptor, handle, bootstrapMethodArguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object readConst(int constantPoolEntryIndex, char[] charBuffer) {
/*      */     int referenceKind, referenceCpInfoOffset, nameAndTypeCpInfoOffset;
/*      */     String owner, name, descriptor;
/*      */     boolean isInterface;
/* 3854 */     int cpInfoOffset = this.cpInfoOffsets[constantPoolEntryIndex];
/* 3855 */     switch (this.classFileBuffer[cpInfoOffset - 1]) {
/*      */       case 3:
/* 3857 */         return Integer.valueOf(readInt(cpInfoOffset));
/*      */       case 4:
/* 3859 */         return Float.valueOf(Float.intBitsToFloat(readInt(cpInfoOffset)));
/*      */       case 5:
/* 3861 */         return Long.valueOf(readLong(cpInfoOffset));
/*      */       case 6:
/* 3863 */         return Double.valueOf(Double.longBitsToDouble(readLong(cpInfoOffset)));
/*      */       case 7:
/* 3865 */         return Type.getObjectType(readUTF8(cpInfoOffset, charBuffer));
/*      */       case 8:
/* 3867 */         return readUTF8(cpInfoOffset, charBuffer);
/*      */       case 16:
/* 3869 */         return Type.getMethodType(readUTF8(cpInfoOffset, charBuffer));
/*      */       case 15:
/* 3871 */         referenceKind = readByte(cpInfoOffset);
/* 3872 */         referenceCpInfoOffset = this.cpInfoOffsets[readUnsignedShort(cpInfoOffset + 1)];
/* 3873 */         nameAndTypeCpInfoOffset = this.cpInfoOffsets[readUnsignedShort(referenceCpInfoOffset + 2)];
/* 3874 */         owner = readClass(referenceCpInfoOffset, charBuffer);
/* 3875 */         name = readUTF8(nameAndTypeCpInfoOffset, charBuffer);
/* 3876 */         descriptor = readUTF8(nameAndTypeCpInfoOffset + 2, charBuffer);
/* 3877 */         isInterface = (this.classFileBuffer[referenceCpInfoOffset - 1] == 11);
/*      */         
/* 3879 */         return new Handle(referenceKind, owner, name, descriptor, isInterface);
/*      */       case 17:
/* 3881 */         return readConstantDynamic(constantPoolEntryIndex, charBuffer);
/*      */     } 
/* 3883 */     throw new IllegalArgumentException();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\asm\ClassReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */