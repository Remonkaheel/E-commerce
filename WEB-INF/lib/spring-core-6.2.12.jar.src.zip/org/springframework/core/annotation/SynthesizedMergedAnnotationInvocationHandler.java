/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SynthesizedMergedAnnotationInvocationHandler<A extends Annotation>
/*     */   implements InvocationHandler
/*     */ {
/*     */   private final MergedAnnotation<?> annotation;
/*     */   private final Class<A> type;
/*     */   private final AttributeMethods attributes;
/*  55 */   private final Map<String, Object> valueCache = new ConcurrentHashMap<>(8);
/*     */   
/*     */   @Nullable
/*     */   private volatile Integer hashCode;
/*     */   
/*     */   @Nullable
/*     */   private volatile String string;
/*     */ 
/*     */   
/*     */   private SynthesizedMergedAnnotationInvocationHandler(MergedAnnotation<A> annotation, Class<A> type) {
/*  65 */     Assert.notNull(annotation, "MergedAnnotation must not be null");
/*  66 */     Assert.notNull(type, "Type must not be null");
/*  67 */     Assert.isTrue(type.isAnnotation(), "Type must be an annotation");
/*  68 */     this.annotation = annotation;
/*  69 */     this.type = type;
/*  70 */     this.attributes = AttributeMethods.forAnnotationType(type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) {
/*  76 */     if (this.attributes.indexOf(method.getName()) != -1) {
/*  77 */       return getAttributeValue(method);
/*     */     }
/*  79 */     if (method.getParameterCount() == 0) {
/*  80 */       switch (method.getName()) { case "annotationType":
/*  81 */           return this.type;
/*  82 */         case "hashCode": return Integer.valueOf(annotationHashCode());
/*  83 */         case "toString": return annotationToString(); }
/*     */     
/*     */     }
/*  86 */     if (ReflectionUtils.isEqualsMethod(method)) {
/*  87 */       return Boolean.valueOf(annotationEquals(args[0]));
/*     */     }
/*  89 */     throw new AnnotationConfigurationException(String.format("Method [%s] is unsupported for synthesized annotation type [%s]", new Object[] { method, this.type }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean annotationEquals(Object other) {
/*  98 */     if (this == other) {
/*  99 */       return true;
/*     */     }
/* 101 */     if (!this.type.isInstance(other)) {
/* 102 */       return false;
/*     */     }
/* 104 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 105 */       Method attribute = this.attributes.get(i);
/* 106 */       Object thisValue = getAttributeValue(attribute);
/* 107 */       Object otherValue = AnnotationUtils.invokeAnnotationMethod(attribute, other);
/* 108 */       if (!ObjectUtils.nullSafeEquals(thisValue, otherValue)) {
/* 109 */         return false;
/*     */       }
/*     */     } 
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int annotationHashCode() {
/* 119 */     Integer hashCode = this.hashCode;
/* 120 */     if (hashCode == null) {
/* 121 */       hashCode = computeHashCode();
/* 122 */       this.hashCode = hashCode;
/*     */     } 
/* 124 */     return hashCode.intValue();
/*     */   }
/*     */   
/*     */   private Integer computeHashCode() {
/* 128 */     int hashCode = 0;
/* 129 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 130 */       Method attribute = this.attributes.get(i);
/* 131 */       Object value = getAttributeValue(attribute);
/* 132 */       hashCode += 127 * attribute.getName().hashCode() ^ ObjectUtils.nullSafeHashCode(value);
/*     */     } 
/* 134 */     return Integer.valueOf(hashCode);
/*     */   }
/*     */   
/*     */   private String annotationToString() {
/* 138 */     String string = this.string;
/* 139 */     if (string == null) {
/* 140 */       StringBuilder builder = (new StringBuilder("@")).append(getName(this.type)).append('(');
/* 141 */       for (int i = 0; i < this.attributes.size(); i++) {
/* 142 */         Method attribute = this.attributes.get(i);
/* 143 */         if (i > 0) {
/* 144 */           builder.append(", ");
/*     */         }
/* 146 */         builder.append(attribute.getName());
/* 147 */         builder.append('=');
/* 148 */         builder.append(toString(getAttributeValue(attribute)));
/*     */       } 
/* 150 */       builder.append(')');
/* 151 */       string = builder.toString();
/* 152 */       this.string = string;
/*     */     } 
/* 154 */     return string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toString(Object value) {
/* 171 */     if (value instanceof String) { String str = (String)value;
/* 172 */       return "\"" + str + "\""; }
/*     */     
/* 174 */     if (value instanceof Character) {
/* 175 */       return "'" + value.toString() + "'";
/*     */     }
/* 177 */     if (value instanceof Byte) {
/* 178 */       return String.format("(byte) 0x%02X", new Object[] { value });
/*     */     }
/* 180 */     if (value instanceof Long) { Long longValue = (Long)value;
/* 181 */       return Long.toString(longValue.longValue()) + "L"; }
/*     */     
/* 183 */     if (value instanceof Float) { Float floatValue = (Float)value;
/* 184 */       return Float.toString(floatValue.floatValue()) + "f"; }
/*     */     
/* 186 */     if (value instanceof Double) { Double doubleValue = (Double)value;
/* 187 */       return Double.toString(doubleValue.doubleValue()) + "d"; }
/*     */     
/* 189 */     if (value instanceof Enum) { Enum<?> e = (Enum)value;
/* 190 */       return e.name(); }
/*     */     
/* 192 */     if (value instanceof Class) { Class<?> clazz = (Class)value;
/* 193 */       return getName(clazz) + ".class"; }
/*     */     
/* 195 */     if (value.getClass().isArray()) {
/* 196 */       StringBuilder builder = new StringBuilder("{");
/* 197 */       for (int i = 0; i < Array.getLength(value); i++) {
/* 198 */         if (i > 0) {
/* 199 */           builder.append(", ");
/*     */         }
/* 201 */         builder.append(toString(Array.get(value, i)));
/*     */       } 
/* 203 */       builder.append('}');
/* 204 */       return builder.toString();
/*     */     } 
/* 206 */     return String.valueOf(value);
/*     */   }
/*     */   
/*     */   private Object getAttributeValue(Method method) {
/* 210 */     Object value = this.valueCache.computeIfAbsent(method.getName(), attributeName -> {
/*     */           Class<?> type = ClassUtils.resolvePrimitiveIfNecessary(method.getReturnType());
/*     */ 
/*     */           
/*     */           return this.annotation.getValue(attributeName, type).orElseThrow(());
/*     */         });
/*     */ 
/*     */     
/* 218 */     if (value.getClass().isArray() && Array.getLength(value) > 0) {
/* 219 */       value = cloneArray(value);
/*     */     }
/*     */     
/* 222 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object cloneArray(Object array) {
/* 230 */     if (array instanceof boolean[]) { boolean[] booleans = (boolean[])array;
/* 231 */       return booleans.clone(); }
/*     */     
/* 233 */     if (array instanceof byte[]) { byte[] bytes = (byte[])array;
/* 234 */       return bytes.clone(); }
/*     */     
/* 236 */     if (array instanceof char[]) { char[] chars = (char[])array;
/* 237 */       return chars.clone(); }
/*     */     
/* 239 */     if (array instanceof double[]) { double[] doubles = (double[])array;
/* 240 */       return doubles.clone(); }
/*     */     
/* 242 */     if (array instanceof float[]) { float[] floats = (float[])array;
/* 243 */       return floats.clone(); }
/*     */     
/* 245 */     if (array instanceof int[]) { int[] ints = (int[])array;
/* 246 */       return ints.clone(); }
/*     */     
/* 248 */     if (array instanceof long[]) { long[] longs = (long[])array;
/* 249 */       return longs.clone(); }
/*     */     
/* 251 */     if (array instanceof short[]) { short[] shorts = (short[])array;
/* 252 */       return shorts.clone(); }
/*     */ 
/*     */ 
/*     */     
/* 256 */     return ((Object[])array).clone();
/*     */   }
/*     */ 
/*     */   
/*     */   static <A extends Annotation> A createProxy(MergedAnnotation<A> annotation, Class<A> type) {
/* 261 */     ClassLoader classLoader = type.getClassLoader();
/* 262 */     Class<?>[] interfaces = new Class[] { type };
/* 263 */     InvocationHandler<A> handler = new SynthesizedMergedAnnotationInvocationHandler<>(annotation, type);
/* 264 */     return (A)Proxy.newProxyInstance(classLoader, interfaces, handler);
/*     */   }
/*     */   
/*     */   private static String getName(Class<?> clazz) {
/* 268 */     String canonicalName = clazz.getCanonicalName();
/* 269 */     return (canonicalName != null) ? canonicalName : clazz.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\SynthesizedMergedAnnotationInvocationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */