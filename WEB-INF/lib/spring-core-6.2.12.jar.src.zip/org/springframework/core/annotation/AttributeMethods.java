/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AttributeMethods
/*     */ {
/*  40 */   static final AttributeMethods NONE = new AttributeMethods(null, new Method[0]);
/*     */   
/*  42 */   static final Map<Class<? extends Annotation>, AttributeMethods> cache = (Map<Class<? extends Annotation>, AttributeMethods>)new ConcurrentReferenceHashMap();
/*     */   static {
/*  44 */     methodComparator = ((m1, m2) -> 
/*  45 */       (m1 != null && m2 != null) ? m1.getName().compareTo(m2.getName()) : ((m1 != null) ? -1 : 1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Comparator<Method> methodComparator;
/*     */   
/*     */   @Nullable
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   
/*     */   private final Method[] attributeMethods;
/*     */   
/*     */   private final boolean[] canThrowTypeNotPresentException;
/*     */   
/*     */   private final boolean hasDefaultValueMethod;
/*     */   
/*     */   private final boolean hasNestedAnnotation;
/*     */ 
/*     */   
/*     */   private AttributeMethods(@Nullable Class<? extends Annotation> annotationType, Method[] attributeMethods) {
/*  65 */     this.annotationType = annotationType;
/*  66 */     this.attributeMethods = attributeMethods;
/*  67 */     this.canThrowTypeNotPresentException = new boolean[attributeMethods.length];
/*  68 */     boolean foundDefaultValueMethod = false;
/*  69 */     boolean foundNestedAnnotation = false;
/*  70 */     for (int i = 0; i < attributeMethods.length; i++) {
/*  71 */       Method method = this.attributeMethods[i];
/*  72 */       Class<?> type = method.getReturnType();
/*  73 */       if (!foundDefaultValueMethod && method.getDefaultValue() != null) {
/*  74 */         foundDefaultValueMethod = true;
/*     */       }
/*  76 */       if (!foundNestedAnnotation && (type.isAnnotation() || (type.isArray() && type.componentType().isAnnotation()))) {
/*  77 */         foundNestedAnnotation = true;
/*     */       }
/*  79 */       ReflectionUtils.makeAccessible(method);
/*  80 */       this.canThrowTypeNotPresentException[i] = (type == Class.class || type == Class[].class || type.isEnum());
/*     */     } 
/*  82 */     this.hasDefaultValueMethod = foundDefaultValueMethod;
/*  83 */     this.hasNestedAnnotation = foundNestedAnnotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canLoad(Annotation annotation) {
/*  98 */     assertAnnotation(annotation);
/*  99 */     for (int i = 0; i < size(); i++) {
/* 100 */       if (canThrowTypeNotPresentException(i)) {
/*     */         try {
/* 102 */           AnnotationUtils.invokeAnnotationMethod(get(i), annotation);
/*     */         }
/* 104 */         catch (IllegalStateException illegalStateException) {
/*     */ 
/*     */         
/*     */         }
/* 108 */         catch (Throwable ex) {
/*     */           
/* 110 */           return false;
/*     */         } 
/*     */       }
/*     */     } 
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validate(Annotation annotation) {
/* 128 */     assertAnnotation(annotation);
/* 129 */     for (int i = 0; i < size(); i++) {
/* 130 */       if (canThrowTypeNotPresentException(i)) {
/*     */         try {
/* 132 */           AnnotationUtils.invokeAnnotationMethod(get(i), annotation);
/*     */         }
/* 134 */         catch (IllegalStateException ex) {
/* 135 */           throw ex;
/*     */         }
/* 137 */         catch (Throwable ex) {
/* 138 */           throw new IllegalStateException("Could not obtain annotation attribute value for " + 
/* 139 */               get(i).getName() + " declared on @" + getName(annotation.annotationType()), ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void assertAnnotation(Annotation annotation) {
/* 146 */     Assert.notNull(annotation, "Annotation must not be null");
/* 147 */     if (this.annotationType != null) {
/* 148 */       Assert.isInstanceOf(this.annotationType, annotation);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Method get(String name) {
/* 160 */     int index = indexOf(name);
/* 161 */     return (index != -1) ? this.attributeMethods[index] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Method get(int index) {
/* 172 */     return this.attributeMethods[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canThrowTypeNotPresentException(int index) {
/* 183 */     return this.canThrowTypeNotPresentException[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int indexOf(String name) {
/* 193 */     for (int i = 0; i < this.attributeMethods.length; i++) {
/* 194 */       if (this.attributeMethods[i].getName().equals(name)) {
/* 195 */         return i;
/*     */       }
/*     */     } 
/* 198 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int indexOf(Method attribute) {
/* 208 */     for (int i = 0; i < this.attributeMethods.length; i++) {
/* 209 */       if (this.attributeMethods[i].equals(attribute)) {
/* 210 */         return i;
/*     */       }
/*     */     } 
/* 213 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 221 */     return this.attributeMethods.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasDefaultValueMethod() {
/* 229 */     return this.hasDefaultValueMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasNestedAnnotation() {
/* 238 */     return this.hasNestedAnnotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AttributeMethods forAnnotationType(@Nullable Class<? extends Annotation> annotationType) {
/* 248 */     if (annotationType == null) {
/* 249 */       return NONE;
/*     */     }
/* 251 */     return cache.computeIfAbsent(annotationType, AttributeMethods::compute);
/*     */   }
/*     */   
/*     */   private static AttributeMethods compute(Class<? extends Annotation> annotationType) {
/* 255 */     Method[] methods = annotationType.getDeclaredMethods();
/* 256 */     int size = methods.length;
/* 257 */     for (int i = 0; i < methods.length; i++) {
/* 258 */       if (!isAttributeMethod(methods[i])) {
/* 259 */         methods[i] = null;
/* 260 */         size--;
/*     */       } 
/*     */     } 
/* 263 */     if (size == 0) {
/* 264 */       return NONE;
/*     */     }
/* 266 */     Arrays.sort(methods, methodComparator);
/* 267 */     Method[] attributeMethods = Arrays.<Method>copyOf(methods, size);
/* 268 */     return new AttributeMethods(annotationType, attributeMethods);
/*     */   }
/*     */   
/*     */   private static boolean isAttributeMethod(Method method) {
/* 272 */     return (method.getParameterCount() == 0 && method.getReturnType() != void.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String describe(@Nullable Method attribute) {
/* 282 */     if (attribute == null) {
/* 283 */       return "(none)";
/*     */     }
/* 285 */     return describe(attribute.getDeclaringClass(), attribute.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String describe(@Nullable Class<?> annotationType, @Nullable String attributeName) {
/* 296 */     if (attributeName == null) {
/* 297 */       return "(none)";
/*     */     }
/* 299 */     String in = (annotationType != null) ? (" in annotation [" + annotationType.getName() + "]") : "";
/* 300 */     return "attribute '" + attributeName + "'" + in;
/*     */   }
/*     */   
/*     */   private static String getName(Class<?> clazz) {
/* 304 */     String canonicalName = clazz.getCanonicalName();
/* 305 */     return (canonicalName != null) ? canonicalName : clazz.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AttributeMethods.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */