/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum null
/*    */ {
/*    */   public boolean isEnabled() {
/* 38 */     return IntrospectionFailureLogger.getLogger().isDebugEnabled();
/*    */   }
/*    */   
/*    */   public void log(String message) {
/* 42 */     IntrospectionFailureLogger.getLogger().debug(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\IntrospectionFailureLogger$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */