/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotatedElementUtils
/*     */ {
/*     */   public static AnnotatedElement forAnnotations(Annotation... annotations) {
/* 107 */     return new AnnotatedElementForAnnotations(annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> getMetaAnnotationTypes(AnnotatedElement element, Class<? extends Annotation> annotationType) {
/* 127 */     return getMetaAnnotationTypes(element, element.getAnnotation((Class)annotationType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> getMetaAnnotationTypes(AnnotatedElement element, String annotationName) {
/* 145 */     for (Annotation annotation : element.getAnnotations()) {
/* 146 */       if (annotation.annotationType().getName().equals(annotationName)) {
/* 147 */         return getMetaAnnotationTypes(element, annotation);
/*     */       }
/*     */     } 
/* 150 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   private static Set<String> getMetaAnnotationTypes(AnnotatedElement element, @Nullable Annotation annotation) {
/* 154 */     if (annotation == null) {
/* 155 */       return Collections.emptySet();
/*     */     }
/* 157 */     return (Set<String>)getAnnotations(annotation.annotationType()).stream()
/* 158 */       .map(mergedAnnotation -> mergedAnnotation.getType().getName())
/* 159 */       .collect(Collectors.toCollection(java.util.LinkedHashSet::new));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasMetaAnnotationTypes(AnnotatedElement element, Class<? extends Annotation> annotationType) {
/* 175 */     return getAnnotations(element).<Annotation>stream(annotationType).anyMatch(MergedAnnotation::isMetaPresent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasMetaAnnotationTypes(AnnotatedElement element, String annotationName) {
/* 191 */     return getAnnotations(element).<Annotation>stream(annotationName).anyMatch(MergedAnnotation::isMetaPresent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAnnotated(AnnotatedElement element, Class<? extends Annotation> annotationType) {
/* 210 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/* 211 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(element)) {
/* 212 */       return element.isAnnotationPresent(annotationType);
/*     */     }
/*     */     
/* 215 */     return getAnnotations(element).isPresent(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAnnotated(AnnotatedElement element, String annotationName) {
/* 231 */     return getAnnotations(element).isPresent(annotationName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static AnnotationAttributes getMergedAnnotationAttributes(AnnotatedElement element, Class<? extends Annotation> annotationType) {
/* 256 */     MergedAnnotation<?> mergedAnnotation = getAnnotations(element).get(annotationType, (Predicate<? super MergedAnnotation<?>>)null, MergedAnnotationSelectors.firstDirectlyDeclared());
/* 257 */     return getAnnotationAttributes(mergedAnnotation, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static AnnotationAttributes getMergedAnnotationAttributes(AnnotatedElement element, String annotationName) {
/* 282 */     return getMergedAnnotationAttributes(element, annotationName, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static AnnotationAttributes getMergedAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/* 316 */     MergedAnnotation<?> mergedAnnotation = getAnnotations(element).get(annotationName, (Predicate<? super MergedAnnotation<?>>)null, MergedAnnotationSelectors.firstDirectlyDeclared());
/* 317 */     return getAnnotationAttributes(mergedAnnotation, classValuesAsString, nestedAnnotationsAsMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <A extends Annotation> A getMergedAnnotation(AnnotatedElement element, Class<A> annotationType) {
/* 337 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/* 338 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(element)) {
/* 339 */       return element.getDeclaredAnnotation(annotationType);
/*     */     }
/*     */     
/* 342 */     return (A)getAnnotations(element)
/* 343 */       .<Annotation>get(annotationType, (Predicate<? super MergedAnnotation<Annotation>>)null, MergedAnnotationSelectors.firstDirectlyDeclared())
/* 344 */       .synthesize(MergedAnnotation::isPresent).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> Set<A> getAllMergedAnnotations(AnnotatedElement element, Class<A> annotationType) {
/* 370 */     return (Set<A>)getAnnotations(element).<A>stream(annotationType)
/* 371 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Annotation> getAllMergedAnnotations(AnnotatedElement element, Set<Class<? extends Annotation>> annotationTypes) {
/* 395 */     return (Set<Annotation>)getAnnotations(element).stream()
/* 396 */       .filter((Predicate)MergedAnnotationPredicates.typeIn(annotationTypes))
/* 397 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> Set<A> getMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType) {
/* 427 */     return getMergedRepeatableAnnotations(element, annotationType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> Set<A> getMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType, @Nullable Class<? extends Annotation> containerType) {
/* 470 */     return (Set<A>)getRepeatableAnnotations(element, containerType, annotationType)
/* 471 */       .<A>stream(annotationType)
/* 472 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static MultiValueMap<String, Object> getAllAnnotationAttributes(AnnotatedElement element, String annotationName) {
/* 493 */     return getAllAnnotationAttributes(element, annotationName, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static MultiValueMap<String, Object> getAllAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/* 518 */     MergedAnnotation.Adapt[] adaptations = MergedAnnotation.Adapt.values(classValuesAsString, nestedAnnotationsAsMap);
/* 519 */     return (MultiValueMap<String, Object>)getAnnotations(element).<Annotation>stream(annotationName)
/* 520 */       .filter(MergedAnnotationPredicates.unique(MergedAnnotation::getMetaTypes))
/* 521 */       .map(MergedAnnotation::withNonMergedAttributes)
/* 522 */       .collect(MergedAnnotationCollectors.toMultiValueMap(AnnotatedElementUtils::nullIfEmpty, adaptations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAnnotation(AnnotatedElement element, Class<? extends Annotation> annotationType) {
/* 541 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/* 542 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(element)) {
/* 543 */       return element.isAnnotationPresent(annotationType);
/*     */     }
/*     */     
/* 546 */     return findAnnotations(element).isPresent(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static AnnotationAttributes findMergedAnnotationAttributes(AnnotatedElement element, Class<? extends Annotation> annotationType, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/* 581 */     MergedAnnotation<?> mergedAnnotation = findAnnotations(element).get(annotationType, (Predicate<? super MergedAnnotation<?>>)null, MergedAnnotationSelectors.firstDirectlyDeclared());
/* 582 */     return getAnnotationAttributes(mergedAnnotation, classValuesAsString, nestedAnnotationsAsMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static AnnotationAttributes findMergedAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/* 617 */     MergedAnnotation<?> mergedAnnotation = findAnnotations(element).get(annotationName, (Predicate<? super MergedAnnotation<?>>)null, MergedAnnotationSelectors.firstDirectlyDeclared());
/* 618 */     return getAnnotationAttributes(mergedAnnotation, classValuesAsString, nestedAnnotationsAsMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <A extends Annotation> A findMergedAnnotation(AnnotatedElement element, Class<A> annotationType) {
/* 642 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/* 643 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(element)) {
/* 644 */       return element.getDeclaredAnnotation(annotationType);
/*     */     }
/*     */     
/* 647 */     return (A)findAnnotations(element)
/* 648 */       .<Annotation>get(annotationType, (Predicate<? super MergedAnnotation<Annotation>>)null, MergedAnnotationSelectors.firstDirectlyDeclared())
/* 649 */       .synthesize(MergedAnnotation::isPresent).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> Set<A> findAllMergedAnnotations(AnnotatedElement element, Class<A> annotationType) {
/* 672 */     return (Set<A>)findAnnotations(element).<A>stream(annotationType)
/* 673 */       .sorted(highAggregateIndexesFirst())
/* 674 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Annotation> findAllMergedAnnotations(AnnotatedElement element, Set<Class<? extends Annotation>> annotationTypes) {
/* 696 */     return (Set<Annotation>)findAnnotations(element).stream()
/* 697 */       .filter((Predicate)MergedAnnotationPredicates.typeIn(annotationTypes))
/* 698 */       .sorted(highAggregateIndexesFirst())
/* 699 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> Set<A> findMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType) {
/* 729 */     return findMergedRepeatableAnnotations(element, annotationType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> Set<A> findMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType, @Nullable Class<? extends Annotation> containerType) {
/* 771 */     return (Set<A>)findRepeatableAnnotations(element, containerType, annotationType)
/* 772 */       .<A>stream(annotationType)
/* 773 */       .sorted(highAggregateIndexesFirst())
/* 774 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*     */   }
/*     */   
/*     */   private static MergedAnnotations getAnnotations(AnnotatedElement element) {
/* 778 */     return MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.INHERITED_ANNOTATIONS, RepeatableContainers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MergedAnnotations getRepeatableAnnotations(AnnotatedElement element, @Nullable Class<? extends Annotation> containerType, Class<? extends Annotation> annotationType) {
/*     */     RepeatableContainers repeatableContainers;
/* 785 */     if (containerType == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 795 */       RepeatableContainers.of(annotationType, null);
/* 796 */       repeatableContainers = RepeatableContainers.standardRepeatables();
/*     */     } else {
/*     */       
/* 799 */       repeatableContainers = RepeatableContainers.of(annotationType, containerType);
/*     */     } 
/* 801 */     return MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.INHERITED_ANNOTATIONS, repeatableContainers);
/*     */   }
/*     */   
/*     */   private static MergedAnnotations findAnnotations(AnnotatedElement element) {
/* 805 */     return MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY, RepeatableContainers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MergedAnnotations findRepeatableAnnotations(AnnotatedElement element, @Nullable Class<? extends Annotation> containerType, Class<? extends Annotation> annotationType) {
/*     */     RepeatableContainers repeatableContainers;
/* 812 */     if (containerType == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 822 */       RepeatableContainers.of(annotationType, null);
/* 823 */       repeatableContainers = RepeatableContainers.standardRepeatables();
/*     */     } else {
/*     */       
/* 826 */       repeatableContainers = RepeatableContainers.of(annotationType, containerType);
/*     */     } 
/* 828 */     return MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY, repeatableContainers);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static MultiValueMap<String, Object> nullIfEmpty(MultiValueMap<String, Object> map) {
/* 833 */     return map.isEmpty() ? null : map;
/*     */   }
/*     */   
/*     */   private static <A extends Annotation> Comparator<MergedAnnotation<A>> highAggregateIndexesFirst() {
/* 837 */     return Comparator.<MergedAnnotation<A>>comparingInt(MergedAnnotation::getAggregateIndex).reversed();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static AnnotationAttributes getAnnotationAttributes(MergedAnnotation<?> annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/* 844 */     if (!annotation.isPresent()) {
/* 845 */       return null;
/*     */     }
/* 847 */     return annotation.asAnnotationAttributes(MergedAnnotation.Adapt.values(classValuesAsString, nestedAnnotationsAsMap));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AnnotatedElementForAnnotations
/*     */     implements AnnotatedElement
/*     */   {
/*     */     private final Annotation[] annotations;
/*     */ 
/*     */     
/*     */     AnnotatedElementForAnnotations(Annotation... annotations) {
/* 859 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <T extends Annotation> T getAnnotation(Class<T> annotationClass) {
/* 866 */       for (Annotation annotation : this.annotations) {
/* 867 */         if (annotation.annotationType() == annotationClass) {
/* 868 */           return (T)annotation;
/*     */         }
/*     */       } 
/* 871 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Annotation[] getAnnotations() {
/* 876 */       return (Annotation[])this.annotations.clone();
/*     */     }
/*     */ 
/*     */     
/*     */     public Annotation[] getDeclaredAnnotations() {
/* 881 */       return (Annotation[])this.annotations.clone();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotatedElementUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */