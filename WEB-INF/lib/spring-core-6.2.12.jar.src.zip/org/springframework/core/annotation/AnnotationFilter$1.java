/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements AnnotationFilter
/*    */ {
/*    */   public boolean matches(Annotation annotation) {
/* 58 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(Class<?> type) {
/* 62 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(String typeName) {
/* 66 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 70 */     return "All annotations filtered";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationFilter$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */