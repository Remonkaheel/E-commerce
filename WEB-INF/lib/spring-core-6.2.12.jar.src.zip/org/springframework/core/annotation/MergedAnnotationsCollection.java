/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Spliterator;
/*     */ import java.util.Spliterators;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MergedAnnotationsCollection
/*     */   implements MergedAnnotations
/*     */ {
/*     */   private final MergedAnnotation<?>[] annotations;
/*     */   private final AnnotationTypeMappings[] mappings;
/*     */   
/*     */   private MergedAnnotationsCollection(Collection<MergedAnnotation<?>> annotations) {
/*  48 */     Assert.notNull(annotations, "Annotations must not be null");
/*  49 */     this.annotations = (MergedAnnotation<?>[])annotations.<MergedAnnotation>toArray(new MergedAnnotation[0]);
/*  50 */     this.mappings = new AnnotationTypeMappings[this.annotations.length];
/*  51 */     for (int i = 0; i < this.annotations.length; i++) {
/*  52 */       MergedAnnotation<?> annotation = this.annotations[i];
/*  53 */       Assert.notNull(annotation, "Annotation must not be null");
/*  54 */       Assert.isTrue(annotation.isDirectlyPresent(), "Annotation must be directly present");
/*  55 */       Assert.isTrue((annotation.getAggregateIndex() == 0), "Annotation must have aggregate index of zero");
/*  56 */       this.mappings[i] = AnnotationTypeMappings.forAnnotationType((Class)annotation.getType());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<MergedAnnotation<Annotation>> iterator() {
/*  63 */     return Spliterators.iterator(spliterator());
/*     */   }
/*     */ 
/*     */   
/*     */   public Spliterator<MergedAnnotation<Annotation>> spliterator() {
/*  68 */     return spliterator(null);
/*     */   }
/*     */   
/*     */   private <A extends Annotation> Spliterator<MergedAnnotation<A>> spliterator(@Nullable Object annotationType) {
/*  72 */     return new AnnotationsSpliterator<>(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> boolean isPresent(Class<A> annotationType) {
/*  77 */     return isPresent(annotationType, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPresent(String annotationType) {
/*  82 */     return isPresent(annotationType, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> boolean isDirectlyPresent(Class<A> annotationType) {
/*  87 */     return isPresent(annotationType, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirectlyPresent(String annotationType) {
/*  92 */     return isPresent(annotationType, true);
/*     */   }
/*     */   
/*     */   private boolean isPresent(Object requiredType, boolean directOnly) {
/*  96 */     for (MergedAnnotation<?> annotation : this.annotations) {
/*  97 */       Class<? extends Annotation> type = (Class)annotation.getType();
/*  98 */       if (type == requiredType || type.getName().equals(requiredType)) {
/*  99 */         return true;
/*     */       }
/*     */     } 
/* 102 */     if (!directOnly) {
/* 103 */       for (AnnotationTypeMappings mappings : this.mappings) {
/* 104 */         for (int i = 1; i < mappings.size(); i++) {
/* 105 */           AnnotationTypeMapping mapping = mappings.get(i);
/* 106 */           if (isMappingForType(mapping, requiredType)) {
/* 107 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(Class<A> annotationType) {
/* 117 */     return get(annotationType, (Predicate<? super MergedAnnotation<A>>)null, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(Class<A> annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate) {
/* 124 */     return get(annotationType, predicate, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(Class<A> annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate, @Nullable MergedAnnotationSelector<A> selector) {
/* 132 */     MergedAnnotation<A> result = find(annotationType, predicate, selector);
/* 133 */     return (result != null) ? result : MergedAnnotation.<A>missing();
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(String annotationType) {
/* 138 */     return get(annotationType, (Predicate<? super MergedAnnotation<A>>)null, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(String annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate) {
/* 145 */     return get(annotationType, predicate, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(String annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate, @Nullable MergedAnnotationSelector<A> selector) {
/* 153 */     MergedAnnotation<A> result = find(annotationType, predicate, selector);
/* 154 */     return (result != null) ? result : MergedAnnotation.<A>missing();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private <A extends Annotation> MergedAnnotation<A> find(Object requiredType, @Nullable Predicate<? super MergedAnnotation<A>> predicate, @Nullable MergedAnnotationSelector<A> selector) {
/* 163 */     if (selector == null) {
/* 164 */       selector = MergedAnnotationSelectors.nearest();
/*     */     }
/*     */     
/* 167 */     MergedAnnotation<A> result = null;
/* 168 */     for (int i = 0; i < this.annotations.length; i++) {
/* 169 */       MergedAnnotation<?> root = this.annotations[i];
/* 170 */       if (root != null) {
/* 171 */         AnnotationTypeMappings mappings = this.mappings[i];
/* 172 */         for (int mappingIndex = 0; mappingIndex < mappings.size(); mappingIndex++) {
/* 173 */           AnnotationTypeMapping mapping = mappings.get(mappingIndex);
/* 174 */           if (isMappingForType(mapping, requiredType)) {
/*     */ 
/*     */ 
/*     */             
/* 178 */             MergedAnnotation<A> candidate = (mappingIndex == 0) ? (MergedAnnotation)root : TypeMappedAnnotation.<A>createIfPossible(mapping, root, IntrospectionFailureLogger.INFO);
/* 179 */             if (candidate != null && (predicate == null || predicate.test(candidate))) {
/* 180 */               if (selector.isBestCandidate(candidate)) {
/* 181 */                 return candidate;
/*     */               }
/* 183 */               result = (result != null) ? selector.select(result, candidate) : candidate;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 188 */     }  return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> Stream<MergedAnnotation<A>> stream(Class<A> annotationType) {
/* 193 */     return StreamSupport.stream(spliterator(annotationType), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> Stream<MergedAnnotation<A>> stream(String annotationType) {
/* 198 */     return StreamSupport.stream(spliterator(annotationType), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<MergedAnnotation<Annotation>> stream() {
/* 203 */     return StreamSupport.stream(spliterator(), false);
/*     */   }
/*     */   
/*     */   private static boolean isMappingForType(AnnotationTypeMapping mapping, @Nullable Object requiredType) {
/* 207 */     if (requiredType == null) {
/* 208 */       return true;
/*     */     }
/* 210 */     Class<? extends Annotation> actualType = mapping.getAnnotationType();
/* 211 */     return (actualType == requiredType || actualType.getName().equals(requiredType));
/*     */   }
/*     */   
/*     */   static MergedAnnotations of(Collection<MergedAnnotation<?>> annotations) {
/* 215 */     Assert.notNull(annotations, "Annotations must not be null");
/* 216 */     if (annotations.isEmpty()) {
/* 217 */       return TypeMappedAnnotations.NONE;
/*     */     }
/* 219 */     return new MergedAnnotationsCollection(annotations);
/*     */   }
/*     */ 
/*     */   
/*     */   private class AnnotationsSpliterator<A extends Annotation>
/*     */     implements Spliterator<MergedAnnotation<A>>
/*     */   {
/*     */     @Nullable
/*     */     private final Object requiredType;
/*     */     private final int[] mappingCursors;
/*     */     
/*     */     public AnnotationsSpliterator(Object requiredType) {
/* 231 */       this.mappingCursors = new int[MergedAnnotationsCollection.this.annotations.length];
/* 232 */       this.requiredType = requiredType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryAdvance(Consumer<? super MergedAnnotation<A>> action) {
/* 237 */       int lowestDistance = Integer.MAX_VALUE;
/* 238 */       int annotationResult = -1;
/* 239 */       for (int annotationIndex = 0; annotationIndex < MergedAnnotationsCollection.this.annotations.length; annotationIndex++) {
/* 240 */         AnnotationTypeMapping mapping = getNextSuitableMapping(annotationIndex);
/* 241 */         if (mapping != null && mapping.getDistance() < lowestDistance) {
/* 242 */           annotationResult = annotationIndex;
/* 243 */           lowestDistance = mapping.getDistance();
/*     */         } 
/* 245 */         if (lowestDistance == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/* 249 */       if (annotationResult != -1) {
/* 250 */         MergedAnnotation<A> mergedAnnotation = createMergedAnnotationIfPossible(annotationResult, this.mappingCursors[annotationResult]);
/*     */         
/* 252 */         this.mappingCursors[annotationResult] = this.mappingCursors[annotationResult] + 1;
/* 253 */         if (mergedAnnotation == null) {
/* 254 */           return tryAdvance(action);
/*     */         }
/* 256 */         action.accept(mergedAnnotation);
/* 257 */         return true;
/*     */       } 
/* 259 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private AnnotationTypeMapping getNextSuitableMapping(int annotationIndex) {
/*     */       while (true) {
/* 266 */         AnnotationTypeMapping mapping = getMapping(annotationIndex, this.mappingCursors[annotationIndex]);
/* 267 */         if (mapping != null && MergedAnnotationsCollection.isMappingForType(mapping, this.requiredType)) {
/* 268 */           return mapping;
/*     */         }
/* 270 */         this.mappingCursors[annotationIndex] = this.mappingCursors[annotationIndex] + 1;
/*     */         
/* 272 */         if (mapping == null)
/* 273 */           return null; 
/*     */       } 
/*     */     }
/*     */     @Nullable
/*     */     private AnnotationTypeMapping getMapping(int annotationIndex, int mappingIndex) {
/* 278 */       AnnotationTypeMappings mappings = MergedAnnotationsCollection.this.mappings[annotationIndex];
/* 279 */       return (mappingIndex < mappings.size()) ? mappings.get(mappingIndex) : null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private MergedAnnotation<A> createMergedAnnotationIfPossible(int annotationIndex, int mappingIndex) {
/* 285 */       MergedAnnotation<?> root = MergedAnnotationsCollection.this.annotations[annotationIndex];
/* 286 */       if (mappingIndex == 0) {
/* 287 */         return (MergedAnnotation)root;
/*     */       }
/*     */       
/* 290 */       IntrospectionFailureLogger logger = (this.requiredType != null) ? IntrospectionFailureLogger.INFO : IntrospectionFailureLogger.DEBUG;
/* 291 */       return TypeMappedAnnotation.createIfPossible(MergedAnnotationsCollection.this.mappings[annotationIndex]
/* 292 */           .get(mappingIndex), root, logger);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Spliterator<MergedAnnotation<A>> trySplit() {
/* 298 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public long estimateSize() {
/* 303 */       int size = 0;
/* 304 */       for (int i = 0; i < MergedAnnotationsCollection.this.annotations.length; i++) {
/* 305 */         AnnotationTypeMappings mappings = MergedAnnotationsCollection.this.mappings[i];
/* 306 */         int numberOfMappings = mappings.size();
/* 307 */         numberOfMappings -= Math.min(this.mappingCursors[i], mappings.size());
/* 308 */         size += numberOfMappings;
/*     */       } 
/* 310 */       return size;
/*     */     }
/*     */ 
/*     */     
/*     */     public int characteristics() {
/* 315 */       return 1280;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\MergedAnnotationsCollection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */