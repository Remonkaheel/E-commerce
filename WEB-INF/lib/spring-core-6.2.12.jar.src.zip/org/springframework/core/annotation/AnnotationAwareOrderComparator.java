/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationAwareOrderComparator
/*     */   extends OrderComparator
/*     */ {
/*  52 */   public static final AnnotationAwareOrderComparator INSTANCE = new AnnotationAwareOrderComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Integer findOrder(Object obj) {
/*  64 */     Integer order = super.findOrder(obj);
/*  65 */     if (order != null) {
/*  66 */       return order;
/*     */     }
/*  68 */     return findOrderFromAnnotation(obj);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Integer findOrderFromAnnotation(Object obj) {
/*  73 */     AnnotatedElement ae = (AnnotatedElement)obj, element = (obj instanceof AnnotatedElement) ? ae : obj.getClass();
/*  74 */     MergedAnnotations annotations = MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY);
/*  75 */     Integer order = OrderUtils.getOrderFromAnnotations(element, annotations);
/*  76 */     if (order == null && obj instanceof DecoratingProxy) { DecoratingProxy decoratingProxy = (DecoratingProxy)obj;
/*  77 */       return findOrderFromAnnotation(decoratingProxy.getDecoratedClass()); }
/*     */     
/*  79 */     return order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer getPriority(Object obj) {
/*  91 */     if (obj instanceof Class) { Class<?> clazz = (Class)obj;
/*  92 */       return OrderUtils.getPriority(clazz); }
/*     */     
/*  94 */     Integer priority = OrderUtils.getPriority(obj.getClass());
/*  95 */     if (priority == null && obj instanceof DecoratingProxy) { DecoratingProxy decoratingProxy = (DecoratingProxy)obj;
/*  96 */       return getPriority(decoratingProxy.getDecoratedClass()); }
/*     */     
/*  98 */     return priority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sort(List<?> list) {
/* 110 */     if (list.size() > 1) {
/* 111 */       list.sort((Comparator<?>)INSTANCE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sort(Object[] array) {
/* 123 */     if (array.length > 1) {
/* 124 */       Arrays.sort(array, (Comparator<? super Object>)INSTANCE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sortIfNecessary(Object value) {
/* 137 */     if (value instanceof Object[]) { Object[] objects = (Object[])value;
/* 138 */       sort(objects); }
/*     */     
/* 140 */     else if (value instanceof List) { List<?> list = (List)value;
/* 141 */       sort(list); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationAwareOrderComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */