/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AnnotationsScanner
/*     */ {
/*  49 */   private static final Annotation[] NO_ANNOTATIONS = new Annotation[0];
/*     */   
/*  51 */   private static final Method[] NO_METHODS = new Method[0];
/*     */ 
/*     */   
/*  54 */   private static final Map<AnnotatedElement, Annotation[]> declaredAnnotationCache = (Map<AnnotatedElement, Annotation[]>)new ConcurrentReferenceHashMap(256);
/*     */ 
/*     */   
/*  57 */   private static final Map<Class<?>, Method[]> baseTypeMethodsCache = (Map<Class<?>, Method[]>)new ConcurrentReferenceHashMap(256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static <C, R> R scan(C context, AnnotatedElement source, MergedAnnotations.SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass, AnnotationsProcessor<C, R> processor) {
/*  82 */     R result = process(context, source, searchStrategy, searchEnclosingClass, processor);
/*  83 */     return processor.finish(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R process(C context, AnnotatedElement source, MergedAnnotations.SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass, AnnotationsProcessor<C, R> processor) {
/*  91 */     if (source instanceof Class) { Class<?> clazz = (Class)source;
/*  92 */       return processClass(context, clazz, searchStrategy, searchEnclosingClass, processor); }
/*     */     
/*  94 */     if (source instanceof Method) { Method method = (Method)source;
/*  95 */       return processMethod(context, method, searchStrategy, processor); }
/*     */     
/*  97 */     return processElement(context, source, processor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processClass(C context, Class<?> source, MergedAnnotations.SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass, AnnotationsProcessor<C, R> processor) {
/* 104 */     switch (searchStrategy) { default: throw new IncompatibleClassChangeError();case DIRECT: case INHERITED_ANNOTATIONS: case SUPERCLASS: case TYPE_HIERARCHY: break; }  return 
/*     */ 
/*     */ 
/*     */       
/* 108 */       processClassHierarchy(context, source, processor, true, searchEnclosingClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processClassInheritedAnnotations(C context, Class<?> source, AnnotationsProcessor<C, R> processor) {
/*     */     try {
/* 117 */       if (isWithoutHierarchy(source, MergedAnnotations.Search.never)) {
/* 118 */         return processElement(context, source, processor);
/*     */       }
/* 120 */       Annotation[] relevant = null;
/* 121 */       int remaining = Integer.MAX_VALUE;
/* 122 */       int aggregateIndex = 0;
/* 123 */       Class<?> root = source;
/* 124 */       while (source != null && source != Object.class && remaining > 0 && !hasPlainJavaAnnotationsOnly(source)) {
/* 125 */         R result = processor.doWithAggregate(context, aggregateIndex);
/* 126 */         if (result != null) {
/* 127 */           return result;
/*     */         }
/* 129 */         Annotation[] declaredAnns = getDeclaredAnnotations(source, true);
/* 130 */         if (declaredAnns.length > 0) {
/* 131 */           if (relevant == null) {
/* 132 */             relevant = root.getAnnotations();
/* 133 */             remaining = relevant.length;
/*     */           } 
/* 135 */           for (int i = 0; i < declaredAnns.length; i++) {
/* 136 */             if (declaredAnns[i] != null) {
/* 137 */               boolean isRelevant = false;
/* 138 */               for (int relevantIndex = 0; relevantIndex < relevant.length; relevantIndex++) {
/* 139 */                 if (relevant[relevantIndex] != null && declaredAnns[i]
/* 140 */                   .annotationType() == relevant[relevantIndex].annotationType()) {
/* 141 */                   isRelevant = true;
/* 142 */                   relevant[relevantIndex] = null;
/* 143 */                   remaining--;
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 147 */               if (!isRelevant) {
/* 148 */                 declaredAnns[i] = null;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 153 */         result = processor.doWithAnnotations(context, aggregateIndex, source, declaredAnns);
/* 154 */         if (result != null) {
/* 155 */           return result;
/*     */         }
/* 157 */         source = source.getSuperclass();
/* 158 */         aggregateIndex++;
/*     */       }
/*     */     
/* 161 */     } catch (Throwable ex) {
/* 162 */       AnnotationUtils.handleIntrospectionFailure(source, ex);
/*     */     } 
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processClassHierarchy(C context, Class<?> source, AnnotationsProcessor<C, R> processor, boolean includeInterfaces, Predicate<Class<?>> searchEnclosingClass) {
/* 172 */     return processClassHierarchy(context, new int[] { 0 }, source, processor, includeInterfaces, searchEnclosingClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processClassHierarchy(C context, int[] aggregateIndex, Class<?> source, AnnotationsProcessor<C, R> processor, boolean includeInterfaces, Predicate<Class<?>> searchEnclosingClass) {
/*     */     try {
/* 182 */       R result = processor.doWithAggregate(context, aggregateIndex[0]);
/* 183 */       if (result != null) {
/* 184 */         return result;
/*     */       }
/* 186 */       if (hasPlainJavaAnnotationsOnly(source)) {
/* 187 */         return null;
/*     */       }
/* 189 */       Annotation[] annotations = getDeclaredAnnotations(source, false);
/* 190 */       result = processor.doWithAnnotations(context, aggregateIndex[0], source, annotations);
/* 191 */       if (result != null) {
/* 192 */         return result;
/*     */       }
/* 194 */       aggregateIndex[0] = aggregateIndex[0] + 1;
/* 195 */       if (includeInterfaces) {
/* 196 */         for (Class<?> interfaceType : source.getInterfaces()) {
/* 197 */           R interfacesResult = processClassHierarchy(context, aggregateIndex, interfaceType, processor, true, searchEnclosingClass);
/*     */           
/* 199 */           if (interfacesResult != null) {
/* 200 */             return interfacesResult;
/*     */           }
/*     */         } 
/*     */       }
/* 204 */       Class<?> superclass = source.getSuperclass();
/* 205 */       if (superclass != Object.class && superclass != null) {
/* 206 */         R superclassResult = processClassHierarchy(context, aggregateIndex, superclass, processor, includeInterfaces, searchEnclosingClass);
/*     */         
/* 208 */         if (superclassResult != null) {
/* 209 */           return superclassResult;
/*     */         }
/*     */       } 
/* 212 */       if (searchEnclosingClass.test(source)) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 219 */           Class<?> enclosingClass = source.getEnclosingClass();
/* 220 */           if (enclosingClass != null) {
/* 221 */             R enclosingResult = processClassHierarchy(context, aggregateIndex, enclosingClass, processor, includeInterfaces, searchEnclosingClass);
/*     */             
/* 223 */             if (enclosingResult != null) {
/* 224 */               return enclosingResult;
/*     */             }
/*     */           }
/*     */         
/* 228 */         } catch (Throwable ex) {
/* 229 */           AnnotationUtils.handleIntrospectionFailure(source, ex);
/*     */         }
/*     */       
/*     */       }
/* 233 */     } catch (Throwable ex) {
/* 234 */       AnnotationUtils.handleIntrospectionFailure(source, ex);
/*     */     } 
/* 236 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processMethod(C context, Method source, MergedAnnotations.SearchStrategy searchStrategy, AnnotationsProcessor<C, R> processor) {
/* 243 */     switch (searchStrategy) { default: throw new IncompatibleClassChangeError();case DIRECT: case INHERITED_ANNOTATIONS: case SUPERCLASS: case TYPE_HIERARCHY: break; }  return 
/*     */ 
/*     */ 
/*     */       
/* 247 */       processMethodHierarchy(context, new int[] { 0 }, source.getDeclaringClass(), processor, source, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processMethodInheritedAnnotations(C context, Method source, AnnotationsProcessor<C, R> processor) {
/*     */     try {
/* 257 */       R result = processor.doWithAggregate(context, 0);
/* 258 */       return (result != null) ? result : 
/* 259 */         processMethodAnnotations(context, 0, source, processor);
/*     */     }
/* 261 */     catch (Throwable ex) {
/* 262 */       AnnotationUtils.handleIntrospectionFailure(source, ex);
/*     */       
/* 264 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processMethodHierarchy(C context, int[] aggregateIndex, Class<?> sourceClass, AnnotationsProcessor<C, R> processor, Method rootMethod, boolean includeInterfaces) {
/*     */     try {
/* 273 */       R result = processor.doWithAggregate(context, aggregateIndex[0]);
/* 274 */       if (result != null) {
/* 275 */         return result;
/*     */       }
/* 277 */       if (hasPlainJavaAnnotationsOnly(sourceClass)) {
/* 278 */         return null;
/*     */       }
/* 280 */       boolean calledProcessor = false;
/* 281 */       if (sourceClass == rootMethod.getDeclaringClass()) {
/* 282 */         result = processMethodAnnotations(context, aggregateIndex[0], rootMethod, processor);
/*     */         
/* 284 */         calledProcessor = true;
/* 285 */         if (result != null) {
/* 286 */           return result;
/*     */         }
/*     */       } else {
/*     */         
/* 290 */         for (Method candidateMethod : getBaseTypeMethods(context, sourceClass)) {
/* 291 */           if (candidateMethod != null && isOverride(rootMethod, candidateMethod)) {
/* 292 */             result = processMethodAnnotations(context, aggregateIndex[0], candidateMethod, processor);
/*     */             
/* 294 */             calledProcessor = true;
/* 295 */             if (result != null) {
/* 296 */               return result;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 301 */       if (Modifier.isPrivate(rootMethod.getModifiers())) {
/* 302 */         return null;
/*     */       }
/* 304 */       if (calledProcessor) {
/* 305 */         aggregateIndex[0] = aggregateIndex[0] + 1;
/*     */       }
/* 307 */       if (includeInterfaces) {
/* 308 */         for (Class<?> interfaceType : sourceClass.getInterfaces()) {
/* 309 */           R interfacesResult = processMethodHierarchy(context, aggregateIndex, interfaceType, processor, rootMethod, true);
/*     */           
/* 311 */           if (interfacesResult != null) {
/* 312 */             return interfacesResult;
/*     */           }
/*     */         } 
/*     */       }
/* 316 */       Class<?> superclass = sourceClass.getSuperclass();
/* 317 */       if (superclass != Object.class && superclass != null) {
/* 318 */         R superclassResult = processMethodHierarchy(context, aggregateIndex, superclass, processor, rootMethod, includeInterfaces);
/*     */         
/* 320 */         if (superclassResult != null) {
/* 321 */           return superclassResult;
/*     */         }
/*     */       }
/*     */     
/* 325 */     } catch (Throwable ex) {
/* 326 */       AnnotationUtils.handleIntrospectionFailure(rootMethod, ex);
/*     */     } 
/* 328 */     return null;
/*     */   }
/*     */   
/*     */   private static <C> Method[] getBaseTypeMethods(C context, Class<?> baseType) {
/* 332 */     if (baseType == Object.class || hasPlainJavaAnnotationsOnly(baseType)) {
/* 333 */       return NO_METHODS;
/*     */     }
/*     */     
/* 336 */     Method[] methods = baseTypeMethodsCache.get(baseType);
/* 337 */     if (methods == null) {
/* 338 */       methods = ReflectionUtils.getDeclaredMethods(baseType);
/* 339 */       int cleared = 0;
/* 340 */       for (int i = 0; i < methods.length; i++) {
/* 341 */         if (Modifier.isPrivate(methods[i].getModifiers()) || 
/* 342 */           hasPlainJavaAnnotationsOnly(methods[i]) || (
/* 343 */           getDeclaredAnnotations(methods[i], false)).length == 0) {
/* 344 */           methods[i] = null;
/* 345 */           cleared++;
/*     */         } 
/*     */       } 
/* 348 */       if (cleared == methods.length) {
/* 349 */         methods = NO_METHODS;
/*     */       }
/* 351 */       baseTypeMethodsCache.put(baseType, methods);
/*     */     } 
/* 353 */     return methods;
/*     */   }
/*     */   
/*     */   private static boolean isOverride(Method rootMethod, Method candidateMethod) {
/* 357 */     return (!Modifier.isPrivate(candidateMethod.getModifiers()) && candidateMethod
/* 358 */       .getParameterCount() == rootMethod.getParameterCount() && candidateMethod
/* 359 */       .getName().equals(rootMethod.getName()) && 
/* 360 */       hasSameParameterTypes(rootMethod, candidateMethod));
/*     */   }
/*     */   
/*     */   private static boolean hasSameParameterTypes(Method rootMethod, Method candidateMethod) {
/* 364 */     Class<?>[] rootParameterTypes = rootMethod.getParameterTypes();
/* 365 */     Class<?>[] candidateParameterTypes = candidateMethod.getParameterTypes();
/* 366 */     if (Arrays.equals((Object[])candidateParameterTypes, (Object[])rootParameterTypes)) {
/* 367 */       return true;
/*     */     }
/* 369 */     return hasSameGenericTypeParameters(rootMethod, candidateMethod, rootParameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasSameGenericTypeParameters(Method rootMethod, Method candidateMethod, Class<?>[] rootParameterTypes) {
/* 375 */     Class<?> rootDeclaringClass = rootMethod.getDeclaringClass();
/* 376 */     Class<?> candidateDeclaringClass = candidateMethod.getDeclaringClass();
/* 377 */     if (!candidateDeclaringClass.isAssignableFrom(rootDeclaringClass)) {
/* 378 */       return false;
/*     */     }
/* 380 */     for (int i = 0; i < rootParameterTypes.length; i++) {
/*     */       
/* 382 */       Class<?> resolvedParameterType = ResolvableType.forMethodParameter(candidateMethod, i, rootDeclaringClass).toClass();
/* 383 */       if (rootParameterTypes[i] != resolvedParameterType) {
/* 384 */         return false;
/*     */       }
/*     */     } 
/* 387 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processMethodAnnotations(C context, int aggregateIndex, Method source, AnnotationsProcessor<C, R> processor) {
/* 394 */     Annotation[] annotations = getDeclaredAnnotations(source, false);
/* 395 */     R result = processor.doWithAnnotations(context, aggregateIndex, source, annotations);
/* 396 */     if (result != null) {
/* 397 */       return result;
/*     */     }
/* 399 */     Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(source);
/* 400 */     if (bridgedMethod != source) {
/* 401 */       Annotation[] bridgedAnnotations = getDeclaredAnnotations(bridgedMethod, true);
/* 402 */       for (int i = 0; i < bridgedAnnotations.length; i++) {
/* 403 */         if (ObjectUtils.containsElement((Object[])annotations, bridgedAnnotations[i])) {
/* 404 */           bridgedAnnotations[i] = null;
/*     */         }
/*     */       } 
/* 407 */       return processor.doWithAnnotations(context, aggregateIndex, source, bridgedAnnotations);
/*     */     } 
/* 409 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <C, R> R processElement(C context, AnnotatedElement source, AnnotationsProcessor<C, R> processor) {
/*     */     try {
/* 417 */       R result = processor.doWithAggregate(context, 0);
/* 418 */       return (result != null) ? result : processor.doWithAnnotations(context, 0, source, 
/* 419 */           getDeclaredAnnotations(source, false));
/*     */     }
/* 421 */     catch (Throwable ex) {
/* 422 */       AnnotationUtils.handleIntrospectionFailure(source, ex);
/*     */       
/* 424 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static <A extends Annotation> A getDeclaredAnnotation(AnnotatedElement source, Class<A> annotationType) {
/* 430 */     Annotation[] annotations = getDeclaredAnnotations(source, false);
/* 431 */     for (Annotation annotation : annotations) {
/* 432 */       if (annotation != null && annotationType == annotation.annotationType()) {
/* 433 */         return (A)annotation;
/*     */       }
/*     */     } 
/* 436 */     return null;
/*     */   }
/*     */   
/*     */   static Annotation[] getDeclaredAnnotations(AnnotatedElement source, boolean defensive) {
/* 440 */     boolean cached = false;
/* 441 */     Annotation[] annotations = declaredAnnotationCache.get(source);
/* 442 */     if (annotations != null) {
/* 443 */       cached = true;
/*     */     } else {
/*     */       
/* 446 */       annotations = source.getDeclaredAnnotations();
/* 447 */       if (annotations.length != 0) {
/* 448 */         boolean allIgnored = true;
/* 449 */         for (int i = 0; i < annotations.length; i++) {
/* 450 */           Annotation annotation = annotations[i];
/* 451 */           if (isIgnorable(annotation.annotationType()) || 
/* 452 */             !AttributeMethods.forAnnotationType(annotation.annotationType()).canLoad(annotation)) {
/* 453 */             annotations[i] = null;
/*     */           } else {
/*     */             
/* 456 */             allIgnored = false;
/*     */           } 
/*     */         } 
/* 459 */         annotations = allIgnored ? NO_ANNOTATIONS : annotations;
/* 460 */         if (source instanceof Class || source instanceof Member) {
/* 461 */           declaredAnnotationCache.put(source, annotations);
/* 462 */           cached = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 466 */     if (!defensive || annotations.length == 0 || !cached) {
/* 467 */       return annotations;
/*     */     }
/* 469 */     return (Annotation[])annotations.clone();
/*     */   }
/*     */   
/*     */   private static boolean isIgnorable(Class<?> annotationType) {
/* 473 */     return AnnotationFilter.PLAIN.matches(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isKnownEmpty(AnnotatedElement source, MergedAnnotations.SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass) {
/* 479 */     if (hasPlainJavaAnnotationsOnly(source)) {
/* 480 */       return true;
/*     */     }
/* 482 */     if (searchStrategy == MergedAnnotations.SearchStrategy.DIRECT || isWithoutHierarchy(source, searchEnclosingClass)) {
/* 483 */       if (source instanceof Method) { Method method = (Method)source; if (method.isBridge())
/* 484 */           return false;  }
/*     */       
/* 486 */       return ((getDeclaredAnnotations(source, false)).length == 0);
/*     */     } 
/* 488 */     return false;
/*     */   }
/*     */   
/*     */   static boolean hasPlainJavaAnnotationsOnly(@Nullable Object annotatedElement) {
/* 492 */     if (annotatedElement instanceof Class) { Class<?> clazz = (Class)annotatedElement;
/* 493 */       return hasPlainJavaAnnotationsOnly(clazz); }
/*     */     
/* 495 */     if (annotatedElement instanceof Member) { Member member = (Member)annotatedElement;
/* 496 */       return hasPlainJavaAnnotationsOnly(member.getDeclaringClass()); }
/*     */ 
/*     */     
/* 499 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean hasPlainJavaAnnotationsOnly(Class<?> type) {
/* 504 */     return (type.getName().startsWith("java.") || type == Ordered.class);
/*     */   }
/*     */   
/*     */   private static boolean isWithoutHierarchy(AnnotatedElement source, Predicate<Class<?>> searchEnclosingClass) {
/* 508 */     if (source == Object.class) {
/* 509 */       return true;
/*     */     }
/* 511 */     if (source instanceof Class) { Class<?> sourceClass = (Class)source;
/*     */       
/* 513 */       boolean noSuperTypes = (sourceClass.getSuperclass() == Object.class && (sourceClass.getInterfaces()).length == 0);
/* 514 */       return searchEnclosingClass.test(sourceClass) ? ((noSuperTypes && sourceClass
/* 515 */         .getEnclosingClass() == null)) : noSuperTypes; }
/*     */     
/* 517 */     if (source instanceof Method) { Method sourceMethod = (Method)source;
/* 518 */       return (Modifier.isPrivate(sourceMethod.getModifiers()) || 
/* 519 */         isWithoutHierarchy(sourceMethod.getDeclaringClass(), searchEnclosingClass)); }
/*     */     
/* 521 */     return true;
/*     */   }
/*     */   
/*     */   static void clearCache() {
/* 525 */     declaredAnnotationCache.clear();
/* 526 */     baseTypeMethodsCache.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationsScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */