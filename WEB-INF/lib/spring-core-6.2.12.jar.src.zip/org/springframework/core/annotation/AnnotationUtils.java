/*      */ package org.springframework.core.annotation;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import org.springframework.core.BridgeMethodResolver;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ConcurrentReferenceHashMap;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AnnotationUtils
/*      */ {
/*      */   public static final String VALUE = "value";
/*  116 */   private static final AnnotationFilter JAVA_LANG_ANNOTATION_FILTER = AnnotationFilter.packages(new String[] { "java.lang.annotation" });
/*      */   
/*  118 */   private static final Map<Class<? extends Annotation>, Map<String, DefaultValueHolder>> defaultValuesCache = (Map<Class<? extends Annotation>, Map<String, DefaultValueHolder>>)new ConcurrentReferenceHashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isCandidateClass(Class<?> clazz, Collection<Class<? extends Annotation>> annotationTypes) {
/*  135 */     for (Class<? extends Annotation> annotationType : annotationTypes) {
/*  136 */       if (isCandidateClass(clazz, annotationType)) {
/*  137 */         return true;
/*      */       }
/*      */     } 
/*  140 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isCandidateClass(Class<?> clazz, @Nullable Class<? extends Annotation> annotationType) {
/*  155 */     return (annotationType != null && isCandidateClass(clazz, annotationType.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isCandidateClass(Class<?> clazz, String annotationName) {
/*  170 */     if (annotationName.startsWith("java.")) {
/*  171 */       return true;
/*      */     }
/*  173 */     if (AnnotationsScanner.hasPlainJavaAnnotationsOnly(clazz)) {
/*  174 */       return false;
/*      */     }
/*  176 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <A extends Annotation> A getAnnotation(Annotation annotation, Class<A> annotationType) {
/*  195 */     if (annotationType.isInstance(annotation)) {
/*  196 */       return synthesizeAnnotation((A)annotation, annotationType);
/*      */     }
/*      */     
/*  199 */     if (AnnotationsScanner.hasPlainJavaAnnotationsOnly(annotation)) {
/*  200 */       return null;
/*      */     }
/*      */     
/*  203 */     return (A)MergedAnnotations.from(annotation, new Annotation[] { annotation }, RepeatableContainers.none())
/*  204 */       .<Annotation>get(annotationType).withNonMergedAttributes()
/*  205 */       .synthesize(AnnotationUtils::isSingleLevelPresent).orElse(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <A extends Annotation> A getAnnotation(AnnotatedElement annotatedElement, Class<A> annotationType) {
/*  223 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/*  224 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(annotatedElement)) {
/*  225 */       return annotatedElement.getAnnotation(annotationType);
/*      */     }
/*      */     
/*  228 */     return (A)MergedAnnotations.from(annotatedElement, MergedAnnotations.SearchStrategy.INHERITED_ANNOTATIONS, RepeatableContainers.none())
/*  229 */       .<Annotation>get(annotationType).withNonMergedAttributes()
/*  230 */       .synthesize(AnnotationUtils::isSingleLevelPresent).orElse(null);
/*      */   }
/*      */   
/*      */   private static <A extends Annotation> boolean isSingleLevelPresent(MergedAnnotation<A> mergedAnnotation) {
/*  234 */     int distance = mergedAnnotation.getDistance();
/*  235 */     return (distance == 0 || distance == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <A extends Annotation> A getAnnotation(Method method, Class<A> annotationType) {
/*  254 */     Method resolvedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  255 */     return getAnnotation(resolvedMethod, annotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public static Annotation[] getAnnotations(AnnotatedElement annotatedElement) {
/*      */     try {
/*  274 */       return synthesizeAnnotationArray(annotatedElement.getAnnotations(), annotatedElement);
/*      */     }
/*  276 */     catch (Throwable ex) {
/*  277 */       handleIntrospectionFailure(annotatedElement, ex);
/*  278 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public static Annotation[] getAnnotations(Method method) {
/*      */     try {
/*  299 */       return synthesizeAnnotationArray(BridgeMethodResolver.findBridgedMethod(method).getAnnotations(), method);
/*      */     }
/*  301 */     catch (Throwable ex) {
/*  302 */       handleIntrospectionFailure(method, ex);
/*  303 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <A extends Annotation> Set<A> getRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType) {
/*  339 */     return getRepeatableAnnotations(annotatedElement, annotationType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <A extends Annotation> Set<A> getRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType, @Nullable Class<? extends Annotation> containerAnnotationType) {
/*  378 */     RepeatableContainers repeatableContainers = (containerAnnotationType != null) ? RepeatableContainers.of(annotationType, containerAnnotationType) : RepeatableContainers.standardRepeatables();
/*      */     
/*  380 */     return (Set<A>)MergedAnnotations.from(annotatedElement, MergedAnnotations.SearchStrategy.SUPERCLASS, repeatableContainers)
/*  381 */       .<A>stream(annotationType)
/*  382 */       .filter(MergedAnnotationPredicates.firstRunOf(MergedAnnotation::getAggregateIndex))
/*  383 */       .map(MergedAnnotation::withNonMergedAttributes)
/*  384 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <A extends Annotation> Set<A> getDeclaredRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType) {
/*  420 */     return getDeclaredRepeatableAnnotations(annotatedElement, annotationType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <A extends Annotation> Set<A> getDeclaredRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType, @Nullable Class<? extends Annotation> containerAnnotationType) {
/*  459 */     RepeatableContainers repeatableContainers = (containerAnnotationType != null) ? RepeatableContainers.of(annotationType, containerAnnotationType) : RepeatableContainers.standardRepeatables();
/*      */     
/*  461 */     return (Set<A>)MergedAnnotations.from(annotatedElement, MergedAnnotations.SearchStrategy.DIRECT, repeatableContainers)
/*  462 */       .<A>stream(annotationType)
/*  463 */       .map(MergedAnnotation::withNonMergedAttributes)
/*  464 */       .collect(MergedAnnotationCollectors.toAnnotationSet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <A extends Annotation> A findAnnotation(AnnotatedElement annotatedElement, @Nullable Class<A> annotationType) {
/*  487 */     if (annotationType == null) {
/*  488 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  492 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/*  493 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(annotatedElement)) {
/*  494 */       return annotatedElement.getDeclaredAnnotation(annotationType);
/*      */     }
/*      */ 
/*      */     
/*  498 */     return (A)MergedAnnotations.from(annotatedElement, MergedAnnotations.SearchStrategy.INHERITED_ANNOTATIONS, RepeatableContainers.none())
/*  499 */       .<Annotation>get(annotationType).withNonMergedAttributes()
/*  500 */       .synthesize(MergedAnnotation::isPresent).orElse(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <A extends Annotation> A findAnnotation(Method method, @Nullable Class<A> annotationType) {
/*  520 */     if (annotationType == null) {
/*  521 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  525 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/*  526 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(method)) {
/*  527 */       return method.getDeclaredAnnotation(annotationType);
/*      */     }
/*      */ 
/*      */     
/*  531 */     return (A)MergedAnnotations.from(method, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY, RepeatableContainers.none())
/*  532 */       .<Annotation>get(annotationType).withNonMergedAttributes()
/*  533 */       .synthesize(MergedAnnotation::isPresent).orElse(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <A extends Annotation> A findAnnotation(Class<?> clazz, @Nullable Class<A> annotationType) {
/*  560 */     if (annotationType == null) {
/*  561 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  565 */     if (AnnotationFilter.PLAIN.matches(annotationType) || 
/*  566 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(clazz)) {
/*  567 */       A annotation = clazz.getDeclaredAnnotation(annotationType);
/*  568 */       if (annotation != null) {
/*  569 */         return annotation;
/*      */       }
/*      */ 
/*      */       
/*  573 */       Class<?> superclass = clazz.getSuperclass();
/*  574 */       if (superclass == null || superclass == Object.class) {
/*  575 */         return null;
/*      */       }
/*  577 */       return findAnnotation(superclass, annotationType);
/*      */     } 
/*      */ 
/*      */     
/*  581 */     return (A)MergedAnnotations.from(clazz, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY, RepeatableContainers.none())
/*  582 */       .<Annotation>get(annotationType).withNonMergedAttributes()
/*  583 */       .synthesize(MergedAnnotation::isPresent).orElse(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public static Class<?> findAnnotationDeclaringClass(Class<? extends Annotation> annotationType, @Nullable Class<?> clazz) {
/*  612 */     if (clazz == null) {
/*  613 */       return null;
/*      */     }
/*      */     
/*  616 */     return (Class)MergedAnnotations.from(clazz, MergedAnnotations.SearchStrategy.SUPERCLASS)
/*  617 */       .<Annotation>get(annotationType, MergedAnnotation::isDirectlyPresent)
/*  618 */       .getSource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   public static Class<?> findAnnotationDeclaringClassForTypes(List<Class<? extends Annotation>> annotationTypes, @Nullable Class<?> clazz) {
/*  649 */     if (clazz == null) {
/*  650 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  655 */     MergedAnnotation<?> merged = MergedAnnotations.from(clazz, MergedAnnotations.SearchStrategy.SUPERCLASS).stream().filter(MergedAnnotationPredicates.<Annotation>typeIn(annotationTypes).and(MergedAnnotation::isDirectlyPresent)).findFirst().orElse(null);
/*  656 */     if (merged != null) { Object object = merged.getSource(); if (object instanceof Class) Class<?> sourceClass = (Class)object;  }  return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAnnotationDeclaredLocally(Class<? extends Annotation> annotationType, Class<?> clazz) {
/*  675 */     return MergedAnnotations.from(clazz).<Annotation>get(annotationType).isDirectlyPresent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isAnnotationInherited(Class<? extends Annotation> annotationType, Class<?> clazz) {
/*  700 */     return 
/*      */ 
/*      */ 
/*      */       
/*  704 */       (((MergedAnnotation)MergedAnnotations.from(clazz, MergedAnnotations.SearchStrategy.INHERITED_ANNOTATIONS).<Annotation>stream(annotationType).filter(MergedAnnotation::isDirectlyPresent).findFirst().orElseGet(MergedAnnotation::missing)).getAggregateIndex() > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isAnnotationMetaPresent(Class<? extends Annotation> annotationType, @Nullable Class<? extends Annotation> metaAnnotationType) {
/*  720 */     if (metaAnnotationType == null) {
/*  721 */       return false;
/*      */     }
/*      */     
/*  724 */     if (AnnotationFilter.PLAIN.matches(metaAnnotationType) || 
/*  725 */       AnnotationsScanner.hasPlainJavaAnnotationsOnly(annotationType)) {
/*  726 */       return annotationType.isAnnotationPresent(metaAnnotationType);
/*      */     }
/*      */     
/*  729 */     return MergedAnnotations.from(annotationType, MergedAnnotations.SearchStrategy.INHERITED_ANNOTATIONS, 
/*  730 */         RepeatableContainers.none()).isPresent(metaAnnotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInJavaLangAnnotationPackage(@Nullable Annotation annotation) {
/*  740 */     return (annotation != null && JAVA_LANG_ANNOTATION_FILTER.matches(annotation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInJavaLangAnnotationPackage(@Nullable String annotationType) {
/*  751 */     return (annotationType != null && JAVA_LANG_ANNOTATION_FILTER.matches(annotationType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void validateAnnotation(Annotation annotation) {
/*  767 */     AttributeMethods.forAnnotationType(annotation.annotationType()).validate(annotation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> getAnnotationAttributes(Annotation annotation) {
/*  786 */     return getAnnotationAttributes((AnnotatedElement)null, annotation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> getAnnotationAttributes(Annotation annotation, boolean classValuesAsString) {
/*  806 */     return getAnnotationAttributes(annotation, classValuesAsString, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AnnotationAttributes getAnnotationAttributes(Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/*  828 */     return getAnnotationAttributes(null, annotation, classValuesAsString, nestedAnnotationsAsMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AnnotationAttributes getAnnotationAttributes(@Nullable AnnotatedElement annotatedElement, Annotation annotation) {
/*  847 */     return getAnnotationAttributes(annotatedElement, annotation, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AnnotationAttributes getAnnotationAttributes(@Nullable AnnotatedElement annotatedElement, Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/*  872 */     MergedAnnotation.Adapt[] adaptations = MergedAnnotation.Adapt.values(classValuesAsString, nestedAnnotationsAsMap);
/*  873 */     return (AnnotationAttributes)MergedAnnotation.<Annotation>from(annotatedElement, annotation)
/*  874 */       .withNonMergedAttributes()
/*  875 */       .asMap(mergedAnnotation -> new AnnotationAttributes(mergedAnnotation.getType(), true), adaptations);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerDefaultValues(AnnotationAttributes attributes) {
/*  886 */     Class<? extends Annotation> annotationType = attributes.annotationType();
/*  887 */     if (annotationType != null && Modifier.isPublic(annotationType.getModifiers()) && 
/*  888 */       !AnnotationFilter.PLAIN.matches(annotationType)) {
/*  889 */       Map<String, DefaultValueHolder> defaultValues = getDefaultValues(annotationType);
/*  890 */       Objects.requireNonNull(attributes); defaultValues.forEach(attributes::putIfAbsent);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, DefaultValueHolder> getDefaultValues(Class<? extends Annotation> annotationType) {
/*  897 */     return defaultValuesCache.computeIfAbsent(annotationType, AnnotationUtils::computeDefaultValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, DefaultValueHolder> computeDefaultValues(Class<? extends Annotation> annotationType) {
/*  904 */     AttributeMethods methods = AttributeMethods.forAnnotationType(annotationType);
/*  905 */     if (!methods.hasDefaultValueMethod()) {
/*  906 */       return Collections.emptyMap();
/*      */     }
/*  908 */     Map<String, DefaultValueHolder> result = CollectionUtils.newLinkedHashMap(methods.size());
/*  909 */     if (!methods.hasNestedAnnotation()) {
/*      */       
/*  911 */       for (int i = 0; i < methods.size(); i++) {
/*  912 */         Method method = methods.get(i);
/*  913 */         Object defaultValue = method.getDefaultValue();
/*  914 */         if (defaultValue != null) {
/*  915 */           result.put(method.getName(), new DefaultValueHolder(defaultValue));
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  922 */       AnnotationAttributes attributes = (AnnotationAttributes)MergedAnnotation.<Annotation>of(annotationType).asMap(annotation -> new AnnotationAttributes(annotation.getType(), true), new MergedAnnotation.Adapt[] { MergedAnnotation.Adapt.ANNOTATION_TO_MAP });
/*      */       
/*  924 */       for (Map.Entry<String, Object> element : attributes.entrySet()) {
/*  925 */         result.put(element.getKey(), new DefaultValueHolder(element.getValue()));
/*      */       }
/*      */     } 
/*  928 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void postProcessAnnotationAttributes(@Nullable Object annotatedElement, @Nullable AnnotationAttributes attributes, boolean classValuesAsString) {
/*  950 */     if (attributes == null) {
/*      */       return;
/*      */     }
/*  953 */     if (!attributes.validated) {
/*  954 */       Class<? extends Annotation> annotationType = attributes.annotationType();
/*  955 */       if (annotationType == null) {
/*      */         return;
/*      */       }
/*  958 */       AnnotationTypeMapping mapping = AnnotationTypeMappings.forAnnotationType(annotationType).get(0);
/*  959 */       for (int i = 0; i < mapping.getMirrorSets().size(); i++) {
/*  960 */         AnnotationTypeMapping.MirrorSets.MirrorSet mirrorSet = mapping.getMirrorSets().get(i);
/*  961 */         int resolved = mirrorSet.resolve(attributes.displayName, attributes, AnnotationUtils::getAttributeValueForMirrorResolution);
/*      */         
/*  963 */         if (resolved != -1) {
/*  964 */           Method attribute = mapping.getAttributes().get(resolved);
/*  965 */           Object value = attributes.get(attribute.getName());
/*  966 */           for (int j = 0; j < mirrorSet.size(); j++) {
/*  967 */             Method mirror = mirrorSet.get(j);
/*  968 */             if (mirror != attribute) {
/*  969 */               attributes.put(mirror.getName(), 
/*  970 */                   adaptValue(annotatedElement, value, classValuesAsString));
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  976 */     for (Map.Entry<String, Object> attributeEntry : attributes.entrySet()) {
/*  977 */       String attributeName = attributeEntry.getKey();
/*  978 */       Object value = attributeEntry.getValue();
/*  979 */       if (value instanceof DefaultValueHolder) { DefaultValueHolder defaultValueHolder = (DefaultValueHolder)value;
/*  980 */         value = defaultValueHolder.defaultValue;
/*  981 */         attributes.put(attributeName, 
/*  982 */             adaptValue(annotatedElement, value, classValuesAsString)); }
/*      */     
/*      */     } 
/*      */   }
/*      */   @Nullable
/*      */   private static Object getAttributeValueForMirrorResolution(Method attribute, @Nullable Object attributes) {
/*      */     AnnotationAttributes annotationAttributes;
/*  989 */     if (attributes instanceof AnnotationAttributes) { annotationAttributes = (AnnotationAttributes)attributes; }
/*  990 */     else { return null; }
/*      */     
/*  992 */     Object result = annotationAttributes.get(attribute.getName());
/*  993 */     DefaultValueHolder defaultValueHolder = (DefaultValueHolder)result; return (result instanceof DefaultValueHolder) ? defaultValueHolder.defaultValue : result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private static Object adaptValue(@Nullable Object annotatedElement, @Nullable Object value, boolean classValuesAsString) {
/* 1000 */     if (classValuesAsString) {
/* 1001 */       if (value instanceof Class) { Class<?> clazz = (Class)value;
/* 1002 */         return clazz.getName(); }
/*      */       
/* 1004 */       if (value instanceof Class[]) { Class<?>[] classes = (Class[])value;
/* 1005 */         String[] names = new String[classes.length];
/* 1006 */         for (int i = 0; i < classes.length; i++) {
/* 1007 */           names[i] = classes[i].getName();
/*      */         }
/* 1009 */         return names; }
/*      */     
/*      */     } 
/* 1012 */     if (value instanceof Annotation) { Annotation annotation = (Annotation)value;
/* 1013 */       return MergedAnnotation.<Annotation>from(annotatedElement, annotation).synthesize(); }
/*      */     
/* 1015 */     if (value instanceof Annotation[]) { Annotation[] annotations = (Annotation[])value;
/* 1016 */       Annotation[] synthesized = (Annotation[])Array.newInstance(annotations
/* 1017 */           .getClass().componentType(), annotations.length);
/* 1018 */       for (int i = 0; i < annotations.length; i++) {
/* 1019 */         synthesized[i] = MergedAnnotation.<Annotation>from(annotatedElement, annotations[i]).synthesize();
/*      */       }
/* 1021 */       return synthesized; }
/*      */     
/* 1023 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static Object getValue(Annotation annotation) {
/* 1037 */     return getValue(annotation, "value");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static Object getValue(@Nullable Annotation annotation, @Nullable String attributeName) {
/* 1051 */     if (annotation == null || !StringUtils.hasText(attributeName)) {
/* 1052 */       return null;
/*      */     }
/*      */     try {
/* 1055 */       for (Method method : annotation.annotationType().getDeclaredMethods()) {
/* 1056 */         if (method.getName().equals(attributeName) && method.getParameterCount() == 0) {
/* 1057 */           return invokeAnnotationMethod(method, annotation);
/*      */         }
/*      */       }
/*      */     
/* 1061 */     } catch (Throwable ex) {
/* 1062 */       handleValueRetrievalFailure(annotation, ex);
/*      */     } 
/* 1064 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   static Object invokeAnnotationMethod(Method method, @Nullable Object annotation) {
/* 1080 */     if (annotation == null) {
/* 1081 */       return null;
/*      */     }
/* 1083 */     if (Proxy.isProxyClass(annotation.getClass())) {
/*      */       try {
/* 1085 */         InvocationHandler handler = Proxy.getInvocationHandler(annotation);
/* 1086 */         return handler.invoke(annotation, method, null);
/*      */       }
/* 1088 */       catch (Throwable throwable) {}
/*      */     }
/*      */ 
/*      */     
/* 1092 */     return ReflectionUtils.invokeMethod(method, annotation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void rethrowAnnotationConfigurationException(Throwable ex) {
/* 1103 */     if (ex instanceof AnnotationConfigurationException) { AnnotationConfigurationException exception = (AnnotationConfigurationException)ex;
/* 1104 */       throw exception; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void handleIntrospectionFailure(AnnotatedElement element, Throwable ex) {
/* 1124 */     rethrowAnnotationConfigurationException(ex);
/* 1125 */     IntrospectionFailureLogger logger = IntrospectionFailureLogger.INFO;
/* 1126 */     boolean meta = false;
/* 1127 */     if (element instanceof Class) { Class<?> clazz = (Class)element; if (Annotation.class.isAssignableFrom(clazz)) {
/*      */         
/* 1129 */         logger = IntrospectionFailureLogger.DEBUG;
/* 1130 */         meta = true;
/*      */       }  }
/* 1132 */      if (logger.isEnabled()) {
/* 1133 */       logger.log("Failed to " + (meta ? "meta-introspect annotation " : "introspect annotations on ") + String.valueOf(element) + ": " + String.valueOf(ex));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void handleValueRetrievalFailure(Annotation annotation, Throwable ex) {
/* 1145 */     rethrowAnnotationConfigurationException(ex);
/* 1146 */     IntrospectionFailureLogger logger = IntrospectionFailureLogger.INFO;
/* 1147 */     if (logger.isEnabled()) {
/* 1148 */       logger.log("Failed to retrieve value from " + String.valueOf(annotation) + ": " + String.valueOf(ex));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static Object getDefaultValue(Annotation annotation) {
/* 1161 */     return getDefaultValue(annotation, "value");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static Object getDefaultValue(@Nullable Annotation annotation, @Nullable String attributeName) {
/* 1173 */     return (annotation != null) ? getDefaultValue(annotation.annotationType(), attributeName) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static Object getDefaultValue(Class<? extends Annotation> annotationType) {
/* 1185 */     return getDefaultValue(annotationType, "value");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static Object getDefaultValue(@Nullable Class<? extends Annotation> annotationType, @Nullable String attributeName) {
/* 1200 */     if (annotationType == null || !StringUtils.hasText(attributeName)) {
/* 1201 */       return null;
/*      */     }
/* 1203 */     return MergedAnnotation.<Annotation>of(annotationType).getDefaultValue(attributeName).orElse(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <A extends Annotation> A synthesizeAnnotation(A annotation, @Nullable AnnotatedElement annotatedElement) {
/* 1226 */     if (isSynthesizedAnnotation((Annotation)annotation) || AnnotationFilter.PLAIN.matches((Annotation)annotation)) {
/* 1227 */       return annotation;
/*      */     }
/* 1229 */     return MergedAnnotation.<A>from(annotatedElement, annotation).synthesize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <A extends Annotation> A synthesizeAnnotation(Class<A> annotationType) {
/* 1248 */     return synthesizeAnnotation(Collections.emptyMap(), annotationType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <A extends Annotation> A synthesizeAnnotation(Map<String, Object> attributes, Class<A> annotationType, @Nullable AnnotatedElement annotatedElement) {
/*      */     try {
/* 1284 */       return MergedAnnotation.<A>of(annotatedElement, annotationType, attributes).synthesize();
/*      */     }
/* 1286 */     catch (NoSuchElementException|IllegalStateException ex) {
/* 1287 */       throw new IllegalArgumentException(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Annotation[] synthesizeAnnotationArray(Annotation[] annotations, AnnotatedElement annotatedElement) {
/* 1309 */     if (AnnotationsScanner.hasPlainJavaAnnotationsOnly(annotatedElement)) {
/* 1310 */       return annotations;
/*      */     }
/* 1312 */     Annotation[] synthesized = (Annotation[])Array.newInstance(annotations
/* 1313 */         .getClass().componentType(), annotations.length);
/* 1314 */     for (int i = 0; i < annotations.length; i++) {
/* 1315 */       synthesized[i] = synthesizeAnnotation(annotations[i], annotatedElement);
/*      */     }
/* 1317 */     return synthesized;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSynthesizedAnnotation(@Nullable Annotation annotation) {
/*      */     try {
/* 1330 */       return (annotation != null && Proxy.isProxyClass(annotation.getClass()) && 
/* 1331 */         Proxy.getInvocationHandler(annotation) instanceof SynthesizedMergedAnnotationInvocationHandler);
/*      */     }
/* 1333 */     catch (SecurityException ex) {
/*      */ 
/*      */       
/* 1336 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clearCache() {
/* 1345 */     AnnotationTypeMappings.clearCache();
/* 1346 */     AnnotationsScanner.clearCache();
/* 1347 */     AttributeMethods.cache.clear();
/* 1348 */     RepeatableContainers.cache.clear();
/* 1349 */     OrderUtils.orderCache.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class DefaultValueHolder
/*      */   {
/*      */     final Object defaultValue;
/*      */ 
/*      */ 
/*      */     
/*      */     public DefaultValueHolder(Object defaultValue) {
/* 1361 */       this.defaultValue = defaultValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1366 */       return "*" + String.valueOf(this.defaultValue);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */