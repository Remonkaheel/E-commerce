/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FirstRunOfPredicate<A extends Annotation>
/*     */   implements Predicate<MergedAnnotation<A>>
/*     */ {
/*     */   private final Function<? super MergedAnnotation<A>, ?> valueExtractor;
/*     */   private boolean hasLastValue;
/*     */   @Nullable
/*     */   private Object lastValue;
/*     */   
/*     */   FirstRunOfPredicate(Function<? super MergedAnnotation<A>, ?> valueExtractor) {
/* 132 */     Assert.notNull(valueExtractor, "Value extractor must not be null");
/* 133 */     this.valueExtractor = valueExtractor;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean test(@Nullable MergedAnnotation<A> annotation) {
/* 138 */     if (!this.hasLastValue) {
/* 139 */       this.hasLastValue = true;
/* 140 */       this.lastValue = this.valueExtractor.apply(annotation);
/*     */     } 
/* 142 */     Object value = this.valueExtractor.apply(annotation);
/* 143 */     return ObjectUtils.nullSafeEquals(value, this.lastValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\MergedAnnotationPredicates$FirstRunOfPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */