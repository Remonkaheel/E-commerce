/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedMethod
/*     */ {
/*     */   private final Method method;
/*     */   private final Method bridgedMethod;
/*     */   private final MethodParameter[] parameters;
/*     */   @Nullable
/*     */   private volatile List<Annotation[][]> inheritedParameterAnnotations;
/*     */   
/*     */   public AnnotatedMethod(Method method) {
/*  66 */     Assert.notNull(method, "Method is required");
/*  67 */     this.method = method;
/*  68 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  69 */     ReflectionUtils.makeAccessible(this.bridgedMethod);
/*  70 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedMethod(AnnotatedMethod annotatedMethod) {
/*  77 */     Assert.notNull(annotatedMethod, "AnnotatedMethod is required");
/*  78 */     this.method = annotatedMethod.method;
/*  79 */     this.bridgedMethod = annotatedMethod.bridgedMethod;
/*  80 */     this.parameters = annotatedMethod.parameters;
/*  81 */     this.inheritedParameterAnnotations = annotatedMethod.inheritedParameterAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Method getMethod() {
/*  89 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Method getBridgedMethod() {
/*  97 */     return this.bridgedMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getContainingClass() {
/* 105 */     return this.method.getDeclaringClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MethodParameter[] getMethodParameters() {
/* 112 */     return this.parameters;
/*     */   }
/*     */   
/*     */   private MethodParameter[] initMethodParameters() {
/* 116 */     int count = this.bridgedMethod.getParameterCount();
/* 117 */     MethodParameter[] result = new MethodParameter[count];
/* 118 */     for (int i = 0; i < count; i++) {
/* 119 */       result[i] = new AnnotatedMethodParameter(i);
/*     */     }
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodParameter getReturnType() {
/* 128 */     return new AnnotatedMethodParameter(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodParameter getReturnValueType(@Nullable Object returnValue) {
/* 135 */     return new ReturnValueMethodParameter(returnValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVoid() {
/* 142 */     return (getReturnType().getParameterType() == void.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType) {
/* 155 */     return AnnotatedElementUtils.findMergedAnnotation(this.method, annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> boolean hasMethodAnnotation(Class<A> annotationType) {
/* 165 */     return AnnotatedElementUtils.hasAnnotation(this.method, annotationType);
/*     */   }
/*     */   
/*     */   private List<Annotation[][]> getInheritedParameterAnnotations() {
/* 169 */     List<Annotation[][]> parameterAnnotations = this.inheritedParameterAnnotations;
/* 170 */     if (parameterAnnotations == null) {
/* 171 */       parameterAnnotations = (List)new ArrayList<>();
/* 172 */       Class<?> clazz = this.method.getDeclaringClass();
/* 173 */       while (clazz != null) {
/* 174 */         for (Class<?> ifc : clazz.getInterfaces()) {
/* 175 */           for (Method candidate : ifc.getMethods()) {
/* 176 */             if (isOverrideFor(candidate)) {
/* 177 */               parameterAnnotations.add(candidate.getParameterAnnotations());
/*     */             }
/*     */           } 
/*     */         } 
/* 181 */         clazz = clazz.getSuperclass();
/* 182 */         if (clazz == Object.class) {
/* 183 */           clazz = null;
/*     */         }
/* 185 */         if (clazz != null) {
/* 186 */           for (Method candidate : clazz.getDeclaredMethods()) {
/* 187 */             if (isOverrideFor(candidate)) {
/* 188 */               parameterAnnotations.add(candidate.getParameterAnnotations());
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/* 193 */       this.inheritedParameterAnnotations = parameterAnnotations;
/*     */     } 
/* 195 */     return parameterAnnotations;
/*     */   }
/*     */   
/*     */   private boolean isOverrideFor(Method candidate) {
/* 199 */     if (Modifier.isPrivate(candidate.getModifiers()) || 
/* 200 */       !candidate.getName().equals(this.method.getName()) || candidate
/* 201 */       .getParameterCount() != this.method.getParameterCount()) {
/* 202 */       return false;
/*     */     }
/* 204 */     Class<?>[] paramTypes = this.method.getParameterTypes();
/* 205 */     if (Arrays.equals((Object[])candidate.getParameterTypes(), (Object[])paramTypes)) {
/* 206 */       return true;
/*     */     }
/* 208 */     for (int i = 0; i < paramTypes.length; i++) {
/* 209 */       if (paramTypes[i] != 
/* 210 */         ResolvableType.forMethodParameter(candidate, i, this.method.getDeclaringClass()).toClass()) {
/* 211 */         return false;
/*     */       }
/*     */     } 
/* 214 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 220 */     if (this != other) { if (other instanceof AnnotatedMethod) { AnnotatedMethod otherHandlerMethod = (AnnotatedMethod)other; if (this.method
/* 221 */           .equals(otherHandlerMethod.method)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 226 */     return this.method.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 231 */     return this.method.toGenericString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected static Object findProvidedArgument(MethodParameter parameter, @Nullable Object... providedArgs) {
/* 239 */     if (!ObjectUtils.isEmpty(providedArgs)) {
/* 240 */       for (Object providedArg : providedArgs) {
/* 241 */         if (parameter.getParameterType().isInstance(providedArg)) {
/* 242 */           return providedArg;
/*     */         }
/*     */       } 
/*     */     }
/* 246 */     return null;
/*     */   }
/*     */   
/*     */   protected static String formatArgumentError(MethodParameter param, String message) {
/* 250 */     return "Could not resolve parameter [" + param.getParameterIndex() + "] in " + param
/* 251 */       .getExecutable().toGenericString() + (StringUtils.hasText(message) ? (": " + message) : "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected class AnnotatedMethodParameter
/*     */     extends SynthesizingMethodParameter
/*     */   {
/*     */     @Nullable
/*     */     private volatile Annotation[] combinedAnnotations;
/*     */ 
/*     */     
/*     */     public AnnotatedMethodParameter(int index) {
/* 264 */       super(AnnotatedMethod.this.getBridgedMethod(), index);
/*     */     }
/*     */     
/*     */     protected AnnotatedMethodParameter(AnnotatedMethodParameter original) {
/* 268 */       super(original);
/* 269 */       this.combinedAnnotations = original.combinedAnnotations;
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Method getMethod() {
/* 275 */       return AnnotatedMethod.this.getBridgedMethod();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getContainingClass() {
/* 280 */       return AnnotatedMethod.this.getContainingClass();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType) {
/* 286 */       return AnnotatedMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T extends Annotation> boolean hasMethodAnnotation(Class<T> annotationType) {
/* 291 */       return AnnotatedMethod.this.hasMethodAnnotation(annotationType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Annotation[] getParameterAnnotations() {
/* 296 */       Annotation[] anns = this.combinedAnnotations;
/* 297 */       if (anns == null) {
/* 298 */         anns = super.getParameterAnnotations();
/* 299 */         int index = getParameterIndex();
/* 300 */         if (index >= 0) {
/* 301 */           for (Annotation[][] ifcAnns : AnnotatedMethod.this.getInheritedParameterAnnotations()) {
/* 302 */             if (index < ifcAnns.length) {
/* 303 */               Annotation[] paramAnns = ifcAnns[index];
/* 304 */               if (paramAnns.length > 0) {
/* 305 */                 List<Annotation> merged = new ArrayList<>(anns.length + paramAnns.length);
/* 306 */                 merged.addAll(Arrays.asList(anns));
/* 307 */                 for (Annotation paramAnn : paramAnns) {
/* 308 */                   boolean existingType = false;
/* 309 */                   for (Annotation ann : anns) {
/* 310 */                     if (ann.annotationType() == paramAnn.annotationType()) {
/* 311 */                       existingType = true;
/*     */                       break;
/*     */                     } 
/*     */                   } 
/* 315 */                   if (!existingType) {
/* 316 */                     merged.add(adaptAnnotation(paramAnn));
/*     */                   }
/*     */                 } 
/* 319 */                 anns = merged.<Annotation>toArray(new Annotation[0]);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/* 324 */         this.combinedAnnotations = anns;
/*     */       } 
/* 326 */       return anns;
/*     */     }
/*     */ 
/*     */     
/*     */     public AnnotatedMethodParameter clone() {
/* 331 */       return new AnnotatedMethodParameter(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class ReturnValueMethodParameter
/*     */     extends AnnotatedMethodParameter
/*     */   {
/*     */     @Nullable
/*     */     private final Class<?> returnValueType;
/*     */ 
/*     */     
/*     */     public ReturnValueMethodParameter(Object returnValue) {
/* 345 */       super(-1);
/* 346 */       this.returnValueType = (returnValue != null) ? returnValue.getClass() : null;
/*     */     }
/*     */     
/*     */     protected ReturnValueMethodParameter(ReturnValueMethodParameter original) {
/* 350 */       super(original);
/* 351 */       this.returnValueType = original.returnValueType;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getParameterType() {
/* 356 */       return (this.returnValueType != null) ? this.returnValueType : super.getParameterType();
/*     */     }
/*     */ 
/*     */     
/*     */     public ReturnValueMethodParameter clone() {
/* 361 */       return new ReturnValueMethodParameter(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotatedMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */