/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Spliterator;
/*     */ import java.util.Spliterators;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TypeMappedAnnotations
/*     */   implements MergedAnnotations
/*     */ {
/*  47 */   static final MergedAnnotations NONE = new TypeMappedAnnotations(null, new Annotation[0], 
/*  48 */       RepeatableContainers.none(), AnnotationFilter.ALL);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Object source;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final AnnotatedElement element;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final MergedAnnotations.SearchStrategy searchStrategy;
/*     */ 
/*     */   
/*     */   private final Predicate<Class<?>> searchEnclosingClass;
/*     */   
/*     */   @Nullable
/*     */   private final Annotation[] annotations;
/*     */   
/*     */   private final RepeatableContainers repeatableContainers;
/*     */   
/*     */   private final AnnotationFilter annotationFilter;
/*     */   
/*     */   @Nullable
/*     */   private volatile List<Aggregate> aggregates;
/*     */ 
/*     */   
/*     */   private TypeMappedAnnotations(AnnotatedElement element, MergedAnnotations.SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/*  77 */     this.source = element;
/*  78 */     this.element = element;
/*  79 */     this.searchStrategy = searchStrategy;
/*  80 */     this.searchEnclosingClass = searchEnclosingClass;
/*  81 */     this.annotations = null;
/*  82 */     this.repeatableContainers = repeatableContainers;
/*  83 */     this.annotationFilter = annotationFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeMappedAnnotations(@Nullable Object source, Annotation[] annotations, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/*  89 */     this.source = source;
/*  90 */     this.element = null;
/*  91 */     this.searchStrategy = null;
/*  92 */     this.searchEnclosingClass = MergedAnnotations.Search.never;
/*  93 */     this.annotations = annotations;
/*  94 */     this.repeatableContainers = repeatableContainers;
/*  95 */     this.annotationFilter = annotationFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> boolean isPresent(Class<A> annotationType) {
/* 101 */     if (this.annotationFilter.matches(annotationType)) {
/* 102 */       return false;
/*     */     }
/* 104 */     return Boolean.TRUE.equals(scan(annotationType, 
/* 105 */           IsPresent.get(this.repeatableContainers, this.annotationFilter, false)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPresent(String annotationType) {
/* 110 */     if (this.annotationFilter.matches(annotationType)) {
/* 111 */       return false;
/*     */     }
/* 113 */     return Boolean.TRUE.equals(scan(annotationType, 
/* 114 */           IsPresent.get(this.repeatableContainers, this.annotationFilter, false)));
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> boolean isDirectlyPresent(Class<A> annotationType) {
/* 119 */     if (this.annotationFilter.matches(annotationType)) {
/* 120 */       return false;
/*     */     }
/* 122 */     return Boolean.TRUE.equals(scan(annotationType, 
/* 123 */           IsPresent.get(this.repeatableContainers, this.annotationFilter, true)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirectlyPresent(String annotationType) {
/* 128 */     if (this.annotationFilter.matches(annotationType)) {
/* 129 */       return false;
/*     */     }
/* 131 */     return Boolean.TRUE.equals(scan(annotationType, 
/* 132 */           IsPresent.get(this.repeatableContainers, this.annotationFilter, true)));
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(Class<A> annotationType) {
/* 137 */     return get(annotationType, (Predicate<? super MergedAnnotation<A>>)null, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(Class<A> annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate) {
/* 144 */     return get(annotationType, predicate, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(Class<A> annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate, @Nullable MergedAnnotationSelector<A> selector) {
/* 152 */     if (this.annotationFilter.matches(annotationType)) {
/* 153 */       return MergedAnnotation.missing();
/*     */     }
/* 155 */     MergedAnnotation<A> result = scan(annotationType, (AnnotationsProcessor)new MergedAnnotationFinder<>(annotationType, predicate, selector));
/*     */     
/* 157 */     return (result != null) ? result : MergedAnnotation.<A>missing();
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(String annotationType) {
/* 162 */     return get(annotationType, (Predicate<? super MergedAnnotation<A>>)null, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(String annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate) {
/* 169 */     return get(annotationType, predicate, (MergedAnnotationSelector<A>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> MergedAnnotation<A> get(String annotationType, @Nullable Predicate<? super MergedAnnotation<A>> predicate, @Nullable MergedAnnotationSelector<A> selector) {
/* 177 */     if (this.annotationFilter.matches(annotationType)) {
/* 178 */       return MergedAnnotation.missing();
/*     */     }
/* 180 */     MergedAnnotation<A> result = scan(annotationType, (AnnotationsProcessor)new MergedAnnotationFinder<>(annotationType, predicate, selector));
/*     */     
/* 182 */     return (result != null) ? result : MergedAnnotation.<A>missing();
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> Stream<MergedAnnotation<A>> stream(Class<A> annotationType) {
/* 187 */     if (this.annotationFilter == AnnotationFilter.ALL) {
/* 188 */       return Stream.empty();
/*     */     }
/* 190 */     return StreamSupport.stream(spliterator(annotationType), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> Stream<MergedAnnotation<A>> stream(String annotationType) {
/* 195 */     if (this.annotationFilter == AnnotationFilter.ALL) {
/* 196 */       return Stream.empty();
/*     */     }
/* 198 */     return StreamSupport.stream(spliterator(annotationType), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<MergedAnnotation<Annotation>> stream() {
/* 203 */     if (this.annotationFilter == AnnotationFilter.ALL) {
/* 204 */       return Stream.empty();
/*     */     }
/* 206 */     return StreamSupport.stream(spliterator(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<MergedAnnotation<Annotation>> iterator() {
/* 211 */     if (this.annotationFilter == AnnotationFilter.ALL) {
/* 212 */       return Collections.emptyIterator();
/*     */     }
/* 214 */     return Spliterators.iterator(spliterator());
/*     */   }
/*     */ 
/*     */   
/*     */   public Spliterator<MergedAnnotation<Annotation>> spliterator() {
/* 219 */     if (this.annotationFilter == AnnotationFilter.ALL) {
/* 220 */       return Spliterators.emptySpliterator();
/*     */     }
/* 222 */     return spliterator(null);
/*     */   }
/*     */   
/*     */   private <A extends Annotation> Spliterator<MergedAnnotation<A>> spliterator(@Nullable Object annotationType) {
/* 226 */     return new AggregatesSpliterator<>(annotationType, getAggregates());
/*     */   }
/*     */   
/*     */   private List<Aggregate> getAggregates() {
/* 230 */     List<Aggregate> aggregates = this.aggregates;
/* 231 */     if (aggregates == null) {
/* 232 */       aggregates = scan(this, new AggregatesCollector());
/* 233 */       if (aggregates == null || aggregates.isEmpty()) {
/* 234 */         aggregates = Collections.emptyList();
/*     */       }
/* 236 */       this.aggregates = aggregates;
/*     */     } 
/* 238 */     return aggregates;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private <C, R> R scan(C criteria, AnnotationsProcessor<C, R> processor) {
/* 243 */     if (this.annotations != null) {
/* 244 */       R result = processor.doWithAnnotations(criteria, 0, this.source, this.annotations);
/* 245 */       return processor.finish(result);
/*     */     } 
/* 247 */     if (this.element != null && this.searchStrategy != null) {
/* 248 */       return AnnotationsScanner.scan(criteria, this.element, this.searchStrategy, this.searchEnclosingClass, processor);
/*     */     }
/*     */     
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(AnnotatedElement element, MergedAnnotations.SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/* 259 */     if (AnnotationsScanner.isKnownEmpty(element, searchStrategy, searchEnclosingClass)) {
/* 260 */       return NONE;
/*     */     }
/* 262 */     return new TypeMappedAnnotations(element, searchStrategy, searchEnclosingClass, repeatableContainers, annotationFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(@Nullable Object source, Annotation[] annotations, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/* 268 */     if (annotations.length == 0) {
/* 269 */       return NONE;
/*     */     }
/* 271 */     return new TypeMappedAnnotations(source, annotations, repeatableContainers, annotationFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isMappingForType(AnnotationTypeMapping mapping, AnnotationFilter annotationFilter, @Nullable Object requiredType) {
/* 277 */     Class<? extends Annotation> actualType = mapping.getAnnotationType();
/* 278 */     return (!annotationFilter.matches(actualType) && (requiredType == null || actualType == requiredType || actualType
/* 279 */       .getName().equals(requiredType)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class IsPresent
/*     */     implements AnnotationsProcessor<Object, Boolean>
/*     */   {
/* 295 */     private static final IsPresent[] SHARED = new IsPresent[4]; static {
/* 296 */       SHARED[0] = new IsPresent(RepeatableContainers.none(), AnnotationFilter.PLAIN, true);
/* 297 */       SHARED[1] = new IsPresent(RepeatableContainers.none(), AnnotationFilter.PLAIN, false);
/* 298 */       SHARED[2] = new IsPresent(RepeatableContainers.standardRepeatables(), AnnotationFilter.PLAIN, true);
/* 299 */       SHARED[3] = new IsPresent(RepeatableContainers.standardRepeatables(), AnnotationFilter.PLAIN, false);
/*     */     }
/*     */ 
/*     */     
/*     */     private final RepeatableContainers repeatableContainers;
/*     */     
/*     */     private final AnnotationFilter annotationFilter;
/*     */     
/*     */     private final boolean directOnly;
/*     */ 
/*     */     
/*     */     private IsPresent(RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter, boolean directOnly) {
/* 311 */       this.repeatableContainers = repeatableContainers;
/* 312 */       this.annotationFilter = annotationFilter;
/* 313 */       this.directOnly = directOnly;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Boolean doWithAnnotations(Object requiredType, int aggregateIndex, @Nullable Object source, Annotation[] annotations) {
/* 321 */       for (Annotation annotation : annotations) {
/* 322 */         if (annotation != null) {
/* 323 */           Class<? extends Annotation> type = annotation.annotationType();
/* 324 */           if (type != null && !this.annotationFilter.matches(type)) {
/* 325 */             if (type == requiredType || type.getName().equals(requiredType)) {
/* 326 */               return Boolean.TRUE;
/*     */             }
/*     */             
/* 329 */             Annotation[] repeatedAnnotations = this.repeatableContainers.findRepeatedAnnotations(annotation);
/* 330 */             if (repeatedAnnotations != null) {
/* 331 */               Boolean result = doWithAnnotations(requiredType, aggregateIndex, source, repeatedAnnotations);
/*     */               
/* 333 */               if (result != null) {
/* 334 */                 return result;
/*     */               }
/*     */             } 
/* 337 */             if (!this.directOnly) {
/* 338 */               AnnotationTypeMappings mappings = AnnotationTypeMappings.forAnnotationType(type);
/* 339 */               for (int i = 0; i < mappings.size(); i++) {
/* 340 */                 AnnotationTypeMapping mapping = mappings.get(i);
/* 341 */                 if (TypeMappedAnnotations.isMappingForType(mapping, this.annotationFilter, requiredType)) {
/* 342 */                   return Boolean.TRUE;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 349 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static IsPresent get(RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter, boolean directOnly) {
/* 356 */       if (annotationFilter == AnnotationFilter.PLAIN) {
/* 357 */         if (repeatableContainers == RepeatableContainers.none()) {
/* 358 */           return SHARED[directOnly ? 0 : 1];
/*     */         }
/* 360 */         if (repeatableContainers == RepeatableContainers.standardRepeatables()) {
/* 361 */           return SHARED[directOnly ? 2 : 3];
/*     */         }
/*     */       } 
/* 364 */       return new IsPresent(repeatableContainers, annotationFilter, directOnly);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class MergedAnnotationFinder<A extends Annotation>
/*     */     implements AnnotationsProcessor<Object, MergedAnnotation<A>>
/*     */   {
/*     */     private final Object requiredType;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Predicate<? super MergedAnnotation<A>> predicate;
/*     */ 
/*     */     
/*     */     private final MergedAnnotationSelector<A> selector;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private MergedAnnotation<A> result;
/*     */ 
/*     */     
/*     */     MergedAnnotationFinder(@Nullable Object requiredType, @Nullable Predicate<? super MergedAnnotation<A>> predicate, MergedAnnotationSelector<A> selector) {
/* 388 */       this.requiredType = requiredType;
/* 389 */       this.predicate = predicate;
/* 390 */       this.selector = (selector != null) ? selector : MergedAnnotationSelectors.<A>nearest();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public MergedAnnotation<A> doWithAggregate(Object context, int aggregateIndex) {
/* 396 */       return this.result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public MergedAnnotation<A> doWithAnnotations(Object type, int aggregateIndex, @Nullable Object source, Annotation[] annotations) {
/* 404 */       for (Annotation annotation : annotations) {
/* 405 */         if (annotation != null && !TypeMappedAnnotations.this.annotationFilter.matches(annotation)) {
/* 406 */           MergedAnnotation<A> result = process(type, aggregateIndex, source, annotation);
/* 407 */           if (result != null) {
/* 408 */             return result;
/*     */           }
/*     */         } 
/*     */       } 
/* 412 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private MergedAnnotation<A> process(Object type, int aggregateIndex, @Nullable Object source, Annotation annotation) {
/* 419 */       Annotation[] repeatedAnnotations = TypeMappedAnnotations.this.repeatableContainers.findRepeatedAnnotations(annotation);
/* 420 */       if (repeatedAnnotations != null) {
/* 421 */         MergedAnnotation<A> result = doWithAnnotations(type, aggregateIndex, source, repeatedAnnotations);
/* 422 */         if (result != null) {
/* 423 */           return result;
/*     */         }
/*     */       } 
/* 426 */       AnnotationTypeMappings mappings = AnnotationTypeMappings.forAnnotationType(annotation
/* 427 */           .annotationType(), TypeMappedAnnotations.this.repeatableContainers, TypeMappedAnnotations.this.annotationFilter);
/* 428 */       for (int i = 0; i < mappings.size(); i++) {
/* 429 */         AnnotationTypeMapping mapping = mappings.get(i);
/* 430 */         if (TypeMappedAnnotations.isMappingForType(mapping, TypeMappedAnnotations.this.annotationFilter, this.requiredType)) {
/* 431 */           MergedAnnotation<A> candidate = TypeMappedAnnotation.createIfPossible(mapping, source, annotation, aggregateIndex, IntrospectionFailureLogger.INFO);
/*     */           
/* 433 */           if (candidate != null && (this.predicate == null || this.predicate.test(candidate))) {
/* 434 */             if (this.selector.isBestCandidate(candidate)) {
/* 435 */               return candidate;
/*     */             }
/* 437 */             updateLastResult(candidate);
/*     */           } 
/*     */         } 
/*     */       } 
/* 441 */       return null;
/*     */     }
/*     */     
/*     */     private void updateLastResult(MergedAnnotation<A> candidate) {
/* 445 */       MergedAnnotation<A> lastResult = this.result;
/* 446 */       this.result = (lastResult != null) ? this.selector.select(lastResult, candidate) : candidate;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public MergedAnnotation<A> finish(@Nullable MergedAnnotation<A> result) {
/* 452 */       return (result != null) ? result : this.result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class AggregatesCollector
/*     */     implements AnnotationsProcessor<Object, List<Aggregate>>
/*     */   {
/* 462 */     private final List<TypeMappedAnnotations.Aggregate> aggregates = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public List<TypeMappedAnnotations.Aggregate> doWithAnnotations(Object criteria, int aggregateIndex, @Nullable Object source, Annotation[] annotations) {
/* 469 */       this.aggregates.add(createAggregate(aggregateIndex, source, annotations));
/* 470 */       return null;
/*     */     }
/*     */     
/*     */     private TypeMappedAnnotations.Aggregate createAggregate(int aggregateIndex, @Nullable Object source, Annotation[] annotations) {
/* 474 */       List<Annotation> aggregateAnnotations = getAggregateAnnotations(annotations);
/* 475 */       return new TypeMappedAnnotations.Aggregate(aggregateIndex, source, aggregateAnnotations);
/*     */     }
/*     */     
/*     */     private List<Annotation> getAggregateAnnotations(Annotation[] annotations) {
/* 479 */       List<Annotation> result = new ArrayList<>(annotations.length);
/* 480 */       addAggregateAnnotations(result, annotations);
/* 481 */       return result;
/*     */     }
/*     */     
/*     */     private void addAggregateAnnotations(List<Annotation> aggregateAnnotations, Annotation[] annotations) {
/* 485 */       for (Annotation annotation : annotations) {
/* 486 */         if (annotation != null && !TypeMappedAnnotations.this.annotationFilter.matches(annotation)) {
/* 487 */           Annotation[] repeatedAnnotations = TypeMappedAnnotations.this.repeatableContainers.findRepeatedAnnotations(annotation);
/* 488 */           if (repeatedAnnotations != null) {
/* 489 */             addAggregateAnnotations(aggregateAnnotations, repeatedAnnotations);
/*     */           } else {
/*     */             
/* 492 */             aggregateAnnotations.add(annotation);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public List<TypeMappedAnnotations.Aggregate> finish(@Nullable List<TypeMappedAnnotations.Aggregate> processResult) {
/* 500 */       return this.aggregates;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Aggregate
/*     */   {
/*     */     private final int aggregateIndex;
/*     */     
/*     */     @Nullable
/*     */     private final Object source;
/*     */     
/*     */     private final List<Annotation> annotations;
/*     */     
/*     */     private final AnnotationTypeMappings[] mappings;
/*     */     
/*     */     Aggregate(int aggregateIndex, @Nullable Object source, List<Annotation> annotations) {
/* 517 */       this.aggregateIndex = aggregateIndex;
/* 518 */       this.source = source;
/* 519 */       this.annotations = annotations;
/* 520 */       this.mappings = new AnnotationTypeMappings[annotations.size()];
/* 521 */       for (int i = 0; i < annotations.size(); i++) {
/* 522 */         this.mappings[i] = AnnotationTypeMappings.forAnnotationType(((Annotation)annotations.get(i)).annotationType());
/*     */       }
/*     */     }
/*     */     
/*     */     int size() {
/* 527 */       return this.annotations.size();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     AnnotationTypeMapping getMapping(int annotationIndex, int mappingIndex) {
/* 532 */       AnnotationTypeMappings mappings = getMappings(annotationIndex);
/* 533 */       return (mappingIndex < mappings.size()) ? mappings.get(mappingIndex) : null;
/*     */     }
/*     */     
/*     */     AnnotationTypeMappings getMappings(int annotationIndex) {
/* 537 */       return this.mappings[annotationIndex];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     <A extends Annotation> MergedAnnotation<A> createMergedAnnotationIfPossible(int annotationIndex, int mappingIndex, IntrospectionFailureLogger logger) {
/* 544 */       return TypeMappedAnnotation.createIfPossible(this.mappings[annotationIndex]
/* 545 */           .get(mappingIndex), this.source, this.annotations
/* 546 */           .get(annotationIndex), this.aggregateIndex, logger);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class AggregatesSpliterator<A extends Annotation>
/*     */     implements Spliterator<MergedAnnotation<A>>
/*     */   {
/*     */     @Nullable
/*     */     private final Object requiredType;
/*     */ 
/*     */     
/*     */     private final List<TypeMappedAnnotations.Aggregate> aggregates;
/*     */     
/*     */     private int aggregateCursor;
/*     */     
/*     */     @Nullable
/*     */     private int[] mappingCursors;
/*     */ 
/*     */     
/*     */     AggregatesSpliterator(Object requiredType, List<TypeMappedAnnotations.Aggregate> aggregates) {
/* 568 */       this.requiredType = requiredType;
/* 569 */       this.aggregates = aggregates;
/* 570 */       this.aggregateCursor = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryAdvance(Consumer<? super MergedAnnotation<A>> action) {
/* 575 */       while (this.aggregateCursor < this.aggregates.size()) {
/* 576 */         TypeMappedAnnotations.Aggregate aggregate = this.aggregates.get(this.aggregateCursor);
/* 577 */         if (tryAdvance(aggregate, action)) {
/* 578 */           return true;
/*     */         }
/* 580 */         this.aggregateCursor++;
/* 581 */         this.mappingCursors = null;
/*     */       } 
/* 583 */       return false;
/*     */     }
/*     */     
/*     */     private boolean tryAdvance(TypeMappedAnnotations.Aggregate aggregate, Consumer<? super MergedAnnotation<A>> action) {
/* 587 */       if (this.mappingCursors == null) {
/* 588 */         this.mappingCursors = new int[aggregate.size()];
/*     */       }
/* 590 */       int lowestDistance = Integer.MAX_VALUE;
/* 591 */       int annotationResult = -1;
/* 592 */       for (int annotationIndex = 0; annotationIndex < aggregate.size(); annotationIndex++) {
/* 593 */         AnnotationTypeMapping mapping = getNextSuitableMapping(aggregate, annotationIndex);
/* 594 */         if (mapping != null && mapping.getDistance() < lowestDistance) {
/* 595 */           annotationResult = annotationIndex;
/* 596 */           lowestDistance = mapping.getDistance();
/*     */         } 
/* 598 */         if (lowestDistance == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/* 602 */       if (annotationResult != -1) {
/* 603 */         MergedAnnotation<A> mergedAnnotation = aggregate.createMergedAnnotationIfPossible(annotationResult, this.mappingCursors[annotationResult], 
/*     */             
/* 605 */             (this.requiredType != null) ? IntrospectionFailureLogger.INFO : IntrospectionFailureLogger.DEBUG);
/* 606 */         this.mappingCursors[annotationResult] = this.mappingCursors[annotationResult] + 1;
/* 607 */         if (mergedAnnotation == null) {
/* 608 */           return tryAdvance(aggregate, action);
/*     */         }
/* 610 */         action.accept(mergedAnnotation);
/* 611 */         return true;
/*     */       } 
/* 613 */       return false;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private AnnotationTypeMapping getNextSuitableMapping(TypeMappedAnnotations.Aggregate aggregate, int annotationIndex) {
/* 618 */       int[] cursors = this.mappingCursors;
/* 619 */       if (cursors != null) {
/*     */         AnnotationTypeMapping mapping;
/*     */         do {
/* 622 */           mapping = aggregate.getMapping(annotationIndex, cursors[annotationIndex]);
/* 623 */           if (mapping != null && TypeMappedAnnotations.isMappingForType(mapping, TypeMappedAnnotations.this.annotationFilter, this.requiredType)) {
/* 624 */             return mapping;
/*     */           }
/* 626 */           cursors[annotationIndex] = cursors[annotationIndex] + 1;
/*     */         }
/* 628 */         while (mapping != null);
/*     */       } 
/* 630 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Spliterator<MergedAnnotation<A>> trySplit() {
/* 636 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public long estimateSize() {
/* 641 */       int size = 0;
/* 642 */       int aggregateIndex = this.aggregateCursor;
/* 643 */       for (; aggregateIndex < this.aggregates.size(); aggregateIndex++) {
/* 644 */         TypeMappedAnnotations.Aggregate aggregate = this.aggregates.get(aggregateIndex);
/* 645 */         for (int annotationIndex = 0; annotationIndex < aggregate.size(); annotationIndex++) {
/* 646 */           AnnotationTypeMappings mappings = aggregate.getMappings(annotationIndex);
/* 647 */           int numberOfMappings = mappings.size();
/* 648 */           if (aggregateIndex == this.aggregateCursor && this.mappingCursors != null) {
/* 649 */             numberOfMappings -= Math.min(this.mappingCursors[annotationIndex], mappings.size());
/*     */           }
/* 651 */           size += numberOfMappings;
/*     */         } 
/*     */       } 
/* 654 */       return size;
/*     */     }
/*     */ 
/*     */     
/*     */     public int characteristics() {
/* 659 */       return 1280;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\TypeMappedAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */