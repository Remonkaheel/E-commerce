/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Repeatable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StandardRepeatableContainers
/*     */   extends RepeatableContainers
/*     */ {
/* 149 */   private static final Object NONE = new Object();
/*     */   
/* 151 */   private static final StandardRepeatableContainers INSTANCE = new StandardRepeatableContainers();
/*     */   
/*     */   StandardRepeatableContainers() {
/* 154 */     super(null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Annotation[] findRepeatedAnnotations(Annotation annotation) {
/* 160 */     Method method = getRepeatedAnnotationsMethod(annotation.annotationType());
/* 161 */     if (method != null) {
/* 162 */       return (Annotation[])AnnotationUtils.invokeAnnotationMethod(method, annotation);
/*     */     }
/* 164 */     return super.findRepeatedAnnotations(annotation);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static Method getRepeatedAnnotationsMethod(Class<? extends Annotation> annotationType) {
/* 169 */     Object result = cache.computeIfAbsent(annotationType, StandardRepeatableContainers::computeRepeatedAnnotationsMethod);
/*     */     
/* 171 */     return (result != NONE) ? (Method)result : null;
/*     */   }
/*     */   
/*     */   private static Object computeRepeatedAnnotationsMethod(Class<? extends Annotation> annotationType) {
/* 175 */     AttributeMethods methods = AttributeMethods.forAnnotationType(annotationType);
/* 176 */     Method method = methods.get("value");
/* 177 */     if (method != null) {
/* 178 */       Class<?> returnType = method.getReturnType();
/* 179 */       if (returnType.isArray()) {
/* 180 */         Class<?> componentType = returnType.componentType();
/* 181 */         if (Annotation.class.isAssignableFrom(componentType) && componentType
/* 182 */           .isAnnotationPresent((Class)Repeatable.class)) {
/* 183 */           return method;
/*     */         }
/*     */       } 
/*     */     } 
/* 187 */     return NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\RepeatableContainers$StandardRepeatableContainers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */