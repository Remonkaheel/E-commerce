/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedMethodParameter
/*     */   extends SynthesizingMethodParameter
/*     */ {
/*     */   @Nullable
/*     */   private volatile Annotation[] combinedAnnotations;
/*     */   
/*     */   public AnnotatedMethodParameter(int index) {
/* 264 */     super(AnnotatedMethod.this.getBridgedMethod(), index);
/*     */   }
/*     */   
/*     */   protected AnnotatedMethodParameter(AnnotatedMethodParameter original) {
/* 268 */     super(original);
/* 269 */     this.combinedAnnotations = original.combinedAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Method getMethod() {
/* 275 */     return AnnotatedMethod.this.getBridgedMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getContainingClass() {
/* 280 */     return AnnotatedMethod.this.getContainingClass();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType) {
/* 286 */     return AnnotatedMethod.this.getMethodAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Annotation> boolean hasMethodAnnotation(Class<T> annotationType) {
/* 291 */     return AnnotatedMethod.this.hasMethodAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getParameterAnnotations() {
/* 296 */     Annotation[] anns = this.combinedAnnotations;
/* 297 */     if (anns == null) {
/* 298 */       anns = super.getParameterAnnotations();
/* 299 */       int index = getParameterIndex();
/* 300 */       if (index >= 0) {
/* 301 */         for (Annotation[][] ifcAnns : AnnotatedMethod.this.getInheritedParameterAnnotations()) {
/* 302 */           if (index < ifcAnns.length) {
/* 303 */             Annotation[] paramAnns = ifcAnns[index];
/* 304 */             if (paramAnns.length > 0) {
/* 305 */               List<Annotation> merged = new ArrayList<>(anns.length + paramAnns.length);
/* 306 */               merged.addAll(Arrays.asList(anns));
/* 307 */               for (Annotation paramAnn : paramAnns) {
/* 308 */                 boolean existingType = false;
/* 309 */                 for (Annotation ann : anns) {
/* 310 */                   if (ann.annotationType() == paramAnn.annotationType()) {
/* 311 */                     existingType = true;
/*     */                     break;
/*     */                   } 
/*     */                 } 
/* 315 */                 if (!existingType) {
/* 316 */                   merged.add(adaptAnnotation(paramAnn));
/*     */                 }
/*     */               } 
/* 319 */               anns = merged.<Annotation>toArray(new Annotation[0]);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/* 324 */       this.combinedAnnotations = anns;
/*     */     } 
/* 326 */     return anns;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMethodParameter clone() {
/* 331 */     return new AnnotatedMethodParameter(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotatedMethod$AnnotatedMethodParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */