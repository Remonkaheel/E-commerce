/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TypeMappedAnnotation<A extends Annotation>
/*     */   extends AbstractMergedAnnotation<A>
/*     */ {
/*  71 */   private static final Map<Class<?>, Object> EMPTY_ARRAYS = Map.of(boolean.class, new boolean[0], byte.class, new byte[0], char.class, new char[0], double.class, new double[0], float.class, new float[0], int.class, new int[0], long.class, new long[0], short.class, new short[0], String.class, new String[0]);
/*     */ 
/*     */ 
/*     */   
/*     */   private final AnnotationTypeMapping mapping;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final ClassLoader classLoader;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Object source;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Object rootAttributes;
/*     */ 
/*     */   
/*     */   private final ValueExtractor valueExtractor;
/*     */ 
/*     */   
/*     */   private final int aggregateIndex;
/*     */ 
/*     */   
/*     */   private final boolean useMergedValues;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Predicate<String> attributeFilter;
/*     */ 
/*     */   
/*     */   private final int[] resolvedRootMirrors;
/*     */ 
/*     */   
/*     */   private final int[] resolvedMirrors;
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeMappedAnnotation(AnnotationTypeMapping mapping, @Nullable ClassLoader classLoader, @Nullable Object source, @Nullable Object rootAttributes, ValueExtractor valueExtractor, int aggregateIndex) {
/* 112 */     this(mapping, classLoader, source, rootAttributes, valueExtractor, aggregateIndex, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeMappedAnnotation(AnnotationTypeMapping mapping, @Nullable ClassLoader classLoader, @Nullable Object source, @Nullable Object rootAttributes, ValueExtractor valueExtractor, int aggregateIndex, @Nullable int[] resolvedRootMirrors) {
/* 119 */     this.mapping = mapping;
/* 120 */     this.classLoader = classLoader;
/* 121 */     this.source = source;
/* 122 */     this.rootAttributes = rootAttributes;
/* 123 */     this.valueExtractor = valueExtractor;
/* 124 */     this.aggregateIndex = aggregateIndex;
/* 125 */     this.useMergedValues = true;
/* 126 */     this.attributeFilter = null;
/* 127 */     this
/* 128 */       .resolvedRootMirrors = (resolvedRootMirrors != null) ? resolvedRootMirrors : mapping.getRoot().getMirrorSets().resolve(source, rootAttributes, this.valueExtractor);
/* 129 */     this
/* 130 */       .resolvedMirrors = (getDistance() == 0) ? this.resolvedRootMirrors : mapping.getMirrorSets().resolve(source, this, this::getValueForMirrorResolution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeMappedAnnotation(AnnotationTypeMapping mapping, @Nullable ClassLoader classLoader, @Nullable Object source, @Nullable Object rootAnnotation, ValueExtractor valueExtractor, int aggregateIndex, boolean useMergedValues, @Nullable Predicate<String> attributeFilter, int[] resolvedRootMirrors, int[] resolvedMirrors) {
/* 138 */     this.classLoader = classLoader;
/* 139 */     this.source = source;
/* 140 */     this.rootAttributes = rootAnnotation;
/* 141 */     this.valueExtractor = valueExtractor;
/* 142 */     this.mapping = mapping;
/* 143 */     this.aggregateIndex = aggregateIndex;
/* 144 */     this.useMergedValues = useMergedValues;
/* 145 */     this.attributeFilter = attributeFilter;
/* 146 */     this.resolvedRootMirrors = resolvedRootMirrors;
/* 147 */     this.resolvedMirrors = resolvedMirrors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<A> getType() {
/* 154 */     return (Class)this.mapping.getAnnotationType();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Class<? extends Annotation>> getMetaTypes() {
/* 159 */     return this.mapping.getMetaTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPresent() {
/* 164 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDistance() {
/* 169 */     return this.mapping.getDistance();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAggregateIndex() {
/* 174 */     return this.aggregateIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/* 180 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MergedAnnotation<?> getMetaSource() {
/* 186 */     AnnotationTypeMapping metaSourceMapping = this.mapping.getSource();
/* 187 */     if (metaSourceMapping == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     return new TypeMappedAnnotation(metaSourceMapping, this.classLoader, this.source, this.rootAttributes, this.valueExtractor, this.aggregateIndex, this.resolvedRootMirrors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MergedAnnotation<?> getRoot() {
/* 196 */     if (getDistance() == 0) {
/* 197 */       return this;
/*     */     }
/* 199 */     AnnotationTypeMapping rootMapping = this.mapping.getRoot();
/* 200 */     return new TypeMappedAnnotation(rootMapping, this.classLoader, this.source, this.rootAttributes, this.valueExtractor, this.aggregateIndex, this.resolvedRootMirrors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDefaultValue(String attributeName) {
/* 206 */     int attributeIndex = getAttributeIndex(attributeName, true);
/* 207 */     Object value = getValue(attributeIndex, true, false);
/* 208 */     return (value == null || this.mapping.isEquivalentToDefaultValue(attributeIndex, value, this.valueExtractor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> MergedAnnotation<T> getAnnotation(String attributeName, Class<T> type) throws NoSuchElementException {
/* 216 */     int attributeIndex = getAttributeIndex(attributeName, true);
/* 217 */     Method attribute = this.mapping.getAttributes().get(attributeIndex);
/* 218 */     Assert.notNull(type, "Type must not be null");
/* 219 */     Assert.isAssignable(type, attribute.getReturnType(), () -> "Attribute " + attributeName + " type mismatch:");
/*     */     
/* 221 */     return (MergedAnnotation<T>)getRequiredValue(attributeIndex, attributeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> MergedAnnotation<T>[] getAnnotationArray(String attributeName, Class<T> type) throws NoSuchElementException {
/* 229 */     int attributeIndex = getAttributeIndex(attributeName, true);
/* 230 */     Method attribute = this.mapping.getAttributes().get(attributeIndex);
/* 231 */     Class<?> componentType = attribute.getReturnType().componentType();
/* 232 */     Assert.notNull(type, "Type must not be null");
/* 233 */     Assert.notNull(componentType, () -> "Attribute " + attributeName + " is not an array");
/* 234 */     Assert.isAssignable(type, componentType, () -> "Attribute " + attributeName + " component type mismatch:");
/* 235 */     return (MergedAnnotation<T>[])getRequiredValue(attributeIndex, attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<T> getDefaultValue(String attributeName, Class<T> type) {
/* 240 */     int attributeIndex = getAttributeIndex(attributeName, false);
/* 241 */     if (attributeIndex == -1) {
/* 242 */       return Optional.empty();
/*     */     }
/* 244 */     Method attribute = this.mapping.getAttributes().get(attributeIndex);
/* 245 */     return Optional.ofNullable(adapt(attribute, attribute.getDefaultValue(), type));
/*     */   }
/*     */ 
/*     */   
/*     */   public MergedAnnotation<A> filterAttributes(Predicate<String> predicate) {
/* 250 */     if (this.attributeFilter != null) {
/* 251 */       predicate = this.attributeFilter.and(predicate);
/*     */     }
/* 253 */     return new TypeMappedAnnotation(this.mapping, this.classLoader, this.source, this.rootAttributes, this.valueExtractor, this.aggregateIndex, this.useMergedValues, predicate, this.resolvedRootMirrors, this.resolvedMirrors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MergedAnnotation<A> withNonMergedAttributes() {
/* 260 */     return new TypeMappedAnnotation(this.mapping, this.classLoader, this.source, this.rootAttributes, this.valueExtractor, this.aggregateIndex, false, this.attributeFilter, this.resolvedRootMirrors, this.resolvedMirrors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> asMap(MergedAnnotation.Adapt... adaptations) {
/* 267 */     return Collections.unmodifiableMap(asMap(mergedAnnotation -> new LinkedHashMap<>(), adaptations));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Map<String, Object>> T asMap(Function<MergedAnnotation<?>, T> factory, MergedAnnotation.Adapt... adaptations) {
/* 272 */     Map<String, Object> map = (Map)factory.apply(this);
/* 273 */     Assert.state((map != null), "Factory used to create MergedAnnotation Map must not return null");
/* 274 */     AttributeMethods attributes = this.mapping.getAttributes();
/* 275 */     for (int i = 0; i < attributes.size(); i++) {
/* 276 */       Method attribute = attributes.get(i);
/*     */       
/* 278 */       Object value = isFiltered(attribute.getName()) ? null : getValue(i, getTypeForMapOptions(attribute, adaptations));
/* 279 */       if (value != null) {
/* 280 */         map.put(attribute.getName(), 
/* 281 */             adaptValueForMapOptions(attribute, value, map.getClass(), factory, adaptations));
/*     */       }
/*     */     } 
/* 284 */     return (T)map;
/*     */   }
/*     */   
/*     */   private Class<?> getTypeForMapOptions(Method attribute, MergedAnnotation.Adapt[] adaptations) {
/* 288 */     Class<?> attributeType = attribute.getReturnType();
/* 289 */     Class<?> componentType = attributeType.isArray() ? attributeType.componentType() : attributeType;
/* 290 */     if (MergedAnnotation.Adapt.CLASS_TO_STRING.isIn(adaptations) && componentType == Class.class) {
/* 291 */       return attributeType.isArray() ? String[].class : String.class;
/*     */     }
/* 293 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends Map<String, Object>> Object adaptValueForMapOptions(Method attribute, Object value, Class<?> mapType, Function<MergedAnnotation<?>, T> factory, MergedAnnotation.Adapt[] adaptations) {
/* 299 */     if (value instanceof MergedAnnotation) { MergedAnnotation<?> annotation = (MergedAnnotation)value;
/* 300 */       return MergedAnnotation.Adapt.ANNOTATION_TO_MAP.isIn(adaptations) ? 
/* 301 */         annotation.<T>asMap(factory, adaptations) : annotation.synthesize(); }
/*     */     
/* 303 */     if (value instanceof MergedAnnotation[]) { MergedAnnotation[] arrayOfMergedAnnotation = (MergedAnnotation[])value;
/* 304 */       if (MergedAnnotation.Adapt.ANNOTATION_TO_MAP.isIn(adaptations)) {
/* 305 */         Object object = Array.newInstance(mapType, arrayOfMergedAnnotation.length);
/* 306 */         for (int j = 0; j < arrayOfMergedAnnotation.length; j++) {
/* 307 */           Array.set(object, j, arrayOfMergedAnnotation[j].asMap(factory, adaptations));
/*     */         }
/* 309 */         return object;
/*     */       } 
/* 311 */       Object result = Array.newInstance(attribute
/* 312 */           .getReturnType().componentType(), arrayOfMergedAnnotation.length);
/* 313 */       for (int i = 0; i < arrayOfMergedAnnotation.length; i++) {
/* 314 */         Array.set(result, i, arrayOfMergedAnnotation[i].synthesize());
/*     */       }
/* 316 */       return result; }
/*     */     
/* 318 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected A createSynthesizedAnnotation() {
/* 325 */     Object object = this.rootAttributes; if (object instanceof Annotation) { Annotation ann = (Annotation)object; if (isTargetAnnotation(ann) && !isSynthesizable(ann)) {
/* 326 */         return (A)ann;
/*     */       } }
/*     */     
/* 329 */     Annotation meta = this.mapping.getAnnotation();
/* 330 */     if (meta != null && isTargetAnnotation(meta) && !isSynthesizable(meta)) {
/* 331 */       return (A)meta;
/*     */     }
/* 333 */     return SynthesizedMergedAnnotationInvocationHandler.createProxy(this, getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isTargetAnnotation(Object obj) {
/* 343 */     return getType().isInstance(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSynthesizable(Annotation annotation) {
/* 356 */     if (AnnotationUtils.isSynthesizedAnnotation(annotation)) {
/* 357 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 361 */     if (getDistance() > 0 && this.resolvedMirrors.length > 0) {
/* 362 */       return true;
/*     */     }
/*     */     
/* 365 */     return this.mapping.isSynthesizable();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <T> T getAttributeValue(String attributeName, Class<T> type) {
/* 371 */     int attributeIndex = getAttributeIndex(attributeName, false);
/* 372 */     return (attributeIndex != -1) ? getValue(attributeIndex, type) : null;
/*     */   }
/*     */   
/*     */   private Object getRequiredValue(int attributeIndex, String attributeName) {
/* 376 */     Object value = getValue(attributeIndex, Object.class);
/* 377 */     if (value == null) {
/* 378 */       throw new NoSuchElementException("No element at attribute index " + attributeIndex + " for name " + attributeName);
/*     */     }
/*     */     
/* 381 */     return value;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private <T> T getValue(int attributeIndex, Class<T> type) {
/* 386 */     Method attribute = this.mapping.getAttributes().get(attributeIndex);
/* 387 */     Object value = getValue(attributeIndex, true, false);
/* 388 */     if (value == null) {
/* 389 */       value = attribute.getDefaultValue();
/*     */     }
/* 391 */     return adapt(attribute, value, type);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getValue(int attributeIndex, boolean useConventionMapping, boolean forMirrorResolution) {
/* 396 */     AnnotationTypeMapping mapping = this.mapping;
/* 397 */     if (this.useMergedValues) {
/* 398 */       int mappedIndex = this.mapping.getAliasMapping(attributeIndex);
/* 399 */       if (mappedIndex == -1 && useConventionMapping) {
/* 400 */         mappedIndex = this.mapping.getConventionMapping(attributeIndex);
/*     */       }
/* 402 */       if (mappedIndex != -1) {
/* 403 */         mapping = mapping.getRoot();
/* 404 */         attributeIndex = mappedIndex;
/*     */       } 
/*     */     } 
/* 407 */     if (!forMirrorResolution)
/*     */     {
/* 409 */       attributeIndex = ((mapping.getDistance() != 0) ? this.resolvedMirrors : this.resolvedRootMirrors)[attributeIndex];
/*     */     }
/* 411 */     if (attributeIndex == -1) {
/* 412 */       return null;
/*     */     }
/* 414 */     if (mapping.getDistance() == 0) {
/* 415 */       Method attribute = mapping.getAttributes().get(attributeIndex);
/* 416 */       Object result = this.valueExtractor.extract(attribute, this.rootAttributes);
/* 417 */       return (result != null) ? result : attribute.getDefaultValue();
/*     */     } 
/* 419 */     return getValueFromMetaAnnotation(attributeIndex, forMirrorResolution);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getValueFromMetaAnnotation(int attributeIndex, boolean forMirrorResolution) {
/* 424 */     Object value = null;
/* 425 */     if (this.useMergedValues || forMirrorResolution) {
/* 426 */       value = this.mapping.getMappedAnnotationValue(attributeIndex, forMirrorResolution);
/*     */     }
/* 428 */     if (value == null) {
/* 429 */       Method attribute = this.mapping.getAttributes().get(attributeIndex);
/* 430 */       value = AnnotationUtils.invokeAnnotationMethod(attribute, this.mapping.getAnnotation());
/*     */     } 
/* 432 */     return value;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getValueForMirrorResolution(Method attribute, @Nullable Object annotation) {
/* 437 */     int attributeIndex = this.mapping.getAttributes().indexOf(attribute);
/* 438 */     boolean valueAttribute = "value".equals(attribute.getName());
/* 439 */     return getValue(attributeIndex, !valueAttribute, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private <T> T adapt(Method attribute, @Nullable Object value, Class<T> type) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: ifnonnull -> 6
/*     */     //   4: aconst_null
/*     */     //   5: areturn
/*     */     //   6: aload_0
/*     */     //   7: aload_1
/*     */     //   8: aload_2
/*     */     //   9: invokevirtual adaptForAttribute : (Ljava/lang/reflect/Method;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   12: astore_2
/*     */     //   13: aload_0
/*     */     //   14: aload_1
/*     */     //   15: aload_3
/*     */     //   16: invokevirtual getAdaptType : (Ljava/lang/reflect/Method;Ljava/lang/Class;)Ljava/lang/Class;
/*     */     //   19: astore_3
/*     */     //   20: aload_2
/*     */     //   21: instanceof java/lang/Class
/*     */     //   24: ifeq -> 48
/*     */     //   27: aload_2
/*     */     //   28: checkcast java/lang/Class
/*     */     //   31: astore #4
/*     */     //   33: aload_3
/*     */     //   34: ldc java/lang/String
/*     */     //   36: if_acmpne -> 48
/*     */     //   39: aload #4
/*     */     //   41: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   44: astore_2
/*     */     //   45: goto -> 321
/*     */     //   48: aload_2
/*     */     //   49: instanceof java/lang/String
/*     */     //   52: ifeq -> 80
/*     */     //   55: aload_2
/*     */     //   56: checkcast java/lang/String
/*     */     //   59: astore #5
/*     */     //   61: aload_3
/*     */     //   62: ldc java/lang/Class
/*     */     //   64: if_acmpne -> 80
/*     */     //   67: aload #5
/*     */     //   69: aload_0
/*     */     //   70: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
/*     */     //   73: invokestatic resolveClassName : (Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;
/*     */     //   76: astore_2
/*     */     //   77: goto -> 321
/*     */     //   80: aload_2
/*     */     //   81: instanceof [Ljava/lang/Class;
/*     */     //   84: ifeq -> 143
/*     */     //   87: aload_2
/*     */     //   88: checkcast [Ljava/lang/Class;
/*     */     //   91: astore #6
/*     */     //   93: aload_3
/*     */     //   94: ldc [Ljava/lang/String;
/*     */     //   96: if_acmpne -> 143
/*     */     //   99: aload #6
/*     */     //   101: arraylength
/*     */     //   102: anewarray java/lang/String
/*     */     //   105: astore #10
/*     */     //   107: iconst_0
/*     */     //   108: istore #11
/*     */     //   110: iload #11
/*     */     //   112: aload #6
/*     */     //   114: arraylength
/*     */     //   115: if_icmpge -> 137
/*     */     //   118: aload #10
/*     */     //   120: iload #11
/*     */     //   122: aload #6
/*     */     //   124: iload #11
/*     */     //   126: aaload
/*     */     //   127: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   130: aastore
/*     */     //   131: iinc #11, 1
/*     */     //   134: goto -> 110
/*     */     //   137: aload #10
/*     */     //   139: astore_2
/*     */     //   140: goto -> 321
/*     */     //   143: aload_2
/*     */     //   144: instanceof [Ljava/lang/String;
/*     */     //   147: ifeq -> 211
/*     */     //   150: aload_2
/*     */     //   151: checkcast [Ljava/lang/String;
/*     */     //   154: astore #7
/*     */     //   156: aload_3
/*     */     //   157: ldc_w [Ljava/lang/Class;
/*     */     //   160: if_acmpne -> 211
/*     */     //   163: aload #7
/*     */     //   165: arraylength
/*     */     //   166: anewarray java/lang/Class
/*     */     //   169: astore #10
/*     */     //   171: iconst_0
/*     */     //   172: istore #11
/*     */     //   174: iload #11
/*     */     //   176: aload #7
/*     */     //   178: arraylength
/*     */     //   179: if_icmpge -> 205
/*     */     //   182: aload #10
/*     */     //   184: iload #11
/*     */     //   186: aload #7
/*     */     //   188: iload #11
/*     */     //   190: aaload
/*     */     //   191: aload_0
/*     */     //   192: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
/*     */     //   195: invokestatic resolveClassName : (Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;
/*     */     //   198: aastore
/*     */     //   199: iinc #11, 1
/*     */     //   202: goto -> 174
/*     */     //   205: aload #10
/*     */     //   207: astore_2
/*     */     //   208: goto -> 321
/*     */     //   211: aload_2
/*     */     //   212: instanceof org/springframework/core/annotation/MergedAnnotation
/*     */     //   215: ifeq -> 242
/*     */     //   218: aload_2
/*     */     //   219: checkcast org/springframework/core/annotation/MergedAnnotation
/*     */     //   222: astore #8
/*     */     //   224: aload_3
/*     */     //   225: invokevirtual isAnnotation : ()Z
/*     */     //   228: ifeq -> 242
/*     */     //   231: aload #8
/*     */     //   233: invokeinterface synthesize : ()Ljava/lang/annotation/Annotation;
/*     */     //   238: astore_2
/*     */     //   239: goto -> 321
/*     */     //   242: aload_2
/*     */     //   243: instanceof [Lorg/springframework/core/annotation/MergedAnnotation;
/*     */     //   246: ifeq -> 321
/*     */     //   249: aload_2
/*     */     //   250: checkcast [Lorg/springframework/core/annotation/MergedAnnotation;
/*     */     //   253: astore #9
/*     */     //   255: aload_3
/*     */     //   256: invokevirtual isArray : ()Z
/*     */     //   259: ifeq -> 321
/*     */     //   262: aload_3
/*     */     //   263: invokevirtual componentType : ()Ljava/lang/Class;
/*     */     //   266: invokevirtual isAnnotation : ()Z
/*     */     //   269: ifeq -> 321
/*     */     //   272: aload_3
/*     */     //   273: invokevirtual componentType : ()Ljava/lang/Class;
/*     */     //   276: aload #9
/*     */     //   278: arraylength
/*     */     //   279: invokestatic newInstance : (Ljava/lang/Class;I)Ljava/lang/Object;
/*     */     //   282: astore #10
/*     */     //   284: iconst_0
/*     */     //   285: istore #11
/*     */     //   287: iload #11
/*     */     //   289: aload #9
/*     */     //   291: arraylength
/*     */     //   292: if_icmpge -> 318
/*     */     //   295: aload #10
/*     */     //   297: iload #11
/*     */     //   299: aload #9
/*     */     //   301: iload #11
/*     */     //   303: aaload
/*     */     //   304: invokeinterface synthesize : ()Ljava/lang/annotation/Annotation;
/*     */     //   309: invokestatic set : (Ljava/lang/Object;ILjava/lang/Object;)V
/*     */     //   312: iinc #11, 1
/*     */     //   315: goto -> 287
/*     */     //   318: aload #10
/*     */     //   320: astore_2
/*     */     //   321: aload_3
/*     */     //   322: aload_2
/*     */     //   323: invokevirtual isInstance : (Ljava/lang/Object;)Z
/*     */     //   326: ifne -> 353
/*     */     //   329: new java/lang/IllegalArgumentException
/*     */     //   332: dup
/*     */     //   333: aload_2
/*     */     //   334: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   337: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   340: aload_3
/*     */     //   341: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   344: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   349: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   352: athrow
/*     */     //   353: aload_2
/*     */     //   354: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #445	-> 0
/*     */     //   #446	-> 4
/*     */     //   #448	-> 6
/*     */     //   #449	-> 13
/*     */     //   #450	-> 20
/*     */     //   #451	-> 39
/*     */     //   #453	-> 48
/*     */     //   #454	-> 67
/*     */     //   #456	-> 80
/*     */     //   #457	-> 99
/*     */     //   #458	-> 107
/*     */     //   #459	-> 118
/*     */     //   #458	-> 131
/*     */     //   #461	-> 137
/*     */     //   #462	-> 140
/*     */     //   #463	-> 143
/*     */     //   #464	-> 163
/*     */     //   #465	-> 171
/*     */     //   #466	-> 182
/*     */     //   #465	-> 199
/*     */     //   #468	-> 205
/*     */     //   #469	-> 208
/*     */     //   #470	-> 211
/*     */     //   #471	-> 231
/*     */     //   #473	-> 242
/*     */     //   #474	-> 256
/*     */     //   #475	-> 272
/*     */     //   #476	-> 284
/*     */     //   #477	-> 295
/*     */     //   #476	-> 312
/*     */     //   #479	-> 318
/*     */     //   #481	-> 321
/*     */     //   #482	-> 329
/*     */     //   #483	-> 334
/*     */     //   #485	-> 353
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   33	15	4	clazz	Ljava/lang/Class;
/*     */     //   61	19	5	str	Ljava/lang/String;
/*     */     //   110	27	11	i	I
/*     */     //   107	33	10	names	[Ljava/lang/String;
/*     */     //   93	50	6	classes	[Ljava/lang/Class;
/*     */     //   174	31	11	i	I
/*     */     //   171	37	10	classes	[Ljava/lang/Class;
/*     */     //   156	55	7	names	[Ljava/lang/String;
/*     */     //   224	18	8	annotation	Lorg/springframework/core/annotation/MergedAnnotation;
/*     */     //   287	31	11	i	I
/*     */     //   284	37	10	array	Ljava/lang/Object;
/*     */     //   255	66	9	annotations	[Lorg/springframework/core/annotation/MergedAnnotation;
/*     */     //   0	355	0	this	Lorg/springframework/core/annotation/TypeMappedAnnotation;
/*     */     //   0	355	1	attribute	Ljava/lang/reflect/Method;
/*     */     //   0	355	2	value	Ljava/lang/Object;
/*     */     //   0	355	3	type	Ljava/lang/Class;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   33	15	4	clazz	Ljava/lang/Class<*>;
/*     */     //   93	50	6	classes	[Ljava/lang/Class<*>;
/*     */     //   171	37	10	classes	[Ljava/lang/Class<*>;
/*     */     //   224	18	8	annotation	Lorg/springframework/core/annotation/MergedAnnotation<*>;
/*     */     //   255	66	9	annotations	[Lorg/springframework/core/annotation/MergedAnnotation<*>;
/*     */     //   0	355	0	this	Lorg/springframework/core/annotation/TypeMappedAnnotation<TA;>;
/*     */     //   0	355	3	type	Ljava/lang/Class<TT;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object adaptForAttribute(Method attribute, Object value) {
/* 490 */     Class<?> attributeType = ClassUtils.resolvePrimitiveIfNecessary(attribute.getReturnType());
/* 491 */     if (attributeType.isArray() && !value.getClass().isArray()) {
/* 492 */       Object array = Array.newInstance(value.getClass(), 1);
/* 493 */       Array.set(array, 0, value);
/* 494 */       return adaptForAttribute(attribute, array);
/*     */     } 
/* 496 */     if (attributeType.isAnnotation()) {
/* 497 */       return adaptToMergedAnnotation(value, (Class)attributeType);
/*     */     }
/* 499 */     if (attributeType.isArray() && attributeType.componentType().isAnnotation()) {
/* 500 */       MergedAnnotation[] arrayOfMergedAnnotation = new MergedAnnotation[Array.getLength(value)];
/* 501 */       for (int i = 0; i < arrayOfMergedAnnotation.length; i++) {
/* 502 */         arrayOfMergedAnnotation[i] = adaptToMergedAnnotation(Array.get(value, i), (Class)attributeType
/* 503 */             .componentType());
/*     */       }
/* 505 */       return arrayOfMergedAnnotation;
/*     */     } 
/* 507 */     if ((attributeType == Class.class && value instanceof String) || (attributeType == Class[].class && value instanceof String[]) || (attributeType == String.class && value instanceof Class) || (attributeType == String[].class && value instanceof Class[]))
/*     */     {
/*     */ 
/*     */       
/* 511 */       return value;
/*     */     }
/* 513 */     if (attributeType.isArray() && isEmptyObjectArray(value)) {
/* 514 */       return emptyArray(attributeType.componentType());
/*     */     }
/* 516 */     if (!attributeType.isInstance(value)) {
/* 517 */       throw new IllegalStateException("Attribute '" + attribute.getName() + "' in annotation " + 
/* 518 */           getType().getName() + " should be compatible with " + attributeType
/* 519 */           .getName() + " but a " + value.getClass().getName() + " value was returned");
/*     */     }
/*     */     
/* 522 */     return value;
/*     */   }
/*     */   
/*     */   private boolean isEmptyObjectArray(Object value) {
/* 526 */     if (value instanceof Object[]) { Object[] objects = (Object[])value; if (objects.length == 0); }  return false;
/*     */   }
/*     */   
/*     */   private Object emptyArray(Class<?> componentType) {
/* 530 */     Object result = EMPTY_ARRAYS.get(componentType);
/* 531 */     if (result == null) {
/* 532 */       result = Array.newInstance(componentType, 0);
/*     */     }
/* 534 */     return result;
/*     */   }
/*     */   
/*     */   private MergedAnnotation<?> adaptToMergedAnnotation(Object value, Class<? extends Annotation> annotationType) {
/* 538 */     if (value instanceof MergedAnnotation) { MergedAnnotation<?> mergedAnnotation = (MergedAnnotation)value;
/* 539 */       return mergedAnnotation; }
/*     */     
/* 541 */     AnnotationTypeMapping mapping = AnnotationTypeMappings.forAnnotationType(annotationType).get(0);
/* 542 */     return new TypeMappedAnnotation(mapping, null, this.source, value, 
/* 543 */         getValueExtractor(value), this.aggregateIndex);
/*     */   }
/*     */   
/*     */   private ValueExtractor getValueExtractor(Object value) {
/* 547 */     if (value instanceof Annotation) {
/* 548 */       return AnnotationUtils::invokeAnnotationMethod;
/*     */     }
/* 550 */     if (value instanceof Map) {
/* 551 */       return TypeMappedAnnotation::extractFromMap;
/*     */     }
/* 553 */     return this.valueExtractor;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Class<T> getAdaptType(Method attribute, Class<T> type) {
/* 558 */     if (type != Object.class) {
/* 559 */       return type;
/*     */     }
/* 561 */     Class<?> attributeType = attribute.getReturnType();
/* 562 */     if (attributeType.isAnnotation()) {
/* 563 */       return (Class)MergedAnnotation.class;
/*     */     }
/* 565 */     if (attributeType.isArray() && attributeType.componentType().isAnnotation()) {
/* 566 */       return (Class)MergedAnnotation[].class;
/*     */     }
/* 568 */     return ClassUtils.resolvePrimitiveIfNecessary(attributeType);
/*     */   }
/*     */   
/*     */   private int getAttributeIndex(String attributeName, boolean required) {
/* 572 */     Assert.hasText(attributeName, "Attribute name must not be null");
/* 573 */     int attributeIndex = isFiltered(attributeName) ? -1 : this.mapping.getAttributes().indexOf(attributeName);
/* 574 */     if (attributeIndex == -1 && required) {
/* 575 */       throw new NoSuchElementException("No attribute named '" + attributeName + "' present in merged annotation " + 
/* 576 */           getType().getName());
/*     */     }
/* 578 */     return attributeIndex;
/*     */   }
/*     */   
/*     */   private boolean isFiltered(String attributeName) {
/* 582 */     if (this.attributeFilter != null) {
/* 583 */       return !this.attributeFilter.test(attributeName);
/*     */     }
/* 585 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader getClassLoader() {
/* 590 */     if (this.classLoader != null) {
/* 591 */       return this.classLoader;
/*     */     }
/* 593 */     if (this.source != null) {
/* 594 */       Object object = this.source; if (object instanceof Class) { Class<?> clazz = (Class)object;
/* 595 */         return clazz.getClassLoader(); }
/*     */       
/* 597 */       object = this.source; if (object instanceof Member) { Member member = (Member)object;
/* 598 */         member.getDeclaringClass().getClassLoader(); }
/*     */     
/*     */     } 
/* 601 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static <A extends Annotation> MergedAnnotation<A> from(@Nullable Object source, A annotation) {
/* 606 */     Assert.notNull(annotation, "Annotation must not be null");
/* 607 */     AnnotationTypeMappings mappings = AnnotationTypeMappings.forAnnotationType(annotation.annotationType());
/* 608 */     return new TypeMappedAnnotation<>(mappings
/* 609 */         .get(0), null, source, annotation, AnnotationUtils::invokeAnnotationMethod, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <A extends Annotation> MergedAnnotation<A> of(@Nullable ClassLoader classLoader, @Nullable Object source, Class<A> annotationType, @Nullable Map<String, ?> attributes) {
/* 616 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 617 */     AnnotationTypeMappings mappings = AnnotationTypeMappings.forAnnotationType(annotationType);
/* 618 */     return new TypeMappedAnnotation<>(mappings
/* 619 */         .get(0), classLoader, source, attributes, TypeMappedAnnotation::extractFromMap, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static <A extends Annotation> TypeMappedAnnotation<A> createIfPossible(AnnotationTypeMapping mapping, MergedAnnotation<?> annotation, IntrospectionFailureLogger logger) {
/* 626 */     if (annotation instanceof TypeMappedAnnotation) { TypeMappedAnnotation<?> typeMappedAnnotation = (TypeMappedAnnotation)annotation;
/* 627 */       return createIfPossible(mapping, typeMappedAnnotation.source, typeMappedAnnotation.rootAttributes, typeMappedAnnotation.valueExtractor, typeMappedAnnotation.aggregateIndex, logger); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 632 */     return createIfPossible(mapping, annotation.getSource(), (Annotation)annotation.synthesize(), annotation
/* 633 */         .getAggregateIndex(), logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static <A extends Annotation> TypeMappedAnnotation<A> createIfPossible(AnnotationTypeMapping mapping, @Nullable Object source, Annotation annotation, int aggregateIndex, IntrospectionFailureLogger logger) {
/* 641 */     return createIfPossible(mapping, source, annotation, AnnotationUtils::invokeAnnotationMethod, aggregateIndex, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static <A extends Annotation> TypeMappedAnnotation<A> createIfPossible(AnnotationTypeMapping mapping, @Nullable Object source, @Nullable Object rootAttribute, ValueExtractor valueExtractor, int aggregateIndex, IntrospectionFailureLogger logger) {
/*     */     try {
/* 651 */       return new TypeMappedAnnotation<>(mapping, null, source, rootAttribute, valueExtractor, aggregateIndex);
/*     */     
/*     */     }
/* 654 */     catch (Exception ex) {
/* 655 */       AnnotationUtils.rethrowAnnotationConfigurationException(ex);
/* 656 */       if (logger.isEnabled()) {
/* 657 */         String type = mapping.getAnnotationType().getName();
/*     */         
/* 659 */         String item = (mapping.getDistance() == 0) ? ("annotation " + type) : ("meta-annotation " + type + " from " + mapping.getRoot().getAnnotationType().getName());
/* 660 */         logger.log("Failed to introspect " + item, source, ex);
/*     */       } 
/* 662 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static Object extractFromMap(Method attribute, @Nullable Object map) {
/* 669 */     return (map != null) ? ((Map)map).get(attribute.getName()) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\TypeMappedAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */