/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Spliterator;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationsSpliterator<A extends Annotation>
/*     */   implements Spliterator<MergedAnnotation<A>>
/*     */ {
/*     */   @Nullable
/*     */   private final Object requiredType;
/*     */   private final int[] mappingCursors;
/*     */   
/*     */   public AnnotationsSpliterator(Object requiredType) {
/* 231 */     this.mappingCursors = new int[paramMergedAnnotationsCollection.annotations.length];
/* 232 */     this.requiredType = requiredType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean tryAdvance(Consumer<? super MergedAnnotation<A>> action) {
/* 237 */     int lowestDistance = Integer.MAX_VALUE;
/* 238 */     int annotationResult = -1;
/* 239 */     for (int annotationIndex = 0; annotationIndex < MergedAnnotationsCollection.this.annotations.length; annotationIndex++) {
/* 240 */       AnnotationTypeMapping mapping = getNextSuitableMapping(annotationIndex);
/* 241 */       if (mapping != null && mapping.getDistance() < lowestDistance) {
/* 242 */         annotationResult = annotationIndex;
/* 243 */         lowestDistance = mapping.getDistance();
/*     */       } 
/* 245 */       if (lowestDistance == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/* 249 */     if (annotationResult != -1) {
/* 250 */       MergedAnnotation<A> mergedAnnotation = createMergedAnnotationIfPossible(annotationResult, this.mappingCursors[annotationResult]);
/*     */       
/* 252 */       this.mappingCursors[annotationResult] = this.mappingCursors[annotationResult] + 1;
/* 253 */       if (mergedAnnotation == null) {
/* 254 */         return tryAdvance(action);
/*     */       }
/* 256 */       action.accept(mergedAnnotation);
/* 257 */       return true;
/*     */     } 
/* 259 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private AnnotationTypeMapping getNextSuitableMapping(int annotationIndex) {
/*     */     while (true) {
/* 266 */       AnnotationTypeMapping mapping = getMapping(annotationIndex, this.mappingCursors[annotationIndex]);
/* 267 */       if (mapping != null && MergedAnnotationsCollection.isMappingForType(mapping, this.requiredType)) {
/* 268 */         return mapping;
/*     */       }
/* 270 */       this.mappingCursors[annotationIndex] = this.mappingCursors[annotationIndex] + 1;
/*     */       
/* 272 */       if (mapping == null)
/* 273 */         return null; 
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   private AnnotationTypeMapping getMapping(int annotationIndex, int mappingIndex) {
/* 278 */     AnnotationTypeMappings mappings = MergedAnnotationsCollection.this.mappings[annotationIndex];
/* 279 */     return (mappingIndex < mappings.size()) ? mappings.get(mappingIndex) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private MergedAnnotation<A> createMergedAnnotationIfPossible(int annotationIndex, int mappingIndex) {
/* 285 */     MergedAnnotation<?> root = MergedAnnotationsCollection.this.annotations[annotationIndex];
/* 286 */     if (mappingIndex == 0) {
/* 287 */       return (MergedAnnotation)root;
/*     */     }
/*     */     
/* 290 */     IntrospectionFailureLogger logger = (this.requiredType != null) ? IntrospectionFailureLogger.INFO : IntrospectionFailureLogger.DEBUG;
/* 291 */     return TypeMappedAnnotation.createIfPossible(MergedAnnotationsCollection.this.mappings[annotationIndex]
/* 292 */         .get(mappingIndex), root, logger);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Spliterator<MergedAnnotation<A>> trySplit() {
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long estimateSize() {
/* 303 */     int size = 0;
/* 304 */     for (int i = 0; i < MergedAnnotationsCollection.this.annotations.length; i++) {
/* 305 */       AnnotationTypeMappings mappings = MergedAnnotationsCollection.this.mappings[i];
/* 306 */       int numberOfMappings = mappings.size();
/* 307 */       numberOfMappings -= Math.min(this.mappingCursors[i], mappings.size());
/* 308 */       size += numberOfMappings;
/*     */     } 
/* 310 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public int characteristics() {
/* 315 */     return 1280;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\MergedAnnotationsCollection$AnnotationsSpliterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */