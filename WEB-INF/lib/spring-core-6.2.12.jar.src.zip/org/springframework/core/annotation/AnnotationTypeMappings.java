/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AnnotationTypeMappings
/*     */ {
/*  51 */   private static final IntrospectionFailureLogger failureLogger = IntrospectionFailureLogger.DEBUG;
/*     */   
/*  53 */   private static final Map<AnnotationFilter, Cache> standardRepeatablesCache = (Map<AnnotationFilter, Cache>)new ConcurrentReferenceHashMap();
/*     */   
/*  55 */   private static final Map<AnnotationFilter, Cache> noRepeatablesCache = (Map<AnnotationFilter, Cache>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */   
/*     */   private final RepeatableContainers repeatableContainers;
/*     */ 
/*     */   
/*     */   private final AnnotationFilter filter;
/*     */ 
/*     */   
/*     */   private final List<AnnotationTypeMapping> mappings;
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationTypeMappings(RepeatableContainers repeatableContainers, AnnotationFilter filter, Class<? extends Annotation> annotationType, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/*  69 */     this.repeatableContainers = repeatableContainers;
/*  70 */     this.filter = filter;
/*  71 */     this.mappings = new ArrayList<>();
/*  72 */     addAllMappings(annotationType, visitedAnnotationTypes);
/*  73 */     this.mappings.forEach(AnnotationTypeMapping::afterAllMappingsSet);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addAllMappings(Class<? extends Annotation> annotationType, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/*  79 */     Deque<AnnotationTypeMapping> queue = new ArrayDeque<>();
/*  80 */     addIfPossible(queue, null, annotationType, null, visitedAnnotationTypes);
/*  81 */     while (!queue.isEmpty()) {
/*  82 */       AnnotationTypeMapping mapping = queue.removeFirst();
/*  83 */       this.mappings.add(mapping);
/*  84 */       addMetaAnnotationsToQueue(queue, mapping);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addMetaAnnotationsToQueue(Deque<AnnotationTypeMapping> queue, AnnotationTypeMapping source) {
/*  89 */     Annotation[] metaAnnotations = AnnotationsScanner.getDeclaredAnnotations(source.getAnnotationType(), false);
/*  90 */     for (Annotation metaAnnotation : metaAnnotations) {
/*  91 */       if (isMappable(source, metaAnnotation)) {
/*     */ 
/*     */         
/*  94 */         Annotation[] repeatedAnnotations = this.repeatableContainers.findRepeatedAnnotations(metaAnnotation);
/*  95 */         if (repeatedAnnotations != null) {
/*  96 */           for (Annotation repeatedAnnotation : repeatedAnnotations) {
/*  97 */             if (isMappable(source, repeatedAnnotation))
/*     */             {
/*     */               
/* 100 */               addIfPossible(queue, source, repeatedAnnotation);
/*     */             }
/*     */           } 
/*     */         } else {
/* 104 */           addIfPossible(queue, source, metaAnnotation);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void addIfPossible(Deque<AnnotationTypeMapping> queue, AnnotationTypeMapping source, Annotation ann) {
/* 110 */     addIfPossible(queue, source, ann.annotationType(), ann, new HashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addIfPossible(Deque<AnnotationTypeMapping> queue, @Nullable AnnotationTypeMapping source, Class<? extends Annotation> annotationType, @Nullable Annotation ann, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/*     */     try {
/* 118 */       queue.addLast(new AnnotationTypeMapping(source, annotationType, ann, visitedAnnotationTypes));
/*     */     }
/* 120 */     catch (Exception ex) {
/* 121 */       AnnotationUtils.rethrowAnnotationConfigurationException(ex);
/* 122 */       if (failureLogger.isEnabled()) {
/* 123 */         failureLogger.log("Failed to introspect meta-annotation " + annotationType.getName(), 
/* 124 */             (source != null) ? source.getAnnotationType() : null, ex);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isMappable(AnnotationTypeMapping source, @Nullable Annotation metaAnnotation) {
/* 130 */     return (metaAnnotation != null && !this.filter.matches(metaAnnotation) && 
/* 131 */       !AnnotationFilter.PLAIN.matches(source.getAnnotationType()) && 
/* 132 */       !isAlreadyMapped(source, metaAnnotation));
/*     */   }
/*     */   
/*     */   private boolean isAlreadyMapped(AnnotationTypeMapping source, Annotation metaAnnotation) {
/* 136 */     Class<? extends Annotation> annotationType = metaAnnotation.annotationType();
/* 137 */     AnnotationTypeMapping mapping = source;
/* 138 */     while (mapping != null) {
/* 139 */       if (mapping.getAnnotationType() == annotationType) {
/* 140 */         return true;
/*     */       }
/* 142 */       mapping = mapping.getSource();
/*     */     } 
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 152 */     return this.mappings.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationTypeMapping get(int index) {
/* 165 */     return this.mappings.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AnnotationTypeMappings forAnnotationType(Class<? extends Annotation> annotationType) {
/* 175 */     return forAnnotationType(annotationType, new HashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AnnotationTypeMappings forAnnotationType(Class<? extends Annotation> annotationType, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/* 189 */     return forAnnotationType(annotationType, RepeatableContainers.standardRepeatables(), AnnotationFilter.PLAIN, visitedAnnotationTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AnnotationTypeMappings forAnnotationType(Class<? extends Annotation> annotationType, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/* 205 */     return forAnnotationType(annotationType, repeatableContainers, annotationFilter, new HashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AnnotationTypeMappings forAnnotationType(Class<? extends Annotation> annotationType, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/* 224 */     if (repeatableContainers == RepeatableContainers.standardRepeatables()) {
/* 225 */       return ((Cache)standardRepeatablesCache.computeIfAbsent(annotationFilter, key -> new Cache(repeatableContainers, key)))
/* 226 */         .get(annotationType, visitedAnnotationTypes);
/*     */     }
/* 228 */     if (repeatableContainers == RepeatableContainers.none()) {
/* 229 */       return ((Cache)noRepeatablesCache.computeIfAbsent(annotationFilter, key -> new Cache(repeatableContainers, key)))
/* 230 */         .get(annotationType, visitedAnnotationTypes);
/*     */     }
/* 232 */     return new AnnotationTypeMappings(repeatableContainers, annotationFilter, annotationType, visitedAnnotationTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   static void clearCache() {
/* 237 */     standardRepeatablesCache.clear();
/* 238 */     noRepeatablesCache.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Cache
/*     */   {
/*     */     private final RepeatableContainers repeatableContainers;
/*     */ 
/*     */ 
/*     */     
/*     */     private final AnnotationFilter filter;
/*     */ 
/*     */     
/*     */     private final Map<Class<? extends Annotation>, AnnotationTypeMappings> mappings;
/*     */ 
/*     */ 
/*     */     
/*     */     Cache(RepeatableContainers repeatableContainers, AnnotationFilter filter) {
/* 258 */       this.repeatableContainers = repeatableContainers;
/* 259 */       this.filter = filter;
/* 260 */       this.mappings = (Map<Class<? extends Annotation>, AnnotationTypeMappings>)new ConcurrentReferenceHashMap();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AnnotationTypeMappings get(Class<? extends Annotation> annotationType, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/* 273 */       return this.mappings.computeIfAbsent(annotationType, key -> createMappings(key, visitedAnnotationTypes));
/*     */     }
/*     */ 
/*     */     
/*     */     private AnnotationTypeMappings createMappings(Class<? extends Annotation> annotationType, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/* 278 */       return new AnnotationTypeMappings(this.repeatableContainers, this.filter, annotationType, visitedAnnotationTypes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationTypeMappings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */