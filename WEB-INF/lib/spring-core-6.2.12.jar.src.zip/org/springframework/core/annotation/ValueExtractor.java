package org.springframework.core.annotation;

import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

@FunctionalInterface
interface ValueExtractor {
  @Nullable
  Object extract(Method paramMethod, @Nullable Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\ValueExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */