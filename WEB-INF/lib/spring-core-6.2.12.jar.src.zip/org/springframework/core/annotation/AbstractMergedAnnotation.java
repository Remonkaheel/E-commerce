/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractMergedAnnotation<A extends Annotation>
/*     */   implements MergedAnnotation<A>
/*     */ {
/*     */   @Nullable
/*     */   private volatile A synthesizedAnnotation;
/*     */   
/*     */   public boolean isDirectlyPresent() {
/*  43 */     return (isPresent() && getDistance() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMetaPresent() {
/*  48 */     return (isPresent() && getDistance() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNonDefaultValue(String attributeName) {
/*  53 */     return !hasDefaultValue(attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(String attributeName) {
/*  58 */     return ((Byte)getRequiredAttributeValue(attributeName, Byte.class)).byteValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getByteArray(String attributeName) {
/*  63 */     return getRequiredAttributeValue(attributeName, (Class)byte[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String attributeName) {
/*  68 */     return ((Boolean)getRequiredAttributeValue(attributeName, Boolean.class)).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getBooleanArray(String attributeName) {
/*  73 */     return getRequiredAttributeValue(attributeName, (Class)boolean[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(String attributeName) {
/*  78 */     return ((Character)getRequiredAttributeValue(attributeName, Character.class)).charValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getCharArray(String attributeName) {
/*  83 */     return getRequiredAttributeValue(attributeName, (Class)char[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(String attributeName) {
/*  88 */     return ((Short)getRequiredAttributeValue(attributeName, Short.class)).shortValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getShortArray(String attributeName) {
/*  93 */     return getRequiredAttributeValue(attributeName, (Class)short[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(String attributeName) {
/*  98 */     return ((Integer)getRequiredAttributeValue(attributeName, Integer.class)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getIntArray(String attributeName) {
/* 103 */     return getRequiredAttributeValue(attributeName, (Class)int[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(String attributeName) {
/* 108 */     return ((Long)getRequiredAttributeValue(attributeName, Long.class)).longValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public long[] getLongArray(String attributeName) {
/* 113 */     return getRequiredAttributeValue(attributeName, (Class)long[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(String attributeName) {
/* 118 */     return ((Double)getRequiredAttributeValue(attributeName, Double.class)).doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public double[] getDoubleArray(String attributeName) {
/* 123 */     return getRequiredAttributeValue(attributeName, (Class)double[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(String attributeName) {
/* 128 */     return ((Float)getRequiredAttributeValue(attributeName, Float.class)).floatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getFloatArray(String attributeName) {
/* 133 */     return getRequiredAttributeValue(attributeName, (Class)float[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String attributeName) {
/* 138 */     return getRequiredAttributeValue(attributeName, String.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getStringArray(String attributeName) {
/* 143 */     return getRequiredAttributeValue(attributeName, (Class)String[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getClass(String attributeName) {
/* 148 */     return getRequiredAttributeValue(attributeName, Class.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getClassArray(String attributeName) {
/* 153 */     return getRequiredAttributeValue(attributeName, (Class)Class[].class);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<E>> E getEnum(String attributeName, Class<E> type) {
/* 158 */     Assert.notNull(type, "Type must not be null");
/* 159 */     return (E)getRequiredAttributeValue(attributeName, type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Enum<E>> E[] getEnumArray(String attributeName, Class<E> type) {
/* 165 */     Assert.notNull(type, "Type must not be null");
/* 166 */     return (E[])getRequiredAttributeValue(attributeName, type.arrayType());
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Object> getValue(String attributeName) {
/* 171 */     return getValue(attributeName, Object.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<T> getValue(String attributeName, Class<T> type) {
/* 176 */     return Optional.ofNullable(getAttributeValue(attributeName, type));
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Object> getDefaultValue(String attributeName) {
/* 181 */     return getDefaultValue(attributeName, Object.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public MergedAnnotation<A> filterDefaultValues() {
/* 186 */     return filterAttributes(this::hasNonDefaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationAttributes asAnnotationAttributes(MergedAnnotation.Adapt... adaptations) {
/* 191 */     return (AnnotationAttributes)asMap(mergedAnnotation -> new AnnotationAttributes(mergedAnnotation.getType()), adaptations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<A> synthesize(Predicate<? super MergedAnnotation<A>> condition) throws NoSuchElementException {
/* 198 */     return condition.test(this) ? Optional.<A>of(synthesize()) : Optional.<A>empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public A synthesize() {
/* 203 */     if (!isPresent()) {
/* 204 */       throw new NoSuchElementException("Unable to synthesize missing annotation");
/*     */     }
/* 206 */     A synthesized = this.synthesizedAnnotation;
/* 207 */     if (synthesized == null) {
/* 208 */       synthesized = createSynthesizedAnnotation();
/* 209 */       this.synthesizedAnnotation = synthesized;
/*     */     } 
/* 211 */     return synthesized;
/*     */   }
/*     */   
/*     */   private <T> T getRequiredAttributeValue(String attributeName, Class<T> type) {
/* 215 */     T value = getAttributeValue(attributeName, type);
/* 216 */     if (value == null) {
/* 217 */       throw new NoSuchElementException("No attribute named '" + attributeName + "' present in merged annotation " + 
/* 218 */           getType().getName());
/*     */     }
/* 220 */     return value;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract <T> T getAttributeValue(String paramString, Class<T> paramClass);
/*     */   
/*     */   protected abstract A createSynthesizedAnnotation();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AbstractMergedAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */