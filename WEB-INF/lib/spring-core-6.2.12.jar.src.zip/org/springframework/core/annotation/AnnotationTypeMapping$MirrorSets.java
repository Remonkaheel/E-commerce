/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MirrorSets
/*     */ {
/* 692 */   private final MirrorSet[] assigned = (AnnotationTypeMapping.this.attributes.size() > 0) ? new MirrorSet[AnnotationTypeMapping.this.attributes.size()] : AnnotationTypeMapping.EMPTY_MIRROR_SETS;
/* 693 */   private MirrorSet[] mirrorSets = AnnotationTypeMapping.EMPTY_MIRROR_SETS;
/*     */ 
/*     */   
/*     */   void updateFrom(Collection<Method> aliases) {
/* 697 */     MirrorSet mirrorSet = null;
/* 698 */     int size = 0;
/* 699 */     int last = -1;
/* 700 */     for (int i = 0; i < AnnotationTypeMapping.this.attributes.size(); i++) {
/* 701 */       Method attribute = AnnotationTypeMapping.this.attributes.get(i);
/* 702 */       if (aliases.contains(attribute)) {
/* 703 */         size++;
/* 704 */         if (size > 1) {
/* 705 */           if (mirrorSet == null) {
/* 706 */             mirrorSet = new MirrorSet();
/* 707 */             this.assigned[last] = mirrorSet;
/*     */           } 
/* 709 */           this.assigned[i] = mirrorSet;
/*     */         } 
/* 711 */         last = i;
/*     */       } 
/*     */     } 
/* 714 */     if (mirrorSet != null) {
/* 715 */       mirrorSet.update();
/* 716 */       Set<MirrorSet> unique = new LinkedHashSet<>(Arrays.asList(this.assigned));
/* 717 */       unique.remove(null);
/* 718 */       this.mirrorSets = unique.<MirrorSet>toArray(AnnotationTypeMapping.EMPTY_MIRROR_SETS);
/*     */     } 
/*     */   }
/*     */   
/*     */   int size() {
/* 723 */     return this.mirrorSets.length;
/*     */   }
/*     */   
/*     */   MirrorSet get(int index) {
/* 727 */     return this.mirrorSets[index];
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   MirrorSet getAssigned(int attributeIndex) {
/* 732 */     return this.assigned[attributeIndex];
/*     */   }
/*     */   
/*     */   int[] resolve(@Nullable Object source, @Nullable Object annotation, ValueExtractor valueExtractor) {
/* 736 */     if (AnnotationTypeMapping.this.attributes.size() == 0) {
/* 737 */       return AnnotationTypeMapping.EMPTY_INT_ARRAY;
/*     */     }
/* 739 */     int[] result = new int[AnnotationTypeMapping.this.attributes.size()]; int i;
/* 740 */     for (i = 0; i < result.length; i++) {
/* 741 */       result[i] = i;
/*     */     }
/* 743 */     for (i = 0; i < size(); i++) {
/* 744 */       MirrorSet mirrorSet = get(i);
/* 745 */       int resolved = mirrorSet.resolve(source, annotation, valueExtractor);
/* 746 */       for (int j = 0; j < mirrorSet.size; j++) {
/* 747 */         result[mirrorSet.indexes[j]] = resolved;
/*     */       }
/*     */     } 
/* 750 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class MirrorSet
/*     */   {
/*     */     private int size;
/*     */ 
/*     */     
/* 761 */     private final int[] indexes = new int[this.this$1.this$0.attributes.size()];
/*     */     
/*     */     void update() {
/* 764 */       this.size = 0;
/* 765 */       Arrays.fill(this.indexes, -1);
/* 766 */       for (int i = 0; i < AnnotationTypeMapping.MirrorSets.this.assigned.length; i++) {
/* 767 */         if (AnnotationTypeMapping.MirrorSets.this.assigned[i] == this) {
/* 768 */           this.indexes[this.size] = i;
/* 769 */           this.size++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     <A> int resolve(@Nullable Object source, @Nullable A annotation, ValueExtractor valueExtractor) {
/* 775 */       int result = -1;
/* 776 */       Object lastValue = null;
/* 777 */       for (int i = 0; i < this.size; i++) {
/* 778 */         Method attribute = this.this$1.this$0.attributes.get(this.indexes[i]);
/* 779 */         Object value = valueExtractor.extract(attribute, annotation);
/*     */         
/* 781 */         boolean isDefaultValue = (value == null || AnnotationTypeMapping.isEquivalentToDefaultValue(attribute, value, valueExtractor));
/* 782 */         if (isDefaultValue || ObjectUtils.nullSafeEquals(lastValue, value)) {
/* 783 */           if (result == -1) {
/* 784 */             result = this.indexes[i];
/*     */           }
/*     */         } else {
/*     */           
/* 788 */           if (lastValue != null && !ObjectUtils.nullSafeEquals(lastValue, value)) {
/* 789 */             String on = (source != null) ? (" declared on " + String.valueOf(source)) : "";
/* 790 */             throw new AnnotationConfigurationException(String.format("Different @AliasFor mirror values for annotation [%s]%s; attribute '%s' and its alias '%s' are declared with values of [%s] and [%s].", new Object[] { this.this$1.this$0
/*     */ 
/*     */                     
/* 793 */                     .getAnnotationType().getName(), on, this.this$1.this$0.attributes
/* 794 */                     .get(result).getName(), attribute
/* 795 */                     .getName(), 
/* 796 */                     ObjectUtils.nullSafeToString(lastValue), 
/* 797 */                     ObjectUtils.nullSafeToString(value) }));
/*     */           } 
/* 799 */           result = this.indexes[i];
/* 800 */           lastValue = value;
/*     */         } 
/* 802 */       }  return result;
/*     */     }
/*     */     
/*     */     int size() {
/* 806 */       return this.size;
/*     */     }
/*     */     
/*     */     Method get(int index) {
/* 810 */       int attributeIndex = this.indexes[index];
/* 811 */       return this.this$1.this$0.attributes.get(attributeIndex);
/*     */     }
/*     */     
/*     */     int getAttributeIndex(int index) {
/* 815 */       return this.indexes[index];
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationTypeMapping$MirrorSets.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */