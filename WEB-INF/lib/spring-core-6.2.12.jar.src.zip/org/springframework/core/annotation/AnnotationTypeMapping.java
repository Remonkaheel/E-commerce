/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AnnotationTypeMapping
/*     */ {
/*  54 */   private static final Log logger = LogFactory.getLog(AnnotationTypeMapping.class); private static final Predicate<? super Annotation> isBeanValidationConstraint;
/*     */   static {
/*  56 */     isBeanValidationConstraint = (annotation -> annotation.annotationType().getName().equals("jakarta.validation.Constraint"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static final Set<String> conventionBasedOverrideCheckCache = ConcurrentHashMap.newKeySet();
/*     */   
/*  70 */   private static final MirrorSets.MirrorSet[] EMPTY_MIRROR_SETS = new MirrorSets.MirrorSet[0];
/*     */   
/*  72 */   private static final int[] EMPTY_INT_ARRAY = new int[0];
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final AnnotationTypeMapping source;
/*     */   
/*     */   private final AnnotationTypeMapping root;
/*     */   
/*     */   private final int distance;
/*     */   
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   
/*     */   private final List<Class<? extends Annotation>> metaTypes;
/*     */   
/*     */   @Nullable
/*     */   private final Annotation annotation;
/*     */   
/*     */   private final AttributeMethods attributes;
/*     */   
/*     */   private final MirrorSets mirrorSets;
/*     */   
/*     */   private final int[] aliasMappings;
/*     */   
/*     */   private final int[] conventionMappings;
/*     */   
/*     */   private final int[] annotationValueMappings;
/*     */   
/*     */   private final AnnotationTypeMapping[] annotationValueSource;
/*     */   
/*     */   private final Map<Method, List<Method>> aliasedBy;
/*     */   
/*     */   private final boolean synthesizable;
/*     */   
/* 105 */   private final Set<Method> claimedAliases = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationTypeMapping(@Nullable AnnotationTypeMapping source, Class<? extends Annotation> annotationType, @Nullable Annotation annotation, Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/* 111 */     this.source = source;
/* 112 */     this.root = (source != null) ? source.getRoot() : this;
/* 113 */     this.distance = (source == null) ? 0 : (source.getDistance() + 1);
/* 114 */     this.annotationType = annotationType;
/* 115 */     this.metaTypes = merge(
/* 116 */         (source != null) ? source.getMetaTypes() : null, annotationType);
/*     */     
/* 118 */     this.annotation = annotation;
/* 119 */     this.attributes = AttributeMethods.forAnnotationType(annotationType);
/* 120 */     this.mirrorSets = new MirrorSets();
/* 121 */     this.aliasMappings = filledIntArray(this.attributes.size());
/* 122 */     this.conventionMappings = filledIntArray(this.attributes.size());
/* 123 */     this.annotationValueMappings = filledIntArray(this.attributes.size());
/* 124 */     this.annotationValueSource = new AnnotationTypeMapping[this.attributes.size()];
/* 125 */     this.aliasedBy = resolveAliasedForTargets();
/* 126 */     processAliases();
/* 127 */     addConventionMappings();
/* 128 */     addConventionAnnotationValues();
/* 129 */     this.synthesizable = computeSynthesizableFlag(visitedAnnotationTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> List<T> merge(@Nullable List<T> existing, T element) {
/* 134 */     if (existing == null) {
/* 135 */       return Collections.singletonList(element);
/*     */     }
/* 137 */     List<T> merged = new ArrayList<>(existing.size() + 1);
/* 138 */     merged.addAll(existing);
/* 139 */     merged.add(element);
/* 140 */     return Collections.unmodifiableList(merged);
/*     */   }
/*     */   
/*     */   private Map<Method, List<Method>> resolveAliasedForTargets() {
/* 144 */     Map<Method, List<Method>> aliasedBy = new HashMap<>();
/* 145 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 146 */       Method attribute = this.attributes.get(i);
/* 147 */       AliasFor aliasFor = AnnotationsScanner.<AliasFor>getDeclaredAnnotation(attribute, AliasFor.class);
/* 148 */       if (aliasFor != null) {
/* 149 */         Method target = resolveAliasTarget(attribute, aliasFor);
/* 150 */         ((List<Method>)aliasedBy.computeIfAbsent(target, key -> new ArrayList())).add(attribute);
/*     */       } 
/*     */     } 
/* 153 */     return Collections.unmodifiableMap(aliasedBy);
/*     */   }
/*     */   
/*     */   private Method resolveAliasTarget(Method attribute, AliasFor aliasFor) {
/* 157 */     return resolveAliasTarget(attribute, aliasFor, true);
/*     */   }
/*     */   
/*     */   private Method resolveAliasTarget(Method attribute, AliasFor aliasFor, boolean checkAliasPair) {
/* 161 */     if (StringUtils.hasText(aliasFor.value()) && StringUtils.hasText(aliasFor.attribute()))
/* 162 */       throw new AnnotationConfigurationException(String.format("In @AliasFor declared on %s, attribute 'attribute' and its alias 'value' are present with values of '%s' and '%s', but only one is permitted.", new Object[] {
/*     */ 
/*     */               
/* 165 */               AttributeMethods.describe(attribute), aliasFor.attribute(), aliasFor
/* 166 */               .value()
/*     */             })); 
/* 168 */     Class<? extends Annotation> targetAnnotation = aliasFor.annotation();
/* 169 */     if (targetAnnotation == Annotation.class) {
/* 170 */       targetAnnotation = this.annotationType;
/*     */     }
/* 172 */     String targetAttributeName = aliasFor.attribute();
/* 173 */     if (!StringUtils.hasLength(targetAttributeName)) {
/* 174 */       targetAttributeName = aliasFor.value();
/*     */     }
/* 176 */     if (!StringUtils.hasLength(targetAttributeName)) {
/* 177 */       targetAttributeName = attribute.getName();
/*     */     }
/* 179 */     Method target = AttributeMethods.forAnnotationType(targetAnnotation).get(targetAttributeName);
/* 180 */     if (target == null) {
/* 181 */       if (targetAnnotation == this.annotationType)
/* 182 */         throw new AnnotationConfigurationException(String.format("@AliasFor declaration on %s declares an alias for '%s' which is not present.", new Object[] {
/*     */                 
/* 184 */                 AttributeMethods.describe(attribute), targetAttributeName
/*     */               })); 
/* 186 */       throw new AnnotationConfigurationException(String.format("%s is declared as an @AliasFor nonexistent %s.", new Object[] {
/*     */               
/* 188 */               StringUtils.capitalize(AttributeMethods.describe(attribute)), 
/* 189 */               AttributeMethods.describe(targetAnnotation, targetAttributeName) }));
/*     */     } 
/* 191 */     if (target.equals(attribute))
/* 192 */       throw new AnnotationConfigurationException(String.format("@AliasFor declaration on %s points to itself. Specify 'annotation' to point to a same-named attribute on a meta-annotation.", new Object[] {
/*     */ 
/*     */               
/* 195 */               AttributeMethods.describe(attribute)
/*     */             })); 
/* 197 */     if (!isCompatibleReturnType(attribute.getReturnType(), target.getReturnType()))
/* 198 */       throw new AnnotationConfigurationException(String.format("Misconfigured aliases: %s and %s must declare the same return type.", new Object[] {
/*     */               
/* 200 */               AttributeMethods.describe(attribute), 
/* 201 */               AttributeMethods.describe(target)
/*     */             })); 
/* 203 */     if (isAliasPair(target) && checkAliasPair) {
/* 204 */       AliasFor targetAliasFor = target.<AliasFor>getAnnotation(AliasFor.class);
/* 205 */       if (targetAliasFor != null) {
/* 206 */         Method mirror = resolveAliasTarget(target, targetAliasFor, false);
/* 207 */         if (!mirror.equals(attribute))
/* 208 */           throw new AnnotationConfigurationException(String.format("%s must be declared as an @AliasFor %s, not %s.", new Object[] {
/*     */                   
/* 210 */                   StringUtils.capitalize(AttributeMethods.describe(target)), 
/* 211 */                   AttributeMethods.describe(attribute), AttributeMethods.describe(mirror)
/*     */                 })); 
/*     */       } 
/*     */     } 
/* 215 */     return target;
/*     */   }
/*     */   
/*     */   private boolean isAliasPair(Method target) {
/* 219 */     return (this.annotationType == target.getDeclaringClass());
/*     */   }
/*     */   
/*     */   private boolean isCompatibleReturnType(Class<?> attributeType, Class<?> targetType) {
/* 223 */     return (attributeType == targetType || attributeType == targetType.componentType());
/*     */   }
/*     */   
/*     */   private void processAliases() {
/* 227 */     List<Method> aliases = new ArrayList<>();
/* 228 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 229 */       aliases.clear();
/* 230 */       aliases.add(this.attributes.get(i));
/* 231 */       collectAliases(aliases);
/* 232 */       if (aliases.size() > 1) {
/* 233 */         processAliases(i, aliases);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void collectAliases(List<Method> aliases) {
/* 239 */     AnnotationTypeMapping mapping = this;
/* 240 */     while (mapping != null) {
/* 241 */       int size = aliases.size();
/* 242 */       for (int j = 0; j < size; j++) {
/* 243 */         List<Method> additional = mapping.aliasedBy.get(aliases.get(j));
/* 244 */         if (additional != null) {
/* 245 */           aliases.addAll(additional);
/*     */         }
/*     */       } 
/* 248 */       mapping = mapping.source;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processAliases(int attributeIndex, List<Method> aliases) {
/* 253 */     int rootAttributeIndex = getFirstRootAttributeIndex(aliases);
/* 254 */     AnnotationTypeMapping mapping = this;
/* 255 */     while (mapping != null) {
/* 256 */       if (rootAttributeIndex != -1 && mapping != this.root) {
/* 257 */         for (int i = 0; i < mapping.attributes.size(); i++) {
/* 258 */           if (aliases.contains(mapping.attributes.get(i))) {
/* 259 */             mapping.aliasMappings[i] = rootAttributeIndex;
/*     */           }
/*     */         } 
/*     */       }
/* 263 */       mapping.mirrorSets.updateFrom(aliases);
/* 264 */       mapping.claimedAliases.addAll(aliases);
/* 265 */       if (mapping.annotation != null) {
/* 266 */         int[] resolvedMirrors = mapping.mirrorSets.resolve(null, mapping.annotation, AnnotationUtils::invokeAnnotationMethod);
/*     */         
/* 268 */         for (int i = 0; i < mapping.attributes.size(); i++) {
/* 269 */           if (aliases.contains(mapping.attributes.get(i))) {
/* 270 */             this.annotationValueMappings[attributeIndex] = resolvedMirrors[i];
/* 271 */             this.annotationValueSource[attributeIndex] = mapping;
/*     */           } 
/*     */         } 
/*     */       } 
/* 275 */       mapping = mapping.source;
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getFirstRootAttributeIndex(Collection<Method> aliases) {
/* 280 */     AttributeMethods rootAttributes = this.root.getAttributes();
/* 281 */     for (int i = 0; i < rootAttributes.size(); i++) {
/* 282 */       if (aliases.contains(rootAttributes.get(i))) {
/* 283 */         return i;
/*     */       }
/*     */     } 
/* 286 */     return -1;
/*     */   }
/*     */   
/*     */   private void addConventionMappings() {
/* 290 */     if (this.distance == 0) {
/*     */       return;
/*     */     }
/* 293 */     AttributeMethods rootAttributes = this.root.getAttributes();
/* 294 */     int[] mappings = this.conventionMappings;
/* 295 */     Set<String> conventionMappedAttributes = new HashSet<>();
/* 296 */     for (int i = 0; i < mappings.length; i++) {
/* 297 */       String name = this.attributes.get(i).getName();
/* 298 */       int mapped = rootAttributes.indexOf(name);
/* 299 */       if (!"value".equals(name) && mapped != -1 && !isExplicitAttributeOverride(name)) {
/* 300 */         conventionMappedAttributes.add(name);
/* 301 */         mappings[i] = mapped;
/* 302 */         MirrorSets.MirrorSet mirrors = getMirrorSets().getAssigned(i);
/* 303 */         if (mirrors != null) {
/* 304 */           for (int j = 0; j < mirrors.size(); j++) {
/* 305 */             mappings[mirrors.getAttributeIndex(j)] = mapped;
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 310 */     String rootAnnotationTypeName = this.root.annotationType.getName();
/* 311 */     String cacheKey = rootAnnotationTypeName + "-" + rootAnnotationTypeName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     if (conventionBasedOverrideCheckCache.add(cacheKey) && !conventionMappedAttributes.isEmpty() && 
/* 321 */       Arrays.<Annotation>stream(this.annotationType.getAnnotations()).noneMatch(isBeanValidationConstraint) && logger
/* 322 */       .isWarnEnabled()) {
/* 323 */       logger.warn("Support for convention-based annotation attribute overrides is deprecated and will be removed in Spring Framework 7.0. Please annotate the following attributes in @%s with appropriate @AliasFor declarations: %s"
/*     */ 
/*     */ 
/*     */           
/* 327 */           .formatted(new Object[] { rootAnnotationTypeName, conventionMappedAttributes }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isExplicitAttributeOverride(String name) {
/* 342 */     Method attribute = this.root.getAttributes().get(name);
/* 343 */     if (attribute != null) {
/* 344 */       AliasFor aliasFor = AnnotationsScanner.<AliasFor>getDeclaredAnnotation(attribute, AliasFor.class);
/* 345 */       return (aliasFor != null && aliasFor
/* 346 */         .annotation() != Annotation.class && aliasFor
/* 347 */         .annotation() != this.root.annotationType);
/*     */     } 
/* 349 */     return false;
/*     */   }
/*     */   
/*     */   private void addConventionAnnotationValues() {
/* 353 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 354 */       Method attribute = this.attributes.get(i);
/* 355 */       boolean isValueAttribute = "value".equals(attribute.getName());
/* 356 */       AnnotationTypeMapping mapping = this;
/* 357 */       while (mapping != null && mapping.distance > 0) {
/* 358 */         int mapped = mapping.getAttributes().indexOf(attribute.getName());
/* 359 */         if (mapped != -1 && isBetterConventionAnnotationValue(i, isValueAttribute, mapping)) {
/* 360 */           this.annotationValueMappings[i] = mapped;
/* 361 */           this.annotationValueSource[i] = mapping;
/*     */         } 
/* 363 */         mapping = mapping.source;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isBetterConventionAnnotationValue(int index, boolean isValueAttribute, AnnotationTypeMapping mapping) {
/* 371 */     if (this.annotationValueMappings[index] == -1) {
/* 372 */       return true;
/*     */     }
/* 374 */     int existingDistance = (this.annotationValueSource[index]).distance;
/* 375 */     return (!isValueAttribute && existingDistance > mapping.distance);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean computeSynthesizableFlag(Set<Class<? extends Annotation>> visitedAnnotationTypes) {
/* 381 */     visitedAnnotationTypes.add(this.annotationType);
/*     */ 
/*     */     
/* 384 */     for (int index : this.aliasMappings) {
/* 385 */       if (index != -1) {
/* 386 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 391 */     if (!this.aliasedBy.isEmpty()) {
/* 392 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 396 */     for (int index : this.conventionMappings) {
/* 397 */       if (index != -1) {
/* 398 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 403 */     if (getAttributes().hasNestedAnnotation()) {
/* 404 */       AttributeMethods attributeMethods = getAttributes();
/* 405 */       for (int i = 0; i < attributeMethods.size(); i++) {
/* 406 */         Method method = attributeMethods.get(i);
/* 407 */         Class<?> type = method.getReturnType();
/* 408 */         if (type.isAnnotation() || (type.isArray() && type.componentType().isAnnotation())) {
/*     */           
/* 410 */           Class<? extends Annotation> annotationType = type.isAnnotation() ? (Class)type : (Class)type.componentType();
/*     */ 
/*     */ 
/*     */           
/* 414 */           if (visitedAnnotationTypes.add(annotationType)) {
/*     */             
/* 416 */             AnnotationTypeMapping mapping = AnnotationTypeMappings.forAnnotationType(annotationType, visitedAnnotationTypes).get(0);
/* 417 */             if (mapping.isSynthesizable()) {
/* 418 */               return true;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 425 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void afterAllMappingsSet() {
/* 433 */     validateAllAliasesClaimed();
/* 434 */     for (int i = 0; i < this.mirrorSets.size(); i++) {
/* 435 */       validateMirrorSet(this.mirrorSets.get(i));
/*     */     }
/* 437 */     this.claimedAliases.clear();
/*     */   }
/*     */   
/*     */   private void validateAllAliasesClaimed() {
/* 441 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 442 */       Method attribute = this.attributes.get(i);
/* 443 */       AliasFor aliasFor = AnnotationsScanner.<AliasFor>getDeclaredAnnotation(attribute, AliasFor.class);
/* 444 */       if (aliasFor != null && !this.claimedAliases.contains(attribute)) {
/* 445 */         Method target = resolveAliasTarget(attribute, aliasFor);
/* 446 */         throw new AnnotationConfigurationException(String.format("@AliasFor declaration on %s declares an alias for %s which is not meta-present.", new Object[] {
/*     */                 
/* 448 */                 AttributeMethods.describe(attribute), AttributeMethods.describe(target) }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateMirrorSet(MirrorSets.MirrorSet mirrorSet) {
/* 454 */     Method firstAttribute = mirrorSet.get(0);
/* 455 */     Object firstDefaultValue = firstAttribute.getDefaultValue();
/* 456 */     for (int i = 1; i <= mirrorSet.size() - 1; i++) {
/* 457 */       Method mirrorAttribute = mirrorSet.get(i);
/* 458 */       Object mirrorDefaultValue = mirrorAttribute.getDefaultValue();
/* 459 */       if (firstDefaultValue == null || mirrorDefaultValue == null)
/* 460 */         throw new AnnotationConfigurationException(String.format("Misconfigured aliases: %s and %s must declare default values.", new Object[] {
/*     */                 
/* 462 */                 AttributeMethods.describe(firstAttribute), AttributeMethods.describe(mirrorAttribute)
/*     */               })); 
/* 464 */       if (!ObjectUtils.nullSafeEquals(firstDefaultValue, mirrorDefaultValue)) {
/* 465 */         throw new AnnotationConfigurationException(String.format("Misconfigured aliases: %s and %s must declare the same default value.", new Object[] {
/*     */                 
/* 467 */                 AttributeMethods.describe(firstAttribute), AttributeMethods.describe(mirrorAttribute)
/*     */               }));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationTypeMapping getRoot() {
/* 477 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   AnnotationTypeMapping getSource() {
/* 486 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getDistance() {
/* 494 */     return this.distance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<? extends Annotation> getAnnotationType() {
/* 502 */     return this.annotationType;
/*     */   }
/*     */   
/*     */   List<Class<? extends Annotation>> getMetaTypes() {
/* 506 */     return this.metaTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Annotation getAnnotation() {
/* 516 */     return this.annotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AttributeMethods getAttributes() {
/* 524 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getAliasMapping(int attributeIndex) {
/* 536 */     return this.aliasMappings[attributeIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getConventionMapping(int attributeIndex) {
/* 548 */     return this.conventionMappings[attributeIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Object getMappedAnnotationValue(int attributeIndex, boolean metaAnnotationsOnly) {
/* 565 */     int mappedIndex = this.annotationValueMappings[attributeIndex];
/* 566 */     if (mappedIndex == -1) {
/* 567 */       return null;
/*     */     }
/* 569 */     AnnotationTypeMapping source = this.annotationValueSource[attributeIndex];
/* 570 */     if (source == this && metaAnnotationsOnly) {
/* 571 */       return null;
/*     */     }
/* 573 */     return AnnotationUtils.invokeAnnotationMethod(source.attributes.get(mappedIndex), source.annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEquivalentToDefaultValue(int attributeIndex, Object value, ValueExtractor valueExtractor) {
/* 586 */     Method attribute = this.attributes.get(attributeIndex);
/* 587 */     return isEquivalentToDefaultValue(attribute, value, valueExtractor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MirrorSets getMirrorSets() {
/* 595 */     return this.mirrorSets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSynthesizable() {
/* 606 */     return this.synthesizable;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int[] filledIntArray(int size) {
/* 611 */     if (size == 0) {
/* 612 */       return EMPTY_INT_ARRAY;
/*     */     }
/* 614 */     int[] array = new int[size];
/* 615 */     Arrays.fill(array, -1);
/* 616 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isEquivalentToDefaultValue(Method attribute, Object value, ValueExtractor valueExtractor) {
/* 622 */     return areEquivalent(attribute.getDefaultValue(), value, valueExtractor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean areEquivalent(@Nullable Object value, @Nullable Object extractedValue, ValueExtractor valueExtractor) {
/* 628 */     if (ObjectUtils.nullSafeEquals(value, extractedValue)) {
/* 629 */       return true;
/*     */     }
/* 631 */     if (value instanceof Class) { Class<?> clazz = (Class)value; if (extractedValue instanceof String) { String string = (String)extractedValue;
/* 632 */         return areEquivalent(clazz, string); }
/*     */        }
/* 634 */      if (value instanceof Class[]) { Class<?>[] classes = (Class[])value; if (extractedValue instanceof String[]) { String[] strings = (String[])extractedValue;
/* 635 */         return areEquivalent(classes, strings); }
/*     */        }
/* 637 */      if (value instanceof Annotation) { Annotation annotation = (Annotation)value;
/* 638 */       return areEquivalent(annotation, extractedValue, valueExtractor); }
/*     */     
/* 640 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean areEquivalent(Class<?>[] value, String[] extractedValue) {
/* 644 */     if (value.length != extractedValue.length) {
/* 645 */       return false;
/*     */     }
/* 647 */     for (int i = 0; i < value.length; i++) {
/* 648 */       if (!areEquivalent(value[i], extractedValue[i])) {
/* 649 */         return false;
/*     */       }
/*     */     } 
/* 652 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean areEquivalent(Class<?> value, String extractedValue) {
/* 656 */     return value.getName().equals(extractedValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean areEquivalent(Annotation annotation, @Nullable Object extractedValue, ValueExtractor valueExtractor) {
/* 662 */     AttributeMethods attributes = AttributeMethods.forAnnotationType(annotation.annotationType());
/* 663 */     for (int i = 0; i < attributes.size(); i++) {
/* 664 */       Object value2; Method attribute = attributes.get(i);
/* 665 */       Object value1 = AnnotationUtils.invokeAnnotationMethod(attribute, annotation);
/*     */       
/* 667 */       if (extractedValue instanceof TypeMappedAnnotation) { TypeMappedAnnotation<?> typeMappedAnnotation = (TypeMappedAnnotation)extractedValue;
/* 668 */         value2 = typeMappedAnnotation.getValue(attribute.getName()).orElse(null); }
/*     */       else
/*     */       
/* 671 */       { value2 = valueExtractor.extract(attribute, extractedValue); }
/*     */       
/* 673 */       if (!areEquivalent(value1, value2, valueExtractor)) {
/* 674 */         return false;
/*     */       }
/*     */     } 
/* 677 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class MirrorSets
/*     */   {
/* 692 */     private final MirrorSet[] assigned = (AnnotationTypeMapping.this.attributes.size() > 0) ? new MirrorSet[AnnotationTypeMapping.this.attributes.size()] : AnnotationTypeMapping.EMPTY_MIRROR_SETS;
/* 693 */     private MirrorSet[] mirrorSets = AnnotationTypeMapping.EMPTY_MIRROR_SETS;
/*     */ 
/*     */     
/*     */     void updateFrom(Collection<Method> aliases) {
/* 697 */       MirrorSet mirrorSet = null;
/* 698 */       int size = 0;
/* 699 */       int last = -1;
/* 700 */       for (int i = 0; i < AnnotationTypeMapping.this.attributes.size(); i++) {
/* 701 */         Method attribute = AnnotationTypeMapping.this.attributes.get(i);
/* 702 */         if (aliases.contains(attribute)) {
/* 703 */           size++;
/* 704 */           if (size > 1) {
/* 705 */             if (mirrorSet == null) {
/* 706 */               mirrorSet = new MirrorSet();
/* 707 */               this.assigned[last] = mirrorSet;
/*     */             } 
/* 709 */             this.assigned[i] = mirrorSet;
/*     */           } 
/* 711 */           last = i;
/*     */         } 
/*     */       } 
/* 714 */       if (mirrorSet != null) {
/* 715 */         mirrorSet.update();
/* 716 */         Set<MirrorSet> unique = new LinkedHashSet<>(Arrays.asList(this.assigned));
/* 717 */         unique.remove(null);
/* 718 */         this.mirrorSets = unique.<MirrorSet>toArray(AnnotationTypeMapping.EMPTY_MIRROR_SETS);
/*     */       } 
/*     */     }
/*     */     
/*     */     int size() {
/* 723 */       return this.mirrorSets.length;
/*     */     }
/*     */     
/*     */     MirrorSet get(int index) {
/* 727 */       return this.mirrorSets[index];
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     MirrorSet getAssigned(int attributeIndex) {
/* 732 */       return this.assigned[attributeIndex];
/*     */     }
/*     */     
/*     */     int[] resolve(@Nullable Object source, @Nullable Object annotation, ValueExtractor valueExtractor) {
/* 736 */       if (AnnotationTypeMapping.this.attributes.size() == 0) {
/* 737 */         return AnnotationTypeMapping.EMPTY_INT_ARRAY;
/*     */       }
/* 739 */       int[] result = new int[AnnotationTypeMapping.this.attributes.size()]; int i;
/* 740 */       for (i = 0; i < result.length; i++) {
/* 741 */         result[i] = i;
/*     */       }
/* 743 */       for (i = 0; i < size(); i++) {
/* 744 */         MirrorSet mirrorSet = get(i);
/* 745 */         int resolved = mirrorSet.resolve(source, annotation, valueExtractor);
/* 746 */         for (int j = 0; j < mirrorSet.size; j++) {
/* 747 */           result[mirrorSet.indexes[j]] = resolved;
/*     */         }
/*     */       } 
/* 750 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     class MirrorSet
/*     */     {
/*     */       private int size;
/*     */ 
/*     */       
/* 761 */       private final int[] indexes = new int[AnnotationTypeMapping.this.attributes.size()];
/*     */       
/*     */       void update() {
/* 764 */         this.size = 0;
/* 765 */         Arrays.fill(this.indexes, -1);
/* 766 */         for (int i = 0; i < AnnotationTypeMapping.MirrorSets.this.assigned.length; i++) {
/* 767 */           if (AnnotationTypeMapping.MirrorSets.this.assigned[i] == this) {
/* 768 */             this.indexes[this.size] = i;
/* 769 */             this.size++;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/*     */       <A> int resolve(@Nullable Object source, @Nullable A annotation, ValueExtractor valueExtractor) {
/* 775 */         int result = -1;
/* 776 */         Object lastValue = null;
/* 777 */         for (int i = 0; i < this.size; i++) {
/* 778 */           Method attribute = AnnotationTypeMapping.this.attributes.get(this.indexes[i]);
/* 779 */           Object value = valueExtractor.extract(attribute, annotation);
/*     */           
/* 781 */           boolean isDefaultValue = (value == null || AnnotationTypeMapping.isEquivalentToDefaultValue(attribute, value, valueExtractor));
/* 782 */           if (isDefaultValue || ObjectUtils.nullSafeEquals(lastValue, value)) {
/* 783 */             if (result == -1) {
/* 784 */               result = this.indexes[i];
/*     */             }
/*     */           } else {
/*     */             
/* 788 */             if (lastValue != null && !ObjectUtils.nullSafeEquals(lastValue, value)) {
/* 789 */               String on = (source != null) ? (" declared on " + String.valueOf(source)) : "";
/* 790 */               throw new AnnotationConfigurationException(String.format("Different @AliasFor mirror values for annotation [%s]%s; attribute '%s' and its alias '%s' are declared with values of [%s] and [%s].", new Object[] { this.this$1.this$0
/*     */ 
/*     */                       
/* 793 */                       .getAnnotationType().getName(), on, this.this$1.this$0.attributes
/* 794 */                       .get(result).getName(), attribute
/* 795 */                       .getName(), 
/* 796 */                       ObjectUtils.nullSafeToString(lastValue), 
/* 797 */                       ObjectUtils.nullSafeToString(value) }));
/*     */             } 
/* 799 */             result = this.indexes[i];
/* 800 */             lastValue = value;
/*     */           } 
/* 802 */         }  return result;
/*     */       }
/*     */       
/*     */       int size() {
/* 806 */         return this.size;
/*     */       }
/*     */       
/*     */       Method get(int index) {
/* 810 */         int attributeIndex = this.indexes[index];
/* 811 */         return AnnotationTypeMapping.this.attributes.get(attributeIndex);
/*     */       }
/*     */       
/*     */       int getAttributeIndex(int index) {
/* 815 */         return this.indexes[index]; } } } class MirrorSet { int getAttributeIndex(int index) { return this.indexes[index]; }
/*     */ 
/*     */     
/*     */     private int size;
/*     */     private final int[] indexes;
/*     */     
/*     */     MirrorSet() {
/*     */       this.indexes = new int[AnnotationTypeMapping.this.attributes.size()];
/*     */     }
/*     */     
/*     */     void update() {
/*     */       this.size = 0;
/*     */       Arrays.fill(this.indexes, -1);
/*     */       for (int i = 0; i < AnnotationTypeMapping.MirrorSets.this.assigned.length; i++) {
/*     */         if (AnnotationTypeMapping.MirrorSets.this.assigned[i] == this) {
/*     */           this.indexes[this.size] = i;
/*     */           this.size++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     <A> int resolve(@Nullable Object source, @Nullable A annotation, ValueExtractor valueExtractor) {
/*     */       int result = -1;
/*     */       Object lastValue = null;
/*     */       for (int i = 0; i < this.size; i++) {
/*     */         Method attribute = AnnotationTypeMapping.this.attributes.get(this.indexes[i]);
/*     */         Object value = valueExtractor.extract(attribute, annotation);
/*     */         boolean isDefaultValue = (value == null || AnnotationTypeMapping.isEquivalentToDefaultValue(attribute, value, valueExtractor));
/*     */         if (isDefaultValue || ObjectUtils.nullSafeEquals(lastValue, value)) {
/*     */           if (result == -1)
/*     */             result = this.indexes[i]; 
/*     */         } else {
/*     */           if (lastValue != null && !ObjectUtils.nullSafeEquals(lastValue, value)) {
/*     */             String on = (source != null) ? (" declared on " + String.valueOf(source)) : "";
/*     */             throw new AnnotationConfigurationException(String.format("Different @AliasFor mirror values for annotation [%s]%s; attribute '%s' and its alias '%s' are declared with values of [%s] and [%s].", new Object[] { this.this$1.this$0.getAnnotationType().getName(), on, this.this$1.this$0.attributes.get(result).getName(), attribute.getName(), ObjectUtils.nullSafeToString(lastValue), ObjectUtils.nullSafeToString(value) }));
/*     */           } 
/*     */           result = this.indexes[i];
/*     */           lastValue = value;
/*     */         } 
/*     */       } 
/*     */       return result;
/*     */     }
/*     */     
/*     */     int size() {
/*     */       return this.size;
/*     */     }
/*     */     
/*     */     Method get(int index) {
/*     */       int attributeIndex = this.indexes[index];
/*     */       return AnnotationTypeMapping.this.attributes.get(attributeIndex);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationTypeMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */