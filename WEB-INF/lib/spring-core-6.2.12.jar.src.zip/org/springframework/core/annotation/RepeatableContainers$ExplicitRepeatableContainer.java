/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Repeatable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExplicitRepeatableContainer
/*     */   extends RepeatableContainers
/*     */ {
/*     */   private final Class<? extends Annotation> repeatable;
/*     */   private final Class<? extends Annotation> container;
/*     */   private final Method valueMethod;
/*     */   
/*     */   ExplicitRepeatableContainer(@Nullable RepeatableContainers parent, Class<? extends Annotation> repeatable, @Nullable Class<? extends Annotation> container) {
/* 206 */     super(parent);
/* 207 */     Assert.notNull(repeatable, "Repeatable must not be null");
/* 208 */     if (container == null) {
/* 209 */       container = deduceContainer(repeatable);
/*     */     }
/* 211 */     Method valueMethod = AttributeMethods.forAnnotationType(container).get("value");
/*     */     try {
/* 213 */       if (valueMethod == null) {
/* 214 */         throw new NoSuchMethodException("No value method found");
/*     */       }
/* 216 */       Class<?> returnType = valueMethod.getReturnType();
/* 217 */       if (!returnType.isArray() || returnType.componentType() != repeatable) {
/* 218 */         throw new AnnotationConfigurationException("Container type [%s] must declare a 'value' attribute for an array of type [%s]"
/*     */             
/* 220 */             .formatted(new Object[] { container.getName(), repeatable.getName() }));
/*     */       }
/*     */     }
/* 223 */     catch (AnnotationConfigurationException ex) {
/* 224 */       throw ex;
/*     */     }
/* 226 */     catch (Throwable ex) {
/* 227 */       throw new AnnotationConfigurationException("Invalid declaration of container type [%s] for repeatable annotation [%s]"
/*     */           
/* 229 */           .formatted(new Object[] { container.getName(), repeatable.getName() }, ), ex);
/*     */     } 
/* 231 */     this.repeatable = repeatable;
/* 232 */     this.container = container;
/* 233 */     this.valueMethod = valueMethod;
/*     */   }
/*     */   
/*     */   private Class<? extends Annotation> deduceContainer(Class<? extends Annotation> repeatable) {
/* 237 */     Repeatable annotation = repeatable.<Repeatable>getAnnotation(Repeatable.class);
/* 238 */     Assert.notNull(annotation, () -> "Annotation type must be a repeatable annotation: failed to resolve container type for " + repeatable.getName());
/*     */     
/* 240 */     return annotation.value();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Annotation[] findRepeatedAnnotations(Annotation annotation) {
/* 246 */     if (this.container.isAssignableFrom(annotation.annotationType())) {
/* 247 */       return (Annotation[])AnnotationUtils.invokeAnnotationMethod(this.valueMethod, annotation);
/*     */     }
/* 249 */     return super.findRepeatedAnnotations(annotation);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 254 */     if (!super.equals(other)) {
/* 255 */       return false;
/*     */     }
/* 257 */     ExplicitRepeatableContainer otherErc = (ExplicitRepeatableContainer)other;
/* 258 */     return (this.container.equals(otherErc.container) && this.repeatable.equals(otherErc.repeatable));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 263 */     int hashCode = super.hashCode();
/* 264 */     hashCode = 31 * hashCode + this.container.hashCode();
/* 265 */     hashCode = 31 * hashCode + this.repeatable.hashCode();
/* 266 */     return hashCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\RepeatableContainers$ExplicitRepeatableContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */