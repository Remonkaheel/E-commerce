/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Repeatable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Contract;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RepeatableContainers
/*     */ {
/*  48 */   static final Map<Class<? extends Annotation>, Object> cache = (Map<Class<? extends Annotation>, Object>)new ConcurrentReferenceHashMap();
/*     */   
/*     */   @Nullable
/*     */   private final RepeatableContainers parent;
/*     */ 
/*     */   
/*     */   private RepeatableContainers(@Nullable RepeatableContainers parent) {
/*  55 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RepeatableContainers and(Class<? extends Annotation> container, Class<? extends Annotation> repeatable) {
/*  71 */     return new ExplicitRepeatableContainer(this, repeatable, container);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Annotation[] findRepeatedAnnotations(Annotation annotation) {
/*  76 */     if (this.parent == null) {
/*  77 */       return null;
/*     */     }
/*  79 */     return this.parent.findRepeatedAnnotations(annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null -> false")
/*     */   public boolean equals(@Nullable Object other) {
/*  86 */     if (other == this) {
/*  87 */       return true;
/*     */     }
/*  89 */     if (other == null || getClass() != other.getClass()) {
/*  90 */       return false;
/*     */     }
/*  92 */     return ObjectUtils.nullSafeEquals(this.parent, ((RepeatableContainers)other).parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     return Objects.hashCode(this.parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RepeatableContainers standardRepeatables() {
/* 107 */     return StandardRepeatableContainers.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RepeatableContainers of(Class<? extends Annotation> repeatable, @Nullable Class<? extends Annotation> container) {
/* 130 */     return new ExplicitRepeatableContainer(null, repeatable, container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RepeatableContainers none() {
/* 139 */     return NoRepeatableContainers.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StandardRepeatableContainers
/*     */     extends RepeatableContainers
/*     */   {
/* 149 */     private static final Object NONE = new Object();
/*     */     
/* 151 */     private static final StandardRepeatableContainers INSTANCE = new StandardRepeatableContainers();
/*     */     
/*     */     StandardRepeatableContainers() {
/* 154 */       super(null);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Annotation[] findRepeatedAnnotations(Annotation annotation) {
/* 160 */       Method method = getRepeatedAnnotationsMethod(annotation.annotationType());
/* 161 */       if (method != null) {
/* 162 */         return (Annotation[])AnnotationUtils.invokeAnnotationMethod(method, annotation);
/*     */       }
/* 164 */       return super.findRepeatedAnnotations(annotation);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private static Method getRepeatedAnnotationsMethod(Class<? extends Annotation> annotationType) {
/* 169 */       Object result = cache.computeIfAbsent(annotationType, StandardRepeatableContainers::computeRepeatedAnnotationsMethod);
/*     */       
/* 171 */       return (result != NONE) ? (Method)result : null;
/*     */     }
/*     */     
/*     */     private static Object computeRepeatedAnnotationsMethod(Class<? extends Annotation> annotationType) {
/* 175 */       AttributeMethods methods = AttributeMethods.forAnnotationType(annotationType);
/* 176 */       Method method = methods.get("value");
/* 177 */       if (method != null) {
/* 178 */         Class<?> returnType = method.getReturnType();
/* 179 */         if (returnType.isArray()) {
/* 180 */           Class<?> componentType = returnType.componentType();
/* 181 */           if (Annotation.class.isAssignableFrom(componentType) && componentType
/* 182 */             .isAnnotationPresent((Class)Repeatable.class)) {
/* 183 */             return method;
/*     */           }
/*     */         } 
/*     */       } 
/* 187 */       return NONE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ExplicitRepeatableContainer
/*     */     extends RepeatableContainers
/*     */   {
/*     */     private final Class<? extends Annotation> repeatable;
/*     */ 
/*     */     
/*     */     private final Class<? extends Annotation> container;
/*     */ 
/*     */     
/*     */     private final Method valueMethod;
/*     */ 
/*     */     
/*     */     ExplicitRepeatableContainer(@Nullable RepeatableContainers parent, Class<? extends Annotation> repeatable, @Nullable Class<? extends Annotation> container) {
/* 206 */       super(parent);
/* 207 */       Assert.notNull(repeatable, "Repeatable must not be null");
/* 208 */       if (container == null) {
/* 209 */         container = deduceContainer(repeatable);
/*     */       }
/* 211 */       Method valueMethod = AttributeMethods.forAnnotationType(container).get("value");
/*     */       try {
/* 213 */         if (valueMethod == null) {
/* 214 */           throw new NoSuchMethodException("No value method found");
/*     */         }
/* 216 */         Class<?> returnType = valueMethod.getReturnType();
/* 217 */         if (!returnType.isArray() || returnType.componentType() != repeatable) {
/* 218 */           throw new AnnotationConfigurationException("Container type [%s] must declare a 'value' attribute for an array of type [%s]"
/*     */               
/* 220 */               .formatted(new Object[] { container.getName(), repeatable.getName() }));
/*     */         }
/*     */       }
/* 223 */       catch (AnnotationConfigurationException ex) {
/* 224 */         throw ex;
/*     */       }
/* 226 */       catch (Throwable ex) {
/* 227 */         throw new AnnotationConfigurationException("Invalid declaration of container type [%s] for repeatable annotation [%s]"
/*     */             
/* 229 */             .formatted(new Object[] { container.getName(), repeatable.getName() }, ), ex);
/*     */       } 
/* 231 */       this.repeatable = repeatable;
/* 232 */       this.container = container;
/* 233 */       this.valueMethod = valueMethod;
/*     */     }
/*     */     
/*     */     private Class<? extends Annotation> deduceContainer(Class<? extends Annotation> repeatable) {
/* 237 */       Repeatable annotation = repeatable.<Repeatable>getAnnotation(Repeatable.class);
/* 238 */       Assert.notNull(annotation, () -> "Annotation type must be a repeatable annotation: failed to resolve container type for " + repeatable.getName());
/*     */       
/* 240 */       return annotation.value();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Annotation[] findRepeatedAnnotations(Annotation annotation) {
/* 246 */       if (this.container.isAssignableFrom(annotation.annotationType())) {
/* 247 */         return (Annotation[])AnnotationUtils.invokeAnnotationMethod(this.valueMethod, annotation);
/*     */       }
/* 249 */       return super.findRepeatedAnnotations(annotation);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 254 */       if (!super.equals(other)) {
/* 255 */         return false;
/*     */       }
/* 257 */       ExplicitRepeatableContainer otherErc = (ExplicitRepeatableContainer)other;
/* 258 */       return (this.container.equals(otherErc.container) && this.repeatable.equals(otherErc.repeatable));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 263 */       int hashCode = super.hashCode();
/* 264 */       hashCode = 31 * hashCode + this.container.hashCode();
/* 265 */       hashCode = 31 * hashCode + this.repeatable.hashCode();
/* 266 */       return hashCode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NoRepeatableContainers
/*     */     extends RepeatableContainers
/*     */   {
/* 276 */     private static final NoRepeatableContainers INSTANCE = new NoRepeatableContainers();
/*     */     
/*     */     NoRepeatableContainers() {
/* 279 */       super(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\RepeatableContainers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */