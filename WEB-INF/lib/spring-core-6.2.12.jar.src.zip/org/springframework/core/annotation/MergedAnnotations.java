/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.Collection;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MergedAnnotations
/*     */   extends Iterable<MergedAnnotation<Annotation>>
/*     */ {
/*     */   <A extends Annotation> boolean isPresent(Class<A> paramClass);
/*     */   
/*     */   boolean isPresent(String paramString);
/*     */   
/*     */   <A extends Annotation> boolean isDirectlyPresent(Class<A> paramClass);
/*     */   
/*     */   boolean isDirectlyPresent(String paramString);
/*     */   
/*     */   <A extends Annotation> MergedAnnotation<A> get(Class<A> paramClass);
/*     */   
/*     */   <A extends Annotation> MergedAnnotation<A> get(Class<A> paramClass, @Nullable Predicate<? super MergedAnnotation<A>> paramPredicate);
/*     */   
/*     */   <A extends Annotation> MergedAnnotation<A> get(Class<A> paramClass, @Nullable Predicate<? super MergedAnnotation<A>> paramPredicate, @Nullable MergedAnnotationSelector<A> paramMergedAnnotationSelector);
/*     */   
/*     */   <A extends Annotation> MergedAnnotation<A> get(String paramString);
/*     */   
/*     */   <A extends Annotation> MergedAnnotation<A> get(String paramString, @Nullable Predicate<? super MergedAnnotation<A>> paramPredicate);
/*     */   
/*     */   <A extends Annotation> MergedAnnotation<A> get(String paramString, @Nullable Predicate<? super MergedAnnotation<A>> paramPredicate, @Nullable MergedAnnotationSelector<A> paramMergedAnnotationSelector);
/*     */   
/*     */   <A extends Annotation> Stream<MergedAnnotation<A>> stream(Class<A> paramClass);
/*     */   
/*     */   <A extends Annotation> Stream<MergedAnnotation<A>> stream(String paramString);
/*     */   
/*     */   Stream<MergedAnnotation<Annotation>> stream();
/*     */   
/*     */   static MergedAnnotations from(AnnotatedElement element) {
/* 310 */     return from(element, SearchStrategy.DIRECT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(AnnotatedElement element, SearchStrategy searchStrategy) {
/* 324 */     return from(element, searchStrategy, RepeatableContainers.standardRepeatables());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(AnnotatedElement element, SearchStrategy searchStrategy, RepeatableContainers repeatableContainers) {
/* 342 */     return from(element, searchStrategy, repeatableContainers, AnnotationFilter.PLAIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(AnnotatedElement element, SearchStrategy searchStrategy, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/* 362 */     return from(element, searchStrategy, Search.never, repeatableContainers, annotationFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MergedAnnotations from(AnnotatedElement element, SearchStrategy searchStrategy, Predicate<Class<?>> searchEnclosingClass, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/* 369 */     Assert.notNull(element, "AnnotatedElement must not be null");
/* 370 */     Assert.notNull(searchStrategy, "SearchStrategy must not be null");
/* 371 */     Assert.notNull(searchEnclosingClass, "Predicate must not be null");
/* 372 */     Assert.notNull(repeatableContainers, "RepeatableContainers must not be null");
/* 373 */     Assert.notNull(annotationFilter, "AnnotationFilter must not be null");
/* 374 */     return TypeMappedAnnotations.from(element, searchStrategy, searchEnclosingClass, repeatableContainers, annotationFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(Annotation... annotations) {
/* 386 */     return from(annotations, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(Object source, Annotation... annotations) {
/* 401 */     return from(source, annotations, RepeatableContainers.standardRepeatables());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(Object source, Annotation[] annotations, RepeatableContainers repeatableContainers) {
/* 416 */     return from(source, annotations, repeatableContainers, AnnotationFilter.PLAIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations from(Object source, Annotation[] annotations, RepeatableContainers repeatableContainers, AnnotationFilter annotationFilter) {
/* 435 */     Assert.notNull(repeatableContainers, "RepeatableContainers must not be null");
/* 436 */     Assert.notNull(annotationFilter, "AnnotationFilter must not be null");
/* 437 */     return TypeMappedAnnotations.from(source, annotations, repeatableContainers, annotationFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MergedAnnotations of(Collection<MergedAnnotation<?>> annotations) {
/* 456 */     return MergedAnnotationsCollection.of(annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Search search(SearchStrategy searchStrategy) {
/* 468 */     Assert.notNull(searchStrategy, "SearchStrategy must not be null");
/* 469 */     return new Search(searchStrategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Search
/*     */   {
/*     */     static final Predicate<Class<?>> always = clazz -> true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static final Predicate<Class<?>> never = clazz -> false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MergedAnnotations.SearchStrategy searchStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 522 */     private Predicate<Class<?>> searchEnclosingClass = never;
/*     */     
/* 524 */     private RepeatableContainers repeatableContainers = RepeatableContainers.standardRepeatables();
/*     */     
/* 526 */     private AnnotationFilter annotationFilter = AnnotationFilter.PLAIN;
/*     */ 
/*     */     
/*     */     private Search(MergedAnnotations.SearchStrategy searchStrategy) {
/* 530 */       this.searchStrategy = searchStrategy;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Search withEnclosingClasses(Predicate<Class<?>> searchEnclosingClass) {
/* 569 */       Assert.notNull(searchEnclosingClass, "Predicate must not be null");
/* 570 */       Assert.state((this.searchStrategy == MergedAnnotations.SearchStrategy.TYPE_HIERARCHY), "A custom 'searchEnclosingClass' predicate can only be combined with SearchStrategy.TYPE_HIERARCHY");
/*     */       
/* 572 */       this.searchEnclosingClass = searchEnclosingClass;
/* 573 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Search withRepeatableContainers(RepeatableContainers repeatableContainers) {
/* 586 */       Assert.notNull(repeatableContainers, "RepeatableContainers must not be null");
/* 587 */       this.repeatableContainers = repeatableContainers;
/* 588 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Search withAnnotationFilter(AnnotationFilter annotationFilter) {
/* 601 */       Assert.notNull(annotationFilter, "AnnotationFilter must not be null");
/* 602 */       this.annotationFilter = annotationFilter;
/* 603 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MergedAnnotations from(AnnotatedElement element) {
/* 620 */       return MergedAnnotations.from(element, this.searchStrategy, this.searchEnclosingClass, this.repeatableContainers, this.annotationFilter);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SearchStrategy
/*     */   {
/* 641 */     DIRECT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 651 */     INHERITED_ANNOTATIONS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 660 */     SUPERCLASS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 672 */     TYPE_HIERARCHY;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\MergedAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */