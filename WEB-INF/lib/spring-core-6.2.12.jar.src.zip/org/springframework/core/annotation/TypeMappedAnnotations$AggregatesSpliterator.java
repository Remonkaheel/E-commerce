/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import java.util.Spliterator;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AggregatesSpliterator<A extends Annotation>
/*     */   implements Spliterator<MergedAnnotation<A>>
/*     */ {
/*     */   @Nullable
/*     */   private final Object requiredType;
/*     */   private final List<TypeMappedAnnotations.Aggregate> aggregates;
/*     */   private int aggregateCursor;
/*     */   @Nullable
/*     */   private int[] mappingCursors;
/*     */   
/*     */   AggregatesSpliterator(Object requiredType, List<TypeMappedAnnotations.Aggregate> aggregates) {
/* 568 */     this.requiredType = requiredType;
/* 569 */     this.aggregates = aggregates;
/* 570 */     this.aggregateCursor = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean tryAdvance(Consumer<? super MergedAnnotation<A>> action) {
/* 575 */     while (this.aggregateCursor < this.aggregates.size()) {
/* 576 */       TypeMappedAnnotations.Aggregate aggregate = this.aggregates.get(this.aggregateCursor);
/* 577 */       if (tryAdvance(aggregate, action)) {
/* 578 */         return true;
/*     */       }
/* 580 */       this.aggregateCursor++;
/* 581 */       this.mappingCursors = null;
/*     */     } 
/* 583 */     return false;
/*     */   }
/*     */   
/*     */   private boolean tryAdvance(TypeMappedAnnotations.Aggregate aggregate, Consumer<? super MergedAnnotation<A>> action) {
/* 587 */     if (this.mappingCursors == null) {
/* 588 */       this.mappingCursors = new int[aggregate.size()];
/*     */     }
/* 590 */     int lowestDistance = Integer.MAX_VALUE;
/* 591 */     int annotationResult = -1;
/* 592 */     for (int annotationIndex = 0; annotationIndex < aggregate.size(); annotationIndex++) {
/* 593 */       AnnotationTypeMapping mapping = getNextSuitableMapping(aggregate, annotationIndex);
/* 594 */       if (mapping != null && mapping.getDistance() < lowestDistance) {
/* 595 */         annotationResult = annotationIndex;
/* 596 */         lowestDistance = mapping.getDistance();
/*     */       } 
/* 598 */       if (lowestDistance == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/* 602 */     if (annotationResult != -1) {
/* 603 */       MergedAnnotation<A> mergedAnnotation = aggregate.createMergedAnnotationIfPossible(annotationResult, this.mappingCursors[annotationResult], 
/*     */           
/* 605 */           (this.requiredType != null) ? IntrospectionFailureLogger.INFO : IntrospectionFailureLogger.DEBUG);
/* 606 */       this.mappingCursors[annotationResult] = this.mappingCursors[annotationResult] + 1;
/* 607 */       if (mergedAnnotation == null) {
/* 608 */         return tryAdvance(aggregate, action);
/*     */       }
/* 610 */       action.accept(mergedAnnotation);
/* 611 */       return true;
/*     */     } 
/* 613 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private AnnotationTypeMapping getNextSuitableMapping(TypeMappedAnnotations.Aggregate aggregate, int annotationIndex) {
/* 618 */     int[] cursors = this.mappingCursors;
/* 619 */     if (cursors != null) {
/*     */       AnnotationTypeMapping mapping;
/*     */       do {
/* 622 */         mapping = aggregate.getMapping(annotationIndex, cursors[annotationIndex]);
/* 623 */         if (mapping != null && TypeMappedAnnotations.isMappingForType(mapping, TypeMappedAnnotations.this.annotationFilter, this.requiredType)) {
/* 624 */           return mapping;
/*     */         }
/* 626 */         cursors[annotationIndex] = cursors[annotationIndex] + 1;
/*     */       }
/* 628 */       while (mapping != null);
/*     */     } 
/* 630 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Spliterator<MergedAnnotation<A>> trySplit() {
/* 636 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long estimateSize() {
/* 641 */     int size = 0;
/* 642 */     int aggregateIndex = this.aggregateCursor;
/* 643 */     for (; aggregateIndex < this.aggregates.size(); aggregateIndex++) {
/* 644 */       TypeMappedAnnotations.Aggregate aggregate = this.aggregates.get(aggregateIndex);
/* 645 */       for (int annotationIndex = 0; annotationIndex < aggregate.size(); annotationIndex++) {
/* 646 */         AnnotationTypeMappings mappings = aggregate.getMappings(annotationIndex);
/* 647 */         int numberOfMappings = mappings.size();
/* 648 */         if (aggregateIndex == this.aggregateCursor && this.mappingCursors != null) {
/* 649 */           numberOfMappings -= Math.min(this.mappingCursors[annotationIndex], mappings.size());
/*     */         }
/* 651 */         size += numberOfMappings;
/*     */       } 
/*     */     } 
/* 654 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public int characteristics() {
/* 659 */     return 1280;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\TypeMappedAnnotations$AggregatesSpliterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */