/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationAttributes
/*     */   extends LinkedHashMap<String, Object>
/*     */ {
/*     */   private static final String UNKNOWN = "unknown";
/*     */   @Nullable
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   final String displayName;
/*     */   final boolean validated;
/*     */   
/*     */   public AnnotationAttributes() {
/*  63 */     this.annotationType = null;
/*  64 */     this.displayName = "unknown";
/*  65 */     this.validated = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes(int initialCapacity) {
/*  74 */     super(initialCapacity);
/*  75 */     this.annotationType = null;
/*  76 */     this.displayName = "unknown";
/*  77 */     this.validated = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes(Map<String, Object> map) {
/*  87 */     super(map);
/*  88 */     this.annotationType = null;
/*  89 */     this.displayName = "unknown";
/*  90 */     this.validated = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes(AnnotationAttributes other) {
/* 100 */     super(other);
/* 101 */     this.annotationType = other.annotationType;
/* 102 */     this.displayName = other.displayName;
/* 103 */     this.validated = other.validated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes(Class<? extends Annotation> annotationType) {
/* 114 */     this(annotationType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationAttributes(Class<? extends Annotation> annotationType, boolean validated) {
/* 127 */     Assert.notNull(annotationType, "'annotationType' must not be null");
/* 128 */     this.annotationType = annotationType;
/* 129 */     this.displayName = annotationType.getName();
/* 130 */     this.validated = validated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes(String annotationType, @Nullable ClassLoader classLoader) {
/* 143 */     Assert.notNull(annotationType, "'annotationType' must not be null");
/* 144 */     this.annotationType = getAnnotationType(annotationType, classLoader);
/* 145 */     this.displayName = annotationType;
/* 146 */     this.validated = false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Class<? extends Annotation> getAnnotationType(String annotationType, @Nullable ClassLoader classLoader) {
/* 152 */     if (classLoader != null) {
/*     */       try {
/* 154 */         return (Class)classLoader.loadClass(annotationType);
/*     */       }
/* 156 */       catch (ClassNotFoundException classNotFoundException) {}
/*     */     }
/*     */ 
/*     */     
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<? extends Annotation> annotationType() {
/* 171 */     return this.annotationType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String attributeName) {
/* 183 */     return getRequiredAttribute(attributeName, String.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getStringArray(String attributeName) {
/* 199 */     return getRequiredAttribute(attributeName, (Class)String[].class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String attributeName) {
/* 211 */     return ((Boolean)getRequiredAttribute(attributeName, Boolean.class)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <N extends Number> N getNumber(String attributeName) {
/* 224 */     return (N)getRequiredAttribute(attributeName, Number.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E getEnum(String attributeName) {
/* 237 */     return (E)getRequiredAttribute(attributeName, Enum.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Class<? extends T> getClass(String attributeName) {
/* 250 */     return getRequiredAttribute(attributeName, (Class)Class.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] getClassArray(String attributeName) {
/* 265 */     return getRequiredAttribute(attributeName, (Class)Class[].class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes getAnnotation(String attributeName) {
/* 280 */     return getRequiredAttribute(attributeName, AnnotationAttributes.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(String attributeName, Class<A> annotationType) {
/* 295 */     return (A)getRequiredAttribute(attributeName, annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes[] getAnnotationArray(String attributeName) {
/* 313 */     return getRequiredAttribute(attributeName, (Class)AnnotationAttributes[].class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A[] getAnnotationArray(String attributeName, Class<A> annotationType) {
/* 332 */     return (A[])getRequiredAttribute(attributeName, annotationType.arrayType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T getRequiredAttribute(String attributeName, Class<T> expectedType) {
/* 352 */     Assert.hasText(attributeName, "'attributeName' must not be null or empty");
/* 353 */     Object value = get(attributeName);
/* 354 */     if (value == null) {
/* 355 */       throw new IllegalArgumentException(String.format("Attribute '%s' not found in attributes for annotation [%s]", new Object[] { attributeName, this.displayName }));
/*     */     }
/*     */ 
/*     */     
/* 359 */     if (value instanceof Throwable) { Throwable throwable = (Throwable)value;
/* 360 */       throw new IllegalArgumentException(String.format("Attribute '%s' for annotation [%s] was not resolvable due to exception [%s]", new Object[] { attributeName, this.displayName, value }), throwable); }
/*     */ 
/*     */ 
/*     */     
/* 364 */     if (!expectedType.isInstance(value) && expectedType.isArray() && expectedType
/* 365 */       .componentType().isInstance(value)) {
/* 366 */       Object array = Array.newInstance(expectedType.componentType(), 1);
/* 367 */       Array.set(array, 0, value);
/* 368 */       value = array;
/*     */     } 
/* 370 */     if (!expectedType.isInstance(value)) {
/* 371 */       throw new IllegalArgumentException(String.format("Attribute '%s' is of type %s, but %s was expected in attributes for annotation [%s]", new Object[] { attributeName, value
/*     */               
/* 373 */               .getClass().getSimpleName(), expectedType.getSimpleName(), this.displayName }));
/*     */     }
/*     */     
/* 376 */     return (T)value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 381 */     Iterator<Map.Entry<String, Object>> entries = entrySet().iterator();
/* 382 */     StringBuilder sb = new StringBuilder("{");
/* 383 */     while (entries.hasNext()) {
/* 384 */       Map.Entry<String, Object> entry = entries.next();
/* 385 */       sb.append(entry.getKey());
/* 386 */       sb.append('=');
/* 387 */       sb.append(valueToString(entry.getValue()));
/* 388 */       if (entries.hasNext()) {
/* 389 */         sb.append(", ");
/*     */       }
/*     */     } 
/* 392 */     sb.append('}');
/* 393 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private String valueToString(Object value) {
/* 397 */     if (value == this) {
/* 398 */       return "(this Map)";
/*     */     }
/* 400 */     if (value instanceof Object[]) { Object[] objects = (Object[])value;
/* 401 */       return "[" + StringUtils.arrayToDelimitedString(objects, ", ") + "]"; }
/*     */     
/* 403 */     return String.valueOf(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static AnnotationAttributes fromMap(@Nullable Map<String, Object> map) {
/* 417 */     if (map == null) {
/* 418 */       return null;
/*     */     }
/* 420 */     if (map instanceof AnnotationAttributes) { AnnotationAttributes annotationAttributes = (AnnotationAttributes)map;
/* 421 */       return annotationAttributes; }
/*     */     
/* 423 */     return new AnnotationAttributes(map);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\AnnotationAttributes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */