/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface MergedAnnotationSelector<A extends java.lang.annotation.Annotation>
/*    */ {
/*    */   default boolean isBestCandidate(MergedAnnotation<A> annotation) {
/* 40 */     return false;
/*    */   }
/*    */   
/*    */   MergedAnnotation<A> select(MergedAnnotation<A> paramMergedAnnotation1, MergedAnnotation<A> paramMergedAnnotation2);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\annotation\MergedAnnotationSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */