/*     */ package org.springframework.core.codec;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CoderMalfunctionError;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharSequenceEncoder
/*     */   extends AbstractEncoder<CharSequence>
/*     */ {
/*  52 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */   
/*  54 */   private final ConcurrentMap<Charset, Float> charsetToMaxBytesPerChar = new ConcurrentHashMap<>(3);
/*     */ 
/*     */   
/*     */   private CharSequenceEncoder(MimeType... mimeTypes) {
/*  58 */     super(mimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  64 */     Class<?> clazz = elementType.toClass();
/*  65 */     return (super.canEncode(elementType, mimeType) && CharSequence.class.isAssignableFrom(clazz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> encode(Publisher<? extends CharSequence> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  73 */     return Flux.from(inputStream).map(charSequence -> encodeValue(charSequence, bufferFactory, elementType, mimeType, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBuffer encodeValue(CharSequence charSequence, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  81 */     if (!Hints.isLoggingSuppressed(hints)) {
/*  82 */       LogFormatUtils.traceDebug(this.logger, traceOn -> {
/*     */             String formatted = LogFormatUtils.formatValue(charSequence, !traceOn.booleanValue());
/*     */             return Hints.getLogPrefix(hints) + "Writing " + Hints.getLogPrefix(hints);
/*     */           });
/*     */     }
/*  87 */     boolean release = true;
/*  88 */     Charset charset = getCharset(mimeType);
/*  89 */     int capacity = calculateCapacity(charSequence, charset);
/*  90 */     DataBuffer dataBuffer = bufferFactory.allocateBuffer(capacity);
/*     */     try {
/*  92 */       dataBuffer.write(charSequence, charset);
/*  93 */       release = false;
/*     */     }
/*  95 */     catch (CoderMalfunctionError ex) {
/*  96 */       throw new EncodingException("String encoding error: " + ex.getMessage(), ex);
/*     */     } finally {
/*     */       
/*  99 */       if (release) {
/* 100 */         DataBufferUtils.release(dataBuffer);
/*     */       }
/*     */     } 
/* 103 */     return dataBuffer;
/*     */   }
/*     */   
/*     */   int calculateCapacity(CharSequence sequence, Charset charset) {
/* 107 */     float maxBytesPerChar = ((Float)this.charsetToMaxBytesPerChar.computeIfAbsent(charset, cs -> Float.valueOf(cs.newEncoder().maxBytesPerChar()))).floatValue();
/*     */     
/* 109 */     float maxBytesForSequence = sequence.length() * maxBytesPerChar;
/* 110 */     return (int)Math.ceil(maxBytesForSequence);
/*     */   }
/*     */   
/*     */   private Charset getCharset(@Nullable MimeType mimeType) {
/* 114 */     if (mimeType != null && mimeType.getCharset() != null) {
/* 115 */       return mimeType.getCharset();
/*     */     }
/*     */     
/* 118 */     return DEFAULT_CHARSET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequenceEncoder textPlainOnly() {
/* 127 */     return new CharSequenceEncoder(new MimeType[] { new MimeType("text", "plain", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequenceEncoder allMimeTypes() {
/* 134 */     return new CharSequenceEncoder(new MimeType[] { new MimeType("text", "plain", DEFAULT_CHARSET), MimeTypeUtils.ALL });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\CharSequenceEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */