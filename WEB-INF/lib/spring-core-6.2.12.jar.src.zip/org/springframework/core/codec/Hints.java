/*     */ package org.springframework.core.codec;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Hints
/*     */ {
/*  42 */   public static final String LOG_PREFIX_HINT = Log.class.getName() + ".PREFIX";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final String SUPPRESS_LOGGING_HINT = Log.class.getName() + ".SUPPRESS_LOGGING";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> from(String hintName, Object value) {
/*  59 */     return Collections.singletonMap(hintName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> none() {
/*  67 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getRequiredHint(@Nullable Map<String, Object> hints, String hintName) {
/*  80 */     if (hints == null) {
/*  81 */       throw new IllegalArgumentException("No hints map for required hint '" + hintName + "'");
/*     */     }
/*  83 */     T hint = (T)hints.get(hintName);
/*  84 */     if (hint == null) {
/*  85 */       throw new IllegalArgumentException("Hints map must contain the hint '" + hintName + "'");
/*     */     }
/*  87 */     return hint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLogPrefix(@Nullable Map<String, Object> hints) {
/*  96 */     return (hints != null) ? (String)hints.getOrDefault(LOG_PREFIX_HINT, "") : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLoggingSuppressed(@Nullable Map<String, Object> hints) {
/* 105 */     return (hints != null && ((Boolean)hints.getOrDefault(SUPPRESS_LOGGING_HINT, Boolean.valueOf(false))).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> merge(@Nullable Map<String, Object> hints1, @Nullable Map<String, Object> hints2) {
/* 118 */     if (ObjectUtils.isEmpty(hints1) && ObjectUtils.isEmpty(hints2)) {
/* 119 */       return Collections.emptyMap();
/*     */     }
/* 121 */     if (ObjectUtils.isEmpty(hints2)) {
/* 122 */       return (hints1 != null) ? hints1 : Collections.<String, Object>emptyMap();
/*     */     }
/* 124 */     if (ObjectUtils.isEmpty(hints1)) {
/* 125 */       return hints2;
/*     */     }
/* 127 */     Map<String, Object> result = CollectionUtils.newHashMap(hints1.size() + hints2.size());
/* 128 */     result.putAll(hints1);
/* 129 */     result.putAll(hints2);
/* 130 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> merge(@Nullable Map<String, Object> hints, String hintName, Object hintValue) {
/* 143 */     if (ObjectUtils.isEmpty(hints)) {
/* 144 */       return Collections.singletonMap(hintName, hintValue);
/*     */     }
/* 146 */     Map<String, Object> result = CollectionUtils.newHashMap(hints.size() + 1);
/* 147 */     result.putAll(hints);
/* 148 */     result.put(hintName, hintValue);
/* 149 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void touchDataBuffer(DataBuffer buffer, @Nullable Map<String, Object> hints, Log logger) {
/* 162 */     if (logger.isDebugEnabled() && hints != null) {
/* 163 */       Object logPrefix = hints.get(LOG_PREFIX_HINT);
/* 164 */       if (logPrefix != null)
/* 165 */         DataBufferUtils.touch(buffer, logPrefix); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\Hints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */