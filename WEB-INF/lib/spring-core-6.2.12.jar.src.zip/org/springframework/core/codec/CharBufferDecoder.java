/*    */ package org.springframework.core.codec;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.List;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CharBufferDecoder
/*    */   extends AbstractCharSequenceDecoder<CharBuffer>
/*    */ {
/*    */   public CharBufferDecoder(List<String> delimiters, boolean stripDelimiter, MimeType... mimeTypes) {
/* 46 */     super(delimiters, stripDelimiter, mimeTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 52 */     return (elementType.resolve() == CharBuffer.class && super.canDecode(elementType, mimeType));
/*    */   }
/*    */ 
/*    */   
/*    */   protected CharBuffer decodeInternal(DataBuffer dataBuffer, Charset charset) {
/* 57 */     ByteBuffer byteBuffer = ByteBuffer.allocate(dataBuffer.readableByteCount());
/* 58 */     dataBuffer.toByteBuffer(byteBuffer);
/* 59 */     return charset.decode(byteBuffer);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CharBufferDecoder textPlainOnly() {
/* 67 */     return textPlainOnly(DEFAULT_DELIMITERS, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CharBufferDecoder textPlainOnly(List<String> delimiters, boolean stripDelimiter) {
/* 76 */     MimeType textPlain = new MimeType("text", "plain", DEFAULT_CHARSET);
/* 77 */     return new CharBufferDecoder(delimiters, stripDelimiter, new MimeType[] { textPlain });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CharBufferDecoder allMimeTypes() {
/* 84 */     return allMimeTypes(DEFAULT_DELIMITERS, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CharBufferDecoder allMimeTypes(List<String> delimiters, boolean stripDelimiter) {
/* 93 */     MimeType textPlain = new MimeType("text", "plain", DEFAULT_CHARSET);
/* 94 */     return new CharBufferDecoder(delimiters, stripDelimiter, new MimeType[] { textPlain, MimeTypeUtils.ALL });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\CharBufferDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */