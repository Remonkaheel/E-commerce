/*     */ package org.springframework.core.codec;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.LimitedDataBufferList;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCharSequenceDecoder<T extends CharSequence>
/*     */   extends AbstractDataBufferDecoder<T>
/*     */ {
/*  53 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */   
/*  56 */   public static final List<String> DEFAULT_DELIMITERS = List.of("\r\n", "\n");
/*     */ 
/*     */   
/*     */   private final List<String> delimiters;
/*     */   
/*     */   private final boolean stripDelimiter;
/*     */   
/*  63 */   private Charset defaultCharset = DEFAULT_CHARSET;
/*     */   
/*  65 */   private final ConcurrentMap<Charset, byte[][]> delimitersCache = (ConcurrentMap)new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractCharSequenceDecoder(List<String> delimiters, boolean stripDelimiter, MimeType... mimeTypes) {
/*  72 */     super(mimeTypes);
/*  73 */     Assert.notEmpty(delimiters, "'delimiters' must not be empty");
/*  74 */     this.delimiters = new ArrayList<>(delimiters);
/*  75 */     this.stripDelimiter = stripDelimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(Charset defaultCharset) {
/*  85 */     this.defaultCharset = defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getDefaultCharset() {
/*  92 */     return this.defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<T> decode(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 100 */     byte[][] delimiterBytes = getDelimiterBytes(mimeType);
/*     */     
/* 102 */     LimitedDataBufferList chunks = new LimitedDataBufferList(getMaxInMemorySize());
/* 103 */     DataBufferUtils.Matcher matcher = DataBufferUtils.matcher(delimiterBytes);
/*     */     
/* 105 */     return Flux.from(input)
/* 106 */       .concatMapIterable(buffer -> processDataBuffer(buffer, matcher, chunks))
/* 107 */       .concatWith((Publisher)Mono.defer(() -> {
/*     */             if (chunks.isEmpty()) {
/*     */               return Mono.empty();
/*     */             }
/*     */             
/*     */             DataBuffer lastBuffer = ((DataBuffer)chunks.get(0)).factory().join((List)chunks);
/*     */             chunks.clear();
/*     */             return Mono.just(lastBuffer);
/* 115 */           })).doFinally(signalType -> chunks.releaseAndClear())
/* 116 */       .doOnDiscard(DataBuffer.class, DataBufferUtils::release)
/* 117 */       .map(buffer -> decode(buffer, elementType, mimeType, hints));
/*     */   }
/*     */   
/*     */   private byte[][] getDelimiterBytes(@Nullable MimeType mimeType) {
/* 121 */     return this.delimitersCache.computeIfAbsent(getCharset(mimeType), charset -> {
/*     */           byte[][] result = new byte[this.delimiters.size()][];
/*     */           for (int i = 0; i < this.delimiters.size(); i++) {
/*     */             result[i] = ((String)this.delimiters.get(i)).getBytes(charset);
/*     */           }
/*     */           return result;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<DataBuffer> processDataBuffer(DataBuffer buffer, DataBufferUtils.Matcher matcher, LimitedDataBufferList chunks) {
/* 133 */     boolean release = true;
/*     */     try {
/* 135 */       List<DataBuffer> result = null;
/*     */       do {
/* 137 */         int endIndex = matcher.match(buffer);
/* 138 */         if (endIndex == -1) {
/* 139 */           chunks.add(buffer);
/* 140 */           release = false;
/*     */           break;
/*     */         } 
/* 143 */         DataBuffer split = buffer.split(endIndex + 1);
/* 144 */         if (result == null) {
/* 145 */           result = new ArrayList<>();
/*     */         }
/* 147 */         int delimiterLength = (matcher.delimiter()).length;
/* 148 */         if (chunks.isEmpty()) {
/* 149 */           if (this.stripDelimiter) {
/* 150 */             split.writePosition(split.writePosition() - delimiterLength);
/*     */           }
/* 152 */           result.add(split);
/*     */         } else {
/*     */           
/* 155 */           chunks.add(split);
/* 156 */           DataBuffer joined = buffer.factory().join((List)chunks);
/* 157 */           if (this.stripDelimiter) {
/* 158 */             joined.writePosition(joined.writePosition() - delimiterLength);
/*     */           }
/* 160 */           result.add(joined);
/* 161 */           chunks.clear();
/*     */         }
/*     */       
/* 164 */       } while (buffer.readableByteCount() > 0);
/* 165 */       return (Collection<DataBuffer>)((result != null) ? result : Collections.emptyList());
/*     */     } finally {
/*     */       
/* 168 */       if (release) {
/* 169 */         DataBufferUtils.release(buffer);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T decode(DataBuffer dataBuffer, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*     */     try {
/* 179 */       Charset charset = getCharset(mimeType);
/* 180 */       T value = decodeInternal(dataBuffer, charset);
/* 181 */       LogFormatUtils.traceDebug(this.logger, traceOn -> {
/*     */             String formatted = LogFormatUtils.formatValue(value, !traceOn.booleanValue());
/*     */             return Hints.getLogPrefix(hints) + "Decoded " + Hints.getLogPrefix(hints);
/*     */           });
/* 185 */       return value;
/*     */     } finally {
/*     */       
/* 188 */       DataBufferUtils.release(dataBuffer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Charset getCharset(@Nullable MimeType mimeType) {
/* 193 */     if (mimeType != null) {
/* 194 */       Charset charset = mimeType.getCharset();
/* 195 */       if (charset != null) {
/* 196 */         return charset;
/*     */       }
/*     */     } 
/* 199 */     return getDefaultCharset();
/*     */   }
/*     */   
/*     */   protected abstract T decodeInternal(DataBuffer paramDataBuffer, Charset paramCharset);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\AbstractCharSequenceDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */