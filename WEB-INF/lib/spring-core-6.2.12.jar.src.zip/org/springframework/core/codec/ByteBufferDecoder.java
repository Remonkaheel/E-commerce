/*    */ package org.springframework.core.codec;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteBufferDecoder
/*    */   extends AbstractDataBufferDecoder<ByteBuffer>
/*    */ {
/*    */   public ByteBufferDecoder() {
/* 40 */     super(new MimeType[] { MimeTypeUtils.ALL });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 46 */     return (ByteBuffer.class.isAssignableFrom(elementType.toClass()) && super
/* 47 */       .canDecode(elementType, mimeType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteBuffer decode(DataBuffer dataBuffer, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 54 */     int len = dataBuffer.readableByteCount();
/* 55 */     ByteBuffer result = ByteBuffer.allocate(len);
/* 56 */     dataBuffer.toByteBuffer(result);
/* 57 */     if (this.logger.isDebugEnabled()) {
/* 58 */       this.logger.debug(Hints.getLogPrefix(hints) + "Read " + Hints.getLogPrefix(hints) + " bytes");
/*    */     }
/* 60 */     DataBufferUtils.release(dataBuffer);
/* 61 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\ByteBufferDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */