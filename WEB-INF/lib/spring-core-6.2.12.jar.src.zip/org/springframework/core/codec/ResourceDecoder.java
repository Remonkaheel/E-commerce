/*     */ package org.springframework.core.codec;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.ByteArrayResource;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDecoder
/*     */   extends AbstractDataBufferDecoder<Resource>
/*     */ {
/*  45 */   public static final String FILENAME_HINT = ResourceDecoder.class.getName() + ".filename";
/*     */ 
/*     */   
/*     */   public ResourceDecoder() {
/*  49 */     super(new MimeType[] { MimeTypeUtils.ALL });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  55 */     return (Resource.class.isAssignableFrom(elementType.toClass()) && super
/*  56 */       .canDecode(elementType, mimeType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Resource> decode(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  63 */     return Flux.from((Publisher)decodeToMono(inputStream, elementType, mimeType, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource decode(DataBuffer dataBuffer, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  70 */     final byte[] bytes = new byte[dataBuffer.readableByteCount()];
/*  71 */     dataBuffer.read(bytes);
/*  72 */     DataBufferUtils.release(dataBuffer);
/*     */     
/*  74 */     if (this.logger.isDebugEnabled()) {
/*  75 */       this.logger.debug(Hints.getLogPrefix(hints) + "Read " + Hints.getLogPrefix(hints) + " bytes");
/*     */     }
/*     */     
/*  78 */     Class<?> clazz = elementType.toClass();
/*  79 */     final String filename = (hints != null) ? (String)hints.get(FILENAME_HINT) : null;
/*  80 */     if (clazz == InputStreamResource.class) {
/*  81 */       return (Resource)new InputStreamResource(new ByteArrayInputStream(bytes))
/*     */         {
/*     */           @Nullable
/*     */           public String getFilename() {
/*  85 */             return filename;
/*     */           }
/*     */           
/*     */           public long contentLength() {
/*  89 */             return bytes.length;
/*     */           }
/*     */         };
/*     */     }
/*  93 */     if (Resource.class.isAssignableFrom(clazz)) {
/*  94 */       return (Resource)new ByteArrayResource(bytes)
/*     */         {
/*     */           @Nullable
/*     */           public String getFilename() {
/*  98 */             return filename;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 103 */     throw new IllegalStateException("Unsupported resource class: " + String.valueOf(clazz));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\ResourceDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */