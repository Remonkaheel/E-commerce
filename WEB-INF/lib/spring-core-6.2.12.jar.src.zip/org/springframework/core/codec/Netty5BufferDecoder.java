/*    */ package org.springframework.core.codec;
/*    */ 
/*    */ import io.netty5.buffer.Buffer;
/*    */ import io.netty5.buffer.DefaultBufferAllocators;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferUtils;
/*    */ import org.springframework.core.io.buffer.Netty5DataBuffer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Netty5BufferDecoder
/*    */   extends AbstractDataBufferDecoder<Buffer>
/*    */ {
/*    */   public Netty5BufferDecoder() {
/* 41 */     super(new MimeType[] { MimeTypeUtils.ALL });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 47 */     return (Buffer.class.isAssignableFrom(elementType.toClass()) && super
/* 48 */       .canDecode(elementType, mimeType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Buffer decode(DataBuffer dataBuffer, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 55 */     if (this.logger.isDebugEnabled()) {
/* 56 */       this.logger.debug(Hints.getLogPrefix(hints) + "Read " + Hints.getLogPrefix(hints) + " bytes");
/*    */     }
/* 58 */     if (dataBuffer instanceof Netty5DataBuffer) { Netty5DataBuffer netty5DataBuffer = (Netty5DataBuffer)dataBuffer;
/* 59 */       return netty5DataBuffer.getNativeBuffer(); }
/*    */     
/* 61 */     byte[] bytes = new byte[dataBuffer.readableByteCount()];
/* 62 */     dataBuffer.read(bytes);
/* 63 */     Buffer buffer = DefaultBufferAllocators.preferredAllocator().copyOf(bytes);
/* 64 */     DataBufferUtils.release(dataBuffer);
/* 65 */     return buffer;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\Netty5BufferDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */