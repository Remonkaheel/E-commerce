/*    */ package org.springframework.core.codec;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.List;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringDecoder
/*    */   extends AbstractCharSequenceDecoder<String>
/*    */ {
/*    */   private StringDecoder(List<String> delimiters, boolean stripDelimiter, MimeType... mimeTypes) {
/* 46 */     super(delimiters, stripDelimiter, mimeTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 52 */     return (elementType.resolve() == String.class && super.canDecode(elementType, mimeType));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String decodeInternal(DataBuffer dataBuffer, Charset charset) {
/* 58 */     return dataBuffer.toString(charset);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StringDecoder textPlainOnly() {
/* 66 */     return textPlainOnly(DEFAULT_DELIMITERS, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StringDecoder textPlainOnly(List<String> delimiters, boolean stripDelimiter) {
/* 76 */     return new StringDecoder(delimiters, stripDelimiter, new MimeType[] { new MimeType("text", "plain", DEFAULT_CHARSET) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StringDecoder allMimeTypes() {
/* 83 */     return allMimeTypes(DEFAULT_DELIMITERS, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StringDecoder allMimeTypes(List<String> delimiters, boolean stripDelimiter) {
/* 93 */     return new StringDecoder(delimiters, stripDelimiter, new MimeType[] { new MimeType("text", "plain", DEFAULT_CHARSET), MimeTypeUtils.ALL });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\StringDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */