/*     */ package org.springframework.core.codec;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Decoder<T>
/*     */ {
/*     */   boolean canDecode(ResolvableType paramResolvableType, @Nullable MimeType paramMimeType);
/*     */   
/*     */   Flux<T> decode(Publisher<DataBuffer> paramPublisher, ResolvableType paramResolvableType, @Nullable MimeType paramMimeType, @Nullable Map<String, Object> paramMap);
/*     */   
/*     */   Mono<T> decodeToMono(Publisher<DataBuffer> paramPublisher, ResolvableType paramResolvableType, @Nullable MimeType paramMimeType, @Nullable Map<String, Object> paramMap);
/*     */   
/*     */   @Nullable
/*     */   default T decode(DataBuffer buffer, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) throws DecodingException {
/*  97 */     CompletableFuture<T> future = decodeToMono((Publisher<DataBuffer>)Mono.just(buffer), targetType, mimeType, hints).toFuture();
/*  98 */     Assert.state(future.isDone(), "DataBuffer decoding should have completed");
/*     */     
/*     */     try {
/* 101 */       return future.get();
/*     */     }
/* 103 */     catch (ExecutionException ex) {
/* 104 */       Throwable cause = ex.getCause();
/* 105 */       CodecException codecException = (CodecException)cause; throw (cause instanceof CodecException) ? codecException : 
/* 106 */         new DecodingException("Failed to decode: " + String.valueOf((cause != null) ? cause.getMessage() : ex), cause);
/*     */     }
/* 108 */     catch (InterruptedException ex) {
/* 109 */       throw new DecodingException("Interrupted during decode", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<MimeType> getDecodableMimeTypes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<MimeType> getDecodableMimeTypes(ResolvableType targetType) {
/* 134 */     return canDecode(targetType, null) ? getDecodableMimeTypes() : Collections.<MimeType>emptyList();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\Decoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */