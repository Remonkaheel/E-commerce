/*    */ package org.springframework.core.codec;
/*    */ 
/*    */ import io.netty5.buffer.Buffer;
/*    */ import java.util.Map;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.core.io.buffer.Netty5DataBufferFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Netty5BufferEncoder
/*    */   extends AbstractEncoder<Buffer>
/*    */ {
/*    */   public Netty5BufferEncoder() {
/* 42 */     super(new MimeType[] { MimeTypeUtils.ALL });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canEncode(ResolvableType type, @Nullable MimeType mimeType) {
/* 48 */     Class<?> clazz = type.toClass();
/* 49 */     return (super.canEncode(type, mimeType) && Buffer.class.isAssignableFrom(clazz));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<DataBuffer> encode(Publisher<? extends Buffer> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 57 */     return Flux.from(inputStream).map(byteBuffer -> encodeValue(byteBuffer, bufferFactory, elementType, mimeType, hints));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataBuffer encodeValue(Buffer buffer, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 65 */     if (this.logger.isDebugEnabled() && !Hints.isLoggingSuppressed(hints)) {
/* 66 */       String logPrefix = Hints.getLogPrefix(hints);
/* 67 */       this.logger.debug(logPrefix + "Writing " + logPrefix + " bytes");
/*    */     } 
/* 69 */     if (bufferFactory instanceof Netty5DataBufferFactory) { Netty5DataBufferFactory netty5DataBufferFactory = (Netty5DataBufferFactory)bufferFactory;
/* 70 */       return (DataBuffer)netty5DataBufferFactory.wrap(buffer); }
/*    */     
/* 72 */     byte[] bytes = new byte[buffer.readableBytes()];
/* 73 */     buffer.readBytes(bytes, 0, bytes.length);
/* 74 */     buffer.close();
/* 75 */     return bufferFactory.wrap(bytes);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\codec\Netty5BufferEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */