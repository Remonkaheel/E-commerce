package org.springframework.core.convert.converter;

public interface ConditionalGenericConverter extends GenericConverter, ConditionalConverter {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\convert\converter\ConditionalGenericConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */