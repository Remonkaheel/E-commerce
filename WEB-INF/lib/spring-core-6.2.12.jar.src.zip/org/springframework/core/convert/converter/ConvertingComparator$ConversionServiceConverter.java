/*     */ package org.springframework.core.convert.converter;
/*     */ 
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConversionServiceConverter<S, T>
/*     */   implements Converter<S, T>
/*     */ {
/*     */   private final ConversionService conversionService;
/*     */   private final Class<? extends T> targetType;
/*     */   
/*     */   public ConversionServiceConverter(ConversionService conversionService, Class<? extends T> targetType) {
/* 116 */     Assert.notNull(conversionService, "ConversionService must not be null");
/* 117 */     Assert.notNull(targetType, "'targetType' must not be null");
/* 118 */     this.conversionService = conversionService;
/* 119 */     this.targetType = targetType;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T convert(S source) {
/* 125 */     return (T)this.conversionService.convert(source, this.targetType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\convert\converter\ConvertingComparator$ConversionServiceConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */