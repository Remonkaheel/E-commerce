/*    */ package org.springframework.core.convert.converter;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface Converter<S, T>
/*    */ {
/*    */   @Nullable
/*    */   T convert(S paramS);
/*    */   
/*    */   default <U> Converter<S, U> andThen(Converter<? super T, ? extends U> after) {
/* 60 */     Assert.notNull(after, "'after' Converter must not be null");
/* 61 */     return s -> {
/*    */         T initialResult = convert((S)s);
/*    */         return (initialResult != null) ? after.convert(initialResult) : null;
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\convert\converter\Converter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */