/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ArrayToArrayConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final CollectionToArrayConverter helperConverter;
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   public ArrayToArrayConverter(ConversionService conversionService) {
/* 48 */     this.helperConverter = new CollectionToArrayConverter(conversionService);
/* 49 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 55 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object[].class, Object[].class));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 60 */     return this.helperConverter.matches(sourceType, targetType);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 66 */     ConversionService conversionService = this.conversionService; if (conversionService instanceof GenericConversionService) { GenericConversionService genericConversionService = (GenericConversionService)conversionService;
/* 67 */       TypeDescriptor targetElement = targetType.getElementTypeDescriptor();
/* 68 */       if (targetElement != null && targetType.getType().isInstance(source) && genericConversionService
/* 69 */         .canBypassConvert(sourceType.getElementTypeDescriptor(), targetElement)) {
/* 70 */         return source;
/*    */       } }
/*    */     
/* 73 */     List<Object> sourceList = Arrays.asList(ObjectUtils.toObjectArray(source));
/* 74 */     return this.helperConverter.convert(sourceList, sourceType, targetType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\convert\support\ArrayToArrayConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */