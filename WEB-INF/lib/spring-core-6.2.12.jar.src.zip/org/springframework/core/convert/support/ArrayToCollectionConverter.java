/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ArrayToCollectionConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   public ArrayToCollectionConverter(ConversionService conversionService) {
/* 49 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 55 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object[].class, Collection.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 60 */     return ConversionUtils.canConvertElements(sourceType
/* 61 */         .getElementTypeDescriptor(), targetType.getElementTypeDescriptor(), this.conversionService);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 67 */     if (source == null) {
/* 68 */       return null;
/*    */     }
/*    */     
/* 71 */     int length = Array.getLength(source);
/* 72 */     TypeDescriptor elementDesc = targetType.getElementTypeDescriptor();
/* 73 */     Collection<Object> target = createCollection(targetType.getType(), 
/* 74 */         (elementDesc != null) ? elementDesc.getType() : null, length);
/*    */     
/* 76 */     if (elementDesc == null) {
/* 77 */       for (int i = 0; i < length; i++) {
/* 78 */         Object sourceElement = Array.get(source, i);
/* 79 */         target.add(sourceElement);
/*    */       } 
/*    */     } else {
/*    */       
/* 83 */       for (int i = 0; i < length; i++) {
/* 84 */         Object sourceElement = Array.get(source, i);
/* 85 */         Object targetElement = this.conversionService.convert(sourceElement, sourceType
/* 86 */             .elementTypeDescriptor(sourceElement), elementDesc);
/* 87 */         target.add(targetElement);
/*    */       } 
/*    */     } 
/* 90 */     return target;
/*    */   }
/*    */   
/*    */   private Collection<Object> createCollection(Class<?> targetType, @Nullable Class<?> elementType, int length) {
/* 94 */     if (targetType.isInterface() && targetType.isAssignableFrom(ArrayList.class))
/*    */     {
/*    */       
/* 97 */       return new ArrayList(length);
/*    */     }
/* 99 */     return CollectionFactory.createCollection(targetType, elementType, length);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\core\convert\support\ArrayToCollectionConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */