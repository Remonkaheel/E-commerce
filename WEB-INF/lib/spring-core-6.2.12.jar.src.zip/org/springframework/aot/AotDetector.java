/*    */ package org.springframework.aot;
/*    */ 
/*    */ import org.springframework.core.NativeDetector;
/*    */ import org.springframework.core.SpringProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AotDetector
/*    */ {
/*    */   public static final String AOT_ENABLED = "spring.aot.enabled";
/* 41 */   private static final boolean inNativeImage = NativeDetector.inNativeImage(new NativeDetector.Context[] { NativeDetector.Context.RUN, NativeDetector.Context.BUILD });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean useGeneratedArtifacts() {
/* 51 */     return (inNativeImage || SpringProperties.getFlag("spring.aot.enabled"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\AotDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */