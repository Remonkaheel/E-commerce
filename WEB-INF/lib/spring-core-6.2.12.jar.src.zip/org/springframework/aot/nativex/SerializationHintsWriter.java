/*    */ package org.springframework.aot.nativex;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.aot.hint.ConditionalHint;
/*    */ import org.springframework.aot.hint.JavaSerializationHint;
/*    */ import org.springframework.aot.hint.SerializationHints;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SerializationHintsWriter
/*    */ {
/* 40 */   public static final SerializationHintsWriter INSTANCE = new SerializationHintsWriter();
/*    */ 
/*    */   
/* 43 */   private static final Comparator<JavaSerializationHint> JAVA_SERIALIZATION_HINT_COMPARATOR = Comparator.comparing(JavaSerializationHint::getType);
/*    */   
/*    */   public void write(BasicJsonWriter writer, SerializationHints hints) {
/* 46 */     writer.writeArray(hints.javaSerializationHints()
/* 47 */         .sorted(JAVA_SERIALIZATION_HINT_COMPARATOR)
/* 48 */         .map(this::toAttributes).toList());
/*    */   }
/*    */   
/*    */   private Map<String, Object> toAttributes(JavaSerializationHint serializationHint) {
/* 52 */     LinkedHashMap<String, Object> attributes = new LinkedHashMap<>();
/* 53 */     handleCondition(attributes, (ConditionalHint)serializationHint);
/* 54 */     attributes.put("name", serializationHint.getType());
/* 55 */     return attributes;
/*    */   }
/*    */   
/*    */   private void handleCondition(Map<String, Object> attributes, ConditionalHint hint) {
/* 59 */     if (hint.getReachableType() != null) {
/* 60 */       Map<String, Object> conditionAttributes = new LinkedHashMap<>();
/* 61 */       conditionAttributes.put("typeReachable", hint.getReachableType());
/* 62 */       attributes.put("condition", conditionAttributes);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\SerializationHintsWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */