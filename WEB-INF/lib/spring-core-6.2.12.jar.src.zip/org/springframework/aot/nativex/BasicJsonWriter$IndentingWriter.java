/*     */ package org.springframework.aot.nativex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndentingWriter
/*     */   extends Writer
/*     */ {
/*     */   private final Writer out;
/*     */   private final String singleIndent;
/* 185 */   private int level = 0;
/*     */   
/* 187 */   private String currentIndent = "";
/*     */   
/*     */   private boolean prependIndent = false;
/*     */   
/*     */   IndentingWriter(Writer out, String singleIndent) {
/* 192 */     this.out = out;
/* 193 */     this.singleIndent = singleIndent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndentingWriter print(String string) {
/* 201 */     write(string.toCharArray(), 0, string.length());
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndentingWriter println(String string) {
/* 210 */     write(string.toCharArray(), 0, string.length());
/* 211 */     return println();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndentingWriter println() {
/* 218 */     String separator = System.lineSeparator();
/*     */     try {
/* 220 */       this.out.write(separator.toCharArray(), 0, separator.length());
/*     */     }
/* 222 */     catch (IOException ex) {
/* 223 */       throw new IllegalStateException(ex);
/*     */     } 
/* 225 */     this.prependIndent = true;
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndentingWriter indented(Runnable runnable) {
/* 235 */     indent();
/* 236 */     runnable.run();
/* 237 */     return outdent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IndentingWriter indent() {
/* 244 */     this.level++;
/* 245 */     return refreshIndent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IndentingWriter outdent() {
/* 252 */     this.level--;
/* 253 */     return refreshIndent();
/*     */   }
/*     */   
/*     */   private IndentingWriter refreshIndent() {
/* 257 */     this.currentIndent = this.singleIndent.repeat(Math.max(0, this.level));
/* 258 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(char[] chars, int offset, int length) {
/*     */     try {
/* 264 */       if (this.prependIndent) {
/* 265 */         this.out.write(this.currentIndent.toCharArray(), 0, this.currentIndent.length());
/* 266 */         this.prependIndent = false;
/*     */       } 
/* 268 */       this.out.write(chars, offset, length);
/*     */     }
/* 270 */     catch (IOException ex) {
/* 271 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 277 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 282 */     this.out.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\BasicJsonWriter$IndentingWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */