/*     */ package org.springframework.aot.nativex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BasicJsonWriter
/*     */ {
/*     */   private final IndentingWriter writer;
/*     */   
/*     */   public BasicJsonWriter(Writer writer, String singleIndent) {
/*  44 */     this.writer = new IndentingWriter(writer, singleIndent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicJsonWriter(Writer writer) {
/*  52 */     this(writer, "  ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeObject(Map<String, Object> attributes) {
/*  67 */     writeObject(attributes, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeArray(List<?> items) {
/*  78 */     writeArray(items, true);
/*     */   }
/*     */   
/*     */   private void writeObject(Map<String, Object> attributes, boolean newLine) {
/*  82 */     if (attributes.isEmpty()) {
/*  83 */       this.writer.print("{ }");
/*     */     } else {
/*     */       
/*  86 */       this.writer.println("{").indented(writeAll(attributes.entrySet().iterator(), entry -> writeAttribute((String)entry.getKey(), entry.getValue())))
/*  87 */         .print("}");
/*     */     } 
/*  89 */     if (newLine) {
/*  90 */       this.writer.println();
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeArray(List<?> items, boolean newLine) {
/*  95 */     if (items.isEmpty()) {
/*  96 */       this.writer.print("[ ]");
/*     */     } else {
/*     */       
/*  99 */       this.writer.println("[")
/* 100 */         .indented(writeAll(items.iterator(), this::writeValue)).print("]");
/*     */     } 
/* 102 */     if (newLine) {
/* 103 */       this.writer.println();
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> Runnable writeAll(Iterator<T> it, Consumer<T> writer) {
/* 108 */     return () -> {
/*     */         while (it.hasNext()) {
/*     */           writer.accept(it.next());
/*     */           if (it.hasNext()) {
/*     */             this.writer.println(",");
/*     */             continue;
/*     */           } 
/*     */           this.writer.println();
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAttribute(String name, Object value) {
/* 122 */     this.writer.print(quote(name) + ": ");
/* 123 */     writeValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeValue(Object value) {
/* 128 */     if (value instanceof Map) { Map<?, ?> map = (Map<?, ?>)value;
/* 129 */       writeObject((Map)map, false); }
/*     */     
/* 131 */     else if (value instanceof List) { List<?> list = (List)value;
/* 132 */       writeArray(list, false); }
/*     */     
/* 134 */     else if (value instanceof TypeReference) { TypeReference typeReference = (TypeReference)value;
/* 135 */       this.writer.print(quote(typeReference.getName())); }
/*     */     
/* 137 */     else if (value instanceof CharSequence) { CharSequence string = (CharSequence)value;
/* 138 */       this.writer.print(quote(escape(string))); }
/*     */     
/* 140 */     else if (value instanceof Boolean) { Boolean flag = (Boolean)value;
/* 141 */       this.writer.print(Boolean.toString(flag.booleanValue())); }
/*     */     else
/*     */     
/* 144 */     { throw new IllegalStateException("unsupported type: " + String.valueOf(value.getClass())); }
/*     */   
/*     */   }
/*     */   
/*     */   private String quote(String name) {
/* 149 */     return "\"" + name + "\"";
/*     */   }
/*     */ 
/*     */   
/*     */   private static String escape(CharSequence input) {
/* 154 */     StringBuilder builder = new StringBuilder();
/* 155 */     input.chars().forEach(c -> { switch (c) {
/*     */             case 34:
/*     */             
/*     */             case 92:
/*     */             
/*     */             case 47:
/*     */             
/*     */             case 8:
/*     */             
/*     */             case 12:
/*     */             
/*     */             case 10:
/*     */             
/*     */             case 13:
/*     */             
/*     */             case 9:
/*     */             
/*     */             default:
/*     */               if (c <= 31); break;
/*     */           }  builder.append(Character.valueOf((char)c));
/* 175 */         }); return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static class IndentingWriter
/*     */     extends Writer
/*     */   {
/*     */     private final Writer out;
/*     */     
/*     */     private final String singleIndent;
/* 185 */     private int level = 0;
/*     */     
/* 187 */     private String currentIndent = "";
/*     */     
/*     */     private boolean prependIndent = false;
/*     */     
/*     */     IndentingWriter(Writer out, String singleIndent) {
/* 192 */       this.out = out;
/* 193 */       this.singleIndent = singleIndent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IndentingWriter print(String string) {
/* 201 */       write(string.toCharArray(), 0, string.length());
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IndentingWriter println(String string) {
/* 210 */       write(string.toCharArray(), 0, string.length());
/* 211 */       return println();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IndentingWriter println() {
/* 218 */       String separator = System.lineSeparator();
/*     */       try {
/* 220 */         this.out.write(separator.toCharArray(), 0, separator.length());
/*     */       }
/* 222 */       catch (IOException ex) {
/* 223 */         throw new IllegalStateException(ex);
/*     */       } 
/* 225 */       this.prependIndent = true;
/* 226 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IndentingWriter indented(Runnable runnable) {
/* 235 */       indent();
/* 236 */       runnable.run();
/* 237 */       return outdent();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private IndentingWriter indent() {
/* 244 */       this.level++;
/* 245 */       return refreshIndent();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private IndentingWriter outdent() {
/* 252 */       this.level--;
/* 253 */       return refreshIndent();
/*     */     }
/*     */     
/*     */     private IndentingWriter refreshIndent() {
/* 257 */       this.currentIndent = this.singleIndent.repeat(Math.max(0, this.level));
/* 258 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(char[] chars, int offset, int length) {
/*     */       try {
/* 264 */         if (this.prependIndent) {
/* 265 */           this.out.write(this.currentIndent.toCharArray(), 0, this.currentIndent.length());
/* 266 */           this.prependIndent = false;
/*     */         } 
/* 268 */         this.out.write(chars, offset, length);
/*     */       }
/* 270 */       catch (IOException ex) {
/* 271 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() throws IOException {
/* 277 */       this.out.flush();
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 282 */       this.out.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\BasicJsonWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */