/*    */ package org.springframework.aot.nativex.substitution;
/*    */ 
/*    */ import com.oracle.svm.core.annotate.Alias;
/*    */ import com.oracle.svm.core.annotate.TargetClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @TargetClass(className = "com.sun.beans.finder.ClassFinder")
/*    */ final class Target_ClassFinder
/*    */ {
/*    */   @Alias
/*    */   public static Class<?> findClass(String name, ClassLoader loader) throws ClassNotFoundException {
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\substitution\Target_ClassFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */