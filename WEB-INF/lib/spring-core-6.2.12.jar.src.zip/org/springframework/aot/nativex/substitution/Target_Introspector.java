/*    */ package org.springframework.aot.nativex.substitution;
/*    */ 
/*    */ import com.oracle.svm.core.annotate.Substitute;
/*    */ import com.oracle.svm.core.annotate.TargetClass;
/*    */ import java.beans.Customizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @TargetClass(className = "java.beans.Introspector")
/*    */ final class Target_Introspector
/*    */ {
/*    */   @Substitute
/*    */   private static Class<?> findCustomizerClass(Class<?> type) {
/* 38 */     String name = type.getName() + "Customizer";
/*    */     try {
/* 40 */       type = Target_ClassFinder.findClass(name, type.getClassLoader());
/* 41 */       if (Customizer.class.isAssignableFrom(type)) {
/* 42 */         Class<?> c = type;
/*    */         do {
/* 44 */           c = c.getSuperclass();
/* 45 */           if (c.getName().equals("java.awt.Component")) {
/* 46 */             return type;
/*    */           }
/* 48 */         } while (!c.getName().equals("java.lang.Object"));
/*    */       }
/*    */     
/* 51 */     } catch (Exception exception) {}
/*    */     
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\substitution\Target_Introspector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */