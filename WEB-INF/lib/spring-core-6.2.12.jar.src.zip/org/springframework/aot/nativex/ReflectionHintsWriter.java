/*     */ package org.springframework.aot.nativex;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.aot.hint.ExecutableHint;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.FieldHint;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.MemberHint;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReflectionHintsWriter
/*     */ {
/*  50 */   public static final ReflectionHintsWriter INSTANCE = new ReflectionHintsWriter();
/*     */   
/*     */   public void write(BasicJsonWriter writer, ReflectionHints hints) {
/*  53 */     writer.writeArray(hints.typeHints()
/*  54 */         .sorted(Comparator.comparing(TypeHint::getType))
/*  55 */         .map(this::toAttributes).toList());
/*     */   }
/*     */   
/*     */   private Map<String, Object> toAttributes(TypeHint hint) {
/*  59 */     Map<String, Object> attributes = new LinkedHashMap<>();
/*  60 */     attributes.put("name", hint.getType());
/*  61 */     handleCondition(attributes, hint);
/*  62 */     handleCategories(attributes, hint.getMemberCategories());
/*  63 */     handleFields(attributes, hint.fields());
/*  64 */     handleExecutables(attributes, Stream.<ExecutableHint>concat(hint
/*  65 */           .constructors(), hint.methods()).sorted().toList());
/*  66 */     return attributes;
/*     */   }
/*     */   
/*     */   private void handleCondition(Map<String, Object> attributes, TypeHint hint) {
/*  70 */     if (hint.getReachableType() != null) {
/*  71 */       Map<String, Object> conditionAttributes = new LinkedHashMap<>();
/*  72 */       conditionAttributes.put("typeReachable", hint.getReachableType());
/*  73 */       attributes.put("condition", conditionAttributes);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleFields(Map<String, Object> attributes, Stream<FieldHint> fields) {
/*  78 */     addIfNotEmpty(attributes, "fields", fields
/*  79 */         .sorted(Comparator.comparing(MemberHint::getName, String::compareToIgnoreCase))
/*  80 */         .map(this::toAttributes).toList());
/*     */   }
/*     */   
/*     */   private Map<String, Object> toAttributes(FieldHint hint) {
/*  84 */     Map<String, Object> attributes = new LinkedHashMap<>();
/*  85 */     attributes.put("name", hint.getName());
/*  86 */     return attributes;
/*     */   }
/*     */   
/*     */   private void handleExecutables(Map<String, Object> attributes, List<ExecutableHint> hints) {
/*  90 */     addIfNotEmpty(attributes, "methods", hints.stream()
/*  91 */         .filter(h -> h.getMode().equals(ExecutableMode.INVOKE))
/*  92 */         .map(this::toAttributes).toList());
/*  93 */     addIfNotEmpty(attributes, "queriedMethods", hints.stream()
/*  94 */         .filter(h -> h.getMode().equals(ExecutableMode.INTROSPECT))
/*  95 */         .map(this::toAttributes).toList());
/*     */   }
/*     */   
/*     */   private Map<String, Object> toAttributes(ExecutableHint hint) {
/*  99 */     Map<String, Object> attributes = new LinkedHashMap<>();
/* 100 */     attributes.put("name", hint.getName());
/* 101 */     attributes.put("parameterTypes", hint.getParameterTypes());
/* 102 */     return attributes;
/*     */   }
/*     */   
/*     */   private void handleCategories(Map<String, Object> attributes, Set<MemberCategory> categories) {
/* 106 */     categories.stream().sorted().forEach(category -> { switch (category) {
/*     */             case PUBLIC_FIELDS:
/*     */               attributes.put("allPublicFields", Boolean.valueOf(true)); break;
/*     */             case DECLARED_FIELDS:
/*     */               attributes.put("allDeclaredFields", Boolean.valueOf(true)); break;
/*     */             case INTROSPECT_PUBLIC_CONSTRUCTORS:
/*     */               attributes.put("queryAllPublicConstructors", Boolean.valueOf(true)); break;
/*     */             case INTROSPECT_DECLARED_CONSTRUCTORS:
/*     */               attributes.put("queryAllDeclaredConstructors", Boolean.valueOf(true)); break;
/*     */             case INVOKE_PUBLIC_CONSTRUCTORS:
/*     */               attributes.put("allPublicConstructors", Boolean.valueOf(true)); break;
/*     */             case INVOKE_DECLARED_CONSTRUCTORS:
/*     */               attributes.put("allDeclaredConstructors", Boolean.valueOf(true)); break;
/*     */             case INTROSPECT_PUBLIC_METHODS:
/*     */               attributes.put("queryAllPublicMethods", Boolean.valueOf(true)); break;
/*     */             case INTROSPECT_DECLARED_METHODS:
/*     */               attributes.put("queryAllDeclaredMethods", Boolean.valueOf(true)); break;
/*     */             case INVOKE_PUBLIC_METHODS:
/*     */               attributes.put("allPublicMethods", Boolean.valueOf(true)); break;
/*     */             case INVOKE_DECLARED_METHODS:
/*     */               attributes.put("allDeclaredMethods", Boolean.valueOf(true)); break;
/*     */             case PUBLIC_CLASSES:
/*     */               attributes.put("allPublicClasses", Boolean.valueOf(true)); break;
/*     */             case DECLARED_CLASSES:
/*     */               attributes.put("allDeclaredClasses", Boolean.valueOf(true)); break;
/*     */             case UNSAFE_ALLOCATED:
/*     */               attributes.put("unsafeAllocated", Boolean.valueOf(true)); break;
/*     */           } 
/* 134 */         }); } private void addIfNotEmpty(Map<String, Object> attributes, String name, @Nullable Object value) { if (value != null && value instanceof Collection) { Collection<?> collection = (Collection)value; if (!collection.isEmpty())
/* 135 */         attributes.put(name, value);  }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\ReflectionHintsWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */