/*     */ package org.springframework.aot.nativex;
/*     */ 
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ 


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\ReflectionHintsWriter$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */