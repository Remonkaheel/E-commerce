/*    */ package org.springframework.aot.nativex;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.aot.hint.ProxyHints;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ import org.springframework.aot.hint.ResourceHints;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.SerializationHints;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NativeConfigurationWriter
/*    */ {
/*    */   public void write(RuntimeHints hints) {
/* 43 */     if (hints.serialization().javaSerializationHints().findAny().isPresent()) {
/* 44 */       writeSerializationHints(hints.serialization());
/*    */     }
/* 46 */     if (hints.proxies().jdkProxyHints().findAny().isPresent()) {
/* 47 */       writeProxyHints(hints.proxies());
/*    */     }
/* 49 */     if (hints.reflection().typeHints().findAny().isPresent()) {
/* 50 */       writeReflectionHints(hints.reflection());
/*    */     }
/* 52 */     if (hints.resources().resourcePatternHints().findAny().isPresent() || hints
/* 53 */       .resources().resourceBundleHints().findAny().isPresent()) {
/* 54 */       writeResourceHints(hints.resources());
/*    */     }
/* 56 */     if (hints.jni().typeHints().findAny().isPresent()) {
/* 57 */       writeJniHints(hints.jni());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeSerializationHints(SerializationHints hints) {
/* 70 */     writeTo("serialization-config.json", writer -> SerializationHintsWriter.INSTANCE.write(writer, hints));
/*    */   }
/*    */ 
/*    */   
/*    */   private void writeProxyHints(ProxyHints hints) {
/* 75 */     writeTo("proxy-config.json", writer -> ProxyHintsWriter.INSTANCE.write(writer, hints));
/*    */   }
/*    */ 
/*    */   
/*    */   private void writeReflectionHints(ReflectionHints hints) {
/* 80 */     writeTo("reflect-config.json", writer -> ReflectionHintsWriter.INSTANCE.write(writer, hints));
/*    */   }
/*    */ 
/*    */   
/*    */   private void writeResourceHints(ResourceHints hints) {
/* 85 */     writeTo("resource-config.json", writer -> ResourceHintsWriter.INSTANCE.write(writer, hints));
/*    */   }
/*    */ 
/*    */   
/*    */   private void writeJniHints(ReflectionHints hints) {
/* 90 */     writeTo("jni-config.json", writer -> ReflectionHintsWriter.INSTANCE.write(writer, hints));
/*    */   }
/*    */   
/*    */   protected abstract void writeTo(String paramString, Consumer<BasicJsonWriter> paramConsumer);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\NativeConfigurationWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */