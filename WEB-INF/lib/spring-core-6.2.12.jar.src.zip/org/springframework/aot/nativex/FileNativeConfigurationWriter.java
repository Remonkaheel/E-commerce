/*    */ package org.springframework.aot.nativex;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.nio.file.Path;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileNativeConfigurationWriter
/*    */   extends NativeConfigurationWriter
/*    */ {
/*    */   private final Path basePath;
/*    */   @Nullable
/*    */   private final String groupId;
/*    */   @Nullable
/*    */   private final String artifactId;
/*    */   
/*    */   public FileNativeConfigurationWriter(Path basePath) {
/* 48 */     this(basePath, null, null);
/*    */   }
/*    */   
/*    */   public FileNativeConfigurationWriter(Path basePath, @Nullable String groupId, @Nullable String artifactId) {
/* 52 */     this.basePath = basePath;
/* 53 */     if ((groupId == null && artifactId != null) || (groupId != null && artifactId == null)) {
/* 54 */       throw new IllegalArgumentException("groupId and artifactId must be both null or both non-null");
/*    */     }
/* 56 */     this.groupId = groupId;
/* 57 */     this.artifactId = artifactId;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void writeTo(String fileName, Consumer<BasicJsonWriter> writer) {
/*    */     try {
/* 63 */       File file = createIfNecessary(fileName);
/* 64 */       FileWriter out = new FileWriter(file); 
/* 65 */       try { writer.accept(createJsonWriter(out));
/* 66 */         out.close(); } catch (Throwable throwable) { try { out.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*    */     
/* 68 */     } catch (IOException ex) {
/* 69 */       throw new IllegalStateException("Failed to write native configuration for " + fileName, ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   private File createIfNecessary(String filename) throws IOException {
/* 74 */     Path outputDirectory = this.basePath.resolve("META-INF").resolve("native-image");
/* 75 */     if (this.groupId != null && this.artifactId != null) {
/* 76 */       outputDirectory = outputDirectory.resolve(this.groupId).resolve(this.artifactId);
/*    */     }
/* 78 */     outputDirectory.toFile().mkdirs();
/* 79 */     File file = outputDirectory.resolve(filename).toFile();
/* 80 */     file.createNewFile();
/* 81 */     return file;
/*    */   }
/*    */   
/*    */   private BasicJsonWriter createJsonWriter(Writer out) {
/* 85 */     return new BasicJsonWriter(out);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\FileNativeConfigurationWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */