/*     */ package org.springframework.aot.nativex;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.aot.hint.ConditionalHint;
/*     */ import org.springframework.aot.hint.ResourceBundleHint;
/*     */ import org.springframework.aot.hint.ResourceHints;
/*     */ import org.springframework.aot.hint.ResourcePatternHint;
/*     */ import org.springframework.aot.hint.ResourcePatternHints;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceHintsWriter
/*     */ {
/*  46 */   public static final ResourceHintsWriter INSTANCE = new ResourceHintsWriter();
/*     */ 
/*     */   
/*  49 */   private static final Comparator<ResourcePatternHint> RESOURCE_PATTERN_HINT_COMPARATOR = Comparator.comparing(ResourcePatternHint::getPattern);
/*     */ 
/*     */   
/*  52 */   private static final Comparator<ResourceBundleHint> RESOURCE_BUNDLE_HINT_COMPARATOR = Comparator.comparing(ResourceBundleHint::getBaseName);
/*     */ 
/*     */   
/*     */   public void write(BasicJsonWriter writer, ResourceHints hints) {
/*  56 */     Map<String, Object> attributes = new LinkedHashMap<>();
/*  57 */     addIfNotEmpty(attributes, "resources", toAttributes(hints));
/*  58 */     handleResourceBundles(attributes, hints.resourceBundleHints());
/*  59 */     writer.writeObject(attributes);
/*     */   }
/*     */   
/*     */   private Map<String, Object> toAttributes(ResourceHints hint) {
/*  63 */     Map<String, Object> attributes = new LinkedHashMap<>();
/*  64 */     addIfNotEmpty(attributes, "includes", hint.resourcePatternHints()
/*  65 */         .map(ResourcePatternHints::getIncludes).flatMap(Collection::stream).distinct()
/*  66 */         .sorted(RESOURCE_PATTERN_HINT_COMPARATOR)
/*  67 */         .map(this::toAttributes).toList());
/*  68 */     addIfNotEmpty(attributes, "excludes", hint.resourcePatternHints()
/*  69 */         .map(ResourcePatternHints::getExcludes).flatMap(Collection::stream).distinct()
/*  70 */         .sorted(RESOURCE_PATTERN_HINT_COMPARATOR)
/*  71 */         .map(this::toAttributes).toList());
/*  72 */     return attributes;
/*     */   }
/*     */   
/*     */   private void handleResourceBundles(Map<String, Object> attributes, Stream<ResourceBundleHint> resourceBundles) {
/*  76 */     addIfNotEmpty(attributes, "bundles", resourceBundles
/*  77 */         .sorted(RESOURCE_BUNDLE_HINT_COMPARATOR)
/*  78 */         .map(this::toAttributes).toList());
/*     */   }
/*     */   
/*     */   private Map<String, Object> toAttributes(ResourceBundleHint hint) {
/*  82 */     Map<String, Object> attributes = new LinkedHashMap<>();
/*  83 */     handleCondition(attributes, (ConditionalHint)hint);
/*  84 */     attributes.put("name", hint.getBaseName());
/*  85 */     return attributes;
/*     */   }
/*     */   
/*     */   private Map<String, Object> toAttributes(ResourcePatternHint hint) {
/*  89 */     Map<String, Object> attributes = new LinkedHashMap<>();
/*  90 */     handleCondition(attributes, (ConditionalHint)hint);
/*  91 */     attributes.put("pattern", hint.toRegex().toString());
/*  92 */     return attributes;
/*     */   }
/*     */   
/*     */   private void addIfNotEmpty(Map<String, Object> attributes, String name, @Nullable Object value) {
/*  96 */     if (value instanceof Collection) { Collection<?> collection = (Collection)value;
/*  97 */       if (!collection.isEmpty()) {
/*  98 */         attributes.put(name, value);
/*     */       } }
/*     */     
/* 101 */     else if (value instanceof Map) { Map<?, ?> map = (Map<?, ?>)value;
/* 102 */       if (!map.isEmpty()) {
/* 103 */         attributes.put(name, value);
/*     */       } }
/*     */     
/* 106 */     else if (value != null)
/* 107 */     { attributes.put(name, value); }
/*     */   
/*     */   }
/*     */   
/*     */   private void handleCondition(Map<String, Object> attributes, ConditionalHint hint) {
/* 112 */     if (hint.getReachableType() != null) {
/* 113 */       Map<String, Object> conditionAttributes = new LinkedHashMap<>();
/* 114 */       conditionAttributes.put("typeReachable", hint.getReachableType());
/* 115 */       attributes.put("condition", conditionAttributes);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\ResourceHintsWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */