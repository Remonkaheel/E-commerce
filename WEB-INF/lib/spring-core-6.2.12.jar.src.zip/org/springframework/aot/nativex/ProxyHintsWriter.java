/*    */ package org.springframework.aot.nativex;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.aot.hint.JdkProxyHint;
/*    */ import org.springframework.aot.hint.ProxyHints;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProxyHintsWriter
/*    */ {
/* 42 */   public static final ProxyHintsWriter INSTANCE = new ProxyHintsWriter();
/*    */   static {
/* 44 */     JDK_PROXY_HINT_COMPARATOR = ((left, right) -> {
/*    */         String leftSignature = left.getProxiedInterfaces().stream().map(TypeReference::getCanonicalName).collect(Collectors.joining(","));
/*    */         String rightSignature = right.getProxiedInterfaces().stream().map(TypeReference::getCanonicalName).collect(Collectors.joining(","));
/*    */         return leftSignature.compareTo(rightSignature);
/*    */       });
/*    */   }
/*    */   
/*    */   private static final Comparator<JdkProxyHint> JDK_PROXY_HINT_COMPARATOR;
/*    */   
/*    */   public void write(BasicJsonWriter writer, ProxyHints hints) {
/* 54 */     writer.writeArray(hints.jdkProxyHints().sorted(JDK_PROXY_HINT_COMPARATOR)
/* 55 */         .map(this::toAttributes).toList());
/*    */   }
/*    */   
/*    */   private Map<String, Object> toAttributes(JdkProxyHint hint) {
/* 59 */     Map<String, Object> attributes = new LinkedHashMap<>();
/* 60 */     handleCondition(attributes, hint);
/* 61 */     attributes.put("interfaces", hint.getProxiedInterfaces());
/* 62 */     return attributes;
/*    */   }
/*    */   
/*    */   private void handleCondition(Map<String, Object> attributes, JdkProxyHint hint) {
/* 66 */     if (hint.getReachableType() != null) {
/* 67 */       Map<String, Object> conditionAttributes = new LinkedHashMap<>();
/* 68 */       conditionAttributes.put("typeReachable", hint.getReachableType());
/* 69 */       attributes.put("condition", conditionAttributes);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\ProxyHintsWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */