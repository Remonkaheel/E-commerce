/*     */ package org.springframework.aot.nativex.feature;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.regex.Pattern;
/*     */ import org.graalvm.nativeimage.hosted.Feature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PreComputeFieldFeature
/*     */   implements Feature
/*     */ {
/*  39 */   private static final boolean verbose = "verbose"
/*  40 */     .equalsIgnoreCase(System.getProperty("spring.native.precompute.log"));
/*     */   
/*  42 */   private static final Pattern[] patterns = new Pattern[] {
/*  43 */       Pattern.compile(Pattern.quote("org.springframework.core.NativeDetector#inNativeImage")), 
/*  44 */       Pattern.compile(Pattern.quote("org.springframework.cglib.core.AbstractClassGenerator#inNativeImage")), 
/*  45 */       Pattern.compile(Pattern.quote("org.springframework.aot.AotDetector#inNativeImage")), 
/*  46 */       Pattern.compile(Pattern.quote("org.springframework.") + ".*#.*Present"), 
/*  47 */       Pattern.compile(Pattern.quote("org.springframework.") + ".*#.*PRESENT"), 
/*  48 */       Pattern.compile(Pattern.quote("reactor.core.") + ".*#.*Available"), 
/*  49 */       Pattern.compile(Pattern.quote("org.apache.commons.logging.LogAdapter") + "#.*Present")
/*     */     };
/*     */   
/*  52 */   private final ThrowawayClassLoader throwawayClassLoader = new ThrowawayClassLoader(getClass().getClassLoader());
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeAnalysis(Feature.BeforeAnalysisAccess access) {
/*  57 */     access.registerSubtypeReachabilityHandler(this::iterateFields, Object.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private void iterateFields(Feature.DuringAnalysisAccess access, Class<?> subtype) {
/*     */     try {
/*  63 */       for (Field field : subtype.getDeclaredFields()) {
/*  64 */         int modifiers = field.getModifiers();
/*  65 */         if (Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers) && !field.isEnumConstant() && (field
/*  66 */           .getType() == boolean.class || field.getType() == Boolean.class)) {
/*     */ 
/*     */           
/*  69 */           String fieldIdentifier = field.getDeclaringClass().getName() + "#" + field.getDeclaringClass().getName();
/*  70 */           for (Pattern pattern : patterns) {
/*  71 */             if (pattern.matcher(fieldIdentifier).matches()) {
/*     */               try {
/*  73 */                 Object fieldValue = provideFieldValue(field);
/*  74 */                 access.registerFieldValueTransformer(field, (receiver, originalValue) -> fieldValue);
/*  75 */                 if (verbose) {
/*  76 */                   System.out.println("Field " + fieldIdentifier + " set to " + String.valueOf(fieldValue) + " at build time");
/*     */                 
/*     */                 }
/*     */               }
/*  80 */               catch (Throwable ex) {
/*  81 */                 if (verbose) {
/*  82 */                   System.out.println("Field " + fieldIdentifier + " will be evaluated at runtime due to this error during build time evaluation: " + String.valueOf(ex));
/*     */                 }
/*     */               }
/*     */             
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*  90 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object provideFieldValue(Field field) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException {
/*  99 */     Class<?> throwawayClass = this.throwawayClassLoader.loadClass(field.getDeclaringClass().getName());
/* 100 */     Field throwawayField = throwawayClass.getDeclaredField(field.getName());
/* 101 */     throwawayField.setAccessible(true);
/* 102 */     return throwawayField.get(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\feature\PreComputeFieldFeature.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */