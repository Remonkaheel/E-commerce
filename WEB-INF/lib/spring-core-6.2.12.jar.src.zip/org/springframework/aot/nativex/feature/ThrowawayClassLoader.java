/*    */ package org.springframework.aot.nativex.feature;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ThrowawayClassLoader
/*    */   extends ClassLoader
/*    */ {
/*    */   private final ClassLoader resourceLoader;
/*    */   
/*    */   static {
/* 34 */     registerAsParallelCapable();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ThrowawayClassLoader(ClassLoader parent) {
/* 41 */     super(parent.getParent());
/* 42 */     this.resourceLoader = parent;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 48 */     synchronized (getClassLoadingLock(name)) {
/* 49 */       Class<?> loaded = findLoadedClass(name);
/* 50 */       if (loaded != null) {
/* 51 */         return loaded;
/*    */       }
/*    */       try {
/* 54 */         return super.loadClass(name, true);
/*    */       }
/* 56 */       catch (ClassNotFoundException ex) {
/* 57 */         return loadClassFromResource(name);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private Class<?> loadClassFromResource(String name) throws ClassNotFoundException, ClassFormatError {
/* 63 */     String resourceName = name.replace('.', '/') + ".class";
/* 64 */     InputStream inputStream = this.resourceLoader.getResourceAsStream(resourceName);
/* 65 */     if (inputStream == null) {
/* 66 */       return null;
/*    */     }
/*    */     try {
/* 69 */       ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
/* 70 */       inputStream.transferTo(outputStream);
/* 71 */       byte[] bytes = outputStream.toByteArray();
/* 72 */       return defineClass(name, bytes, 0, bytes.length);
/*    */     
/*    */     }
/* 75 */     catch (IOException ex) {
/* 76 */       throw new ClassNotFoundException("Cannot load resource for class [" + name + "]", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL findResource(String name) {
/* 82 */     return this.resourceLoader.getResource(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\nativex\feature\ThrowawayClassLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */