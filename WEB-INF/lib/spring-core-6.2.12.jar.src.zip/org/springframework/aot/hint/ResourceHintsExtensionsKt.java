package org.springframework.aot.hint;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\003\032\035\020\000\032\n \002*\004\030\0010\0010\001\"\006\b\000\020\003\030\001*\0020\001H\b¨\006\004"}, d2 = {"registerType", "Lorg/springframework/aot/hint/ResourceHints;", "kotlin.jvm.PlatformType", "T", "spring-core"})
public final class ResourceHintsExtensionsKt {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ResourceHintsExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */