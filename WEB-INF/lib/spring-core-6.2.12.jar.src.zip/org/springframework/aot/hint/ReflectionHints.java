/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionHints
/*     */ {
/*  45 */   private final Map<TypeReference, TypeHint.Builder> types = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<TypeHint> typeHints() {
/*  53 */     return this.types.values().stream().map(TypeHint.Builder::build);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeHint getTypeHint(TypeReference type) {
/*  64 */     TypeHint.Builder typeHintBuilder = this.types.get(type);
/*  65 */     return (typeHintBuilder != null) ? typeHintBuilder.build() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeHint getTypeHint(Class<?> type) {
/*  75 */     return getTypeHint(TypeReference.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerType(TypeReference type, Consumer<TypeHint.Builder> typeHint) {
/*  87 */     TypeHint.Builder builder = this.types.computeIfAbsent(type, Builder::new);
/*  88 */     typeHint.accept(builder);
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerType(TypeReference type, MemberCategory... memberCategories) {
/* 100 */     return registerType(type, TypeHint.builtWith(memberCategories));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerType(Class<?> type, Consumer<TypeHint.Builder> typeHint) {
/* 111 */     Assert.notNull(type, "'type' must not be null");
/* 112 */     if (type.getCanonicalName() != null) {
/* 113 */       registerType(TypeReference.of(type), typeHint);
/*     */     }
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerType(Class<?> type, MemberCategory... memberCategories) {
/* 126 */     Assert.notNull(type, "'type' must not be null");
/* 127 */     if (type.getCanonicalName() != null) {
/* 128 */       registerType(TypeReference.of(type), memberCategories);
/*     */     }
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerTypeIfPresent(@Nullable ClassLoader classLoader, String typeName, Consumer<TypeHint.Builder> typeHint) {
/* 145 */     if (ClassUtils.isPresent(typeName, classLoader)) {
/* 146 */       registerType(TypeReference.of(typeName), typeHint);
/*     */     }
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerTypeIfPresent(@Nullable ClassLoader classLoader, String typeName, MemberCategory... memberCategories) {
/* 162 */     return registerTypeIfPresent(classLoader, typeName, TypeHint.builtWith(memberCategories));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerTypes(Iterable<TypeReference> types, Consumer<TypeHint.Builder> typeHint) {
/* 174 */     types.forEach(type -> registerType(type, typeHint));
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerForInterfaces(Class<?> type, Consumer<TypeHint.Builder> typeHint) {
/* 188 */     Class<?> currentClass = type;
/* 189 */     while (currentClass != null && currentClass != Object.class) {
/* 190 */       for (Class<?> interfaceType : currentClass.getInterfaces()) {
/* 191 */         if (!ClassUtils.isJavaLanguageInterface(interfaceType)) {
/* 192 */           registerType(interfaceType, typeHint);
/* 193 */           registerForInterfaces(interfaceType, typeHint);
/*     */         } 
/*     */       } 
/* 196 */       currentClass = currentClass.getSuperclass();
/*     */     } 
/* 198 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerField(Field field) {
/* 207 */     return registerType(TypeReference.of(field.getDeclaringClass()), typeHint -> typeHint.withField(field.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerConstructor(Constructor<?> constructor, ExecutableMode mode) {
/* 219 */     return registerType(TypeReference.of(constructor.getDeclaringClass()), typeHint -> typeHint.withConstructor(mapParameters(constructor), mode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectionHints registerMethod(Method method, ExecutableMode mode) {
/* 231 */     return registerType(TypeReference.of(method.getDeclaringClass()), typeHint -> typeHint.withMethod(method.getName(), mapParameters(method), mode));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<TypeReference> mapParameters(Executable executable) {
/* 236 */     return TypeReference.listOf(executable.getParameterTypes());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ReflectionHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */