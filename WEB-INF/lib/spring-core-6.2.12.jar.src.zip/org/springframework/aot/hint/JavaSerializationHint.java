/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaSerializationHint
/*     */   implements ConditionalHint
/*     */ {
/*     */   private final TypeReference type;
/*     */   @Nullable
/*     */   private final TypeReference reachableType;
/*     */   
/*     */   JavaSerializationHint(Builder builder) {
/*  40 */     this.type = builder.type;
/*  41 */     this.reachableType = builder.reachableType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeReference getType() {
/*  50 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeReference getReachableType() {
/*  56 */     return this.reachableType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  61 */     if (this != other) { if (other instanceof JavaSerializationHint) { JavaSerializationHint that = (JavaSerializationHint)other; if (this.type
/*  62 */           .equals(that.type) && Objects.equals(this.reachableType, that.reachableType)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  67 */     return Objects.hash(new Object[] { this.type, this.reachableType });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private final TypeReference type;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private TypeReference reachableType;
/*     */ 
/*     */     
/*     */     Builder(TypeReference type) {
/*  82 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder onReachableType(TypeReference reachableType) {
/*  91 */       this.reachableType = reachableType;
/*  92 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JavaSerializationHint build() {
/* 100 */       return new JavaSerializationHint(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\JavaSerializationHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */