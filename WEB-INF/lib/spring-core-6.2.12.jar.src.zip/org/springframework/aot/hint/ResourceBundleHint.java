/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceBundleHint
/*     */   implements ConditionalHint
/*     */ {
/*     */   private final String baseName;
/*     */   @Nullable
/*     */   private final TypeReference reachableType;
/*     */   
/*     */   ResourceBundleHint(Builder builder) {
/*  40 */     this.baseName = builder.baseName;
/*  41 */     this.reachableType = builder.reachableType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseName() {
/*  49 */     return this.baseName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeReference getReachableType() {
/*  55 */     return this.reachableType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  60 */     if (this != other) { if (other instanceof ResourceBundleHint) { ResourceBundleHint that = (ResourceBundleHint)other; if (this.baseName
/*  61 */           .equals(that.baseName) && Objects.equals(this.reachableType, that.reachableType)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  66 */     return Objects.hash(new Object[] { this.baseName, this.reachableType });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private String baseName;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private TypeReference reachableType;
/*     */ 
/*     */     
/*     */     Builder(String baseName) {
/*  81 */       this.baseName = baseName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder onReachableType(TypeReference reachableType) {
/*  90 */       this.reachableType = reachableType;
/*  91 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder baseName(String baseName) {
/*  99 */       this.baseName = baseName;
/* 100 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ResourceBundleHint build() {
/* 108 */       return new ResourceBundleHint(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ResourceBundleHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */