/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeHints
/*    */ {
/* 36 */   private final ReflectionHints reflection = new ReflectionHints();
/*    */   
/* 38 */   private final ResourceHints resources = new ResourceHints();
/*    */   
/* 40 */   private final SerializationHints serialization = new SerializationHints();
/*    */   
/* 42 */   private final ProxyHints proxies = new ProxyHints();
/*    */   
/* 44 */   private final ReflectionHints jni = new ReflectionHints();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReflectionHints reflection() {
/* 52 */     return this.reflection;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceHints resources() {
/* 60 */     return this.resources;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationHints serialization() {
/* 68 */     return this.serialization;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ProxyHints proxies() {
/* 76 */     return this.proxies;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReflectionHints jni() {
/* 84 */     return this.jni;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\RuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */