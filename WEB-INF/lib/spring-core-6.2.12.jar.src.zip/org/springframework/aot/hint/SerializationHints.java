/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializationHints
/*    */ {
/* 40 */   private final Set<JavaSerializationHint> javaSerializationHints = new LinkedHashSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<JavaSerializationHint> javaSerializationHints() {
/* 49 */     return this.javaSerializationHints.stream();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationHints registerType(TypeReference type, @Nullable Consumer<JavaSerializationHint.Builder> serializationHint) {
/* 60 */     JavaSerializationHint.Builder builder = new JavaSerializationHint.Builder(type);
/* 61 */     if (serializationHint != null) {
/* 62 */       serializationHint.accept(builder);
/*    */     }
/* 64 */     this.javaSerializationHints.add(builder.build());
/* 65 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationHints registerType(TypeReference type) {
/* 75 */     return registerType(type, (Consumer<JavaSerializationHint.Builder>)null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationHints registerType(Class<? extends Serializable> type, @Nullable Consumer<JavaSerializationHint.Builder> serializationHint) {
/* 86 */     return registerType(TypeReference.of(type), serializationHint);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationHints registerType(Class<? extends Serializable> type) {
/* 96 */     return registerType(type, (Consumer<JavaSerializationHint.Builder>)null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\SerializationHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */