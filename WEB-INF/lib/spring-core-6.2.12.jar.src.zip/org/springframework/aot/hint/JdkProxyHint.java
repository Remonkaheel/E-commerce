/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JdkProxyHint
/*     */   implements ConditionalHint
/*     */ {
/*     */   private final List<TypeReference> proxiedInterfaces;
/*     */   @Nullable
/*     */   private final TypeReference reachableType;
/*     */   
/*     */   private JdkProxyHint(Builder builder) {
/*  43 */     this.proxiedInterfaces = List.copyOf(builder.proxiedInterfaces);
/*  44 */     this.reachableType = builder.reachableType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder of(TypeReference... proxiedInterfaces) {
/*  53 */     return (new Builder()).proxiedInterfaces(proxiedInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder of(Class<?>... proxiedInterfaces) {
/*  62 */     return (new Builder()).proxiedInterfaces(proxiedInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TypeReference> getProxiedInterfaces() {
/*  71 */     return this.proxiedInterfaces;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeReference getReachableType() {
/*  77 */     return this.reachableType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  82 */     if (this != other) { if (other instanceof JdkProxyHint) { JdkProxyHint that = (JdkProxyHint)other; if (this.proxiedInterfaces
/*  83 */           .equals(that.proxiedInterfaces) && 
/*  84 */           Objects.equals(this.reachableType, that.reachableType)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  89 */     return Objects.hash(new Object[] { this.proxiedInterfaces });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/* 104 */     private final LinkedList<TypeReference> proxiedInterfaces = new LinkedList<>();
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private TypeReference reachableType;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder proxiedInterfaces(TypeReference... proxiedInterfaces) {
/* 113 */       this.proxiedInterfaces.addAll(Arrays.asList(proxiedInterfaces));
/* 114 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder proxiedInterfaces(Class<?>... proxiedInterfaces) {
/* 123 */       this.proxiedInterfaces.addAll(toTypeReferences(proxiedInterfaces));
/* 124 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder onReachableType(TypeReference reachableType) {
/* 133 */       this.reachableType = reachableType;
/* 134 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JdkProxyHint build() {
/* 142 */       return new JdkProxyHint(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static List<TypeReference> toTypeReferences(Class<?>... proxiedInterfaces) {
/* 149 */       List<String> invalidTypes = Arrays.<Class<?>>stream(proxiedInterfaces).filter(candidate -> (!candidate.isInterface() || candidate.isSealed())).map(Class::getName).toList();
/* 150 */       if (!invalidTypes.isEmpty()) {
/* 151 */         throw new IllegalArgumentException("The following must be non-sealed interfaces: " + String.valueOf(invalidTypes));
/*     */       }
/* 153 */       return TypeReference.listOf(proxiedInterfaces);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\JdkProxyHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */