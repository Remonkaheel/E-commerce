package org.springframework.aot.hint;

import org.springframework.lang.Nullable;

@FunctionalInterface
public interface RuntimeHintsRegistrar {
  void registerHints(RuntimeHints paramRuntimeHints, @Nullable ClassLoader paramClassLoader);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\RuntimeHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */