/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ExecutableMode
/*    */ {
/* 34 */   INTROSPECT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   INVOKE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean includes(@Nullable ExecutableMode other) {
/* 48 */     return (other == null || ordinal() >= other.ordinal());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ExecutableMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */