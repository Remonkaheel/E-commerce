/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReflectionTypeReference
/*    */   extends AbstractTypeReference
/*    */ {
/*    */   private final Class<?> type;
/*    */   
/*    */   private ReflectionTypeReference(Class<?> type) {
/* 34 */     super(type.getPackageName(), type.getSimpleName(), getEnclosingClass(type));
/* 35 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private static TypeReference getEnclosingClass(Class<?> type) {
/* 41 */     Class<?> candidate = type.isArray() ? type.componentType().getEnclosingClass() : type.getEnclosingClass();
/* 42 */     return (candidate != null) ? new ReflectionTypeReference(candidate) : null;
/*    */   }
/*    */   
/*    */   static ReflectionTypeReference of(Class<?> type) {
/* 46 */     Assert.notNull(type, "'type' must not be null");
/* 47 */     Assert.notNull(type.getCanonicalName(), "'type.getCanonicalName()' must not be null");
/* 48 */     return new ReflectionTypeReference(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCanonicalName() {
/* 53 */     return this.type.getCanonicalName();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isPrimitive() {
/* 58 */     return (this.type.isPrimitive() || (this.type
/* 59 */       .isArray() && this.type.componentType().isPrimitive()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ReflectionTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */