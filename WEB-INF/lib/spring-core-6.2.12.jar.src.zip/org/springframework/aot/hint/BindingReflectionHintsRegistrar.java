/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.RecordComponent;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KClass;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingReflectionHintsRegistrar
/*     */ {
/*     */   private static final String KOTLIN_COMPANION_SUFFIX = "$Companion";
/*     */   private static final String JACKSON_ANNOTATION = "com.fasterxml.jackson.annotation.JacksonAnnotation";
/*  59 */   private static final boolean jacksonAnnotationPresent = ClassUtils.isPresent("com.fasterxml.jackson.annotation.JacksonAnnotation", BindingReflectionHintsRegistrar.class.getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerReflectionHints(ReflectionHints hints, Type... types) {
/*  68 */     Set<Type> seen = new HashSet<>();
/*  69 */     for (Type type : types) {
/*  70 */       registerReflectionHints(hints, seen, type);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean shouldSkipType(Class<?> type) {
/*  75 */     return (type.isPrimitive() || type == Object.class);
/*     */   }
/*     */   
/*     */   private boolean shouldSkipMembers(Class<?> type) {
/*  79 */     return (type.getCanonicalName().startsWith("java.") || type.isArray());
/*     */   }
/*     */   
/*     */   private void registerReflectionHints(ReflectionHints hints, Set<Type> seen, Type type) {
/*  83 */     if (seen.contains(type)) {
/*     */       return;
/*     */     }
/*  86 */     seen.add(type);
/*  87 */     if (type instanceof Class) { Class<?> clazz = (Class)type;
/*  88 */       if (shouldSkipType(clazz)) {
/*     */         return;
/*     */       }
/*  91 */       hints.registerType(clazz, typeHint -> {
/*     */             if (!shouldSkipMembers(clazz)) {
/*     */               if (clazz.isRecord()) {
/*     */                 typeHint.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */                 
/*     */                 for (RecordComponent recordComponent : clazz.getRecordComponents()) {
/*     */                   registerRecordHints(hints, seen, recordComponent.getAccessor());
/*     */                 }
/*     */               } 
/*     */               
/*     */               if (clazz.isEnum()) {
/*     */                 typeHint.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_CONSTRUCTORS, MemberCategory.INVOKE_PUBLIC_METHODS });
/*     */               }
/*     */               
/*     */               typeHint.withMembers(new MemberCategory[] { MemberCategory.DECLARED_FIELDS, MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */               
/*     */               for (Method method : clazz.getMethods()) {
/*     */                 String methodName = method.getName();
/*     */                 
/*     */                 if (methodName.startsWith("set") && method.getParameterCount() == 1) {
/*     */                   registerPropertyHints(hints, seen, method, 0);
/*     */                 } else if ((methodName.startsWith("get") && method.getParameterCount() == 0 && method.getReturnType() != void.class) || (methodName.startsWith("is") && method.getParameterCount() == 0 && ClassUtils.resolvePrimitiveIfNecessary(method.getReturnType()) == Boolean.class)) {
/*     */                   registerPropertyHints(hints, seen, method, -1);
/*     */                 } 
/*     */               } 
/*     */               
/*     */               if (jacksonAnnotationPresent) {
/*     */                 registerJacksonHints(hints, clazz);
/*     */               }
/*     */             } 
/*     */             if (KotlinDetector.isKotlinType(clazz)) {
/*     */               KotlinDelegate.registerComponentHints(hints, clazz);
/*     */               registerKotlinSerializationHints(hints, clazz);
/*     */               typeHint.withMembers(new MemberCategory[] { MemberCategory.INTROSPECT_DECLARED_METHODS });
/*     */             } 
/*     */           }); }
/*     */     
/* 128 */     Set<Class<?>> referencedTypes = new LinkedHashSet<>();
/* 129 */     collectReferencedTypes(referencedTypes, ResolvableType.forType(type));
/* 130 */     referencedTypes.forEach(referencedType -> registerReflectionHints(hints, seen, referencedType));
/*     */   }
/*     */   
/*     */   private void registerRecordHints(ReflectionHints hints, Set<Type> seen, Method method) {
/* 134 */     hints.registerMethod(method, ExecutableMode.INVOKE);
/* 135 */     MethodParameter methodParameter = MethodParameter.forExecutable(method, -1);
/* 136 */     Type methodParameterType = methodParameter.getGenericParameterType();
/* 137 */     registerReflectionHints(hints, seen, methodParameterType);
/*     */   }
/*     */   
/*     */   private void registerPropertyHints(ReflectionHints hints, Set<Type> seen, @Nullable Method method, int parameterIndex) {
/* 141 */     if (method != null && method.getDeclaringClass() != Object.class && method.getDeclaringClass() != Enum.class) {
/* 142 */       hints.registerMethod(method, ExecutableMode.INVOKE);
/* 143 */       MethodParameter methodParameter = MethodParameter.forExecutable(method, parameterIndex);
/* 144 */       Type methodParameterType = methodParameter.getGenericParameterType();
/* 145 */       registerReflectionHints(hints, seen, methodParameterType);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerKotlinSerializationHints(ReflectionHints hints, Class<?> clazz) {
/* 150 */     String companionClassName = clazz.getCanonicalName() + "$Companion";
/* 151 */     if (ClassUtils.isPresent(companionClassName, null)) {
/* 152 */       Class<?> companionClass = ClassUtils.resolveClassName(companionClassName, null);
/* 153 */       Method serializerMethod = ClassUtils.getMethodIfAvailable(companionClass, "serializer", (Class[])null);
/*     */       
/* 155 */       if (serializerMethod != null) {
/* 156 */         hints.registerMethod(serializerMethod, ExecutableMode.INVOKE);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void collectReferencedTypes(Set<Class<?>> types, ResolvableType resolvableType) {
/* 162 */     Class<?> clazz = resolvableType.resolve();
/* 163 */     if (clazz != null && !types.contains(clazz)) {
/* 164 */       types.add(clazz);
/* 165 */       for (ResolvableType genericResolvableType : resolvableType.getGenerics()) {
/* 166 */         collectReferencedTypes(types, genericResolvableType);
/*     */       }
/* 168 */       Class<?> superClass = clazz.getSuperclass();
/* 169 */       if (superClass != null && superClass != Object.class && superClass != Record.class && superClass != Enum.class) {
/* 170 */         types.add(superClass);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerJacksonHints(ReflectionHints hints, Class<?> clazz) {
/* 176 */     ReflectionUtils.doWithFields(clazz, field -> forEachJacksonAnnotation(field, ()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     ReflectionUtils.doWithMethods(clazz, method -> forEachJacksonAnnotation(method, ()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     forEachJacksonAnnotation(clazz, annotation -> registerHintsForClassAttributes(hints, annotation));
/*     */   }
/*     */ 
/*     */   
/*     */   private void forEachJacksonAnnotation(AnnotatedElement element, Consumer<MergedAnnotation<Annotation>> action) {
/* 197 */     MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/* 198 */       .stream("com.fasterxml.jackson.annotation.JacksonAnnotation")
/* 199 */       .filter(MergedAnnotation::isMetaPresent)
/* 200 */       .forEach(action);
/*     */   }
/*     */   
/*     */   private void registerHintsForClassAttributes(ReflectionHints hints, MergedAnnotation<Annotation> annotation) {
/* 204 */     annotation.getRoot().asMap(new MergedAnnotation.Adapt[0]).forEach((attributeName, value) -> {
/*     */           if (value instanceof Class) {
/*     */             Class<?> classValue = (Class)value;
/*     */             if (value != Void.class) {
/*     */               if (attributeName.equals("builder")) {
/*     */                 hints.registerType(classValue, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_DECLARED_METHODS });
/*     */               } else {
/*     */                 hints.registerType(classValue, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */               } 
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     public static void registerComponentHints(ReflectionHints hints, Class<?> type) {
/* 224 */       KClass<?> kClass = JvmClassMappingKt.getKotlinClass(type);
/* 225 */       if (kClass.isData())
/* 226 */         for (Method method : type.getMethods()) {
/* 227 */           String methodName = method.getName();
/* 228 */           if (methodName.startsWith("component") || methodName.equals("copy") || methodName.equals("copy$default"))
/* 229 */             hints.registerMethod(method, ExecutableMode.INVOKE); 
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\BindingReflectionHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */