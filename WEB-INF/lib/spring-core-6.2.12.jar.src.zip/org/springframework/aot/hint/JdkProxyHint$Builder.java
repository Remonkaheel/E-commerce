/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */ {
/* 104 */   private final LinkedList<TypeReference> proxiedInterfaces = new LinkedList<>();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypeReference reachableType;
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder proxiedInterfaces(TypeReference... proxiedInterfaces) {
/* 113 */     this.proxiedInterfaces.addAll(Arrays.asList(proxiedInterfaces));
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder proxiedInterfaces(Class<?>... proxiedInterfaces) {
/* 123 */     this.proxiedInterfaces.addAll(toTypeReferences(proxiedInterfaces));
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder onReachableType(TypeReference reachableType) {
/* 133 */     this.reachableType = reachableType;
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JdkProxyHint build() {
/* 142 */     return new JdkProxyHint(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<TypeReference> toTypeReferences(Class<?>... proxiedInterfaces) {
/* 149 */     List<String> invalidTypes = Arrays.<Class<?>>stream(proxiedInterfaces).filter(candidate -> (!candidate.isInterface() || candidate.isSealed())).map(Class::getName).toList();
/* 150 */     if (!invalidTypes.isEmpty()) {
/* 151 */       throw new IllegalArgumentException("The following must be non-sealed interfaces: " + String.valueOf(invalidTypes));
/*     */     }
/* 153 */     return TypeReference.listOf(proxiedInterfaces);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\JdkProxyHint$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */