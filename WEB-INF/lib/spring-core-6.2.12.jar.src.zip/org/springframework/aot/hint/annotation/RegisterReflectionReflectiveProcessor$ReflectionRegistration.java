/*    */ package org.springframework.aot.hint.annotation;
/*    */ 
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReflectionRegistration
/*    */   extends Record
/*    */ {
/*    */   private final Class<?>[] classes;
/*    */   private final MemberCategory[] memberCategories;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #97	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #97	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #97	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   protected ReflectionRegistration(Class<?>[] classes, MemberCategory[] memberCategories) {
/* 97 */     this.classes = classes; this.memberCategories = memberCategories; } public Class<?>[] classes() { return this.classes; } public MemberCategory[] memberCategories() { return this.memberCategories; }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\annotation\RegisterReflectionReflectiveProcessor$ReflectionRegistration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */