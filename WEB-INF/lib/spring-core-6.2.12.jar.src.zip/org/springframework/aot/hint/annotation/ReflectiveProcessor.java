package org.springframework.aot.hint.annotation;

import java.lang.reflect.AnnotatedElement;
import org.springframework.aot.hint.ReflectionHints;

public interface ReflectiveProcessor {
  void registerReflectionHints(ReflectionHints paramReflectionHints, AnnotatedElement paramAnnotatedElement);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\annotation\ReflectiveProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */