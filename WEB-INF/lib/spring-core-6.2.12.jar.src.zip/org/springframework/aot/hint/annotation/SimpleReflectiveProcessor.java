/*    */ package org.springframework.aot.hint.annotation;
/*    */ 
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aot.hint.ExecutableMode;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleReflectiveProcessor
/*    */   implements ReflectiveProcessor
/*    */ {
/*    */   public void registerReflectionHints(ReflectionHints hints, AnnotatedElement element) {
/* 39 */     if (element instanceof Class) { Class<?> type = (Class)element;
/* 40 */       registerTypeHint(hints, type); }
/*    */     
/* 42 */     else if (element instanceof Constructor) { Constructor<?> constructor = (Constructor)element;
/* 43 */       registerConstructorHint(hints, constructor); }
/*    */     
/* 45 */     else if (element instanceof Field) { Field field = (Field)element;
/* 46 */       registerFieldHint(hints, field); }
/*    */     
/* 48 */     else if (element instanceof Method) { Method method = (Method)element;
/* 49 */       registerMethodHint(hints, method); }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void registerTypeHint(ReflectionHints hints, Class<?> type) {
/* 59 */     hints.registerType(type, new org.springframework.aot.hint.MemberCategory[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void registerConstructorHint(ReflectionHints hints, Constructor<?> constructor) {
/* 68 */     hints.registerConstructor(constructor, ExecutableMode.INVOKE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void registerFieldHint(ReflectionHints hints, Field field) {
/* 77 */     hints.registerField(field);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void registerMethodHint(ReflectionHints hints, Method method) {
/* 86 */     hints.registerMethod(method, ExecutableMode.INVOKE);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\annotation\SimpleReflectiveProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */