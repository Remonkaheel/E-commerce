/*    */ package org.springframework.aot.hint.annotation;
/*    */ 
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegisterReflectionReflectiveProcessor
/*    */   implements ReflectiveProcessor
/*    */ {
/* 46 */   private static final Log logger = LogFactory.getLog(RegisterReflectionReflectiveProcessor.class);
/*    */ 
/*    */ 
/*    */   
/*    */   public final void registerReflectionHints(ReflectionHints hints, AnnotatedElement element) {
/* 51 */     RegisterReflection annotation = (RegisterReflection)AnnotatedElementUtils.getMergedAnnotation(element, RegisterReflection.class);
/* 52 */     Assert.notNull(annotation, () -> "Element must be annotated with @RegisterReflection: " + String.valueOf(element));
/* 53 */     ReflectionRegistration registration = parse(element, annotation);
/* 54 */     registerReflectionHints(hints, registration);
/*    */   }
/*    */   
/*    */   protected ReflectionRegistration parse(AnnotatedElement element, RegisterReflection annotation) {
/* 58 */     List<Class<?>> allClassNames = new ArrayList<>();
/* 59 */     allClassNames.addAll(Arrays.asList(annotation.classes()));
/* 60 */     allClassNames.addAll(Arrays.<String>stream(annotation.classNames())
/* 61 */         .map(this::loadClass).filter(Objects::nonNull).toList());
/* 62 */     if (allClassNames.isEmpty()) {
/* 63 */       if (element instanceof Class) { Class<?> clazz = (Class)element;
/* 64 */         allClassNames.add(clazz); }
/*    */       else
/*    */       
/* 67 */       { throw new IllegalStateException("At least one class must be specified: " + String.valueOf(element)); }
/*    */     
/*    */     }
/* 70 */     return new ReflectionRegistration((Class[])allClassNames.<Class<?>[]>toArray((Class<?>[][])new Class[0]), annotation.memberCategories());
/*    */   }
/*    */   
/*    */   protected void registerReflectionHints(ReflectionHints hints, ReflectionRegistration registration) {
/* 74 */     for (Class<?> target : registration.classes) {
/* 75 */       registerReflectionHints(hints, target, registration.memberCategories);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void registerReflectionHints(ReflectionHints hints, Class<?> target, MemberCategory[] memberCategories) {
/* 80 */     hints.registerType(target, type -> type.withMembers(memberCategories));
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   private Class<?> loadClass(String className) {
/*    */     try {
/* 86 */       return ClassUtils.forName(className, getClass().getClassLoader());
/*    */     }
/* 88 */     catch (Exception ex) {
/* 89 */       if (logger.isWarnEnabled()) {
/* 90 */         logger.warn("Ignoring '" + className + "': " + String.valueOf(ex));
/*    */       }
/* 92 */       return null;
/*    */     } 
/*    */   }
/*    */   protected static final class ReflectionRegistration extends Record { private final Class<?>[] classes; private final MemberCategory[] memberCategories;
/*    */     
/* 97 */     protected ReflectionRegistration(Class<?>[] classes, MemberCategory[] memberCategories) { this.classes = classes; this.memberCategories = memberCategories; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #97	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 97 */       //   0	7	0	this	Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration; } public Class<?>[] classes() { return this.classes; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #97	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #97	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lorg/springframework/aot/hint/annotation/RegisterReflectionReflectiveProcessor$ReflectionRegistration;
/* 97 */       //   0	8	1	o	Ljava/lang/Object; } public MemberCategory[] memberCategories() { return this.memberCategories; }
/*    */      }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\annotation\RegisterReflectionReflectiveProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */