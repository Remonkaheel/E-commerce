/*    */ package org.springframework.aot.hint.annotation;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import org.springframework.aot.hint.BindingReflectionHintsRegistrar;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RegisterReflectionForBindingProcessor
/*    */   extends RegisterReflectionReflectiveProcessor
/*    */ {
/* 36 */   private final BindingReflectionHintsRegistrar bindingRegistrar = new BindingReflectionHintsRegistrar();
/*    */ 
/*    */   
/*    */   protected void registerReflectionHints(ReflectionHints hints, Class<?> target, MemberCategory[] memberCategories) {
/* 40 */     this.bindingRegistrar.registerReflectionHints(hints, new Type[] { target });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\annotation\RegisterReflectionForBindingProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */