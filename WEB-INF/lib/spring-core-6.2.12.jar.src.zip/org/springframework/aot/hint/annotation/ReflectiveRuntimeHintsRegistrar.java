/*     */ package org.springframework.aot.hint.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveRuntimeHintsRegistrar
/*     */ {
/*  47 */   private final Map<Class<? extends ReflectiveProcessor>, ReflectiveProcessor> processors = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerRuntimeHints(RuntimeHints runtimeHints, Class<?>... types) {
/*  57 */     Set<Entry> entries = new HashSet<>();
/*  58 */     for (Class<?> type : types) {
/*  59 */       processType(entries, type);
/*  60 */       for (Class<?> implementedInterface : ClassUtils.getAllInterfacesForClass(type)) {
/*  61 */         processType(entries, implementedInterface);
/*     */       }
/*     */     } 
/*  64 */     entries.forEach(entry -> {
/*     */           AnnotatedElement element = entry.element();
/*     */           entry.processor().registerReflectionHints(runtimeHints.reflection(), element);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCandidate(Class<?> type) {
/*  78 */     if (isReflective(type)) {
/*  79 */       return true;
/*     */     }
/*  81 */     AtomicBoolean candidate = new AtomicBoolean(false);
/*  82 */     doWithReflectiveConstructors(type, constructor -> candidate.set(true));
/*  83 */     if (!candidate.get()) {
/*  84 */       ReflectionUtils.doWithFields(type, field -> candidate.set(true), this::isReflective);
/*     */     }
/*  86 */     if (!candidate.get()) {
/*  87 */       ReflectionUtils.doWithMethods(type, method -> candidate.set(true), this::isReflective);
/*     */     }
/*  89 */     return candidate.get();
/*     */   }
/*     */   
/*     */   private void processType(Set<Entry> entries, Class<?> typeToProcess) {
/*  93 */     if (isReflective(typeToProcess)) {
/*  94 */       entries.add(createEntry(typeToProcess));
/*     */     }
/*  96 */     doWithReflectiveConstructors(typeToProcess, constructor -> entries.add(createEntry(constructor)));
/*     */     
/*  98 */     ReflectionUtils.doWithFields(typeToProcess, field -> entries.add(createEntry(field)), this::isReflective);
/*     */     
/* 100 */     ReflectionUtils.doWithMethods(typeToProcess, method -> entries.add(createEntry(method)), this::isReflective);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doWithReflectiveConstructors(Class<?> typeToProcess, Consumer<Constructor<?>> consumer) {
/* 105 */     for (Constructor<?> constructor : typeToProcess.getDeclaredConstructors()) {
/* 106 */       if (isReflective(constructor)) {
/* 107 */         consumer.accept(constructor);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isReflective(AnnotatedElement element) {
/* 113 */     return MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).isPresent(Reflective.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Entry createEntry(AnnotatedElement element) {
/* 125 */     List<ReflectiveProcessor> processors = MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).stream(Reflective.class).map(annotation -> annotation.getClassArray("value")).flatMap(Arrays::stream).distinct().map(type -> type).map(processorClass -> (ReflectiveProcessor)this.processors.computeIfAbsent(processorClass, this::instantiateClass)).toList();
/*     */     
/* 127 */     ReflectiveProcessor processorToUse = (processors.size() == 1) ? processors.get(0) : new DelegatingReflectiveProcessor(processors);
/* 128 */     return new Entry(element, processorToUse);
/*     */   }
/*     */   
/*     */   private ReflectiveProcessor instantiateClass(Class<? extends ReflectiveProcessor> type) {
/*     */     try {
/* 133 */       return ReflectionUtils.accessibleConstructor(type, new Class[0]).newInstance(new Object[0]);
/*     */     }
/* 135 */     catch (Exception ex) {
/* 136 */       throw new IllegalStateException("Failed to instantiate " + String.valueOf(type), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class DelegatingReflectiveProcessor
/*     */     implements ReflectiveProcessor
/*     */   {
/*     */     private final Iterable<ReflectiveProcessor> processors;
/*     */     
/*     */     DelegatingReflectiveProcessor(Iterable<ReflectiveProcessor> processors) {
/* 146 */       this.processors = processors;
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerReflectionHints(ReflectionHints hints, AnnotatedElement element) {
/* 151 */       this.processors.forEach(processor -> processor.registerReflectionHints(hints, element));
/*     */     } }
/*     */   private static final class Entry extends Record { private final AnnotatedElement element;
/*     */     private final ReflectiveProcessor processor;
/*     */     
/* 156 */     private Entry(AnnotatedElement element, ReflectiveProcessor processor) { this.element = element; this.processor = processor; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/aot/hint/annotation/ReflectiveRuntimeHintsRegistrar$Entry;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #156	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 156 */       //   0	7	0	this	Lorg/springframework/aot/hint/annotation/ReflectiveRuntimeHintsRegistrar$Entry; } public AnnotatedElement element() { return this.element; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/aot/hint/annotation/ReflectiveRuntimeHintsRegistrar$Entry;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #156	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aot/hint/annotation/ReflectiveRuntimeHintsRegistrar$Entry; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/aot/hint/annotation/ReflectiveRuntimeHintsRegistrar$Entry;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #156	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/aot/hint/annotation/ReflectiveRuntimeHintsRegistrar$Entry;
/* 156 */       //   0	8	1	o	Ljava/lang/Object; } public ReflectiveProcessor processor() { return this.processor; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\annotation\ReflectiveRuntimeHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */