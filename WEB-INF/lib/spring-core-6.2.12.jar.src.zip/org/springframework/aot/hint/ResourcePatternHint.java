/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourcePatternHint
/*     */   implements ConditionalHint
/*     */ {
/*     */   private final String pattern;
/*     */   @Nullable
/*     */   private final TypeReference reachableType;
/*     */   
/*     */   ResourcePatternHint(String pattern, @Nullable TypeReference reachableType) {
/*  64 */     Assert.isTrue(("/".equals(pattern) || !pattern.startsWith("/")), () -> "Resource pattern [%s] must not start with a '/' unless it is the root directory".formatted(new Object[] { pattern }));
/*     */ 
/*     */     
/*  67 */     this.pattern = pattern;
/*  68 */     this.reachableType = reachableType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/*  76 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pattern toRegex() {
/*  83 */     String prefix = this.pattern.startsWith("*") ? ".*" : "";
/*  84 */     String suffix = this.pattern.endsWith("*") ? ".*" : "";
/*     */ 
/*     */ 
/*     */     
/*  88 */     String regex = Arrays.<String>stream(this.pattern.split("\\*")).filter(s -> !s.isEmpty()).map(Pattern::quote).collect(Collectors.joining(".*", prefix, suffix));
/*  89 */     return Pattern.compile(regex);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeReference getReachableType() {
/*  95 */     return this.reachableType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 100 */     if (this != other) { if (other instanceof ResourcePatternHint) { ResourcePatternHint that = (ResourcePatternHint)other; if (this.pattern
/* 101 */           .equals(that.pattern) && Objects.equals(this.reachableType, that.reachableType)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 106 */     return Objects.hash(new Object[] { this.pattern, this.reachableType });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ResourcePatternHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */