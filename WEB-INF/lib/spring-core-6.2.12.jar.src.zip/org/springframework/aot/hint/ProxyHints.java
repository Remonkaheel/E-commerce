/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProxyHints
/*    */ {
/* 32 */   private final Set<JdkProxyHint> jdkProxies = new LinkedHashSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<JdkProxyHint> jdkProxyHints() {
/* 40 */     return this.jdkProxies.stream();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ProxyHints registerJdkProxy(Consumer<JdkProxyHint.Builder> jdkProxyHint) {
/* 49 */     JdkProxyHint.Builder builder = new JdkProxyHint.Builder();
/* 50 */     jdkProxyHint.accept(builder);
/* 51 */     this.jdkProxies.add(builder.build());
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ProxyHints registerJdkProxy(TypeReference... proxiedInterfaces) {
/* 63 */     return registerJdkProxy(jdkProxyHint -> jdkProxyHint.proxiedInterfaces(proxiedInterfaces));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ProxyHints registerJdkProxy(Class<?>... proxiedInterfaces) {
/* 77 */     return registerJdkProxy(jdkProxyHint -> jdkProxyHint.proxiedInterfaces(proxiedInterfaces));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ProxyHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */