/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TypeReference
/*    */   extends Comparable<TypeReference>
/*    */ {
/*    */   String getName();
/*    */   
/*    */   String getCanonicalName();
/*    */   
/*    */   String getPackageName();
/*    */   
/*    */   String getSimpleName();
/*    */   
/*    */   @Nullable
/*    */   TypeReference getEnclosingType();
/*    */   
/*    */   static TypeReference of(Class<?> type) {
/* 75 */     return ReflectionTypeReference.of(type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TypeReference of(String className) {
/* 86 */     return SimpleTypeReference.of(className);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static List<TypeReference> listOf(Class<?>... types) {
/* 96 */     return Arrays.<Class<?>>stream(types).map(TypeReference::of).toList();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\TypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */