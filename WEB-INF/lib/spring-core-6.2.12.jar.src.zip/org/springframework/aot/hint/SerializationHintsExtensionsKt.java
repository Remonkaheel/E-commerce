/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.function.Consumer;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\036\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\020\002\n\000\032:\020\000\032\n \002*\004\030\0010\0010\001\"\n\b\000\020\003\030\001*\0020\004*\0020\0012\024\b\n\020\005\032\016\022\004\022\0020\007\022\004\022\0020\b0\006H\bø\001\000\002\007\n\005\b20\001¨\006\t"}, d2 = {"registerType", "Lorg/springframework/aot/hint/SerializationHints;", "kotlin.jvm.PlatformType", "T", "Ljava/io/Serializable;", "serializationHint", "Lkotlin/Function1;", "Lorg/springframework/aot/hint/JavaSerializationHint$Builder;", "", "spring-core"})
/*    */ public final class SerializationHintsExtensionsKt
/*    */ {
/*    */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\024\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\0032\006\020\004\032\0020\005H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "T", "Ljava/io/Serializable;", "it", "Lorg/springframework/aot/hint/JavaSerializationHint$Builder;", "invoke"})
/*    */   @SourceDebugExtension({"SMAP\nSerializationHintsExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SerializationHintsExtensions.kt\norg/springframework/aot/hint/SerializationHintsExtensionsKt$registerType$1\n*L\n1#1,30:1\n*E\n"})
/*    */   public static final class SerializationHintsExtensionsKt$registerType$1
/*    */     extends Lambda
/*    */     implements Function1<JavaSerializationHint.Builder, Unit> {
/*    */     public static final SerializationHintsExtensionsKt$registerType$1 INSTANCE = new SerializationHintsExtensionsKt$registerType$1();
/*    */     
/*    */     public SerializationHintsExtensionsKt$registerType$1() {
/*    */       super(1);
/*    */     }
/*    */     
/*    */     public final void invoke(@NotNull JavaSerializationHint.Builder it) {
/* 28 */       Intrinsics.checkNotNullParameter(it, "it");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\SerializationHintsExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */