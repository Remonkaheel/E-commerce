/*    */ package org.springframework.aot.hint.predicate;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.aot.hint.JavaSerializationHint;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializationHintsPredicates
/*    */ {
/*    */   public Predicate<RuntimeHints> onType(Class<?> type) {
/* 47 */     Assert.notNull(type, "'type' must not be null");
/* 48 */     return onType(TypeReference.of(type));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Predicate<RuntimeHints> onType(TypeReference typeReference) {
/* 59 */     Assert.notNull(typeReference, "'typeReference' must not be null");
/* 60 */     return hints -> hints.serialization().javaSerializationHints().anyMatch(());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\SerializationHintsPredicates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */