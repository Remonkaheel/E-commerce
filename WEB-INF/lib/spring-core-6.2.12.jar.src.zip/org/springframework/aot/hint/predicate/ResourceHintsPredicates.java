/*     */ package org.springframework.aot.hint.predicate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.aot.hint.ResourceBundleHint;
/*     */ import org.springframework.aot.hint.ResourceHints;
/*     */ import org.springframework.aot.hint.ResourcePatternHint;
/*     */ import org.springframework.aot.hint.ResourcePatternHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentLruCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHintsPredicates
/*     */ {
/*  42 */   private static final ConcurrentLruCache<ResourcePatternHint, Pattern> CACHED_RESOURCE_PATTERNS = new ConcurrentLruCache(32, ResourcePatternHint::toRegex);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate<RuntimeHints> forBundle(String bundleName) {
/*  53 */     Assert.hasText(bundleName, "resource bundle name should not be empty");
/*  54 */     return runtimeHints -> runtimeHints.resources().resourceBundleHints().anyMatch(());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate<RuntimeHints> forResource(TypeReference type, String resourceName) {
/*  72 */     String absoluteName = resolveAbsoluteResourceName(type, resourceName);
/*  73 */     return forResource(absoluteName);
/*     */   }
/*     */ 
/*     */   
/*     */   private String resolveAbsoluteResourceName(TypeReference type, String resourceName) {
/*  78 */     if (resourceName.startsWith("/")) {
/*  79 */       return resourceName.substring(1);
/*     */     }
/*     */     
/*  82 */     if (type.getPackageName().isEmpty()) {
/*  83 */       return resourceName;
/*     */     }
/*     */ 
/*     */     
/*  87 */     return type.getPackageName().replace('.', '/') + "/" + type.getPackageName().replace('.', '/');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate<RuntimeHints> forResource(String resourceName) {
/*  99 */     String resourceNameToUse = resourceName.startsWith("/") ? resourceName.substring(1) : resourceName;
/* 100 */     return hints -> {
/*     */         AggregatedResourcePatternHints aggregatedResourcePatternHints = AggregatedResourcePatternHints.of(hints.resources());
/*     */         boolean isExcluded = aggregatedResourcePatternHints.excludes().stream().anyMatch(());
/*     */         return isExcluded ? false : aggregatedResourcePatternHints.includes().stream().anyMatch(());
/*     */       };
/*     */   }
/*     */   private static final class AggregatedResourcePatternHints extends Record { private final List<ResourcePatternHint> includes; private final List<ResourcePatternHint> excludes;
/*     */     public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #113	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;
/*     */     }
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #113	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;
/*     */     }
/* 113 */     private AggregatedResourcePatternHints(List<ResourcePatternHint> includes, List<ResourcePatternHint> excludes) { this.includes = includes; this.excludes = excludes; } public List<ResourcePatternHint> includes() { return this.includes; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #113	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;
/* 113 */       //   0	8	1	o	Ljava/lang/Object; } public List<ResourcePatternHint> excludes() { return this.excludes; }
/*     */     
/*     */     static AggregatedResourcePatternHints of(ResourceHints resourceHints) {
/* 116 */       List<ResourcePatternHint> includes = new ArrayList<>();
/* 117 */       List<ResourcePatternHint> excludes = new ArrayList<>();
/* 118 */       resourceHints.resourcePatternHints().forEach(resourcePatternHint -> {
/*     */             includes.addAll(resourcePatternHint.getIncludes());
/*     */             excludes.addAll(resourcePatternHint.getExcludes());
/*     */           });
/* 122 */       return new AggregatedResourcePatternHints(includes, excludes);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\ResourceHintsPredicates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */