/*     */ package org.springframework.aot.hint.predicate;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeHintPredicate
/*     */   implements Predicate<RuntimeHints>
/*     */ {
/*     */   private final TypeReference type;
/*     */   
/*     */   TypeHintPredicate(TypeReference type) {
/* 201 */     this.type = type;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private TypeHint getTypeHint(RuntimeHints hints) {
/* 206 */     return hints.reflection().getTypeHint(this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean test(RuntimeHints hints) {
/* 211 */     return (getTypeHint(hints) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate<RuntimeHints> withMemberCategory(MemberCategory memberCategory) {
/* 220 */     Assert.notNull(memberCategory, "'memberCategory' must not be null");
/* 221 */     return and(hints -> {
/*     */           TypeHint hint = getTypeHint(hints);
/* 223 */           return (hint != null && hint.getMemberCategories().contains(memberCategory));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate<RuntimeHints> withMemberCategories(MemberCategory... memberCategories) {
/* 233 */     Assert.notEmpty((Object[])memberCategories, "'memberCategories' must not be empty");
/* 234 */     return and(hints -> {
/*     */           TypeHint hint = getTypeHint(hints);
/* 236 */           return (hint != null && hint.getMemberCategories().containsAll(Arrays.asList((Object[])memberCategories)));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate<RuntimeHints> withAnyMemberCategory(MemberCategory... memberCategories) {
/* 246 */     Assert.notEmpty((Object[])memberCategories, "'memberCategories' must not be empty");
/* 247 */     return and(hints -> {
/*     */           TypeHint hint = getTypeHint(hints);
/* 249 */           return (hint != null && Arrays.<MemberCategory>stream(memberCategories).anyMatch(()));
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\ReflectionHintsPredicates$TypeHintPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */