/*     */ package org.springframework.aot.hint.predicate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.aot.hint.ResourceHints;
/*     */ import org.springframework.aot.hint.ResourcePatternHint;
/*     */ import org.springframework.aot.hint.ResourcePatternHints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AggregatedResourcePatternHints
/*     */   extends Record
/*     */ {
/*     */   private final List<ResourcePatternHint> includes;
/*     */   private final List<ResourcePatternHint> excludes;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #113	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #113	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #113	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/aot/hint/predicate/ResourceHintsPredicates$AggregatedResourcePatternHints;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private AggregatedResourcePatternHints(List<ResourcePatternHint> includes, List<ResourcePatternHint> excludes) {
/* 113 */     this.includes = includes; this.excludes = excludes; } public List<ResourcePatternHint> includes() { return this.includes; } public List<ResourcePatternHint> excludes() { return this.excludes; }
/*     */   
/*     */   static AggregatedResourcePatternHints of(ResourceHints resourceHints) {
/* 116 */     List<ResourcePatternHint> includes = new ArrayList<>();
/* 117 */     List<ResourcePatternHint> excludes = new ArrayList<>();
/* 118 */     resourceHints.resourcePatternHints().forEach(resourcePatternHint -> {
/*     */           includes.addAll(resourcePatternHint.getIncludes());
/*     */           excludes.addAll(resourcePatternHint.getExcludes());
/*     */         });
/* 122 */     return new AggregatedResourcePatternHints(includes, excludes);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\ResourceHintsPredicates$AggregatedResourcePatternHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */