/*    */ package org.springframework.aot.hint.predicate;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.aot.hint.JdkProxyHint;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProxyHintsPredicates
/*    */ {
/*    */   public Predicate<RuntimeHints> forInterfaces(Class<?>... interfaces) {
/* 49 */     Assert.notEmpty((Object[])interfaces, "'interfaces' should not be empty");
/* 50 */     return forInterfaces((TypeReference[])Arrays.<Class<?>>stream(interfaces).map(TypeReference::of).toArray(x$0 -> new TypeReference[x$0]));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Predicate<RuntimeHints> forInterfaces(TypeReference... interfaces) {
/* 62 */     Assert.notEmpty((Object[])interfaces, "'interfaces' should not be empty");
/* 63 */     List<TypeReference> interfaceList = Arrays.asList(interfaces);
/* 64 */     return hints -> hints.proxies().jdkProxyHints().anyMatch(());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\ProxyHintsPredicates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */