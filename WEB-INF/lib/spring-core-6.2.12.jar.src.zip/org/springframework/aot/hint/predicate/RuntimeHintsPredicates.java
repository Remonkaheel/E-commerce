/*    */ package org.springframework.aot.hint.predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RuntimeHintsPredicates
/*    */ {
/* 45 */   private static final ReflectionHintsPredicates reflection = new ReflectionHintsPredicates();
/*    */   
/* 47 */   private static final ResourceHintsPredicates resource = new ResourceHintsPredicates();
/*    */   
/* 49 */   private static final SerializationHintsPredicates serialization = new SerializationHintsPredicates();
/*    */   
/* 51 */   private static final ProxyHintsPredicates proxies = new ProxyHintsPredicates();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ReflectionHintsPredicates reflection() {
/* 62 */     return reflection;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ResourceHintsPredicates resource() {
/* 70 */     return resource;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SerializationHintsPredicates serialization() {
/* 78 */     return serialization;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ProxyHintsPredicates proxies() {
/* 86 */     return proxies;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\RuntimeHintsPredicates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */