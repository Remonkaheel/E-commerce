/*     */ package org.springframework.aot.hint.predicate;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.aot.hint.ExecutableHint;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.FieldHint;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionHintsPredicates
/*     */ {
/*     */   public TypeHintPredicate onType(TypeReference typeReference) {
/*  62 */     Assert.notNull(typeReference, "'typeReference' must not be null");
/*  63 */     return new TypeHintPredicate(typeReference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeHintPredicate onType(Class<?> type) {
/*  73 */     Assert.notNull(type, "'type' must not be null");
/*  74 */     return new TypeHintPredicate(TypeReference.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstructorHintPredicate onConstructor(Constructor<?> constructor) {
/*  85 */     Assert.notNull(constructor, "'constructor' must not be null");
/*  86 */     return new ConstructorHintPredicate(constructor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodHintPredicate onMethod(Method method) {
/*  97 */     Assert.notNull(method, "'method' must not be null");
/*  98 */     return new MethodHintPredicate(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodHintPredicate onMethod(Class<?> type, String methodName) {
/* 112 */     Assert.notNull(type, "'type' must not be null");
/* 113 */     Assert.hasText(methodName, "'methodName' must not be empty");
/* 114 */     return new MethodHintPredicate(getMethod(type, methodName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodHintPredicate onMethod(String className, String methodName) throws ClassNotFoundException {
/* 129 */     Assert.hasText(className, "'className' must not be empty");
/* 130 */     Assert.hasText(methodName, "'methodName' must not be empty");
/* 131 */     return onMethod(Class.forName(className), methodName);
/*     */   }
/*     */   
/*     */   private Method getMethod(Class<?> type, String methodName) {
/* 135 */     ReflectionUtils.MethodFilter selector = method -> methodName.equals(method.getName());
/* 136 */     Set<Method> methods = MethodIntrospector.selectMethods(type, selector);
/* 137 */     if (methods.size() == 1) {
/* 138 */       return methods.iterator().next();
/*     */     }
/* 140 */     if (methods.size() > 1) {
/* 141 */       throw new IllegalArgumentException("Found multiple methods named '%s' on class %s".formatted(new Object[] { methodName, type.getName() }));
/*     */     }
/*     */     
/* 144 */     throw new IllegalArgumentException("No method named '%s' on class %s".formatted(new Object[] { methodName, type.getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldHintPredicate onField(Class<?> type, String fieldName) {
/* 159 */     Assert.notNull(type, "'type' must not be null");
/* 160 */     Assert.hasText(fieldName, "'fieldName' must not be empty");
/* 161 */     Field field = ReflectionUtils.findField(type, fieldName);
/* 162 */     if (field == null) {
/* 163 */       throw new IllegalArgumentException("No field named '%s' on class %s".formatted(new Object[] { fieldName, type.getName() }));
/*     */     }
/* 165 */     return new FieldHintPredicate(field);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldHintPredicate onField(String className, String fieldName) throws ClassNotFoundException {
/* 180 */     Assert.hasText(className, "'className' must not be empty");
/* 181 */     Assert.hasText(fieldName, "'fieldName' must not be empty");
/* 182 */     return onField(Class.forName(className), fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldHintPredicate onField(Field field) {
/* 191 */     Assert.notNull(field, "'field' must not be null");
/* 192 */     return new FieldHintPredicate(field);
/*     */   }
/*     */   
/*     */   public static class TypeHintPredicate
/*     */     implements Predicate<RuntimeHints>
/*     */   {
/*     */     private final TypeReference type;
/*     */     
/*     */     TypeHintPredicate(TypeReference type) {
/* 201 */       this.type = type;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private TypeHint getTypeHint(RuntimeHints hints) {
/* 206 */       return hints.reflection().getTypeHint(this.type);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(RuntimeHints hints) {
/* 211 */       return (getTypeHint(hints) != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Predicate<RuntimeHints> withMemberCategory(MemberCategory memberCategory) {
/* 220 */       Assert.notNull(memberCategory, "'memberCategory' must not be null");
/* 221 */       return and(hints -> {
/*     */             TypeHint hint = getTypeHint(hints);
/* 223 */             return (hint != null && hint.getMemberCategories().contains(memberCategory));
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Predicate<RuntimeHints> withMemberCategories(MemberCategory... memberCategories) {
/* 233 */       Assert.notEmpty((Object[])memberCategories, "'memberCategories' must not be empty");
/* 234 */       return and(hints -> {
/*     */             TypeHint hint = getTypeHint(hints);
/* 236 */             return (hint != null && hint.getMemberCategories().containsAll(Arrays.asList((Object[])memberCategories)));
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Predicate<RuntimeHints> withAnyMemberCategory(MemberCategory... memberCategories) {
/* 246 */       Assert.notEmpty((Object[])memberCategories, "'memberCategories' must not be empty");
/* 247 */       return and(hints -> {
/*     */             TypeHint hint = getTypeHint(hints);
/* 249 */             return (hint != null && Arrays.<MemberCategory>stream(memberCategories).anyMatch(()));
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static abstract class ExecutableHintPredicate<T extends Executable>
/*     */     implements Predicate<RuntimeHints>
/*     */   {
/*     */     protected final T executable;
/*     */     
/* 260 */     protected ExecutableMode executableMode = ExecutableMode.INTROSPECT;
/*     */     
/*     */     ExecutableHintPredicate(T executable) {
/* 263 */       this.executable = executable;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExecutableHintPredicate<T> introspect() {
/* 271 */       this.executableMode = ExecutableMode.INTROSPECT;
/* 272 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExecutableHintPredicate<T> invoke() {
/* 280 */       this.executableMode = ExecutableMode.INVOKE;
/* 281 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract Predicate<RuntimeHints> exactMatch();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean includes(ExecutableHint hint, String name, List<TypeReference> parameterTypes, ExecutableMode executableModes) {
/* 294 */       return (hint.getName().equals(name) && hint.getParameterTypes().equals(parameterTypes) && (hint
/* 295 */         .getMode().equals(ExecutableMode.INVOKE) || !executableModes.equals(ExecutableMode.INVOKE)));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ConstructorHintPredicate
/*     */     extends ExecutableHintPredicate<Constructor<?>>
/*     */   {
/*     */     ConstructorHintPredicate(Constructor<?> constructor) {
/* 303 */       super(constructor);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(RuntimeHints runtimeHints) {
/* 308 */       return (new ReflectionHintsPredicates.TypeHintPredicate(TypeReference.of(this.executable.getDeclaringClass())))
/* 309 */         .withAnyMemberCategory(getPublicMemberCategories())
/* 310 */         .and(hints -> Modifier.isPublic(this.executable.getModifiers()))
/* 311 */         .or((new ReflectionHintsPredicates.TypeHintPredicate(TypeReference.of(this.executable.getDeclaringClass()))).withAnyMemberCategory(getDeclaredMemberCategories()))
/* 312 */         .or(exactMatch()).test(runtimeHints);
/*     */     }
/*     */     
/*     */     MemberCategory[] getPublicMemberCategories() {
/* 316 */       if (this.executableMode == ExecutableMode.INTROSPECT) {
/* 317 */         return new MemberCategory[] { MemberCategory.INTROSPECT_PUBLIC_CONSTRUCTORS, MemberCategory.INVOKE_PUBLIC_CONSTRUCTORS };
/*     */       }
/*     */       
/* 320 */       return new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_CONSTRUCTORS };
/*     */     }
/*     */     
/*     */     MemberCategory[] getDeclaredMemberCategories() {
/* 324 */       if (this.executableMode == ExecutableMode.INTROSPECT) {
/* 325 */         return new MemberCategory[] { MemberCategory.INTROSPECT_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_DECLARED_CONSTRUCTORS };
/*     */       }
/*     */       
/* 328 */       return new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS };
/*     */     }
/*     */ 
/*     */     
/*     */     Predicate<RuntimeHints> exactMatch() {
/* 333 */       return hints -> {
/*     */           TypeHint hint = hints.reflection().getTypeHint(this.executable.getDeclaringClass());
/* 335 */           return (hint != null && hint.constructors().anyMatch(()));
/*     */         };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MethodHintPredicate
/*     */     extends ExecutableHintPredicate<Method>
/*     */   {
/*     */     MethodHintPredicate(Method method) {
/* 347 */       super(method);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(RuntimeHints runtimeHints) {
/* 352 */       return (new ReflectionHintsPredicates.TypeHintPredicate(TypeReference.of(this.executable.getDeclaringClass())))
/* 353 */         .withAnyMemberCategory(getPublicMemberCategories())
/* 354 */         .and(hints -> Modifier.isPublic(this.executable.getModifiers()))
/* 355 */         .or((new ReflectionHintsPredicates.TypeHintPredicate(TypeReference.of(this.executable.getDeclaringClass())))
/* 356 */           .withAnyMemberCategory(getDeclaredMemberCategories())
/* 357 */           .and(hints -> !Modifier.isPublic(this.executable.getModifiers())))
/* 358 */         .or(exactMatch()).test(runtimeHints);
/*     */     }
/*     */     
/*     */     MemberCategory[] getPublicMemberCategories() {
/* 362 */       if (this.executableMode == ExecutableMode.INTROSPECT) {
/* 363 */         return new MemberCategory[] { MemberCategory.INTROSPECT_PUBLIC_METHODS, MemberCategory.INVOKE_PUBLIC_METHODS };
/*     */       }
/*     */       
/* 366 */       return new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS };
/*     */     }
/*     */ 
/*     */     
/*     */     MemberCategory[] getDeclaredMemberCategories() {
/* 371 */       if (this.executableMode == ExecutableMode.INTROSPECT) {
/* 372 */         return new MemberCategory[] { MemberCategory.INTROSPECT_DECLARED_METHODS, MemberCategory.INVOKE_DECLARED_METHODS };
/*     */       }
/*     */       
/* 375 */       return new MemberCategory[] { MemberCategory.INVOKE_DECLARED_METHODS };
/*     */     }
/*     */ 
/*     */     
/*     */     Predicate<RuntimeHints> exactMatch() {
/* 380 */       return hints -> {
/*     */           TypeHint hint = hints.reflection().getTypeHint(this.executable.getDeclaringClass());
/* 382 */           return (hint != null && hint.methods().anyMatch(()));
/*     */         };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FieldHintPredicate
/*     */     implements Predicate<RuntimeHints>
/*     */   {
/*     */     private final Field field;
/*     */ 
/*     */     
/*     */     FieldHintPredicate(Field field) {
/* 396 */       this.field = field;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(RuntimeHints runtimeHints) {
/* 401 */       TypeHint typeHint = runtimeHints.reflection().getTypeHint(this.field.getDeclaringClass());
/* 402 */       if (typeHint == null) {
/* 403 */         return false;
/*     */       }
/* 405 */       return (memberCategoryMatch(typeHint) || exactMatch(typeHint));
/*     */     }
/*     */     
/*     */     private boolean memberCategoryMatch(TypeHint typeHint) {
/* 409 */       if (Modifier.isPublic(this.field.getModifiers())) {
/* 410 */         return typeHint.getMemberCategories().contains(MemberCategory.PUBLIC_FIELDS);
/*     */       }
/*     */       
/* 413 */       return typeHint.getMemberCategories().contains(MemberCategory.DECLARED_FIELDS);
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean exactMatch(TypeHint typeHint) {
/* 418 */       return typeHint.fields().anyMatch(fieldHint -> this.field.getName().equals(fieldHint.getName()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\predicate\ReflectionHintsPredicates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */