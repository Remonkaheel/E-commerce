/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExecutableHint
/*     */   extends MemberHint
/*     */   implements Comparable<ExecutableHint>
/*     */ {
/*     */   private final List<TypeReference> parameterTypes;
/*     */   private final ExecutableMode mode;
/*     */   
/*     */   private ExecutableHint(Builder builder) {
/*  45 */     super(builder.name);
/*  46 */     this.parameterTypes = List.copyOf(builder.parameterTypes);
/*  47 */     this.mode = (builder.mode != null) ? builder.mode : ExecutableMode.INVOKE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder ofConstructor(List<TypeReference> parameterTypes) {
/*  56 */     return new Builder("<init>", parameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder ofMethod(String name, List<TypeReference> parameterTypes) {
/*  66 */     return new Builder(name, parameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TypeReference> getParameterTypes() {
/*  75 */     return this.parameterTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExecutableMode getMode() {
/*  83 */     return this.mode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Consumer<Builder> builtWith(ExecutableMode mode) {
/*  93 */     return builder -> builder.withMode(mode);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ExecutableHint other) {
/*  98 */     return Comparator.comparing(MemberHint::getName, String::compareToIgnoreCase)
/*  99 */       .thenComparing(ExecutableHint::getParameterTypes, Comparator.comparingInt(List::size))
/* 100 */       .thenComparing(ExecutableHint::getParameterTypes, (params1, params2) -> {
/*     */           String left = params1.stream().map(TypeReference::getCanonicalName).collect(Collectors.joining(","));
/*     */           String right = params2.stream().map(TypeReference::getCanonicalName).collect(Collectors.joining(","));
/*     */           return left.compareTo(right);
/* 104 */         }).compare(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final List<TypeReference> parameterTypes;
/*     */     
/*     */     @Nullable
/*     */     private ExecutableMode mode;
/*     */ 
/*     */     
/*     */     Builder(String name, List<TypeReference> parameterTypes) {
/* 121 */       this.name = name;
/* 122 */       this.parameterTypes = parameterTypes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withMode(ExecutableMode mode) {
/* 131 */       Assert.notNull(mode, "'mode' must not be null");
/* 132 */       if (this.mode == null || !this.mode.includes(mode)) {
/* 133 */         this.mode = mode;
/*     */       }
/* 135 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ExecutableHint build() {
/* 143 */       return new ExecutableHint(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ExecutableHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */