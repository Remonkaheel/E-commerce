/*    */ package org.springframework.aot.hint.support;
/*    */ 
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class KotlinDetectorRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 34 */     hints.reflection().registerType(TypeReference.of("kotlin.Metadata"), new org.springframework.aot.hint.MemberCategory[0])
/* 35 */       .registerType(TypeReference.of("kotlin.reflect.full.KClasses"), new org.springframework.aot.hint.MemberCategory[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\support\KotlinDetectorRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */