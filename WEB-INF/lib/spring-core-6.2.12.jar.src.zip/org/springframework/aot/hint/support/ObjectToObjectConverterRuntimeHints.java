/*    */ package org.springframework.aot.hint.support;
/*    */ 
/*    */ import java.time.Instant;
/*    */ import java.time.LocalDate;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.aot.hint.ExecutableMode;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ObjectToObjectConverterRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 44 */     ReflectionHints reflectionHints = hints.reflection();
/*    */     
/* 46 */     TypeReference sqlDateTypeReference = TypeReference.of("java.sql.Date");
/* 47 */     reflectionHints.registerTypeIfPresent(classLoader, sqlDateTypeReference.getName(), hint -> hint.withMethod("toLocalDate", Collections.emptyList(), ExecutableMode.INVOKE).onReachableType(sqlDateTypeReference).withMethod("valueOf", List.of(TypeReference.of(LocalDate.class)), ExecutableMode.INVOKE).onReachableType(sqlDateTypeReference));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     TypeReference sqlTimestampTypeReference = TypeReference.of("java.sql.Timestamp");
/* 54 */     reflectionHints.registerTypeIfPresent(classLoader, sqlTimestampTypeReference.getName(), hint -> hint.withMethod("from", List.of(TypeReference.of(Instant.class)), ExecutableMode.INVOKE).onReachableType(sqlTimestampTypeReference));
/*    */ 
/*    */ 
/*    */     
/* 58 */     reflectionHints.registerTypeIfPresent(classLoader, "org.springframework.http.HttpMethod", builder -> builder.withMethod("valueOf", List.of(TypeReference.of(String.class)), ExecutableMode.INVOKE));
/*    */ 
/*    */     
/* 61 */     reflectionHints.registerTypeIfPresent(classLoader, "java.net.URI", new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\support\ObjectToObjectConverterRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */