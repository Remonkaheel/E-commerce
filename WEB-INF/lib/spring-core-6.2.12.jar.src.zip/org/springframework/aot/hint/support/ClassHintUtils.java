/*    */ package org.springframework.aot.hint.support;
/*    */ 
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClassHintUtils
/*    */ {
/*    */   private static final Consumer<TypeHint.Builder> asClassBasedProxy;
/*    */   private static final Consumer<TypeHint.Builder> asProxiedUserClass;
/*    */   
/*    */   static {
/* 44 */     asClassBasedProxy = (hint -> hint.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_DECLARED_METHODS, MemberCategory.DECLARED_FIELDS }));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     asProxiedUserClass = (hint -> hint.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS, MemberCategory.INVOKE_DECLARED_METHODS }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void registerProxyIfNecessary(Class<?> candidateClass, RuntimeHints runtimeHints) {
/* 63 */     if (Proxy.isProxyClass(candidateClass)) {
/*    */       
/* 65 */       runtimeHints.proxies().registerJdkProxy(candidateClass.getInterfaces());
/*    */     }
/*    */     else {
/*    */       
/* 69 */       Class<?> userClass = ClassUtils.getUserClass(candidateClass);
/* 70 */       if (userClass != candidateClass)
/* 71 */         runtimeHints.reflection()
/* 72 */           .registerType(candidateClass, asClassBasedProxy)
/* 73 */           .registerType(userClass, asProxiedUserClass); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\support\ClassHintUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */