/*     */ package org.springframework.aot.hint.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.aot.hint.ResourceHints;
/*     */ import org.springframework.aot.hint.ResourcePatternHints;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePatternResourceHintsRegistrar
/*     */ {
/*     */   private final List<String> classpathLocations;
/*     */   private final List<String> filePrefixes;
/*     */   private final List<String> fileExtensions;
/*     */   
/*     */   @Deprecated(since = "6.0.12", forRemoval = true)
/*     */   public FilePatternResourceHintsRegistrar(List<String> filePrefixes, List<String> classpathLocations, List<String> fileExtensions) {
/*  62 */     this.classpathLocations = validateClasspathLocations(classpathLocations);
/*  63 */     this.filePrefixes = validateFilePrefixes(filePrefixes);
/*  64 */     this.fileExtensions = validateFileExtensions(fileExtensions);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0.12", forRemoval = true)
/*     */   public void registerHints(ResourceHints hints, @Nullable ClassLoader classLoader) {
/*  70 */     ClassLoader classLoaderToUse = (classLoader != null) ? classLoader : ClassUtils.getDefaultClassLoader();
/*  71 */     if (classLoaderToUse != null) {
/*  72 */       List<String> includes = new ArrayList<>();
/*  73 */       for (String location : this.classpathLocations) {
/*  74 */         if (classLoaderToUse.getResource(location) != null) {
/*  75 */           for (String filePrefix : this.filePrefixes) {
/*  76 */             for (String fileExtension : this.fileExtensions) {
/*  77 */               includes.add(location + location + "*" + filePrefix);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*  82 */       if (!includes.isEmpty()) {
/*  83 */         hints.registerPattern(hint -> hint.includes((String[])includes.toArray(())));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forClassPathLocations(String... classpathLocations) {
/*  98 */     return forClassPathLocations(Arrays.asList(classpathLocations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forClassPathLocations(List<String> classpathLocations) {
/* 110 */     return (new Builder()).withClasspathLocations(classpathLocations);
/*     */   }
/*     */   
/*     */   private static List<String> validateClasspathLocations(List<String> classpathLocations) {
/* 114 */     Assert.notEmpty(classpathLocations, "At least one classpath location must be specified");
/* 115 */     List<String> parsedLocations = new ArrayList<>();
/* 116 */     for (String location : classpathLocations) {
/* 117 */       if (location.startsWith("classpath:")) {
/* 118 */         location = location.substring("classpath:".length());
/*     */       }
/* 120 */       if (location.startsWith("/")) {
/* 121 */         location = location.substring(1);
/*     */       }
/* 123 */       if (!location.isEmpty() && !location.endsWith("/")) {
/* 124 */         location = location + "/";
/*     */       }
/* 126 */       parsedLocations.add(location);
/*     */     } 
/* 128 */     return parsedLocations;
/*     */   }
/*     */   
/*     */   private static List<String> validateFilePrefixes(List<String> filePrefixes) {
/* 132 */     for (String filePrefix : filePrefixes) {
/* 133 */       if (filePrefix.contains("*")) {
/* 134 */         throw new IllegalArgumentException("File prefix '" + filePrefix + "' cannot contain '*'");
/*     */       }
/*     */     } 
/* 137 */     return filePrefixes;
/*     */   }
/*     */   
/*     */   private static List<String> validateFileExtensions(List<String> fileExtensions) {
/* 141 */     for (String fileExtension : fileExtensions) {
/* 142 */       if (!fileExtension.startsWith(".")) {
/* 143 */         throw new IllegalArgumentException("Extension '" + fileExtension + "' must start with '.'");
/*     */       }
/*     */     } 
/* 146 */     return fileExtensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/* 156 */     private final List<String> classpathLocations = new ArrayList<>();
/*     */     
/* 158 */     private final List<String> filePrefixes = new ArrayList<>();
/*     */     
/* 160 */     private final List<String> fileExtensions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withClasspathLocations(String... classpathLocations) {
/* 176 */       return withClasspathLocations(Arrays.asList(classpathLocations));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withClasspathLocations(List<String> classpathLocations) {
/* 189 */       this.classpathLocations.addAll(FilePatternResourceHintsRegistrar.validateClasspathLocations(classpathLocations));
/* 190 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withFilePrefixes(String... filePrefixes) {
/* 202 */       return withFilePrefixes(Arrays.asList(filePrefixes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withFilePrefixes(List<String> filePrefixes) {
/* 214 */       this.filePrefixes.addAll(FilePatternResourceHintsRegistrar.validateFilePrefixes(filePrefixes));
/* 215 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withFileExtensions(String... fileExtensions) {
/* 226 */       return withFileExtensions(Arrays.asList(fileExtensions));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withFileExtensions(List<String> fileExtensions) {
/* 237 */       this.fileExtensions.addAll(FilePatternResourceHintsRegistrar.validateFileExtensions(fileExtensions));
/* 238 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     private FilePatternResourceHintsRegistrar build() {
/* 243 */       return new FilePatternResourceHintsRegistrar(this.filePrefixes, this.classpathLocations, this.fileExtensions);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void registerHints(ResourceHints hints, @Nullable ClassLoader classLoader) {
/* 255 */       build().registerHints(hints, classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\support\FilePatternResourceHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */