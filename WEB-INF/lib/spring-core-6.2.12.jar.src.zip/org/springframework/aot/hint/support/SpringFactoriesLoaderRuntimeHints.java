/*     */ package org.springframework.aot.hint.support;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringFactoriesLoaderRuntimeHints
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*  44 */   private static final List<String> RESOURCE_LOCATIONS = List.of("META-INF/spring.factories");
/*     */   
/*  46 */   private static final Log logger = LogFactory.getLog(SpringFactoriesLoaderRuntimeHints.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/*  51 */     ClassLoader classLoaderToUse = (classLoader != null) ? classLoader : ClassUtils.getDefaultClassLoader();
/*  52 */     if (classLoaderToUse != null) {
/*  53 */       for (String resourceLocation : RESOURCE_LOCATIONS) {
/*  54 */         registerHints(hints, classLoaderToUse, resourceLocation);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerHints(RuntimeHints hints, ClassLoader classLoader, String resourceLocation) {
/*  60 */     hints.resources().registerPattern(resourceLocation);
/*     */     
/*  62 */     Map<String, List<String>> factories = ExtendedSpringFactoriesLoader.accessLoadFactoriesResource(classLoader, resourceLocation);
/*  63 */     factories.forEach((factoryClassName, implementationClassNames) -> registerHints(hints, classLoader, factoryClassName, implementationClassNames));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerHints(RuntimeHints hints, ClassLoader classLoader, String factoryClassName, List<String> implementationClassNames) {
/*  70 */     Class<?> factoryClass = resolveClassName(classLoader, factoryClassName);
/*  71 */     if (factoryClass == null) {
/*  72 */       if (logger.isTraceEnabled()) {
/*  73 */         logger.trace(LogMessage.format("Skipping factories for [%s]", factoryClassName));
/*     */       }
/*     */       return;
/*     */     } 
/*  77 */     if (logger.isTraceEnabled()) {
/*  78 */       logger.trace(LogMessage.format("Processing factories for [%s]", factoryClassName));
/*     */     }
/*  80 */     hints.reflection().registerType(factoryClass, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*  81 */     for (String implementationClassName : implementationClassNames) {
/*  82 */       Class<?> implementationType = resolveClassName(classLoader, implementationClassName);
/*  83 */       if (logger.isTraceEnabled()) {
/*  84 */         logger.trace(LogMessage.format("%s factory type [%s] and implementation [%s]", 
/*  85 */               (implementationType != null) ? "Processing" : "Skipping", factoryClassName, implementationClassName));
/*     */       }
/*     */       
/*  88 */       if (implementationType != null) {
/*  89 */         hints.reflection().registerType(implementationType, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Class<?> resolveClassName(ClassLoader classLoader, String factoryClassName) {
/*     */     try {
/*  97 */       Class<?> clazz = ClassUtils.resolveClassName(factoryClassName, classLoader);
/*     */       
/*  99 */       clazz.getDeclaredConstructors();
/* 100 */       return clazz;
/*     */     }
/* 102 */     catch (Throwable ex) {
/* 103 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class ExtendedSpringFactoriesLoader
/*     */     extends SpringFactoriesLoader
/*     */   {
/*     */     ExtendedSpringFactoriesLoader(@Nullable ClassLoader classLoader, Map<String, List<String>> factories) {
/* 111 */       super(classLoader, factories);
/*     */     }
/*     */     
/*     */     static Map<String, List<String>> accessLoadFactoriesResource(ClassLoader classLoader, String resourceLocation) {
/* 115 */       return SpringFactoriesLoader.loadFactoriesResource(classLoader, resourceLocation);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\support\SpringFactoriesLoaderRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */