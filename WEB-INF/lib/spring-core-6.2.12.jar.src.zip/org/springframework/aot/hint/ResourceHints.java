/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHints
/*     */ {
/*  49 */   private final Set<TypeReference> types = new HashSet<>();
/*  50 */   private final List<ResourcePatternHints> resourcePatternHints = new ArrayList<>();
/*  51 */   private final Set<ResourceBundleHint> resourceBundleHints = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<ResourcePatternHints> resourcePatternHints() {
/*  60 */     Stream<ResourcePatternHints> patterns = this.resourcePatternHints.stream();
/*  61 */     return this.types.isEmpty() ? patterns : Stream.<ResourcePatternHints>concat(Stream.of(typesPatternResourceHint()), patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<ResourceBundleHint> resourceBundleHints() {
/*  69 */     return this.resourceBundleHints.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerPatternIfPresent(@Nullable ClassLoader classLoader, String location, Consumer<ResourcePatternHints.Builder> resourceHint) {
/*  84 */     ClassLoader classLoaderToUse = (classLoader != null) ? classLoader : ClassUtils.getDefaultClassLoader();
/*  85 */     if (classLoaderToUse != null && classLoaderToUse.getResource(location) != null) {
/*  86 */       registerPattern(resourceHint);
/*     */     }
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerPattern(@Nullable Consumer<ResourcePatternHints.Builder> resourceHint) {
/*  98 */     ResourcePatternHints.Builder builder = new ResourcePatternHints.Builder();
/*  99 */     if (resourceHint != null) {
/* 100 */       resourceHint.accept(builder);
/*     */     }
/* 102 */     this.resourcePatternHints.add(builder.build());
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerPattern(String include) {
/* 113 */     return registerPattern(builder -> builder.includes(new String[] { include }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerResource(Resource resource) {
/* 125 */     if (resource instanceof ClassPathResource) { ClassPathResource classPathResource = (ClassPathResource)resource; if (classPathResource.exists())
/* 126 */       { registerPattern(classPathResource.getPath()); }
/*     */       else
/*     */       
/* 129 */       { throw new IllegalArgumentException("Resource must be a ClassPathResource that exists: " + String.valueOf(resource)); }  } else { throw new IllegalArgumentException("Resource must be a ClassPathResource that exists: " + String.valueOf(resource)); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerType(TypeReference type) {
/* 140 */     this.types.add(type);
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerType(Class<?> type) {
/* 151 */     return registerType(TypeReference.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerResourceBundle(String baseName, @Nullable Consumer<ResourceBundleHint.Builder> resourceHint) {
/* 162 */     ResourceBundleHint.Builder builder = new ResourceBundleHint.Builder(baseName);
/* 163 */     if (resourceHint != null) {
/* 164 */       resourceHint.accept(builder);
/*     */     }
/* 166 */     this.resourceBundleHints.add(builder.build());
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHints registerResourceBundle(String baseName) {
/* 177 */     return registerResourceBundle(baseName, null);
/*     */   }
/*     */   
/*     */   private ResourcePatternHints typesPatternResourceHint() {
/* 181 */     ResourcePatternHints.Builder builder = new ResourcePatternHints.Builder();
/* 182 */     this.types.forEach(type -> builder.includes(new String[] { toIncludePattern(type) }));
/* 183 */     return builder.build();
/*     */   }
/*     */   
/*     */   private String toIncludePattern(TypeReference type) {
/* 187 */     return type.getName().replace(".", "/") + ".class";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ResourceHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */