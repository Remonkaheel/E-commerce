/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ConditionalHint
/*    */ {
/*    */   @Nullable
/*    */   TypeReference getReachableType();
/*    */   
/*    */   default boolean conditionMatches(ClassLoader classLoader) {
/* 49 */     TypeReference reachableType = getReachableType();
/* 50 */     if (reachableType != null) {
/* 51 */       return ClassUtils.isPresent(reachableType.getCanonicalName(), classLoader);
/*    */     }
/* 53 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ConditionalHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */