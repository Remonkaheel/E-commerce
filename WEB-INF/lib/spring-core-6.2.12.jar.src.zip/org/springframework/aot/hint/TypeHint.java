/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeHint
/*     */   implements ConditionalHint
/*     */ {
/*     */   private final TypeReference type;
/*     */   @Nullable
/*     */   private final TypeReference reachableType;
/*     */   private final Set<FieldHint> fields;
/*     */   private final Set<ExecutableHint> constructors;
/*     */   private final Set<ExecutableHint> methods;
/*     */   private final Set<MemberCategory> memberCategories;
/*     */   
/*     */   private TypeHint(Builder builder) {
/*  58 */     this.type = builder.type;
/*  59 */     this.reachableType = builder.reachableType;
/*  60 */     this.memberCategories = Set.copyOf(builder.memberCategories);
/*  61 */     this.fields = (Set<FieldHint>)builder.fields.stream().map(FieldHint::new).collect(Collectors.toSet());
/*  62 */     this.constructors = (Set<ExecutableHint>)builder.constructors.values().stream().map(ExecutableHint.Builder::build).collect(Collectors.toSet());
/*  63 */     this.methods = (Set<ExecutableHint>)builder.methods.values().stream().map(ExecutableHint.Builder::build).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder of(TypeReference type) {
/*  73 */     Assert.notNull(type, "'type' must not be null");
/*  74 */     return new Builder(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeReference getType() {
/*  83 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeReference getReachableType() {
/*  89 */     return this.reachableType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<FieldHint> fields() {
/*  97 */     return this.fields.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<ExecutableHint> constructors() {
/* 105 */     return this.constructors.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<ExecutableHint> methods() {
/* 113 */     return this.methods.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MemberCategory> getMemberCategories() {
/* 121 */     return this.memberCategories;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return TypeHint.class.getSimpleName() + "[type=" + TypeHint.class.getSimpleName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Consumer<Builder> builtWith(MemberCategory... memberCategories) {
/* 136 */     return builder -> builder.withMembers(memberCategories);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private final TypeReference type;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private TypeReference reachableType;
/*     */ 
/*     */     
/* 150 */     private final Set<String> fields = new HashSet<>();
/*     */     
/* 152 */     private final Map<TypeHint.ExecutableKey, ExecutableHint.Builder> constructors = new HashMap<>();
/*     */     
/* 154 */     private final Map<TypeHint.ExecutableKey, ExecutableHint.Builder> methods = new HashMap<>();
/*     */     
/* 156 */     private final Set<MemberCategory> memberCategories = new HashSet<>();
/*     */     
/*     */     Builder(TypeReference type) {
/* 159 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder onReachableType(TypeReference reachableType) {
/* 169 */       this.reachableType = reachableType;
/* 170 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder onReachableType(Class<?> reachableType) {
/* 180 */       this.reachableType = TypeReference.of(reachableType);
/* 181 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withField(String name) {
/* 192 */       this.fields.add(name);
/* 193 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withConstructor(List<TypeReference> parameterTypes, ExecutableMode mode) {
/* 204 */       return withConstructor(parameterTypes, ExecutableHint.builtWith(mode));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder withConstructor(List<TypeReference> parameterTypes, Consumer<ExecutableHint.Builder> constructorHint) {
/* 218 */       TypeHint.ExecutableKey key = new TypeHint.ExecutableKey("<init>", parameterTypes);
/* 219 */       ExecutableHint.Builder builder = this.constructors.computeIfAbsent(key, k -> ExecutableHint.ofConstructor(parameterTypes));
/*     */       
/* 221 */       constructorHint.accept(builder);
/* 222 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withMethod(String name, List<TypeReference> parameterTypes, ExecutableMode mode) {
/* 234 */       return withMethod(name, parameterTypes, ExecutableHint.builtWith(mode));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder withMethod(String name, List<TypeReference> parameterTypes, Consumer<ExecutableHint.Builder> methodHint) {
/* 247 */       TypeHint.ExecutableKey key = new TypeHint.ExecutableKey(name, parameterTypes);
/* 248 */       ExecutableHint.Builder builder = this.methods.computeIfAbsent(key, k -> ExecutableHint.ofMethod(name, parameterTypes));
/*     */       
/* 250 */       methodHint.accept(builder);
/* 251 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withMembers(MemberCategory... memberCategories) {
/* 261 */       this.memberCategories.addAll(Arrays.asList(memberCategories));
/* 262 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TypeHint build() {
/* 270 */       return new TypeHint(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ExecutableKey
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final List<String> parameterTypes;
/*     */     
/*     */     private ExecutableKey(String name, List<TypeReference> parameterTypes) {
/* 282 */       this.name = name;
/* 283 */       this.parameterTypes = parameterTypes.stream().map(TypeReference::getCanonicalName).toList();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 288 */       if (this != other) { if (other instanceof ExecutableKey) { ExecutableKey that = (ExecutableKey)other; if (this.name
/* 289 */             .equals(that.name) && this.parameterTypes.equals(that.parameterTypes)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 294 */       return Objects.hash(new Object[] { this.name, this.parameterTypes });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\TypeHint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */