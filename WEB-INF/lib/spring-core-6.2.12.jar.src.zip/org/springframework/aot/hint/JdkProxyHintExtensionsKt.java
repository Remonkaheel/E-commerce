/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.JvmClassMappingKt;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import kotlin.reflect.KClass;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\024\n\000\n\002\030\002\n\000\n\002\020\021\n\002\030\002\n\002\b\002\0323\020\000\032\n \002*\004\030\0010\0010\001*\0020\0012\032\020\000\032\016\022\n\b\001\022\006\022\002\b\0030\0040\003\"\006\022\002\b\0030\004¢\006\002\020\005¨\006\006"}, d2 = {"proxiedInterfaces", "Lorg/springframework/aot/hint/JdkProxyHint$Builder;", "kotlin.jvm.PlatformType", "", "Lkotlin/reflect/KClass;", "(Lorg/springframework/aot/hint/JdkProxyHint$Builder;[Lkotlin/reflect/KClass;)Lorg/springframework/aot/hint/JdkProxyHint$Builder;", "spring-core"})
/*    */ @SourceDebugExtension({"SMAP\nJdkProxyHintExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JdkProxyHintExtensions.kt\norg/springframework/aot/hint/JdkProxyHintExtensionsKt\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,29:1\n11065#2:30\n11400#2,3:31\n37#3,2:34\n*S KotlinDebug\n*F\n+ 1 JdkProxyHintExtensions.kt\norg/springframework/aot/hint/JdkProxyHintExtensionsKt\n*L\n28#1:30\n28#1:31,3\n28#1:34,2\n*E\n"})
/*    */ public final class JdkProxyHintExtensionsKt
/*    */ {
/*    */   public static final JdkProxyHint.Builder proxiedInterfaces(@NotNull JdkProxyHint.Builder $this$proxiedInterfaces, @NotNull KClass... proxiedInterfaces) {
/* 28 */     Intrinsics.checkNotNullParameter($this$proxiedInterfaces, "<this>"); Intrinsics.checkNotNullParameter(proxiedInterfaces, "proxiedInterfaces"); KClass[] arrayOfKClass1 = proxiedInterfaces; JdkProxyHint.Builder builder = $this$proxiedInterfaces; int $i$f$map = 0;
/*    */     
/* 30 */     KClass[] arrayOfKClass2 = arrayOfKClass1; Collection<Class<?>> destination$iv$iv = new ArrayList(arrayOfKClass1.length); int $i$f$mapTo = 0; byte b; int i;
/* 31 */     for (b = 0, i = arrayOfKClass2.length; b < i; ) { Object item$iv$iv = arrayOfKClass2[b];
/* 32 */       Object object1 = item$iv$iv; Collection<Class<?>> collection = destination$iv$iv; int $i$a$-map-JdkProxyHintExtensionsKt$proxiedInterfaces$1 = 0; collection.add(JvmClassMappingKt.getJavaClass((KClass)object1)); }
/* 33 */      List list = (List)destination$iv$iv; int $i$f$toTypedArray = 0;
/* 34 */     Collection thisCollection$iv = list;
/* 35 */     Class[] arrayOfClass = (Class[])thisCollection$iv.toArray((Object[])new Class[0]);
/*    */     return builder.proxiedInterfaces((Class[])Arrays.<Class<?>[]>copyOf((Class<?>[][])arrayOfClass, arrayOfClass.length));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\JdkProxyHintExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */