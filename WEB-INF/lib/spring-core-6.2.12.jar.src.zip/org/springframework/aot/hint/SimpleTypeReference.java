/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SimpleTypeReference
/*     */   extends AbstractTypeReference
/*     */ {
/*  34 */   private static final List<String> PRIMITIVE_NAMES = List.of("boolean", "byte", "short", "int", "long", "char", "float", "double", "void");
/*     */   
/*     */   @Nullable
/*     */   private String canonicalName;
/*     */ 
/*     */   
/*     */   SimpleTypeReference(String packageName, String simpleName, @Nullable TypeReference enclosingType) {
/*  41 */     super(packageName, simpleName, enclosingType);
/*     */   }
/*     */   
/*     */   static SimpleTypeReference of(String className) {
/*  45 */     Assert.notNull(className, "'className' must not be null");
/*  46 */     if (!isValidClassName(className)) {
/*  47 */       throw new IllegalStateException("Invalid class name '" + className + "'");
/*     */     }
/*  49 */     if (!className.contains("$")) {
/*  50 */       return createTypeReference(className);
/*     */     }
/*  52 */     String[] elements = className.split("(?<!\\$)\\$(?!\\$)");
/*  53 */     SimpleTypeReference typeReference = createTypeReference(elements[0]);
/*  54 */     for (int i = 1; i < elements.length; i++) {
/*  55 */       typeReference = new SimpleTypeReference(typeReference.getPackageName(), elements[i], typeReference);
/*     */     }
/*  57 */     return typeReference;
/*     */   }
/*     */   
/*     */   private static boolean isValidClassName(String className) {
/*  61 */     for (String s : className.split("\\.", -1)) {
/*  62 */       String candidate = s.replace("[", "").replace("]", "");
/*  63 */       if (!SourceVersion.isIdentifier(candidate)) {
/*  64 */         return false;
/*     */       }
/*     */     } 
/*  67 */     return true;
/*     */   }
/*     */   
/*     */   private static SimpleTypeReference createTypeReference(String className) {
/*  71 */     int i = className.lastIndexOf('.');
/*  72 */     if (i != -1) {
/*  73 */       return new SimpleTypeReference(className.substring(0, i), className.substring(i + 1), null);
/*     */     }
/*     */     
/*  76 */     String packageName = isPrimitive(className) ? "java.lang" : "";
/*  77 */     return new SimpleTypeReference(packageName, className, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCanonicalName() {
/*  83 */     if (this.canonicalName == null) {
/*  84 */       StringBuilder names = new StringBuilder();
/*  85 */       buildName(this, names);
/*  86 */       this.canonicalName = addPackageIfNecessary(names.toString());
/*     */     } 
/*  88 */     return this.canonicalName;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isPrimitive() {
/*  93 */     return isPrimitive(getSimpleName());
/*     */   }
/*     */   
/*     */   private static boolean isPrimitive(String name) {
/*  97 */     Objects.requireNonNull(name); return PRIMITIVE_NAMES.stream().anyMatch(name::startsWith);
/*     */   }
/*     */   
/*     */   private static void buildName(@Nullable TypeReference type, StringBuilder sb) {
/* 101 */     if (type == null) {
/*     */       return;
/*     */     }
/* 104 */     String typeName = (type.getEnclosingType() != null) ? ("." + type.getSimpleName()) : type.getSimpleName();
/* 105 */     sb.insert(0, typeName);
/* 106 */     buildName(type.getEnclosingType(), sb);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\SimpleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */