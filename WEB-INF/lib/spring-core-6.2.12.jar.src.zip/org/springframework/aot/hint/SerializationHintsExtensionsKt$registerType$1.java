/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 176, d1 = {"\000\024\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\0032\006\020\004\032\0020\005H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "T", "Ljava/io/Serializable;", "it", "Lorg/springframework/aot/hint/JavaSerializationHint$Builder;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nSerializationHintsExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SerializationHintsExtensions.kt\norg/springframework/aot/hint/SerializationHintsExtensionsKt$registerType$1\n*L\n1#1,30:1\n*E\n"})
/*    */ public final class SerializationHintsExtensionsKt$registerType$1
/*    */   extends Lambda
/*    */   implements Function1<JavaSerializationHint.Builder, Unit>
/*    */ {
/*    */   public static final SerializationHintsExtensionsKt$registerType$1 INSTANCE = new SerializationHintsExtensionsKt$registerType$1();
/*    */   
/*    */   public SerializationHintsExtensionsKt$registerType$1() {
/*    */     super(1);
/*    */   }
/*    */   
/*    */   public final void invoke(@NotNull JavaSerializationHint.Builder it) {
/* 28 */     Intrinsics.checkNotNullParameter(it, "it");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\SerializationHintsExtensionsKt$registerType$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */