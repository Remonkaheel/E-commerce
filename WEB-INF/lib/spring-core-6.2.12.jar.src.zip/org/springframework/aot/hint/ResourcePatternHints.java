/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourcePatternHints
/*     */ {
/*     */   private final List<ResourcePatternHint> includes;
/*     */   private final List<ResourcePatternHint> excludes;
/*     */   
/*     */   private ResourcePatternHints(Builder builder) {
/*  45 */     this.includes = new ArrayList<>(builder.includes);
/*  46 */     this.excludes = new ArrayList<>(builder.excludes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResourcePatternHint> getIncludes() {
/*  54 */     return this.includes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResourcePatternHint> getExcludes() {
/*  62 */     return this.excludes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*  71 */     private final Set<ResourcePatternHint> includes = new LinkedHashSet<>();
/*     */     
/*  73 */     private final Set<ResourcePatternHint> excludes = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder includes(@Nullable TypeReference reachableType, String... includes) {
/*  89 */       Objects.requireNonNull(this.includes); Arrays.<String>stream(includes).map(this::expandToIncludeDirectories).flatMap(Collection::stream).map(include -> new ResourcePatternHint(include, reachableType)).forEach(this.includes::add);
/*  90 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<String> expandToIncludeDirectories(String includePattern) {
/* 102 */       if (!includePattern.contains("/"))
/*     */       {
/* 104 */         return List.of("/", includePattern);
/*     */       }
/*     */       
/* 107 */       List<String> includePatterns = new ArrayList<>();
/*     */       
/* 109 */       includePatterns.add("/");
/* 110 */       includePatterns.add(includePattern);
/* 111 */       StringBuilder path = new StringBuilder();
/* 112 */       for (String pathElement : includePattern.split("/")) {
/* 113 */         if (!pathElement.isEmpty()) {
/*     */ 
/*     */ 
/*     */           
/* 117 */           if (pathElement.contains("*")) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 122 */           if (!path.isEmpty()) {
/* 123 */             path.append("/");
/*     */           }
/* 125 */           path.append(pathElement);
/* 126 */           includePatterns.add(path.toString());
/*     */         } 
/* 128 */       }  return includePatterns;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder includes(String... includes) {
/* 137 */       return includes(null, includes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder excludes(@Nullable TypeReference reachableType, String... excludes) {
/* 148 */       List<ResourcePatternHint> newExcludes = Arrays.<String>stream(excludes).map(include -> new ResourcePatternHint(include, reachableType)).toList();
/* 149 */       this.excludes.addAll(newExcludes);
/* 150 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder excludes(String... excludes) {
/* 159 */       return excludes(null, excludes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ResourcePatternHints build() {
/* 168 */       return new ResourcePatternHints(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ResourcePatternHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */