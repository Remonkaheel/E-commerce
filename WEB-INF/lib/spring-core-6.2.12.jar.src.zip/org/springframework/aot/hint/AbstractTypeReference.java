/*     */ package org.springframework.aot.hint;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTypeReference
/*     */   implements TypeReference
/*     */ {
/*     */   private final String packageName;
/*     */   private final String simpleName;
/*     */   @Nullable
/*     */   private final TypeReference enclosingType;
/*     */   
/*     */   protected AbstractTypeReference(String packageName, String simpleName, @Nullable TypeReference enclosingType) {
/*  42 */     this.packageName = packageName;
/*  43 */     this.simpleName = simpleName;
/*  44 */     this.enclosingType = enclosingType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  50 */     TypeReference enclosingType = getEnclosingType();
/*  51 */     String simpleName = getSimpleName();
/*  52 */     return (enclosingType != null) ? (enclosingType.getName() + "$" + enclosingType.getName()) : 
/*  53 */       addPackageIfNecessary(simpleName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPackageName() {
/*  58 */     return this.packageName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSimpleName() {
/*  63 */     return this.simpleName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeReference getEnclosingType() {
/*  69 */     return this.enclosingType;
/*     */   }
/*     */   
/*     */   protected String addPackageIfNecessary(String part) {
/*  73 */     if (this.packageName.isEmpty() || (this.packageName
/*  74 */       .equals("java.lang") && isPrimitive())) {
/*  75 */       return part;
/*     */     }
/*  77 */     return this.packageName + "." + this.packageName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(TypeReference other) {
/*  84 */     return getCanonicalName().compareToIgnoreCase(other.getCanonicalName());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  89 */     if (this != other) { if (other instanceof TypeReference) { TypeReference that = (TypeReference)other;
/*  90 */         if (getCanonicalName().equals(that.getCanonicalName())); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  95 */     return Objects.hash(new Object[] { getCanonicalName() });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return getCanonicalName();
/*     */   }
/*     */   
/*     */   protected abstract boolean isPrimitive();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\AbstractTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */