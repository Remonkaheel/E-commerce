/*    */ package org.springframework.aot.hint;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.function.Consumer;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000*\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\020\021\n\002\030\002\n\002\b\002\032\027\020\000\032\004\030\0010\001\"\006\b\000\020\002\030\001*\0020\003H\b\0326\020\004\032\n \005*\004\030\0010\0030\003\"\006\b\000\020\002\030\001*\0020\0032\024\b\b\020\006\032\016\022\004\022\0020\b\022\004\022\0020\t0\007H\bø\001\000\0326\020\004\032\n \005*\004\030\0010\0030\003\"\006\b\000\020\002\030\001*\0020\0032\022\020\n\032\n\022\006\b\001\022\0020\f0\013\"\0020\fH\b¢\006\002\020\r\002\007\n\005\b20\001¨\006\016"}, d2 = {"getTypeHint", "Lorg/springframework/aot/hint/TypeHint;", "T", "Lorg/springframework/aot/hint/ReflectionHints;", "registerType", "kotlin.jvm.PlatformType", "typeHint", "Lkotlin/Function1;", "Lorg/springframework/aot/hint/TypeHint$Builder;", "", "memberCategories", "", "Lorg/springframework/aot/hint/MemberCategory;", "(Lorg/springframework/aot/hint/ReflectionHints;[Lorg/springframework/aot/hint/MemberCategory;)Lorg/springframework/aot/hint/ReflectionHints;", "spring-core"})
/*    */ public final class ReflectionHintsExtensionsKt {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\hint\ReflectionHintsExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */