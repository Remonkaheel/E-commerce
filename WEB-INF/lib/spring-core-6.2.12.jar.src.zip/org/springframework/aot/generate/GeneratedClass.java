/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.JavaFile;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GeneratedClass
/*     */ {
/*     */   @Nullable
/*     */   private final GeneratedClass enclosingClass;
/*     */   private final ClassName name;
/*     */   private final GeneratedMethods methods;
/*     */   private final Consumer<TypeSpec.Builder> type;
/*     */   private final Map<ClassName, GeneratedClass> declaredClasses;
/*     */   private final Map<MethodName, AtomicInteger> methodNameSequenceGenerator;
/*     */   
/*     */   GeneratedClass(ClassName name, Consumer<TypeSpec.Builder> type) {
/*  62 */     this(null, name, type);
/*     */   }
/*     */ 
/*     */   
/*     */   private GeneratedClass(@Nullable GeneratedClass enclosingClass, ClassName name, Consumer<TypeSpec.Builder> type) {
/*  67 */     this.enclosingClass = enclosingClass;
/*  68 */     this.name = name;
/*  69 */     this.type = type;
/*  70 */     this.methods = new GeneratedMethods(name, this::generateSequencedMethodName);
/*  71 */     this.declaredClasses = new ConcurrentHashMap<>();
/*  72 */     this.methodNameSequenceGenerator = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reserveMethodNames(String... reservedMethodNames) {
/*  83 */     for (String reservedMethodName : reservedMethodNames) {
/*  84 */       String generatedName = generateSequencedMethodName(MethodName.of(reservedMethodNames));
/*  85 */       Assert.state(generatedName.equals(reservedMethodName), () -> String.format("Unable to reserve method name '%s'", new Object[] { reservedMethodName }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String generateSequencedMethodName(MethodName name) {
/*  92 */     int sequence = ((AtomicInteger)this.methodNameSequenceGenerator.computeIfAbsent(name, key -> new AtomicInteger())).getAndIncrement();
/*  93 */     return (sequence > 0) ? (name.toString() + name.toString()) : name.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public GeneratedClass getEnclosingClass() {
/* 103 */     return this.enclosingClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassName getName() {
/* 111 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedMethods getMethods() {
/* 119 */     return this.methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass getOrAdd(String name, Consumer<TypeSpec.Builder> type) {
/* 131 */     ClassName className = this.name.nestedClass(name);
/* 132 */     return this.declaredClasses.computeIfAbsent(className, key -> new GeneratedClass(this, className, type));
/*     */   }
/*     */ 
/*     */   
/*     */   JavaFile generateJavaFile() {
/* 137 */     Assert.state((getEnclosingClass() == null), "Java file cannot be generated for an inner class");
/*     */     
/* 139 */     TypeSpec.Builder type = apply();
/* 140 */     return JavaFile.builder(this.name.packageName(), type.build()).build();
/*     */   }
/*     */   
/*     */   private TypeSpec.Builder apply() {
/* 144 */     TypeSpec.Builder type = getBuilder(this.type);
/* 145 */     type.addAnnotation(Generated.class);
/* 146 */     Objects.requireNonNull(type); this.methods.doWithMethodSpecs(type::addMethod);
/* 147 */     this.declaredClasses.values().forEach(declaredClass -> type.addType(declaredClass.apply().build()));
/*     */     
/* 149 */     return type;
/*     */   }
/*     */   
/*     */   private TypeSpec.Builder getBuilder(Consumer<TypeSpec.Builder> type) {
/* 153 */     TypeSpec.Builder builder = TypeSpec.classBuilder(this.name);
/* 154 */     type.accept(builder);
/* 155 */     return builder;
/*     */   }
/*     */   
/*     */   void assertSameType(Consumer<TypeSpec.Builder> type) {
/* 159 */     Assert.state((type == this.type || getBuilder(this.type).build().equals(getBuilder(type).build())), "'type' consumer generated different result");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GeneratedClass.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */