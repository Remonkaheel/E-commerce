/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.TypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MethodReference
/*     */ {
/*     */   CodeBlock toCodeBlock();
/*     */   
/*     */   default CodeBlock toInvokeCodeBlock(ArgumentCodeGenerator argumentCodeGenerator) {
/*  50 */     return toInvokeCodeBlock(argumentCodeGenerator, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CodeBlock toInvokeCodeBlock(ArgumentCodeGenerator paramArgumentCodeGenerator, @Nullable ClassName paramClassName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface ArgumentCodeGenerator
/*     */   {
/*     */     static ArgumentCodeGenerator none() {
/*  86 */       return from(type -> null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static ArgumentCodeGenerator of(Class<?> argumentType, String argumentCode) {
/*  97 */       return from(candidateType -> candidateType.equals(ClassName.get(argumentType)) ? CodeBlock.of(argumentCode, new Object[0]) : null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static ArgumentCodeGenerator from(Function<TypeName, CodeBlock> function) {
/* 110 */       Objects.requireNonNull(function); return function::apply;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default ArgumentCodeGenerator and(Class<?> argumentType, String argumentCode) {
/* 121 */       return and(of(argumentType, argumentCode));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default ArgumentCodeGenerator and(ArgumentCodeGenerator argumentCodeGenerator) {
/* 131 */       return from(type -> {
/*     */             CodeBlock code = generateCode(type);
/*     */             return (code != null) ? code : argumentCodeGenerator.generateCode(type);
/*     */           });
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     CodeBlock generateCode(TypeName param1TypeName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\MethodReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */