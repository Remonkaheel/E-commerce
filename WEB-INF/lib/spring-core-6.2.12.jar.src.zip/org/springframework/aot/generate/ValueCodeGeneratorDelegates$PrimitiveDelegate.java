/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrimitiveDelegate
/*     */   implements ValueCodeGenerator.Delegate
/*     */ {
/* 199 */   private static final Map<Character, String> CHAR_ESCAPES = Map.of(
/* 200 */       Character.valueOf('\b'), "\\b", 
/* 201 */       Character.valueOf('\t'), "\\t", 
/* 202 */       Character.valueOf('\n'), "\\n", 
/* 203 */       Character.valueOf('\f'), "\\f", 
/* 204 */       Character.valueOf('\r'), "\\r", 
/* 205 */       Character.valueOf('"'), "\"", 
/* 206 */       Character.valueOf('\''), "\\'", 
/* 207 */       Character.valueOf('\\'), "\\\\");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 214 */     if (value instanceof Boolean || value instanceof Integer) {
/* 215 */       return CodeBlock.of("$L", new Object[] { value });
/*     */     }
/* 217 */     if (value instanceof Byte) {
/* 218 */       return CodeBlock.of("(byte) $L", new Object[] { value });
/*     */     }
/* 220 */     if (value instanceof Short) {
/* 221 */       return CodeBlock.of("(short) $L", new Object[] { value });
/*     */     }
/* 223 */     if (value instanceof Long) {
/* 224 */       return CodeBlock.of("$LL", new Object[] { value });
/*     */     }
/* 226 */     if (value instanceof Float) {
/* 227 */       return CodeBlock.of("$LF", new Object[] { value });
/*     */     }
/* 229 */     if (value instanceof Double) {
/* 230 */       return CodeBlock.of("(double) $L", new Object[] { value });
/*     */     }
/* 232 */     if (value instanceof Character) { Character character = (Character)value;
/* 233 */       return CodeBlock.of("'$L'", new Object[] { escape(character.charValue()) }); }
/*     */     
/* 235 */     return null;
/*     */   }
/*     */   
/*     */   private String escape(char ch) {
/* 239 */     String escaped = CHAR_ESCAPES.get(Character.valueOf(ch));
/* 240 */     if (escaped != null) {
/* 241 */       return escaped;
/*     */     }
/* 243 */     return !Character.isISOControl(ch) ? Character.toString(ch) : 
/* 244 */       String.format("\\u%04x", new Object[] { Integer.valueOf(ch) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGeneratorDelegates$PrimitiveDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */