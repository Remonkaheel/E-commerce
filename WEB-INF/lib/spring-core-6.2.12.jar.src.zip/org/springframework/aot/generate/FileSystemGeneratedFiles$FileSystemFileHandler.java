/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FileSystemFileHandler
/*     */   extends GeneratedFiles.FileHandler
/*     */ {
/*     */   private final Path path;
/*     */   
/*     */   FileSystemFileHandler(Path path) {
/* 107 */     super(Files.exists(path, new java.nio.file.LinkOption[0]), () -> new FileSystemResource(path));
/* 108 */     this.path = path;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void copy(InputStreamSource content, boolean override) {
/* 113 */     if (override) {
/* 114 */       copy(content, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */     } else {
/*     */       
/* 117 */       copy(content, new CopyOption[0]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copy(InputStreamSource content, CopyOption... copyOptions) {
/*     */     try {
/* 123 */       InputStream inputStream = content.getInputStream(); 
/* 124 */       try { Files.createDirectories(this.path.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/* 125 */         Files.copy(inputStream, this.path, copyOptions);
/* 126 */         if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null)
/*     */           try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/* 128 */     } catch (IOException ex) {
/* 129 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     return this.path.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\FileSystemGeneratedFiles$FileSystemFileHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */