/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InMemoryFileHandler
/*     */   extends GeneratedFiles.FileHandler
/*     */ {
/*     */   private final Map<String, InputStreamSource> paths;
/*     */   private final String key;
/*     */   
/*     */   InMemoryFileHandler(Map<String, InputStreamSource> paths, String key) {
/*  97 */     super(paths.containsKey(key), () -> (InputStreamSource)paths.get(key));
/*  98 */     this.paths = paths;
/*  99 */     this.key = key;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void copy(InputStreamSource content, boolean override) {
/* 104 */     this.paths.put(this.key, content);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return this.key;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\InMemoryGeneratedFiles$InMemoryFileHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */