/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueCodeGenerator
/*     */ {
/*  36 */   private static final ValueCodeGenerator INSTANCE = new ValueCodeGenerator(ValueCodeGeneratorDelegates.INSTANCES, null);
/*     */ 
/*     */   
/*  39 */   private static final CodeBlock NULL_VALUE_CODE_BLOCK = CodeBlock.of("null", new Object[0]);
/*     */ 
/*     */   
/*     */   private final List<Delegate> delegates;
/*     */   
/*     */   @Nullable
/*     */   private final GeneratedMethods generatedMethods;
/*     */ 
/*     */   
/*     */   private ValueCodeGenerator(List<Delegate> delegates, @Nullable GeneratedMethods generatedMethods) {
/*  49 */     this.delegates = delegates;
/*  50 */     this.generatedMethods = generatedMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueCodeGenerator withDefaults() {
/*  60 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueCodeGenerator with(Delegate... delegates) {
/*  69 */     return with(Arrays.asList(delegates));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueCodeGenerator with(List<Delegate> delegates) {
/*  78 */     Assert.notEmpty(delegates, "Delegates must not be empty");
/*  79 */     return new ValueCodeGenerator(new ArrayList<>(delegates), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueCodeGenerator add(List<Delegate> additionalDelegates) {
/*  84 */     Assert.notEmpty(additionalDelegates, "AdditionalDelegates must not be empty");
/*  85 */     List<Delegate> allDelegates = new ArrayList<>(this.delegates);
/*  86 */     allDelegates.addAll(additionalDelegates);
/*  87 */     return new ValueCodeGenerator(allDelegates, this.generatedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueCodeGenerator scoped(GeneratedMethods generatedMethods) {
/*  99 */     return new ValueCodeGenerator(this.delegates, generatedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateCode(@Nullable Object value) {
/* 108 */     if (value == null) {
/* 109 */       return NULL_VALUE_CODE_BLOCK;
/*     */     }
/*     */     try {
/* 112 */       for (Delegate delegate : this.delegates) {
/* 113 */         CodeBlock code = delegate.generateCode(this, value);
/* 114 */         if (code != null) {
/* 115 */           return code;
/*     */         }
/*     */       } 
/* 118 */       throw new UnsupportedTypeValueCodeGenerationException(value);
/*     */     }
/* 120 */     catch (Exception ex) {
/* 121 */       throw new ValueCodeGenerationException(value, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public GeneratedMethods getGeneratedMethods() {
/* 133 */     return this.generatedMethods;
/*     */   }
/*     */   
/*     */   public static interface Delegate {
/*     */     @Nullable
/*     */     CodeBlock generateCode(ValueCodeGenerator param1ValueCodeGenerator, Object param1Object);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */