/*    */ package org.springframework.aot.generate;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.javapoet.ClassName;
/*    */ import org.springframework.javapoet.MethodSpec;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GeneratedMethod
/*    */ {
/*    */   private final ClassName className;
/*    */   private final String name;
/*    */   private final MethodSpec methodSpec;
/*    */   
/*    */   GeneratedMethod(ClassName className, String name, Consumer<MethodSpec.Builder> method) {
/* 51 */     this.className = className;
/* 52 */     this.name = name;
/* 53 */     MethodSpec.Builder builder = MethodSpec.methodBuilder(this.name);
/* 54 */     method.accept(builder);
/* 55 */     this.methodSpec = builder.build();
/* 56 */     Assert.state(this.name.equals(this.methodSpec.name), "'method' consumer must not change the generated method name");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 66 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodReference toMethodReference() {
/* 74 */     return new DefaultMethodReference(this.methodSpec, this.className);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MethodSpec getMethodSpec() {
/* 84 */     return this.methodSpec;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GeneratedMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */