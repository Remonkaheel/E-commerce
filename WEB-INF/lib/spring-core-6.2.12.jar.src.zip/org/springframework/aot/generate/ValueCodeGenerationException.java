/*    */ package org.springframework.aot.generate;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueCodeGenerationException
/*    */   extends RuntimeException
/*    */ {
/*    */   @Nullable
/*    */   private final Object value;
/*    */   
/*    */   protected ValueCodeGenerationException(String message, @Nullable Object value, @Nullable Throwable cause) {
/* 35 */     super(message, cause);
/* 36 */     this.value = value;
/*    */   }
/*    */   
/*    */   public ValueCodeGenerationException(@Nullable Object value, Throwable cause) {
/* 40 */     super(buildErrorMessage(value), cause);
/* 41 */     this.value = value;
/*    */   }
/*    */   
/*    */   private static String buildErrorMessage(@Nullable Object value) {
/* 45 */     StringBuilder message = new StringBuilder("Failed to generate code for '");
/* 46 */     message.append(value).append("'");
/* 47 */     if (value != null) {
/* 48 */       message.append(" with type ").append(value.getClass());
/*    */     }
/* 50 */     return message.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getValue() {
/* 59 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGenerationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */