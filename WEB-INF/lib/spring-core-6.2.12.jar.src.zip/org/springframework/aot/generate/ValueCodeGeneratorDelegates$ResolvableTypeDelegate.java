/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResolvableTypeDelegate
/*     */   implements ValueCodeGenerator.Delegate
/*     */ {
/*     */   @Nullable
/*     */   public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 322 */     if (value instanceof ResolvableType) { ResolvableType resolvableType = (ResolvableType)value;
/* 323 */       return generateCode(resolvableType, false); }
/*     */     
/* 325 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static CodeBlock generateCode(ResolvableType resolvableType, boolean allowClassResult) {
/* 330 */     if (ResolvableType.NONE.equals(resolvableType)) {
/* 331 */       return CodeBlock.of("$T.NONE", new Object[] { ResolvableType.class });
/*     */     }
/* 333 */     Class<?> type = ClassUtils.getUserClass(resolvableType.toClass());
/* 334 */     if (resolvableType.hasGenerics() && resolvableType.hasResolvableGenerics()) {
/* 335 */       return generateCodeWithGenerics(resolvableType, type);
/*     */     }
/* 337 */     if (allowClassResult) {
/* 338 */       return CodeBlock.of("$T.class", new Object[] { type });
/*     */     }
/* 340 */     return CodeBlock.of("$T.forClass($T.class)", new Object[] { ResolvableType.class, type });
/*     */   }
/*     */   
/*     */   private static CodeBlock generateCodeWithGenerics(ResolvableType target, Class<?> type) {
/* 344 */     ResolvableType[] generics = target.getGenerics();
/* 345 */     boolean hasNoNestedGenerics = Arrays.<ResolvableType>stream(generics).noneMatch(ResolvableType::hasGenerics);
/* 346 */     CodeBlock.Builder code = CodeBlock.builder();
/* 347 */     code.add("$T.forClassWithGenerics($T.class", new Object[] { ResolvableType.class, type });
/* 348 */     for (ResolvableType generic : generics) {
/* 349 */       code.add(", $L", new Object[] { generateCode(generic, hasNoNestedGenerics) });
/*     */     } 
/* 351 */     code.add(")", new Object[0]);
/* 352 */     return code.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGeneratorDelegates$ResolvableTypeDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */