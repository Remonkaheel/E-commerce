/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.javapoet.JavaFile;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.function.ThrowingConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface GeneratedFiles
/*     */ {
/*     */   default void addSourceFile(JavaFile javaFile) {
/*  50 */     validatePackage(javaFile.packageName, javaFile.typeSpec.name);
/*  51 */     String className = javaFile.packageName + "." + javaFile.packageName;
/*  52 */     Objects.requireNonNull(javaFile); addSourceFile(className, javaFile::writeTo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addSourceFile(String className, CharSequence content) {
/*  63 */     addSourceFile(className, appendable -> appendable.append(content));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addSourceFile(String className, ThrowingConsumer<Appendable> content) {
/*  75 */     addFile(Kind.SOURCE, getClassNamePath(className), content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addSourceFile(String className, InputStreamSource content) {
/*  87 */     addFile(Kind.SOURCE, getClassNamePath(className), content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addResourceFile(String path, CharSequence content) {
/*  97 */     addResourceFile(path, appendable -> appendable.append(content));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addResourceFile(String path, ThrowingConsumer<Appendable> content) {
/* 108 */     addFile(Kind.RESOURCE, path, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addResourceFile(String path, InputStreamSource content) {
/* 119 */     addFile(Kind.RESOURCE, path, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addClassFile(String path, InputStreamSource content) {
/* 130 */     addFile(Kind.CLASS, path, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addFile(Kind kind, String path, CharSequence content) {
/* 141 */     addFile(kind, path, appendable -> appendable.append(content));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addFile(Kind kind, String path, ThrowingConsumer<Appendable> content) {
/* 153 */     Assert.notNull(content, "'content' must not be null");
/* 154 */     addFile(kind, path, new AppendableConsumerInputStreamSource(content));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void addFile(Kind kind, String path, InputStreamSource content) {
/* 166 */     Assert.notNull(kind, "'kind' must not be null");
/* 167 */     Assert.hasLength(path, "'path' must not be empty");
/* 168 */     Assert.notNull(content, "'content' must not be null");
/* 169 */     handleFile(kind, path, handler -> handler.create(content));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getClassNamePath(String className) {
/* 186 */     Assert.hasLength(className, "'className' must not be empty");
/* 187 */     validatePackage(ClassUtils.getPackageName(className), className);
/* 188 */     Assert.isTrue(isJavaIdentifier(className), "'className' must be a valid identifier, got '" + className + "'");
/*     */     
/* 190 */     return ClassUtils.convertClassNameToResourcePath(className) + ".java";
/*     */   }
/*     */   
/*     */   private static void validatePackage(String packageName, String className) {
/* 194 */     if (!StringUtils.hasLength(packageName)) {
/* 195 */       throw new IllegalArgumentException("Could not add '" + className + "', processing classes in the default package is not supported. Did you forget to add a package statement?");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isJavaIdentifier(String className) {
/* 202 */     char[] chars = className.toCharArray();
/* 203 */     for (int i = 0; i < chars.length; i++) {
/* 204 */       if (i == 0 && !Character.isJavaIdentifierStart(chars[i])) {
/* 205 */         return false;
/*     */       }
/* 207 */       if (i > 0 && chars[i] != '.' && !Character.isJavaIdentifierPart(chars[i])) {
/* 208 */         return false;
/*     */       }
/*     */     } 
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleFile(Kind paramKind, String paramString, ThrowingConsumer<FileHandler> paramThrowingConsumer);
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Kind
/*     */   {
/* 223 */     SOURCE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     RESOURCE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     CLASS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class FileHandler
/*     */   {
/*     */     private final boolean exists;
/*     */ 
/*     */     
/*     */     private final Supplier<InputStreamSource> existingContent;
/*     */ 
/*     */ 
/*     */     
/*     */     protected FileHandler(boolean exists, Supplier<InputStreamSource> existingContent) {
/* 251 */       this.exists = exists;
/* 252 */       this.existingContent = existingContent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean exists() {
/* 260 */       return this.exists;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public InputStreamSource getContent() {
/* 269 */       return exists() ? this.existingContent.get() : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void create(InputStreamSource content) {
/* 277 */       Assert.notNull(content, "'content' must not be null");
/* 278 */       if (exists()) {
/* 279 */         throw new IllegalStateException("%s already exists".formatted(new Object[] { this }));
/*     */       }
/* 281 */       copy(content, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void override(InputStreamSource content) {
/* 290 */       Assert.notNull(content, "'content' must not be null");
/* 291 */       copy(content, true);
/*     */     }
/*     */     
/*     */     protected abstract void copy(InputStreamSource param1InputStreamSource, boolean param1Boolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GeneratedFiles.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */