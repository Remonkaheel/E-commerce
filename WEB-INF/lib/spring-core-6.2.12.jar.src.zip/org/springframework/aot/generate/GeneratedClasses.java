/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratedClasses
/*     */ {
/*     */   private final ClassNameGenerator classNameGenerator;
/*     */   private final List<GeneratedClass> classes;
/*     */   private final Map<Owner, GeneratedClass> classesByOwner;
/*     */   
/*     */   GeneratedClasses(ClassNameGenerator classNameGenerator) {
/*  56 */     this(classNameGenerator, new ArrayList<>(), new ConcurrentHashMap<>());
/*     */   }
/*     */ 
/*     */   
/*     */   private GeneratedClasses(ClassNameGenerator classNameGenerator, List<GeneratedClass> classes, Map<Owner, GeneratedClass> classesByOwner) {
/*  61 */     Assert.notNull(classNameGenerator, "'classNameGenerator' must not be null");
/*  62 */     this.classNameGenerator = classNameGenerator;
/*  63 */     this.classes = classes;
/*  64 */     this.classesByOwner = classesByOwner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass getOrAddForFeature(String featureName, Consumer<TypeSpec.Builder> type) {
/*  81 */     Assert.hasLength(featureName, "'featureName' must not be empty");
/*  82 */     Assert.notNull(type, "'type' must not be null");
/*  83 */     Owner owner = new Owner(this.classNameGenerator.getFeatureNamePrefix(), featureName, null);
/*  84 */     GeneratedClass generatedClass = this.classesByOwner.computeIfAbsent(owner, key -> createAndAddGeneratedClass(featureName, null, type));
/*  85 */     generatedClass.assertSameType(type);
/*  86 */     return generatedClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass getOrAddForFeatureComponent(String featureName, ClassName targetComponent, Consumer<TypeSpec.Builder> type) {
/* 104 */     Assert.hasLength(featureName, "'featureName' must not be empty");
/* 105 */     Assert.notNull(targetComponent, "'targetComponent' must not be null");
/* 106 */     Assert.notNull(type, "'type' must not be null");
/* 107 */     Owner owner = new Owner(this.classNameGenerator.getFeatureNamePrefix(), featureName, targetComponent);
/* 108 */     GeneratedClass generatedClass = this.classesByOwner.computeIfAbsent(owner, key -> createAndAddGeneratedClass(featureName, targetComponent, type));
/*     */     
/* 110 */     generatedClass.assertSameType(type);
/* 111 */     return generatedClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass getOrAddForFeatureComponent(String featureName, Class<?> targetComponent, Consumer<TypeSpec.Builder> type) {
/* 129 */     return getOrAddForFeatureComponent(featureName, ClassName.get(targetComponent), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass addForFeature(String featureName, Consumer<TypeSpec.Builder> type) {
/* 141 */     Assert.hasLength(featureName, "'featureName' must not be empty");
/* 142 */     Assert.notNull(type, "'type' must not be null");
/* 143 */     return createAndAddGeneratedClass(featureName, null, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass addForFeatureComponent(String featureName, ClassName targetComponent, Consumer<TypeSpec.Builder> type) {
/* 158 */     Assert.hasLength(featureName, "'featureName' must not be empty");
/* 159 */     Assert.notNull(targetComponent, "'targetComponent' must not be null");
/* 160 */     Assert.notNull(type, "'type' must not be null");
/* 161 */     return createAndAddGeneratedClass(featureName, targetComponent, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClass addForFeatureComponent(String featureName, Class<?> targetComponent, Consumer<TypeSpec.Builder> type) {
/* 176 */     return addForFeatureComponent(featureName, ClassName.get(targetComponent), type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GeneratedClass createAndAddGeneratedClass(String featureName, @Nullable ClassName targetComponent, Consumer<TypeSpec.Builder> type) {
/* 182 */     ClassName className = this.classNameGenerator.generateClassName(featureName, targetComponent);
/* 183 */     GeneratedClass generatedClass = new GeneratedClass(className, type);
/* 184 */     this.classes.add(generatedClass);
/* 185 */     return generatedClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeTo(GeneratedFiles generatedFiles) {
/* 194 */     Assert.notNull(generatedFiles, "'generatedFiles' must not be null");
/* 195 */     List<GeneratedClass> generatedClasses = new ArrayList<>(this.classes);
/* 196 */     generatedClasses.sort(Comparator.comparing(GeneratedClass::getName));
/* 197 */     for (GeneratedClass generatedClass : generatedClasses) {
/* 198 */       generatedFiles.addSourceFile(generatedClass.generateJavaFile());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GeneratedClasses withFeatureNamePrefix(String featureNamePrefix) {
/* 210 */     return new GeneratedClasses(this.classNameGenerator.withFeatureNamePrefix(featureNamePrefix), this.classes, this.classesByOwner);
/*     */   }
/*     */   private static final class Owner extends Record { private final String featureNamePrefix; private final String featureName; @Nullable
/*     */     private final ClassName target;
/* 214 */     private Owner(String featureNamePrefix, String featureName, @Nullable ClassName target) { this.featureNamePrefix = featureNamePrefix; this.featureName = featureName; this.target = target; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/aot/generate/GeneratedClasses$Owner;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #214	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 214 */       //   0	7	0	this	Lorg/springframework/aot/generate/GeneratedClasses$Owner; } public String featureNamePrefix() { return this.featureNamePrefix; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/aot/generate/GeneratedClasses$Owner;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #214	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aot/generate/GeneratedClasses$Owner; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/aot/generate/GeneratedClasses$Owner;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #214	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/aot/generate/GeneratedClasses$Owner;
/* 214 */       //   0	8	1	o	Ljava/lang/Object; } public String featureName() { return this.featureName; } @Nullable public ClassName target() { return this.target; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GeneratedClasses.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */