/*    */ package org.springframework.aot.generate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedTypeValueCodeGenerationException
/*    */   extends ValueCodeGenerationException
/*    */ {
/*    */   public UnsupportedTypeValueCodeGenerationException(Object value) {
/* 30 */     super("Code generation does not support " + value.getClass().getName(), value, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\UnsupportedTypeValueCodeGenerationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */