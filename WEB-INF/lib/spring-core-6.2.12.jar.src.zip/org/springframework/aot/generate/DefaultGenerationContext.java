/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultGenerationContext
/*     */   implements GenerationContext
/*     */ {
/*     */   private final Map<String, AtomicInteger> sequenceGenerator;
/*     */   private final GeneratedClasses generatedClasses;
/*     */   private final GeneratedFiles generatedFiles;
/*     */   private final RuntimeHints runtimeHints;
/*     */   
/*     */   public DefaultGenerationContext(ClassNameGenerator classNameGenerator, GeneratedFiles generatedFiles) {
/*  57 */     this(classNameGenerator, generatedFiles, new RuntimeHints());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultGenerationContext(ClassNameGenerator classNameGenerator, GeneratedFiles generatedFiles, RuntimeHints runtimeHints) {
/*  71 */     this(new GeneratedClasses(classNameGenerator), generatedFiles, runtimeHints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultGenerationContext(GeneratedClasses generatedClasses, GeneratedFiles generatedFiles, RuntimeHints runtimeHints) {
/*  84 */     Assert.notNull(generatedClasses, "'generatedClasses' must not be null");
/*  85 */     Assert.notNull(generatedFiles, "'generatedFiles' must not be null");
/*  86 */     Assert.notNull(runtimeHints, "'runtimeHints' must not be null");
/*  87 */     this.sequenceGenerator = new ConcurrentHashMap<>();
/*  88 */     this.generatedClasses = generatedClasses;
/*  89 */     this.generatedFiles = generatedFiles;
/*  90 */     this.runtimeHints = runtimeHints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultGenerationContext(DefaultGenerationContext existing, String featureName) {
/* 101 */     int sequence = ((AtomicInteger)existing.sequenceGenerator.computeIfAbsent(featureName, key -> new AtomicInteger())).getAndIncrement();
/* 102 */     if (sequence > 0) {
/* 103 */       featureName = featureName + featureName;
/*     */     }
/* 105 */     this.sequenceGenerator = existing.sequenceGenerator;
/* 106 */     this.generatedClasses = existing.generatedClasses.withFeatureNamePrefix(featureName);
/* 107 */     this.generatedFiles = existing.generatedFiles;
/* 108 */     this.runtimeHints = existing.runtimeHints;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClasses getGeneratedClasses() {
/* 114 */     return this.generatedClasses;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeneratedFiles getGeneratedFiles() {
/* 119 */     return this.generatedFiles;
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeHints getRuntimeHints() {
/* 124 */     return this.runtimeHints;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultGenerationContext withName(String name) {
/* 129 */     return new DefaultGenerationContext(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeGeneratedContent() {
/* 136 */     this.generatedClasses.writeTo(this.generatedFiles);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\DefaultGenerationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */