/*    */ package org.springframework.aot.generate;
/*    */ 
/*    */ import org.springframework.aot.hint.AbstractTypeReference;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.javapoet.ClassName;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GeneratedTypeReference
/*    */   extends AbstractTypeReference
/*    */ {
/*    */   private final ClassName className;
/*    */   
/*    */   private GeneratedTypeReference(ClassName className) {
/* 36 */     super(className.packageName(), className.simpleName(), (TypeReference)safeCreate(className.enclosingClassName()));
/* 37 */     this.className = className;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   private static GeneratedTypeReference safeCreate(@Nullable ClassName className) {
/* 42 */     return (className != null) ? new GeneratedTypeReference(className) : null;
/*    */   }
/*    */   
/*    */   public static GeneratedTypeReference of(ClassName className) {
/* 46 */     Assert.notNull(className, "ClassName must not be null");
/* 47 */     return new GeneratedTypeReference(className);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCanonicalName() {
/* 52 */     return this.className.canonicalName();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isPrimitive() {
/* 57 */     return this.className.isPrimitive();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GeneratedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */