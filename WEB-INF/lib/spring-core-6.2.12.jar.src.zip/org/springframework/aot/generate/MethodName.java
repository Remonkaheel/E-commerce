/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MethodName
/*     */ {
/*  34 */   private static final String[] PREFIXES = new String[] { "get", "set", "is" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   public static final MethodName NONE = of(new String[0]);
/*     */   
/*     */   private final String value;
/*     */ 
/*     */   
/*     */   private MethodName(String value) {
/*  45 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MethodName of(String... parts) {
/*  56 */     Assert.notNull(parts, "'parts' must not be null");
/*  57 */     return new MethodName(join(parts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodName and(MethodName name) {
/*  66 */     Assert.notNull(name, "'name' must not be null");
/*  67 */     return and(new String[] { name.value });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodName and(String... parts) {
/*  76 */     Assert.notNull(parts, "'parts' must not be null");
/*  77 */     String joined = join(parts);
/*  78 */     String prefix = getPrefix(joined);
/*  79 */     String suffix = joined.substring(prefix.length());
/*  80 */     return of(new String[] { prefix, this.value, suffix });
/*     */   }
/*     */   
/*     */   private String getPrefix(String name) {
/*  84 */     for (String candidate : PREFIXES) {
/*  85 */       if (name.startsWith(candidate)) {
/*  86 */         return candidate;
/*     */       }
/*     */     } 
/*  89 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  95 */     if (this != other) { if (other instanceof MethodName) { MethodName that = (MethodName)other; if (this.value.equals(that.value)); }  return false; }
/*     */   
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 100 */     return this.value.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     return !StringUtils.hasLength(this.value) ? "$$aot" : this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String join(String[] parts) {
/* 110 */     return StringUtils.uncapitalize(Arrays.<String>stream(parts).map(MethodName::clean)
/* 111 */         .map(StringUtils::capitalize).collect(Collectors.joining()));
/*     */   }
/*     */   
/*     */   private static String clean(@Nullable String part) {
/* 115 */     char[] chars = (part != null) ? part.toCharArray() : new char[0];
/* 116 */     StringBuilder name = new StringBuilder(chars.length);
/* 117 */     boolean uppercase = false;
/* 118 */     for (char ch : chars) {
/* 119 */       char outputChar = !uppercase ? ch : Character.toUpperCase(ch);
/* 120 */       name.append(!Character.isLetter(ch) ? "" : Character.valueOf(outputChar));
/* 121 */       uppercase = (ch == '.');
/*     */     } 
/* 123 */     return name.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\MethodName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */