/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapDelegate
/*     */   implements ValueCodeGenerator.Delegate
/*     */ {
/* 136 */   private static final CodeBlock EMPTY_RESULT = CodeBlock.of("$T.emptyMap()", new Object[] { Collections.class });
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/* 141 */     if (value instanceof Map) { Map<?, ?> map = (Map<?, ?>)value;
/* 142 */       if (map.isEmpty()) {
/* 143 */         return EMPTY_RESULT;
/*     */       }
/* 145 */       return generateMapCode(valueCodeGenerator, map); }
/*     */     
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected CodeBlock generateMapCode(ValueCodeGenerator valueCodeGenerator, Map<?, ?> map) {
/* 159 */     map = orderForCodeConsistency(map);
/* 160 */     boolean useOfEntries = (map.size() > 10);
/* 161 */     CodeBlock.Builder code = CodeBlock.builder();
/* 162 */     code.add("$T" + (!useOfEntries ? ".of(" : ".ofEntries("), new Object[] { Map.class });
/* 163 */     Iterator<? extends Map.Entry<?, ?>> iterator = map.entrySet().iterator();
/* 164 */     while (iterator.hasNext()) {
/* 165 */       Map.Entry<?, ?> entry = iterator.next();
/* 166 */       CodeBlock keyCode = valueCodeGenerator.generateCode(entry.getKey());
/* 167 */       CodeBlock valueCode = valueCodeGenerator.generateCode(entry.getValue());
/* 168 */       if (!useOfEntries) {
/* 169 */         code.add("$L, $L", new Object[] { keyCode, valueCode });
/*     */       } else {
/*     */         
/* 172 */         code.add("$T.entry($L,$L)", new Object[] { Map.class, keyCode, valueCode });
/*     */       } 
/* 174 */       if (iterator.hasNext()) {
/* 175 */         code.add(", ", new Object[0]);
/*     */       }
/*     */     } 
/* 178 */     code.add(")", new Object[0]);
/* 179 */     return code.build();
/*     */   }
/*     */   
/*     */   private <K, V> Map<K, V> orderForCodeConsistency(Map<K, V> map) {
/*     */     try {
/* 184 */       return new TreeMap<>(map);
/*     */     }
/* 186 */     catch (ClassCastException ex) {
/*     */       
/* 188 */       return map;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGeneratorDelegates$MapDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */