/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.ThrowingConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileSystemGeneratedFiles
/*     */   implements GeneratedFiles
/*     */ {
/*     */   private final Function<GeneratedFiles.Kind, Path> roots;
/*     */   
/*     */   public FileSystemGeneratedFiles(Path root) {
/*  61 */     this(conventionRoots(root));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileSystemGeneratedFiles(Function<GeneratedFiles.Kind, Path> roots) {
/*  71 */     Assert.notNull(roots, "'roots' must not be null");
/*  72 */     Assert.isTrue(Arrays.<GeneratedFiles.Kind>stream(GeneratedFiles.Kind.values()).<Path>map(roots).noneMatch(Objects::isNull), "'roots' must return a value for all file kinds");
/*     */     
/*  74 */     this.roots = roots;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Function<GeneratedFiles.Kind, Path> conventionRoots(Path root) {
/*  79 */     Assert.notNull(root, "'root' must not be null");
/*  80 */     return kind -> { switch (kind) { default:
/*     */             throw new IncompatibleClassChangeError();
/*     */           case SOURCE:
/*     */           
/*     */           case RESOURCE:
/*     */           
/*     */           case CLASS:
/*     */             break; }
/*     */          return root.resolve("classes");
/*  89 */       }; } public void handleFile(GeneratedFiles.Kind kind, String path, ThrowingConsumer<GeneratedFiles.FileHandler> handler) { FileSystemFileHandler fileHandler = new FileSystemFileHandler(toPath(kind, path));
/*  90 */     handler.accept(fileHandler); }
/*     */ 
/*     */   
/*     */   private Path toPath(GeneratedFiles.Kind kind, String path) {
/*  94 */     Assert.notNull(kind, "'kind' must not be null");
/*  95 */     Assert.hasLength(path, "'path' must not be empty");
/*  96 */     Path root = ((Path)this.roots.apply(kind)).toAbsolutePath().normalize();
/*  97 */     Path relativePath = root.resolve(path).toAbsolutePath().normalize();
/*  98 */     Assert.isTrue(relativePath.startsWith(root), "'path' must be relative");
/*  99 */     return relativePath;
/*     */   }
/*     */   
/*     */   static final class FileSystemFileHandler
/*     */     extends GeneratedFiles.FileHandler {
/*     */     private final Path path;
/*     */     
/*     */     FileSystemFileHandler(Path path) {
/* 107 */       super(Files.exists(path, new java.nio.file.LinkOption[0]), () -> new FileSystemResource(path));
/* 108 */       this.path = path;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void copy(InputStreamSource content, boolean override) {
/* 113 */       if (override) {
/* 114 */         copy(content, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */       } else {
/*     */         
/* 117 */         copy(content, new CopyOption[0]);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void copy(InputStreamSource content, CopyOption... copyOptions) {
/*     */       try {
/* 123 */         InputStream inputStream = content.getInputStream(); 
/* 124 */         try { Files.createDirectories(this.path.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/* 125 */           Files.copy(inputStream, this.path, copyOptions);
/* 126 */           if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null)
/*     */             try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/* 128 */       } catch (IOException ex) {
/* 129 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 135 */       return this.path.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\FileSystemGeneratedFiles.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */