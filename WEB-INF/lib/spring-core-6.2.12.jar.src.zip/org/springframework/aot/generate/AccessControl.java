/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.IntFunction;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AccessControl
/*     */ {
/*     */   private final Class<?> target;
/*     */   private final Visibility visibility;
/*     */   
/*     */   AccessControl(Class<?> target, Visibility visibility) {
/*  50 */     this.target = target;
/*  51 */     this.visibility = visibility;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AccessControl forMember(Member member) {
/*  63 */     return new AccessControl(member.getDeclaringClass(), Visibility.forMember(member));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AccessControl forResolvableType(ResolvableType resolvableType) {
/*  73 */     return new AccessControl(resolvableType.toClass(), Visibility.forResolvableType(resolvableType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AccessControl forClass(Class<?> type) {
/*  82 */     return new AccessControl(type, Visibility.forClass(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AccessControl lowest(AccessControl... candidates) {
/*  91 */     int index = Visibility.lowestIndex(
/*  92 */         (Visibility[])Arrays.<AccessControl>stream(candidates).map(AccessControl::getVisibility).toArray(x$0 -> new Visibility[x$0]));
/*  93 */     return candidates[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Visibility getVisibility() {
/* 101 */     return this.visibility;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/* 110 */     return (this.visibility == Visibility.PUBLIC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessibleFrom(ClassName type) {
/* 120 */     if (this.visibility == Visibility.PRIVATE) {
/* 121 */       return false;
/*     */     }
/* 123 */     if (this.visibility == Visibility.PUBLIC) {
/* 124 */       return true;
/*     */     }
/* 126 */     return this.target.getPackageName().equals(type.packageName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Visibility
/*     */   {
/* 140 */     PUBLIC,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     PROTECTED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     PACKAGE_PRIVATE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     PRIVATE;
/*     */ 
/*     */     
/*     */     private static Visibility forMember(Member member) {
/* 161 */       Assert.notNull(member, "'member' must not be null");
/* 162 */       Visibility visibility = forModifiers(member.getModifiers());
/* 163 */       Visibility declaringClassVisibility = forClass(member.getDeclaringClass());
/* 164 */       visibility = lowest(new Visibility[] { visibility, declaringClassVisibility });
/* 165 */       if (visibility != PRIVATE) {
/* 166 */         if (member instanceof Field) { Field field = (Field)member;
/* 167 */           Visibility fieldVisibility = forResolvableType(
/* 168 */               ResolvableType.forField(field));
/* 169 */           return lowest(new Visibility[] { visibility, fieldVisibility }); }
/*     */         
/* 171 */         if (member instanceof Constructor) { Constructor<?> constructor = (Constructor)member;
/* 172 */           Visibility parameterVisibility = forParameterTypes(constructor, i -> ResolvableType.forConstructorParameter(constructor, i));
/*     */           
/* 174 */           return lowest(new Visibility[] { visibility, parameterVisibility }); }
/*     */         
/* 176 */         if (member instanceof Method) { Method method = (Method)member;
/* 177 */           Visibility parameterVisibility = forParameterTypes(method, i -> ResolvableType.forMethodParameter(method, i));
/*     */           
/* 179 */           Visibility returnTypeVisibility = forResolvableType(
/* 180 */               ResolvableType.forMethodReturnType(method));
/* 181 */           return lowest(new Visibility[] { visibility, parameterVisibility, returnTypeVisibility }); }
/*     */       
/*     */       } 
/* 184 */       return PRIVATE;
/*     */     }
/*     */     
/*     */     private static Visibility forResolvableType(ResolvableType resolvableType) {
/* 188 */       return forResolvableType(resolvableType, new HashSet<>());
/*     */     }
/*     */ 
/*     */     
/*     */     private static Visibility forResolvableType(ResolvableType resolvableType, Set<ResolvableType> seen) {
/* 193 */       if (!seen.add(resolvableType)) {
/* 194 */         return PUBLIC;
/*     */       }
/* 196 */       Class<?> userClass = ClassUtils.getUserClass(resolvableType.toClass());
/* 197 */       ResolvableType userType = resolvableType.as(userClass);
/* 198 */       Visibility visibility = forClass(userType.toClass());
/* 199 */       for (ResolvableType generic : userType.getGenerics()) {
/* 200 */         visibility = lowest(new Visibility[] { visibility, forResolvableType(generic, seen) });
/*     */       } 
/* 202 */       return visibility;
/*     */     }
/*     */ 
/*     */     
/*     */     private static Visibility forParameterTypes(Executable executable, IntFunction<ResolvableType> resolvableTypeFactory) {
/* 207 */       Visibility visibility = PUBLIC;
/* 208 */       Class<?>[] parameterTypes = executable.getParameterTypes();
/* 209 */       for (int i = 0; i < parameterTypes.length; i++) {
/* 210 */         ResolvableType type = resolvableTypeFactory.apply(i);
/* 211 */         visibility = lowest(new Visibility[] { visibility, forResolvableType(type) });
/*     */       } 
/* 213 */       return visibility;
/*     */     }
/*     */     
/*     */     private static Visibility forClass(Class<?> clazz) {
/* 217 */       clazz = ClassUtils.getUserClass(clazz);
/* 218 */       Visibility visibility = forModifiers(clazz.getModifiers());
/* 219 */       if (clazz.isArray()) {
/* 220 */         visibility = lowest(new Visibility[] { visibility, forClass(clazz.componentType()) });
/*     */       }
/* 222 */       Class<?> enclosingClass = clazz.getEnclosingClass();
/* 223 */       if (enclosingClass != null) {
/* 224 */         visibility = lowest(new Visibility[] { visibility, forClass(clazz.getEnclosingClass()) });
/*     */       }
/* 226 */       return visibility;
/*     */     }
/*     */     
/*     */     private static Visibility forModifiers(int modifiers) {
/* 230 */       if (Modifier.isPublic(modifiers)) {
/* 231 */         return PUBLIC;
/*     */       }
/* 233 */       if (Modifier.isProtected(modifiers)) {
/* 234 */         return PROTECTED;
/*     */       }
/* 236 */       if (Modifier.isPrivate(modifiers)) {
/* 237 */         return PRIVATE;
/*     */       }
/* 239 */       return PACKAGE_PRIVATE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Visibility lowest(Visibility... candidates) {
/* 248 */       Visibility visibility = PUBLIC;
/* 249 */       for (Visibility candidate : candidates) {
/* 250 */         if (candidate.ordinal() > visibility.ordinal()) {
/* 251 */           visibility = candidate;
/*     */         }
/*     */       } 
/* 254 */       return visibility;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static int lowestIndex(Visibility... candidates) {
/* 264 */       Visibility visibility = PUBLIC;
/* 265 */       int index = 0;
/* 266 */       for (int i = 0; i < candidates.length; i++) {
/* 267 */         Visibility candidate = candidates[i];
/* 268 */         if (candidate.ordinal() > visibility.ordinal()) {
/* 269 */           visibility = candidate;
/* 270 */           index = i;
/*     */         } 
/*     */       } 
/* 273 */       return index;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\AccessControl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */