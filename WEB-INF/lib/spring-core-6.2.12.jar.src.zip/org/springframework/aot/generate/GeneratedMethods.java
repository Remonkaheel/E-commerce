/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratedMethods
/*     */ {
/*     */   private final ClassName className;
/*     */   private final Function<MethodName, String> methodNameGenerator;
/*     */   private final MethodName prefix;
/*     */   private final List<GeneratedMethod> generatedMethods;
/*     */   
/*     */   GeneratedMethods(ClassName className, Function<MethodName, String> methodNameGenerator) {
/*  55 */     Assert.notNull(className, "'className' must not be null");
/*  56 */     Assert.notNull(methodNameGenerator, "'methodNameGenerator' must not be null");
/*  57 */     this.className = className;
/*  58 */     this.methodNameGenerator = methodNameGenerator;
/*  59 */     this.prefix = MethodName.NONE;
/*  60 */     this.generatedMethods = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GeneratedMethods(ClassName className, Function<MethodName, String> methodNameGenerator, MethodName prefix, List<GeneratedMethod> generatedMethods) {
/*  66 */     this.className = className;
/*  67 */     this.methodNameGenerator = methodNameGenerator;
/*  68 */     this.prefix = prefix;
/*  69 */     this.generatedMethods = generatedMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedMethod add(String suggestedName, Consumer<MethodSpec.Builder> method) {
/*  88 */     Assert.notNull(suggestedName, "'suggestedName' must not be null");
/*  89 */     return add(new String[] { suggestedName }, method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedMethod add(String[] suggestedNameParts, Consumer<MethodSpec.Builder> method) {
/* 109 */     Assert.notNull(suggestedNameParts, "'suggestedNameParts' must not be null");
/* 110 */     Assert.notNull(method, "'method' must not be null");
/* 111 */     String generatedName = this.methodNameGenerator.apply(this.prefix.and(suggestedNameParts));
/* 112 */     GeneratedMethod generatedMethod = new GeneratedMethod(this.className, generatedName, method);
/* 113 */     this.generatedMethods.add(generatedMethod);
/* 114 */     return generatedMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedMethods withPrefix(String prefix) {
/* 125 */     Assert.notNull(prefix, "'prefix' must not be null");
/* 126 */     return new GeneratedMethods(this.className, this.methodNameGenerator, this.prefix
/* 127 */         .and(new String[] { prefix }, ), this.generatedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doWithMethodSpecs(Consumer<MethodSpec> action) {
/* 136 */     stream().<MethodSpec>map(GeneratedMethod::getMethodSpec).forEach(action);
/*     */   }
/*     */   
/*     */   Stream<GeneratedMethod> stream() {
/* 140 */     return this.generatedMethods.stream();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GeneratedMethods.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */