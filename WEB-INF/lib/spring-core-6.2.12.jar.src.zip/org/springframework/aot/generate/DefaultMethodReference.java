/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.ParameterSpec;
/*     */ import org.springframework.javapoet.TypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMethodReference
/*     */   implements MethodReference
/*     */ {
/*     */   private final MethodSpec method;
/*     */   @Nullable
/*     */   private final ClassName declaringClass;
/*     */   
/*     */   public DefaultMethodReference(MethodSpec method, @Nullable ClassName declaringClass) {
/*  47 */     this.method = method;
/*  48 */     this.declaringClass = declaringClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock toCodeBlock() {
/*  54 */     String methodName = this.method.name;
/*  55 */     if (isStatic()) {
/*  56 */       Assert.state((this.declaringClass != null), "Static method reference must define a declaring class");
/*  57 */       return CodeBlock.of("$T::$L", new Object[] { this.declaringClass, methodName });
/*     */     } 
/*     */     
/*  60 */     return CodeBlock.of("this::$L", new Object[] { methodName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock toInvokeCodeBlock(MethodReference.ArgumentCodeGenerator argumentCodeGenerator, @Nullable ClassName targetClassName) {
/*  68 */     String methodName = this.method.name;
/*  69 */     CodeBlock.Builder code = CodeBlock.builder();
/*  70 */     if (isStatic()) {
/*  71 */       Assert.state((this.declaringClass != null), "Static method reference must define a declaring class");
/*  72 */       if (this.declaringClass.equals(targetClassName)) {
/*  73 */         code.add("$L", new Object[] { methodName });
/*     */       } else {
/*     */         
/*  76 */         code.add("$T.$L", new Object[] { this.declaringClass, methodName });
/*     */       } 
/*     */     } else {
/*     */       
/*  80 */       if (this.declaringClass != null && !this.declaringClass.equals(targetClassName)) {
/*  81 */         code.add(instantiateDeclaringClass(this.declaringClass));
/*     */       }
/*  83 */       code.add("$L", new Object[] { methodName });
/*     */     } 
/*  85 */     code.add("(", new Object[0]);
/*  86 */     addArguments(code, argumentCodeGenerator);
/*  87 */     code.add(")", new Object[0]);
/*  88 */     return code.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addArguments(CodeBlock.Builder code, MethodReference.ArgumentCodeGenerator argumentCodeGenerator) {
/*  98 */     List<CodeBlock> arguments = new ArrayList<>();
/*     */     
/* 100 */     TypeName[] argumentTypes = (TypeName[])this.method.parameters.stream().map(parameter -> parameter.type).toArray(x$0 -> new TypeName[x$0]);
/* 101 */     for (int i = 0; i < argumentTypes.length; i++) {
/* 102 */       TypeName argumentType = argumentTypes[i];
/* 103 */       CodeBlock argumentCode = argumentCodeGenerator.generateCode(argumentType);
/* 104 */       if (argumentCode == null) {
/* 105 */         throw new IllegalArgumentException("Could not generate code for " + String.valueOf(this) + ": parameter " + i + " of type " + String.valueOf(argumentType) + " is not supported");
/*     */       }
/*     */       
/* 108 */       arguments.add(argumentCode);
/*     */     } 
/* 110 */     code.add(CodeBlock.join(arguments, ", "));
/*     */   }
/*     */   
/*     */   protected CodeBlock instantiateDeclaringClass(ClassName declaringClass) {
/* 114 */     return CodeBlock.of("new $T().", new Object[] { declaringClass });
/*     */   }
/*     */   
/*     */   private boolean isStatic() {
/* 118 */     return this.method.modifiers.contains(Modifier.STATIC);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 123 */     String methodName = this.method.name;
/* 124 */     if (isStatic()) {
/* 125 */       return String.valueOf(this.declaringClass) + "::" + String.valueOf(this.declaringClass);
/*     */     }
/*     */     
/* 128 */     return ((this.declaringClass != null) ? ("<" + 
/* 129 */       String.valueOf(this.declaringClass) + ">") : "<instance>") + "::" + ((this.declaringClass != null) ? ("<" + String.valueOf(this.declaringClass) + ">") : "<instance>");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\DefaultMethodReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */