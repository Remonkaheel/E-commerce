/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.ThrowingConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InMemoryGeneratedFiles
/*     */   implements GeneratedFiles
/*     */ {
/*  40 */   private final Map<GeneratedFiles.Kind, Map<String, InputStreamSource>> files = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleFile(GeneratedFiles.Kind kind, String path, ThrowingConsumer<GeneratedFiles.FileHandler> handler) {
/*  45 */     Map<String, InputStreamSource> paths = this.files.computeIfAbsent(kind, key -> new LinkedHashMap<>());
/*     */     
/*  47 */     handler.accept(new InMemoryFileHandler(paths, path));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, InputStreamSource> getGeneratedFiles(GeneratedFiles.Kind kind) {
/*  56 */     Assert.notNull(kind, "'kind' must not be null");
/*  57 */     return Collections.unmodifiableMap(this.files.getOrDefault(kind, Collections.emptyMap()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getGeneratedFileContent(GeneratedFiles.Kind kind, String path) throws IOException {
/*  69 */     InputStreamSource source = getGeneratedFile(kind, path);
/*  70 */     if (source != null) {
/*  71 */       return new String(source.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
/*     */     }
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InputStreamSource getGeneratedFile(GeneratedFiles.Kind kind, String path) {
/*  84 */     Assert.notNull(kind, "'kind' must not be null");
/*  85 */     Assert.hasLength(path, "'path' must not be empty");
/*  86 */     Map<String, InputStreamSource> paths = this.files.get(kind);
/*  87 */     return (paths != null) ? paths.get(path) : null;
/*     */   }
/*     */   
/*     */   private static class InMemoryFileHandler
/*     */     extends GeneratedFiles.FileHandler
/*     */   {
/*     */     private final Map<String, InputStreamSource> paths;
/*     */     private final String key;
/*     */     
/*     */     InMemoryFileHandler(Map<String, InputStreamSource> paths, String key) {
/*  97 */       super(paths.containsKey(key), () -> (InputStreamSource)paths.get(key));
/*  98 */       this.paths = paths;
/*  99 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void copy(InputStreamSource content, boolean override) {
/* 104 */       this.paths.put(this.key, content);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 109 */       return this.key;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\InMemoryGeneratedFiles.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */