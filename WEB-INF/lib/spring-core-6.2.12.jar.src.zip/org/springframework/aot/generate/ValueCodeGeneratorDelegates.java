/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValueCodeGeneratorDelegates
/*     */ {
/*  67 */   public static final List<ValueCodeGenerator.Delegate> INSTANCES = List.of(new PrimitiveDelegate(), new StringDelegate(), new CharsetDelegate(), new EnumDelegate(), new ClassDelegate(), new ResolvableTypeDelegate(), new ArrayDelegate(), new ListDelegate(), new SetDelegate(), new MapDelegate());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class CollectionDelegate<T extends Collection<?>>
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     private final Class<?> collectionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final CodeBlock emptyResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected CollectionDelegate(Class<?> collectionType, CodeBlock emptyResult) {
/*  91 */       this.collectionType = collectionType;
/*  92 */       this.emptyResult = emptyResult;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/*  99 */       if (this.collectionType.isInstance(value)) {
/* 100 */         Collection collection = (Collection)value;
/* 101 */         if (collection.isEmpty()) {
/* 102 */           return this.emptyResult;
/*     */         }
/* 104 */         return generateCollectionCode(valueCodeGenerator, (T)collection);
/*     */       } 
/* 106 */       return null;
/*     */     }
/*     */     
/*     */     protected CodeBlock generateCollectionCode(ValueCodeGenerator valueCodeGenerator, T collection) {
/* 110 */       return generateCollectionOf(valueCodeGenerator, (Collection<?>)collection, this.collectionType);
/*     */     }
/*     */ 
/*     */     
/*     */     protected final CodeBlock generateCollectionOf(ValueCodeGenerator valueCodeGenerator, Collection<?> collection, Class<?> collectionType) {
/* 115 */       CodeBlock.Builder code = CodeBlock.builder();
/* 116 */       code.add("$T.of(", new Object[] { collectionType });
/* 117 */       Iterator<?> iterator = collection.iterator();
/* 118 */       while (iterator.hasNext()) {
/* 119 */         Object element = iterator.next();
/* 120 */         code.add("$L", new Object[] { valueCodeGenerator.generateCode(element) });
/* 121 */         if (iterator.hasNext()) {
/* 122 */           code.add(", ", new Object[0]);
/*     */         }
/*     */       } 
/* 125 */       code.add(")", new Object[0]);
/* 126 */       return code.build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MapDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/* 136 */     private static final CodeBlock EMPTY_RESULT = CodeBlock.of("$T.emptyMap()", new Object[] { Collections.class });
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/* 141 */       if (value instanceof Map) { Map<?, ?> map = (Map<?, ?>)value;
/* 142 */         if (map.isEmpty()) {
/* 143 */           return EMPTY_RESULT;
/*     */         }
/* 145 */         return generateMapCode(valueCodeGenerator, map); }
/*     */       
/* 147 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected CodeBlock generateMapCode(ValueCodeGenerator valueCodeGenerator, Map<?, ?> map) {
/* 159 */       map = orderForCodeConsistency(map);
/* 160 */       boolean useOfEntries = (map.size() > 10);
/* 161 */       CodeBlock.Builder code = CodeBlock.builder();
/* 162 */       code.add("$T" + (!useOfEntries ? ".of(" : ".ofEntries("), new Object[] { Map.class });
/* 163 */       Iterator<? extends Map.Entry<?, ?>> iterator = map.entrySet().iterator();
/* 164 */       while (iterator.hasNext()) {
/* 165 */         Map.Entry<?, ?> entry = iterator.next();
/* 166 */         CodeBlock keyCode = valueCodeGenerator.generateCode(entry.getKey());
/* 167 */         CodeBlock valueCode = valueCodeGenerator.generateCode(entry.getValue());
/* 168 */         if (!useOfEntries) {
/* 169 */           code.add("$L, $L", new Object[] { keyCode, valueCode });
/*     */         } else {
/*     */           
/* 172 */           code.add("$T.entry($L,$L)", new Object[] { Map.class, keyCode, valueCode });
/*     */         } 
/* 174 */         if (iterator.hasNext()) {
/* 175 */           code.add(", ", new Object[0]);
/*     */         }
/*     */       } 
/* 178 */       code.add(")", new Object[0]);
/* 179 */       return code.build();
/*     */     }
/*     */     
/*     */     private <K, V> Map<K, V> orderForCodeConsistency(Map<K, V> map) {
/*     */       try {
/* 184 */         return new TreeMap<>(map);
/*     */       }
/* 186 */       catch (ClassCastException ex) {
/*     */         
/* 188 */         return map;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PrimitiveDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/* 199 */     private static final Map<Character, String> CHAR_ESCAPES = Map.of(
/* 200 */         Character.valueOf('\b'), "\\b", 
/* 201 */         Character.valueOf('\t'), "\\t", 
/* 202 */         Character.valueOf('\n'), "\\n", 
/* 203 */         Character.valueOf('\f'), "\\f", 
/* 204 */         Character.valueOf('\r'), "\\r", 
/* 205 */         Character.valueOf('"'), "\"", 
/* 206 */         Character.valueOf('\''), "\\'", 
/* 207 */         Character.valueOf('\\'), "\\\\");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 214 */       if (value instanceof Boolean || value instanceof Integer) {
/* 215 */         return CodeBlock.of("$L", new Object[] { value });
/*     */       }
/* 217 */       if (value instanceof Byte) {
/* 218 */         return CodeBlock.of("(byte) $L", new Object[] { value });
/*     */       }
/* 220 */       if (value instanceof Short) {
/* 221 */         return CodeBlock.of("(short) $L", new Object[] { value });
/*     */       }
/* 223 */       if (value instanceof Long) {
/* 224 */         return CodeBlock.of("$LL", new Object[] { value });
/*     */       }
/* 226 */       if (value instanceof Float) {
/* 227 */         return CodeBlock.of("$LF", new Object[] { value });
/*     */       }
/* 229 */       if (value instanceof Double) {
/* 230 */         return CodeBlock.of("(double) $L", new Object[] { value });
/*     */       }
/* 232 */       if (value instanceof Character) { Character character = (Character)value;
/* 233 */         return CodeBlock.of("'$L'", new Object[] { escape(character.charValue()) }); }
/*     */       
/* 235 */       return null;
/*     */     }
/*     */     
/*     */     private String escape(char ch) {
/* 239 */       String escaped = CHAR_ESCAPES.get(Character.valueOf(ch));
/* 240 */       if (escaped != null) {
/* 241 */         return escaped;
/*     */       }
/* 243 */       return !Character.isISOControl(ch) ? Character.toString(ch) : 
/* 244 */         String.format("\\u%04x", new Object[] { Integer.valueOf(ch) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StringDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 257 */       if (value instanceof String) {
/* 258 */         return CodeBlock.of("$S", new Object[] { value });
/*     */       }
/* 260 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CharsetDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 273 */       if (value instanceof Charset) { Charset charset = (Charset)value;
/* 274 */         return CodeBlock.of("$T.forName($S)", new Object[] { Charset.class, charset.name() }); }
/*     */       
/* 276 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EnumDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 289 */       if (value instanceof Enum) { Enum<?> enumValue = (Enum)value;
/* 290 */         return CodeBlock.of("$T.$L", new Object[] { enumValue.getDeclaringClass(), enumValue
/* 291 */               .name() }); }
/*     */       
/* 293 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ClassDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 306 */       if (value instanceof Class) { Class<?> clazz = (Class)value;
/* 307 */         return CodeBlock.of("$T.class", new Object[] { ClassUtils.getUserClass(clazz) }); }
/*     */       
/* 309 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResolvableTypeDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 322 */       if (value instanceof ResolvableType) { ResolvableType resolvableType = (ResolvableType)value;
/* 323 */         return generateCode(resolvableType, false); }
/*     */       
/* 325 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     private static CodeBlock generateCode(ResolvableType resolvableType, boolean allowClassResult) {
/* 330 */       if (ResolvableType.NONE.equals(resolvableType)) {
/* 331 */         return CodeBlock.of("$T.NONE", new Object[] { ResolvableType.class });
/*     */       }
/* 333 */       Class<?> type = ClassUtils.getUserClass(resolvableType.toClass());
/* 334 */       if (resolvableType.hasGenerics() && resolvableType.hasResolvableGenerics()) {
/* 335 */         return generateCodeWithGenerics(resolvableType, type);
/*     */       }
/* 337 */       if (allowClassResult) {
/* 338 */         return CodeBlock.of("$T.class", new Object[] { type });
/*     */       }
/* 340 */       return CodeBlock.of("$T.forClass($T.class)", new Object[] { ResolvableType.class, type });
/*     */     }
/*     */     
/*     */     private static CodeBlock generateCodeWithGenerics(ResolvableType target, Class<?> type) {
/* 344 */       ResolvableType[] generics = target.getGenerics();
/* 345 */       boolean hasNoNestedGenerics = Arrays.<ResolvableType>stream(generics).noneMatch(ResolvableType::hasGenerics);
/* 346 */       CodeBlock.Builder code = CodeBlock.builder();
/* 347 */       code.add("$T.forClassWithGenerics($T.class", new Object[] { ResolvableType.class, type });
/* 348 */       for (ResolvableType generic : generics) {
/* 349 */         code.add(", $L", new Object[] { generateCode(generic, hasNoNestedGenerics) });
/*     */       } 
/* 351 */       code.add(")", new Object[0]);
/* 352 */       return code.build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ArrayDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator codeGenerator, Object value) {
/* 365 */       if (value.getClass().isArray()) {
/*     */         
/* 367 */         Objects.requireNonNull(codeGenerator); Stream<CodeBlock> elements = Arrays.<Object>stream(ObjectUtils.toObjectArray(value)).map(codeGenerator::generateCode);
/* 368 */         CodeBlock.Builder code = CodeBlock.builder();
/* 369 */         code.add("new $T {", new Object[] { value.getClass() });
/* 370 */         code.add(elements.collect(CodeBlock.joining(", ")));
/* 371 */         code.add("}", new Object[0]);
/* 372 */         return code.build();
/*     */       } 
/* 374 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ListDelegate
/*     */     extends CollectionDelegate<List<?>>
/*     */   {
/*     */     ListDelegate() {
/* 385 */       super(List.class, CodeBlock.of("$T.emptyList()", new Object[] { Collections.class }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SetDelegate
/*     */     extends CollectionDelegate<Set<?>>
/*     */   {
/*     */     SetDelegate() {
/* 396 */       super(Set.class, CodeBlock.of("$T.emptySet()", new Object[] { Collections.class }));
/*     */     }
/*     */ 
/*     */     
/*     */     protected CodeBlock generateCollectionCode(ValueCodeGenerator valueCodeGenerator, Set<?> collection) {
/* 401 */       if (collection instanceof LinkedHashSet) {
/* 402 */         return CodeBlock.of("new $T($L)", new Object[] { LinkedHashSet.class, 
/* 403 */               generateCollectionOf(valueCodeGenerator, collection, List.class) });
/*     */       }
/* 405 */       return super.generateCollectionCode(valueCodeGenerator, 
/* 406 */           orderForCodeConsistency(collection));
/*     */     }
/*     */     
/*     */     private Set<?> orderForCodeConsistency(Set<?> set) {
/*     */       try {
/* 411 */         return new TreeSet(set);
/*     */       }
/* 413 */       catch (ClassCastException ex) {
/*     */         
/* 415 */         return set;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGeneratorDelegates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */