package org.springframework.aot.generate;

import org.springframework.aot.hint.RuntimeHints;

public interface GenerationContext {
  GeneratedClasses getGeneratedClasses();
  
  GeneratedFiles getGeneratedFiles();
  
  RuntimeHints getRuntimeHints();
  
  GenerationContext withName(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\GenerationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */