/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CollectionDelegate<T extends Collection<?>>
/*     */   implements ValueCodeGenerator.Delegate
/*     */ {
/*     */   private final Class<?> collectionType;
/*     */   private final CodeBlock emptyResult;
/*     */   
/*     */   protected CollectionDelegate(Class<?> collectionType, CodeBlock emptyResult) {
/*  91 */     this.collectionType = collectionType;
/*  92 */     this.emptyResult = emptyResult;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/*  99 */     if (this.collectionType.isInstance(value)) {
/* 100 */       Collection collection = (Collection)value;
/* 101 */       if (collection.isEmpty()) {
/* 102 */         return this.emptyResult;
/*     */       }
/* 104 */       return generateCollectionCode(valueCodeGenerator, (T)collection);
/*     */     } 
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   protected CodeBlock generateCollectionCode(ValueCodeGenerator valueCodeGenerator, T collection) {
/* 110 */     return generateCollectionOf(valueCodeGenerator, (Collection<?>)collection, this.collectionType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final CodeBlock generateCollectionOf(ValueCodeGenerator valueCodeGenerator, Collection<?> collection, Class<?> collectionType) {
/* 115 */     CodeBlock.Builder code = CodeBlock.builder();
/* 116 */     code.add("$T.of(", new Object[] { collectionType });
/* 117 */     Iterator<?> iterator = collection.iterator();
/* 118 */     while (iterator.hasNext()) {
/* 119 */       Object element = iterator.next();
/* 120 */       code.add("$L", new Object[] { valueCodeGenerator.generateCode(element) });
/* 121 */       if (iterator.hasNext()) {
/* 122 */         code.add(", ", new Object[0]);
/*     */       }
/*     */     } 
/* 125 */     code.add(")", new Object[0]);
/* 126 */     return code.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGeneratorDelegates$CollectionDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */