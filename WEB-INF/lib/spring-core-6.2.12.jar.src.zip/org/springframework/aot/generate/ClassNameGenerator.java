/*     */ package org.springframework.aot.generate;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassNameGenerator
/*     */ {
/*     */   private static final String SEPARATOR = "__";
/*     */   private static final String AOT_FEATURE = "Aot";
/*     */   private final ClassName defaultTarget;
/*     */   private final String featureNamePrefix;
/*     */   private final Map<String, AtomicInteger> sequenceGenerator;
/*     */   
/*     */   public ClassNameGenerator(ClassName defaultTarget) {
/*  59 */     this(defaultTarget, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassNameGenerator(ClassName defaultTarget, String featureNamePrefix) {
/*  69 */     this(defaultTarget, featureNamePrefix, new ConcurrentHashMap<>());
/*     */   }
/*     */ 
/*     */   
/*     */   private ClassNameGenerator(ClassName defaultTarget, String featureNamePrefix, Map<String, AtomicInteger> sequenceGenerator) {
/*  74 */     Assert.notNull(defaultTarget, "'defaultTarget' must not be null");
/*  75 */     this.defaultTarget = defaultTarget;
/*  76 */     this.featureNamePrefix = !StringUtils.hasText(featureNamePrefix) ? "" : featureNamePrefix;
/*  77 */     this.sequenceGenerator = sequenceGenerator;
/*     */   }
/*     */   
/*     */   String getFeatureNamePrefix() {
/*  81 */     return this.featureNamePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassName generateClassName(String featureName, @Nullable ClassName target) {
/* 102 */     return generateSequencedClassName(getRootName(featureName, target));
/*     */   }
/*     */   
/*     */   private String getRootName(String featureName, @Nullable ClassName target) {
/* 106 */     Assert.hasLength(featureName, "'featureName' must not be empty");
/* 107 */     featureName = clean(featureName);
/* 108 */     ClassName targetToUse = (target != null) ? target : this.defaultTarget;
/* 109 */     String featureNameToUse = this.featureNamePrefix + this.featureNamePrefix;
/* 110 */     return toName(targetToUse).replace("$", "_") + "__" + toName(targetToUse).replace("$", "_");
/*     */   }
/*     */   
/*     */   private String clean(String name) {
/* 114 */     StringBuilder clean = new StringBuilder();
/* 115 */     boolean lastNotLetter = true;
/* 116 */     for (char ch : name.toCharArray()) {
/* 117 */       if (!Character.isLetter(ch)) {
/* 118 */         lastNotLetter = true;
/*     */       } else {
/*     */         
/* 121 */         clean.append(lastNotLetter ? Character.toUpperCase(ch) : ch);
/* 122 */         lastNotLetter = false;
/*     */       } 
/* 124 */     }  return !clean.isEmpty() ? clean.toString() : "Aot";
/*     */   }
/*     */ 
/*     */   
/*     */   private ClassName generateSequencedClassName(String name) {
/* 129 */     int sequence = ((AtomicInteger)this.sequenceGenerator.computeIfAbsent(name, key -> new AtomicInteger())).getAndIncrement();
/* 130 */     if (sequence > 0) {
/* 131 */       name = name + name;
/*     */     }
/* 133 */     return ClassName.get(ClassUtils.getPackageName(name), 
/* 134 */         ClassUtils.getShortName(name), new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ClassNameGenerator withFeatureNamePrefix(String featureNamePrefix) {
/* 146 */     return new ClassNameGenerator(this.defaultTarget, featureNamePrefix, this.sequenceGenerator);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toName(ClassName className) {
/* 151 */     return GeneratedTypeReference.of(className).getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ClassNameGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */