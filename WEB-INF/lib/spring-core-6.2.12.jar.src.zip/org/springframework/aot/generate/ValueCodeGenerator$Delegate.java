package org.springframework.aot.generate;

import org.springframework.javapoet.CodeBlock;
import org.springframework.lang.Nullable;

public interface Delegate {
  @Nullable
  CodeBlock generateCode(ValueCodeGenerator paramValueCodeGenerator, Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\ValueCodeGenerator$Delegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */