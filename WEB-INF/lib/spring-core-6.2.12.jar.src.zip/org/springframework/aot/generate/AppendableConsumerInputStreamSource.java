/*    */ package org.springframework.aot.generate;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.springframework.core.io.InputStreamSource;
/*    */ import org.springframework.util.function.ThrowingConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AppendableConsumerInputStreamSource
/*    */   implements InputStreamSource
/*    */ {
/*    */   private final ThrowingConsumer<Appendable> content;
/*    */   
/*    */   AppendableConsumerInputStreamSource(ThrowingConsumer<Appendable> content) {
/* 39 */     this.content = content;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() {
/* 45 */     return new ByteArrayInputStream(toString().getBytes(StandardCharsets.UTF_8));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     StringBuilder buffer = new StringBuilder();
/* 51 */     this.content.accept(buffer);
/* 52 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\aot\generate\AppendableConsumerInputStreamSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */