package org.springframework.cglib;

public final class SpringCglibInfo {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\SpringCglibInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */