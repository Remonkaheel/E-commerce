/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.Converter;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BeanCopier
/*     */ {
/*  45 */   private static final BeanCopierKey KEY_FACTORY = (BeanCopierKey)KeyFactory.create(BeanCopierKey.class);
/*     */   
/*  47 */   private static final Type CONVERTER = TypeUtils.parseType("org.springframework.cglib.core.Converter");
/*     */   
/*  49 */   private static final Type BEAN_COPIER = TypeUtils.parseType("org.springframework.cglib.beans.BeanCopier");
/*  50 */   private static final Signature COPY = new Signature("copy", Type.VOID_TYPE, new Type[] { Constants.TYPE_OBJECT, Constants.TYPE_OBJECT, CONVERTER });
/*     */ 
/*     */   
/*  53 */   private static final Signature CONVERT = TypeUtils.parseSignature("Object convert(Object, Class, Object)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanCopier create(Class source, Class target, boolean useConverter) {
/*  60 */     Generator gen = new Generator();
/*  61 */     gen.setSource(source);
/*  62 */     gen.setTarget(target);
/*  63 */     gen.setUseConverter(useConverter);
/*  64 */     return gen.create();
/*     */   }
/*     */   
/*     */   public abstract void copy(Object paramObject1, Object paramObject2, Converter paramConverter);
/*     */   
/*     */   public static class Generator extends AbstractClassGenerator {
/*  70 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(BeanCopier.class.getName());
/*     */     private Class source;
/*     */     private Class target;
/*     */     private boolean useConverter;
/*     */     
/*     */     public Generator() {
/*  76 */       super(SOURCE);
/*     */     }
/*     */     
/*     */     public void setSource(Class source) {
/*  80 */       this.source = source;
/*     */       
/*  82 */       setContextClass(source);
/*  83 */       setNamePrefix(source.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     public void setTarget(Class target) {
/*  88 */       this.target = target;
/*     */       
/*  90 */       setContextClass(target);
/*  91 */       setNamePrefix(target.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     public void setUseConverter(boolean useConverter) {
/*  96 */       this.useConverter = useConverter;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 101 */       return this.source.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/* 106 */       return ReflectUtils.getProtectionDomain(this.source);
/*     */     }
/*     */     
/*     */     public BeanCopier create() {
/* 110 */       Object key = BeanCopier.KEY_FACTORY.newInstance(this.source.getName(), this.target.getName(), this.useConverter);
/* 111 */       return (BeanCopier)create(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) {
/* 116 */       Type sourceType = Type.getType(this.source);
/* 117 */       Type targetType = Type.getType(this.target);
/* 118 */       ClassEmitter ce = new ClassEmitter(v);
/* 119 */       ce.begin_class(52, 1, 
/*     */           
/* 121 */           getClassName(), BeanCopier.BEAN_COPIER, null, "<generated>");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       EmitUtils.null_constructor(ce);
/* 127 */       CodeEmitter e = ce.begin_method(1, BeanCopier.COPY, null);
/* 128 */       PropertyDescriptor[] getters = ReflectUtils.getBeanGetters(this.source);
/* 129 */       PropertyDescriptor[] setters = ReflectUtils.getBeanSetters(this.target);
/*     */       
/* 131 */       Map<Object, Object> names = new HashMap<>();
/* 132 */       for (PropertyDescriptor getter : getters) {
/* 133 */         names.put(getter.getName(), getter);
/*     */       }
/* 135 */       Local targetLocal = e.make_local();
/* 136 */       Local sourceLocal = e.make_local();
/* 137 */       if (this.useConverter) {
/* 138 */         e.load_arg(1);
/* 139 */         e.checkcast(targetType);
/* 140 */         e.store_local(targetLocal);
/* 141 */         e.load_arg(0);
/* 142 */         e.checkcast(sourceType);
/* 143 */         e.store_local(sourceLocal);
/*     */       } else {
/* 145 */         e.load_arg(1);
/* 146 */         e.checkcast(targetType);
/* 147 */         e.load_arg(0);
/* 148 */         e.checkcast(sourceType);
/*     */       } 
/* 150 */       for (PropertyDescriptor setter : setters) {
/* 151 */         PropertyDescriptor getter = (PropertyDescriptor)names.get(setter.getName());
/* 152 */         if (getter != null) {
/* 153 */           MethodInfo read = ReflectUtils.getMethodInfo(getter.getReadMethod());
/* 154 */           MethodInfo write = ReflectUtils.getMethodInfo(setter.getWriteMethod());
/* 155 */           if (this.useConverter) {
/* 156 */             Type setterType = write.getSignature().getArgumentTypes()[0];
/* 157 */             e.load_local(targetLocal);
/* 158 */             e.load_arg(2);
/* 159 */             e.load_local(sourceLocal);
/* 160 */             e.invoke(read);
/* 161 */             e.box(read.getSignature().getReturnType());
/* 162 */             EmitUtils.load_class(e, setterType);
/* 163 */             e.push(write.getSignature().getName());
/* 164 */             e.invoke_interface(BeanCopier.CONVERTER, BeanCopier.CONVERT);
/* 165 */             e.unbox_or_zero(setterType);
/* 166 */             e.invoke(write);
/* 167 */           } else if (compatible(getter, setter)) {
/* 168 */             e.dup2();
/* 169 */             e.invoke(read);
/* 170 */             e.invoke(write);
/*     */           } 
/*     */         } 
/*     */       } 
/* 174 */       e.return_value();
/* 175 */       e.end_method();
/* 176 */       ce.end_class();
/*     */     }
/*     */ 
/*     */     
/*     */     private static boolean compatible(PropertyDescriptor getter, PropertyDescriptor setter) {
/* 181 */       return setter.getPropertyType().isAssignableFrom(getter.getPropertyType());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 186 */       return ReflectUtils.newInstance(type);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 191 */       return instance;
/*     */     }
/*     */   }
/*     */   
/*     */   static interface BeanCopierKey {
/*     */     Object newInstance(String param1String1, String param1String2, boolean param1Boolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanCopier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */