/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  56 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(ImmutableBean.class.getName());
/*     */   private Object bean;
/*     */   private Class target;
/*     */   
/*     */   public Generator() {
/*  61 */     super(SOURCE);
/*     */   }
/*     */   
/*     */   public void setBean(Object bean) {
/*  65 */     this.bean = bean;
/*  66 */     this.target = bean.getClass();
/*     */     
/*  68 */     setContextClass(this.target);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/*  74 */     return this.target.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/*  79 */     return ReflectUtils.getProtectionDomain(this.target);
/*     */   }
/*     */   
/*     */   public Object create() {
/*  83 */     String name = this.target.getName();
/*  84 */     setNamePrefix(name);
/*  85 */     return create(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) {
/*  90 */     Type targetType = Type.getType(this.target);
/*  91 */     ClassEmitter ce = new ClassEmitter(v);
/*  92 */     ce.begin_class(52, 1, 
/*     */         
/*  94 */         getClassName(), targetType, null, "<generated>");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     ce.declare_field(18, "CGLIB$RWBean", targetType, null);
/*     */     
/* 101 */     CodeEmitter e = ce.begin_method(1, ImmutableBean.CSTRUCT_OBJECT, null);
/* 102 */     e.load_this();
/* 103 */     e.super_invoke_constructor();
/* 104 */     e.load_this();
/* 105 */     e.load_arg(0);
/* 106 */     e.checkcast(targetType);
/* 107 */     e.putfield("CGLIB$RWBean");
/* 108 */     e.return_value();
/* 109 */     e.end_method();
/*     */     
/* 111 */     PropertyDescriptor[] descriptors = ReflectUtils.getBeanProperties(this.target);
/* 112 */     Method[] getters = ReflectUtils.getPropertyMethods(descriptors, true, false);
/* 113 */     Method[] setters = ReflectUtils.getPropertyMethods(descriptors, false, true);
/*     */     
/* 115 */     for (Method getter2 : getters) {
/* 116 */       MethodInfo getter = ReflectUtils.getMethodInfo(getter2);
/* 117 */       e = EmitUtils.begin_method(ce, getter, 1);
/* 118 */       e.load_this();
/* 119 */       e.getfield("CGLIB$RWBean");
/* 120 */       e.invoke(getter);
/* 121 */       e.return_value();
/* 122 */       e.end_method();
/*     */     } 
/*     */     
/* 125 */     for (Method setter2 : setters) {
/* 126 */       MethodInfo setter = ReflectUtils.getMethodInfo(setter2);
/* 127 */       e = EmitUtils.begin_method(ce, setter, 1);
/* 128 */       e.throw_exception(ImmutableBean.ILLEGAL_STATE_EXCEPTION, "Bean is immutable");
/* 129 */       e.end_method();
/*     */     } 
/*     */     
/* 132 */     ce.end_class();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 137 */     return ReflectUtils.newInstance(type, ImmutableBean.OBJECT_CLASSES, new Object[] { this.bean });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 143 */     return firstInstance(instance.getClass());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\ImmutableBean$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */