/*    */ package org.springframework.cglib.beans;
/*    */ 
/*    */ import java.util.AbstractSet;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedKeySet
/*    */   extends AbstractSet
/*    */ {
/*    */   private Set set;
/*    */   private int size;
/*    */   
/*    */   public FixedKeySet(String[] keys) {
/* 31 */     this.size = keys.length;
/* 32 */     this.set = Collections.unmodifiableSet(new HashSet(Arrays.asList((Object[])keys)));
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator iterator() {
/* 37 */     return this.set.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 42 */     return this.size;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\FixedKeySet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */