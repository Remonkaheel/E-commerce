package org.springframework.cglib.beans;

interface BeanMapKey {
  Object newInstance(Class paramClass, int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanMap$Generator$BeanMapKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */