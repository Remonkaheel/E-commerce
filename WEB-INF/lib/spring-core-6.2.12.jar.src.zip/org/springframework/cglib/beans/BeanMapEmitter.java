/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanMapEmitter
/*     */   extends ClassEmitter
/*     */ {
/*  39 */   private static final Type BEAN_MAP = TypeUtils.parseType("org.springframework.cglib.beans.BeanMap");
/*     */   
/*  41 */   private static final Type FIXED_KEY_SET = TypeUtils.parseType("org.springframework.cglib.beans.FixedKeySet");
/*     */   
/*  43 */   private static final Signature CSTRUCT_OBJECT = TypeUtils.parseConstructor("Object");
/*     */   
/*  45 */   private static final Signature CSTRUCT_STRING_ARRAY = TypeUtils.parseConstructor("String[]");
/*     */   
/*  47 */   private static final Signature BEAN_MAP_GET = TypeUtils.parseSignature("Object get(Object, Object)");
/*     */   
/*  49 */   private static final Signature BEAN_MAP_PUT = TypeUtils.parseSignature("Object put(Object, Object, Object)");
/*     */   
/*  51 */   private static final Signature KEY_SET = TypeUtils.parseSignature("java.util.Set keySet()");
/*  52 */   private static final Signature NEW_INSTANCE = new Signature("newInstance", BEAN_MAP, new Type[] { Constants.TYPE_OBJECT });
/*     */ 
/*     */   
/*  55 */   private static final Signature GET_PROPERTY_TYPE = TypeUtils.parseSignature("Class getPropertyType(String)");
/*     */   
/*     */   public BeanMapEmitter(ClassVisitor v, String className, Class type, int require) {
/*  58 */     super(v);
/*     */     
/*  60 */     begin_class(52, 1, className, BEAN_MAP, null, "<generated>");
/*  61 */     EmitUtils.null_constructor(this);
/*  62 */     EmitUtils.factory_method(this, NEW_INSTANCE);
/*  63 */     generateConstructor();
/*     */     
/*  65 */     Map<?, ?> getters = makePropertyMap(ReflectUtils.getBeanGetters(type));
/*  66 */     Map<?, ?> setters = makePropertyMap(ReflectUtils.getBeanSetters(type));
/*  67 */     Map<Object, Object> allProps = new HashMap<>();
/*  68 */     allProps.putAll(getters);
/*  69 */     allProps.putAll(setters);
/*     */     
/*  71 */     if (require != 0) {
/*  72 */       for (Iterator<String> it = allProps.keySet().iterator(); it.hasNext(); ) {
/*  73 */         String name = it.next();
/*  74 */         if (((require & 0x1) != 0 && !getters.containsKey(name)) || ((require & 0x2) != 0 && 
/*  75 */           !setters.containsKey(name))) {
/*  76 */           it.remove();
/*  77 */           getters.remove(name);
/*  78 */           setters.remove(name);
/*     */         } 
/*     */       } 
/*     */     }
/*  82 */     generateGet(type, getters);
/*  83 */     generatePut(type, setters);
/*     */     
/*  85 */     String[] allNames = getNames(allProps);
/*  86 */     generateKeySet(allNames);
/*  87 */     generateGetPropertyType(allProps, allNames);
/*  88 */     end_class();
/*     */   }
/*     */   
/*     */   private Map makePropertyMap(PropertyDescriptor[] props) {
/*  92 */     Map<Object, Object> names = new HashMap<>();
/*  93 */     for (PropertyDescriptor prop : props) {
/*  94 */       names.put(prop.getName(), prop);
/*     */     }
/*  96 */     return names;
/*     */   }
/*     */   
/*     */   private String[] getNames(Map propertyMap) {
/* 100 */     return (String[])propertyMap.keySet().toArray((Object[])new String[propertyMap.size()]);
/*     */   }
/*     */   
/*     */   private void generateConstructor() {
/* 104 */     CodeEmitter e = begin_method(1, CSTRUCT_OBJECT, null);
/* 105 */     e.load_this();
/* 106 */     e.load_arg(0);
/* 107 */     e.super_invoke_constructor(CSTRUCT_OBJECT);
/* 108 */     e.return_value();
/* 109 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void generateGet(Class type, final Map getters) {
/* 113 */     final CodeEmitter e = begin_method(1, BEAN_MAP_GET, null);
/* 114 */     e.load_arg(0);
/* 115 */     e.checkcast(Type.getType(type));
/* 116 */     e.load_arg(1);
/* 117 */     e.checkcast(Constants.TYPE_STRING);
/* 118 */     EmitUtils.string_switch(e, getNames(getters), 1, new ObjectSwitchCallback()
/*     */         {
/*     */           public void processCase(Object key, Label end) {
/* 121 */             PropertyDescriptor pd = (PropertyDescriptor)getters.get(key);
/* 122 */             MethodInfo method = ReflectUtils.getMethodInfo(pd.getReadMethod());
/* 123 */             e.invoke(method);
/* 124 */             e.box(method.getSignature().getReturnType());
/* 125 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 129 */             e.aconst_null();
/* 130 */             e.return_value();
/*     */           }
/*     */         });
/* 133 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void generatePut(Class type, final Map setters) {
/* 137 */     final CodeEmitter e = begin_method(1, BEAN_MAP_PUT, null);
/* 138 */     e.load_arg(0);
/* 139 */     e.checkcast(Type.getType(type));
/* 140 */     e.load_arg(1);
/* 141 */     e.checkcast(Constants.TYPE_STRING);
/* 142 */     EmitUtils.string_switch(e, getNames(setters), 1, new ObjectSwitchCallback()
/*     */         {
/*     */           public void processCase(Object key, Label end) {
/* 145 */             PropertyDescriptor pd = (PropertyDescriptor)setters.get(key);
/* 146 */             if (pd.getReadMethod() == null) {
/* 147 */               e.aconst_null();
/*     */             } else {
/* 149 */               MethodInfo read = ReflectUtils.getMethodInfo(pd.getReadMethod());
/* 150 */               e.dup();
/* 151 */               e.invoke(read);
/* 152 */               e.box(read.getSignature().getReturnType());
/*     */             } 
/* 154 */             e.swap();
/* 155 */             e.load_arg(2);
/* 156 */             MethodInfo write = ReflectUtils.getMethodInfo(pd.getWriteMethod());
/* 157 */             e.unbox(write.getSignature().getArgumentTypes()[0]);
/* 158 */             e.invoke(write);
/* 159 */             e.return_value();
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void processDefault() {}
/*     */         });
/* 166 */     e.aconst_null();
/* 167 */     e.return_value();
/* 168 */     e.end_method();
/*     */   }
/*     */ 
/*     */   
/*     */   private void generateKeySet(String[] allNames) {
/* 173 */     declare_field(10, "keys", FIXED_KEY_SET, null);
/*     */     
/* 175 */     CodeEmitter e = begin_static();
/* 176 */     e.new_instance(FIXED_KEY_SET);
/* 177 */     e.dup();
/* 178 */     EmitUtils.push_array(e, (Object[])allNames);
/* 179 */     e.invoke_constructor(FIXED_KEY_SET, CSTRUCT_STRING_ARRAY);
/* 180 */     e.putfield("keys");
/* 181 */     e.return_value();
/* 182 */     e.end_method();
/*     */ 
/*     */     
/* 185 */     e = begin_method(1, KEY_SET, null);
/* 186 */     e.load_this();
/* 187 */     e.getfield("keys");
/* 188 */     e.return_value();
/* 189 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void generateGetPropertyType(final Map allProps, String[] allNames) {
/* 193 */     final CodeEmitter e = begin_method(1, GET_PROPERTY_TYPE, null);
/* 194 */     e.load_arg(0);
/* 195 */     EmitUtils.string_switch(e, allNames, 1, new ObjectSwitchCallback()
/*     */         {
/*     */           public void processCase(Object key, Label end) {
/* 198 */             PropertyDescriptor pd = (PropertyDescriptor)allProps.get(key);
/* 199 */             EmitUtils.load_class(e, Type.getType(pd.getPropertyType()));
/* 200 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 204 */             e.aconst_null();
/* 205 */             e.return_value();
/*     */           }
/*     */         });
/* 208 */     e.end_method();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanMapEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */