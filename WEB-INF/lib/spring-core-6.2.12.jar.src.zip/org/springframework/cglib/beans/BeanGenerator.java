/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanGenerator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  39 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(BeanGenerator.class.getName());
/*     */   
/*  41 */   private static final BeanGeneratorKey KEY_FACTORY = (BeanGeneratorKey)KeyFactory.create(BeanGeneratorKey.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private Class superclass;
/*     */ 
/*     */   
/*  48 */   private Map props = new HashMap<>();
/*     */   private boolean classOnly;
/*     */   
/*     */   public BeanGenerator() {
/*  52 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuperclass(Class superclass) {
/*  62 */     if (superclass != null && superclass.equals(Object.class)) {
/*  63 */       superclass = null;
/*     */     }
/*  65 */     this.superclass = superclass;
/*     */     
/*  67 */     setContextClass(superclass);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addProperty(String name, Class type) {
/*  72 */     if (this.props.containsKey(name)) {
/*  73 */       throw new IllegalArgumentException("Duplicate property name \"" + name + "\"");
/*     */     }
/*  75 */     this.props.put(name, Type.getType(type));
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/*  80 */     if (this.superclass != null) {
/*  81 */       return this.superclass.getClassLoader();
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/*  89 */     return ReflectUtils.getProtectionDomain(this.superclass);
/*     */   }
/*     */   
/*     */   public Object create() {
/*  93 */     this.classOnly = false;
/*  94 */     return createHelper();
/*     */   }
/*     */   
/*     */   public Object createClass() {
/*  98 */     this.classOnly = true;
/*  99 */     return createHelper();
/*     */   }
/*     */   
/*     */   private Object createHelper() {
/* 103 */     if (this.superclass != null) {
/* 104 */       setNamePrefix(this.superclass.getName());
/*     */     }
/* 106 */     String superName = (this.superclass != null) ? this.superclass.getName() : "java.lang.Object";
/* 107 */     Object key = KEY_FACTORY.newInstance(superName, this.props);
/* 108 */     return create(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) throws Exception {
/* 113 */     int size = this.props.size();
/* 114 */     String[] names = (String[])this.props.keySet().toArray((Object[])new String[size]);
/* 115 */     Type[] types = new Type[size];
/* 116 */     for (int i = 0; i < size; i++) {
/* 117 */       types[i] = (Type)this.props.get(names[i]);
/*     */     }
/* 119 */     ClassEmitter ce = new ClassEmitter(v);
/* 120 */     ce.begin_class(52, 1, 
/*     */         
/* 122 */         getClassName(), 
/* 123 */         (this.superclass != null) ? Type.getType(this.superclass) : Constants.TYPE_OBJECT, null, null);
/*     */ 
/*     */     
/* 126 */     EmitUtils.null_constructor(ce);
/* 127 */     EmitUtils.add_properties(ce, names, types);
/* 128 */     ce.end_class();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 133 */     if (this.classOnly) {
/* 134 */       return type;
/*     */     }
/* 136 */     return ReflectUtils.newInstance(type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 142 */     Class<?> clazz = (Class)instance, protoclass = (instance instanceof Class) ? clazz : instance.getClass();
/* 143 */     if (this.classOnly) {
/* 144 */       return protoclass;
/*     */     }
/* 146 */     return ReflectUtils.newInstance(protoclass);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addProperties(BeanGenerator gen, Map props) {
/* 151 */     for (Iterator<String> it = props.keySet().iterator(); it.hasNext(); ) {
/* 152 */       String name = it.next();
/* 153 */       gen.addProperty(name, (Class)props.get(name));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void addProperties(BeanGenerator gen, Class type) {
/* 158 */     addProperties(gen, ReflectUtils.getBeanProperties(type));
/*     */   }
/*     */   
/*     */   public static void addProperties(BeanGenerator gen, PropertyDescriptor[] descriptors) {
/* 162 */     for (PropertyDescriptor descriptor : descriptors)
/* 163 */       gen.addProperty(descriptor.getName(), descriptor.getPropertyType()); 
/*     */   }
/*     */   
/*     */   static interface BeanGeneratorKey {
/*     */     Object newInstance(String param1String, Map param1Map);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */