/*    */ package org.springframework.cglib.beans;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BulkBeanException
/*    */   extends RuntimeException
/*    */ {
/*    */   private int index;
/*    */   private Throwable cause;
/*    */   
/*    */   public BulkBeanException(String message, int index) {
/* 25 */     super(message);
/* 26 */     this.index = index;
/*    */   }
/*    */   
/*    */   public BulkBeanException(Throwable cause, int index) {
/* 30 */     super(cause.getMessage());
/* 31 */     this.index = index;
/* 32 */     this.cause = cause;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 36 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable getCause() {
/* 41 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BulkBeanException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */