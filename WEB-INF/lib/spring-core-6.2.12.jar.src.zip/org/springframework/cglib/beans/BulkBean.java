/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BulkBean
/*     */ {
/*  32 */   private static final BulkBeanKey KEY_FACTORY = (BulkBeanKey)KeyFactory.create(BulkBeanKey.class);
/*     */   
/*     */   protected Class target;
/*     */   
/*     */   protected String[] getters;
/*     */   
/*     */   protected String[] setters;
/*     */   
/*     */   protected Class[] types;
/*     */ 
/*     */   
/*     */   public abstract void getPropertyValues(Object paramObject, Object[] paramArrayOfObject);
/*     */   
/*     */   public abstract void setPropertyValues(Object paramObject, Object[] paramArrayOfObject);
/*     */   
/*     */   public Object[] getPropertyValues(Object bean) {
/*  48 */     Object[] values = new Object[this.getters.length];
/*  49 */     getPropertyValues(bean, values);
/*  50 */     return values;
/*     */   }
/*     */   
/*     */   public Class[] getPropertyTypes() {
/*  54 */     return (Class[])this.types.clone();
/*     */   }
/*     */   
/*     */   public String[] getGetters() {
/*  58 */     return (String[])this.getters.clone();
/*     */   }
/*     */   
/*     */   public String[] getSetters() {
/*  62 */     return (String[])this.setters.clone();
/*     */   }
/*     */   
/*     */   public static BulkBean create(Class target, String[] getters, String[] setters, Class[] types) {
/*  66 */     Generator gen = new Generator();
/*  67 */     gen.setTarget(target);
/*  68 */     gen.setGetters(getters);
/*  69 */     gen.setSetters(setters);
/*  70 */     gen.setTypes(types);
/*  71 */     return gen.create();
/*     */   }
/*     */   
/*     */   public static class Generator extends AbstractClassGenerator {
/*  75 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(BulkBean.class.getName());
/*     */     private Class target;
/*     */     private String[] getters;
/*     */     private String[] setters;
/*     */     private Class[] types;
/*     */     
/*     */     public Generator() {
/*  82 */       super(SOURCE);
/*     */     }
/*     */     
/*     */     public void setTarget(Class target) {
/*  86 */       this.target = target;
/*     */       
/*  88 */       setContextClass(target);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setGetters(String[] getters) {
/*  93 */       this.getters = getters;
/*     */     }
/*     */     
/*     */     public void setSetters(String[] setters) {
/*  97 */       this.setters = setters;
/*     */     }
/*     */     
/*     */     public void setTypes(Class[] types) {
/* 101 */       this.types = types;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 106 */       return this.target.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/* 111 */       return ReflectUtils.getProtectionDomain(this.target);
/*     */     }
/*     */     
/*     */     public BulkBean create() {
/* 115 */       setNamePrefix(this.target.getName());
/* 116 */       String targetClassName = this.target.getName();
/* 117 */       String[] typeClassNames = ReflectUtils.getNames(this.types);
/* 118 */       Object key = BulkBean.KEY_FACTORY.newInstance(targetClassName, this.getters, this.setters, typeClassNames);
/* 119 */       return (BulkBean)create(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) throws Exception {
/* 124 */       new BulkBeanEmitter(v, getClassName(), this.target, this.getters, this.setters, this.types);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 129 */       BulkBean instance = (BulkBean)ReflectUtils.newInstance(type);
/* 130 */       instance.target = this.target;
/*     */       
/* 132 */       int length = this.getters.length;
/* 133 */       instance.getters = new String[length];
/* 134 */       System.arraycopy(this.getters, 0, instance.getters, 0, length);
/*     */       
/* 136 */       instance.setters = new String[length];
/* 137 */       System.arraycopy(this.setters, 0, instance.setters, 0, length);
/*     */       
/* 139 */       instance.types = new Class[this.types.length];
/* 140 */       System.arraycopy(this.types, 0, instance.types, 0, this.types.length);
/*     */       
/* 142 */       return instance;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 147 */       return instance;
/*     */     }
/*     */   }
/*     */   
/*     */   static interface BulkBeanKey {
/*     */     Object newInstance(String param1String, String[] param1ArrayOfString1, String[] param1ArrayOfString2, String[] param1ArrayOfString3);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BulkBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */