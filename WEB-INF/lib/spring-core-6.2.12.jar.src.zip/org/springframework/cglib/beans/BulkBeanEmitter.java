/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.Block;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BulkBeanEmitter
/*     */   extends ClassEmitter
/*     */ {
/*  37 */   private static final Signature GET_PROPERTY_VALUES = TypeUtils.parseSignature("void getPropertyValues(Object, Object[])");
/*     */   
/*  39 */   private static final Signature SET_PROPERTY_VALUES = TypeUtils.parseSignature("void setPropertyValues(Object, Object[])");
/*     */   
/*  41 */   private static final Signature CSTRUCT_EXCEPTION = TypeUtils.parseConstructor("Throwable, int");
/*     */   
/*  43 */   private static final Type BULK_BEAN = TypeUtils.parseType("org.springframework.cglib.beans.BulkBean");
/*     */   
/*  45 */   private static final Type BULK_BEAN_EXCEPTION = TypeUtils.parseType("org.springframework.cglib.beans.BulkBeanException");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BulkBeanEmitter(ClassVisitor v, String className, Class target, String[] getterNames, String[] setterNames, Class[] types) {
/*  53 */     super(v);
/*     */     
/*  55 */     Method[] getters = new Method[getterNames.length];
/*  56 */     Method[] setters = new Method[setterNames.length];
/*  57 */     validate(target, getterNames, setterNames, types, getters, setters);
/*     */     
/*  59 */     begin_class(52, 1, className, BULK_BEAN, null, "<generated>");
/*  60 */     EmitUtils.null_constructor(this);
/*  61 */     generateGet(target, getters);
/*  62 */     generateSet(target, setters);
/*  63 */     end_class();
/*     */   }
/*     */   
/*     */   private void generateGet(Class target, Method[] getters) {
/*  67 */     CodeEmitter e = begin_method(1, GET_PROPERTY_VALUES, null);
/*  68 */     if (getters.length > 0) {
/*  69 */       e.load_arg(0);
/*  70 */       e.checkcast(Type.getType(target));
/*  71 */       Local bean = e.make_local();
/*  72 */       e.store_local(bean);
/*  73 */       for (int i = 0; i < getters.length; i++) {
/*  74 */         if (getters[i] != null) {
/*  75 */           MethodInfo getter = ReflectUtils.getMethodInfo(getters[i]);
/*  76 */           e.load_arg(1);
/*  77 */           e.push(i);
/*  78 */           e.load_local(bean);
/*  79 */           e.invoke(getter);
/*  80 */           e.box(getter.getSignature().getReturnType());
/*  81 */           e.aastore();
/*     */         } 
/*     */       } 
/*     */     } 
/*  85 */     e.return_value();
/*  86 */     e.end_method();
/*     */   }
/*     */ 
/*     */   
/*     */   private void generateSet(Class target, Method[] setters) {
/*  91 */     CodeEmitter e = begin_method(1, SET_PROPERTY_VALUES, null);
/*  92 */     if (setters.length > 0) {
/*  93 */       Local index = e.make_local(Type.INT_TYPE);
/*  94 */       e.push(0);
/*  95 */       e.store_local(index);
/*  96 */       e.load_arg(0);
/*  97 */       e.checkcast(Type.getType(target));
/*  98 */       e.load_arg(1);
/*  99 */       Block handler = e.begin_block();
/* 100 */       int lastIndex = 0;
/* 101 */       for (int i = 0; i < setters.length; i++) {
/* 102 */         if (setters[i] != null) {
/* 103 */           MethodInfo setter = ReflectUtils.getMethodInfo(setters[i]);
/* 104 */           int diff = i - lastIndex;
/* 105 */           if (diff > 0) {
/* 106 */             e.iinc(index, diff);
/* 107 */             lastIndex = i;
/*     */           } 
/* 109 */           e.dup2();
/* 110 */           e.aaload(i);
/* 111 */           e.unbox(setter.getSignature().getArgumentTypes()[0]);
/* 112 */           e.invoke(setter);
/*     */         } 
/*     */       } 
/* 115 */       handler.end();
/* 116 */       e.return_value();
/* 117 */       e.catch_exception(handler, Constants.TYPE_THROWABLE);
/* 118 */       e.new_instance(BULK_BEAN_EXCEPTION);
/* 119 */       e.dup_x1();
/* 120 */       e.swap();
/* 121 */       e.load_local(index);
/* 122 */       e.invoke_constructor(BULK_BEAN_EXCEPTION, CSTRUCT_EXCEPTION);
/* 123 */       e.athrow();
/*     */     } else {
/* 125 */       e.return_value();
/*     */     } 
/* 127 */     e.end_method();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validate(Class target, String[] getters, String[] setters, Class[] types, Method[] getters_out, Method[] setters_out) {
/* 136 */     int i = -1;
/* 137 */     if (setters.length != types.length || getters.length != types.length) {
/* 138 */       throw new BulkBeanException("accessor array length must be equal type array length", i);
/*     */     }
/*     */     try {
/* 141 */       for (i = 0; i < types.length; i++) {
/* 142 */         if (getters[i] != null) {
/* 143 */           Method method = ReflectUtils.findDeclaredMethod(target, getters[i], null);
/* 144 */           if (method.getReturnType() != types[i]) {
/* 145 */             throw new BulkBeanException("Specified type " + String.valueOf(types[i]) + " does not match declared type " + 
/* 146 */                 String.valueOf(method.getReturnType()), i);
/*     */           }
/* 148 */           if (Modifier.isPrivate(method.getModifiers())) {
/* 149 */             throw new BulkBeanException("Property is private", i);
/*     */           }
/* 151 */           getters_out[i] = method;
/*     */         } 
/* 153 */         if (setters[i] != null) {
/* 154 */           Method method = ReflectUtils.findDeclaredMethod(target, setters[i], new Class[] { types[i] });
/* 155 */           if (Modifier.isPrivate(method.getModifiers())) {
/* 156 */             throw new BulkBeanException("Property is private", i);
/*     */           }
/* 158 */           setters_out[i] = method;
/*     */         } 
/*     */       } 
/* 161 */     } catch (NoSuchMethodException e) {
/* 162 */       throw new BulkBeanException("Cannot find specified property", i);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BulkBeanEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */