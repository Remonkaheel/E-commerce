/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  73 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(BeanMap.class.getName());
/*     */ 
/*     */   
/*  76 */   private static final BeanMapKey KEY_FACTORY = (BeanMapKey)KeyFactory.create(BeanMapKey.class, KeyFactory.CLASS_BY_NAME);
/*     */ 
/*     */   
/*     */   private Object bean;
/*     */   
/*     */   private Class beanClass;
/*     */   
/*     */   private int require;
/*     */ 
/*     */   
/*     */   public Generator() {
/*  87 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBean(Object bean) {
/*  98 */     this.bean = bean;
/*  99 */     if (bean != null) {
/* 100 */       this.beanClass = bean.getClass();
/*     */       
/* 102 */       setContextClass(this.beanClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanClass(Class beanClass) {
/* 113 */     this.beanClass = beanClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequire(int require) {
/* 122 */     this.require = require;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/* 127 */     return this.beanClass.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/* 132 */     return ReflectUtils.getProtectionDomain(this.beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanMap create() {
/* 140 */     if (this.beanClass == null) {
/* 141 */       throw new IllegalArgumentException("Class of bean unknown");
/*     */     }
/* 143 */     setNamePrefix(this.beanClass.getName());
/* 144 */     return (BeanMap)create(KEY_FACTORY.newInstance(this.beanClass, this.require));
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) throws Exception {
/* 149 */     new BeanMapEmitter(v, getClassName(), this.beanClass, this.require);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 154 */     return ((BeanMap)ReflectUtils.newInstance(type)).newInstance(this.bean);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 159 */     return ((BeanMap)instance).newInstance(this.bean);
/*     */   }
/*     */   
/*     */   static interface BeanMapKey {
/*     */     Object newInstance(Class param2Class, int param2Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanMap$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */