package org.springframework.cglib.beans;

interface BeanCopierKey {
  Object newInstance(String paramString1, String paramString2, boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanCopier$BeanCopierKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */