/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BeanMap
/*     */   implements Map
/*     */ {
/*     */   public static final int REQUIRE_GETTER = 1;
/*     */   public static final int REQUIRE_SETTER = 2;
/*     */   protected Object bean;
/*     */   
/*     */   public abstract BeanMap newInstance(Object paramObject);
/*     */   
/*     */   public abstract Class getPropertyType(String paramString);
/*     */   
/*     */   public static BeanMap create(Object bean) {
/*  67 */     Generator gen = new Generator();
/*  68 */     gen.setBean(bean);
/*  69 */     return gen.create();
/*     */   }
/*     */   
/*     */   public static class Generator extends AbstractClassGenerator {
/*  73 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(BeanMap.class.getName());
/*     */ 
/*     */     
/*  76 */     private static final BeanMapKey KEY_FACTORY = (BeanMapKey)KeyFactory.create(BeanMapKey.class, KeyFactory.CLASS_BY_NAME);
/*     */ 
/*     */     
/*     */     private Object bean;
/*     */     
/*     */     private Class beanClass;
/*     */     
/*     */     private int require;
/*     */ 
/*     */     
/*     */     public Generator() {
/*  87 */       super(SOURCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBean(Object bean) {
/*  98 */       this.bean = bean;
/*  99 */       if (bean != null) {
/* 100 */         this.beanClass = bean.getClass();
/*     */         
/* 102 */         setContextClass(this.beanClass);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBeanClass(Class beanClass) {
/* 113 */       this.beanClass = beanClass;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setRequire(int require) {
/* 122 */       this.require = require;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 127 */       return this.beanClass.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/* 132 */       return ReflectUtils.getProtectionDomain(this.beanClass);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BeanMap create() {
/* 140 */       if (this.beanClass == null) {
/* 141 */         throw new IllegalArgumentException("Class of bean unknown");
/*     */       }
/* 143 */       setNamePrefix(this.beanClass.getName());
/* 144 */       return (BeanMap)create(KEY_FACTORY.newInstance(this.beanClass, this.require));
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) throws Exception {
/* 149 */       new BeanMapEmitter(v, getClassName(), this.beanClass, this.require);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 154 */       return ((BeanMap)ReflectUtils.newInstance(type)).newInstance(this.bean);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 159 */       return ((BeanMap)instance).newInstance(this.bean);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static interface BeanMapKey
/*     */     {
/*     */       Object newInstance(Class param2Class, int param2Int);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanMap() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanMap(Object bean) {
/* 184 */     setBean(bean);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 189 */     return get(this.bean, key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 194 */     return put(this.bean, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object get(Object paramObject1, Object paramObject2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object put(Object paramObject1, Object paramObject2, Object paramObject3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBean(Object bean) {
/* 223 */     this.bean = bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBean() {
/* 232 */     return this.bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 237 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 242 */     return keySet().contains(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 247 */     for (Iterator<K> it = keySet().iterator(); it.hasNext(); ) {
/* 248 */       Object v = get(it.next());
/* 249 */       if ((value == null && v == null) || (value != null && value.equals(v))) {
/* 250 */         return true;
/*     */       }
/*     */     } 
/* 253 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 258 */     return keySet().size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 263 */     return (size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 268 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map t) {
/* 273 */     for (Object key : t.keySet()) {
/* 274 */       put(key, t.get(key));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Map other;
/* 280 */     if (o != null && o instanceof Map) { other = (Map)o; }
/* 281 */     else { return false; }
/*     */     
/* 283 */     if (size() != other.size()) {
/* 284 */       return false;
/*     */     }
/* 286 */     for (K key : keySet()) {
/* 287 */       if (!other.containsKey(key)) {
/* 288 */         return false;
/*     */       }
/* 290 */       Object v1 = get(key);
/* 291 */       Object v2 = other.get(key);
/* 292 */       if (!Objects.equals(v1, v2)) {
/* 293 */         return false;
/*     */       }
/*     */     } 
/* 296 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 301 */     int code = 0;
/* 302 */     for (K key : keySet()) {
/* 303 */       Object value = get(key);
/* 304 */       code += ((key == null) ? 0 : key.hashCode()) ^ (
/* 305 */         (value == null) ? 0 : value.hashCode());
/*     */     } 
/* 307 */     return code;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/* 313 */     HashMap<Object, Object> copy = new HashMap<>();
/* 314 */     for (K key : keySet()) {
/* 315 */       copy.put(key, get(key));
/*     */     }
/* 317 */     return Collections.<Object, Object>unmodifiableMap(copy).entrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 322 */     Set<K> keys = keySet();
/* 323 */     List<Object> values = new ArrayList(keys.size());
/* 324 */     for (Iterator<K> it = keys.iterator(); it.hasNext();) {
/* 325 */       values.add(get(it.next()));
/*     */     }
/* 327 */     return Collections.unmodifiableCollection(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 336 */     StringBuilder sb = new StringBuilder();
/* 337 */     sb.append('{');
/* 338 */     for (Iterator<K> it = keySet().iterator(); it.hasNext(); ) {
/* 339 */       Object key = it.next();
/* 340 */       sb.append(key);
/* 341 */       sb.append('=');
/* 342 */       sb.append(get(key));
/* 343 */       if (it.hasNext()) {
/* 344 */         sb.append(", ");
/*     */       }
/*     */     } 
/* 347 */     sb.append('}');
/* 348 */     return sb.toString();
/*     */   }
/*     */   
/*     */   static interface BeanMapKey {
/*     */     Object newInstance(Class param1Class, int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */