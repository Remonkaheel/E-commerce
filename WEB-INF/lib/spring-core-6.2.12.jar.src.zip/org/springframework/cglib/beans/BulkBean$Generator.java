/*     */ package org.springframework.cglib.beans;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  75 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(BulkBean.class.getName());
/*     */   private Class target;
/*     */   private String[] getters;
/*     */   private String[] setters;
/*     */   private Class[] types;
/*     */   
/*     */   public Generator() {
/*  82 */     super(SOURCE);
/*     */   }
/*     */   
/*     */   public void setTarget(Class target) {
/*  86 */     this.target = target;
/*     */     
/*  88 */     setContextClass(target);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGetters(String[] getters) {
/*  93 */     this.getters = getters;
/*     */   }
/*     */   
/*     */   public void setSetters(String[] setters) {
/*  97 */     this.setters = setters;
/*     */   }
/*     */   
/*     */   public void setTypes(Class[] types) {
/* 101 */     this.types = types;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/* 106 */     return this.target.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/* 111 */     return ReflectUtils.getProtectionDomain(this.target);
/*     */   }
/*     */   
/*     */   public BulkBean create() {
/* 115 */     setNamePrefix(this.target.getName());
/* 116 */     String targetClassName = this.target.getName();
/* 117 */     String[] typeClassNames = ReflectUtils.getNames(this.types);
/* 118 */     Object key = BulkBean.KEY_FACTORY.newInstance(targetClassName, this.getters, this.setters, typeClassNames);
/* 119 */     return (BulkBean)create(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) throws Exception {
/* 124 */     new BulkBeanEmitter(v, getClassName(), this.target, this.getters, this.setters, this.types);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 129 */     BulkBean instance = (BulkBean)ReflectUtils.newInstance(type);
/* 130 */     instance.target = this.target;
/*     */     
/* 132 */     int length = this.getters.length;
/* 133 */     instance.getters = new String[length];
/* 134 */     System.arraycopy(this.getters, 0, instance.getters, 0, length);
/*     */     
/* 136 */     instance.setters = new String[length];
/* 137 */     System.arraycopy(this.setters, 0, instance.setters, 0, length);
/*     */     
/* 139 */     instance.types = new Class[this.types.length];
/* 140 */     System.arraycopy(this.types, 0, instance.types, 0, this.types.length);
/*     */     
/* 142 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 147 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BulkBean$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */