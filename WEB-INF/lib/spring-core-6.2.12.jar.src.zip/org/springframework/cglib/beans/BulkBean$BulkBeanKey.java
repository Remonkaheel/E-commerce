package org.springframework.cglib.beans;

interface BulkBeanKey {
  Object newInstance(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BulkBean$BulkBeanKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */