package org.springframework.cglib.beans;

import java.util.Map;

interface BeanGeneratorKey {
  Object newInstance(String paramString, Map paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\beans\BeanGenerator$BeanGeneratorKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */