package org.springframework.cglib.reflect;

interface ConstructorKey {
  Object newInstance(String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\ConstructorDelegate$ConstructorKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */