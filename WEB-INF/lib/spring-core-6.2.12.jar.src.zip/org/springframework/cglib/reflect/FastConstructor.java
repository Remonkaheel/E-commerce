/*    */ package org.springframework.cglib.reflect;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastConstructor
/*    */   extends FastMember
/*    */ {
/*    */   FastConstructor(FastClass fc, Constructor constructor) {
/* 25 */     super(fc, constructor, fc.getIndex(constructor.getParameterTypes()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Class[] getParameterTypes() {
/* 30 */     return ((Constructor)this.member).getParameterTypes();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class[] getExceptionTypes() {
/* 35 */     return ((Constructor)this.member).getExceptionTypes();
/*    */   }
/*    */   
/*    */   public Object newInstance() throws InvocationTargetException {
/* 39 */     return this.fc.newInstance(this.index, (Object[])null);
/*    */   }
/*    */   
/*    */   public Object newInstance(Object[] args) throws InvocationTargetException {
/* 43 */     return this.fc.newInstance(this.index, args);
/*    */   }
/*    */   
/*    */   public Constructor getJavaConstructor() {
/* 47 */     return (Constructor)this.member;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\FastConstructor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */