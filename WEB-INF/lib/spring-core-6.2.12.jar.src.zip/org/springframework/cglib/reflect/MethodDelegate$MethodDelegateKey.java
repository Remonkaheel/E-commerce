package org.springframework.cglib.reflect;

interface MethodDelegateKey {
  Object newInstance(Class paramClass1, String paramString, Class paramClass2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\MethodDelegate$MethodDelegateKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */