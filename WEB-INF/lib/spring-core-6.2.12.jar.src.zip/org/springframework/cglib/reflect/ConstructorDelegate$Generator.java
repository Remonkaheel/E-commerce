/*     */ package org.springframework.cglib.reflect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  57 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(ConstructorDelegate.class.getName());
/*     */   
/*  59 */   private static final Type CONSTRUCTOR_DELEGATE = TypeUtils.parseType("org.springframework.cglib.reflect.ConstructorDelegate");
/*     */   
/*     */   private Class iface;
/*     */   private Class targetClass;
/*     */   
/*     */   public Generator() {
/*  65 */     super(SOURCE);
/*     */   }
/*     */   
/*     */   public void setInterface(Class iface) {
/*  69 */     this.iface = iface;
/*     */   }
/*     */   
/*     */   public void setTargetClass(Class targetClass) {
/*  73 */     this.targetClass = targetClass;
/*     */   }
/*     */   
/*     */   public ConstructorDelegate create() {
/*  77 */     setNamePrefix(this.targetClass.getName());
/*  78 */     Object key = ConstructorDelegate.KEY_FACTORY.newInstance(this.iface.getName(), this.targetClass.getName());
/*  79 */     return (ConstructorDelegate)create(key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/*  84 */     return this.targetClass.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/*  89 */     return ReflectUtils.getProtectionDomain(this.targetClass);
/*     */   }
/*     */   
/*     */   public void generateClass(ClassVisitor v) {
/*     */     Constructor constructor;
/*  94 */     setNamePrefix(this.targetClass.getName());
/*     */     
/*  96 */     Method newInstance = ReflectUtils.findNewInstance(this.iface);
/*  97 */     if (!newInstance.getReturnType().isAssignableFrom(this.targetClass)) {
/*  98 */       throw new IllegalArgumentException("incompatible return type");
/*     */     }
/*     */     
/*     */     try {
/* 102 */       constructor = this.targetClass.getDeclaredConstructor(newInstance.getParameterTypes());
/* 103 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 104 */       throw new IllegalArgumentException("interface does not match any known constructor");
/*     */     } 
/*     */     
/* 107 */     ClassEmitter ce = new ClassEmitter(v);
/* 108 */     ce.begin_class(52, 1, 
/*     */         
/* 110 */         getClassName(), CONSTRUCTOR_DELEGATE, new Type[] {
/*     */           
/* 112 */           Type.getType(this.iface) }, "<generated>");
/*     */     
/* 114 */     Type declaring = Type.getType(constructor.getDeclaringClass());
/* 115 */     EmitUtils.null_constructor(ce);
/* 116 */     CodeEmitter e = ce.begin_method(1, 
/* 117 */         ReflectUtils.getSignature(newInstance), 
/* 118 */         ReflectUtils.getExceptionTypes(newInstance));
/* 119 */     e.new_instance(declaring);
/* 120 */     e.dup();
/* 121 */     e.load_args();
/* 122 */     e.invoke_constructor(declaring, ReflectUtils.getSignature(constructor));
/* 123 */     e.return_value();
/* 124 */     e.end_method();
/* 125 */     ce.end_class();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 130 */     return ReflectUtils.newInstance(type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 135 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\ConstructorDelegate$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */