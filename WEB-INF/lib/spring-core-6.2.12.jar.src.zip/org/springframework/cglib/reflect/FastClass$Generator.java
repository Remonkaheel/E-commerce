/*    */ package org.springframework.cglib.reflect;
/*    */ 
/*    */ import java.security.ProtectionDomain;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.AbstractClassGenerator;
/*    */ import org.springframework.cglib.core.ReflectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Generator
/*    */   extends AbstractClassGenerator
/*    */ {
/* 57 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(FastClass.class.getName());
/*    */   private Class type;
/*    */   
/*    */   public Generator() {
/* 61 */     super(SOURCE);
/*    */   }
/*    */   
/*    */   public void setType(Class type) {
/* 65 */     this.type = type;
/*    */   }
/*    */   
/*    */   public FastClass create() {
/* 69 */     setNamePrefix(this.type.getName());
/* 70 */     return (FastClass)create(this.type.getName());
/*    */   }
/*    */ 
/*    */   
/*    */   protected ClassLoader getDefaultClassLoader() {
/* 75 */     return this.type.getClassLoader();
/*    */   }
/*    */ 
/*    */   
/*    */   protected ProtectionDomain getProtectionDomain() {
/* 80 */     return ReflectUtils.getProtectionDomain(this.type);
/*    */   }
/*    */ 
/*    */   
/*    */   public void generateClass(ClassVisitor v) throws Exception {
/* 85 */     new FastClassEmitter(v, getClassName(), this.type);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object firstInstance(Class type) {
/* 90 */     return ReflectUtils.newInstance(type, new Class[] { Class.class }, new Object[] { this.type });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object nextInstance(Object instance) {
/* 97 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\FastClass$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */