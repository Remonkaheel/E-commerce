/*     */ package org.springframework.cglib.reflect;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  80 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(MulticastDelegate.class.getName());
/*     */   
/*  82 */   private static final Type MULTICAST_DELEGATE = TypeUtils.parseType("org.springframework.cglib.reflect.MulticastDelegate");
/*  83 */   private static final Signature NEW_INSTANCE = new Signature("newInstance", MULTICAST_DELEGATE, new Type[0]);
/*     */   
/*  85 */   private static final Signature ADD_DELEGATE = new Signature("add", MULTICAST_DELEGATE, new Type[] { Constants.TYPE_OBJECT });
/*     */   
/*  87 */   private static final Signature ADD_HELPER = new Signature("addHelper", MULTICAST_DELEGATE, new Type[] { Constants.TYPE_OBJECT });
/*     */   
/*     */   private Class iface;
/*     */ 
/*     */   
/*     */   public Generator() {
/*  93 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/*  98 */     return this.iface.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/* 103 */     return ReflectUtils.getProtectionDomain(this.iface);
/*     */   }
/*     */   
/*     */   public void setInterface(Class iface) {
/* 107 */     this.iface = iface;
/*     */   }
/*     */   
/*     */   public MulticastDelegate create() {
/* 111 */     setNamePrefix(MulticastDelegate.class.getName());
/* 112 */     return (MulticastDelegate)create(this.iface.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor cv) {
/* 117 */     MethodInfo method = ReflectUtils.getMethodInfo(ReflectUtils.findInterfaceMethod(this.iface));
/*     */     
/* 119 */     ClassEmitter ce = new ClassEmitter(cv);
/* 120 */     ce.begin_class(52, 1, 
/*     */         
/* 122 */         getClassName(), MULTICAST_DELEGATE, new Type[] {
/*     */           
/* 124 */           Type.getType(this.iface) }, "<generated>");
/*     */     
/* 126 */     EmitUtils.null_constructor(ce);
/*     */ 
/*     */     
/* 129 */     emitProxy(ce, method);
/*     */ 
/*     */     
/* 132 */     CodeEmitter e = ce.begin_method(1, NEW_INSTANCE, null);
/* 133 */     e.new_instance_this();
/* 134 */     e.dup();
/* 135 */     e.invoke_constructor_this();
/* 136 */     e.return_value();
/* 137 */     e.end_method();
/*     */ 
/*     */     
/* 140 */     e = ce.begin_method(1, ADD_DELEGATE, null);
/* 141 */     e.load_this();
/* 142 */     e.load_arg(0);
/* 143 */     e.checkcast(Type.getType(this.iface));
/* 144 */     e.invoke_virtual_this(ADD_HELPER);
/* 145 */     e.return_value();
/* 146 */     e.end_method();
/*     */     
/* 148 */     ce.end_class();
/*     */   }
/*     */   
/*     */   private void emitProxy(ClassEmitter ce, MethodInfo method) {
/* 152 */     int modifiers = 1;
/* 153 */     if ((method.getModifiers() & 0x80) == 128) {
/* 154 */       modifiers |= 0x80;
/*     */     }
/* 156 */     CodeEmitter e = EmitUtils.begin_method(ce, method, modifiers);
/* 157 */     Type returnType = method.getSignature().getReturnType();
/* 158 */     boolean returns = (returnType != Type.VOID_TYPE);
/* 159 */     Local result = null;
/* 160 */     if (returns) {
/* 161 */       result = e.make_local(returnType);
/* 162 */       e.zero_or_null(returnType);
/* 163 */       e.store_local(result);
/*     */     } 
/* 165 */     e.load_this();
/* 166 */     e.super_getfield("targets", Constants.TYPE_OBJECT_ARRAY);
/* 167 */     Local result2 = result;
/* 168 */     EmitUtils.process_array(e, Constants.TYPE_OBJECT_ARRAY, type -> {
/*     */           e.checkcast(Type.getType(this.iface));
/*     */           e.load_args();
/*     */           e.invoke(method);
/*     */           if (returns) {
/*     */             e.store_local(result2);
/*     */           }
/*     */         });
/* 176 */     if (returns) {
/* 177 */       e.load_local(result);
/*     */     }
/* 179 */     e.return_value();
/* 180 */     e.end_method();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 186 */     return ((MulticastDelegate)ReflectUtils.newInstance(type)).newInstance();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 191 */     return ((MulticastDelegate)instance).newInstance();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\MulticastDelegate$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */