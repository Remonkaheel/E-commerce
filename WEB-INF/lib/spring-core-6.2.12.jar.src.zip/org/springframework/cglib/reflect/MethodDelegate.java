/*     */ package org.springframework.cglib.reflect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MethodDelegate
/*     */ {
/* 121 */   private static final MethodDelegateKey KEY_FACTORY = (MethodDelegateKey)KeyFactory.create(MethodDelegateKey.class, KeyFactory.CLASS_BY_NAME);
/*     */ 
/*     */   
/*     */   protected Object target;
/*     */ 
/*     */   
/*     */   protected String eqMethod;
/*     */ 
/*     */   
/*     */   public static MethodDelegate createStatic(Class targetClass, String methodName, Class iface) {
/* 131 */     Generator gen = new Generator();
/* 132 */     gen.setTargetClass(targetClass);
/* 133 */     gen.setMethodName(methodName);
/* 134 */     gen.setInterface(iface);
/* 135 */     return gen.create();
/*     */   }
/*     */   
/*     */   public static MethodDelegate create(Object target, String methodName, Class iface) {
/* 139 */     Generator gen = new Generator();
/* 140 */     gen.setTarget(target);
/* 141 */     gen.setMethodName(methodName);
/* 142 */     gen.setInterface(iface);
/* 143 */     return gen.create();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 148 */     MethodDelegate other = (MethodDelegate)obj;
/* 149 */     return (other != null && this.target == other.target && this.eqMethod.equals(other.eqMethod));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     return this.target.hashCode() ^ this.eqMethod.hashCode();
/*     */   }
/*     */   
/*     */   public Object getTarget() {
/* 158 */     return this.target;
/*     */   }
/*     */   
/*     */   public abstract MethodDelegate newInstance(Object paramObject);
/*     */   
/*     */   public static class Generator extends AbstractClassGenerator {
/* 164 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(MethodDelegate.class.getName());
/*     */     
/* 166 */     private static final Type METHOD_DELEGATE = TypeUtils.parseType("org.springframework.cglib.reflect.MethodDelegate");
/* 167 */     private static final Signature NEW_INSTANCE = new Signature("newInstance", METHOD_DELEGATE, new Type[] { Constants.TYPE_OBJECT });
/*     */     
/*     */     private Object target;
/*     */     
/*     */     private Class targetClass;
/*     */     private String methodName;
/*     */     private Class iface;
/*     */     
/*     */     public Generator() {
/* 176 */       super(SOURCE);
/*     */     }
/*     */     
/*     */     public void setTarget(Object target) {
/* 180 */       this.target = target;
/* 181 */       this.targetClass = target.getClass();
/*     */     }
/*     */     
/*     */     public void setTargetClass(Class targetClass) {
/* 185 */       this.targetClass = targetClass;
/*     */     }
/*     */     
/*     */     public void setMethodName(String methodName) {
/* 189 */       this.methodName = methodName;
/*     */     }
/*     */     
/*     */     public void setInterface(Class iface) {
/* 193 */       this.iface = iface;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 198 */       return this.targetClass.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/* 203 */       return ReflectUtils.getProtectionDomain(this.targetClass);
/*     */     }
/*     */     
/*     */     public MethodDelegate create() {
/* 207 */       setNamePrefix(this.targetClass.getName());
/* 208 */       Object key = MethodDelegate.KEY_FACTORY.newInstance(this.targetClass, this.methodName, this.iface);
/* 209 */       return (MethodDelegate)create(key);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 214 */       return ((MethodDelegate)ReflectUtils.newInstance(type)).newInstance(this.target);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 219 */       return ((MethodDelegate)instance).newInstance(this.target);
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) throws NoSuchMethodException {
/* 224 */       Method proxy = ReflectUtils.findInterfaceMethod(this.iface);
/* 225 */       Method method = this.targetClass.getMethod(this.methodName, proxy.getParameterTypes());
/* 226 */       if (!proxy.getReturnType().isAssignableFrom(method.getReturnType())) {
/* 227 */         throw new IllegalArgumentException("incompatible return types");
/*     */       }
/*     */       
/* 230 */       MethodInfo methodInfo = ReflectUtils.getMethodInfo(method);
/*     */       
/* 232 */       boolean isStatic = TypeUtils.isStatic(methodInfo.getModifiers());
/* 233 */       if ((((this.target == null) ? 1 : 0) ^ isStatic) != 0) {
/* 234 */         throw new IllegalArgumentException("Static method " + (isStatic ? "not " : "") + "expected");
/*     */       }
/*     */       
/* 237 */       ClassEmitter ce = new ClassEmitter(v);
/*     */       
/* 239 */       ce.begin_class(52, 1, 
/*     */           
/* 241 */           getClassName(), METHOD_DELEGATE, new Type[] {
/*     */             
/* 243 */             Type.getType(this.iface) }, "<generated>");
/*     */       
/* 245 */       ce.declare_field(26, "eqMethod", Constants.TYPE_STRING, null);
/* 246 */       EmitUtils.null_constructor(ce);
/*     */ 
/*     */       
/* 249 */       MethodInfo proxied = ReflectUtils.getMethodInfo(this.iface.getDeclaredMethods()[0]);
/* 250 */       int modifiers = 1;
/* 251 */       if ((proxied.getModifiers() & 0x80) == 128) {
/* 252 */         modifiers |= 0x80;
/*     */       }
/* 254 */       CodeEmitter e = EmitUtils.begin_method(ce, proxied, modifiers);
/* 255 */       e.load_this();
/* 256 */       e.super_getfield("target", Constants.TYPE_OBJECT);
/* 257 */       e.checkcast(methodInfo.getClassInfo().getType());
/* 258 */       e.load_args();
/* 259 */       e.invoke(methodInfo);
/* 260 */       e.return_value();
/* 261 */       e.end_method();
/*     */ 
/*     */       
/* 264 */       e = ce.begin_method(1, NEW_INSTANCE, null);
/* 265 */       e.new_instance_this();
/* 266 */       e.dup();
/* 267 */       e.dup2();
/* 268 */       e.invoke_constructor_this();
/* 269 */       e.getfield("eqMethod");
/* 270 */       e.super_putfield("eqMethod", Constants.TYPE_STRING);
/* 271 */       e.load_arg(0);
/* 272 */       e.super_putfield("target", Constants.TYPE_OBJECT);
/* 273 */       e.return_value();
/* 274 */       e.end_method();
/*     */ 
/*     */       
/* 277 */       e = ce.begin_static();
/* 278 */       e.push(methodInfo.getSignature().toString());
/* 279 */       e.putfield("eqMethod");
/* 280 */       e.return_value();
/* 281 */       e.end_method();
/*     */       
/* 283 */       ce.end_class();
/*     */     }
/*     */   }
/*     */   
/*     */   static interface MethodDelegateKey {
/*     */     Object newInstance(Class param1Class1, String param1String, Class param1Class2);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\MethodDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */