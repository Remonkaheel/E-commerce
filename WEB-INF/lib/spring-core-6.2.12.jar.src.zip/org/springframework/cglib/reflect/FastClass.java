/*     */ package org.springframework.cglib.reflect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FastClass
/*     */ {
/*     */   private Class type;
/*     */   
/*     */   protected FastClass() {
/*  36 */     throw new Error("Using the FastClass empty constructor--please report to the cglib-devel mailing list");
/*     */   }
/*     */   
/*     */   protected FastClass(Class type) {
/*  40 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static FastClass create(Class type) {
/*  45 */     return create(type.getClassLoader(), type);
/*     */   }
/*     */   
/*     */   public static FastClass create(ClassLoader loader, Class type) {
/*  49 */     Generator gen = new Generator();
/*  50 */     gen.setType(type);
/*  51 */     gen.setClassLoader(loader);
/*  52 */     return gen.create();
/*     */   }
/*     */   
/*     */   public static class Generator
/*     */     extends AbstractClassGenerator {
/*  57 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(FastClass.class.getName());
/*     */     private Class type;
/*     */     
/*     */     public Generator() {
/*  61 */       super(SOURCE);
/*     */     }
/*     */     
/*     */     public void setType(Class type) {
/*  65 */       this.type = type;
/*     */     }
/*     */     
/*     */     public FastClass create() {
/*  69 */       setNamePrefix(this.type.getName());
/*  70 */       return (FastClass)create(this.type.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/*  75 */       return this.type.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/*  80 */       return ReflectUtils.getProtectionDomain(this.type);
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) throws Exception {
/*  85 */       new FastClassEmitter(v, getClassName(), this.type);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/*  90 */       return ReflectUtils.newInstance(type, new Class[] { Class.class }, new Object[] { this.type });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/*  97 */       return instance;
/*     */     }
/*     */   }
/*     */   
/*     */   public Object invoke(String name, Class[] parameterTypes, Object obj, Object[] args) throws InvocationTargetException {
/* 102 */     return invoke(getIndex(name, parameterTypes), obj, args);
/*     */   }
/*     */   
/*     */   public Object newInstance() throws InvocationTargetException {
/* 106 */     return newInstance(getIndex(Constants.EMPTY_CLASS_ARRAY), (Object[])null);
/*     */   }
/*     */   
/*     */   public Object newInstance(Class[] parameterTypes, Object[] args) throws InvocationTargetException {
/* 110 */     return newInstance(getIndex(parameterTypes), args);
/*     */   }
/*     */   
/*     */   public FastMethod getMethod(Method method) {
/* 114 */     return new FastMethod(this, method);
/*     */   }
/*     */   
/*     */   public FastConstructor getConstructor(Constructor constructor) {
/* 118 */     return new FastConstructor(this, constructor);
/*     */   }
/*     */   
/*     */   public FastMethod getMethod(String name, Class[] parameterTypes) {
/*     */     try {
/* 123 */       return getMethod(this.type.getMethod(name, parameterTypes));
/* 124 */     } catch (NoSuchMethodException e) {
/* 125 */       throw new NoSuchMethodError(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public FastConstructor getConstructor(Class[] parameterTypes) {
/*     */     try {
/* 131 */       return getConstructor(this.type.getConstructor(parameterTypes));
/* 132 */     } catch (NoSuchMethodException e) {
/* 133 */       throw new NoSuchMethodError(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getName() {
/* 138 */     return this.type.getName();
/*     */   }
/*     */   
/*     */   public Class getJavaClass() {
/* 142 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     return this.type.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 152 */     return this.type.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     FastClass that;
/* 157 */     if (o != null && o instanceof FastClass) { that = (FastClass)o; }
/* 158 */     else { return false; }
/*     */     
/* 160 */     return this.type.equals(that.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getIndex(String paramString, Class[] paramArrayOfClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getIndex(Class[] paramArrayOfClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object invoke(int paramInt, Object paramObject, Object[] paramArrayOfObject) throws InvocationTargetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object newInstance(int paramInt, Object[] paramArrayOfObject) throws InvocationTargetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getIndex(Signature paramSignature);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getMaxIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getSignatureWithoutReturnType(String name, Class[] parameterTypes) {
/* 211 */     StringBuilder sb = new StringBuilder();
/* 212 */     sb.append(name);
/* 213 */     sb.append('(');
/* 214 */     for (Class parameterType : parameterTypes) {
/* 215 */       sb.append(Type.getDescriptor(parameterType));
/*     */     }
/* 217 */     sb.append(')');
/* 218 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\FastClass.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */