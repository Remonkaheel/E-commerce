/*    */ package org.springframework.cglib.reflect;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FastMember
/*    */ {
/*    */   protected FastClass fc;
/*    */   protected Member member;
/*    */   protected int index;
/*    */   
/*    */   protected FastMember(FastClass fc, Member member, int index) {
/* 28 */     this.fc = fc;
/* 29 */     this.member = member;
/* 30 */     this.index = index;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract Class[] getParameterTypes();
/*    */   
/*    */   public int getIndex() {
/* 37 */     return this.index;
/*    */   }
/*    */   public abstract Class[] getExceptionTypes();
/*    */   public String getName() {
/* 41 */     return this.member.getName();
/*    */   }
/*    */   
/*    */   public Class getDeclaringClass() {
/* 45 */     return this.fc.getJavaClass();
/*    */   }
/*    */   
/*    */   public int getModifiers() {
/* 49 */     return this.member.getModifiers();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 54 */     return this.member.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 59 */     return this.member.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     FastMember other;
/* 64 */     if (o != null && o instanceof FastMember) { other = (FastMember)o; }
/* 65 */     else { return false; }
/*    */     
/* 67 */     return this.member.equals(other.member);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\FastMember.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */