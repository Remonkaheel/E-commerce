/*     */ package org.springframework.cglib.reflect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.Block;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.CollectionUtils;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.DuplicatesPredicate;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.MethodInfoTransformer;
/*     */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*     */ import org.springframework.cglib.core.Predicate;
/*     */ import org.springframework.cglib.core.ProcessSwitchCallback;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.Transformer;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ import org.springframework.cglib.core.VisibilityPredicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FastClassEmitter
/*     */   extends ClassEmitter
/*     */ {
/*  49 */   private static final Signature CSTRUCT_CLASS = TypeUtils.parseConstructor("Class");
/*     */   
/*  51 */   private static final Signature METHOD_GET_INDEX = TypeUtils.parseSignature("int getIndex(String, Class[])");
/*  52 */   private static final Signature SIGNATURE_GET_INDEX = new Signature("getIndex", Type.INT_TYPE, new Type[] { Constants.TYPE_SIGNATURE });
/*     */ 
/*     */   
/*  55 */   private static final Signature TO_STRING = TypeUtils.parseSignature("String toString()");
/*     */   
/*  57 */   private static final Signature CONSTRUCTOR_GET_INDEX = TypeUtils.parseSignature("int getIndex(Class[])");
/*     */   
/*  59 */   private static final Signature INVOKE = TypeUtils.parseSignature("Object invoke(int, Object, Object[])");
/*     */   
/*  61 */   private static final Signature NEW_INSTANCE = TypeUtils.parseSignature("Object newInstance(int, Object[])");
/*     */   
/*  63 */   private static final Signature GET_MAX_INDEX = TypeUtils.parseSignature("int getMaxIndex()");
/*     */   
/*  65 */   private static final Signature GET_SIGNATURE_WITHOUT_RETURN_TYPE = TypeUtils.parseSignature("String getSignatureWithoutReturnType(String, Class[])");
/*     */   
/*  67 */   private static final Type FAST_CLASS = TypeUtils.parseType("org.springframework.cglib.reflect.FastClass");
/*     */   
/*  69 */   private static final Type ILLEGAL_ARGUMENT_EXCEPTION = TypeUtils.parseType("IllegalArgumentException");
/*     */   
/*  71 */   private static final Type INVOCATION_TARGET_EXCEPTION = TypeUtils.parseType("java.lang.reflect.InvocationTargetException");
/*  72 */   private static final Type[] INVOCATION_TARGET_EXCEPTION_ARRAY = new Type[] { INVOCATION_TARGET_EXCEPTION };
/*     */   
/*     */   public FastClassEmitter(ClassVisitor v, String className, Class type) {
/*  75 */     super(v);
/*     */     
/*  77 */     Type base = Type.getType(type);
/*  78 */     begin_class(52, 1, className, FAST_CLASS, null, "<generated>");
/*     */ 
/*     */     
/*  81 */     CodeEmitter e = begin_method(1, CSTRUCT_CLASS, null);
/*  82 */     e.load_this();
/*  83 */     e.load_args();
/*  84 */     e.super_invoke_constructor(CSTRUCT_CLASS);
/*  85 */     e.return_value();
/*  86 */     e.end_method();
/*     */     
/*  88 */     VisibilityPredicate vp = new VisibilityPredicate(type, false);
/*  89 */     List methods = ReflectUtils.addAllMethods(type, new ArrayList());
/*  90 */     CollectionUtils.filter(methods, (Predicate)vp);
/*  91 */     CollectionUtils.filter(methods, (Predicate)new DuplicatesPredicate());
/*  92 */     List constructors = new ArrayList(Arrays.asList((Object[])type.getDeclaredConstructors()));
/*  93 */     CollectionUtils.filter(constructors, (Predicate)vp);
/*     */ 
/*     */     
/*  96 */     emitIndexBySignature(methods);
/*     */ 
/*     */     
/*  99 */     emitIndexByClassArray(methods);
/*     */ 
/*     */     
/* 102 */     e = begin_method(1, CONSTRUCTOR_GET_INDEX, null);
/* 103 */     e.load_args();
/* 104 */     List info = CollectionUtils.transform(constructors, (Transformer)MethodInfoTransformer.getInstance());
/* 105 */     EmitUtils.constructor_switch(e, info, new GetIndexCallback(e, info));
/* 106 */     e.end_method();
/*     */ 
/*     */     
/* 109 */     e = begin_method(1, INVOKE, INVOCATION_TARGET_EXCEPTION_ARRAY);
/* 110 */     e.load_arg(1);
/* 111 */     e.checkcast(base);
/* 112 */     e.load_arg(0);
/* 113 */     invokeSwitchHelper(e, methods, 2, base);
/* 114 */     e.end_method();
/*     */ 
/*     */     
/* 117 */     e = begin_method(1, NEW_INSTANCE, INVOCATION_TARGET_EXCEPTION_ARRAY);
/* 118 */     e.new_instance(base);
/* 119 */     e.dup();
/* 120 */     e.load_arg(0);
/* 121 */     invokeSwitchHelper(e, constructors, 1, base);
/* 122 */     e.end_method();
/*     */ 
/*     */     
/* 125 */     e = begin_method(1, GET_MAX_INDEX, null);
/* 126 */     e.push(methods.size() - 1);
/* 127 */     e.return_value();
/* 128 */     e.end_method();
/*     */     
/* 130 */     end_class();
/*     */   }
/*     */   private static final int TOO_MANY_METHODS = 100;
/*     */   
/*     */   private void emitIndexBySignature(List methods) {
/* 135 */     CodeEmitter e = begin_method(1, SIGNATURE_GET_INDEX, null);
/* 136 */     List signatures = CollectionUtils.transform(methods, obj -> ReflectUtils.getSignature((Method)obj).toString());
/* 137 */     e.load_arg(0);
/* 138 */     e.invoke_virtual(Constants.TYPE_OBJECT, TO_STRING);
/* 139 */     signatureSwitchHelper(e, signatures);
/* 140 */     e.end_method();
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitIndexByClassArray(List methods) {
/* 145 */     CodeEmitter e = begin_method(1, METHOD_GET_INDEX, null);
/* 146 */     if (methods.size() > 100) {
/*     */       
/* 148 */       List signatures = CollectionUtils.transform(methods, obj -> {
/*     */             String s = ReflectUtils.getSignature((Method)obj).toString();
/*     */             return s.substring(0, s.lastIndexOf(')') + 1);
/*     */           });
/* 152 */       e.load_args();
/* 153 */       e.invoke_static(FAST_CLASS, GET_SIGNATURE_WITHOUT_RETURN_TYPE);
/* 154 */       signatureSwitchHelper(e, signatures);
/*     */     } else {
/* 156 */       e.load_args();
/* 157 */       List info = CollectionUtils.transform(methods, (Transformer)MethodInfoTransformer.getInstance());
/* 158 */       EmitUtils.method_switch(e, info, new GetIndexCallback(e, info));
/*     */     } 
/* 160 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void signatureSwitchHelper(final CodeEmitter e, final List signatures) {
/* 164 */     ObjectSwitchCallback callback = new ObjectSwitchCallback()
/*     */       {
/*     */         public void processCase(Object key, Label end)
/*     */         {
/* 168 */           e.push(signatures.indexOf(key));
/* 169 */           e.return_value();
/*     */         }
/*     */         
/*     */         public void processDefault() {
/* 173 */           e.push(-1);
/* 174 */           e.return_value();
/*     */         }
/*     */       };
/* 177 */     EmitUtils.string_switch(e, (String[])signatures
/* 178 */         .toArray((Object[])new String[signatures.size()]), 1, callback);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void invokeSwitchHelper(final CodeEmitter e, List members, final int arg, final Type base) {
/* 184 */     final List info = CollectionUtils.transform(members, (Transformer)MethodInfoTransformer.getInstance());
/* 185 */     final Label illegalArg = e.make_label();
/* 186 */     Block block = e.begin_block();
/* 187 */     e.process_switch(getIntRange(info.size()), new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label end) {
/* 190 */             MethodInfo method = info.get(key);
/* 191 */             Type[] types = method.getSignature().getArgumentTypes();
/* 192 */             for (int i = 0; i < types.length; i++) {
/* 193 */               e.load_arg(arg);
/* 194 */               e.aaload(i);
/* 195 */               e.unbox(types[i]);
/*     */             } 
/*     */ 
/*     */             
/* 199 */             e.invoke(method, base);
/* 200 */             if (!TypeUtils.isConstructor(method)) {
/* 201 */               e.box(method.getSignature().getReturnType());
/*     */             }
/* 203 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 207 */             e.goTo(illegalArg);
/*     */           }
/*     */         });
/* 210 */     block.end();
/* 211 */     EmitUtils.wrap_throwable(block, INVOCATION_TARGET_EXCEPTION);
/* 212 */     e.mark(illegalArg);
/* 213 */     e.throw_exception(ILLEGAL_ARGUMENT_EXCEPTION, "Cannot find matching method/constructor");
/*     */   }
/*     */   
/*     */   private static class GetIndexCallback implements ObjectSwitchCallback {
/*     */     private CodeEmitter e;
/* 218 */     private Map indexes = new HashMap<>();
/*     */     
/*     */     public GetIndexCallback(CodeEmitter e, List methods) {
/* 221 */       this.e = e;
/* 222 */       int index = 0;
/* 223 */       for (Iterator it = methods.iterator(); it.hasNext();) {
/* 224 */         this.indexes.put(it.next(), Integer.valueOf(index++));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void processCase(Object key, Label end) {
/* 230 */       this.e.push(((Integer)this.indexes.get(key)).intValue());
/* 231 */       this.e.return_value();
/*     */     }
/*     */ 
/*     */     
/*     */     public void processDefault() {
/* 236 */       this.e.push(-1);
/* 237 */       this.e.return_value();
/*     */     }
/*     */   }
/*     */   
/*     */   private static int[] getIntRange(int length) {
/* 242 */     int[] range = new int[length];
/* 243 */     for (int i = 0; i < length; i++) {
/* 244 */       range[i] = i;
/*     */     }
/* 246 */     return range;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\reflect\FastClassEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */