/*     */ package org.springframework.cglib.util;
/*     */ 
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParallelSorterEmitter
/*     */   extends ClassEmitter
/*     */ {
/*  31 */   private static final Type PARALLEL_SORTER = TypeUtils.parseType("org.springframework.cglib.util.ParallelSorter");
/*     */   
/*  33 */   private static final Signature CSTRUCT_OBJECT_ARRAY = TypeUtils.parseConstructor("Object[]");
/*  34 */   private static final Signature NEW_INSTANCE = new Signature("newInstance", PARALLEL_SORTER, new Type[] { Constants.TYPE_OBJECT_ARRAY });
/*     */ 
/*     */   
/*  37 */   private static final Signature SWAP = TypeUtils.parseSignature("void swap(int, int)");
/*     */   
/*     */   public ParallelSorterEmitter(ClassVisitor v, String className, Object[] arrays) {
/*  40 */     super(v);
/*  41 */     begin_class(52, 1, className, PARALLEL_SORTER, null, "<generated>");
/*  42 */     EmitUtils.null_constructor(this);
/*  43 */     EmitUtils.factory_method(this, NEW_INSTANCE);
/*  44 */     generateConstructor(arrays);
/*  45 */     generateSwap(arrays);
/*  46 */     end_class();
/*     */   }
/*     */   
/*     */   private String getFieldName(int index) {
/*  50 */     return "FIELD_" + index;
/*     */   }
/*     */   
/*     */   private void generateConstructor(Object[] arrays) {
/*  54 */     CodeEmitter e = begin_method(1, CSTRUCT_OBJECT_ARRAY, null);
/*  55 */     e.load_this();
/*  56 */     e.super_invoke_constructor();
/*  57 */     e.load_this();
/*  58 */     e.load_arg(0);
/*  59 */     e.super_putfield("a", Constants.TYPE_OBJECT_ARRAY);
/*  60 */     for (int i = 0; i < arrays.length; i++) {
/*  61 */       Type type = Type.getType(arrays[i].getClass());
/*  62 */       declare_field(2, getFieldName(i), type, null);
/*  63 */       e.load_this();
/*  64 */       e.load_arg(0);
/*  65 */       e.push(i);
/*  66 */       e.aaload();
/*  67 */       e.checkcast(type);
/*  68 */       e.putfield(getFieldName(i));
/*     */     } 
/*  70 */     e.return_value();
/*  71 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void generateSwap(Object[] arrays) {
/*  75 */     CodeEmitter e = begin_method(1, SWAP, null);
/*  76 */     for (int i = 0; i < arrays.length; i++) {
/*  77 */       Type type = Type.getType(arrays[i].getClass());
/*  78 */       Type component = TypeUtils.getComponentType(type);
/*  79 */       Local T = e.make_local(type);
/*     */       
/*  81 */       e.load_this();
/*  82 */       e.getfield(getFieldName(i));
/*  83 */       e.store_local(T);
/*     */       
/*  85 */       e.load_local(T);
/*  86 */       e.load_arg(0);
/*     */       
/*  88 */       e.load_local(T);
/*  89 */       e.load_arg(1);
/*  90 */       e.array_load(component);
/*     */       
/*  92 */       e.load_local(T);
/*  93 */       e.load_arg(1);
/*     */       
/*  95 */       e.load_local(T);
/*  96 */       e.load_arg(0);
/*  97 */       e.array_load(component);
/*     */       
/*  99 */       e.array_store(component);
/* 100 */       e.array_store(component);
/*     */     } 
/* 102 */     e.return_value();
/* 103 */     e.end_method();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cgli\\util\ParallelSorterEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */