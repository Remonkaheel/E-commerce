/*     */ package org.springframework.cglib.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SorterTemplate
/*     */ {
/*     */   private static final int MERGESORT_THRESHOLD = 12;
/*     */   private static final int QUICKSORT_THRESHOLD = 7;
/*     */   
/*     */   protected abstract void swap(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract int compare(int paramInt1, int paramInt2);
/*     */   
/*     */   protected void quickSort(int lo, int hi) {
/*  27 */     quickSortHelper(lo, hi);
/*  28 */     insertionSort(lo, hi);
/*     */   }
/*     */   
/*     */   private void quickSortHelper(int lo, int hi) {
/*     */     while (true) {
/*  33 */       int diff = hi - lo;
/*  34 */       if (diff <= 7) {
/*     */         break;
/*     */       }
/*  37 */       int i = (hi + lo) / 2;
/*  38 */       if (compare(lo, i) > 0) {
/*  39 */         swap(lo, i);
/*     */       }
/*  41 */       if (compare(lo, hi) > 0) {
/*  42 */         swap(lo, hi);
/*     */       }
/*  44 */       if (compare(i, hi) > 0) {
/*  45 */         swap(i, hi);
/*     */       }
/*  47 */       int j = hi - 1;
/*  48 */       swap(i, j);
/*  49 */       i = lo;
/*  50 */       int v = j;
/*     */       while (true) {
/*  52 */         if (compare(++i, v) < 0) {
/*     */           continue;
/*     */         }
/*  55 */         while (compare(--j, v) > 0);
/*     */ 
/*     */         
/*  58 */         if (j < i) {
/*     */           break;
/*     */         }
/*  61 */         swap(i, j);
/*     */       } 
/*  63 */       swap(i, hi - 1);
/*  64 */       if (j - lo <= hi - i + 1) {
/*  65 */         quickSortHelper(lo, j);
/*  66 */         lo = i + 1; continue;
/*     */       } 
/*  68 */       quickSortHelper(i + 1, hi);
/*  69 */       hi = j;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void insertionSort(int lo, int hi) {
/*  75 */     for (int i = lo + 1; i <= hi; i++) {
/*  76 */       for (int j = i; j > lo && 
/*  77 */         compare(j - 1, j) > 0; j--) {
/*  78 */         swap(j - 1, j);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mergeSort(int lo, int hi) {
/*  87 */     int diff = hi - lo;
/*  88 */     if (diff <= 12) {
/*  89 */       insertionSort(lo, hi);
/*     */       return;
/*     */     } 
/*  92 */     int mid = lo + diff / 2;
/*  93 */     mergeSort(lo, mid);
/*  94 */     mergeSort(mid, hi);
/*  95 */     merge(lo, mid, hi, mid - lo, hi - mid);
/*     */   }
/*     */   private void merge(int lo, int pivot, int hi, int len1, int len2) {
/*     */     int first_cut, second_cut, len11, len22;
/*  99 */     if (len1 == 0 || len2 == 0) {
/*     */       return;
/*     */     }
/* 102 */     if (len1 + len2 == 2) {
/* 103 */       if (compare(pivot, lo) < 0) {
/* 104 */         swap(pivot, lo);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 110 */     if (len1 > len2) {
/* 111 */       len11 = len1 / 2;
/* 112 */       first_cut = lo + len11;
/* 113 */       second_cut = lower(pivot, hi, first_cut);
/* 114 */       len22 = second_cut - pivot;
/*     */     } else {
/* 116 */       len22 = len2 / 2;
/* 117 */       second_cut = pivot + len22;
/* 118 */       first_cut = upper(lo, pivot, second_cut);
/* 119 */       len11 = first_cut - lo;
/*     */     } 
/* 121 */     rotate(first_cut, pivot, second_cut);
/* 122 */     int new_mid = first_cut + len22;
/* 123 */     merge(lo, first_cut, new_mid, len11, len22);
/* 124 */     merge(new_mid, second_cut, hi, len1 - len11, len2 - len22);
/*     */   }
/*     */   
/*     */   private void rotate(int lo, int mid, int hi) {
/* 128 */     int lot = lo;
/* 129 */     int hit = mid - 1;
/* 130 */     while (lot < hit) {
/* 131 */       swap(lot++, hit--);
/*     */     }
/* 133 */     lot = mid; hit = hi - 1;
/* 134 */     while (lot < hit) {
/* 135 */       swap(lot++, hit--);
/*     */     }
/* 137 */     lot = lo; hit = hi - 1;
/* 138 */     while (lot < hit) {
/* 139 */       swap(lot++, hit--);
/*     */     }
/*     */   }
/*     */   
/*     */   private int lower(int lo, int hi, int val) {
/* 144 */     int len = hi - lo;
/* 145 */     while (len > 0) {
/* 146 */       int half = len / 2;
/* 147 */       int mid = lo + half;
/* 148 */       if (compare(mid, val) < 0) {
/* 149 */         lo = mid + 1;
/* 150 */         len = len - half - 1; continue;
/*     */       } 
/* 152 */       len = half;
/*     */     } 
/*     */     
/* 155 */     return lo;
/*     */   }
/*     */   
/*     */   private int upper(int lo, int hi, int val) {
/* 159 */     int len = hi - lo;
/* 160 */     while (len > 0) {
/* 161 */       int half = len / 2;
/* 162 */       int mid = lo + half;
/* 163 */       if (compare(val, mid) < 0) {
/* 164 */         len = half; continue;
/*     */       } 
/* 166 */       lo = mid + 1;
/* 167 */       len = len - half - 1;
/*     */     } 
/*     */     
/* 170 */     return lo;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cgli\\util\SorterTemplate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */