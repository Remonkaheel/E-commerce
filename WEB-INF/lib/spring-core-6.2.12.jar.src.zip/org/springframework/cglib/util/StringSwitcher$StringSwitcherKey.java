package org.springframework.cglib.util;

interface StringSwitcherKey {
  Object newInstance(String[] paramArrayOfString, int[] paramArrayOfint, boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cgli\\util\StringSwitcher$StringSwitcherKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */