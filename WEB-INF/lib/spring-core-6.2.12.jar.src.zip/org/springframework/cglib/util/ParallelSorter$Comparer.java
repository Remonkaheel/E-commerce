package org.springframework.cglib.util;

interface Comparer {
  int compare(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cgli\\util\ParallelSorter$Comparer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */