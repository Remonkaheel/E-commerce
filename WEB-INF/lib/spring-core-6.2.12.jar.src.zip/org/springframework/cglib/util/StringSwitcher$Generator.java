/*     */ package org.springframework.cglib.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/*  82 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(StringSwitcher.class.getName());
/*     */   
/*     */   private String[] strings;
/*     */   private int[] ints;
/*     */   private boolean fixedInput;
/*     */   
/*     */   public Generator() {
/*  89 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStrings(String[] strings) {
/*  98 */     this.strings = strings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInts(int[] ints) {
/* 107 */     this.ints = ints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFixedInput(boolean fixedInput) {
/* 116 */     this.fixedInput = fixedInput;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/* 121 */     return getClass().getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringSwitcher create() {
/* 128 */     setNamePrefix(StringSwitcher.class.getName());
/* 129 */     Object key = StringSwitcher.KEY_FACTORY.newInstance(this.strings, this.ints, this.fixedInput);
/* 130 */     return (StringSwitcher)create(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) throws Exception {
/* 135 */     ClassEmitter ce = new ClassEmitter(v);
/* 136 */     ce.begin_class(52, 1, 
/*     */         
/* 138 */         getClassName(), StringSwitcher.STRING_SWITCHER, null, "<generated>");
/*     */ 
/*     */ 
/*     */     
/* 142 */     EmitUtils.null_constructor(ce);
/* 143 */     final CodeEmitter e = ce.begin_method(1, StringSwitcher.INT_VALUE, null);
/* 144 */     e.load_arg(0);
/* 145 */     final List<String> stringList = Arrays.asList(this.strings);
/* 146 */     int style = this.fixedInput ? 2 : 1;
/* 147 */     EmitUtils.string_switch(e, this.strings, style, new ObjectSwitchCallback()
/*     */         {
/*     */           public void processCase(Object key, Label end) {
/* 150 */             e.push(StringSwitcher.Generator.this.ints[stringList.indexOf(key)]);
/* 151 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 155 */             e.push(-1);
/* 156 */             e.return_value();
/*     */           }
/*     */         });
/* 159 */     e.end_method();
/* 160 */     ce.end_class();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 165 */     return ReflectUtils.newInstance(type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 170 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cgli\\util\StringSwitcher$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */