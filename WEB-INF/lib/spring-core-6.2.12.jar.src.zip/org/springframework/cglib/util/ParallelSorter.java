/*     */ package org.springframework.cglib.util;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassesKey;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParallelSorter
/*     */   extends SorterTemplate
/*     */ {
/*     */   protected Object[] a;
/*     */   private Comparer comparer;
/*     */   
/*     */   public abstract ParallelSorter newInstance(Object[] paramArrayOfObject);
/*     */   
/*     */   public static ParallelSorter create(Object[] arrays) {
/*  69 */     Generator gen = new Generator();
/*  70 */     gen.setArrays(arrays);
/*  71 */     return gen.create();
/*     */   }
/*     */   
/*     */   private int len() {
/*  75 */     return ((Object[])this.a[0]).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quickSort(int index) {
/*  83 */     quickSort(index, 0, len(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quickSort(int index, int lo, int hi) {
/*  93 */     quickSort(index, lo, hi, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quickSort(int index, Comparator cmp) {
/* 102 */     quickSort(index, 0, len(), cmp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quickSort(int index, int lo, int hi, Comparator cmp) {
/* 113 */     chooseComparer(index, cmp);
/* 114 */     quickSort(lo, hi - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeSort(int index) {
/* 121 */     mergeSort(index, 0, len(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeSort(int index, int lo, int hi) {
/* 131 */     mergeSort(index, lo, hi, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeSort(int index, Comparator cmp) {
/* 140 */     mergeSort(index, 0, len(), cmp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeSort(int index, int lo, int hi, Comparator cmp) {
/* 151 */     chooseComparer(index, cmp);
/* 152 */     mergeSort(lo, hi - 1);
/*     */   }
/*     */   
/*     */   private void chooseComparer(int index, Comparator cmp) {
/* 156 */     Object array = this.a[index];
/* 157 */     Class<?> type = array.getClass().componentType();
/* 158 */     if (type.equals(int.class)) {
/* 159 */       this.comparer = new IntComparer((int[])array);
/* 160 */     } else if (type.equals(long.class)) {
/* 161 */       this.comparer = new LongComparer((long[])array);
/* 162 */     } else if (type.equals(double.class)) {
/* 163 */       this.comparer = new DoubleComparer((double[])array);
/* 164 */     } else if (type.equals(float.class)) {
/* 165 */       this.comparer = new FloatComparer((float[])array);
/* 166 */     } else if (type.equals(short.class)) {
/* 167 */       this.comparer = new ShortComparer((short[])array);
/* 168 */     } else if (type.equals(byte.class)) {
/* 169 */       this.comparer = new ByteComparer((byte[])array);
/* 170 */     } else if (cmp != null) {
/* 171 */       this.comparer = new ComparatorComparer((Object[])array, cmp);
/*     */     } else {
/* 173 */       this.comparer = new ObjectComparer((Object[])array);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int compare(int i, int j) {
/* 179 */     return this.comparer.compare(i, j);
/*     */   }
/*     */ 
/*     */   
/*     */   static class ComparatorComparer
/*     */     implements Comparer
/*     */   {
/*     */     private final Object[] a;
/*     */     
/*     */     private final Comparator cmp;
/*     */     
/*     */     public ComparatorComparer(Object[] a, Comparator cmp) {
/* 191 */       this.a = a;
/* 192 */       this.cmp = cmp;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compare(int i, int j) {
/* 197 */       return this.cmp.compare(this.a[i], this.a[j]);
/*     */     } }
/*     */   
/*     */   static class ObjectComparer implements Comparer { private final Object[] a;
/*     */     
/*     */     public ObjectComparer(Object[] a) {
/* 203 */       this.a = a;
/*     */     }
/*     */     public int compare(int i, int j) {
/* 206 */       return ((Comparable<Object>)this.a[i]).compareTo(this.a[j]);
/*     */     } }
/*     */   
/*     */   static class IntComparer implements Comparer { private final int[] a;
/*     */     
/*     */     public IntComparer(int[] a) {
/* 212 */       this.a = a;
/*     */     } public int compare(int i, int j) {
/* 214 */       return this.a[i] - this.a[j];
/*     */     } }
/*     */   static class LongComparer implements Comparer { private final long[] a;
/*     */     
/*     */     public LongComparer(long[] a) {
/* 219 */       this.a = a;
/*     */     }
/*     */     public int compare(int i, int j) {
/* 222 */       long vi = this.a[i];
/* 223 */       long vj = this.a[j];
/* 224 */       return Long.compare(vi, vj);
/*     */     } }
/*     */   
/*     */   static class FloatComparer implements Comparer { private final float[] a;
/*     */     
/*     */     public FloatComparer(float[] a) {
/* 230 */       this.a = a;
/*     */     }
/*     */     public int compare(int i, int j) {
/* 233 */       float vi = this.a[i];
/* 234 */       float vj = this.a[j];
/* 235 */       return Float.compare(vi, vj);
/*     */     } }
/*     */   
/*     */   static class DoubleComparer implements Comparer { private final double[] a;
/*     */     
/*     */     public DoubleComparer(double[] a) {
/* 241 */       this.a = a;
/*     */     }
/*     */     public int compare(int i, int j) {
/* 244 */       double vi = this.a[i];
/* 245 */       double vj = this.a[j];
/* 246 */       return Double.compare(vi, vj);
/*     */     } }
/*     */   
/*     */   static class ShortComparer implements Comparer { private final short[] a;
/*     */     
/*     */     public ShortComparer(short[] a) {
/* 252 */       this.a = a;
/*     */     } public int compare(int i, int j) {
/* 254 */       return this.a[i] - this.a[j];
/*     */     } }
/*     */   static class ByteComparer implements Comparer { private final byte[] a;
/*     */     
/*     */     public ByteComparer(byte[] a) {
/* 259 */       this.a = a;
/*     */     } public int compare(int i, int j) {
/* 261 */       return this.a[i] - this.a[j];
/*     */     } }
/*     */   
/*     */   public static class Generator extends AbstractClassGenerator {
/* 265 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(ParallelSorter.class.getName());
/*     */     
/*     */     private Object[] arrays;
/*     */     
/*     */     public Generator() {
/* 270 */       super(SOURCE);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 275 */       return null;
/*     */     }
/*     */     
/*     */     public void setArrays(Object[] arrays) {
/* 279 */       this.arrays = arrays;
/*     */     }
/*     */     
/*     */     public ParallelSorter create() {
/* 283 */       return (ParallelSorter)create(ClassesKey.create(this.arrays));
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) throws Exception {
/* 288 */       if (this.arrays.length == 0) {
/* 289 */         throw new IllegalArgumentException("No arrays specified to sort");
/*     */       }
/* 291 */       for (Object array : this.arrays) {
/* 292 */         if (!array.getClass().isArray()) {
/* 293 */           throw new IllegalArgumentException(String.valueOf(array.getClass()) + " is not an array");
/*     */         }
/*     */       } 
/* 296 */       new ParallelSorterEmitter(v, getClassName(), this.arrays);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 301 */       return ((ParallelSorter)ReflectUtils.newInstance(type)).newInstance(this.arrays);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 306 */       return ((ParallelSorter)instance).newInstance(this.arrays);
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Comparer {
/*     */     int compare(int param1Int1, int param1Int2);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cgli\\util\ParallelSorter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */