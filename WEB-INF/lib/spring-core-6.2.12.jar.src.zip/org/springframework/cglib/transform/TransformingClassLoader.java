/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassReader;
/*    */ import org.springframework.cglib.core.ClassGenerator;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformingClassLoader
/*    */   extends AbstractClassLoader
/*    */ {
/*    */   private final ClassTransformerFactory t;
/*    */   
/*    */   public TransformingClassLoader(ClassLoader parent, ClassFilter filter, ClassTransformerFactory t) {
/* 27 */     super(parent, parent, filter);
/* 28 */     this.t = t;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ClassGenerator getGenerator(ClassReader r) {
/* 33 */     ClassTransformer t2 = this.t.newInstance();
/* 34 */     return new TransformingClassGenerator(super.getGenerator(r), t2);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\TransformingClassLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */