/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.asm.MethodVisitor;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodFilterTransformer
/*    */   extends AbstractClassTransformer
/*    */ {
/*    */   private MethodFilter filter;
/*    */   private ClassTransformer pass;
/*    */   private ClassVisitor direct;
/*    */   
/*    */   public MethodFilterTransformer(MethodFilter filter, ClassTransformer pass) {
/* 28 */     this.filter = filter;
/* 29 */     this.pass = pass;
/* 30 */     super.setTarget((ClassVisitor)pass);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 39 */     return (this.filter.accept(access, name, desc, signature, exceptions) ? this.pass : this.direct).visitMethod(access, name, desc, signature, exceptions);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTarget(ClassVisitor target) {
/* 44 */     this.pass.setTarget(target);
/* 45 */     this.direct = target;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\MethodFilterTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */