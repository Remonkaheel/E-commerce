/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.asm.MethodVisitor;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassTransformerChain
/*    */   extends AbstractClassTransformer
/*    */ {
/*    */   private ClassTransformer[] chain;
/*    */   
/*    */   public ClassTransformerChain(ClassTransformer[] chain) {
/* 26 */     this.chain = (ClassTransformer[])chain.clone();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTarget(ClassVisitor v) {
/* 31 */     super.setTarget((ClassVisitor)this.chain[0]);
/* 32 */     ClassVisitor next = v;
/* 33 */     for (int i = this.chain.length - 1; i >= 0; i--) {
/* 34 */       this.chain[i].setTarget(next);
/* 35 */       ClassTransformer classTransformer = this.chain[i];
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 45 */     return this.cv.visitMethod(access, name, desc, signature, exceptions);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     StringBuilder sb = new StringBuilder();
/* 51 */     sb.append("ClassTransformerChain{");
/* 52 */     for (int i = 0; i < this.chain.length; i++) {
/* 53 */       if (i > 0) {
/* 54 */         sb.append(", ");
/*    */       }
/* 56 */       sb.append(this.chain[i].toString());
/*    */     } 
/* 58 */     sb.append("}");
/* 59 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\ClassTransformerChain.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */