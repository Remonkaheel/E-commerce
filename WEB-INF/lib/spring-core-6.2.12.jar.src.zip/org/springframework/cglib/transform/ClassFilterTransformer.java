/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassFilterTransformer
/*    */   extends AbstractClassFilterTransformer
/*    */ {
/*    */   private ClassFilter filter;
/*    */   
/*    */   public ClassFilterTransformer(ClassFilter filter, ClassTransformer pass) {
/* 25 */     super(pass);
/* 26 */     this.filter = filter;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean accept(int version, int access, String name, String signature, String superName, String[] interfaces) {
/* 31 */     return this.filter.accept(name.replace('/', '.'));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\ClassFilterTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */