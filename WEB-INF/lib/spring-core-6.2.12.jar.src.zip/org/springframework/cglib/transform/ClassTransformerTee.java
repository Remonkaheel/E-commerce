/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassTransformerTee
/*    */   extends ClassTransformer
/*    */ {
/*    */   private ClassVisitor branch;
/*    */   
/*    */   public ClassTransformerTee(ClassVisitor branch) {
/* 26 */     super(Constants.ASM_API);
/* 27 */     this.branch = branch;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTarget(ClassVisitor target) {
/* 32 */     this.cv = new ClassVisitorTee(this.branch, target);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\ClassTransformerTee.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */