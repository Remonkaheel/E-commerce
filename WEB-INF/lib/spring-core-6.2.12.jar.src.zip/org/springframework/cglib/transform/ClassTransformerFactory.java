package org.springframework.cglib.transform;

import org.springframework.cglib.core.ClassTransformer;

public interface ClassTransformerFactory {
  ClassTransformer newInstance();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\ClassTransformerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */