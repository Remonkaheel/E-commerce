/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.AnnotationVisitor;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationVisitorTee
/*    */   extends AnnotationVisitor
/*    */ {
/*    */   private AnnotationVisitor av1;
/*    */   private AnnotationVisitor av2;
/*    */   
/*    */   public static AnnotationVisitor getInstance(AnnotationVisitor av1, AnnotationVisitor av2) {
/* 25 */     if (av1 == null) {
/* 26 */       return av2;
/*    */     }
/* 28 */     if (av2 == null) {
/* 29 */       return av1;
/*    */     }
/* 31 */     return new AnnotationVisitorTee(av1, av2);
/*    */   }
/*    */   
/*    */   public AnnotationVisitorTee(AnnotationVisitor av1, AnnotationVisitor av2) {
/* 35 */     super(Constants.ASM_API);
/* 36 */     this.av1 = av1;
/* 37 */     this.av2 = av2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(String name, Object value) {
/* 42 */     this.av2.visit(name, value);
/* 43 */     this.av2.visit(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitEnum(String name, String desc, String value) {
/* 48 */     this.av1.visitEnum(name, desc, value);
/* 49 */     this.av2.visitEnum(name, desc, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationVisitor visitAnnotation(String name, String desc) {
/* 54 */     return getInstance(this.av1.visitAnnotation(name, desc), this.av2
/* 55 */         .visitAnnotation(name, desc));
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationVisitor visitArray(String name) {
/* 60 */     return getInstance(this.av1.visitArray(name), this.av2.visitArray(name));
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitEnd() {
/* 65 */     this.av1.visitEnd();
/* 66 */     this.av2.visitEnd();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\AnnotationVisitorTee.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */