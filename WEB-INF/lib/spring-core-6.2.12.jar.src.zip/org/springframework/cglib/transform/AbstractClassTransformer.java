/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractClassTransformer
/*    */   extends ClassTransformer
/*    */ {
/*    */   protected AbstractClassTransformer() {
/* 24 */     super(Constants.ASM_API);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTarget(ClassVisitor target) {
/* 29 */     this.cv = target;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\AbstractClassTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */