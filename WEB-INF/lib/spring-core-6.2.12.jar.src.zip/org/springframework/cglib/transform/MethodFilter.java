package org.springframework.cglib.transform;

public interface MethodFilter {
  boolean accept(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\MethodFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */