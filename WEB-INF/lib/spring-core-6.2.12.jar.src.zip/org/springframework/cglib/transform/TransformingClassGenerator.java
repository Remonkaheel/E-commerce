/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.ClassGenerator;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformingClassGenerator
/*    */   implements ClassGenerator
/*    */ {
/*    */   private final ClassGenerator gen;
/*    */   private final ClassTransformer t;
/*    */   
/*    */   public TransformingClassGenerator(ClassGenerator gen, ClassTransformer t) {
/* 28 */     this.gen = gen;
/* 29 */     this.t = t;
/*    */   }
/*    */ 
/*    */   
/*    */   public void generateClass(ClassVisitor v) throws Exception {
/* 34 */     this.t.setTarget(v);
/* 35 */     this.gen.generateClass((ClassVisitor)this.t);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\TransformingClassGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */