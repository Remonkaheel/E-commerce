package org.springframework.cglib.transform;

import org.springframework.cglib.core.ClassEmitter;

public abstract class ClassEmitterTransformer extends ClassEmitter {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\ClassEmitterTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */