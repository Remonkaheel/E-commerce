/*     */ package org.springframework.cglib.transform;
/*     */ 
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.Handle;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.TypePath;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodVisitorTee
/*     */   extends MethodVisitor
/*     */ {
/*     */   private final MethodVisitor mv1;
/*     */   private final MethodVisitor mv2;
/*     */   
/*     */   public MethodVisitorTee(MethodVisitor mv1, MethodVisitor mv2) {
/*  32 */     super(Constants.ASM_API);
/*  33 */     this.mv1 = mv1;
/*  34 */     this.mv2 = mv2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {
/*  39 */     this.mv1.visitFrame(type, nLocal, local, nStack, stack);
/*  40 */     this.mv2.visitFrame(type, nLocal, local, nStack, stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotationDefault() {
/*  45 */     return AnnotationVisitorTee.getInstance(this.mv1.visitAnnotationDefault(), this.mv2
/*  46 */         .visitAnnotationDefault());
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
/*  51 */     return AnnotationVisitorTee.getInstance(this.mv1.visitAnnotation(desc, visible), this.mv2
/*  52 */         .visitAnnotation(desc, visible));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible) {
/*  59 */     return AnnotationVisitorTee.getInstance(this.mv1.visitParameterAnnotation(parameter, desc, visible), this.mv2
/*  60 */         .visitParameterAnnotation(parameter, desc, visible));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitAttribute(Attribute attr) {
/*  65 */     this.mv1.visitAttribute(attr);
/*  66 */     this.mv2.visitAttribute(attr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitCode() {
/*  71 */     this.mv1.visitCode();
/*  72 */     this.mv2.visitCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInsn(int opcode) {
/*  77 */     this.mv1.visitInsn(opcode);
/*  78 */     this.mv2.visitInsn(opcode);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand) {
/*  83 */     this.mv1.visitIntInsn(opcode, operand);
/*  84 */     this.mv2.visitIntInsn(opcode, operand);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitVarInsn(int opcode, int var) {
/*  89 */     this.mv1.visitVarInsn(opcode, var);
/*  90 */     this.mv2.visitVarInsn(opcode, var);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTypeInsn(int opcode, String desc) {
/*  95 */     this.mv1.visitTypeInsn(opcode, desc);
/*  96 */     this.mv2.visitTypeInsn(opcode, desc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String desc) {
/* 101 */     this.mv1.visitFieldInsn(opcode, owner, name, desc);
/* 102 */     this.mv2.visitFieldInsn(opcode, owner, name, desc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String desc) {
/* 107 */     this.mv1.visitMethodInsn(opcode, owner, name, desc);
/* 108 */     this.mv2.visitMethodInsn(opcode, owner, name, desc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/* 113 */     this.mv1.visitMethodInsn(opcode, owner, name, desc, itf);
/* 114 */     this.mv2.visitMethodInsn(opcode, owner, name, desc, itf);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label) {
/* 119 */     this.mv1.visitJumpInsn(opcode, label);
/* 120 */     this.mv2.visitJumpInsn(opcode, label);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLabel(Label label) {
/* 125 */     this.mv1.visitLabel(label);
/* 126 */     this.mv2.visitLabel(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLdcInsn(Object cst) {
/* 131 */     this.mv1.visitLdcInsn(cst);
/* 132 */     this.mv2.visitLdcInsn(cst);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIincInsn(int var, int increment) {
/* 137 */     this.mv1.visitIincInsn(var, increment);
/* 138 */     this.mv2.visitIincInsn(var, increment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
/* 143 */     this.mv1.visitTableSwitchInsn(min, max, dflt, labels);
/* 144 */     this.mv2.visitTableSwitchInsn(min, max, dflt, labels);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
/* 149 */     this.mv1.visitLookupSwitchInsn(dflt, keys, labels);
/* 150 */     this.mv2.visitLookupSwitchInsn(dflt, keys, labels);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMultiANewArrayInsn(String desc, int dims) {
/* 155 */     this.mv1.visitMultiANewArrayInsn(desc, dims);
/* 156 */     this.mv2.visitMultiANewArrayInsn(desc, dims);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
/* 161 */     this.mv1.visitTryCatchBlock(start, end, handler, type);
/* 162 */     this.mv2.visitTryCatchBlock(start, end, handler, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index) {
/* 167 */     this.mv1.visitLocalVariable(name, desc, signature, start, end, index);
/* 168 */     this.mv2.visitLocalVariable(name, desc, signature, start, end, index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLineNumber(int line, Label start) {
/* 173 */     this.mv1.visitLineNumber(line, start);
/* 174 */     this.mv2.visitLineNumber(line, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMaxs(int maxStack, int maxLocals) {
/* 179 */     this.mv1.visitMaxs(maxStack, maxLocals);
/* 180 */     this.mv2.visitMaxs(maxStack, maxLocals);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitEnd() {
/* 185 */     this.mv1.visitEnd();
/* 186 */     this.mv2.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitParameter(String name, int access) {
/* 191 */     this.mv1.visitParameter(name, access);
/* 192 */     this.mv2.visitParameter(name, access);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 197 */     return AnnotationVisitorTee.getInstance(this.mv1.visitTypeAnnotation(typeRef, typePath, desc, visible), this.mv2
/* 198 */         .visitTypeAnnotation(typeRef, typePath, desc, visible));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs) {
/* 203 */     this.mv1.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/* 204 */     this.mv2.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 209 */     return AnnotationVisitorTee.getInstance(this.mv1.visitInsnAnnotation(typeRef, typePath, desc, visible), this.mv2
/* 210 */         .visitInsnAnnotation(typeRef, typePath, desc, visible));
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 215 */     return AnnotationVisitorTee.getInstance(this.mv1.visitTryCatchAnnotation(typeRef, typePath, desc, visible), this.mv2
/* 216 */         .visitTryCatchAnnotation(typeRef, typePath, desc, visible));
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, int[] index, String desc, boolean visible) {
/* 221 */     return AnnotationVisitorTee.getInstance(this.mv1.visitLocalVariableAnnotation(typeRef, typePath, start, end, index, desc, visible), this.mv2
/* 222 */         .visitLocalVariableAnnotation(typeRef, typePath, start, end, index, desc, visible));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\MethodVisitorTee.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */