/*     */ package org.springframework.cglib.transform.impl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*     */ import org.springframework.cglib.core.ProcessSwitchCallback;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldProviderTransformer
/*     */   extends ClassEmitterTransformer
/*     */ {
/*     */   private static final String FIELD_NAMES = "CGLIB$FIELD_NAMES";
/*     */   private static final String FIELD_TYPES = "CGLIB$FIELD_TYPES";
/*  41 */   private static final Type FIELD_PROVIDER = TypeUtils.parseType("org.springframework.cglib.transform.impl.FieldProvider");
/*     */   
/*  43 */   private static final Type ILLEGAL_ARGUMENT_EXCEPTION = TypeUtils.parseType("IllegalArgumentException");
/*     */   
/*  45 */   private static final Signature PROVIDER_GET = TypeUtils.parseSignature("Object getField(String)");
/*     */   
/*  47 */   private static final Signature PROVIDER_SET = TypeUtils.parseSignature("void setField(String, Object)");
/*     */   
/*  49 */   private static final Signature PROVIDER_SET_BY_INDEX = TypeUtils.parseSignature("void setField(int, Object)");
/*     */   
/*  51 */   private static final Signature PROVIDER_GET_BY_INDEX = TypeUtils.parseSignature("Object getField(int)");
/*     */   
/*  53 */   private static final Signature PROVIDER_GET_TYPES = TypeUtils.parseSignature("Class[] getFieldTypes()");
/*     */   
/*  55 */   private static final Signature PROVIDER_GET_NAMES = TypeUtils.parseSignature("String[] getFieldNames()");
/*     */   
/*     */   private int access;
/*     */   
/*     */   private Map fields;
/*     */   
/*     */   public void begin_class(int version, int access, String className, Type superType, Type[] interfaces, String sourceFile) {
/*  62 */     if (!TypeUtils.isAbstract(access)) {
/*  63 */       interfaces = TypeUtils.add(interfaces, FIELD_PROVIDER);
/*     */     }
/*  65 */     this.access = access;
/*  66 */     this.fields = new HashMap<>();
/*  67 */     super.begin_class(version, access, className, superType, interfaces, sourceFile);
/*     */   }
/*     */ 
/*     */   
/*     */   public void declare_field(int access, String name, Type type, Object value) {
/*  72 */     super.declare_field(access, name, type, value);
/*     */     
/*  74 */     if (!TypeUtils.isStatic(access)) {
/*  75 */       this.fields.put(name, type);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void end_class() {
/*  81 */     if (!TypeUtils.isInterface(this.access)) {
/*     */       try {
/*  83 */         generate();
/*  84 */       } catch (RuntimeException e) {
/*  85 */         throw e;
/*  86 */       } catch (Exception e) {
/*  87 */         throw new CodeGenerationException(e);
/*     */       } 
/*     */     }
/*  90 */     super.end_class();
/*     */   }
/*     */   
/*     */   private void generate() throws Exception {
/*  94 */     String[] names = (String[])this.fields.keySet().toArray((Object[])new String[this.fields.size()]);
/*     */     
/*  96 */     int[] indexes = new int[names.length];
/*  97 */     for (int i = 0; i < indexes.length; i++) {
/*  98 */       indexes[i] = i;
/*     */     }
/*     */     
/* 101 */     super.declare_field(26, "CGLIB$FIELD_NAMES", Constants.TYPE_STRING_ARRAY, null);
/* 102 */     super.declare_field(26, "CGLIB$FIELD_TYPES", Constants.TYPE_CLASS_ARRAY, null);
/*     */ 
/*     */     
/* 105 */     initFieldProvider(names);
/* 106 */     getNames();
/* 107 */     getTypes();
/* 108 */     getField(names);
/* 109 */     setField(names);
/* 110 */     setByIndex(names, indexes);
/* 111 */     getByIndex(names, indexes);
/*     */   }
/*     */   
/*     */   private void initFieldProvider(String[] names) {
/* 115 */     CodeEmitter e = getStaticHook();
/* 116 */     EmitUtils.push_object(e, names);
/* 117 */     e.putstatic(getClassType(), "CGLIB$FIELD_NAMES", Constants.TYPE_STRING_ARRAY);
/*     */     
/* 119 */     e.push(names.length);
/* 120 */     e.newarray(Constants.TYPE_CLASS);
/* 121 */     e.dup();
/* 122 */     for (int i = 0; i < names.length; i++) {
/* 123 */       e.dup();
/* 124 */       e.push(i);
/* 125 */       Type type = (Type)this.fields.get(names[i]);
/* 126 */       EmitUtils.load_class(e, type);
/* 127 */       e.aastore();
/*     */     } 
/* 129 */     e.putstatic(getClassType(), "CGLIB$FIELD_TYPES", Constants.TYPE_CLASS_ARRAY);
/*     */   }
/*     */   
/*     */   private void getNames() {
/* 133 */     CodeEmitter e = begin_method(1, PROVIDER_GET_NAMES, null);
/* 134 */     e.getstatic(getClassType(), "CGLIB$FIELD_NAMES", Constants.TYPE_STRING_ARRAY);
/* 135 */     e.return_value();
/* 136 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void getTypes() {
/* 140 */     CodeEmitter e = begin_method(1, PROVIDER_GET_TYPES, null);
/* 141 */     e.getstatic(getClassType(), "CGLIB$FIELD_TYPES", Constants.TYPE_CLASS_ARRAY);
/* 142 */     e.return_value();
/* 143 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void setByIndex(final String[] names, int[] indexes) throws Exception {
/* 147 */     final CodeEmitter e = begin_method(1, PROVIDER_SET_BY_INDEX, null);
/* 148 */     e.load_this();
/* 149 */     e.load_arg(1);
/* 150 */     e.load_arg(0);
/* 151 */     e.process_switch(indexes, new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label end) throws Exception {
/* 154 */             Type type = (Type)FieldProviderTransformer.this.fields.get(names[key]);
/* 155 */             e.unbox(type);
/* 156 */             e.putfield(names[key]);
/* 157 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() throws Exception {
/* 161 */             e.throw_exception(FieldProviderTransformer.ILLEGAL_ARGUMENT_EXCEPTION, "Unknown field index");
/*     */           }
/*     */         });
/* 164 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void getByIndex(final String[] names, int[] indexes) throws Exception {
/* 168 */     final CodeEmitter e = begin_method(1, PROVIDER_GET_BY_INDEX, null);
/* 169 */     e.load_this();
/* 170 */     e.load_arg(0);
/* 171 */     e.process_switch(indexes, new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label end) throws Exception {
/* 174 */             Type type = (Type)FieldProviderTransformer.this.fields.get(names[key]);
/* 175 */             e.getfield(names[key]);
/* 176 */             e.box(type);
/* 177 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() throws Exception {
/* 181 */             e.throw_exception(FieldProviderTransformer.ILLEGAL_ARGUMENT_EXCEPTION, "Unknown field index");
/*     */           }
/*     */         });
/* 184 */     e.end_method();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void getField(String[] names) throws Exception {
/* 190 */     final CodeEmitter e = begin_method(1, PROVIDER_GET, null);
/* 191 */     e.load_this();
/* 192 */     e.load_arg(0);
/* 193 */     EmitUtils.string_switch(e, names, 1, new ObjectSwitchCallback()
/*     */         {
/*     */           public void processCase(Object key, Label end) {
/* 196 */             Type type = (Type)FieldProviderTransformer.this.fields.get(key);
/* 197 */             e.getfield((String)key);
/* 198 */             e.box(type);
/* 199 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 203 */             e.throw_exception(FieldProviderTransformer.ILLEGAL_ARGUMENT_EXCEPTION, "Unknown field name");
/*     */           }
/*     */         });
/* 206 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void setField(String[] names) throws Exception {
/* 210 */     final CodeEmitter e = begin_method(1, PROVIDER_SET, null);
/* 211 */     e.load_this();
/* 212 */     e.load_arg(1);
/* 213 */     e.load_arg(0);
/* 214 */     EmitUtils.string_switch(e, names, 1, new ObjectSwitchCallback()
/*     */         {
/*     */           public void processCase(Object key, Label end) {
/* 217 */             Type type = (Type)FieldProviderTransformer.this.fields.get(key);
/* 218 */             e.unbox(type);
/* 219 */             e.putfield((String)key);
/* 220 */             e.return_value();
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 224 */             e.throw_exception(FieldProviderTransformer.ILLEGAL_ARGUMENT_EXCEPTION, "Unknown field name");
/*     */           }
/*     */         });
/* 227 */     e.end_method();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\FieldProviderTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */