/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import org.springframework.cglib.core.ClassGenerator;
/*    */ import org.springframework.cglib.core.ClassTransformer;
/*    */ import org.springframework.cglib.core.DefaultGeneratorStrategy;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ import org.springframework.cglib.transform.MethodFilter;
/*    */ import org.springframework.cglib.transform.MethodFilterTransformer;
/*    */ import org.springframework.cglib.transform.TransformingClassGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UndeclaredThrowableStrategy
/*    */   extends DefaultGeneratorStrategy
/*    */ {
/*    */   private Class wrapper;
/*    */   private static final MethodFilter TRANSFORM_FILTER;
/*    */   
/*    */   public UndeclaredThrowableStrategy(Class wrapper) {
/* 46 */     this.wrapper = wrapper;
/*    */   }
/*    */   static {
/* 49 */     TRANSFORM_FILTER = ((access, name, desc, signature, exceptions) -> (!TypeUtils.isPrivate(access) && name.indexOf('$') < 0));
/*    */   }
/*    */   
/*    */   protected ClassGenerator transform(ClassGenerator cg) throws Exception {
/* 53 */     UndeclaredThrowableTransformer undeclaredThrowableTransformer = new UndeclaredThrowableTransformer(this.wrapper);
/* 54 */     MethodFilterTransformer methodFilterTransformer = new MethodFilterTransformer(TRANSFORM_FILTER, (ClassTransformer)undeclaredThrowableTransformer);
/* 55 */     return (ClassGenerator)new TransformingClassGenerator(cg, (ClassTransformer)methodFilterTransformer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\UndeclaredThrowableStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */