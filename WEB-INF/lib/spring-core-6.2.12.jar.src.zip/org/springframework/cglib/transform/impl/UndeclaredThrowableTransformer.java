/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.Block;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ import org.springframework.cglib.core.EmitUtils;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UndeclaredThrowableTransformer
/*    */   extends ClassEmitterTransformer
/*    */ {
/*    */   private final Type wrapper;
/*    */   
/*    */   public UndeclaredThrowableTransformer(Class wrapper) {
/* 36 */     this.wrapper = Type.getType(wrapper);
/* 37 */     boolean found = false;
/* 38 */     Constructor[] cstructs = (Constructor[])wrapper.getConstructors();
/* 39 */     for (Constructor cstruct : cstructs) {
/* 40 */       Class[] types = cstruct.getParameterTypes();
/* 41 */       if (types.length == 1 && types[0].equals(Throwable.class)) {
/* 42 */         found = true;
/*    */         break;
/*    */       } 
/*    */     } 
/* 46 */     if (!found) {
/* 47 */       throw new IllegalArgumentException(String.valueOf(wrapper) + " does not have a single-arg constructor that takes a Throwable");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public CodeEmitter begin_method(int access, final Signature sig, final Type[] exceptions) {
/* 53 */     CodeEmitter e = super.begin_method(access, sig, exceptions);
/* 54 */     if (TypeUtils.isAbstract(access) || sig.equals(Constants.SIG_STATIC)) {
/* 55 */       return e;
/*    */     }
/* 57 */     return new CodeEmitter(e) {
/* 58 */         private final boolean isConstructor = "<init>".equals(sig.getName());
/* 59 */         private Block handler = begin_block();
/*    */         private boolean callToSuperSeen;
/*    */         
/*    */         public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
/* 63 */           super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
/* 64 */           if (this.isConstructor && !this.callToSuperSeen && "<init>".equals(name)) {
/*    */             
/* 66 */             this.handler = begin_block();
/* 67 */             this.callToSuperSeen = true;
/*    */           } 
/*    */         }
/*    */         
/*    */         public void visitMaxs(int maxStack, int maxLocals) {
/* 72 */           this.handler.end();
/* 73 */           EmitUtils.wrap_undeclared_throwable(this, this.handler, exceptions, UndeclaredThrowableTransformer.this.wrapper);
/* 74 */           super.visitMaxs(maxStack, maxLocals);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\UndeclaredThrowableTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */