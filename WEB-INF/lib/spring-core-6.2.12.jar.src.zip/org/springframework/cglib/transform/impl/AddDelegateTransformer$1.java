/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends CodeEmitter
/*    */ {
/*    */   private boolean transformInit;
/*    */   
/*    */   null(CodeEmitter wrap) {
/* 85 */     super(wrap);
/* 86 */     this.transformInit = true;
/*    */   }
/*    */   public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/* 89 */     super.visitMethodInsn(opcode, owner, name, desc, itf);
/* 90 */     if (this.transformInit && opcode == 183) {
/* 91 */       load_this();
/* 92 */       new_instance(AddDelegateTransformer.this.delegateType);
/* 93 */       dup();
/* 94 */       load_this();
/* 95 */       invoke_constructor(AddDelegateTransformer.this.delegateType, AddDelegateTransformer.CSTRUCT_OBJECT);
/* 96 */       putfield("$CGLIB_DELEGATE");
/* 97 */       this.transformInit = false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AddDelegateTransformer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */