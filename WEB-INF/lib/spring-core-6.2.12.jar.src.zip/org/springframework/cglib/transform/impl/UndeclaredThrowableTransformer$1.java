/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.Block;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.EmitUtils;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends CodeEmitter
/*    */ {
/*    */   private final boolean isConstructor;
/*    */   private Block handler;
/*    */   private boolean callToSuperSeen;
/*    */   
/*    */   null(CodeEmitter wrap) {
/* 57 */     super(wrap);
/* 58 */     this.isConstructor = "<init>".equals(sig.getName());
/* 59 */     this.handler = begin_block();
/*    */   }
/*    */   
/*    */   public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
/* 63 */     super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
/* 64 */     if (this.isConstructor && !this.callToSuperSeen && "<init>".equals(name)) {
/*    */       
/* 66 */       this.handler = begin_block();
/* 67 */       this.callToSuperSeen = true;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void visitMaxs(int maxStack, int maxLocals) {
/* 72 */     this.handler.end();
/* 73 */     EmitUtils.wrap_undeclared_throwable(this, this.handler, exceptions, UndeclaredThrowableTransformer.this.wrapper);
/* 74 */     super.visitMaxs(maxStack, maxLocals);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\UndeclaredThrowableTransformer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */