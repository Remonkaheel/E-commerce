/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends CodeEmitter
/*    */ {
/*    */   null(CodeEmitter wrap) {
/* 50 */     super(wrap);
/*    */   }
/*    */   public void visitInsn(int opcode) {
/* 53 */     if (opcode == 177) {
/* 54 */       load_this();
/* 55 */       invoke(AddInitTransformer.this.info);
/*    */     } 
/* 57 */     super.visitInsn(opcode);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AddInitTransformer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */