package org.springframework.cglib.transform.impl;

import org.springframework.asm.Type;

public interface Callback {
  String getPropertyName(Type paramType, String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AccessFieldTransformer$Callback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */