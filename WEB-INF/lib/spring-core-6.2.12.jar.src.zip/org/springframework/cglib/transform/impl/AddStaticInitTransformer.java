/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ import org.springframework.cglib.core.EmitUtils;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.ReflectUtils;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddStaticInitTransformer
/*    */   extends ClassEmitterTransformer
/*    */ {
/*    */   private MethodInfo info;
/*    */   
/*    */   public AddStaticInitTransformer(Method classInit) {
/* 36 */     this.info = ReflectUtils.getMethodInfo(classInit);
/* 37 */     if (!TypeUtils.isStatic(this.info.getModifiers())) {
/* 38 */       throw new IllegalArgumentException(String.valueOf(classInit) + " is not static");
/*    */     }
/* 40 */     Type[] types = this.info.getSignature().getArgumentTypes();
/* 41 */     if (types.length != 1 || 
/* 42 */       !types[0].equals(Constants.TYPE_CLASS) || 
/* 43 */       !this.info.getSignature().getReturnType().equals(Type.VOID_TYPE)) {
/* 44 */       throw new IllegalArgumentException(String.valueOf(classInit) + " illegal signature");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void init() {
/* 50 */     if (!TypeUtils.isInterface(getAccess())) {
/* 51 */       CodeEmitter e = getStaticHook();
/* 52 */       EmitUtils.load_class_this(e);
/* 53 */       e.invoke(this.info);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AddStaticInitTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */