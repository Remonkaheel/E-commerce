/*     */ package org.springframework.cglib.transform.impl;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddDelegateTransformer
/*     */   extends ClassEmitterTransformer
/*     */ {
/*     */   private static final String DELEGATE = "$CGLIB_DELEGATE";
/*  38 */   private static final Signature CSTRUCT_OBJECT = TypeUtils.parseSignature("void <init>(Object)");
/*     */   
/*     */   private Class[] delegateIf;
/*     */   
/*     */   private Class delegateImpl;
/*     */   private Type delegateType;
/*     */   
/*     */   public AddDelegateTransformer(Class[] delegateIf, Class delegateImpl) {
/*     */     try {
/*  47 */       delegateImpl.getConstructor(new Class[] { Object.class });
/*  48 */       this.delegateIf = delegateIf;
/*  49 */       this.delegateImpl = delegateImpl;
/*  50 */       this.delegateType = Type.getType(delegateImpl);
/*  51 */     } catch (NoSuchMethodException e) {
/*  52 */       throw new CodeGenerationException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void begin_class(int version, int access, String className, Type superType, Type[] interfaces, String sourceFile) {
/*  59 */     if (!TypeUtils.isInterface(access)) {
/*     */       
/*  61 */       Type[] all = TypeUtils.add(interfaces, TypeUtils.getTypes(this.delegateIf));
/*  62 */       super.begin_class(version, access, className, superType, all, sourceFile);
/*     */       
/*  64 */       declare_field(130, "$CGLIB_DELEGATE", this.delegateType, null);
/*     */ 
/*     */ 
/*     */       
/*  68 */       for (Class element : this.delegateIf) {
/*  69 */         Method[] methods = element.getMethods();
/*  70 */         for (Method method : methods) {
/*  71 */           if (Modifier.isAbstract(method.getModifiers())) {
/*  72 */             addDelegate(method);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*  77 */       super.begin_class(version, access, className, superType, interfaces, sourceFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CodeEmitter begin_method(int access, Signature sig, Type[] exceptions) {
/*  83 */     CodeEmitter e = super.begin_method(access, sig, exceptions);
/*  84 */     if (sig.getName().equals("<init>")) {
/*  85 */       return new CodeEmitter(e) {
/*     */           private boolean transformInit = true;
/*     */           
/*     */           public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/*  89 */             super.visitMethodInsn(opcode, owner, name, desc, itf);
/*  90 */             if (this.transformInit && opcode == 183) {
/*  91 */               load_this();
/*  92 */               new_instance(AddDelegateTransformer.this.delegateType);
/*  93 */               dup();
/*  94 */               load_this();
/*  95 */               invoke_constructor(AddDelegateTransformer.this.delegateType, AddDelegateTransformer.CSTRUCT_OBJECT);
/*  96 */               putfield("$CGLIB_DELEGATE");
/*  97 */               this.transformInit = false;
/*     */             } 
/*     */           }
/*     */         };
/*     */     }
/* 102 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addDelegate(Method m) {
/*     */     try {
/* 108 */       Method delegate = this.delegateImpl.getMethod(m.getName(), m.getParameterTypes());
/* 109 */       if (!delegate.getReturnType().getName().equals(m.getReturnType().getName())) {
/* 110 */         throw new IllegalArgumentException("Invalid delegate signature " + String.valueOf(delegate));
/*     */       }
/* 112 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 113 */       throw new CodeGenerationException(noSuchMethodException);
/*     */     } 
/*     */     
/* 116 */     Signature sig = ReflectUtils.getSignature(m);
/* 117 */     Type[] exceptions = TypeUtils.getTypes(m.getExceptionTypes());
/* 118 */     CodeEmitter e = super.begin_method(1, sig, exceptions);
/* 119 */     e.load_this();
/* 120 */     e.getfield("$CGLIB_DELEGATE");
/* 121 */     e.load_args();
/* 122 */     e.invoke_virtual(this.delegateType, sig);
/* 123 */     e.return_value();
/* 124 */     e.end_method();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AddDelegateTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */