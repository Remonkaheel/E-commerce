package org.springframework.cglib.transform.impl;

public interface InterceptFieldEnabled {
  void setInterceptFieldCallback(InterceptFieldCallback paramInterceptFieldCallback);
  
  InterceptFieldCallback getInterceptFieldCallback();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\InterceptFieldEnabled.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */