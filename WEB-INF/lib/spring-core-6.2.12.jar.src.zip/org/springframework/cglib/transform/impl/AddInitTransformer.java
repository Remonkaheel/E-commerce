/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.ReflectUtils;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddInitTransformer
/*    */   extends ClassEmitterTransformer
/*    */ {
/*    */   private MethodInfo info;
/*    */   
/*    */   public AddInitTransformer(Method method) {
/* 36 */     this.info = ReflectUtils.getMethodInfo(method);
/*    */     
/* 38 */     Type[] types = this.info.getSignature().getArgumentTypes();
/* 39 */     if (types.length != 1 || 
/* 40 */       !types[0].equals(Constants.TYPE_OBJECT) || 
/* 41 */       !this.info.getSignature().getReturnType().equals(Type.VOID_TYPE)) {
/* 42 */       throw new IllegalArgumentException(String.valueOf(method) + " illegal signature");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public CodeEmitter begin_method(int access, Signature sig, Type[] exceptions) {
/* 48 */     CodeEmitter emitter = super.begin_method(access, sig, exceptions);
/* 49 */     if (sig.getName().equals("<init>")) {
/* 50 */       return new CodeEmitter(emitter)
/*    */         {
/*    */           public void visitInsn(int opcode) {
/* 53 */             if (opcode == 177) {
/* 54 */               load_this();
/* 55 */               invoke(AddInitTransformer.this.info);
/*    */             } 
/* 57 */             super.visitInsn(opcode);
/*    */           }
/*    */         };
/*    */     }
/* 61 */     return emitter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AddInitTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */