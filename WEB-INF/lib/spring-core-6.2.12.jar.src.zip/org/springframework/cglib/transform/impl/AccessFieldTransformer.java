/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessFieldTransformer
/*    */   extends ClassEmitterTransformer
/*    */ {
/*    */   private Callback callback;
/*    */   
/*    */   public AccessFieldTransformer(Callback callback) {
/* 30 */     this.callback = callback;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void declare_field(int access, String name, Type type, Object value) {
/* 39 */     super.declare_field(access, name, type, value);
/*    */     
/* 41 */     String property = TypeUtils.upperFirst(this.callback.getPropertyName(getClassType(), name));
/* 42 */     if (property != null) {
/*    */       
/* 44 */       CodeEmitter e = begin_method(1, new Signature("get" + property, type, Constants.TYPES_EMPTY), null);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 49 */       e.load_this();
/* 50 */       e.getfield(name);
/* 51 */       e.return_value();
/* 52 */       e.end_method();
/*    */       
/* 54 */       e = begin_method(1, new Signature("set" + property, Type.VOID_TYPE, new Type[] { type }), null);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 59 */       e.load_this();
/* 60 */       e.load_arg(0);
/* 61 */       e.putfield(name);
/* 62 */       e.return_value();
/* 63 */       e.end_method();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static interface Callback {
/*    */     String getPropertyName(Type param1Type, String param1String);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AccessFieldTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */