/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.ClassEmitter;
/*    */ import org.springframework.cglib.core.EmitUtils;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddPropertyTransformer
/*    */   extends ClassEmitterTransformer
/*    */ {
/*    */   private final String[] names;
/*    */   private final Type[] types;
/*    */   
/*    */   public AddPropertyTransformer(Map props) {
/* 31 */     int size = props.size();
/* 32 */     this.names = (String[])props.keySet().toArray((Object[])new String[size]);
/* 33 */     this.types = new Type[size];
/* 34 */     for (int i = 0; i < size; i++) {
/* 35 */       this.types[i] = (Type)props.get(this.names[i]);
/*    */     }
/*    */   }
/*    */   
/*    */   public AddPropertyTransformer(String[] names, Type[] types) {
/* 40 */     this.names = names;
/* 41 */     this.types = types;
/*    */   }
/*    */ 
/*    */   
/*    */   public void end_class() {
/* 46 */     if (!TypeUtils.isAbstract(getAccess())) {
/* 47 */       EmitUtils.add_properties((ClassEmitter)this, this.names, this.types);
/*    */     }
/* 49 */     super.end_class();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AddPropertyTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */