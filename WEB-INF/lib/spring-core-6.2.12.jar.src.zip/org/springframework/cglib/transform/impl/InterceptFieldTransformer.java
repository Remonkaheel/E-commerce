/*     */ package org.springframework.cglib.transform.impl;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterceptFieldTransformer
/*     */   extends ClassEmitterTransformer
/*     */ {
/*     */   private static final String CALLBACK_FIELD = "$CGLIB_READ_WRITE_CALLBACK";
/*  33 */   private static final Type CALLBACK = TypeUtils.parseType("org.springframework.cglib.transform.impl.InterceptFieldCallback");
/*     */   
/*  35 */   private static final Type ENABLED = TypeUtils.parseType("org.springframework.cglib.transform.impl.InterceptFieldEnabled");
/*  36 */   private static final Signature ENABLED_SET = new Signature("setInterceptFieldCallback", Type.VOID_TYPE, new Type[] { CALLBACK });
/*     */   
/*  38 */   private static final Signature ENABLED_GET = new Signature("getInterceptFieldCallback", CALLBACK, new Type[0]);
/*     */   
/*     */   private InterceptFieldFilter filter;
/*     */ 
/*     */   
/*     */   public InterceptFieldTransformer(InterceptFieldFilter filter) {
/*  44 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void begin_class(int version, int access, String className, Type superType, Type[] interfaces, String sourceFile) {
/*  49 */     if (!TypeUtils.isInterface(access)) {
/*  50 */       super.begin_class(version, access, className, superType, TypeUtils.add(interfaces, ENABLED), sourceFile);
/*     */       
/*  52 */       super.declare_field(130, "$CGLIB_READ_WRITE_CALLBACK", CALLBACK, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  58 */       CodeEmitter e = super.begin_method(1, ENABLED_GET, null);
/*  59 */       e.load_this();
/*  60 */       e.getfield("$CGLIB_READ_WRITE_CALLBACK");
/*  61 */       e.return_value();
/*  62 */       e.end_method();
/*     */       
/*  64 */       e = super.begin_method(1, ENABLED_SET, null);
/*  65 */       e.load_this();
/*  66 */       e.load_arg(0);
/*  67 */       e.putfield("$CGLIB_READ_WRITE_CALLBACK");
/*  68 */       e.return_value();
/*  69 */       e.end_method();
/*     */     } else {
/*  71 */       super.begin_class(version, access, className, superType, interfaces, sourceFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void declare_field(int access, String name, Type type, Object value) {
/*  77 */     super.declare_field(access, name, type, value);
/*  78 */     if (!TypeUtils.isStatic(access)) {
/*  79 */       if (this.filter.acceptRead(getClassType(), name)) {
/*  80 */         addReadMethod(name, type);
/*     */       }
/*  82 */       if (this.filter.acceptWrite(getClassType(), name)) {
/*  83 */         addWriteMethod(name, type);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addReadMethod(String name, Type type) {
/*  89 */     CodeEmitter e = super.begin_method(1, 
/*  90 */         readMethodSig(name, type.getDescriptor()), null);
/*     */     
/*  92 */     e.load_this();
/*  93 */     e.getfield(name);
/*  94 */     e.load_this();
/*  95 */     e.invoke_interface(ENABLED, ENABLED_GET);
/*  96 */     Label intercept = e.make_label();
/*  97 */     e.ifnonnull(intercept);
/*  98 */     e.return_value();
/*     */     
/* 100 */     e.mark(intercept);
/* 101 */     Local result = e.make_local(type);
/* 102 */     e.store_local(result);
/* 103 */     e.load_this();
/* 104 */     e.invoke_interface(ENABLED, ENABLED_GET);
/* 105 */     e.load_this();
/* 106 */     e.push(name);
/* 107 */     e.load_local(result);
/* 108 */     e.invoke_interface(CALLBACK, readCallbackSig(type));
/* 109 */     if (!TypeUtils.isPrimitive(type)) {
/* 110 */       e.checkcast(type);
/*     */     }
/* 112 */     e.return_value();
/* 113 */     e.end_method();
/*     */   }
/*     */   
/*     */   private void addWriteMethod(String name, Type type) {
/* 117 */     CodeEmitter e = super.begin_method(1, 
/* 118 */         writeMethodSig(name, type.getDescriptor()), null);
/*     */     
/* 120 */     e.load_this();
/* 121 */     e.dup();
/* 122 */     e.invoke_interface(ENABLED, ENABLED_GET);
/* 123 */     Label skip = e.make_label();
/* 124 */     e.ifnull(skip);
/*     */     
/* 126 */     e.load_this();
/* 127 */     e.invoke_interface(ENABLED, ENABLED_GET);
/* 128 */     e.load_this();
/* 129 */     e.push(name);
/* 130 */     e.load_this();
/* 131 */     e.getfield(name);
/* 132 */     e.load_arg(0);
/* 133 */     e.invoke_interface(CALLBACK, writeCallbackSig(type));
/* 134 */     if (!TypeUtils.isPrimitive(type)) {
/* 135 */       e.checkcast(type);
/*     */     }
/* 137 */     Label go = e.make_label();
/* 138 */     e.goTo(go);
/* 139 */     e.mark(skip);
/* 140 */     e.load_arg(0);
/* 141 */     e.mark(go);
/* 142 */     e.putfield(name);
/* 143 */     e.return_value();
/* 144 */     e.end_method();
/*     */   }
/*     */ 
/*     */   
/*     */   public CodeEmitter begin_method(int access, Signature sig, Type[] exceptions) {
/* 149 */     return new CodeEmitter(super.begin_method(access, sig, exceptions))
/*     */       {
/*     */         public void visitFieldInsn(int opcode, String owner, String name, String desc) {
/* 152 */           Type towner = TypeUtils.fromInternalName(owner);
/* 153 */           switch (opcode) {
/*     */             case 180:
/* 155 */               if (InterceptFieldTransformer.this.filter.acceptRead(towner, name)) {
/* 156 */                 helper(towner, InterceptFieldTransformer.readMethodSig(name, desc));
/*     */                 return;
/*     */               } 
/*     */               break;
/*     */             case 181:
/* 161 */               if (InterceptFieldTransformer.this.filter.acceptWrite(towner, name)) {
/* 162 */                 helper(towner, InterceptFieldTransformer.writeMethodSig(name, desc));
/*     */                 return;
/*     */               } 
/*     */               break;
/*     */           } 
/* 167 */           super.visitFieldInsn(opcode, owner, name, desc);
/*     */         }
/*     */         
/*     */         private void helper(Type owner, Signature sig) {
/* 171 */           invoke_virtual(owner, sig);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private static Signature readMethodSig(String name, String desc) {
/* 177 */     return new Signature("$cglib_read_" + name, "()" + desc);
/*     */   }
/*     */   
/*     */   private static Signature writeMethodSig(String name, String desc) {
/* 181 */     return new Signature("$cglib_write_" + name, "(" + desc + ")V");
/*     */   }
/*     */   
/*     */   private static Signature readCallbackSig(Type type) {
/* 185 */     Type remap = remap(type);
/* 186 */     return new Signature("read" + callbackName(remap), remap, new Type[] { Constants.TYPE_OBJECT, Constants.TYPE_STRING, remap });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Signature writeCallbackSig(Type type) {
/* 194 */     Type remap = remap(type);
/* 195 */     return new Signature("write" + callbackName(remap), remap, new Type[] { Constants.TYPE_OBJECT, Constants.TYPE_STRING, remap, remap });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Type remap(Type type) {
/* 204 */     switch (type.getSort()) {
/*     */       case 9:
/*     */       case 10:
/* 207 */         return Constants.TYPE_OBJECT;
/*     */     } 
/* 209 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String callbackName(Type type) {
/* 214 */     return (type == Constants.TYPE_OBJECT) ? 
/* 215 */       "Object" : 
/* 216 */       TypeUtils.upperFirst(TypeUtils.getClassName(type));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\InterceptFieldTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */