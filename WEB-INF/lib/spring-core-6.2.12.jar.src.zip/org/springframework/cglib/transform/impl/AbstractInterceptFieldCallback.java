/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractInterceptFieldCallback
/*    */   implements InterceptFieldCallback
/*    */ {
/*    */   public int writeInt(Object obj, String name, int oldValue, int newValue) {
/* 24 */     return newValue;
/*    */   } public char writeChar(Object obj, String name, char oldValue, char newValue) {
/* 26 */     return newValue;
/*    */   } public byte writeByte(Object obj, String name, byte oldValue, byte newValue) {
/* 28 */     return newValue;
/*    */   } public boolean writeBoolean(Object obj, String name, boolean oldValue, boolean newValue) {
/* 30 */     return newValue;
/*    */   } public short writeShort(Object obj, String name, short oldValue, short newValue) {
/* 32 */     return newValue;
/*    */   } public float writeFloat(Object obj, String name, float oldValue, float newValue) {
/* 34 */     return newValue;
/*    */   } public double writeDouble(Object obj, String name, double oldValue, double newValue) {
/* 36 */     return newValue;
/*    */   } public long writeLong(Object obj, String name, long oldValue, long newValue) {
/* 38 */     return newValue;
/*    */   } public Object writeObject(Object obj, String name, Object oldValue, Object newValue) {
/* 40 */     return newValue;
/*    */   }
/*    */   public int readInt(Object obj, String name, int oldValue) {
/* 43 */     return oldValue;
/*    */   } public char readChar(Object obj, String name, char oldValue) {
/* 45 */     return oldValue;
/*    */   } public byte readByte(Object obj, String name, byte oldValue) {
/* 47 */     return oldValue;
/*    */   } public boolean readBoolean(Object obj, String name, boolean oldValue) {
/* 49 */     return oldValue;
/*    */   } public short readShort(Object obj, String name, short oldValue) {
/* 51 */     return oldValue;
/*    */   } public float readFloat(Object obj, String name, float oldValue) {
/* 53 */     return oldValue;
/*    */   } public double readDouble(Object obj, String name, double oldValue) {
/* 55 */     return oldValue;
/*    */   } public long readLong(Object obj, String name, long oldValue) {
/* 57 */     return oldValue;
/*    */   } public Object readObject(Object obj, String name, Object oldValue) {
/* 59 */     return oldValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\impl\AbstractInterceptFieldCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */