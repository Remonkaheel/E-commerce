/*     */ package org.springframework.cglib.transform;
/*     */ 
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.FieldVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.TypePath;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassVisitorTee
/*     */   extends ClassVisitor
/*     */ {
/*     */   private ClassVisitor cv1;
/*     */   private ClassVisitor cv2;
/*     */   
/*     */   public ClassVisitorTee(ClassVisitor cv1, ClassVisitor cv2) {
/*  30 */     super(Constants.ASM_API);
/*  31 */     this.cv1 = cv1;
/*  32 */     this.cv2 = cv2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/*  42 */     this.cv1.visit(version, access, name, signature, superName, interfaces);
/*  43 */     this.cv2.visit(version, access, name, signature, superName, interfaces);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitEnd() {
/*  48 */     this.cv1.visitEnd();
/*  49 */     this.cv2.visitEnd();
/*  50 */     this.cv1 = this.cv2 = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInnerClass(String name, String outerName, String innerName, int access) {
/*  55 */     this.cv1.visitInnerClass(name, outerName, innerName, access);
/*  56 */     this.cv2.visitInnerClass(name, outerName, innerName, access);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
/*  65 */     FieldVisitor fv1 = this.cv1.visitField(access, name, desc, signature, value);
/*  66 */     FieldVisitor fv2 = this.cv2.visitField(access, name, desc, signature, value);
/*  67 */     if (fv1 == null) {
/*  68 */       return fv2;
/*     */     }
/*  70 */     if (fv2 == null) {
/*  71 */       return fv1;
/*     */     }
/*  73 */     return new FieldVisitorTee(fv1, fv2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/*  83 */     MethodVisitor mv1 = this.cv1.visitMethod(access, name, desc, signature, exceptions);
/*  84 */     MethodVisitor mv2 = this.cv2.visitMethod(access, name, desc, signature, exceptions);
/*  85 */     if (mv1 == null) {
/*  86 */       return mv2;
/*     */     }
/*  88 */     if (mv2 == null) {
/*  89 */       return mv1;
/*     */     }
/*  91 */     return new MethodVisitorTee(mv1, mv2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitSource(String source, String debug) {
/*  96 */     this.cv1.visitSource(source, debug);
/*  97 */     this.cv2.visitSource(source, debug);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitOuterClass(String owner, String name, String desc) {
/* 102 */     this.cv1.visitOuterClass(owner, name, desc);
/* 103 */     this.cv2.visitOuterClass(owner, name, desc);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
/* 108 */     return AnnotationVisitorTee.getInstance(this.cv1.visitAnnotation(desc, visible), this.cv2
/* 109 */         .visitAnnotation(desc, visible));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitAttribute(Attribute attrs) {
/* 114 */     this.cv1.visitAttribute(attrs);
/* 115 */     this.cv2.visitAttribute(attrs);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 120 */     return AnnotationVisitorTee.getInstance(this.cv1.visitTypeAnnotation(typeRef, typePath, desc, visible), this.cv2
/* 121 */         .visitTypeAnnotation(typeRef, typePath, desc, visible));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\ClassVisitorTee.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */