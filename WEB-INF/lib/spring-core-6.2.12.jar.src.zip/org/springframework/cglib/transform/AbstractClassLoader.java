/*     */ package org.springframework.cglib.transform;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.ClassGenerator;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.DebuggingClassWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractClassLoader
/*     */   extends ClassLoader
/*     */ {
/*     */   private ClassFilter filter;
/*     */   private ClassLoader classPath;
/*  34 */   private static ProtectionDomain DOMAIN = AbstractClassLoader.class.getProtectionDomain();
/*     */ 
/*     */   
/*     */   protected AbstractClassLoader(ClassLoader parent, ClassLoader classPath, ClassFilter filter) {
/*  38 */     super(parent);
/*  39 */     this.filter = filter;
/*  40 */     this.classPath = classPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class loadClass(String name) throws ClassNotFoundException {
/*     */     ClassReader r;
/*  46 */     Class<?> loaded = findLoadedClass(name);
/*     */     
/*  48 */     if (loaded != null && 
/*  49 */       loaded.getClassLoader() == this) {
/*  50 */       return loaded;
/*     */     }
/*     */ 
/*     */     
/*  54 */     if (!this.filter.accept(name)) {
/*  55 */       return super.loadClass(name);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  60 */       InputStream is = this.classPath.getResourceAsStream(name
/*  61 */           .replace('.', '/') + ".class");
/*     */ 
/*     */       
/*  64 */       if (is == null)
/*     */       {
/*  66 */         throw new ClassNotFoundException(name);
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/*  71 */         r = new ClassReader(is);
/*     */       }
/*     */       finally {
/*     */         
/*  75 */         is.close();
/*     */       }
/*     */     
/*  78 */     } catch (IOException e) {
/*  79 */       throw new ClassNotFoundException(name + ":" + name);
/*     */     } 
/*     */     
/*     */     try {
/*  83 */       DebuggingClassWriter w = new DebuggingClassWriter(2);
/*     */       
/*  85 */       getGenerator(r).generateClass((ClassVisitor)w);
/*  86 */       byte[] b = w.toByteArray();
/*  87 */       Class<?> c = defineClass(name, b, 0, b.length, DOMAIN);
/*  88 */       postProcess(c);
/*  89 */       return c;
/*  90 */     } catch (RuntimeException|Error e) {
/*  91 */       throw e;
/*  92 */     } catch (Exception e) {
/*  93 */       throw new CodeGenerationException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ClassGenerator getGenerator(ClassReader r) {
/*  98 */     return new ClassReaderGenerator(r, attributes(), getFlags());
/*     */   }
/*     */   
/*     */   protected int getFlags() {
/* 102 */     return 0;
/*     */   }
/*     */   
/*     */   protected Attribute[] attributes() {
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   protected void postProcess(Class c) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\transform\AbstractClassLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */