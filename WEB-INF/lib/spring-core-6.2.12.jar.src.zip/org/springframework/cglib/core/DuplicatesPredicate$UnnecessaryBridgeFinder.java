/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UnnecessaryBridgeFinder
/*     */   extends ClassVisitor
/*     */ {
/*     */   private final Set rejected;
/* 125 */   private Signature currentMethodSig = null;
/* 126 */   private Map methods = new HashMap<>();
/*     */   
/*     */   UnnecessaryBridgeFinder(Set rejected) {
/* 129 */     super(Constants.ASM_API);
/* 130 */     this.rejected = rejected;
/*     */   }
/*     */   
/*     */   void addSuspectMethod(Method m) {
/* 134 */     this.methods.put(ReflectUtils.getSignature(m), m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 149 */     Signature sig = new Signature(name, desc);
/* 150 */     final Method currentMethod = (Method)this.methods.remove(sig);
/* 151 */     if (currentMethod != null) {
/* 152 */       this.currentMethodSig = sig;
/* 153 */       return new MethodVisitor(Constants.ASM_API)
/*     */         {
/*     */           public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf)
/*     */           {
/* 157 */             if (opcode == 183 && DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig != null) {
/* 158 */               Signature target = new Signature(name, desc);
/* 159 */               if (target.equals(DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig)) {
/* 160 */                 DuplicatesPredicate.UnnecessaryBridgeFinder.this.rejected.add(currentMethod);
/*     */               }
/* 162 */               DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig = null;
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/* 167 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\DuplicatesPredicate$UnnecessaryBridgeFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */