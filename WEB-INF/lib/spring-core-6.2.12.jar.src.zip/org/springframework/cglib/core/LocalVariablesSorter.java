/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariablesSorter
/*     */   extends MethodVisitor
/*     */ {
/*     */   protected final int firstLocal;
/*     */   private final State state;
/*     */   
/*     */   private static class State
/*     */   {
/*  54 */     int[] mapping = new int[40];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int nextLocal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariablesSorter(int access, String desc, MethodVisitor mv) {
/*  66 */     super(Constants.ASM_API, mv);
/*  67 */     this.state = new State();
/*  68 */     Type[] args = Type.getArgumentTypes(desc);
/*  69 */     this.state.nextLocal = ((0x8 & access) != 0) ? 0 : 1;
/*  70 */     for (Type arg : args) {
/*  71 */       this.state.nextLocal += arg.getSize();
/*     */     }
/*  73 */     this.firstLocal = this.state.nextLocal;
/*     */   }
/*     */   
/*     */   public LocalVariablesSorter(LocalVariablesSorter lvs) {
/*  77 */     super(Constants.ASM_API, lvs.mv);
/*  78 */     this.state = lvs.state;
/*  79 */     this.firstLocal = lvs.firstLocal;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitVarInsn(int opcode, int var) {
/*  84 */     switch (opcode) { case 22: case 24: case 55: case 57: 
/*     */       default:
/*  86 */         break; }  int size = 1;
/*     */     
/*  88 */     this.mv.visitVarInsn(opcode, remap(var, size));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIincInsn(int var, int increment) {
/*  93 */     this.mv.visitIincInsn(remap(var, 1), increment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMaxs(int maxStack, int maxLocals) {
/*  98 */     this.mv.visitMaxs(maxStack, this.state.nextLocal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index) {
/* 110 */     this.mv.visitLocalVariable(name, desc, signature, start, end, remap(index));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int newLocal(int size) {
/* 116 */     int var = this.state.nextLocal;
/* 117 */     this.state.nextLocal += size;
/* 118 */     return var;
/*     */   }
/*     */   
/*     */   private int remap(int var, int size) {
/* 122 */     if (var < this.firstLocal) {
/* 123 */       return var;
/*     */     }
/* 125 */     int key = 2 * var + size - 1;
/* 126 */     int length = this.state.mapping.length;
/* 127 */     if (key >= length) {
/* 128 */       int[] newMapping = new int[Math.max(2 * length, key + 1)];
/* 129 */       System.arraycopy(this.state.mapping, 0, newMapping, 0, length);
/* 130 */       this.state.mapping = newMapping;
/*     */     } 
/* 132 */     int value = this.state.mapping[key];
/* 133 */     if (value == 0) {
/* 134 */       value = this.state.nextLocal + 1;
/* 135 */       this.state.mapping[key] = value;
/* 136 */       this.state.nextLocal += size;
/*     */     } 
/* 138 */     return value - 1;
/*     */   }
/*     */   
/*     */   private int remap(int var) {
/* 142 */     if (var < this.firstLocal) {
/* 143 */       return var;
/*     */     }
/* 145 */     int key = 2 * var;
/* 146 */     int value = (key < this.state.mapping.length) ? this.state.mapping[key] : 0;
/* 147 */     if (value == 0) {
/* 148 */       value = (key + 1 < this.state.mapping.length) ? this.state.mapping[key + 1] : 0;
/*     */     }
/* 150 */     if (value == 0) {
/* 151 */       throw new IllegalStateException("Unknown local variable " + var);
/*     */     }
/* 153 */     return value - 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\LocalVariablesSorter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */