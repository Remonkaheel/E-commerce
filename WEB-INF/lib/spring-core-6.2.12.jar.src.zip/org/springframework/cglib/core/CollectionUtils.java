/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionUtils
/*    */ {
/*    */   public static Map bucket(Collection c, Transformer t) {
/* 36 */     Map<Object, Object> buckets = new HashMap<>();
/* 37 */     for (Object value : c) {
/* 38 */       Object key = t.transform(value);
/* 39 */       List<Object> bucket = (List)buckets.get(key);
/* 40 */       if (bucket == null) {
/* 41 */         buckets.put(key, bucket = new LinkedList());
/*    */       }
/* 43 */       bucket.add(value);
/*    */     } 
/* 45 */     return buckets;
/*    */   }
/*    */   
/*    */   public static void reverse(Map source, Map target) {
/* 49 */     for (Object key : source.keySet()) {
/* 50 */       target.put(source.get(key), key);
/*    */     }
/*    */   }
/*    */   
/*    */   public static Collection filter(Collection c, Predicate p) {
/* 55 */     c.removeIf(o -> !p.evaluate(o));
/* 56 */     return c;
/*    */   }
/*    */   
/*    */   public static List transform(Collection c, Transformer t) {
/* 60 */     List<Object> result = new ArrayList(c.size());
/* 61 */     for (Iterator it = c.iterator(); it.hasNext();) {
/* 62 */       result.add(t.transform(it.next()));
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */   
/*    */   public static Map getIndexMap(List list) {
/* 68 */     Map<Object, Object> indexes = new HashMap<>();
/* 69 */     int index = 0;
/* 70 */     for (Iterator it = list.iterator(); it.hasNext();) {
/* 71 */       indexes.put(it.next(), Integer.valueOf(index++));
/*    */     }
/* 73 */     return indexes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\CollectionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */