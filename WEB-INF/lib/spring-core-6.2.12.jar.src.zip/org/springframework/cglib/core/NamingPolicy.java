package org.springframework.cglib.core;

public interface NamingPolicy {
  String getClassName(String paramString1, String paramString2, Object paramObject, Predicate paramPredicate);
  
  boolean equals(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\NamingPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */