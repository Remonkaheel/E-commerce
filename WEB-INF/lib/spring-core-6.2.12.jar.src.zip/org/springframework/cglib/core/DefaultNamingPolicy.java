/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultNamingPolicy
/*    */   implements NamingPolicy
/*    */ {
/* 30 */   public static final DefaultNamingPolicy INSTANCE = new DefaultNamingPolicy();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   private static final boolean STRESS_HASH_CODE = Boolean.getBoolean("org.springframework.cglib.test.stressHashCodes");
/*    */ 
/*    */   
/*    */   public String getClassName(String prefix, String source, Object key, Predicate names) {
/* 39 */     if (prefix == null) {
/* 40 */       prefix = "org.springframework.cglib.empty.Object";
/* 41 */     } else if (prefix.startsWith("java")) {
/* 42 */       prefix = "$" + prefix;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     String base = prefix + "$$" + prefix + source.substring(source.lastIndexOf('.') + 1) + "$$" + getTag();
/* 49 */     String attempt = base;
/* 50 */     int index = 2;
/* 51 */     while (names.evaluate(attempt)) {
/* 52 */       attempt = base + "_" + base;
/*    */     }
/* 54 */     return attempt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getTag() {
/* 62 */     return "ByCGLIB";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 67 */     return getTag().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 72 */     if (o instanceof DefaultNamingPolicy) { DefaultNamingPolicy defaultNamingPolicy = (DefaultNamingPolicy)o; if (defaultNamingPolicy
/* 73 */         .getTag().equals(getTag())); }
/*    */     
/*    */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\DefaultNamingPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */