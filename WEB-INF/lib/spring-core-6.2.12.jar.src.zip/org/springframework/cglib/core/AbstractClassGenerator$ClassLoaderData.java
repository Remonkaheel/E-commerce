/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.cglib.core.internal.Function;
/*     */ import org.springframework.cglib.core.internal.LoadingCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLoaderData
/*     */ {
/*  77 */   private final Set<String> reservedClassNames = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private final LoadingCache<AbstractClassGenerator, Object, Object> generatedClasses;
/*     */ 
/*     */ 
/*     */   
/*     */   private final WeakReference<ClassLoader> classLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Predicate uniqueNamePredicate;
/*     */ 
/*     */   
/*     */   private static final Function<AbstractClassGenerator, Object> GET_KEY;
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoaderData(ClassLoader classLoader) {
/*  97 */     Objects.requireNonNull(this.reservedClassNames); this.uniqueNamePredicate = this.reservedClassNames::contains;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (classLoader == null) {
/* 103 */       throw new IllegalArgumentException("classLoader == null is not yet supported");
/*     */     }
/* 105 */     this.classLoader = new WeakReference<>(classLoader);
/* 106 */     Function<AbstractClassGenerator, Object> load = gen -> {
/*     */         Class klass = gen.generate(this);
/*     */         return gen.wrapCachedClass(klass);
/*     */       };
/* 110 */     this.generatedClasses = new LoadingCache(GET_KEY, load);
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 114 */     return this.classLoader.get();
/*     */   } static {
/*     */     GET_KEY = (gen -> gen.key);
/*     */   } public void reserveName(String name) {
/* 118 */     this.reservedClassNames.add(name);
/*     */   }
/*     */   
/*     */   public Predicate getUniqueNamePredicate() {
/* 122 */     return this.uniqueNamePredicate;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(AbstractClassGenerator<Object> gen, boolean useCache) {
/* 127 */     Object value = null;
/* 128 */     if (useCache) {
/* 129 */       Object cachedValue = this.generatedClasses.get(gen);
/* 130 */       value = gen.unwrapCachedValue(cachedValue);
/*     */     } 
/* 132 */     if (value == null) {
/* 133 */       value = gen.generate(this);
/*     */     }
/* 135 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\AbstractClassGenerator$ClassLoaderData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */