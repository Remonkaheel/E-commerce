package org.springframework.cglib.core;

public interface Transformer {
  Object transform(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\Transformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */