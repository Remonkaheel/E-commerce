/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends ClassVisitor
/*    */ {
/*    */   null(int api, ClassVisitor classVisitor) {
/* 44 */     super(api, classVisitor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/* 52 */     array.add(name.replace('/', '.'));
/* 53 */     if (superName != null) {
/* 54 */       array.add(superName.replace('/', '.'));
/*    */     }
/* 56 */     for (String element : interfaces) {
/* 57 */       array.add(element.replace('/', '.'));
/*    */     }
/*    */     
/* 60 */     throw ClassNameReader.EARLY_EXIT;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassNameReader$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */