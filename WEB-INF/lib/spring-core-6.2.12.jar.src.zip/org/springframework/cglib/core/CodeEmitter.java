/*      */ package org.springframework.cglib.core;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import org.springframework.asm.Label;
/*      */ import org.springframework.asm.MethodVisitor;
/*      */ import org.springframework.asm.Type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CodeEmitter
/*      */   extends LocalVariablesSorter
/*      */ {
/*   33 */   private static final Signature BOOLEAN_VALUE_OF = TypeUtils.parseSignature("Boolean valueOf(boolean)");
/*      */   
/*   35 */   private static final Signature BYTE_VALUE_OF = TypeUtils.parseSignature("Byte valueOf(byte)");
/*      */   
/*   37 */   private static final Signature CHARACTER_VALUE_OF = TypeUtils.parseSignature("Character valueOf(char)");
/*      */   
/*   39 */   private static final Signature DOUBLE_VALUE_OF = TypeUtils.parseSignature("Double valueOf(double)");
/*      */   
/*   41 */   private static final Signature FLOAT_VALUE_OF = TypeUtils.parseSignature("Float valueOf(float)");
/*      */   
/*   43 */   private static final Signature INTEGER_VALUE_OF = TypeUtils.parseSignature("Integer valueOf(int)");
/*      */   
/*   45 */   private static final Signature LONG_VALUE_OF = TypeUtils.parseSignature("Long valueOf(long)");
/*      */   
/*   47 */   private static final Signature SHORT_VALUE_OF = TypeUtils.parseSignature("Short valueOf(short)");
/*      */ 
/*      */ 
/*      */   
/*   51 */   private static final Signature BOOLEAN_VALUE = TypeUtils.parseSignature("boolean booleanValue()");
/*      */   
/*   53 */   private static final Signature CHAR_VALUE = TypeUtils.parseSignature("char charValue()");
/*      */   
/*   55 */   private static final Signature DOUBLE_VALUE = TypeUtils.parseSignature("double doubleValue()");
/*      */   
/*   57 */   private static final Signature FLOAT_VALUE = TypeUtils.parseSignature("float floatValue()");
/*      */   
/*   59 */   private static final Signature INT_VALUE = TypeUtils.parseSignature("int intValue()");
/*      */   
/*   61 */   private static final Signature LONG_VALUE = TypeUtils.parseSignature("long longValue()");
/*      */   
/*   63 */   private static final Signature CSTRUCT_NULL = TypeUtils.parseConstructor("");
/*      */   
/*   65 */   private static final Signature CSTRUCT_STRING = TypeUtils.parseConstructor("String");
/*      */   
/*      */   public static final int ADD = 96;
/*      */   
/*      */   public static final int MUL = 104;
/*      */   
/*      */   public static final int XOR = 130;
/*      */   
/*      */   public static final int USHR = 124;
/*      */   public static final int SUB = 100;
/*      */   public static final int DIV = 108;
/*      */   public static final int NEG = 116;
/*      */   public static final int REM = 112;
/*      */   public static final int AND = 126;
/*      */   public static final int OR = 128;
/*      */   public static final int GT = 157;
/*      */   public static final int LT = 155;
/*      */   public static final int GE = 156;
/*      */   public static final int LE = 158;
/*      */   public static final int NE = 154;
/*      */   public static final int EQ = 153;
/*      */   private ClassEmitter ce;
/*      */   private State state;
/*      */   
/*      */   CodeEmitter(ClassEmitter ce, MethodVisitor mv, int access, Signature sig, Type[] exceptionTypes) {
/*   90 */     super(access, sig.getDescriptor(), mv);
/*   91 */     this.ce = ce;
/*   92 */     this.state = new State(ce.getClassInfo(), access, sig, exceptionTypes);
/*      */   }
/*      */   
/*      */   public CodeEmitter(CodeEmitter wrap) {
/*   96 */     super(wrap);
/*   97 */     this.ce = wrap.ce;
/*   98 */     this.state = wrap.state;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStaticHook() {
/*  103 */     return false;
/*      */   }
/*      */   
/*      */   public Signature getSignature() {
/*  107 */     return this.state.sig;
/*      */   }
/*      */   
/*      */   public Type getReturnType() {
/*  111 */     return this.state.sig.getReturnType();
/*      */   }
/*      */   
/*      */   public MethodInfo getMethodInfo() {
/*  115 */     return this.state;
/*      */   }
/*      */   
/*      */   public ClassEmitter getClassEmitter() {
/*  119 */     return this.ce;
/*      */   }
/*      */   
/*      */   public void end_method() {
/*  123 */     visitMaxs(0, 0);
/*      */   }
/*      */   
/*      */   public Block begin_block() {
/*  127 */     return new Block(this);
/*      */   }
/*      */   
/*      */   public void catch_exception(Block block, Type exception) {
/*  131 */     if (block.getEnd() == null) {
/*  132 */       throw new IllegalStateException("end of block is unset");
/*      */     }
/*  134 */     this.mv.visitTryCatchBlock(block.getStart(), block
/*  135 */         .getEnd(), 
/*  136 */         mark(), exception
/*  137 */         .getInternalName());
/*      */   }
/*      */   
/*      */   public void goTo(Label label) {
/*  141 */     this.mv.visitJumpInsn(167, label);
/*      */   }
/*      */   
/*      */   public void ifnull(Label label) {
/*  145 */     this.mv.visitJumpInsn(198, label);
/*      */   }
/*      */   
/*      */   public void ifnonnull(Label label) {
/*  149 */     this.mv.visitJumpInsn(199, label);
/*      */   }
/*      */   
/*      */   public void if_jump(int mode, Label label) {
/*  153 */     this.mv.visitJumpInsn(mode, label);
/*      */   }
/*      */   
/*      */   public void if_icmp(int mode, Label label) {
/*  157 */     if_cmp(Type.INT_TYPE, mode, label);
/*      */   }
/*      */   
/*      */   public void if_cmp(Type type, int mode, Label label) {
/*  161 */     int intOp = -1;
/*  162 */     int jumpmode = mode;
/*  163 */     switch (mode) {
/*      */       case 156:
/*  165 */         jumpmode = 155;
/*      */         break;
/*      */       case 158:
/*  168 */         jumpmode = 157;
/*      */         break;
/*      */     } 
/*  171 */     switch (type.getSort()) {
/*      */       case 7:
/*  173 */         this.mv.visitInsn(148);
/*      */         break;
/*      */       case 8:
/*  176 */         this.mv.visitInsn(152);
/*      */         break;
/*      */       case 6:
/*  179 */         this.mv.visitInsn(150);
/*      */         break;
/*      */       case 9:
/*      */       case 10:
/*  183 */         switch (mode) {
/*      */           case 153:
/*  185 */             this.mv.visitJumpInsn(165, label);
/*      */             return;
/*      */           case 154:
/*  188 */             this.mv.visitJumpInsn(166, label);
/*      */             return;
/*      */         } 
/*  191 */         throw new IllegalArgumentException("Bad comparison for type " + String.valueOf(type));
/*      */       default:
/*  193 */         switch (mode) {
/*      */           case 153:
/*  195 */             intOp = 159;
/*      */             break;
/*      */           case 154:
/*  198 */             intOp = 160;
/*      */             break;
/*      */           case 156:
/*  201 */             swap();
/*      */           case 155:
/*  203 */             intOp = 161;
/*      */             break;
/*      */           case 158:
/*  206 */             swap();
/*      */           case 157:
/*  208 */             intOp = 163;
/*      */             break;
/*      */         } 
/*  211 */         this.mv.visitJumpInsn(intOp, label);
/*      */         return;
/*      */     } 
/*  214 */     if_jump(jumpmode, label);
/*      */   }
/*      */   
/*      */   public void pop() {
/*  218 */     this.mv.visitInsn(87);
/*      */   }
/*      */   
/*      */   public void pop2() {
/*  222 */     this.mv.visitInsn(88);
/*      */   }
/*      */   
/*      */   public void dup() {
/*  226 */     this.mv.visitInsn(89);
/*      */   }
/*      */   
/*      */   public void dup2() {
/*  230 */     this.mv.visitInsn(92);
/*      */   }
/*      */   
/*      */   public void dup_x1() {
/*  234 */     this.mv.visitInsn(90);
/*      */   }
/*      */   
/*      */   public void dup_x2() {
/*  238 */     this.mv.visitInsn(91);
/*      */   }
/*      */   
/*      */   public void dup2_x1() {
/*  242 */     this.mv.visitInsn(93);
/*      */   }
/*      */   
/*      */   public void dup2_x2() {
/*  246 */     this.mv.visitInsn(94);
/*      */   }
/*      */   
/*      */   public void swap() {
/*  250 */     this.mv.visitInsn(95);
/*      */   }
/*      */   
/*      */   public void aconst_null() {
/*  254 */     this.mv.visitInsn(1);
/*      */   }
/*      */   
/*      */   public void swap(Type prev, Type type) {
/*  258 */     if (type.getSize() == 1) {
/*  259 */       if (prev.getSize() == 1) {
/*  260 */         swap();
/*      */       } else {
/*      */         
/*  263 */         dup_x2();
/*  264 */         pop();
/*      */       }
/*      */     
/*      */     }
/*  268 */     else if (prev.getSize() == 1) {
/*  269 */       dup2_x1();
/*  270 */       pop2();
/*      */     } else {
/*      */       
/*  273 */       dup2_x2();
/*  274 */       pop2();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void monitorenter() {
/*  280 */     this.mv.visitInsn(194);
/*      */   }
/*      */   
/*      */   public void monitorexit() {
/*  284 */     this.mv.visitInsn(195);
/*      */   }
/*      */   
/*      */   public void math(int op, Type type) {
/*  288 */     this.mv.visitInsn(type.getOpcode(op));
/*      */   }
/*      */   
/*      */   public void array_load(Type type) {
/*  292 */     this.mv.visitInsn(type.getOpcode(46));
/*      */   }
/*      */   
/*      */   public void array_store(Type type) {
/*  296 */     this.mv.visitInsn(type.getOpcode(79));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cast_numeric(Type from, Type to) {
/*  303 */     if (from != to) {
/*  304 */       if (from == Type.DOUBLE_TYPE) {
/*  305 */         if (to == Type.FLOAT_TYPE) {
/*  306 */           this.mv.visitInsn(144);
/*      */         }
/*  308 */         else if (to == Type.LONG_TYPE) {
/*  309 */           this.mv.visitInsn(143);
/*      */         } else {
/*      */           
/*  312 */           this.mv.visitInsn(142);
/*  313 */           cast_numeric(Type.INT_TYPE, to);
/*      */         }
/*      */       
/*  316 */       } else if (from == Type.FLOAT_TYPE) {
/*  317 */         if (to == Type.DOUBLE_TYPE) {
/*  318 */           this.mv.visitInsn(141);
/*      */         }
/*  320 */         else if (to == Type.LONG_TYPE) {
/*  321 */           this.mv.visitInsn(140);
/*      */         } else {
/*      */           
/*  324 */           this.mv.visitInsn(139);
/*  325 */           cast_numeric(Type.INT_TYPE, to);
/*      */         }
/*      */       
/*  328 */       } else if (from == Type.LONG_TYPE) {
/*  329 */         if (to == Type.DOUBLE_TYPE) {
/*  330 */           this.mv.visitInsn(138);
/*      */         }
/*  332 */         else if (to == Type.FLOAT_TYPE) {
/*  333 */           this.mv.visitInsn(137);
/*      */         } else {
/*      */           
/*  336 */           this.mv.visitInsn(136);
/*  337 */           cast_numeric(Type.INT_TYPE, to);
/*      */         }
/*      */       
/*      */       }
/*  341 */       else if (to == Type.BYTE_TYPE) {
/*  342 */         this.mv.visitInsn(145);
/*      */       }
/*  344 */       else if (to == Type.CHAR_TYPE) {
/*  345 */         this.mv.visitInsn(146);
/*      */       }
/*  347 */       else if (to == Type.DOUBLE_TYPE) {
/*  348 */         this.mv.visitInsn(135);
/*      */       }
/*  350 */       else if (to == Type.FLOAT_TYPE) {
/*  351 */         this.mv.visitInsn(134);
/*      */       }
/*  353 */       else if (to == Type.LONG_TYPE) {
/*  354 */         this.mv.visitInsn(133);
/*      */       }
/*  356 */       else if (to == Type.SHORT_TYPE) {
/*  357 */         this.mv.visitInsn(147);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void push(int i) {
/*  364 */     if (i < -1) {
/*  365 */       this.mv.visitLdcInsn(Integer.valueOf(i));
/*      */     }
/*  367 */     else if (i <= 5) {
/*  368 */       this.mv.visitInsn(TypeUtils.ICONST(i));
/*      */     }
/*  370 */     else if (i <= 127) {
/*  371 */       this.mv.visitIntInsn(16, i);
/*      */     }
/*  373 */     else if (i <= 32767) {
/*  374 */       this.mv.visitIntInsn(17, i);
/*      */     } else {
/*      */       
/*  377 */       this.mv.visitLdcInsn(Integer.valueOf(i));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void push(long value) {
/*  382 */     if (value == 0L || value == 1L) {
/*  383 */       this.mv.visitInsn(TypeUtils.LCONST(value));
/*      */     } else {
/*      */       
/*  386 */       this.mv.visitLdcInsn(Long.valueOf(value));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void push(float value) {
/*  391 */     if (value == 0.0F || value == 1.0F || value == 2.0F) {
/*  392 */       this.mv.visitInsn(TypeUtils.FCONST(value));
/*      */     } else {
/*      */       
/*  395 */       this.mv.visitLdcInsn(Float.valueOf(value));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void push(double value) {
/*  400 */     if (value == 0.0D || value == 1.0D) {
/*  401 */       this.mv.visitInsn(TypeUtils.DCONST(value));
/*      */     } else {
/*      */       
/*  404 */       this.mv.visitLdcInsn(Double.valueOf(value));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void push(String value) {
/*  409 */     this.mv.visitLdcInsn(value);
/*      */   }
/*      */   
/*      */   public void newarray() {
/*  413 */     newarray(Constants.TYPE_OBJECT);
/*      */   }
/*      */   
/*      */   public void newarray(Type type) {
/*  417 */     if (TypeUtils.isPrimitive(type)) {
/*  418 */       this.mv.visitIntInsn(188, TypeUtils.NEWARRAY(type));
/*      */     } else {
/*      */       
/*  421 */       emit_type(189, type);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void arraylength() {
/*  426 */     this.mv.visitInsn(190);
/*      */   }
/*      */   
/*      */   public void load_this() {
/*  430 */     if (TypeUtils.isStatic(this.state.access)) {
/*  431 */       throw new IllegalStateException("no 'this' pointer within static method");
/*      */     }
/*  433 */     this.mv.visitVarInsn(25, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void load_args() {
/*  440 */     load_args(0, this.state.argumentTypes.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void load_arg(int index) {
/*  449 */     load_local(this.state.argumentTypes[index], this.state.localOffset + 
/*  450 */         skipArgs(index));
/*      */   }
/*      */ 
/*      */   
/*      */   public void load_args(int fromArg, int count) {
/*  455 */     int pos = this.state.localOffset + skipArgs(fromArg);
/*  456 */     for (int i = 0; i < count; i++) {
/*  457 */       Type t = this.state.argumentTypes[fromArg + i];
/*  458 */       load_local(t, pos);
/*  459 */       pos += t.getSize();
/*      */     } 
/*      */   }
/*      */   
/*      */   private int skipArgs(int numArgs) {
/*  464 */     int amount = 0;
/*  465 */     for (int i = 0; i < numArgs; i++) {
/*  466 */       amount += this.state.argumentTypes[i].getSize();
/*      */     }
/*  468 */     return amount;
/*      */   }
/*      */ 
/*      */   
/*      */   private void load_local(Type t, int pos) {
/*  473 */     this.mv.visitVarInsn(t.getOpcode(21), pos);
/*      */   }
/*      */ 
/*      */   
/*      */   private void store_local(Type t, int pos) {
/*  478 */     this.mv.visitVarInsn(t.getOpcode(54), pos);
/*      */   }
/*      */   
/*      */   public void iinc(Local local, int amount) {
/*  482 */     this.mv.visitIincInsn(local.getIndex(), amount);
/*      */   }
/*      */   
/*      */   public void store_local(Local local) {
/*  486 */     store_local(local.getType(), local.getIndex());
/*      */   }
/*      */   
/*      */   public void load_local(Local local) {
/*  490 */     load_local(local.getType(), local.getIndex());
/*      */   }
/*      */   
/*      */   public void return_value() {
/*  494 */     this.mv.visitInsn(this.state.sig.getReturnType().getOpcode(172));
/*      */   }
/*      */   
/*      */   public void getfield(String name) {
/*  498 */     ClassEmitter.FieldInfo info = this.ce.getFieldInfo(name);
/*  499 */     int opcode = TypeUtils.isStatic(info.access) ? 178 : 180;
/*  500 */     emit_field(opcode, this.ce.getClassType(), name, info.type);
/*      */   }
/*      */   
/*      */   public void putfield(String name) {
/*  504 */     ClassEmitter.FieldInfo info = this.ce.getFieldInfo(name);
/*  505 */     int opcode = TypeUtils.isStatic(info.access) ? 179 : 181;
/*  506 */     emit_field(opcode, this.ce.getClassType(), name, info.type);
/*      */   }
/*      */   
/*      */   public void super_getfield(String name, Type type) {
/*  510 */     emit_field(180, this.ce.getSuperType(), name, type);
/*      */   }
/*      */   
/*      */   public void super_putfield(String name, Type type) {
/*  514 */     emit_field(181, this.ce.getSuperType(), name, type);
/*      */   }
/*      */   
/*      */   public void super_getstatic(String name, Type type) {
/*  518 */     emit_field(178, this.ce.getSuperType(), name, type);
/*      */   }
/*      */   
/*      */   public void super_putstatic(String name, Type type) {
/*  522 */     emit_field(179, this.ce.getSuperType(), name, type);
/*      */   }
/*      */   
/*      */   public void getfield(Type owner, String name, Type type) {
/*  526 */     emit_field(180, owner, name, type);
/*      */   }
/*      */   
/*      */   public void putfield(Type owner, String name, Type type) {
/*  530 */     emit_field(181, owner, name, type);
/*      */   }
/*      */   
/*      */   public void getstatic(Type owner, String name, Type type) {
/*  534 */     emit_field(178, owner, name, type);
/*      */   }
/*      */   
/*      */   public void putstatic(Type owner, String name, Type type) {
/*  538 */     emit_field(179, owner, name, type);
/*      */   }
/*      */ 
/*      */   
/*      */   void emit_field(int opcode, Type ctype, String name, Type ftype) {
/*  543 */     this.mv.visitFieldInsn(opcode, ctype
/*  544 */         .getInternalName(), name, ftype
/*      */         
/*  546 */         .getDescriptor());
/*      */   }
/*      */   
/*      */   public void super_invoke() {
/*  550 */     super_invoke(this.state.sig);
/*      */   }
/*      */   
/*      */   public void super_invoke(Signature sig) {
/*  554 */     emit_invoke(183, this.ce.getSuperType(), sig, false);
/*      */   }
/*      */   
/*      */   public void invoke_constructor(Type type) {
/*  558 */     invoke_constructor(type, CSTRUCT_NULL);
/*      */   }
/*      */   
/*      */   public void super_invoke_constructor() {
/*  562 */     invoke_constructor(this.ce.getSuperType());
/*      */   }
/*      */   
/*      */   public void invoke_constructor_this() {
/*  566 */     invoke_constructor(this.ce.getClassType());
/*      */   }
/*      */   
/*      */   private void emit_invoke(int opcode, Type type, Signature sig, boolean isInterface) {
/*  570 */     if (!sig.getName().equals("<init>") || opcode == 182 || opcode == 184);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  575 */     this.mv.visitMethodInsn(opcode, type
/*  576 */         .getInternalName(), sig
/*  577 */         .getName(), sig
/*  578 */         .getDescriptor(), isInterface);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invoke_interface(Type owner, Signature sig) {
/*  583 */     emit_invoke(185, owner, sig, true);
/*      */   }
/*      */   
/*      */   public void invoke_virtual(Type owner, Signature sig) {
/*  587 */     emit_invoke(182, owner, sig, false);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void invoke_static(Type owner, Signature sig) {
/*  592 */     invoke_static(owner, sig, false);
/*      */   }
/*      */   
/*      */   public void invoke_static(Type owner, Signature sig, boolean isInterface) {
/*  596 */     emit_invoke(184, owner, sig, isInterface);
/*      */   }
/*      */   
/*      */   public void invoke_virtual_this(Signature sig) {
/*  600 */     invoke_virtual(this.ce.getClassType(), sig);
/*      */   }
/*      */   
/*      */   public void invoke_static_this(Signature sig) {
/*  604 */     invoke_static(this.ce.getClassType(), sig);
/*      */   }
/*      */   
/*      */   public void invoke_constructor(Type type, Signature sig) {
/*  608 */     emit_invoke(183, type, sig, false);
/*      */   }
/*      */   
/*      */   public void invoke_constructor_this(Signature sig) {
/*  612 */     invoke_constructor(this.ce.getClassType(), sig);
/*      */   }
/*      */   
/*      */   public void super_invoke_constructor(Signature sig) {
/*  616 */     invoke_constructor(this.ce.getSuperType(), sig);
/*      */   }
/*      */   
/*      */   public void new_instance_this() {
/*  620 */     new_instance(this.ce.getClassType());
/*      */   }
/*      */   
/*      */   public void new_instance(Type type) {
/*  624 */     emit_type(187, type);
/*      */   }
/*      */   
/*      */   private void emit_type(int opcode, Type type) {
/*      */     String desc;
/*  629 */     if (TypeUtils.isArray(type)) {
/*  630 */       desc = type.getDescriptor();
/*      */     } else {
/*      */       
/*  633 */       desc = type.getInternalName();
/*      */     } 
/*  635 */     this.mv.visitTypeInsn(opcode, desc);
/*      */   }
/*      */   
/*      */   public void aaload(int index) {
/*  639 */     push(index);
/*  640 */     aaload();
/*      */   }
/*      */   
/*      */   public void aaload() {
/*  644 */     this.mv.visitInsn(50);
/*      */   }
/*      */   
/*      */   public void aastore() {
/*  648 */     this.mv.visitInsn(83);
/*      */   }
/*      */   
/*      */   public void athrow() {
/*  652 */     this.mv.visitInsn(191);
/*      */   }
/*      */   
/*      */   public Label make_label() {
/*  656 */     return new Label();
/*      */   }
/*      */   
/*      */   public Local make_local() {
/*  660 */     return make_local(Constants.TYPE_OBJECT);
/*      */   }
/*      */   
/*      */   public Local make_local(Type type) {
/*  664 */     return new Local(newLocal(type.getSize()), type);
/*      */   }
/*      */   
/*      */   public void checkcast_this() {
/*  668 */     checkcast(this.ce.getClassType());
/*      */   }
/*      */   
/*      */   public void checkcast(Type type) {
/*  672 */     if (!type.equals(Constants.TYPE_OBJECT)) {
/*  673 */       emit_type(192, type);
/*      */     }
/*      */   }
/*      */   
/*      */   public void instance_of(Type type) {
/*  678 */     emit_type(193, type);
/*      */   }
/*      */   
/*      */   public void instance_of_this() {
/*  682 */     instance_of(this.ce.getClassType());
/*      */   }
/*      */   
/*      */   public void process_switch(int[] keys, ProcessSwitchCallback callback) {
/*      */     float density;
/*  687 */     if (keys.length == 0) {
/*  688 */       density = 0.0F;
/*      */     } else {
/*      */       
/*  691 */       density = keys.length / (keys[keys.length - 1] - keys[0] + 1);
/*      */     } 
/*  693 */     process_switch(keys, callback, (density >= 0.5F));
/*      */   }
/*      */   
/*      */   public void process_switch(int[] keys, ProcessSwitchCallback callback, boolean useTable) {
/*  697 */     if (!isSorted(keys)) {
/*  698 */       throw new IllegalArgumentException("keys to switch must be sorted ascending");
/*      */     }
/*  700 */     Label def = make_label();
/*  701 */     Label end = make_label();
/*      */     
/*      */     try {
/*  704 */       if (keys.length > 0) {
/*  705 */         int len = keys.length;
/*  706 */         int min = keys[0];
/*  707 */         int max = keys[len - 1];
/*  708 */         int range = max - min + 1;
/*      */         
/*  710 */         if (useTable) {
/*  711 */           Label[] labels = new Label[range];
/*  712 */           Arrays.fill((Object[])labels, def); int i;
/*  713 */           for (i = 0; i < len; i++) {
/*  714 */             labels[keys[i] - min] = make_label();
/*      */           }
/*  716 */           this.mv.visitTableSwitchInsn(min, max, def, labels);
/*  717 */           for (i = 0; i < range; i++) {
/*  718 */             Label label = labels[i];
/*  719 */             if (label != def) {
/*  720 */               mark(label);
/*  721 */               callback.processCase(i + min, end);
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  726 */           Label[] labels = new Label[len]; int i;
/*  727 */           for (i = 0; i < len; i++) {
/*  728 */             labels[i] = make_label();
/*      */           }
/*  730 */           this.mv.visitLookupSwitchInsn(def, keys, labels);
/*  731 */           for (i = 0; i < len; i++) {
/*  732 */             mark(labels[i]);
/*  733 */             callback.processCase(keys[i], end);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  738 */       mark(def);
/*  739 */       callback.processDefault();
/*  740 */       mark(end);
/*      */     
/*      */     }
/*  743 */     catch (RuntimeException|Error e) {
/*  744 */       throw e;
/*      */     }
/*  746 */     catch (Exception e) {
/*  747 */       throw new CodeGenerationException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean isSorted(int[] keys) {
/*  752 */     for (int i = 1; i < keys.length; i++) {
/*  753 */       if (keys[i] < keys[i - 1]) {
/*  754 */         return false;
/*      */       }
/*      */     } 
/*  757 */     return true;
/*      */   }
/*      */   
/*      */   public void mark(Label label) {
/*  761 */     this.mv.visitLabel(label);
/*      */   }
/*      */   
/*      */   Label mark() {
/*  765 */     Label label = make_label();
/*  766 */     this.mv.visitLabel(label);
/*  767 */     return label;
/*      */   }
/*      */   
/*      */   public void push(boolean value) {
/*  771 */     push(value ? 1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void not() {
/*  778 */     push(1);
/*  779 */     math(130, Type.INT_TYPE);
/*      */   }
/*      */   
/*      */   public void throw_exception(Type type, String msg) {
/*  783 */     new_instance(type);
/*  784 */     dup();
/*  785 */     push(msg);
/*  786 */     invoke_constructor(type, CSTRUCT_STRING);
/*  787 */     athrow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void box(Type type) {
/*  799 */     if (TypeUtils.isPrimitive(type)) {
/*  800 */       switch (type.getSort()) {
/*      */         case 0:
/*  802 */           aconst_null();
/*      */           return;
/*      */         
/*      */         case 2:
/*  806 */           invoke_static(Constants.TYPE_CHARACTER, CHARACTER_VALUE_OF);
/*      */           return;
/*      */         case 1:
/*  809 */           invoke_static(Constants.TYPE_BOOLEAN, BOOLEAN_VALUE_OF);
/*      */           return;
/*      */         case 8:
/*  812 */           invoke_static(Constants.TYPE_DOUBLE, DOUBLE_VALUE_OF);
/*      */           return;
/*      */         case 6:
/*  815 */           invoke_static(Constants.TYPE_FLOAT, FLOAT_VALUE_OF);
/*      */           return;
/*      */         case 7:
/*  818 */           invoke_static(Constants.TYPE_LONG, LONG_VALUE_OF);
/*      */           return;
/*      */         case 5:
/*  821 */           invoke_static(Constants.TYPE_INTEGER, INTEGER_VALUE_OF);
/*      */           return;
/*      */         case 4:
/*  824 */           invoke_static(Constants.TYPE_SHORT, SHORT_VALUE_OF);
/*      */           return;
/*      */         case 3:
/*  827 */           invoke_static(Constants.TYPE_BYTE, BYTE_VALUE_OF);
/*      */           return;
/*      */       } 
/*      */       
/*  831 */       Type boxed = TypeUtils.getBoxedType(type);
/*  832 */       new_instance(boxed);
/*  833 */       if (type.getSize() == 2) {
/*      */         
/*  835 */         dup_x2();
/*  836 */         dup_x2();
/*  837 */         pop();
/*      */       }
/*      */       else {
/*      */         
/*  841 */         dup_x1();
/*  842 */         swap();
/*      */       } 
/*  844 */       invoke_constructor(boxed, new Signature("<init>", Type.VOID_TYPE, new Type[] { type }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unbox(Type type) {
/*  857 */     Type t = Constants.TYPE_NUMBER;
/*  858 */     Signature sig = null;
/*  859 */     switch (type.getSort()) {
/*      */       case 0:
/*      */         return;
/*      */       case 2:
/*  863 */         t = Constants.TYPE_CHARACTER;
/*  864 */         sig = CHAR_VALUE;
/*      */         break;
/*      */       case 1:
/*  867 */         t = Constants.TYPE_BOOLEAN;
/*  868 */         sig = BOOLEAN_VALUE;
/*      */         break;
/*      */       case 8:
/*  871 */         sig = DOUBLE_VALUE;
/*      */         break;
/*      */       case 6:
/*  874 */         sig = FLOAT_VALUE;
/*      */         break;
/*      */       case 7:
/*  877 */         sig = LONG_VALUE;
/*      */         break;
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*  882 */         sig = INT_VALUE;
/*      */         break;
/*      */     } 
/*  885 */     if (sig == null) {
/*  886 */       checkcast(type);
/*      */     } else {
/*      */       
/*  889 */       checkcast(t);
/*  890 */       invoke_virtual(t, sig);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void create_arg_array() {
/*  904 */     push(this.state.argumentTypes.length);
/*  905 */     newarray();
/*  906 */     for (int i = 0; i < this.state.argumentTypes.length; i++) {
/*  907 */       dup();
/*  908 */       push(i);
/*  909 */       load_arg(i);
/*  910 */       box(this.state.argumentTypes[i]);
/*  911 */       aastore();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void zero_or_null(Type type) {
/*  920 */     if (TypeUtils.isPrimitive(type)) {
/*  921 */       switch (type.getSort()) {
/*      */         case 8:
/*  923 */           push(0.0D);
/*      */           return;
/*      */         case 7:
/*  926 */           push(0L);
/*      */           return;
/*      */         case 6:
/*  929 */           push(0.0F);
/*      */           return;
/*      */         case 0:
/*  932 */           aconst_null(); break;
/*      */       } 
/*  934 */       push(0);
/*      */     }
/*      */     else {
/*      */       
/*  938 */       aconst_null();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unbox_or_zero(Type type) {
/*  947 */     if (TypeUtils.isPrimitive(type)) {
/*  948 */       if (type != Type.VOID_TYPE) {
/*  949 */         Label nonNull = make_label();
/*  950 */         Label end = make_label();
/*  951 */         dup();
/*  952 */         ifnonnull(nonNull);
/*  953 */         pop();
/*  954 */         zero_or_null(type);
/*  955 */         goTo(end);
/*  956 */         mark(nonNull);
/*  957 */         unbox(type);
/*  958 */         mark(end);
/*      */       } 
/*      */     } else {
/*      */       
/*  962 */       checkcast(type);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitMaxs(int maxStack, int maxLocals) {
/*  968 */     if (!TypeUtils.isAbstract(this.state.access)) {
/*  969 */       this.mv.visitMaxs(0, 0);
/*      */     }
/*      */   }
/*      */   
/*      */   public void invoke(MethodInfo method, Type virtualType) {
/*  974 */     ClassInfo classInfo = method.getClassInfo();
/*  975 */     Type type = classInfo.getType();
/*  976 */     Signature sig = method.getSignature();
/*  977 */     if (sig.getName().equals("<init>")) {
/*  978 */       invoke_constructor(type, sig);
/*      */     }
/*  980 */     else if (TypeUtils.isStatic(method.getModifiers())) {
/*  981 */       invoke_static(type, sig, TypeUtils.isInterface(classInfo.getModifiers()));
/*      */     }
/*  983 */     else if (TypeUtils.isInterface(classInfo.getModifiers())) {
/*  984 */       invoke_interface(type, sig);
/*      */     } else {
/*      */       
/*  987 */       invoke_virtual(virtualType, sig);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void invoke(MethodInfo method) {
/*  992 */     invoke(method, method.getClassInfo().getType());
/*      */   }
/*      */ 
/*      */   
/*      */   private static class State
/*      */     extends MethodInfo
/*      */   {
/*      */     ClassInfo classInfo;
/*      */     
/*      */     int access;
/*      */     
/*      */     Signature sig;
/*      */     
/*      */     Type[] argumentTypes;
/*      */     
/*      */     int localOffset;
/*      */     Type[] exceptionTypes;
/*      */     
/*      */     State(ClassInfo classInfo, int access, Signature sig, Type[] exceptionTypes) {
/* 1011 */       this.classInfo = classInfo;
/* 1012 */       this.access = access;
/* 1013 */       this.sig = sig;
/* 1014 */       this.exceptionTypes = exceptionTypes;
/* 1015 */       this.localOffset = TypeUtils.isStatic(access) ? 0 : 1;
/* 1016 */       this.argumentTypes = sig.getArgumentTypes();
/*      */     }
/*      */ 
/*      */     
/*      */     public ClassInfo getClassInfo() {
/* 1021 */       return this.classInfo;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1026 */       return this.access;
/*      */     }
/*      */ 
/*      */     
/*      */     public Signature getSignature() {
/* 1031 */       return this.sig;
/*      */     }
/*      */ 
/*      */     
/*      */     public Type[] getExceptionTypes() {
/* 1036 */       return this.exceptionTypes;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\CodeEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */