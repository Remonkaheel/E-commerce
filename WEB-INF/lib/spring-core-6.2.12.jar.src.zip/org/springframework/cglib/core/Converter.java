package org.springframework.cglib.core;

public interface Converter {
  Object convert(Object paramObject1, Class paramClass, Object paramObject2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\Converter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */