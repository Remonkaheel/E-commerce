package org.springframework.cglib.core;

import org.springframework.asm.Type;

public interface ProcessArrayCallback {
  void processElement(Type paramType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ProcessArrayCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */