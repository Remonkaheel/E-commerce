/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.FieldVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassEmitter
/*     */   extends ClassTransformer
/*     */ {
/*     */   private ClassInfo classInfo;
/*     */   private Map fieldInfo;
/*     */   private static int hookCounter;
/*     */   private MethodVisitor rawStaticInit;
/*     */   private CodeEmitter staticInit;
/*     */   private CodeEmitter staticHook;
/*     */   private Signature staticHookSig;
/*     */   
/*     */   public ClassEmitter(ClassVisitor cv) {
/*  41 */     setTarget(cv);
/*     */   }
/*     */   
/*     */   public ClassEmitter() {
/*  45 */     super(Constants.ASM_API);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTarget(ClassVisitor cv) {
/*  50 */     this.cv = cv;
/*  51 */     this.fieldInfo = new HashMap<>();
/*     */ 
/*     */     
/*  54 */     this.staticInit = this.staticHook = null;
/*  55 */     this.staticHookSig = null;
/*     */   }
/*     */   
/*     */   private static synchronized int getNextHook() {
/*  59 */     return ++hookCounter;
/*     */   }
/*     */   
/*     */   public ClassInfo getClassInfo() {
/*  63 */     return this.classInfo;
/*     */   }
/*     */   
/*     */   public void begin_class(int version, final int access, String className, final Type superType, final Type[] interfaces, String source) {
/*  67 */     final Type classType = Type.getType("L" + className.replace('.', '/') + ";");
/*  68 */     this.classInfo = new ClassInfo()
/*     */       {
/*     */         public Type getType() {
/*  71 */           return classType;
/*     */         }
/*     */         
/*     */         public Type getSuperType() {
/*  75 */           return (superType != null) ? superType : Constants.TYPE_OBJECT;
/*     */         }
/*     */         
/*     */         public Type[] getInterfaces() {
/*  79 */           return interfaces;
/*     */         }
/*     */         
/*     */         public int getModifiers() {
/*  83 */           return access;
/*     */         }
/*     */       };
/*  86 */     this.cv.visit(version, access, this.classInfo
/*     */         
/*  88 */         .getType().getInternalName(), null, this.classInfo
/*     */         
/*  90 */         .getSuperType().getInternalName(), 
/*  91 */         TypeUtils.toInternalNames(interfaces));
/*  92 */     if (source != null) {
/*  93 */       this.cv.visitSource(source, null);
/*     */     }
/*  95 */     init();
/*     */   }
/*     */   
/*     */   public CodeEmitter getStaticHook() {
/*  99 */     if (TypeUtils.isInterface(getAccess())) {
/* 100 */       throw new IllegalStateException("static hook is invalid for this class");
/*     */     }
/* 102 */     if (this.staticHook == null) {
/* 103 */       this.staticHookSig = new Signature("CGLIB$STATICHOOK" + getNextHook(), "()V");
/* 104 */       this.staticHook = begin_method(8, this.staticHookSig, null);
/*     */ 
/*     */       
/* 107 */       if (this.staticInit != null) {
/* 108 */         this.staticInit.invoke_static_this(this.staticHookSig);
/*     */       }
/*     */     } 
/* 111 */     return this.staticHook;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void init() {}
/*     */   
/*     */   public int getAccess() {
/* 118 */     return this.classInfo.getModifiers();
/*     */   }
/*     */   
/*     */   public Type getClassType() {
/* 122 */     return this.classInfo.getType();
/*     */   }
/*     */   
/*     */   public Type getSuperType() {
/* 126 */     return this.classInfo.getSuperType();
/*     */   }
/*     */   
/*     */   public void end_class() {
/* 130 */     if (this.staticHook != null && this.staticInit == null)
/*     */     {
/* 132 */       begin_static();
/*     */     }
/* 134 */     if (this.staticInit != null) {
/* 135 */       this.staticHook.return_value();
/* 136 */       this.staticHook.end_method();
/* 137 */       this.rawStaticInit.visitInsn(177);
/* 138 */       this.rawStaticInit.visitMaxs(0, 0);
/* 139 */       this.staticInit = this.staticHook = null;
/* 140 */       this.staticHookSig = null;
/*     */     } 
/* 142 */     this.cv.visitEnd();
/*     */   }
/*     */   
/*     */   public CodeEmitter begin_method(int access, Signature sig, Type[] exceptions) {
/* 146 */     if (this.classInfo == null) {
/* 147 */       throw new IllegalStateException("classInfo is null! " + String.valueOf(this));
/*     */     }
/* 149 */     MethodVisitor v = this.cv.visitMethod(access, sig
/* 150 */         .getName(), sig
/* 151 */         .getDescriptor(), null, 
/*     */         
/* 153 */         TypeUtils.toInternalNames(exceptions));
/* 154 */     if (sig.equals(Constants.SIG_STATIC) && !TypeUtils.isInterface(getAccess())) {
/* 155 */       this.rawStaticInit = v;
/* 156 */       MethodVisitor wrapped = new MethodVisitor(Constants.ASM_API, v)
/*     */         {
/*     */           public void visitMaxs(int maxStack, int maxLocals) {}
/*     */ 
/*     */ 
/*     */           
/*     */           public void visitInsn(int insn) {
/* 163 */             if (insn != 177) {
/* 164 */               super.visitInsn(insn);
/*     */             }
/*     */           }
/*     */         };
/* 168 */       this.staticInit = new CodeEmitter(this, wrapped, access, sig, exceptions);
/* 169 */       if (this.staticHook == null) {
/*     */         
/* 171 */         getStaticHook();
/*     */       } else {
/* 173 */         this.staticInit.invoke_static_this(this.staticHookSig);
/*     */       } 
/* 175 */       return this.staticInit;
/* 176 */     }  if (sig.equals(this.staticHookSig)) {
/* 177 */       return new CodeEmitter(this, v, access, sig, exceptions)
/*     */         {
/*     */           public boolean isStaticHook() {
/* 180 */             return true;
/*     */           }
/*     */         };
/*     */     }
/* 184 */     return new CodeEmitter(this, v, access, sig, exceptions);
/*     */   }
/*     */ 
/*     */   
/*     */   public CodeEmitter begin_static() {
/* 189 */     return begin_method(8, Constants.SIG_STATIC, null);
/*     */   }
/*     */   
/*     */   public void declare_field(int access, String name, Type type, Object value) {
/* 193 */     FieldInfo existing = (FieldInfo)this.fieldInfo.get(name);
/* 194 */     FieldInfo info = new FieldInfo(access, name, type, value);
/* 195 */     if (existing != null) {
/* 196 */       if (!info.equals(existing)) {
/* 197 */         throw new IllegalArgumentException("Field \"" + name + "\" has been declared differently");
/*     */       }
/*     */     } else {
/* 200 */       this.fieldInfo.put(name, info);
/* 201 */       this.cv.visitField(access, name, type.getDescriptor(), null, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isFieldDeclared(String name) {
/* 207 */     return (this.fieldInfo.get(name) != null);
/*     */   }
/*     */   
/*     */   FieldInfo getFieldInfo(String name) {
/* 211 */     FieldInfo field = (FieldInfo)this.fieldInfo.get(name);
/* 212 */     if (field == null) {
/* 213 */       throw new IllegalArgumentException("Field " + name + " is not declared in " + getClassType().getClassName());
/*     */     }
/* 215 */     return field;
/*     */   }
/*     */   
/*     */   static class FieldInfo {
/*     */     int access;
/*     */     String name;
/*     */     Type type;
/*     */     Object value;
/*     */     
/*     */     public FieldInfo(int access, String name, Type type, Object value) {
/* 225 */       this.access = access;
/* 226 */       this.name = name;
/* 227 */       this.type = type;
/* 228 */       this.value = value;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       FieldInfo other;
/* 233 */       if (o == null) {
/* 234 */         return false;
/*     */       }
/* 236 */       if (o instanceof FieldInfo) { other = (FieldInfo)o; }
/* 237 */       else { return false; }
/*     */       
/* 239 */       if (this.access != other.access || 
/* 240 */         !this.name.equals(other.name) || 
/* 241 */         !this.type.equals(other.type)) {
/* 242 */         return false;
/*     */       }
/* 244 */       if ((((this.value == null) ? 1 : 0) ^ ((other.value == null) ? 1 : 0)) != 0) {
/* 245 */         return false;
/*     */       }
/* 247 */       if (this.value != null && !this.value.equals(other.value)) {
/* 248 */         return false;
/*     */       }
/* 250 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 255 */       return this.access ^ this.name.hashCode() ^ this.type.hashCode() ^ ((this.value == null) ? 0 : this.value.hashCode());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/* 266 */     begin_class(version, access, name
/*     */         
/* 268 */         .replace('/', '.'), 
/* 269 */         TypeUtils.fromInternalName(superName), 
/* 270 */         TypeUtils.fromInternalNames(interfaces), null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitEnd() {
/* 276 */     end_class();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
/* 285 */     declare_field(access, name, Type.getType(desc), value);
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 295 */     return begin_method(access, new Signature(name, desc), 
/*     */         
/* 297 */         TypeUtils.fromInternalNames(exceptions));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */