package org.springframework.cglib.core;

@FunctionalInterface
public interface Predicate {
  boolean evaluate(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\Predicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */