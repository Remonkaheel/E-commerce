/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.internal.CustomizerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmitUtils
/*     */ {
/*  38 */   private static final Signature CSTRUCT_NULL = TypeUtils.parseConstructor("");
/*     */   
/*  40 */   private static final Signature CSTRUCT_THROWABLE = TypeUtils.parseConstructor("Throwable");
/*     */ 
/*     */   
/*  43 */   private static final Signature GET_NAME = TypeUtils.parseSignature("String getName()");
/*     */   
/*  45 */   private static final Signature HASH_CODE = TypeUtils.parseSignature("int hashCode()");
/*     */   
/*  47 */   private static final Signature EQUALS = TypeUtils.parseSignature("boolean equals(Object)");
/*     */   
/*  49 */   private static final Signature STRING_LENGTH = TypeUtils.parseSignature("int length()");
/*     */   
/*  51 */   private static final Signature STRING_CHAR_AT = TypeUtils.parseSignature("char charAt(int)");
/*     */   
/*  53 */   private static final Signature FOR_NAME = TypeUtils.parseSignature("Class forName(String)");
/*     */   
/*  55 */   private static final Signature DOUBLE_TO_LONG_BITS = TypeUtils.parseSignature("long doubleToLongBits(double)");
/*     */   
/*  57 */   private static final Signature FLOAT_TO_INT_BITS = TypeUtils.parseSignature("int floatToIntBits(float)");
/*     */   
/*  59 */   private static final Signature TO_STRING = TypeUtils.parseSignature("String toString()");
/*     */   
/*  61 */   private static final Signature APPEND_STRING = TypeUtils.parseSignature("StringBuffer append(String)");
/*     */   
/*  63 */   private static final Signature APPEND_INT = TypeUtils.parseSignature("StringBuffer append(int)");
/*     */   
/*  65 */   private static final Signature APPEND_DOUBLE = TypeUtils.parseSignature("StringBuffer append(double)");
/*     */   
/*  67 */   private static final Signature APPEND_FLOAT = TypeUtils.parseSignature("StringBuffer append(float)");
/*     */   
/*  69 */   private static final Signature APPEND_CHAR = TypeUtils.parseSignature("StringBuffer append(char)");
/*     */   
/*  71 */   private static final Signature APPEND_LONG = TypeUtils.parseSignature("StringBuffer append(long)");
/*     */   
/*  73 */   private static final Signature APPEND_BOOLEAN = TypeUtils.parseSignature("StringBuffer append(boolean)");
/*     */   
/*  75 */   private static final Signature LENGTH = TypeUtils.parseSignature("int length()");
/*     */   
/*  77 */   private static final Signature SET_LENGTH = TypeUtils.parseSignature("void setLength(int)");
/*     */   
/*  79 */   private static final Signature GET_DECLARED_METHOD = TypeUtils.parseSignature("java.lang.reflect.Method getDeclaredMethod(String, Class[])");
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final ArrayDelimiters DEFAULT_DELIMITERS = new ArrayDelimiters("{", ", ", "}");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void factory_method(ClassEmitter ce, Signature sig) {
/*  89 */     CodeEmitter e = ce.begin_method(1, sig, null);
/*  90 */     e.new_instance_this();
/*  91 */     e.dup();
/*  92 */     e.load_args();
/*  93 */     e.invoke_constructor_this(TypeUtils.parseConstructor(sig.getArgumentTypes()));
/*  94 */     e.return_value();
/*  95 */     e.end_method();
/*     */   }
/*     */   
/*     */   public static void null_constructor(ClassEmitter ce) {
/*  99 */     CodeEmitter e = ce.begin_method(1, CSTRUCT_NULL, null);
/* 100 */     e.load_this();
/* 101 */     e.super_invoke_constructor();
/* 102 */     e.return_value();
/* 103 */     e.end_method();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void process_array(CodeEmitter e, Type type, ProcessArrayCallback callback) {
/* 114 */     Type componentType = TypeUtils.getComponentType(type);
/* 115 */     Local array = e.make_local();
/* 116 */     Local loopvar = e.make_local(Type.INT_TYPE);
/* 117 */     Label loopbody = e.make_label();
/* 118 */     Label checkloop = e.make_label();
/* 119 */     e.store_local(array);
/* 120 */     e.push(0);
/* 121 */     e.store_local(loopvar);
/* 122 */     e.goTo(checkloop);
/*     */     
/* 124 */     e.mark(loopbody);
/* 125 */     e.load_local(array);
/* 126 */     e.load_local(loopvar);
/* 127 */     e.array_load(componentType);
/* 128 */     callback.processElement(componentType);
/* 129 */     e.iinc(loopvar, 1);
/*     */     
/* 131 */     e.mark(checkloop);
/* 132 */     e.load_local(loopvar);
/* 133 */     e.load_local(array);
/* 134 */     e.arraylength();
/* 135 */     e.if_icmp(155, loopbody);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void process_arrays(CodeEmitter e, Type type, ProcessArrayCallback callback) {
/* 146 */     Type componentType = TypeUtils.getComponentType(type);
/* 147 */     Local array1 = e.make_local();
/* 148 */     Local array2 = e.make_local();
/* 149 */     Local loopvar = e.make_local(Type.INT_TYPE);
/* 150 */     Label loopbody = e.make_label();
/* 151 */     Label checkloop = e.make_label();
/* 152 */     e.store_local(array1);
/* 153 */     e.store_local(array2);
/* 154 */     e.push(0);
/* 155 */     e.store_local(loopvar);
/* 156 */     e.goTo(checkloop);
/*     */     
/* 158 */     e.mark(loopbody);
/* 159 */     e.load_local(array1);
/* 160 */     e.load_local(loopvar);
/* 161 */     e.array_load(componentType);
/* 162 */     e.load_local(array2);
/* 163 */     e.load_local(loopvar);
/* 164 */     e.array_load(componentType);
/* 165 */     callback.processElement(componentType);
/* 166 */     e.iinc(loopvar, 1);
/*     */     
/* 168 */     e.mark(checkloop);
/* 169 */     e.load_local(loopvar);
/* 170 */     e.load_local(array1);
/* 171 */     e.arraylength();
/* 172 */     e.if_icmp(155, loopbody);
/*     */   }
/*     */   
/*     */   public static void string_switch(CodeEmitter e, String[] strings, int switchStyle, ObjectSwitchCallback callback) {
/*     */     try {
/* 177 */       switch (switchStyle) {
/*     */         case 0:
/* 179 */           string_switch_trie(e, strings, callback);
/*     */           return;
/*     */         case 1:
/* 182 */           string_switch_hash(e, strings, callback, false);
/*     */           return;
/*     */         case 2:
/* 185 */           string_switch_hash(e, strings, callback, true);
/*     */           return;
/*     */       } 
/* 188 */       throw new IllegalArgumentException("unknown switch style " + switchStyle);
/*     */     }
/* 190 */     catch (RuntimeException|Error ex) {
/* 191 */       throw ex;
/* 192 */     } catch (Exception ex) {
/* 193 */       throw new CodeGenerationException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void string_switch_trie(final CodeEmitter e, String[] strings, final ObjectSwitchCallback callback) throws Exception {
/* 200 */     final Label def = e.make_label();
/* 201 */     final Label end = e.make_label();
/* 202 */     final Map buckets = CollectionUtils.bucket(Arrays.asList(strings), value -> Integer.valueOf(((String)value).length()));
/* 203 */     e.dup();
/* 204 */     e.invoke_virtual(Constants.TYPE_STRING, STRING_LENGTH);
/* 205 */     e.process_switch(getSwitchKeys(buckets), new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label ignore_end) throws Exception {
/* 208 */             List bucket = (List)buckets.get(Integer.valueOf(key));
/* 209 */             EmitUtils.stringSwitchHelper(e, bucket, callback, def, end, 0);
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 213 */             e.goTo(def);
/*     */           }
/*     */         });
/* 216 */     e.mark(def);
/* 217 */     e.pop();
/* 218 */     callback.processDefault();
/* 219 */     e.mark(end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void stringSwitchHelper(final CodeEmitter e, List<String> strings, final ObjectSwitchCallback callback, final Label def, final Label end, final int index) throws Exception {
/* 228 */     final int len = ((String)strings.get(0)).length();
/* 229 */     final Map buckets = CollectionUtils.bucket(strings, value -> Character.valueOf(((String)value).charAt(index)));
/* 230 */     e.dup();
/* 231 */     e.push(index);
/* 232 */     e.invoke_virtual(Constants.TYPE_STRING, STRING_CHAR_AT);
/* 233 */     e.process_switch(getSwitchKeys(buckets), new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label ignore_end) throws Exception {
/* 236 */             List bucket = (List)buckets.get(Integer.valueOf(key));
/* 237 */             if (index + 1 == len) {
/* 238 */               e.pop();
/* 239 */               callback.processCase(bucket.get(0), end);
/*     */             } else {
/* 241 */               EmitUtils.stringSwitchHelper(e, bucket, callback, def, end, index + 1);
/*     */             } 
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 246 */             e.goTo(def);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   static int[] getSwitchKeys(Map buckets) {
/* 252 */     int[] keys = new int[buckets.size()];
/* 253 */     int index = 0;
/* 254 */     for (Iterator it = buckets.keySet().iterator(); it.hasNext();) {
/* 255 */       keys[index++] = ((Integer)it.next()).intValue();
/*     */     }
/* 257 */     Arrays.sort(keys);
/* 258 */     return keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void string_switch_hash(final CodeEmitter e, String[] strings, final ObjectSwitchCallback callback, final boolean skipEquals) throws Exception {
/* 265 */     final Map buckets = CollectionUtils.bucket(Arrays.asList(strings), value -> Integer.valueOf(value.hashCode()));
/* 266 */     final Label def = e.make_label();
/* 267 */     final Label end = e.make_label();
/* 268 */     e.dup();
/* 269 */     e.invoke_virtual(Constants.TYPE_OBJECT, HASH_CODE);
/* 270 */     e.process_switch(getSwitchKeys(buckets), new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label ignore_end) throws Exception {
/* 273 */             List bucket = (List)buckets.get(Integer.valueOf(key));
/* 274 */             Label next = null;
/* 275 */             if (skipEquals && bucket.size() == 1) {
/* 276 */               if (skipEquals) {
/* 277 */                 e.pop();
/*     */               }
/* 279 */               callback.processCase(bucket.get(0), end);
/*     */             } else {
/* 281 */               for (Iterator<String> it = bucket.iterator(); it.hasNext(); ) {
/* 282 */                 String string = it.next();
/* 283 */                 if (next != null) {
/* 284 */                   e.mark(next);
/*     */                 }
/* 286 */                 if (it.hasNext()) {
/* 287 */                   e.dup();
/*     */                 }
/* 289 */                 e.push(string);
/* 290 */                 e.invoke_virtual(Constants.TYPE_OBJECT, EmitUtils.EQUALS);
/* 291 */                 if (it.hasNext()) {
/* 292 */                   e.if_jump(153, next = e.make_label());
/* 293 */                   e.pop();
/*     */                 } else {
/* 295 */                   e.if_jump(153, def);
/*     */                 } 
/* 297 */                 callback.processCase(string, end);
/*     */               } 
/*     */             } 
/*     */           }
/*     */           
/*     */           public void processDefault() {
/* 303 */             e.pop();
/*     */           }
/*     */         });
/* 306 */     e.mark(def);
/* 307 */     callback.processDefault();
/* 308 */     e.mark(end);
/*     */   }
/*     */   
/*     */   public static void load_class_this(CodeEmitter e) {
/* 312 */     load_class_helper(e, e.getClassEmitter().getClassType());
/*     */   }
/*     */   
/*     */   public static void load_class(CodeEmitter e, Type type) {
/* 316 */     if (TypeUtils.isPrimitive(type)) {
/* 317 */       if (type == Type.VOID_TYPE) {
/* 318 */         throw new IllegalArgumentException("cannot load void type");
/*     */       }
/* 320 */       e.getstatic(TypeUtils.getBoxedType(type), "TYPE", Constants.TYPE_CLASS);
/*     */     } else {
/* 322 */       load_class_helper(e, type);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void load_class_helper(CodeEmitter e, Type type) {
/* 327 */     if (e.isStaticHook()) {
/*     */       
/* 329 */       e.push(TypeUtils.emulateClassGetName(type));
/* 330 */       e.invoke_static(Constants.TYPE_CLASS, FOR_NAME);
/*     */     } else {
/* 332 */       ClassEmitter ce = e.getClassEmitter();
/* 333 */       String typeName = TypeUtils.emulateClassGetName(type);
/*     */ 
/*     */       
/* 336 */       String fieldName = "CGLIB$load_class$" + TypeUtils.escapeType(typeName);
/* 337 */       if (!ce.isFieldDeclared(fieldName)) {
/* 338 */         ce.declare_field(26, fieldName, Constants.TYPE_CLASS, null);
/* 339 */         CodeEmitter hook = ce.getStaticHook();
/* 340 */         hook.push(typeName);
/* 341 */         hook.invoke_static(Constants.TYPE_CLASS, FOR_NAME);
/* 342 */         hook.putstatic(ce.getClassType(), fieldName, Constants.TYPE_CLASS);
/*     */       } 
/* 344 */       e.getfield(fieldName);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void push_array(CodeEmitter e, Object[] array) {
/* 349 */     e.push(array.length);
/* 350 */     e.newarray(Type.getType(remapComponentType(array.getClass().componentType())));
/* 351 */     for (int i = 0; i < array.length; i++) {
/* 352 */       e.dup();
/* 353 */       e.push(i);
/* 354 */       push_object(e, array[i]);
/* 355 */       e.aastore();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class remapComponentType(Class componentType) {
/* 360 */     if (componentType.equals(Type.class)) {
/* 361 */       return Class.class;
/*     */     }
/* 363 */     return componentType;
/*     */   }
/*     */   
/*     */   public static void push_object(CodeEmitter e, Object obj) {
/* 367 */     if (obj == null)
/* 368 */     { e.aconst_null(); }
/*     */     
/* 370 */     else if (obj.getClass().isArray())
/* 371 */     { push_array(e, (Object[])obj); }
/* 372 */     else if (obj instanceof String) { String text = (String)obj;
/* 373 */       e.push(text); }
/* 374 */     else if (obj instanceof Type) { Type type = (Type)obj;
/* 375 */       load_class(e, type); }
/* 376 */     else if (obj instanceof Class) { Class<?> clazz = (Class)obj;
/* 377 */       load_class(e, Type.getType(clazz)); }
/* 378 */     else if (obj instanceof java.math.BigInteger)
/* 379 */     { e.new_instance(Constants.TYPE_BIG_INTEGER);
/* 380 */       e.dup();
/* 381 */       e.push(obj.toString());
/* 382 */       e.invoke_constructor(Constants.TYPE_BIG_INTEGER); }
/* 383 */     else if (obj instanceof java.math.BigDecimal)
/* 384 */     { e.new_instance(Constants.TYPE_BIG_DECIMAL);
/* 385 */       e.dup();
/* 386 */       e.push(obj.toString());
/* 387 */       e.invoke_constructor(Constants.TYPE_BIG_DECIMAL); }
/*     */     else
/* 389 */     { throw new IllegalArgumentException("unknown type: " + String.valueOf(obj.getClass())); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void hash_code(CodeEmitter e, Type type, int multiplier, Customizer customizer) {
/* 399 */     hash_code(e, type, multiplier, CustomizerRegistry.singleton(customizer));
/*     */   }
/*     */   
/*     */   public static void hash_code(CodeEmitter e, Type type, int multiplier, CustomizerRegistry registry) {
/* 403 */     if (TypeUtils.isArray(type)) {
/* 404 */       hash_array(e, type, multiplier, registry);
/*     */     } else {
/* 406 */       e.swap(Type.INT_TYPE, type);
/* 407 */       e.push(multiplier);
/* 408 */       e.math(104, Type.INT_TYPE);
/* 409 */       e.swap(type, Type.INT_TYPE);
/* 410 */       if (TypeUtils.isPrimitive(type)) {
/* 411 */         hash_primitive(e, type);
/*     */       } else {
/* 413 */         hash_object(e, type, registry);
/*     */       } 
/* 415 */       e.math(96, Type.INT_TYPE);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void hash_array(CodeEmitter e, Type type, int multiplier, CustomizerRegistry registry) {
/* 420 */     Label skip = e.make_label();
/* 421 */     Label end = e.make_label();
/* 422 */     e.dup();
/* 423 */     e.ifnull(skip);
/* 424 */     process_array(e, type, type1 -> hash_code(e, type1, multiplier, registry));
/* 425 */     e.goTo(end);
/* 426 */     e.mark(skip);
/* 427 */     e.pop();
/* 428 */     e.mark(end);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void hash_object(CodeEmitter e, Type type, CustomizerRegistry registry) {
/* 433 */     Label skip = e.make_label();
/* 434 */     Label end = e.make_label();
/* 435 */     e.dup();
/* 436 */     e.ifnull(skip);
/* 437 */     boolean customHashCode = false;
/* 438 */     for (HashCodeCustomizer customizer : registry.get(HashCodeCustomizer.class)) {
/* 439 */       if (customizer.customize(e, type)) {
/* 440 */         customHashCode = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 444 */     if (!customHashCode) {
/* 445 */       for (Customizer customizer : registry.get(Customizer.class)) {
/* 446 */         customizer.customize(e, type);
/*     */       }
/* 448 */       e.invoke_virtual(Constants.TYPE_OBJECT, HASH_CODE);
/*     */     } 
/* 450 */     e.goTo(end);
/* 451 */     e.mark(skip);
/* 452 */     e.pop();
/* 453 */     e.push(0);
/* 454 */     e.mark(end);
/*     */   }
/*     */   
/*     */   private static void hash_primitive(CodeEmitter e, Type type) {
/* 458 */     switch (type.getSort()) {
/*     */       
/*     */       case 1:
/* 461 */         e.push(1);
/* 462 */         e.math(130, Type.INT_TYPE);
/*     */         break;
/*     */       
/*     */       case 6:
/* 466 */         e.invoke_static(Constants.TYPE_FLOAT, FLOAT_TO_INT_BITS);
/*     */         break;
/*     */       
/*     */       case 8:
/* 470 */         e.invoke_static(Constants.TYPE_DOUBLE, DOUBLE_TO_LONG_BITS);
/*     */       
/*     */       case 7:
/* 473 */         hash_long(e);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void hash_long(CodeEmitter e) {
/* 479 */     e.dup2();
/* 480 */     e.push(32);
/* 481 */     e.math(124, Type.LONG_TYPE);
/* 482 */     e.math(130, Type.LONG_TYPE);
/* 483 */     e.cast_numeric(Type.LONG_TYPE, Type.INT_TYPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void not_equals(CodeEmitter e, Type type, Label notEquals, Customizer customizer) {
/* 495 */     not_equals(e, type, notEquals, CustomizerRegistry.singleton(customizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void not_equals(final CodeEmitter e, Type type, final Label notEquals, final CustomizerRegistry registry) {
/* 506 */     (new ProcessArrayCallback()
/*     */       {
/*     */         public void processElement(Type type) {
/* 509 */           EmitUtils.not_equals_helper(e, type, notEquals, registry, this);
/*     */         }
/* 511 */       }).processElement(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void not_equals_helper(CodeEmitter e, Type type, Label notEquals, CustomizerRegistry registry, ProcessArrayCallback callback) {
/* 519 */     if (TypeUtils.isPrimitive(type)) {
/* 520 */       e.if_cmp(type, 154, notEquals);
/*     */     } else {
/* 522 */       Label end = e.make_label();
/* 523 */       nullcmp(e, notEquals, end);
/* 524 */       if (TypeUtils.isArray(type)) {
/* 525 */         Label checkContents = e.make_label();
/* 526 */         e.dup2();
/* 527 */         e.arraylength();
/* 528 */         e.swap();
/* 529 */         e.arraylength();
/* 530 */         e.if_icmp(153, checkContents);
/* 531 */         e.pop2();
/* 532 */         e.goTo(notEquals);
/* 533 */         e.mark(checkContents);
/* 534 */         process_arrays(e, type, callback);
/*     */       } else {
/* 536 */         List<Customizer> customizers = registry.get(Customizer.class);
/* 537 */         if (!customizers.isEmpty()) {
/* 538 */           for (Customizer customizer : customizers) {
/* 539 */             customizer.customize(e, type);
/*     */           }
/* 541 */           e.swap();
/* 542 */           for (Customizer customizer : customizers) {
/* 543 */             customizer.customize(e, type);
/*     */           }
/*     */         } 
/* 546 */         e.invoke_virtual(Constants.TYPE_OBJECT, EQUALS);
/* 547 */         e.if_jump(153, notEquals);
/*     */       } 
/* 549 */       e.mark(end);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void nullcmp(CodeEmitter e, Label oneNull, Label bothNull) {
/* 561 */     e.dup2();
/* 562 */     Label nonNull = e.make_label();
/* 563 */     Label oneNullHelper = e.make_label();
/* 564 */     Label end = e.make_label();
/* 565 */     e.ifnonnull(nonNull);
/* 566 */     e.ifnonnull(oneNullHelper);
/* 567 */     e.pop2();
/* 568 */     e.goTo(bothNull);
/*     */     
/* 570 */     e.mark(nonNull);
/* 571 */     e.ifnull(oneNullHelper);
/* 572 */     e.goTo(end);
/*     */     
/* 574 */     e.mark(oneNullHelper);
/* 575 */     e.pop2();
/* 576 */     e.goTo(oneNull);
/*     */     
/* 578 */     e.mark(end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void append_string(CodeEmitter e, Type type, ArrayDelimiters delims, Customizer customizer) {
/* 603 */     append_string(e, type, delims, CustomizerRegistry.singleton(customizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void append_string(final CodeEmitter e, Type type, ArrayDelimiters delims, final CustomizerRegistry registry) {
/* 610 */     final ArrayDelimiters d = (delims != null) ? delims : DEFAULT_DELIMITERS;
/* 611 */     ProcessArrayCallback callback = new ProcessArrayCallback()
/*     */       {
/*     */         public void processElement(Type type) {
/* 614 */           EmitUtils.append_string_helper(e, type, d, registry, this);
/* 615 */           e.push(d.inside);
/* 616 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, EmitUtils.APPEND_STRING);
/*     */         }
/*     */       };
/* 619 */     append_string_helper(e, type, d, registry, callback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void append_string_helper(CodeEmitter e, Type type, ArrayDelimiters delims, CustomizerRegistry registry, ProcessArrayCallback callback) {
/* 627 */     Label skip = e.make_label();
/* 628 */     Label end = e.make_label();
/* 629 */     if (TypeUtils.isPrimitive(type)) {
/* 630 */       switch (type.getSort()) {
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/* 634 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_INT);
/*     */           break;
/*     */         case 8:
/* 637 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_DOUBLE);
/*     */           break;
/*     */         case 6:
/* 640 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_FLOAT);
/*     */           break;
/*     */         case 7:
/* 643 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_LONG);
/*     */           break;
/*     */         case 1:
/* 646 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_BOOLEAN);
/*     */           break;
/*     */         case 2:
/* 649 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_CHAR);
/*     */           break;
/*     */       } 
/* 652 */     } else if (TypeUtils.isArray(type)) {
/* 653 */       e.dup();
/* 654 */       e.ifnull(skip);
/* 655 */       e.swap();
/* 656 */       if (delims != null && delims.before != null && !delims.before.isEmpty()) {
/* 657 */         e.push(delims.before);
/* 658 */         e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_STRING);
/* 659 */         e.swap();
/*     */       } 
/* 661 */       process_array(e, type, callback);
/* 662 */       shrinkStringBuffer(e, 2);
/* 663 */       if (delims != null && delims.after != null && !delims.after.isEmpty()) {
/* 664 */         e.push(delims.after);
/* 665 */         e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_STRING);
/*     */       } 
/*     */     } else {
/* 668 */       e.dup();
/* 669 */       e.ifnull(skip);
/* 670 */       for (Customizer customizer : registry.get(Customizer.class)) {
/* 671 */         customizer.customize(e, type);
/*     */       }
/* 673 */       e.invoke_virtual(Constants.TYPE_OBJECT, TO_STRING);
/* 674 */       e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_STRING);
/*     */     } 
/* 676 */     e.goTo(end);
/* 677 */     e.mark(skip);
/* 678 */     e.pop();
/* 679 */     e.push("null");
/* 680 */     e.invoke_virtual(Constants.TYPE_STRING_BUFFER, APPEND_STRING);
/* 681 */     e.mark(end);
/*     */   }
/*     */   
/*     */   private static void shrinkStringBuffer(CodeEmitter e, int amt) {
/* 685 */     e.dup();
/* 686 */     e.dup();
/* 687 */     e.invoke_virtual(Constants.TYPE_STRING_BUFFER, LENGTH);
/* 688 */     e.push(amt);
/* 689 */     e.math(100, Type.INT_TYPE);
/* 690 */     e.invoke_virtual(Constants.TYPE_STRING_BUFFER, SET_LENGTH);
/*     */   }
/*     */   
/*     */   public static class ArrayDelimiters {
/*     */     private String before;
/*     */     private String inside;
/*     */     private String after;
/*     */     
/*     */     public ArrayDelimiters(String before, String inside, String after) {
/* 699 */       this.before = before;
/* 700 */       this.inside = inside;
/* 701 */       this.after = after;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void load_method(CodeEmitter e, MethodInfo method) {
/* 706 */     load_class(e, method.getClassInfo().getType());
/* 707 */     e.push(method.getSignature().getName());
/* 708 */     push_object(e, method.getSignature().getArgumentTypes());
/* 709 */     e.invoke_virtual(Constants.TYPE_CLASS, GET_DECLARED_METHOD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void method_switch(CodeEmitter e, List methods, ObjectSwitchCallback callback) {
/* 719 */     member_switch_helper(e, methods, callback, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void constructor_switch(CodeEmitter e, List constructors, ObjectSwitchCallback callback) {
/* 725 */     member_switch_helper(e, constructors, callback, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void member_switch_helper(final CodeEmitter e, List members, final ObjectSwitchCallback callback, boolean useName) {
/*     */     try {
/* 733 */       Map<Object, Object> cache = new HashMap<>();
/* 734 */       final ParameterTyper cached = member -> {
/*     */           Type[] types = (Type[])cache.get(member);
/*     */           if (types == null) {
/*     */             cache.put(member, types = member.getSignature().getArgumentTypes());
/*     */           }
/*     */           return types;
/*     */         };
/* 741 */       final Label def = e.make_label();
/* 742 */       final Label end = e.make_label();
/* 743 */       if (useName) {
/* 744 */         e.swap();
/* 745 */         final Map buckets = CollectionUtils.bucket(members, value -> ((MethodInfo)value).getSignature().getName());
/* 746 */         String[] names = (String[])buckets.keySet().toArray((Object[])new String[buckets.size()]);
/* 747 */         string_switch(e, names, 1, new ObjectSwitchCallback()
/*     */             {
/*     */               public void processCase(Object key, Label dontUseEnd) throws Exception {
/* 750 */                 EmitUtils.member_helper_size(e, (List)buckets.get(key), callback, cached, def, end);
/*     */               }
/*     */               
/*     */               public void processDefault() throws Exception {
/* 754 */                 e.goTo(def);
/*     */               }
/*     */             });
/*     */       } else {
/* 758 */         member_helper_size(e, members, callback, cached, def, end);
/*     */       } 
/* 760 */       e.mark(def);
/* 761 */       e.pop();
/* 762 */       callback.processDefault();
/* 763 */       e.mark(end);
/* 764 */     } catch (RuntimeException|Error ex) {
/* 765 */       throw ex;
/* 766 */     } catch (Exception ex) {
/* 767 */       throw new CodeGenerationException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void member_helper_size(final CodeEmitter e, List members, final ObjectSwitchCallback callback, final ParameterTyper typer, final Label def, final Label end) throws Exception {
/* 777 */     final Map buckets = CollectionUtils.bucket(members, value -> Integer.valueOf((typer.getParameterTypes((MethodInfo)value)).length));
/* 778 */     e.dup();
/* 779 */     e.arraylength();
/* 780 */     e.process_switch(getSwitchKeys(buckets), new ProcessSwitchCallback()
/*     */         {
/*     */           public void processCase(int key, Label dontUseEnd) throws Exception {
/* 783 */             List bucket = (List)buckets.get(Integer.valueOf(key));
/* 784 */             EmitUtils.member_helper_type(e, bucket, callback, typer, def, end, new BitSet());
/*     */           }
/*     */           
/*     */           public void processDefault() throws Exception {
/* 788 */             e.goTo(def);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void member_helper_type(final CodeEmitter e, List<MethodInfo> members, final ObjectSwitchCallback callback, final ParameterTyper typer, final Label def, final Label end, final BitSet checked) throws Exception {
/* 800 */     if (members.size() == 1) {
/* 801 */       MethodInfo member = members.get(0);
/* 802 */       Type[] types = typer.getParameterTypes(member);
/*     */       
/* 804 */       for (int i = 0; i < types.length; i++) {
/* 805 */         if (checked == null || !checked.get(i)) {
/* 806 */           e.dup();
/* 807 */           e.aaload(i);
/* 808 */           e.invoke_virtual(Constants.TYPE_CLASS, GET_NAME);
/* 809 */           e.push(TypeUtils.emulateClassGetName(types[i]));
/* 810 */           e.invoke_virtual(Constants.TYPE_OBJECT, EQUALS);
/* 811 */           e.if_jump(153, def);
/*     */         } 
/*     */       } 
/* 814 */       e.pop();
/* 815 */       callback.processCase(member, end);
/*     */     } else {
/*     */       
/* 818 */       Type[] example = typer.getParameterTypes(members.get(0));
/* 819 */       Map buckets = null;
/* 820 */       int index = -1;
/* 821 */       for (int i = 0; i < example.length; i++) {
/* 822 */         int j = i;
/* 823 */         Map test = CollectionUtils.bucket(members, value -> TypeUtils.emulateClassGetName(typer.getParameterTypes((MethodInfo)value)[j]));
/*     */         
/* 825 */         if (buckets == null || test.size() > buckets.size()) {
/* 826 */           buckets = test;
/* 827 */           index = i;
/*     */         } 
/*     */       } 
/* 830 */       if (buckets == null || buckets.size() == 1) {
/*     */ 
/*     */         
/* 833 */         e.goTo(def);
/*     */       } else {
/* 835 */         checked.set(index);
/*     */         
/* 837 */         e.dup();
/* 838 */         e.aaload(index);
/* 839 */         e.invoke_virtual(Constants.TYPE_CLASS, GET_NAME);
/*     */         
/* 841 */         final Map fbuckets = buckets;
/* 842 */         String[] names = (String[])buckets.keySet().toArray((Object[])new String[buckets.size()]);
/* 843 */         string_switch(e, names, 1, new ObjectSwitchCallback()
/*     */             {
/*     */               public void processCase(Object key, Label dontUseEnd) throws Exception {
/* 846 */                 EmitUtils.member_helper_type(e, (List)fbuckets.get(key), callback, typer, def, end, checked);
/*     */               }
/*     */               
/*     */               public void processDefault() throws Exception {
/* 850 */                 e.goTo(def);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void wrap_throwable(Block block, Type wrapper) {
/* 858 */     CodeEmitter e = block.getCodeEmitter();
/* 859 */     e.catch_exception(block, Constants.TYPE_THROWABLE);
/* 860 */     e.new_instance(wrapper);
/* 861 */     e.dup_x1();
/* 862 */     e.swap();
/* 863 */     e.invoke_constructor(wrapper, CSTRUCT_THROWABLE);
/* 864 */     e.athrow();
/*     */   }
/*     */   
/*     */   public static void add_properties(ClassEmitter ce, String[] names, Type[] types) {
/* 868 */     for (int i = 0; i < names.length; i++) {
/* 869 */       String fieldName = "$cglib_prop_" + names[i];
/* 870 */       ce.declare_field(2, fieldName, types[i], null);
/* 871 */       add_property(ce, names[i], types[i], fieldName);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void add_property(ClassEmitter ce, String name, Type type, String fieldName) {
/* 876 */     String property = TypeUtils.upperFirst(name);
/*     */     
/* 878 */     CodeEmitter e = ce.begin_method(1, new Signature("get" + property, type, Constants.TYPES_EMPTY), null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 883 */     e.load_this();
/* 884 */     e.getfield(fieldName);
/* 885 */     e.return_value();
/* 886 */     e.end_method();
/*     */     
/* 888 */     e = ce.begin_method(1, new Signature("set" + property, Type.VOID_TYPE, new Type[] { type }), null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 893 */     e.load_this();
/* 894 */     e.load_arg(0);
/* 895 */     e.putfield(fieldName);
/* 896 */     e.return_value();
/* 897 */     e.end_method();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void wrap_undeclared_throwable(CodeEmitter e, Block handler, Type[] exceptions, Type wrapper) {
/* 912 */     Set set = (exceptions == null) ? Collections.EMPTY_SET : new HashSet(Arrays.asList((Object[])exceptions));
/*     */     
/* 914 */     if (set.contains(Constants.TYPE_THROWABLE)) {
/*     */       return;
/*     */     }
/*     */     
/* 918 */     boolean needThrow = (exceptions != null);
/* 919 */     if (!set.contains(Constants.TYPE_RUNTIME_EXCEPTION)) {
/* 920 */       e.catch_exception(handler, Constants.TYPE_RUNTIME_EXCEPTION);
/* 921 */       needThrow = true;
/*     */     } 
/* 923 */     if (!set.contains(Constants.TYPE_ERROR)) {
/* 924 */       e.catch_exception(handler, Constants.TYPE_ERROR);
/* 925 */       needThrow = true;
/*     */     } 
/* 927 */     if (exceptions != null) {
/* 928 */       for (Type exception : exceptions) {
/* 929 */         e.catch_exception(handler, exception);
/*     */       }
/*     */     }
/* 932 */     if (needThrow) {
/* 933 */       e.athrow();
/*     */     }
/*     */     
/* 936 */     e.catch_exception(handler, Constants.TYPE_THROWABLE);
/* 937 */     e.new_instance(wrapper);
/* 938 */     e.dup_x1();
/* 939 */     e.swap();
/* 940 */     e.invoke_constructor(wrapper, CSTRUCT_THROWABLE);
/* 941 */     e.athrow();
/*     */   }
/*     */   
/*     */   public static CodeEmitter begin_method(ClassEmitter e, MethodInfo method) {
/* 945 */     return begin_method(e, method, method.getModifiers());
/*     */   }
/*     */   
/*     */   public static CodeEmitter begin_method(ClassEmitter e, MethodInfo method, int access) {
/* 949 */     return e.begin_method(access, method
/* 950 */         .getSignature(), method
/* 951 */         .getExceptionTypes());
/*     */   }
/*     */   
/*     */   private static interface ParameterTyper {
/*     */     Type[] getParameterTypes(MethodInfo param1MethodInfo);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\EmitUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */