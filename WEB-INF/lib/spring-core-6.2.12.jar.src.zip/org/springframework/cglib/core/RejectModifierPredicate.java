/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RejectModifierPredicate
/*    */   implements Predicate
/*    */ {
/*    */   private int rejectMask;
/*    */   
/*    */   public RejectModifierPredicate(int rejectMask) {
/* 24 */     this.rejectMask = rejectMask;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean evaluate(Object arg) {
/* 29 */     return ((((Member)arg).getModifiers() & this.rejectMask) == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\RejectModifierPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */