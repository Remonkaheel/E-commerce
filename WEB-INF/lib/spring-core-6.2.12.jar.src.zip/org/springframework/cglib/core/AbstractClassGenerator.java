/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.cglib.core.internal.Function;
/*     */ import org.springframework.cglib.core.internal.LoadingCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractClassGenerator<T>
/*     */   implements ClassGenerator
/*     */ {
/*  39 */   private static final ThreadLocal CURRENT = new ThreadLocal();
/*     */   
/*  41 */   private static volatile Map<ClassLoader, ClassLoaderData> CACHE = new WeakHashMap<>();
/*     */ 
/*     */   
/*  44 */   private static final boolean DEFAULT_USE_CACHE = Boolean.parseBoolean(System.getProperty("cglib.useCache", "true"));
/*     */   
/*     */   private static final boolean inNativeImage;
/*     */   
/*     */   static {
/*  49 */     String imageCode = System.getProperty("org.graalvm.nativeimage.imagecode");
/*  50 */     inNativeImage = ("buildtime".equals(imageCode) || "runtime".equals(imageCode));
/*     */   }
/*     */ 
/*     */   
/*  54 */   private GeneratorStrategy strategy = DefaultGeneratorStrategy.INSTANCE;
/*     */   
/*  56 */   private NamingPolicy namingPolicy = DefaultNamingPolicy.INSTANCE;
/*     */   
/*     */   private Source source;
/*     */   
/*     */   private ClassLoader classLoader;
/*     */   
/*     */   private Class contextClass;
/*     */   
/*     */   private String namePrefix;
/*     */   
/*     */   private Object key;
/*     */   
/*  68 */   private boolean useCache = DEFAULT_USE_CACHE;
/*     */   
/*     */   private String className;
/*     */   
/*     */   private boolean attemptLoad;
/*     */ 
/*     */   
/*     */   protected static class ClassLoaderData
/*     */   {
/*  77 */     private final Set<String> reservedClassNames = new HashSet<>();
/*     */ 
/*     */ 
/*     */     
/*     */     private final LoadingCache<AbstractClassGenerator, Object, Object> generatedClasses;
/*     */ 
/*     */ 
/*     */     
/*     */     private final WeakReference<ClassLoader> classLoader;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Predicate uniqueNamePredicate;
/*     */ 
/*     */     
/*     */     private static final Function<AbstractClassGenerator, Object> GET_KEY;
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoaderData(ClassLoader classLoader) {
/*  97 */       Objects.requireNonNull(this.reservedClassNames); this.uniqueNamePredicate = this.reservedClassNames::contains;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       if (classLoader == null) {
/* 103 */         throw new IllegalArgumentException("classLoader == null is not yet supported");
/*     */       }
/* 105 */       this.classLoader = new WeakReference<>(classLoader);
/* 106 */       Function<AbstractClassGenerator, Object> load = gen -> {
/*     */           Class klass = gen.generate(this);
/*     */           return gen.wrapCachedClass(klass);
/*     */         };
/* 110 */       this.generatedClasses = new LoadingCache(GET_KEY, load);
/*     */     }
/*     */     
/*     */     public ClassLoader getClassLoader() {
/* 114 */       return this.classLoader.get();
/*     */     } static {
/*     */       GET_KEY = (gen -> gen.key);
/*     */     } public void reserveName(String name) {
/* 118 */       this.reservedClassNames.add(name);
/*     */     }
/*     */     
/*     */     public Predicate getUniqueNamePredicate() {
/* 122 */       return this.uniqueNamePredicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object get(AbstractClassGenerator<Object> gen, boolean useCache) {
/* 127 */       Object value = null;
/* 128 */       if (useCache) {
/* 129 */         Object cachedValue = this.generatedClasses.get(gen);
/* 130 */         value = gen.unwrapCachedValue(cachedValue);
/*     */       } 
/* 132 */       if (value == null) {
/* 133 */         value = gen.generate(this);
/*     */       }
/* 135 */       return value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected T wrapCachedClass(Class<?> klass) {
/* 142 */     return (T)new WeakReference<>(klass);
/*     */   }
/*     */   
/*     */   protected Object unwrapCachedValue(T cached) {
/* 146 */     return ((WeakReference)cached).get();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class Source
/*     */   {
/*     */     String name;
/*     */     
/*     */     public Source(String name) {
/* 155 */       this.name = name;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractClassGenerator(Source source) {
/* 161 */     this.source = source;
/*     */   }
/*     */   
/*     */   protected void setNamePrefix(String namePrefix) {
/* 165 */     this.namePrefix = namePrefix;
/*     */   }
/*     */   
/*     */   protected final String getClassName() {
/* 169 */     return this.className;
/*     */   }
/*     */   
/*     */   private void setClassName(String className) {
/* 173 */     this.className = className;
/*     */   }
/*     */   
/*     */   private String generateClassName(Predicate nameTestPredicate) {
/* 177 */     return this.namingPolicy.getClassName(this.namePrefix, this.source.name, this.key, nameTestPredicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassLoader(ClassLoader classLoader) {
/* 190 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContextClass(Class contextClass) {
/* 195 */     this.contextClass = contextClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamingPolicy(NamingPolicy namingPolicy) {
/* 205 */     if (namingPolicy == null) {
/* 206 */       namingPolicy = DefaultNamingPolicy.INSTANCE;
/*     */     }
/* 208 */     this.namingPolicy = namingPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamingPolicy getNamingPolicy() {
/* 215 */     return this.namingPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseCache(boolean useCache) {
/* 223 */     this.useCache = useCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUseCache() {
/* 230 */     return this.useCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttemptLoad(boolean attemptLoad) {
/* 239 */     this.attemptLoad = attemptLoad;
/*     */   }
/*     */   
/*     */   public boolean getAttemptLoad() {
/* 243 */     return this.attemptLoad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStrategy(GeneratorStrategy strategy) {
/* 251 */     if (strategy == null) {
/* 252 */       strategy = DefaultGeneratorStrategy.INSTANCE;
/*     */     }
/* 254 */     this.strategy = strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratorStrategy getStrategy() {
/* 261 */     return this.strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractClassGenerator getCurrent() {
/* 269 */     return CURRENT.get();
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 273 */     ClassLoader t = this.classLoader;
/* 274 */     if (t == null) {
/* 275 */       t = getDefaultClassLoader();
/*     */     }
/* 277 */     if (t == null) {
/* 278 */       t = getClass().getClassLoader();
/*     */     }
/* 280 */     if (t == null) {
/* 281 */       t = Thread.currentThread().getContextClassLoader();
/*     */     }
/* 283 */     if (t == null) {
/* 284 */       throw new IllegalStateException("Cannot determine classloader");
/*     */     }
/* 286 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/* 300 */     return null;
/*     */   }
/*     */   
/*     */   protected Object create(Object key) {
/*     */     try {
/* 305 */       ClassLoader loader = getClassLoader();
/* 306 */       Map<ClassLoader, ClassLoaderData> cache = CACHE;
/* 307 */       ClassLoaderData data = cache.get(loader);
/* 308 */       if (data == null) {
/* 309 */         synchronized (AbstractClassGenerator.class) {
/* 310 */           cache = CACHE;
/* 311 */           data = cache.get(loader);
/* 312 */           if (data == null) {
/* 313 */             Map<ClassLoader, ClassLoaderData> newCache = new WeakHashMap<>(cache);
/* 314 */             data = new ClassLoaderData(loader);
/* 315 */             newCache.put(loader, data);
/* 316 */             CACHE = newCache;
/*     */           } 
/*     */         } 
/*     */       }
/* 320 */       this.key = key;
/* 321 */       Object obj = data.get(this, getUseCache());
/* 322 */       if (obj instanceof Class) { Class<?> clazz = (Class)obj;
/* 323 */         return firstInstance(clazz); }
/*     */       
/* 325 */       return nextInstance(obj);
/*     */     }
/* 327 */     catch (RuntimeException|Error ex) {
/* 328 */       throw ex;
/*     */     }
/* 330 */     catch (Exception ex) {
/* 331 */       throw new CodeGenerationException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class generate(ClassLoaderData data) {
/* 337 */     Object save = CURRENT.get();
/* 338 */     CURRENT.set(this); try {
/*     */       Class gen;
/* 340 */       ClassLoader classLoader = data.getClassLoader();
/* 341 */       if (classLoader == null) {
/* 342 */         throw new IllegalStateException("ClassLoader is null while trying to define class " + 
/* 343 */             getClassName() + ". It seems that the loader has been expired from a weak reference somehow. Please file an issue at cglib's issue tracker.");
/*     */       }
/*     */       
/* 346 */       synchronized (classLoader) {
/* 347 */         String name = generateClassName(data.getUniqueNamePredicate());
/* 348 */         data.reserveName(name);
/* 349 */         setClassName(name);
/*     */       } 
/* 351 */       if (this.attemptLoad) {
/*     */         
/*     */         try {
/* 354 */           synchronized (classLoader) {
/* 355 */             gen = ReflectUtils.loadClass(getClassName(), classLoader);
/*     */           } 
/*     */           
/* 358 */           return gen;
/*     */         }
/* 360 */         catch (ClassNotFoundException classNotFoundException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 365 */       if (inNativeImage) {
/* 366 */         throw new UnsupportedOperationException("CGLIB runtime enhancement not supported on native image. Make sure to enable Spring AOT processing to pre-generate '" + 
/* 367 */             getClassName() + "' at build time.");
/*     */       }
/*     */       
/* 370 */       byte[] b = this.strategy.generate(this);
/* 371 */       String className = ClassNameReader.getClassName(new ClassReader(b));
/* 372 */       ProtectionDomain protectionDomain = getProtectionDomain();
/* 373 */       synchronized (classLoader) {
/*     */         
/* 375 */         gen = ReflectUtils.defineClass(className, b, classLoader, protectionDomain, this.contextClass);
/*     */       } 
/*     */       
/* 378 */       return gen;
/*     */     }
/* 380 */     catch (RuntimeException|Error ex) {
/* 381 */       throw ex;
/*     */     }
/* 383 */     catch (Exception ex) {
/* 384 */       throw new CodeGenerationException(ex);
/*     */     } finally {
/*     */       
/* 387 */       CURRENT.set(save);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract ClassLoader getDefaultClassLoader();
/*     */   
/*     */   protected abstract Object firstInstance(Class paramClass) throws Exception;
/*     */   
/*     */   protected abstract Object nextInstance(Object paramObject) throws Exception;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\AbstractClassGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */