/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.internal.CustomizerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyFactory
/*     */ {
/*  61 */   private static final Signature GET_NAME = TypeUtils.parseSignature("String getName()");
/*     */ 
/*     */   
/*  64 */   private static final Signature GET_CLASS = TypeUtils.parseSignature("Class getClass()");
/*     */ 
/*     */   
/*  67 */   private static final Signature HASH_CODE = TypeUtils.parseSignature("int hashCode()");
/*     */ 
/*     */   
/*  70 */   private static final Signature EQUALS = TypeUtils.parseSignature("boolean equals(Object)");
/*     */ 
/*     */   
/*  73 */   private static final Signature TO_STRING = TypeUtils.parseSignature("String toString()");
/*     */ 
/*     */   
/*  76 */   private static final Signature APPEND_STRING = TypeUtils.parseSignature("StringBuffer append(String)");
/*     */ 
/*     */   
/*  79 */   private static final Type KEY_FACTORY = TypeUtils.parseType("org.springframework.cglib.core.KeyFactory");
/*     */ 
/*     */   
/*  82 */   private static final Signature GET_SORT = TypeUtils.parseSignature("int getSort()");
/*     */ 
/*     */   
/*  85 */   private static final int[] PRIMES = new int[] { 11, 73, 179, 331, 521, 787, 1213, 1823, 2609, 3691, 5189, 7247, 10037, 13931, 19289, 26627, 36683, 50441, 69403, 95401, 131129, 180179, 247501, 340057, 467063, 641371, 880603, 1209107, 1660097, 2279161, 3129011, 4295723, 5897291, 8095873, 11114263, 15257791, 20946017, 28754629, 39474179, 54189869, 74391461, 102123817, 140194277, 192456917, 264202273, 362693231, 497900099, 683510293, 938313161, 1288102441, 1768288259 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Customizer CLASS_BY_NAME;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 101 */     CLASS_BY_NAME = ((e, type) -> {
/*     */         if (type.equals(Constants.TYPE_CLASS))
/*     */           e.invoke_virtual(Constants.TYPE_CLASS, GET_NAME); 
/*     */       });
/*     */   }
/*     */   
/* 107 */   public static final FieldTypeCustomizer STORE_CLASS_AS_STRING = new FieldTypeCustomizer()
/*     */     {
/*     */       public void customize(CodeEmitter e, int index, Type type) {
/* 110 */         if (type.equals(Constants.TYPE_CLASS)) {
/* 111 */           e.invoke_virtual(Constants.TYPE_CLASS, KeyFactory.GET_NAME);
/*     */         }
/*     */       }
/*     */       
/*     */       public Type getOutType(int index, Type type) {
/* 116 */         if (type.equals(Constants.TYPE_CLASS)) {
/* 117 */           return Constants.TYPE_STRING;
/*     */         }
/* 119 */         return type;
/*     */       }
/*     */     };
/*     */   public static final HashCodeCustomizer HASH_ASM_TYPE;
/*     */   @Deprecated
/*     */   public static final Customizer OBJECT_BY_CLASS;
/*     */   
/*     */   static {
/* 127 */     HASH_ASM_TYPE = ((e, type) -> {
/*     */         if (Constants.TYPE_TYPE.equals(type)) {
/*     */           e.invoke_virtual(type, GET_SORT);
/*     */ 
/*     */           
/*     */           return true;
/*     */         } 
/*     */ 
/*     */         
/*     */         return false;
/*     */       });
/*     */ 
/*     */     
/* 140 */     OBJECT_BY_CLASS = ((e, type) -> e.invoke_virtual(Constants.TYPE_OBJECT, GET_CLASS));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyFactory create(Class keyInterface) {
/* 146 */     return create(keyInterface, null);
/*     */   }
/*     */   
/*     */   public static KeyFactory create(Class keyInterface, Customizer customizer) {
/* 150 */     return create(keyInterface.getClassLoader(), keyInterface, customizer);
/*     */   }
/*     */   
/*     */   public static KeyFactory create(Class keyInterface, KeyFactoryCustomizer first, List<KeyFactoryCustomizer> next) {
/* 154 */     return create(keyInterface.getClassLoader(), keyInterface, first, next);
/*     */   }
/*     */   
/*     */   public static KeyFactory create(ClassLoader loader, Class keyInterface, Customizer customizer) {
/* 158 */     return create(loader, keyInterface, customizer, Collections.emptyList());
/*     */   }
/*     */ 
/*     */   
/*     */   public static KeyFactory create(ClassLoader loader, Class keyInterface, KeyFactoryCustomizer customizer, List<KeyFactoryCustomizer> next) {
/* 163 */     Generator gen = new Generator();
/* 164 */     gen.setInterface(keyInterface);
/*     */     
/* 166 */     gen.setContextClass(keyInterface);
/*     */ 
/*     */     
/* 169 */     if (customizer != null) {
/* 170 */       gen.addCustomizer(customizer);
/*     */     }
/* 172 */     if (next != null && !next.isEmpty()) {
/* 173 */       for (KeyFactoryCustomizer keyFactoryCustomizer : next) {
/* 174 */         gen.addCustomizer(keyFactoryCustomizer);
/*     */       }
/*     */     }
/* 177 */     gen.setClassLoader(loader);
/* 178 */     return gen.create();
/*     */   }
/*     */   
/*     */   public static class Generator
/*     */     extends AbstractClassGenerator
/*     */   {
/* 184 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(KeyFactory.class.getName());
/*     */     
/* 186 */     private static final Class[] KNOWN_CUSTOMIZER_TYPES = new Class[] { Customizer.class, FieldTypeCustomizer.class };
/*     */ 
/*     */     
/*     */     private Class keyInterface;
/*     */     
/* 191 */     private CustomizerRegistry customizers = new CustomizerRegistry(KNOWN_CUSTOMIZER_TYPES);
/*     */     
/*     */     private int constant;
/*     */     
/*     */     private int multiplier;
/*     */     
/*     */     public Generator() {
/* 198 */       super(SOURCE);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 203 */       return this.keyInterface.getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/* 208 */       return ReflectUtils.getProtectionDomain(this.keyInterface);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void setCustomizer(Customizer customizer) {
/* 216 */       this.customizers = CustomizerRegistry.singleton(customizer);
/*     */     }
/*     */     
/*     */     public void addCustomizer(KeyFactoryCustomizer customizer) {
/* 220 */       this.customizers.add(customizer);
/*     */     }
/*     */     
/*     */     public <T> List<T> getCustomizers(Class<T> klass) {
/* 224 */       return this.customizers.get(klass);
/*     */     }
/*     */     
/*     */     public void setInterface(Class keyInterface) {
/* 228 */       this.keyInterface = keyInterface;
/*     */     }
/*     */     
/*     */     public KeyFactory create() {
/* 232 */       setNamePrefix(this.keyInterface.getName());
/* 233 */       return (KeyFactory)create(this.keyInterface.getName());
/*     */     }
/*     */     
/*     */     public void setHashConstant(int constant) {
/* 237 */       this.constant = constant;
/*     */     }
/*     */     
/*     */     public void setHashMultiplier(int multiplier) {
/* 241 */       this.multiplier = multiplier;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 246 */       return ReflectUtils.newInstance(type);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 251 */       return instance;
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) {
/* 256 */       ClassEmitter ce = new ClassEmitter(v);
/*     */       
/* 258 */       Method newInstance = ReflectUtils.findNewInstance(this.keyInterface);
/* 259 */       if (!newInstance.getReturnType().equals(Object.class)) {
/* 260 */         throw new IllegalArgumentException("newInstance method must return Object");
/*     */       }
/*     */       
/* 263 */       Type[] parameterTypes = TypeUtils.getTypes(newInstance.getParameterTypes());
/* 264 */       ce.begin_class(52, 1, 
/*     */           
/* 266 */           getClassName(), KeyFactory.KEY_FACTORY, new Type[] {
/*     */             
/* 268 */             Type.getType(this.keyInterface) }, "<generated>");
/*     */       
/* 270 */       EmitUtils.null_constructor(ce);
/* 271 */       EmitUtils.factory_method(ce, ReflectUtils.getSignature(newInstance));
/*     */       
/* 273 */       int seed = 0;
/* 274 */       CodeEmitter e = ce.begin_method(1, 
/* 275 */           TypeUtils.parseConstructor(parameterTypes), null);
/*     */       
/* 277 */       e.load_this();
/* 278 */       e.super_invoke_constructor();
/* 279 */       e.load_this();
/* 280 */       List<FieldTypeCustomizer> fieldTypeCustomizers = getCustomizers(FieldTypeCustomizer.class);
/* 281 */       for (int i = 0; i < parameterTypes.length; i++) {
/* 282 */         Type parameterType = parameterTypes[i];
/* 283 */         Type fieldType = parameterType;
/* 284 */         for (FieldTypeCustomizer customizer : fieldTypeCustomizers) {
/* 285 */           fieldType = customizer.getOutType(i, fieldType);
/*     */         }
/* 287 */         seed += fieldType.hashCode();
/* 288 */         ce.declare_field(18, 
/* 289 */             getFieldName(i), fieldType, null);
/*     */ 
/*     */         
/* 292 */         e.dup();
/* 293 */         e.load_arg(i);
/* 294 */         for (FieldTypeCustomizer customizer : fieldTypeCustomizers) {
/* 295 */           customizer.customize(e, i, parameterType);
/*     */         }
/* 297 */         e.putfield(getFieldName(i));
/*     */       } 
/* 299 */       e.return_value();
/* 300 */       e.end_method();
/*     */ 
/*     */       
/* 303 */       e = ce.begin_method(1, KeyFactory.HASH_CODE, null);
/* 304 */       int hc = (this.constant != 0) ? this.constant : KeyFactory.PRIMES[Math.abs(seed) % KeyFactory.PRIMES.length];
/* 305 */       int hm = (this.multiplier != 0) ? this.multiplier : KeyFactory.PRIMES[Math.abs(seed * 13) % KeyFactory.PRIMES.length];
/* 306 */       e.push(hc);
/* 307 */       for (int j = 0; j < parameterTypes.length; j++) {
/* 308 */         e.load_this();
/* 309 */         e.getfield(getFieldName(j));
/* 310 */         EmitUtils.hash_code(e, parameterTypes[j], hm, this.customizers);
/*     */       } 
/* 312 */       e.return_value();
/* 313 */       e.end_method();
/*     */ 
/*     */       
/* 316 */       e = ce.begin_method(1, KeyFactory.EQUALS, null);
/* 317 */       Label fail = e.make_label();
/* 318 */       e.load_arg(0);
/* 319 */       e.instance_of_this();
/* 320 */       e.if_jump(153, fail); int k;
/* 321 */       for (k = 0; k < parameterTypes.length; k++) {
/* 322 */         e.load_this();
/* 323 */         e.getfield(getFieldName(k));
/* 324 */         e.load_arg(0);
/* 325 */         e.checkcast_this();
/* 326 */         e.getfield(getFieldName(k));
/* 327 */         EmitUtils.not_equals(e, parameterTypes[k], fail, this.customizers);
/*     */       } 
/* 329 */       e.push(1);
/* 330 */       e.return_value();
/* 331 */       e.mark(fail);
/* 332 */       e.push(0);
/* 333 */       e.return_value();
/* 334 */       e.end_method();
/*     */ 
/*     */       
/* 337 */       e = ce.begin_method(1, KeyFactory.TO_STRING, null);
/* 338 */       e.new_instance(Constants.TYPE_STRING_BUFFER);
/* 339 */       e.dup();
/* 340 */       e.invoke_constructor(Constants.TYPE_STRING_BUFFER);
/* 341 */       for (k = 0; k < parameterTypes.length; k++) {
/* 342 */         if (k > 0) {
/* 343 */           e.push(", ");
/* 344 */           e.invoke_virtual(Constants.TYPE_STRING_BUFFER, KeyFactory.APPEND_STRING);
/*     */         } 
/* 346 */         e.load_this();
/* 347 */         e.getfield(getFieldName(k));
/* 348 */         EmitUtils.append_string(e, parameterTypes[k], EmitUtils.DEFAULT_DELIMITERS, this.customizers);
/*     */       } 
/* 350 */       e.invoke_virtual(Constants.TYPE_STRING_BUFFER, KeyFactory.TO_STRING);
/* 351 */       e.return_value();
/* 352 */       e.end_method();
/*     */       
/* 354 */       ce.end_class();
/*     */     }
/*     */     
/*     */     private String getFieldName(int arg) {
/* 358 */       return "FIELD_" + arg;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\KeyFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */