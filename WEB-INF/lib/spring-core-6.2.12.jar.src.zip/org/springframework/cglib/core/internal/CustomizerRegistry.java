/*    */ package org.springframework.cglib.core.internal;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.cglib.core.Customizer;
/*    */ import org.springframework.cglib.core.KeyFactoryCustomizer;
/*    */ 
/*    */ 
/*    */ public class CustomizerRegistry
/*    */ {
/*    */   private final Class[] customizerTypes;
/* 15 */   private Map<Class, List<KeyFactoryCustomizer>> customizers = (Map)new HashMap<>();
/*    */   
/*    */   public CustomizerRegistry(Class[] customizerTypes) {
/* 18 */     this.customizerTypes = customizerTypes;
/*    */   }
/*    */   
/*    */   public void add(KeyFactoryCustomizer customizer) {
/* 22 */     Class<? extends KeyFactoryCustomizer> klass = (Class)customizer.getClass();
/* 23 */     for (Class type : this.customizerTypes) {
/* 24 */       if (type.isAssignableFrom(klass)) {
/* 25 */         List<KeyFactoryCustomizer> list = this.customizers.computeIfAbsent(type, k -> new ArrayList());
/* 26 */         list.add(customizer);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public <T> List<T> get(Class<T> klass) {
/* 32 */     List<KeyFactoryCustomizer> list = this.customizers.get(klass);
/* 33 */     if (list == null) {
/* 34 */       return Collections.emptyList();
/*    */     }
/* 36 */     return (List)list;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static CustomizerRegistry singleton(Customizer customizer) {
/* 45 */     CustomizerRegistry registry = new CustomizerRegistry(new Class[] { Customizer.class });
/* 46 */     registry.add((KeyFactoryCustomizer)customizer);
/* 47 */     return registry;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\internal\CustomizerRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */