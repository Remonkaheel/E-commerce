/*    */ package org.springframework.cglib.core.internal;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.FutureTask;
/*    */ 
/*    */ public class LoadingCache<K, KK, V>
/*    */ {
/*    */   protected final ConcurrentMap<KK, Object> map;
/*    */   protected final Function<K, V> loader;
/*    */   
/*    */   static {
/* 14 */     IDENTITY = (key -> key);
/*    */   } protected final Function<K, KK> keyMapper; public static final Function IDENTITY;
/*    */   public LoadingCache(Function<K, KK> keyMapper, Function<K, V> loader) {
/* 17 */     this.keyMapper = keyMapper;
/* 18 */     this.loader = loader;
/* 19 */     this.map = new ConcurrentHashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public static <K> Function<K, K> identity() {
/* 24 */     return IDENTITY;
/*    */   }
/*    */   
/*    */   public V get(K key) {
/* 28 */     KK cacheKey = this.keyMapper.apply(key);
/* 29 */     Object v = this.map.get(cacheKey);
/* 30 */     if (v != null && !(v instanceof FutureTask)) {
/* 31 */       return (V)v;
/*    */     }
/*    */     
/* 34 */     return createEntry(key, cacheKey, v);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected V createEntry(K key, KK cacheKey, Object v) {
/*    */     FutureTask<V> task;
/*    */     V result;
/* 47 */     boolean creator = false;
/* 48 */     if (v != null) {
/*    */       
/* 50 */       task = (FutureTask<V>)v;
/*    */     } else {
/* 52 */       task = new FutureTask<>(() -> this.loader.apply((K)key));
/* 53 */       Object prevTask = this.map.putIfAbsent(cacheKey, task);
/* 54 */       if (prevTask == null) {
/*    */         
/* 56 */         creator = true;
/* 57 */         task.run();
/* 58 */       } else if (prevTask instanceof FutureTask) {
/* 59 */         task = (FutureTask<V>)prevTask;
/*    */       } else {
/* 61 */         return (V)prevTask;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/*    */     try {
/* 67 */       result = task.get();
/* 68 */     } catch (InterruptedException e) {
/* 69 */       throw new IllegalStateException("Interrupted while loading cache item", e);
/* 70 */     } catch (ExecutionException e) {
/* 71 */       Throwable cause = e.getCause();
/* 72 */       if (cause instanceof RuntimeException) { RuntimeException runtimeException = (RuntimeException)cause;
/* 73 */         throw runtimeException; }
/*    */       
/* 75 */       throw new IllegalStateException("Unable to load cache item", cause);
/*    */     } 
/* 77 */     if (creator) {
/* 78 */       this.map.put(cacheKey, result);
/*    */     }
/* 80 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\internal\LoadingCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */