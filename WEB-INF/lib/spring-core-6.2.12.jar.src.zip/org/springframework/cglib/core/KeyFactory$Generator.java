/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.List;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.internal.CustomizerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/* 184 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(KeyFactory.class.getName());
/*     */   
/* 186 */   private static final Class[] KNOWN_CUSTOMIZER_TYPES = new Class[] { Customizer.class, FieldTypeCustomizer.class };
/*     */ 
/*     */   
/*     */   private Class keyInterface;
/*     */   
/* 191 */   private CustomizerRegistry customizers = new CustomizerRegistry(KNOWN_CUSTOMIZER_TYPES);
/*     */   
/*     */   private int constant;
/*     */   
/*     */   private int multiplier;
/*     */   
/*     */   public Generator() {
/* 198 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/* 203 */     return this.keyInterface.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/* 208 */     return ReflectUtils.getProtectionDomain(this.keyInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setCustomizer(Customizer customizer) {
/* 216 */     this.customizers = CustomizerRegistry.singleton(customizer);
/*     */   }
/*     */   
/*     */   public void addCustomizer(KeyFactoryCustomizer customizer) {
/* 220 */     this.customizers.add(customizer);
/*     */   }
/*     */   
/*     */   public <T> List<T> getCustomizers(Class<T> klass) {
/* 224 */     return this.customizers.get(klass);
/*     */   }
/*     */   
/*     */   public void setInterface(Class keyInterface) {
/* 228 */     this.keyInterface = keyInterface;
/*     */   }
/*     */   
/*     */   public KeyFactory create() {
/* 232 */     setNamePrefix(this.keyInterface.getName());
/* 233 */     return (KeyFactory)create(this.keyInterface.getName());
/*     */   }
/*     */   
/*     */   public void setHashConstant(int constant) {
/* 237 */     this.constant = constant;
/*     */   }
/*     */   
/*     */   public void setHashMultiplier(int multiplier) {
/* 241 */     this.multiplier = multiplier;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 246 */     return ReflectUtils.newInstance(type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 251 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) {
/* 256 */     ClassEmitter ce = new ClassEmitter(v);
/*     */     
/* 258 */     Method newInstance = ReflectUtils.findNewInstance(this.keyInterface);
/* 259 */     if (!newInstance.getReturnType().equals(Object.class)) {
/* 260 */       throw new IllegalArgumentException("newInstance method must return Object");
/*     */     }
/*     */     
/* 263 */     Type[] parameterTypes = TypeUtils.getTypes(newInstance.getParameterTypes());
/* 264 */     ce.begin_class(52, 1, 
/*     */         
/* 266 */         getClassName(), KeyFactory.KEY_FACTORY, new Type[] {
/*     */           
/* 268 */           Type.getType(this.keyInterface) }, "<generated>");
/*     */     
/* 270 */     EmitUtils.null_constructor(ce);
/* 271 */     EmitUtils.factory_method(ce, ReflectUtils.getSignature(newInstance));
/*     */     
/* 273 */     int seed = 0;
/* 274 */     CodeEmitter e = ce.begin_method(1, 
/* 275 */         TypeUtils.parseConstructor(parameterTypes), null);
/*     */     
/* 277 */     e.load_this();
/* 278 */     e.super_invoke_constructor();
/* 279 */     e.load_this();
/* 280 */     List<FieldTypeCustomizer> fieldTypeCustomizers = getCustomizers(FieldTypeCustomizer.class);
/* 281 */     for (int i = 0; i < parameterTypes.length; i++) {
/* 282 */       Type parameterType = parameterTypes[i];
/* 283 */       Type fieldType = parameterType;
/* 284 */       for (FieldTypeCustomizer customizer : fieldTypeCustomizers) {
/* 285 */         fieldType = customizer.getOutType(i, fieldType);
/*     */       }
/* 287 */       seed += fieldType.hashCode();
/* 288 */       ce.declare_field(18, 
/* 289 */           getFieldName(i), fieldType, null);
/*     */ 
/*     */       
/* 292 */       e.dup();
/* 293 */       e.load_arg(i);
/* 294 */       for (FieldTypeCustomizer customizer : fieldTypeCustomizers) {
/* 295 */         customizer.customize(e, i, parameterType);
/*     */       }
/* 297 */       e.putfield(getFieldName(i));
/*     */     } 
/* 299 */     e.return_value();
/* 300 */     e.end_method();
/*     */ 
/*     */     
/* 303 */     e = ce.begin_method(1, KeyFactory.HASH_CODE, null);
/* 304 */     int hc = (this.constant != 0) ? this.constant : KeyFactory.PRIMES[Math.abs(seed) % KeyFactory.PRIMES.length];
/* 305 */     int hm = (this.multiplier != 0) ? this.multiplier : KeyFactory.PRIMES[Math.abs(seed * 13) % KeyFactory.PRIMES.length];
/* 306 */     e.push(hc);
/* 307 */     for (int j = 0; j < parameterTypes.length; j++) {
/* 308 */       e.load_this();
/* 309 */       e.getfield(getFieldName(j));
/* 310 */       EmitUtils.hash_code(e, parameterTypes[j], hm, this.customizers);
/*     */     } 
/* 312 */     e.return_value();
/* 313 */     e.end_method();
/*     */ 
/*     */     
/* 316 */     e = ce.begin_method(1, KeyFactory.EQUALS, null);
/* 317 */     Label fail = e.make_label();
/* 318 */     e.load_arg(0);
/* 319 */     e.instance_of_this();
/* 320 */     e.if_jump(153, fail); int k;
/* 321 */     for (k = 0; k < parameterTypes.length; k++) {
/* 322 */       e.load_this();
/* 323 */       e.getfield(getFieldName(k));
/* 324 */       e.load_arg(0);
/* 325 */       e.checkcast_this();
/* 326 */       e.getfield(getFieldName(k));
/* 327 */       EmitUtils.not_equals(e, parameterTypes[k], fail, this.customizers);
/*     */     } 
/* 329 */     e.push(1);
/* 330 */     e.return_value();
/* 331 */     e.mark(fail);
/* 332 */     e.push(0);
/* 333 */     e.return_value();
/* 334 */     e.end_method();
/*     */ 
/*     */     
/* 337 */     e = ce.begin_method(1, KeyFactory.TO_STRING, null);
/* 338 */     e.new_instance(Constants.TYPE_STRING_BUFFER);
/* 339 */     e.dup();
/* 340 */     e.invoke_constructor(Constants.TYPE_STRING_BUFFER);
/* 341 */     for (k = 0; k < parameterTypes.length; k++) {
/* 342 */       if (k > 0) {
/* 343 */         e.push(", ");
/* 344 */         e.invoke_virtual(Constants.TYPE_STRING_BUFFER, KeyFactory.APPEND_STRING);
/*     */       } 
/* 346 */       e.load_this();
/* 347 */       e.getfield(getFieldName(k));
/* 348 */       EmitUtils.append_string(e, parameterTypes[k], EmitUtils.DEFAULT_DELIMITERS, this.customizers);
/*     */     } 
/* 350 */     e.invoke_virtual(Constants.TYPE_STRING_BUFFER, KeyFactory.TO_STRING);
/* 351 */     e.return_value();
/* 352 */     e.end_method();
/*     */     
/* 354 */     ce.end_class();
/*     */   }
/*     */   
/*     */   private String getFieldName(int arg) {
/* 358 */     return "FIELD_" + arg;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\KeyFactory$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */