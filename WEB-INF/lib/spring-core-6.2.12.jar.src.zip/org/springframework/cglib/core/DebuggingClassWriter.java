/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.ClassWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DebuggingClassWriter
/*     */   extends ClassVisitor
/*     */ {
/*     */   public static final String DEBUG_LOCATION_PROPERTY = "cglib.debugLocation";
/*  43 */   private static String debugLocation = System.getProperty("cglib.debugLocation"); private static Constructor traceCtor; static {
/*  44 */     if (debugLocation != null) {
/*  45 */       System.err.println("CGLIB debugging enabled, writing to '" + debugLocation + "'");
/*     */       try {
/*  47 */         Class<?> clazz = Class.forName("org.springframework.asm.util.TraceClassVisitor");
/*  48 */         traceCtor = clazz.getConstructor(new Class[] { ClassVisitor.class, PrintWriter.class });
/*  49 */       } catch (Throwable throwable) {}
/*     */     } 
/*     */   }
/*     */   private String className; private String superName;
/*     */   
/*     */   public DebuggingClassWriter(int flags) {
/*  55 */     super(Constants.ASM_API, (ClassVisitor)new ClassWriter(flags));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/*  65 */     this.className = name.replace('/', '.');
/*  66 */     this.superName = superName.replace('/', '.');
/*  67 */     super.visit(version, access, name, signature, superName, interfaces);
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*  71 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getSuperName() {
/*  75 */     return this.superName;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/*  80 */     byte[] b = ((ClassWriter)access$001(this)).toByteArray();
/*  81 */     if (debugLocation != null) {
/*  82 */       String dirs = this.className.replace('.', File.separatorChar);
/*     */       try {
/*  84 */         (new File(debugLocation + debugLocation + File.separatorChar)).getParentFile().mkdirs();
/*     */         
/*  86 */         File file = new File(new File(debugLocation), dirs + ".class");
/*  87 */         OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
/*     */         try {
/*  89 */           out.write(b);
/*     */         } finally {
/*  91 */           out.close();
/*     */         } 
/*     */         
/*  94 */         if (traceCtor != null) {
/*  95 */           file = new File(new File(debugLocation), dirs + ".asm");
/*  96 */           out = new BufferedOutputStream(new FileOutputStream(file));
/*     */           try {
/*  98 */             ClassReader cr = new ClassReader(b);
/*  99 */             PrintWriter pw = new PrintWriter(new OutputStreamWriter(out));
/* 100 */             ClassVisitor tcv = traceCtor.newInstance(new Object[] { null, pw });
/* 101 */             cr.accept(tcv, 0);
/* 102 */             pw.flush();
/*     */           } finally {
/* 104 */             out.close();
/*     */           } 
/*     */         } 
/* 107 */       } catch (Exception e) {
/* 108 */         throw new CodeGenerationException(e);
/*     */       } 
/*     */     } 
/* 111 */     return b;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\DebuggingClassWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */