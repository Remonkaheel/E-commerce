/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.ClassReader;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassNameReader
/*    */ {
/* 31 */   private static final EarlyExitException EARLY_EXIT = new EarlyExitException();
/*    */ 
/*    */   
/*    */   private static class EarlyExitException
/*    */     extends RuntimeException {}
/*    */   
/*    */   public static String getClassName(ClassReader r) {
/* 38 */     return getClassInfo(r)[0];
/*    */   }
/*    */   
/*    */   public static String[] getClassInfo(ClassReader r) {
/* 42 */     final List<String> array = new ArrayList<>();
/*    */     try {
/* 44 */       r.accept(new ClassVisitor(Constants.ASM_API, null)
/*    */           {
/*    */ 
/*    */ 
/*    */ 
/*    */             
/*    */             public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*    */             {
/* 52 */               array.add(name.replace('/', '.'));
/* 53 */               if (superName != null) {
/* 54 */                 array.add(superName.replace('/', '.'));
/*    */               }
/* 56 */               for (String element : interfaces) {
/* 57 */                 array.add(element.replace('/', '.'));
/*    */               }
/*    */               
/* 60 */               throw ClassNameReader.EARLY_EXIT;
/*    */             }
/*    */           }6);
/* 63 */     } catch (EarlyExitException earlyExitException) {}
/*    */     
/* 65 */     return array.<String>toArray(new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassNameReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */