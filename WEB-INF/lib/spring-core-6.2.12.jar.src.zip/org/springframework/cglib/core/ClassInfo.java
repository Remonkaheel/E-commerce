/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import org.springframework.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClassInfo
/*    */ {
/*    */   public abstract Type getType();
/*    */   
/*    */   public abstract Type getSuperType();
/*    */   
/*    */   public abstract Type[] getInterfaces();
/*    */   
/*    */   public abstract int getModifiers();
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     ClassInfo classInfo;
/* 33 */     if (o == null) {
/* 34 */       return false;
/*    */     }
/* 36 */     if (o instanceof ClassInfo) { classInfo = (ClassInfo)o; }
/* 37 */     else { return false; }
/*    */     
/* 39 */     return getType().equals(classInfo.getType());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 44 */     return getType().hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return getType().getClassName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */