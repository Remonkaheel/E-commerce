/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInfoTransformer
/*    */   implements Transformer
/*    */ {
/* 24 */   private static final MethodInfoTransformer INSTANCE = new MethodInfoTransformer();
/*    */   
/*    */   public static MethodInfoTransformer getInstance() {
/* 27 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object transform(Object value) {
/* 32 */     if (value instanceof Method) { Method method = (Method)value;
/* 33 */       return ReflectUtils.getMethodInfo(method); }
/* 34 */      if (value instanceof Constructor) { Constructor<?> constructor = (Constructor)value;
/* 35 */       return ReflectUtils.getMethodInfo(constructor); }
/*    */     
/* 37 */     throw new IllegalArgumentException("cannot get method info for " + String.valueOf(value));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\MethodInfoTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */