/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import org.springframework.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MethodInfo
/*    */ {
/*    */   public abstract ClassInfo getClassInfo();
/*    */   
/*    */   public abstract int getModifiers();
/*    */   
/*    */   public abstract Signature getSignature();
/*    */   
/*    */   public abstract Type[] getExceptionTypes();
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     MethodInfo other;
/* 33 */     if (o == null) {
/* 34 */       return false;
/*    */     }
/* 36 */     if (o instanceof MethodInfo) { other = (MethodInfo)o; }
/* 37 */     else { return false; }
/*    */     
/* 39 */     return getSignature().equals(other.getSignature());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 44 */     return getSignature().hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return getSignature().toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\MethodInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */