/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassLoaderAwareGeneratorStrategy
/*    */   extends DefaultGeneratorStrategy
/*    */ {
/*    */   private final ClassLoader classLoader;
/*    */   private final GeneratorStrategy delegate;
/*    */   
/*    */   public ClassLoaderAwareGeneratorStrategy(ClassLoader classLoader) {
/* 40 */     this.classLoader = classLoader;
/* 41 */     this.delegate = (x$0 -> super.generate(x$0));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClassLoaderAwareGeneratorStrategy(ClassLoader classLoader, GeneratorStrategy delegate) {
/* 50 */     this.classLoader = classLoader;
/* 51 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] generate(ClassGenerator cg) throws Exception {
/*    */     ClassLoader threadContextClassLoader;
/* 57 */     if (this.classLoader == null) {
/* 58 */       return this.delegate.generate(cg);
/*    */     }
/*    */     
/* 61 */     Thread currentThread = Thread.currentThread();
/*    */     
/*    */     try {
/* 64 */       threadContextClassLoader = currentThread.getContextClassLoader();
/*    */     }
/* 66 */     catch (Throwable ex) {
/*    */       
/* 68 */       return this.delegate.generate(cg);
/*    */     } 
/*    */     
/* 71 */     boolean overrideClassLoader = !this.classLoader.equals(threadContextClassLoader);
/* 72 */     if (overrideClassLoader) {
/* 73 */       currentThread.setContextClassLoader(this.classLoader);
/*    */     }
/*    */     try {
/* 76 */       return this.delegate.generate(cg);
/*    */     } finally {
/*    */       
/* 79 */       if (overrideClassLoader)
/*    */       {
/* 81 */         currentThread.setContextClassLoader(threadContextClassLoader);
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassLoaderAwareGeneratorStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */