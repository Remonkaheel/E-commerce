/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import org.springframework.asm.ClassWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultGeneratorStrategy
/*    */   implements GeneratorStrategy
/*    */ {
/* 21 */   public static final DefaultGeneratorStrategy INSTANCE = new DefaultGeneratorStrategy();
/*    */ 
/*    */   
/*    */   public byte[] generate(ClassGenerator cg) throws Exception {
/* 25 */     DebuggingClassWriter cw = getClassVisitor();
/* 26 */     transform(cg).generateClass(cw);
/* 27 */     return transform(cw.toByteArray());
/*    */   }
/*    */   
/*    */   protected DebuggingClassWriter getClassVisitor() throws Exception {
/* 31 */     return new DebuggingClassWriter(2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final ClassWriter getClassWriter() {
/* 37 */     throw new UnsupportedOperationException("You are calling getClassWriter, which no longer exists in this cglib version.");
/*    */   }
/*    */ 
/*    */   
/*    */   protected byte[] transform(byte[] b) throws Exception {
/* 42 */     return b;
/*    */   }
/*    */   
/*    */   protected ClassGenerator transform(ClassGenerator cg) throws Exception {
/* 46 */     return cg;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\DefaultGeneratorStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */