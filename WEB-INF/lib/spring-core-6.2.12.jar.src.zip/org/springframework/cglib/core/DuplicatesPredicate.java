/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DuplicatesPredicate
/*     */   implements Predicate
/*     */ {
/*     */   private final Set unique;
/*     */   private final Set rejected;
/*     */   
/*     */   public DuplicatesPredicate() {
/*  44 */     this.unique = new HashSet();
/*  45 */     this.rejected = Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DuplicatesPredicate(List allMethods) {
/*  53 */     this.rejected = new HashSet();
/*  54 */     this.unique = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     Map<Object, Object> scanned = new HashMap<>();
/*  61 */     Map<Object, Object> suspects = new HashMap<>();
/*  62 */     for (Object o : allMethods) {
/*  63 */       Method method = (Method)o;
/*  64 */       Object sig = MethodWrapper.create(method);
/*  65 */       Method existing = (Method)scanned.get(sig);
/*  66 */       if (existing == null) {
/*  67 */         scanned.put(sig, method); continue;
/*  68 */       }  if (!suspects.containsKey(sig) && existing.isBridge() && !method.isBridge())
/*     */       {
/*     */ 
/*     */         
/*  72 */         suspects.put(sig, existing);
/*     */       }
/*     */     } 
/*     */     
/*  76 */     if (!suspects.isEmpty()) {
/*  77 */       Set<Class<?>> classes = new HashSet();
/*  78 */       UnnecessaryBridgeFinder finder = new UnnecessaryBridgeFinder(this.rejected);
/*  79 */       for (Object o : suspects.values()) {
/*  80 */         Method m = (Method)o;
/*  81 */         classes.add(m.getDeclaringClass());
/*  82 */         finder.addSuspectMethod(m);
/*     */       } 
/*  84 */       for (Object<?> o : classes) {
/*  85 */         Class c = (Class)o;
/*     */         try {
/*  87 */           ClassLoader cl = getClassLoader(c);
/*  88 */           if (cl == null) {
/*     */             continue;
/*     */           }
/*  91 */           InputStream is = cl.getResourceAsStream(c.getName().replace('.', '/') + ".class");
/*  92 */           if (is == null) {
/*     */             continue;
/*     */           }
/*     */           try {
/*  96 */             (new ClassReader(is)).accept(finder, 6);
/*     */           } finally {
/*  98 */             is.close();
/*     */           } 
/* 100 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean evaluate(Object arg) {
/* 108 */     return (!this.rejected.contains(arg) && this.unique.add(MethodWrapper.create((Method)arg)));
/*     */   }
/*     */   
/*     */   private static ClassLoader getClassLoader(Class c) {
/* 112 */     ClassLoader cl = c.getClassLoader();
/* 113 */     if (cl == null) {
/* 114 */       cl = DuplicatesPredicate.class.getClassLoader();
/*     */     }
/* 116 */     if (cl == null) {
/* 117 */       cl = Thread.currentThread().getContextClassLoader();
/*     */     }
/* 119 */     return cl;
/*     */   }
/*     */   
/*     */   private static class UnnecessaryBridgeFinder
/*     */     extends ClassVisitor {
/*     */     private final Set rejected;
/* 125 */     private Signature currentMethodSig = null;
/* 126 */     private Map methods = new HashMap<>();
/*     */     
/*     */     UnnecessaryBridgeFinder(Set rejected) {
/* 129 */       super(Constants.ASM_API);
/* 130 */       this.rejected = rejected;
/*     */     }
/*     */     
/*     */     void addSuspectMethod(Method m) {
/* 134 */       this.methods.put(ReflectUtils.getSignature(m), m);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 149 */       Signature sig = new Signature(name, desc);
/* 150 */       final Method currentMethod = (Method)this.methods.remove(sig);
/* 151 */       if (currentMethod != null) {
/* 152 */         this.currentMethodSig = sig;
/* 153 */         return new MethodVisitor(Constants.ASM_API)
/*     */           {
/*     */             public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf)
/*     */             {
/* 157 */               if (opcode == 183 && DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig != null) {
/* 158 */                 Signature target = new Signature(name, desc);
/* 159 */                 if (target.equals(DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig)) {
/* 160 */                   DuplicatesPredicate.UnnecessaryBridgeFinder.this.rejected.add(currentMethod);
/*     */                 }
/* 162 */                 DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig = null;
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/* 167 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   class null extends MethodVisitor {
/*     */     null(int api) {
/*     */       super(api);
/*     */     }
/*     */     
/*     */     public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/*     */       if (opcode == 183 && DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig != null) {
/*     */         Signature target = new Signature(name, desc);
/*     */         if (target.equals(DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig))
/*     */           DuplicatesPredicate.UnnecessaryBridgeFinder.this.rejected.add(currentMethod); 
/*     */         DuplicatesPredicate.UnnecessaryBridgeFinder.this.currentMethodSig = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\DuplicatesPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */