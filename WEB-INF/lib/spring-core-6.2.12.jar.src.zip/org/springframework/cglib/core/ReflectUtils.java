/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InaccessibleObjectException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectUtils
/*     */ {
/*  52 */   private static final Map primitives = new HashMap<>(8);
/*     */   
/*  54 */   private static final Map transforms = new HashMap<>(8);
/*     */   
/*  56 */   private static final ClassLoader defaultLoader = ReflectUtils.class.getClassLoader();
/*     */   
/*     */   private static final Method classLoaderDefineClassMethod;
/*     */   
/*     */   private static final Throwable THROWABLE;
/*     */   
/*     */   private static final ProtectionDomain PROTECTION_DOMAIN;
/*     */   
/*  64 */   private static final List<Method> OBJECT_METHODS = new ArrayList<>();
/*     */   
/*     */   private static BiConsumer<String, byte[]> generatedClassHandler;
/*     */   private static Consumer<Class<?>> loadedClassHandler;
/*     */   private static final String[] CGLIB_PACKAGES;
/*     */   
/*     */   static {
/*     */     Method classLoaderDefineClass;
/*     */   }
/*     */   
/*     */   static {
/*  75 */     Throwable throwable = null;
/*     */     try {
/*  77 */       classLoaderDefineClass = ClassLoader.class.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ProtectionDomain.class });
/*     */     
/*     */     }
/*  80 */     catch (Throwable t) {
/*  81 */       classLoaderDefineClass = null;
/*  82 */       throwable = t;
/*     */     } 
/*     */     
/*  85 */     classLoaderDefineClassMethod = classLoaderDefineClass;
/*  86 */     THROWABLE = throwable;
/*  87 */     PROTECTION_DOMAIN = getProtectionDomain(ReflectUtils.class);
/*     */     
/*  89 */     for (Method method : Object.class.getDeclaredMethods()) {
/*  90 */       if (!"finalize".equals(method.getName()) && (method
/*  91 */         .getModifiers() & 0x18) <= 0)
/*     */       {
/*     */         
/*  94 */         OBJECT_METHODS.add(method);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  99 */     CGLIB_PACKAGES = new String[] { "java.lang" };
/*     */ 
/*     */     
/* 102 */     primitives.put("byte", byte.class);
/* 103 */     primitives.put("char", char.class);
/* 104 */     primitives.put("double", double.class);
/* 105 */     primitives.put("float", float.class);
/* 106 */     primitives.put("int", int.class);
/* 107 */     primitives.put("long", long.class);
/* 108 */     primitives.put("short", short.class);
/* 109 */     primitives.put("boolean", boolean.class);
/*     */     
/* 111 */     transforms.put("byte", "B");
/* 112 */     transforms.put("char", "C");
/* 113 */     transforms.put("double", "D");
/* 114 */     transforms.put("float", "F");
/* 115 */     transforms.put("int", "I");
/* 116 */     transforms.put("long", "J");
/* 117 */     transforms.put("short", "S");
/* 118 */     transforms.put("boolean", "Z");
/*     */   }
/*     */   
/*     */   public static ProtectionDomain getProtectionDomain(Class source) {
/* 122 */     if (source == null) {
/* 123 */       return null;
/*     */     }
/* 125 */     return source.getProtectionDomain();
/*     */   }
/*     */   
/*     */   public static Type[] getExceptionTypes(Member member) {
/* 129 */     if (member instanceof Method) { Method method = (Method)member;
/* 130 */       return TypeUtils.getTypes(method.getExceptionTypes()); }
/*     */     
/* 132 */     if (member instanceof Constructor) { Constructor<?> constructor = (Constructor)member;
/* 133 */       return TypeUtils.getTypes(constructor.getExceptionTypes()); }
/*     */ 
/*     */     
/* 136 */     throw new IllegalArgumentException("Cannot get exception types of a field");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Signature getSignature(Member member) {
/* 141 */     if (member instanceof Method) { Method method = (Method)member;
/* 142 */       return new Signature(member.getName(), Type.getMethodDescriptor(method)); }
/*     */     
/* 144 */     if (member instanceof Constructor) { Constructor<?> constructor = (Constructor)member;
/* 145 */       Type[] types = TypeUtils.getTypes(constructor.getParameterTypes());
/* 146 */       return new Signature("<init>", 
/* 147 */           Type.getMethodDescriptor(Type.VOID_TYPE, types)); }
/*     */ 
/*     */     
/* 150 */     throw new IllegalArgumentException("Cannot get signature of a field");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Constructor findConstructor(String desc) {
/* 155 */     return findConstructor(desc, defaultLoader);
/*     */   }
/*     */   
/*     */   public static Constructor findConstructor(String desc, ClassLoader loader) {
/*     */     try {
/* 160 */       int lparen = desc.indexOf('(');
/* 161 */       String className = desc.substring(0, lparen).trim();
/* 162 */       return getClass(className, loader).getConstructor(parseTypes(desc, loader));
/*     */     }
/* 164 */     catch (ClassNotFoundException|NoSuchMethodException ex) {
/* 165 */       throw new CodeGenerationException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Method findMethod(String desc) {
/* 170 */     return findMethod(desc, defaultLoader);
/*     */   }
/*     */   
/*     */   public static Method findMethod(String desc, ClassLoader loader) {
/*     */     try {
/* 175 */       int lparen = desc.indexOf('(');
/* 176 */       int dot = desc.lastIndexOf('.', lparen);
/* 177 */       String className = desc.substring(0, dot).trim();
/* 178 */       String methodName = desc.substring(dot + 1, lparen).trim();
/* 179 */       return getClass(className, loader).getDeclaredMethod(methodName, parseTypes(desc, loader));
/*     */     }
/* 181 */     catch (ClassNotFoundException|NoSuchMethodException ex) {
/* 182 */       throw new CodeGenerationException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class[] parseTypes(String desc, ClassLoader loader) throws ClassNotFoundException {
/* 187 */     int lparen = desc.indexOf('(');
/* 188 */     int rparen = desc.indexOf(')', lparen);
/* 189 */     List<String> params = new ArrayList();
/* 190 */     int start = lparen + 1;
/*     */     while (true) {
/* 192 */       int comma = desc.indexOf(',', start);
/* 193 */       if (comma < 0) {
/*     */         break;
/*     */       }
/* 196 */       params.add(desc.substring(start, comma).trim());
/* 197 */       start = comma + 1;
/*     */     } 
/* 199 */     if (start < rparen) {
/* 200 */       params.add(desc.substring(start, rparen).trim());
/*     */     }
/* 202 */     Class[] types = new Class[params.size()];
/* 203 */     for (int i = 0; i < types.length; i++) {
/* 204 */       types[i] = getClass(params.get(i), loader);
/*     */     }
/* 206 */     return types;
/*     */   }
/*     */   
/*     */   private static Class getClass(String className, ClassLoader loader) throws ClassNotFoundException {
/* 210 */     return getClass(className, loader, CGLIB_PACKAGES);
/*     */   }
/*     */   
/*     */   private static Class getClass(String className, ClassLoader loader, String[] packages) throws ClassNotFoundException {
/* 214 */     String save = className;
/* 215 */     int dimensions = 0;
/* 216 */     int index = 0;
/* 217 */     while ((index = className.indexOf("[]", index) + 1) > 0) {
/* 218 */       dimensions++;
/*     */     }
/* 220 */     StringBuilder brackets = new StringBuilder(className.length() - dimensions);
/* 221 */     for (int i = 0; i < dimensions; i++) {
/* 222 */       brackets.append('[');
/*     */     }
/* 224 */     className = className.substring(0, className.length() - 2 * dimensions);
/*     */     
/* 226 */     String prefix = (dimensions > 0) ? (String.valueOf(brackets) + "L") : "";
/* 227 */     String suffix = (dimensions > 0) ? ";" : "";
/*     */     try {
/* 229 */       return Class.forName(prefix + prefix + className, false, loader);
/*     */     }
/* 231 */     catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 233 */       for (String pkg : packages) {
/*     */         try {
/* 235 */           return Class.forName(prefix + prefix + "." + pkg + className, false, loader);
/*     */         }
/* 237 */         catch (ClassNotFoundException classNotFoundException1) {}
/*     */       } 
/*     */       
/* 240 */       if (dimensions == 0) {
/* 241 */         Class c = (Class)primitives.get(className);
/* 242 */         if (c != null) {
/* 243 */           return c;
/*     */         }
/*     */       } else {
/*     */         
/* 247 */         String transform = (String)transforms.get(className);
/* 248 */         if (transform != null) {
/*     */           try {
/* 250 */             return Class.forName(String.valueOf(brackets) + String.valueOf(brackets), false, loader);
/*     */           }
/* 252 */           catch (ClassNotFoundException classNotFoundException1) {}
/*     */         }
/*     */       } 
/*     */       
/* 256 */       throw new ClassNotFoundException(save);
/*     */     } 
/*     */   }
/*     */   public static Object newInstance(Class type) {
/* 260 */     return newInstance(type, Constants.EMPTY_CLASS_ARRAY, null);
/*     */   }
/*     */   
/*     */   public static Object newInstance(Class type, Class[] parameterTypes, Object[] args) {
/* 264 */     return newInstance(getConstructor(type, parameterTypes), args);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object newInstance(Constructor cstruct, Object[] args) {
/* 269 */     boolean flag = cstruct.isAccessible();
/*     */     try {
/* 271 */       if (!flag) {
/* 272 */         cstruct.setAccessible(true);
/*     */       }
/* 274 */       Object result = cstruct.newInstance(args);
/* 275 */       return result;
/*     */     }
/* 277 */     catch (InstantiationException|IllegalAccessException e) {
/* 278 */       throw new CodeGenerationException(e);
/*     */     }
/* 280 */     catch (InvocationTargetException e) {
/* 281 */       throw new CodeGenerationException(e.getTargetException());
/*     */     } finally {
/*     */       
/* 284 */       if (!flag) {
/* 285 */         cstruct.setAccessible(flag);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Constructor getConstructor(Class type, Class[] parameterTypes) {
/*     */     try {
/* 292 */       Constructor constructor = type.getDeclaredConstructor(parameterTypes);
/* 293 */       constructor.setAccessible(true);
/* 294 */       return constructor;
/*     */     }
/* 296 */     catch (NoSuchMethodException e) {
/* 297 */       throw new CodeGenerationException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String[] getNames(Class[] classes) {
/* 302 */     if (classes == null) {
/* 303 */       return null;
/*     */     }
/* 305 */     String[] names = new String[classes.length];
/* 306 */     for (int i = 0; i < names.length; i++) {
/* 307 */       names[i] = classes[i].getName();
/*     */     }
/* 309 */     return names;
/*     */   }
/*     */   
/*     */   public static Class[] getClasses(Object[] objects) {
/* 313 */     Class[] classes = new Class[objects.length];
/* 314 */     for (int i = 0; i < objects.length; i++) {
/* 315 */       classes[i] = objects[i].getClass();
/*     */     }
/* 317 */     return classes;
/*     */   }
/*     */   
/*     */   public static Method findNewInstance(Class iface) {
/* 321 */     Method m = findInterfaceMethod(iface);
/* 322 */     if (!m.getName().equals("newInstance")) {
/* 323 */       throw new IllegalArgumentException(String.valueOf(iface) + " missing newInstance method");
/*     */     }
/* 325 */     return m;
/*     */   }
/*     */   
/*     */   public static Method[] getPropertyMethods(PropertyDescriptor[] properties, boolean read, boolean write) {
/* 329 */     Set<Method> methods = new HashSet();
/* 330 */     for (PropertyDescriptor pd : properties) {
/* 331 */       if (read) {
/* 332 */         methods.add(pd.getReadMethod());
/*     */       }
/* 334 */       if (write) {
/* 335 */         methods.add(pd.getWriteMethod());
/*     */       }
/*     */     } 
/* 338 */     methods.remove(null);
/* 339 */     return methods.<Method>toArray(new Method[methods.size()]);
/*     */   }
/*     */   
/*     */   public static PropertyDescriptor[] getBeanProperties(Class type) {
/* 343 */     return getPropertiesHelper(type, true, true);
/*     */   }
/*     */   
/*     */   public static PropertyDescriptor[] getBeanGetters(Class type) {
/* 347 */     return getPropertiesHelper(type, true, false);
/*     */   }
/*     */   
/*     */   public static PropertyDescriptor[] getBeanSetters(Class type) {
/* 351 */     return getPropertiesHelper(type, false, true);
/*     */   }
/*     */   
/*     */   private static PropertyDescriptor[] getPropertiesHelper(Class<?> type, boolean read, boolean write) {
/*     */     try {
/* 356 */       BeanInfo info = Introspector.getBeanInfo(type, Object.class);
/* 357 */       PropertyDescriptor[] all = info.getPropertyDescriptors();
/* 358 */       if (read && write) {
/* 359 */         return all;
/*     */       }
/* 361 */       List<PropertyDescriptor> properties = new ArrayList(all.length);
/* 362 */       for (PropertyDescriptor pd : all) {
/* 363 */         if ((read && pd.getReadMethod() != null) || (write && pd
/* 364 */           .getWriteMethod() != null)) {
/* 365 */           properties.add(pd);
/*     */         }
/*     */       } 
/* 368 */       return properties.<PropertyDescriptor>toArray(new PropertyDescriptor[properties.size()]);
/*     */     }
/* 370 */     catch (IntrospectionException e) {
/* 371 */       throw new CodeGenerationException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method findDeclaredMethod(Class type, String methodName, Class[] parameterTypes) throws NoSuchMethodException {
/* 379 */     Class cl = type;
/* 380 */     while (cl != null) {
/*     */       try {
/* 382 */         return cl.getDeclaredMethod(methodName, parameterTypes);
/*     */       }
/* 384 */       catch (NoSuchMethodException e) {
/* 385 */         cl = cl.getSuperclass();
/*     */       } 
/*     */     } 
/* 388 */     throw new NoSuchMethodException(methodName);
/*     */   }
/*     */   
/*     */   public static List addAllMethods(Class<Object> type, List<Method> list) {
/* 392 */     if (type == Object.class) {
/* 393 */       list.addAll(OBJECT_METHODS);
/*     */     } else {
/*     */       
/* 396 */       list.addAll(Arrays.asList(type.getDeclaredMethods()));
/*     */     } 
/*     */     
/* 399 */     Class<? super Object> superclass = type.getSuperclass();
/* 400 */     if (superclass != null) {
/* 401 */       addAllMethods(superclass, list);
/*     */     }
/* 403 */     Class[] interfaces = type.getInterfaces();
/* 404 */     for (Class element : interfaces) {
/* 405 */       addAllMethods(element, list);
/*     */     }
/*     */     
/* 408 */     return list;
/*     */   }
/*     */   
/*     */   public static List addAllInterfaces(Class type, List list) {
/* 412 */     Class superclass = type.getSuperclass();
/* 413 */     if (superclass != null) {
/* 414 */       list.addAll(Arrays.asList(type.getInterfaces()));
/* 415 */       addAllInterfaces(superclass, list);
/*     */     } 
/* 417 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method findInterfaceMethod(Class iface) {
/* 422 */     if (!iface.isInterface()) {
/* 423 */       throw new IllegalArgumentException(String.valueOf(iface) + " is not an interface");
/*     */     }
/* 425 */     Method[] methods = iface.getDeclaredMethods();
/* 426 */     if (methods.length != 1) {
/* 427 */       throw new IllegalArgumentException("expecting exactly 1 method in " + String.valueOf(iface));
/*     */     }
/* 429 */     return methods[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setGeneratedClassHandler(BiConsumer<String, byte[]> handler) {
/* 434 */     generatedClassHandler = handler;
/*     */   }
/*     */   
/*     */   public static Class defineClass(String className, byte[] b, ClassLoader loader) throws Exception {
/* 438 */     return defineClass(className, b, loader, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class defineClass(String className, byte[] b, ClassLoader loader, ProtectionDomain protectionDomain) throws Exception {
/* 444 */     return defineClass(className, b, loader, protectionDomain, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class defineClass(String className, byte[] b, final ClassLoader loader, ProtectionDomain protectionDomain, final Class<?> contextClass) throws Exception {
/* 451 */     Class<?> c = null;
/* 452 */     Throwable t = THROWABLE;
/*     */     
/* 454 */     BiConsumer<String, byte[]> handlerToUse = generatedClassHandler;
/* 455 */     if (handlerToUse != null) {
/* 456 */       handlerToUse.accept(className, b);
/*     */     }
/*     */ 
/*     */     
/* 460 */     if (contextClass != null && contextClass.getClassLoader() == loader) {
/*     */       try {
/* 462 */         MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(contextClass, MethodHandles.lookup());
/* 463 */         c = lookup.defineClass(b);
/*     */       }
/* 465 */       catch (LinkageError|IllegalArgumentException ex) {
/* 466 */         if (ex instanceof LinkageError) {
/*     */           
/*     */           try {
/*     */             
/* 470 */             c = contextClass.getClassLoader().loadClass(className);
/*     */           }
/* 472 */           catch (ClassNotFoundException classNotFoundException) {}
/*     */         }
/*     */         
/* 475 */         if (c == null)
/*     */         {
/*     */ 
/*     */           
/* 479 */           t = ex;
/*     */         }
/*     */       }
/* 482 */       catch (Throwable ex) {
/* 483 */         throw new CodeGenerationException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 488 */     if (c == null) {
/* 489 */       if (protectionDomain == null) {
/* 490 */         protectionDomain = PROTECTION_DOMAIN;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 495 */         Method publicDefineClass = loader.getClass().getMethod("publicDefineClass", new Class[] { String.class, byte[].class, ProtectionDomain.class });
/*     */         
/* 497 */         c = (Class)publicDefineClass.invoke(loader, new Object[] { className, b, protectionDomain });
/*     */       }
/* 499 */       catch (InvocationTargetException ex) {
/* 500 */         if (!(ex.getTargetException() instanceof UnsupportedOperationException)) {
/* 501 */           throw new CodeGenerationException(ex.getTargetException());
/*     */         }
/*     */         
/* 504 */         t = ex.getTargetException();
/*     */       }
/* 506 */       catch (Throwable ex) {
/*     */         
/* 508 */         t = ex;
/*     */       } 
/*     */ 
/*     */       
/* 512 */       if (c == null && classLoaderDefineClassMethod != null) {
/* 513 */         Object[] args = { className, b, Integer.valueOf(0), Integer.valueOf(b.length), protectionDomain };
/*     */         try {
/* 515 */           if (!classLoaderDefineClassMethod.isAccessible()) {
/* 516 */             classLoaderDefineClassMethod.setAccessible(true);
/*     */           }
/* 518 */           c = (Class)classLoaderDefineClassMethod.invoke(loader, args);
/*     */         }
/* 520 */         catch (InvocationTargetException ex) {
/* 521 */           throw new CodeGenerationException(ex.getTargetException());
/*     */         }
/* 523 */         catch (InaccessibleObjectException ex) {
/*     */ 
/*     */           
/* 526 */           t = ex;
/*     */         }
/* 528 */         catch (Throwable ex) {
/* 529 */           throw new CodeGenerationException(ex);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 535 */     if (c == null && contextClass != null && contextClass.getClassLoader() != loader) {
/*     */       try {
/* 537 */         MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(contextClass, MethodHandles.lookup());
/* 538 */         c = lookup.defineClass(b);
/*     */       }
/* 540 */       catch (LinkageError|IllegalAccessException ex) {
/* 541 */         if (ex instanceof LinkageError) {
/*     */           
/*     */           try {
/*     */             
/* 545 */             c = contextClass.getClassLoader().loadClass(className);
/*     */           }
/* 547 */           catch (ClassNotFoundException classNotFoundException) {}
/*     */         }
/*     */         
/* 550 */         if (c == null) {
/* 551 */           throw new CodeGenerationException(ex)
/*     */             {
/*     */               public String getMessage() {
/* 554 */                 return "ClassLoader mismatch for [" + contextClass.getName() + "]: JVM should be started with --add-opens=java.base/java.lang=ALL-UNNAMED for ClassLoader.defineClass to be accessible on " + loader
/*     */                   
/* 556 */                   .getClass().getName() + "; consider co-locating the affected class in that target ClassLoader instead.";
/*     */               }
/*     */             };
/*     */         
/*     */         }
/*     */       }
/* 562 */       catch (Throwable ex) {
/* 563 */         throw new CodeGenerationException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 568 */     if (c == null) {
/* 569 */       throw new CodeGenerationException(t)
/*     */         {
/*     */           public String getMessage() {
/* 572 */             return "No compatible defineClass mechanism detected: JVM should be started with --add-opens=java.base/java.lang=ALL-UNNAMED for ClassLoader.defineClass to be accessible. On the module path, you may not be able to define this CGLIB-generated class at all.";
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 581 */     Class.forName(className, true, loader);
/* 582 */     return c;
/*     */   }
/*     */   
/*     */   public static void setLoadedClassHandler(Consumer<Class<?>> loadedClassHandler) {
/* 586 */     ReflectUtils.loadedClassHandler = loadedClassHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String className, ClassLoader classLoader) throws ClassNotFoundException {
/* 591 */     Class<?> clazz = Class.forName(className, true, classLoader);
/* 592 */     Consumer<Class<?>> handlerToUse = loadedClassHandler;
/* 593 */     if (handlerToUse != null) {
/* 594 */       handlerToUse.accept(clazz);
/*     */     }
/* 596 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int findPackageProtected(Class[] classes) {
/* 602 */     for (int i = 0; i < classes.length; i++) {
/* 603 */       if (!Modifier.isPublic(classes[i].getModifiers())) {
/* 604 */         return i;
/*     */       }
/*     */     } 
/* 607 */     return 0;
/*     */   }
/*     */   
/*     */   public static MethodInfo getMethodInfo(final Member member, final int modifiers) {
/* 611 */     final Signature sig = getSignature(member);
/* 612 */     return new MethodInfo()
/*     */       {
/*     */         private ClassInfo ci;
/*     */         
/*     */         public ClassInfo getClassInfo() {
/* 617 */           if (this.ci == null) {
/* 618 */             this.ci = ReflectUtils.getClassInfo(member.getDeclaringClass());
/*     */           }
/* 620 */           return this.ci;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getModifiers() {
/* 625 */           return modifiers;
/*     */         }
/*     */ 
/*     */         
/*     */         public Signature getSignature() {
/* 630 */           return sig;
/*     */         }
/*     */ 
/*     */         
/*     */         public Type[] getExceptionTypes() {
/* 635 */           return ReflectUtils.getExceptionTypes(member);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static MethodInfo getMethodInfo(Member member) {
/* 641 */     return getMethodInfo(member, member.getModifiers());
/*     */   }
/*     */   
/*     */   public static ClassInfo getClassInfo(final Class clazz) {
/* 645 */     final Type type = Type.getType(clazz);
/* 646 */     final Type sc = (clazz.getSuperclass() == null) ? null : Type.getType(clazz.getSuperclass());
/* 647 */     return new ClassInfo()
/*     */       {
/*     */         public Type getType() {
/* 650 */           return type;
/*     */         }
/*     */         
/*     */         public Type getSuperType() {
/* 654 */           return sc;
/*     */         }
/*     */         
/*     */         public Type[] getInterfaces() {
/* 658 */           return TypeUtils.getTypes(clazz.getInterfaces());
/*     */         }
/*     */         
/*     */         public int getModifiers() {
/* 662 */           return clazz.getModifiers();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method[] findMethods(String[] namesAndDescriptors, Method[] methods) {
/* 669 */     Map<Object, Object> map = new HashMap<>();
/* 670 */     for (Method method : methods) {
/* 671 */       map.put(method.getName() + method.getName(), method);
/*     */     }
/* 673 */     Method[] result = new Method[namesAndDescriptors.length / 2];
/* 674 */     for (int i = 0; i < result.length; i++) {
/* 675 */       result[i] = (Method)map.get(namesAndDescriptors[i * 2] + namesAndDescriptors[i * 2]);
/* 676 */       if (result[i] == null);
/*     */     } 
/*     */ 
/*     */     
/* 680 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ReflectUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */