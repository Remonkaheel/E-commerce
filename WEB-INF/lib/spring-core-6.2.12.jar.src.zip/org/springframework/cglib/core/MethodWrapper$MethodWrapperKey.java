/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MethodWrapperKey
/*    */   extends Record
/*    */ {
/*    */   private final String name;
/*    */   private final List<String> parameterTypes;
/*    */   private final String returnType;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   private MethodWrapperKey(String name, List<String> parameterTypes, String returnType) {
/* 30 */     this.name = name; this.parameterTypes = parameterTypes; this.returnType = returnType; } public String name() { return this.name; } public List<String> parameterTypes() { return this.parameterTypes; } public String returnType() { return this.returnType; }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\MethodWrapper$MethodWrapperKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */