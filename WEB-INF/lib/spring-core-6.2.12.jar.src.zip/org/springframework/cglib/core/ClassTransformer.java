/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClassTransformer
/*    */   extends ClassVisitor
/*    */ {
/*    */   public ClassTransformer() {
/* 22 */     super(Constants.ASM_API);
/*    */   }
/*    */   public ClassTransformer(int opcode) {
/* 25 */     super(opcode);
/*    */   }
/*    */   
/*    */   public abstract void setTarget(ClassVisitor paramClassVisitor);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */