/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import java.lang.reflect.Modifier;
/*    */ import org.springframework.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VisibilityPredicate
/*    */   implements Predicate
/*    */ {
/*    */   private boolean protectedOk;
/*    */   private String pkg;
/*    */   private boolean samePackageOk;
/*    */   
/*    */   public VisibilityPredicate(Class source, boolean protectedOk) {
/* 30 */     this.protectedOk = protectedOk;
/*    */ 
/*    */     
/* 33 */     this.samePackageOk = (source.getClassLoader() != null);
/* 34 */     this.pkg = TypeUtils.getPackageName(Type.getType(source));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean evaluate(Object arg) {
/* 39 */     Member member = (Member)arg;
/* 40 */     int mod = member.getModifiers();
/* 41 */     if (Modifier.isPrivate(mod))
/* 42 */       return false; 
/* 43 */     if (Modifier.isPublic(mod))
/* 44 */       return true; 
/* 45 */     if (Modifier.isProtected(mod) && this.protectedOk)
/*    */     {
/* 47 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 51 */     return (this.samePackageOk && this.pkg
/* 52 */       .equals(TypeUtils.getPackageName(Type.getType(member.getDeclaringClass()))));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\VisibilityPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */