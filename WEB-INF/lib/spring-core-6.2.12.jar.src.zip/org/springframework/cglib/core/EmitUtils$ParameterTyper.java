package org.springframework.cglib.core;

import org.springframework.asm.Type;

interface ParameterTyper {
  Type[] getParameterTypes(MethodInfo paramMethodInfo);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\EmitUtils$ParameterTyper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */