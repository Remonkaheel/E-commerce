/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeUtils
/*     */ {
/*  29 */   private static final Map transforms = new HashMap<>();
/*  30 */   private static final Map rtransforms = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  36 */     transforms.put("void", "V");
/*  37 */     transforms.put("byte", "B");
/*  38 */     transforms.put("char", "C");
/*  39 */     transforms.put("double", "D");
/*  40 */     transforms.put("float", "F");
/*  41 */     transforms.put("int", "I");
/*  42 */     transforms.put("long", "J");
/*  43 */     transforms.put("short", "S");
/*  44 */     transforms.put("boolean", "Z");
/*     */     
/*  46 */     CollectionUtils.reverse(transforms, rtransforms);
/*     */   }
/*     */   
/*     */   public static Type getType(String className) {
/*  50 */     return Type.getType("L" + className.replace('.', '/') + ";");
/*     */   }
/*     */   
/*     */   public static boolean isFinal(int access) {
/*  54 */     return ((0x10 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isStatic(int access) {
/*  58 */     return ((0x8 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isProtected(int access) {
/*  62 */     return ((0x4 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isPublic(int access) {
/*  66 */     return ((0x1 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isAbstract(int access) {
/*  70 */     return ((0x400 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isInterface(int access) {
/*  74 */     return ((0x200 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isPrivate(int access) {
/*  78 */     return ((0x2 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isSynthetic(int access) {
/*  82 */     return ((0x1000 & access) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isBridge(int access) {
/*  86 */     return ((0x40 & access) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getPackageName(Type type) {
/*  91 */     return getPackageName(getClassName(type));
/*     */   }
/*     */   
/*     */   public static String getPackageName(String className) {
/*  95 */     int idx = className.lastIndexOf('.');
/*  96 */     return (idx < 0) ? "" : className.substring(0, idx);
/*     */   }
/*     */   
/*     */   public static String upperFirst(String s) {
/* 100 */     if (s == null || s.isEmpty()) {
/* 101 */       return s;
/*     */     }
/* 103 */     return "" + Character.toUpperCase(s.charAt(0)) + Character.toUpperCase(s.charAt(0));
/*     */   }
/*     */   
/*     */   public static String getClassName(Type type) {
/* 107 */     if (isPrimitive(type))
/* 108 */       return (String)rtransforms.get(type.getDescriptor()); 
/* 109 */     if (isArray(type)) {
/* 110 */       return getClassName(getComponentType(type)) + "[]";
/*     */     }
/* 112 */     return type.getClassName();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Type[] add(Type[] types, Type extra) {
/* 117 */     if (types == null) {
/* 118 */       return new Type[] { extra };
/*     */     }
/* 120 */     List<Type> list = Arrays.asList(types);
/* 121 */     if (list.contains(extra)) {
/* 122 */       return types;
/*     */     }
/* 124 */     Type[] copy = new Type[types.length + 1];
/* 125 */     System.arraycopy(types, 0, copy, 0, types.length);
/* 126 */     copy[types.length] = extra;
/* 127 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type[] add(Type[] t1, Type[] t2) {
/* 133 */     Type[] all = new Type[t1.length + t2.length];
/* 134 */     System.arraycopy(t1, 0, all, 0, t1.length);
/* 135 */     System.arraycopy(t2, 0, all, t1.length, t2.length);
/* 136 */     return all;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Type fromInternalName(String name) {
/* 141 */     return Type.getType("L" + name + ";");
/*     */   }
/*     */   
/*     */   public static Type[] fromInternalNames(String[] names) {
/* 145 */     if (names == null) {
/* 146 */       return null;
/*     */     }
/* 148 */     Type[] types = new Type[names.length];
/* 149 */     for (int i = 0; i < names.length; i++) {
/* 150 */       types[i] = fromInternalName(names[i]);
/*     */     }
/* 152 */     return types;
/*     */   }
/*     */   
/*     */   public static int getStackSize(Type[] types) {
/* 156 */     int size = 0;
/* 157 */     for (Type type : types) {
/* 158 */       size += type.getSize();
/*     */     }
/* 160 */     return size;
/*     */   }
/*     */   
/*     */   public static String[] toInternalNames(Type[] types) {
/* 164 */     if (types == null) {
/* 165 */       return null;
/*     */     }
/* 167 */     String[] names = new String[types.length];
/* 168 */     for (int i = 0; i < types.length; i++) {
/* 169 */       names[i] = types[i].getInternalName();
/*     */     }
/* 171 */     return names;
/*     */   }
/*     */   
/*     */   public static Signature parseSignature(String s) {
/* 175 */     int space = s.indexOf(' ');
/* 176 */     int lparen = s.indexOf('(', space);
/* 177 */     int rparen = s.indexOf(')', lparen);
/* 178 */     String returnType = s.substring(0, space);
/* 179 */     String methodName = s.substring(space + 1, lparen);
/* 180 */     StringBuilder sb = new StringBuilder();
/* 181 */     sb.append('(');
/* 182 */     for (Iterator it = parseTypes(s, lparen + 1, rparen).iterator(); it.hasNext();) {
/* 183 */       sb.append(it.next());
/*     */     }
/* 185 */     sb.append(')');
/* 186 */     sb.append(map(returnType));
/* 187 */     return new Signature(methodName, sb.toString());
/*     */   }
/*     */   
/*     */   public static Type parseType(String s) {
/* 191 */     return Type.getType(map(s));
/*     */   }
/*     */   
/*     */   public static Type[] parseTypes(String s) {
/* 195 */     List<String> names = parseTypes(s, 0, s.length());
/* 196 */     Type[] types = new Type[names.size()];
/* 197 */     for (int i = 0; i < types.length; i++) {
/* 198 */       types[i] = Type.getType(names.get(i));
/*     */     }
/* 200 */     return types;
/*     */   }
/*     */   
/*     */   public static Signature parseConstructor(Type[] types) {
/* 204 */     StringBuilder sb = new StringBuilder();
/* 205 */     sb.append("(");
/* 206 */     for (Type type : types) {
/* 207 */       sb.append(type.getDescriptor());
/*     */     }
/* 209 */     sb.append(")");
/* 210 */     sb.append("V");
/* 211 */     return new Signature("<init>", sb.toString());
/*     */   }
/*     */   
/*     */   public static Signature parseConstructor(String sig) {
/* 215 */     return parseSignature("void <init>(" + sig + ")");
/*     */   }
/*     */   
/*     */   private static List parseTypes(String s, int mark, int end) {
/* 219 */     List<String> types = new ArrayList(5);
/*     */     while (true) {
/* 221 */       int next = s.indexOf(',', mark);
/* 222 */       if (next < 0) {
/*     */         break;
/*     */       }
/* 225 */       types.add(map(s.substring(mark, next).trim()));
/* 226 */       mark = next + 1;
/*     */     } 
/* 228 */     types.add(map(s.substring(mark, end).trim()));
/* 229 */     return types;
/*     */   }
/*     */   
/*     */   private static String map(String type) {
/* 233 */     if (type.isEmpty()) {
/* 234 */       return type;
/*     */     }
/* 236 */     String t = (String)transforms.get(type);
/* 237 */     if (t != null)
/* 238 */       return t; 
/* 239 */     if (type.indexOf('.') < 0) {
/* 240 */       return map("java.lang." + type);
/*     */     }
/* 242 */     StringBuilder sb = new StringBuilder();
/* 243 */     int index = 0;
/* 244 */     while ((index = type.indexOf("[]", index) + 1) > 0) {
/* 245 */       sb.append('[');
/*     */     }
/* 247 */     type = type.substring(0, type.length() - sb.length() * 2);
/* 248 */     sb.append('L').append(type.replace('.', '/')).append(';');
/* 249 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Type getBoxedType(Type type) {
/* 254 */     switch (type.getSort()) { case 2: case 1: case 8: case 6: case 7: case 5: case 4: case 3:  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 263 */       type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Type getUnboxedType(Type type) {
/* 268 */     if (Constants.TYPE_INTEGER.equals(type))
/* 269 */       return Type.INT_TYPE; 
/* 270 */     if (Constants.TYPE_BOOLEAN.equals(type))
/* 271 */       return Type.BOOLEAN_TYPE; 
/* 272 */     if (Constants.TYPE_DOUBLE.equals(type))
/* 273 */       return Type.DOUBLE_TYPE; 
/* 274 */     if (Constants.TYPE_LONG.equals(type))
/* 275 */       return Type.LONG_TYPE; 
/* 276 */     if (Constants.TYPE_CHARACTER.equals(type))
/* 277 */       return Type.CHAR_TYPE; 
/* 278 */     if (Constants.TYPE_BYTE.equals(type))
/* 279 */       return Type.BYTE_TYPE; 
/* 280 */     if (Constants.TYPE_FLOAT.equals(type))
/* 281 */       return Type.FLOAT_TYPE; 
/* 282 */     if (Constants.TYPE_SHORT.equals(type)) {
/* 283 */       return Type.SHORT_TYPE;
/*     */     }
/* 285 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isArray(Type type) {
/* 290 */     return (type.getSort() == 9);
/*     */   }
/*     */   
/*     */   public static Type getComponentType(Type type) {
/* 294 */     if (!isArray(type)) {
/* 295 */       throw new IllegalArgumentException("Type " + String.valueOf(type) + " is not an array");
/*     */     }
/* 297 */     return Type.getType(type.getDescriptor().substring(1));
/*     */   }
/*     */   
/*     */   public static boolean isPrimitive(Type type) {
/* 301 */     switch (type.getSort()) { case 9: case 10:  }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String emulateClassGetName(Type type) {
/* 308 */     if (isArray(type)) {
/* 309 */       return type.getDescriptor().replace('/', '.');
/*     */     }
/* 311 */     return getClassName(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isConstructor(MethodInfo method) {
/* 316 */     return method.getSignature().getName().equals("<init>");
/*     */   }
/*     */   
/*     */   public static Type[] getTypes(Class[] classes) {
/* 320 */     if (classes == null) {
/* 321 */       return null;
/*     */     }
/* 323 */     Type[] types = new Type[classes.length];
/* 324 */     for (int i = 0; i < classes.length; i++) {
/* 325 */       types[i] = Type.getType(classes[i]);
/*     */     }
/* 327 */     return types;
/*     */   }
/*     */   
/*     */   public static int ICONST(int value) {
/* 331 */     switch (value) { case -1: case 0: case 1: case 2: case 3: case 4: case 5:  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 339 */       -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int LCONST(long value) {
/* 344 */     if (value == 0L)
/* 345 */       return 9; 
/* 346 */     if (value == 1L) {
/* 347 */       return 10;
/*     */     }
/* 349 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int FCONST(float value) {
/* 354 */     if (value == 0.0F)
/* 355 */       return 11; 
/* 356 */     if (value == 1.0F)
/* 357 */       return 12; 
/* 358 */     if (value == 2.0F) {
/* 359 */       return 13;
/*     */     }
/* 361 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int DCONST(double value) {
/* 366 */     if (value == 0.0D)
/* 367 */       return 14; 
/* 368 */     if (value == 1.0D) {
/* 369 */       return 15;
/*     */     }
/* 371 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int NEWARRAY(Type type) {
/* 376 */     switch (type.getSort()) { case 3: case 2: case 8: case 6: case 5: case 7: case 4: case 1:  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 385 */       -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String escapeType(String s) {
/* 390 */     StringBuilder sb = new StringBuilder();
/* 391 */     for (int i = 0, len = s.length(); i < len; i++) {
/* 392 */       char c = s.charAt(i);
/* 393 */       switch (c) { case '$':
/* 394 */           sb.append("$24"); break;
/* 395 */         case '.': sb.append("$2E"); break;
/* 396 */         case '[': sb.append("$5B"); break;
/* 397 */         case ';': sb.append("$3B"); break;
/* 398 */         case '(': sb.append("$28"); break;
/* 399 */         case ')': sb.append("$29"); break;
/* 400 */         case '/': sb.append("$2F"); break;
/* 401 */         default: sb.append(c); break; }
/*     */     
/*     */     } 
/* 404 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\TypeUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */