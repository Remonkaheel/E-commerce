/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringNamingPolicy
/*    */   implements NamingPolicy
/*    */ {
/* 33 */   public static final SpringNamingPolicy INSTANCE = new SpringNamingPolicy();
/*    */ 
/*    */   
/*    */   private static final String SPRING_LABEL = "$$SpringCGLIB$$";
/*    */ 
/*    */   
/*    */   private static final String FAST_CLASS_SUFFIX = "FastClass$$";
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName(String prefix, String source, Object key, Predicate names) {
/*    */     String base;
/* 45 */     if (prefix == null) {
/* 46 */       prefix = "org.springframework.cglib.empty.Object";
/*    */     }
/* 48 */     else if (prefix.startsWith("java.") || prefix.startsWith("javax.")) {
/* 49 */       prefix = "_" + prefix;
/*    */     } 
/*    */ 
/*    */     
/* 53 */     int existingLabel = prefix.indexOf("$$SpringCGLIB$$");
/* 54 */     if (existingLabel >= 0) {
/* 55 */       base = prefix.substring(0, existingLabel + "$$SpringCGLIB$$".length());
/*    */     } else {
/*    */       
/* 58 */       base = prefix + "$$SpringCGLIB$$";
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 63 */     boolean isFastClass = (source != null && source.endsWith(".FastClass"));
/* 64 */     if (isFastClass && !prefix.contains("FastClass$$")) {
/* 65 */       base = base + "FastClass$$";
/*    */     }
/*    */     
/* 68 */     int index = 0;
/* 69 */     String attempt = base + base;
/* 70 */     while (names.evaluate(attempt)) {
/* 71 */       attempt = base + base;
/*    */     }
/* 73 */     return attempt;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\SpringNamingPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */