/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class MethodWrapper {
/*    */   private static final class MethodWrapperKey extends Record {
/*    */     private final String name;
/*    */     private final List<String> parameterTypes;
/*    */     private final String returnType;
/*    */     
/*    */     public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #30	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;
/*    */     }
/*    */     
/*    */     public final int hashCode() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #30	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;
/*    */     }
/*    */     
/*    */     public final boolean equals(Object o) {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #30	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lorg/springframework/cglib/core/MethodWrapper$MethodWrapperKey;
/*    */       //   0	8	1	o	Ljava/lang/Object;
/*    */     }
/*    */     
/*    */     private MethodWrapperKey(String name, List<String> parameterTypes, String returnType) {
/* 30 */       this.name = name; this.parameterTypes = parameterTypes; this.returnType = returnType; } public String name() { return this.name; } public List<String> parameterTypes() { return this.parameterTypes; } public String returnType() { return this.returnType; }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object create(Method method) {
/* 39 */     return new MethodWrapperKey(method.getName(), 
/* 40 */         Arrays.asList(ReflectUtils.getNames(method.getParameterTypes())), method
/* 41 */         .getReturnType().getName());
/*    */   }
/*    */ 
/*    */   
/*    */   public static Set createSet(Collection methods) {
/* 46 */     Set<Object> set = new HashSet();
/* 47 */     for (Iterator<Method> it = methods.iterator(); it.hasNext();) {
/* 48 */       set.add(create(it.next()));
/*    */     }
/* 50 */     return set;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\MethodWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */