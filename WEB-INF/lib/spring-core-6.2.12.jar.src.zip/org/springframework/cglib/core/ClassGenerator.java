package org.springframework.cglib.core;

import org.springframework.asm.ClassVisitor;

public interface ClassGenerator {
  void generateClass(ClassVisitor paramClassVisitor) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\core\ClassGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */