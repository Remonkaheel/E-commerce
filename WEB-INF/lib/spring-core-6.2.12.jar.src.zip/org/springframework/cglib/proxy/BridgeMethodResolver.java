/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BridgeMethodResolver
/*     */ {
/*     */   private final Map declToBridge;
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   public BridgeMethodResolver(Map declToBridge, ClassLoader classLoader) {
/*  50 */     this.declToBridge = declToBridge;
/*  51 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map resolveAll() {
/*  59 */     Map<Object, Object> resolved = new HashMap<>();
/*  60 */     for (Iterator<Map.Entry> entryIter = this.declToBridge.entrySet().iterator(); entryIter.hasNext(); ) {
/*  61 */       Map.Entry entry = entryIter.next();
/*  62 */       Class owner = (Class)entry.getKey();
/*  63 */       Set bridges = (Set)entry.getValue();
/*     */       try {
/*  65 */         InputStream is = this.classLoader.getResourceAsStream(owner.getName().replace('.', '/') + ".class");
/*  66 */         if (is == null) {
/*  67 */           return resolved;
/*     */         }
/*     */         try {
/*  70 */           (new ClassReader(is))
/*  71 */             .accept(new BridgedFinder(bridges, resolved), 6);
/*     */         } finally {
/*     */           
/*  74 */           is.close();
/*     */         } 
/*  76 */       } catch (IOException iOException) {}
/*     */     } 
/*  78 */     return resolved;
/*     */   }
/*     */   
/*     */   private static class BridgedFinder
/*     */     extends ClassVisitor {
/*     */     private Map resolved;
/*     */     private Set eligibleMethods;
/*  85 */     private Signature currentMethod = null;
/*     */     
/*     */     BridgedFinder(Set eligibleMethods, Map resolved) {
/*  88 */       super(Constants.ASM_API);
/*  89 */       this.resolved = resolved;
/*  90 */       this.eligibleMethods = eligibleMethods;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 101 */       Signature sig = new Signature(name, desc);
/* 102 */       if (this.eligibleMethods.remove(sig)) {
/* 103 */         this.currentMethod = sig;
/* 104 */         return new MethodVisitor(Constants.ASM_API)
/*     */           {
/*     */             public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf)
/*     */             {
/* 108 */               if ((opcode == 183 || (itf && opcode == 185)) && BridgeMethodResolver.BridgedFinder.this.currentMethod != null) {
/*     */ 
/*     */                 
/* 111 */                 Signature target = new Signature(name, desc);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 118 */                 if (!target.equals(BridgeMethodResolver.BridgedFinder.this.currentMethod)) {
/* 119 */                   BridgeMethodResolver.BridgedFinder.this.resolved.put(BridgeMethodResolver.BridgedFinder.this.currentMethod, target);
/*     */                 }
/* 121 */                 BridgeMethodResolver.BridgedFinder.this.currentMethod = null;
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/* 126 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   class null extends MethodVisitor {
/*     */     null(int api) {
/*     */       super(api);
/*     */     }
/*     */     
/*     */     public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/*     */       if ((opcode == 183 || (itf && opcode == 185)) && BridgeMethodResolver.BridgedFinder.this.currentMethod != null) {
/*     */         Signature target = new Signature(name, desc);
/*     */         if (!target.equals(BridgeMethodResolver.BridgedFinder.this.currentMethod))
/*     */           BridgeMethodResolver.BridgedFinder.this.resolved.put(BridgeMethodResolver.BridgedFinder.this.currentMethod, target); 
/*     */         BridgeMethodResolver.BridgedFinder.this.currentMethod = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\BridgeMethodResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */