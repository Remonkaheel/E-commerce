/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.asm.Label;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.ClassEmitter;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LazyLoaderGenerator
/*    */   implements CallbackGenerator
/*    */ {
/* 34 */   public static final LazyLoaderGenerator INSTANCE = new LazyLoaderGenerator();
/*    */ 
/*    */   
/* 37 */   private static final Signature LOAD_OBJECT = TypeUtils.parseSignature("Object loadObject()");
/*    */   
/* 39 */   private static final Type LAZY_LOADER = TypeUtils.parseType("org.springframework.cglib.proxy.LazyLoader");
/*    */ 
/*    */   
/*    */   public void generate(ClassEmitter ce, CallbackGenerator.Context context, List methods) {
/* 43 */     Set<Integer> indexes = new HashSet();
/* 44 */     for (Iterator<MethodInfo> iterator = methods.iterator(); iterator.hasNext(); ) {
/* 45 */       MethodInfo method = iterator.next();
/* 46 */       if (TypeUtils.isProtected(method.getModifiers())) {
/*    */         continue;
/*    */       }
/* 49 */       int index = context.getIndex(method);
/* 50 */       indexes.add(Integer.valueOf(index));
/* 51 */       CodeEmitter e = context.beginMethod(ce, method);
/* 52 */       e.load_this();
/* 53 */       e.dup();
/* 54 */       e.invoke_virtual_this(loadMethod(index));
/* 55 */       e.checkcast(method.getClassInfo().getType());
/* 56 */       e.load_args();
/* 57 */       e.invoke(method);
/* 58 */       e.return_value();
/* 59 */       e.end_method();
/*    */     } 
/*    */ 
/*    */     
/* 63 */     for (Iterator<Integer> it = indexes.iterator(); it.hasNext(); ) {
/* 64 */       int index = ((Integer)it.next()).intValue();
/*    */       
/* 66 */       String delegate = "CGLIB$LAZY_LOADER_" + index;
/* 67 */       ce.declare_field(2, delegate, Constants.TYPE_OBJECT, null);
/*    */       
/* 69 */       CodeEmitter e = ce.begin_method(50, 
/*    */ 
/*    */           
/* 72 */           loadMethod(index), null);
/*    */       
/* 74 */       e.load_this();
/* 75 */       e.getfield(delegate);
/* 76 */       e.dup();
/* 77 */       Label end = e.make_label();
/* 78 */       e.ifnonnull(end);
/* 79 */       e.pop();
/* 80 */       e.load_this();
/* 81 */       context.emitCallback(e, index);
/* 82 */       e.invoke_interface(LAZY_LOADER, LOAD_OBJECT);
/* 83 */       e.dup_x1();
/* 84 */       e.putfield(delegate);
/* 85 */       e.mark(end);
/* 86 */       e.return_value();
/* 87 */       e.end_method();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private Signature loadMethod(int index) {
/* 93 */     return new Signature("CGLIB$LOAD_PRIVATE_" + index, Constants.TYPE_OBJECT, Constants.TYPES_EMPTY);
/*    */   }
/*    */   
/*    */   public void generateStatic(CodeEmitter e, CallbackGenerator.Context context, List methods) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\LazyLoaderGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */