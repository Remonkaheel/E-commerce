/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BridgedFinder
/*     */   extends ClassVisitor
/*     */ {
/*     */   private Map resolved;
/*     */   private Set eligibleMethods;
/*  85 */   private Signature currentMethod = null;
/*     */   
/*     */   BridgedFinder(Set eligibleMethods, Map resolved) {
/*  88 */     super(Constants.ASM_API);
/*  89 */     this.resolved = resolved;
/*  90 */     this.eligibleMethods = eligibleMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 101 */     Signature sig = new Signature(name, desc);
/* 102 */     if (this.eligibleMethods.remove(sig)) {
/* 103 */       this.currentMethod = sig;
/* 104 */       return new MethodVisitor(Constants.ASM_API)
/*     */         {
/*     */           public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf)
/*     */           {
/* 108 */             if ((opcode == 183 || (itf && opcode == 185)) && BridgeMethodResolver.BridgedFinder.this.currentMethod != null) {
/*     */ 
/*     */               
/* 111 */               Signature target = new Signature(name, desc);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 118 */               if (!target.equals(BridgeMethodResolver.BridgedFinder.this.currentMethod)) {
/* 119 */                 BridgeMethodResolver.BridgedFinder.this.resolved.put(BridgeMethodResolver.BridgedFinder.this.currentMethod, target);
/*     */               }
/* 121 */               BridgeMethodResolver.BridgedFinder.this.currentMethod = null;
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/* 126 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\BridgeMethodResolver$BridgedFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */