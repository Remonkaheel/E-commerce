/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.ClassEmitter;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FixedValueGenerator
/*    */   implements CallbackGenerator
/*    */ {
/* 30 */   public static final FixedValueGenerator INSTANCE = new FixedValueGenerator();
/*    */   
/* 32 */   private static final Type FIXED_VALUE = TypeUtils.parseType("org.springframework.cglib.proxy.FixedValue");
/*    */   
/* 34 */   private static final Signature LOAD_OBJECT = TypeUtils.parseSignature("Object loadObject()");
/*    */ 
/*    */   
/*    */   public void generate(ClassEmitter ce, CallbackGenerator.Context context, List methods) {
/* 38 */     for (Iterator<MethodInfo> it = methods.iterator(); it.hasNext(); ) {
/* 39 */       MethodInfo method = it.next();
/* 40 */       CodeEmitter e = context.beginMethod(ce, method);
/* 41 */       context.emitCallback(e, context.getIndex(method));
/* 42 */       e.invoke_interface(FIXED_VALUE, LOAD_OBJECT);
/* 43 */       e.unbox_or_zero(e.getReturnType());
/* 44 */       e.return_value();
/* 45 */       e.end_method();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void generateStatic(CodeEmitter e, CallbackGenerator.Context context, List methods) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\FixedValueGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */