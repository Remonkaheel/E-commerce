/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.MethodWrapper;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MixinEmitter
/*     */   extends ClassEmitter
/*     */ {
/*     */   private static final String FIELD_NAME = "CGLIB$DELEGATES";
/*  42 */   private static final Signature CSTRUCT_OBJECT_ARRAY = TypeUtils.parseConstructor("Object[]");
/*     */   
/*  44 */   private static final Type MIXIN = TypeUtils.parseType("org.springframework.cglib.proxy.Mixin");
/*  45 */   private static final Signature NEW_INSTANCE = new Signature("newInstance", MIXIN, new Type[] { Constants.TYPE_OBJECT_ARRAY });
/*     */ 
/*     */   
/*     */   public MixinEmitter(ClassVisitor v, String className, Class[] classes, int[] route) {
/*  49 */     super(v);
/*     */     
/*  51 */     begin_class(52, 1, className, MIXIN, 
/*     */ 
/*     */ 
/*     */         
/*  55 */         TypeUtils.getTypes(getInterfaces(classes)), "<generated>");
/*     */     
/*  57 */     EmitUtils.null_constructor(this);
/*  58 */     EmitUtils.factory_method(this, NEW_INSTANCE);
/*     */     
/*  60 */     declare_field(2, "CGLIB$DELEGATES", Constants.TYPE_OBJECT_ARRAY, null);
/*     */     
/*  62 */     CodeEmitter e = begin_method(1, CSTRUCT_OBJECT_ARRAY, null);
/*  63 */     e.load_this();
/*  64 */     e.super_invoke_constructor();
/*  65 */     e.load_this();
/*  66 */     e.load_arg(0);
/*  67 */     e.putfield("CGLIB$DELEGATES");
/*  68 */     e.return_value();
/*  69 */     e.end_method();
/*     */     
/*  71 */     Set<Object> unique = new HashSet();
/*  72 */     for (int i = 0; i < classes.length; i++) {
/*  73 */       Method[] methods = getMethods(classes[i]);
/*  74 */       for (Method method : methods) {
/*  75 */         if (unique.add(MethodWrapper.create(method))) {
/*  76 */           MethodInfo methodInfo = ReflectUtils.getMethodInfo(method);
/*  77 */           int modifiers = 1;
/*  78 */           if ((methodInfo.getModifiers() & 0x80) == 128) {
/*  79 */             modifiers |= 0x80;
/*     */           }
/*  81 */           e = EmitUtils.begin_method(this, methodInfo, modifiers);
/*  82 */           e.load_this();
/*  83 */           e.getfield("CGLIB$DELEGATES");
/*  84 */           e.aaload((route != null) ? route[i] : i);
/*  85 */           e.checkcast(methodInfo.getClassInfo().getType());
/*  86 */           e.load_args();
/*  87 */           e.invoke(methodInfo);
/*  88 */           e.return_value();
/*  89 */           e.end_method();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     end_class();
/*     */   }
/*     */   
/*     */   protected Class[] getInterfaces(Class[] classes) {
/*  98 */     return classes;
/*     */   }
/*     */   
/*     */   protected Method[] getMethods(Class type) {
/* 102 */     return type.getMethods();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\MixinEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */