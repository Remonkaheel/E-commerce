/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.Block;
/*    */ import org.springframework.cglib.core.ClassEmitter;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.EmitUtils;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InvocationHandlerGenerator
/*    */   implements CallbackGenerator
/*    */ {
/* 35 */   public static final InvocationHandlerGenerator INSTANCE = new InvocationHandlerGenerator();
/*    */ 
/*    */   
/* 38 */   private static final Type INVOCATION_HANDLER = TypeUtils.parseType("org.springframework.cglib.proxy.InvocationHandler");
/*    */   
/* 40 */   private static final Type UNDECLARED_THROWABLE_EXCEPTION = TypeUtils.parseType("org.springframework.cglib.proxy.UndeclaredThrowableException");
/*    */   
/* 42 */   private static final Type METHOD = TypeUtils.parseType("java.lang.reflect.Method");
/*    */   
/* 44 */   private static final Signature INVOKE = TypeUtils.parseSignature("Object invoke(Object, java.lang.reflect.Method, Object[])");
/*    */ 
/*    */   
/*    */   public void generate(ClassEmitter ce, CallbackGenerator.Context context, List methods) {
/* 48 */     for (Iterator<MethodInfo> it = methods.iterator(); it.hasNext(); ) {
/* 49 */       MethodInfo method = it.next();
/* 50 */       Signature impl = context.getImplSignature(method);
/* 51 */       ce.declare_field(26, impl.getName(), METHOD, null);
/*    */       
/* 53 */       CodeEmitter e = context.beginMethod(ce, method);
/* 54 */       Block handler = e.begin_block();
/* 55 */       context.emitCallback(e, context.getIndex(method));
/* 56 */       e.load_this();
/* 57 */       e.getfield(impl.getName());
/* 58 */       e.create_arg_array();
/* 59 */       e.invoke_interface(INVOCATION_HANDLER, INVOKE);
/* 60 */       e.unbox(method.getSignature().getReturnType());
/* 61 */       e.return_value();
/* 62 */       handler.end();
/* 63 */       EmitUtils.wrap_undeclared_throwable(e, handler, method.getExceptionTypes(), UNDECLARED_THROWABLE_EXCEPTION);
/* 64 */       e.end_method();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void generateStatic(CodeEmitter e, CallbackGenerator.Context context, List methods) {
/* 70 */     for (Iterator<MethodInfo> it = methods.iterator(); it.hasNext(); ) {
/* 71 */       MethodInfo method = it.next();
/* 72 */       EmitUtils.load_method(e, method);
/* 73 */       e.putfield(context.getImplSignature(method).getName());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\InvocationHandlerGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */