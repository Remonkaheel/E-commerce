/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.CollectionUtils;
/*    */ import org.springframework.cglib.core.Predicate;
/*    */ import org.springframework.cglib.core.ReflectUtils;
/*    */ import org.springframework.cglib.core.RejectModifierPredicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MixinEverythingEmitter
/*    */   extends MixinEmitter
/*    */ {
/*    */   public MixinEverythingEmitter(ClassVisitor v, String className, Class[] classes) {
/* 38 */     super(v, className, classes, null);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class[] getInterfaces(Class[] classes) {
/* 43 */     List list = new ArrayList();
/* 44 */     for (Class clazz : classes) {
/* 45 */       ReflectUtils.addAllInterfaces(clazz, list);
/*    */     }
/* 47 */     return (Class[])list.toArray((Object[])new Class[list.size()]);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Method[] getMethods(Class type) {
/* 52 */     List methods = new ArrayList(Arrays.asList((Object[])type.getMethods()));
/* 53 */     CollectionUtils.filter(methods, (Predicate)new RejectModifierPredicate(24));
/* 54 */     return (Method[])methods.toArray((Object[])new Method[methods.size()]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\MixinEverythingEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */