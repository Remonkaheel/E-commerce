/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface NoOp
/*    */   extends Callback
/*    */ {
/* 27 */   public static final NoOp INSTANCE = new NoOp() {
/*    */     
/*    */     };
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\NoOp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */