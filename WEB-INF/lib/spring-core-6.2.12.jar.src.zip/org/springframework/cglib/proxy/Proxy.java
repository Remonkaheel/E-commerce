/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.cglib.core.CodeGenerationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Proxy
/*    */   implements Serializable
/*    */ {
/*    */   protected InvocationHandler h;
/*    */   private static final CallbackFilter BAD_OBJECT_METHOD_FILTER;
/*    */   
/*    */   static {
/* 42 */     BAD_OBJECT_METHOD_FILTER = (method -> {
/*    */         if (method.getDeclaringClass().getName().equals("java.lang.Object")) {
/*    */           String name = method.getName();
/*    */           if (!name.equals("hashCode") && !name.equals("equals") && !name.equals("toString")) {
/*    */             return 1;
/*    */           }
/*    */         } 
/*    */         return 0;
/*    */       });
/*    */   }
/*    */ 
/*    */   
/*    */   protected Proxy(InvocationHandler h) {
/* 55 */     Enhancer.registerCallbacks(getClass(), new Callback[] { h, null });
/* 56 */     this.h = h;
/*    */   }
/*    */   
/*    */   private static class ProxyImpl
/*    */     extends Proxy {
/*    */     protected ProxyImpl(InvocationHandler h) {
/* 62 */       super(h);
/*    */     }
/*    */   }
/*    */   
/*    */   public static InvocationHandler getInvocationHandler(Object proxy) {
/* 67 */     if (!(proxy instanceof ProxyImpl)) {
/* 68 */       throw new IllegalArgumentException("Object is not a proxy");
/*    */     }
/* 70 */     return ((Proxy)proxy).h;
/*    */   }
/*    */   
/*    */   public static Class getProxyClass(ClassLoader loader, Class[] interfaces) {
/* 74 */     Enhancer e = new Enhancer();
/* 75 */     e.setSuperclass(ProxyImpl.class);
/* 76 */     e.setInterfaces(interfaces);
/* 77 */     e.setCallbackTypes(new Class[] { InvocationHandler.class, NoOp.class });
/*    */ 
/*    */ 
/*    */     
/* 81 */     e.setCallbackFilter(BAD_OBJECT_METHOD_FILTER);
/* 82 */     e.setUseFactory(false);
/* 83 */     return e.createClass();
/*    */   }
/*    */   
/*    */   public static boolean isProxyClass(Class cl) {
/* 87 */     return cl.getSuperclass().equals(ProxyImpl.class);
/*    */   }
/*    */   
/*    */   public static Object newProxyInstance(ClassLoader loader, Class[] interfaces, InvocationHandler h) {
/*    */     try {
/* 92 */       Class clazz = getProxyClass(loader, interfaces);
/* 93 */       return clazz.getConstructor(new Class[] { InvocationHandler.class }).newInstance(new Object[] { h });
/* 94 */     } catch (RuntimeException e) {
/* 95 */       throw e;
/* 96 */     } catch (Exception e) {
/* 97 */       throw new CodeGenerationException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\Proxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */