package org.springframework.cglib.proxy;

import org.springframework.cglib.core.ClassEmitter;
import org.springframework.cglib.core.CodeEmitter;
import org.springframework.cglib.core.MethodInfo;
import org.springframework.cglib.core.Signature;

public interface Context {
  ClassLoader getClassLoader();
  
  CodeEmitter beginMethod(ClassEmitter paramClassEmitter, MethodInfo paramMethodInfo);
  
  int getOriginalModifiers(MethodInfo paramMethodInfo);
  
  int getIndex(MethodInfo paramMethodInfo);
  
  void emitCallback(CodeEmitter paramCodeEmitter, int paramInt);
  
  Signature getImplSignature(MethodInfo paramMethodInfo);
  
  void emitLoadArgsAndInvoke(CodeEmitter paramCodeEmitter, MethodInfo paramMethodInfo);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\CallbackGenerator$Context.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */