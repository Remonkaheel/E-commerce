package org.springframework.cglib.proxy;

import org.springframework.cglib.reflect.FastClass;

class FastClassInfo {
  FastClass f1;
  
  FastClass f2;
  
  int i1;
  
  int i2;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\MethodProxy$FastClassInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */