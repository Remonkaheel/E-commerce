/*      */ package org.springframework.cglib.proxy;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.springframework.asm.ClassVisitor;
/*      */ import org.springframework.asm.Label;
/*      */ import org.springframework.asm.Type;
/*      */ import org.springframework.cglib.core.AbstractClassGenerator;
/*      */ import org.springframework.cglib.core.ClassEmitter;
/*      */ import org.springframework.cglib.core.CodeEmitter;
/*      */ import org.springframework.cglib.core.CodeGenerationException;
/*      */ import org.springframework.cglib.core.CollectionUtils;
/*      */ import org.springframework.cglib.core.Constants;
/*      */ import org.springframework.cglib.core.DuplicatesPredicate;
/*      */ import org.springframework.cglib.core.EmitUtils;
/*      */ import org.springframework.cglib.core.Local;
/*      */ import org.springframework.cglib.core.MethodInfo;
/*      */ import org.springframework.cglib.core.MethodInfoTransformer;
/*      */ import org.springframework.cglib.core.MethodWrapper;
/*      */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*      */ import org.springframework.cglib.core.Predicate;
/*      */ import org.springframework.cglib.core.ProcessSwitchCallback;
/*      */ import org.springframework.cglib.core.ReflectUtils;
/*      */ import org.springframework.cglib.core.RejectModifierPredicate;
/*      */ import org.springframework.cglib.core.Signature;
/*      */ import org.springframework.cglib.core.Transformer;
/*      */ import org.springframework.cglib.core.TypeUtils;
/*      */ import org.springframework.cglib.core.VisibilityPredicate;
/*      */ import org.springframework.cglib.core.WeakCacheKey;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Enhancer
/*      */   extends AbstractClassGenerator
/*      */ {
/*      */   private static final CallbackFilter ALL_ZERO = method -> 0;
/*   95 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(Enhancer.class.getName());
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String BOUND_FIELD = "CGLIB$BOUND";
/*      */ 
/*      */   
/*      */   private static final String FACTORY_DATA_FIELD = "CGLIB$FACTORY_DATA";
/*      */ 
/*      */   
/*      */   private static final String THREAD_CALLBACKS_FIELD = "CGLIB$THREAD_CALLBACKS";
/*      */ 
/*      */   
/*      */   private static final String STATIC_CALLBACKS_FIELD = "CGLIB$STATIC_CALLBACKS";
/*      */ 
/*      */   
/*      */   private static final String SET_THREAD_CALLBACKS_NAME = "CGLIB$SET_THREAD_CALLBACKS";
/*      */ 
/*      */   
/*      */   private static final String SET_STATIC_CALLBACKS_NAME = "CGLIB$SET_STATIC_CALLBACKS";
/*      */ 
/*      */   
/*      */   private static final String CONSTRUCTED_FIELD = "CGLIB$CONSTRUCTED";
/*      */ 
/*      */   
/*      */   private static final String CALLBACK_FILTER_FIELD = "CGLIB$CALLBACK_FILTER";
/*      */ 
/*      */   
/*  123 */   private static final Type OBJECT_TYPE = TypeUtils.parseType("Object");
/*      */ 
/*      */   
/*  126 */   private static final Type FACTORY = TypeUtils.parseType("org.springframework.cglib.proxy.Factory");
/*      */ 
/*      */   
/*  129 */   private static final Type ILLEGAL_STATE_EXCEPTION = TypeUtils.parseType("IllegalStateException");
/*      */ 
/*      */   
/*  132 */   private static final Type ILLEGAL_ARGUMENT_EXCEPTION = TypeUtils.parseType("IllegalArgumentException");
/*      */ 
/*      */   
/*  135 */   private static final Type THREAD_LOCAL = TypeUtils.parseType("ThreadLocal");
/*      */ 
/*      */   
/*  138 */   private static final Type CALLBACK = TypeUtils.parseType("org.springframework.cglib.proxy.Callback");
/*      */ 
/*      */   
/*  141 */   private static final Type CALLBACK_ARRAY = Type.getType(Callback[].class);
/*      */ 
/*      */   
/*  144 */   private static final Signature CSTRUCT_NULL = TypeUtils.parseConstructor("");
/*      */   
/*  146 */   private static final Signature SET_THREAD_CALLBACKS = new Signature("CGLIB$SET_THREAD_CALLBACKS", Type.VOID_TYPE, new Type[] { CALLBACK_ARRAY });
/*      */ 
/*      */   
/*  149 */   private static final Signature SET_STATIC_CALLBACKS = new Signature("CGLIB$SET_STATIC_CALLBACKS", Type.VOID_TYPE, new Type[] { CALLBACK_ARRAY });
/*      */ 
/*      */   
/*  152 */   private static final Signature NEW_INSTANCE = new Signature("newInstance", Constants.TYPE_OBJECT, new Type[] { CALLBACK_ARRAY });
/*      */ 
/*      */   
/*  155 */   private static final Signature MULTIARG_NEW_INSTANCE = new Signature("newInstance", Constants.TYPE_OBJECT, new Type[] { Constants.TYPE_CLASS_ARRAY, Constants.TYPE_OBJECT_ARRAY, CALLBACK_ARRAY });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   private static final Signature SINGLE_NEW_INSTANCE = new Signature("newInstance", Constants.TYPE_OBJECT, new Type[] { CALLBACK });
/*      */ 
/*      */   
/*  165 */   private static final Signature SET_CALLBACK = new Signature("setCallback", Type.VOID_TYPE, new Type[] { Type.INT_TYPE, CALLBACK });
/*      */ 
/*      */   
/*  168 */   private static final Signature GET_CALLBACK = new Signature("getCallback", CALLBACK, new Type[] { Type.INT_TYPE });
/*      */ 
/*      */   
/*  171 */   private static final Signature SET_CALLBACKS = new Signature("setCallbacks", Type.VOID_TYPE, new Type[] { CALLBACK_ARRAY });
/*      */ 
/*      */   
/*  174 */   private static final Signature GET_CALLBACKS = new Signature("getCallbacks", CALLBACK_ARRAY, new Type[0]);
/*      */ 
/*      */ 
/*      */   
/*  178 */   private static final Signature THREAD_LOCAL_GET = TypeUtils.parseSignature("Object get()");
/*      */ 
/*      */   
/*  181 */   private static final Signature THREAD_LOCAL_SET = TypeUtils.parseSignature("void set(Object)");
/*      */ 
/*      */   
/*  184 */   private static final Signature BIND_CALLBACKS = TypeUtils.parseSignature("void CGLIB$BIND_CALLBACKS(Object)"); private EnhancerFactoryData currentData; private Object currentKey; private Class[] interfaces; private CallbackFilter filter; private Callback[] callbacks; private Type[] callbackTypes; private boolean validateCallbackTypes; private boolean classOnly; private Class superclass; private Class[] argumentTypes; private Object[] arguments;
/*      */   private static final class EnhancerKey extends Record { private final String type; private final List<String> interfaces;
/*      */     private final WeakCacheKey<CallbackFilter> filter;
/*      */     private final List<Type> callbackTypes;
/*      */     private final boolean useFactory;
/*      */     private final boolean interceptDuringConstruction;
/*      */     private final Long serialVersionUID;
/*      */     
/*  192 */     private EnhancerKey(String type, List<String> interfaces, WeakCacheKey<CallbackFilter> filter, List<Type> callbackTypes, boolean useFactory, boolean interceptDuringConstruction, Long serialVersionUID) { this.type = type; this.interfaces = interfaces; this.filter = filter; this.callbackTypes = callbackTypes; this.useFactory = useFactory; this.interceptDuringConstruction = interceptDuringConstruction; this.serialVersionUID = serialVersionUID; } public final String toString() { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> toString : (Lorg/springframework/cglib/proxy/Enhancer$EnhancerKey;)Ljava/lang/String;
/*      */       //   6: areturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #192	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*  192 */       //   0	7	0	this	Lorg/springframework/cglib/proxy/Enhancer$EnhancerKey; } public String type() { return this.type; } public final int hashCode() { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> hashCode : (Lorg/springframework/cglib/proxy/Enhancer$EnhancerKey;)I
/*      */       //   6: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #192	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/cglib/proxy/Enhancer$EnhancerKey; } public final boolean equals(Object o) { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: aload_1
/*      */       //   2: <illegal opcode> equals : (Lorg/springframework/cglib/proxy/Enhancer$EnhancerKey;Ljava/lang/Object;)Z
/*      */       //   7: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #192	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	8	0	this	Lorg/springframework/cglib/proxy/Enhancer$EnhancerKey;
/*  192 */       //   0	8	1	o	Ljava/lang/Object; } public List<String> interfaces() { return this.interfaces; } public WeakCacheKey<CallbackFilter> filter() { return this.filter; } public List<Type> callbackTypes() { return this.callbackTypes; } public boolean useFactory() { return this.useFactory; } public boolean interceptDuringConstruction() { return this.interceptDuringConstruction; } public Long serialVersionUID() { return this.serialVersionUID; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useFactory = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Long serialVersionUID;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean interceptDuringConstruction = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enhancer() {
/*  235 */     super(SOURCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSuperclass(Class superclass) {
/*  248 */     if (superclass != null && superclass.isInterface()) {
/*  249 */       setInterfaces(new Class[] { superclass });
/*      */       
/*  251 */       setContextClass(superclass);
/*      */     
/*      */     }
/*  254 */     else if (superclass != null && superclass.equals(Object.class)) {
/*      */       
/*  256 */       this.superclass = null;
/*      */     } else {
/*      */       
/*  259 */       this.superclass = superclass;
/*      */       
/*  261 */       setContextClass(superclass);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInterfaces(Class[] interfaces) {
/*  273 */     this.interfaces = interfaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallbackFilter(CallbackFilter filter) {
/*  285 */     this.filter = filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallback(Callback callback) {
/*  296 */     setCallbacks(new Callback[] { callback });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallbacks(Callback[] callbacks) {
/*  309 */     if (callbacks != null && callbacks.length == 0) {
/*  310 */       throw new IllegalArgumentException("Array cannot be empty");
/*      */     }
/*  312 */     this.callbacks = callbacks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseFactory(boolean useFactory) {
/*  325 */     this.useFactory = useFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInterceptDuringConstruction(boolean interceptDuringConstruction) {
/*  335 */     this.interceptDuringConstruction = interceptDuringConstruction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallbackType(Class callbackType) {
/*  347 */     setCallbackTypes(new Class[] { callbackType });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallbackTypes(Class[] callbackTypes) {
/*  360 */     if (callbackTypes != null && callbackTypes.length == 0) {
/*  361 */       throw new IllegalArgumentException("Array cannot be empty");
/*      */     }
/*  363 */     this.callbackTypes = CallbackInfo.determineTypes(callbackTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object create() {
/*  373 */     this.classOnly = false;
/*  374 */     this.argumentTypes = null;
/*  375 */     return createHelper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object create(Class[] argumentTypes, Object[] arguments) {
/*  388 */     this.classOnly = false;
/*  389 */     if (argumentTypes == null || arguments == null || argumentTypes.length != arguments.length) {
/*  390 */       throw new IllegalArgumentException("Arguments must be non-null and of equal length");
/*      */     }
/*  392 */     this.argumentTypes = argumentTypes;
/*  393 */     this.arguments = arguments;
/*  394 */     return createHelper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class createClass() {
/*  406 */     this.classOnly = true;
/*  407 */     return (Class)createHelper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSerialVersionUID(Long sUID) {
/*  415 */     this.serialVersionUID = sUID;
/*      */   }
/*      */   
/*      */   private void preValidate() {
/*  419 */     if (this.callbackTypes == null) {
/*  420 */       this.callbackTypes = CallbackInfo.determineTypes(this.callbacks, false);
/*  421 */       this.validateCallbackTypes = true;
/*      */     } 
/*  423 */     if (this.filter == null) {
/*  424 */       if (this.callbackTypes.length > 1) {
/*  425 */         throw new IllegalStateException("Multiple callback types possible but no filter specified");
/*      */       }
/*  427 */       this.filter = ALL_ZERO;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void validate() {
/*  432 */     if ((this.classOnly ^ ((this.callbacks == null) ? 1 : 0)) != 0) {
/*  433 */       if (this.classOnly) {
/*  434 */         throw new IllegalStateException("createClass does not accept callbacks");
/*      */       }
/*      */       
/*  437 */       throw new IllegalStateException("Callbacks are required");
/*      */     } 
/*      */     
/*  440 */     if (this.classOnly && this.callbackTypes == null) {
/*  441 */       throw new IllegalStateException("Callback types are required");
/*      */     }
/*  443 */     if (this.validateCallbackTypes) {
/*  444 */       this.callbackTypes = null;
/*      */     }
/*  446 */     if (this.callbacks != null && this.callbackTypes != null) {
/*  447 */       if (this.callbacks.length != this.callbackTypes.length) {
/*  448 */         throw new IllegalStateException("Lengths of callback and callback types array must be the same");
/*      */       }
/*  450 */       Type[] check = CallbackInfo.determineTypes(this.callbacks);
/*  451 */       for (int i = 0; i < check.length; i++) {
/*  452 */         if (!check[i].equals(this.callbackTypes[i])) {
/*  453 */           throw new IllegalStateException("Callback " + String.valueOf(check[i]) + " is not assignable to " + String.valueOf(this.callbackTypes[i]));
/*      */         }
/*      */       }
/*      */     
/*  457 */     } else if (this.callbacks != null) {
/*  458 */       this.callbackTypes = CallbackInfo.determineTypes(this.callbacks);
/*      */     } 
/*  460 */     if (this.interfaces != null) {
/*  461 */       for (Class element : this.interfaces) {
/*  462 */         if (element == null) {
/*  463 */           throw new IllegalStateException("Interfaces cannot be null");
/*      */         }
/*  465 */         if (!element.isInterface()) {
/*  466 */           throw new IllegalStateException(String.valueOf(element) + " is not an interface");
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class EnhancerFactoryData
/*      */   {
/*      */     public final Class generatedClass;
/*      */ 
/*      */     
/*      */     private final Method setThreadCallbacks;
/*      */ 
/*      */     
/*      */     private final Class[] primaryConstructorArgTypes;
/*      */     
/*      */     private final Constructor primaryConstructor;
/*      */ 
/*      */     
/*      */     public EnhancerFactoryData(Class generatedClass, Class[] primaryConstructorArgTypes, boolean classOnly) {
/*  488 */       this.generatedClass = generatedClass;
/*      */       try {
/*  490 */         this.setThreadCallbacks = Enhancer.getCallbacksSetter(generatedClass, "CGLIB$SET_THREAD_CALLBACKS");
/*  491 */         if (classOnly) {
/*  492 */           this.primaryConstructorArgTypes = null;
/*  493 */           this.primaryConstructor = null;
/*      */         } else {
/*      */           
/*  496 */           this.primaryConstructorArgTypes = primaryConstructorArgTypes;
/*  497 */           this.primaryConstructor = ReflectUtils.getConstructor(generatedClass, primaryConstructorArgTypes);
/*      */         }
/*      */       
/*  500 */       } catch (NoSuchMethodException e) {
/*  501 */         throw new CodeGenerationException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object newInstance(Class[] argumentTypes, Object[] arguments, Callback[] callbacks) {
/*  518 */       setThreadCallbacks(callbacks);
/*      */       
/*      */       try {
/*  521 */         if (this.primaryConstructorArgTypes == argumentTypes || 
/*  522 */           Arrays.equals((Object[])this.primaryConstructorArgTypes, (Object[])argumentTypes))
/*      */         {
/*      */           
/*  525 */           return ReflectUtils.newInstance(this.primaryConstructor, arguments);
/*      */         }
/*      */         
/*  528 */         return ReflectUtils.newInstance(this.generatedClass, argumentTypes, arguments);
/*      */       }
/*      */       finally {
/*      */         
/*  532 */         setThreadCallbacks(null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void setThreadCallbacks(Callback[] callbacks) {
/*      */       try {
/*  539 */         this.setThreadCallbacks.invoke(this.generatedClass, new Object[] { callbacks });
/*      */       }
/*  541 */       catch (IllegalAccessException e) {
/*  542 */         throw new CodeGenerationException(e);
/*      */       }
/*  544 */       catch (InvocationTargetException e) {
/*  545 */         throw new CodeGenerationException(e.getTargetException());
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private Object createHelper() {
/*  551 */     preValidate();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  556 */     Object key = new EnhancerKey((this.superclass != null) ? this.superclass.getName() : null, (this.interfaces != null) ? Arrays.<String>asList(ReflectUtils.getNames(this.interfaces)) : null, (this.filter == ALL_ZERO) ? null : new WeakCacheKey(this.filter), Arrays.asList(this.callbackTypes), this.useFactory, this.interceptDuringConstruction, this.serialVersionUID);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  561 */     this.currentKey = key;
/*  562 */     Object result = create(key);
/*  563 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Class generate(AbstractClassGenerator.ClassLoaderData data) {
/*  568 */     validate();
/*  569 */     if (this.superclass != null) {
/*  570 */       setNamePrefix(this.superclass.getName());
/*      */     }
/*  572 */     else if (this.interfaces != null) {
/*  573 */       setNamePrefix(this.interfaces[ReflectUtils.findPackageProtected(this.interfaces)].getName());
/*      */     } 
/*  575 */     return super.generate(data);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ClassLoader getDefaultClassLoader() {
/*  580 */     if (this.superclass != null) {
/*  581 */       return this.superclass.getClassLoader();
/*      */     }
/*  583 */     if (this.interfaces != null) {
/*  584 */       return this.interfaces[0].getClassLoader();
/*      */     }
/*      */     
/*  587 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ProtectionDomain getProtectionDomain() {
/*  593 */     if (this.superclass != null) {
/*  594 */       return ReflectUtils.getProtectionDomain(this.superclass);
/*      */     }
/*  596 */     if (this.interfaces != null) {
/*  597 */       return ReflectUtils.getProtectionDomain(this.interfaces[0]);
/*      */     }
/*      */     
/*  600 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private Signature rename(Signature sig, int index) {
/*  605 */     return new Signature("CGLIB$" + sig.getName() + "$" + index, sig
/*  606 */         .getDescriptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void getMethods(Class superclass, Class[] interfaces, List methods) {
/*  623 */     getMethods(superclass, interfaces, methods, (List)null, (Set)null);
/*      */   }
/*      */   
/*      */   private static void getMethods(Class superclass, Class[] interfaces, List methods, List interfaceMethods, Set forcePublic) {
/*  627 */     ReflectUtils.addAllMethods(superclass, methods);
/*  628 */     List target = (interfaceMethods != null) ? interfaceMethods : methods;
/*  629 */     if (interfaces != null) {
/*  630 */       for (Class<Factory> element : interfaces) {
/*  631 */         if (element != Factory.class) {
/*  632 */           ReflectUtils.addAllMethods(element, target);
/*      */         }
/*      */       } 
/*      */     }
/*  636 */     if (interfaceMethods != null) {
/*  637 */       if (forcePublic != null) {
/*  638 */         forcePublic.addAll(MethodWrapper.createSet(interfaceMethods));
/*      */       }
/*  640 */       methods.addAll(interfaceMethods);
/*      */     } 
/*  642 */     CollectionUtils.filter(methods, (Predicate)new RejectModifierPredicate(8));
/*  643 */     CollectionUtils.filter(methods, (Predicate)new VisibilityPredicate(superclass, true));
/*  644 */     CollectionUtils.filter(methods, (Predicate)new DuplicatesPredicate());
/*  645 */     CollectionUtils.filter(methods, (Predicate)new RejectModifierPredicate(16));
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateClass(ClassVisitor v) throws Exception {
/*  650 */     Class sc = (this.superclass == null) ? Object.class : this.superclass;
/*      */     
/*  652 */     if (TypeUtils.isFinal(sc.getModifiers())) {
/*  653 */       throw new IllegalArgumentException("Cannot subclass final class " + sc.getName());
/*      */     }
/*  655 */     List constructors = new ArrayList(Arrays.asList((Object[])sc.getDeclaredConstructors()));
/*  656 */     filterConstructors(sc, constructors);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  661 */     List actualMethods = new ArrayList();
/*  662 */     List interfaceMethods = new ArrayList();
/*  663 */     Set forcePublic = new HashSet();
/*  664 */     getMethods(sc, this.interfaces, actualMethods, interfaceMethods, forcePublic);
/*      */     
/*  666 */     List methods = CollectionUtils.transform(actualMethods, value -> {
/*      */           Method method = (Method)value;
/*      */ 
/*      */           
/*      */           int modifiers = 0x10 | method.getModifiers() & 0xFFFFFBFF & 0xFFFFFEFF & 0xFFFFFFDF;
/*      */           
/*      */           if (forcePublic.contains(MethodWrapper.create(method))) {
/*      */             modifiers = modifiers & 0xFFFFFFFB | 0x1;
/*      */           }
/*      */           
/*      */           return ReflectUtils.getMethodInfo(method, modifiers);
/*      */         });
/*      */     
/*  679 */     ClassEmitter e = new ClassEmitter(v);
/*  680 */     if (this.currentData == null) {
/*  681 */       e.begin_class(52, 1, 
/*      */           
/*  683 */           getClassName(), 
/*  684 */           Type.getType(sc), 
/*  685 */           this.useFactory ? 
/*  686 */           TypeUtils.add(TypeUtils.getTypes(this.interfaces), FACTORY) : 
/*  687 */           TypeUtils.getTypes(this.interfaces), "<generated>");
/*      */     }
/*      */     else {
/*      */       
/*  691 */       e.begin_class(52, 1, 
/*      */           
/*  693 */           getClassName(), null, new Type[] { FACTORY }, "<generated>");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  698 */     List constructorInfo = CollectionUtils.transform(constructors, (Transformer)MethodInfoTransformer.getInstance());
/*      */     
/*  700 */     e.declare_field(2, "CGLIB$BOUND", Type.BOOLEAN_TYPE, null);
/*  701 */     e.declare_field(9, "CGLIB$FACTORY_DATA", OBJECT_TYPE, null);
/*  702 */     if (!this.interceptDuringConstruction) {
/*  703 */       e.declare_field(2, "CGLIB$CONSTRUCTED", Type.BOOLEAN_TYPE, null);
/*      */     }
/*  705 */     e.declare_field(26, "CGLIB$THREAD_CALLBACKS", THREAD_LOCAL, null);
/*  706 */     e.declare_field(26, "CGLIB$STATIC_CALLBACKS", CALLBACK_ARRAY, null);
/*  707 */     if (this.serialVersionUID != null) {
/*  708 */       e.declare_field(26, "serialVersionUID", Type.LONG_TYPE, this.serialVersionUID);
/*      */     }
/*      */     
/*  711 */     for (int i = 0; i < this.callbackTypes.length; i++) {
/*  712 */       e.declare_field(2, getCallbackField(i), this.callbackTypes[i], null);
/*      */     }
/*      */     
/*  715 */     e.declare_field(10, "CGLIB$CALLBACK_FILTER", OBJECT_TYPE, null);
/*      */     
/*  717 */     if (this.currentData == null) {
/*  718 */       emitMethods(e, methods, actualMethods);
/*  719 */       emitConstructors(e, constructorInfo);
/*      */     } else {
/*      */       
/*  722 */       emitDefaultConstructor(e);
/*      */     } 
/*  724 */     emitSetThreadCallbacks(e);
/*  725 */     emitSetStaticCallbacks(e);
/*  726 */     emitBindCallbacks(e);
/*      */     
/*  728 */     if (this.useFactory || this.currentData != null) {
/*  729 */       int[] keys = getCallbackKeys();
/*  730 */       emitNewInstanceCallbacks(e);
/*  731 */       emitNewInstanceCallback(e);
/*  732 */       emitNewInstanceMultiarg(e, constructorInfo);
/*  733 */       emitGetCallback(e, keys);
/*  734 */       emitSetCallback(e, keys);
/*  735 */       emitGetCallbacks(e);
/*  736 */       emitSetCallbacks(e);
/*      */     } 
/*      */     
/*  739 */     e.end_class();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void filterConstructors(Class sc, List constructors) {
/*  753 */     CollectionUtils.filter(constructors, (Predicate)new VisibilityPredicate(sc, true));
/*  754 */     if (constructors.size() == 0) {
/*  755 */       throw new IllegalArgumentException("No visible constructors in " + String.valueOf(sc));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object firstInstance(Class type) throws Exception {
/*  770 */     if (this.classOnly) {
/*  771 */       return type;
/*      */     }
/*      */     
/*  774 */     return createUsingReflection(type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object nextInstance(Object instance) {
/*  780 */     EnhancerFactoryData data = (EnhancerFactoryData)instance;
/*      */     
/*  782 */     if (this.classOnly) {
/*  783 */       return data.generatedClass;
/*      */     }
/*      */     
/*  786 */     Class[] argumentTypes = this.argumentTypes;
/*  787 */     Object[] arguments = this.arguments;
/*  788 */     if (argumentTypes == null) {
/*  789 */       argumentTypes = Constants.EMPTY_CLASS_ARRAY;
/*  790 */       arguments = null;
/*      */     } 
/*  792 */     return data.newInstance(argumentTypes, arguments, this.callbacks);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object wrapCachedClass(Class klass) {
/*  797 */     Class[] argumentTypes = this.argumentTypes;
/*  798 */     if (argumentTypes == null) {
/*  799 */       argumentTypes = Constants.EMPTY_CLASS_ARRAY;
/*      */     }
/*  801 */     EnhancerFactoryData factoryData = new EnhancerFactoryData(klass, argumentTypes, this.classOnly);
/*  802 */     Field factoryDataField = null;
/*      */ 
/*      */     
/*      */     try {
/*  806 */       factoryDataField = klass.getField("CGLIB$FACTORY_DATA");
/*  807 */       factoryDataField.set(null, factoryData);
/*  808 */       Field callbackFilterField = klass.getDeclaredField("CGLIB$CALLBACK_FILTER");
/*  809 */       callbackFilterField.setAccessible(true);
/*  810 */       callbackFilterField.set(null, this.filter);
/*      */     }
/*  812 */     catch (NoSuchFieldException|IllegalAccessException e) {
/*  813 */       throw new CodeGenerationException(e);
/*      */     } 
/*  815 */     return new WeakReference<>(factoryData);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object unwrapCachedValue(Object cached) {
/*  820 */     if (this.currentKey instanceof EnhancerKey) {
/*  821 */       EnhancerFactoryData data = ((WeakReference<EnhancerFactoryData>)cached).get();
/*  822 */       return data;
/*      */     } 
/*  824 */     return super.unwrapCachedValue(cached);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerCallbacks(Class generatedClass, Callback[] callbacks) {
/*  851 */     setThreadCallbacks(generatedClass, callbacks);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerStaticCallbacks(Class generatedClass, Callback[] callbacks) {
/*  864 */     setCallbacksHelper(generatedClass, callbacks, "CGLIB$SET_STATIC_CALLBACKS");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEnhanced(Class type) {
/*      */     try {
/*  874 */       getCallbacksSetter(type, "CGLIB$SET_THREAD_CALLBACKS");
/*  875 */       return true;
/*      */     }
/*  877 */     catch (NoSuchMethodException e) {
/*  878 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void setThreadCallbacks(Class type, Callback[] callbacks) {
/*  883 */     setCallbacksHelper(type, callbacks, "CGLIB$SET_THREAD_CALLBACKS");
/*      */   }
/*      */ 
/*      */   
/*      */   private static void setCallbacksHelper(Class type, Callback[] callbacks, String methodName) {
/*      */     try {
/*  889 */       Method setter = getCallbacksSetter(type, methodName);
/*  890 */       setter.invoke(null, new Object[] { callbacks });
/*      */     }
/*  892 */     catch (NoSuchMethodException e) {
/*  893 */       throw new IllegalArgumentException(String.valueOf(type) + " is not an enhanced class");
/*      */     }
/*  895 */     catch (IllegalAccessException|InvocationTargetException e) {
/*  896 */       throw new CodeGenerationException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Method getCallbacksSetter(Class type, String methodName) throws NoSuchMethodException {
/*  901 */     return type.getDeclaredMethod(methodName, new Class[] { Callback[].class });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object createUsingReflection(Class type) {
/*  913 */     setThreadCallbacks(type, this.callbacks);
/*      */     
/*      */     try {
/*  916 */       if (this.argumentTypes != null)
/*      */       {
/*  918 */         return ReflectUtils.newInstance(type, this.argumentTypes, this.arguments);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  923 */       return ReflectUtils.newInstance(type);
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/*  929 */       setThreadCallbacks(type, (Callback[])null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object create(Class type, Callback callback) {
/*  941 */     Enhancer e = new Enhancer();
/*  942 */     e.setSuperclass(type);
/*  943 */     e.setCallback(callback);
/*  944 */     return e.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object create(Class superclass, Class[] interfaces, Callback callback) {
/*  956 */     Enhancer e = new Enhancer();
/*  957 */     e.setSuperclass(superclass);
/*  958 */     e.setInterfaces(interfaces);
/*  959 */     e.setCallback(callback);
/*  960 */     return e.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object create(Class superclass, Class[] interfaces, CallbackFilter filter, Callback[] callbacks) {
/*  973 */     Enhancer e = new Enhancer();
/*  974 */     e.setSuperclass(superclass);
/*  975 */     e.setInterfaces(interfaces);
/*  976 */     e.setCallbackFilter(filter);
/*  977 */     e.setCallbacks(callbacks);
/*  978 */     return e.create();
/*      */   }
/*      */   
/*      */   private void emitDefaultConstructor(ClassEmitter ce) {
/*      */     Constructor<Object> declaredConstructor;
/*      */     try {
/*  984 */       declaredConstructor = Object.class.getDeclaredConstructor(new Class[0]);
/*      */     }
/*  986 */     catch (NoSuchMethodException noSuchMethodException) {
/*  987 */       throw new IllegalStateException("Object should have default constructor ", noSuchMethodException);
/*      */     } 
/*  989 */     MethodInfo constructor = (MethodInfo)MethodInfoTransformer.getInstance().transform(declaredConstructor);
/*  990 */     CodeEmitter e = EmitUtils.begin_method(ce, constructor, 1);
/*  991 */     e.load_this();
/*  992 */     e.dup();
/*  993 */     Signature sig = constructor.getSignature();
/*  994 */     e.super_invoke_constructor(sig);
/*  995 */     e.return_value();
/*  996 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitConstructors(ClassEmitter ce, List constructors) {
/* 1000 */     boolean seenNull = false;
/* 1001 */     for (Iterator<MethodInfo> it = constructors.iterator(); it.hasNext(); ) {
/* 1002 */       MethodInfo constructor = it.next();
/* 1003 */       if (this.currentData != null && !"()V".equals(constructor.getSignature().getDescriptor())) {
/*      */         continue;
/*      */       }
/* 1006 */       CodeEmitter e = EmitUtils.begin_method(ce, constructor, 1);
/* 1007 */       e.load_this();
/* 1008 */       e.dup();
/* 1009 */       e.load_args();
/* 1010 */       Signature sig = constructor.getSignature();
/* 1011 */       seenNull = (seenNull || sig.getDescriptor().equals("()V"));
/* 1012 */       e.super_invoke_constructor(sig);
/* 1013 */       if (this.currentData == null) {
/* 1014 */         e.invoke_static_this(BIND_CALLBACKS);
/* 1015 */         if (!this.interceptDuringConstruction) {
/* 1016 */           e.load_this();
/* 1017 */           e.push(1);
/* 1018 */           e.putfield("CGLIB$CONSTRUCTED");
/*      */         } 
/*      */       } 
/* 1021 */       e.return_value();
/* 1022 */       e.end_method();
/*      */     } 
/* 1024 */     if (!this.classOnly && !seenNull && this.arguments == null) {
/* 1025 */       throw new IllegalArgumentException("Superclass has no null constructors but no arguments were given");
/*      */     }
/*      */   }
/*      */   
/*      */   private int[] getCallbackKeys() {
/* 1030 */     int[] keys = new int[this.callbackTypes.length];
/* 1031 */     for (int i = 0; i < this.callbackTypes.length; i++) {
/* 1032 */       keys[i] = i;
/*      */     }
/* 1034 */     return keys;
/*      */   }
/*      */   
/*      */   private void emitGetCallback(ClassEmitter ce, int[] keys) {
/* 1038 */     final CodeEmitter e = ce.begin_method(1, GET_CALLBACK, null);
/* 1039 */     e.load_this();
/* 1040 */     e.invoke_static_this(BIND_CALLBACKS);
/* 1041 */     e.load_this();
/* 1042 */     e.load_arg(0);
/* 1043 */     e.process_switch(keys, new ProcessSwitchCallback()
/*      */         {
/*      */           public void processCase(int key, Label end) {
/* 1046 */             e.getfield(Enhancer.getCallbackField(key));
/* 1047 */             e.goTo(end);
/*      */           }
/*      */ 
/*      */           
/*      */           public void processDefault() {
/* 1052 */             e.pop();
/* 1053 */             e.aconst_null();
/*      */           }
/*      */         });
/* 1056 */     e.return_value();
/* 1057 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitSetCallback(ClassEmitter ce, int[] keys) {
/* 1061 */     final CodeEmitter e = ce.begin_method(1, SET_CALLBACK, null);
/* 1062 */     e.load_arg(0);
/* 1063 */     e.process_switch(keys, new ProcessSwitchCallback()
/*      */         {
/*      */           public void processCase(int key, Label end) {
/* 1066 */             e.load_this();
/* 1067 */             e.load_arg(1);
/* 1068 */             e.checkcast(Enhancer.this.callbackTypes[key]);
/* 1069 */             e.putfield(Enhancer.getCallbackField(key));
/* 1070 */             e.goTo(end);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void processDefault() {}
/*      */         });
/* 1078 */     e.return_value();
/* 1079 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitSetCallbacks(ClassEmitter ce) {
/* 1083 */     CodeEmitter e = ce.begin_method(1, SET_CALLBACKS, null);
/* 1084 */     e.load_this();
/* 1085 */     e.load_arg(0);
/* 1086 */     for (int i = 0; i < this.callbackTypes.length; i++) {
/* 1087 */       e.dup2();
/* 1088 */       e.aaload(i);
/* 1089 */       e.checkcast(this.callbackTypes[i]);
/* 1090 */       e.putfield(getCallbackField(i));
/*      */     } 
/* 1092 */     e.return_value();
/* 1093 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitGetCallbacks(ClassEmitter ce) {
/* 1097 */     CodeEmitter e = ce.begin_method(1, GET_CALLBACKS, null);
/* 1098 */     e.load_this();
/* 1099 */     e.invoke_static_this(BIND_CALLBACKS);
/* 1100 */     e.load_this();
/* 1101 */     e.push(this.callbackTypes.length);
/* 1102 */     e.newarray(CALLBACK);
/* 1103 */     for (int i = 0; i < this.callbackTypes.length; i++) {
/* 1104 */       e.dup();
/* 1105 */       e.push(i);
/* 1106 */       e.load_this();
/* 1107 */       e.getfield(getCallbackField(i));
/* 1108 */       e.aastore();
/*      */     } 
/* 1110 */     e.return_value();
/* 1111 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitNewInstanceCallbacks(ClassEmitter ce) {
/* 1115 */     CodeEmitter e = ce.begin_method(1, NEW_INSTANCE, null);
/* 1116 */     Type thisType = getThisType(e);
/* 1117 */     e.load_arg(0);
/* 1118 */     e.invoke_static(thisType, SET_THREAD_CALLBACKS, false);
/* 1119 */     emitCommonNewInstance(e);
/*      */   }
/*      */   
/*      */   private Type getThisType(CodeEmitter e) {
/* 1123 */     if (this.currentData == null) {
/* 1124 */       return e.getClassEmitter().getClassType();
/*      */     }
/*      */     
/* 1127 */     return Type.getType(this.currentData.generatedClass);
/*      */   }
/*      */ 
/*      */   
/*      */   private void emitCommonNewInstance(CodeEmitter e) {
/* 1132 */     Type thisType = getThisType(e);
/* 1133 */     e.new_instance(thisType);
/* 1134 */     e.dup();
/* 1135 */     e.invoke_constructor(thisType);
/* 1136 */     e.aconst_null();
/* 1137 */     e.invoke_static(thisType, SET_THREAD_CALLBACKS, false);
/* 1138 */     e.return_value();
/* 1139 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitNewInstanceCallback(ClassEmitter ce) {
/* 1143 */     CodeEmitter e = ce.begin_method(1, SINGLE_NEW_INSTANCE, null);
/* 1144 */     switch (this.callbackTypes.length) {
/*      */       case 0:
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/* 1150 */         e.push(1);
/* 1151 */         e.newarray(CALLBACK);
/* 1152 */         e.dup();
/* 1153 */         e.push(0);
/* 1154 */         e.load_arg(0);
/* 1155 */         e.aastore();
/* 1156 */         e.invoke_static(getThisType(e), SET_THREAD_CALLBACKS, false);
/*      */         break;
/*      */       default:
/* 1159 */         e.throw_exception(ILLEGAL_STATE_EXCEPTION, "More than one callback object required"); break;
/*      */     } 
/* 1161 */     emitCommonNewInstance(e);
/*      */   }
/*      */   
/*      */   private void emitNewInstanceMultiarg(ClassEmitter ce, List constructors) {
/* 1165 */     final CodeEmitter e = ce.begin_method(1, MULTIARG_NEW_INSTANCE, null);
/* 1166 */     final Type thisType = getThisType(e);
/* 1167 */     e.load_arg(2);
/* 1168 */     e.invoke_static(thisType, SET_THREAD_CALLBACKS, false);
/* 1169 */     e.new_instance(thisType);
/* 1170 */     e.dup();
/* 1171 */     e.load_arg(0);
/* 1172 */     EmitUtils.constructor_switch(e, constructors, new ObjectSwitchCallback()
/*      */         {
/*      */           public void processCase(Object key, Label end) {
/* 1175 */             MethodInfo constructor = (MethodInfo)key;
/* 1176 */             Type[] types = constructor.getSignature().getArgumentTypes();
/* 1177 */             for (int i = 0; i < types.length; i++) {
/* 1178 */               e.load_arg(1);
/* 1179 */               e.push(i);
/* 1180 */               e.aaload();
/* 1181 */               e.unbox(types[i]);
/*      */             } 
/* 1183 */             e.invoke_constructor(thisType, constructor.getSignature());
/* 1184 */             e.goTo(end);
/*      */           }
/*      */ 
/*      */           
/*      */           public void processDefault() {
/* 1189 */             e.throw_exception(Enhancer.ILLEGAL_ARGUMENT_EXCEPTION, "Constructor not found");
/*      */           }
/*      */         });
/* 1192 */     e.aconst_null();
/* 1193 */     e.invoke_static(thisType, SET_THREAD_CALLBACKS, false);
/* 1194 */     e.return_value();
/* 1195 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitMethods(ClassEmitter ce, List methods, List<E> actualMethods) {
/* 1199 */     CallbackGenerator[] generators = CallbackInfo.getGenerators(this.callbackTypes);
/*      */     
/* 1201 */     Map<Object, Object> groups = new HashMap<>();
/* 1202 */     final Map<Object, Object> indexes = new HashMap<>();
/* 1203 */     final Map<Object, Object> originalModifiers = new HashMap<>();
/* 1204 */     final Map positions = CollectionUtils.getIndexMap(methods);
/* 1205 */     Map<Object, Object> declToBridge = new HashMap<>();
/*      */     
/* 1207 */     Iterator<MethodInfo> it1 = methods.iterator();
/* 1208 */     Iterator<E> it2 = (actualMethods != null) ? actualMethods.iterator() : null;
/*      */     
/* 1210 */     while (it1.hasNext()) {
/* 1211 */       MethodInfo method = it1.next();
/* 1212 */       Method actualMethod = (it2 != null) ? (Method)it2.next() : null;
/* 1213 */       int index = this.filter.accept(actualMethod);
/* 1214 */       if (index >= this.callbackTypes.length) {
/* 1215 */         throw new IllegalArgumentException("Callback filter returned an index that is too large: " + index);
/*      */       }
/* 1217 */       originalModifiers.put(method, Integer.valueOf((actualMethod != null) ? actualMethod.getModifiers() : method.getModifiers()));
/* 1218 */       indexes.put(method, Integer.valueOf(index));
/* 1219 */       List<MethodInfo> group = (List)groups.get(generators[index]);
/* 1220 */       if (group == null) {
/* 1221 */         groups.put(generators[index], group = new ArrayList(methods.size()));
/*      */       }
/* 1223 */       group.add(method);
/*      */ 
/*      */ 
/*      */       
/* 1227 */       if (TypeUtils.isBridge(actualMethod.getModifiers())) {
/* 1228 */         Set<Signature> bridges = (Set)declToBridge.get(actualMethod.getDeclaringClass());
/* 1229 */         if (bridges == null) {
/* 1230 */           bridges = new HashSet();
/* 1231 */           declToBridge.put(actualMethod.getDeclaringClass(), bridges);
/*      */         } 
/* 1233 */         bridges.add(method.getSignature());
/*      */       } 
/*      */     } 
/*      */     
/* 1237 */     final Map bridgeToTarget = (new BridgeMethodResolver(declToBridge, getClassLoader())).resolveAll();
/*      */     
/* 1239 */     Set<CallbackGenerator> seenGen = new HashSet();
/* 1240 */     CodeEmitter se = ce.getStaticHook();
/* 1241 */     se.new_instance(THREAD_LOCAL);
/* 1242 */     se.dup();
/* 1243 */     se.invoke_constructor(THREAD_LOCAL, CSTRUCT_NULL);
/* 1244 */     se.putfield("CGLIB$THREAD_CALLBACKS");
/*      */     
/* 1246 */     CallbackGenerator.Context context = new CallbackGenerator.Context()
/*      */       {
/*      */         public ClassLoader getClassLoader() {
/* 1249 */           return Enhancer.this.getClassLoader();
/*      */         }
/*      */ 
/*      */         
/*      */         public int getOriginalModifiers(MethodInfo method) {
/* 1254 */           return ((Integer)originalModifiers.get(method)).intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public int getIndex(MethodInfo method) {
/* 1259 */           return ((Integer)indexes.get(method)).intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public void emitCallback(CodeEmitter e, int index) {
/* 1264 */           Enhancer.this.emitCurrentCallback(e, index);
/*      */         }
/*      */ 
/*      */         
/*      */         public Signature getImplSignature(MethodInfo method) {
/* 1269 */           return Enhancer.this.rename(method.getSignature(), ((Integer)positions.get(method)).intValue());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void emitLoadArgsAndInvoke(CodeEmitter e, MethodInfo method) {
/* 1278 */           Signature bridgeTarget = (Signature)bridgeToTarget.get(method.getSignature());
/* 1279 */           if (bridgeTarget != null) {
/*      */             
/* 1281 */             Type[] argTypes = method.getSignature().getArgumentTypes();
/* 1282 */             Type[] targetTypes = bridgeTarget.getArgumentTypes();
/* 1283 */             for (int i = 0; i < targetTypes.length; i++) {
/* 1284 */               e.load_arg(i);
/* 1285 */               Type argType = argTypes[i];
/* 1286 */               Type type1 = targetTypes[i];
/* 1287 */               if (!type1.equals(argType)) {
/* 1288 */                 if (!TypeUtils.isPrimitive(type1)) {
/* 1289 */                   e.box(argType);
/*      */                 }
/* 1291 */                 e.checkcast(type1);
/*      */               } 
/*      */             } 
/*      */             
/* 1295 */             e.invoke_virtual_this(bridgeTarget);
/*      */ 
/*      */             
/* 1298 */             Type retType = method.getSignature().getReturnType();
/* 1299 */             Type target = bridgeTarget.getReturnType();
/* 1300 */             if (!target.equals(retType)) {
/* 1301 */               if (!TypeUtils.isPrimitive(target)) {
/* 1302 */                 e.unbox(retType);
/*      */               } else {
/*      */                 
/* 1305 */                 e.checkcast(retType);
/*      */               } 
/*      */             }
/*      */           } else {
/*      */             
/* 1310 */             e.load_args();
/* 1311 */             e.super_invoke(method.getSignature());
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public CodeEmitter beginMethod(ClassEmitter ce, MethodInfo method) {
/* 1317 */           CodeEmitter e = EmitUtils.begin_method(ce, method);
/* 1318 */           if (!Enhancer.this.interceptDuringConstruction && 
/* 1319 */             !TypeUtils.isAbstract(method.getModifiers())) {
/* 1320 */             Label constructed = e.make_label();
/* 1321 */             e.load_this();
/* 1322 */             e.getfield("CGLIB$CONSTRUCTED");
/* 1323 */             e.if_jump(154, constructed);
/* 1324 */             e.load_this();
/* 1325 */             e.load_args();
/* 1326 */             e.super_invoke();
/* 1327 */             e.return_value();
/* 1328 */             e.mark(constructed);
/*      */           } 
/* 1330 */           return e;
/*      */         }
/*      */       };
/* 1333 */     for (int i = 0; i < this.callbackTypes.length; i++) {
/* 1334 */       CallbackGenerator gen = generators[i];
/* 1335 */       if (!seenGen.contains(gen)) {
/* 1336 */         seenGen.add(gen);
/* 1337 */         List fmethods = (List)groups.get(gen);
/* 1338 */         if (fmethods != null) {
/*      */           try {
/* 1340 */             gen.generate(ce, context, fmethods);
/* 1341 */             gen.generateStatic(se, context, fmethods);
/*      */           }
/* 1343 */           catch (RuntimeException x) {
/* 1344 */             throw x;
/*      */           }
/* 1346 */           catch (Exception x) {
/* 1347 */             throw new CodeGenerationException(x);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1352 */     se.return_value();
/* 1353 */     se.end_method();
/*      */   }
/*      */   
/*      */   private void emitSetThreadCallbacks(ClassEmitter ce) {
/* 1357 */     CodeEmitter e = ce.begin_method(9, SET_THREAD_CALLBACKS, null);
/*      */ 
/*      */     
/* 1360 */     e.getfield("CGLIB$THREAD_CALLBACKS");
/* 1361 */     e.load_arg(0);
/* 1362 */     e.invoke_virtual(THREAD_LOCAL, THREAD_LOCAL_SET);
/* 1363 */     e.return_value();
/* 1364 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitSetStaticCallbacks(ClassEmitter ce) {
/* 1368 */     CodeEmitter e = ce.begin_method(9, SET_STATIC_CALLBACKS, null);
/*      */ 
/*      */     
/* 1371 */     e.load_arg(0);
/* 1372 */     e.putfield("CGLIB$STATIC_CALLBACKS");
/* 1373 */     e.return_value();
/* 1374 */     e.end_method();
/*      */   }
/*      */   
/*      */   private void emitCurrentCallback(CodeEmitter e, int index) {
/* 1378 */     e.load_this();
/* 1379 */     e.getfield(getCallbackField(index));
/* 1380 */     e.dup();
/* 1381 */     Label end = e.make_label();
/* 1382 */     e.ifnonnull(end);
/* 1383 */     e.pop();
/* 1384 */     e.load_this();
/* 1385 */     e.invoke_static_this(BIND_CALLBACKS);
/* 1386 */     e.load_this();
/* 1387 */     e.getfield(getCallbackField(index));
/* 1388 */     e.mark(end);
/*      */   }
/*      */   
/*      */   private void emitBindCallbacks(ClassEmitter ce) {
/* 1392 */     CodeEmitter e = ce.begin_method(26, BIND_CALLBACKS, null);
/*      */ 
/*      */     
/* 1395 */     Local me = e.make_local();
/* 1396 */     e.load_arg(0);
/* 1397 */     e.checkcast_this();
/* 1398 */     e.store_local(me);
/*      */     
/* 1400 */     Label end = e.make_label();
/* 1401 */     e.load_local(me);
/* 1402 */     e.getfield("CGLIB$BOUND");
/* 1403 */     e.if_jump(154, end);
/* 1404 */     e.load_local(me);
/* 1405 */     e.push(1);
/* 1406 */     e.putfield("CGLIB$BOUND");
/*      */     
/* 1408 */     e.getfield("CGLIB$THREAD_CALLBACKS");
/* 1409 */     e.invoke_virtual(THREAD_LOCAL, THREAD_LOCAL_GET);
/* 1410 */     e.dup();
/* 1411 */     Label found_callback = e.make_label();
/* 1412 */     e.ifnonnull(found_callback);
/* 1413 */     e.pop();
/*      */     
/* 1415 */     e.getfield("CGLIB$STATIC_CALLBACKS");
/* 1416 */     e.dup();
/* 1417 */     e.ifnonnull(found_callback);
/* 1418 */     e.pop();
/* 1419 */     e.goTo(end);
/*      */     
/* 1421 */     e.mark(found_callback);
/* 1422 */     e.checkcast(CALLBACK_ARRAY);
/* 1423 */     e.load_local(me);
/* 1424 */     e.swap();
/* 1425 */     for (int i = this.callbackTypes.length - 1; i >= 0; i--) {
/* 1426 */       if (i != 0) {
/* 1427 */         e.dup2();
/*      */       }
/* 1429 */       e.aaload(i);
/* 1430 */       e.checkcast(this.callbackTypes[i]);
/* 1431 */       e.putfield(getCallbackField(i));
/*      */     } 
/*      */     
/* 1434 */     e.mark(end);
/* 1435 */     e.return_value();
/* 1436 */     e.end_method();
/*      */   }
/*      */   
/*      */   private static String getCallbackField(int index) {
/* 1440 */     return "CGLIB$CALLBACK_" + index;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\Enhancer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */