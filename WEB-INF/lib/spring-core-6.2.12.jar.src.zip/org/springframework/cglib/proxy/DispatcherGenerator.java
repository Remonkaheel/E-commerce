/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.cglib.core.ClassEmitter;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DispatcherGenerator
/*    */   implements CallbackGenerator
/*    */ {
/* 30 */   public static final DispatcherGenerator INSTANCE = new DispatcherGenerator(false);
/*    */   
/* 32 */   public static final DispatcherGenerator PROXY_REF_INSTANCE = new DispatcherGenerator(true);
/*    */ 
/*    */ 
/*    */   
/* 36 */   private static final Type DISPATCHER = TypeUtils.parseType("org.springframework.cglib.proxy.Dispatcher");
/*    */   
/* 38 */   private static final Type PROXY_REF_DISPATCHER = TypeUtils.parseType("org.springframework.cglib.proxy.ProxyRefDispatcher");
/*    */   
/* 40 */   private static final Signature LOAD_OBJECT = TypeUtils.parseSignature("Object loadObject()");
/*    */   
/* 42 */   private static final Signature PROXY_REF_LOAD_OBJECT = TypeUtils.parseSignature("Object loadObject(Object)");
/*    */   
/*    */   private boolean proxyRef;
/*    */   
/*    */   private DispatcherGenerator(boolean proxyRef) {
/* 47 */     this.proxyRef = proxyRef;
/*    */   }
/*    */ 
/*    */   
/*    */   public void generate(ClassEmitter ce, CallbackGenerator.Context context, List methods) {
/* 52 */     for (Iterator<MethodInfo> it = methods.iterator(); it.hasNext(); ) {
/* 53 */       MethodInfo method = it.next();
/* 54 */       if (!TypeUtils.isProtected(method.getModifiers())) {
/* 55 */         CodeEmitter e = context.beginMethod(ce, method);
/* 56 */         context.emitCallback(e, context.getIndex(method));
/* 57 */         if (this.proxyRef) {
/* 58 */           e.load_this();
/* 59 */           e.invoke_interface(PROXY_REF_DISPATCHER, PROXY_REF_LOAD_OBJECT);
/*    */         } else {
/* 61 */           e.invoke_interface(DISPATCHER, LOAD_OBJECT);
/*    */         } 
/* 63 */         e.checkcast(method.getClassInfo().getType());
/* 64 */         e.load_args();
/* 65 */         e.invoke(method);
/* 66 */         e.return_value();
/* 67 */         e.end_method();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void generateStatic(CodeEmitter e, CallbackGenerator.Context context, List methods) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\DispatcherGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */