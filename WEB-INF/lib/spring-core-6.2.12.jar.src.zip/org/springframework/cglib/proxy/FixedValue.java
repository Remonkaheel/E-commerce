package org.springframework.cglib.proxy;

public interface FixedValue extends Callback {
  Object loadObject() throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\FixedValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */