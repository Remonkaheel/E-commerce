/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CallbackHelper
/*     */   implements CallbackFilter
/*     */ {
/*  33 */   private Map methodMap = new HashMap<>();
/*  34 */   private List callbacks = new ArrayList();
/*     */   
/*     */   public CallbackHelper(Class superclass, Class[] interfaces) {
/*  37 */     List<Method> methods = new ArrayList();
/*  38 */     Enhancer.getMethods(superclass, interfaces, methods);
/*  39 */     Map<Object, Object> indexes = new HashMap<>();
/*  40 */     for (int i = 0, size = methods.size(); i < size; i++) {
/*  41 */       Method method = methods.get(i);
/*  42 */       Object callback = getCallback(method);
/*  43 */       if (callback == null) {
/*  44 */         throw new IllegalStateException("getCallback cannot return null");
/*     */       }
/*  46 */       boolean isCallback = callback instanceof Callback;
/*  47 */       if (!isCallback && !(callback instanceof Class)) {
/*  48 */         throw new IllegalStateException("getCallback must return a Callback or a Class");
/*     */       }
/*  50 */       if (i > 0 && this.callbacks.get(i - 1) instanceof Callback ^ isCallback) {
/*  51 */         throw new IllegalStateException("getCallback must return a Callback or a Class consistently for every Method");
/*     */       }
/*  53 */       Integer index = (Integer)indexes.get(callback);
/*  54 */       if (index == null) {
/*  55 */         index = Integer.valueOf(this.callbacks.size());
/*  56 */         indexes.put(callback, index);
/*     */       } 
/*  58 */       this.methodMap.put(method, index);
/*  59 */       this.callbacks.add(callback);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract Object getCallback(Method paramMethod);
/*     */   
/*     */   public Callback[] getCallbacks() {
/*  66 */     if (this.callbacks.size() == 0) {
/*  67 */       return new Callback[0];
/*     */     }
/*  69 */     if (this.callbacks.get(0) instanceof Callback) {
/*  70 */       return (Callback[])this.callbacks.toArray((Object[])new Callback[this.callbacks.size()]);
/*     */     }
/*     */     
/*  73 */     throw new IllegalStateException("getCallback returned classes, not callbacks; call getCallbackTypes instead");
/*     */   }
/*     */ 
/*     */   
/*     */   public Class[] getCallbackTypes() {
/*  78 */     if (this.callbacks.size() == 0) {
/*  79 */       return new Class[0];
/*     */     }
/*  81 */     if (this.callbacks.get(0) instanceof Callback) {
/*  82 */       return ReflectUtils.getClasses((Object[])getCallbacks());
/*     */     }
/*     */     
/*  85 */     return (Class[])this.callbacks.toArray((Object[])new Class[this.callbacks.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int accept(Method method) {
/*  91 */     return ((Integer)this.methodMap.get(method)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  96 */     return this.methodMap.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     CallbackHelper other;
/* 101 */     if (o == null) {
/* 102 */       return false;
/*     */     }
/* 104 */     if (o instanceof CallbackHelper) { other = (CallbackHelper)o; }
/* 105 */     else { return false; }
/*     */     
/* 107 */     return this.methodMap.equals(other.methodMap);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\CallbackHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */