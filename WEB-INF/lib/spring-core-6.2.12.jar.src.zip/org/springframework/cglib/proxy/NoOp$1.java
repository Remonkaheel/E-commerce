package org.springframework.cglib.proxy;

class null implements NoOp {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\NoOp$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */