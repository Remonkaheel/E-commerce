/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CallbackInfo
/*     */ {
/*     */   private Class cls;
/*     */   private CallbackGenerator generator;
/*     */   private Type type;
/*     */   
/*     */   public static Type[] determineTypes(Class[] callbackTypes) {
/*  24 */     return determineTypes(callbackTypes, true);
/*     */   }
/*     */   
/*     */   public static Type[] determineTypes(Class[] callbackTypes, boolean checkAll) {
/*  28 */     Type[] types = new Type[callbackTypes.length];
/*  29 */     for (int i = 0; i < types.length; i++) {
/*  30 */       types[i] = determineType(callbackTypes[i], checkAll);
/*     */     }
/*  32 */     return types;
/*     */   }
/*     */   
/*     */   public static Type[] determineTypes(Callback[] callbacks) {
/*  36 */     return determineTypes(callbacks, true);
/*     */   }
/*     */   
/*     */   public static Type[] determineTypes(Callback[] callbacks, boolean checkAll) {
/*  40 */     Type[] types = new Type[callbacks.length];
/*  41 */     for (int i = 0; i < types.length; i++) {
/*  42 */       types[i] = determineType(callbacks[i], checkAll);
/*     */     }
/*  44 */     return types;
/*     */   }
/*     */   
/*     */   public static CallbackGenerator[] getGenerators(Type[] callbackTypes) {
/*  48 */     CallbackGenerator[] generators = new CallbackGenerator[callbackTypes.length];
/*  49 */     for (int i = 0; i < generators.length; i++) {
/*  50 */       generators[i] = getGenerator(callbackTypes[i]);
/*     */     }
/*  52 */     return generators;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static final CallbackInfo[] CALLBACKS = new CallbackInfo[] { new CallbackInfo(NoOp.class, NoOpGenerator.INSTANCE), new CallbackInfo(MethodInterceptor.class, MethodInterceptorGenerator.INSTANCE), new CallbackInfo(InvocationHandler.class, InvocationHandlerGenerator.INSTANCE), new CallbackInfo(LazyLoader.class, LazyLoaderGenerator.INSTANCE), new CallbackInfo(Dispatcher.class, DispatcherGenerator.INSTANCE), new CallbackInfo(FixedValue.class, FixedValueGenerator.INSTANCE), new CallbackInfo(ProxyRefDispatcher.class, DispatcherGenerator.PROXY_REF_INSTANCE) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CallbackInfo(Class cls, CallbackGenerator generator) {
/*  72 */     this.cls = cls;
/*  73 */     this.generator = generator;
/*  74 */     this.type = Type.getType(cls);
/*     */   }
/*     */   
/*     */   private static Type determineType(Callback callback, boolean checkAll) {
/*  78 */     if (callback == null) {
/*  79 */       throw new IllegalStateException("Callback is null");
/*     */     }
/*  81 */     return determineType(callback.getClass(), checkAll);
/*     */   }
/*     */   
/*     */   private static Type determineType(Class<?> callbackType, boolean checkAll) {
/*  85 */     Class cur = null;
/*  86 */     Type type = null;
/*  87 */     for (CallbackInfo info : CALLBACKS) {
/*  88 */       if (info.cls.isAssignableFrom(callbackType)) {
/*  89 */         if (cur != null) {
/*  90 */           throw new IllegalStateException("Callback implements both " + String.valueOf(cur) + " and " + String.valueOf(info.cls));
/*     */         }
/*  92 */         cur = info.cls;
/*  93 */         type = info.type;
/*  94 */         if (!checkAll) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*  99 */     if (cur == null) {
/* 100 */       throw new IllegalStateException("Unknown callback type " + String.valueOf(callbackType));
/*     */     }
/* 102 */     return type;
/*     */   }
/*     */   
/*     */   private static CallbackGenerator getGenerator(Type callbackType) {
/* 106 */     for (CallbackInfo info : CALLBACKS) {
/* 107 */       if (info.type.equals(callbackType)) {
/* 108 */         return info.generator;
/*     */       }
/*     */     } 
/* 111 */     throw new IllegalStateException("Unknown callback type " + String.valueOf(callbackType));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\CallbackInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */