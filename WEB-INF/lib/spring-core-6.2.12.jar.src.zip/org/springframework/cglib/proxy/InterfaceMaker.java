/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterfaceMaker
/*     */   extends AbstractClassGenerator
/*     */ {
/*  42 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(InterfaceMaker.class.getName());
/*  43 */   private Map signatures = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InterfaceMaker() {
/*  51 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Signature sig, Type[] exceptions) {
/*  60 */     this.signatures.put(sig, exceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Method method) {
/*  69 */     add(ReflectUtils.getSignature(method), 
/*  70 */         ReflectUtils.getExceptionTypes(method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Class clazz) {
/*  80 */     Method[] methods = clazz.getMethods();
/*  81 */     for (Method m : methods) {
/*  82 */       if (!m.getDeclaringClass().getName().equals("java.lang.Object")) {
/*  83 */         add(m);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class create() {
/*  92 */     setUseCache(false);
/*  93 */     return (Class)create(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 103 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 108 */     throw new IllegalStateException("InterfaceMaker does not cache");
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) throws Exception {
/* 113 */     ClassEmitter ce = new ClassEmitter(v);
/* 114 */     ce.begin_class(52, 1537, 
/*     */         
/* 116 */         getClassName(), null, null, "<generated>");
/*     */ 
/*     */ 
/*     */     
/* 120 */     for (Iterator<Signature> it = this.signatures.keySet().iterator(); it.hasNext(); ) {
/* 121 */       Signature sig = it.next();
/* 122 */       Type[] exceptions = (Type[])this.signatures.get(sig);
/* 123 */       ce.begin_method(1025, sig, exceptions)
/*     */         
/* 125 */         .end_method();
/*     */     } 
/* 127 */     ce.end_class();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\InterfaceMaker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */