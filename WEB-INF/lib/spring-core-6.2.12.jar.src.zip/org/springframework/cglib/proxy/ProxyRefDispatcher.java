package org.springframework.cglib.proxy;

public interface ProxyRefDispatcher extends Callback {
  Object loadObject(Object paramObject) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\ProxyRefDispatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */