/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ClassesKey;
/*     */ import org.springframework.cglib.core.KeyFactory;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Mixin
/*     */ {
/*  43 */   private static final MixinKey KEY_FACTORY = (MixinKey)KeyFactory.create(MixinKey.class, KeyFactory.CLASS_BY_NAME);
/*  44 */   private static final Map ROUTE_CACHE = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int STYLE_INTERFACES = 0;
/*     */ 
/*     */   
/*     */   public static final int STYLE_BEANS = 1;
/*     */ 
/*     */   
/*     */   public static final int STYLE_EVERYTHING = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Mixin newInstance(Object[] paramArrayOfObject);
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mixin create(Object[] delegates) {
/*  63 */     Generator gen = new Generator();
/*  64 */     gen.setDelegates(delegates);
/*  65 */     return gen.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mixin create(Class[] interfaces, Object[] delegates) {
/*  75 */     Generator gen = new Generator();
/*  76 */     gen.setClasses(interfaces);
/*  77 */     gen.setDelegates(delegates);
/*  78 */     return gen.create();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mixin createBean(Object[] beans) {
/*  84 */     return createBean(null, beans);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mixin createBean(ClassLoader loader, Object[] beans) {
/*  94 */     Generator gen = new Generator();
/*  95 */     gen.setStyle(1);
/*  96 */     gen.setDelegates(beans);
/*  97 */     gen.setClassLoader(loader);
/*  98 */     return gen.create();
/*     */   }
/*     */   
/*     */   public static class Generator extends AbstractClassGenerator {
/* 102 */     private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(Mixin.class.getName());
/*     */     
/*     */     private Class[] classes;
/*     */     private Object[] delegates;
/* 106 */     private int style = 0;
/*     */     
/*     */     private int[] route;
/*     */     
/*     */     public Generator() {
/* 111 */       super(SOURCE);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ClassLoader getDefaultClassLoader() {
/* 116 */       return this.classes[0].getClassLoader();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ProtectionDomain getProtectionDomain() {
/* 121 */       return ReflectUtils.getProtectionDomain(this.classes[0]);
/*     */     }
/*     */     
/*     */     public void setStyle(int style) {
/* 125 */       switch (style) {
/*     */         case 0:
/*     */         case 1:
/*     */         case 2:
/* 129 */           this.style = style;
/*     */           return;
/*     */       } 
/* 132 */       throw new IllegalArgumentException("Unknown mixin style: " + style);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setClasses(Class[] classes) {
/* 137 */       this.classes = classes;
/*     */     }
/*     */     
/*     */     public void setDelegates(Object[] delegates) {
/* 141 */       this.delegates = delegates;
/*     */     }
/*     */     
/*     */     public Mixin create() {
/* 145 */       if (this.classes == null && this.delegates == null) {
/* 146 */         throw new IllegalStateException("Either classes or delegates must be set");
/*     */       }
/* 148 */       switch (this.style) {
/*     */         case 0:
/* 150 */           if (this.classes == null) {
/* 151 */             Mixin.Route r = Mixin.route(this.delegates);
/* 152 */             this.classes = r.classes;
/* 153 */             this.route = r.route;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 1:
/*     */         case 2:
/* 159 */           if (this.classes == null) {
/* 160 */             this.classes = ReflectUtils.getClasses(this.delegates); break;
/*     */           } 
/* 162 */           if (this.delegates != null) {
/* 163 */             Class[] temp = ReflectUtils.getClasses(this.delegates);
/* 164 */             if (this.classes.length != temp.length) {
/* 165 */               throw new IllegalStateException("Specified classes are incompatible with delegates");
/*     */             }
/* 167 */             for (int i = 0; i < this.classes.length; i++) {
/* 168 */               if (!this.classes[i].isAssignableFrom(temp[i])) {
/* 169 */                 throw new IllegalStateException("Specified class " + String.valueOf(this.classes[i]) + " is incompatible with delegate class " + String.valueOf(temp[i]) + " (index " + i + ")");
/*     */               }
/*     */             } 
/*     */           } 
/*     */           break;
/*     */       } 
/* 175 */       setNamePrefix(this.classes[ReflectUtils.findPackageProtected(this.classes)].getName());
/*     */       
/* 177 */       return (Mixin)create(Mixin.KEY_FACTORY.newInstance(this.style, ReflectUtils.getNames(this.classes), this.route));
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateClass(ClassVisitor v) {
/* 182 */       switch (this.style) {
/*     */         case 0:
/* 184 */           new MixinEmitter(v, getClassName(), this.classes, this.route);
/*     */           break;
/*     */         case 1:
/* 187 */           new MixinBeanEmitter(v, getClassName(), this.classes);
/*     */           break;
/*     */         case 2:
/* 190 */           new MixinEverythingEmitter(v, getClassName(), this.classes);
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object firstInstance(Class type) {
/* 197 */       return ((Mixin)ReflectUtils.newInstance(type)).newInstance(this.delegates);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextInstance(Object instance) {
/* 202 */       return ((Mixin)instance).newInstance(this.delegates);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Class[] getClasses(Object[] delegates) {
/* 207 */     return (Class[])(route(delegates)).classes.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Route route(Object[] delegates) {
/* 215 */     Object key = ClassesKey.create(delegates);
/* 216 */     Route route = (Route)ROUTE_CACHE.get(key);
/* 217 */     if (route == null) {
/* 218 */       ROUTE_CACHE.put(key, route = new Route(delegates));
/*     */     }
/* 220 */     return route;
/*     */   }
/*     */   
/*     */   private static class Route
/*     */   {
/*     */     private Class[] classes;
/*     */     private int[] route;
/*     */     
/*     */     Route(Object[] delegates) {
/* 229 */       Map<Object, Object> map = new HashMap<>();
/* 230 */       ArrayList collect = new ArrayList();
/* 231 */       for (int i = 0; i < delegates.length; i++) {
/* 232 */         Class<?> delegate = delegates[i].getClass();
/* 233 */         collect.clear();
/* 234 */         ReflectUtils.addAllInterfaces(delegate, collect);
/* 235 */         for (Iterator<Class<?>> iterator = collect.iterator(); iterator.hasNext(); ) {
/* 236 */           Class iface = iterator.next();
/* 237 */           if (!map.containsKey(iface)) {
/* 238 */             map.put(iface, Integer.valueOf(i));
/*     */           }
/*     */         } 
/*     */       } 
/* 242 */       this.classes = new Class[map.size()];
/* 243 */       this.route = new int[map.size()];
/* 244 */       int index = 0;
/* 245 */       for (Iterator<Class<?>> it = map.keySet().iterator(); it.hasNext(); ) {
/* 246 */         Class key = it.next();
/* 247 */         this.classes[index] = key;
/* 248 */         this.route[index] = ((Integer)map.get(key)).intValue();
/* 249 */         index++;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static interface MixinKey {
/*     */     Object newInstance(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\Mixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */