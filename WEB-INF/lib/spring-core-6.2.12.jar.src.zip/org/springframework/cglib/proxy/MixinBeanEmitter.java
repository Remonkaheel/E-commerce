/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.ReflectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MixinBeanEmitter
/*    */   extends MixinEmitter
/*    */ {
/*    */   public MixinBeanEmitter(ClassVisitor v, String className, Class[] classes) {
/* 30 */     super(v, className, classes, null);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class[] getInterfaces(Class[] classes) {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Method[] getMethods(Class type) {
/* 40 */     return ReflectUtils.getPropertyMethods(ReflectUtils.getBeanProperties(type), true, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\MixinBeanEmitter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */