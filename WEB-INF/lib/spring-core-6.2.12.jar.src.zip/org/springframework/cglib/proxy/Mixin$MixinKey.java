package org.springframework.cglib.proxy;

interface MixinKey {
  Object newInstance(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\Mixin$MixinKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */