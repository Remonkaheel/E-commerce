/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.cglib.core.ClassEmitter;
/*    */ import org.springframework.cglib.core.CodeEmitter;
/*    */ import org.springframework.cglib.core.EmitUtils;
/*    */ import org.springframework.cglib.core.MethodInfo;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NoOpGenerator
/*    */   implements CallbackGenerator
/*    */ {
/* 31 */   public static final NoOpGenerator INSTANCE = new NoOpGenerator();
/*    */ 
/*    */   
/*    */   public void generate(ClassEmitter ce, CallbackGenerator.Context context, List methods) {
/* 35 */     for (Iterator<MethodInfo> it = methods.iterator(); it.hasNext(); ) {
/* 36 */       MethodInfo method = it.next();
/* 37 */       if (TypeUtils.isBridge(method.getModifiers()) || (
/* 38 */         TypeUtils.isProtected(context.getOriginalModifiers(method)) && 
/* 39 */         TypeUtils.isPublic(method.getModifiers()))) {
/* 40 */         CodeEmitter e = EmitUtils.begin_method(ce, method);
/* 41 */         e.load_this();
/* 42 */         context.emitLoadArgsAndInvoke(e, method);
/* 43 */         e.return_value();
/* 44 */         e.end_method();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void generateStatic(CodeEmitter e, CallbackGenerator.Context context, List methods) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\NoOpGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */