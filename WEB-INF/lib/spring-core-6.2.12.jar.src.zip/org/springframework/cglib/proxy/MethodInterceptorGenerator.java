/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.ClassEmitter;
/*     */ import org.springframework.cglib.core.ClassInfo;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.CollectionUtils;
/*     */ import org.springframework.cglib.core.Constants;
/*     */ import org.springframework.cglib.core.EmitUtils;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.core.Transformer;
/*     */ import org.springframework.cglib.core.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodInterceptorGenerator
/*     */   implements CallbackGenerator
/*     */ {
/*  43 */   public static final MethodInterceptorGenerator INSTANCE = new MethodInterceptorGenerator();
/*     */   
/*     */   static final String EMPTY_ARGS_NAME = "CGLIB$emptyArgs";
/*     */   static final String FIND_PROXY_NAME = "CGLIB$findMethodProxy";
/*  47 */   static final Class[] FIND_PROXY_TYPES = new Class[] { Signature.class };
/*     */ 
/*     */   
/*  50 */   private static final Type ABSTRACT_METHOD_ERROR = TypeUtils.parseType("AbstractMethodError");
/*     */   
/*  52 */   private static final Type METHOD = TypeUtils.parseType("java.lang.reflect.Method");
/*     */   
/*  54 */   private static final Type REFLECT_UTILS = TypeUtils.parseType("org.springframework.cglib.core.ReflectUtils");
/*     */   
/*  56 */   private static final Type METHOD_PROXY = TypeUtils.parseType("org.springframework.cglib.proxy.MethodProxy");
/*     */   
/*  58 */   private static final Type METHOD_INTERCEPTOR = TypeUtils.parseType("org.springframework.cglib.proxy.MethodInterceptor");
/*     */   
/*  60 */   private static final Signature GET_DECLARED_METHODS = TypeUtils.parseSignature("java.lang.reflect.Method[] getDeclaredMethods()");
/*     */   
/*  62 */   private static final Signature FIND_METHODS = TypeUtils.parseSignature("java.lang.reflect.Method[] findMethods(String[], java.lang.reflect.Method[])");
/*  63 */   private static final Signature MAKE_PROXY = new Signature("create", METHOD_PROXY, new Type[] { Constants.TYPE_CLASS, Constants.TYPE_CLASS, Constants.TYPE_STRING, Constants.TYPE_STRING, Constants.TYPE_STRING });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final Signature INTERCEPT = new Signature("intercept", Constants.TYPE_OBJECT, new Type[] { Constants.TYPE_OBJECT, METHOD, Constants.TYPE_OBJECT_ARRAY, METHOD_PROXY });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final Signature FIND_PROXY = new Signature("CGLIB$findMethodProxy", METHOD_PROXY, new Type[] { Constants.TYPE_SIGNATURE });
/*     */   
/*     */   private static final Transformer METHOD_TO_CLASS;
/*  81 */   private static final Signature TO_STRING = TypeUtils.parseSignature("String toString()"); static {
/*  82 */     METHOD_TO_CLASS = (value -> ((MethodInfo)value).getClassInfo());
/*     */   }
/*     */   private String getMethodField(Signature impl) {
/*  85 */     return impl.getName() + "$Method";
/*     */   }
/*     */   private String getMethodProxyField(Signature impl) {
/*  88 */     return impl.getName() + "$Proxy";
/*     */   }
/*     */ 
/*     */   
/*     */   public void generate(ClassEmitter ce, CallbackGenerator.Context context, List methods) {
/*  93 */     Map<Object, Object> sigMap = new HashMap<>();
/*  94 */     for (Iterator<MethodInfo> it = methods.iterator(); it.hasNext(); ) {
/*  95 */       MethodInfo method = it.next();
/*  96 */       Signature sig = method.getSignature();
/*  97 */       Signature impl = context.getImplSignature(method);
/*     */       
/*  99 */       String methodField = getMethodField(impl);
/* 100 */       String methodProxyField = getMethodProxyField(impl);
/*     */       
/* 102 */       sigMap.put(sig.toString(), methodProxyField);
/* 103 */       ce.declare_field(26, methodField, METHOD, null);
/* 104 */       ce.declare_field(26, methodProxyField, METHOD_PROXY, null);
/* 105 */       ce.declare_field(26, "CGLIB$emptyArgs", Constants.TYPE_OBJECT_ARRAY, null);
/*     */ 
/*     */ 
/*     */       
/* 109 */       CodeEmitter e = ce.begin_method(16, impl, method
/*     */           
/* 111 */           .getExceptionTypes());
/* 112 */       superHelper(e, method, context);
/* 113 */       e.return_value();
/* 114 */       e.end_method();
/*     */ 
/*     */       
/* 117 */       e = context.beginMethod(ce, method);
/* 118 */       Label nullInterceptor = e.make_label();
/* 119 */       context.emitCallback(e, context.getIndex(method));
/* 120 */       e.dup();
/* 121 */       e.ifnull(nullInterceptor);
/*     */       
/* 123 */       e.load_this();
/* 124 */       e.getfield(methodField);
/*     */       
/* 126 */       if ((sig.getArgumentTypes()).length == 0) {
/* 127 */         e.getfield("CGLIB$emptyArgs");
/*     */       } else {
/* 129 */         e.create_arg_array();
/*     */       } 
/*     */       
/* 132 */       e.getfield(methodProxyField);
/* 133 */       e.invoke_interface(METHOD_INTERCEPTOR, INTERCEPT);
/* 134 */       e.unbox_or_zero(sig.getReturnType());
/* 135 */       e.return_value();
/*     */       
/* 137 */       e.mark(nullInterceptor);
/* 138 */       superHelper(e, method, context);
/* 139 */       e.return_value();
/* 140 */       e.end_method();
/*     */     } 
/* 142 */     generateFindProxy(ce, sigMap);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void superHelper(CodeEmitter e, MethodInfo method, CallbackGenerator.Context context) {
/* 147 */     if (TypeUtils.isAbstract(method.getModifiers())) {
/* 148 */       e.throw_exception(ABSTRACT_METHOD_ERROR, method.toString() + " is abstract");
/*     */     } else {
/* 150 */       e.load_this();
/* 151 */       context.emitLoadArgsAndInvoke(e, method);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateStatic(CodeEmitter e, CallbackGenerator.Context context, List methods) throws Exception {
/* 170 */     e.push(0);
/* 171 */     e.newarray();
/* 172 */     e.putfield("CGLIB$emptyArgs");
/*     */     
/* 174 */     Local thisclass = e.make_local();
/* 175 */     Local declaringclass = e.make_local();
/* 176 */     EmitUtils.load_class_this(e);
/* 177 */     e.store_local(thisclass);
/*     */     
/* 179 */     Map methodsByClass = CollectionUtils.bucket(methods, METHOD_TO_CLASS);
/* 180 */     for (Iterator<ClassInfo> i = methodsByClass.keySet().iterator(); i.hasNext(); ) {
/* 181 */       ClassInfo classInfo = i.next();
/*     */       
/* 183 */       List<MethodInfo> classMethods = (List)methodsByClass.get(classInfo);
/* 184 */       e.push(2 * classMethods.size());
/* 185 */       e.newarray(Constants.TYPE_STRING); int index;
/* 186 */       for (index = 0; index < classMethods.size(); index++) {
/* 187 */         MethodInfo method = classMethods.get(index);
/* 188 */         Signature sig = method.getSignature();
/* 189 */         e.dup();
/* 190 */         e.push(2 * index);
/* 191 */         e.push(sig.getName());
/* 192 */         e.aastore();
/* 193 */         e.dup();
/* 194 */         e.push(2 * index + 1);
/* 195 */         e.push(sig.getDescriptor());
/* 196 */         e.aastore();
/*     */       } 
/*     */       
/* 199 */       EmitUtils.load_class(e, classInfo.getType());
/* 200 */       e.dup();
/* 201 */       e.store_local(declaringclass);
/* 202 */       e.invoke_virtual(Constants.TYPE_CLASS, GET_DECLARED_METHODS);
/* 203 */       e.invoke_static(REFLECT_UTILS, FIND_METHODS);
/*     */       
/* 205 */       for (index = 0; index < classMethods.size(); index++) {
/* 206 */         MethodInfo method = classMethods.get(index);
/* 207 */         Signature sig = method.getSignature();
/* 208 */         Signature impl = context.getImplSignature(method);
/* 209 */         e.dup();
/* 210 */         e.push(index);
/* 211 */         e.array_load(METHOD);
/* 212 */         e.putfield(getMethodField(impl));
/*     */         
/* 214 */         e.load_local(declaringclass);
/* 215 */         e.load_local(thisclass);
/* 216 */         e.push(sig.getDescriptor());
/* 217 */         e.push(sig.getName());
/* 218 */         e.push(impl.getName());
/* 219 */         e.invoke_static(METHOD_PROXY, MAKE_PROXY);
/* 220 */         e.putfield(getMethodProxyField(impl));
/*     */       } 
/* 222 */       e.pop();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void generateFindProxy(ClassEmitter ce, final Map sigMap) {
/* 227 */     final CodeEmitter e = ce.begin_method(9, FIND_PROXY, null);
/*     */ 
/*     */     
/* 230 */     e.load_arg(0);
/* 231 */     e.invoke_virtual(Constants.TYPE_OBJECT, TO_STRING);
/* 232 */     ObjectSwitchCallback callback = new ObjectSwitchCallback()
/*     */       {
/*     */         public void processCase(Object key, Label end) {
/* 235 */           e.getfield((String)sigMap.get(key));
/* 236 */           e.return_value();
/*     */         }
/*     */         
/*     */         public void processDefault() {
/* 240 */           e.aconst_null();
/* 241 */           e.return_value();
/*     */         }
/*     */       };
/* 244 */     EmitUtils.string_switch(e, (String[])sigMap
/* 245 */         .keySet().toArray((Object[])new String[0]), 1, callback);
/*     */ 
/*     */     
/* 248 */     e.end_method();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\MethodInterceptorGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */