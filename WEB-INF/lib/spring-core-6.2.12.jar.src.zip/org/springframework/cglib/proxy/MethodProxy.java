/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.GeneratorStrategy;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.reflect.FastClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodProxy
/*     */ {
/*     */   private Signature sig1;
/*     */   private Signature sig2;
/*     */   private CreateInfo createInfo;
/*  45 */   private final Object initLock = new Object();
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile FastClassInfo fastClassInfo;
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodProxy create(Class<Object> c1, Class<?> c2, String desc, String name1, String name2) {
/*  54 */     MethodProxy proxy = new MethodProxy();
/*  55 */     proxy.sig1 = new Signature(name1, desc);
/*  56 */     proxy.sig2 = new Signature(name2, desc);
/*  57 */     proxy.createInfo = new CreateInfo(c1, c2);
/*     */ 
/*     */     
/*  60 */     if (c1 != Object.class && c1.isAssignableFrom(c2.getSuperclass()) && !Factory.class.isAssignableFrom(c2)) {
/*     */       
/*     */       try {
/*  63 */         proxy.init();
/*     */       }
/*  65 */       catch (CodeGenerationException codeGenerationException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     return proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/*  83 */     if (this.fastClassInfo == null) {
/*  84 */       synchronized (this.initLock) {
/*  85 */         if (this.fastClassInfo == null) {
/*  86 */           CreateInfo ci = this.createInfo;
/*     */           
/*  88 */           FastClassInfo fci = new FastClassInfo();
/*  89 */           fci.f1 = helper(ci, ci.c1);
/*  90 */           fci.f2 = helper(ci, ci.c2);
/*  91 */           fci.i1 = fci.f1.getIndex(this.sig1);
/*  92 */           fci.i2 = fci.f2.getIndex(this.sig2);
/*  93 */           this.fastClassInfo = fci;
/*  94 */           this.createInfo = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class FastClassInfo
/*     */   {
/*     */     FastClass f1;
/*     */     
/*     */     FastClass f2;
/*     */     
/*     */     int i1;
/*     */     
/*     */     int i2;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CreateInfo
/*     */   {
/*     */     Class c1;
/*     */     
/*     */     Class c2;
/*     */     
/*     */     NamingPolicy namingPolicy;
/*     */     
/*     */     GeneratorStrategy strategy;
/*     */     
/*     */     boolean attemptLoad;
/*     */     
/*     */     public CreateInfo(Class c1, Class c2) {
/* 126 */       this.c1 = c1;
/* 127 */       this.c2 = c2;
/* 128 */       AbstractClassGenerator fromEnhancer = AbstractClassGenerator.getCurrent();
/* 129 */       if (fromEnhancer != null) {
/* 130 */         this.namingPolicy = fromEnhancer.getNamingPolicy();
/* 131 */         this.strategy = fromEnhancer.getStrategy();
/* 132 */         this.attemptLoad = fromEnhancer.getAttemptLoad();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static FastClass helper(CreateInfo ci, Class type) {
/* 139 */     FastClass.Generator g = new FastClass.Generator();
/* 140 */     g.setType(type);
/*     */     
/* 142 */     g.setContextClass(type);
/*     */     
/* 144 */     g.setClassLoader(ci.c2.getClassLoader());
/* 145 */     g.setNamingPolicy(ci.namingPolicy);
/* 146 */     g.setStrategy(ci.strategy);
/* 147 */     g.setAttemptLoad(ci.attemptLoad);
/* 148 */     return g.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Signature getSignature() {
/* 158 */     return this.sig1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuperName() {
/* 168 */     return this.sig2.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSuperIndex() {
/* 179 */     init();
/* 180 */     return this.fastClassInfo.i2;
/*     */   }
/*     */ 
/*     */   
/*     */   FastClass getFastClass() {
/* 185 */     init();
/* 186 */     return this.fastClassInfo.f1;
/*     */   }
/*     */ 
/*     */   
/*     */   FastClass getSuperFastClass() {
/* 191 */     init();
/* 192 */     return this.fastClassInfo.f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodProxy find(Class type, Signature sig) {
/*     */     try {
/* 205 */       Method m = type.getDeclaredMethod("CGLIB$findMethodProxy", MethodInterceptorGenerator.FIND_PROXY_TYPES);
/*     */       
/* 207 */       return (MethodProxy)m.invoke(null, new Object[] { sig });
/*     */     }
/* 209 */     catch (NoSuchMethodException ex) {
/* 210 */       throw new IllegalArgumentException("Class " + String.valueOf(type) + " does not use a MethodInterceptor");
/*     */     }
/* 212 */     catch (IllegalAccessException|InvocationTargetException ex) {
/* 213 */       throw new CodeGenerationException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object obj, Object[] args) throws Throwable {
/*     */     try {
/* 229 */       init();
/* 230 */       FastClassInfo fci = this.fastClassInfo;
/* 231 */       return fci.f1.invoke(fci.i1, obj, args);
/*     */     }
/* 233 */     catch (InvocationTargetException ex) {
/* 234 */       throw ex.getTargetException();
/*     */     }
/* 236 */     catch (IllegalArgumentException ex) {
/* 237 */       if (this.fastClassInfo.i1 < 0) {
/* 238 */         throw new IllegalArgumentException("Protected method: " + String.valueOf(this.sig1));
/*     */       }
/* 240 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invokeSuper(Object obj, Object[] args) throws Throwable {
/*     */     try {
/* 256 */       init();
/* 257 */       FastClassInfo fci = this.fastClassInfo;
/* 258 */       return fci.f2.invoke(fci.i2, obj, args);
/*     */     }
/* 260 */     catch (InvocationTargetException e) {
/* 261 */       throw e.getTargetException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\MethodProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */