/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.cglib.core.AbstractClassGenerator;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   extends AbstractClassGenerator
/*     */ {
/* 102 */   private static final AbstractClassGenerator.Source SOURCE = new AbstractClassGenerator.Source(Mixin.class.getName());
/*     */   
/*     */   private Class[] classes;
/*     */   private Object[] delegates;
/* 106 */   private int style = 0;
/*     */   
/*     */   private int[] route;
/*     */   
/*     */   public Generator() {
/* 111 */     super(SOURCE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassLoader getDefaultClassLoader() {
/* 116 */     return this.classes[0].getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProtectionDomain getProtectionDomain() {
/* 121 */     return ReflectUtils.getProtectionDomain(this.classes[0]);
/*     */   }
/*     */   
/*     */   public void setStyle(int style) {
/* 125 */     switch (style) {
/*     */       case 0:
/*     */       case 1:
/*     */       case 2:
/* 129 */         this.style = style;
/*     */         return;
/*     */     } 
/* 132 */     throw new IllegalArgumentException("Unknown mixin style: " + style);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClasses(Class[] classes) {
/* 137 */     this.classes = classes;
/*     */   }
/*     */   
/*     */   public void setDelegates(Object[] delegates) {
/* 141 */     this.delegates = delegates;
/*     */   }
/*     */   
/*     */   public Mixin create() {
/* 145 */     if (this.classes == null && this.delegates == null) {
/* 146 */       throw new IllegalStateException("Either classes or delegates must be set");
/*     */     }
/* 148 */     switch (this.style) {
/*     */       case 0:
/* 150 */         if (this.classes == null) {
/* 151 */           Mixin.Route r = Mixin.route(this.delegates);
/* 152 */           this.classes = r.classes;
/* 153 */           this.route = r.route;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 159 */         if (this.classes == null) {
/* 160 */           this.classes = ReflectUtils.getClasses(this.delegates); break;
/*     */         } 
/* 162 */         if (this.delegates != null) {
/* 163 */           Class[] temp = ReflectUtils.getClasses(this.delegates);
/* 164 */           if (this.classes.length != temp.length) {
/* 165 */             throw new IllegalStateException("Specified classes are incompatible with delegates");
/*     */           }
/* 167 */           for (int i = 0; i < this.classes.length; i++) {
/* 168 */             if (!this.classes[i].isAssignableFrom(temp[i])) {
/* 169 */               throw new IllegalStateException("Specified class " + String.valueOf(this.classes[i]) + " is incompatible with delegate class " + String.valueOf(temp[i]) + " (index " + i + ")");
/*     */             }
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/* 175 */     setNamePrefix(this.classes[ReflectUtils.findPackageProtected(this.classes)].getName());
/*     */     
/* 177 */     return (Mixin)create(Mixin.KEY_FACTORY.newInstance(this.style, ReflectUtils.getNames(this.classes), this.route));
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateClass(ClassVisitor v) {
/* 182 */     switch (this.style) {
/*     */       case 0:
/* 184 */         new MixinEmitter(v, getClassName(), this.classes, this.route);
/*     */         break;
/*     */       case 1:
/* 187 */         new MixinBeanEmitter(v, getClassName(), this.classes);
/*     */         break;
/*     */       case 2:
/* 190 */         new MixinEverythingEmitter(v, getClassName(), this.classes);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object firstInstance(Class type) {
/* 197 */     return ((Mixin)ReflectUtils.newInstance(type)).newInstance(this.delegates);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object nextInstance(Object instance) {
/* 202 */     return ((Mixin)instance).newInstance(this.delegates);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\org\springframework\cglib\proxy\Mixin$Generator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */