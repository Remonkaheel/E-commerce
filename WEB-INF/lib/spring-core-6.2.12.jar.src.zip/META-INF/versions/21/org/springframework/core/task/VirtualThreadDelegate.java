/*    */ package META-INF.versions.21.org.springframework.core.task;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class VirtualThreadDelegate
/*    */ {
/* 31 */   private final Thread.Builder threadBuilder = Thread.ofVirtual();
/*    */   
/*    */   public ThreadFactory virtualThreadFactory() {
/* 34 */     return this.threadBuilder.factory();
/*    */   }
/*    */   
/*    */   public ThreadFactory virtualThreadFactory(String threadNamePrefix) {
/* 38 */     return this.threadBuilder.name(threadNamePrefix, 0L).factory();
/*    */   }
/*    */   
/*    */   public Thread newVirtualThread(String name, Runnable task) {
/* 42 */     return this.threadBuilder.name(name).unstarted(task);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-core-6.2.12.jar!\META-INF\versions\21\org\springframework\core\task\VirtualThreadDelegate.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */