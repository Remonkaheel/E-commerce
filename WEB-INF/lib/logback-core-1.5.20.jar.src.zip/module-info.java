module ch.qos.logback.core {
  requires java.base;
  requires transitive java.xml;
  requires java.sql;
  requires java.naming;
  requires janino;
  requires commons.compiler;
  requires jakarta.mail;
  requires jakarta.servlet;
  requires org.fusesource.jansi;
  requires org.tukaani.xz;
  
  exports ch.qos.logback.core;
  exports ch.qos.logback.core.boolex;
  exports ch.qos.logback.core.encoder;
  exports ch.qos.logback.core.helpers;
  exports ch.qos.logback.core.html;
  exports ch.qos.logback.core.filter;
  exports ch.qos.logback.core.hook;
  exports ch.qos.logback.core.joran;
  exports ch.qos.logback.core.joran.action;
  exports ch.qos.logback.core.joran.conditional;
  exports ch.qos.logback.core.joran.event;
  exports ch.qos.logback.core.joran.sanity;
  exports ch.qos.logback.core.joran.spi;
  exports ch.qos.logback.core.joran.util;
  exports ch.qos.logback.core.joran.util.beans;
  exports ch.qos.logback.core.layout;
  exports ch.qos.logback.core.model;
  exports ch.qos.logback.core.model.conditional;
  exports ch.qos.logback.core.model.processor;
  exports ch.qos.logback.core.model.processor.conditional;
  exports ch.qos.logback.core.model.util;
  exports ch.qos.logback.core.net;
  exports ch.qos.logback.core.net.server;
  exports ch.qos.logback.core.net.ssl;
  exports ch.qos.logback.core.pattern;
  exports ch.qos.logback.core.pattern.color;
  exports ch.qos.logback.core.pattern.parser;
  exports ch.qos.logback.core.recovery;
  exports ch.qos.logback.core.read;
  exports ch.qos.logback.core.rolling;
  exports ch.qos.logback.core.rolling.helper;
  exports ch.qos.logback.core.sift;
  exports ch.qos.logback.core.spi;
  exports ch.qos.logback.core.status;
  exports ch.qos.logback.core.testUtil;
  exports ch.qos.logback.core.util;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */