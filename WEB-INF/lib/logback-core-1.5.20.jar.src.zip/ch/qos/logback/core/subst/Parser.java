/*     */ package ch.qos.logback.core.subst;
/*     */ 
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser
/*     */ {
/*     */   public static final String EXPECTING_DATA_AFTER_LEFT_ACCOLADE = "Expecting at least a literal between left accolade and ':-'";
/*     */   final List<Token> tokenList;
/*  45 */   int pointer = 0;
/*     */   
/*     */   public Parser(List<Token> tokenList) {
/*  48 */     this.tokenList = tokenList;
/*     */   }
/*     */   
/*     */   public Node parse() throws ScanException {
/*  52 */     if (this.tokenList == null || this.tokenList.isEmpty())
/*  53 */       return null; 
/*  54 */     return E();
/*     */   }
/*     */   
/*     */   private Node E() throws ScanException {
/*  58 */     Node t = T();
/*  59 */     if (t == null) {
/*  60 */       return null;
/*     */     }
/*  62 */     Node eOpt = Eopt();
/*  63 */     if (eOpt != null) {
/*  64 */       t.append(eOpt);
/*     */     }
/*  66 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   private Node Eopt() throws ScanException {
/*  71 */     Token next = peekAtCurentToken();
/*  72 */     if (next == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     return E();
/*     */   }
/*     */   private Node T() throws ScanException {
/*     */     Node innerNode;
/*     */     Token right;
/*     */     Node curlyLeft, v;
/*  81 */     Token w, t = peekAtCurentToken();
/*  82 */     if (t == null) {
/*  83 */       return null;
/*     */     }
/*  85 */     switch (t.type) {
/*     */       case LITERAL:
/*  87 */         advanceTokenPointer();
/*  88 */         return makeNewLiteralNode(t.payload);
/*     */       case CURLY_LEFT:
/*  90 */         advanceTokenPointer();
/*  91 */         innerNode = C();
/*  92 */         right = peekAtCurentToken();
/*  93 */         expectCurlyRight(right);
/*  94 */         advanceTokenPointer();
/*  95 */         curlyLeft = makeNewLiteralNode(CoreConstants.LEFT_ACCOLADE);
/*  96 */         curlyLeft.append(innerNode);
/*  97 */         curlyLeft.append(makeNewLiteralNode(CoreConstants.RIGHT_ACCOLADE));
/*  98 */         return curlyLeft;
/*     */       case START:
/* 100 */         advanceTokenPointer();
/* 101 */         v = V();
/* 102 */         w = peekAtCurentToken();
/* 103 */         expectCurlyRight(w);
/* 104 */         advanceTokenPointer();
/* 105 */         return v;
/*     */     } 
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Node makeNewLiteralNode(String s) {
/* 112 */     return new Node(Node.Type.LITERAL, s);
/*     */   }
/*     */ 
/*     */   
/*     */   private Node V() throws ScanException {
/* 117 */     Node e = E();
/* 118 */     Node variable = new Node(Node.Type.VARIABLE, e);
/* 119 */     Token t = peekAtCurentToken();
/* 120 */     if (isDefaultToken(t)) {
/* 121 */       advanceTokenPointer();
/* 122 */       Node def = Eopt();
/* 123 */       if (def != null) {
/* 124 */         variable.defaultPart = def;
/*     */       } else {
/* 126 */         variable.defaultPart = makeNewLiteralNode("");
/*     */       } 
/*     */     } 
/* 129 */     return variable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Node C() throws ScanException {
/* 135 */     Node e0 = E();
/* 136 */     Token t = peekAtCurentToken();
/* 137 */     if (isDefaultToken(t)) {
/* 138 */       advanceTokenPointer();
/* 139 */       Node literal = makeNewLiteralNode(":-");
/* 140 */       if (e0 == null) {
/* 141 */         throw new ScanException("Expecting at least a literal between left accolade and ':-'");
/*     */       }
/* 143 */       e0.append(literal);
/* 144 */       Node e1 = E();
/* 145 */       e0.append(e1);
/*     */     } 
/* 147 */     return e0;
/*     */   }
/*     */   
/*     */   private boolean isDefaultToken(Token t) {
/* 151 */     return (t != null && t.type == Token.Type.DEFAULT);
/*     */   }
/*     */   
/*     */   void advanceTokenPointer() {
/* 155 */     this.pointer++;
/*     */   }
/*     */   
/*     */   void expectNotNull(Token t, String expected) {
/* 159 */     if (t == null) {
/* 160 */       throw new IllegalArgumentException("All tokens consumed but was expecting \"" + expected + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */   void expectCurlyRight(Token t) throws ScanException {
/* 165 */     expectNotNull(t, "}");
/* 166 */     if (t.type != Token.Type.CURLY_RIGHT) {
/* 167 */       throw new ScanException("Expecting }");
/*     */     }
/*     */   }
/*     */   
/*     */   Token peekAtCurentToken() {
/* 172 */     if (this.pointer < this.tokenList.size()) {
/* 173 */       return this.tokenList.get(this.pointer);
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\subst\Parser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */