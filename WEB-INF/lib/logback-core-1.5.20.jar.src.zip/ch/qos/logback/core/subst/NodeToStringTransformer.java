/*     */ package ch.qos.logback.core.subst;
/*     */ 
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeToStringTransformer
/*     */ {
/*     */   public static final String CIRCULAR_VARIABLE_REFERENCE_DETECTED = "Circular variable reference detected while parsing input [";
/*     */   final Node node;
/*     */   final PropertyContainer propertyContainer0;
/*     */   final PropertyContainer propertyContainer1;
/*     */   
/*     */   public NodeToStringTransformer(Node node, PropertyContainer propertyContainer0, PropertyContainer propertyContainer1) {
/*  39 */     this.node = node;
/*  40 */     this.propertyContainer0 = propertyContainer0;
/*  41 */     this.propertyContainer1 = propertyContainer1;
/*     */   }
/*     */   
/*     */   public NodeToStringTransformer(Node node, PropertyContainer propertyContainer0) {
/*  45 */     this(node, propertyContainer0, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String substituteVariable(String input, PropertyContainer pc0, PropertyContainer pc1) throws ScanException {
/*  50 */     Node node = tokenizeAndParseString(input);
/*  51 */     NodeToStringTransformer nodeToStringTransformer = new NodeToStringTransformer(node, pc0, pc1);
/*  52 */     return nodeToStringTransformer.transform();
/*     */   }
/*     */   
/*     */   private static Node tokenizeAndParseString(String value) throws ScanException {
/*  56 */     Tokenizer tokenizer = new Tokenizer(value);
/*  57 */     List<Token> tokens = tokenizer.tokenize();
/*  58 */     Parser parser = new Parser(tokens);
/*  59 */     return parser.parse();
/*     */   }
/*     */   
/*     */   public String transform() throws ScanException {
/*  63 */     StringBuilder stringBuilder = new StringBuilder();
/*  64 */     compileNode(this.node, stringBuilder, new Stack<>());
/*  65 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private void compileNode(Node inputNode, StringBuilder stringBuilder, Stack<Node> cycleCheckStack) throws ScanException {
/*  70 */     Node n = inputNode;
/*  71 */     while (n != null) {
/*  72 */       switch (n.type) {
/*     */         case LITERAL:
/*  74 */           handleLiteral(n, stringBuilder);
/*     */           break;
/*     */         case VARIABLE:
/*  77 */           handleVariable(n, stringBuilder, cycleCheckStack);
/*     */           break;
/*     */       } 
/*  80 */       n = n.next;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleVariable(Node n, StringBuilder stringBuilder, Stack<Node> cycleCheckStack) throws ScanException {
/*  87 */     if (haveVisitedNodeAlready(n, cycleCheckStack)) {
/*  88 */       cycleCheckStack.push(n);
/*  89 */       String error = constructRecursionErrorMessage(cycleCheckStack);
/*  90 */       throw new IllegalArgumentException(error);
/*     */     } 
/*  92 */     cycleCheckStack.push(n);
/*     */     
/*  94 */     StringBuilder keyBuffer = new StringBuilder();
/*  95 */     Node payload = (Node)n.payload;
/*  96 */     compileNode(payload, keyBuffer, cycleCheckStack);
/*  97 */     String key = keyBuffer.toString();
/*  98 */     String value = lookupKey(key);
/*     */ 
/*     */     
/* 101 */     if (value != null) {
/* 102 */       Node innerNode = tokenizeAndParseString(value);
/* 103 */       compileNode(innerNode, stringBuilder, cycleCheckStack);
/* 104 */       cycleCheckStack.pop();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 109 */     if (n.defaultPart == null) {
/* 110 */       stringBuilder.append(key + "_IS_UNDEFINED");
/* 111 */       cycleCheckStack.pop();
/*     */       
/*     */       return;
/*     */     } 
/* 115 */     Node defaultPart = (Node)n.defaultPart;
/* 116 */     StringBuilder defaultPartBuffer = new StringBuilder();
/* 117 */     compileNode(defaultPart, defaultPartBuffer, cycleCheckStack);
/* 118 */     cycleCheckStack.pop();
/* 119 */     String defaultVal = defaultPartBuffer.toString();
/* 120 */     stringBuilder.append(defaultVal);
/*     */   }
/*     */   
/*     */   private String lookupKey(String key) {
/* 124 */     String value = this.propertyContainer0.getProperty(key);
/* 125 */     if (value != null) {
/* 126 */       return value;
/*     */     }
/* 128 */     if (this.propertyContainer1 != null) {
/* 129 */       value = this.propertyContainer1.getProperty(key);
/* 130 */       if (value != null) {
/* 131 */         return value;
/*     */       }
/*     */     } 
/* 134 */     value = OptionHelper.getSystemProperty(key, null);
/* 135 */     if (value != null) {
/* 136 */       return value;
/*     */     }
/* 138 */     value = OptionHelper.getEnv(key);
/* 139 */     if (value != null) {
/* 140 */       return value;
/*     */     }
/*     */     
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   private void handleLiteral(Node n, StringBuilder stringBuilder) {
/* 147 */     stringBuilder.append((String)n.payload);
/*     */   }
/*     */   
/*     */   private String variableNodeValue(Node variableNode) {
/* 151 */     Node payload = (Node)variableNode.payload;
/* 152 */     if (payload == null) {
/* 153 */       return "";
/*     */     }
/*     */     
/* 156 */     if (payload.type == Node.Type.LITERAL) {
/* 157 */       return (String)payload.payload;
/*     */     }
/*     */     
/* 160 */     if (payload.type == Node.Type.VARIABLE) {
/* 161 */       return " ? " + variableNodeValue(payload);
/*     */     }
/* 163 */     throw new IllegalStateException("unreachable code");
/*     */   }
/*     */   
/*     */   private String constructRecursionErrorMessage(Stack<Node> recursionNodes) {
/* 167 */     StringBuilder errorBuilder = new StringBuilder("Circular variable reference detected while parsing input [");
/*     */     
/* 169 */     for (Node stackNode : recursionNodes) {
/* 170 */       errorBuilder.append("${").append(variableNodeValue(stackNode)).append("}");
/* 171 */       if (recursionNodes.lastElement() != stackNode) {
/* 172 */         errorBuilder.append(" --> ");
/*     */       }
/*     */     } 
/* 175 */     errorBuilder.append("]");
/* 176 */     return errorBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean haveVisitedNodeAlready(Node node, Stack<Node> cycleDetectionStack) {
/* 186 */     for (Node cycleNode : cycleDetectionStack) {
/* 187 */       if (equalNodes(node, cycleNode)) {
/* 188 */         return true;
/*     */       }
/*     */     } 
/* 191 */     return false;
/*     */   }
/*     */   
/*     */   private boolean equalNodes(Node node1, Node node2) {
/* 195 */     if (node1.type != null && !node1.type.equals(node2.type))
/* 196 */       return false; 
/* 197 */     if (node1.payload != null && !node1.payload.equals(node2.payload))
/* 198 */       return false; 
/* 199 */     if (node1.defaultPart != null && !node1.defaultPart.equals(node2.defaultPart)) {
/* 200 */       return false;
/*     */     }
/* 202 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\subst\NodeToStringTransformer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */