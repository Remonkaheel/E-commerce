package ch.qos.logback.core.html;

public class NOPThrowableRenderer implements IThrowableRenderer<Object> {
  public void render(StringBuilder sbuf, Object event) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\html\NOPThrowableRenderer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */