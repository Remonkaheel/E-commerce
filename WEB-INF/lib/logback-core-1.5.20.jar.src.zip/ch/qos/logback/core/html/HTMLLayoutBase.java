/*     */ package ch.qos.logback.core.html;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import ch.qos.logback.core.LayoutBase;
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.pattern.ConverterUtil;
/*     */ import ch.qos.logback.core.pattern.DynamicConverter;
/*     */ import ch.qos.logback.core.pattern.parser.Node;
/*     */ import ch.qos.logback.core.pattern.parser.Parser;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HTMLLayoutBase<E>
/*     */   extends LayoutBase<E>
/*     */ {
/*     */   protected String pattern;
/*     */   protected Converter<E> head;
/*  44 */   protected String title = "Logback Log Messages";
/*     */ 
/*     */ 
/*     */   
/*     */   protected CssBuilder cssBuilder;
/*     */ 
/*     */   
/*  51 */   protected long counter = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(String conversionPattern) {
/*  59 */     this.pattern = conversionPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/*  66 */     return this.pattern;
/*     */   }
/*     */   
/*     */   public CssBuilder getCssBuilder() {
/*  70 */     return this.cssBuilder;
/*     */   }
/*     */   
/*     */   public void setCssBuilder(CssBuilder cssBuilder) {
/*  74 */     this.cssBuilder = cssBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  82 */     int errorCount = 0;
/*     */     
/*     */     try {
/*  85 */       Parser<E> p = new Parser(this.pattern);
/*  86 */       p.setContext(getContext());
/*  87 */       Node t = p.parse();
/*  88 */       this.head = p.compile(t, getEffectiveConverterMap());
/*  89 */       ConverterUtil.startConverters(this.head);
/*  90 */     } catch (ScanException ex) {
/*  91 */       addError("Incorrect pattern found", (Throwable)ex);
/*  92 */       errorCount++;
/*     */     } 
/*     */     
/*  95 */     if (errorCount == 0) {
/*  96 */       this.started = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Map<String, Supplier<DynamicConverter>> getDefaultConverterSupplierMap();
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Supplier<DynamicConverter>> getEffectiveConverterMap() {
/* 107 */     Map<String, Supplier<DynamicConverter>> effectiveMap = new HashMap<>();
/*     */ 
/*     */     
/* 110 */     Map<String, Supplier<DynamicConverter>> defaultSupplierMap = getDefaultConverterSupplierMap();
/* 111 */     if (defaultSupplierMap != null) {
/* 112 */       effectiveMap.putAll(defaultSupplierMap);
/*     */     }
/*     */ 
/*     */     
/* 116 */     Context context = getContext();
/* 117 */     if (context != null) {
/*     */ 
/*     */       
/* 120 */       Map<String, Supplier<DynamicConverter>> contextMap = (Map<String, Supplier<DynamicConverter>>)context.getObject("PATTERN_RULE_REGISTRY_FOR_SUPPLIERS");
/* 121 */       if (contextMap != null) {
/* 122 */         effectiveMap.putAll(contextMap);
/*     */       }
/*     */     } 
/* 125 */     return effectiveMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTitle(String title) {
/* 136 */     this.title = title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTitle() {
/* 143 */     return this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 151 */     return "text/html";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileHeader() {
/* 159 */     StringBuilder sbuf = new StringBuilder();
/* 160 */     sbuf.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"");
/* 161 */     sbuf.append(" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
/* 162 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 163 */     sbuf.append("<html>");
/* 164 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 165 */     sbuf.append("  <head>");
/* 166 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 167 */     sbuf.append("    <title>");
/* 168 */     sbuf.append(this.title);
/* 169 */     sbuf.append("</title>");
/* 170 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/*     */     
/* 172 */     this.cssBuilder.addCss(sbuf);
/*     */     
/* 174 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 175 */     sbuf.append("  </head>");
/* 176 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 177 */     sbuf.append("<body>");
/* 178 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/*     */     
/* 180 */     return sbuf.toString();
/*     */   }
/*     */   
/*     */   public String getPresentationHeader() {
/* 184 */     StringBuilder sbuf = new StringBuilder();
/* 185 */     sbuf.append("<hr/>");
/* 186 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 187 */     sbuf.append("<p>Log session start time ");
/* 188 */     sbuf.append(new Date());
/* 189 */     sbuf.append("</p><p></p>");
/* 190 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 191 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 192 */     sbuf.append("<table cellspacing=\"0\">");
/* 193 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/*     */     
/* 195 */     buildHeaderRowForTable(sbuf);
/*     */     
/* 197 */     return sbuf.toString();
/*     */   }
/*     */   
/*     */   private void buildHeaderRowForTable(StringBuilder sbuf) {
/* 201 */     Converter<E> c = this.head;
/*     */     
/* 203 */     sbuf.append("<tr class=\"header\">");
/* 204 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 205 */     while (c != null) {
/* 206 */       String name = computeConverterName(c);
/* 207 */       if (name == null) {
/* 208 */         c = c.getNext();
/*     */         continue;
/*     */       } 
/* 211 */       sbuf.append("<td class=\"");
/* 212 */       sbuf.append(computeConverterName(c));
/* 213 */       sbuf.append("\">");
/* 214 */       sbuf.append(computeConverterName(c));
/* 215 */       sbuf.append("</td>");
/* 216 */       sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 217 */       c = c.getNext();
/*     */     } 
/* 219 */     sbuf.append("</tr>");
/* 220 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/*     */   }
/*     */   
/*     */   public String getPresentationFooter() {
/* 224 */     StringBuilder sbuf = new StringBuilder();
/* 225 */     sbuf.append("</table>");
/* 226 */     return sbuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileFooter() {
/* 234 */     StringBuilder sbuf = new StringBuilder();
/* 235 */     sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 236 */     sbuf.append("</body></html>");
/* 237 */     return sbuf.toString();
/*     */   }
/*     */   
/*     */   protected void startNewTableIfLimitReached(StringBuilder sbuf) {
/* 241 */     if (this.counter >= 10000L) {
/* 242 */       this.counter = 0L;
/* 243 */       sbuf.append("</table>");
/* 244 */       sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 245 */       sbuf.append("<p></p>");
/* 246 */       sbuf.append("<table cellspacing=\"0\">");
/* 247 */       sbuf.append(CoreConstants.LINE_SEPARATOR);
/* 248 */       buildHeaderRowForTable(sbuf);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String computeConverterName(Converter<E> c) {
/* 253 */     String className = c.getClass().getSimpleName();
/* 254 */     int index = className.indexOf("Converter");
/* 255 */     if (index == -1) {
/* 256 */       return className;
/*     */     }
/* 258 */     return className.substring(0, index);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\html\HTMLLayoutBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */