/*     */ package ch.qos.logback.core.encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonEscapeUtil
/*     */ {
/*  19 */   protected static final char[] HEXADECIMALS_TABLE = "0123456789ABCDEF".toCharArray();
/*     */   
/*     */   static final int ESCAPE_CODES_COUNT = 32;
/*     */   
/*  23 */   static final String[] ESCAPE_CODES = new String[32];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  38 */     for (char c = Character.MIN_VALUE; c < ' '; c = (char)(c + 1)) {
/*     */       
/*  40 */       switch (c) {
/*     */         case '\b':
/*  42 */           ESCAPE_CODES[c] = "\\b";
/*     */           break;
/*     */         case '\t':
/*  45 */           ESCAPE_CODES[c] = "\\t";
/*     */           break;
/*     */         case '\n':
/*  48 */           ESCAPE_CODES[c] = "\\n";
/*     */           break;
/*     */         case '\f':
/*  51 */           ESCAPE_CODES[c] = "\\f";
/*     */           break;
/*     */         case '\r':
/*  54 */           ESCAPE_CODES[c] = "\\r";
/*     */           break;
/*     */         default:
/*  57 */           ESCAPE_CODES[c] = _computeEscapeCodeBelowASCII32(c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String _computeEscapeCodeBelowASCII32(char c) {
/*  64 */     if (c > ' ') {
/*  65 */       throw new IllegalArgumentException("input must be less than 32");
/*     */     }
/*     */     
/*  68 */     StringBuilder sb = new StringBuilder(6);
/*  69 */     sb.append("\\u00");
/*     */     
/*  71 */     int highPart = c >> 4;
/*  72 */     sb.append(HEXADECIMALS_TABLE[highPart]);
/*     */     
/*  74 */     int lowPart = c & 0xF;
/*  75 */     sb.append(HEXADECIMALS_TABLE[lowPart]);
/*     */     
/*  77 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getObligatoryEscapeCode(char c) {
/*  85 */     if (c < ' ')
/*  86 */       return ESCAPE_CODES[c]; 
/*  87 */     if (c == '"')
/*  88 */       return "\\\""; 
/*  89 */     if (c == '/')
/*  90 */       return "\\/"; 
/*  91 */     if (c == '\\') {
/*  92 */       return "\\\\";
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public static String jsonEscapeString(String input) {
/*  98 */     int length = input.length();
/*  99 */     int lenthWithLeeway = (int)(length * 1.1D);
/*     */     
/* 101 */     StringBuilder sb = new StringBuilder(lenthWithLeeway);
/* 102 */     for (int i = 0; i < length; i++) {
/* 103 */       char c = input.charAt(i);
/* 104 */       String escaped = getObligatoryEscapeCode(c);
/* 105 */       if (escaped == null) {
/* 106 */         sb.append(c);
/*     */       } else {
/* 108 */         sb.append(escaped);
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\encoder\JsonEscapeUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */