/*    */ package ch.qos.logback.core.encoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EchoEncoder<E>
/*    */   extends EncoderBase<E>
/*    */ {
/*    */   String fileHeader;
/*    */   String fileFooter;
/*    */   
/*    */   public byte[] encode(E event) {
/* 24 */     String val = String.valueOf(event) + String.valueOf(event);
/* 25 */     return val.getBytes();
/*    */   }
/*    */   
/*    */   public byte[] footerBytes() {
/* 29 */     if (this.fileFooter == null) {
/* 30 */       return null;
/*    */     }
/* 32 */     return this.fileFooter.getBytes();
/*    */   }
/*    */   
/*    */   public byte[] headerBytes() {
/* 36 */     if (this.fileHeader == null) {
/* 37 */       return null;
/*    */     }
/* 39 */     return this.fileHeader.getBytes();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\encoder\EchoEncoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */