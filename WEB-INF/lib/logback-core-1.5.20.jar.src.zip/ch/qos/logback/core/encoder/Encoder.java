package ch.qos.logback.core.encoder;

import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.LifeCycle;

public interface Encoder<E> extends ContextAware, LifeCycle {
  byte[] headerBytes();
  
  byte[] encode(E paramE);
  
  byte[] footerBytes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\encoder\Encoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */