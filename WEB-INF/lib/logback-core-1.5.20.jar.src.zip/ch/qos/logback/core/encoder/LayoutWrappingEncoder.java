/*     */ package ch.qos.logback.core.encoder;
/*     */ 
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import ch.qos.logback.core.Layout;
/*     */ import ch.qos.logback.core.OutputStreamAppender;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayoutWrappingEncoder<E>
/*     */   extends EncoderBase<E>
/*     */ {
/*     */   protected Layout<E> layout;
/*     */   private Charset charset;
/*     */   ContextAware parent;
/*  36 */   Boolean immediateFlush = null;
/*     */   
/*     */   public Layout<E> getLayout() {
/*  39 */     return this.layout;
/*     */   }
/*     */   
/*     */   public void setLayout(Layout<E> layout) {
/*  43 */     this.layout = layout;
/*     */   }
/*     */   
/*     */   public Charset getCharset() {
/*  47 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(Charset charset) {
/*  60 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImmediateFlush(boolean immediateFlush) {
/*  72 */     addWarn("As of version 1.2.0 \"immediateFlush\" property should be set within the enclosing Appender.");
/*  73 */     addWarn("Please move \"immediateFlush\" property into the enclosing appender.");
/*  74 */     this.immediateFlush = Boolean.valueOf(immediateFlush);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] headerBytes() {
/*  79 */     if (this.layout == null) {
/*  80 */       return null;
/*     */     }
/*  82 */     StringBuilder sb = new StringBuilder();
/*  83 */     appendIfNotNull(sb, this.layout.getFileHeader());
/*  84 */     appendIfNotNull(sb, this.layout.getPresentationHeader());
/*  85 */     if (sb.length() > 0)
/*     */     {
/*     */ 
/*     */       
/*  89 */       sb.append(CoreConstants.LINE_SEPARATOR);
/*     */     }
/*  91 */     return convertToBytes(sb.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] footerBytes() {
/*  96 */     if (this.layout == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     StringBuilder sb = new StringBuilder();
/* 100 */     appendIfNotNull(sb, this.layout.getPresentationFooter());
/* 101 */     appendIfNotNull(sb, this.layout.getFileFooter());
/* 102 */     return convertToBytes(sb.toString());
/*     */   }
/*     */   
/*     */   private byte[] convertToBytes(String s) {
/* 106 */     if (this.charset == null) {
/* 107 */       return s.getBytes();
/*     */     }
/* 109 */     return s.getBytes(this.charset);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] encode(E event) {
/* 114 */     String txt = this.layout.doLayout(event);
/* 115 */     return convertToBytes(txt);
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 119 */     return this.started;
/*     */   }
/*     */   
/*     */   public void start() {
/* 123 */     if (this.immediateFlush != null) {
/* 124 */       if (this.parent instanceof OutputStreamAppender) {
/* 125 */         addWarn("Setting the \"immediateFlush\" property of the enclosing appender to " + this.immediateFlush);
/*     */         
/* 127 */         OutputStreamAppender<E> parentOutputStreamAppender = (OutputStreamAppender<E>)this.parent;
/* 128 */         parentOutputStreamAppender.setImmediateFlush(this.immediateFlush.booleanValue());
/*     */       } else {
/* 130 */         addError("Could not set the \"immediateFlush\" property of the enclosing appender.");
/*     */       } 
/*     */     }
/* 133 */     this.started = true;
/*     */   }
/*     */   
/*     */   public void stop() {
/* 137 */     this.started = false;
/*     */   }
/*     */   
/*     */   private void appendIfNotNull(StringBuilder sb, String s) {
/* 141 */     if (s != null) {
/* 142 */       sb.append(s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(ContextAware parent) {
/* 153 */     this.parent = parent;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\encoder\LayoutWrappingEncoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */