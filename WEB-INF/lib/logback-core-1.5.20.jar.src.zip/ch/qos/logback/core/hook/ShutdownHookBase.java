/*    */ package ch.qos.logback.core.hook;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.ContextBase;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ShutdownHookBase
/*    */   extends ContextAwareBase
/*    */   implements ShutdownHook
/*    */ {
/*    */   protected void stop() {
/* 35 */     addInfo("Logback context being closed via shutdown hook");
/*    */     
/* 37 */     Context hookContext = getContext();
/* 38 */     if (hookContext instanceof ContextBase) {
/* 39 */       ContextBase context = (ContextBase)hookContext;
/* 40 */       context.stop();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\hook\ShutdownHookBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */