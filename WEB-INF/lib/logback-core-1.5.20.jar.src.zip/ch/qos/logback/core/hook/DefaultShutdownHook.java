/*    */ package ch.qos.logback.core.hook;
/*    */ 
/*    */ import ch.qos.logback.core.util.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultShutdownHook
/*    */   extends ShutdownHookBase
/*    */ {
/* 31 */   public static final Duration DEFAULT_DELAY = Duration.buildByMilliseconds(0.0D);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   private Duration delay = DEFAULT_DELAY;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Duration getDelay() {
/* 42 */     return this.delay;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDelay(Duration delay) {
/* 51 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public void run() {
/* 55 */     if (this.delay.getMilliseconds() > 0L) {
/* 56 */       addInfo("Sleeping for " + String.valueOf(this.delay));
/*    */       try {
/* 58 */         Thread.sleep(this.delay.getMilliseconds());
/* 59 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/*    */     
/* 62 */     stop();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\hook\DefaultShutdownHook.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */