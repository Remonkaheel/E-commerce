package ch.qos.logback.core.hook;

import ch.qos.logback.core.spi.ContextAware;

public interface ShutdownHook extends Runnable, ContextAware {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\hook\ShutdownHook.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */