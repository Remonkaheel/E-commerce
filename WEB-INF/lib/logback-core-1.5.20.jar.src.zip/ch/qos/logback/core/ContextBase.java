/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ConfigurationEvent;
/*     */ import ch.qos.logback.core.spi.ConfigurationEventListener;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.spi.SequenceNumberGenerator;
/*     */ import ch.qos.logback.core.status.InfoStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.util.ExecutorServiceUtil;
/*     */ import ch.qos.logback.core.util.NetworkAddressUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextBase
/*     */   implements Context, LifeCycle
/*     */ {
/*  40 */   private long birthTime = System.currentTimeMillis();
/*     */   
/*     */   private String name;
/*  43 */   private StatusManager sm = new BasicStatusManager();
/*     */ 
/*     */ 
/*     */   
/*  47 */   Map<String, String> propertyMap = new HashMap<>();
/*  48 */   Map<String, Object> objectMap = new ConcurrentHashMap<>();
/*     */   
/*  50 */   protected ReentrantLock configurationLock = new ReentrantLock();
/*     */   
/*  52 */   private final List<ConfigurationEventListener> configurationEventListenerList = new CopyOnWriteArrayList<>();
/*     */   
/*     */   private ScheduledExecutorService scheduledExecutorService;
/*     */   
/*     */   private ThreadPoolExecutor threadPoolExecutor;
/*     */   
/*     */   private ExecutorService alternateExecutorService;
/*     */   
/*  60 */   protected List<ScheduledFuture<?>> scheduledFutures = new ArrayList<>(1);
/*     */   
/*     */   private LifeCycleManager lifeCycleManager;
/*     */   
/*     */   private SequenceNumberGenerator sequenceNumberGenerator;
/*     */   private volatile boolean started;
/*     */   
/*     */   public ContextBase() {
/*  68 */     initCollisionMaps();
/*     */   }
/*     */   
/*     */   public StatusManager getStatusManager() {
/*  72 */     return this.sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusManager(StatusManager statusManager) {
/*  88 */     if (statusManager == null) {
/*  89 */       throw new IllegalArgumentException("null StatusManager not allowed");
/*     */     }
/*  91 */     this.sm = statusManager;
/*     */   }
/*     */   
/*     */   public Map<String, String> getCopyOfPropertyMap() {
/*  95 */     return new HashMap<>(this.propertyMap);
/*     */   }
/*     */   
/*     */   public void putProperty(String key, String val) {
/*  99 */     if ("HOSTNAME".equalsIgnoreCase(key)) {
/* 100 */       putHostnameProperty(val);
/*     */     } else {
/* 102 */       this.propertyMap.put(key, val);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void initCollisionMaps() {
/* 107 */     putObject("FA_FILENAMES_MAP", new HashMap<>());
/* 108 */     putObject("RFA_FILENAME_PATTERN_COLLISION_MAP", new HashMap<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSubstitutionProperty(String key, String value) {
/* 113 */     if (key == null || value == null) {
/*     */       return;
/*     */     }
/*     */     
/* 117 */     value = value.trim();
/* 118 */     this.propertyMap.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 129 */     if ("CONTEXT_NAME".equals(key))
/* 130 */       return getName(); 
/* 131 */     if ("HOSTNAME".equalsIgnoreCase(key)) {
/* 132 */       return lazyGetHostname();
/*     */     }
/*     */     
/* 135 */     return this.propertyMap.get(key);
/*     */   }
/*     */   
/*     */   private String lazyGetHostname() {
/* 139 */     String hostname = this.propertyMap.get("HOSTNAME");
/* 140 */     if (hostname == null) {
/* 141 */       hostname = (new NetworkAddressUtil(this)).safelyGetLocalHostName();
/* 142 */       putHostnameProperty(hostname);
/*     */     } 
/* 144 */     return hostname;
/*     */   }
/*     */   
/*     */   private void putHostnameProperty(String hostname) {
/* 148 */     String existingHostname = this.propertyMap.get("HOSTNAME");
/* 149 */     if (existingHostname == null) {
/* 150 */       this.propertyMap.put("HOSTNAME", hostname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(String key) {
/* 157 */     return this.objectMap.get(key);
/*     */   }
/*     */   
/*     */   public void putObject(String key, Object value) {
/* 161 */     this.objectMap.put(key, value);
/*     */   }
/*     */   
/*     */   public void removeObject(String key) {
/* 165 */     this.objectMap.remove(key);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 169 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 177 */     this.started = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 183 */     stopExecutorServices();
/*     */     
/* 185 */     this.started = false;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 189 */     return this.started;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 198 */     removeShutdownHook();
/* 199 */     getLifeCycleManager().reset();
/* 200 */     this.propertyMap.clear();
/* 201 */     this.objectMap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) throws IllegalStateException {
/* 213 */     if (name != null && name.equals(this.name)) {
/*     */       return;
/*     */     }
/* 216 */     if (this.name == null || "default".equals(this.name)) {
/* 217 */       this.name = name;
/*     */     } else {
/* 219 */       throw new IllegalStateException("Context has been already given a name");
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getBirthTime() {
/* 224 */     return this.birthTime;
/*     */   }
/*     */   
/*     */   public ReentrantLock getConfigurationLock() {
/* 228 */     return this.configurationLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ExecutorService getExecutorService() {
/* 235 */     if (this.threadPoolExecutor == null) {
/* 236 */       this.threadPoolExecutor = ExecutorServiceUtil.newThreadPoolExecutor();
/*     */     }
/* 238 */     return this.threadPoolExecutor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ExecutorService getAlternateExecutorService() {
/* 243 */     if (this.alternateExecutorService == null) {
/* 244 */       this.alternateExecutorService = ExecutorServiceUtil.newAlternateThreadPoolExecutor();
/*     */     }
/* 246 */     return this.alternateExecutorService;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ScheduledExecutorService getScheduledExecutorService() {
/* 251 */     if (this.scheduledExecutorService == null) {
/* 252 */       this.scheduledExecutorService = ExecutorServiceUtil.newScheduledExecutorService();
/*     */     }
/* 254 */     return this.scheduledExecutorService;
/*     */   }
/*     */   
/*     */   private synchronized void stopExecutorServices() {
/* 258 */     ExecutorServiceUtil.shutdown(this.scheduledExecutorService);
/* 259 */     this.scheduledExecutorService = null;
/*     */     
/* 261 */     ExecutorServiceUtil.shutdown(this.threadPoolExecutor);
/* 262 */     this.threadPoolExecutor = null;
/*     */   }
/*     */   
/*     */   private void removeShutdownHook() {
/* 266 */     Thread hook = (Thread)getObject("SHUTDOWN_HOOK");
/* 267 */     if (hook != null) {
/* 268 */       removeObject("SHUTDOWN_HOOK");
/*     */       
/*     */       try {
/* 271 */         this.sm.add((Status)new InfoStatus("Removing shutdownHook " + String.valueOf(hook), this));
/* 272 */         Runtime runtime = Runtime.getRuntime();
/* 273 */         boolean result = runtime.removeShutdownHook(hook);
/* 274 */         this.sm.add((Status)new InfoStatus("ShutdownHook removal result: " + result, this));
/* 275 */       } catch (IllegalStateException illegalStateException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(LifeCycle component) {
/* 283 */     getLifeCycleManager().register(component);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized LifeCycleManager getLifeCycleManager() {
/* 299 */     if (this.lifeCycleManager == null) {
/* 300 */       this.lifeCycleManager = new LifeCycleManager();
/*     */     }
/* 302 */     return this.lifeCycleManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 307 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addScheduledFuture(ScheduledFuture<?> scheduledFuture) {
/* 312 */     this.scheduledFutures.add(scheduledFuture);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<ScheduledFuture<?>> getScheduledFutures() {
/* 320 */     return getCopyOfScheduledFutures();
/*     */   }
/*     */   
/*     */   public List<ScheduledFuture<?>> getCopyOfScheduledFutures() {
/* 324 */     return new ArrayList<>(this.scheduledFutures);
/*     */   }
/*     */   
/*     */   public SequenceNumberGenerator getSequenceNumberGenerator() {
/* 328 */     return this.sequenceNumberGenerator;
/*     */   }
/*     */   
/*     */   public void setSequenceNumberGenerator(SequenceNumberGenerator sequenceNumberGenerator) {
/* 332 */     this.sequenceNumberGenerator = sequenceNumberGenerator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConfigurationEventListener(ConfigurationEventListener listener) {
/* 337 */     this.configurationEventListenerList.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeConfigurationEventListener(ConfigurationEventListener listener) {
/* 342 */     this.configurationEventListenerList.remove(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fireConfigurationEvent(ConfigurationEvent configurationEvent) {
/* 347 */     this.configurationEventListenerList.forEach(l -> l.listen(configurationEvent));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\ContextBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */