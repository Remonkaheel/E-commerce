/*    */ package ch.qos.logback.core;
/*    */ 
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.spi.PropertyDefiner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PropertyDefinerBase
/*    */   extends ContextAwareBase
/*    */   implements PropertyDefiner
/*    */ {
/*    */   protected static String booleanAsStr(boolean bool) {
/* 28 */     return bool ? Boolean.TRUE.toString() : Boolean.FALSE.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\PropertyDefinerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */