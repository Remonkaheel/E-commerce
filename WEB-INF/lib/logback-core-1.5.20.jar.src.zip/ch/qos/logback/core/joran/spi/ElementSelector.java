/*     */ package ch.qos.logback.core.joran.spi;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementSelector
/*     */   extends ElementPath
/*     */ {
/*     */   public ElementSelector() {}
/*     */   
/*     */   public ElementSelector(List<String> list) {
/*  37 */     super(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementSelector(String p) {
/*  47 */     super(p);
/*     */   }
/*     */   
/*     */   public boolean fullPathMatch(ElementPath path) {
/*  51 */     if (path.size() != size()) {
/*  52 */       return false;
/*     */     }
/*     */     
/*  55 */     int len = size();
/*  56 */     for (int i = 0; i < len; i++) {
/*  57 */       if (!equalityCheck(get(i), path.get(i))) {
/*  58 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  62 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTailMatchLength(ElementPath p) {
/*  71 */     if (p == null) {
/*  72 */       return 0;
/*     */     }
/*     */     
/*  75 */     int lSize = this.partList.size();
/*  76 */     int rSize = p.partList.size();
/*     */ 
/*     */     
/*  79 */     if (lSize == 0 || rSize == 0) {
/*  80 */       return 0;
/*     */     }
/*     */     
/*  83 */     int minLen = (lSize <= rSize) ? lSize : rSize;
/*  84 */     int match = 0;
/*     */ 
/*     */     
/*  87 */     for (int i = 1; i <= minLen; ) {
/*  88 */       String l = this.partList.get(lSize - i);
/*  89 */       String r = p.partList.get(rSize - i);
/*     */       
/*  91 */       if (equalityCheck(l, r)) {
/*  92 */         match++;
/*     */         
/*     */         i++;
/*     */       } 
/*     */     } 
/*  97 */     return match;
/*     */   }
/*     */   
/*     */   public boolean isContainedIn(ElementPath p) {
/* 101 */     if (p == null) {
/* 102 */       return false;
/*     */     }
/* 104 */     return p.toStableString().contains(toStableString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefixMatchLength(ElementPath p) {
/* 113 */     if (p == null) {
/* 114 */       return 0;
/*     */     }
/*     */     
/* 117 */     int lSize = this.partList.size();
/* 118 */     int rSize = p.partList.size();
/*     */ 
/*     */     
/* 121 */     if (lSize == 0 || rSize == 0) {
/* 122 */       return 0;
/*     */     }
/*     */     
/* 125 */     int minLen = (lSize <= rSize) ? lSize : rSize;
/* 126 */     int match = 0;
/*     */     
/* 128 */     for (int i = 0; i < minLen; ) {
/* 129 */       String l = this.partList.get(i);
/* 130 */       String r = p.partList.get(i);
/*     */       
/* 132 */       if (equalityCheck(l, r)) {
/* 133 */         match++;
/*     */         
/*     */         i++;
/*     */       } 
/*     */     } 
/*     */     
/* 139 */     return match;
/*     */   }
/*     */   
/*     */   private boolean equalityCheck(String x, String y) {
/* 143 */     return x.equalsIgnoreCase(y);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 148 */     if (o == null || !(o instanceof ElementSelector)) {
/* 149 */       return false;
/*     */     }
/*     */     
/* 152 */     ElementSelector r = (ElementSelector)o;
/*     */     
/* 154 */     if (r.size() != size()) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     int len = size();
/*     */     
/* 160 */     for (int i = 0; i < len; i++) {
/* 161 */       if (!equalityCheck(get(i), r.get(i))) {
/* 162 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 167 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 172 */     int hc = 0;
/* 173 */     int len = size();
/*     */     
/* 175 */     for (int i = 0; i < len; i++)
/*     */     {
/*     */       
/* 178 */       hc ^= get(i).toLowerCase().hashCode();
/*     */     }
/* 180 */     return hc;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\ElementSelector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */