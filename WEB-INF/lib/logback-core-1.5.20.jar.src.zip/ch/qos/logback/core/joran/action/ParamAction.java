/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.ParamModel;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext intercon, String name, Attributes attributes) {
/* 27 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, intercon, name, attributes);
/* 28 */     pv.validateNameAttribute();
/* 29 */     pv.validateValueAttribute();
/*    */     
/* 31 */     addWarn("<param> element is deprecated in favor of a more direct syntax." + atLine(intercon));
/* 32 */     addWarn("For details see https://logback.qos.ch/codes.html#param");
/*    */     
/* 34 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 41 */     ParamModel paramModel = new ParamModel();
/* 42 */     paramModel.setName(attributes.getValue("name"));
/* 43 */     paramModel.setValue(attributes.getValue("value"));
/* 44 */     return (Model)paramModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ParamAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */