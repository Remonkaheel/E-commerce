/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.EventEvaluatorModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventEvaluatorAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext intercon, String name, Attributes attributes) {
/* 26 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, intercon, name, attributes);
/* 27 */     pv.validateNameAttribute();
/* 28 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 35 */     EventEvaluatorModel eem = new EventEvaluatorModel();
/*    */     
/* 37 */     eem.setClassName(attributes.getValue("class"));
/* 38 */     eem.setName(attributes.getValue("name"));
/*    */     
/* 40 */     return (Model)eem;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\EventEvaluatorAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */