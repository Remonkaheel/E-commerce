/*     */ package ch.qos.logback.core.joran.util;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescription;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.AggregationType;
/*     */ import ch.qos.logback.core.util.PropertySetterException;
/*     */ import ch.qos.logback.core.util.StringUtil;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySetter
/*     */   extends ContextAwareBase
/*     */ {
/*     */   protected final Object obj;
/*     */   protected final Class<?> objClass;
/*     */   protected final BeanDescription beanDescription;
/*     */   protected final AggregationAssessor aggregationAssessor;
/*     */   
/*     */   public PropertySetter(BeanDescriptionCache beanDescriptionCache, Object obj) {
/*  65 */     this.obj = obj;
/*  66 */     this.objClass = obj.getClass();
/*  67 */     this.beanDescription = beanDescriptionCache.getBeanDescription(this.objClass);
/*  68 */     this.aggregationAssessor = new AggregationAssessor(beanDescriptionCache, this.objClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContext(Context context) {
/*  73 */     super.setContext(context);
/*  74 */     this.aggregationAssessor.setContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, String value) {
/*  95 */     if (value == null) {
/*     */       return;
/*     */     }
/*  98 */     Method setter = this.aggregationAssessor.findSetterMethod(name);
/*  99 */     if (setter == null) {
/* 100 */       addWarn("No setter for property [" + name + "] in " + this.objClass.getName() + ".");
/*     */     } else {
/*     */       try {
/* 103 */         setProperty(setter, value);
/* 104 */       } catch (PropertySetterException ex) {
/* 105 */         addWarn("Failed to set property [" + name + "] to value \"" + value + "\". ", (Throwable)ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setProperty(Method setter, String value) throws PropertySetterException {
/*     */     Object arg;
/* 118 */     Class<?>[] paramTypes = setter.getParameterTypes();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 123 */       arg = StringToObjectConverter.convertArg((ContextAware)this, value, paramTypes[0]);
/* 124 */     } catch (Throwable t) {
/* 125 */       throw new PropertySetterException("Conversion to type [" + String.valueOf(paramTypes[0]) + "] failed. ", t);
/*     */     } 
/*     */     
/* 128 */     if (arg == null) {
/* 129 */       throw new PropertySetterException("Conversion to type [" + String.valueOf(paramTypes[0]) + "] failed.");
/*     */     }
/*     */     try {
/* 132 */       setter.invoke(this.obj, new Object[] { arg });
/* 133 */     } catch (Exception ex) {
/* 134 */       throw new PropertySetterException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public AggregationType computeAggregationType(String name) {
/* 139 */     return this.aggregationAssessor.computeAggregationType(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getObjClass() {
/* 179 */     return this.objClass;
/*     */   }
/*     */   
/*     */   public void addComplexProperty(String name, Object complexProperty) {
/* 183 */     Method adderMethod = this.aggregationAssessor.findAdderMethod(name);
/*     */     
/* 185 */     if (adderMethod != null) {
/* 186 */       Class<?>[] paramTypes = adderMethod.getParameterTypes();
/* 187 */       if (!isSanityCheckSuccessful(name, adderMethod, paramTypes, complexProperty)) {
/*     */         return;
/*     */       }
/* 190 */       invokeMethodWithSingleParameterOnThisObject(adderMethod, complexProperty);
/*     */     } else {
/* 192 */       addError("Could not find method [add" + name + "] in class [" + this.objClass.getName() + "].");
/*     */     } 
/*     */   }
/*     */   
/*     */   void invokeMethodWithSingleParameterOnThisObject(Method method, Object parameter) {
/* 197 */     Class<?> ccc = parameter.getClass();
/*     */     try {
/* 199 */       method.invoke(this.obj, new Object[] { parameter });
/* 200 */     } catch (Exception e) {
/* 201 */       addError("Could not invoke method " + method.getName() + " in class " + this.obj.getClass().getName() + " with parameter of type " + ccc
/* 202 */           .getName(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addBasicProperty(String name, String strValue) {
/*     */     Object arg;
/* 208 */     if (strValue == null) {
/*     */       return;
/*     */     }
/*     */     
/* 212 */     name = StringUtil.capitalizeFirstLetter(name);
/* 213 */     Method adderMethod = this.aggregationAssessor.findAdderMethod(name);
/*     */     
/* 215 */     if (adderMethod == null) {
/* 216 */       addError("No adder for property [" + name + "].");
/*     */       
/*     */       return;
/*     */     } 
/* 220 */     Class<?>[] paramTypes = adderMethod.getParameterTypes();
/* 221 */     isSanityCheckSuccessful(name, adderMethod, paramTypes, strValue);
/*     */ 
/*     */     
/*     */     try {
/* 225 */       arg = StringToObjectConverter.convertArg((ContextAware)this, strValue, paramTypes[0]);
/* 226 */     } catch (Throwable t) {
/* 227 */       addError("Conversion to type [" + String.valueOf(paramTypes[0]) + "] failed. ", t);
/*     */       return;
/*     */     } 
/* 230 */     if (arg != null) {
/* 231 */       invokeMethodWithSingleParameterOnThisObject(adderMethod, arg);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setComplexProperty(String name, Object complexProperty) {
/* 236 */     Method setter = this.aggregationAssessor.findSetterMethod(name);
/*     */     
/* 238 */     if (setter == null) {
/* 239 */       addWarn("Not setter method for property [" + name + "] in " + this.obj.getClass().getName());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 244 */     Class<?>[] paramTypes = setter.getParameterTypes();
/*     */     
/* 246 */     if (!isSanityCheckSuccessful(name, setter, paramTypes, complexProperty)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 250 */       invokeMethodWithSingleParameterOnThisObject(setter, complexProperty);
/*     */     }
/* 252 */     catch (Exception e) {
/* 253 */       addError("Could not set component " + String.valueOf(this.obj) + " for parent component " + String.valueOf(this.obj), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSanityCheckSuccessful(String name, Method method, Class<?>[] params, Object complexProperty) {
/* 258 */     Class<?> ccc = complexProperty.getClass();
/* 259 */     if (params.length != 1) {
/* 260 */       addError("Wrong number of parameters in setter method for property [" + name + "] in " + this.obj
/* 261 */           .getClass().getName());
/*     */       
/* 263 */       return false;
/*     */     } 
/*     */     
/* 266 */     if (!params[0].isAssignableFrom(complexProperty.getClass())) {
/* 267 */       addError("A \"" + ccc.getName() + "\" object is not assignable to a \"" + params[0].getName() + "\" variable.");
/*     */       
/* 269 */       addError("The class \"" + params[0].getName() + "\" was loaded by ");
/* 270 */       addError("[" + String.valueOf(params[0].getClassLoader()) + "] whereas object of type ");
/* 271 */       addError("\"" + ccc.getName() + "\" was loaded by [" + String.valueOf(ccc.getClassLoader()) + "].");
/* 272 */       return false;
/*     */     } 
/*     */     
/* 275 */     return true;
/*     */   }
/*     */   
/*     */   public Object getObj() {
/* 279 */     return this.obj;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getClassNameViaImplicitRules(String name, AggregationType aggregationType, DefaultNestedComponentRegistry registry) {
/* 285 */     return this.aggregationAssessor.getClassNameViaImplicitRules(name, aggregationType, registry);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\PropertySetter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */