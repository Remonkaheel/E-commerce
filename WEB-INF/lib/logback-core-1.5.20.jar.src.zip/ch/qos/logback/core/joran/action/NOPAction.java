package ch.qos.logback.core.joran.action;

import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
import org.xml.sax.Attributes;

public class NOPAction extends Action {
  public void begin(SaxEventInterpretationContext ec, String name, Attributes attributes) {}
  
  public void end(SaxEventInterpretationContext ec, String name) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\NOPAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */