/*    */ package ch.qos.logback.core.joran;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.ConversionRuleModel;
/*    */ import ch.qos.logback.core.model.DefineModel;
/*    */ import ch.qos.logback.core.model.EventEvaluatorModel;
/*    */ import ch.qos.logback.core.model.ImplicitModel;
/*    */ import ch.qos.logback.core.model.ImportModel;
/*    */ import ch.qos.logback.core.model.IncludeModel;
/*    */ import ch.qos.logback.core.model.ParamModel;
/*    */ import ch.qos.logback.core.model.PropertyModel;
/*    */ import ch.qos.logback.core.model.SequenceNumberGeneratorModel;
/*    */ import ch.qos.logback.core.model.SerializeModelModel;
/*    */ import ch.qos.logback.core.model.ShutdownHookModel;
/*    */ import ch.qos.logback.core.model.SiftModel;
/*    */ import ch.qos.logback.core.model.StatusListenerModel;
/*    */ import ch.qos.logback.core.model.TimestampModel;
/*    */ import ch.qos.logback.core.model.conditional.ByPropertiesConditionModel;
/*    */ import ch.qos.logback.core.model.conditional.ElseModel;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.model.conditional.ThenModel;
/*    */ import ch.qos.logback.core.model.processor.ConversionRuleModelHandler;
/*    */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*    */ import ch.qos.logback.core.model.processor.DefineModelHandler;
/*    */ import ch.qos.logback.core.model.processor.EventEvaluatorModelHandler;
/*    */ import ch.qos.logback.core.model.processor.ImplicitModelHandler;
/*    */ import ch.qos.logback.core.model.processor.ImportModelHandler;
/*    */ import ch.qos.logback.core.model.processor.IncludeModelHandler;
/*    */ import ch.qos.logback.core.model.processor.PropertyModelHandler;
/*    */ import ch.qos.logback.core.model.processor.SequenceNumberGeneratorModelHandler;
/*    */ import ch.qos.logback.core.model.processor.SerializeModelModelHandler;
/*    */ import ch.qos.logback.core.model.processor.ShutdownHookModelHandler;
/*    */ import ch.qos.logback.core.model.processor.StatusListenerModelHandler;
/*    */ import ch.qos.logback.core.model.processor.TimestampModelHandler;
/*    */ import ch.qos.logback.core.model.processor.conditional.ByPropertiesConditionModelHandler;
/*    */ import ch.qos.logback.core.model.processor.conditional.ElseModelHandler;
/*    */ import ch.qos.logback.core.model.processor.conditional.IfModelHandler;
/*    */ import ch.qos.logback.core.model.processor.conditional.ThenModelHandler;
/*    */ import ch.qos.logback.core.sift.SiftModelHandler;
/*    */ 
/*    */ public class ModelClassToModelHandlerLinkerBase
/*    */ {
/*    */   public ModelClassToModelHandlerLinkerBase(Context context) {
/* 44 */     this.context = context;
/*    */   }
/*    */   protected Context context;
/*    */   public void link(DefaultProcessor defaultProcessor) {
/* 48 */     defaultProcessor.addHandler(ImportModel.class, ImportModelHandler::makeInstance);
/*    */     
/* 50 */     defaultProcessor.addHandler(ShutdownHookModel.class, ShutdownHookModelHandler::makeInstance);
/* 51 */     defaultProcessor.addHandler(SequenceNumberGeneratorModel.class, SequenceNumberGeneratorModelHandler::makeInstance);
/* 52 */     defaultProcessor.addHandler(SerializeModelModel.class, SerializeModelModelHandler::makeInstance);
/*    */     
/* 54 */     defaultProcessor.addHandler(EventEvaluatorModel.class, EventEvaluatorModelHandler::makeInstance);
/* 55 */     defaultProcessor.addHandler(ConversionRuleModel.class, ConversionRuleModelHandler::makeInstance);
/*    */     
/* 57 */     defaultProcessor.addHandler(DefineModel.class, DefineModelHandler::makeInstance);
/* 58 */     defaultProcessor.addHandler(IncludeModel.class, IncludeModelHandler::makeInstance);
/*    */ 
/*    */     
/* 61 */     defaultProcessor.addHandler(ParamModel.class, ParamModelHandler::makeInstance);
/* 62 */     defaultProcessor.addHandler(PropertyModel.class, PropertyModelHandler::makeInstance);
/* 63 */     defaultProcessor.addHandler(TimestampModel.class, TimestampModelHandler::makeInstance);
/* 64 */     defaultProcessor.addHandler(StatusListenerModel.class, StatusListenerModelHandler::makeInstance);
/* 65 */     defaultProcessor.addHandler(ImplicitModel.class, ImplicitModelHandler::makeInstance);
/*    */ 
/*    */     
/* 68 */     defaultProcessor.addHandler(ByPropertiesConditionModel.class, ByPropertiesConditionModelHandler::makeInstance);
/* 69 */     defaultProcessor.addHandler(IfModel.class, IfModelHandler::makeInstance);
/* 70 */     defaultProcessor.addHandler(ThenModel.class, ThenModelHandler::makeInstance);
/* 71 */     defaultProcessor.addHandler(ElseModel.class, ElseModelHandler::makeInstance);
/*    */     
/* 73 */     defaultProcessor.addHandler(SiftModel.class, SiftModelHandler::makeInstance);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void sealModelFilters(DefaultProcessor defaultProcessor) {
/* 81 */     defaultProcessor.getPhaseOneFilter().denyAll();
/* 82 */     defaultProcessor.getPhaseTwoFilter().allowAll();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\ModelClassToModelHandlerLinkerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */