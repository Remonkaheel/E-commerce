/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JoranException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1112493363728774021L;
/*    */   
/*    */   public JoranException(String msg) {
/* 21 */     super(msg);
/*    */   }
/*    */   
/*    */   public JoranException(String msg, Throwable cause) {
/* 25 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\JoranException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */