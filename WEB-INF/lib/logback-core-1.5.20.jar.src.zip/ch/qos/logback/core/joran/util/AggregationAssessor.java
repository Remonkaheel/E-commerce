/*     */ package ch.qos.logback.core.joran.util;
/*     */ 
/*     */ import ch.qos.logback.core.joran.spi.DefaultClass;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescription;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanUtil;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.AggregationType;
/*     */ import ch.qos.logback.core.util.StringUtil;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AggregationAssessor
/*     */   extends ContextAwareBase
/*     */ {
/*     */   protected final Class<?> objClass;
/*     */   protected final BeanDescription beanDescription;
/*     */   
/*     */   public AggregationAssessor(BeanDescriptionCache beanDescriptionCache, Class<?> objClass) {
/*  45 */     this.objClass = objClass;
/*  46 */     this.beanDescription = beanDescriptionCache.getBeanDescription(objClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AggregationType computeAggregationType(String name) {
/*  57 */     String cName = StringUtil.capitalizeFirstLetter(name);
/*     */     
/*  59 */     Method addMethod = findAdderMethod(cName);
/*     */     
/*  61 */     if (addMethod != null) {
/*  62 */       AggregationType type = computeRawAggregationType(addMethod);
/*  63 */       switch (type) {
/*     */         case NOT_FOUND:
/*  65 */           return AggregationType.NOT_FOUND;
/*     */         case AS_BASIC_PROPERTY:
/*  67 */           return AggregationType.AS_BASIC_PROPERTY_COLLECTION;
/*     */         
/*     */         case AS_COMPLEX_PROPERTY:
/*  70 */           return AggregationType.AS_COMPLEX_PROPERTY_COLLECTION;
/*     */         case AS_BASIC_PROPERTY_COLLECTION:
/*     */         case AS_COMPLEX_PROPERTY_COLLECTION:
/*  73 */           addError("Unexpected AggregationType " + String.valueOf(type));
/*     */           break;
/*     */       } 
/*     */     } 
/*  77 */     Method setter = findSetterMethod(name);
/*  78 */     if (setter != null) {
/*  79 */       return computeRawAggregationType(setter);
/*     */     }
/*     */     
/*  82 */     return AggregationType.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method findAdderMethod(String name) {
/*  92 */     String propertyName = BeanUtil.toLowerCamelCase(name);
/*  93 */     return this.beanDescription.getAdder(propertyName);
/*     */   }
/*     */   
/*     */   public Method findSetterMethod(String name) {
/*  97 */     String propertyName = BeanUtil.toLowerCamelCase(name);
/*  98 */     return this.beanDescription.getSetter(propertyName);
/*     */   }
/*     */   
/*     */   private AggregationType computeRawAggregationType(Method method) {
/* 102 */     Class<?> parameterClass = getParameterClassForMethod(method);
/* 103 */     if (parameterClass == null) {
/* 104 */       return AggregationType.NOT_FOUND;
/*     */     }
/* 106 */     if (StringToObjectConverter.canBeBuiltFromSimpleString(parameterClass)) {
/* 107 */       return AggregationType.AS_BASIC_PROPERTY;
/*     */     }
/* 109 */     return AggregationType.AS_COMPLEX_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> getParameterClassForMethod(Method method) {
/* 114 */     if (method == null) {
/* 115 */       return null;
/*     */     }
/* 117 */     Class<?>[] classArray = method.getParameterTypes();
/* 118 */     if (classArray.length != 1) {
/* 119 */       return null;
/*     */     }
/* 121 */     return classArray[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getClassNameViaImplicitRules(String name, AggregationType aggregationType, DefaultNestedComponentRegistry registry) {
/* 128 */     Class<?> registryResult = registry.findDefaultComponentType(this.objClass, name);
/* 129 */     if (registryResult != null) {
/* 130 */       return registryResult;
/*     */     }
/*     */     
/* 133 */     Method relevantMethod = getRelevantMethod(name, aggregationType);
/* 134 */     if (relevantMethod == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     Class<?> byAnnotation = getDefaultClassNameByAnnonation(name, relevantMethod);
/* 138 */     if (byAnnotation != null) {
/* 139 */       return byAnnotation;
/*     */     }
/* 141 */     return getByConcreteType(name, relevantMethod);
/*     */   }
/*     */ 
/*     */   
/*     */   <T extends java.lang.annotation.Annotation> T getAnnotation(String name, Class<T> annonationClass, Method relevantMethod) {
/* 146 */     if (relevantMethod != null) {
/* 147 */       return relevantMethod.getAnnotation(annonationClass);
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   Class<?> getDefaultClassNameByAnnonation(String name, Method relevantMethod) {
/* 154 */     DefaultClass defaultClassAnnon = getAnnotation(name, DefaultClass.class, relevantMethod);
/* 155 */     if (defaultClassAnnon != null) {
/* 156 */       return defaultClassAnnon.value();
/*     */     }
/* 158 */     return null;
/*     */   }
/*     */   Method getRelevantMethod(String name, AggregationType aggregationType) {
/*     */     Method relevantMethod;
/* 162 */     if (aggregationType == AggregationType.AS_COMPLEX_PROPERTY_COLLECTION) {
/* 163 */       relevantMethod = findAdderMethod(name);
/* 164 */     } else if (aggregationType == AggregationType.AS_COMPLEX_PROPERTY) {
/* 165 */       relevantMethod = findSetterMethod(name);
/*     */     } else {
/* 167 */       throw new IllegalStateException(String.valueOf(aggregationType) + " not allowed here");
/*     */     } 
/* 169 */     return relevantMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   Class<?> getByConcreteType(String name, Method relevantMethod) {
/* 174 */     Class<?> paramType = getParameterClassForMethod(relevantMethod);
/* 175 */     if (paramType == null) {
/* 176 */       return null;
/*     */     }
/*     */     
/* 179 */     boolean isUnequivocallyInstantiable = isUnequivocallyInstantiable(paramType);
/* 180 */     if (isUnequivocallyInstantiable) {
/* 181 */       return paramType;
/*     */     }
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUnequivocallyInstantiable(Class<?> clazz) {
/* 194 */     if (clazz.isInterface()) {
/* 195 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 202 */       Object o = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 203 */       if (o != null) {
/* 204 */         return true;
/*     */       }
/* 206 */       return false;
/*     */     }
/* 208 */     catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException|NoSuchMethodException e) {
/*     */       
/* 210 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\AggregationAssessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */