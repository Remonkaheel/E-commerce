/*     */ package ch.qos.logback.core.joran.spi;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaxEventInterpretationContext
/*     */   extends ContextAwareBase
/*     */   implements PropertyContainer
/*     */ {
/*     */   Stack<Model> modelStack;
/*     */   SaxEventInterpreter saxEventInterpreter;
/*     */   
/*     */   public SaxEventInterpretationContext(Context context, SaxEventInterpreter saxEventInterpreter) {
/*  41 */     this.context = context;
/*  42 */     this.saxEventInterpreter = saxEventInterpreter;
/*  43 */     this.modelStack = new Stack<>();
/*     */   }
/*     */   
/*     */   public SaxEventInterpreter getSaxEventInterpreter() {
/*  47 */     return this.saxEventInterpreter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Model peekModel() {
/*  56 */     if (this.modelStack.isEmpty()) {
/*  57 */       return null;
/*     */     }
/*  59 */     return this.modelStack.peek();
/*     */   }
/*     */   
/*     */   public void pushModel(Model m) {
/*  63 */     this.modelStack.push(m);
/*     */   }
/*     */   
/*     */   public boolean isModelStackEmpty() {
/*  67 */     return this.modelStack.isEmpty();
/*     */   }
/*     */   
/*     */   public Model popModel() {
/*  71 */     return this.modelStack.pop();
/*     */   }
/*     */   
/*     */   public Stack<Model> getCopyOfModelStack() {
/*  75 */     Stack<Model> copy = new Stack<>();
/*  76 */     copy.addAll(this.modelStack);
/*  77 */     return copy;
/*     */   }
/*     */   
/*     */   public void addSubstitutionProperty(String key, String value) {
/*  81 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/*  89 */     return this.context.getProperty(key);
/*     */   }
/*     */   
/*     */   public Map<String, String> getCopyOfPropertyMap() {
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   public String subst(String value) {
/*  97 */     if (value == null) {
/*  98 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 102 */       return OptionHelper.substVars(value, this, (PropertyContainer)this.context);
/* 103 */     } catch (ScanException|IllegalArgumentException e) {
/* 104 */       addError("Problem while parsing [" + value + "]", e);
/* 105 */       return value;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\SaxEventInterpretationContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */