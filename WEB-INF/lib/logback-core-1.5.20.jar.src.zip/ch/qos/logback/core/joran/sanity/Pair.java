/*    */ package ch.qos.logback.core.joran.sanity;
/*    */ 
/*    */ public class Pair<F, S>
/*    */ {
/*    */   public final F first;
/*    */   public final S second;
/*    */   
/*    */   Pair(F first, S second) {
/*  9 */     this.first = first;
/* 10 */     this.second = second;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\sanity\Pair.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */