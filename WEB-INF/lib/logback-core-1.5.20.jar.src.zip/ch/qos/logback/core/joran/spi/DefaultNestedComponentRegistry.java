/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultNestedComponentRegistry
/*    */ {
/* 27 */   Map<HostClassAndPropertyDouble, Class<?>> defaultComponentMap = new HashMap<>();
/* 28 */   Map<String, Class<?>> tagToClassMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void duplicate(DefaultNestedComponentRegistry other) {
/* 32 */     this.defaultComponentMap.putAll(other.defaultComponentMap);
/* 33 */     this.tagToClassMap.putAll(other.tagToClassMap);
/*    */   }
/*    */   
/*    */   public void add(Class<?> hostClass, String propertyName, Class<?> componentClass) {
/* 37 */     HostClassAndPropertyDouble hpDouble = new HostClassAndPropertyDouble(hostClass, propertyName.toLowerCase());
/* 38 */     this.defaultComponentMap.put(hpDouble, componentClass);
/* 39 */     this.tagToClassMap.put(propertyName, componentClass);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String findDefaultComponentTypeByTag(String tagName) {
/* 45 */     Class<?> defaultClass = this.tagToClassMap.get(tagName);
/* 46 */     if (defaultClass == null) {
/* 47 */       return null;
/*    */     }
/* 49 */     return defaultClass.getCanonicalName();
/*    */   }
/*    */   
/*    */   public Class<?> findDefaultComponentType(Class<?> hostClass, String propertyName) {
/* 53 */     propertyName = propertyName.toLowerCase();
/* 54 */     while (hostClass != null) {
/* 55 */       Class<?> componentClass = oneShotFind(hostClass, propertyName);
/* 56 */       if (componentClass != null) {
/* 57 */         return componentClass;
/*    */       }
/* 59 */       hostClass = hostClass.getSuperclass();
/*    */     } 
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   private Class<?> oneShotFind(Class<?> hostClass, String propertyName) {
/* 65 */     HostClassAndPropertyDouble hpDouble = new HostClassAndPropertyDouble(hostClass, propertyName);
/* 66 */     return this.defaultComponentMap.get(hpDouble);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\DefaultNestedComponentRegistry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */