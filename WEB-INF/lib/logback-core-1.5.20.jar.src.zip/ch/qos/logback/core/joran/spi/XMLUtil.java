/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ import ch.qos.logback.core.status.StatusManager;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLUtil
/*    */ {
/*    */   public static final int ILL_FORMED = 1;
/*    */   public static final int UNRECOVERABLE_ERROR = 2;
/*    */   
/*    */   public static int checkIfWellFormed(URL url, StatusManager sm) {
/* 26 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\XMLUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */