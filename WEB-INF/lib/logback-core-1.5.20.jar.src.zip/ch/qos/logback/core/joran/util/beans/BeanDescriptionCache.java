/*    */ package ch.qos.logback.core.joran.util.beans;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanDescriptionCache
/*    */   extends ContextAwareBase
/*    */ {
/* 24 */   private Map<Class<?>, BeanDescription> classToBeanDescription = new HashMap<>();
/*    */   private BeanDescriptionFactory beanDescriptionFactory;
/*    */   
/*    */   public BeanDescriptionCache(Context context) {
/* 28 */     setContext(context);
/*    */   }
/*    */   
/*    */   private BeanDescriptionFactory getBeanDescriptionFactory() {
/* 32 */     if (this.beanDescriptionFactory == null) {
/* 33 */       this.beanDescriptionFactory = new BeanDescriptionFactory(getContext());
/*    */     }
/* 35 */     return this.beanDescriptionFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BeanDescription getBeanDescription(Class<?> clazz) {
/* 47 */     if (!this.classToBeanDescription.containsKey(clazz)) {
/* 48 */       BeanDescription beanDescription = getBeanDescriptionFactory().create(clazz);
/* 49 */       this.classToBeanDescription.put(clazz, beanDescription);
/*    */     } 
/* 51 */     return this.classToBeanDescription.get(clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\beans\BeanDescriptionCache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */