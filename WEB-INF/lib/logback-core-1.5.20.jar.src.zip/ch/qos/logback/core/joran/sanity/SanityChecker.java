/*    */ package ch.qos.logback.core.joran.sanity;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SanityChecker
/*    */ {
/*    */   default void deepFindAllModelsOfType(Class<? extends Model> modelClass, List<Model> modelList, Model model) {
/* 31 */     if (modelClass.isInstance(model)) {
/* 32 */       modelList.add(model);
/*    */     }
/*    */     
/* 35 */     for (Model m : model.getSubModels()) {
/* 36 */       deepFindAllModelsOfType(modelClass, modelList, m);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   default List<Pair<Model, Model>> deepFindNestedSubModelsOfType(Class<? extends Model> modelClass, List<? extends Model> parentList) {
/* 42 */     List<Pair<Model, Model>> nestingPairs = new ArrayList<>();
/*    */     
/* 44 */     for (Model parent : parentList) {
/* 45 */       List<Model> nestedElements = new ArrayList<>();
/* 46 */       parent.getSubModels().stream().forEach(m -> deepFindAllModelsOfType(modelClass, nestedElements, m));
/* 47 */       nestedElements.forEach(n -> nestingPairs.add(new Pair<>(parent, n)));
/*    */     } 
/* 49 */     return nestingPairs;
/*    */   }
/*    */   
/*    */   void check(Model paramModel);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\sanity\SanityChecker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */