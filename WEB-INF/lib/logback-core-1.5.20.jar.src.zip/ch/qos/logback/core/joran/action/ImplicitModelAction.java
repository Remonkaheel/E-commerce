/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.ActionException;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.ImplicitModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import java.util.Stack;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplicitModelAction
/*    */   extends Action
/*    */ {
/* 37 */   Stack<ImplicitModel> currentImplicitModelStack = new Stack<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public void begin(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) throws ActionException {
/* 42 */     ImplicitModel currentImplicitModel = new ImplicitModel();
/* 43 */     currentImplicitModel.setTag(name);
/*    */     
/* 45 */     String className = attributes.getValue("class");
/* 46 */     currentImplicitModel.setClassName(className);
/* 47 */     this.currentImplicitModelStack.push(currentImplicitModel);
/* 48 */     interpretationContext.pushModel((Model)currentImplicitModel);
/*    */   }
/*    */ 
/*    */   
/*    */   public void body(SaxEventInterpretationContext ec, String body) {
/* 53 */     ImplicitModel implicitModel = this.currentImplicitModelStack.peek();
/* 54 */     implicitModel.addText(body);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void end(SaxEventInterpretationContext interpretationContext, String name) throws ActionException {
/* 60 */     ImplicitModel implicitModel = this.currentImplicitModelStack.peek();
/* 61 */     Model otherImplicitModel = interpretationContext.popModel();
/*    */     
/* 63 */     if (implicitModel != otherImplicitModel) {
/* 64 */       addError(String.valueOf(implicitModel) + " does not match " + String.valueOf(implicitModel));
/*    */       return;
/*    */     } 
/* 67 */     Model parentModel = interpretationContext.peekModel();
/* 68 */     if (parentModel != null) {
/* 69 */       parentModel.addSubModel((Model)implicitModel);
/*    */     } else {
/* 71 */       addWarn("Could not find parent model.");
/* 72 */       addWarn(" Will not add current implicit model as subModel.");
/*    */     } 
/* 74 */     this.currentImplicitModelStack.pop();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ImplicitModelAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */