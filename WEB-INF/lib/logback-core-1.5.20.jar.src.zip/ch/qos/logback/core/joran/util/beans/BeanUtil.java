/*     */ package ch.qos.logback.core.joran.util.beans;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanUtil
/*     */ {
/*     */   public static final String PREFIX_GETTER_IS = "is";
/*     */   public static final String PREFIX_GETTER_GET = "get";
/*     */   public static final String PREFIX_SETTER = "set";
/*     */   public static final String PREFIX_ADDER = "add";
/*     */   
/*     */   public static boolean isAdder(Method method) {
/*  25 */     int parameterCount = getParameterCount(method);
/*  26 */     if (parameterCount != 1) {
/*  27 */       return false;
/*     */     }
/*  29 */     Class<?> returnType = method.getReturnType();
/*  30 */     if (returnType != void.class) {
/*  31 */       return false;
/*     */     }
/*  33 */     String methodName = method.getName();
/*  34 */     return methodName.startsWith("add");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isGetter(Method method) {
/*  43 */     int parameterCount = getParameterCount(method);
/*  44 */     if (parameterCount > 0) {
/*  45 */       return false;
/*     */     }
/*  47 */     Class<?> returnType = method.getReturnType();
/*  48 */     if (returnType == void.class) {
/*  49 */       return false;
/*     */     }
/*  51 */     String methodName = method.getName();
/*  52 */     if (!methodName.startsWith("get") && !methodName.startsWith("is")) {
/*  53 */       return false;
/*     */     }
/*  55 */     if (methodName.startsWith("is") && 
/*  56 */       !returnType.equals(boolean.class) && !returnType.equals(Boolean.class)) {
/*  57 */       return false;
/*     */     }
/*     */     
/*  60 */     return true;
/*     */   }
/*     */   
/*     */   private static int getParameterCount(Method method) {
/*  64 */     return (method.getParameterTypes()).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSetter(Method method) {
/*  73 */     int parameterCount = getParameterCount(method);
/*  74 */     if (parameterCount != 1) {
/*  75 */       return false;
/*     */     }
/*  77 */     Class<?> returnType = method.getReturnType();
/*  78 */     if (returnType != void.class) {
/*  79 */       return false;
/*     */     }
/*  81 */     String methodName = method.getName();
/*  82 */     if (!methodName.startsWith("set")) {
/*  83 */       return false;
/*     */     }
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPropertyName(Method method) {
/*  94 */     String methodName = method.getName();
/*  95 */     String rawPropertyName = getSubstringIfPrefixMatches(methodName, "get");
/*  96 */     if (rawPropertyName == null) {
/*  97 */       rawPropertyName = getSubstringIfPrefixMatches(methodName, "set");
/*     */     }
/*  99 */     if (rawPropertyName == null) {
/* 100 */       rawPropertyName = getSubstringIfPrefixMatches(methodName, "is");
/*     */     }
/* 102 */     if (rawPropertyName == null) {
/* 103 */       rawPropertyName = getSubstringIfPrefixMatches(methodName, "add");
/*     */     }
/* 105 */     return toLowerCamelCase(rawPropertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toLowerCamelCase(String string) {
/* 118 */     if (string == null) {
/* 119 */       return null;
/*     */     }
/* 121 */     if (string.isEmpty()) {
/* 122 */       return string;
/*     */     }
/* 124 */     if (string.length() > 1 && Character.isUpperCase(string.charAt(1)) && Character.isUpperCase(string.charAt(0))) {
/* 125 */       return string;
/*     */     }
/* 127 */     char[] chars = string.toCharArray();
/* 128 */     chars[0] = Character.toLowerCase(chars[0]);
/* 129 */     return new String(chars);
/*     */   }
/*     */   
/*     */   private static String getSubstringIfPrefixMatches(String wholeString, String prefix) {
/* 133 */     if (wholeString.startsWith(prefix)) {
/* 134 */       return wholeString.substring(prefix.length());
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\beans\BeanUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */