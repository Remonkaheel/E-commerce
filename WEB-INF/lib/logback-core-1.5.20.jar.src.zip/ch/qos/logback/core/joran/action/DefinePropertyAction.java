/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.DefineModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefinePropertyAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext ic, String name, Attributes attributes) {
/* 33 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, ic, name, attributes);
/* 34 */     validator.validateClassAttribute();
/* 35 */     validator.validateNameAttribute();
/* 36 */     return validator.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 42 */     DefineModel defineModel = new DefineModel();
/* 43 */     defineModel.setClassName(attributes.getValue("class"));
/* 44 */     defineModel.setName(attributes.getValue("name"));
/* 45 */     defineModel.setScopeStr(attributes.getValue("scope"));
/* 46 */     return (Model)defineModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\DefinePropertyAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */