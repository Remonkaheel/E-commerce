/*    */ package ch.qos.logback.core.joran.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.ElseModel;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElseAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpcont, String name, Attributes attributes) {
/* 28 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, interpcont, name, attributes);
/* 29 */     pv.validateZeroAttributes();
/* 30 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 36 */     ElseModel elseModel = new ElseModel();
/* 37 */     return (Model)elseModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\conditional\ElseAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */