/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.ConversionRuleModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversionRuleAction
/*    */   extends BaseModelAction
/*    */ {
/* 31 */   public static String CONVERTER_CLASS_ATTRIBUTE = "converterClass";
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext seic, String name, Attributes attributes) {
/* 36 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, seic, name, attributes);
/*    */     
/* 38 */     boolean invalidConverterClassAttribute = pv.isInvalidAttribute(CONVERTER_CLASS_ATTRIBUTE);
/* 39 */     boolean invalidClassAttribute = pv.isInvalidAttribute("class");
/*    */     
/* 41 */     if (!invalidConverterClassAttribute) {
/* 42 */       pv.addWarn("[" + CONVERTER_CLASS_ATTRIBUTE + "] attribute is deprecated and replaced by [class]. " + pv
/* 43 */           .getLocationSuffix());
/*    */     }
/* 45 */     boolean missingClass = (invalidClassAttribute && invalidConverterClassAttribute);
/* 46 */     if (missingClass) {
/* 47 */       pv.addMissingAttributeError("class");
/* 48 */       return false;
/*    */     } 
/*    */     
/* 51 */     boolean multipleClassAttributes = (!invalidClassAttribute && !invalidConverterClassAttribute);
/* 52 */     if (multipleClassAttributes) {
/* 53 */       pv.addWarn("Both [" + CONVERTER_CLASS_ATTRIBUTE + "] attribute and [class] attribute specified. ");
/* 54 */       pv.addWarn("[class] attribute will override. ");
/*    */     } 
/* 56 */     pv.validateGivenAttribute("conversionWord");
/* 57 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 65 */     ConversionRuleModel conversionRuleModel = new ConversionRuleModel();
/* 66 */     conversionRuleModel.setConversionWord(attributes.getValue("conversionWord"));
/*    */     
/* 68 */     String converterClassStr = attributes.getValue(CONVERTER_CLASS_ATTRIBUTE);
/* 69 */     if (!OptionHelper.isNullOrEmpty(converterClassStr)) {
/* 70 */       conversionRuleModel.setClassName(converterClassStr);
/*    */     }
/*    */     
/* 73 */     String classStr = attributes.getValue("class");
/* 74 */     if (!OptionHelper.isNullOrEmpty(classStr)) {
/* 75 */       conversionRuleModel.setClassName(classStr);
/*    */     }
/* 77 */     return (Model)conversionRuleModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ConversionRuleAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */