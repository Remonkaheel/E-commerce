/*    */ package ch.qos.logback.core.joran.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.ByPropertiesConditionModel;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByPropertiesConditionAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 29 */     ByPropertiesConditionModel sngm = new ByPropertiesConditionModel();
/* 30 */     sngm.setClassName(attributes.getValue("class"));
/* 31 */     return (Model)sngm;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext seic, String name, Attributes attributes) {
/* 36 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, seic, name, attributes);
/* 37 */     validator.validateClassAttribute();
/* 38 */     return validator.isValid();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\conditional\ByPropertiesConditionAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */