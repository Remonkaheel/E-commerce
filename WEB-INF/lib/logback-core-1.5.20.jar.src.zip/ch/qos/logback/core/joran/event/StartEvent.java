/*    */ package ch.qos.logback.core.joran.event;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.ElementPath;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.Locator;
/*    */ import org.xml.sax.helpers.AttributesImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartEvent
/*    */   extends SaxEvent
/*    */ {
/*    */   public final Attributes attributes;
/*    */   public final ElementPath elementPath;
/*    */   
/*    */   StartEvent(ElementPath elementPath, String namespaceURI, String localName, String qName, Attributes attributes, Locator locator) {
/* 28 */     super(namespaceURI, localName, qName, locator);
/*    */     
/* 30 */     this.attributes = new AttributesImpl(attributes);
/* 31 */     this.elementPath = elementPath;
/*    */   }
/*    */   
/*    */   public Attributes getAttributes() {
/* 35 */     return this.attributes;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 40 */     StringBuilder b = new StringBuilder("StartEvent(");
/* 41 */     b.append(getQName());
/* 42 */     if (this.attributes != null) {
/* 43 */       for (int i = 0; i < this.attributes.getLength(); i++) {
/* 44 */         b.append(' ');
/* 45 */         b.append(this.attributes.getLocalName(i)).append("=\"").append(this.attributes.getValue(i)).append("\"");
/*    */       } 
/*    */     }
/* 48 */     b.append(")  [");
/* 49 */     b.append(this.locator.getLineNumber());
/* 50 */     b.append(",");
/* 51 */     b.append(this.locator.getColumnNumber());
/* 52 */     b.append("]");
/* 53 */     return b.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\event\StartEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */