/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.AppenderModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ public class AppenderAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext ic, String name, Attributes attributes) {
/* 13 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, ic, name, attributes);
/* 14 */     validator.validateClassAttribute();
/* 15 */     validator.validateNameAttribute();
/* 16 */     return validator.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 22 */     AppenderModel appenderModel = new AppenderModel();
/* 23 */     appenderModel.setClassName(attributes.getValue("class"));
/* 24 */     appenderModel.setName(attributes.getValue("name"));
/* 25 */     return (Model)appenderModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\AppenderAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */