/*    */ package ch.qos.logback.core.joran.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   public static final String CONDITION_ATTRIBUTE = "condition";
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpcont, String name, Attributes attributes) {
/* 31 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, interpcont, name, attributes);
/*    */     
/* 33 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 39 */     IfModel ifModel = new IfModel();
/*    */     
/* 41 */     String condition = attributes.getValue("condition");
/* 42 */     ifModel.setCondition(condition);
/*    */     
/* 44 */     return (Model)ifModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\conditional\IfAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */