/*    */ package ch.qos.logback.core.joran.util.beans;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanDescriptionFactory
/*    */   extends ContextAwareBase
/*    */ {
/*    */   BeanDescriptionFactory(Context context) {
/* 24 */     setContext(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BeanDescription create(Class<?> clazz) {
/* 33 */     Map<String, Method> propertyNameToGetter = new HashMap<>();
/* 34 */     Map<String, Method> propertyNameToSetter = new HashMap<>();
/* 35 */     Map<String, Method> propertyNameToAdder = new HashMap<>();
/* 36 */     Method[] methods = clazz.getMethods();
/* 37 */     for (Method method : methods) {
/* 38 */       if (!method.isBridge())
/*    */       {
/*    */ 
/*    */         
/* 42 */         if (BeanUtil.isGetter(method)) {
/* 43 */           String propertyName = BeanUtil.getPropertyName(method);
/* 44 */           Method oldGetter = propertyNameToGetter.put(propertyName, method);
/* 45 */           if (oldGetter != null) {
/* 46 */             if (oldGetter.getName().startsWith("is")) {
/* 47 */               propertyNameToGetter.put(propertyName, oldGetter);
/*    */             }
/* 49 */             String message = String.format("Class '%s' contains multiple getters for the same property '%s'.", new Object[] { clazz
/* 50 */                   .getCanonicalName(), propertyName });
/* 51 */             addWarn(message);
/*    */           } 
/* 53 */         } else if (BeanUtil.isSetter(method)) {
/* 54 */           String propertyName = BeanUtil.getPropertyName(method);
/* 55 */           Method oldSetter = propertyNameToSetter.put(propertyName, method);
/* 56 */           if (oldSetter != null) {
/* 57 */             String message = String.format("Class '%s' contains multiple setters for the same property '%s'.", new Object[] { clazz
/* 58 */                   .getCanonicalName(), propertyName });
/* 59 */             addWarn(message);
/*    */           } 
/* 61 */         } else if (BeanUtil.isAdder(method)) {
/* 62 */           String propertyName = BeanUtil.getPropertyName(method);
/* 63 */           Method oldAdder = propertyNameToAdder.put(propertyName, method);
/* 64 */           if (oldAdder != null) {
/* 65 */             String message = String.format("Class '%s' contains multiple adders for the same property '%s'.", new Object[] { clazz
/* 66 */                   .getCanonicalName(), propertyName });
/* 67 */             addWarn(message);
/*    */           } 
/*    */         }  } 
/*    */     } 
/* 71 */     return new BeanDescription(clazz, propertyNameToGetter, propertyNameToSetter, propertyNameToAdder);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\beans\BeanDescriptionFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */