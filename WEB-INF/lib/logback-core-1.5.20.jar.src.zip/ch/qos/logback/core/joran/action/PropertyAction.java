/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.PropertyModel;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   static final String RESOURCE_ATTRIBUTE = "resource";
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpretationContext, String localName, Attributes attributes) {
/* 35 */     if ("substitutionProperty".equals(localName)) {
/* 36 */       addWarn("[substitutionProperty] element has been deprecated. Please use the [variable] element instead.");
/*    */     }
/* 38 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 44 */     PropertyModel propertyModel = new PropertyModel();
/* 45 */     propertyModel.setName(attributes.getValue("name"));
/* 46 */     propertyModel.setValue(attributes.getValue("value"));
/* 47 */     propertyModel.setFile(attributes.getValue("file"));
/* 48 */     propertyModel.setResource(attributes.getValue("resource"));
/* 49 */     propertyModel.setScopeStr(attributes.getValue("scope"));
/* 50 */     return (Model)propertyModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\PropertyAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */