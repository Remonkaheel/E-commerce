/*    */ package ch.qos.logback.core.joran.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParentTag_Tag_Class_Tuple
/*    */ {
/*    */   public final String parentTag;
/*    */   public final String tag;
/*    */   public final String className;
/*    */   
/*    */   public ParentTag_Tag_Class_Tuple(String parentTag, String tag, String className) {
/* 34 */     this.parentTag = parentTag;
/* 35 */     this.tag = tag;
/* 36 */     this.className = className;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 41 */     return "ParentTag_Tag_Class_Tuple [parentTag=" + this.parentTag + ", tag=" + this.tag + ", className=" + this.className + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\ParentTag_Tag_Class_Tuple.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */