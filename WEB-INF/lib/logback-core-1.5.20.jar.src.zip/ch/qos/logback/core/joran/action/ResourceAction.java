/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.ActionException;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.ResourceModel;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceAction
/*    */   extends Action
/*    */ {
/*    */   private static final String FILE_ATTR = "file";
/*    */   private static final String URL_ATTR = "url";
/*    */   private static final String RESOURCE_ATTR = "resource";
/*    */   private static final String OPTIONAL_ATTR = "optional";
/*    */   Model parentModel;
/*    */   ResourceModel resourceModel;
/*    */   boolean inError = false;
/*    */   
/*    */   protected abstract ResourceModel makeNewResourceModel();
/*    */   
/*    */   public void begin(SaxEventInterpretationContext seic, String tagName, Attributes attributes) throws ActionException {
/* 43 */     String optionalStr = attributes.getValue("optional");
/*    */     
/* 45 */     this.resourceModel = makeNewResourceModel();
/* 46 */     this.resourceModel.setOptional(optionalStr);
/* 47 */     fillInIncludeModelAttributes(this.resourceModel, tagName, attributes);
/* 48 */     if (!seic.isModelStackEmpty()) {
/* 49 */       this.parentModel = seic.peekModel();
/*    */     }
/* 51 */     int lineNumber = getLineNumber(seic);
/* 52 */     this.resourceModel.setLineNumber(lineNumber);
/* 53 */     seic.pushModel((Model)this.resourceModel);
/*    */   }
/*    */   
/*    */   private void fillInIncludeModelAttributes(ResourceModel resourceModel, String tagName, Attributes attributes) {
/* 57 */     this.resourceModel.setTag(tagName);
/* 58 */     String fileAttribute = attributes.getValue("file");
/* 59 */     String urlAttribute = attributes.getValue("url");
/* 60 */     String resourceAttribute = attributes.getValue("resource");
/*    */     
/* 62 */     this.resourceModel.setFile(fileAttribute);
/* 63 */     this.resourceModel.setUrl(urlAttribute);
/* 64 */     this.resourceModel.setResource(resourceAttribute);
/*    */   }
/*    */ 
/*    */   
/*    */   public void end(SaxEventInterpretationContext seic, String name) throws ActionException {
/* 69 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 72 */     Model m = seic.peekModel();
/*    */     
/* 74 */     if (m != this.resourceModel) {
/* 75 */       addWarn("The object at the of the stack is not the model [" + this.resourceModel.idString() + "] pushed earlier.");
/*    */       
/* 77 */       addWarn("This is wholly unexpected.");
/*    */     } 
/*    */ 
/*    */     
/* 81 */     if (this.parentModel != null) {
/* 82 */       this.parentModel.addSubModel((Model)this.resourceModel);
/* 83 */       seic.popModel();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ResourceAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */