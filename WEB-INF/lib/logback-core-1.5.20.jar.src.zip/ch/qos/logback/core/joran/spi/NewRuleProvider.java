package ch.qos.logback.core.joran.spi;

import ch.qos.logback.core.model.processor.DefaultProcessor;

public interface NewRuleProvider {
  void addPathActionAssociations(RuleStore paramRuleStore);
  
  void addModelHandlerAssociations(DefaultProcessor paramDefaultProcessor);
  
  void addModelAnalyserAssociations(DefaultProcessor paramDefaultProcessor);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\NewRuleProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */