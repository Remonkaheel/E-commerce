/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.util.PropertySetter;
/*    */ import ch.qos.logback.core.util.AggregationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplicitModelData
/*    */ {
/*    */   public final PropertySetter parentBean;
/*    */   public final AggregationType aggregationType;
/*    */   public final String propertyName;
/*    */   public boolean inError;
/*    */   
/*    */   public ImplicitModelData(PropertySetter parentBean, AggregationType aggregationType, String propertyName) {
/* 31 */     this.parentBean = parentBean;
/* 32 */     this.aggregationType = aggregationType;
/* 33 */     this.propertyName = propertyName;
/*    */   }
/*    */   
/*    */   public AggregationType getAggregationType() {
/* 37 */     return this.aggregationType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ImplicitModelData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */