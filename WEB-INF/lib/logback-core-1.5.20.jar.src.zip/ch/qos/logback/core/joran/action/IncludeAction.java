/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.model.IncludeModel;
/*    */ import ch.qos.logback.core.model.ResourceModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncludeAction
/*    */   extends ResourceAction
/*    */ {
/*    */   protected ResourceModel makeNewResourceModel() {
/* 28 */     return (ResourceModel)new IncludeModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\IncludeAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */