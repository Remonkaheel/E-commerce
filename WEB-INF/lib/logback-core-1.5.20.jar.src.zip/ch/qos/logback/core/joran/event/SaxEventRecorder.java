/*     */ package ch.qos.logback.core.joran.event;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.ElementPath;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareImpl;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaxEventRecorder
/*     */   extends DefaultHandler
/*     */   implements ContextAware
/*     */ {
/*     */   final ContextAwareImpl contextAwareImpl;
/*     */   final ElementPath elementPath;
/*  47 */   List<SaxEvent> saxEventList = new ArrayList<>();
/*     */   
/*     */   Locator locator;
/*     */   
/*     */   public SaxEventRecorder(Context context) {
/*  52 */     this(context, new ElementPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public SaxEventRecorder(Context context, ElementPath elementPath) {
/*  57 */     this.contextAwareImpl = new ContextAwareImpl(context, this);
/*  58 */     this.elementPath = elementPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
/*  75 */     addWarn("Document Type Declaration (DOCTYPE) with external file reference is");
/*  76 */     addWarn("disallowed to prevent Server-Side Request Forgery (SSRF) attacks.");
/*  77 */     addWarn("returning contents of SYSTEM " + systemId + " as a white space");
/*  78 */     return new InputSource(new ByteArrayInputStream(" ".getBytes()));
/*     */   }
/*     */   
/*     */   public final void recordEvents(InputStream inputStream) throws JoranException {
/*  82 */     recordEvents(new InputSource(inputStream));
/*     */   }
/*     */   
/*     */   public void recordEvents(InputSource inputSource) throws JoranException {
/*  86 */     SAXParser saxParser = buildSaxParser();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  92 */       saxParser.parse(inputSource, this);
/*     */       
/*     */       return;
/*  95 */     } catch (IOException ie) {
/*  96 */       handleError("I/O error occurred while parsing xml file", ie);
/*  97 */     } catch (SAXException se) {
/*     */       
/*  99 */       throw new JoranException("Problem parsing XML document. See previously reported errors.", se);
/* 100 */     } catch (Exception ex) {
/* 101 */       handleError("Unexpected exception while parsing XML document.", ex);
/*     */     } 
/* 103 */     throw new IllegalStateException("This point can never be reached");
/*     */   }
/*     */   
/*     */   private void handleError(String errMsg, Throwable t) throws JoranException {
/* 107 */     addError(errMsg, t);
/* 108 */     throw new JoranException(errMsg, t);
/*     */   }
/*     */   
/*     */   private SAXParser buildSaxParser() throws JoranException {
/*     */     try {
/* 113 */       SAXParserFactory spf = SAXParserFactory.newInstance();
/* 114 */       spf.setValidating(false);
/*     */ 
/*     */       
/* 117 */       spf.setFeature("http://xml.org/sax/features/external-general-entities", false);
/* 118 */       spf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
/* 119 */       spf.setNamespaceAware(true);
/* 120 */       return spf.newSAXParser();
/* 121 */     } catch (ParserConfigurationException pce) {
/* 122 */       String errMsg = "Error during SAX paser configuration. See https://logback.qos.ch/codes.html#saxParserConfiguration";
/* 123 */       addError(errMsg, pce);
/* 124 */       throw new JoranException(errMsg, pce);
/* 125 */     } catch (SAXException pce) {
/* 126 */       String errMsg = "Error during parser creation or parser configuration";
/* 127 */       addError(errMsg, pce);
/* 128 */       throw new JoranException(errMsg, pce);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() {}
/*     */   
/*     */   public Locator getLocator() {
/* 136 */     return this.locator;
/*     */   }
/*     */   
/*     */   public void setDocumentLocator(Locator l) {
/* 140 */     this.locator = l;
/*     */   }
/*     */   
/*     */   protected boolean shouldIgnoreForElementPath(String tagName) {
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   public void startElement(String namespaceURI, String localName, String qName, Attributes atts) {
/* 148 */     String tagName = getTagName(localName, qName);
/* 149 */     if (!shouldIgnoreForElementPath(tagName)) {
/* 150 */       this.elementPath.push(tagName);
/*     */     }
/* 152 */     ElementPath current = this.elementPath.duplicate();
/* 153 */     this.saxEventList.add(new StartEvent(current, namespaceURI, localName, qName, atts, getLocator()));
/*     */   }
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/* 157 */     String bodyStr = new String(ch, start, length);
/* 158 */     SaxEvent lastEvent = getLastEvent();
/* 159 */     if (lastEvent instanceof BodyEvent) {
/* 160 */       BodyEvent be = (BodyEvent)lastEvent;
/* 161 */       be.append(bodyStr);
/*     */     
/*     */     }
/* 164 */     else if (!isSpaceOnly(bodyStr)) {
/* 165 */       this.saxEventList.add(new BodyEvent(bodyStr, getLocator()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isSpaceOnly(String bodyStr) {
/* 171 */     String bodyTrimmed = bodyStr.trim();
/* 172 */     return (bodyTrimmed.length() == 0);
/*     */   }
/*     */   
/*     */   SaxEvent getLastEvent() {
/* 176 */     if (this.saxEventList.isEmpty()) {
/* 177 */       return null;
/*     */     }
/* 179 */     int size = this.saxEventList.size();
/* 180 */     return this.saxEventList.get(size - 1);
/*     */   }
/*     */   
/*     */   public void endElement(String namespaceURI, String localName, String qName) {
/* 184 */     this.saxEventList.add(new EndEvent(namespaceURI, localName, qName, getLocator()));
/* 185 */     String tagName = getTagName(localName, qName);
/* 186 */     if (!shouldIgnoreForElementPath(tagName)) {
/* 187 */       this.elementPath.pop();
/*     */     }
/*     */   }
/*     */   
/*     */   String getTagName(String localName, String qName) {
/* 192 */     String tagName = localName;
/* 193 */     if (tagName == null || tagName.length() < 1) {
/* 194 */       tagName = qName;
/*     */     }
/* 196 */     return tagName;
/*     */   }
/*     */   
/*     */   public void error(SAXParseException spe) throws SAXException {
/* 200 */     addError("XML_PARSING - Parsing error on line " + spe.getLineNumber() + " and column " + spe.getColumnNumber());
/* 201 */     addError(spe.toString());
/*     */   }
/*     */   
/*     */   public void fatalError(SAXParseException spe) throws SAXException {
/* 205 */     addError("XML_PARSING - Parsing fatal error on line " + spe.getLineNumber() + " and column " + spe.getColumnNumber());
/* 206 */     addError(spe.toString());
/*     */   }
/*     */   
/*     */   public void warning(SAXParseException spe) throws SAXException {
/* 210 */     addWarn("XML_PARSING - Parsing warning on line " + spe.getLineNumber() + " and column " + spe.getColumnNumber(), spe);
/*     */   }
/*     */   
/*     */   public void addError(String msg) {
/* 214 */     this.contextAwareImpl.addError(msg);
/*     */   }
/*     */   
/*     */   public void addError(String msg, Throwable ex) {
/* 218 */     this.contextAwareImpl.addError(msg, ex);
/*     */   }
/*     */   
/*     */   public void addInfo(String msg) {
/* 222 */     this.contextAwareImpl.addInfo(msg);
/*     */   }
/*     */   
/*     */   public void addInfo(String msg, Throwable ex) {
/* 226 */     this.contextAwareImpl.addInfo(msg, ex);
/*     */   }
/*     */   
/*     */   public void addStatus(Status status) {
/* 230 */     this.contextAwareImpl.addStatus(status);
/*     */   }
/*     */   
/*     */   public void addWarn(String msg) {
/* 234 */     this.contextAwareImpl.addWarn(msg);
/*     */   }
/*     */   
/*     */   public void addWarn(String msg, Throwable ex) {
/* 238 */     this.contextAwareImpl.addWarn(msg, ex);
/*     */   }
/*     */   
/*     */   public Context getContext() {
/* 242 */     return this.contextAwareImpl.getContext();
/*     */   }
/*     */   
/*     */   public void setContext(Context context) {
/* 246 */     this.contextAwareImpl.setContext(context);
/*     */   }
/*     */   
/*     */   public List<SaxEvent> getSaxEventList() {
/* 250 */     return this.saxEventList;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\event\SaxEventRecorder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */