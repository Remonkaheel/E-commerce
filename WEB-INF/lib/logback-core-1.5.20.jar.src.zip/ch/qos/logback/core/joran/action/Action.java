/*     */ package ch.qos.logback.core.joran.action;
/*     */ 
/*     */ import ch.qos.logback.core.joran.spi.ActionException;
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpreter;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Action
/*     */   extends ContextAwareBase
/*     */ {
/*     */   public static final String NAME_ATTRIBUTE = "name";
/*     */   public static final String KEY_ATTRIBUTE = "key";
/*     */   public static final String VALUE_ATTRIBUTE = "value";
/*     */   public static final String FILE_ATTRIBUTE = "file";
/*     */   public static final String CLASS_ATTRIBUTE = "class";
/*     */   public static final String PATTERN_ATTRIBUTE = "pattern";
/*     */   public static final String SCOPE_ATTRIBUTE = "scope";
/*     */   public static final String ACTION_CLASS_ATTRIBUTE = "actionClass";
/*     */   
/*     */   public abstract void begin(SaxEventInterpretationContext paramSaxEventInterpretationContext, String paramString, Attributes paramAttributes) throws ActionException;
/*     */   
/*     */   public void body(SaxEventInterpretationContext intercon, String body) throws ActionException {}
/*     */   
/*     */   public abstract void end(SaxEventInterpretationContext paramSaxEventInterpretationContext, String paramString) throws ActionException;
/*     */   
/*     */   public String toString() {
/*  77 */     return getClass().getName();
/*     */   }
/*     */   
/*     */   protected int getColumnNumber(SaxEventInterpretationContext intercon) {
/*  81 */     SaxEventInterpreter interpreter = intercon.getSaxEventInterpreter();
/*  82 */     if (interpreter == null) {
/*  83 */       return -1;
/*     */     }
/*  85 */     Locator locator = interpreter.getLocator();
/*  86 */     if (locator != null) {
/*  87 */       return locator.getColumnNumber();
/*     */     }
/*  89 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getLineNumber(SaxEventInterpretationContext intercon) {
/*  94 */     SaxEventInterpreter interpreter = intercon.getSaxEventInterpreter();
/*  95 */     if (interpreter == null)
/*  96 */       return -1; 
/*  97 */     Locator locator = interpreter.getLocator();
/*  98 */     if (locator != null) {
/*  99 */       return locator.getLineNumber();
/*     */     }
/* 101 */     return -1;
/*     */   }
/*     */   
/*     */   protected String getLineColStr(SaxEventInterpretationContext intercon) {
/* 105 */     return "line: " + getLineNumber(intercon) + ", column: " + getColumnNumber(intercon);
/*     */   }
/*     */   
/*     */   protected String atLine(SaxEventInterpretationContext intercon) {
/* 109 */     return "At line " + getLineNumber(intercon);
/*     */   }
/*     */   
/*     */   protected String nearLine(SaxEventInterpretationContext intercon) {
/* 113 */     return "Near line " + getLineNumber(intercon);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\Action.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */