/*     */ package ch.qos.logback.core.joran.spi;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.action.Action;
/*     */ import ch.qos.logback.core.joran.action.NOPAction;
/*     */ import ch.qos.logback.core.joran.event.BodyEvent;
/*     */ import ch.qos.logback.core.joran.event.EndEvent;
/*     */ import ch.qos.logback.core.joran.event.SaxEvent;
/*     */ import ch.qos.logback.core.joran.event.StartEvent;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import java.util.function.Supplier;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaxEventInterpreter
/*     */ {
/*  66 */   private static Action NOP_ACTION_SINGLETON = (Action)new NOPAction();
/*     */ 
/*     */   
/*     */   private final RuleStore ruleStore;
/*     */ 
/*     */   
/*     */   private final SaxEventInterpretationContext interpretationContext;
/*     */ 
/*     */   
/*     */   private Supplier<Action> implicitActionSupplier;
/*     */ 
/*     */   
/*     */   private final CAI_WithLocatorSupport cai;
/*     */ 
/*     */   
/*     */   private ElementPath elementPath;
/*     */   
/*     */   Locator locator;
/*     */   
/*     */   EventPlayer eventPlayer;
/*     */   
/*     */   Context context;
/*     */   
/*     */   Stack<Action> actionStack;
/*     */   
/*  91 */   ElementPath skip = null;
/*     */   
/*     */   public SaxEventInterpreter(Context context, RuleStore rs, ElementPath initialElementPath, List<SaxEvent> saxEvents) {
/*  94 */     this.context = context;
/*  95 */     this.cai = new CAI_WithLocatorSupport(context, this);
/*  96 */     this.ruleStore = rs;
/*  97 */     this.interpretationContext = new SaxEventInterpretationContext(context, this);
/*  98 */     this.elementPath = initialElementPath;
/*  99 */     this.actionStack = new Stack<>();
/* 100 */     this.eventPlayer = new EventPlayer(this, saxEvents);
/*     */   }
/*     */   
/*     */   public EventPlayer getEventPlayer() {
/* 104 */     return this.eventPlayer;
/*     */   }
/*     */   
/*     */   public ElementPath getCopyOfElementPath() {
/* 108 */     return this.elementPath.duplicate();
/*     */   }
/*     */   
/*     */   public SaxEventInterpretationContext getSaxEventInterpretationContext() {
/* 112 */     return this.interpretationContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() {}
/*     */   
/*     */   public void startElement(StartEvent se) {
/* 119 */     setDocumentLocator(se.getLocator());
/* 120 */     startElement(se.namespaceURI, se.localName, se.qName, se.attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   private void startElement(String namespaceURI, String localName, String qName, Attributes atts) {
/* 125 */     String tagName = getTagName(localName, qName);
/*     */ 
/*     */     
/* 128 */     this.elementPath.push(tagName);
/*     */     
/* 130 */     if (this.skip != null) {
/*     */       
/* 132 */       pushEmptyActionOntoActionStack();
/*     */       
/*     */       return;
/*     */     } 
/* 136 */     Action applicableAction = getApplicableAction(this.elementPath, atts);
/* 137 */     if (applicableAction != null) {
/* 138 */       this.actionStack.add(applicableAction);
/* 139 */       callBeginAction(applicableAction, tagName, atts);
/*     */     } else {
/*     */       
/* 142 */       pushEmptyActionOntoActionStack();
/* 143 */       String errMsg = "no applicable action for [" + tagName + "], current ElementPath  is [" + String.valueOf(this.elementPath) + "]";
/* 144 */       this.cai.addError(errMsg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pushEmptyActionOntoActionStack() {
/* 152 */     this.actionStack.push(NOP_ACTION_SINGLETON);
/*     */   }
/*     */ 
/*     */   
/*     */   public void characters(BodyEvent be) {
/* 157 */     setDocumentLocator(be.locator);
/*     */     
/* 159 */     String body = be.getText();
/* 160 */     Action applicableAction = this.actionStack.peek();
/*     */     
/* 162 */     if (body != null) {
/* 163 */       body = body.trim();
/* 164 */       if (body.length() > 0) {
/* 165 */         callBodyAction(applicableAction, body);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endElement(EndEvent endEvent) {
/* 171 */     setDocumentLocator(endEvent.locator);
/* 172 */     endElement(endEvent.namespaceURI, endEvent.localName, endEvent.qName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void endElement(String namespaceURI, String localName, String qName) {
/* 178 */     Action applicableAction = this.actionStack.pop();
/*     */     
/* 180 */     if (this.skip != null) {
/* 181 */       if (this.skip.equals(this.elementPath)) {
/* 182 */         this.skip = null;
/*     */       }
/* 184 */     } else if (applicableAction != NOP_ACTION_SINGLETON) {
/* 185 */       callEndAction(applicableAction, getTagName(localName, qName));
/*     */     } 
/*     */ 
/*     */     
/* 189 */     this.elementPath.pop();
/*     */   }
/*     */   
/*     */   public Locator getLocator() {
/* 193 */     return this.locator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator l) {
/* 198 */     this.locator = l;
/*     */   }
/*     */   
/*     */   String getTagName(String localName, String qName) {
/* 202 */     String tagName = localName;
/*     */     
/* 204 */     if (tagName == null || tagName.length() < 1) {
/* 205 */       tagName = qName;
/*     */     }
/*     */     
/* 208 */     return tagName;
/*     */   }
/*     */   
/*     */   public void setImplicitActionSupplier(Supplier<Action> actionSupplier) {
/* 212 */     this.implicitActionSupplier = actionSupplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Action getApplicableAction(ElementPath elementPath, Attributes attributes) {
/* 219 */     Supplier<Action> applicableActionSupplier = this.ruleStore.matchActions(elementPath);
/*     */     
/* 221 */     if (applicableActionSupplier != null) {
/* 222 */       Action applicableAction = applicableActionSupplier.get();
/* 223 */       applicableAction.setContext(this.context);
/* 224 */       return applicableAction;
/*     */     } 
/* 226 */     Action implicitAction = this.implicitActionSupplier.get();
/* 227 */     implicitAction.setContext(this.context);
/* 228 */     return implicitAction;
/*     */   }
/*     */ 
/*     */   
/*     */   void callBeginAction(Action applicableAction, String tagName, Attributes atts) {
/* 233 */     if (applicableAction == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 240 */       applicableAction.begin(this.interpretationContext, tagName, atts);
/* 241 */     } catch (ActionException e) {
/* 242 */       this.skip = this.elementPath.duplicate();
/* 243 */       this.cai.addError("ActionException in Action for tag [" + tagName + "]", e);
/* 244 */     } catch (RuntimeException e) {
/* 245 */       this.skip = this.elementPath.duplicate();
/* 246 */       this.cai.addError("RuntimeException in Action for tag [" + tagName + "]", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void callBodyAction(Action applicableAction, String body) {
/* 252 */     if (applicableAction == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 257 */       applicableAction.body(this.interpretationContext, body);
/* 258 */     } catch (ActionException ae) {
/* 259 */       this.cai.addError("Exception in body() method for action [" + String.valueOf(applicableAction) + "]", ae);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void callEndAction(Action applicableAction, String tagName) {
/* 264 */     if (applicableAction == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 269 */       applicableAction.end(this.interpretationContext, tagName);
/* 270 */     } catch (ActionException ae) {
/*     */ 
/*     */       
/* 273 */       this.cai.addError("ActionException in Action for tag [" + tagName + "]", ae);
/* 274 */     } catch (RuntimeException e) {
/*     */       
/* 276 */       this.cai.addError("RuntimeException in Action for tag [" + tagName + "]", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public RuleStore getRuleStore() {
/* 281 */     return this.ruleStore;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\SaxEventInterpreter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */