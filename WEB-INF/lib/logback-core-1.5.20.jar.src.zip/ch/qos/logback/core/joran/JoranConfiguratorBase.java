/*     */ package ch.qos.logback.core.joran;
/*     */ 
/*     */ import ch.qos.logback.core.joran.sanity.AppenderWithinAppenderSanityChecker;
/*     */ import ch.qos.logback.core.joran.sanity.SanityChecker;
/*     */ import ch.qos.logback.core.joran.spi.ElementSelector;
/*     */ import ch.qos.logback.core.joran.spi.RuleStore;
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpreter;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JoranConfiguratorBase<E>
/*     */   extends GenericXMLConfigurator
/*     */ {
/*     */   protected void addElementSelectorAndActionAssociations(RuleStore rs) {
/*  47 */     rs.addRule(new ElementSelector("*/variable"), ch.qos.logback.core.joran.action.PropertyAction::new);
/*  48 */     rs.addRule(new ElementSelector("*/property"), ch.qos.logback.core.joran.action.PropertyAction::new);
/*     */     
/*  50 */     rs.addRule(new ElementSelector("*/substitutionProperty"), ch.qos.logback.core.joran.action.PropertyAction::new);
/*     */     
/*  52 */     rs.addRule(new ElementSelector("configuration/import"), ch.qos.logback.core.joran.action.ImportAction::new);
/*     */ 
/*     */     
/*  55 */     rs.addRule(new ElementSelector("configuration/timestamp"), ch.qos.logback.core.joran.action.TimestampAction::new);
/*  56 */     rs.addRule(new ElementSelector("configuration/shutdownHook"), ch.qos.logback.core.joran.action.ShutdownHookAction::new);
/*  57 */     rs.addRule(new ElementSelector("configuration/sequenceNumberGenerator"), ch.qos.logback.core.joran.action.SequenceNumberGeneratorAction::new);
/*  58 */     rs.addRule(new ElementSelector("configuration/serializeModel"), ch.qos.logback.core.joran.action.SerializeModelAction::new);
/*     */     
/*  60 */     rs.addRule(new ElementSelector("configuration/define"), ch.qos.logback.core.joran.action.DefinePropertyAction::new);
/*  61 */     rs.addRule(new ElementSelector("configuration/evaluator"), ch.qos.logback.core.joran.action.EventEvaluatorAction::new);
/*     */ 
/*     */ 
/*     */     
/*  65 */     rs.addRule(new ElementSelector("configuration/contextProperty"), ch.qos.logback.core.joran.action.ContextPropertyAction::new);
/*     */     
/*  67 */     rs.addRule(new ElementSelector("configuration/conversionRule"), ch.qos.logback.core.joran.action.ConversionRuleAction::new);
/*     */     
/*  69 */     rs.addRule(new ElementSelector("configuration/statusListener"), ch.qos.logback.core.joran.action.StatusListenerAction::new);
/*     */     
/*  71 */     rs.addRule(new ElementSelector("*/appender"), ch.qos.logback.core.joran.action.AppenderAction::new);
/*  72 */     rs.addRule(new ElementSelector("configuration/appender/appender-ref"), ch.qos.logback.core.joran.action.AppenderRefAction::new);
/*  73 */     rs.addRule(new ElementSelector("configuration/newRule"), ch.qos.logback.core.joran.action.NewRuleAction::new);
/*     */     
/*  75 */     rs.addRule(new ElementSelector("*/param"), ch.qos.logback.core.joran.action.ParamAction::new);
/*     */ 
/*     */     
/*  78 */     rs.addRule(new ElementSelector("*/condition"), ch.qos.logback.core.joran.conditional.ByPropertiesConditionAction::new);
/*  79 */     rs.addRule(new ElementSelector("*/if"), ch.qos.logback.core.joran.conditional.IfAction::new);
/*  80 */     rs.addTransparentPathPart("if");
/*  81 */     rs.addRule(new ElementSelector("*/if/then"), ch.qos.logback.core.joran.conditional.ThenAction::new);
/*  82 */     rs.addTransparentPathPart("then");
/*  83 */     rs.addRule(new ElementSelector("*/if/else"), ch.qos.logback.core.joran.conditional.ElseAction::new);
/*  84 */     rs.addTransparentPathPart("else");
/*     */     
/*  86 */     rs.addRule(new ElementSelector("*/appender/sift"), ch.qos.logback.core.joran.action.SiftAction::new);
/*  87 */     rs.addTransparentPathPart("sift");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sanityCheck(Model topModel) {
/*  98 */     performCheck((SanityChecker)new AppenderWithinAppenderSanityChecker(), topModel);
/*     */   }
/*     */   
/*     */   protected void performCheck(SanityChecker sc, Model model) {
/* 102 */     if (sc instanceof ContextAware)
/* 103 */       ((ContextAware)sc).setContext(this.context); 
/* 104 */     sc.check(model);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setImplicitRuleSupplier(SaxEventInterpreter interpreter) {
/* 109 */     interpreter.setImplicitActionSupplier(ch.qos.logback.core.joran.action.ImplicitModelAction::new);
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildModelInterpretationContext() {
/* 114 */     super.buildModelInterpretationContext();
/* 115 */     this.modelInterpretationContext.createAppenderBags();
/*     */   }
/*     */   
/*     */   public SaxEventInterpretationContext getInterpretationContext() {
/* 119 */     return this.saxEventInterpreter.getSaxEventInterpretationContext();
/*     */   }
/*     */   
/*     */   protected void addModelHandlerAssociations(DefaultProcessor defaultProcessor) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\JoranConfiguratorBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */