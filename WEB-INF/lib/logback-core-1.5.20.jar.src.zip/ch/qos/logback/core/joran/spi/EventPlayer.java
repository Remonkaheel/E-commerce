/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ import ch.qos.logback.core.joran.event.BodyEvent;
/*    */ import ch.qos.logback.core.joran.event.EndEvent;
/*    */ import ch.qos.logback.core.joran.event.SaxEvent;
/*    */ import ch.qos.logback.core.joran.event.StartEvent;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventPlayer
/*    */ {
/*    */   final SaxEventInterpreter interpreter;
/*    */   final List<SaxEvent> saxEvents;
/*    */   int currentIndex;
/*    */   
/*    */   public EventPlayer(SaxEventInterpreter interpreter, List<SaxEvent> saxEvents) {
/* 32 */     this.interpreter = interpreter;
/* 33 */     this.saxEvents = saxEvents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<SaxEvent> getCopyOfPlayerEventList() {
/* 43 */     return new ArrayList<>(this.saxEvents);
/*    */   }
/*    */ 
/*    */   
/*    */   public void play() {
/* 48 */     for (this.currentIndex = 0; this.currentIndex < this.saxEvents.size(); this.currentIndex++) {
/* 49 */       SaxEvent se = this.saxEvents.get(this.currentIndex);
/*    */       
/* 51 */       if (se instanceof StartEvent) {
/* 52 */         this.interpreter.startElement((StartEvent)se);
/*    */       
/*    */       }
/* 55 */       else if (se instanceof BodyEvent) {
/* 56 */         this.interpreter.characters((BodyEvent)se);
/*    */       
/*    */       }
/* 59 */       else if (se instanceof EndEvent) {
/* 60 */         this.interpreter.endElement((EndEvent)se);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addEventsDynamically(List<SaxEvent> eventList, int offset) {
/* 68 */     this.saxEvents.addAll(this.currentIndex + offset, eventList);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\EventPlayer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */