/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.StatusListenerModel;
/*    */ import ch.qos.logback.core.status.StatusListener;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusListenerAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   boolean inError = false;
/* 27 */   Boolean effectivelyAdded = null;
/* 28 */   StatusListener statusListener = null;
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 33 */     String className = attributes.getValue("class");
/* 34 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 35 */       addError("Missing class name for statusListener. Near [" + name + "] line " + 
/* 36 */           getLineNumber(interpretationContext));
/* 37 */       return false;
/*    */     } 
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 45 */     StatusListenerModel statusListenerModel = new StatusListenerModel();
/* 46 */     statusListenerModel.setClassName(attributes.getValue("class"));
/* 47 */     return (Model)statusListenerModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\StatusListenerAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */