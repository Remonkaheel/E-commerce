package ch.qos.logback.core.joran.node;

public class ComponentNode {
  String classStr;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\node\ComponentNode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */