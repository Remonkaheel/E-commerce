/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.TimestampModel;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimestampAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   public static final String DATE_PATTERN_ATTRIBUTE = "datePattern";
/*    */   public static final String TIME_REFERENCE_ATTRIBUTE = "timeReference";
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 39 */     boolean valid = true;
/* 40 */     String keyStr = attributes.getValue("key");
/* 41 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(keyStr)) {
/* 42 */       addError("Attribute named [key] cannot be empty");
/* 43 */       valid = false;
/*    */     } 
/* 45 */     String datePatternStr = attributes.getValue("datePattern");
/* 46 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(datePatternStr)) {
/* 47 */       addError("Attribute named [datePattern] cannot be empty");
/* 48 */       valid = false;
/*    */     } 
/* 50 */     return valid;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 56 */     TimestampModel timestampModel = new TimestampModel();
/*    */     
/* 58 */     timestampModel.setKey(attributes.getValue("key"));
/* 59 */     timestampModel.setDatePattern(attributes.getValue("datePattern"));
/* 60 */     timestampModel.setTimeReference(attributes.getValue("timeReference"));
/* 61 */     timestampModel.setScopeStr(attributes.getValue("scope"));
/*    */     
/* 63 */     return (Model)timestampModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\TimestampAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */