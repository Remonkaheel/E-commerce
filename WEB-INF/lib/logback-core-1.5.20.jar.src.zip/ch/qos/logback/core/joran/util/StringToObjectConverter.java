/*     */ package ch.qos.logback.core.joran.util;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringToObjectConverter
/*     */ {
/*  34 */   private static final Class<?>[] STRING_CLASS_PARAMETER = new Class[] { String.class };
/*     */   
/*     */   public static boolean canBeBuiltFromSimpleString(Class<?> parameterClass) {
/*  37 */     Package p = parameterClass.getPackage();
/*  38 */     if (parameterClass.isPrimitive())
/*  39 */       return true; 
/*  40 */     if (p != null && "java.lang".equals(p.getName()))
/*  41 */       return true; 
/*  42 */     if (followsTheValueOfConvention(parameterClass))
/*  43 */       return true; 
/*  44 */     if (parameterClass.isEnum())
/*  45 */       return true; 
/*  46 */     if (isOfTypeCharset(parameterClass)) {
/*  47 */       return true;
/*     */     }
/*  49 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object convertArg(ContextAware ca, String val, Class<?> type) {
/*  57 */     if (val == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     String v = val.trim();
/*  61 */     if (String.class.isAssignableFrom(type))
/*  62 */       return v; 
/*  63 */     if (int.class.isAssignableFrom(type))
/*  64 */       return Integer.valueOf(v); 
/*  65 */     if (long.class.isAssignableFrom(type))
/*  66 */       return Long.valueOf(v); 
/*  67 */     if (float.class.isAssignableFrom(type))
/*  68 */       return Float.valueOf(v); 
/*  69 */     if (double.class.isAssignableFrom(type))
/*  70 */       return Double.valueOf(v); 
/*  71 */     if (boolean.class.isAssignableFrom(type)) {
/*  72 */       if ("true".equalsIgnoreCase(v))
/*  73 */         return Boolean.TRUE; 
/*  74 */       if ("false".equalsIgnoreCase(v))
/*  75 */         return Boolean.FALSE; 
/*     */     } else {
/*  77 */       if (type.isEnum())
/*  78 */         return convertToEnum(ca, v, (Class)type); 
/*  79 */       if (followsTheValueOfConvention(type))
/*  80 */         return convertByValueOfMethod(ca, type, v); 
/*  81 */       if (isOfTypeCharset(type)) {
/*  82 */         return convertToCharset(ca, val);
/*     */       }
/*     */     } 
/*  85 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isOfTypeCharset(Class<?> type) {
/*  89 */     return Charset.class.isAssignableFrom(type);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Charset convertToCharset(ContextAware ca, String val) {
/*  94 */     if ("null".equalsIgnoreCase(val)) {
/*  95 */       ca.addInfo("Converting the string \"null\" as Charset.defaultCharset()");
/*  96 */       return Charset.defaultCharset();
/*     */     } 
/*     */     
/*     */     try {
/* 100 */       return Charset.forName(val);
/* 101 */     } catch (UnsupportedCharsetException e) {
/* 102 */       ca.addError("Failed to get charset [" + val + "]", e);
/* 103 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method getValueOfMethod(Class<?> type) {
/*     */     try {
/* 110 */       return type.getMethod("valueOf", STRING_CLASS_PARAMETER);
/* 111 */     } catch (NoSuchMethodException e) {
/* 112 */       return null;
/* 113 */     } catch (SecurityException e) {
/* 114 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean followsTheValueOfConvention(Class<?> parameterClass) {
/* 119 */     Method valueOfMethod = getValueOfMethod(parameterClass);
/* 120 */     if (valueOfMethod == null) {
/* 121 */       return false;
/*     */     }
/* 123 */     int mod = valueOfMethod.getModifiers();
/* 124 */     return Modifier.isStatic(mod);
/*     */   }
/*     */   
/*     */   private static Object convertByValueOfMethod(ContextAware ca, Class<?> type, String val) {
/*     */     try {
/* 129 */       Method valueOfMethod = type.getMethod("valueOf", STRING_CLASS_PARAMETER);
/* 130 */       return valueOfMethod.invoke(null, new Object[] { val });
/* 131 */     } catch (Exception e) {
/* 132 */       ca.addError("Failed to invoke valueOf{} method in class [" + type.getName() + "] with value [" + val + "]");
/*     */       
/* 134 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object convertToEnum(ContextAware ca, String val, Class<? extends Enum> enumType) {
/* 140 */     return Enum.valueOf(enumType, val);
/*     */   }
/*     */   
/*     */   boolean isBuildableFromSimpleString() {
/* 144 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\StringToObjectConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */