/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.SequenceNumberGeneratorModel;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceNumberGeneratorAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 33 */     SequenceNumberGeneratorModel sngm = new SequenceNumberGeneratorModel();
/* 34 */     sngm.setClassName(attributes.getValue("class"));
/* 35 */     return (Model)sngm;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext seic, String name, Attributes attributes) {
/* 40 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, seic, name, attributes);
/* 41 */     validator.validateClassAttribute();
/* 42 */     return validator.isValid();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\SequenceNumberGeneratorAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */