package ch.qos.logback.core.joran.spi;

import ch.qos.logback.core.joran.action.Action;
import java.util.function.Supplier;

public interface RuleStore {
  void addRule(ElementSelector paramElementSelector, String paramString) throws ClassNotFoundException;
  
  void addRule(ElementSelector paramElementSelector, Supplier<Action> paramSupplier);
  
  Supplier<Action> matchActions(ElementPath paramElementPath);
  
  void addTransparentPathPart(String paramString);
  
  void addPathPathMapping(String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\RuleStore.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */