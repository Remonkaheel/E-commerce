/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.ActionException;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseModelAction
/*    */   extends Action
/*    */ {
/*    */   Model parentModel;
/*    */   Model currentModel;
/*    */   boolean inError = false;
/*    */   
/*    */   public void begin(SaxEventInterpretationContext saxEventInterpretationContext, String name, Attributes attributes) throws ActionException {
/* 31 */     this.parentModel = null;
/* 32 */     this.inError = false;
/*    */     
/* 34 */     if (!validPreconditions(saxEventInterpretationContext, name, attributes)) {
/* 35 */       this.inError = true;
/*    */       
/*    */       return;
/*    */     } 
/* 39 */     this.currentModel = buildCurrentModel(saxEventInterpretationContext, name, attributes);
/* 40 */     this.currentModel.setTag(name);
/* 41 */     if (!saxEventInterpretationContext.isModelStackEmpty()) {
/* 42 */       this.parentModel = saxEventInterpretationContext.peekModel();
/*    */     }
/* 44 */     int lineNumber = getLineNumber(saxEventInterpretationContext);
/* 45 */     this.currentModel.setLineNumber(lineNumber);
/* 46 */     saxEventInterpretationContext.pushModel(this.currentModel);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract Model buildCurrentModel(SaxEventInterpretationContext paramSaxEventInterpretationContext, String paramString, Attributes paramAttributes);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext intercon, String name, Attributes attributes) {
/* 63 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void body(SaxEventInterpretationContext ec, String body) throws ActionException {
/* 68 */     if (this.currentModel == null) {
/* 69 */       throw new ActionException("current model is null. Is <configuration> element missing?");
/*    */     }
/* 71 */     this.currentModel.addText(body);
/*    */   }
/*    */ 
/*    */   
/*    */   public void end(SaxEventInterpretationContext saxEventInterpretationContext, String name) throws ActionException {
/* 76 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 79 */     Model m = saxEventInterpretationContext.peekModel();
/*    */     
/* 81 */     if (m != this.currentModel) {
/* 82 */       addWarn("The object " + String.valueOf(m) + "] at the top of the stack differs from the model [" + this.currentModel.idString() + "] pushed earlier.");
/*    */       
/* 84 */       addWarn("This is wholly unexpected.");
/*    */     } 
/*    */ 
/*    */     
/* 88 */     if (this.parentModel != null) {
/* 89 */       this.parentModel.addSubModel(this.currentModel);
/* 90 */       saxEventInterpretationContext.popModel();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\BaseModelAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */