/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.SerializeModelModel;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializeModelAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 28 */     SerializeModelModel serializeModelModel = new SerializeModelModel();
/* 29 */     serializeModelModel.setFile(attributes.getValue("file"));
/*    */     
/* 31 */     return (Model)serializeModelModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\SerializeModelAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */