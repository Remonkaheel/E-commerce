/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.ElementSelector;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewRuleAction
/*    */   extends Action
/*    */ {
/*    */   boolean inError = false;
/*    */   
/*    */   public void begin(SaxEventInterpretationContext ec, String localName, Attributes attributes) {
/* 30 */     this.inError = false;
/*    */     
/* 32 */     String pattern = attributes.getValue("pattern");
/* 33 */     String actionClass = attributes.getValue("actionClass");
/*    */     
/* 35 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(pattern)) {
/* 36 */       this.inError = true;
/* 37 */       String errorMsg = "No 'pattern' attribute in <newRule>";
/* 38 */       addError(errorMsg);
/*    */       
/*    */       return;
/*    */     } 
/* 42 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(actionClass)) {
/* 43 */       this.inError = true;
/* 44 */       String errorMsg = "No 'actionClass' attribute in <newRule>";
/* 45 */       addError(errorMsg);
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 50 */       addInfo("About to add new Joran parsing rule [" + pattern + "," + actionClass + "].");
/* 51 */       ec.getSaxEventInterpreter().getRuleStore().addRule(new ElementSelector(pattern), actionClass);
/* 52 */     } catch (Exception oops) {
/* 53 */       this.inError = true;
/* 54 */       String errorMsg = "Could not add new Joran parsing rule [" + pattern + "," + actionClass + "]";
/* 55 */       addError(errorMsg);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void end(SaxEventInterpretationContext ec, String n) {}
/*    */   
/*    */   public void finish(SaxEventInterpretationContext ec) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\NewRuleAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */