/*     */ package ch.qos.logback.core.joran.spi;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.MD5Util;
/*     */ import java.io.File;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationWatchList
/*     */   extends ContextAwareBase
/*     */ {
/*     */   public static final String HTTPS_PROTOCOL_STR = "https";
/*     */   public static final String HTTP_PROTOCOL_STR = "http";
/*     */   public static final String FILE_PROTOCOL_STR = "file";
/*  42 */   static final String[] WATCHABLE_PROTOCOLS = new String[] { "file", "https", "http" };
/*     */   
/*  44 */   static final byte[] BUF_ZERO = new byte[] { 0 };
/*     */   
/*     */   URL mainURL;
/*  47 */   List<File> fileWatchList = new ArrayList<>();
/*  48 */   List<URL> urlWatchList = new ArrayList<>();
/*  49 */   List<byte[]> lastHashList = (List)new ArrayList<>();
/*     */   
/*  51 */   List<Long> lastModifiedList = new ArrayList<>();
/*     */   
/*     */   public ConfigurationWatchList buildClone() {
/*  54 */     ConfigurationWatchList out = new ConfigurationWatchList();
/*  55 */     out.mainURL = this.mainURL;
/*  56 */     out.fileWatchList = new ArrayList<>(this.fileWatchList);
/*  57 */     out.lastModifiedList = new ArrayList<>(this.lastModifiedList);
/*  58 */     out.lastHashList = (List)new ArrayList<>(this.lastHashList);
/*  59 */     return out;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  63 */     this.mainURL = null;
/*  64 */     this.lastModifiedList.clear();
/*  65 */     this.fileWatchList.clear();
/*  66 */     this.urlWatchList.clear();
/*  67 */     this.lastHashList.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainURL(URL mainURL) {
/*  77 */     this.mainURL = mainURL;
/*  78 */     if (mainURL != null)
/*  79 */       addAsFileToWatch(mainURL); 
/*     */   }
/*     */   
/*     */   public boolean watchPredicateFulfilled() {
/*  83 */     if (hasMainURLAndNonEmptyFileList()) {
/*  84 */       return true;
/*     */     }
/*     */     
/*  87 */     if (urlListContainsProperties()) {
/*  88 */       return true;
/*     */     }
/*     */     
/*  91 */     return fileWatchListContainsProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean urlListContainsProperties() {
/*  96 */     return this.urlWatchList.stream().anyMatch(url -> url.toString().endsWith(".properties"));
/*     */   }
/*     */   
/*     */   private boolean hasMainURLAndNonEmptyFileList() {
/* 100 */     return (this.mainURL != null && !this.fileWatchList.isEmpty());
/*     */   }
/*     */   
/*     */   private boolean fileWatchListContainsProperties() {
/* 104 */     return this.fileWatchList.stream().anyMatch(file -> file.getName().endsWith(".properties"));
/*     */   }
/*     */ 
/*     */   
/*     */   private void addAsFileToWatch(URL url) {
/* 109 */     File file = convertToFile(url);
/* 110 */     if (file != null) {
/* 111 */       this.fileWatchList.add(file);
/* 112 */       this.lastModifiedList.add(Long.valueOf(file.lastModified()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isHTTP_Or_HTTPS(URL url) {
/* 118 */     String protocolStr = url.getProtocol();
/* 119 */     return isHTTP_Or_HTTPS(protocolStr);
/*     */   }
/*     */   
/*     */   private boolean isHTTP_Or_HTTPS(String protocolStr) {
/* 123 */     return (protocolStr.equals("http") || protocolStr.equals("https"));
/*     */   }
/*     */   
/*     */   private void addAsHTTP_or_HTTPS_URLToWatch(URL url) {
/* 127 */     if (isHTTP_Or_HTTPS(url)) {
/* 128 */       this.urlWatchList.add(url);
/* 129 */       this.lastHashList.add(BUF_ZERO);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToWatchList(URL url) {
/* 139 */     String protocolStr = url.getProtocol();
/* 140 */     if (protocolStr.equals("file")) {
/* 141 */       addAsFileToWatch(url);
/* 142 */     } else if (isHTTP_Or_HTTPS(protocolStr)) {
/* 143 */       addAsHTTP_or_HTTPS_URLToWatch(url);
/*     */     } 
/*     */   }
/*     */   
/*     */   public URL getMainURL() {
/* 148 */     return this.mainURL;
/*     */   }
/*     */   
/*     */   public List<File> getCopyOfFileWatchList() {
/* 152 */     return new ArrayList<>(this.fileWatchList);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean emptyWatchLists() {
/* 157 */     if (this.fileWatchList != null && !this.fileWatchList.isEmpty()) {
/* 158 */       return false;
/*     */     }
/*     */     
/* 161 */     if (this.urlWatchList != null && !this.urlWatchList.isEmpty()) {
/* 162 */       return false;
/*     */     }
/* 164 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File changeDetected() {
/* 173 */     return changeDetectedInFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File changeDetectedInFile() {
/* 181 */     int len = this.fileWatchList.size();
/*     */     
/* 183 */     for (int i = 0; i < len; i++) {
/* 184 */       long lastModified = ((Long)this.lastModifiedList.get(i)).longValue();
/* 185 */       File file = this.fileWatchList.get(i);
/* 186 */       long actualModificationDate = file.lastModified();
/*     */       
/* 188 */       if (lastModified != actualModificationDate) {
/*     */         
/* 190 */         this.lastModifiedList.set(i, Long.valueOf(actualModificationDate));
/* 191 */         return file;
/*     */       } 
/*     */     } 
/* 194 */     return null;
/*     */   }
/*     */   
/*     */   public URL changeDetectedInURL() {
/* 198 */     int len = this.urlWatchList.size();
/*     */     
/* 200 */     int i = 0; if (i < len) {
/* 201 */       byte[] lastHash = this.lastHashList.get(i);
/* 202 */       URL url = this.urlWatchList.get(i);
/*     */       
/* 204 */       HttpUtil httpGetUtil = new HttpUtil(HttpUtil.RequestMethod.GET, url);
/* 205 */       HttpURLConnection getConnection = httpGetUtil.connectTextTxt();
/* 206 */       String response = httpGetUtil.readResponse(getConnection);
/*     */       
/* 208 */       byte[] hash = computeHash(response);
/* 209 */       if (lastHash == BUF_ZERO) {
/* 210 */         this.lastHashList.set(i, hash);
/* 211 */         return null;
/*     */       } 
/*     */       
/* 214 */       if (Arrays.equals(lastHash, hash)) {
/* 215 */         return null;
/*     */       }
/* 217 */       this.lastHashList.set(i, hash);
/* 218 */       return url;
/*     */     } 
/*     */     
/* 221 */     return null;
/*     */   }
/*     */   
/*     */   private byte[] computeHash(String response) {
/* 225 */     if (response == null || response.trim().length() == 0) {
/* 226 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 230 */       MD5Util md5Util = new MD5Util();
/* 231 */       byte[] hashBytes = md5Util.md5Hash(response);
/* 232 */       return hashBytes;
/* 233 */     } catch (NoSuchAlgorithmException e) {
/* 234 */       addError("missing MD5 algorithm", e);
/* 235 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   File convertToFile(URL url) {
/* 241 */     String protocol = url.getProtocol();
/* 242 */     if ("file".equals(protocol)) {
/* 243 */       return new File(URLDecoder.decode(url.getFile()));
/*     */     }
/* 245 */     addInfo("URL [" + String.valueOf(url) + "] is not of type file");
/* 246 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAtLeastOneWatchableFile() {
/* 256 */     return !this.fileWatchList.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWatchableProtocol(URL url) {
/* 267 */     if (url == null) {
/* 268 */       return false;
/*     */     }
/* 270 */     String protocolStr = url.getProtocol();
/* 271 */     return isWatchableProtocol(protocolStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWatchableProtocol(String protocolStr) {
/* 282 */     return Arrays.<String>stream(WATCHABLE_PROTOCOLS).anyMatch(protocol -> protocol.equalsIgnoreCase(protocolStr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrlWatchListAsStr() {
/* 291 */     String urlWatchListStr = this.urlWatchList.stream().map(URL::toString).collect(Collectors.joining(", "));
/* 292 */     return urlWatchListStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileWatchListAsStr() {
/* 301 */     return this.fileWatchList.stream().map(File::getPath).collect(Collectors.joining(", "));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\ConfigurationWatchList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */