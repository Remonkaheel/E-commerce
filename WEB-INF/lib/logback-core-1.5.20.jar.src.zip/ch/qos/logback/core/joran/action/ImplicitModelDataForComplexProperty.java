/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.util.PropertySetter;
/*    */ import ch.qos.logback.core.util.AggregationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplicitModelDataForComplexProperty
/*    */   extends ImplicitModelData
/*    */ {
/*    */   private Object nestedComplexProperty;
/*    */   
/*    */   public ImplicitModelDataForComplexProperty(PropertySetter parentBean, AggregationType aggregationType, String propertyName) {
/* 28 */     super(parentBean, aggregationType, propertyName);
/*    */   }
/*    */   
/*    */   public Object getNestedComplexProperty() {
/* 32 */     return this.nestedComplexProperty;
/*    */   }
/*    */   
/*    */   public void setNestedComplexProperty(Object nestedComplexProperty) {
/* 36 */     this.nestedComplexProperty = nestedComplexProperty;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ImplicitModelDataForComplexProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */