/*     */ package ch.qos.logback.core.joran.spi;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.action.Action;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleRuleStore
/*     */   extends ContextAwareBase
/*     */   implements RuleStore
/*     */ {
/*  36 */   static String KLEENE_STAR = "*";
/*     */ 
/*     */   
/*  39 */   HashMap<ElementSelector, Supplier<Action>> rules = new HashMap<>();
/*     */   
/*  41 */   List<String> transparentPathParts = new ArrayList<>(2);
/*  42 */   Map<String, String> pathPartsMapForRenaming = new HashMap<>(2);
/*     */   
/*     */   public SimpleRuleStore(Context context) {
/*  45 */     setContext(context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addTransparentPathPart(String pathPart) {
/*  50 */     if (pathPart == null) {
/*  51 */       throw new IllegalArgumentException("pathPart cannot be null");
/*     */     }
/*  53 */     pathPart = pathPart.trim();
/*     */     
/*  55 */     if (pathPart.isEmpty()) {
/*  56 */       throw new IllegalArgumentException("pathPart cannot be empty or to consist of only spaces");
/*     */     }
/*  58 */     if (pathPart.contains("/")) {
/*  59 */       throw new IllegalArgumentException("pathPart cannot contain '/', i.e. the forward slash character");
/*     */     }
/*  61 */     this.transparentPathParts.add(pathPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPathPathMapping(String originalName, String modifiedName) {
/*  74 */     this.pathPartsMapForRenaming.put(originalName, modifiedName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRule(ElementSelector elementSelector, Supplier<Action> actionSupplier) {
/*  84 */     Supplier<Action> existing = this.rules.get(elementSelector);
/*     */     
/*  86 */     if (existing == null) {
/*  87 */       this.rules.put(elementSelector, actionSupplier);
/*     */     } else {
/*  89 */       throw new IllegalStateException(elementSelector.toString() + " already has an associated action supplier");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addRule(ElementSelector elementSelector, String actionClassName) {
/*  94 */     Action action = null;
/*     */     
/*     */     try {
/*  97 */       action = (Action)OptionHelper.instantiateByClassName(actionClassName, Action.class, this.context);
/*  98 */     } catch (Exception e) {
/*  99 */       addError("Could not instantiate class [" + actionClassName + "]", e);
/*     */     } 
/* 101 */     if (action != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<Action> matchActions(ElementPath elementPath) {
/* 115 */     Supplier<Action> actionSupplier = internalMatchAction(elementPath);
/* 116 */     if (actionSupplier != null) {
/* 117 */       return actionSupplier;
/*     */     }
/*     */     
/* 120 */     return matchActionsWithoutTransparentPartsAndRenamedParts(elementPath);
/*     */   }
/*     */   
/*     */   private Supplier<Action> matchActionsWithoutTransparentPartsAndRenamedParts(ElementPath elementPath) {
/* 124 */     ElementPath cleanedElementPath = removeTransparentPathParts(elementPath);
/* 125 */     ElementPath renamePathParts = renamePathParts(cleanedElementPath);
/*     */     
/* 127 */     return internalMatchAction(renamePathParts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Supplier<Action> internalMatchAction(ElementPath elementPath) {
/*     */     Supplier<Action> actionSupplier;
/* 143 */     if ((actionSupplier = fullPathMatch(elementPath)) != null)
/* 144 */       return actionSupplier; 
/* 145 */     if ((actionSupplier = suffixMatch(elementPath)) != null)
/* 146 */       return actionSupplier; 
/* 147 */     if ((actionSupplier = prefixMatch(elementPath)) != null)
/* 148 */       return actionSupplier; 
/* 149 */     if ((actionSupplier = middleMatch(elementPath)) != null) {
/* 150 */       return actionSupplier;
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ElementPath removeTransparentPathParts(ElementPath originalElementPath) {
/* 158 */     List<String> preservedElementList = new ArrayList<>(originalElementPath.partList.size());
/*     */     
/* 160 */     for (String part : originalElementPath.partList) {
/* 161 */       boolean shouldKeep = this.transparentPathParts.stream().noneMatch(p -> p.equalsIgnoreCase(part));
/* 162 */       if (shouldKeep) {
/* 163 */         preservedElementList.add(part);
/*     */       }
/*     */     } 
/* 166 */     return new ElementPath(preservedElementList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ElementPath renamePathParts(ElementPath originalElementPath) {
/* 173 */     List<String> result = new ArrayList<>(originalElementPath.partList.size());
/*     */     
/* 175 */     for (String part : originalElementPath.partList) {
/* 176 */       String modifiedName = this.pathPartsMapForRenaming.getOrDefault(part, part);
/* 177 */       result.add(modifiedName);
/*     */     } 
/*     */     
/* 180 */     return new ElementPath(result);
/*     */   }
/*     */ 
/*     */   
/*     */   Supplier<Action> fullPathMatch(ElementPath elementPath) {
/* 185 */     for (ElementSelector selector : this.rules.keySet()) {
/* 186 */       if (selector.fullPathMatch(elementPath))
/* 187 */         return this.rules.get(selector); 
/*     */     } 
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   Supplier<Action> suffixMatch(ElementPath elementPath) {
/* 194 */     int max = 0;
/* 195 */     ElementSelector longestMatchingElementSelector = null;
/*     */     
/* 197 */     for (ElementSelector selector : this.rules.keySet()) {
/* 198 */       if (isSuffixPattern(selector)) {
/* 199 */         int r = selector.getTailMatchLength(elementPath);
/* 200 */         if (r > max) {
/* 201 */           max = r;
/* 202 */           longestMatchingElementSelector = selector;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 207 */     if (longestMatchingElementSelector != null) {
/* 208 */       return this.rules.get(longestMatchingElementSelector);
/*     */     }
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSuffixPattern(ElementSelector p) {
/* 215 */     return (p.size() > 1 && p.get(0).equals(KLEENE_STAR));
/*     */   }
/*     */   
/*     */   Supplier<Action> prefixMatch(ElementPath elementPath) {
/* 219 */     int max = 0;
/* 220 */     ElementSelector longestMatchingElementSelector = null;
/*     */     
/* 222 */     for (ElementSelector selector : this.rules.keySet()) {
/* 223 */       String last = selector.peekLast();
/* 224 */       if (isKleeneStar(last)) {
/* 225 */         int r = selector.getPrefixMatchLength(elementPath);
/*     */         
/* 227 */         if (r == selector.size() - 1 && r > max) {
/* 228 */           max = r;
/* 229 */           longestMatchingElementSelector = selector;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 234 */     if (longestMatchingElementSelector != null) {
/* 235 */       return this.rules.get(longestMatchingElementSelector);
/*     */     }
/* 237 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isKleeneStar(String last) {
/* 242 */     return KLEENE_STAR.equals(last);
/*     */   }
/*     */ 
/*     */   
/*     */   Supplier<Action> middleMatch(ElementPath path) {
/* 247 */     int max = 0;
/* 248 */     ElementSelector longestMatchingElementSelector = null;
/*     */     
/* 250 */     for (ElementSelector selector : this.rules.keySet()) {
/* 251 */       String last = selector.peekLast();
/* 252 */       String first = null;
/* 253 */       if (selector.size() > 1) {
/* 254 */         first = selector.get(0);
/*     */       }
/* 256 */       if (isKleeneStar(last) && isKleeneStar(first)) {
/* 257 */         List<String> copyOfPartList = selector.getCopyOfPartList();
/* 258 */         if (copyOfPartList.size() > 2) {
/* 259 */           copyOfPartList.remove(0);
/* 260 */           copyOfPartList.remove(copyOfPartList.size() - 1);
/*     */         } 
/*     */         
/* 263 */         int r = 0;
/* 264 */         ElementSelector clone = new ElementSelector(copyOfPartList);
/* 265 */         if (clone.isContainedIn(path)) {
/* 266 */           r = clone.size();
/*     */         }
/* 268 */         if (r > max) {
/* 269 */           max = r;
/* 270 */           longestMatchingElementSelector = selector;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 275 */     if (longestMatchingElementSelector != null) {
/* 276 */       return this.rules.get(longestMatchingElementSelector);
/*     */     }
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 283 */     String TAB = "  ";
/*     */     
/* 285 */     StringBuilder retValue = new StringBuilder();
/*     */     
/* 287 */     retValue.append("SimpleRuleStore ( ").append("rules = ").append(this.rules).append("  ").append(" )");
/*     */     
/* 289 */     return retValue.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\SimpleRuleStore.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */