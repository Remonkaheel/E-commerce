/*     */ package ch.qos.logback.core.joran.spi;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoAutoStartUtil
/*     */ {
/*     */   public static boolean notMarkedWithNoAutoStart(Object o) {
/*  32 */     if (o == null) {
/*  33 */       return false;
/*     */     }
/*  35 */     Class<?> clazz = o.getClass();
/*  36 */     NoAutoStart a = findAnnotation(clazz, NoAutoStart.class);
/*  37 */     return (a == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <A extends Annotation> A findAnnotation(Class<?> clazz, Class<A> annotationType) {
/*  62 */     return findAnnotation(clazz, annotationType, new HashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <A extends Annotation> A findAnnotation(Class<?> clazz, Class<A> annotationType, Set<Annotation> visited) {
/*  77 */     Annotation foundAnnotation = clazz.getAnnotation(annotationType);
/*  78 */     if (foundAnnotation != null) {
/*  79 */       return (A)foundAnnotation;
/*     */     }
/*     */ 
/*     */     
/*  83 */     for (Class<?> ifc : clazz.getInterfaces()) {
/*  84 */       A annotation = findAnnotation(ifc, annotationType, visited);
/*  85 */       if (annotation != null) {
/*  86 */         return annotation;
/*     */       }
/*     */     } 
/*     */     
/*  90 */     Class<?> superclass = clazz.getSuperclass();
/*  91 */     if (superclass == null || Object.class == superclass) {
/*  92 */       return null;
/*     */     }
/*  94 */     return findAnnotation(superclass, annotationType, visited);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean shouldBeStarted(Object o) {
/* 105 */     if (o instanceof ch.qos.logback.core.spi.LifeCycle) {
/* 106 */       return notMarkedWithNoAutoStart(o);
/*     */     }
/* 108 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\NoAutoStartUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */