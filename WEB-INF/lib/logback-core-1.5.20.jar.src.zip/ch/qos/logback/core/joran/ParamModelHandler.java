/*    */ package ch.qos.logback.core.joran;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.util.PropertySetter;
/*    */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.ParamModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ public class ParamModelHandler
/*    */   extends ModelHandlerBase {
/*    */   private final BeanDescriptionCache beanDescriptionCache;
/*    */   
/*    */   public ParamModelHandler(Context context, BeanDescriptionCache beanDescriptionCache) {
/* 17 */     super(context);
/* 18 */     this.beanDescriptionCache = beanDescriptionCache;
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 22 */     return new ParamModelHandler(context, ic.getBeanDescriptionCache());
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ParamModel> getSupportedModelClass() {
/* 27 */     return ParamModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext intercon, Model model) throws ModelHandlerException {
/* 33 */     ParamModel paramModel = (ParamModel)model;
/*    */     
/* 35 */     String valueStr = intercon.subst(paramModel.getValue());
/*    */     
/* 37 */     Object o = intercon.peekObject();
/*    */     
/* 39 */     PropertySetter propSetter = new PropertySetter(this.beanDescriptionCache, o);
/* 40 */     propSetter.setContext(this.context);
/*    */ 
/*    */     
/* 43 */     String finalName = intercon.subst(paramModel.getName());
/* 44 */     propSetter.setProperty(finalName, valueStr);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\ParamModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */