/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 2743349809995319806L;
/*    */   
/*    */   public ActionException() {}
/*    */   
/*    */   public ActionException(String msg) {
/* 31 */     super(msg);
/*    */   }
/*    */   
/*    */   public ActionException(Throwable rootCause) {
/* 35 */     super(rootCause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\spi\ActionException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */