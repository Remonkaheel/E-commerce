/*    */ package ch.qos.logback.core.joran.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.spi.PropertyContainer;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.codehaus.commons.compiler.CompileException;
/*    */ import org.codehaus.janino.ClassBodyEvaluator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyEvalScriptBuilder
/*    */   extends ContextAwareBase
/*    */ {
/* 29 */   private static String SCRIPT_PREFIX = "public boolean evaluate() { return ";
/* 30 */   private static String SCRIPT_SUFFIX = "; }";
/*    */   
/*    */   final PropertyContainer localPropContainer;
/*    */   
/*    */   Map<String, String> map;
/*    */ 
/*    */   
/*    */   public PropertyEvalScriptBuilder(PropertyContainer localPropContainer) {
/* 38 */     this.map = new HashMap<>();
/*    */     this.localPropContainer = localPropContainer;
/*    */   }
/*    */   
/*    */   public Condition build(String script) throws IllegalAccessException, CompileException, InstantiationException, SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
/* 43 */     ClassBodyEvaluator cbe = new ClassBodyEvaluator();
/* 44 */     cbe.setImplementedInterfaces(new Class[] { Condition.class });
/* 45 */     cbe.setExtendedClass(PropertyWrapperForScripts.class);
/* 46 */     cbe.setParentClassLoader(ClassBodyEvaluator.class.getClassLoader());
/* 47 */     cbe.cook(SCRIPT_PREFIX + SCRIPT_PREFIX + script);
/*    */     
/* 49 */     Class<?> clazz = cbe.getClazz();
/* 50 */     Condition instance = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 51 */     Method setMapMethod = clazz.getMethod("setPropertyContainers", new Class[] { PropertyContainer.class, PropertyContainer.class });
/*    */     
/* 53 */     setMapMethod.invoke(instance, new Object[] { this.localPropContainer, this.context });
/*    */     
/* 55 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\conditional\PropertyEvalScriptBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */