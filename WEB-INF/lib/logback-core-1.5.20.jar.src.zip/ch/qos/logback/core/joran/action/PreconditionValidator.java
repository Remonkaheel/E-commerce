/*     */ package ch.qos.logback.core.joran.action;
/*     */ 
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreconditionValidator
/*     */   extends ContextAwareBase
/*     */ {
/*     */   boolean valid = true;
/*     */   SaxEventInterpretationContext seic;
/*     */   Attributes attributes;
/*     */   String tag;
/*     */   
/*     */   public PreconditionValidator(ContextAware origin, SaxEventInterpretationContext seic, String name, Attributes attributes) {
/*  33 */     super(origin);
/*  34 */     setContext(origin.getContext());
/*  35 */     this.seic = seic;
/*  36 */     this.tag = name;
/*  37 */     this.attributes = attributes;
/*     */   }
/*     */   
/*     */   public PreconditionValidator validateZeroAttributes() {
/*  41 */     if (this.attributes == null) {
/*  42 */       return this;
/*     */     }
/*  44 */     if (this.attributes.getLength() != 0) {
/*  45 */       addError("Element [" + this.tag + "] should have no attributes, near line " + 
/*  46 */           Action.getLineNumber(this.seic));
/*  47 */       this.valid = false;
/*     */     } 
/*  49 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PreconditionValidator validateClassAttribute() {
/*  54 */     return validateGivenAttribute("class");
/*     */   }
/*     */   
/*     */   public PreconditionValidator validateNameAttribute() {
/*  58 */     return validateGivenAttribute("name");
/*     */   }
/*     */   
/*     */   public PreconditionValidator validateValueAttribute() {
/*  62 */     return validateGivenAttribute("value");
/*     */   }
/*     */   
/*     */   public PreconditionValidator validateRefAttribute() {
/*  66 */     return validateGivenAttribute("ref");
/*     */   }
/*     */   
/*     */   public boolean isInvalidAttribute(String attributeName) {
/*  70 */     String attributeValue = this.attributes.getValue(attributeName);
/*  71 */     return OptionHelper.isNullOrEmptyOrAllSpaces(attributeValue);
/*     */   }
/*     */   
/*     */   public PreconditionValidator validateGivenAttribute(String attributeName) {
/*  75 */     boolean invalid = isInvalidAttribute(attributeName);
/*  76 */     if (invalid) {
/*  77 */       addMissingAttributeError(attributeName);
/*  78 */       this.valid = false;
/*     */     } 
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PreconditionValidator generic(String attributeName) {
/*  91 */     return validateGivenAttribute(attributeName);
/*     */   }
/*     */   
/*     */   public void addMissingAttributeError(String attributeName) {
/*  95 */     addError("Missing attribute [" + attributeName + "]. " + getLocationSuffix());
/*     */   }
/*     */   
/*     */   public String getLocationSuffix() {
/*  99 */     return "See element [" + this.tag + "] near line " + Action.getLineNumber(this.seic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 111 */     return this.valid;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\PreconditionValidator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */