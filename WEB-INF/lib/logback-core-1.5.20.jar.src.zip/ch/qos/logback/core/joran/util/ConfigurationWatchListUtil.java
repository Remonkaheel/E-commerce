/*     */ package ch.qos.logback.core.joran.util;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.ConfigurationWatchList;
/*     */ import ch.qos.logback.core.status.InfoStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.status.WarnStatus;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationWatchListUtil
/*     */ {
/*  33 */   static final ConfigurationWatchListUtil ORIGIN = new ConfigurationWatchListUtil();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerConfigurationWatchList(Context context, ConfigurationWatchList cwl) {
/*  39 */     context.putObject("CONFIGURATION_WATCH_LIST", cwl);
/*     */   }
/*     */   
/*     */   public static void setMainWatchURL(Context context, URL url) {
/*  43 */     ConfigurationWatchList cwl = getConfigurationWatchList(context);
/*  44 */     if (cwl == null) {
/*  45 */       cwl = registerNewConfigurationWatchListWithContext(context);
/*     */     } else {
/*  47 */       cwl.clear();
/*     */     } 
/*     */     
/*  50 */     cwl.setMainURL(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean watchPredicateFulfilled(Context context) {
/*  59 */     ConfigurationWatchList cwl = getConfigurationWatchList(context);
/*  60 */     if (cwl == null) {
/*  61 */       return false;
/*     */     }
/*  63 */     return cwl.watchPredicateFulfilled();
/*     */   }
/*     */   
/*     */   public static URL getMainWatchURL(Context context) {
/*  67 */     ConfigurationWatchList cwl = getConfigurationWatchList(context);
/*  68 */     if (cwl == null) {
/*  69 */       return null;
/*     */     }
/*  71 */     return cwl.getMainURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addToWatchList(Context context, URL url) {
/*  76 */     addToWatchList(context, url, false);
/*     */   }
/*     */   
/*     */   public static void addToWatchList(Context context, URL url, boolean createCWL) {
/*  80 */     ConfigurationWatchList cwl = getConfigurationWatchList(context);
/*  81 */     if (cwl == null) {
/*  82 */       if (createCWL && ConfigurationWatchList.isWatchableProtocol(url)) {
/*  83 */         cwl = registerNewConfigurationWatchListWithContext(context);
/*     */       } else {
/*  85 */         addWarn(context, "Null ConfigurationWatchList. Cannot add " + String.valueOf(url));
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*  90 */     String protocol = url.getProtocol();
/*  91 */     if (ConfigurationWatchList.isWatchableProtocol(protocol)) {
/*  92 */       addInfo(context, "Will add [" + String.valueOf(url) + "] to configuration watch list.");
/*  93 */       cwl.addToWatchList(url);
/*     */     } else {
/*  95 */       addInfo(context, "Will not add configuration file [" + String.valueOf(url) + "] to watch list, because '" + protocol + "' protocol is not watchable.");
/*  96 */       addInfo(context, "Only the protocols 'file', 'http' and 'https' are watchable.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static ConfigurationWatchList registerNewConfigurationWatchListWithContext(Context context) {
/* 101 */     ConfigurationWatchList cwl = new ConfigurationWatchList();
/* 102 */     cwl.setContext(context);
/* 103 */     context.putObject("CONFIGURATION_WATCH_LIST", cwl);
/* 104 */     return cwl;
/*     */   }
/*     */   
/*     */   public static ConfigurationWatchList getConfigurationWatchList(Context context) {
/* 108 */     return (ConfigurationWatchList)context.getObject("CONFIGURATION_WATCH_LIST");
/*     */   }
/*     */   
/*     */   static void addStatus(Context context, Status s) {
/* 112 */     if (context == null) {
/* 113 */       System.out.println("Null context in " + ConfigurationWatchList.class.getName());
/*     */       return;
/*     */     } 
/* 116 */     StatusManager sm = context.getStatusManager();
/* 117 */     if (sm == null)
/*     */       return; 
/* 119 */     sm.add(s);
/*     */   }
/*     */   
/*     */   static void addInfo(Context context, String msg) {
/* 123 */     addStatus(context, (Status)new InfoStatus(msg, ORIGIN));
/*     */   }
/*     */   
/*     */   static void addWarn(Context context, String msg) {
/* 127 */     addStatus(context, (Status)new WarnStatus(msg, ORIGIN));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\ConfigurationWatchListUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */