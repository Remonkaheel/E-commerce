/*    */ package ch.qos.logback.core.joran.util.beans;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanDescription
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   private final Map<String, Method> propertyNameToGetter;
/*    */   private final Map<String, Method> propertyNameToSetter;
/*    */   private final Map<String, Method> propertyNameToAdder;
/*    */   
/*    */   protected BeanDescription(Class<?> clazz, Map<String, Method> propertyNameToGetter, Map<String, Method> propertyNameToSetter, Map<String, Method> propertyNameToAdder) {
/* 38 */     this.clazz = clazz;
/* 39 */     this.propertyNameToGetter = Collections.unmodifiableMap(propertyNameToGetter);
/* 40 */     this.propertyNameToSetter = Collections.unmodifiableMap(propertyNameToSetter);
/* 41 */     this.propertyNameToAdder = Collections.unmodifiableMap(propertyNameToAdder);
/*    */   }
/*    */   
/*    */   public Class<?> getClazz() {
/* 45 */     return this.clazz;
/*    */   }
/*    */   
/*    */   public Map<String, Method> getPropertyNameToGetter() {
/* 49 */     return this.propertyNameToGetter;
/*    */   }
/*    */   
/*    */   public Map<String, Method> getPropertyNameToSetter() {
/* 53 */     return this.propertyNameToSetter;
/*    */   }
/*    */   
/*    */   public Method getGetter(String propertyName) {
/* 57 */     return this.propertyNameToGetter.get(propertyName);
/*    */   }
/*    */   
/*    */   public Method getSetter(String propertyName) {
/* 61 */     return this.propertyNameToSetter.get(propertyName);
/*    */   }
/*    */   
/*    */   public Map<String, Method> getPropertyNameToAdder() {
/* 65 */     return this.propertyNameToAdder;
/*    */   }
/*    */   
/*    */   public Method getAdder(String propertyName) {
/* 69 */     return this.propertyNameToAdder.get(propertyName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\jora\\util\beans\BeanDescription.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */