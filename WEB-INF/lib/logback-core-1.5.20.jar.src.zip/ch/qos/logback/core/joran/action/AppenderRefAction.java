/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.AppenderRefModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppenderRefAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext intercon, String name, Attributes attributes) {
/* 27 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, intercon, name, attributes);
/* 28 */     pv.validateRefAttribute();
/* 29 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 35 */     AppenderRefModel arm = new AppenderRefModel();
/* 36 */     String ref = attributes.getValue("ref");
/* 37 */     arm.setRef(ref);
/* 38 */     return (Model)arm;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\AppenderRefAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */