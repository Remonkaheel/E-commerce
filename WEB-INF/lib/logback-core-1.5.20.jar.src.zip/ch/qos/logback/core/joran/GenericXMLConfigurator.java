/*     */ package ch.qos.logback.core.joran;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.event.SaxEvent;
/*     */ import ch.qos.logback.core.joran.event.SaxEventRecorder;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.joran.spi.ElementPath;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.joran.spi.RuleStore;
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*     */ import ch.qos.logback.core.joran.spi.SaxEventInterpreter;
/*     */ import ch.qos.logback.core.joran.spi.SimpleRuleStore;
/*     */ import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*     */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*     */ import ch.qos.logback.core.spi.ConfigurationEvent;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.status.StatusUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GenericXMLConfigurator
/*     */   extends ContextAwareBase
/*     */ {
/*     */   protected SaxEventInterpreter saxEventInterpreter;
/*     */   protected ModelInterpretationContext modelInterpretationContext;
/*     */   private RuleStore ruleStore;
/*     */   
/*     */   public ModelInterpretationContext getModelInterpretationContext() {
/*  52 */     return this.modelInterpretationContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void doConfigure(URL url) throws JoranException {
/*  57 */     InputStream in = null;
/*     */     try {
/*  59 */       informContextOfURLUsedForConfiguration(getContext(), url);
/*  60 */       URLConnection urlConnection = url.openConnection();
/*     */ 
/*     */       
/*  63 */       urlConnection.setUseCaches(false);
/*     */       
/*  65 */       in = urlConnection.getInputStream();
/*  66 */       doConfigure(in, url.toExternalForm());
/*  67 */     } catch (IOException ioe) {
/*  68 */       String errMsg = "Could not open URL [" + String.valueOf(url) + "].";
/*  69 */       addError(errMsg, ioe);
/*  70 */       throw new JoranException(errMsg, ioe);
/*     */     } finally {
/*  72 */       if (in != null) {
/*     */         try {
/*  74 */           in.close();
/*  75 */         } catch (IOException ioe) {
/*  76 */           String errMsg = "Could not close input stream";
/*  77 */           addError(errMsg, ioe);
/*  78 */           throw new JoranException(errMsg, ioe);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void doConfigure(String filename) throws JoranException {
/*  85 */     doConfigure(new File(filename));
/*     */   }
/*     */   
/*     */   public final void doConfigure(File file) throws JoranException {
/*  89 */     FileInputStream fis = null;
/*     */     try {
/*  91 */       URL url = file.toURI().toURL();
/*  92 */       informContextOfURLUsedForConfiguration(getContext(), url);
/*  93 */       fis = new FileInputStream(file);
/*  94 */       doConfigure(fis, url.toExternalForm());
/*  95 */     } catch (IOException ioe) {
/*  96 */       String errMsg = "Could not open [" + file.getPath() + "].";
/*  97 */       addError(errMsg, ioe);
/*  98 */       throw new JoranException(errMsg, ioe);
/*     */     } finally {
/* 100 */       if (fis != null) {
/*     */         try {
/* 102 */           fis.close();
/* 103 */         } catch (IOException ioe) {
/* 104 */           String errMsg = "Could not close [" + file.getName() + "].";
/* 105 */           addError(errMsg, ioe);
/* 106 */           throw new JoranException(errMsg, ioe);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void informContextOfURLUsedForConfiguration(Context context, URL url) {
/* 113 */     ConfigurationWatchListUtil.setMainWatchURL(context, url);
/*     */   }
/*     */   
/*     */   public final void doConfigure(InputStream inputStream) throws JoranException {
/* 117 */     doConfigure(new InputSource(inputStream));
/*     */   }
/*     */   
/*     */   public final void doConfigure(InputStream inputStream, String systemId) throws JoranException {
/* 121 */     InputSource inputSource = new InputSource(inputStream);
/* 122 */     inputSource.setSystemId(systemId);
/* 123 */     doConfigure(inputSource);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract void addElementSelectorAndActionAssociations(RuleStore paramRuleStore);
/*     */ 
/*     */   
/*     */   protected abstract void setImplicitRuleSupplier(SaxEventInterpreter paramSaxEventInterpreter);
/*     */   
/*     */   protected void addDefaultNestedComponentRegistryRules(DefaultNestedComponentRegistry registry) {}
/*     */   
/*     */   protected ElementPath initialElementPath() {
/* 135 */     return new ElementPath();
/*     */   }
/*     */   
/*     */   protected void buildSaxEventInterpreter(List<SaxEvent> saxEvents) {
/* 139 */     RuleStore rs = getRuleStore();
/* 140 */     addElementSelectorAndActionAssociations(rs);
/* 141 */     this.saxEventInterpreter = new SaxEventInterpreter(this.context, rs, initialElementPath(), saxEvents);
/* 142 */     SaxEventInterpretationContext interpretationContext = this.saxEventInterpreter.getSaxEventInterpretationContext();
/* 143 */     interpretationContext.setContext(this.context);
/* 144 */     setImplicitRuleSupplier(this.saxEventInterpreter);
/*     */   }
/*     */   
/*     */   public RuleStore getRuleStore() {
/* 148 */     if (this.ruleStore == null) {
/* 149 */       this.ruleStore = (RuleStore)new SimpleRuleStore(this.context);
/*     */     }
/* 151 */     return this.ruleStore;
/*     */   }
/*     */   
/*     */   protected void buildModelInterpretationContext() {
/* 155 */     this.modelInterpretationContext = new ModelInterpretationContext(this.context);
/* 156 */     addDefaultNestedComponentRegistryRules(this.modelInterpretationContext.getDefaultNestedComponentRegistry());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void doConfigure(InputSource inputSource) throws JoranException {
/* 163 */     this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationStartedEvent(this));
/* 164 */     long threshold = System.currentTimeMillis();
/*     */     
/* 166 */     SaxEventRecorder recorder = populateSaxEventRecorder(inputSource);
/* 167 */     List<SaxEvent> saxEvents = recorder.getSaxEventList();
/* 168 */     if (saxEvents.isEmpty()) {
/* 169 */       addWarn("Empty sax event list");
/*     */       return;
/*     */     } 
/* 172 */     Model top = buildModelFromSaxEventList(recorder.getSaxEventList());
/* 173 */     if (top == null) {
/* 174 */       addError("Could not find valid configuration instructions. Exiting.");
/*     */       return;
/*     */     } 
/* 177 */     sanityCheck(top);
/* 178 */     processModel(top);
/*     */ 
/*     */     
/* 181 */     StatusUtil statusUtil = new StatusUtil(this.context);
/* 182 */     if (statusUtil.noXMLParsingErrorsOccurred(threshold)) {
/* 183 */       addInfo("Registering current configuration as safe fallback point");
/* 184 */       registerSafeConfiguration(top);
/* 185 */       this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationEndedSuccessfullyEvent(this));
/*     */     } else {
/* 187 */       this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationEndedWithXMLParsingErrorsEvent(this));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SaxEventRecorder populateSaxEventRecorder(InputSource inputSource) throws JoranException {
/* 194 */     SaxEventRecorder recorder = new SaxEventRecorder(this.context);
/* 195 */     recorder.recordEvents(inputSource);
/* 196 */     return recorder;
/*     */   }
/*     */   
/*     */   public Model buildModelFromSaxEventList(List<SaxEvent> saxEvents) throws JoranException {
/* 200 */     buildSaxEventInterpreter(saxEvents);
/* 201 */     playSaxEvents();
/* 202 */     Model top = this.saxEventInterpreter.getSaxEventInterpretationContext().peekModel();
/* 203 */     return top;
/*     */   }
/*     */   
/*     */   private void playSaxEvents() throws JoranException {
/* 207 */     this.saxEventInterpreter.getEventPlayer().play();
/*     */   }
/*     */   
/*     */   public void processModel(Model model) {
/* 211 */     buildModelInterpretationContext();
/* 212 */     this.modelInterpretationContext.setTopModel(model);
/* 213 */     this.modelInterpretationContext.setConfiguratorHint(this);
/* 214 */     DefaultProcessor defaultProcessor = new DefaultProcessor(this.context, this.modelInterpretationContext);
/* 215 */     addModelHandlerAssociations(defaultProcessor);
/*     */ 
/*     */     
/* 218 */     ReentrantLock configurationLock = this.context.getConfigurationLock();
/*     */     
/*     */     try {
/* 221 */       configurationLock.lock();
/* 222 */       defaultProcessor.process(model);
/*     */     } finally {
/* 224 */       configurationLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sanityCheck(Model topModel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addModelHandlerAssociations(DefaultProcessor defaultProcessor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerSafeConfiguration(Model top) {
/* 250 */     this.context.putObject("SAFE_JORAN_CONFIGURATION", top);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Model recallSafeConfiguration() {
/* 257 */     return (Model)this.context.getObject("SAFE_JORAN_CONFIGURATION");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\GenericXMLConfigurator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */