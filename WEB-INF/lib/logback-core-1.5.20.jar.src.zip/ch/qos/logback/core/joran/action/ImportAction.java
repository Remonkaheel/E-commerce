/*    */ package ch.qos.logback.core.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.ImportModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext intercon, String name, Attributes attributes) {
/* 32 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, intercon, name, attributes);
/* 33 */     pv.validateClassAttribute();
/* 34 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String localName, Attributes attributes) {
/* 40 */     ImportModel importModel = new ImportModel();
/* 41 */     importModel.setClassName(attributes.getValue("class"));
/* 42 */     return (Model)importModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\action\ImportAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */