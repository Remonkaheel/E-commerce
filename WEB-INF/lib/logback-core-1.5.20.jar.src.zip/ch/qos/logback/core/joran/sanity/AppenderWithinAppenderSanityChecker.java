/*    */ package ch.qos.logback.core.joran.sanity;
/*    */ 
/*    */ import ch.qos.logback.core.model.AppenderModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppenderWithinAppenderSanityChecker
/*    */   extends ContextAwareBase
/*    */   implements SanityChecker
/*    */ {
/* 26 */   public static String NESTED_APPENDERS_WARNING = "As of logback version 1.3, nested appenders are not allowed.";
/*    */ 
/*    */   
/*    */   public void check(Model model) {
/* 30 */     if (model == null) {
/*    */       return;
/*    */     }
/* 33 */     List<Model> appenderModels = new ArrayList<>();
/* 34 */     deepFindAllModelsOfType((Class)AppenderModel.class, appenderModels, model);
/*    */     
/* 36 */     List<Pair<Model, Model>> nestedPairs = deepFindNestedSubModelsOfType((Class)AppenderModel.class, appenderModels);
/*    */     
/* 38 */     List<Pair<Model, Model>> filteredNestedPairs = (List<Pair<Model, Model>>)nestedPairs.stream().filter(pair -> !isSiftingAppender((Model)pair.first)).collect(Collectors.toList());
/*    */     
/* 40 */     if (filteredNestedPairs.isEmpty()) {
/*    */       return;
/*    */     }
/* 43 */     addWarn(NESTED_APPENDERS_WARNING);
/* 44 */     for (Pair<Model, Model> pair : filteredNestedPairs) {
/* 45 */       addWarn("Appender at line " + ((Model)pair.first).getLineNumber() + " contains a nested appender at line " + ((Model)pair.second).getLineNumber());
/*    */     }
/*    */   }
/*    */   
/*    */   private boolean isSiftingAppender(Model first) {
/* 50 */     if (first instanceof AppenderModel) {
/* 51 */       AppenderModel appenderModel = (AppenderModel)first;
/* 52 */       String classname = appenderModel.getClassName();
/* 53 */       if (classname == null)
/* 54 */         return false; 
/* 55 */       return appenderModel.getClassName().contains("SiftingAppender");
/*    */     } 
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\joran\sanity\AppenderWithinAppenderSanityChecker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */