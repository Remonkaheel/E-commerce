package ch.qos.logback.core.boolex;

import ch.qos.logback.core.joran.conditional.Condition;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.LifeCycle;
import ch.qos.logback.core.spi.PropertyContainer;

public interface PropertyCondition extends Condition, ContextAware, LifeCycle {
  PropertyContainer getLocalPropertyContainer();
  
  void setLocalPropertyContainer(PropertyContainer paramPropertyContainer);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\boolex\PropertyCondition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */