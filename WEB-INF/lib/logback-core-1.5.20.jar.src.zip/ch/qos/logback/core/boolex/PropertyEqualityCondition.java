/*     */ package ch.qos.logback.core.boolex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyEqualityCondition
/*     */   extends PropertyConditionBase
/*     */ {
/*     */   String key;
/*     */   String value;
/*     */   
/*     */   public void start() {
/*  46 */     if (this.key == null) {
/*  47 */       addError("In PropertyEqualsValue 'key' parameter cannot be null");
/*     */       return;
/*     */     } 
/*  50 */     if (this.value == null) {
/*  51 */       addError("In PropertyEqualsValue 'value' parameter cannot be null");
/*     */       return;
/*     */     } 
/*  54 */     super.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  63 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/*  73 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  83 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKey(String key) {
/*  92 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean evaluate() {
/* 104 */     if (this.key == null) {
/* 105 */       addError("key cannot be null");
/* 106 */       return false;
/*     */     } 
/*     */     
/* 109 */     String val = p(this.key);
/* 110 */     if (val == null) {
/* 111 */       return false;
/*     */     }
/* 113 */     return val.equals(this.value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\boolex\PropertyEqualityCondition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */