/*    */ package ch.qos.logback.core.boolex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsPropertyDefinedCondition
/*    */   extends PropertyConditionBase
/*    */ {
/*    */   String key;
/*    */   
/*    */   public void start() {
/* 40 */     if (this.key == null) {
/* 41 */       addError("In IsPropertyDefinedEvaluator 'key' parameter cannot be null");
/*    */       return;
/*    */     } 
/* 44 */     super.start();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 54 */     return this.key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setKey(String key) {
/* 63 */     this.key = key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean evaluate() {
/* 75 */     return isDefined(this.key);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\boolex\IsPropertyDefinedCondition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */