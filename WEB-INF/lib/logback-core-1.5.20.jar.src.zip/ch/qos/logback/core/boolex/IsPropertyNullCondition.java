/*    */ package ch.qos.logback.core.boolex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsPropertyNullCondition
/*    */   extends PropertyConditionBase
/*    */ {
/*    */   String key;
/*    */   
/*    */   public void start() {
/* 22 */     if (this.key == null) {
/* 23 */       addError("In IsPropertyNullCondition 'key' parameter cannot be null");
/*    */       return;
/*    */     } 
/* 26 */     super.start();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 31 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(String key) {
/* 35 */     this.key = key;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean evaluate() {
/* 40 */     return isNull(this.key);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\boolex\IsPropertyNullCondition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */