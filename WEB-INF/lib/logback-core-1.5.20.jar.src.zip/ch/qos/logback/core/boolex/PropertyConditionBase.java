/*     */ package ch.qos.logback.core.boolex;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyConditionBase
/*     */   extends ContextAwareBase
/*     */   implements PropertyCondition
/*     */ {
/*     */   boolean started;
/*     */   PropertyContainer localPropertyContainer;
/*     */   
/*     */   public PropertyContainer getLocalPropertyContainer() {
/*  65 */     return this.localPropertyContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalPropertyContainer(PropertyContainer aLocalPropertyContainer) {
/*  78 */     this.localPropertyContainer = aLocalPropertyContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNull(String k) {
/*  92 */     String val = OptionHelper.propertyLookup(k, this.localPropertyContainer, (PropertyContainer)getContext());
/*  93 */     return (val == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefined(String k) {
/* 107 */     String val = OptionHelper.propertyLookup(k, this.localPropertyContainer, (PropertyContainer)getContext());
/* 108 */     return (val != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String p(String k) {
/* 119 */     return property(k);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String property(String k) {
/* 133 */     String val = OptionHelper.propertyLookup(k, this.localPropertyContainer, (PropertyContainer)getContext());
/* 134 */     if (val != null) {
/* 135 */       return val;
/*     */     }
/* 137 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStarted() {
/* 146 */     return this.started;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 153 */     this.started = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 160 */     this.started = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\boolex\PropertyConditionBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */