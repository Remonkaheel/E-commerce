/*     */ package ch.qos.logback.core.helpers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CyclicBuffer<E>
/*     */ {
/*     */   E[] ea;
/*     */   int first;
/*     */   int last;
/*     */   int numElems;
/*     */   int maxSize;
/*     */   
/*     */   public CyclicBuffer(int maxSize) throws IllegalArgumentException {
/*  44 */     if (maxSize < 1) {
/*  45 */       throw new IllegalArgumentException("The maxSize argument (" + maxSize + ") is not a positive integer.");
/*     */     }
/*  47 */     init(maxSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public CyclicBuffer(CyclicBuffer<E> other) {
/*  52 */     this.maxSize = other.maxSize;
/*  53 */     this.ea = (E[])new Object[this.maxSize];
/*  54 */     System.arraycopy(other.ea, 0, this.ea, 0, this.maxSize);
/*  55 */     this.last = other.last;
/*  56 */     this.first = other.first;
/*  57 */     this.numElems = other.numElems;
/*     */   }
/*     */ 
/*     */   
/*     */   private void init(int maxSize) {
/*  62 */     this.maxSize = maxSize;
/*  63 */     this.ea = (E[])new Object[maxSize];
/*  64 */     this.first = 0;
/*  65 */     this.last = 0;
/*  66 */     this.numElems = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  73 */     init(this.maxSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(E event) {
/*  81 */     this.ea[this.last] = event;
/*  82 */     if (++this.last == this.maxSize) {
/*  83 */       this.last = 0;
/*     */     }
/*  85 */     if (this.numElems < this.maxSize) {
/*  86 */       this.numElems++;
/*  87 */     } else if (++this.first == this.maxSize) {
/*  88 */       this.first = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E get(int i) {
/*  97 */     if (i < 0 || i >= this.numElems) {
/*  98 */       return null;
/*     */     }
/* 100 */     return this.ea[(this.first + i) % this.maxSize];
/*     */   }
/*     */   
/*     */   public int getMaxSize() {
/* 104 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E get() {
/* 112 */     E r = null;
/*     */     
/* 114 */     this.numElems--;
/* 115 */     r = this.ea[this.first];
/* 116 */     this.ea[this.first] = null;
/* 117 */     if (this.numElems > 0 && ++this.first == this.maxSize) {
/* 118 */       this.first = 0;
/*     */     }
/* 120 */     return r;
/*     */   }
/*     */   
/*     */   public List<E> asList() {
/* 124 */     List<E> tList = new ArrayList<>();
/* 125 */     for (int i = 0; i < length(); i++) {
/* 126 */       tList.add(get(i));
/*     */     }
/* 128 */     return tList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/* 136 */     return this.numElems;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resize(int newSize) {
/* 146 */     if (newSize < 0) {
/* 147 */       throw new IllegalArgumentException("Negative array size [" + newSize + "] not allowed.");
/*     */     }
/* 149 */     if (newSize == this.numElems) {
/*     */       return;
/*     */     }
/*     */     
/* 153 */     E[] temp = (E[])new Object[newSize];
/*     */     
/* 155 */     int loopLen = (newSize < this.numElems) ? newSize : this.numElems;
/*     */     
/* 157 */     for (int i = 0; i < loopLen; i++) {
/* 158 */       temp[i] = this.ea[this.first];
/* 159 */       this.ea[this.first] = null;
/* 160 */       if (++this.first == this.numElems)
/* 161 */         this.first = 0; 
/*     */     } 
/* 163 */     this.ea = temp;
/* 164 */     this.first = 0;
/* 165 */     this.numElems = loopLen;
/* 166 */     this.maxSize = newSize;
/* 167 */     if (loopLen == newSize) {
/* 168 */       this.last = 0;
/*     */     } else {
/* 170 */       this.last = loopLen;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\helpers\CyclicBuffer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */