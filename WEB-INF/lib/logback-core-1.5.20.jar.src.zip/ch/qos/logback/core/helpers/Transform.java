/*     */ package ch.qos.logback.core.helpers;
/*     */ 
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transform
/*     */ {
/*     */   private static final String CDATA_START = "<![CDATA[";
/*     */   private static final String CDATA_END = "]]>";
/*     */   private static final String CDATA_PSEUDO_END = "]]&gt;";
/*     */   private static final String CDATA_EMBEDED_END = "]]>]]&gt;<![CDATA[";
/*  29 */   private static final int CDATA_END_LEN = "]]>".length();
/*  30 */   private static final Pattern UNSAFE_XML_CHARS = Pattern.compile("[\000-\b\013\f\016-\037<>&'\"]");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeTags(String input) {
/*  40 */     if (input == null || input.length() == 0 || !UNSAFE_XML_CHARS.matcher(input).find()) {
/*  41 */       return input;
/*     */     }
/*  43 */     StringBuffer buf = new StringBuffer(input);
/*  44 */     return escapeTags(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeTags(StringBuffer buf) {
/*  56 */     for (int i = 0; i < buf.length(); i++) {
/*  57 */       char ch = buf.charAt(i);
/*  58 */       switch (ch) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\r':
/*     */           break;
/*     */         
/*     */         case '&':
/*  65 */           buf.replace(i, i + 1, "&amp;");
/*     */           break;
/*     */         case '<':
/*  68 */           buf.replace(i, i + 1, "&lt;");
/*     */           break;
/*     */         case '>':
/*  71 */           buf.replace(i, i + 1, "&gt;");
/*     */           break;
/*     */         case '"':
/*  74 */           buf.replace(i, i + 1, "&quot;");
/*     */           break;
/*     */         case '\'':
/*  77 */           buf.replace(i, i + 1, "&#39;");
/*     */           break;
/*     */         default:
/*  80 */           if (ch < ' ')
/*     */           {
/*     */             
/*  83 */             buf.replace(i, i + 1, "�");
/*     */           }
/*     */           break;
/*     */       } 
/*     */     } 
/*  88 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendEscapingCDATA(StringBuilder output, String str) {
/* 102 */     if (str == null) {
/*     */       return;
/*     */     }
/*     */     
/* 106 */     int end = str.indexOf("]]>");
/*     */     
/* 108 */     if (end < 0) {
/* 109 */       output.append(str);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 114 */     int start = 0;
/*     */     
/* 116 */     while (end > -1) {
/* 117 */       output.append(str.substring(start, end));
/* 118 */       output.append("]]>]]&gt;<![CDATA[");
/* 119 */       start = end + CDATA_END_LEN;
/*     */       
/* 121 */       if (start < str.length()) {
/* 122 */         end = str.indexOf("]]>", start);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       return;
/*     */     } 
/* 128 */     output.append(str.substring(start));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\helpers\Transform.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */