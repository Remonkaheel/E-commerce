package ch.qos.logback.core.helpers;

import ch.qos.logback.core.AppenderBase;

public final class NOPAppender<E> extends AppenderBase<E> {
  protected void append(E eventObject) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\helpers\NOPAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */