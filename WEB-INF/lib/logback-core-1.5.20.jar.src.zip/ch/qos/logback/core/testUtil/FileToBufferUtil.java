/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ import java.util.zip.GZIPInputStream;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileToBufferUtil
/*    */ {
/*    */   public static void readIntoList(File file, List<String> stringList) throws IOException {
/* 32 */     if (file.getName().endsWith(".gz")) {
/* 33 */       gzFileReadIntoList(file, stringList);
/* 34 */     } else if (file.getName().endsWith(".zip")) {
/* 35 */       zipFileReadIntoList(file, stringList);
/*    */     } else {
/* 37 */       regularReadIntoList(file, stringList);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void zipFileReadIntoList(File file, List<String> stringList) throws IOException {
/* 42 */     System.out.println("Reading zip file [" + String.valueOf(file) + "]");
/* 43 */     ZipFile zipFile = new ZipFile(file); 
/* 44 */     try { Enumeration<? extends ZipEntry> entries = zipFile.entries();
/* 45 */       ZipEntry entry = entries.nextElement();
/* 46 */       readInputStream(zipFile.getInputStream(entry), stringList);
/* 47 */       zipFile.close(); }
/*    */     catch (Throwable throwable) { try { zipFile.close(); }
/*    */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*    */        throw throwable; }
/* 51 */      } static void readInputStream(InputStream is, List<String> stringList) throws IOException { BufferedReader in = new BufferedReader(new InputStreamReader(is));
/*    */     String line;
/* 53 */     while ((line = in.readLine()) != null) {
/* 54 */       stringList.add(line);
/*    */     }
/* 56 */     in.close(); }
/*    */ 
/*    */   
/*    */   public static void regularReadIntoList(File file, List<String> stringList) throws IOException {
/* 60 */     FileInputStream fis = new FileInputStream(file);
/* 61 */     BufferedReader in = new BufferedReader(new InputStreamReader(fis));
/*    */     String line;
/* 63 */     while ((line = in.readLine()) != null) {
/* 64 */       stringList.add(line);
/*    */     }
/* 66 */     in.close();
/*    */   }
/*    */   
/*    */   public static void gzFileReadIntoList(File file, List<String> stringList) throws IOException {
/* 70 */     FileInputStream fis = new FileInputStream(file);
/* 71 */     GZIPInputStream gzis = new GZIPInputStream(fis);
/* 72 */     readInputStream(gzis, stringList);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\FileToBufferUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */