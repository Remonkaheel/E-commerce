/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvUtilForTests
/*    */ {
/* 21 */   static String GITHUB_HOME = "/home/runner";
/*    */   
/* 23 */   static String LOCAL_REPOSITORY_PREFIX = GITHUB_HOME;
/*    */   
/*    */   public static boolean isGithubAction() {
/* 26 */     String userHome = System.getProperty("user.home");
/* 27 */     String localRepository = System.getProperty("localRepository");
/*    */     
/* 29 */     if (GITHUB_HOME.equals(userHome)) {
/* 30 */       return true;
/*    */     }
/* 32 */     if (localRepository != null && localRepository.startsWith(LOCAL_REPOSITORY_PREFIX)) {
/* 33 */       return true;
/*    */     }
/* 35 */     return false;
/*    */   }
/*    */   
/*    */   public static boolean isWindows() {
/* 39 */     return (System.getProperty("os.name").indexOf("Windows") != -1);
/*    */   }
/*    */   
/*    */   public static boolean isMac() {
/* 43 */     return (System.getProperty("os.name").indexOf("Mac") != -1);
/*    */   }
/*    */   
/*    */   public static boolean isLinux() {
/* 47 */     return (System.getProperty("os.name").indexOf("Linux") != -1);
/*    */   }
/*    */   
/*    */   public static boolean isRunningOnSlowJenkins() {
/* 51 */     return (System.getProperty("slowJenkins") != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getLocalHostName() {
/*    */     try {
/* 57 */       InetAddress localhostIA = InetAddress.getLocalHost();
/* 58 */       return localhostIA.getHostName();
/* 59 */     } catch (UnknownHostException e) {
/* 60 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static boolean isLocalHostNameInList(String[] hostList) {
/* 65 */     String localHostName = getLocalHostName();
/* 66 */     if (localHostName == null) {
/* 67 */       return false;
/*    */     }
/* 69 */     for (String host : hostList) {
/* 70 */       if (host.equalsIgnoreCase(localHostName)) {
/* 71 */         return true;
/*    */       }
/*    */     } 
/* 74 */     return false;
/*    */   }
/*    */   
/*    */   public static String getPathToBash() {
/* 78 */     if (isLinux()) {
/* 79 */       return "bash";
/*    */     }
/* 81 */     if (isLocalHostNameInList(new String[] { "hetz", "het" })) {
/* 82 */       return "c:/cygwin/bin/bash";
/*    */     }
/* 84 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\EnvUtilForTests.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */