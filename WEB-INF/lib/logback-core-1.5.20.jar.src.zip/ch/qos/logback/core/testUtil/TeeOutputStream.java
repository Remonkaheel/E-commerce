/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeeOutputStream
/*    */   extends OutputStream
/*    */ {
/*    */   final PrintStream targetPS;
/* 31 */   public final ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*    */ 
/*    */   
/*    */   public TeeOutputStream(PrintStream targetPS) {
/* 35 */     this.targetPS = targetPS;
/*    */   }
/*    */   
/*    */   public void write(int b) throws IOException {
/* 39 */     this.baos.write(b);
/* 40 */     if (this.targetPS != null) {
/* 41 */       this.targetPS.write(b);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString() {
/* 46 */     return this.baos.toString();
/*    */   }
/*    */   
/*    */   public byte[] toByteArray() {
/* 50 */     return this.baos.toByteArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\TeeOutputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */