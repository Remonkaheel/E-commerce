/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import ch.qos.logback.core.AppenderBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NPEAppender<E>
/*    */   extends AppenderBase<E>
/*    */ {
/*    */   protected void append(E eventObject) {
/* 21 */     throw new NullPointerException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\NPEAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */