/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RunnableWithCounterAndDone
/*    */   implements Runnable
/*    */ {
/*    */   protected boolean done = false;
/* 25 */   protected long counter = 0L;
/*    */   
/*    */   public long getCounter() {
/* 28 */     return this.counter;
/*    */   }
/*    */   
/*    */   public void setDone(boolean done) {
/* 32 */     this.done = done;
/*    */   }
/*    */   
/*    */   public boolean isDone() {
/* 36 */     return this.done;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\RunnableWithCounterAndDone.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */