/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileTestUtil
/*    */ {
/*    */   public static void makeTestOutputDir() {
/* 25 */     File target = new File("target/");
/* 26 */     if (target.exists() && target.isDirectory()) {
/* 27 */       File testoutput = new File("target/test-output/");
/* 28 */       if (!testoutput.exists()) {
/* 29 */         boolean result = testoutput.mkdir();
/* 30 */         if (!result)
/* 31 */           throw new IllegalStateException("Failed to create " + String.valueOf(testoutput)); 
/*    */       } 
/*    */     } else {
/* 34 */       throw new IllegalStateException("target/ does not exist");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\FileTestUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */