/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import ch.qos.logback.core.AppenderBase;
/*    */ import ch.qos.logback.core.Layout;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringListAppender<E>
/*    */   extends AppenderBase<E>
/*    */ {
/*    */   Layout<E> layout;
/* 25 */   public List<String> strList = new ArrayList<>();
/*    */   
/*    */   public void start() {
/* 28 */     this.strList.clear();
/*    */     
/* 30 */     if (this.layout == null || !this.layout.isStarted()) {
/*    */       return;
/*    */     }
/* 33 */     super.start();
/*    */   }
/*    */   
/*    */   public void stop() {
/* 37 */     super.stop();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void append(E eventObject) {
/* 42 */     String res = this.layout.doLayout(eventObject);
/* 43 */     this.strList.add(res);
/*    */   }
/*    */   
/*    */   public Layout<E> getLayout() {
/* 47 */     return this.layout;
/*    */   }
/*    */   
/*    */   public void setLayout(Layout<E> layout) {
/* 51 */     this.layout = layout;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\StringListAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */