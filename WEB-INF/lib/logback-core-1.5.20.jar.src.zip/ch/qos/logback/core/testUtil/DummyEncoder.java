/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import ch.qos.logback.core.CoreConstants;
/*    */ import ch.qos.logback.core.encoder.EncoderBase;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DummyEncoder<E>
/*    */   extends EncoderBase<E>
/*    */ {
/* 23 */   public static final String DUMMY = "dummy" + CoreConstants.LINE_SEPARATOR;
/* 24 */   String val = DUMMY;
/*    */   String fileHeader;
/*    */   String fileFooter;
/*    */   Charset charset;
/*    */   
/*    */   public Charset getCharset() {
/* 30 */     return this.charset;
/*    */   }
/*    */   
/*    */   public void setCharset(Charset charset) {
/* 34 */     this.charset = charset;
/*    */   }
/*    */ 
/*    */   
/*    */   public DummyEncoder() {}
/*    */   
/*    */   public DummyEncoder(String val) {
/* 41 */     this.val = val;
/*    */   }
/*    */   
/*    */   public byte[] encode(E event) {
/* 45 */     return encodeString(this.val);
/*    */   }
/*    */   
/*    */   byte[] encodeString(String s) {
/* 49 */     if (this.charset == null) {
/* 50 */       return s.getBytes();
/*    */     }
/* 52 */     return s.getBytes(this.charset);
/*    */   }
/*    */ 
/*    */   
/*    */   private void appendIfNotNull(StringBuilder sb, String s) {
/* 57 */     if (s != null) {
/* 58 */       sb.append(s);
/*    */     }
/*    */   }
/*    */   
/*    */   byte[] header() {
/* 63 */     StringBuilder sb = new StringBuilder();
/* 64 */     appendIfNotNull(sb, this.fileHeader);
/* 65 */     if (sb.length() > 0)
/*    */     {
/*    */ 
/*    */       
/* 69 */       sb.append(CoreConstants.LINE_SEPARATOR);
/*    */     }
/* 71 */     return encodeString(sb.toString());
/*    */   }
/*    */   
/*    */   public byte[] headerBytes() {
/* 75 */     return header();
/*    */   }
/*    */   
/*    */   public byte[] footerBytes() {
/* 79 */     if (this.fileFooter == null) {
/* 80 */       return null;
/*    */     }
/* 82 */     return encodeString(this.fileFooter);
/*    */   }
/*    */   
/*    */   public String getFileHeader() {
/* 86 */     return this.fileHeader;
/*    */   }
/*    */   
/*    */   public void setFileHeader(String fileHeader) {
/* 90 */     this.fileHeader = fileHeader;
/*    */   }
/*    */   
/*    */   public String getFileFooter() {
/* 94 */     return this.fileFooter;
/*    */   }
/*    */   
/*    */   public void setFileFooter(String fileFooter) {
/* 98 */     this.fileFooter = fileFooter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\DummyEncoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */