/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import ch.qos.logback.core.read.ListAppender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelayingListAppender<E>
/*    */   extends ListAppender<E>
/*    */ {
/* 20 */   public int delay = 1;
/*    */   public boolean interrupted = false;
/*    */   
/*    */   public void setDelay(int ms) {
/* 24 */     this.delay = ms;
/*    */   }
/*    */ 
/*    */   
/*    */   public void append(E e) {
/*    */     try {
/* 30 */       Thread.sleep(this.delay);
/* 31 */     } catch (InterruptedException ie) {
/*    */       
/* 33 */       this.interrupted = true;
/*    */     } 
/* 35 */     super.append(e);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\DelayingListAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */