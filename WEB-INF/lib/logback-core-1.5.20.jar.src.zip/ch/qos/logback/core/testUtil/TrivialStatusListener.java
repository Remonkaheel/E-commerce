/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.status.Status;
/*    */ import ch.qos.logback.core.status.StatusListener;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrivialStatusListener
/*    */   implements StatusListener, LifeCycle
/*    */ {
/* 25 */   public List<Status> list = new ArrayList<>();
/*    */   boolean start = false;
/*    */   
/*    */   public void addStatusEvent(Status status) {
/* 29 */     if (!isStarted())
/*    */       return; 
/* 31 */     this.list.add(status);
/*    */   }
/*    */   
/*    */   public void start() {
/* 35 */     this.start = true;
/*    */   }
/*    */   
/*    */   public void stop() {
/* 39 */     this.start = false;
/*    */   }
/*    */   
/*    */   public boolean isStarted() {
/* 43 */     return this.start;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\TrivialStatusListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */