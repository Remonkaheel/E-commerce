/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractMultiThreadedHarness
/*    */ {
/*    */   public abstract void waitUntilEndCondition() throws InterruptedException;
/*    */   
/*    */   public void execute(RunnableWithCounterAndDone[] runnableArray) throws InterruptedException {
/* 21 */     Thread[] threadArray = new Thread[runnableArray.length];
/*    */     
/* 23 */     for (int i = 0; i < runnableArray.length; i++) {
/* 24 */       System.out.println("Starting " + String.valueOf(runnableArray[i]));
/* 25 */       threadArray[i] = new Thread(runnableArray[i], "Harness[" + i + "]");
/*    */     } 
/* 27 */     for (Thread t : threadArray) {
/* 28 */       t.start();
/*    */     }
/*    */     
/* 31 */     waitUntilEndCondition();
/* 32 */     for (RunnableWithCounterAndDone r : runnableArray) {
/* 33 */       r.setDone(true);
/*    */     }
/* 35 */     for (Thread t : threadArray)
/* 36 */       t.join(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\AbstractMultiThreadedHarness.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */