/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MockInitialContext
/*    */   extends InitialContext
/*    */ {
/* 24 */   public Map<String, Object> map = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object lookup(String name) throws NamingException {
/* 32 */     if (name == null) {
/* 33 */       return null;
/*    */     }
/*    */     
/* 36 */     return this.map.get(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\MockInitialContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */