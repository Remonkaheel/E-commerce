/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XTeeOutputStream
/*    */   extends TeeOutputStream
/*    */ {
/*    */   boolean closed = false;
/*    */   
/*    */   public XTeeOutputStream(PrintStream targetPS) {
/* 26 */     super(targetPS);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 31 */     this.closed = true;
/* 32 */     super.close();
/*    */   }
/*    */   
/*    */   public boolean isClosed() {
/* 36 */     return this.closed;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\XTeeOutputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */