package ch.qos.logback.core.testUtil;

public class CoreTestConstants {
  public static final String TEST_SRC_PREFIX = "src/test/";
  
  public static final String TEST_INPUT_PREFIX = "src/test/input/";
  
  public static final String JORAN_INPUT_PREFIX = "src/test/input/joran/";
  
  public static final String TARGET_DIR = "target/";
  
  public static final String OUTPUT_DIR_PREFIX = "target/test-output/";
  
  public static final int SUCCESSFUL_EXIT_CODE = 8;
  
  public static final int FAILURE_EXIT_CODE = 1;
  
  public static final String BASH_PATH_ON_CYGWIN = "c:/cygwin/bin/bash";
  
  public static final String BASH_PATH_ON_LINUX = "bash";
  
  public static final String SLOW_JENKINS = "slowJenkins";
  
  public static final String JAVA_NAMING_FACTORY_INITIAL = "java.naming.factory.initial";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\CoreTestConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */