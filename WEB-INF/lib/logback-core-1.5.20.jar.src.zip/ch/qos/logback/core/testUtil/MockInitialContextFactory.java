/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.NamingException;
/*    */ import javax.naming.spi.InitialContextFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MockInitialContextFactory
/*    */   implements InitialContextFactory
/*    */ {
/*    */   static MockInitialContext mic;
/*    */   
/*    */   static {
/* 26 */     System.out.println("MockInitialContextFactory static called");
/* 27 */     initialize();
/*    */   }
/*    */   
/*    */   public static void initialize() {
/*    */     try {
/* 32 */       mic = new MockInitialContext();
/* 33 */     } catch (NamingException e) {
/* 34 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public Context getInitialContext(Hashtable<?, ?> environment) throws NamingException {
/* 39 */     return mic;
/*    */   }
/*    */   
/*    */   public static MockInitialContext getContext() {
/* 43 */     return mic;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\MockInitialContextFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */