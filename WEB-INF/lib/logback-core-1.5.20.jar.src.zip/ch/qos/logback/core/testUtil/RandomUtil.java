/*    */ package ch.qos.logback.core.testUtil;
/*    */ 
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomUtil
/*    */ {
/* 20 */   private static Random random = new Random();
/*    */   
/*    */   public static int getRandomServerPort() {
/* 23 */     int r = random.nextInt(20000);
/*    */     
/* 25 */     return r + 1024;
/*    */   }
/*    */   
/*    */   public static int getPositiveInt() {
/* 29 */     int r = random.nextInt();
/* 30 */     if (r < 0) {
/* 31 */       r = -r;
/*    */     }
/* 33 */     return r;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\testUtil\RandomUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */