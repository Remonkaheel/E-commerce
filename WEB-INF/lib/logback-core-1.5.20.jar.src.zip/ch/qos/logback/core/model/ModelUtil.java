/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.ActionUtil;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.model.util.PropertyModelHandlerHelper;
/*    */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelUtil
/*    */ {
/*    */   public static void resetForReuse(Model model) {
/* 26 */     if (model == null)
/*    */       return; 
/* 28 */     model.resetForReuse();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static void setProperty(ModelInterpretationContext mic, String key, String value, ActionUtil.Scope scope) {
/* 41 */     PropertyModelHandlerHelper.setProperty((ContextAwarePropertyContainer)mic, key, value, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static void setProperties(ModelInterpretationContext mic, Properties props, ActionUtil.Scope scope) {
/* 52 */     PropertyModelHandlerHelper.setProperties((ContextAwarePropertyContainer)mic, props, scope);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ModelUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */