/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversionRuleModel
/*    */   extends ComponentModel
/*    */ {
/*    */   String conversionWord;
/*    */   
/*    */   protected ConversionRuleModel makeNewInstance() {
/* 23 */     return new ConversionRuleModel();
/*    */   }
/*    */   
/*    */   public String getConversionWord() {
/* 27 */     return this.conversionWord;
/*    */   }
/*    */   
/*    */   public void setConversionWord(String conversionWord) {
/* 31 */     this.conversionWord = conversionWord;
/*    */   }
/*    */   
/*    */   public String getConverterClass() {
/* 35 */     return getClassName();
/*    */   }
/*    */   
/*    */   public void setConverterClass(String converterClass) {
/* 39 */     setClassName(converterClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ConversionRuleModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */