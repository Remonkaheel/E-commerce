/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.action.ActionUtil;
/*    */ import ch.qos.logback.core.model.InsertFromJNDIModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.util.PropertyModelHandlerHelper;
/*    */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*    */ import ch.qos.logback.core.util.JNDIUtil;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ public class InsertFromJNDIModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public InsertFromJNDIModelHandler(Context context) {
/* 18 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 22 */     return new InsertFromJNDIModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<InsertFromJNDIModel> getSupportedModelClass() {
/* 27 */     return InsertFromJNDIModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 32 */     InsertFromJNDIModel ifjm = (InsertFromJNDIModel)model;
/* 33 */     detachedHandle(mic, ifjm);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void detachedHandle(ContextAwarePropertyContainer capc, InsertFromJNDIModel ifjm) {
/* 43 */     int errorCount = 0;
/* 44 */     String envEntryName = capc.subst(ifjm.getEnvEntryName());
/* 45 */     String asKey = capc.subst(ifjm.getAs());
/*    */     
/* 47 */     String scopeStr = capc.subst(ifjm.getScopeStr());
/* 48 */     ActionUtil.Scope scope = ActionUtil.stringToScope(scopeStr);
/*    */ 
/*    */ 
/*    */     
/* 52 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(envEntryName)) {
/* 53 */       addError("[env-entry-name] missing");
/* 54 */       errorCount++;
/*    */     } 
/*    */     
/* 57 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(asKey)) {
/* 58 */       addError("[as] missing");
/* 59 */       errorCount++;
/*    */     } 
/*    */     
/* 62 */     if (errorCount != 0) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 67 */       Context ctx = JNDIUtil.getInitialContext();
/* 68 */       String envEntryValue = JNDIUtil.lookupString(ctx, envEntryName);
/* 69 */       if (OptionHelper.isNullOrEmptyOrAllSpaces(envEntryValue)) {
/* 70 */         addError("[" + envEntryName + "] has null or empty value");
/*    */       } else {
/* 72 */         addInfo("Setting variable [" + asKey + "] to [" + envEntryValue + "] in [" + String.valueOf(scope) + "] scope");
/* 73 */         PropertyModelHandlerHelper.setProperty(capc, asKey, envEntryValue, scope);
/*    */       } 
/* 75 */     } catch (NamingException e) {
/* 76 */       addError("Failed to lookup JNDI env-entry [" + envEntryName + "]");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\InsertFromJNDIModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */