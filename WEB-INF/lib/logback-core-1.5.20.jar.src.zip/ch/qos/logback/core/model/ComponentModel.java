/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = -7117814935763453139L;
/*    */   String className;
/*    */   
/*    */   protected ComponentModel makeNewInstance() {
/* 32 */     return new ComponentModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 37 */     ComponentModel actual = (ComponentModel)that;
/* 38 */     super.mirror(actual);
/* 39 */     this.className = actual.className;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 44 */     return this.className;
/*    */   }
/*    */   
/*    */   public void setClassName(String className) {
/* 48 */     this.className = className;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     return getClass().getSimpleName() + " [tag=" + getClass().getSimpleName() + ", className=" + this.tag + ", bodyText=" + this.className + "]";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 59 */     int prime = 31;
/* 60 */     int result = super.hashCode();
/* 61 */     result = 31 * result + Objects.hash(new Object[] { this.className });
/* 62 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 67 */     if (this == obj)
/* 68 */       return true; 
/* 69 */     if (!super.equals(obj))
/* 70 */       return false; 
/* 71 */     if (getClass() != obj.getClass())
/* 72 */       return false; 
/* 73 */     ComponentModel other = (ComponentModel)obj;
/* 74 */     return Objects.equals(this.className, other.className);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ComponentModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */