/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DependencyDefinition
/*    */ {
/*    */   Model depender;
/*    */   String dependee;
/*    */   
/*    */   public DependencyDefinition(Model depender, String dependee) {
/* 35 */     this.depender = depender;
/* 36 */     this.dependee = dependee;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDependee() {
/* 42 */     return this.dependee;
/*    */   }
/*    */   
/*    */   public Model getDepender() {
/* 46 */     return this.depender;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\DependencyDefinition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */