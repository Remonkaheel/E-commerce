/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.GenericXMLConfigurator;
/*     */ import ch.qos.logback.core.joran.event.SaxEvent;
/*     */ import ch.qos.logback.core.joran.event.SaxEventRecorder;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
/*     */ import ch.qos.logback.core.model.IncludeModel;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.ResourceModel;
/*     */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IncludeModelHandler
/*     */   extends ResourceHandlerBase
/*     */ {
/*     */   boolean inError = false;
/*     */   
/*     */   public IncludeModelHandler(Context context) {
/*  49 */     super(context);
/*     */   }
/*     */   
/*     */   public static IncludeModelHandler makeInstance(Context context, ModelInterpretationContext mic) {
/*  53 */     return new IncludeModelHandler(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<IncludeModel> getSupportedModelClass() {
/*  58 */     return IncludeModel.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/*  63 */     IncludeModel includeModel = (IncludeModel)model;
/*  64 */     Model modelFromIncludedFile = buildModelFromIncludedFile(mic, includeModel);
/*  65 */     if (modelFromIncludedFile == null) {
/*  66 */       warnIfRequired("Failed to build include model from included file");
/*     */       return;
/*     */     } 
/*  69 */     processModelFromIncludedFile(includeModel, modelFromIncludedFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Model buildModelFromIncludedFile(ContextAwarePropertyContainer capc, IncludeModel includeModel) throws ModelHandlerException {
/*  82 */     this.optional = OptionHelper.toBoolean(includeModel.getOptional(), false);
/*     */     
/*  84 */     if (!checkAttributes((ResourceModel)includeModel)) {
/*  85 */       this.inError = true;
/*  86 */       return null;
/*     */     } 
/*     */     
/*  89 */     InputStream in = getInputStream(capc, includeModel);
/*  90 */     if (in == null) {
/*  91 */       this.inError = true;
/*  92 */       return null;
/*     */     } 
/*     */     
/*  95 */     SaxEventRecorder recorder = null;
/*     */     
/*     */     try {
/*  98 */       recorder = populateSaxEventRecorder(in);
/*     */       
/* 100 */       List<SaxEvent> saxEvents = recorder.getSaxEventList();
/* 101 */       if (saxEvents.isEmpty()) {
/* 102 */         addWarn("Empty sax event list");
/* 103 */         return null;
/*     */       } 
/*     */       
/* 106 */       Supplier<? extends GenericXMLConfigurator> jcSupplier = capc.getConfiguratorSupplier();
/* 107 */       if (jcSupplier == null) {
/* 108 */         addError("null configurator supplier. Abandoning inclusion of [" + this.attributeInUse + "]");
/* 109 */         this.inError = true;
/* 110 */         return null;
/*     */       } 
/*     */       
/* 113 */       GenericXMLConfigurator genericXMLConfigurator = jcSupplier.get();
/* 114 */       genericXMLConfigurator.getRuleStore().addPathPathMapping("included", "configuration");
/*     */       
/* 116 */       Model modelFromIncludedFile = genericXMLConfigurator.buildModelFromSaxEventList(recorder.getSaxEventList());
/* 117 */       return modelFromIncludedFile;
/* 118 */     } catch (JoranException e) {
/* 119 */       this.inError = true;
/* 120 */       addError("Error processing XML data in [" + this.attributeInUse + "]", (Throwable)e);
/* 121 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processModelFromIncludedFile(IncludeModel includeModel, Model modelFromIncludedFile) {
/* 126 */     includeModel.getSubModels().addAll(modelFromIncludedFile.getSubModels());
/*     */   }
/*     */   
/*     */   public SaxEventRecorder populateSaxEventRecorder(InputStream inputStream) throws JoranException {
/* 130 */     SaxEventRecorder recorder = new SaxEventRecorder(this.context);
/* 131 */     recorder.recordEvents(inputStream);
/* 132 */     return recorder;
/*     */   }
/*     */   
/*     */   private InputStream getInputStream(ContextAwarePropertyContainer capc, IncludeModel includeModel) {
/* 136 */     URL inputURL = getInputURL(capc, (ResourceModel)includeModel);
/* 137 */     if (inputURL == null)
/* 138 */       return null; 
/* 139 */     ConfigurationWatchListUtil.addToWatchList(this.context, inputURL);
/* 140 */     return openURL(inputURL);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\IncludeModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */