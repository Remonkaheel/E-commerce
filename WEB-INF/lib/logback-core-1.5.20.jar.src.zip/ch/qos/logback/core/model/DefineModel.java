/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefineModel
/*    */   extends NamedComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 6209642548924431065L;
/*    */   String scopeStr;
/*    */   
/*    */   protected DefineModel makeNewInstance() {
/* 25 */     return new DefineModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 30 */     DefineModel actual = (DefineModel)that;
/* 31 */     super.mirror(actual);
/* 32 */     this.scopeStr = actual.scopeStr;
/*    */   }
/*    */   
/*    */   public String getScopeStr() {
/* 36 */     return this.scopeStr;
/*    */   }
/*    */   
/*    */   public void setScopeStr(String scopeStr) {
/* 40 */     this.scopeStr = scopeStr;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 45 */     int prime = 31;
/* 46 */     int result = super.hashCode();
/* 47 */     result = 31 * result + Objects.hash(new Object[] { this.scopeStr });
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 53 */     if (this == obj)
/* 54 */       return true; 
/* 55 */     if (!super.equals(obj))
/* 56 */       return false; 
/* 57 */     if (getClass() != obj.getClass())
/* 58 */       return false; 
/* 59 */     DefineModel other = (DefineModel)obj;
/* 60 */     return Objects.equals(this.scopeStr, other.scopeStr);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\DefineModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */