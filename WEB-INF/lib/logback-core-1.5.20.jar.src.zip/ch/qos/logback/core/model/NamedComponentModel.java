/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedComponentModel
/*    */   extends ComponentModel
/*    */   implements INamedModel
/*    */ {
/*    */   private static final long serialVersionUID = -6388316680413871442L;
/*    */   String name;
/*    */   
/*    */   protected NamedComponentModel makeNewInstance() {
/* 25 */     return new NamedComponentModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 30 */     NamedComponentModel actual = (NamedComponentModel)that;
/* 31 */     super.mirror(actual);
/* 32 */     this.name = actual.name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 36 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 40 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 45 */     return "NamedComponentModel [name=" + this.name + ", className=" + this.className + ", tag=" + this.tag + ", bodyText=" + this.bodyText + "]";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     int prime = 31;
/* 52 */     int result = super.hashCode();
/* 53 */     result = 31 * result + Objects.hash(new Object[] { this.name });
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj)
/* 60 */       return true; 
/* 61 */     if (!super.equals(obj))
/* 62 */       return false; 
/* 63 */     if (getClass() != obj.getClass())
/* 64 */       return false; 
/* 65 */     NamedComponentModel other = (NamedComponentModel)obj;
/* 66 */     return Objects.equals(this.name, other.name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\NamedComponentModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */