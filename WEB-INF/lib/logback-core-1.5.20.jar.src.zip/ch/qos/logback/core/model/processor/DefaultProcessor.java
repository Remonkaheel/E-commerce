/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.ModelHandlerFactoryMethod;
/*     */ import ch.qos.logback.core.model.NamedComponentModel;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.FilterReply;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultProcessor
/*     */   extends ContextAwareBase
/*     */ {
/*     */   protected final ModelInterpretationContext mic;
/*  44 */   final HashMap<Class<? extends Model>, ModelHandlerFactoryMethod> modelClassToHandlerMap = new HashMap<>();
/*  45 */   final HashMap<Class<? extends Model>, Supplier<ModelHandlerBase>> modelClassToDependencyAnalyserMap = new HashMap<>();
/*     */   
/*  47 */   ChainedModelFilter phaseOneFilter = new ChainedModelFilter();
/*  48 */   ChainedModelFilter phaseTwoFilter = new ChainedModelFilter();
/*     */   
/*     */   public DefaultProcessor(Context context, ModelInterpretationContext mic) {
/*  51 */     setContext(context);
/*  52 */     this.mic = mic;
/*     */   }
/*     */   static final int DENIED = -1;
/*     */   
/*     */   public void addHandler(Class<? extends Model> modelClass, ModelHandlerFactoryMethod modelFactoryMethod) {
/*  57 */     this.modelClassToHandlerMap.put(modelClass, modelFactoryMethod);
/*     */     
/*  59 */     ProcessingPhase phase = determineProcessingPhase(modelClass);
/*  60 */     switch (phase) {
/*     */       case FIRST:
/*  62 */         getPhaseOneFilter().allow(modelClass);
/*     */         return;
/*     */       case SECOND:
/*  65 */         getPhaseTwoFilter().allow(modelClass);
/*     */         return;
/*     */     } 
/*  68 */     throw new IllegalArgumentException("unexpected value " + String.valueOf(phase) + " for model class " + modelClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ProcessingPhase determineProcessingPhase(Class<? extends Model> modelClass) {
/*  74 */     PhaseIndicator phaseIndicator = modelClass.<PhaseIndicator>getAnnotation(PhaseIndicator.class);
/*  75 */     if (phaseIndicator == null) {
/*  76 */       return ProcessingPhase.FIRST;
/*     */     }
/*     */     
/*  79 */     ProcessingPhase phase = phaseIndicator.phase();
/*  80 */     return phase;
/*     */   }
/*     */   
/*     */   public void addAnalyser(Class<? extends Model> modelClass, Supplier<ModelHandlerBase> analyserSupplier) {
/*  84 */     this.modelClassToDependencyAnalyserMap.put(modelClass, analyserSupplier);
/*     */   }
/*     */   
/*     */   private void traversalLoop(TraverseMethod traverseMethod, Model model, ModelFilter modelfFilter, String phaseName) {
/*  88 */     int LIMIT = 3;
/*  89 */     for (int i = 0; i < LIMIT; i++) {
/*  90 */       int handledModelCount = traverseMethod.traverse(model, modelfFilter);
/*  91 */       if (handledModelCount == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void process(Model model) {
/*  98 */     if (model == null) {
/*  99 */       addError("Expecting non null model to process");
/*     */       return;
/*     */     } 
/* 102 */     initialObjectPush();
/*     */     
/* 104 */     mainTraverse(model, getPhaseOneFilter());
/* 105 */     analyseDependencies(model);
/* 106 */     traversalLoop(this::secondPhaseTraverse, model, getPhaseTwoFilter(), "phase 2");
/*     */     
/* 108 */     addInfo("End of configuration.");
/* 109 */     finalObjectPop();
/*     */   }
/*     */   
/*     */   private void finalObjectPop() {
/* 113 */     this.mic.popObject();
/*     */   }
/*     */   
/*     */   private void initialObjectPush() {
/* 117 */     this.mic.pushObject(this.context);
/*     */   }
/*     */   
/*     */   public ChainedModelFilter getPhaseOneFilter() {
/* 121 */     return this.phaseOneFilter;
/*     */   }
/*     */   
/*     */   public ChainedModelFilter getPhaseTwoFilter() {
/* 125 */     return this.phaseTwoFilter;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void analyseDependencies(Model model) {
/* 130 */     Supplier<ModelHandlerBase> analyserSupplier = this.modelClassToDependencyAnalyserMap.get(model.getClass());
/*     */     
/* 132 */     ModelHandlerBase analyser = null;
/*     */     
/* 134 */     if (analyserSupplier != null) {
/* 135 */       analyser = analyserSupplier.get();
/*     */     }
/*     */     
/* 138 */     if (analyser != null && !model.isSkipped()) {
/* 139 */       callAnalyserHandleOnModel(model, analyser);
/*     */     }
/*     */     
/* 142 */     for (Model m : model.getSubModels()) {
/* 143 */       analyseDependencies(m);
/*     */     }
/*     */     
/* 146 */     if (analyser != null && !model.isSkipped()) {
/* 147 */       callAnalyserPostHandleOnModel(model, analyser);
/*     */     }
/*     */   }
/*     */   
/*     */   private void callAnalyserPostHandleOnModel(Model model, ModelHandlerBase analyser) {
/*     */     try {
/* 153 */       analyser.postHandle(this.mic, model);
/* 154 */     } catch (ModelHandlerException e) {
/* 155 */       addError("Failed to invoke postHandle on model " + model.getTag(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void callAnalyserHandleOnModel(Model model, ModelHandlerBase analyser) {
/*     */     try {
/* 161 */       analyser.handle(this.mic, model);
/* 162 */     } catch (ModelHandlerException e) {
/* 163 */       addError("Failed to traverse model " + model.getTag(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ModelHandlerBase createHandler(Model model) {
/* 170 */     ModelHandlerFactoryMethod modelFactoryMethod = this.modelClassToHandlerMap.get(model.getClass());
/*     */     
/* 172 */     if (modelFactoryMethod == null) {
/* 173 */       addError("Can't handle model of type " + String.valueOf(model.getClass()) + "  with tag: " + model.getTag() + " at line " + model
/* 174 */           .getLineNumber());
/* 175 */       return null;
/*     */     } 
/*     */     
/* 178 */     ModelHandlerBase handler = modelFactoryMethod.make(this.context, this.mic);
/* 179 */     if (handler == null)
/* 180 */       return null; 
/* 181 */     if (!handler.isSupportedModelType(model)) {
/* 182 */       addWarn("Handler [" + String.valueOf(handler.getClass()) + "] does not support " + model.idString());
/* 183 */       return null;
/*     */     } 
/* 185 */     return handler;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int mainTraverse(Model model, ModelFilter modelFiler) {
/* 190 */     FilterReply filterReply = modelFiler.decide(model);
/* 191 */     if (filterReply == FilterReply.DENY) {
/* 192 */       return -1;
/*     */     }
/* 194 */     int count = 0;
/*     */     
/*     */     try {
/* 197 */       ModelHandlerBase handler = null;
/* 198 */       boolean unhandled = model.isUnhandled();
/*     */       
/* 200 */       if (unhandled) {
/* 201 */         handler = createHandler(model);
/* 202 */         if (handler != null) {
/* 203 */           handler.handle(this.mic, model);
/* 204 */           model.markAsHandled();
/* 205 */           count++;
/*     */         } 
/*     */       } 
/*     */       
/* 209 */       if (!model.isSkipped()) {
/* 210 */         for (Model m : model.getSubModels()) {
/* 211 */           count += mainTraverse(m, modelFiler);
/*     */         }
/*     */       }
/*     */       
/* 215 */       if (unhandled && handler != null) {
/* 216 */         handler.postHandle(this.mic, model);
/*     */       }
/* 218 */     } catch (ModelHandlerException e) {
/* 219 */       addError("Failed to traverse model " + model.getTag(), e);
/*     */     } 
/* 221 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int secondPhaseTraverse(Model model, ModelFilter modelFilter) {
/* 226 */     FilterReply filterReply = modelFilter.decide(model);
/* 227 */     if (filterReply == FilterReply.DENY) {
/* 228 */       return 0;
/*     */     }
/*     */     
/* 231 */     int count = 0;
/*     */ 
/*     */     
/*     */     try {
/* 235 */       boolean allDependenciesStarted = allDependenciesStarted(model);
/*     */       
/* 237 */       ModelHandlerBase handler = null;
/* 238 */       if (model.isUnhandled() && allDependenciesStarted) {
/* 239 */         handler = createHandler(model);
/* 240 */         if (handler != null) {
/* 241 */           handler.handle(this.mic, model);
/* 242 */           model.markAsHandled();
/* 243 */           count++;
/*     */         } 
/*     */       } 
/*     */       
/* 247 */       if (!allDependenciesStarted && !dependencyIsADirectSubmodel(model)) {
/* 248 */         return count;
/*     */       }
/*     */       
/* 251 */       if (!model.isSkipped()) {
/* 252 */         for (Model m : model.getSubModels()) {
/* 253 */           count += secondPhaseTraverse(m, modelFilter);
/*     */         }
/*     */       }
/* 256 */       if (handler != null) {
/* 257 */         handler.postHandle(this.mic, model);
/*     */       }
/* 259 */     } catch (ModelHandlerException e) {
/* 260 */       addError("Failed to traverse model " + model.getTag(), e);
/*     */     } 
/* 262 */     return count;
/*     */   }
/*     */   
/*     */   private boolean dependencyIsADirectSubmodel(Model model) {
/* 266 */     List<String> dependecyNames = this.mic.getDependeeNamesForModel(model);
/* 267 */     if (dependecyNames == null || dependecyNames.isEmpty()) {
/* 268 */       return false;
/*     */     }
/* 270 */     for (Model submodel : model.getSubModels()) {
/* 271 */       if (submodel instanceof NamedComponentModel) {
/* 272 */         NamedComponentModel namedComponentModel = (NamedComponentModel)submodel;
/* 273 */         String subModelName = namedComponentModel.getName();
/* 274 */         if (dependecyNames.contains(subModelName)) {
/* 275 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 280 */     return false;
/*     */   }
/*     */   
/*     */   private boolean allDependenciesStarted(Model model) {
/* 284 */     List<String> dependencyNames = this.mic.getDependeeNamesForModel(model);
/*     */     
/* 286 */     if (dependencyNames == null || dependencyNames.isEmpty()) {
/* 287 */       return true;
/*     */     }
/* 289 */     for (String name : dependencyNames) {
/* 290 */       boolean isStarted = this.mic.isNamedDependeeStarted(name);
/* 291 */       if (!isStarted) {
/* 292 */         return false;
/*     */       }
/*     */     } 
/* 295 */     return true;
/*     */   }
/*     */   
/*     */   ModelHandlerBase instantiateHandler(Class<? extends ModelHandlerBase> handlerClass) {
/*     */     try {
/* 300 */       Constructor<? extends ModelHandlerBase> commonConstructor = getWithContextConstructor(handlerClass);
/* 301 */       if (commonConstructor != null) {
/* 302 */         return commonConstructor.newInstance(new Object[] { this.context });
/*     */       }
/* 304 */       Constructor<? extends ModelHandlerBase> constructorWithBDC = getWithContextAndBDCConstructor(handlerClass);
/* 305 */       if (constructorWithBDC != null) {
/* 306 */         return constructorWithBDC.newInstance(new Object[] { this.context, this.mic.getBeanDescriptionCache() });
/*     */       }
/* 308 */       addError("Failed to find suitable constructor for class [" + String.valueOf(handlerClass) + "]");
/* 309 */       return null;
/* 310 */     } catch (InstantiationException|IllegalAccessException|SecurityException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e1) {
/*     */       
/* 312 */       addError("Failed to instantiate " + String.valueOf(handlerClass));
/* 313 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Constructor<? extends ModelHandlerBase> getWithContextConstructor(Class<? extends ModelHandlerBase> handlerClass) {
/*     */     try {
/* 320 */       Constructor<? extends ModelHandlerBase> constructor = handlerClass.getConstructor(new Class[] { Context.class });
/* 321 */       return constructor;
/* 322 */     } catch (NoSuchMethodException e) {
/* 323 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Constructor<? extends ModelHandlerBase> getWithContextAndBDCConstructor(Class<? extends ModelHandlerBase> handlerClass) {
/*     */     try {
/* 330 */       Constructor<? extends ModelHandlerBase> constructor = handlerClass.getConstructor(new Class[] { Context.class, BeanDescriptionCache.class });
/*     */       
/* 332 */       return constructor;
/* 333 */     } catch (NoSuchMethodException e) {
/* 334 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static interface TraverseMethod {
/*     */     int traverse(Model param1Model, ModelFilter param1ModelFilter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\DefaultProcessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */