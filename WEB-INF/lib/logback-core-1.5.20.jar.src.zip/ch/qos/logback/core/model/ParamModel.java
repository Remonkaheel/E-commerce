/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ public class ParamModel
/*    */   extends NamedModel
/*    */ {
/*    */   private static final long serialVersionUID = -3697627721759508667L;
/*    */   String value;
/*    */   
/*    */   protected ParamModel makeNewInstance() {
/* 12 */     return new ParamModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 17 */     ParamModel actual = (ParamModel)that;
/* 18 */     super.mirror(actual);
/* 19 */     this.value = actual.value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 23 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 27 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 32 */     int prime = 31;
/* 33 */     int result = super.hashCode();
/* 34 */     result = 31 * result + Objects.hash(new Object[] { this.value });
/* 35 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 40 */     if (this == obj)
/* 41 */       return true; 
/* 42 */     if (!super.equals(obj))
/* 43 */       return false; 
/* 44 */     if (getClass() != obj.getClass())
/* 45 */       return false; 
/* 46 */     ParamModel other = (ParamModel)obj;
/* 47 */     return Objects.equals(this.value, other.value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ParamModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */