package ch.qos.logback.core.model.processor;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface PhaseIndicator {
  ProcessingPhase phase() default ProcessingPhase.FIRST;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\PhaseIndicator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */