/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceNumberGeneratorModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 4109015583434648277L;
/*    */   
/*    */   protected SequenceNumberGeneratorModel makeNewInstance() {
/* 22 */     return new SequenceNumberGeneratorModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\SequenceNumberGeneratorModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */