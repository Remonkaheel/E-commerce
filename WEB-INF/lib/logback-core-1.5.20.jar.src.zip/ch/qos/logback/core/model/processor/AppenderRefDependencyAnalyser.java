/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.AppenderRefModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PhaseIndicator(phase = ProcessingPhase.DEPENDENCY_ANALYSIS)
/*    */ public class AppenderRefDependencyAnalyser
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public AppenderRefDependencyAnalyser(Context context) {
/* 24 */     super(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<AppenderRefModel> getSupportedModelClass() {
/* 29 */     return AppenderRefModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/*    */     Model depender;
/* 35 */     AppenderRefModel appenderRefModel = (AppenderRefModel)model;
/*    */     
/* 37 */     String ref = mic.subst(appenderRefModel.getRef());
/*    */ 
/*    */     
/* 40 */     if (mic.isModelStackEmpty()) {
/*    */       
/* 42 */       AppenderRefModel appenderRefModel1 = appenderRefModel;
/*    */     } else {
/* 44 */       Model parentModel = mic.peekModel();
/* 45 */       depender = parentModel;
/*    */     } 
/*    */     
/* 48 */     DependencyDefinition dd = new DependencyDefinition(depender, ref);
/* 49 */     mic.addDependencyDefinition(dd);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\AppenderRefDependencyAnalyser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */