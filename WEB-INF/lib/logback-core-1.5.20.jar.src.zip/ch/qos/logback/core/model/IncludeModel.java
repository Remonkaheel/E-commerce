package ch.qos.logback.core.model;

public class IncludeModel extends ResourceModel {
  private static final long serialVersionUID = -9114108510322703902L;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\IncludeModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */