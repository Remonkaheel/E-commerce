/*    */ package ch.qos.logback.core.model.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ public class ThenModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = -3264631638136701741L;
/*    */   
/*    */   protected ThenModel makeNewInstance() {
/* 11 */     return new ThenModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\conditional\ThenModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */