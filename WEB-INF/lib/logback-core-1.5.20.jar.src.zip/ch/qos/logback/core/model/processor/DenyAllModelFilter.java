/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.FilterReply;
/*    */ 
/*    */ public class DenyAllModelFilter
/*    */   implements ModelFilter
/*    */ {
/*    */   public FilterReply decide(Model model) {
/* 10 */     return FilterReply.DENY;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\DenyAllModelFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */