/*     */ package ch.qos.logback.core.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Model
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -797372668713068159L;
/*     */   boolean handled = false;
/*     */   boolean skipped = false;
/*     */   String tag;
/*     */   String bodyText;
/*     */   int lineNumber;
/*  40 */   List<Model> subModels = new ArrayList<>();
/*     */   
/*     */   public static Model duplicate(Model that) {
/*  43 */     Model copy = that.makeNewInstance();
/*  44 */     copy.mirror(that);
/*  45 */     for (Model m : that.subModels) {
/*  46 */       Model duplicate = duplicate(m);
/*  47 */       copy.subModels.add(duplicate);
/*     */     } 
/*  49 */     return copy;
/*     */   }
/*     */   
/*     */   protected Model makeNewInstance() {
/*  53 */     return new Model();
/*     */   }
/*     */   
/*     */   protected void mirror(Model that) {
/*  57 */     this.tag = that.tag;
/*  58 */     this.bodyText = that.bodyText;
/*  59 */     this.lineNumber = that.lineNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsSkipped() {
/*  64 */     this.skipped = true;
/*     */   }
/*     */   public void deepMarkAsSkipped() {
/*  67 */     markAsSkipped();
/*  68 */     for (Model m : getSubModels()) {
/*  69 */       m.deepMarkAsSkipped();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resetForReuse() {
/*  78 */     this.handled = false;
/*  79 */     this.skipped = false;
/*  80 */     for (Model sub : this.subModels) {
/*  81 */       sub.resetForReuse();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isSkipped() {
/*  86 */     return this.skipped;
/*     */   }
/*     */   
/*     */   public boolean isUnhandled() {
/*  90 */     return !this.handled;
/*     */   }
/*     */   
/*     */   public boolean isHandled() {
/*  94 */     return this.handled;
/*     */   }
/*     */   
/*     */   public void markAsHandled() {
/*  98 */     this.handled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTag() {
/* 105 */     return this.tag;
/*     */   }
/*     */   
/*     */   public void setTag(String tag) {
/* 109 */     this.tag = tag;
/*     */   }
/*     */   
/*     */   public int getLineNumber() {
/* 113 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */   public void setLineNumber(int lineNumber) {
/* 117 */     this.lineNumber = lineNumber;
/*     */   }
/*     */   
/*     */   public List<Model> getSubModels() {
/* 121 */     return this.subModels;
/*     */   }
/*     */   
/*     */   public void addSubModel(Model m) {
/* 125 */     this.subModels.add(m);
/*     */   }
/*     */   
/*     */   public String getBodyText() {
/* 129 */     return this.bodyText;
/*     */   }
/*     */   
/*     */   public void addText(String bodytext) {
/* 133 */     if (this.bodyText == null) {
/* 134 */       this.bodyText = bodytext;
/*     */     } else {
/* 136 */       this.bodyText += this.bodyText;
/*     */     } 
/*     */   }
/*     */   public String idString() {
/* 140 */     return "<" + this.tag + "> at line " + this.lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     return Objects.hash(new Object[] { this.bodyText, Integer.valueOf(this.lineNumber), this.subModels, this.tag });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 151 */     if (this == obj)
/* 152 */       return true; 
/* 153 */     if (obj == null)
/* 154 */       return false; 
/* 155 */     if (getClass() != obj.getClass())
/* 156 */       return false; 
/* 157 */     Model other = (Model)obj;
/* 158 */     return (Objects.equals(this.bodyText, other.bodyText) && this.lineNumber == other.lineNumber && 
/* 159 */       Objects.equals(this.subModels, other.subModels) && Objects.equals(this.tag, other.tag));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 165 */     return getClass().getSimpleName() + " [tag=" + getClass().getSimpleName() + ", bodyText=" + this.tag + ", id=" + this.bodyText + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\Model.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */