/*    */ package ch.qos.logback.core.model.processor.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.boolex.PropertyCondition;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.ByPropertiesConditionModel;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.spi.PropertyContainer;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByPropertiesConditionModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   private boolean inError = false;
/*    */   PropertyCondition propertyEvaluator;
/*    */   
/*    */   public ByPropertiesConditionModelHandler(Context context) {
/* 36 */     super(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ByPropertiesConditionModel> getSupportedModelClass() {
/* 41 */     return ByPropertiesConditionModel.class;
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext mic) {
/* 45 */     return new ByPropertiesConditionModelHandler(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 52 */     ByPropertiesConditionModel byPropertiesConditionModel = (ByPropertiesConditionModel)model;
/* 53 */     String className = byPropertiesConditionModel.getClassName();
/* 54 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 55 */       addWarn("Missing className. This should have been caught earlier.");
/* 56 */       this.inError = true;
/*    */       return;
/*    */     } 
/* 59 */     className = mic.getImport(className);
/*    */     
/*    */     try {
/* 62 */       addInfo("About to instantiate PropertyEvaluator of type [" + className + "]");
/*    */       
/* 64 */       this.propertyEvaluator = (PropertyCondition)OptionHelper.instantiateByClassName(className, PropertyCondition.class, this.context);
/*    */       
/* 66 */       this.propertyEvaluator.setContext(this.context);
/* 67 */       this.propertyEvaluator.setLocalPropertyContainer((PropertyContainer)mic);
/* 68 */       mic.pushObject(this.propertyEvaluator);
/* 69 */     } catch (Exception e) {
/* 70 */       this.inError = true;
/* 71 */       mic.pushObject(IfModel.BranchState.IN_ERROR);
/* 72 */       addError("Could not create a SequenceNumberGenerator of type [" + className + "].", e);
/* 73 */       throw new ModelHandlerException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 78 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 81 */     Object o = mic.peekObject();
/* 82 */     if (o != this.propertyEvaluator) {
/* 83 */       addWarn("The object at the of the stack is not the propertyEvaluator instance pushed earlier.");
/*    */     } else {
/* 85 */       mic.popObject();
/*    */     } 
/*    */     
/* 88 */     this.propertyEvaluator.start();
/* 89 */     if (!this.propertyEvaluator.isStarted()) {
/* 90 */       addError("PropertyEvaluator of type [" + this.propertyEvaluator.getClass().getName() + "] did not start successfully.");
/* 91 */       mic.pushObject(IfModel.BranchState.IN_ERROR);
/*    */       return;
/*    */     } 
/* 94 */     boolean evaluationResult = this.propertyEvaluator.evaluate();
/* 95 */     IfModel.BranchState branchState = evaluationResult ? IfModel.BranchState.IF_BRANCH : IfModel.BranchState.ELSE_BRANCH;
/* 96 */     mic.pushObject(branchState);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\conditional\ByPropertiesConditionModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */