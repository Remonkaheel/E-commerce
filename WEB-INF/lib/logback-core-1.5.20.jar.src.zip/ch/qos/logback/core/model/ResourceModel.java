/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 2185210901733958800L;
/*    */   String file;
/*    */   String url;
/*    */   String resource;
/*    */   String optional;
/*    */   
/*    */   public String getOptional() {
/* 28 */     return this.optional;
/*    */   }
/*    */   
/*    */   public void setOptional(String optional) {
/* 32 */     this.optional = optional;
/*    */   }
/*    */   
/*    */   public String getFile() {
/* 36 */     return this.file;
/*    */   }
/*    */   
/*    */   public void setFile(String file) {
/* 40 */     this.file = file;
/*    */   }
/*    */   
/*    */   public String getUrl() {
/* 44 */     return this.url;
/*    */   }
/*    */   
/*    */   public void setUrl(String url) {
/* 48 */     this.url = url;
/*    */   }
/*    */   
/*    */   public String getResource() {
/* 52 */     return this.resource;
/*    */   }
/*    */   
/*    */   public void setResource(String resource) {
/* 56 */     this.resource = resource;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ResourceModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */