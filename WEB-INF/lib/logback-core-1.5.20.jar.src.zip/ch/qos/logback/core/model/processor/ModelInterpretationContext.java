/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.GenericXMLConfigurator;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.util.VariableSubstitutionsHelper;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelInterpretationContext
/*     */   extends ContextAwareBase
/*     */   implements ContextAwarePropertyContainer
/*     */ {
/*     */   Stack<Object> objectStack;
/*     */   Stack<Model> modelStack;
/*     */   Supplier<? extends GenericXMLConfigurator> configuratorSupplier;
/*     */   Map<String, Object> objectMap;
/*     */   protected VariableSubstitutionsHelper variableSubstitutionsHelper;
/*     */   protected Map<String, String> importMap;
/*     */   private final BeanDescriptionCache beanDescriptionCache;
/*  59 */   final DefaultNestedComponentRegistry defaultNestedComponentRegistry = new DefaultNestedComponentRegistry();
/*  60 */   List<DependencyDefinition> dependencyDefinitionList = new ArrayList<>();
/*  61 */   final List<String> startedDependees = new ArrayList<>();
/*     */   
/*     */   Object configuratorHint;
/*     */   
/*     */   Model topModel;
/*     */   
/*     */   public ModelInterpretationContext(Context context) {
/*  68 */     this(context, (Object)null);
/*     */   }
/*     */   
/*     */   public ModelInterpretationContext(Context context, Object configuratorHint) {
/*  72 */     this.context = context;
/*  73 */     this.configuratorHint = configuratorHint;
/*  74 */     this.objectStack = new Stack();
/*  75 */     this.modelStack = new Stack<>();
/*  76 */     this.beanDescriptionCache = new BeanDescriptionCache(context);
/*  77 */     this.objectMap = new HashMap<>(5);
/*  78 */     this.variableSubstitutionsHelper = new VariableSubstitutionsHelper(context);
/*  79 */     this.importMap = new HashMap<>(5);
/*     */   }
/*     */   
/*     */   public ModelInterpretationContext(ModelInterpretationContext otherMic) {
/*  83 */     this(otherMic.context, otherMic.configuratorHint);
/*  84 */     this.importMap = new HashMap<>(otherMic.importMap);
/*  85 */     this.variableSubstitutionsHelper = new VariableSubstitutionsHelper(this.context, otherMic.getCopyOfPropertyMap());
/*  86 */     this.defaultNestedComponentRegistry.duplicate(otherMic.getDefaultNestedComponentRegistry());
/*  87 */     createAppenderBags();
/*     */   }
/*     */   
/*     */   public Map<String, Object> getObjectMap() {
/*  91 */     return this.objectMap;
/*     */   }
/*     */   
/*     */   public void createAppenderBags() {
/*  95 */     this.objectMap.put("APPENDER_BAG", new HashMap<>());
/*  96 */     this.objectMap.put("APPENDER_REF_BAG", new HashMap<>());
/*     */   }
/*     */   
/*     */   public Model getTopModel() {
/* 100 */     return this.topModel;
/*     */   }
/*     */   
/*     */   public void setTopModel(Model topModel) {
/* 104 */     this.topModel = topModel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushModel(Model m) {
/* 110 */     this.modelStack.push(m);
/*     */   }
/*     */   
/*     */   public Model peekModel() {
/* 114 */     return this.modelStack.peek();
/*     */   }
/*     */   
/*     */   public boolean isModelStackEmpty() {
/* 118 */     return this.modelStack.isEmpty();
/*     */   }
/*     */   
/*     */   public Model popModel() {
/* 122 */     return this.modelStack.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Stack<Object> getObjectStack() {
/* 128 */     return this.objectStack;
/*     */   }
/*     */   
/*     */   public boolean isObjectStackEmpty() {
/* 132 */     return this.objectStack.isEmpty();
/*     */   }
/*     */   
/*     */   public Object peekObject() {
/* 136 */     return this.objectStack.peek();
/*     */   }
/*     */   
/*     */   public void pushObject(Object o) {
/* 140 */     this.objectStack.push(o);
/*     */   }
/*     */   
/*     */   public Object popObject() {
/* 144 */     return this.objectStack.pop();
/*     */   }
/*     */   
/*     */   public Object getObject(int i) {
/* 148 */     return this.objectStack.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getConfiguratorHint() {
/* 154 */     return this.configuratorHint;
/*     */   }
/*     */   
/*     */   public void setConfiguratorHint(Object configuratorHint) {
/* 158 */     this.configuratorHint = configuratorHint;
/*     */   }
/*     */   
/*     */   public BeanDescriptionCache getBeanDescriptionCache() {
/* 162 */     return this.beanDescriptionCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public String subst(String ref) {
/* 167 */     String substituted = this.variableSubstitutionsHelper.subst(ref);
/* 168 */     if (ref != null && !ref.equals(substituted)) {
/* 169 */       addInfo("value \"" + substituted + "\" substituted for \"" + ref + "\"");
/*     */     }
/* 171 */     return substituted;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultNestedComponentRegistry getDefaultNestedComponentRegistry() {
/* 176 */     return this.defaultNestedComponentRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDependencyDefinition(DependencyDefinition dd) {
/* 182 */     this.dependencyDefinitionList.add(dd);
/*     */   }
/*     */   
/*     */   public List<DependencyDefinition> getDependencyDefinitions() {
/* 186 */     return Collections.unmodifiableList(this.dependencyDefinitionList);
/*     */   }
/*     */   
/*     */   public List<String> getDependeeNamesForModel(Model model) {
/* 190 */     List<String> dependencyList = new ArrayList<>();
/* 191 */     for (DependencyDefinition dd : this.dependencyDefinitionList) {
/* 192 */       if (dd.getDepender() == model) {
/* 193 */         dependencyList.add(dd.getDependee());
/*     */       }
/*     */     } 
/* 196 */     return dependencyList;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDependers(String dependeeName) {
/* 201 */     if (dependeeName == null || dependeeName.trim().length() == 0) {
/* 202 */       new IllegalArgumentException("Empty dependeeName name not allowed here");
/*     */     }
/*     */     
/* 205 */     for (DependencyDefinition dd : this.dependencyDefinitionList) {
/* 206 */       if (dd.dependee.equals(dependeeName)) {
/* 207 */         return true;
/*     */       }
/*     */     } 
/* 210 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void markStartOfNamedDependee(String name) {
/* 215 */     this.startedDependees.add(name);
/*     */   }
/*     */   
/*     */   public boolean isNamedDependeeStarted(String name) {
/* 219 */     return this.startedDependees.contains(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSubstitutionProperty(String key, String value) {
/* 230 */     this.variableSubstitutionsHelper.addSubstitutionProperty(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 238 */     return this.variableSubstitutionsHelper.getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopyOfPropertyMap() {
/* 243 */     return this.variableSubstitutionsHelper.getCopyOfPropertyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addImport(String stem, String fqcn) {
/* 257 */     this.importMap.put(stem, fqcn);
/*     */   }
/*     */   
/*     */   public Map<String, String> getImportMapCopy() {
/* 261 */     return new HashMap<>(this.importMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImport(String stem) {
/* 277 */     if (stem == null) {
/* 278 */       return null;
/*     */     }
/* 280 */     String result = this.importMap.get(stem);
/* 281 */     if (result == null) {
/* 282 */       return stem;
/*     */     }
/* 284 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<? extends GenericXMLConfigurator> getConfiguratorSupplier() {
/* 294 */     return this.configuratorSupplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfiguratorSupplier(Supplier<? extends GenericXMLConfigurator> configuratorSupplier) {
/* 302 */     this.configuratorSupplier = configuratorSupplier;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ModelInterpretationContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */