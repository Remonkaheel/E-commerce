/*    */ package ch.qos.logback.core.model.util;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TagUtil
/*    */ {
/*    */   public static String unifiedTag(Model aModel) {
/* 21 */     String tag = aModel.getTag();
/*    */     
/* 23 */     char first = tag.charAt(0);
/* 24 */     if (Character.isUpperCase(first)) {
/* 25 */       char lower = Character.toLowerCase(first);
/* 26 */       return "" + lower + lower;
/*    */     } 
/* 28 */     return tag;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\mode\\util\TagUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */