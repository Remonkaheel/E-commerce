/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusListenerModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = -236751010143929616L;
/*    */   
/*    */   protected StatusListenerModel makeNewInstance() {
/* 22 */     return new StatusListenerModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\StatusListenerModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */