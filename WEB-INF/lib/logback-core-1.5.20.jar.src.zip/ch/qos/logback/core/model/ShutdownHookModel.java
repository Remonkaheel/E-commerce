/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShutdownHookModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 8886561840058239494L;
/*    */   
/*    */   protected ShutdownHookModel makeNewInstance() {
/* 22 */     return new ShutdownHookModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ShutdownHookModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */