/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.action.ImcplicitActionDataForBasicProperty;
/*     */ import ch.qos.logback.core.joran.action.ImplicitModelData;
/*     */ import ch.qos.logback.core.joran.action.ImplicitModelDataForComplexProperty;
/*     */ import ch.qos.logback.core.joran.spi.NoAutoStartUtil;
/*     */ import ch.qos.logback.core.joran.util.PropertySetter;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*     */ import ch.qos.logback.core.model.ComponentModel;
/*     */ import ch.qos.logback.core.model.ImplicitModel;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.util.AggregationType;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImplicitModelHandler
/*     */   extends ModelHandlerBase
/*     */ {
/*     */   private final BeanDescriptionCache beanDescriptionCache;
/*     */   private ImplicitModelData implicitModelData;
/*     */   public static final String IGNORING_UNKNOWN_PROP = "Ignoring unknown property";
/*     */   boolean inError = false;
/*     */   
/*     */   public ImplicitModelHandler(Context context, BeanDescriptionCache beanDescriptionCache) {
/*  43 */     super(context);
/*  44 */     this.beanDescriptionCache = beanDescriptionCache;
/*     */   }
/*     */   
/*     */   protected Class<? extends ImplicitModel> getSupportedModelClass() {
/*  48 */     return ImplicitModel.class;
/*     */   }
/*     */   
/*     */   public static ImplicitModelHandler makeInstance(Context context, ModelInterpretationContext mic) {
/*  52 */     BeanDescriptionCache beanDescriptionCache = mic.getBeanDescriptionCache();
/*  53 */     return new ImplicitModelHandler(context, beanDescriptionCache);
/*     */   }
/*     */   
/*     */   public void handle(ModelInterpretationContext mic, Model model) {
/*     */     ImcplicitActionDataForBasicProperty adBasicProperty;
/*     */     ImplicitModelDataForComplexProperty adComplex;
/*  59 */     ImplicitModel implicitModel = (ImplicitModel)model;
/*     */ 
/*     */     
/*  62 */     if (mic.isObjectStackEmpty()) {
/*  63 */       this.inError = true;
/*     */       return;
/*     */     } 
/*  66 */     String nestedElementTagName = implicitModel.getTag();
/*     */     
/*  68 */     Object o = mic.peekObject();
/*  69 */     PropertySetter parentBean = new PropertySetter(this.beanDescriptionCache, o);
/*  70 */     parentBean.setContext(this.context);
/*     */     
/*  72 */     AggregationType aggregationType = parentBean.computeAggregationType(nestedElementTagName);
/*     */     
/*  74 */     switch (aggregationType) {
/*     */       case NOT_FOUND:
/*  76 */         addWarn("Ignoring unknown property [" + nestedElementTagName + "] in [" + o.getClass().getName() + "]");
/*  77 */         this.inError = true;
/*     */         
/*  79 */         implicitModel.markAsSkipped();
/*     */         return;
/*     */       case AS_BASIC_PROPERTY:
/*     */       case AS_BASIC_PROPERTY_COLLECTION:
/*  83 */         adBasicProperty = new ImcplicitActionDataForBasicProperty(parentBean, aggregationType, nestedElementTagName);
/*     */         
/*  85 */         this.implicitModelData = (ImplicitModelData)adBasicProperty;
/*  86 */         doBasicProperty(mic, model, adBasicProperty);
/*     */         return;
/*     */       
/*     */       case AS_COMPLEX_PROPERTY_COLLECTION:
/*     */       case AS_COMPLEX_PROPERTY:
/*  91 */         adComplex = new ImplicitModelDataForComplexProperty(parentBean, aggregationType, nestedElementTagName);
/*     */         
/*  93 */         this.implicitModelData = (ImplicitModelData)adComplex;
/*  94 */         doComplex(mic, (ComponentModel)implicitModel, adComplex);
/*     */         return;
/*     */     } 
/*  97 */     addError("PropertySetter.computeAggregationType returned " + String.valueOf(aggregationType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doBasicProperty(ModelInterpretationContext interpretationContext, Model model, ImcplicitActionDataForBasicProperty actionData) {
/* 105 */     String finalBody = interpretationContext.subst(model.getBodyText());
/*     */ 
/*     */ 
/*     */     
/* 109 */     switch (actionData.aggregationType) {
/*     */       case AS_BASIC_PROPERTY:
/* 111 */         actionData.parentBean.setProperty(actionData.propertyName, finalBody);
/*     */         return;
/*     */       case AS_BASIC_PROPERTY_COLLECTION:
/* 114 */         actionData.parentBean.addBasicProperty(actionData.propertyName, finalBody);
/*     */         return;
/*     */     } 
/* 117 */     addError("Unexpected aggregationType " + String.valueOf(actionData.aggregationType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doComplex(ModelInterpretationContext interpretationContext, ComponentModel componentModel, ImplicitModelDataForComplexProperty actionData) {
/* 124 */     String className = componentModel.getClassName();
/*     */     
/* 126 */     String substClassName = interpretationContext.subst(className);
/*     */     
/* 128 */     String fqcn = interpretationContext.getImport(substClassName);
/*     */     
/* 130 */     Class<?> componentClass = null;
/*     */     
/*     */     try {
/* 133 */       if (!OptionHelper.isNullOrEmptyOrAllSpaces(fqcn)) {
/* 134 */         componentClass = Loader.loadClass(fqcn, this.context);
/*     */       } else {
/*     */         
/* 137 */         PropertySetter parentBean = actionData.parentBean;
/* 138 */         componentClass = parentBean.getClassNameViaImplicitRules(actionData.propertyName, actionData
/* 139 */             .getAggregationType(), interpretationContext.getDefaultNestedComponentRegistry());
/*     */       } 
/*     */       
/* 142 */       if (componentClass == null) {
/* 143 */         actionData.inError = true;
/* 144 */         String errMsg = "Could not find an appropriate class for property [" + componentModel.getTag() + "]";
/* 145 */         addError(errMsg);
/*     */         
/*     */         return;
/*     */       } 
/* 149 */       if (OptionHelper.isNullOrEmptyOrAllSpaces(fqcn)) {
/* 150 */         addInfo("Assuming default type [" + componentClass.getName() + "] for [" + componentModel.getTag() + "] property");
/*     */       }
/*     */ 
/*     */       
/* 154 */       actionData.setNestedComplexProperty(componentClass.getConstructor(new Class[0]).newInstance(new Object[0]));
/*     */ 
/*     */       
/* 157 */       if (actionData.getNestedComplexProperty() instanceof ContextAware) {
/* 158 */         ((ContextAware)actionData.getNestedComplexProperty()).setContext(this.context);
/*     */       }
/*     */ 
/*     */       
/* 162 */       interpretationContext.pushObject(actionData.getNestedComplexProperty());
/*     */     }
/* 164 */     catch (Exception oops) {
/* 165 */       actionData.inError = true;
/* 166 */       String msg = "Could not create component [" + componentModel.getTag() + "] of type [" + fqcn + "]";
/* 167 */       addError(msg, oops);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void postHandle(ModelInterpretationContext intercon, Model model) {
/* 173 */     if (this.inError) {
/*     */       return;
/*     */     }
/*     */     
/* 177 */     if (this.implicitModelData == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 182 */     if (this.implicitModelData.inError) {
/*     */       return;
/*     */     }
/* 185 */     if (this.implicitModelData instanceof ImplicitModelDataForComplexProperty) {
/* 186 */       postHandleComplex(intercon, model, (ImplicitModelDataForComplexProperty)this.implicitModelData);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void postHandleComplex(ModelInterpretationContext mic, Model model, ImplicitModelDataForComplexProperty imdComplex) {
/* 195 */     PropertySetter nestedBean = new PropertySetter(this.beanDescriptionCache, imdComplex.getNestedComplexProperty());
/* 196 */     nestedBean.setContext(this.context);
/*     */ 
/*     */     
/* 199 */     if (nestedBean.computeAggregationType("parent") == AggregationType.AS_COMPLEX_PROPERTY) {
/* 200 */       nestedBean.setComplexProperty("parent", imdComplex.parentBean.getObj());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 205 */     Object nestedComplexProperty = imdComplex.getNestedComplexProperty();
/* 206 */     if (NoAutoStartUtil.shouldBeStarted(nestedComplexProperty)) {
/* 207 */       ((LifeCycle)nestedComplexProperty).start();
/*     */     }
/*     */     
/* 210 */     Object o = mic.peekObject();
/*     */     
/* 212 */     if (o != imdComplex.getNestedComplexProperty()) {
/* 213 */       addError("The object on the top the of the stack is not the component pushed earlier.");
/*     */     } else {
/* 215 */       mic.popObject();
/*     */       
/* 217 */       switch (imdComplex.aggregationType) {
/*     */         case AS_COMPLEX_PROPERTY:
/* 219 */           imdComplex.parentBean.setComplexProperty(model.getTag(), imdComplex.getNestedComplexProperty());
/*     */           return;
/*     */         
/*     */         case AS_COMPLEX_PROPERTY_COLLECTION:
/* 223 */           imdComplex.parentBean.addComplexProperty(model.getTag(), imdComplex.getNestedComplexProperty());
/*     */           return;
/*     */       } 
/* 226 */       addError("Unexpected aggregationType " + String.valueOf(imdComplex.aggregationType));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ImplicitModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */