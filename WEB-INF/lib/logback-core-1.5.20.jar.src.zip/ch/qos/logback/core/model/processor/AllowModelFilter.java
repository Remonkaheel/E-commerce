/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.FilterReply;
/*    */ 
/*    */ public class AllowModelFilter
/*    */   implements ModelFilter {
/*    */   final Class<? extends Model> allowedModelType;
/*    */   
/*    */   AllowModelFilter(Class<? extends Model> allowedType) {
/* 11 */     this.allowedModelType = allowedType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterReply decide(Model model) {
/* 17 */     if (model.getClass() == this.allowedModelType) {
/* 18 */       return FilterReply.ACCEPT;
/*    */     }
/*    */     
/* 21 */     return FilterReply.NEUTRAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\AllowModelFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */