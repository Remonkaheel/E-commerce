/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.FilterReply;
/*    */ 
/*    */ public class DenyModelFilter
/*    */   implements ModelFilter {
/*    */   final Class<? extends Model> deniedModelType;
/*    */   
/*    */   DenyModelFilter(Class<? extends Model> deniedModelType) {
/* 11 */     this.deniedModelType = deniedModelType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterReply decide(Model model) {
/* 17 */     if (model.getClass() == this.deniedModelType) {
/* 18 */       return FilterReply.DENY;
/*    */     }
/*    */     
/* 21 */     return FilterReply.NEUTRAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\DenyModelFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */