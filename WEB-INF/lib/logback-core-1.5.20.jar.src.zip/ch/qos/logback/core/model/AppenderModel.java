/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.processor.PhaseIndicator;
/*    */ import ch.qos.logback.core.model.processor.ProcessingPhase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PhaseIndicator(phase = ProcessingPhase.SECOND)
/*    */ public class AppenderModel
/*    */   extends NamedComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 1096234203123945432L;
/*    */   
/*    */   protected AppenderModel makeNewInstance() {
/* 26 */     return new AppenderModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\AppenderModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */