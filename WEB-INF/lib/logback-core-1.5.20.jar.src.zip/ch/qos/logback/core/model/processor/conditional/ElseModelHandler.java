/*    */ package ch.qos.logback.core.model.processor.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.ElseModel;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElseModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public ElseModelHandler(Context context) {
/* 28 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 32 */     return new ElseModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ElseModel> getSupportedModelClass() {
/* 37 */     return ElseModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 43 */     ElseModel elseModel = (ElseModel)model;
/*    */     
/* 45 */     Model parent = mic.peekModel();
/*    */     
/* 47 */     if (!(parent instanceof IfModel)) {
/* 48 */       addError("Unexpected type for parent model [" + String.valueOf(parent) + "]");
/* 49 */       elseModel.markAsSkipped();
/*    */       
/*    */       return;
/*    */     } 
/* 53 */     IfModel ifModel = (IfModel)parent;
/* 54 */     if (ifModel.getBranchState() != IfModel.BranchState.ELSE_BRANCH)
/* 55 */       elseModel.deepMarkAsSkipped(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\conditional\ElseModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */