/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.action.ActionUtil;
/*     */ import ch.qos.logback.core.model.DefineModel;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.spi.PropertyDefiner;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefineModelHandler
/*     */   extends ModelHandlerBase
/*     */ {
/*     */   boolean inError;
/*     */   PropertyDefiner definer;
/*     */   String propertyName;
/*     */   ActionUtil.Scope scope;
/*     */   
/*     */   public DefineModelHandler(Context context) {
/*  40 */     super(context);
/*     */   }
/*     */   
/*     */   public static DefineModelHandler makeInstance(Context context, ModelInterpretationContext ic) {
/*  44 */     return new DefineModelHandler(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<DefineModel> getSupportedModelClass() {
/*  49 */     return DefineModel.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(ModelInterpretationContext interpretationContext, Model model) throws ModelHandlerException {
/*  54 */     this.definer = null;
/*  55 */     this.inError = false;
/*  56 */     this.propertyName = null;
/*     */     
/*  58 */     DefineModel defineModel = (DefineModel)model;
/*     */     
/*  60 */     this.propertyName = defineModel.getName();
/*  61 */     String scopeStr = defineModel.getScopeStr();
/*     */     
/*  63 */     this.scope = ActionUtil.stringToScope(scopeStr);
/*     */     
/*  65 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(this.propertyName)) {
/*  66 */       addError("Missing property name for property definer. Near [" + model.getTag() + "] line " + model
/*  67 */           .getLineNumber());
/*  68 */       this.inError = true;
/*     */     } 
/*     */ 
/*     */     
/*  72 */     String className = defineModel.getClassName();
/*  73 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/*  74 */       addError("Missing class name for property definer. Near [" + model.getTag() + "] line " + model
/*  75 */           .getLineNumber());
/*  76 */       this.inError = true;
/*     */     } else {
/*  78 */       className = interpretationContext.getImport(className);
/*     */     } 
/*     */     
/*  81 */     if (this.inError) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  86 */       addInfo("About to instantiate property definer of type [" + className + "]");
/*  87 */       this.definer = (PropertyDefiner)OptionHelper.instantiateByClassName(className, PropertyDefiner.class, this.context);
/*  88 */       this.definer.setContext(this.context);
/*  89 */       interpretationContext.pushObject(this.definer);
/*  90 */     } catch (Exception oops) {
/*  91 */       this.inError = true;
/*  92 */       addError("Could not create an PropertyDefiner of type [" + className + "].", oops);
/*  93 */       throw new ModelHandlerException(oops);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postHandle(ModelInterpretationContext interpretationContext, Model model) throws ModelHandlerException {
/* 104 */     if (this.inError) {
/*     */       return;
/*     */     }
/*     */     
/* 108 */     Object o = interpretationContext.peekObject();
/*     */     
/* 110 */     if (o != this.definer) {
/* 111 */       addWarn("The object at the of the stack is not the property definer for property named [" + this.propertyName + "] pushed earlier.");
/*     */     } else {
/*     */       
/* 114 */       interpretationContext.popObject();
/* 115 */       if (this.definer instanceof LifeCycle) {
/* 116 */         ((LifeCycle)this.definer).start();
/*     */       }
/*     */ 
/*     */       
/* 120 */       String propertyValue = this.definer.getPropertyValue();
/* 121 */       if (propertyValue != null) {
/* 122 */         addInfo("Setting property " + this.propertyName + "=" + propertyValue + " in scope " + String.valueOf(this.scope));
/* 123 */         ActionUtil.setProperty(interpretationContext, this.propertyName, propertyValue, this.scope);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\DefineModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */