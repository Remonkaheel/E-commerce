/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ public class ProcessorException
/*    */   extends Exception {
/*    */   private static final long serialVersionUID = 2245242609539650480L;
/*    */   
/*    */   public ProcessorException() {}
/*    */   
/*    */   public ProcessorException(Throwable rootCause) {
/* 10 */     super(rootCause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ProcessorException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */