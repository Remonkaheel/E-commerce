/*    */ package ch.qos.logback.core.model.processor.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.model.conditional.ThenModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThenModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public ThenModelHandler(Context context) {
/* 30 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 34 */     return new ThenModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ThenModel> getSupportedModelClass() {
/* 39 */     return ThenModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 45 */     ThenModel thenModel = (ThenModel)model;
/*    */     
/* 47 */     if (mic.isModelStackEmpty()) {
/* 48 */       addError("Unexpected empty model stack. Have you omitted the <if> part?");
/* 49 */       thenModel.markAsSkipped();
/*    */       return;
/*    */     } 
/* 52 */     Model parent = mic.peekModel();
/*    */     
/* 54 */     if (!(parent instanceof IfModel)) {
/* 55 */       addError("Unexpected type for parent model [" + String.valueOf(parent) + "]");
/* 56 */       thenModel.markAsSkipped();
/*    */       
/*    */       return;
/*    */     } 
/* 60 */     IfModel ifModel = (IfModel)parent;
/* 61 */     if (ifModel.getBranchState() != IfModel.BranchState.IF_BRANCH)
/* 62 */       thenModel.deepMarkAsSkipped(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\conditional\ThenModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */