/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ public class ModelHandlerException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -6486247349285796564L;
/*    */   
/*    */   public ModelHandlerException() {}
/*    */   
/*    */   public ModelHandlerException(Throwable rootCause) {
/* 11 */     super(rootCause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ModelHandlerException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */