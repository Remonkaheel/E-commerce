/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.ImportModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ public class ImportModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public ImportModelHandler(Context context) {
/* 12 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 16 */     return new ImportModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ImportModel> getSupportedModelClass() {
/* 21 */     return ImportModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext intercon, Model model) throws ModelHandlerException {
/* 26 */     ImportModel importModel = (ImportModel)model;
/*    */     
/* 28 */     String className = importModel.getClassName();
/* 29 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 30 */       addWarn("Empty className not allowed");
/*    */       
/*    */       return;
/*    */     } 
/* 34 */     String stem = extractStem(className);
/* 35 */     if (stem == null) {
/* 36 */       addWarn("[" + className + "] could not be imported due to incorrect format");
/*    */       
/*    */       return;
/*    */     } 
/* 40 */     intercon.addImport(stem, className);
/*    */   }
/*    */ 
/*    */   
/*    */   String extractStem(String className) {
/* 45 */     if (className == null) {
/* 46 */       return null;
/*    */     }
/* 48 */     int lastDotIndex = className.lastIndexOf('.');
/* 49 */     if (lastDotIndex == -1)
/* 50 */       return null; 
/* 51 */     if (lastDotIndex + 1 == className.length())
/* 52 */       return null; 
/* 53 */     return className.substring(lastDotIndex + 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ImportModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */