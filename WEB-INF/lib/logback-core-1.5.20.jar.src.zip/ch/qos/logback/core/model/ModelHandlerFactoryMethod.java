package ch.qos.logback.core.model;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.model.processor.ModelHandlerBase;
import ch.qos.logback.core.model.processor.ModelInterpretationContext;

@FunctionalInterface
public interface ModelHandlerFactoryMethod {
  ModelHandlerBase make(Context paramContext, ModelInterpretationContext paramModelInterpretationContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ModelHandlerFactoryMethod.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */