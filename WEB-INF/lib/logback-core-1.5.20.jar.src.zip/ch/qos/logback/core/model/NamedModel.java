/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedModel
/*    */   extends Model
/*    */   implements INamedModel
/*    */ {
/*    */   private static final long serialVersionUID = 3549881638769570183L;
/*    */   String name;
/*    */   
/*    */   protected NamedModel makeNewInstance() {
/* 26 */     return new NamedModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 31 */     NamedModel actual = (NamedModel)that;
/* 32 */     super.mirror(actual);
/* 33 */     this.name = actual.name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 41 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 46 */     int prime = 31;
/* 47 */     int result = super.hashCode();
/* 48 */     result = 31 * result + Objects.hash(new Object[] { this.name });
/* 49 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 54 */     if (this == obj)
/* 55 */       return true; 
/* 56 */     if (!super.equals(obj))
/* 57 */       return false; 
/* 58 */     if (getClass() != obj.getClass())
/* 59 */       return false; 
/* 60 */     NamedModel other = (NamedModel)obj;
/* 61 */     return Objects.equals(this.name, other.name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\NamedModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */