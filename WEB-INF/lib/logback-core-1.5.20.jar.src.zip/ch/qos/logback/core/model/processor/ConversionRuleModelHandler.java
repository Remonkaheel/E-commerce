/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.ConversionRuleModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.pattern.DynamicConverter;
/*    */ import ch.qos.logback.core.pattern.color.ConverterSupplierByClassName;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversionRuleModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   private boolean inError;
/*    */   
/*    */   public ConversionRuleModelHandler(Context context) {
/* 34 */     super(context);
/*    */   }
/*    */   
/*    */   public static ConversionRuleModelHandler makeInstance(Context context, ModelInterpretationContext mic) {
/* 38 */     return new ConversionRuleModelHandler(context);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 44 */     ConversionRuleModel conversionRuleModel = (ConversionRuleModel)model;
/* 45 */     String converterClass = conversionRuleModel.getClassName();
/*    */     
/* 47 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(converterClass)) {
/* 48 */       addWarn("Missing className. This should have been caught earlier.");
/* 49 */       this.inError = true;
/*    */       return;
/*    */     } 
/* 52 */     converterClass = mic.getImport(converterClass);
/*    */ 
/*    */     
/* 55 */     String conversionWord = conversionRuleModel.getConversionWord();
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 60 */       Map<String, Supplier<DynamicConverter>> ruleRegistry = (Map<String, Supplier<DynamicConverter>>)this.context.getObject("PATTERN_RULE_REGISTRY_FOR_SUPPLIERS");
/* 61 */       if (ruleRegistry == null) {
/* 62 */         ruleRegistry = new HashMap<>();
/* 63 */         this.context.putObject("PATTERN_RULE_REGISTRY_FOR_SUPPLIERS", ruleRegistry);
/*    */       } 
/*    */       
/* 66 */       addInfo("registering conversion word " + conversionWord + " with class [" + converterClass + "]");
/* 67 */       ConverterSupplierByClassName converterSupplierByClassName = new ConverterSupplierByClassName(conversionWord, converterClass);
/* 68 */       converterSupplierByClassName.setContext(getContext());
/* 69 */       ruleRegistry.put(conversionWord, converterSupplierByClassName);
/* 70 */     } catch (Exception oops) {
/* 71 */       this.inError = true;
/* 72 */       String errorMsg = "Could not add conversion rule to PatternLayout.";
/* 73 */       addError(errorMsg);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ConversionRuleModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */