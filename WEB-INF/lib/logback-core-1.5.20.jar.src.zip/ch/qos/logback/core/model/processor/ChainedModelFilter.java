/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.FilterReply;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ChainedModelFilter
/*    */   implements ModelFilter
/*    */ {
/* 11 */   List<ModelFilter> modelFilters = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ChainedModelFilter newInstance() {
/* 17 */     return new ChainedModelFilter();
/*    */   }
/*    */   
/*    */   public ChainedModelFilter allow(Class<? extends Model> allowedType) {
/* 21 */     this.modelFilters.add(new AllowModelFilter(allowedType));
/* 22 */     return this;
/*    */   }
/*    */   
/*    */   public ChainedModelFilter deny(Class<? extends Model> allowedType) {
/* 26 */     this.modelFilters.add(new DenyModelFilter(allowedType));
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public ChainedModelFilter denyAll() {
/* 31 */     this.modelFilters.add(new DenyAllModelFilter());
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public ChainedModelFilter allowAll() {
/* 36 */     this.modelFilters.add(new AllowAllModelFilter());
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterReply decide(Model model) {
/* 43 */     for (ModelFilter modelFilter : this.modelFilters) {
/* 44 */       FilterReply reply = modelFilter.decide(model);
/*    */       
/* 46 */       switch (reply) {
/*    */         case ACCEPT:
/*    */         case DENY:
/* 49 */           return reply;
/*    */       } 
/*    */ 
/*    */     
/*    */     } 
/* 54 */     return FilterReply.NEUTRAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ChainedModelFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */