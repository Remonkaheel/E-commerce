/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.action.ActionUtil;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.TimestampModel;
/*    */ import ch.qos.logback.core.util.CachingDateFormatter;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimestampModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   boolean inError = false;
/*    */   
/*    */   public TimestampModelHandler(Context context) {
/* 31 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 35 */     return new TimestampModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<TimestampModel> getSupportedModelClass() {
/* 40 */     return TimestampModel.class;
/*    */   }
/*    */   
/*    */   public void handle(ModelInterpretationContext interpretationContext, Model model) {
/*    */     long timeReference;
/* 45 */     TimestampModel timestampModel = (TimestampModel)model;
/* 46 */     String keyStr = timestampModel.getKey();
/* 47 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(keyStr)) {
/* 48 */       addError("Attribute named [key] cannot be empty");
/* 49 */       this.inError = true;
/*    */     } 
/* 51 */     String datePatternStr = timestampModel.getDatePattern();
/* 52 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(datePatternStr)) {
/* 53 */       addError("Attribute named [datePattern] cannot be empty");
/* 54 */       this.inError = true;
/*    */     } 
/*    */     
/* 57 */     String timeReferenceStr = timestampModel.getTimeReference();
/*    */     
/* 59 */     if ("contextBirth".equalsIgnoreCase(timeReferenceStr)) {
/* 60 */       addInfo("Using context birth as time reference.");
/* 61 */       timeReference = this.context.getBirthTime();
/*    */     } else {
/* 63 */       timeReference = System.currentTimeMillis();
/* 64 */       addInfo("Using current interpretation time, i.e. now, as time reference.");
/*    */     } 
/*    */     
/* 67 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 70 */     String scopeStr = timestampModel.getScopeStr();
/* 71 */     ActionUtil.Scope scope = ActionUtil.stringToScope(scopeStr);
/*    */     
/* 73 */     CachingDateFormatter sdf = new CachingDateFormatter(datePatternStr);
/* 74 */     String val = sdf.format(timeReference);
/*    */     
/* 76 */     addInfo("Adding property to the context with key=\"" + keyStr + "\" and value=\"" + val + "\" to the " + String.valueOf(scope) + " scope");
/*    */     
/* 78 */     ActionUtil.setProperty(interpretationContext, keyStr, val, scope);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\TimestampModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */