/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimestampModel
/*    */   extends NamedModel
/*    */ {
/*    */   private static final long serialVersionUID = 2096655273673863306L;
/*    */   public static final String CONTEXT_BIRTH = "contextBirth";
/*    */   String datePattern;
/*    */   String timeReference;
/*    */   String scopeStr;
/*    */   
/*    */   protected TimestampModel makeNewInstance() {
/* 30 */     return new TimestampModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 35 */     TimestampModel actual = (TimestampModel)that;
/* 36 */     super.mirror(actual);
/* 37 */     this.datePattern = actual.datePattern;
/* 38 */     this.timeReference = actual.timeReference;
/* 39 */     this.scopeStr = actual.scopeStr;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 43 */     return getName();
/*    */   }
/*    */   
/*    */   public void setKey(String key) {
/* 47 */     setName(key);
/*    */   }
/*    */   
/*    */   public String getDatePattern() {
/* 51 */     return this.datePattern;
/*    */   }
/*    */   
/*    */   public void setDatePattern(String datePattern) {
/* 55 */     this.datePattern = datePattern;
/*    */   }
/*    */   
/*    */   public String getTimeReference() {
/* 59 */     return this.timeReference;
/*    */   }
/*    */   
/*    */   public void setTimeReference(String timeReference) {
/* 63 */     this.timeReference = timeReference;
/*    */   }
/*    */   
/*    */   public String getScopeStr() {
/* 67 */     return this.scopeStr;
/*    */   }
/*    */   
/*    */   public void setScopeStr(String scopeStr) {
/* 71 */     this.scopeStr = scopeStr;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 76 */     int prime = 31;
/* 77 */     int result = super.hashCode();
/* 78 */     result = 31 * result + Objects.hash(new Object[] { this.datePattern, this.scopeStr, this.timeReference });
/* 79 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 84 */     if (this == obj)
/* 85 */       return true; 
/* 86 */     if (!super.equals(obj))
/* 87 */       return false; 
/* 88 */     if (getClass() != obj.getClass())
/* 89 */       return false; 
/* 90 */     TimestampModel other = (TimestampModel)obj;
/* 91 */     return (Objects.equals(this.datePattern, other.datePattern) && Objects.equals(this.scopeStr, other.scopeStr) && 
/* 92 */       Objects.equals(this.timeReference, other.timeReference));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\TimestampModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */