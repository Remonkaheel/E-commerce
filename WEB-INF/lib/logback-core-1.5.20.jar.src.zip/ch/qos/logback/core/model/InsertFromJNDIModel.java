/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InsertFromJNDIModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = -7803377963650426197L;
/*    */   public static final String ENV_ENTRY_NAME_ATTR = "env-entry-name";
/*    */   public static final String AS_ATTR = "as";
/*    */   String as;
/*    */   String envEntryName;
/*    */   String scopeStr;
/*    */   
/*    */   protected InsertFromJNDIModel makeNewInstance() {
/* 31 */     return new InsertFromJNDIModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 36 */     InsertFromJNDIModel actual = (InsertFromJNDIModel)that;
/* 37 */     super.mirror(actual);
/* 38 */     this.as = actual.as;
/* 39 */     this.envEntryName = actual.envEntryName;
/* 40 */     this.scopeStr = actual.scopeStr;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getScopeStr() {
/* 45 */     return this.scopeStr;
/*    */   }
/*    */   
/*    */   public void setScopeStr(String scopeStr) {
/* 49 */     this.scopeStr = scopeStr;
/*    */   }
/*    */   
/*    */   public String getAs() {
/* 53 */     return this.as;
/*    */   }
/*    */   
/*    */   public void setAs(String as) {
/* 57 */     this.as = as;
/*    */   }
/*    */   
/*    */   public String getEnvEntryName() {
/* 61 */     return this.envEntryName;
/*    */   }
/*    */   
/*    */   public void setEnvEntryName(String envEntryName) {
/* 65 */     this.envEntryName = envEntryName;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     int prime = 31;
/* 71 */     int result = super.hashCode();
/* 72 */     result = 31 * result + Objects.hash(new Object[] { this.as, this.envEntryName, this.scopeStr });
/* 73 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 78 */     if (this == obj)
/* 79 */       return true; 
/* 80 */     if (!super.equals(obj))
/* 81 */       return false; 
/* 82 */     if (getClass() != obj.getClass())
/* 83 */       return false; 
/* 84 */     InsertFromJNDIModel other = (InsertFromJNDIModel)obj;
/* 85 */     return (Objects.equals(this.as, other.as) && Objects.equals(this.envEntryName, other.envEntryName) && 
/* 86 */       Objects.equals(this.scopeStr, other.scopeStr));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\InsertFromJNDIModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */