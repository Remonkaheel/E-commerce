/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ModelHandlerBase
/*    */   extends ContextAwareBase
/*    */ {
/*    */   public ModelHandlerBase(Context context) {
/* 23 */     setContext(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<? extends Model> getSupportedModelClass() {
/* 37 */     return Model.class;
/*    */   }
/*    */   
/*    */   protected boolean isSupportedModelType(Model model) {
/* 41 */     Class<? extends Model> modelClass = getSupportedModelClass();
/* 42 */     if (modelClass.isInstance(model)) {
/* 43 */       return true;
/*    */     }
/* 45 */     addError("This handler can only handle models of type [" + String.valueOf(modelClass) + "]");
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void handle(ModelInterpretationContext paramModelInterpretationContext, Model paramModel) throws ModelHandlerException;
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {}
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return getClass().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ModelHandlerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */