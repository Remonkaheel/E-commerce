/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.boolex.EventEvaluator;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.model.EventEvaluatorModel;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventEvaluatorModelHandler
/*     */   extends ModelHandlerBase
/*     */ {
/*     */   EventEvaluator<?> evaluator;
/*     */   boolean inError = false;
/*     */   
/*     */   public EventEvaluatorModelHandler(Context context) {
/*  22 */     super(context);
/*     */   }
/*     */   
/*     */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/*  26 */     return new EventEvaluatorModelHandler(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<EventEvaluatorModel> getSupportedModelClass() {
/*  31 */     return EventEvaluatorModel.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(ModelInterpretationContext intercon, Model model) throws ModelHandlerException {
/*  36 */     EventEvaluatorModel eem = (EventEvaluatorModel)model;
/*     */     
/*  38 */     String className = eem.getClassName();
/*  39 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/*  40 */       String defaultClassName = defaultClassName(intercon, eem);
/*  41 */       if (OptionHelper.isNullOrEmptyOrAllSpaces(defaultClassName)) {
/*  42 */         this.inError = true;
/*  43 */         addError("Mandatory \"class\" attribute missing for <evaluator>");
/*  44 */         addError("No default classname could be found.");
/*     */         return;
/*     */       } 
/*  47 */       addInfo("Assuming default evaluator class [" + defaultClassName + "]");
/*  48 */       className = defaultClassName;
/*     */     } else {
/*     */       
/*  51 */       className = intercon.getImport(className);
/*     */     } 
/*     */     
/*  54 */     String evaluatorName = intercon.subst(eem.getName());
/*     */     try {
/*  56 */       this.evaluator = (EventEvaluator)OptionHelper.instantiateByClassName(className, EventEvaluator.class, this.context);
/*     */       
/*  58 */       this.evaluator.setContext(this.context);
/*  59 */       this.evaluator.setName(evaluatorName);
/*  60 */       intercon.pushObject(this.evaluator);
/*     */     }
/*  62 */     catch (Exception oops) {
/*  63 */       this.inError = true;
/*  64 */       addError("Could not create evaluator of type " + className + "].", oops);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String defaultClassName(ModelInterpretationContext mic, EventEvaluatorModel model) {
/*  70 */     DefaultNestedComponentRegistry registry = mic.getDefaultNestedComponentRegistry();
/*  71 */     return registry.findDefaultComponentTypeByTag(model.getTag());
/*     */   }
/*     */ 
/*     */   
/*     */   public void postHandle(ModelInterpretationContext intercon, Model model) throws ModelHandlerException {
/*  76 */     if (this.inError) {
/*     */       return;
/*     */     }
/*     */     
/*  80 */     if (this.evaluator instanceof ch.qos.logback.core.spi.LifeCycle) {
/*  81 */       this.evaluator.start();
/*  82 */       addInfo("Starting evaluator named [" + this.evaluator.getName() + "]");
/*     */     } 
/*     */     
/*  85 */     Object o = intercon.peekObject();
/*     */     
/*  87 */     if (o != this.evaluator) {
/*  88 */       addWarn("The object on the top the of the stack is not the evaluator pushed earlier.");
/*     */     } else {
/*  90 */       intercon.popObject();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  95 */         Map<String, EventEvaluator<?>> evaluatorMap = (Map<String, EventEvaluator<?>>)this.context.getObject("EVALUATOR_MAP");
/*  96 */         if (evaluatorMap == null) {
/*  97 */           addError("Could not find EvaluatorMap");
/*     */         } else {
/*  99 */           evaluatorMap.put(this.evaluator.getName(), this.evaluator);
/*     */         } 
/* 101 */       } catch (Exception ex) {
/* 102 */         addError("Could not set evaluator named [" + String.valueOf(this.evaluator) + "].", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\EventEvaluatorModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */