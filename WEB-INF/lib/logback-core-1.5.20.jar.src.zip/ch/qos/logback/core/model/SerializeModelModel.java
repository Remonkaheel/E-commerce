/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializeModelModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 16385651235687L;
/*    */   String file;
/*    */   
/*    */   protected SerializeModelModel makeNewInstance() {
/* 27 */     return new SerializeModelModel();
/*    */   }
/*    */   
/*    */   public String getFile() {
/* 31 */     return this.file;
/*    */   }
/*    */   
/*    */   public void setFile(String file) {
/* 35 */     this.file = file;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o)
/* 41 */       return true; 
/* 42 */     if (o == null || getClass() != o.getClass())
/* 43 */       return false; 
/* 44 */     if (!super.equals(o))
/* 45 */       return false; 
/* 46 */     SerializeModelModel that = (SerializeModelModel)o;
/* 47 */     return Objects.equals(this.file, that.file);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Objects.hash(new Object[] { Integer.valueOf(super.hashCode()), this.file });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\SerializeModelModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */