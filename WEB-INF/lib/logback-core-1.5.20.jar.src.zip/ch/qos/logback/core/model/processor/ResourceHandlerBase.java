/*     */ package ch.qos.logback.core.model.processor;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.model.ResourceModel;
/*     */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceHandlerBase
/*     */   extends ModelHandlerBase
/*     */ {
/*     */   protected String attributeInUse;
/*     */   protected boolean optional;
/*     */   
/*     */   protected ResourceHandlerBase(Context context) {
/*  36 */     super(context);
/*     */   }
/*     */   
/*     */   protected InputStream openURL(URL url) {
/*     */     try {
/*  41 */       return url.openStream();
/*  42 */     } catch (IOException e) {
/*  43 */       warnIfRequired("Failed to open [" + url.toString() + "]");
/*  44 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean checkAttributes(ResourceModel resourceModel) {
/*  49 */     String fileAttribute = resourceModel.getFile();
/*  50 */     String urlAttribute = resourceModel.getUrl();
/*  51 */     String resourceAttribute = resourceModel.getResource();
/*     */     
/*  53 */     int count = 0;
/*     */     
/*  55 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(fileAttribute)) {
/*  56 */       count++;
/*     */     }
/*  58 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(urlAttribute)) {
/*  59 */       count++;
/*     */     }
/*  61 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(resourceAttribute)) {
/*  62 */       count++;
/*     */     }
/*     */     
/*  65 */     if (count == 0) {
/*  66 */       addError("One of \"path\", \"resource\" or \"url\" attributes must be set.");
/*  67 */       return false;
/*  68 */     }  if (count > 1) {
/*  69 */       addError("Only one of \"file\", \"url\" or \"resource\" attributes should be set.");
/*  70 */       return false;
/*  71 */     }  if (count == 1) {
/*  72 */       return true;
/*     */     }
/*  74 */     throw new IllegalStateException("Count value [" + count + "] is not expected");
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getAttribureInUse() {
/*  79 */     return this.attributeInUse;
/*     */   }
/*     */   
/*     */   protected URL getInputURL(ContextAwarePropertyContainer contextAwarePropertyContainer, ResourceModel resourceModel) {
/*  83 */     String fileAttribute = resourceModel.getFile();
/*  84 */     String urlAttribute = resourceModel.getUrl();
/*  85 */     String resourceAttribute = resourceModel.getResource();
/*     */     
/*  87 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(fileAttribute)) {
/*  88 */       this.attributeInUse = contextAwarePropertyContainer.subst(fileAttribute);
/*  89 */       return filePathAsURL(this.attributeInUse);
/*     */     } 
/*     */     
/*  92 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(urlAttribute)) {
/*  93 */       this.attributeInUse = contextAwarePropertyContainer.subst(urlAttribute);
/*  94 */       return attributeToURL(this.attributeInUse);
/*     */     } 
/*     */     
/*  97 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(resourceAttribute)) {
/*  98 */       this.attributeInUse = contextAwarePropertyContainer.subst(resourceAttribute);
/*  99 */       return resourceAsURL(this.attributeInUse);
/*     */     } 
/*     */     
/* 102 */     throw new IllegalStateException("A URL stream should have been returned at this stage");
/*     */   }
/*     */ 
/*     */   
/*     */   protected URL filePathAsURL(String path) {
/* 107 */     URI uri = (new File(path)).toURI();
/*     */     try {
/* 109 */       return uri.toURL();
/* 110 */     } catch (MalformedURLException e) {
/*     */       
/* 112 */       e.printStackTrace();
/* 113 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected URL attributeToURL(String urlAttribute) {
/*     */     try {
/* 119 */       return new URL(urlAttribute);
/* 120 */     } catch (MalformedURLException mue) {
/* 121 */       String errMsg = "URL [" + urlAttribute + "] is not well formed.";
/* 122 */       addError(errMsg, mue);
/* 123 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected URL resourceAsURL(String resourceAttribute) {
/* 128 */     URL url = Loader.getResourceBySelfClassLoader(resourceAttribute);
/* 129 */     if (url == null) {
/* 130 */       warnIfRequired("Could not find resource corresponding to [" + resourceAttribute + "]");
/* 131 */       return null;
/*     */     } 
/* 133 */     return url;
/*     */   }
/*     */   
/*     */   protected void warnIfRequired(String msg) {
/* 137 */     if (!this.optional)
/* 138 */       addWarn(msg); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ResourceHandlerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */