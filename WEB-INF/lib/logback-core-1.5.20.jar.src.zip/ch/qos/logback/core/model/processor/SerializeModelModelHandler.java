/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.SerializeModelModel;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializeModelModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public SerializeModelModelHandler(Context context) {
/* 33 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext mic) {
/* 37 */     return new SerializeModelModelHandler(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext modelInterpretationContext, Model model) throws ModelHandlerException {
/* 45 */     Object configuratorHint = modelInterpretationContext.getConfiguratorHint();
/*    */     
/* 47 */     if (configuratorHint != null && configuratorHint.getClass().getName().equals("ch.qos.logback.classic.joran.SerializedModelConfigurator")) {
/* 48 */       addInfo("Skipping model serialization as calling configurator is already model based.");
/*    */       
/*    */       return;
/*    */     } 
/* 52 */     if (!(model instanceof SerializeModelModel)) {
/* 53 */       addWarn("Model parameter is not of type SerializeModelModel. Skipping serialization of model structure");
/*    */       
/*    */       return;
/*    */     } 
/* 57 */     SerializeModelModel serializeModelModel = (SerializeModelModel)model;
/*    */     
/* 59 */     Model topModel = modelInterpretationContext.getTopModel();
/*    */     
/* 61 */     if (topModel == null) {
/* 62 */       addWarn("Could not find top most model. Skipping serialization of model structure.");
/*    */       
/*    */       return;
/*    */     } 
/* 66 */     String fileStr = serializeModelModel.getFile();
/* 67 */     if (fileStr == null) {
/* 68 */       DateTimeFormatter dft = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HHmm");
/* 69 */       Instant now = Instant.now();
/* 70 */       String timestamp = dft.format(now);
/* 71 */       fileStr = "logback-" + timestamp + ".scmo";
/* 72 */       addInfo("For model serialization, using default file destination [" + fileStr + "]");
/*    */     } else {
/* 74 */       fileStr = modelInterpretationContext.subst(fileStr);
/*    */     } 
/*    */     
/* 77 */     writeModel(fileStr, topModel);
/*    */   }
/*    */ 
/*    */   
/*    */   private void writeModel(String fileStr, Model firstModel) {
/* 82 */     addInfo("Serializing model to file [" + fileStr + "]");
/*    */     
/* 84 */     try { FileOutputStream fos = new FileOutputStream(fileStr); 
/* 85 */       try { ObjectOutputStream oos = new ObjectOutputStream(fos);
/* 86 */         oos.writeObject(firstModel);
/* 87 */         oos.flush();
/* 88 */         oos.close();
/* 89 */         fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 90 */     { addError("IO failure while serializing Model [" + fileStr + "]"); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\SerializeModelModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */