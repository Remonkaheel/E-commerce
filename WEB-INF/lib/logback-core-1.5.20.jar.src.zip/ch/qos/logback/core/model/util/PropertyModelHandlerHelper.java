/*     */ package ch.qos.logback.core.model.util;
/*     */ 
/*     */ import ch.qos.logback.core.joran.action.ActionUtil;
/*     */ import ch.qos.logback.core.model.PropertyModel;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*     */ import ch.qos.logback.core.util.ContextUtil;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyModelHandlerHelper
/*     */   extends ContextAwareBase
/*     */ {
/*     */   public static final String HANDLE_PROPERTY_MODEL_METHOD_NAME = "handlePropertyModel";
/*     */   
/*     */   public PropertyModelHandlerHelper(ContextAware declaredOrigin) {
/*  45 */     super(declaredOrigin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlePropertyModel(ContextAwarePropertyContainer capcm, String nameStr, String valueStr, String fileStr, String resourceStr, String scopeStr) {
/*  62 */     PropertyModel propertyModel = new PropertyModel();
/*  63 */     propertyModel.setName(nameStr);
/*  64 */     propertyModel.setValue(valueStr);
/*  65 */     propertyModel.setFile(fileStr);
/*  66 */     propertyModel.setResource(resourceStr);
/*     */     
/*  68 */     propertyModel.setScopeStr(scopeStr);
/*     */     
/*  70 */     handlePropertyModel(capcm, propertyModel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlePropertyModel(ContextAwarePropertyContainer capc, PropertyModel propertyModel) {
/*  81 */     ActionUtil.Scope scope = ActionUtil.stringToScope(propertyModel.getScopeStr());
/*     */     
/*  83 */     if (checkFileAttributeSanity(propertyModel)) {
/*  84 */       String file = propertyModel.getFile();
/*  85 */       file = capc.subst(file); 
/*  86 */       try { FileInputStream istream = new FileInputStream(file); 
/*  87 */         try { loadAndSetProperties(capc, istream, scope);
/*  88 */           istream.close(); } catch (Throwable throwable) { try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (FileNotFoundException e)
/*  89 */       { addError("Could not find properties file [" + file + "]."); }
/*  90 */       catch (IOException|IllegalArgumentException e1)
/*     */       
/*  92 */       { addError("Could not read properties file [" + file + "].", e1); }
/*     */     
/*  94 */     } else if (checkResourceAttributeSanity(propertyModel)) {
/*  95 */       String resource = propertyModel.getResource();
/*  96 */       resource = capc.subst(resource);
/*  97 */       URL resourceURL = Loader.getResourceBySelfClassLoader(resource);
/*  98 */       if (resourceURL == null)
/*  99 */       { addError("Could not find resource [" + resource + "]."); }
/*     */       else { 
/* 101 */         try { InputStream istream = resourceURL.openStream(); 
/* 102 */           try { loadAndSetProperties(capc, istream, scope);
/* 103 */             if (istream != null) istream.close();  } catch (Throwable throwable) { if (istream != null) try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 104 */         { addError("Could not read resource file [" + resource + "].", e); }
/*     */          }
/*     */     
/* 107 */     } else if (checkValueNameAttributesSanity(propertyModel)) {
/*     */ 
/*     */       
/* 110 */       String value = propertyModel.getValue();
/*     */ 
/*     */       
/* 113 */       value = value.trim();
/* 114 */       value = capc.subst(value);
/* 115 */       ActionUtil.setProperty(capc, propertyModel.getName(), value, scope);
/*     */     } else {
/*     */       
/* 118 */       addError("In <property> element, either the \"file\" attribute alone, or the \"resource\" element alone, or both the \"name\" and \"value\" attributes must be set.");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean checkFileAttributeSanity(PropertyModel propertyModel) {
/* 123 */     String file = propertyModel.getFile();
/* 124 */     String name = propertyModel.getName();
/* 125 */     String value = propertyModel.getValue();
/* 126 */     String resource = propertyModel.getResource();
/*     */     
/* 128 */     return (!OptionHelper.isNullOrEmptyOrAllSpaces(file) && OptionHelper.isNullOrEmptyOrAllSpaces(name) && 
/* 129 */       OptionHelper.isNullOrEmptyOrAllSpaces(value) && OptionHelper.isNullOrEmptyOrAllSpaces(resource));
/*     */   }
/*     */   
/*     */   public static boolean checkResourceAttributeSanity(PropertyModel propertyModel) {
/* 133 */     String file = propertyModel.getFile();
/* 134 */     String name = propertyModel.getName();
/* 135 */     String value = propertyModel.getValue();
/* 136 */     String resource = propertyModel.getResource();
/*     */     
/* 138 */     return (!OptionHelper.isNullOrEmptyOrAllSpaces(resource) && OptionHelper.isNullOrEmptyOrAllSpaces(name) && 
/* 139 */       OptionHelper.isNullOrEmptyOrAllSpaces(value) && OptionHelper.isNullOrEmptyOrAllSpaces(file));
/*     */   }
/*     */   
/*     */   public static boolean checkValueNameAttributesSanity(PropertyModel propertyModel) {
/* 143 */     String file = propertyModel.getFile();
/* 144 */     String name = propertyModel.getName();
/* 145 */     String value = propertyModel.getValue();
/* 146 */     String resource = propertyModel.getResource();
/* 147 */     return (!OptionHelper.isNullOrEmptyOrAllSpaces(name) && !OptionHelper.isNullOrEmptyOrAllSpaces(value) && 
/* 148 */       OptionHelper.isNullOrEmptyOrAllSpaces(file) && OptionHelper.isNullOrEmptyOrAllSpaces(resource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setProperty(ContextAwarePropertyContainer capc, String key, String value, ActionUtil.Scope scope) {
/* 156 */     switch (scope) {
/*     */       case LOCAL:
/* 158 */         capc.addSubstitutionProperty(key, value);
/*     */         break;
/*     */       case CONTEXT:
/* 161 */         capc.getContext().putProperty(key, value);
/*     */         break;
/*     */       case SYSTEM:
/* 164 */         OptionHelper.setSystemProperty((ContextAware)capc, key, value);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setProperties(ContextAwarePropertyContainer capc, Properties props, ActionUtil.Scope scope) {
/*     */     ContextUtil cu;
/* 172 */     switch (scope) {
/*     */       case LOCAL:
/* 174 */         capc.addSubstitutionProperties(props);
/*     */         break;
/*     */       case CONTEXT:
/* 177 */         cu = new ContextUtil(capc.getContext());
/* 178 */         cu.addProperties(props);
/*     */         break;
/*     */       case SYSTEM:
/* 181 */         OptionHelper.setSystemProperties((ContextAware)capc, props);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void loadAndSetProperties(ContextAwarePropertyContainer capc, InputStream istream, ActionUtil.Scope scope) throws IOException {
/* 187 */     Properties props = new Properties();
/* 188 */     props.load(istream);
/* 189 */     setProperties(capc, props, scope);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\mode\\util\PropertyModelHandlerHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */