package ch.qos.logback.core.model;

public class ModelConstants {
  public static final String DEBUG_SYSTEM_PROPERTY_KEY = "logback.debug";
  
  public static final String NULL_STR = "null";
  
  public static final String INVALID_ATTRIBUTES = "In <property> element, either the \"file\" attribute alone, or the \"resource\" element alone, or both the \"name\" and \"value\" attributes must be set.";
  
  public static final String PARENT_PROPPERTY_KEY = "parent";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ModelConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */