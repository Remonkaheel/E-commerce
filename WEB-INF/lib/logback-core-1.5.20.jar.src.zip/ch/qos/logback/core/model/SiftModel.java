/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SiftModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 6456117795231083546L;
/*    */   
/*    */   protected SiftModel makeNewInstance() {
/* 22 */     return new SiftModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\SiftModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */