/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Appender;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.AppenderRefModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.AppenderAttachable;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AppenderRefModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   boolean inError = false;
/*    */   
/*    */   public AppenderRefModelHandler(Context context) {
/* 16 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 20 */     return new AppenderRefModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<? extends AppenderRefModel> getSupportedModelClass() {
/* 25 */     return AppenderRefModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext interpContext, Model model) throws ModelHandlerException {
/* 31 */     Object o = interpContext.peekObject();
/*    */     
/* 33 */     if (!(o instanceof AppenderAttachable)) {
/* 34 */       this.inError = true;
/*    */       
/* 36 */       String errMsg = "Could not find an AppenderAttachable at the top of execution stack. Near " + model.idString();
/* 37 */       addError(errMsg);
/*    */       
/*    */       return;
/*    */     } 
/* 41 */     AppenderRefModel appenderRefModel = (AppenderRefModel)model;
/* 42 */     AppenderAttachable<?> appenderAttachable = (AppenderAttachable)o;
/*    */     
/* 44 */     attachRefencedAppenders(interpContext, appenderRefModel, appenderAttachable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void attachRefencedAppenders(ModelInterpretationContext mic, AppenderRefModel appenderRefModel, AppenderAttachable<?> appenderAttachable) {
/* 51 */     String appenderName = mic.subst(appenderRefModel.getRef());
/*    */     
/* 53 */     Map<String, Appender> appenderBag = (Map<String, Appender>)mic.getObjectMap().get("APPENDER_BAG");
/*    */     
/* 55 */     Appender appender = appenderBag.get(appenderName);
/* 56 */     if (appender == null) {
/* 57 */       addError("Failed to find appender named [" + appenderName + "]");
/*    */     } else {
/* 59 */       addInfo("Attaching appender named [" + appenderName + "] to " + String.valueOf(appenderAttachable));
/* 60 */       appenderAttachable.addAppender(appender);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\AppenderRefModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */