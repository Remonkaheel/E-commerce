/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.SequenceNumberGeneratorModel;
/*    */ import ch.qos.logback.core.spi.SequenceNumberGenerator;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceNumberGeneratorModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   SequenceNumberGenerator sequenceNumberGenerator;
/*    */   private boolean inError;
/*    */   
/*    */   public SequenceNumberGeneratorModelHandler(Context context) {
/* 29 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 33 */     return new SequenceNumberGeneratorModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<SequenceNumberGeneratorModel> getSupportedModelClass() {
/* 38 */     return SequenceNumberGeneratorModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 44 */     SequenceNumberGeneratorModel sequenceNumberGeneratorModel = (SequenceNumberGeneratorModel)model;
/* 45 */     String className = sequenceNumberGeneratorModel.getClassName();
/* 46 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 47 */       addWarn("Missing className. This should have been caught earlier.");
/* 48 */       this.inError = true;
/*    */       return;
/*    */     } 
/* 51 */     className = mic.getImport(className);
/*    */ 
/*    */     
/*    */     try {
/* 55 */       addInfo("About to instantiate SequenceNumberGenerator of type [" + className + "]");
/*    */       
/* 57 */       this.sequenceNumberGenerator = (SequenceNumberGenerator)OptionHelper.instantiateByClassName(className, SequenceNumberGenerator.class, this.context);
/*    */       
/* 59 */       this.sequenceNumberGenerator.setContext(this.context);
/*    */       
/* 61 */       mic.pushObject(this.sequenceNumberGenerator);
/* 62 */     } catch (Exception e) {
/* 63 */       this.inError = true;
/* 64 */       addError("Could not create a SequenceNumberGenerator of type [" + className + "].", e);
/* 65 */       throw new ModelHandlerException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 70 */     if (this.inError) {
/*    */       return;
/*    */     }
/*    */     
/* 74 */     Object o = mic.peekObject();
/* 75 */     if (o != this.sequenceNumberGenerator) {
/* 76 */       addWarn("The object at the of the stack is not the hook pushed earlier.");
/*    */     } else {
/* 78 */       mic.popObject();
/*    */       
/* 80 */       addInfo("Registering " + String.valueOf(o) + " with context.");
/* 81 */       this.context.setSequenceNumberGenerator(this.sequenceNumberGenerator);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\SequenceNumberGeneratorModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */