/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.StatusListenerModel;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.status.StatusListener;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ public class StatusListenerModelHandler
/*    */   extends ModelHandlerBase {
/*    */   boolean inError = false;
/* 14 */   Boolean effectivelyAdded = null;
/* 15 */   StatusListener statusListener = null;
/*    */   
/*    */   public StatusListenerModelHandler(Context context) {
/* 18 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 22 */     return new StatusListenerModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<StatusListenerModel> getSupportedModelClass() {
/* 27 */     return StatusListenerModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext ic, Model model) throws ModelHandlerException {
/* 33 */     StatusListenerModel slModel = (StatusListenerModel)model;
/*    */     
/* 35 */     String className = slModel.getClassName();
/*    */     
/* 37 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 38 */       addError("Empty class name for StatusListener");
/* 39 */       this.inError = true;
/*    */       return;
/*    */     } 
/* 42 */     className = ic.getImport(className);
/*    */ 
/*    */     
/*    */     try {
/* 46 */       this.statusListener = (StatusListener)OptionHelper.instantiateByClassName(className, StatusListener.class, this.context);
/*    */       
/* 48 */       this.effectivelyAdded = Boolean.valueOf(ic.getContext().getStatusManager().add(this.statusListener));
/* 49 */       if (this.statusListener instanceof ContextAware) {
/* 50 */         ((ContextAware)this.statusListener).setContext(this.context);
/*    */       }
/* 52 */       addInfo("Added status listener of type [" + slModel.getClassName() + "]");
/* 53 */       ic.pushObject(this.statusListener);
/* 54 */     } catch (Exception e) {
/* 55 */       this.inError = true;
/* 56 */       addError("Could not create an StatusListener of type [" + slModel.getClassName() + "].", e);
/* 57 */       throw new ModelHandlerException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model m) {
/* 63 */     if (this.inError) {
/*    */       return;
/*    */     }
/*    */     
/* 67 */     if (isEffectivelyAdded() && this.statusListener instanceof LifeCycle) {
/* 68 */       ((LifeCycle)this.statusListener).start();
/*    */     }
/* 70 */     Object o = mic.peekObject();
/* 71 */     if (o != this.statusListener) {
/* 72 */       addWarn("The object at the of the stack is not the statusListener pushed earlier.");
/*    */     } else {
/* 74 */       mic.popObject();
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean isEffectivelyAdded() {
/* 79 */     if (this.effectivelyAdded == null)
/* 80 */       return false; 
/* 81 */     return this.effectivelyAdded.booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\StatusListenerModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */