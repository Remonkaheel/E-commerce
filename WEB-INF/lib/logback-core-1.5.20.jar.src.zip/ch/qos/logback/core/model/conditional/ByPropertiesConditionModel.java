/*    */ package ch.qos.logback.core.model.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.model.ComponentModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByPropertiesConditionModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = -1788292310734560420L;
/*    */   
/*    */   protected ByPropertiesConditionModel makeNewInstance() {
/* 25 */     return new ByPropertiesConditionModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\conditional\ByPropertiesConditionModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */