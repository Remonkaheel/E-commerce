/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   String className;
/*    */   
/*    */   protected ImportModel makeNewInstance() {
/* 25 */     return new ImportModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 30 */     ImportModel actual = (ImportModel)that;
/* 31 */     super.mirror(actual);
/* 32 */     this.className = actual.className;
/*    */   }
/*    */   
/*    */   public String getClassName() {
/* 36 */     return this.className;
/*    */   }
/*    */   
/*    */   public void setClassName(String className) {
/* 40 */     this.className = className;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ImportModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */