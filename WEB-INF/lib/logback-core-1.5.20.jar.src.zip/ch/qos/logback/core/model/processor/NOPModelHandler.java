/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NOPModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public NOPModelHandler(Context context) {
/* 22 */     super(context);
/*    */   }
/*    */   
/*    */   public static NOPModelHandler makeInstance(Context context, ModelInterpretationContext ic) {
/* 26 */     return new NOPModelHandler(context);
/*    */   }
/*    */   
/*    */   public void handle(ModelInterpretationContext interpretationContext, Model model) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\NOPModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */