/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.PropertyModel;
/*    */ import ch.qos.logback.core.model.util.PropertyModelHandlerHelper;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public PropertyModelHandler(Context context) {
/* 21 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 25 */     return new PropertyModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<PropertyModel> getSupportedModelClass() {
/* 30 */     return PropertyModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) {
/* 36 */     PropertyModel propertyModel = (PropertyModel)model;
/* 37 */     PropertyModelHandlerHelper propertyModelHandlerHelper = new PropertyModelHandlerHelper((ContextAware)this);
/* 38 */     propertyModelHandlerHelper.setContext(this.context);
/* 39 */     propertyModelHandlerHelper.handlePropertyModel(mic, propertyModel);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\PropertyModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */