/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventEvaluatorModel
/*    */   extends NamedComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 4600344286104093766L;
/*    */   
/*    */   protected EventEvaluatorModel makeNewInstance() {
/* 22 */     return new EventEvaluatorModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\EventEvaluatorModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */