/*    */ package ch.qos.logback.core.model.util;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*    */ import ch.qos.logback.core.spi.PropertyContainer;
/*    */ import ch.qos.logback.core.spi.ScanException;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableSubstitutionsHelper
/*    */   extends ContextAwareBase
/*    */   implements ContextAwarePropertyContainer
/*    */ {
/*    */   protected Map<String, String> propertiesMap;
/*    */   
/*    */   public VariableSubstitutionsHelper(Context context) {
/* 36 */     setContext(context);
/* 37 */     this.propertiesMap = new HashMap<>();
/*    */   }
/*    */   
/*    */   public VariableSubstitutionsHelper(Context context, Map<String, String> otherMap) {
/* 41 */     setContext(context);
/* 42 */     this.propertiesMap = new HashMap<>(otherMap);
/*    */   }
/*    */ 
/*    */   
/*    */   public String subst(String ref) {
/* 47 */     if (ref == null) {
/* 48 */       return null;
/*    */     }
/*    */     
/*    */     try {
/* 52 */       return OptionHelper.substVars(ref, (PropertyContainer)this, (PropertyContainer)this.context);
/* 53 */     } catch (ScanException|IllegalArgumentException e) {
/* 54 */       addError("Problem while parsing [" + ref + "]", e);
/* 55 */       return ref;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addSubstitutionProperty(String key, String value) {
/* 66 */     if (key == null || value == null) {
/*    */       return;
/*    */     }
/*    */     
/* 70 */     value = value.trim();
/* 71 */     this.propertiesMap.put(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProperty(String key) {
/* 76 */     return this.propertiesMap.get(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getCopyOfPropertyMap() {
/* 81 */     return new HashMap<>(this.propertiesMap);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\mode\\util\VariableSubstitutionsHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */