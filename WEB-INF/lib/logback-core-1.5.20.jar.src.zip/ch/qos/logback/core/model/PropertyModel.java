/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyModel
/*    */   extends NamedModel
/*    */ {
/*    */   private static final long serialVersionUID = 1494176979175092052L;
/*    */   String value;
/*    */   String scopeStr;
/*    */   String file;
/*    */   String resource;
/*    */   
/*    */   protected PropertyModel makeNewInstance() {
/* 17 */     return new PropertyModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 22 */     PropertyModel actual = (PropertyModel)that;
/* 23 */     super.mirror(actual);
/* 24 */     this.value = actual.value;
/* 25 */     this.scopeStr = actual.scopeStr;
/* 26 */     this.file = actual.file;
/* 27 */     this.resource = actual.resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 32 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 36 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getScopeStr() {
/* 40 */     return this.scopeStr;
/*    */   }
/*    */   
/*    */   public void setScopeStr(String scopeStr) {
/* 44 */     this.scopeStr = scopeStr;
/*    */   }
/*    */   
/*    */   public String getFile() {
/* 48 */     return this.file;
/*    */   }
/*    */   
/*    */   public void setFile(String file) {
/* 52 */     this.file = file;
/*    */   }
/*    */   
/*    */   public String getResource() {
/* 56 */     return this.resource;
/*    */   }
/*    */   
/*    */   public void setResource(String resource) {
/* 60 */     this.resource = resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 65 */     int prime = 31;
/* 66 */     int result = super.hashCode();
/* 67 */     result = 31 * result + Objects.hash(new Object[] { this.file, this.resource, this.scopeStr, this.value });
/* 68 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 73 */     if (this == obj)
/* 74 */       return true; 
/* 75 */     if (!super.equals(obj))
/* 76 */       return false; 
/* 77 */     if (getClass() != obj.getClass())
/* 78 */       return false; 
/* 79 */     PropertyModel other = (PropertyModel)obj;
/* 80 */     return (Objects.equals(this.file, other.file) && Objects.equals(this.resource, other.resource) && 
/* 81 */       Objects.equals(this.scopeStr, other.scopeStr) && Objects.equals(this.value, other.value));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\PropertyModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */