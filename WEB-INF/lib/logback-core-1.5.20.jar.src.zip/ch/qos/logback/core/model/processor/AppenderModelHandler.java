/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Appender;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.AppenderModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.AppenderAttachable;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppenderModelHandler<E>
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   Appender<E> appender;
/*    */   private boolean inError = false;
/*    */   private boolean skipped = false;
/*    */   AppenderAttachable<E> appenderAttachable;
/*    */   
/*    */   public AppenderModelHandler(Context context) {
/* 34 */     super(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext mic) {
/* 39 */     return new AppenderModelHandler(context);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 45 */     this.appender = null;
/* 46 */     this.inError = false;
/*    */     
/* 48 */     AppenderModel appenderModel = (AppenderModel)model;
/*    */     
/* 50 */     String appenderName = mic.subst(appenderModel.getName());
/*    */     
/* 52 */     if (!mic.hasDependers(appenderName)) {
/* 53 */       addWarn("Appender named [" + appenderName + "] not referenced. Skipping further processing.");
/* 54 */       this.skipped = true;
/* 55 */       appenderModel.markAsSkipped();
/*    */       
/*    */       return;
/*    */     } 
/* 59 */     addInfo("Processing appender named [" + appenderName + "]");
/*    */     
/* 61 */     String originalClassName = appenderModel.getClassName();
/* 62 */     String className = mic.getImport(originalClassName);
/*    */     
/*    */     try {
/* 65 */       addInfo("About to instantiate appender of type [" + className + "]");
/*    */       
/* 67 */       this.appender = (Appender<E>)OptionHelper.instantiateByClassName(className, Appender.class, this.context);
/*    */       
/* 69 */       this.appender.setContext(this.context);
/* 70 */       this.appender.setName(appenderName);
/* 71 */       mic.pushObject(this.appender);
/* 72 */     } catch (Exception oops) {
/* 73 */       this.inError = true;
/* 74 */       addError("Could not create an Appender of type [" + className + "].", oops);
/* 75 */       throw new ModelHandlerException(oops);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 80 */     if (this.inError || this.skipped) {
/*    */       return;
/*    */     }
/* 83 */     if (this.appender instanceof ch.qos.logback.core.spi.LifeCycle) {
/* 84 */       this.appender.start();
/*    */     }
/* 86 */     mic.markStartOfNamedDependee(this.appender.getName());
/*    */     
/* 88 */     Object o = mic.peekObject();
/*    */ 
/*    */ 
/*    */     
/* 92 */     Map<String, Appender<E>> appenderBag = (Map<String, Appender<E>>)mic.getObjectMap().get("APPENDER_BAG");
/* 93 */     appenderBag.put(this.appender.getName(), this.appender);
/*    */     
/* 95 */     if (o != this.appender) {
/* 96 */       addWarn("The object at the of the stack is not the appender named [" + this.appender.getName() + "] pushed earlier.");
/*    */     } else {
/*    */       
/* 99 */       mic.popObject();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\AppenderModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */