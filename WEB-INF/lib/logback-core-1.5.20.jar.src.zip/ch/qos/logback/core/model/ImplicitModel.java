/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplicitModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 5507123447813692833L;
/*    */   
/*    */   protected ImplicitModel makeNewInstance() {
/* 22 */     return new ImplicitModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\ImplicitModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */