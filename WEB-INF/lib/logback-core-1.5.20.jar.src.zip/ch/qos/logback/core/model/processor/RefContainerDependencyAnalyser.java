/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PhaseIndicator(phase = ProcessingPhase.DEPENDENCY_ANALYSIS)
/*    */ public class RefContainerDependencyAnalyser
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   final Class<?> modelClass;
/*    */   
/*    */   public RefContainerDependencyAnalyser(Context context, Class<?> modelClass) {
/* 25 */     super(context);
/* 26 */     this.modelClass = modelClass;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isSupportedModelType(Model model) {
/* 32 */     if (this.modelClass.isInstance(model)) {
/* 33 */       return true;
/*    */     }
/*    */     
/* 36 */     StringBuilder buf = new StringBuilder("This handler can only handle models of type ");
/* 37 */     buf.append(this.modelClass.getName());
/* 38 */     addError(buf.toString());
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 44 */     mic.pushModel(model);
/*    */   }
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 49 */     Model poppedModel = mic.popModel();
/* 50 */     if (model != poppedModel)
/* 51 */       addError("Popped model [" + String.valueOf(poppedModel) + "] different than expected [" + String.valueOf(model) + "]"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\RefContainerDependencyAnalyser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */