/*    */ package ch.qos.logback.core.model.conditional;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElseModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = -8409916706993952710L;
/*    */   
/*    */   protected ElseModel makeNewInstance() {
/* 24 */     return new ElseModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\conditional\ElseModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */