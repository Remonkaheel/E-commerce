/*    */ package ch.qos.logback.core.model.processor;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.hook.DefaultShutdownHook;
/*    */ import ch.qos.logback.core.hook.ShutdownHook;
/*    */ import ch.qos.logback.core.hook.ShutdownHookBase;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.ShutdownHookModel;
/*    */ import ch.qos.logback.core.util.ContextUtil;
/*    */ import ch.qos.logback.core.util.IncompatibleClassException;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShutdownHookModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   static final String OLD_SHUTDOWN_HOOK_CLASSNAME = "ch.qos.logback.core.hook.DelayingShutdownHook";
/* 31 */   static final String DEFAULT_SHUTDOWN_HOOK_CLASSNAME = DefaultShutdownHook.class.getName(); boolean inError;
/* 32 */   public static final String RENAME_WARNING = "ch.qos.logback.core.hook.DelayingShutdownHook was renamed as " + DEFAULT_SHUTDOWN_HOOK_CLASSNAME; ShutdownHook hook;
/*    */   
/*    */   public ShutdownHookModelHandler(Context context) {
/* 35 */     super(context);
/*    */     
/* 37 */     this.inError = false;
/* 38 */     this.hook = null;
/*    */   }
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext mic) {
/* 41 */     return new ShutdownHookModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ShutdownHookModel> getSupportedModelClass() {
/* 46 */     return ShutdownHookModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) {
/* 52 */     ShutdownHookModel shutdownHookModel = (ShutdownHookModel)model;
/*    */     
/* 54 */     String className = shutdownHookModel.getClassName();
/* 55 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 56 */       className = DEFAULT_SHUTDOWN_HOOK_CLASSNAME;
/* 57 */       addInfo("Assuming className [" + className + "]");
/*    */     } else {
/* 59 */       className = mic.getImport(className);
/* 60 */       if (className.equals("ch.qos.logback.core.hook.DelayingShutdownHook")) {
/* 61 */         className = DEFAULT_SHUTDOWN_HOOK_CLASSNAME;
/* 62 */         addWarn(RENAME_WARNING);
/* 63 */         addWarn("Please use the new class name");
/*    */       } 
/*    */     } 
/*    */     
/* 67 */     addInfo("About to instantiate shutdown hook of type [" + className + "]");
/*    */     
/*    */     try {
/* 70 */       this.hook = (ShutdownHook)OptionHelper.instantiateByClassName(className, ShutdownHookBase.class, this.context);
/* 71 */       this.hook.setContext(this.context);
/* 72 */     } catch (IncompatibleClassException|ch.qos.logback.core.util.DynamicClassLoadingException e) {
/* 73 */       addError("Could not create a shutdown hook of type [" + className + "].", e);
/* 74 */       this.inError = true;
/*    */       
/*    */       return;
/*    */     } 
/* 78 */     mic.pushObject(this.hook);
/*    */   }
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 83 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 86 */     Object o = mic.peekObject();
/*    */     
/* 88 */     if (o != this.hook) {
/* 89 */       addWarn("The object on the top the of the stack is not the hook object pushed earlier.");
/*    */     } else {
/* 91 */       ContextUtil contextUtil = new ContextUtil(this.context);
/* 92 */       contextUtil.addOrReplaceShutdownHook(this.hook);
/* 93 */       mic.popObject();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\processor\ShutdownHookModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */