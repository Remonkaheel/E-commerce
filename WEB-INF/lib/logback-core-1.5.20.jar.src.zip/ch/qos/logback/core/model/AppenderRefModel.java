/*    */ package ch.qos.logback.core.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.processor.PhaseIndicator;
/*    */ import ch.qos.logback.core.model.processor.ProcessingPhase;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PhaseIndicator(phase = ProcessingPhase.SECOND)
/*    */ public class AppenderRefModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 5238705468395447547L;
/*    */   String ref;
/*    */   
/*    */   protected AppenderRefModel makeNewInstance() {
/* 29 */     return new AppenderRefModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 34 */     AppenderRefModel actual = (AppenderRefModel)that;
/* 35 */     super.mirror(actual);
/* 36 */     this.ref = actual.ref;
/*    */   }
/*    */   
/*    */   public String getRef() {
/* 40 */     return this.ref;
/*    */   }
/*    */   
/*    */   public void setRef(String ref) {
/* 44 */     this.ref = ref;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 49 */     int prime = 31;
/* 50 */     int result = super.hashCode();
/* 51 */     result = 31 * result + Objects.hash(new Object[] { this.ref });
/* 52 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 57 */     if (this == obj)
/* 58 */       return true; 
/* 59 */     if (!super.equals(obj))
/* 60 */       return false; 
/* 61 */     if (getClass() != obj.getClass())
/* 62 */       return false; 
/* 63 */     AppenderRefModel other = (AppenderRefModel)obj;
/* 64 */     return Objects.equals(this.ref, other.ref);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\model\AppenderRefModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */