package ch.qos.logback.core;

import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.LifeCycle;

public interface Layout<E> extends ContextAware, LifeCycle {
  String doLayout(E paramE);
  
  String getFileHeader();
  
  String getPresentationHeader();
  
  String getPresentationFooter();
  
  String getFileFooter();
  
  String getContentType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\Layout.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */