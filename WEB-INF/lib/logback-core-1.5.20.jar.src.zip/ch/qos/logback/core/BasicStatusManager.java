/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.helpers.CyclicBuffer;
/*     */ import ch.qos.logback.core.spi.LogbackLock;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusListener;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicStatusManager
/*     */   implements StatusManager
/*     */ {
/*     */   public static final int MAX_HEADER_COUNT = 150;
/*     */   public static final int TAIL_SIZE = 150;
/*  31 */   int count = 0;
/*     */ 
/*     */   
/*  34 */   protected final List<Status> statusList = new ArrayList<>();
/*  35 */   protected final CyclicBuffer<Status> tailBuffer = new CyclicBuffer(150);
/*  36 */   protected final LogbackLock statusListLock = new LogbackLock();
/*     */   
/*  38 */   int level = 0;
/*     */ 
/*     */   
/*  41 */   protected final List<StatusListener> statusListenerList = new ArrayList<>();
/*  42 */   protected final LogbackLock statusListenerListLock = new LogbackLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Status newStatus) {
/*  58 */     fireStatusAddEvent(newStatus);
/*     */     
/*  60 */     this.count++;
/*  61 */     if (newStatus.getLevel() > this.level) {
/*  62 */       this.level = newStatus.getLevel();
/*     */     }
/*     */     
/*  65 */     synchronized (this.statusListLock) {
/*  66 */       if (this.statusList.size() < 150) {
/*  67 */         this.statusList.add(newStatus);
/*     */       } else {
/*  69 */         this.tailBuffer.add(newStatus);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Status> getCopyOfStatusList() {
/*  76 */     synchronized (this.statusListLock) {
/*  77 */       List<Status> tList = new ArrayList<>(this.statusList);
/*  78 */       tList.addAll(this.tailBuffer.asList());
/*  79 */       return tList;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fireStatusAddEvent(Status status) {
/*  84 */     synchronized (this.statusListenerListLock) {
/*  85 */       for (StatusListener sl : this.statusListenerList) {
/*  86 */         sl.addStatusEvent(status);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/*  92 */     synchronized (this.statusListLock) {
/*  93 */       this.count = 0;
/*  94 */       this.statusList.clear();
/*  95 */       this.tailBuffer.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLevel() {
/* 100 */     return this.level;
/*     */   }
/*     */   
/*     */   public int getCount() {
/* 104 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(StatusListener listener) {
/* 114 */     synchronized (this.statusListenerListLock) {
/* 115 */       if (listener instanceof ch.qos.logback.core.status.OnConsoleStatusListener) {
/* 116 */         boolean alreadyPresent = checkForPresence(this.statusListenerList, listener.getClass());
/* 117 */         if (alreadyPresent)
/* 118 */           return false; 
/*     */       } 
/* 120 */       this.statusListenerList.add(listener);
/*     */     } 
/* 122 */     return true;
/*     */   }
/*     */   
/*     */   private boolean checkForPresence(List<StatusListener> statusListenerList, Class<?> aClass) {
/* 126 */     for (StatusListener e : statusListenerList) {
/* 127 */       if (e.getClass() == aClass)
/* 128 */         return true; 
/*     */     } 
/* 130 */     return false;
/*     */   }
/*     */   
/*     */   public void remove(StatusListener listener) {
/* 134 */     synchronized (this.statusListenerListLock) {
/* 135 */       this.statusListenerList.remove(listener);
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<StatusListener> getCopyOfStatusListenerList() {
/* 140 */     synchronized (this.statusListenerListLock) {
/* 141 */       return new ArrayList<>(this.statusListenerList);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\BasicStatusManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */