/*    */ package ch.qos.logback.core.property;
/*    */ 
/*    */ import ch.qos.logback.core.PropertyDefinerBase;
/*    */ import ch.qos.logback.core.util.NetworkAddressUtil;
/*    */ 
/*    */ public class CanonicalHostNamePropertyDefiner
/*    */   extends PropertyDefinerBase
/*    */ {
/*    */   public String getPropertyValue() {
/* 10 */     return (new NetworkAddressUtil(getContext())).safelyGetCanonicalLocalHostName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\property\CanonicalHostNamePropertyDefiner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */