/*    */ package ch.qos.logback.core.property;
/*    */ 
/*    */ import ch.qos.logback.core.PropertyDefinerBase;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileExistsPropertyDefiner
/*    */   extends PropertyDefinerBase
/*    */ {
/*    */   String path;
/*    */   
/*    */   public String getPath() {
/* 36 */     return this.path;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPath(String path) {
/* 45 */     this.path = path;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPropertyValue() {
/* 55 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(this.path)) {
/* 56 */       addError("The \"path\" property must be set.");
/* 57 */       return null;
/*    */     } 
/*    */     
/* 60 */     File file = new File(this.path);
/* 61 */     return booleanAsStr(file.exists());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\property\FileExistsPropertyDefiner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */