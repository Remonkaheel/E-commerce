/*    */ package ch.qos.logback.core.property;
/*    */ 
/*    */ import ch.qos.logback.core.PropertyDefinerBase;
/*    */ import ch.qos.logback.core.util.Loader;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceExistsPropertyDefiner
/*    */   extends PropertyDefinerBase
/*    */ {
/*    */   String resourceStr;
/*    */   
/*    */   public String getResource() {
/* 40 */     return this.resourceStr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResource(String resource) {
/* 49 */     this.resourceStr = resource;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPropertyValue() {
/* 60 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(this.resourceStr)) {
/* 61 */       addError("The \"resource\" property must be set.");
/* 62 */       return null;
/*    */     } 
/*    */     
/* 65 */     URL resourceURL = Loader.getResourceBySelfClassLoader(this.resourceStr);
/* 66 */     return booleanAsStr((resourceURL != null));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\property\ResourceExistsPropertyDefiner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */