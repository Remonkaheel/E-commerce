/*    */ package ch.qos.logback.core.read;
/*    */ 
/*    */ import ch.qos.logback.core.AppenderBase;
/*    */ import ch.qos.logback.core.helpers.CyclicBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CyclicBufferAppender<E>
/*    */   extends AppenderBase<E>
/*    */ {
/*    */   CyclicBuffer<E> cb;
/* 30 */   int maxSize = 512;
/*    */   
/*    */   public void start() {
/* 33 */     this.cb = new CyclicBuffer(this.maxSize);
/* 34 */     super.start();
/*    */   }
/*    */   
/*    */   public void stop() {
/* 38 */     this.cb = null;
/* 39 */     super.stop();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void append(E eventObject) {
/* 44 */     if (!isStarted()) {
/*    */       return;
/*    */     }
/* 47 */     this.cb.add(eventObject);
/*    */   }
/*    */   
/*    */   public int getLength() {
/* 51 */     if (isStarted()) {
/* 52 */       return this.cb.length();
/*    */     }
/* 54 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public E get(int i) {
/* 59 */     if (isStarted()) {
/* 60 */       return (E)this.cb.get(i);
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset() {
/* 67 */     this.cb.clear();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaxSize() {
/* 74 */     return this.maxSize;
/*    */   }
/*    */   
/*    */   public void setMaxSize(int maxSize) {
/* 78 */     this.maxSize = maxSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\read\CyclicBufferAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */