/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.joran.spi.ConsoleTarget;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.WarnStatus;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsoleAppender<E>
/*     */   extends OutputStreamAppender<E>
/*     */ {
/*  46 */   protected ConsoleTarget target = ConsoleTarget.SystemOut;
/*     */   
/*     */   protected boolean withJansi = false;
/*     */   private static final String AnsiConsole_CLASS_NAME = "org.fusesource.jansi.AnsiConsole";
/*     */   private static final String JANSI2_OUT_METHOD_NAME = "out";
/*     */   private static final String JANSI2_ERR_METHOD_NAME = "err";
/*     */   private static final String WRAP_SYSTEM_OUT_METHOD_NAME = "wrapSystemOut";
/*     */   private static final String WRAP_SYSTEM_ERR_METHOD_NAME = "wrapSystemErr";
/*     */   private static final String SYSTEM_INSTALL_METHOD_NAME = "systemInstall";
/*  55 */   private static final Class<?>[] ARGUMENT_TYPES = new Class[] { PrintStream.class };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CONSOLE_APPENDER_WARNING_URL = "https://logback.qos.ch/codes.html#slowConsole";
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(String value) {
/*  64 */     ConsoleTarget t = ConsoleTarget.findByName(value.trim());
/*  65 */     if (t == null) {
/*  66 */       targetWarn(value);
/*     */     } else {
/*  68 */       this.target = t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTarget() {
/*  79 */     return this.target.getName();
/*     */   }
/*     */   
/*     */   private void targetWarn(String val) {
/*  83 */     WarnStatus warnStatus = new WarnStatus("[" + val + "] should be one of " + Arrays.toString((Object[])ConsoleTarget.values()), this);
/*     */     
/*  85 */     warnStatus.add((Status)new WarnStatus("Using previously set target, System.out by default.", this));
/*  86 */     addStatus((Status)warnStatus);
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*  91 */     addInfo("NOTE: Writing to the console can be slow. Try to avoid logging to the ");
/*  92 */     addInfo("console in production environments, especially in high volume systems.");
/*  93 */     addInfo("See also https://logback.qos.ch/codes.html#slowConsole");
/*  94 */     OutputStream targetStream = this.target.getStream();
/*     */     
/*  96 */     if (this.withJansi) {
/*  97 */       targetStream = wrapWithJansi(targetStream);
/*     */     }
/*  99 */     setOutputStream(targetStream);
/* 100 */     super.start();
/*     */   }
/*     */   
/*     */   private OutputStream wrapWithJansi(OutputStream targetStream) {
/*     */     try {
/* 105 */       addInfo("Enabling JANSI AnsiPrintStream for the console.");
/* 106 */       ClassLoader classLoader = Loader.getClassLoaderOfObject(this.context);
/* 107 */       Class<?> classObj = classLoader.loadClass("org.fusesource.jansi.AnsiConsole");
/*     */       
/* 109 */       Method systemInstallMethod = classObj.getMethod("systemInstall", new Class[0]);
/* 110 */       if (systemInstallMethod != null) {
/* 111 */         systemInstallMethod.invoke((Object)null, new Object[0]);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       String methodNameJansi2 = (this.target == ConsoleTarget.SystemOut) ? "out" : "err";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 133 */       Optional<Method> optOutMethod = Arrays.<Method>stream(classObj.getMethods()).filter(m -> m.getName().equals(methodNameJansi2)).filter(m -> ((m.getParameters()).length == 0)).filter(m -> Modifier.isStatic(m.getModifiers())).filter(m -> PrintStream.class.isAssignableFrom(m.getReturnType())).findAny();
/* 134 */       if (optOutMethod.isPresent()) {
/* 135 */         Method outMethod = optOutMethod.<Throwable>orElseThrow(() -> new NoSuchElementException("No out/err method present"));
/* 136 */         return (PrintStream)outMethod.invoke((Object)null, new Object[0]);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 141 */       String methodName = (this.target == ConsoleTarget.SystemOut) ? "wrapSystemOut" : "wrapSystemErr";
/* 142 */       Method method = classObj.getMethod(methodName, ARGUMENT_TYPES);
/* 143 */       return (OutputStream)method.invoke((Object)null, new Object[] { new PrintStream(targetStream) });
/* 144 */     } catch (Exception e) {
/* 145 */       addWarn("Failed to create AnsiPrintStream. Falling back on the default stream.", e);
/*     */       
/* 147 */       return targetStream;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWithJansi() {
/* 154 */     return this.withJansi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWithJansi(boolean withJansi) {
/* 164 */     this.withJansi = withJansi;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\ConsoleAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */