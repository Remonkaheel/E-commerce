/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import java.security.MessageDigest;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MD5Util
/*    */ {
/* 25 */   static String MD5_ALGORITHM_KEY = "MD5";
/*    */ 
/*    */ 
/*    */   
/* 29 */   final MessageDigest md5 = MessageDigest.getInstance(MD5_ALGORITHM_KEY);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equalsHash(byte[] b0, byte[] b1) {
/* 35 */     return Arrays.equals(b0, b1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] md5Hash(String input) {
/* 46 */     byte[] messageDigest = this.md5.digest(input.getBytes());
/* 47 */     this.md5.reset();
/* 48 */     return messageDigest;
/*    */   }
/*    */   
/*    */   public String asHexString(byte[] messageDigest) {
/* 52 */     BigInteger number = new BigInteger(1, messageDigest);
/* 53 */     StringBuilder hexString = new StringBuilder(number.toString(16));
/*    */     
/* 55 */     while (hexString.length() < 32) {
/* 56 */       hexString.insert(0, '0');
/*    */     }
/* 58 */     return hexString.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\MD5Util.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */