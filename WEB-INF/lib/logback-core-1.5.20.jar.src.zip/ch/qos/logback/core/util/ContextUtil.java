/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.hook.ShutdownHook;
/*    */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextUtil
/*    */   extends ContextAwareBase
/*    */ {
/*    */   static final String GROOVY_RUNTIME_PACKAGE = "org.codehaus.groovy.runtime";
/*    */   
/*    */   public ContextUtil(Context context) {
/* 36 */     setContext(context);
/*    */   }
/*    */   
/*    */   public void addProperties(Properties props) {
/* 40 */     if (props == null) {
/*    */       return;
/*    */     }
/*    */     
/* 44 */     for (Map.Entry<Object, Object> e : props.entrySet()) {
/* 45 */       String key = (String)e.getKey();
/* 46 */       this.context.putProperty(key, (String)e.getValue());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Map<String, String> getFilenameCollisionMap(Context context) {
/* 52 */     if (context == null) {
/* 53 */       return null;
/*    */     }
/* 55 */     Map<String, String> map = (Map<String, String>)context.getObject("FA_FILENAMES_MAP");
/* 56 */     return map;
/*    */   }
/*    */   
/*    */   public static Map<String, FileNamePattern> getFilenamePatternCollisionMap(Context context) {
/* 60 */     if (context == null) {
/* 61 */       return null;
/*    */     }
/*    */     
/* 64 */     Map<String, FileNamePattern> map = (Map<String, FileNamePattern>)context.getObject("RFA_FILENAME_PATTERN_COLLISION_MAP");
/* 65 */     return map;
/*    */   }
/*    */   
/*    */   public void addGroovyPackages(List<String> frameworkPackages) {
/* 69 */     addFrameworkPackage(frameworkPackages, "org.codehaus.groovy.runtime");
/*    */   }
/*    */   
/*    */   public void addFrameworkPackage(List<String> frameworkPackages, String packageName) {
/* 73 */     if (!frameworkPackages.contains(packageName)) {
/* 74 */       frameworkPackages.add(packageName);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addOrReplaceShutdownHook(ShutdownHook hook) {
/* 86 */     Runtime runtime = Runtime.getRuntime();
/*    */     
/* 88 */     Thread oldShutdownHookThread = (Thread)this.context.getObject("SHUTDOWN_HOOK");
/* 89 */     if (oldShutdownHookThread != null) {
/* 90 */       addInfo("Removing old shutdown hook from JVM runtime");
/* 91 */       runtime.removeShutdownHook(oldShutdownHookThread);
/*    */     } 
/*    */     
/* 94 */     Thread hookThread = new Thread((Runnable)hook, "Logback shutdown hook [" + this.context.getName() + "]");
/* 95 */     addInfo("Registering shutdown hook with JVM runtime.");
/* 96 */     this.context.putObject("SHUTDOWN_HOOK", hookThread);
/* 97 */     runtime.addShutdownHook(hookThread);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\ContextUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */