/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocationUtil
/*    */ {
/*    */   public static final String SCHEME_PATTERN = "^\\p{Alpha}[\\p{Alnum}+.-]*:.*$";
/*    */   public static final String CLASSPATH_SCHEME = "classpath:";
/*    */   
/*    */   public static URL urlForResource(String location) throws MalformedURLException, FileNotFoundException {
/* 46 */     if (location == null) {
/* 47 */       throw new NullPointerException("location is required");
/*    */     }
/* 49 */     URL url = null;
/* 50 */     if (!location.matches("^\\p{Alpha}[\\p{Alnum}+.-]*:.*$")) {
/* 51 */       url = Loader.getResourceBySelfClassLoader(location);
/* 52 */     } else if (location.startsWith("classpath:")) {
/* 53 */       String path = location.substring("classpath:".length());
/* 54 */       if (path.startsWith("/")) {
/* 55 */         path = path.substring(1);
/*    */       }
/* 57 */       if (path.length() == 0) {
/* 58 */         throw new MalformedURLException("path is required");
/*    */       }
/* 60 */       url = Loader.getResourceBySelfClassLoader(path);
/*    */     } else {
/* 62 */       url = new URL(location);
/*    */     } 
/* 64 */     if (url == null) {
/* 65 */       throw new FileNotFoundException(location);
/*    */     }
/* 67 */     return url;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\LocationUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */