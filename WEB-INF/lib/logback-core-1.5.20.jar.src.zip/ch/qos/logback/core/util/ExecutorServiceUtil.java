/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecutorServiceUtil
/*     */ {
/*  29 */   private static final ThreadFactory THREAD_FACTORY_FOR_SCHEDULED_EXECUTION_SERVICE = new ThreadFactory()
/*     */     {
/*  31 */       private final AtomicInteger threadNumber = new AtomicInteger(1);
/*     */       
/*  33 */       private final ThreadFactory defaultFactory = makeThreadFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private ThreadFactory makeThreadFactory() {
/*  41 */         return Executors.defaultThreadFactory();
/*     */       }
/*     */ 
/*     */       
/*     */       public Thread newThread(Runnable r) {
/*  46 */         Thread thread = this.defaultFactory.newThread(r);
/*  47 */         if (!thread.isDaemon()) {
/*  48 */           thread.setDaemon(true);
/*     */         }
/*  50 */         thread.setName("logback-" + this.threadNumber.getAndIncrement());
/*  51 */         return thread;
/*     */       }
/*     */     };
/*     */   
/*     */   public static ScheduledExecutorService newScheduledExecutorService() {
/*  56 */     return new ScheduledThreadPoolExecutor(4, THREAD_FACTORY_FOR_SCHEDULED_EXECUTION_SERVICE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExecutorService newExecutorService() {
/*  63 */     return newThreadPoolExecutor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThreadPoolExecutor newThreadPoolExecutor() {
/*  75 */     int maximumPoolSize = 5;
/*  76 */     long keepAliveMillis = 100L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(4, 5, 100L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(), THREAD_FACTORY_FOR_SCHEDULED_EXECUTION_SERVICE);
/*     */     
/*  84 */     threadPoolExecutor.allowCoreThreadTimeOut(true);
/*  85 */     return threadPoolExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown(ExecutorService executorService) {
/*  96 */     if (executorService != null) {
/*  97 */       executorService.shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExecutorService newAlternateThreadPoolExecutor() {
/* 108 */     return newThreadPoolExecutor();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\ExecutorServiceUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */