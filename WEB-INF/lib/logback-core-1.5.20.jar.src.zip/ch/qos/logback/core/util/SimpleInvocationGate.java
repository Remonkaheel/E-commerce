/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleInvocationGate
/*    */   implements InvocationGate
/*    */ {
/* 31 */   AtomicLong atomicNext = new AtomicLong(0L);
/*    */   
/*    */   final Duration increment;
/*    */   
/* 35 */   public static final Duration DEFAULT_INCREMENT = Duration.buildBySeconds(60.0D);
/*    */   
/*    */   public SimpleInvocationGate() {
/* 38 */     this(DEFAULT_INCREMENT);
/*    */   }
/*    */   
/*    */   public SimpleInvocationGate(Duration anIncrement) {
/* 42 */     this.increment = anIncrement;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isTooSoon(long currentTime) {
/* 47 */     if (currentTime == -1L) {
/* 48 */       return false;
/*    */     }
/* 50 */     long localNext = this.atomicNext.get();
/* 51 */     if (currentTime >= localNext) {
/* 52 */       long next2 = currentTime + this.increment.getMilliseconds();
/*    */       
/* 54 */       boolean success = this.atomicNext.compareAndSet(localNext, next2);
/*    */ 
/*    */       
/* 57 */       return !success;
/*    */     } 
/* 59 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\SimpleInvocationGate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */