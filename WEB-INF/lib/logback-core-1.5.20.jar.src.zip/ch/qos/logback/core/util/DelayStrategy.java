package ch.qos.logback.core.util;

public interface DelayStrategy {
  long nextDelay();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\DelayStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */