/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import java.net.ServerSocket;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloseUtil
/*    */ {
/*    */   public static void closeQuietly(Closeable closeable) {
/* 34 */     if (closeable == null)
/*    */       return; 
/*    */     try {
/* 37 */       closeable.close();
/* 38 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void closeQuietly(Socket socket) {
/* 49 */     if (socket == null)
/*    */       return; 
/*    */     try {
/* 52 */       socket.close();
/* 53 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void closeQuietly(ServerSocket serverSocket) {
/* 64 */     if (serverSocket == null)
/*    */       return; 
/*    */     try {
/* 67 */       serverSocket.close();
/* 68 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\CloseUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */