/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import java.net.InetAddress;
/*    */ import java.net.NetworkInterface;
/*    */ import java.net.SocketException;
/*    */ import java.net.UnknownHostException;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ public class NetworkAddressUtil
/*    */   extends ContextAwareBase
/*    */ {
/*    */   public NetworkAddressUtil(Context context) {
/* 16 */     setContext(context);
/*    */   }
/*    */   
/*    */   public static String getLocalHostName() throws UnknownHostException, SocketException {
/*    */     try {
/* 21 */       InetAddress localhost = InetAddress.getLocalHost();
/* 22 */       return localhost.getHostName();
/* 23 */     } catch (UnknownHostException e) {
/* 24 */       return getLocalAddressAsString();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getCanonicalLocalHostName() throws UnknownHostException, SocketException {
/*    */     try {
/* 30 */       InetAddress localhost = InetAddress.getLocalHost();
/* 31 */       return localhost.getCanonicalHostName();
/* 32 */     } catch (UnknownHostException e) {
/* 33 */       return getLocalAddressAsString();
/*    */     } 
/*    */   }
/*    */   
/*    */   private static String getLocalAddressAsString() throws UnknownHostException, SocketException {
/* 38 */     Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
/* 39 */     while (interfaces != null && interfaces.hasMoreElements()) {
/* 40 */       Enumeration<InetAddress> addresses = ((NetworkInterface)interfaces.nextElement()).getInetAddresses();
/* 41 */       while (addresses != null && addresses.hasMoreElements()) {
/* 42 */         InetAddress address = addresses.nextElement();
/* 43 */         if (acceptableAddress(address)) {
/* 44 */           return address.getHostAddress();
/*    */         }
/*    */       } 
/*    */     } 
/* 48 */     throw new UnknownHostException();
/*    */   }
/*    */   
/*    */   private static boolean acceptableAddress(InetAddress address) {
/* 52 */     return (address != null && !address.isLoopbackAddress() && !address.isAnyLocalAddress() && 
/* 53 */       !address.isLinkLocalAddress());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String safelyGetLocalHostName() {
/*    */     try {
/* 61 */       String localhostName = getLocalHostName();
/* 62 */       return localhostName;
/* 63 */     } catch (UnknownHostException|SocketException|SecurityException e) {
/* 64 */       addError("Failed to get local hostname", e);
/*    */       
/* 66 */       return "UNKNOWN_LOCALHOST";
/*    */     } 
/*    */   }
/*    */   public String safelyGetCanonicalLocalHostName() {
/*    */     try {
/* 71 */       String localhostName = getCanonicalLocalHostName();
/* 72 */       return localhostName;
/* 73 */     } catch (UnknownHostException|SocketException|SecurityException e) {
/* 74 */       addError("Failed to get canonical local hostname", e);
/*    */       
/* 76 */       return "UNKNOWN_LOCALHOST";
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\NetworkAddressUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */