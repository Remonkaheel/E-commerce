/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import java.time.Instant;
/*    */ import java.time.ZoneId;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Locale;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachingDateFormatter
/*    */ {
/*    */   final DateTimeFormatter dtf;
/*    */   final ZoneId zoneId;
/*    */   final AtomicReference<CacheTuple> atomicReference;
/*    */   
/*    */   static class CacheTuple
/*    */   {
/*    */     final long lastTimestamp;
/*    */     final String cachedStr;
/*    */     
/*    */     public CacheTuple(long lastTimestamp, String cachedStr) {
/* 42 */       this.lastTimestamp = lastTimestamp;
/* 43 */       this.cachedStr = cachedStr;
/*    */     }
/*    */   }
/*    */   
/*    */   public CachingDateFormatter(String pattern) {
/* 48 */     this(pattern, null);
/*    */   }
/*    */   
/*    */   public CachingDateFormatter(String pattern, ZoneId aZoneId) {
/* 52 */     this(pattern, aZoneId, null);
/*    */   }
/*    */   
/*    */   public CachingDateFormatter(String pattern, ZoneId aZoneId, Locale aLocale) {
/* 56 */     if (aZoneId == null) {
/* 57 */       this.zoneId = ZoneId.systemDefault();
/*    */     } else {
/* 59 */       this.zoneId = aZoneId;
/*    */     } 
/* 61 */     Locale locale = (aLocale != null) ? aLocale : Locale.getDefault();
/*    */     
/* 63 */     this.dtf = DateTimeFormatter.ofPattern(pattern).withZone(this.zoneId).withLocale(locale);
/* 64 */     CacheTuple cacheTuple = new CacheTuple(-1L, null);
/* 65 */     this.atomicReference = new AtomicReference<>(cacheTuple);
/*    */   }
/*    */   
/*    */   public final String format(long now) {
/* 69 */     CacheTuple localCacheTuple = this.atomicReference.get();
/* 70 */     CacheTuple oldCacheTuple = localCacheTuple;
/*    */     
/* 72 */     if (now != localCacheTuple.lastTimestamp) {
/* 73 */       Instant instant = Instant.ofEpochMilli(now);
/* 74 */       String result = this.dtf.format(instant);
/* 75 */       localCacheTuple = new CacheTuple(now, result);
/*    */       
/* 77 */       this.atomicReference.compareAndSet(oldCacheTuple, localCacheTuple);
/*    */     } 
/* 79 */     return localCacheTuple.cachedStr;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\CachingDateFormatter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */