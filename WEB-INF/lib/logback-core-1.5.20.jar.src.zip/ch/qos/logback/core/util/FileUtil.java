/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.rolling.RolloverFailure;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileUtil
/*     */   extends ContextAwareBase
/*     */ {
/*     */   static final int BUF_SIZE = 32768;
/*     */   
/*     */   public FileUtil(Context context) {
/*  28 */     setContext(context);
/*     */   }
/*     */   
/*     */   public static URL fileToURL(File file) {
/*     */     try {
/*  33 */       return file.toURI().toURL();
/*  34 */     } catch (MalformedURLException e) {
/*  35 */       throw new RuntimeException("Unexpected exception on file [" + String.valueOf(file) + "]", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean createMissingParentDirectories(File file) {
/*  48 */     File parent = file.getParentFile();
/*  49 */     if (parent == null)
/*     */     {
/*     */       
/*  52 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  57 */     parent.mkdirs();
/*  58 */     return parent.exists();
/*     */   }
/*     */   
/*     */   public String resourceAsString(ClassLoader classLoader, String resourceName) {
/*  62 */     URL url = classLoader.getResource(resourceName);
/*  63 */     if (url == null) {
/*  64 */       addError("Failed to find resource [" + resourceName + "]");
/*  65 */       return null;
/*     */     } 
/*     */     
/*  68 */     InputStreamReader isr = null;
/*     */     try {
/*  70 */       URLConnection urlConnection = url.openConnection();
/*  71 */       urlConnection.setUseCaches(false);
/*  72 */       isr = new InputStreamReader(urlConnection.getInputStream());
/*  73 */       char[] buf = new char[128];
/*  74 */       StringBuilder builder = new StringBuilder();
/*  75 */       int count = -1;
/*  76 */       while ((count = isr.read(buf, 0, buf.length)) != -1) {
/*  77 */         builder.append(buf, 0, count);
/*     */       }
/*  79 */       return builder.toString();
/*  80 */     } catch (IOException e) {
/*  81 */       addError("Failed to open " + resourceName, e);
/*     */     } finally {
/*  83 */       if (isr != null) {
/*     */         try {
/*  85 */           isr.close();
/*  86 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(String src, String destination) throws RolloverFailure {
/*  97 */     BufferedInputStream bis = null;
/*  98 */     BufferedOutputStream bos = null;
/*     */     try {
/* 100 */       bis = new BufferedInputStream(new FileInputStream(src));
/* 101 */       bos = new BufferedOutputStream(new FileOutputStream(destination));
/* 102 */       byte[] inbuf = new byte[32768];
/*     */       
/*     */       int n;
/* 105 */       while ((n = bis.read(inbuf)) != -1) {
/* 106 */         bos.write(inbuf, 0, n);
/*     */       }
/*     */       
/* 109 */       bis.close();
/* 110 */       bis = null;
/* 111 */       bos.close();
/* 112 */       bos = null;
/* 113 */     } catch (IOException ioe) {
/* 114 */       String msg = "Failed to copy [" + src + "] to [" + destination + "]";
/* 115 */       addError(msg, ioe);
/* 116 */       throw new RolloverFailure(msg);
/*     */     } finally {
/* 118 */       if (bis != null) {
/*     */         try {
/* 120 */           bis.close();
/* 121 */         } catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 125 */       if (bos != null)
/*     */         try {
/* 127 */           bos.close();
/* 128 */         } catch (IOException iOException) {} 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\FileUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */