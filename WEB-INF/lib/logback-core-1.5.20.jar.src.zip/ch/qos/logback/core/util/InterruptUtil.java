/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterruptUtil
/*    */   extends ContextAwareBase
/*    */ {
/*    */   final boolean previouslyInterrupted;
/*    */   
/*    */   public InterruptUtil(Context context) {
/* 38 */     setContext(context);
/* 39 */     this.previouslyInterrupted = Thread.currentThread().isInterrupted();
/*    */   }
/*    */   
/*    */   public void maskInterruptFlag() {
/* 43 */     if (this.previouslyInterrupted) {
/* 44 */       Thread.interrupted();
/*    */     }
/*    */   }
/*    */   
/*    */   public void unmaskInterruptFlag() {
/* 49 */     if (this.previouslyInterrupted)
/*    */       try {
/* 51 */         Thread.currentThread().interrupt();
/* 52 */       } catch (SecurityException se) {
/* 53 */         addError("Failed to interrupt current thread", se);
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\InterruptUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */