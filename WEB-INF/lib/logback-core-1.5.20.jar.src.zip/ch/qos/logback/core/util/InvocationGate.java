package ch.qos.logback.core.util;

public interface InvocationGate {
  public static final long TIME_UNAVAILABLE = -1L;
  
  boolean isTooSoon(long paramLong);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\InvocationGate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */