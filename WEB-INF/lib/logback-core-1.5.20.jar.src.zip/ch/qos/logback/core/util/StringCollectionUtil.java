/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringCollectionUtil
/*     */ {
/*     */   public static void retainMatching(Collection<String> values, String... patterns) {
/*  40 */     retainMatching(values, Arrays.asList(patterns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void retainMatching(Collection<String> values, Collection<String> patterns) {
/*  55 */     if (patterns.isEmpty())
/*     */       return; 
/*  57 */     List<String> matches = new ArrayList<>(values.size());
/*  58 */     for (String p : patterns) {
/*  59 */       Pattern pattern = Pattern.compile(p);
/*  60 */       for (String value : values) {
/*  61 */         if (pattern.matcher(value).matches()) {
/*  62 */           matches.add(value);
/*     */         }
/*     */       } 
/*     */     } 
/*  66 */     values.retainAll(matches);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeMatching(Collection<String> values, String... patterns) {
/*  80 */     removeMatching(values, Arrays.asList(patterns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeMatching(Collection<String> values, Collection<String> patterns) {
/*  95 */     List<String> matches = new ArrayList<>(values.size());
/*  96 */     for (String p : patterns) {
/*  97 */       Pattern pattern = Pattern.compile(p);
/*  98 */       for (String value : values) {
/*  99 */         if (pattern.matcher(value).matches()) {
/* 100 */           matches.add(value);
/*     */         }
/*     */       } 
/*     */     } 
/* 104 */     values.removeAll(matches);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\StringCollectionUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */