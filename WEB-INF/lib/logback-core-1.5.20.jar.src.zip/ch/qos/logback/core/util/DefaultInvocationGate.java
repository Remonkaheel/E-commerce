/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultInvocationGate
/*     */   implements InvocationGate
/*     */ {
/*     */   static final int MASK_DECREASE_RIGHT_SHIFT_COUNT = 2;
/*     */   private static final int MAX_MASK = 65535;
/*     */   static final int DEFAULT_MASK = 15;
/*  32 */   private volatile long mask = 15L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private long invocationCounter = 0L;
/*     */   
/*     */   private static final long MASK_INCREASE_THRESHOLD = 100L;
/*     */   
/*     */   private static final long MASK_DECREASE_THRESHOLD = 800L;
/*     */   
/*     */   private long minDelayThreshold;
/*     */   
/*     */   private long maxDelayThreshold;
/*     */   long lowerLimitForMaskMatch;
/*     */   long upperLimitForNoMaskMatch;
/*     */   
/*     */   public DefaultInvocationGate() {
/*  52 */     this(100L, 800L, System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   public DefaultInvocationGate(long minDelayThreshold, long maxDelayThreshold, long currentTime) {
/*  56 */     this.minDelayThreshold = minDelayThreshold;
/*  57 */     this.maxDelayThreshold = maxDelayThreshold;
/*  58 */     this.lowerLimitForMaskMatch = currentTime + minDelayThreshold;
/*  59 */     this.upperLimitForNoMaskMatch = currentTime + maxDelayThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTooSoon(long currentTime) {
/*  75 */     boolean maskMatch = ((this.invocationCounter++ & this.mask) == this.mask);
/*     */     
/*  77 */     if (maskMatch) {
/*  78 */       if (currentTime < this.lowerLimitForMaskMatch) {
/*  79 */         increaseMask();
/*     */       }
/*  81 */       updateLimits(currentTime);
/*     */     }
/*  83 */     else if (currentTime > this.upperLimitForNoMaskMatch) {
/*  84 */       decreaseMask();
/*  85 */       updateLimits(currentTime);
/*  86 */       return false;
/*     */     } 
/*     */     
/*  89 */     return !maskMatch;
/*     */   }
/*     */   
/*     */   private void updateLimits(long currentTime) {
/*  93 */     this.lowerLimitForMaskMatch = currentTime + this.minDelayThreshold;
/*  94 */     this.upperLimitForNoMaskMatch = currentTime + this.maxDelayThreshold;
/*     */   }
/*     */ 
/*     */   
/*     */   long getMask() {
/*  99 */     return this.mask;
/*     */   }
/*     */   
/*     */   private void increaseMask() {
/* 103 */     if (this.mask >= 65535L)
/*     */       return; 
/* 105 */     this.mask = this.mask << 1L | 0x1L;
/*     */   }
/*     */   
/*     */   private void decreaseMask() {
/* 109 */     this.mask >>>= 2L;
/*     */   }
/*     */   
/*     */   public long getInvocationCounter() {
/* 113 */     return this.invocationCounter;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\DefaultInvocationGate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */