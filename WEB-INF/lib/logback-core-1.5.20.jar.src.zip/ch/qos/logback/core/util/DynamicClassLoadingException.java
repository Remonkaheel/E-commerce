/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicClassLoadingException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 4962278449162476114L;
/*    */   
/*    */   public DynamicClassLoadingException(String desc, Throwable root) {
/* 21 */     super(desc, root);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\DynamicClassLoadingException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */