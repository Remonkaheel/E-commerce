/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Loader
/*     */ {
/*     */   static final String TSTR = "Caught Exception while in Loader.getResource. This may be innocuous.";
/*     */   private static boolean ignoreTCL = false;
/*     */   public static final String IGNORE_TCL_PROPERTY_NAME = "logback.ignoreTCL";
/*     */   
/*     */   static {
/*  36 */     String ignoreTCLProp = OptionHelper.getSystemProperty("logback.ignoreTCL", null);
/*     */     
/*  38 */     if (ignoreTCLProp != null) {
/*  39 */       ignoreTCL = OptionHelper.toBoolean(ignoreTCLProp, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader systemClassloaderIfNull(ClassLoader cl) {
/*  52 */     if (cl == null) {
/*  53 */       return ClassLoader.getSystemClassLoader();
/*     */     }
/*  55 */     return cl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<URL> getResources(String resource, ClassLoader classLoader) throws IOException {
/*  68 */     Set<URL> urlSet = new HashSet<>();
/*  69 */     Enumeration<URL> urlEnum = classLoader.getResources(resource);
/*  70 */     while (urlEnum.hasMoreElements()) {
/*  71 */       URL url = urlEnum.nextElement();
/*  72 */       urlSet.add(url);
/*     */     } 
/*  74 */     return urlSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getResource(String resource, ClassLoader classLoader) {
/*     */     try {
/*  85 */       return classLoader.getResource(resource);
/*  86 */     } catch (Throwable t) {
/*  87 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getResourceBySelfClassLoader(String resource) {
/*  99 */     return getResource(resource, getClassLoaderOfClass(Loader.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getTCL() {
/* 111 */     return Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */   
/*     */   public static Class<?> loadClass(String clazz, Context context) throws ClassNotFoundException {
/* 115 */     ClassLoader cl = getClassLoaderOfObject(context);
/* 116 */     return cl.loadClass(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getClassLoaderOfObject(Object o) {
/* 127 */     if (o == null) {
/* 128 */       throw new NullPointerException("Argument cannot be null");
/*     */     }
/* 130 */     return getClassLoaderOfClass(o.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isClassLoadable(String className, Context context) {
/*     */     try {
/* 143 */       Class<?> aClass = loadClass(className, context);
/* 144 */       return true;
/* 145 */     } catch (ClassNotFoundException e) {
/* 146 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getClassLoaderOfClass(Class<?> clazz) {
/* 159 */     ClassLoader cl = clazz.getClassLoader();
/* 160 */     return systemClassloaderIfNull(cl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String clazz) throws ClassNotFoundException {
/* 171 */     if (ignoreTCL) {
/* 172 */       return Class.forName(clazz);
/*     */     }
/*     */     try {
/* 175 */       return getTCL().loadClass(clazz);
/* 176 */     } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */       
/* 180 */       return Class.forName(clazz);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\Loader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */