/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Duration
/*     */ {
/*     */   private static final String DOUBLE_PART = "([0-9]*(.[0-9]+)?)";
/*     */   private static final int DOUBLE_GROUP = 1;
/*     */   private static final String UNIT_PART = "(|milli(second)?|second(e)?|minute|hour|day)s?";
/*     */   private static final int UNIT_GROUP = 3;
/*  46 */   private static final Pattern DURATION_PATTERN = Pattern.compile("([0-9]*(.[0-9]+)?)\\s*(|milli(second)?|second(e)?|minute|hour|day)s?", 2);
/*     */   
/*     */   static final long SECONDS_COEFFICIENT = 1000L;
/*     */   
/*     */   static final long MINUTES_COEFFICIENT = 60000L;
/*     */   
/*     */   static final long HOURS_COEFFICIENT = 3600000L;
/*     */   static final long DAYS_COEFFICIENT = 86400000L;
/*     */   final long millis;
/*     */   
/*     */   public Duration(long millis) {
/*  57 */     this.millis = millis;
/*     */   }
/*     */   
/*     */   public static Duration buildByMilliseconds(double value) {
/*  61 */     return new Duration((long)value);
/*     */   }
/*     */   
/*     */   public static Duration buildBySeconds(double value) {
/*  65 */     return new Duration((long)(1000.0D * value));
/*     */   }
/*     */   
/*     */   public static Duration buildByMinutes(double value) {
/*  69 */     return new Duration((long)(60000.0D * value));
/*     */   }
/*     */   
/*     */   public static Duration buildByHours(double value) {
/*  73 */     return new Duration((long)(3600000.0D * value));
/*     */   }
/*     */   
/*     */   public static Duration buildByDays(double value) {
/*  77 */     return new Duration((long)(8.64E7D * value));
/*     */   }
/*     */   
/*     */   public static Duration buildUnbounded() {
/*  81 */     return new Duration(Long.MAX_VALUE);
/*     */   }
/*     */   
/*     */   public long getMilliseconds() {
/*  85 */     return this.millis;
/*     */   }
/*     */   
/*     */   public static Duration valueOf(String durationStr) {
/*  89 */     Matcher matcher = DURATION_PATTERN.matcher(durationStr);
/*     */     
/*  91 */     if (matcher.matches()) {
/*  92 */       String doubleStr = matcher.group(1);
/*  93 */       String unitStr = matcher.group(3);
/*     */       
/*  95 */       double doubleValue = Double.valueOf(doubleStr).doubleValue();
/*  96 */       if (unitStr.equalsIgnoreCase("milli") || unitStr.equalsIgnoreCase("millisecond") || unitStr.length() == 0)
/*  97 */         return buildByMilliseconds(doubleValue); 
/*  98 */       if (unitStr.equalsIgnoreCase("second") || unitStr.equalsIgnoreCase("seconde"))
/*  99 */         return buildBySeconds(doubleValue); 
/* 100 */       if (unitStr.equalsIgnoreCase("minute"))
/* 101 */         return buildByMinutes(doubleValue); 
/* 102 */       if (unitStr.equalsIgnoreCase("hour"))
/* 103 */         return buildByHours(doubleValue); 
/* 104 */       if (unitStr.equalsIgnoreCase("day")) {
/* 105 */         return buildByDays(doubleValue);
/*     */       }
/* 107 */       throw new IllegalStateException("Unexpected " + unitStr);
/*     */     } 
/*     */     
/* 110 */     throw new IllegalArgumentException("String value [" + durationStr + "] is not in the expected format.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 116 */     if (this.millis < 1000L)
/* 117 */       return "" + this.millis + " milliseconds"; 
/* 118 */     if (this.millis < 60000L)
/* 119 */       return "" + this.millis / 1000L + " seconds"; 
/* 120 */     if (this.millis < 3600000L) {
/* 121 */       return "" + this.millis / 60000L + " minutes";
/*     */     }
/* 123 */     return "" + this.millis / 3600000L + " hours";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\Duration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */