/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class COWArrayList<E>
/*     */   implements List<E>
/*     */ {
/*  58 */   AtomicBoolean fresh = new AtomicBoolean(false);
/*  59 */   CopyOnWriteArrayList<E> underlyingList = new CopyOnWriteArrayList<>();
/*     */   E[] ourCopy;
/*     */   final E[] modelArray;
/*     */   
/*     */   public COWArrayList(E[] modelArray) {
/*  64 */     this.modelArray = modelArray;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  69 */     return this.underlyingList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  74 */     return this.underlyingList.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/*  79 */     return this.underlyingList.contains(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/*  84 */     return this.underlyingList.iterator();
/*     */   }
/*     */   
/*     */   private void refreshCopyIfNecessary() {
/*  88 */     if (!isFresh()) {
/*  89 */       refreshCopy();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isFresh() {
/*  94 */     return this.fresh.get();
/*     */   }
/*     */   
/*     */   private void refreshCopy() {
/*  98 */     this.ourCopy = this.underlyingList.toArray(this.modelArray);
/*  99 */     this.fresh.set(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 104 */     refreshCopyIfNecessary();
/* 105 */     return (Object[])this.ourCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] a) {
/* 111 */     refreshCopyIfNecessary();
/* 112 */     return (T[])this.ourCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E[] asTypedArray() {
/* 123 */     refreshCopyIfNecessary();
/* 124 */     return this.ourCopy;
/*     */   }
/*     */   
/*     */   private void markAsStale() {
/* 128 */     this.fresh.set(false);
/*     */   }
/*     */   
/*     */   public void addIfAbsent(E e) {
/* 132 */     this.underlyingList.addIfAbsent(e);
/* 133 */     markAsStale();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E e) {
/* 138 */     boolean result = this.underlyingList.add(e);
/* 139 */     markAsStale();
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 145 */     boolean result = this.underlyingList.remove(o);
/* 146 */     markAsStale();
/* 147 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 152 */     return this.underlyingList.containsAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> c) {
/* 157 */     markAsStale();
/* 158 */     boolean result = this.underlyingList.addAll(c);
/* 159 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection<? extends E> col) {
/* 164 */     markAsStale();
/* 165 */     boolean result = this.underlyingList.addAll(index, col);
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> col) {
/* 171 */     markAsStale();
/* 172 */     boolean result = this.underlyingList.removeAll(col);
/* 173 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> col) {
/* 178 */     markAsStale();
/* 179 */     boolean result = this.underlyingList.retainAll(col);
/* 180 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 185 */     markAsStale();
/* 186 */     this.underlyingList.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int index) {
/* 191 */     refreshCopyIfNecessary();
/* 192 */     return this.ourCopy[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public E set(int index, E element) {
/* 197 */     markAsStale();
/* 198 */     E e = this.underlyingList.set(index, element);
/* 199 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int index, E element) {
/* 204 */     markAsStale();
/* 205 */     this.underlyingList.add(index, element);
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove(int index) {
/* 210 */     markAsStale();
/* 211 */     E e = this.underlyingList.remove(index);
/* 212 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 217 */     return this.underlyingList.indexOf(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 222 */     return this.underlyingList.lastIndexOf(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 227 */     return this.underlyingList.listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(int index) {
/* 232 */     return this.underlyingList.listIterator(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> subList(int fromIndex, int toIndex) {
/* 237 */     return this.underlyingList.subList(fromIndex, toIndex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\COWArrayList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */