/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringUtil
/*    */ {
/*    */   public static String nullStringToEmpty(String input) {
/* 25 */     if (input != null) {
/* 26 */       return input;
/*    */     }
/* 28 */     return "";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isNullOrEmpty(String str) {
/* 38 */     return (str == null || str.isEmpty());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean notNullNorEmpty(String str) {
/* 48 */     return !isNullOrEmpty(str);
/*    */   }
/*    */   
/*    */   public static String capitalizeFirstLetter(String name) {
/* 52 */     if (isNullOrEmpty(name)) {
/* 53 */       return name;
/*    */     }
/* 55 */     if (name.length() == 1) {
/* 56 */       return name.toUpperCase();
/*    */     }
/* 58 */     return name.substring(0, 1).toUpperCase() + name.substring(0, 1).toUpperCase();
/*    */   }
/*    */   
/*    */   public static String lowercaseFirstLetter(String name) {
/* 62 */     if (isNullOrEmpty(name)) {
/* 63 */       return name;
/*    */     }
/* 65 */     if (name.length() == 1) {
/* 66 */       return name.toLowerCase();
/*    */     }
/* 68 */     return name.substring(0, 1).toLowerCase() + name.substring(0, 1).toLowerCase();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\StringUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */