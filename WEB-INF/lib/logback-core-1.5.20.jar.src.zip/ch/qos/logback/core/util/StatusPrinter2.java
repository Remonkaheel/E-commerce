/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import ch.qos.logback.core.helpers.ThrowableToStringArray;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.status.StatusUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusPrinter2
/*     */ {
/*  40 */   private PrintStream ps = System.out;
/*     */   
/*  42 */   static CachingDateFormatter cachingDateFormat = new CachingDateFormatter("HH:mm:ss,SSS");
/*     */   
/*     */   public void setPrintStream(PrintStream printStream) {
/*  45 */     this.ps = printStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printInCaseOfErrorsOrWarnings(Context context) {
/*  55 */     printInCaseOfErrorsOrWarnings(context, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printInCaseOfErrorsOrWarnings(Context context, long threshold) {
/*  66 */     if (context == null) {
/*  67 */       throw new IllegalArgumentException("Context argument cannot be null");
/*     */     }
/*     */     
/*  70 */     StatusManager sm = context.getStatusManager();
/*  71 */     if (sm == null) {
/*  72 */       this.ps.println("WARN: Context named \"" + context.getName() + "\" has no status manager");
/*     */     } else {
/*  74 */       StatusUtil statusUtil = new StatusUtil(context);
/*  75 */       if (statusUtil.getHighestLevel(threshold) >= 1) {
/*  76 */         print(sm, threshold);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printIfErrorsOccured(Context context) {
/*  87 */     if (context == null) {
/*  88 */       throw new IllegalArgumentException("Context argument cannot be null");
/*     */     }
/*     */     
/*  91 */     StatusManager sm = context.getStatusManager();
/*  92 */     if (sm == null) {
/*  93 */       this.ps.println("WARN: Context named \"" + context.getName() + "\" has no status manager");
/*     */     } else {
/*  95 */       StatusUtil statusUtil = new StatusUtil(context);
/*  96 */       if (statusUtil.getHighestLevel(0L) == 2) {
/*  97 */         print(sm);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(Context context) {
/* 108 */     print(context, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(Context context, long threshold) {
/* 117 */     if (context == null) {
/* 118 */       throw new IllegalArgumentException("Context argument cannot be null");
/*     */     }
/*     */     
/* 121 */     StatusManager sm = context.getStatusManager();
/* 122 */     if (sm == null) {
/* 123 */       this.ps.println("WARN: Context named \"" + context.getName() + "\" has no status manager");
/*     */     } else {
/* 125 */       print(sm, threshold);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void print(StatusManager sm) {
/* 130 */     print(sm, 0L);
/*     */   }
/*     */   
/*     */   public void print(StatusManager sm, long threshold) {
/* 134 */     StringBuilder sb = new StringBuilder();
/* 135 */     List<Status> filteredList = StatusUtil.filterStatusListByTimeThreshold(sm.getCopyOfStatusList(), threshold);
/* 136 */     buildStrFromStatusList(sb, filteredList);
/* 137 */     this.ps.println(sb.toString());
/*     */   }
/*     */   
/*     */   public void print(List<Status> statusList) {
/* 141 */     StringBuilder sb = new StringBuilder();
/* 142 */     buildStrFromStatusList(sb, statusList);
/* 143 */     this.ps.println(sb.toString());
/*     */   }
/*     */   
/*     */   private void buildStrFromStatusList(StringBuilder sb, List<Status> statusList) {
/* 147 */     if (statusList == null)
/*     */       return; 
/* 149 */     for (Status s : statusList) {
/* 150 */       buildStr(sb, "", s);
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendThrowable(StringBuilder sb, Throwable t) {
/* 155 */     String[] stringRep = ThrowableToStringArray.convert(t);
/*     */     
/* 157 */     for (String s : stringRep) {
/* 158 */       if (!s.startsWith("Caused by: "))
/*     */       {
/* 160 */         if (Character.isDigit(s.charAt(0))) {
/*     */           
/* 162 */           sb.append("\t... ");
/*     */         } else {
/*     */           
/* 165 */           sb.append("\tat ");
/*     */         }  } 
/* 167 */       sb.append(s).append(CoreConstants.LINE_SEPARATOR);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void buildStr(StringBuilder sb, String indentation, Status s) {
/*     */     String prefix;
/* 173 */     if (s.hasChildren()) {
/* 174 */       prefix = indentation + "+ ";
/*     */     } else {
/* 176 */       prefix = indentation + "|-";
/*     */     } 
/*     */     
/* 179 */     if (cachingDateFormat != null) {
/* 180 */       String dateStr = cachingDateFormat.format(s.getTimestamp());
/* 181 */       sb.append(dateStr).append(" ");
/*     */     } 
/* 183 */     sb.append(prefix).append(s).append(CoreConstants.LINE_SEPARATOR);
/*     */     
/* 185 */     if (s.getThrowable() != null) {
/* 186 */       appendThrowable(sb, s.getThrowable());
/*     */     }
/* 188 */     if (s.hasChildren()) {
/* 189 */       Iterator<Status> ite = s.iterator();
/* 190 */       while (ite.hasNext()) {
/* 191 */         Status child = ite.next();
/* 192 */         buildStr(sb, indentation + "  ", child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\StatusPrinter2.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */