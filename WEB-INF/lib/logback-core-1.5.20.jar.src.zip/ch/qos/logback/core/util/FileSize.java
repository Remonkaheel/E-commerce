/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileSize
/*     */ {
/*     */   private static final String LENGTH_PART = "([0-9]+)";
/*     */   private static final int DOUBLE_GROUP = 1;
/*     */   private static final String UNIT_PART = "(|kb|mb|gb)s?";
/*     */   private static final int UNIT_GROUP = 2;
/*  42 */   private static final Pattern FILE_SIZE_PATTERN = Pattern.compile("([0-9]+)\\s*(|kb|mb|gb)s?", 2);
/*     */   
/*     */   public static final long KB_COEFFICIENT = 1024L;
/*     */   
/*     */   public static final long MB_COEFFICIENT = 1048576L;
/*     */   
/*     */   public static final long GB_COEFFICIENT = 1073741824L;
/*     */   final long size;
/*     */   
/*     */   public FileSize(long size) {
/*  52 */     this.size = size;
/*     */   }
/*     */   
/*     */   public long getSize() {
/*  56 */     return this.size;
/*     */   }
/*     */   
/*     */   public static FileSize valueOf(String fileSizeStr) {
/*  60 */     Matcher matcher = FILE_SIZE_PATTERN.matcher(fileSizeStr);
/*     */ 
/*     */     
/*  63 */     if (matcher.matches()) {
/*  64 */       long coefficient; String lenStr = matcher.group(1);
/*  65 */       String unitStr = matcher.group(2);
/*     */       
/*  67 */       long lenValue = Long.valueOf(lenStr).longValue();
/*  68 */       if (unitStr.equalsIgnoreCase("")) {
/*  69 */         coefficient = 1L;
/*  70 */       } else if (unitStr.equalsIgnoreCase("kb")) {
/*  71 */         coefficient = 1024L;
/*  72 */       } else if (unitStr.equalsIgnoreCase("mb")) {
/*  73 */         coefficient = 1048576L;
/*  74 */       } else if (unitStr.equalsIgnoreCase("gb")) {
/*  75 */         coefficient = 1073741824L;
/*     */       } else {
/*  77 */         throw new IllegalStateException("Unexpected " + unitStr);
/*     */       } 
/*  79 */       return new FileSize(lenValue * coefficient);
/*     */     } 
/*  81 */     throw new IllegalArgumentException("String value [" + fileSizeStr + "] is not in the expected format.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  87 */     long inKB = this.size / 1024L;
/*     */     
/*  89 */     if (inKB == 0L) {
/*  90 */       return "" + this.size + " Bytes";
/*     */     }
/*  92 */     long inMB = this.size / 1048576L;
/*  93 */     if (inMB == 0L) {
/*  94 */       return "" + inKB + " KB";
/*     */     }
/*     */     
/*  97 */     long inGB = this.size / 1073741824L;
/*  98 */     if (inGB == 0L) {
/*  99 */       return "" + inMB + " MB";
/*     */     }
/*     */     
/* 102 */     return "" + inGB + " GB";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 108 */     if (this == o)
/* 109 */       return true; 
/* 110 */     if (o == null || getClass() != o.getClass())
/* 111 */       return false; 
/* 112 */     FileSize fileSize = (FileSize)o;
/* 113 */     return (this.size == fileSize.size);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     return Objects.hashCode(Long.valueOf(this.size));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\FileSize.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */