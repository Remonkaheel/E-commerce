/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.status.OnConsoleStatusListener;
/*    */ import ch.qos.logback.core.status.StatusListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusListenerConfigHelper
/*    */ {
/*    */   public static void installIfAsked(Context context) {
/* 30 */     String slClass = OptionHelper.getSystemProperty("logback.statusListenerClass");
/* 31 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(slClass)) {
/* 32 */       addStatusListener(context, slClass);
/*    */     }
/*    */   }
/*    */   
/*    */   private static void addStatusListener(Context context, String listenerClassName) {
/* 37 */     StatusListener listener = null;
/* 38 */     if ("SYSOUT".equalsIgnoreCase(listenerClassName) || "STDOUT".equalsIgnoreCase(listenerClassName)) {
/* 39 */       OnConsoleStatusListener onConsoleStatusListener = new OnConsoleStatusListener();
/*    */     } else {
/* 41 */       listener = createListenerPerClassName(context, listenerClassName);
/*    */     } 
/* 43 */     initAndAddListener(context, listener);
/*    */   }
/*    */   
/*    */   private static void initAndAddListener(Context context, StatusListener listener) {
/* 47 */     if (listener != null) {
/* 48 */       if (listener instanceof ContextAware) {
/* 49 */         ((ContextAware)listener).setContext(context);
/*    */       }
/* 51 */       boolean effectivelyAdded = context.getStatusManager().add(listener);
/* 52 */       if (effectivelyAdded && listener instanceof LifeCycle) {
/* 53 */         ((LifeCycle)listener).start();
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private static StatusListener createListenerPerClassName(Context context, String listenerClass) {
/*    */     try {
/* 60 */       return (StatusListener)OptionHelper.instantiateByClassName(listenerClass, StatusListener.class, context);
/* 61 */     } catch (Exception e) {
/*    */       
/* 63 */       e.printStackTrace();
/* 64 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void addOnConsoleListenerInstance(Context context, OnConsoleStatusListener onConsoleStatusListener) {
/* 76 */     onConsoleStatusListener.setContext(context);
/* 77 */     boolean effectivelyAdded = context.getStatusManager().add((StatusListener)onConsoleStatusListener);
/* 78 */     if (effectivelyAdded)
/* 79 */       onConsoleStatusListener.start(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\StatusListenerConfigHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */