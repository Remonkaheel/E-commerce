/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DirectJson
/*     */ {
/*     */   private static final int INITIAL_BUFFER_SIZE = 1024;
/*     */   private static final byte QUOTE = 34;
/*     */   private static final byte ENTRY_SEP = 58;
/*     */   private static final byte KV_SEP = 44;
/*     */   private static final byte DOT = 46;
/*     */   private static final byte OPEN_OBJ = 123;
/*     */   private static final byte CLOSE_OBJ = 125;
/*     */   private static final byte OPEN_ARR = 91;
/*     */   private static final byte CLOSE_ARR = 93;
/*  25 */   private static final byte[] NEWLINE = new byte[] { 92, 110 };
/*     */ 
/*     */ 
/*     */   
/*  29 */   private static final byte[] ESCAPE = new byte[] { 92, 92 };
/*     */ 
/*     */ 
/*     */   
/*  33 */   private static final byte[] LINEBREAK = new byte[] { 92, 114 };
/*     */ 
/*     */ 
/*     */   
/*  37 */   private static final byte[] TAB = new byte[] { 92, 116 };
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static final byte[] TRUE = new byte[] { 116, 114, 117, 101 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private static final byte[] FALSE = new byte[] { 102, 97, 108, 115, 101 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private static final byte[] NULL = new byte[] { 110, 117, 108, 108 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private ByteBuffer buffer = ByteBuffer.allocateDirect(1024);
/*     */   
/*     */   public void openObject() {
/*  67 */     this.buffer.put((byte)123); } public void openArray() {
/*  68 */     this.buffer.put((byte)91);
/*     */   }
/*     */   public void openObject(String str) {
/*  71 */     writeString(str);
/*  72 */     writeEntrySep();
/*  73 */     this.buffer.put((byte)123);
/*     */   }
/*     */   
/*     */   public void openArray(String str) {
/*  77 */     writeString(str);
/*  78 */     writeEntrySep();
/*  79 */     this.buffer.put((byte)91);
/*     */   }
/*     */   
/*     */   public void closeObject() {
/*  83 */     int target = this.buffer.position() - 1;
/*  84 */     if (44 == this.buffer.get(target)) {
/*  85 */       this.buffer.put(target, (byte)125);
/*     */     } else {
/*  87 */       this.buffer.put((byte)125);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void closeArray() {
/*  92 */     int target = this.buffer.position() - 1;
/*  93 */     if (44 == this.buffer.get(target)) {
/*  94 */       this.buffer.put(target, (byte)93);
/*     */     } else {
/*  96 */       this.buffer.put((byte)93);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeRaw(String str) {
/* 101 */     for (int i = 0; i < str.length(); i++) {
/* 102 */       int chr = str.codePointAt(i);
/* 103 */       switch (chr) {
/*     */         case 92:
/* 105 */           this.buffer.put(ESCAPE);
/*     */           break;
/*     */         case 10:
/* 108 */           this.buffer.put(NEWLINE);
/*     */           break;
/*     */         case 13:
/* 111 */           this.buffer.put(LINEBREAK);
/*     */           break;
/*     */         case 9:
/* 114 */           this.buffer.put(TAB);
/*     */           break;
/*     */         default:
/* 117 */           if (chr >= 128 && chr <= 1114111) {
/* 118 */             this.buffer.put(String.valueOf(str.charAt(i)).getBytes()); break;
/* 119 */           }  if (chr > 31) this.buffer.put((byte)chr); 
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 125 */   public void writeRaw(char chr) { this.buffer.put((byte)chr); } public void writeRaw(byte[] chr) {
/* 126 */     this.buffer.put(chr);
/*     */   } public void writeQuote() {
/* 128 */     this.buffer.put((byte)34);
/*     */   } public void writeString(String str) {
/* 130 */     checkSpace(str.length() + 3);
/* 131 */     this.buffer.put((byte)34);
/* 132 */     writeRaw(str);
/* 133 */     this.buffer.put((byte)34);
/* 134 */     this.buffer.put((byte)44);
/*     */   } public void writeSep() {
/* 136 */     this.buffer.put((byte)44);
/*     */   }
/*     */   public void writeNumberRaw(long data) {
/* 139 */     int pos = this.buffer.position();
/* 140 */     int sz = (int)Math.log10(data) + 1;
/* 141 */     long dataPointer = data;
/*     */     
/* 143 */     for (int i = sz - 1; i >= 0; i--) {
/* 144 */       byte chr = (byte)(int)(dataPointer % 10L);
/* 145 */       dataPointer /= 10L;
/* 146 */       chr = (byte)(chr + 48);
/* 147 */       this.buffer.put(pos + i, chr);
/*     */     } 
/*     */     
/* 150 */     this.buffer.position(pos + sz);
/*     */   }
/*     */   
/*     */   public void writeNumber(long data) {
/* 154 */     int pos = this.buffer.position();
/* 155 */     int sz = (data == 0L) ? 1 : ((int)Math.log10(data) + 1);
/* 156 */     long dataPointer = data;
/*     */     
/* 158 */     for (int i = sz - 1; i >= 0; i--) {
/* 159 */       byte chr = (byte)(int)(dataPointer % 10L);
/* 160 */       dataPointer /= 10L;
/* 161 */       chr = (byte)(chr + 48);
/* 162 */       this.buffer.put(pos + i, chr);
/*     */     } 
/*     */     
/* 165 */     this.buffer.position(pos + sz);
/* 166 */     this.buffer.put((byte)44);
/*     */   }
/*     */   
/*     */   public void writeNumber(double data) {
/* 170 */     int pos = this.buffer.position();
/* 171 */     long whole = (long)data;
/* 172 */     int sz = (int)Math.log10(whole) + 1;
/*     */     
/* 174 */     for (int i = sz - 1; i >= 0; i--) {
/* 175 */       byte chr = (byte)(int)(whole % 10L);
/* 176 */       whole /= 10L;
/* 177 */       chr = (byte)(chr + 48);
/* 178 */       this.buffer.put(pos + i, chr);
/*     */     } 
/* 180 */     this.buffer.position(pos + sz);
/* 181 */     this.buffer.put((byte)46);
/* 182 */     pos = this.buffer.position();
/* 183 */     BigDecimal fractional = BigDecimal.valueOf(data).remainder(BigDecimal.ONE);
/* 184 */     int decs = 0;
/* 185 */     while (!fractional.equals(BigDecimal.ZERO)) {
/* 186 */       fractional = fractional.movePointRight(1);
/* 187 */       byte chr = (byte)(fractional.intValue() + 48);
/* 188 */       fractional = fractional.remainder(BigDecimal.ONE);
/* 189 */       decs++;
/* 190 */       this.buffer.put(chr);
/*     */     } 
/*     */     
/* 193 */     this.buffer.position(pos + decs);
/* 194 */     this.buffer.put((byte)44);
/*     */   }
/*     */   public void writeEntrySep() {
/* 197 */     this.buffer.put(this.buffer.position() - 1, (byte)58);
/*     */   }
/*     */   public void writeStringValue(String key, String value) {
/* 200 */     writeString(key);
/* 201 */     writeEntrySep();
/* 202 */     writeString(value);
/*     */   }
/*     */   
/*     */   public void writeNumberValue(String key, long value) {
/* 206 */     writeString(key);
/* 207 */     writeEntrySep();
/* 208 */     writeNumber(value);
/*     */   }
/*     */   
/*     */   public void writeNumberValue(String key, double value) {
/* 212 */     writeString(key);
/* 213 */     writeEntrySep();
/* 214 */     writeNumber(value);
/*     */   }
/*     */   
/*     */   public void writeBoolean(boolean value) {
/* 218 */     this.buffer.put(value ? TRUE : FALSE);
/* 219 */     this.buffer.put((byte)44);
/*     */   }
/*     */   
/*     */   public void writeNull() {
/* 223 */     this.buffer.put(NULL);
/* 224 */     this.buffer.put((byte)44);
/*     */   }
/*     */   
/*     */   public void checkSpace(int size) {
/* 228 */     if (this.buffer.position() + size >= this.buffer.capacity()) {
/* 229 */       int newSize = (this.buffer.capacity() + size) * 2;
/* 230 */       ByteBuffer newBuffer = ByteBuffer.allocateDirect(newSize);
/* 231 */       this.buffer.flip();
/* 232 */       newBuffer.put(this.buffer);
/* 233 */       this.buffer = newBuffer;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] flush() {
/* 238 */     byte[] result = new byte[this.buffer.position()];
/* 239 */     this.buffer.flip();
/* 240 */     this.buffer.get(result);
/* 241 */     this.buffer.clear();
/*     */     
/* 243 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\DirectJson.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */