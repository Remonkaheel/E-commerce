/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.status.Status;
/*    */ import ch.qos.logback.core.status.StatusManager;
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusPrinter
/*    */ {
/* 31 */   private static final StatusPrinter2 SINGLETON = new StatusPrinter2();
/*    */   
/*    */   public static void setPrintStream(PrintStream printStream) {
/* 34 */     SINGLETON.setPrintStream(printStream);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void printInCaseOfErrorsOrWarnings(Context context) {
/* 44 */     SINGLETON.printInCaseOfErrorsOrWarnings(context, 0L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void printInCaseOfErrorsOrWarnings(Context context, long threshold) {
/* 55 */     SINGLETON.printInCaseOfErrorsOrWarnings(context, threshold);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void printIfErrorsOccured(Context context) {
/* 64 */     SINGLETON.printIfErrorsOccured(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void print(Context context) {
/* 73 */     SINGLETON.print(context, 0L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void print(Context context, long threshold) {
/* 83 */     SINGLETON.print(context, threshold);
/*    */   }
/*    */   
/*    */   public static void print(StatusManager sm) {
/* 87 */     SINGLETON.print(sm, 0L);
/*    */   }
/*    */   
/*    */   public static void print(StatusManager sm, long threshold) {
/* 91 */     SINGLETON.print(sm, threshold);
/*    */   }
/*    */   
/*    */   public static void print(List<Status> statusList) {
/* 95 */     SINGLETON.print(statusList);
/*    */   }
/*    */   
/*    */   public static void buildStr(StringBuilder sb, String indentation, Status s) {
/* 99 */     SINGLETON.buildStr(sb, indentation, s);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\StatusPrinter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */