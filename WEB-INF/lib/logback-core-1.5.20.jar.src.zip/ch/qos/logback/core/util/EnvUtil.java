/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import java.lang.module.ModuleDescriptor;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnvUtil
/*     */ {
/*     */   public static String logbackVersion() {
/*  37 */     String moduleVersion = getVersionOfLogbackCoreByModule();
/*  38 */     if (moduleVersion != null) {
/*  39 */       return moduleVersion;
/*     */     }
/*  41 */     Package pkg = EnvUtil.class.getPackage();
/*  42 */     if (pkg == null) {
/*  43 */       return null;
/*     */     }
/*  45 */     return pkg.getImplementationVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getVersionOfLogbackCoreByModule() {
/*  57 */     Module module = EnvUtil.class.getModule();
/*  58 */     if (module == null) {
/*  59 */       return null;
/*     */     }
/*  61 */     ModuleDescriptor md = module.getDescriptor();
/*  62 */     if (md == null)
/*  63 */       return null; 
/*  64 */     Optional<String> opt = md.rawVersion();
/*  65 */     return opt.orElse(null);
/*     */   }
/*     */   
/*     */   public static int getJDKVersion(String javaVersionStr) {
/*  69 */     int version = 0;
/*     */     
/*  71 */     for (char ch : javaVersionStr.toCharArray()) {
/*  72 */       if (Character.isDigit(ch)) {
/*  73 */         version = version * 10 + ch - 48;
/*  74 */       } else if (version == 1) {
/*  75 */         version = 0;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*  80 */     return version;
/*     */   }
/*     */   
/*     */   private static boolean isJDK_N_OrHigher(int n) {
/*  84 */     String javaVersionStr = System.getProperty("java.version", "");
/*  85 */     if (javaVersionStr.isEmpty()) {
/*  86 */       return false;
/*     */     }
/*  88 */     int version = getJDKVersion(javaVersionStr);
/*  89 */     return (version > 0 && n <= version);
/*     */   }
/*     */   
/*     */   public static boolean isJDK5() {
/*  93 */     return isJDK_N_OrHigher(5);
/*     */   }
/*     */   
/*     */   public static boolean isJDK6OrHigher() {
/*  97 */     return isJDK_N_OrHigher(6);
/*     */   }
/*     */   
/*     */   public static boolean isJDK7OrHigher() {
/* 101 */     return isJDK_N_OrHigher(7);
/*     */   }
/*     */   
/*     */   public static boolean isJDK16OrHigher() {
/* 105 */     return isJDK_N_OrHigher(16);
/*     */   }
/*     */   
/*     */   public static boolean isJDK18OrHigher() {
/* 109 */     return isJDK_N_OrHigher(18);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJDK21OrHigher() {
/* 117 */     return isJDK_N_OrHigher(21);
/*     */   }
/*     */   
/*     */   public static boolean isJaninoAvailable() {
/* 121 */     ClassLoader classLoader = EnvUtil.class.getClassLoader();
/*     */     try {
/* 123 */       Class<?> bindingClass = classLoader.loadClass("org.codehaus.janino.ScriptEvaluator");
/* 124 */       return (bindingClass != null);
/* 125 */     } catch (ClassNotFoundException e) {
/* 126 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isMacOs() {
/* 131 */     String os = System.getProperty("os.name");
/*     */     
/* 133 */     return os.toLowerCase().contains("mac");
/*     */   }
/*     */   
/*     */   public static boolean isWindows() {
/* 137 */     String os = System.getProperty("os.name");
/* 138 */     return os.startsWith("Windows");
/*     */   }
/*     */   
/*     */   public static boolean isClassAvailable(Class<?> callerClass, String className) {
/* 142 */     ClassLoader classLoader = Loader.getClassLoaderOfClass(callerClass);
/*     */     try {
/* 144 */       Class<?> bindingClass = classLoader.loadClass(className);
/* 145 */       return (bindingClass != null);
/* 146 */     } catch (ClassNotFoundException e) {
/* 147 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\EnvUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */