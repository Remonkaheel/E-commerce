/*     */ package ch.qos.logback.core.util;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import ch.qos.logback.core.subst.NodeToStringTransformer;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionHelper
/*     */ {
/*     */   static final String DELIM_START = "${";
/*     */   static final char DELIM_STOP = '}';
/*     */   static final String DELIM_DEFAULT = ":-";
/*     */   static final int DELIM_START_LEN = 2;
/*     */   static final int DELIM_STOP_LEN = 1;
/*     */   static final int DELIM_DEFAULT_LEN = 2;
/*     */   static final String _IS_UNDEFINED = "_IS_UNDEFINED";
/*     */   
/*     */   public static Object instantiateByClassName(String className, Class<?> superClass, Context context) throws IncompatibleClassException, DynamicClassLoadingException {
/*  32 */     ClassLoader classLoader = Loader.getClassLoaderOfObject(context);
/*  33 */     return instantiateByClassName(className, superClass, classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object instantiateByClassNameAndParameter(String className, Class<?> superClass, Context context, Class<?> type, Object param) throws IncompatibleClassException, DynamicClassLoadingException {
/*  38 */     ClassLoader classLoader = Loader.getClassLoaderOfObject(context);
/*  39 */     return instantiateByClassNameAndParameter(className, superClass, classLoader, type, param);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object instantiateByClassName(String className, Class<?> superClass, ClassLoader classLoader) throws IncompatibleClassException, DynamicClassLoadingException {
/*  44 */     return instantiateByClassNameAndParameter(className, superClass, classLoader, (Class<?>)null, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object instantiateByClassNameAndParameter(String className, Class<?> superClass, ClassLoader classLoader, Class<?> type, Object parameter) throws IncompatibleClassException, DynamicClassLoadingException {
/*  51 */     if (className == null) {
/*  52 */       throw new NullPointerException();
/*     */     }
/*     */     try {
/*  55 */       Class<?> classObj = null;
/*  56 */       classObj = classLoader.loadClass(className);
/*  57 */       if (!superClass.isAssignableFrom(classObj)) {
/*  58 */         throw new IncompatibleClassException(superClass, classObj);
/*     */       }
/*  60 */       if (type == null) {
/*  61 */         return classObj.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */       }
/*  63 */       Constructor<?> constructor = classObj.getConstructor(new Class[] { type });
/*  64 */       return constructor.newInstance(new Object[] { parameter });
/*     */     }
/*  66 */     catch (IncompatibleClassException ice) {
/*  67 */       throw ice;
/*  68 */     } catch (Throwable t) {
/*  69 */       throw new DynamicClassLoadingException("Failed to instantiate type " + className, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String substVars(String val, PropertyContainer pc1) throws ScanException {
/* 104 */     return substVars(val, pc1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String substVars(String input, PropertyContainer pc0, PropertyContainer pc1) throws ScanException {
/* 112 */     return NodeToStringTransformer.substituteVariable(input, pc0, pc1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String propertyLookup(String key, PropertyContainer pc1, PropertyContainer pc2) {
/* 131 */     String value = null;
/*     */     
/* 133 */     value = pc1.getProperty(key);
/*     */ 
/*     */     
/* 136 */     if (value == null && pc2 != null) {
/* 137 */       value = pc2.getProperty(key);
/*     */     }
/*     */     
/* 140 */     if (value == null) {
/* 141 */       value = getSystemProperty(key, null);
/*     */     }
/* 143 */     if (value == null) {
/* 144 */       value = getEnv(key);
/*     */     }
/* 146 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSystemProperty(String key, String def) {
/*     */     try {
/* 160 */       return System.getProperty(key, def);
/* 161 */     } catch (SecurityException e) {
/* 162 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEnv(String key) {
/*     */     try {
/* 174 */       return System.getenv(key);
/* 175 */     } catch (SecurityException e) {
/* 176 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSystemProperty(String key) {
/*     */     try {
/* 189 */       return System.getProperty(key);
/* 190 */     } catch (SecurityException e) {
/* 191 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setSystemProperties(ContextAware contextAware, Properties props) {
/* 196 */     for (Object o : props.keySet()) {
/* 197 */       String key = (String)o;
/* 198 */       String value = props.getProperty(key);
/* 199 */       setSystemProperty(contextAware, key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setSystemProperty(ContextAware contextAware, String key, String value) {
/*     */     try {
/* 205 */       System.setProperty(key, value);
/* 206 */     } catch (SecurityException e) {
/* 207 */       contextAware.addError("Failed to set system property [" + key + "]", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getSystemProperties() {
/*     */     try {
/* 219 */       return System.getProperties();
/* 220 */     } catch (SecurityException e) {
/* 221 */       return new Properties();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] extractDefaultReplacement(String key) {
/* 234 */     String[] result = new String[2];
/* 235 */     if (key == null) {
/* 236 */       return result;
/*     */     }
/* 238 */     result[0] = key;
/* 239 */     int d = key.indexOf(":-");
/* 240 */     if (d != -1) {
/* 241 */       result[0] = key.substring(0, d);
/* 242 */       result[1] = key.substring(d + 2);
/*     */     } 
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(String value, boolean dEfault) {
/* 255 */     if (value == null) {
/* 256 */       return dEfault;
/*     */     }
/*     */     
/* 259 */     String trimmedVal = value.trim();
/*     */     
/* 261 */     if ("true".equalsIgnoreCase(trimmedVal)) {
/* 262 */       return true;
/*     */     }
/*     */     
/* 265 */     if ("false".equalsIgnoreCase(trimmedVal)) {
/* 266 */       return false;
/*     */     }
/*     */     
/* 269 */     return dEfault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(String str) {
/* 277 */     return isNullOrEmptyOrAllSpaces(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNullOrEmpty(String str) {
/* 287 */     return (str == null || str.trim().length() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNullOrEmptyOrAllSpaces(String str) {
/* 297 */     return (str == null || str.trim().length() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean isNullOrEmpty(Object[] array) {
/* 302 */     if (array == null || array.length == 0) {
/* 303 */       return true;
/*     */     }
/* 305 */     return false;
/*     */   }
/*     */   
/*     */   public static final boolean isNotEmtpy(Object[] array) {
/* 309 */     return !isNullOrEmpty(array);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\cor\\util\OptionHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */