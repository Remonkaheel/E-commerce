/*    */ package ch.qos.logback.core.filter;
/*    */ 
/*    */ import ch.qos.logback.core.boolex.EvaluationException;
/*    */ import ch.qos.logback.core.boolex.EventEvaluator;
/*    */ import ch.qos.logback.core.spi.FilterReply;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EvaluatorFilter<E>
/*    */   extends AbstractMatcherFilter<E>
/*    */ {
/*    */   EventEvaluator<E> evaluator;
/*    */   
/*    */   public void start() {
/* 45 */     if (this.evaluator != null) {
/* 46 */       super.start();
/*    */     } else {
/* 48 */       addError("No evaluator set for filter " + getName());
/*    */     } 
/*    */   }
/*    */   
/*    */   public EventEvaluator<E> getEvaluator() {
/* 53 */     return this.evaluator;
/*    */   }
/*    */   
/*    */   public void setEvaluator(EventEvaluator<E> evaluator) {
/* 57 */     this.evaluator = evaluator;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterReply decide(E event) {
/* 63 */     if (!isStarted() || !this.evaluator.isStarted()) {
/* 64 */       return FilterReply.NEUTRAL;
/*    */     }
/*    */     try {
/* 67 */       if (this.evaluator.evaluate(event)) {
/* 68 */         return this.onMatch;
/*    */       }
/* 70 */       return this.onMismatch;
/*    */     }
/* 72 */     catch (EvaluationException e) {
/* 73 */       addError("Evaluator " + this.evaluator.getName() + " threw an exception", (Throwable)e);
/* 74 */       return FilterReply.NEUTRAL;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\filter\EvaluatorFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */