/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.filter.Filter;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.FilterAttachableImpl;
/*     */ import ch.qos.logback.core.spi.FilterReply;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.WarnStatus;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UnsynchronizedAppenderBase<E>
/*     */   extends ContextAwareBase
/*     */   implements Appender<E>
/*     */ {
/*     */   protected volatile boolean started = false;
/*  43 */   private ThreadLocal<Boolean> guard = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected String name;
/*     */ 
/*     */   
/*  50 */   private FilterAttachableImpl<E> fai = new FilterAttachableImpl();
/*     */   
/*     */   public String getName() {
/*  53 */     return this.name;
/*     */   }
/*     */   
/*  56 */   private int statusRepeatCount = 0;
/*  57 */   private int exceptionCount = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int ALLOWED_REPEATS = 3;
/*     */ 
/*     */ 
/*     */   
/*     */   public void doAppend(E eventObject) {
/*  66 */     if (Boolean.TRUE.equals(this.guard.get())) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  71 */       this.guard.set(Boolean.TRUE);
/*     */       
/*  73 */       if (!this.started) {
/*  74 */         if (this.statusRepeatCount++ < 3) {
/*  75 */           addStatus((Status)new WarnStatus("Attempted to append to non started appender [" + this.name + "].", this));
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/*  80 */       if (getFilterChainDecision(eventObject) == FilterReply.DENY) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  85 */       append(eventObject);
/*     */     }
/*  87 */     catch (Exception e) {
/*  88 */       if (this.exceptionCount++ < 3) {
/*  89 */         addError("Appender [" + this.name + "] failed to append.", e);
/*     */       }
/*     */     } finally {
/*  92 */       this.guard.set(Boolean.FALSE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void append(E paramE);
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 102 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void start() {
/* 106 */     this.started = true;
/*     */   }
/*     */   
/*     */   public void stop() {
/* 110 */     this.started = false;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 114 */     return this.started;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 118 */     return getClass().getName() + "[" + getClass().getName() + "]";
/*     */   }
/*     */   
/*     */   public void addFilter(Filter<E> newFilter) {
/* 122 */     this.fai.addFilter(newFilter);
/*     */   }
/*     */   
/*     */   public void clearAllFilters() {
/* 126 */     this.fai.clearAllFilters();
/*     */   }
/*     */   
/*     */   public List<Filter<E>> getCopyOfAttachedFiltersList() {
/* 130 */     return this.fai.getCopyOfAttachedFiltersList();
/*     */   }
/*     */   
/*     */   public FilterReply getFilterChainDecision(E event) {
/* 134 */     return this.fai.getFilterChainDecision(event);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\UnsynchronizedAppenderBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */