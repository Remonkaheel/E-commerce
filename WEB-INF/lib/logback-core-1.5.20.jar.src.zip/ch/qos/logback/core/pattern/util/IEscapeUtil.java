package ch.qos.logback.core.pattern.util;

public interface IEscapeUtil {
  void escape(String paramString, StringBuffer paramStringBuffer, char paramChar, int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\patter\\util\IEscapeUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */