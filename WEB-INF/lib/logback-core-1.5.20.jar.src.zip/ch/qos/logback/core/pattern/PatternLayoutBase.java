/*     */ package ch.qos.logback.core.pattern;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.LayoutBase;
/*     */ import ch.qos.logback.core.pattern.color.ConverterSupplierByClassName;
/*     */ import ch.qos.logback.core.pattern.parser.Node;
/*     */ import ch.qos.logback.core.pattern.parser.Parser;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PatternLayoutBase<E>
/*     */   extends LayoutBase<E>
/*     */ {
/*     */   static final int INTIAL_STRING_BUILDER_SIZE = 256;
/*     */   Converter<E> head;
/*     */   String pattern;
/*     */   protected PostCompileProcessor<E> postCompileProcessor;
/*  45 */   Map<String, Supplier<DynamicConverter>> instanceConverterMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean outputPatternAsHeader = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Map<String, Supplier<DynamicConverter>> getDefaultConverterSupplierMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract Map<String, String> getDefaultConverterMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Supplier<DynamicConverter>> getEffectiveConverterMap() {
/*  76 */     Map<String, Supplier<DynamicConverter>> effectiveMap = new HashMap<>();
/*     */ 
/*     */     
/*  79 */     Map<String, Supplier<DynamicConverter>> defaultConverterSupplierMap = getDefaultConverterSupplierMap();
/*  80 */     if (defaultConverterSupplierMap != null) {
/*  81 */       effectiveMap.putAll(defaultConverterSupplierMap);
/*     */     }
/*     */     
/*  84 */     caterForLegacyConverterMaps(effectiveMap);
/*     */ 
/*     */     
/*  87 */     Context context = getContext();
/*  88 */     if (context != null) {
/*     */ 
/*     */       
/*  91 */       Map<String, Supplier<DynamicConverter>> contextMap = (Map<String, Supplier<DynamicConverter>>)context.getObject("PATTERN_RULE_REGISTRY_FOR_SUPPLIERS");
/*  92 */       if (contextMap != null) {
/*  93 */         effectiveMap.putAll(contextMap);
/*     */       }
/*     */     } 
/*     */     
/*  97 */     effectiveMap.putAll(this.instanceConverterMap);
/*  98 */     return effectiveMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void caterForLegacyConverterMaps(Map<String, Supplier<DynamicConverter>> effectiveMap) {
/* 109 */     Map<String, String> mapFromContext = (Map<String, String>)this.context.getObject("PATTERN_RULE_REGISTRY");
/*     */     
/* 111 */     migrateFromStringMapToSupplierMap(mapFromContext, effectiveMap);
/*     */     
/* 113 */     Map<String, String> defaultConverterMap = getDefaultConverterMap();
/* 114 */     migrateFromStringMapToSupplierMap(defaultConverterMap, effectiveMap);
/*     */   }
/*     */   
/*     */   private void migrateFromStringMapToSupplierMap(Map<String, String> legacyMap, Map<String, Supplier<DynamicConverter>> targetSupplierMap) {
/* 118 */     if (legacyMap == null) {
/*     */       return;
/*     */     }
/*     */     
/* 122 */     for (Map.Entry<String, String> entry : legacyMap.entrySet()) {
/* 123 */       String key = entry.getKey();
/* 124 */       String converterClassName = entry.getValue();
/* 125 */       ConverterSupplierByClassName converterSupplierByClassName = new ConverterSupplierByClassName(key, converterClassName);
/* 126 */       converterSupplierByClassName.setContext(getContext());
/* 127 */       targetSupplierMap.put(key, converterSupplierByClassName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/* 133 */     if (this.pattern == null || this.pattern.length() == 0) {
/* 134 */       addError("Empty or null pattern.");
/*     */       return;
/*     */     } 
/*     */     try {
/* 138 */       Parser<E> p = new Parser(this.pattern);
/* 139 */       if (getContext() != null) {
/* 140 */         p.setContext(getContext());
/*     */       }
/* 142 */       Node t = p.parse();
/* 143 */       this.head = p.compile(t, getEffectiveConverterMap());
/* 144 */       if (this.postCompileProcessor != null) {
/* 145 */         this.postCompileProcessor.process(this.context, this.head);
/*     */       }
/* 147 */       ConverterUtil.setContextForConverters(getContext(), this.head);
/* 148 */       ConverterUtil.startConverters(this.head);
/* 149 */       super.start();
/* 150 */     } catch (ScanException sce) {
/* 151 */       StatusManager sm = getContext().getStatusManager();
/* 152 */       sm.add((Status)new ErrorStatus("Failed to parse pattern \"" + getPattern() + "\".", this, (Throwable)sce));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPostCompileProcessor(PostCompileProcessor<E> postCompileProcessor) {
/* 157 */     this.postCompileProcessor = postCompileProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setContextForConverters(Converter<E> head) {
/* 167 */     ConverterUtil.setContextForConverters(getContext(), head);
/*     */   }
/*     */   
/*     */   protected String writeLoopOnConverters(E event) {
/* 171 */     StringBuilder strBuilder = new StringBuilder(256);
/* 172 */     Converter<E> c = this.head;
/* 173 */     while (c != null) {
/* 174 */       c.write(strBuilder, event);
/* 175 */       c = c.getNext();
/*     */     } 
/* 177 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */   public String getPattern() {
/* 181 */     return this.pattern;
/*     */   }
/*     */   
/*     */   public void setPattern(String pattern) {
/* 185 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 189 */     return getClass().getName() + "(\"" + getClass().getName() + "\")";
/*     */   }
/*     */   
/*     */   public Map<String, Supplier<DynamicConverter>> getInstanceConverterMap() {
/* 193 */     return this.instanceConverterMap;
/*     */   }
/*     */   
/*     */   protected String getPresentationHeaderPrefix() {
/* 197 */     return "";
/*     */   }
/*     */   
/*     */   public boolean isOutputPatternAsHeader() {
/* 201 */     return this.outputPatternAsHeader;
/*     */   }
/*     */   
/*     */   public void setOutputPatternAsHeader(boolean outputPatternAsHeader) {
/* 205 */     this.outputPatternAsHeader = outputPatternAsHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPresentationHeader() {
/* 210 */     if (this.outputPatternAsHeader) {
/* 211 */       return getPresentationHeaderPrefix() + getPresentationHeaderPrefix();
/*     */     }
/* 213 */     return super.getPresentationHeader();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\PatternLayoutBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */