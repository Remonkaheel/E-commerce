/*     */ package ch.qos.logback.core.pattern;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DynamicConverter<E>
/*     */   extends FormattingConverter<E>
/*     */   implements LifeCycle, ContextAware
/*     */ {
/*  33 */   ContextAwareBase cab = new ContextAwareBase(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> optionList;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean started = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  51 */     this.started = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/*  56 */     this.started = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStarted() {
/*  61 */     return this.started;
/*     */   }
/*     */   
/*     */   public void setOptionList(List<String> optionList) {
/*  65 */     this.optionList = optionList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFirstOption() {
/*  75 */     if (this.optionList == null || this.optionList.size() == 0) {
/*  76 */       return null;
/*     */     }
/*  78 */     return this.optionList.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<String> getOptionList() {
/*  83 */     return this.optionList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContext(Context context) {
/*  88 */     this.cab.setContext(context);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context getContext() {
/*  93 */     return this.cab.getContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addStatus(Status status) {
/*  98 */     this.cab.addStatus(status);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInfo(String msg) {
/* 103 */     this.cab.addInfo(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInfo(String msg, Throwable ex) {
/* 108 */     this.cab.addInfo(msg, ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addWarn(String msg) {
/* 113 */     this.cab.addWarn(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addWarn(String msg, Throwable ex) {
/* 118 */     this.cab.addWarn(msg, ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addError(String msg) {
/* 123 */     this.cab.addError(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addError(String msg, Throwable ex) {
/* 128 */     this.cab.addError(msg, ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\DynamicConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */