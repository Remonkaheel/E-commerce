package ch.qos.logback.core.pattern.color;

public class ANSIConstants {
  public static final String ESC_START = "\033[";
  
  public static final String ESC_END = "m";
  
  public static final String BOLD = "1;";
  
  public static final String RESET = "0;";
  
  public static final String BLACK_FG = "30";
  
  public static final String RED_FG = "31";
  
  public static final String GREEN_FG = "32";
  
  public static final String YELLOW_FG = "33";
  
  public static final String BLUE_FG = "34";
  
  public static final String MAGENTA_FG = "35";
  
  public static final String CYAN_FG = "36";
  
  public static final String WHITE_FG = "37";
  
  public static final String DEFAULT_FG = "39";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\color\ANSIConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */