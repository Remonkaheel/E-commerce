/*    */ package ch.qos.logback.core.pattern.color;
/*    */ 
/*    */ import ch.qos.logback.core.pattern.DynamicConverter;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConverterSupplierByClassName
/*    */   extends ContextAwareBase
/*    */   implements Supplier<DynamicConverter>
/*    */ {
/*    */   String conversionWord;
/*    */   String converterClassStr;
/*    */   
/*    */   public ConverterSupplierByClassName(String conversionWord, String converterClassStr) {
/* 36 */     this.conversionWord = conversionWord;
/* 37 */     this.converterClassStr = converterClassStr;
/*    */   }
/*    */ 
/*    */   
/*    */   public DynamicConverter get() {
/*    */     try {
/* 43 */       return (DynamicConverter)OptionHelper.instantiateByClassName(this.converterClassStr, DynamicConverter.class, this.context);
/* 44 */     } catch (Exception e) {
/* 45 */       addError("Failed to instantiate converter class [" + this.converterClassStr + "] for conversion word [" + this.conversionWord + "]", e);
/* 46 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\color\ConverterSupplierByClassName.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */