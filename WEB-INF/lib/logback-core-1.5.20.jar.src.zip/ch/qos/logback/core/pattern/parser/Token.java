/*     */ package ch.qos.logback.core.pattern.parser;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Token
/*     */ {
/*     */   static final int PERCENT = 37;
/*     */   static final int RIGHT_PARENTHESIS = 41;
/*     */   static final int MINUS = 45;
/*     */   static final int DOT = 46;
/*     */   static final int CURLY_LEFT = 123;
/*     */   static final int CURLY_RIGHT = 125;
/*     */   static final int LITERAL = 1000;
/*     */   static final int FORMAT_MODIFIER = 1002;
/*     */   static final int SIMPLE_KEYWORD = 1004;
/*     */   static final int COMPOSITE_KEYWORD = 1005;
/*     */   static final int OPTION = 1006;
/*     */   static final int EOF = 2147483647;
/*  36 */   static Token EOF_TOKEN = new Token(2147483647, "EOF");
/*  37 */   static Token RIGHT_PARENTHESIS_TOKEN = new Token(41);
/*     */   
/*  39 */   static Token BARE_COMPOSITE_KEYWORD_TOKEN = new Token(1005, "BARE");
/*  40 */   static Token PERCENT_TOKEN = new Token(37);
/*     */   
/*     */   private final int type;
/*     */   private final String value;
/*     */   private final List<String> optionsList;
/*     */   
/*     */   public Token(int type) {
/*  47 */     this(type, null, null);
/*     */   }
/*     */   
/*     */   public Token(int type, String value) {
/*  51 */     this(type, value, null);
/*     */   }
/*     */   
/*     */   public Token(int type, List<String> optionsList) {
/*  55 */     this(type, null, optionsList);
/*     */   }
/*     */   
/*     */   public Token(int type, String value, List<String> optionsList) {
/*  59 */     this.type = type;
/*  60 */     this.value = value;
/*  61 */     this.optionsList = optionsList;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  65 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getValue() {
/*  69 */     return this.value;
/*     */   }
/*     */   
/*     */   public List<String> getOptionsList() {
/*  73 */     return this.optionsList;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  77 */     String typeStr = null;
/*  78 */     switch (this.type) {
/*     */       
/*     */       case 37:
/*  81 */         typeStr = "%";
/*     */         break;
/*     */       case 1002:
/*  84 */         typeStr = "FormatModifier";
/*     */         break;
/*     */       case 1000:
/*  87 */         typeStr = "LITERAL";
/*     */         break;
/*     */       case 1006:
/*  90 */         typeStr = "OPTION";
/*     */         break;
/*     */       case 1004:
/*  93 */         typeStr = "SIMPLE_KEYWORD";
/*     */         break;
/*     */       case 1005:
/*  96 */         typeStr = "COMPOSITE_KEYWORD";
/*     */         break;
/*     */       case 41:
/*  99 */         typeStr = "RIGHT_PARENTHESIS";
/*     */         break;
/*     */       default:
/* 102 */         typeStr = "UNKNOWN"; break;
/*     */     } 
/* 104 */     return (this.value == null) ? ("Token(" + 
/* 105 */       typeStr + ")") : ("Token(" + 
/*     */ 
/*     */       
/* 108 */       typeStr + ", \"" + this.value + "\")");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     int result = this.type;
/* 115 */     result = 29 * result + ((this.value != null) ? this.value.hashCode() : 0);
/* 116 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 120 */     if (this == o)
/* 121 */       return true; 
/* 122 */     if (!(o instanceof Token)) {
/* 123 */       return false;
/*     */     }
/* 125 */     Token token = (Token)o;
/*     */     
/* 127 */     if (this.type != token.type)
/* 128 */       return false; 
/* 129 */     if ((this.value != null) ? !this.value.equals(token.value) : (token.value != null)) {
/* 130 */       return false;
/*     */     }
/* 132 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\parser\Token.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */