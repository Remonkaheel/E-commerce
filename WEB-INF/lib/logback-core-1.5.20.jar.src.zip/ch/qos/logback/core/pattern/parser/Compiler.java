/*     */ package ch.qos.logback.core.pattern.parser;
/*     */ 
/*     */ import ch.qos.logback.core.pattern.CompositeConverter;
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.pattern.DynamicConverter;
/*     */ import ch.qos.logback.core.pattern.LiteralConverter;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Compiler<E>
/*     */   extends ContextAwareBase
/*     */ {
/*     */   Converter<E> head;
/*     */   Converter<E> tail;
/*     */   final Node top;
/*     */   final Map<String, Supplier<DynamicConverter>> converterMap;
/*     */   
/*     */   Compiler(Node top, Map<String, Supplier<DynamicConverter>> converterMap) {
/*  35 */     this.top = top;
/*  36 */     this.converterMap = converterMap;
/*     */   }
/*     */   
/*     */   Converter<E> compile() {
/*  40 */     this.head = this.tail = null;
/*  41 */     for (Node n = this.top; n != null; n = n.next) {
/*  42 */       CompositeNode cn; CompositeConverter<E> compositeConverter; Compiler<E> childCompiler; Converter<E> childConverter; SimpleKeywordNode kn; DynamicConverter<E> dynaConverter; LiteralConverter literalConverter; switch (n.type) {
/*     */         case 0:
/*  44 */           addToList((Converter<E>)new LiteralConverter((String)n.getValue()));
/*     */           break;
/*     */         case 2:
/*  47 */           cn = (CompositeNode)n;
/*  48 */           compositeConverter = createCompositeConverter(cn);
/*  49 */           if (compositeConverter == null) {
/*  50 */             addError("Failed to create converter for [%" + String.valueOf(cn.getValue()) + "] keyword");
/*  51 */             addToList((Converter<E>)new LiteralConverter("%PARSER_ERROR[" + String.valueOf(cn.getValue()) + "]"));
/*     */             break;
/*     */           } 
/*  54 */           compositeConverter.setFormattingInfo(cn.getFormatInfo());
/*  55 */           compositeConverter.setOptionList(cn.getOptions());
/*  56 */           childCompiler = new Compiler(cn.getChildNode(), this.converterMap);
/*  57 */           childCompiler.setContext(this.context);
/*  58 */           childConverter = childCompiler.compile();
/*  59 */           compositeConverter.setChildConverter(childConverter);
/*  60 */           addToList((Converter<E>)compositeConverter);
/*     */           break;
/*     */         case 1:
/*  63 */           kn = (SimpleKeywordNode)n;
/*  64 */           dynaConverter = createConverter(kn);
/*  65 */           if (dynaConverter != null) {
/*  66 */             dynaConverter.setFormattingInfo(kn.getFormatInfo());
/*  67 */             dynaConverter.setOptionList(kn.getOptions());
/*  68 */             addToList((Converter<E>)dynaConverter);
/*     */             
/*     */             break;
/*     */           } 
/*  72 */           literalConverter = new LiteralConverter("%PARSER_ERROR[" + String.valueOf(kn.getValue()) + "]");
/*  73 */           addStatus((Status)new ErrorStatus("[" + String.valueOf(kn.getValue()) + "] is not a valid conversion word", this));
/*  74 */           addToList((Converter<E>)literalConverter);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/*  79 */     return this.head;
/*     */   }
/*     */   
/*     */   private void addToList(Converter<E> c) {
/*  83 */     if (this.head == null) {
/*  84 */       this.head = this.tail = c;
/*     */     } else {
/*  86 */       this.tail.setNext(c);
/*  87 */       this.tail = c;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DynamicConverter<E> createConverter(SimpleKeywordNode kn) {
/*  99 */     String keyword = (String)kn.getValue();
/* 100 */     Supplier<DynamicConverter> supplier = this.converterMap.get(keyword);
/*     */     
/* 102 */     if (supplier != null) {
/* 103 */       return supplier.get();
/*     */     }
/* 105 */     addError("There is no conversion supplier registered for conversion word [" + keyword + "]");
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CompositeConverter<E> createCompositeConverter(CompositeNode cn) {
/* 119 */     String keyword = (String)cn.getValue();
/* 120 */     Supplier<DynamicConverter> supplier = this.converterMap.get(keyword);
/*     */     
/* 122 */     if (supplier != null) {
/*     */       try {
/* 124 */         return (CompositeConverter<E>)supplier.get();
/* 125 */       } catch (ClassCastException e) {
/* 126 */         addError("Failed to cast as CompositeConverter for keyword [" + keyword + "]", e);
/* 127 */         return null;
/*     */       } 
/*     */     }
/* 130 */     addError("There is no conversion class registered for composite conversion word [" + keyword + "]");
/* 131 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\parser\Compiler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */