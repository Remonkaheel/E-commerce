/*    */ package ch.qos.logback.core.pattern;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplacingCompositeConverter<E>
/*    */   extends CompositeConverter<E>
/*    */ {
/*    */   Pattern pattern;
/*    */   String regex;
/*    */   String replacement;
/*    */   
/*    */   public void start() {
/* 26 */     List<String> optionList = getOptionList();
/* 27 */     if (optionList == null) {
/* 28 */       addError("at least two options are expected whereas you have declared none");
/*    */       
/*    */       return;
/*    */     } 
/* 32 */     int numOpts = optionList.size();
/*    */     
/* 34 */     if (numOpts < 2) {
/* 35 */       addError("at least two options are expected whereas you have declared only " + numOpts + "as [" + String.valueOf(optionList) + "]");
/*    */       
/*    */       return;
/*    */     } 
/* 39 */     this.regex = optionList.get(0);
/* 40 */     this.pattern = Pattern.compile(this.regex);
/* 41 */     this.replacement = optionList.get(1);
/* 42 */     super.start();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String transform(E event, String in) {
/* 47 */     if (!this.started)
/* 48 */       return in; 
/* 49 */     return this.pattern.matcher(in).replaceAll(this.replacement);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\ReplacingCompositeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */