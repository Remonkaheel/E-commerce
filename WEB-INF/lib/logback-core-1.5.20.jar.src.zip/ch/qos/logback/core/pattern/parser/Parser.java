/*     */ package ch.qos.logback.core.pattern.parser;
/*     */ 
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.pattern.DynamicConverter;
/*     */ import ch.qos.logback.core.pattern.FormatInfo;
/*     */ import ch.qos.logback.core.pattern.util.IEscapeUtil;
/*     */ import ch.qos.logback.core.pattern.util.RegularEscapeUtil;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser<E>
/*     */   extends ContextAwareBase
/*     */ {
/*     */   public static final String MISSING_RIGHT_PARENTHESIS = "https://logback.qos.ch/codes.html#missingRightParenthesis";
/*  45 */   public static final Map<String, Supplier<DynamicConverter>> DEFAULT_COMPOSITE_CONVERTER_MAP = new HashMap<>();
/*     */   
/*     */   static {
/*  48 */     DEFAULT_COMPOSITE_CONVERTER_MAP.put(Token.BARE_COMPOSITE_KEYWORD_TOKEN.getValue().toString(), ch.qos.logback.core.pattern.IdentityCompositeConverter::new);
/*     */     
/*  50 */     DEFAULT_COMPOSITE_CONVERTER_MAP.put("replace", ch.qos.logback.core.pattern.ReplacingCompositeConverter::new);
/*     */   }
/*     */   public static final String REPLACE_CONVERTER_WORD = "replace";
/*     */   final List<Token> tokenList;
/*  54 */   int pointer = 0;
/*     */   
/*     */   Parser(TokenStream ts) throws ScanException {
/*  57 */     this.tokenList = ts.tokenize();
/*     */   }
/*     */   
/*     */   public Parser(String pattern) throws ScanException {
/*  61 */     this(pattern, (IEscapeUtil)new RegularEscapeUtil());
/*     */   }
/*     */   
/*     */   public Parser(String pattern, IEscapeUtil escapeUtil) throws ScanException {
/*     */     try {
/*  66 */       TokenStream ts = new TokenStream(pattern, escapeUtil);
/*  67 */       this.tokenList = ts.tokenize();
/*  68 */     } catch (IllegalArgumentException npe) {
/*  69 */       throw new ScanException("Failed to initialize Parser", npe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<E> compile(Node top, Map<String, Supplier<DynamicConverter>> converterMap) {
/*  82 */     Compiler<E> compiler = new Compiler<>(top, converterMap);
/*  83 */     compiler.setContext(this.context);
/*     */     
/*  85 */     return compiler.compile();
/*     */   }
/*     */   
/*     */   public Node parse() throws ScanException {
/*  89 */     return E();
/*     */   }
/*     */ 
/*     */   
/*     */   Node E() throws ScanException {
/*  94 */     Node t = T();
/*  95 */     if (t == null) {
/*  96 */       return null;
/*     */     }
/*  98 */     Node eOpt = Eopt();
/*  99 */     if (eOpt != null) {
/* 100 */       t.setNext(eOpt);
/*     */     }
/* 102 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Node Eopt() throws ScanException {
/* 108 */     Token next = getCurentToken();
/*     */     
/* 110 */     if (next == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     return E();
/*     */   }
/*     */   
/*     */   Node T() throws ScanException {
/*     */     Token u;
/*     */     FormattingNode c;
/* 119 */     Token t = getCurentToken();
/* 120 */     expectNotNull(t, "a LITERAL or '%'");
/*     */     
/* 122 */     switch (t.getType()) {
/*     */       case 1000:
/* 124 */         advanceTokenPointer();
/* 125 */         return new Node(0, t.getValue());
/*     */       case 37:
/* 127 */         advanceTokenPointer();
/*     */ 
/*     */         
/* 130 */         u = getCurentToken();
/*     */         
/* 132 */         expectNotNull(u, "a FORMAT_MODIFIER, SIMPLE_KEYWORD or COMPOUND_KEYWORD");
/* 133 */         if (u.getType() == 1002) {
/* 134 */           FormatInfo fi = FormatInfo.valueOf(u.getValue());
/* 135 */           advanceTokenPointer();
/* 136 */           c = C();
/* 137 */           c.setFormatInfo(fi);
/*     */         } else {
/* 139 */           c = C();
/*     */         } 
/* 141 */         return c;
/*     */     } 
/*     */     
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FormattingNode C() throws ScanException {
/* 151 */     Token t = getCurentToken();
/*     */ 
/*     */     
/* 154 */     expectNotNull(t, "a LEFT_PARENTHESIS or KEYWORD");
/* 155 */     int type = t.getType();
/* 156 */     switch (type) {
/*     */       case 1004:
/* 158 */         return SINGLE();
/*     */       case 1005:
/* 160 */         advanceTokenPointer();
/* 161 */         return COMPOSITE(t.getValue().toString());
/*     */     } 
/* 163 */     throw new IllegalStateException("Unexpected token " + String.valueOf(t));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   FormattingNode SINGLE() throws ScanException {
/* 169 */     Token t = getNextToken();
/*     */     
/* 171 */     SimpleKeywordNode keywordNode = new SimpleKeywordNode(t.getValue());
/*     */     
/* 173 */     Token ot = getCurentToken();
/* 174 */     if (ot != null && ot.getType() == 1006) {
/* 175 */       List<String> optionList = ot.getOptionsList();
/* 176 */       keywordNode.setOptions(optionList);
/* 177 */       advanceTokenPointer();
/*     */     } 
/* 179 */     return keywordNode;
/*     */   }
/*     */   
/*     */   FormattingNode COMPOSITE(String keyword) throws ScanException {
/* 183 */     CompositeNode compositeNode = new CompositeNode(keyword);
/*     */     
/* 185 */     Node childNode = E();
/* 186 */     compositeNode.setChildNode(childNode);
/*     */     
/* 188 */     Token t = getNextToken();
/*     */     
/* 190 */     if (t == null || t.getType() != 41) {
/* 191 */       String msg = "Expecting RIGHT_PARENTHESIS token but got " + String.valueOf(t);
/* 192 */       addError(msg);
/* 193 */       addError("See also https://logback.qos.ch/codes.html#missingRightParenthesis");
/* 194 */       throw new ScanException(msg);
/*     */     } 
/* 196 */     Token ot = getCurentToken();
/* 197 */     if (ot != null && ot.getType() == 1006) {
/* 198 */       List<String> optionList = ot.getOptionsList();
/* 199 */       compositeNode.setOptions(optionList);
/* 200 */       advanceTokenPointer();
/*     */     } 
/* 202 */     return compositeNode;
/*     */   }
/*     */   
/*     */   Token getNextToken() {
/* 206 */     if (this.pointer < this.tokenList.size()) {
/* 207 */       return this.tokenList.get(this.pointer++);
/*     */     }
/* 209 */     return null;
/*     */   }
/*     */   
/*     */   Token getCurentToken() {
/* 213 */     if (this.pointer < this.tokenList.size()) {
/* 214 */       return this.tokenList.get(this.pointer);
/*     */     }
/* 216 */     return null;
/*     */   }
/*     */   
/*     */   void advanceTokenPointer() {
/* 220 */     this.pointer++;
/*     */   }
/*     */   
/*     */   void expectNotNull(Token t, String expected) {
/* 224 */     if (t == null)
/* 225 */       throw new IllegalStateException("All tokens consumed but was expecting " + expected); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\pattern\parser\Parser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */