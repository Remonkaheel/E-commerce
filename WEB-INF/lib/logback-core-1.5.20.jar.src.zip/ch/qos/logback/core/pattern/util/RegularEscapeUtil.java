/*    */ package ch.qos.logback.core.pattern.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegularEscapeUtil
/*    */   implements IEscapeUtil
/*    */ {
/*    */   public void escape(String escapeChars, StringBuffer buf, char next, int pointer) {
/* 24 */     if (escapeChars.indexOf(next) >= 0) {
/* 25 */       buf.append(next);
/*    */     }
/* 27 */     switch (next) {
/*    */       case '_':
/*    */         return;
/*    */       
/*    */       case '\\':
/* 32 */         buf.append(next);
/*    */       
/*    */       case 't':
/* 35 */         buf.append('\t');
/*    */       
/*    */       case 'r':
/* 38 */         buf.append('\r');
/*    */       
/*    */       case 'n':
/* 41 */         buf.append('\n');
/*    */     } 
/*    */     
/* 44 */     String commaSeperatedEscapeChars = formatEscapeCharsForListing(escapeChars);
/* 45 */     throw new IllegalArgumentException("Illegal char '" + next + " at column " + pointer + ". Only \\\\, \\_" + commaSeperatedEscapeChars + ", \\t, \\n, \\r combinations are allowed as escape characters.");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String formatEscapeCharsForListing(String escapeChars) {
/* 52 */     StringBuilder commaSeperatedEscapeChars = new StringBuilder();
/* 53 */     for (int i = 0; i < escapeChars.length(); i++) {
/* 54 */       commaSeperatedEscapeChars.append(", \\").append(escapeChars.charAt(i));
/*    */     }
/* 56 */     return commaSeperatedEscapeChars.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String basicEscape(String s) {
/* 63 */     int len = s.length();
/* 64 */     StringBuilder sbuf = new StringBuilder(len);
/*    */     
/* 66 */     int i = 0;
/* 67 */     while (i < len) {
/* 68 */       char c = s.charAt(i++);
/* 69 */       if (c == '\\' && i < len) {
/* 70 */         c = s.charAt(i++);
/* 71 */         if (c == 'n') {
/* 72 */           c = '\n';
/* 73 */         } else if (c == 'r') {
/* 74 */           c = '\r';
/* 75 */         } else if (c == 't') {
/* 76 */           c = '\t';
/* 77 */         } else if (c == 'f') {
/* 78 */           c = '\f';
/* 79 */         } else if (c == '\b') {
/* 80 */           c = '\b';
/* 81 */         } else if (c == '"') {
/* 82 */           c = '"';
/* 83 */         } else if (c == '\'') {
/* 84 */           c = '\'';
/* 85 */         } else if (c == '\\') {
/* 86 */           c = '\\';
/*    */         } 
/*    */       } 
/*    */       
/* 90 */       sbuf.append(c);
/*    */     } 
/* 92 */     return sbuf.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\patter\\util\RegularEscapeUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */