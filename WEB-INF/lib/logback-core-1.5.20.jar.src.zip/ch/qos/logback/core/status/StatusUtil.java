/*     */ package ch.qos.logback.core.status;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusUtil
/*     */ {
/*     */   StatusManager sm;
/*     */   
/*     */   public StatusUtil(StatusManager sm) {
/*  30 */     this.sm = sm;
/*     */   }
/*     */   
/*     */   public StatusUtil(Context context) {
/*  34 */     this.sm = context.getStatusManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contextHasStatusListener(Context context) {
/*  47 */     StatusManager sm = context.getStatusManager();
/*  48 */     if (sm == null)
/*  49 */       return false; 
/*  50 */     List<StatusListener> listeners = sm.getCopyOfStatusListenerList();
/*  51 */     if (listeners == null || listeners.size() == 0) {
/*  52 */       return false;
/*     */     }
/*  54 */     return true;
/*     */   }
/*     */   
/*     */   public static List<Status> filterStatusListByTimeThreshold(List<Status> rawList, long threshold) {
/*  58 */     List<Status> filteredList = new ArrayList<>();
/*  59 */     for (Status s : rawList) {
/*  60 */       if (s.getTimestamp() >= threshold)
/*  61 */         filteredList.add(s); 
/*     */     } 
/*  63 */     return filteredList;
/*     */   }
/*     */   
/*     */   public void addStatus(Status status) {
/*  67 */     if (this.sm != null) {
/*  68 */       this.sm.add(status);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInfo(Object caller, String msg) {
/*  73 */     addStatus(new InfoStatus(msg, caller));
/*     */   }
/*     */   
/*     */   public void addWarn(Object caller, String msg) {
/*  77 */     addStatus(new WarnStatus(msg, caller));
/*     */   }
/*     */   
/*     */   public void addError(Object caller, String msg, Throwable t) {
/*  81 */     addStatus(new ErrorStatus(msg, caller, t));
/*     */   }
/*     */   
/*     */   public boolean hasXMLParsingErrors(long threshold) {
/*  85 */     return containsMatch(threshold, 2, "XML_PARSING");
/*     */   }
/*     */   
/*     */   public boolean noXMLParsingErrorsOccurred(long threshold) {
/*  89 */     return !hasXMLParsingErrors(threshold);
/*     */   }
/*     */   
/*     */   public int getHighestLevel(long threshold) {
/*  93 */     List<Status> filteredList = filterStatusListByTimeThreshold(this.sm.getCopyOfStatusList(), threshold);
/*  94 */     int maxLevel = 0;
/*  95 */     for (Status s : filteredList) {
/*  96 */       if (s.getLevel() > maxLevel)
/*  97 */         maxLevel = s.getLevel(); 
/*     */     } 
/*  99 */     return maxLevel;
/*     */   }
/*     */   
/*     */   public boolean isErrorFree(long threshold) {
/* 103 */     return (getHighestLevel(threshold) < 2);
/*     */   }
/*     */   
/*     */   public boolean isWarningOrErrorFree(long threshold) {
/* 107 */     return (1 > getHighestLevel(threshold));
/*     */   }
/*     */   
/*     */   public boolean containsMatch(long threshold, int level, String regex) {
/* 111 */     List<Status> filteredList = filterStatusListByTimeThreshold(this.sm.getCopyOfStatusList(), threshold);
/* 112 */     Pattern p = Pattern.compile(regex);
/*     */     
/* 114 */     for (Status status : filteredList) {
/* 115 */       if (level != status.getLevel()) {
/*     */         continue;
/*     */       }
/* 118 */       String msg = status.getMessage();
/* 119 */       Matcher matcher = p.matcher(msg);
/* 120 */       if (matcher.lookingAt()) {
/* 121 */         return true;
/*     */       }
/*     */     } 
/* 124 */     return false;
/*     */   }
/*     */   
/*     */   public boolean containsMatch(int level, String regex) {
/* 128 */     return containsMatch(0L, level, regex);
/*     */   }
/*     */   
/*     */   public boolean containsMatch(String regex) {
/* 132 */     Pattern p = Pattern.compile(regex);
/* 133 */     for (Status status : this.sm.getCopyOfStatusList()) {
/* 134 */       String msg = status.getMessage();
/* 135 */       Matcher matcher = p.matcher(msg);
/* 136 */       if (matcher.lookingAt()) {
/* 137 */         return true;
/*     */       }
/*     */     } 
/* 140 */     return false;
/*     */   }
/*     */   
/*     */   public int levelCount(int level, long threshold) {
/* 144 */     List<Status> filteredList = filterStatusListByTimeThreshold(this.sm.getCopyOfStatusList(), threshold);
/*     */     
/* 146 */     int count = 0;
/* 147 */     for (Status status : filteredList) {
/* 148 */       if (status.getLevel() == level)
/* 149 */         count++; 
/*     */     } 
/* 151 */     return count;
/*     */   }
/*     */   
/*     */   public int matchCount(String regex) {
/* 155 */     int count = 0;
/* 156 */     Pattern p = Pattern.compile(regex);
/* 157 */     for (Status status : this.sm.getCopyOfStatusList()) {
/* 158 */       String msg = status.getMessage();
/* 159 */       Matcher matcher = p.matcher(msg);
/* 160 */       if (matcher.lookingAt()) {
/* 161 */         count++;
/*     */       }
/*     */     } 
/* 164 */     return count;
/*     */   }
/*     */   
/*     */   public boolean containsException(Class<?> exceptionType) {
/* 168 */     return containsException(exceptionType, null);
/*     */   }
/*     */   
/*     */   public boolean containsException(Class<?> exceptionType, String msgRegex) {
/* 172 */     for (Status status : this.sm.getCopyOfStatusList()) {
/* 173 */       Throwable t = status.getThrowable();
/* 174 */       while (t != null) {
/* 175 */         if (t.getClass().getName().equals(exceptionType.getName())) {
/* 176 */           if (msgRegex == null)
/* 177 */             return true; 
/* 178 */           if (checkRegexMatch(t.getMessage(), msgRegex)) {
/* 179 */             return true;
/*     */           }
/*     */         } 
/* 182 */         t = t.getCause();
/*     */       } 
/*     */     } 
/* 185 */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkRegexMatch(String message, String msgRegex) {
/* 189 */     Pattern p = Pattern.compile(msgRegex);
/* 190 */     Matcher matcher = p.matcher(message);
/* 191 */     return matcher.lookingAt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long timeOfLastReset() {
/* 201 */     List<Status> statusList = this.sm.getCopyOfStatusList();
/* 202 */     if (statusList == null) {
/* 203 */       return -1L;
/*     */     }
/* 205 */     int len = statusList.size();
/* 206 */     for (int i = len - 1; i >= 0; i--) {
/* 207 */       Status s = statusList.get(i);
/* 208 */       if ("Will reset and reconfigure context ".equals(s.getMessage())) {
/* 209 */         return s.getTimestamp();
/*     */       }
/*     */     } 
/* 212 */     return -1L;
/*     */   }
/*     */   
/*     */   public static String diff(Status left, Status right) {
/* 216 */     StringBuilder sb = new StringBuilder();
/* 217 */     if (left.getLevel() != right.getLevel()) {
/* 218 */       sb.append(" left.level ").append(left.getLevel()).append(" != right.level ").append(right.getLevel());
/*     */     }
/* 220 */     if (left.getTimestamp() != right.getTimestamp()) {
/* 221 */       sb.append(" left.timestamp ").append(left.getTimestamp()).append(" != right.timestamp ").append(right.getTimestamp());
/*     */     }
/* 223 */     if (!Objects.equals(left.getMessage(), right.getMessage())) {
/* 224 */       sb.append(" left.message ").append(left.getMessage()).append(" != right.message ").append(right.getMessage());
/*     */     }
/*     */     
/* 227 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\status\StatusUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */