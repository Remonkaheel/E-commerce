/*     */ package ch.qos.logback.core.status;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StatusBase
/*     */   implements Status
/*     */ {
/*  23 */   private static final List<Status> EMPTY_LIST = new ArrayList<>(0);
/*     */   
/*     */   int level;
/*     */   final String message;
/*     */   final Object origin;
/*     */   List<Status> childrenList;
/*     */   Throwable throwable;
/*     */   long timestamp;
/*     */   
/*     */   StatusBase(int level, String msg, Object origin) {
/*  33 */     this(level, msg, origin, null);
/*     */   }
/*     */   
/*     */   StatusBase(int level, String msg, Object origin, Throwable t) {
/*  37 */     this.level = level;
/*  38 */     this.message = msg;
/*  39 */     this.origin = origin;
/*  40 */     this.throwable = t;
/*  41 */     this.timestamp = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   public synchronized void add(Status child) {
/*  45 */     if (child == null) {
/*  46 */       throw new NullPointerException("Null values are not valid Status.");
/*     */     }
/*  48 */     if (this.childrenList == null) {
/*  49 */       this.childrenList = new ArrayList<>();
/*     */     }
/*  51 */     this.childrenList.add(child);
/*     */   }
/*     */   
/*     */   public synchronized boolean hasChildren() {
/*  55 */     return (this.childrenList != null && this.childrenList.size() > 0);
/*     */   }
/*     */   
/*     */   public synchronized Iterator<Status> iterator() {
/*  59 */     if (this.childrenList != null) {
/*  60 */       return this.childrenList.iterator();
/*     */     }
/*  62 */     return EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean remove(Status statusToRemove) {
/*  67 */     if (this.childrenList == null) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     return this.childrenList.remove(statusToRemove);
/*     */   }
/*     */   
/*     */   public int getLevel() {
/*  75 */     return this.level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int getEffectiveLevel() {
/*  83 */     int result = this.level;
/*     */ 
/*     */     
/*  86 */     Iterator<Status> it = iterator();
/*     */     
/*  88 */     while (it.hasNext()) {
/*  89 */       Status s = it.next();
/*  90 */       int effLevel = s.getEffectiveLevel();
/*  91 */       if (effLevel > result) {
/*  92 */         result = effLevel;
/*     */       }
/*     */     } 
/*  95 */     return result;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/*  99 */     return this.message;
/*     */   }
/*     */   
/*     */   public Object getOrigin() {
/* 103 */     return this.origin;
/*     */   }
/*     */   
/*     */   public Throwable getThrowable() {
/* 107 */     return this.throwable;
/*     */   }
/*     */   
/*     */   public long getTimestamp() {
/* 111 */     return this.timestamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 116 */     StringBuilder buf = new StringBuilder();
/* 117 */     switch (getEffectiveLevel()) {
/*     */       case 0:
/* 119 */         buf.append("INFO");
/*     */         break;
/*     */       case 1:
/* 122 */         buf.append("WARN");
/*     */         break;
/*     */       case 2:
/* 125 */         buf.append("ERROR");
/*     */         break;
/*     */     } 
/* 128 */     if (this.origin != null) {
/* 129 */       buf.append(" in ");
/* 130 */       buf.append(this.origin);
/* 131 */       buf.append(" -");
/*     */     } 
/*     */     
/* 134 */     buf.append(" ");
/* 135 */     buf.append(this.message);
/*     */     
/* 137 */     if (this.throwable != null) {
/* 138 */       buf.append(" ");
/* 139 */       buf.append(this.throwable);
/*     */     } 
/*     */     
/* 142 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 147 */     if (this == o)
/* 148 */       return true; 
/* 149 */     if (o == null || getClass() != o.getClass())
/* 150 */       return false; 
/* 151 */     StatusBase that = (StatusBase)o;
/* 152 */     return (this.level == that.level && this.timestamp == that.timestamp && Objects.equals(this.message, that.message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     return Objects.hash(new Object[] { Integer.valueOf(this.level), this.message, Long.valueOf(this.timestamp) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\status\StatusBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */