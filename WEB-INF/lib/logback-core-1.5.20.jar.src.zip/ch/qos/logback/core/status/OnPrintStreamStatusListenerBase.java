/*     */ package ch.qos.logback.core.status;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.util.StatusPrinter;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OnPrintStreamStatusListenerBase
/*     */   extends ContextAwareBase
/*     */   implements StatusListener, LifeCycle
/*     */ {
/*     */   boolean isStarted = false;
/*     */   static final long DEFAULT_RETROSPECTIVE = 300L;
/*  33 */   long retrospectiveThresold = 300L;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean resetResistant = false;
/*     */ 
/*     */ 
/*     */   
/*     */   String prefix;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract PrintStream getPrintStream();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void print(Status status) {
/*  52 */     StringBuilder sb = new StringBuilder();
/*  53 */     if (this.prefix != null) {
/*  54 */       sb.append(this.prefix);
/*     */     }
/*  56 */     StatusPrinter.buildStr(sb, "", status);
/*  57 */     getPrintStream().print(sb);
/*     */   }
/*     */   
/*     */   public void addStatusEvent(Status status) {
/*  61 */     if (!this.isStarted)
/*     */       return; 
/*  63 */     print(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void retrospectivePrint() {
/*  70 */     if (this.context == null)
/*     */       return; 
/*  72 */     long now = System.currentTimeMillis();
/*  73 */     StatusManager sm = this.context.getStatusManager();
/*  74 */     List<Status> statusList = sm.getCopyOfStatusList();
/*  75 */     for (Status status : statusList) {
/*  76 */       long timestampOfStatusMesage = status.getTimestamp();
/*  77 */       if (isElapsedTimeLongerThanThreshold(now, timestampOfStatusMesage)) {
/*  78 */         print(status);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isElapsedTimeLongerThanThreshold(long now, long timestamp) {
/*  84 */     long elapsedTime = now - timestamp;
/*  85 */     return (elapsedTime < this.retrospectiveThresold);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  93 */     this.isStarted = true;
/*  94 */     if (this.retrospectiveThresold > 0L) {
/*  95 */       retrospectivePrint();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 100 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 104 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */   public void setRetrospective(long retrospective) {
/* 108 */     this.retrospectiveThresold = retrospective;
/*     */   }
/*     */   
/*     */   public long getRetrospective() {
/* 112 */     return this.retrospectiveThresold;
/*     */   }
/*     */   
/*     */   public void stop() {
/* 116 */     this.isStarted = false;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 120 */     return this.isStarted;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isResetResistant() {
/* 125 */     return this.resetResistant;
/*     */   }
/*     */   public void setResetResistant(boolean resetResistant) {
/* 128 */     this.resetResistant = resetResistant;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\status\OnPrintStreamStatusListenerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */