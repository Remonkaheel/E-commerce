/*    */ package ch.qos.logback.core.status;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class OnFileStatusListener
/*    */   extends OnPrintStreamStatusListenerBase
/*    */ {
/*    */   String filename;
/*    */   PrintStream ps;
/*    */   
/*    */   public void start() {
/* 14 */     if (this.filename == null) {
/* 15 */       addInfo("File option not set. Defaulting to \"status.txt\"");
/* 16 */       this.filename = "status.txt";
/*    */     } 
/*    */     
/*    */     try {
/* 20 */       FileOutputStream fos = new FileOutputStream(this.filename, true);
/* 21 */       this.ps = new PrintStream(fos, true);
/* 22 */     } catch (FileNotFoundException e) {
/* 23 */       addError("Failed to open [" + this.filename + "]", e);
/*    */       
/*    */       return;
/*    */     } 
/* 27 */     super.start();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop() {
/* 33 */     if (!this.isStarted) {
/*    */       return;
/*    */     }
/* 36 */     if (this.ps != null)
/* 37 */       this.ps.close(); 
/* 38 */     super.stop();
/*    */   }
/*    */   
/*    */   public String getFilename() {
/* 42 */     return this.filename;
/*    */   }
/*    */   
/*    */   public void setFilename(String filename) {
/* 46 */     this.filename = filename;
/*    */   }
/*    */ 
/*    */   
/*    */   protected PrintStream getPrintStream() {
/* 51 */     return this.ps;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\status\OnFileStatusListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */