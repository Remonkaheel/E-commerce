package ch.qos.logback.core.status;

public class NopStatusListener implements StatusListener {
  public void addStatusEvent(Status status) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\status\NopStatusListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */