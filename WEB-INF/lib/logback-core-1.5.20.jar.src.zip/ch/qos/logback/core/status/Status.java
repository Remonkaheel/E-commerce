/*    */ package ch.qos.logback.core.status;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Status
/*    */ {
/*    */   public static final int INFO = 0;
/*    */   public static final int WARN = 1;
/*    */   public static final int ERROR = 2;
/*    */   
/*    */   int getLevel();
/*    */   
/*    */   int getEffectiveLevel();
/*    */   
/*    */   Object getOrigin();
/*    */   
/*    */   String getMessage();
/*    */   
/*    */   Throwable getThrowable();
/*    */   
/*    */   @Deprecated
/*    */   default Long getDate() {
/* 40 */     return Long.valueOf(getTimestamp());
/*    */   }
/*    */   
/*    */   long getTimestamp();
/*    */   
/*    */   boolean hasChildren();
/*    */   
/*    */   void add(Status paramStatus);
/*    */   
/*    */   boolean remove(Status paramStatus);
/*    */   
/*    */   Iterator<Status> iterator();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\status\Status.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */