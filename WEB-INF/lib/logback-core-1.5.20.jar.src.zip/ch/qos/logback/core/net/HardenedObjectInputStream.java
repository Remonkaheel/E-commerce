/*    */ package ch.qos.logback.core.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InvalidClassException;
/*    */ import java.io.ObjectInputFilter;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HardenedObjectInputStream
/*    */   extends ObjectInputStream
/*    */ {
/*    */   private final List<String> whitelistedClassNames;
/* 41 */   private static final String[] JAVA_PACKAGES = new String[] { "java.lang", "java.util" };
/*    */   private static final int DEPTH_LIMIT = 16;
/*    */   private static final int ARRAY_LIMIT = 10000;
/*    */   
/*    */   public HardenedObjectInputStream(InputStream in, String[] whitelist) throws IOException {
/* 46 */     super(in);
/* 47 */     initObjectFilter();
/* 48 */     this.whitelistedClassNames = new ArrayList<>();
/* 49 */     if (whitelist != null) {
/* 50 */       for (int i = 0; i < whitelist.length; i++) {
/* 51 */         this.whitelistedClassNames.add(whitelist[i]);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private void initObjectFilter() {
/* 57 */     setObjectInputFilter(ObjectInputFilter.Config.createFilter("maxarray=10000;maxdepth=16;"));
/*    */   }
/*    */ 
/*    */   
/*    */   public HardenedObjectInputStream(InputStream in, List<String> whitelist) throws IOException {
/* 62 */     super(in);
/* 63 */     initObjectFilter();
/* 64 */     this.whitelistedClassNames = new ArrayList<>();
/* 65 */     this.whitelistedClassNames.addAll(whitelist);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<?> resolveClass(ObjectStreamClass anObjectStreamClass) throws IOException, ClassNotFoundException {
/* 71 */     String incomingClassName = anObjectStreamClass.getName();
/*    */     
/* 73 */     if (!isWhitelisted(incomingClassName)) {
/* 74 */       throw new InvalidClassException("Unauthorized deserialization attempt", anObjectStreamClass.getName());
/*    */     }
/*    */     
/* 77 */     return super.resolveClass(anObjectStreamClass);
/*    */   }
/*    */   
/*    */   private boolean isWhitelisted(String incomingClassName) {
/* 81 */     for (int i = 0; i < JAVA_PACKAGES.length; i++) {
/* 82 */       if (incomingClassName.startsWith(JAVA_PACKAGES[i]))
/* 83 */         return true; 
/*    */     } 
/* 85 */     for (String whiteListed : this.whitelistedClassNames) {
/* 86 */       if (incomingClassName.equals(whiteListed))
/* 87 */         return true; 
/*    */     } 
/* 89 */     return false;
/*    */   }
/*    */   
/*    */   protected void addToWhitelist(List<String> additionalAuthorizedClasses) {
/* 93 */     this.whitelistedClassNames.addAll(additionalAuthorizedClasses);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\HardenedObjectInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */