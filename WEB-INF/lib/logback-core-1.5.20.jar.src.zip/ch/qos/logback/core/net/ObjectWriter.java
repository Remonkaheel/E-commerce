package ch.qos.logback.core.net;

import java.io.IOException;

public interface ObjectWriter {
  void write(Object paramObject) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\ObjectWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */