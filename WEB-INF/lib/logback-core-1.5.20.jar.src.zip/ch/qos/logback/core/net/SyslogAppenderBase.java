/*     */ package ch.qos.logback.core.net;
/*     */ 
/*     */ import ch.qos.logback.core.AppenderBase;
/*     */ import ch.qos.logback.core.Layout;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SyslogAppenderBase<E>
/*     */   extends AppenderBase<E>
/*     */ {
/*     */   static final String SYSLOG_LAYOUT_URL = "https://logback.qos.ch/codes.html#syslog_layout";
/*     */   static final int MAX_MESSAGE_SIZE_LIMIT = 65000;
/*     */   Layout<E> layout;
/*     */   String facilityStr;
/*     */   String syslogHost;
/*     */   protected String suffixPattern;
/*     */   SyslogOutputStream sos;
/*  43 */   int port = 514;
/*     */   int maxMessageSize;
/*     */   Charset charset;
/*     */   
/*     */   public void start() {
/*  48 */     int errorCount = 0;
/*  49 */     if (this.facilityStr == null) {
/*  50 */       addError("The Facility option is mandatory");
/*  51 */       errorCount++;
/*     */     } 
/*     */     
/*  54 */     if (this.charset == null)
/*     */     {
/*     */ 
/*     */       
/*  58 */       this.charset = Charset.defaultCharset();
/*     */     }
/*     */     
/*     */     try {
/*  62 */       this.sos = createOutputStream();
/*     */       
/*  64 */       int systemDatagramSize = this.sos.getSendBufferSize();
/*  65 */       if (this.maxMessageSize == 0) {
/*  66 */         this.maxMessageSize = Math.min(systemDatagramSize, 65000);
/*  67 */         addInfo("Defaulting maxMessageSize to [" + this.maxMessageSize + "]");
/*  68 */       } else if (this.maxMessageSize > systemDatagramSize) {
/*  69 */         addWarn("maxMessageSize of [" + this.maxMessageSize + "] is larger than the system defined datagram size of [" + systemDatagramSize + "].");
/*     */         
/*  71 */         addWarn("This may result in dropped logs.");
/*     */       } 
/*  73 */     } catch (UnknownHostException e) {
/*  74 */       addError("Could not create SyslogWriter", e);
/*  75 */       errorCount++;
/*  76 */     } catch (SocketException e) {
/*  77 */       addWarn("Failed to bind to a random datagram socket. Will try to reconnect later.", e);
/*     */     } 
/*     */     
/*  80 */     if (this.layout == null) {
/*  81 */       this.layout = buildLayout();
/*     */     }
/*     */     
/*  84 */     if (errorCount == 0) {
/*  85 */       super.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract SyslogOutputStream createOutputStream() throws UnknownHostException, SocketException;
/*     */   
/*     */   public abstract Layout<E> buildLayout();
/*     */   
/*     */   public abstract int getSeverityForEvent(Object paramObject);
/*     */   
/*     */   protected void append(E eventObject) {
/*  97 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 102 */       String msg = this.layout.doLayout(eventObject);
/* 103 */       if (msg == null) {
/*     */         return;
/*     */       }
/* 106 */       if (msg.length() > this.maxMessageSize) {
/* 107 */         msg = msg.substring(0, this.maxMessageSize);
/*     */       }
/* 109 */       this.sos.write(msg.getBytes(this.charset));
/* 110 */       this.sos.flush();
/* 111 */       postProcess(eventObject, this.sos);
/* 112 */     } catch (IOException ioe) {
/* 113 */       addError("Failed to send diagram to " + this.syslogHost, ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcess(Object event, OutputStream sw) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int facilityStringToint(String facilityStr) {
/* 127 */     if ("KERN".equalsIgnoreCase(facilityStr))
/* 128 */       return 0; 
/* 129 */     if ("USER".equalsIgnoreCase(facilityStr))
/* 130 */       return 8; 
/* 131 */     if ("MAIL".equalsIgnoreCase(facilityStr))
/* 132 */       return 16; 
/* 133 */     if ("DAEMON".equalsIgnoreCase(facilityStr))
/* 134 */       return 24; 
/* 135 */     if ("AUTH".equalsIgnoreCase(facilityStr))
/* 136 */       return 32; 
/* 137 */     if ("SYSLOG".equalsIgnoreCase(facilityStr))
/* 138 */       return 40; 
/* 139 */     if ("LPR".equalsIgnoreCase(facilityStr))
/* 140 */       return 48; 
/* 141 */     if ("NEWS".equalsIgnoreCase(facilityStr))
/* 142 */       return 56; 
/* 143 */     if ("UUCP".equalsIgnoreCase(facilityStr))
/* 144 */       return 64; 
/* 145 */     if ("CRON".equalsIgnoreCase(facilityStr))
/* 146 */       return 72; 
/* 147 */     if ("AUTHPRIV".equalsIgnoreCase(facilityStr))
/* 148 */       return 80; 
/* 149 */     if ("FTP".equalsIgnoreCase(facilityStr))
/* 150 */       return 88; 
/* 151 */     if ("NTP".equalsIgnoreCase(facilityStr))
/* 152 */       return 96; 
/* 153 */     if ("AUDIT".equalsIgnoreCase(facilityStr))
/* 154 */       return 104; 
/* 155 */     if ("ALERT".equalsIgnoreCase(facilityStr))
/* 156 */       return 112; 
/* 157 */     if ("CLOCK".equalsIgnoreCase(facilityStr))
/* 158 */       return 120; 
/* 159 */     if ("LOCAL0".equalsIgnoreCase(facilityStr))
/* 160 */       return 128; 
/* 161 */     if ("LOCAL1".equalsIgnoreCase(facilityStr))
/* 162 */       return 136; 
/* 163 */     if ("LOCAL2".equalsIgnoreCase(facilityStr))
/* 164 */       return 144; 
/* 165 */     if ("LOCAL3".equalsIgnoreCase(facilityStr))
/* 166 */       return 152; 
/* 167 */     if ("LOCAL4".equalsIgnoreCase(facilityStr))
/* 168 */       return 160; 
/* 169 */     if ("LOCAL5".equalsIgnoreCase(facilityStr))
/* 170 */       return 168; 
/* 171 */     if ("LOCAL6".equalsIgnoreCase(facilityStr))
/* 172 */       return 176; 
/* 173 */     if ("LOCAL7".equalsIgnoreCase(facilityStr)) {
/* 174 */       return 184;
/*     */     }
/* 176 */     throw new IllegalArgumentException(facilityStr + " is not a valid syslog facility string");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSyslogHost() {
/* 184 */     return this.syslogHost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSyslogHost(String syslogHost) {
/* 194 */     this.syslogHost = syslogHost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFacility() {
/* 203 */     return this.facilityStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFacility(String facilityStr) {
/* 217 */     if (facilityStr != null) {
/* 218 */       facilityStr = facilityStr.trim();
/*     */     }
/* 220 */     this.facilityStr = facilityStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 228 */     return this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPort(int port) {
/* 236 */     this.port = port;
/*     */   }
/*     */   
/*     */   public int getMaxMessageSize() {
/* 240 */     return this.maxMessageSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxMessageSize(int maxMessageSize) {
/* 250 */     this.maxMessageSize = maxMessageSize;
/*     */   }
/*     */   
/*     */   public Layout<E> getLayout() {
/* 254 */     return this.layout;
/*     */   }
/*     */   
/*     */   public void setLayout(Layout<E> layout) {
/* 258 */     addWarn("The layout of a SyslogAppender cannot be set directly. See also https://logback.qos.ch/codes.html#syslog_layout");
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 263 */     if (this.sos != null) {
/* 264 */       this.sos.close();
/*     */     }
/* 266 */     super.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuffixPattern() {
/* 275 */     return this.suffixPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuffixPattern(String suffixPattern) {
/* 285 */     this.suffixPattern = suffixPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/* 293 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(Charset charset) {
/* 302 */     this.charset = charset;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\SyslogAppenderBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */