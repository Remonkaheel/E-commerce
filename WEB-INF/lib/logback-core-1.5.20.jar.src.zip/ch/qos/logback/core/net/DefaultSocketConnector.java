/*     */ package ch.qos.logback.core.net;
/*     */ 
/*     */ import ch.qos.logback.core.util.DelayStrategy;
/*     */ import ch.qos.logback.core.util.FixedDelay;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import javax.net.SocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSocketConnector
/*     */   implements SocketConnector
/*     */ {
/*     */   private final InetAddress address;
/*     */   private final int port;
/*     */   private final DelayStrategy delayStrategy;
/*     */   private SocketConnector.ExceptionHandler exceptionHandler;
/*     */   private SocketFactory socketFactory;
/*     */   
/*     */   public DefaultSocketConnector(InetAddress address, int port, long initialDelay, long retryDelay) {
/*  49 */     this(address, port, (DelayStrategy)new FixedDelay(initialDelay, retryDelay));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultSocketConnector(InetAddress address, int port, DelayStrategy delayStrategy) {
/*  61 */     this.address = address;
/*  62 */     this.port = port;
/*  63 */     this.delayStrategy = delayStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket call() throws InterruptedException {
/*  71 */     useDefaultsForMissingFields();
/*  72 */     Socket socket = createSocket();
/*  73 */     while (socket == null && !Thread.currentThread().isInterrupted()) {
/*  74 */       Thread.sleep(this.delayStrategy.nextDelay());
/*  75 */       socket = createSocket();
/*     */     } 
/*  77 */     return socket;
/*     */   }
/*     */   
/*     */   private Socket createSocket() {
/*  81 */     Socket newSocket = null;
/*     */     try {
/*  83 */       newSocket = this.socketFactory.createSocket(this.address, this.port);
/*  84 */     } catch (IOException ioex) {
/*  85 */       this.exceptionHandler.connectionFailed(this, ioex);
/*     */     } 
/*  87 */     return newSocket;
/*     */   }
/*     */   
/*     */   private void useDefaultsForMissingFields() {
/*  91 */     if (this.exceptionHandler == null) {
/*  92 */       this.exceptionHandler = new ConsoleExceptionHandler();
/*     */     }
/*  94 */     if (this.socketFactory == null) {
/*  95 */       this.socketFactory = SocketFactory.getDefault();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionHandler(SocketConnector.ExceptionHandler exceptionHandler) {
/* 103 */     this.exceptionHandler = exceptionHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSocketFactory(SocketFactory socketFactory) {
/* 110 */     this.socketFactory = socketFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConsoleExceptionHandler
/*     */     implements SocketConnector.ExceptionHandler
/*     */   {
/*     */     public void connectionFailed(SocketConnector connector, Exception ex) {
/* 119 */       System.out.println(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\DefaultSocketConnector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */