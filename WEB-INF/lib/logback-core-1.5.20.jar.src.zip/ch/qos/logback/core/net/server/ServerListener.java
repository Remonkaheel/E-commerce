package ch.qos.logback.core.net.server;

import java.io.Closeable;
import java.io.IOException;

public interface ServerListener<T extends Client> extends Closeable {
  T acceptClient() throws IOException, InterruptedException;
  
  void close();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\server\ServerListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */