/*    */ package ch.qos.logback.core.net.ssl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.net.Socket;
/*    */ import java.net.UnknownHostException;
/*    */ import javax.net.SocketFactory;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurableSSLSocketFactory
/*    */   extends SocketFactory
/*    */ {
/*    */   private final SSLParametersConfiguration parameters;
/*    */   private final SSLSocketFactory delegate;
/*    */   
/*    */   public ConfigurableSSLSocketFactory(SSLParametersConfiguration parameters, SSLSocketFactory delegate) {
/* 51 */     this.parameters = parameters;
/* 52 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
/* 61 */     SSLSocket socket = (SSLSocket)this.delegate.createSocket(address, port, localAddress, localPort);
/* 62 */     this.parameters.configure(new SSLConfigurableSocket(socket));
/* 63 */     return socket;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Socket createSocket(InetAddress host, int port) throws IOException {
/* 71 */     SSLSocket socket = (SSLSocket)this.delegate.createSocket(host, port);
/* 72 */     this.parameters.configure(new SSLConfigurableSocket(socket));
/* 73 */     return socket;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException, UnknownHostException {
/* 82 */     SSLSocket socket = (SSLSocket)this.delegate.createSocket(host, port, localHost, localPort);
/* 83 */     this.parameters.configure(new SSLConfigurableSocket(socket));
/* 84 */     return socket;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Socket createSocket(String host, int port) throws IOException, UnknownHostException {
/* 92 */     SSLSocket socket = (SSLSocket)this.delegate.createSocket(host, port);
/* 93 */     this.parameters.configure(new SSLConfigurableSocket(socket));
/* 94 */     return socket;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\ssl\ConfigurableSSLSocketFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */