/*    */ package ch.qos.logback.core.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoFlushingObjectWriter
/*    */   implements ObjectWriter
/*    */ {
/*    */   private final ObjectOutputStream objectOutputStream;
/*    */   private final int resetFrequency;
/* 30 */   private int writeCounter = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AutoFlushingObjectWriter(ObjectOutputStream objectOutputStream, int resetFrequency) {
/* 40 */     this.objectOutputStream = objectOutputStream;
/* 41 */     this.resetFrequency = resetFrequency;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(Object object) throws IOException {
/* 46 */     this.objectOutputStream.writeObject(object);
/* 47 */     this.objectOutputStream.flush();
/* 48 */     preventMemoryLeak();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void preventMemoryLeak() throws IOException {
/* 57 */     if (++this.writeCounter >= this.resetFrequency) {
/* 58 */       this.objectOutputStream.reset();
/* 59 */       this.writeCounter = 0;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\AutoFlushingObjectWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */