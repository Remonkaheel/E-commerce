/*     */ package ch.qos.logback.core.net.ssl;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertificateException;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLContextFactoryBean
/*     */ {
/*     */   private static final String JSSE_KEY_STORE_PROPERTY = "javax.net.ssl.keyStore";
/*     */   private static final String JSSE_TRUST_STORE_PROPERTY = "javax.net.ssl.trustStore";
/*     */   private KeyStoreFactoryBean keyStore;
/*     */   private KeyStoreFactoryBean trustStore;
/*     */   private SecureRandomFactoryBean secureRandom;
/*     */   private KeyManagerFactoryFactoryBean keyManagerFactory;
/*     */   private TrustManagerFactoryFactoryBean trustManagerFactory;
/*     */   private String protocol;
/*     */   private String provider;
/*     */   
/*     */   public SSLContext createContext(ContextAware context) throws NoSuchProviderException, NoSuchAlgorithmException, KeyManagementException, UnrecoverableKeyException, KeyStoreException, CertificateException {
/*  81 */     SSLContext sslContext = (getProvider() != null) ? SSLContext.getInstance(getProtocol(), getProvider()) : SSLContext.getInstance(getProtocol());
/*     */     
/*  83 */     context.addInfo("SSL protocol '" + sslContext.getProtocol() + "' provider '" + String.valueOf(sslContext.getProvider()) + "'");
/*     */     
/*  85 */     KeyManager[] keyManagers = createKeyManagers(context);
/*  86 */     TrustManager[] trustManagers = createTrustManagers(context);
/*  87 */     SecureRandom secureRandom = createSecureRandom(context);
/*  88 */     sslContext.init(keyManagers, trustManagers, secureRandom);
/*  89 */     return sslContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyManager[] createKeyManagers(ContextAware context) throws NoSuchProviderException, NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException {
/* 109 */     if (getKeyStore() == null) {
/* 110 */       return null;
/*     */     }
/* 112 */     KeyStore keyStore = getKeyStore().createKeyStore();
/* 113 */     context.addInfo("key store of type '" + keyStore.getType() + "' provider '" + String.valueOf(keyStore.getProvider()) + "': " + 
/* 114 */         getKeyStore().getLocation());
/*     */     
/* 116 */     KeyManagerFactory kmf = getKeyManagerFactory().createKeyManagerFactory();
/* 117 */     context.addInfo("key manager algorithm '" + kmf.getAlgorithm() + "' provider '" + String.valueOf(kmf.getProvider()) + "'");
/*     */     
/* 119 */     char[] passphrase = getKeyStore().getPassword().toCharArray();
/* 120 */     kmf.init(keyStore, passphrase);
/* 121 */     return kmf.getKeyManagers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TrustManager[] createTrustManagers(ContextAware context) throws NoSuchProviderException, NoSuchAlgorithmException, KeyStoreException {
/* 142 */     if (getTrustStore() == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     KeyStore trustStore = getTrustStore().createKeyStore();
/* 146 */     context.addInfo("trust store of type '" + trustStore.getType() + "' provider '" + String.valueOf(trustStore.getProvider()) + "': " + 
/* 147 */         getTrustStore().getLocation());
/*     */     
/* 149 */     TrustManagerFactory tmf = getTrustManagerFactory().createTrustManagerFactory();
/* 150 */     context.addInfo("trust manager algorithm '" + tmf.getAlgorithm() + "' provider '" + String.valueOf(tmf.getProvider()) + "'");
/*     */     
/* 152 */     tmf.init(trustStore);
/* 153 */     return tmf.getTrustManagers();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private SecureRandom createSecureRandom(ContextAware context) throws NoSuchProviderException, NoSuchAlgorithmException {
/* 159 */     SecureRandom secureRandom = getSecureRandom().createSecureRandom();
/* 160 */     context.addInfo("secure random algorithm '" + secureRandom.getAlgorithm() + "' provider '" + 
/* 161 */         String.valueOf(secureRandom.getProvider()) + "'");
/*     */     
/* 163 */     return secureRandom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyStoreFactoryBean getKeyStore() {
/* 173 */     if (this.keyStore == null) {
/* 174 */       this.keyStore = keyStoreFromSystemProperties("javax.net.ssl.keyStore");
/*     */     }
/* 176 */     return this.keyStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyStore(KeyStoreFactoryBean keyStore) {
/* 185 */     this.keyStore = keyStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyStoreFactoryBean getTrustStore() {
/* 195 */     if (this.trustStore == null) {
/* 196 */       this.trustStore = keyStoreFromSystemProperties("javax.net.ssl.trustStore");
/*     */     }
/* 198 */     return this.trustStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustStore(KeyStoreFactoryBean trustStore) {
/* 207 */     this.trustStore = trustStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyStoreFactoryBean keyStoreFromSystemProperties(String property) {
/* 218 */     if (System.getProperty(property) == null)
/* 219 */       return null; 
/* 220 */     KeyStoreFactoryBean keyStore = new KeyStoreFactoryBean();
/* 221 */     keyStore.setLocation(locationFromSystemProperty(property));
/* 222 */     keyStore.setProvider(System.getProperty(property + "Provider"));
/* 223 */     keyStore.setPassword(System.getProperty(property + "Password"));
/* 224 */     keyStore.setType(System.getProperty(property + "Type"));
/* 225 */     return keyStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String locationFromSystemProperty(String name) {
/* 236 */     String location = System.getProperty(name);
/* 237 */     if (location != null && !location.startsWith("file:")) {
/* 238 */       location = "file:" + location;
/*     */     }
/* 240 */     return location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecureRandomFactoryBean getSecureRandom() {
/* 250 */     if (this.secureRandom == null) {
/* 251 */       return new SecureRandomFactoryBean();
/*     */     }
/* 253 */     return this.secureRandom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureRandom(SecureRandomFactoryBean secureRandom) {
/* 262 */     this.secureRandom = secureRandom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyManagerFactoryFactoryBean getKeyManagerFactory() {
/* 272 */     if (this.keyManagerFactory == null) {
/* 273 */       return new KeyManagerFactoryFactoryBean();
/*     */     }
/* 275 */     return this.keyManagerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyManagerFactory(KeyManagerFactoryFactoryBean keyManagerFactory) {
/* 284 */     this.keyManagerFactory = keyManagerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TrustManagerFactoryFactoryBean getTrustManagerFactory() {
/* 294 */     if (this.trustManagerFactory == null) {
/* 295 */       return new TrustManagerFactoryFactoryBean();
/*     */     }
/* 297 */     return this.trustManagerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustManagerFactory(TrustManagerFactoryFactoryBean trustManagerFactory) {
/* 306 */     this.trustManagerFactory = trustManagerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProtocol() {
/* 317 */     if (this.protocol == null) {
/* 318 */       return "SSL";
/*     */     }
/* 320 */     return this.protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocol(String protocol) {
/* 331 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProvider() {
/* 340 */     return this.provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProvider(String provider) {
/* 349 */     this.provider = provider;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\ssl\SSLContextFactoryBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */