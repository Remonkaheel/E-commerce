package ch.qos.logback.core.net.ssl;

public interface SSLComponent {
  SSLConfiguration getSsl();
  
  void setSsl(SSLConfiguration paramSSLConfiguration);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\ssl\SSLComponent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */