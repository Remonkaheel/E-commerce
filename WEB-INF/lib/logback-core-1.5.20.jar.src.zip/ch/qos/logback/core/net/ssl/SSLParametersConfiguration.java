/*     */ package ch.qos.logback.core.net.ssl;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import ch.qos.logback.core.util.StringCollectionUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLParametersConfiguration
/*     */   extends ContextAwareBase
/*     */ {
/*     */   private String includedProtocols;
/*     */   private String excludedProtocols;
/*     */   private String includedCipherSuites;
/*     */   private String excludedCipherSuites;
/*     */   private Boolean needClientAuth;
/*     */   private Boolean wantClientAuth;
/*     */   private String[] enabledProtocols;
/*     */   private String[] enabledCipherSuites;
/*     */   private Boolean hostnameVerification;
/*     */   
/*     */   public void configure(SSLConfigurable socket) {
/*  50 */     socket.setEnabledProtocols(enabledProtocols(socket.getSupportedProtocols(), socket.getDefaultProtocols()));
/*  51 */     socket.setEnabledCipherSuites(
/*  52 */         enabledCipherSuites(socket.getSupportedCipherSuites(), socket.getDefaultCipherSuites()));
/*  53 */     if (isNeedClientAuth() != null) {
/*  54 */       socket.setNeedClientAuth(isNeedClientAuth().booleanValue());
/*     */     }
/*  56 */     if (isWantClientAuth() != null) {
/*  57 */       socket.setWantClientAuth(isWantClientAuth().booleanValue());
/*     */     }
/*  59 */     if (this.hostnameVerification != null) {
/*  60 */       addInfo("hostnameVerification=" + this.hostnameVerification);
/*  61 */       socket.setHostnameVerification(this.hostnameVerification.booleanValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getHostnameVerification() {
/*  66 */     if (this.hostnameVerification == null)
/*  67 */       return false; 
/*  68 */     return this.hostnameVerification.booleanValue();
/*     */   }
/*     */   
/*     */   public void setHostnameVerification(boolean hostnameVerification) {
/*  72 */     this.hostnameVerification = Boolean.valueOf(hostnameVerification);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] enabledProtocols(String[] supportedProtocols, String[] defaultProtocols) {
/*  83 */     if (this.enabledProtocols == null) {
/*     */ 
/*     */       
/*  86 */       if (OptionHelper.isNullOrEmptyOrAllSpaces(getIncludedProtocols()) && 
/*  87 */         OptionHelper.isNullOrEmptyOrAllSpaces(getExcludedProtocols())) {
/*  88 */         this.enabledProtocols = Arrays.<String>copyOf(defaultProtocols, defaultProtocols.length);
/*     */       } else {
/*  90 */         this.enabledProtocols = includedStrings(supportedProtocols, getIncludedProtocols(), getExcludedProtocols());
/*     */       } 
/*  92 */       for (String protocol : this.enabledProtocols) {
/*  93 */         addInfo("enabled protocol: " + protocol);
/*     */       }
/*     */     } 
/*  96 */     return this.enabledProtocols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] enabledCipherSuites(String[] supportedCipherSuites, String[] defaultCipherSuites) {
/* 107 */     if (this.enabledCipherSuites == null) {
/*     */ 
/*     */       
/* 110 */       if (OptionHelper.isNullOrEmptyOrAllSpaces(getIncludedCipherSuites()) && 
/* 111 */         OptionHelper.isNullOrEmptyOrAllSpaces(getExcludedCipherSuites())) {
/* 112 */         this.enabledCipherSuites = Arrays.<String>copyOf(defaultCipherSuites, defaultCipherSuites.length);
/*     */       } else {
/* 114 */         this.enabledCipherSuites = includedStrings(supportedCipherSuites, getIncludedCipherSuites(), 
/* 115 */             getExcludedCipherSuites());
/*     */       } 
/* 117 */       for (String cipherSuite : this.enabledCipherSuites) {
/* 118 */         addInfo("enabled cipher suite: " + cipherSuite);
/*     */       }
/*     */     } 
/* 121 */     return this.enabledCipherSuites;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] includedStrings(String[] defaults, String included, String excluded) {
/* 136 */     List<String> values = new ArrayList<>(defaults.length);
/* 137 */     values.addAll(Arrays.asList(defaults));
/* 138 */     if (included != null) {
/* 139 */       StringCollectionUtil.retainMatching(values, stringToArray(included));
/*     */     }
/* 141 */     if (excluded != null) {
/* 142 */       StringCollectionUtil.removeMatching(values, stringToArray(excluded));
/*     */     }
/* 144 */     return values.<String>toArray(new String[values.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] stringToArray(String s) {
/* 154 */     return s.split("\\s*,\\s*");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIncludedProtocols() {
/* 164 */     return this.includedProtocols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludedProtocols(String protocols) {
/* 175 */     this.includedProtocols = protocols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExcludedProtocols() {
/* 185 */     return this.excludedProtocols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcludedProtocols(String protocols) {
/* 196 */     this.excludedProtocols = protocols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIncludedCipherSuites() {
/* 206 */     return this.includedCipherSuites;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludedCipherSuites(String cipherSuites) {
/* 217 */     this.includedCipherSuites = cipherSuites;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExcludedCipherSuites() {
/* 227 */     return this.excludedCipherSuites;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcludedCipherSuites(String cipherSuites) {
/* 238 */     this.excludedCipherSuites = cipherSuites;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isNeedClientAuth() {
/* 247 */     return this.needClientAuth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNeedClientAuth(Boolean needClientAuth) {
/* 256 */     this.needClientAuth = needClientAuth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isWantClientAuth() {
/* 265 */     return this.wantClientAuth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWantClientAuth(Boolean wantClientAuth) {
/* 274 */     this.wantClientAuth = wantClientAuth;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\ssl\SSLParametersConfiguration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */