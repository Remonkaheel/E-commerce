/*     */ package ch.qos.logback.core.net.ssl;
/*     */ 
/*     */ import ch.qos.logback.core.util.LocationUtil;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyStoreFactoryBean
/*     */ {
/*     */   private String location;
/*     */   private String provider;
/*     */   private String type;
/*     */   private String password;
/*     */   
/*     */   public KeyStore createKeyStore() throws NoSuchProviderException, NoSuchAlgorithmException, KeyStoreException {
/*  60 */     if (getLocation() == null) {
/*  61 */       throw new IllegalArgumentException("location is required");
/*     */     }
/*     */     
/*  64 */     InputStream inputStream = null;
/*     */     try {
/*  66 */       URL url = LocationUtil.urlForResource(getLocation());
/*  67 */       inputStream = url.openStream();
/*  68 */       KeyStore keyStore = newKeyStore();
/*  69 */       keyStore.load(inputStream, getPassword().toCharArray());
/*  70 */       return keyStore;
/*  71 */     } catch (NoSuchProviderException ex) {
/*  72 */       throw new NoSuchProviderException("no such keystore provider: " + getProvider());
/*  73 */     } catch (NoSuchAlgorithmException ex) {
/*  74 */       throw new NoSuchAlgorithmException("no such keystore type: " + getType());
/*  75 */     } catch (FileNotFoundException ex) {
/*  76 */       throw new KeyStoreException(getLocation() + ": file not found");
/*  77 */     } catch (Exception ex) {
/*  78 */       throw new KeyStoreException(getLocation() + ": " + getLocation(), ex);
/*     */     } finally {
/*     */       try {
/*  81 */         if (inputStream != null) {
/*  82 */           inputStream.close();
/*     */         }
/*  84 */       } catch (IOException ex) {
/*  85 */         ex.printStackTrace(System.err);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyStore newKeyStore() throws NoSuchAlgorithmException, NoSuchProviderException, KeyStoreException {
/*  96 */     return (getProvider() != null) ? KeyStore.getInstance(getType(), getProvider()) : KeyStore.getInstance(getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 105 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocation(String location) {
/* 116 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 127 */     if (this.type == null) {
/* 128 */       return "JKS";
/*     */     }
/* 130 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String type) {
/* 142 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProvider() {
/* 151 */     return this.provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProvider(String provider) {
/* 160 */     this.provider = provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 170 */     if (this.password == null) {
/* 171 */       return "changeit";
/*     */     }
/* 173 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String password) {
/* 182 */     this.password = password;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\ssl\KeyStoreFactoryBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */