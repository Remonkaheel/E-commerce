/*     */ package ch.qos.logback.core.net.server;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.CloseUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RemoteReceiverStreamClient
/*     */   extends ContextAwareBase
/*     */   implements RemoteReceiverClient
/*     */ {
/*     */   private final String clientId;
/*     */   private final Socket socket;
/*     */   private final OutputStream outputStream;
/*     */   private BlockingQueue<Serializable> queue;
/*     */   
/*     */   public RemoteReceiverStreamClient(String id, Socket socket) {
/*  49 */     this.clientId = "client " + id + ": ";
/*  50 */     this.socket = socket;
/*  51 */     this.outputStream = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RemoteReceiverStreamClient(String id, OutputStream outputStream) {
/*  64 */     this.clientId = "client " + id + ": ";
/*  65 */     this.socket = null;
/*  66 */     this.outputStream = outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueue(BlockingQueue<Serializable> queue) {
/*  73 */     this.queue = queue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offer(Serializable event) {
/*  80 */     if (this.queue == null) {
/*  81 */       throw new IllegalStateException("client has no event queue");
/*     */     }
/*  83 */     return this.queue.offer(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  90 */     if (this.socket == null)
/*     */       return; 
/*  92 */     CloseUtil.closeQuietly(this.socket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  99 */     addInfo(this.clientId + "connected");
/*     */     
/* 101 */     ObjectOutputStream oos = null;
/*     */     try {
/* 103 */       int counter = 0;
/* 104 */       oos = createObjectOutputStream();
/* 105 */       while (!Thread.currentThread().isInterrupted()) {
/*     */         try {
/* 107 */           Serializable event = this.queue.take();
/* 108 */           oos.writeObject(event);
/* 109 */           oos.flush();
/* 110 */           if (++counter >= 70) {
/*     */ 
/*     */             
/* 113 */             counter = 0;
/* 114 */             oos.reset();
/*     */           } 
/* 116 */         } catch (InterruptedException ex) {
/* 117 */           Thread.currentThread().interrupt();
/*     */         } 
/*     */       } 
/* 120 */     } catch (SocketException ex) {
/* 121 */       addInfo(this.clientId + this.clientId);
/* 122 */     } catch (IOException ex) {
/* 123 */       addError(this.clientId + this.clientId);
/* 124 */     } catch (RuntimeException ex) {
/* 125 */       addError(this.clientId + this.clientId);
/*     */     } finally {
/* 127 */       if (oos != null) {
/* 128 */         CloseUtil.closeQuietly(oos);
/*     */       }
/* 130 */       close();
/* 131 */       addInfo(this.clientId + "connection closed");
/*     */     } 
/*     */   }
/*     */   
/*     */   private ObjectOutputStream createObjectOutputStream() throws IOException {
/* 136 */     if (this.socket == null) {
/* 137 */       return new ObjectOutputStream(this.outputStream);
/*     */     }
/* 139 */     return new ObjectOutputStream(this.socket.getOutputStream());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\net\server\RemoteReceiverStreamClient.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */