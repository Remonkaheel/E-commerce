/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ConfigurationEvent;
/*     */ import ch.qos.logback.core.spi.ConfigurationEventListener;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.spi.SequenceNumberGenerator;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Context
/*     */   extends PropertyContainer
/*     */ {
/*     */   StatusManager getStatusManager();
/*     */   
/*     */   Object getObject(String paramString);
/*     */   
/*     */   void putObject(String paramString, Object paramObject);
/*     */   
/*     */   String getProperty(String paramString);
/*     */   
/*     */   void putProperty(String paramString1, String paramString2);
/*     */   
/*     */   Map<String, String> getCopyOfPropertyMap();
/*     */   
/*     */   String getName();
/*     */   
/*     */   void setName(String paramString);
/*     */   
/*     */   long getBirthTime();
/*     */   
/*     */   ReentrantLock getConfigurationLock();
/*     */   
/*     */   ScheduledExecutorService getScheduledExecutorService();
/*     */   
/*     */   ExecutorService getExecutorService();
/*     */   
/*     */   default ExecutorService getAlternateExecutorService() {
/* 141 */     return getExecutorService();
/*     */   }
/*     */   
/*     */   void register(LifeCycle paramLifeCycle);
/*     */   
/*     */   void addScheduledFuture(ScheduledFuture<?> paramScheduledFuture);
/*     */   
/*     */   SequenceNumberGenerator getSequenceNumberGenerator();
/*     */   
/*     */   void setSequenceNumberGenerator(SequenceNumberGenerator paramSequenceNumberGenerator);
/*     */   
/*     */   void addConfigurationEventListener(ConfigurationEventListener paramConfigurationEventListener);
/*     */   
/*     */   default void removeConfigurationEventListener(ConfigurationEventListener listener) {}
/*     */   
/*     */   void fireConfigurationEvent(ConfigurationEvent paramConfigurationEvent);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\Context.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */