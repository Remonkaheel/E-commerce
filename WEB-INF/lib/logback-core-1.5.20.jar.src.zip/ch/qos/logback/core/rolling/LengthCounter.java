package ch.qos.logback.core.rolling;

public interface LengthCounter {
  void add(long paramLong);
  
  long getLength();
  
  void reset();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\LengthCounter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */