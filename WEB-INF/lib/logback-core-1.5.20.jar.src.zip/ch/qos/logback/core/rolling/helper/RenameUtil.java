/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.rolling.RollingFileAppender;
/*     */ import ch.qos.logback.core.rolling.RolloverFailure;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.EnvUtil;
/*     */ import ch.qos.logback.core.util.FileUtil;
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenameUtil
/*     */   extends ContextAwareBase
/*     */ {
/*  32 */   static String RENAMING_ERROR_URL = "https://logback.qos.ch/codes.html#renamingError";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rename(String src, String target) throws RolloverFailure {
/*  43 */     if (src.equals(target)) {
/*  44 */       addWarn("Source and target files are the same [" + src + "]. Skipping.");
/*     */       return;
/*     */     } 
/*  47 */     File srcFile = new File(src);
/*     */     
/*  49 */     if (srcFile.exists()) {
/*  50 */       File targetFile = new File(target);
/*  51 */       createMissingTargetDirsIfNecessary(targetFile);
/*     */       
/*  53 */       addInfo("Renaming file [" + String.valueOf(srcFile) + "] to [" + String.valueOf(targetFile) + "]");
/*     */       
/*  55 */       boolean result = srcFile.renameTo(targetFile);
/*     */       
/*  57 */       if (!result) {
/*  58 */         addWarn("Failed to rename file [" + String.valueOf(srcFile) + "] as [" + String.valueOf(targetFile) + "].");
/*  59 */         Boolean areOnDifferentVolumes = areOnDifferentVolumes(srcFile, targetFile);
/*  60 */         if (Boolean.TRUE.equals(areOnDifferentVolumes)) {
/*  61 */           addWarn("Detected different file systems for source [" + src + "] and target [" + target + "]. Attempting rename by copying.");
/*     */           
/*  63 */           renameByCopying(src, target);
/*     */           return;
/*     */         } 
/*  66 */         addWarn("Please consider leaving the [file] option of " + RollingFileAppender.class.getSimpleName() + " empty.");
/*     */         
/*  68 */         addWarn("See also " + RENAMING_ERROR_URL);
/*     */       } 
/*     */     } else {
/*     */       
/*  72 */       throw new RolloverFailure("File [" + src + "] does not exist.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Boolean areOnDifferentVolumes(File srcFile, File targetFile) throws RolloverFailure {
/*  86 */     if (!EnvUtil.isJDK7OrHigher()) {
/*  87 */       return Boolean.valueOf(false);
/*     */     }
/*     */ 
/*     */     
/*  91 */     File parentOfTarget = targetFile.getAbsoluteFile().getParentFile();
/*     */     
/*  93 */     if (parentOfTarget == null) {
/*  94 */       addWarn("Parent of target file [" + String.valueOf(targetFile) + "] is null");
/*  95 */       return null;
/*     */     } 
/*  97 */     if (!parentOfTarget.exists()) {
/*  98 */       addWarn("Parent of target file [" + String.valueOf(targetFile) + "] does not exist");
/*  99 */       return null;
/*     */     } 
/*     */     
/*     */     try {
/* 103 */       boolean onSameFileStore = FileStoreUtil.areOnSameFileStore(srcFile, parentOfTarget);
/* 104 */       return Boolean.valueOf(!onSameFileStore);
/* 105 */     } catch (RolloverFailure rf) {
/* 106 */       addWarn("Error while checking file store equality", (Throwable)rf);
/* 107 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renameByCopying(String src, String target) throws RolloverFailure {
/* 113 */     FileUtil fileUtil = new FileUtil(getContext());
/* 114 */     fileUtil.copy(src, target);
/*     */     
/* 116 */     File srcFile = new File(src);
/* 117 */     if (!srcFile.delete()) {
/* 118 */       addWarn("Could not delete " + src);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void createMissingTargetDirsIfNecessary(File toFile) throws RolloverFailure {
/* 124 */     boolean result = FileUtil.createMissingParentDirectories(toFile);
/* 125 */     if (!result) {
/* 126 */       throw new RolloverFailure("Failed to create parent directories for [" + toFile.getAbsolutePath() + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "c.q.l.co.rolling.helper.RenameUtil";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\RenameUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */