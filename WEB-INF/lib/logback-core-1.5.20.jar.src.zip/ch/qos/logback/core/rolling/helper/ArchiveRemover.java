package ch.qos.logback.core.rolling.helper;

import ch.qos.logback.core.spi.ContextAware;
import java.time.Instant;
import java.util.concurrent.Future;

public interface ArchiveRemover extends ContextAware {
  void clean(Instant paramInstant);
  
  void setMaxHistory(int paramInt);
  
  void setTotalSizeCap(long paramLong);
  
  Future<?> cleanAsynchronously(Instant paramInstant);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\ArchiveRemover.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */