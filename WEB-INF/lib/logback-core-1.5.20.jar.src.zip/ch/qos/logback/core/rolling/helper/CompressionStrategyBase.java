/*    */ package ch.qos.logback.core.rolling.helper;
/*    */ 
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.util.FileUtil;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CompressionStrategyBase
/*    */   extends ContextAwareBase
/*    */   implements CompressionStrategy
/*    */ {
/*    */   static final int BUFFER_SIZE = 8192;
/*    */   
/*    */   void createMissingTargetDirsIfNecessary(File file) {
/* 28 */     boolean result = FileUtil.createMissingParentDirectories(file);
/* 29 */     if (!result)
/* 30 */       addError("Failed to create parent directories for [" + file.getAbsolutePath() + "]"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\CompressionStrategyBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */