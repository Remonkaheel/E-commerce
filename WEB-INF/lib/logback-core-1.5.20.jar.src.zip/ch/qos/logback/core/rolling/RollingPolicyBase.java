/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.FileAppender;
/*     */ import ch.qos.logback.core.rolling.helper.CompressionMode;
/*     */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RollingPolicyBase
/*     */   extends ContextAwareBase
/*     */   implements RollingPolicy
/*     */ {
/*  30 */   protected CompressionMode compressionMode = CompressionMode.NONE;
/*     */ 
/*     */   
/*     */   FileNamePattern fileNamePattern;
/*     */ 
/*     */   
/*     */   protected String fileNamePatternStr;
/*     */ 
/*     */   
/*     */   private FileAppender<?> parent;
/*     */ 
/*     */   
/*     */   FileNamePattern zipEntryFileNamePattern;
/*     */ 
/*     */   
/*     */   private boolean started;
/*     */ 
/*     */ 
/*     */   
/*     */   protected void determineCompressionMode() {
/*  50 */     if (this.fileNamePatternStr.endsWith(CompressionMode.GZ_SUFFIX)) {
/*  51 */       addInfo("Will use gz compression");
/*  52 */       this.compressionMode = CompressionMode.GZ;
/*  53 */     } else if (this.fileNamePatternStr.endsWith(CompressionMode.ZIP_SUFFIX)) {
/*  54 */       addInfo("Will use zip compression");
/*  55 */       this.compressionMode = CompressionMode.ZIP;
/*  56 */     } else if (this.fileNamePatternStr.endsWith(CompressionMode.XZ_SUFFIX)) {
/*  57 */       addInfo("Will use xz compression");
/*  58 */       this.compressionMode = CompressionMode.XZ;
/*     */     } else {
/*  60 */       addInfo("No compression will be used");
/*  61 */       this.compressionMode = CompressionMode.NONE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adjustCompressionModeAndFileNamePatternStrIfNecessary() {
/*  69 */     if (this.compressionMode == CompressionMode.XZ) {
/*  70 */       boolean xzLibraryLoadable = Loader.isClassLoadable("org.tukaani.xz.XZOutputStream", getContext());
/*  71 */       if (!xzLibraryLoadable) {
/*  72 */         addWarn("XZ library missing, falling back to GZ compression");
/*  73 */         this.compressionMode = CompressionMode.GZ;
/*  74 */         this.fileNamePatternStr = replaceSuffix(this.fileNamePatternStr, CompressionMode.XZ_SUFFIX, CompressionMode.GZ_SUFFIX);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String replaceSuffix(String input, String existingSuffix, String newSuffix) {
/*  80 */     int existingSuffixLen = existingSuffix.length();
/*  81 */     if (input.endsWith(existingSuffix)) {
/*  82 */       return input.substring(0, input.length() - existingSuffixLen) + input.substring(0, input.length() - existingSuffixLen);
/*     */     }
/*     */     
/*  85 */     throw new IllegalArgumentException("[" + input + "] should end with " + existingSuffix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFileNamePattern(String fnp) {
/*  90 */     this.fileNamePatternStr = fnp;
/*     */   }
/*     */   
/*     */   public String getFileNamePattern() {
/*  94 */     return this.fileNamePatternStr;
/*     */   }
/*     */   
/*     */   public CompressionMode getCompressionMode() {
/*  98 */     return this.compressionMode;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 102 */     return this.started;
/*     */   }
/*     */   
/*     */   public void start() {
/* 106 */     this.started = true;
/*     */   }
/*     */   
/*     */   public void stop() {
/* 110 */     this.started = false;
/*     */   }
/*     */   
/*     */   public void setParent(FileAppender<?> appender) {
/* 114 */     this.parent = appender;
/*     */   }
/*     */   
/*     */   public boolean isParentPrudent() {
/* 118 */     return this.parent.isPrudent();
/*     */   }
/*     */   
/*     */   public String getParentsRawFileProperty() {
/* 122 */     return this.parent.rawFileProperty();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\RollingPolicyBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */