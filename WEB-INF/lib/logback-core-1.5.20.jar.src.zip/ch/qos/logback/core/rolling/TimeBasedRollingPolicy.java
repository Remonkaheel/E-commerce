/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.rolling.helper.ArchiveRemover;
/*     */ import ch.qos.logback.core.rolling.helper.CompressionMode;
/*     */ import ch.qos.logback.core.rolling.helper.Compressor;
/*     */ import ch.qos.logback.core.rolling.helper.FileFilterUtil;
/*     */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*     */ import ch.qos.logback.core.rolling.helper.RenameUtil;
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import java.io.File;
/*     */ import java.time.Instant;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeBasedRollingPolicy<E>
/*     */   extends RollingPolicyBase
/*     */   implements TriggeringPolicy<E>
/*     */ {
/*     */   static final String FNP_NOT_SET = "The FileNamePattern option must be set before using TimeBasedRollingPolicy. ";
/*     */   FileNamePattern fileNamePatternWithoutCompSuffix;
/*     */   private Compressor compressor;
/*  51 */   private RenameUtil renameUtil = new RenameUtil();
/*     */   
/*     */   Future<?> compressionFuture;
/*     */   Future<?> cleanUpFuture;
/*  55 */   private int maxHistory = 0;
/*  56 */   protected FileSize totalSizeCap = new FileSize(0L);
/*     */   
/*     */   private ArchiveRemover archiveRemover;
/*     */   
/*     */   TimeBasedFileNamingAndTriggeringPolicy<E> timeBasedFileNamingAndTriggeringPolicy;
/*     */   
/*     */   boolean cleanHistoryOnStart = false;
/*     */ 
/*     */   
/*     */   public void start() {
/*  66 */     this.renameUtil.setContext(this.context);
/*     */ 
/*     */     
/*  69 */     if (this.fileNamePatternStr != null) {
/*  70 */       determineCompressionMode();
/*  71 */       adjustCompressionModeAndFileNamePatternStrIfNecessary();
/*  72 */       this.fileNamePattern = new FileNamePattern(this.fileNamePatternStr, this.context);
/*     */     } else {
/*  74 */       addWarn("The FileNamePattern option must be set before using TimeBasedRollingPolicy. ");
/*  75 */       addWarn("See also https://logback.qos.ch/codes.html#tbr_fnp_not_set");
/*  76 */       throw new IllegalStateException("The FileNamePattern option must be set before using TimeBasedRollingPolicy. See also https://logback.qos.ch/codes.html#tbr_fnp_not_set");
/*     */     } 
/*     */     
/*  79 */     this.compressor = new Compressor(this.compressionMode);
/*  80 */     this.compressor.setContext(this.context);
/*     */ 
/*     */     
/*  83 */     this
/*  84 */       .fileNamePatternWithoutCompSuffix = new FileNamePattern(Compressor.computeFileNameStrWithoutCompSuffix(this.fileNamePatternStr, this.compressionMode), this.context);
/*     */     
/*  86 */     addInfo("Will use the pattern " + String.valueOf(this.fileNamePatternWithoutCompSuffix) + " for the active file");
/*     */     
/*  88 */     if (this.compressionMode == CompressionMode.ZIP) {
/*  89 */       String zipEntryFileNamePatternStr = transformFileNamePattern2ZipEntry(this.fileNamePatternStr);
/*  90 */       this.zipEntryFileNamePattern = new FileNamePattern(zipEntryFileNamePatternStr, this.context);
/*     */     } 
/*     */     
/*  93 */     if (this.timeBasedFileNamingAndTriggeringPolicy == null) {
/*  94 */       this.timeBasedFileNamingAndTriggeringPolicy = new DefaultTimeBasedFileNamingAndTriggeringPolicy<>();
/*     */     }
/*  96 */     this.timeBasedFileNamingAndTriggeringPolicy.setContext(this.context);
/*  97 */     this.timeBasedFileNamingAndTriggeringPolicy.setTimeBasedRollingPolicy(this);
/*  98 */     this.timeBasedFileNamingAndTriggeringPolicy.start();
/*     */     
/* 100 */     if (!this.timeBasedFileNamingAndTriggeringPolicy.isStarted()) {
/* 101 */       addWarn("Subcomponent did not start. TimeBasedRollingPolicy will not start.");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 108 */     if (this.maxHistory != 0) {
/* 109 */       this.archiveRemover = this.timeBasedFileNamingAndTriggeringPolicy.getArchiveRemover();
/* 110 */       this.archiveRemover.setMaxHistory(this.maxHistory);
/* 111 */       this.archiveRemover.setTotalSizeCap(this.totalSizeCap.getSize());
/* 112 */       if (this.cleanHistoryOnStart) {
/* 113 */         addInfo("Cleaning on start up");
/* 114 */         Instant now = Instant.ofEpochMilli(this.timeBasedFileNamingAndTriggeringPolicy.getCurrentTime());
/* 115 */         this.cleanUpFuture = this.archiveRemover.cleanAsynchronously(now);
/*     */       } 
/* 117 */     } else if (!isUnboundedTotalSizeCap()) {
/* 118 */       addWarn("'maxHistory' is not set, ignoring 'totalSizeCap' option with value [" + String.valueOf(this.totalSizeCap) + "]");
/*     */     } 
/*     */     
/* 121 */     super.start();
/*     */   }
/*     */   
/*     */   protected boolean isUnboundedTotalSizeCap() {
/* 125 */     return (this.totalSizeCap.getSize() == 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 130 */     if (!isStarted())
/*     */       return; 
/* 132 */     waitForAsynchronousJobToStop(this.compressionFuture, "compression");
/* 133 */     waitForAsynchronousJobToStop(this.cleanUpFuture, "clean-up");
/* 134 */     super.stop();
/*     */   }
/*     */   
/*     */   private void waitForAsynchronousJobToStop(Future<?> aFuture, String jobDescription) {
/* 138 */     if (aFuture != null) {
/*     */       try {
/* 140 */         aFuture.get(30L, TimeUnit.SECONDS);
/* 141 */       } catch (TimeoutException e) {
/* 142 */         addError("Timeout while waiting for " + jobDescription + " job to finish", e);
/* 143 */       } catch (Exception e) {
/* 144 */         addError("Unexpected exception while waiting for " + jobDescription + " job to finish", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private String transformFileNamePattern2ZipEntry(String fileNamePatternStr) {
/* 150 */     String slashified = FileFilterUtil.slashify(fileNamePatternStr);
/* 151 */     return FileFilterUtil.afterLastSlash(slashified);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeBasedFileNamingAndTriggeringPolicy(TimeBasedFileNamingAndTriggeringPolicy<E> timeBasedTriggering) {
/* 156 */     this.timeBasedFileNamingAndTriggeringPolicy = timeBasedTriggering;
/*     */   }
/*     */   
/*     */   public TimeBasedFileNamingAndTriggeringPolicy<E> getTimeBasedFileNamingAndTriggeringPolicy() {
/* 160 */     return this.timeBasedFileNamingAndTriggeringPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollover() throws RolloverFailure {
/* 168 */     String elapsedPeriodsFileName = this.timeBasedFileNamingAndTriggeringPolicy.getElapsedPeriodsFileName();
/*     */     
/* 170 */     String elapsedPeriodStem = FileFilterUtil.afterLastSlash(elapsedPeriodsFileName);
/*     */     
/* 172 */     if (this.compressionMode == CompressionMode.NONE) {
/* 173 */       if (getParentsRawFileProperty() != null) {
/* 174 */         this.renameUtil.rename(getParentsRawFileProperty(), elapsedPeriodsFileName);
/*     */       
/*     */       }
/*     */     }
/* 178 */     else if (getParentsRawFileProperty() == null) {
/* 179 */       this.compressionFuture = this.compressor.asyncCompress(elapsedPeriodsFileName, elapsedPeriodsFileName, elapsedPeriodStem);
/*     */     } else {
/*     */       
/* 182 */       this.compressionFuture = renameRawAndAsyncCompress(elapsedPeriodsFileName, elapsedPeriodStem);
/*     */     } 
/*     */ 
/*     */     
/* 186 */     if (this.archiveRemover != null) {
/* 187 */       Instant now = Instant.ofEpochMilli(this.timeBasedFileNamingAndTriggeringPolicy.getCurrentTime());
/* 188 */       this.cleanUpFuture = this.archiveRemover.cleanAsynchronously(now);
/*     */     } 
/*     */   }
/*     */   
/*     */   Future<?> renameRawAndAsyncCompress(String nameOfCompressedFile, String innerEntryName) throws RolloverFailure {
/* 193 */     String parentsRawFile = getParentsRawFileProperty();
/* 194 */     String tmpTarget = nameOfCompressedFile + nameOfCompressedFile + ".tmp";
/* 195 */     this.renameUtil.rename(parentsRawFile, tmpTarget);
/* 196 */     return this.compressor.asyncCompress(tmpTarget, nameOfCompressedFile, innerEntryName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActiveFileName() {
/* 222 */     String parentsRawFileProperty = getParentsRawFileProperty();
/* 223 */     if (parentsRawFileProperty != null) {
/* 224 */       return parentsRawFileProperty;
/*     */     }
/* 226 */     return this.timeBasedFileNamingAndTriggeringPolicy.getCurrentPeriodsFileNameWithoutCompressionSuffix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTriggeringEvent(File activeFile, E event) {
/* 238 */     return this.timeBasedFileNamingAndTriggeringPolicy.isTriggeringEvent(activeFile, event);
/*     */   }
/*     */ 
/*     */   
/*     */   public LengthCounter getLengthCounter() {
/* 243 */     return this.timeBasedFileNamingAndTriggeringPolicy.getLengthCounter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxHistory() {
/* 252 */     return this.maxHistory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxHistory(int maxHistory) {
/* 261 */     this.maxHistory = maxHistory;
/*     */   }
/*     */   
/*     */   public boolean isCleanHistoryOnStart() {
/* 265 */     return this.cleanHistoryOnStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCleanHistoryOnStart(boolean cleanHistoryOnStart) {
/* 276 */     this.cleanHistoryOnStart = cleanHistoryOnStart;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 281 */     return "c.q.l.core.rolling.TimeBasedRollingPolicy@" + hashCode();
/*     */   }
/*     */   
/*     */   public void setTotalSizeCap(FileSize totalSizeCap) {
/* 285 */     addInfo("setting totalSizeCap to " + totalSizeCap.toString());
/* 286 */     this.totalSizeCap = totalSizeCap;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\TimeBasedRollingPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */