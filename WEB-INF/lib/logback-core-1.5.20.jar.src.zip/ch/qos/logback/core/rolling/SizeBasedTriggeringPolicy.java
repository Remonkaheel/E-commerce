/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ import ch.qos.logback.core.util.Duration;
/*    */ import ch.qos.logback.core.util.FileSize;
/*    */ import ch.qos.logback.core.util.InvocationGate;
/*    */ import ch.qos.logback.core.util.SimpleInvocationGate;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeBasedTriggeringPolicy<E>
/*    */   extends TriggeringPolicyBase<E>
/*    */ {
/*    */   public static final String SEE_SIZE_FORMAT = "http://logback.qos.ch/codes.html#sbtp_size_format";
/*    */   public static final long DEFAULT_MAX_FILE_SIZE = 10485760L;
/* 43 */   FileSize maxFileSize = new FileSize(10485760L);
/* 44 */   InvocationGate invocationGate = (InvocationGate)new SimpleInvocationGate();
/* 45 */   Duration checkIncrement = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void start() {
/* 51 */     if (this.checkIncrement != null)
/* 52 */       this.invocationGate = (InvocationGate)new SimpleInvocationGate(this.checkIncrement); 
/* 53 */     super.start();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isTriggeringEvent(File activeFile, E event) {
/* 58 */     long now = System.currentTimeMillis();
/* 59 */     if (this.invocationGate.isTooSoon(now)) {
/* 60 */       return false;
/*    */     }
/* 62 */     return (activeFile.length() >= this.maxFileSize.getSize());
/*    */   }
/*    */   
/*    */   public FileSize getMaxFileSize() {
/* 66 */     return this.maxFileSize;
/*    */   }
/*    */   
/*    */   public void setMaxFileSize(FileSize aMaxFileSize) {
/* 70 */     this.maxFileSize = aMaxFileSize;
/*    */   }
/*    */   
/*    */   public Duration getCheckIncrement() {
/* 74 */     return this.checkIncrement;
/*    */   }
/*    */   
/*    */   public void setCheckIncrement(Duration checkIncrement) {
/* 78 */     this.checkIncrement = checkIncrement;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\SizeBasedTriggeringPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */