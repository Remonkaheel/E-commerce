/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.NoAutoStart;
/*    */ import ch.qos.logback.core.rolling.helper.ArchiveRemover;
/*    */ import ch.qos.logback.core.rolling.helper.TimeBasedArchiveRemover;
/*    */ import java.io.File;
/*    */ import java.time.Instant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @NoAutoStart
/*    */ public class DefaultTimeBasedFileNamingAndTriggeringPolicy<E>
/*    */   extends TimeBasedFileNamingAndTriggeringPolicyBase<E>
/*    */ {
/*    */   public void start() {
/* 36 */     super.start();
/* 37 */     if (!isErrorFree())
/*    */       return; 
/* 39 */     if (this.tbrp.fileNamePattern.hasIntegerTokenCOnverter()) {
/* 40 */       addError("Filename pattern [" + String.valueOf(this.tbrp.fileNamePattern) + "] contains an integer token converter, i.e. %i, INCOMPATIBLE with this configuration. Please remove it.");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 45 */     this.archiveRemover = (ArchiveRemover)new TimeBasedArchiveRemover(this.tbrp.fileNamePattern, this.rc);
/* 46 */     this.archiveRemover.setContext(this.context);
/* 47 */     this.started = true;
/*    */   }
/*    */   
/*    */   public boolean isTriggeringEvent(File activeFile, E event) {
/* 51 */     long currentTime = getCurrentTime();
/* 52 */     long localNextCheck = this.atomicNextCheck.get();
/* 53 */     if (currentTime >= localNextCheck) {
/* 54 */       long nextCheck = computeNextCheck(currentTime);
/* 55 */       this.atomicNextCheck.set(nextCheck);
/* 56 */       Instant instantOfElapsedPeriod = this.dateInCurrentPeriod;
/* 57 */       addInfo("Elapsed period: " + instantOfElapsedPeriod.toString());
/* 58 */       this.elapsedPeriodsFileName = this.tbrp.fileNamePatternWithoutCompSuffix.convert(instantOfElapsedPeriod);
/* 59 */       setDateInCurrentPeriod(currentTime);
/* 60 */       return true;
/*    */     } 
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return "c.q.l.core.rolling.DefaultTimeBasedFileNamingAndTriggeringPolicy";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\DefaultTimeBasedFileNamingAndTriggeringPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */