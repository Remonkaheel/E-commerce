package ch.qos.logback.core.rolling.helper;

import ch.qos.logback.core.spi.ContextAware;

public interface CompressionStrategy extends ContextAware {
  void compress(String paramString1, String paramString2, String paramString3);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\CompressionStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */