package ch.qos.logback.core.rolling.helper;

public interface MonoTypedConverter {
  boolean isApplicable(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\MonoTypedConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */