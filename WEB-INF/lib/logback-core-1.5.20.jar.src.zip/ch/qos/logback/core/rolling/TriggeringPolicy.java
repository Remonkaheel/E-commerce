/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TriggeringPolicy<E>
/*    */   extends LifeCycle
/*    */ {
/*    */   default LengthCounter getLengthCounter() {
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   boolean isTriggeringEvent(File paramFile, E paramE);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\TriggeringPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */