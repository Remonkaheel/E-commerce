/*    */ package ch.qos.logback.core.rolling.helper;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import org.tukaani.xz.FilterOptions;
/*    */ import org.tukaani.xz.LZMA2Options;
/*    */ import org.tukaani.xz.XZOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XZCompressionStrategy
/*    */   extends CompressionStrategyBase
/*    */ {
/*    */   public void compress(String nameOfFile2xz, String nameOfxzedFile, String innerEntryName) {
/* 36 */     File file2xz = new File(nameOfFile2xz);
/*    */     
/* 38 */     if (!file2xz.exists()) {
/* 39 */       addWarn("The file to compress named [" + nameOfFile2xz + "] does not exist.");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 44 */     if (!nameOfxzedFile.endsWith(".xz")) {
/* 45 */       nameOfxzedFile = nameOfxzedFile + ".xz";
/*    */     }
/*    */     
/* 48 */     File xzedFile = new File(nameOfxzedFile);
/*    */     
/* 50 */     if (xzedFile.exists()) {
/* 51 */       addWarn("The target compressed file named [" + nameOfxzedFile + "] exist already. Aborting file compression.");
/*    */       
/*    */       return;
/*    */     } 
/* 55 */     addInfo("XZ compressing [" + String.valueOf(file2xz) + "] as [" + String.valueOf(xzedFile) + "]");
/* 56 */     createMissingTargetDirsIfNecessary(xzedFile);
/*    */     
/* 58 */     try { BufferedInputStream bis = new BufferedInputStream(new FileInputStream(nameOfFile2xz)); 
/* 59 */       try { XZOutputStream xzos = new XZOutputStream(new FileOutputStream(nameOfxzedFile), (FilterOptions)new LZMA2Options());
/*    */         
/* 61 */         try { byte[] inbuf = new byte[8192];
/*    */           
/*    */           int n;
/* 64 */           while ((n = bis.read(inbuf)) != -1) {
/* 65 */             xzos.write(inbuf, 0, n);
/*    */           }
/* 67 */           xzos.close(); } catch (Throwable throwable) { try { xzos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  bis.close(); } catch (Throwable throwable) { try { bis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/* 68 */     { addError("Error occurred while compressing [" + nameOfFile2xz + "] into [" + nameOfxzedFile + "].", e); }
/*    */ 
/*    */     
/* 71 */     if (!file2xz.delete())
/* 72 */       addWarn("Could not delete [" + nameOfFile2xz + "]."); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\XZCompressionStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */