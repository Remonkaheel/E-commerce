/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneId;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollingCalendar
/*     */   extends GregorianCalendar
/*     */ {
/*     */   private static final long serialVersionUID = -5937537740925066161L;
/*  47 */   static final TimeZone GMT_TIMEZONE = TimeZone.getTimeZone("GMT");
/*     */   
/*  49 */   PeriodicityType periodicityType = PeriodicityType.ERRONEOUS;
/*     */   
/*     */   String datePattern;
/*     */   
/*     */   public RollingCalendar(String datePattern) {
/*  54 */     this.datePattern = datePattern;
/*  55 */     this.periodicityType = computePeriodicityType();
/*     */   }
/*     */   
/*     */   public RollingCalendar(String datePattern, TimeZone tz, Locale locale) {
/*  59 */     super(tz, locale);
/*  60 */     this.datePattern = datePattern;
/*  61 */     this.periodicityType = computePeriodicityType();
/*     */   }
/*     */   
/*     */   public PeriodicityType getPeriodicityType() {
/*  65 */     return this.periodicityType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PeriodicityType computePeriodicityType() {
/*  78 */     GregorianCalendar calendar = new GregorianCalendar(GMT_TIMEZONE, Locale.getDefault());
/*     */ 
/*     */     
/*  81 */     Instant epoch = Instant.ofEpochMilli(0L);
/*  82 */     ZoneId gmtZone = ZoneId.of("UTC");
/*  83 */     if (this.datePattern != null) {
/*  84 */       for (PeriodicityType i : PeriodicityType.VALID_ORDERED_LIST) {
/*  85 */         DateTimeFormatter dtf = DateTimeFormatter.ofPattern(this.datePattern).withZone(gmtZone);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  90 */         String r0 = dtf.format(epoch);
/*     */         
/*  92 */         Instant next = innerGetEndOfThisPeriod(calendar, i, epoch);
/*  93 */         String r1 = dtf.format(next);
/*     */ 
/*     */         
/*  96 */         if (r0 != null && r1 != null && !r0.equals(r1)) {
/*  97 */           return i;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 102 */     return PeriodicityType.ERRONEOUS;
/*     */   }
/*     */   
/*     */   public boolean isCollisionFree() {
/* 106 */     switch (this.periodicityType) {
/*     */       
/*     */       case TOP_OF_HOUR:
/* 109 */         return !collision(43200000L);
/*     */ 
/*     */       
/*     */       case TOP_OF_DAY:
/* 113 */         if (collision(604800000L)) {
/* 114 */           return false;
/*     */         }
/* 116 */         if (collision(2678400000L)) {
/* 117 */           return false;
/*     */         }
/* 119 */         if (collision(31536000000L))
/* 120 */           return false; 
/* 121 */         return true;
/*     */       
/*     */       case TOP_OF_WEEK:
/* 124 */         if (collision(2937600000L)) {
/* 125 */           return false;
/*     */         }
/* 127 */         if (collision(31622400000L))
/* 128 */           return false; 
/* 129 */         return true;
/*     */     } 
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean collision(long delta) {
/* 136 */     SimpleDateFormat simpleDateFormat = new SimpleDateFormat(this.datePattern);
/* 137 */     simpleDateFormat.setTimeZone(GMT_TIMEZONE);
/* 138 */     Date epoch0 = new Date(0L);
/* 139 */     String r0 = simpleDateFormat.format(epoch0);
/* 140 */     Date epoch12 = new Date(delta);
/* 141 */     String r12 = simpleDateFormat.format(epoch12);
/*     */     
/* 143 */     return r0.equals(r12);
/*     */   }
/*     */   
/*     */   public void printPeriodicity(ContextAwareBase cab) {
/* 147 */     switch (this.periodicityType) {
/*     */       case TOP_OF_MILLISECOND:
/* 149 */         cab.addInfo("Roll-over every millisecond.");
/*     */         return;
/*     */       
/*     */       case TOP_OF_SECOND:
/* 153 */         cab.addInfo("Roll-over every second.");
/*     */         return;
/*     */       
/*     */       case TOP_OF_MINUTE:
/* 157 */         cab.addInfo("Roll-over every minute.");
/*     */         return;
/*     */       
/*     */       case TOP_OF_HOUR:
/* 161 */         cab.addInfo("Roll-over at the top of every hour.");
/*     */         return;
/*     */       
/*     */       case HALF_DAY:
/* 165 */         cab.addInfo("Roll-over at midday and midnight.");
/*     */         return;
/*     */       
/*     */       case TOP_OF_DAY:
/* 169 */         cab.addInfo("Roll-over at midnight.");
/*     */         return;
/*     */       
/*     */       case TOP_OF_WEEK:
/* 173 */         cab.addInfo("Rollover at the start of week.");
/*     */         return;
/*     */       
/*     */       case TOP_OF_MONTH:
/* 177 */         cab.addInfo("Rollover at start of every month.");
/*     */         return;
/*     */     } 
/*     */     
/* 181 */     cab.addInfo("Unknown periodicity.");
/*     */   }
/*     */ 
/*     */   
/*     */   public long periodBarriersCrossed(long start, long end) {
/* 186 */     if (start > end) {
/* 187 */       throw new IllegalArgumentException("Start cannot come before end");
/*     */     }
/* 189 */     long startFloored = getStartOfCurrentPeriodWithGMTOffsetCorrection(start, getTimeZone());
/* 190 */     long endFloored = getStartOfCurrentPeriodWithGMTOffsetCorrection(end, getTimeZone());
/*     */     
/* 192 */     long diff = endFloored - startFloored;
/*     */     
/* 194 */     switch (this.periodicityType) {
/*     */       
/*     */       case TOP_OF_MILLISECOND:
/* 197 */         return diff;
/*     */       case TOP_OF_SECOND:
/* 199 */         return diff / 1000L;
/*     */       case TOP_OF_MINUTE:
/* 201 */         return diff / 60000L;
/*     */       case TOP_OF_HOUR:
/* 203 */         return diff / 3600000L;
/*     */       case TOP_OF_DAY:
/* 205 */         return diff / 86400000L;
/*     */       case TOP_OF_WEEK:
/* 207 */         return diff / 604800000L;
/*     */       case TOP_OF_MONTH:
/* 209 */         return diffInMonths(start, end);
/*     */     } 
/* 211 */     throw new IllegalStateException("Unknown periodicity type.");
/*     */   }
/*     */ 
/*     */   
/*     */   public static int diffInMonths(long startTime, long endTime) {
/* 216 */     if (startTime > endTime)
/* 217 */       throw new IllegalArgumentException("startTime cannot be larger than endTime"); 
/* 218 */     Calendar startCal = Calendar.getInstance();
/* 219 */     startCal.setTimeInMillis(startTime);
/* 220 */     Calendar endCal = Calendar.getInstance();
/* 221 */     endCal.setTimeInMillis(endTime);
/* 222 */     int yearDiff = endCal.get(1) - startCal.get(1);
/* 223 */     int monthDiff = endCal.get(2) - startCal.get(2);
/* 224 */     return yearDiff * 12 + monthDiff;
/*     */   }
/*     */   
/*     */   private static Instant innerGetEndOfThisPeriod(Calendar cal, PeriodicityType periodicityType, Instant instant) {
/* 228 */     return innerGetEndOfNextNthPeriod(cal, periodicityType, instant, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Instant innerGetEndOfNextNthPeriod(Calendar cal, PeriodicityType periodicityType, Instant instant, int numPeriods) {
/* 233 */     cal.setTimeInMillis(instant.toEpochMilli());
/* 234 */     switch (periodicityType) {
/*     */       case TOP_OF_MILLISECOND:
/* 236 */         cal.add(14, numPeriods);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 287 */         return Instant.ofEpochMilli(cal.getTimeInMillis());case TOP_OF_SECOND: cal.set(14, 0); cal.add(13, numPeriods); return Instant.ofEpochMilli(cal.getTimeInMillis());case TOP_OF_MINUTE: cal.set(13, 0); cal.set(14, 0); cal.add(12, numPeriods); return Instant.ofEpochMilli(cal.getTimeInMillis());case TOP_OF_HOUR: cal.set(12, 0); cal.set(13, 0); cal.set(14, 0); cal.add(11, numPeriods); return Instant.ofEpochMilli(cal.getTimeInMillis());case TOP_OF_DAY: cal.set(11, 0); cal.set(12, 0); cal.set(13, 0); cal.set(14, 0); cal.add(5, numPeriods); return Instant.ofEpochMilli(cal.getTimeInMillis());case TOP_OF_WEEK: cal.set(7, cal.getFirstDayOfWeek()); cal.set(11, 0); cal.set(12, 0); cal.set(13, 0); cal.set(14, 0); cal.add(3, numPeriods); return Instant.ofEpochMilli(cal.getTimeInMillis());case TOP_OF_MONTH: cal.set(5, 1); cal.set(11, 0); cal.set(12, 0); cal.set(13, 0); cal.set(14, 0); cal.add(2, numPeriods); return Instant.ofEpochMilli(cal.getTimeInMillis());
/*     */     } 
/*     */     throw new IllegalStateException("Unknown periodicity type.");
/*     */   } public Instant getEndOfNextNthPeriod(Instant instant, int periods) {
/* 291 */     return innerGetEndOfNextNthPeriod(this, this.periodicityType, instant, periods);
/*     */   }
/*     */   
/*     */   public Instant getNextTriggeringDate(Instant instant) {
/* 295 */     return getEndOfNextNthPeriod(instant, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getStartOfCurrentPeriodWithGMTOffsetCorrection(long now, TimeZone timezone) {
/* 304 */     Calendar aCal = Calendar.getInstance(timezone);
/* 305 */     aCal.setTimeInMillis(now);
/* 306 */     Instant instant = Instant.ofEpochMilli(aCal.getTimeInMillis());
/* 307 */     Instant toppedInstant = getEndOfNextNthPeriod(instant, 0);
/*     */     
/* 309 */     Calendar secondCalendar = Calendar.getInstance(timezone);
/* 310 */     secondCalendar.setTimeInMillis(toppedInstant.toEpochMilli());
/* 311 */     long gmtOffset = (secondCalendar.get(15) + secondCalendar.get(16));
/* 312 */     return toppedInstant.toEpochMilli() + gmtOffset;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\RollingCalendar.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */