/*    */ package ch.qos.logback.core.rolling.helper;
/*    */ 
/*    */ import ch.qos.logback.core.status.ErrorStatus;
/*    */ import ch.qos.logback.core.status.Status;
/*    */ import ch.qos.logback.core.status.WarnStatus;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.util.zip.GZIPOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GZCompressionStrategy
/*    */   extends CompressionStrategyBase
/*    */ {
/*    */   public void compress(String originalFileName, String compressedFileName, String innerEntryName) {
/* 32 */     File file2gz = new File(originalFileName);
/*    */     
/* 34 */     if (!file2gz.exists()) {
/* 35 */       addStatus((Status)new WarnStatus("The file to compress named [" + originalFileName + "] does not exist.", this));
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 40 */     if (!compressedFileName.endsWith(".gz")) {
/* 41 */       compressedFileName = compressedFileName + ".gz";
/*    */     }
/*    */     
/* 44 */     File gzedFile = new File(compressedFileName);
/*    */     
/* 46 */     if (gzedFile.exists()) {
/* 47 */       addWarn("The target compressed file named [" + compressedFileName + "] exist already. Aborting file compression.");
/*    */       
/*    */       return;
/*    */     } 
/* 51 */     addInfo("GZ compressing [" + String.valueOf(file2gz) + "] as [" + String.valueOf(gzedFile) + "]");
/* 52 */     createMissingTargetDirsIfNecessary(gzedFile);
/*    */     
/* 54 */     try { BufferedInputStream bis = new BufferedInputStream(new FileInputStream(originalFileName)); 
/* 55 */       try { GZIPOutputStream gzos = new GZIPOutputStream(new FileOutputStream(compressedFileName));
/*    */         
/* 57 */         try { byte[] inbuf = new byte[8192];
/*    */           
/*    */           int n;
/* 60 */           while ((n = bis.read(inbuf)) != -1) {
/* 61 */             gzos.write(inbuf, 0, n);
/*    */           }
/*    */           
/* 64 */           addInfo("Done GZ compressing [" + String.valueOf(file2gz) + "] as [" + String.valueOf(gzedFile) + "]");
/* 65 */           gzos.close(); } catch (Throwable throwable) { try { gzos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  bis.close(); } catch (Throwable throwable) { try { bis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/* 66 */     { addStatus((Status)new ErrorStatus("Error occurred while compressing [" + originalFileName + "] into [" + compressedFileName + "].", this, e)); }
/*    */ 
/*    */     
/* 69 */     if (!file2gz.delete())
/* 70 */       addStatus((Status)new WarnStatus("Could not delete [" + originalFileName + "].", this)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\GZCompressionStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */