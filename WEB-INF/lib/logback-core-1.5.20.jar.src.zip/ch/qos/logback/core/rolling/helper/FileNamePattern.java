/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.pattern.ConverterUtil;
/*     */ import ch.qos.logback.core.pattern.DynamicConverter;
/*     */ import ch.qos.logback.core.pattern.parser.Node;
/*     */ import ch.qos.logback.core.pattern.parser.Parser;
/*     */ import ch.qos.logback.core.pattern.util.AlmostAsIsEscapeUtil;
/*     */ import ch.qos.logback.core.pattern.util.IEscapeUtil;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import java.time.Instant;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileNamePattern
/*     */   extends ContextAwareBase
/*     */ {
/*  43 */   static final Map<String, Supplier<DynamicConverter>> CONVERTER_MAP = new HashMap<>();
/*     */   static {
/*  45 */     CONVERTER_MAP.put("i", IntegerTokenConverter::new);
/*  46 */     CONVERTER_MAP.put("d", DateTokenConverter::new);
/*     */   }
/*     */ 
/*     */   
/*     */   String pattern;
/*     */   Converter<Object> headTokenConverter;
/*     */   
/*     */   public FileNamePattern(String patternArg, Context contextArg) {
/*  54 */     setPattern(FileFilterUtil.slashify(patternArg));
/*  55 */     setContext(contextArg);
/*  56 */     parse();
/*  57 */     ConverterUtil.startConverters(this.headTokenConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parse() {
/*     */     try {
/*  68 */       String patternForParsing = escapeRightParantesis(this.pattern);
/*  69 */       Parser<Object> p = new Parser(patternForParsing, (IEscapeUtil)new AlmostAsIsEscapeUtil());
/*  70 */       p.setContext(this.context);
/*  71 */       Node t = p.parse();
/*  72 */       this.headTokenConverter = p.compile(t, CONVERTER_MAP);
/*     */     }
/*  74 */     catch (ScanException sce) {
/*  75 */       addError("Failed to parse pattern \"" + this.pattern + "\".", (Throwable)sce);
/*     */     } 
/*     */   }
/*     */   
/*     */   String escapeRightParantesis(String in) {
/*  80 */     return this.pattern.replace(")", "\\)");
/*     */   }
/*     */   
/*     */   public String toString() {
/*  84 */     return this.pattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  89 */     int prime = 31;
/*  90 */     int result = 1;
/*  91 */     result = 31 * result + ((this.pattern == null) ? 0 : this.pattern.hashCode());
/*  92 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  97 */     if (this == obj)
/*  98 */       return true; 
/*  99 */     if (obj == null)
/* 100 */       return false; 
/* 101 */     if (getClass() != obj.getClass())
/* 102 */       return false; 
/* 103 */     FileNamePattern other = (FileNamePattern)obj;
/* 104 */     if (this.pattern == null) {
/* 105 */       if (other.pattern != null)
/* 106 */         return false; 
/* 107 */     } else if (!this.pattern.equals(other.pattern)) {
/* 108 */       return false;
/* 109 */     }  return true;
/*     */   }
/*     */   
/*     */   public DateTokenConverter<Object> getPrimaryDateTokenConverter() {
/* 113 */     Converter<Object> p = this.headTokenConverter;
/*     */     
/* 115 */     while (p != null) {
/* 116 */       if (p instanceof DateTokenConverter) {
/* 117 */         DateTokenConverter<Object> dtc = (DateTokenConverter<Object>)p;
/*     */         
/* 119 */         if (dtc.isPrimary()) {
/* 120 */           return dtc;
/*     */         }
/*     */       } 
/* 123 */       p = p.getNext();
/*     */     } 
/*     */     
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   public IntegerTokenConverter getIntegerTokenConverter() {
/* 130 */     Converter<Object> p = this.headTokenConverter;
/*     */     
/* 132 */     while (p != null) {
/* 133 */       if (p instanceof IntegerTokenConverter) {
/* 134 */         return (IntegerTokenConverter)p;
/*     */       }
/*     */       
/* 137 */       p = p.getNext();
/*     */     } 
/* 139 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasIntegerTokenCOnverter() {
/* 143 */     IntegerTokenConverter itc = getIntegerTokenConverter();
/* 144 */     return (itc != null);
/*     */   }
/*     */   
/*     */   public String convertMultipleArguments(Object... objectList) {
/* 148 */     StringBuilder buf = new StringBuilder();
/* 149 */     Converter<Object> c = this.headTokenConverter;
/* 150 */     while (c != null) {
/* 151 */       if (c instanceof MonoTypedConverter) {
/* 152 */         MonoTypedConverter monoTyped = (MonoTypedConverter)c;
/* 153 */         for (Object o : objectList) {
/* 154 */           if (monoTyped.isApplicable(o)) {
/* 155 */             buf.append(c.convert(o));
/*     */           }
/*     */         } 
/*     */       } else {
/* 159 */         buf.append(c.convert(objectList));
/*     */       } 
/* 161 */       c = c.getNext();
/*     */     } 
/* 163 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String convert(Object o) {
/* 167 */     StringBuilder buf = new StringBuilder();
/* 168 */     Converter<Object> p = this.headTokenConverter;
/* 169 */     while (p != null) {
/* 170 */       buf.append(p.convert(o));
/* 171 */       p = p.getNext();
/*     */     } 
/* 173 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String convertInt(int i) {
/* 177 */     return convert(Integer.valueOf(i));
/*     */   }
/*     */   
/*     */   public void setPattern(String pattern) {
/* 181 */     if (pattern != null)
/*     */     {
/* 183 */       this.pattern = pattern.trim();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getPattern() {
/* 188 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toRegexForFixedDate(Date date) {
/* 200 */     StringBuilder buf = new StringBuilder();
/* 201 */     Converter<Object> p = this.headTokenConverter;
/* 202 */     while (p != null) {
/* 203 */       if (p instanceof ch.qos.logback.core.pattern.LiteralConverter) {
/* 204 */         buf.append(p.convert(null));
/* 205 */       } else if (p instanceof IntegerTokenConverter) {
/* 206 */         buf.append("(\\d+)");
/* 207 */       } else if (p instanceof DateTokenConverter) {
/* 208 */         buf.append(p.convert(date));
/*     */       } 
/* 210 */       p = p.getNext();
/*     */     } 
/* 212 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toRegexForFixedDate(Instant instant) {
/* 225 */     StringBuilder buf = new StringBuilder();
/* 226 */     Converter<Object> p = this.headTokenConverter;
/* 227 */     while (p != null) {
/* 228 */       if (p instanceof ch.qos.logback.core.pattern.LiteralConverter) {
/* 229 */         buf.append(p.convert(null));
/* 230 */       } else if (p instanceof IntegerTokenConverter) {
/* 231 */         buf.append("(\\d+)");
/* 232 */       } else if (p instanceof DateTokenConverter) {
/* 233 */         buf.append(p.convert(instant));
/*     */       } 
/* 235 */       p = p.getNext();
/*     */     } 
/* 237 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toRegex() {
/* 245 */     StringBuilder buf = new StringBuilder();
/* 246 */     Converter<Object> p = this.headTokenConverter;
/* 247 */     while (p != null) {
/* 248 */       if (p instanceof ch.qos.logback.core.pattern.LiteralConverter) {
/* 249 */         buf.append(p.convert(null));
/* 250 */       } else if (p instanceof IntegerTokenConverter) {
/* 251 */         buf.append("\\d+");
/* 252 */       } else if (p instanceof DateTokenConverter) {
/* 253 */         DateTokenConverter<Object> dtc = (DateTokenConverter<Object>)p;
/* 254 */         buf.append(dtc.toRegex());
/*     */       } 
/* 256 */       p = p.getNext();
/*     */     } 
/* 258 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\FileNamePattern.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */