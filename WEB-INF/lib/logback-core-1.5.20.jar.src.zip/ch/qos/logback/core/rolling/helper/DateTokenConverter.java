/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.pattern.DynamicConverter;
/*     */ import ch.qos.logback.core.util.CachingDateFormatter;
/*     */ import ch.qos.logback.core.util.DatePatternToRegexUtil;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateTokenConverter<E>
/*     */   extends DynamicConverter<E>
/*     */   implements MonoTypedConverter
/*     */ {
/*     */   public static final String CONVERTER_KEY = "d";
/*     */   public static final String AUXILIARY_TOKEN = "AUX";
/*     */   public static final String DEFAULT_DATE_PATTERN = "yyyy-MM-dd";
/*     */   private String datePattern;
/*     */   private ZoneId zoneId;
/*     */   private CachingDateFormatter cdf;
/*     */   private boolean primary = true;
/*     */   
/*     */   public void start() {
/*  48 */     this.datePattern = getFirstOption();
/*  49 */     if (this.datePattern == null) {
/*  50 */       this.datePattern = "yyyy-MM-dd";
/*     */     }
/*     */     
/*  53 */     List<String> optionList = getOptionList();
/*  54 */     if (optionList != null) {
/*  55 */       for (int optionIndex = 1; optionIndex < optionList.size(); optionIndex++) {
/*  56 */         String option = optionList.get(optionIndex);
/*  57 */         if ("AUX".equalsIgnoreCase(option)) {
/*  58 */           this.primary = false;
/*     */         } else {
/*  60 */           this.zoneId = ZoneId.of(option);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  65 */     this.cdf = new CachingDateFormatter(this.datePattern, this.zoneId);
/*     */   }
/*     */   
/*     */   public String convert(Date date) {
/*  69 */     return this.cdf.format(date.getTime());
/*     */   }
/*     */   
/*     */   public String convert(Instant instant) {
/*  73 */     return this.cdf.format(instant.toEpochMilli());
/*     */   }
/*     */   
/*     */   public String convert(Object o) {
/*  77 */     if (o == null) {
/*  78 */       throw new IllegalArgumentException("Null argument forbidden");
/*     */     }
/*  80 */     if (o instanceof Date) {
/*  81 */       return convert((Date)o);
/*     */     }
/*  83 */     if (o instanceof Instant) {
/*  84 */       return convert((Instant)o);
/*     */     }
/*     */     
/*  87 */     throw new IllegalArgumentException("Cannot convert " + String.valueOf(o) + " of type" + o.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatePattern() {
/*  94 */     return this.datePattern;
/*     */   }
/*     */   
/*     */   public ZoneId getZoneId() {
/*  98 */     return this.zoneId;
/*     */   }
/*     */   
/*     */   public boolean isApplicable(Object o) {
/* 102 */     if (o instanceof Date)
/* 103 */       return true; 
/* 104 */     if (o instanceof Instant)
/* 105 */       return true; 
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public String toRegex() {
/* 110 */     DatePatternToRegexUtil datePatternToRegexUtil = new DatePatternToRegexUtil(this.datePattern);
/* 111 */     return datePatternToRegexUtil.toRegex();
/*     */   }
/*     */   
/*     */   public boolean isPrimary() {
/* 115 */     return this.primary;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\DateTokenConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */