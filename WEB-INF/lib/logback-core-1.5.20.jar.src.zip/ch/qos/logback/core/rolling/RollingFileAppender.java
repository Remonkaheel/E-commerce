/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.FileAppender;
/*     */ import ch.qos.logback.core.rolling.helper.CompressionMode;
/*     */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*     */ import ch.qos.logback.core.util.ContextUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollingFileAppender<E>
/*     */   extends FileAppender<E>
/*     */ {
/*     */   File currentlyActiveFile;
/*     */   TriggeringPolicy<E> triggeringPolicy;
/*     */   RollingPolicy rollingPolicy;
/*  46 */   Lock triggeringPolicyLock = new ReentrantLock();
/*     */   
/*  48 */   private static String RFA_NO_TP_URL = "https://logback.qos.ch/codes.html#rfa_no_tp";
/*  49 */   private static String RFA_NO_RP_URL = "https://logback.qos.ch/codes.html#rfa_no_rp";
/*  50 */   private static String COLLISION_URL = "https://logback.qos.ch/codes.html#rfa_collision";
/*  51 */   private static String RFA_LATE_FILE_URL = "https://logback.qos.ch/codes.html#rfa_file_after";
/*  52 */   private static String RFA_RESET_RP_OR_TP = "https://logback.qos.ch/codes.html#rfa_reset_rp_or_tp";
/*     */   
/*     */   public void start() {
/*  55 */     if (this.triggeringPolicy == null) {
/*  56 */       addWarn("No TriggeringPolicy was set for the RollingFileAppender named " + getName());
/*  57 */       addWarn("For more information, please visit " + RFA_NO_TP_URL);
/*     */       return;
/*     */     } 
/*  60 */     if (!this.triggeringPolicy.isStarted()) {
/*  61 */       addWarn("TriggeringPolicy has not started. RollingFileAppender will not start");
/*     */       
/*     */       return;
/*     */     } 
/*  65 */     if (checkForCollisionsInPreviousRollingFileAppenders()) {
/*  66 */       addError("Collisions detected with FileAppender/RollingAppender instances defined earlier. Aborting.");
/*  67 */       addError("For more information, please visit " + COLLISION_WITH_EARLIER_APPENDER_URL);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  72 */     if (!this.append) {
/*  73 */       addWarn("Append mode is mandatory for RollingFileAppender. Defaulting to append=true.");
/*  74 */       this.append = true;
/*     */     } 
/*     */     
/*  77 */     if (this.rollingPolicy == null) {
/*  78 */       addError("No RollingPolicy was set for the RollingFileAppender named " + getName());
/*  79 */       addError("For more information, please visit " + RFA_NO_RP_URL);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  84 */     if (checkForFileAndPatternCollisions()) {
/*  85 */       addError("File property collides with fileNamePattern. Aborting.");
/*  86 */       addError("For more information, please visit " + COLLISION_URL);
/*     */       
/*     */       return;
/*     */     } 
/*  90 */     if (isPrudent()) {
/*  91 */       if (rawFileProperty() != null) {
/*  92 */         addWarn("Setting \"File\" property to null on account of prudent mode");
/*  93 */         setFile((String)null);
/*     */       } 
/*  95 */       if (this.rollingPolicy.getCompressionMode() != CompressionMode.NONE) {
/*  96 */         addError("Compression is not supported in prudent mode. Aborting");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 101 */     addInfo("Active log file name: " + getFile());
/* 102 */     this.currentlyActiveFile = new File(getFile());
/* 103 */     initializeLengthCounter();
/* 104 */     super.start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkForFileAndPatternCollisions() {
/* 110 */     if (this.triggeringPolicy instanceof RollingPolicyBase) {
/* 111 */       RollingPolicyBase base = (RollingPolicyBase)this.triggeringPolicy;
/* 112 */       FileNamePattern fileNamePattern = base.fileNamePattern;
/*     */       
/* 114 */       if (fileNamePattern != null && this.fileName != null) {
/* 115 */         String regex = fileNamePattern.toRegex();
/* 116 */         return this.fileName.matches(regex);
/*     */       } 
/*     */     } 
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkForCollisionsInPreviousRollingFileAppenders() {
/* 123 */     boolean collisionResult = false;
/* 124 */     if (this.triggeringPolicy instanceof RollingPolicyBase) {
/* 125 */       RollingPolicyBase base = (RollingPolicyBase)this.triggeringPolicy;
/* 126 */       FileNamePattern fileNamePattern = base.fileNamePattern;
/* 127 */       boolean collisionsDetected = innerCheckForFileNamePatternCollisionInPreviousRFA(fileNamePattern);
/* 128 */       if (collisionsDetected)
/* 129 */         collisionResult = true; 
/*     */     } 
/* 131 */     return collisionResult;
/*     */   }
/*     */   
/*     */   private boolean innerCheckForFileNamePatternCollisionInPreviousRFA(FileNamePattern fileNamePattern) {
/* 135 */     boolean collisionsDetected = false;
/* 136 */     Map<String, FileNamePattern> map = (Map<String, FileNamePattern>)this.context.getObject("RFA_FILENAME_PATTERN_COLLISION_MAP");
/*     */     
/* 138 */     if (map == null) {
/* 139 */       return collisionsDetected;
/*     */     }
/* 141 */     for (Map.Entry<String, FileNamePattern> entry : map.entrySet()) {
/* 142 */       if (fileNamePattern.equals(entry.getValue())) {
/* 143 */         addErrorForCollision("FileNamePattern", ((FileNamePattern)entry.getValue()).toString(), entry.getKey());
/* 144 */         collisionsDetected = true;
/*     */       } 
/*     */     } 
/* 147 */     if (this.name != null) {
/* 148 */       map.put(this.name, fileNamePattern);
/*     */     }
/* 150 */     return collisionsDetected;
/*     */   }
/*     */   
/*     */   private void initializeLengthCounter() {
/* 154 */     if (getLengthCounter() != null && this.currentlyActiveFile.exists()) {
/* 155 */       long currentFileLength = this.currentlyActiveFile.length();
/* 156 */       addInfo("Setting currentFileLength to " + currentFileLength + " for " + String.valueOf(this.currentlyActiveFile));
/* 157 */       incrementByteCount(currentFileLength);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 163 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/* 166 */     super.stop();
/*     */     
/* 168 */     if (this.rollingPolicy != null)
/* 169 */       this.rollingPolicy.stop(); 
/* 170 */     if (this.triggeringPolicy != null) {
/* 171 */       this.triggeringPolicy.stop();
/*     */     }
/* 173 */     Map<String, FileNamePattern> map = ContextUtil.getFilenamePatternCollisionMap(this.context);
/* 174 */     if (map != null && getName() != null) {
/* 175 */       map.remove(getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFile(String file) {
/* 183 */     if (file != null && (this.triggeringPolicy != null || this.rollingPolicy != null)) {
/* 184 */       addError("File property must be set before any triggeringPolicy or rollingPolicy properties");
/* 185 */       addError("For more information, please visit " + RFA_LATE_FILE_URL);
/*     */     } 
/* 187 */     super.setFile(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFile() {
/* 192 */     return this.rollingPolicy.getActiveFileName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollover() {
/* 199 */     this.streamWriteLock.lock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 206 */       closeOutputStream();
/* 207 */       attemptRollover();
/* 208 */       attemptOpenFile();
/*     */     } finally {
/* 210 */       this.streamWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void attemptOpenFile() {
/*     */     try {
/* 217 */       this.currentlyActiveFile = new File(this.rollingPolicy.getActiveFileName());
/*     */ 
/*     */ 
/*     */       
/* 221 */       openFile(this.rollingPolicy.getActiveFileName());
/* 222 */     } catch (IOException e) {
/* 223 */       addError("setFile(" + this.fileName + ", false) call failed.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void attemptRollover() {
/*     */     try {
/* 229 */       this.rollingPolicy.rollover();
/* 230 */     } catch (RolloverFailure rf) {
/* 231 */       addWarn("RolloverFailure occurred. Deferring roll-over.");
/*     */       
/* 233 */       this.append = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void subAppend(E event) {
/* 250 */     this.triggeringPolicyLock.lock();
/*     */     try {
/* 252 */       if (this.triggeringPolicy.isTriggeringEvent(this.currentlyActiveFile, event)) {
/* 253 */         rollover();
/*     */       }
/*     */     } finally {
/* 256 */       this.triggeringPolicyLock.unlock();
/*     */     } 
/*     */     
/* 259 */     super.subAppend(event);
/*     */   }
/*     */   
/*     */   public RollingPolicy getRollingPolicy() {
/* 263 */     return this.rollingPolicy;
/*     */   }
/*     */   
/*     */   public TriggeringPolicy<E> getTriggeringPolicy() {
/* 267 */     return this.triggeringPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRollingPolicy(RollingPolicy policy) {
/* 279 */     if (this.rollingPolicy instanceof TriggeringPolicy) {
/* 280 */       String className = this.rollingPolicy.getClass().getSimpleName();
/* 281 */       addWarn("A rolling policy of type " + className + " was already set.");
/* 282 */       addWarn("Note that " + className + " doubles as a TriggeringPolicy");
/* 283 */       addWarn("See also " + RFA_RESET_RP_OR_TP);
/*     */     } 
/* 285 */     this.rollingPolicy = policy;
/* 286 */     if (this.rollingPolicy instanceof TriggeringPolicy) {
/* 287 */       this.triggeringPolicy = (TriggeringPolicy<E>)policy;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTriggeringPolicy(TriggeringPolicy<E> policy) {
/* 293 */     if (this.triggeringPolicy instanceof RollingPolicy) {
/* 294 */       String className = this.triggeringPolicy.getClass().getSimpleName();
/* 295 */       addWarn("A triggering policy of type " + className + " was already set.");
/* 296 */       addWarn("Note that " + className + " doubles as a RollingPolicy");
/* 297 */       addWarn("See also " + RFA_RESET_RP_OR_TP);
/*     */     } 
/* 299 */     this.triggeringPolicy = policy;
/* 300 */     if (policy instanceof RollingPolicy) {
/* 301 */       this.rollingPolicy = (RollingPolicy)policy;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateByteCount(byte[] byteArray) {
/* 307 */     if (byteArray == null)
/*     */       return; 
/* 309 */     incrementByteCount(byteArray.length);
/*     */   }
/*     */   
/*     */   void incrementByteCount(long increment) {
/* 313 */     LengthCounter lengthCounter = getLengthCounter();
/* 314 */     if (lengthCounter == null) {
/*     */       return;
/*     */     }
/* 317 */     if (increment > 0L) {
/* 318 */       lengthCounter.add(increment);
/*     */     }
/*     */   }
/*     */   
/*     */   private LengthCounter getLengthCounter() {
/* 323 */     return this.triggeringPolicy.getLengthCounter();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\RollingFileAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */