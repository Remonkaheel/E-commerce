/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.WarnStatus;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipCompressionStrategy
/*     */   extends CompressionStrategyBase
/*     */ {
/*     */   static final int BUFFER_SIZE = 8192;
/*     */   
/*     */   public void compress(String originalFileName, String compressedFileName, String innerEntryName) {
/*  39 */     File file2zip = new File(originalFileName);
/*     */     
/*  41 */     if (!file2zip.exists()) {
/*  42 */       addStatus((Status)new WarnStatus("The file to compress named [" + originalFileName + "] does not exist.", this));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  47 */     if (innerEntryName == null) {
/*  48 */       addStatus((Status)new WarnStatus("The innerEntryName parameter cannot be null", this));
/*     */       
/*     */       return;
/*     */     } 
/*  52 */     if (!compressedFileName.endsWith(".zip")) {
/*  53 */       compressedFileName = compressedFileName + ".zip";
/*     */     }
/*     */     
/*  56 */     File zippedFile = new File(compressedFileName);
/*     */     
/*  58 */     if (zippedFile.exists()) {
/*  59 */       addStatus((Status)new WarnStatus("The target compressed file named [" + compressedFileName + "] exist already.", this));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  64 */     addInfo("ZIP compressing [" + String.valueOf(file2zip) + "] as [" + String.valueOf(zippedFile) + "]");
/*  65 */     createMissingTargetDirsIfNecessary(zippedFile);
/*     */     
/*  67 */     try { BufferedInputStream bis = new BufferedInputStream(new FileInputStream(originalFileName)); 
/*  68 */       try { ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(compressedFileName));
/*     */         
/*  70 */         try { ZipEntry zipEntry = computeZipEntry(innerEntryName);
/*  71 */           zos.putNextEntry(zipEntry);
/*     */           
/*  73 */           byte[] inbuf = new byte[8192];
/*     */           
/*     */           int n;
/*  76 */           while ((n = bis.read(inbuf)) != -1) {
/*  77 */             zos.write(inbuf, 0, n);
/*     */           }
/*     */           
/*  80 */           addInfo("Done ZIP compressing [" + String.valueOf(file2zip) + "] as [" + String.valueOf(zippedFile) + "]");
/*  81 */           zos.close(); } catch (Throwable throwable) { try { zos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  bis.close(); } catch (Throwable throwable) { try { bis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/*  82 */     { addStatus((Status)new ErrorStatus("Error occurred while compressing [" + originalFileName + "] into [" + compressedFileName + "].", this, e)); }
/*     */     
/*  84 */     if (!file2zip.delete()) {
/*  85 */       addStatus((Status)new WarnStatus("Could not delete [" + originalFileName + "].", this));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ZipEntry computeZipEntry(String filename) {
/* 109 */     String nameOfFileNestedWithinArchive = Compressor.computeFileNameStrWithoutCompSuffix(filename, CompressionMode.ZIP);
/* 110 */     return new ZipEntry(nameOfFileNestedWithinArchive);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\ZipCompressionStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */