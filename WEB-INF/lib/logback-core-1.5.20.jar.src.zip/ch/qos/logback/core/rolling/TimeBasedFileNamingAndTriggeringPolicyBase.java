/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.rolling.helper.ArchiveRemover;
/*     */ import ch.qos.logback.core.rolling.helper.DateTokenConverter;
/*     */ import ch.qos.logback.core.rolling.helper.RollingCalendar;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import java.io.File;
/*     */ import java.time.Instant;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TimeBasedFileNamingAndTriggeringPolicyBase<E>
/*     */   extends ContextAwareBase
/*     */   implements TimeBasedFileNamingAndTriggeringPolicy<E>
/*     */ {
/*  43 */   private static String COLLIDING_DATE_FORMAT_URL = "https://logback.qos.ch/codes.html#rfa_collision_in_dateFormat";
/*     */   
/*     */   protected TimeBasedRollingPolicy<E> tbrp;
/*     */   
/*  47 */   protected ArchiveRemover archiveRemover = null;
/*     */   
/*     */   protected String elapsedPeriodsFileName;
/*     */   protected RollingCalendar rc;
/*  51 */   protected long artificialCurrentTime = -1L;
/*     */   
/*  53 */   protected AtomicLong atomicNextCheck = new AtomicLong(0L);
/*  54 */   protected Instant dateInCurrentPeriod = null;
/*     */   
/*     */   protected boolean started = false;
/*     */   protected boolean errorFree = true;
/*     */   
/*     */   public boolean isStarted() {
/*  60 */     return this.started;
/*     */   }
/*     */   
/*     */   public void start() {
/*  64 */     DateTokenConverter<Object> dtc = this.tbrp.fileNamePattern.getPrimaryDateTokenConverter();
/*  65 */     if (dtc == null) {
/*  66 */       throw new IllegalStateException("FileNamePattern [" + this.tbrp.fileNamePattern
/*  67 */           .getPattern() + "] does not contain a valid DateToken");
/*     */     }
/*     */     
/*  70 */     if (dtc.getZoneId() != null) {
/*  71 */       TimeZone tz = TimeZone.getTimeZone(dtc.getZoneId());
/*  72 */       this.rc = new RollingCalendar(dtc.getDatePattern(), tz, Locale.getDefault());
/*     */     } else {
/*  74 */       this.rc = new RollingCalendar(dtc.getDatePattern());
/*     */     } 
/*  76 */     addInfo("The date pattern is '" + dtc.getDatePattern() + "' from file name pattern '" + this.tbrp.fileNamePattern
/*  77 */         .getPattern() + "'.");
/*  78 */     this.rc.printPeriodicity(this);
/*     */     
/*  80 */     if (!this.rc.isCollisionFree()) {
/*  81 */       addError("The date format in FileNamePattern will result in collisions in the names of archived log files.");
/*     */       
/*  83 */       addError("For more information, please visit " + COLLIDING_DATE_FORMAT_URL);
/*  84 */       withErrors();
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     long timestamp = getCurrentTime();
/*  89 */     setDateInCurrentPeriod(timestamp);
/*     */     
/*  91 */     if (this.tbrp.getParentsRawFileProperty() != null) {
/*  92 */       File currentFile = new File(this.tbrp.getParentsRawFileProperty());
/*  93 */       if (currentFile.exists() && currentFile.canRead()) {
/*  94 */         timestamp = currentFile.lastModified();
/*  95 */         setDateInCurrentPeriod(timestamp);
/*     */       } 
/*     */     } 
/*  98 */     addInfo("Setting initial period to " + String.valueOf(this.dateInCurrentPeriod));
/*  99 */     long nextCheck = computeNextCheck(timestamp);
/* 100 */     this.atomicNextCheck.set(nextCheck);
/*     */   }
/*     */   
/*     */   public void stop() {
/* 104 */     this.started = false;
/*     */   }
/*     */   
/*     */   protected long computeNextCheck(long timestamp) {
/* 108 */     return this.rc.getNextTriggeringDate(Instant.ofEpochMilli(timestamp)).toEpochMilli();
/*     */   }
/*     */   
/*     */   public String getElapsedPeriodsFileName() {
/* 112 */     return this.elapsedPeriodsFileName;
/*     */   }
/*     */   
/*     */   public String getCurrentPeriodsFileNameWithoutCompressionSuffix() {
/* 116 */     return this.tbrp.fileNamePatternWithoutCompSuffix.convert(this.dateInCurrentPeriod);
/*     */   }
/*     */   
/*     */   protected void setDateInCurrentPeriod(long timestamp) {
/* 120 */     this.dateInCurrentPeriod = Instant.ofEpochMilli(timestamp);
/*     */   }
/*     */   
/*     */   public void setCurrentTime(long timeInMillis) {
/* 124 */     this.artificialCurrentTime = timeInMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getCurrentTime() {
/* 129 */     if (this.artificialCurrentTime >= 0L) {
/* 130 */       return this.artificialCurrentTime;
/*     */     }
/* 132 */     return System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeBasedRollingPolicy(TimeBasedRollingPolicy<E> _tbrp) {
/* 137 */     this.tbrp = _tbrp;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArchiveRemover getArchiveRemover() {
/* 142 */     return this.archiveRemover;
/*     */   }
/*     */   
/*     */   protected void withErrors() {
/* 146 */     this.errorFree = false;
/*     */   }
/*     */   
/*     */   protected boolean isErrorFree() {
/* 150 */     return this.errorFree;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\TimeBasedFileNamingAndTriggeringPolicyBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */