/*    */ package ch.qos.logback.core.rolling.helper;
/*    */ 
/*    */ import ch.qos.logback.core.rolling.RolloverFailure;
/*    */ import java.io.File;
/*    */ import java.nio.file.FileStore;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileStoreUtil
/*    */ {
/*    */   static final String PATH_CLASS_STR = "java.nio.file.Path";
/*    */   static final String FILES_CLASS_STR = "java.nio.file.Files";
/*    */   
/*    */   public static boolean areOnSameFileStore(File a, File b) throws RolloverFailure {
/* 43 */     if (!a.exists()) {
/* 44 */       throw new IllegalArgumentException("File [" + String.valueOf(a) + "] does not exist.");
/*    */     }
/* 46 */     if (!b.exists()) {
/* 47 */       throw new IllegalArgumentException("File [" + String.valueOf(b) + "] does not exist.");
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 53 */       Path pathA = a.toPath();
/* 54 */       Path pathB = b.toPath();
/*    */       
/* 56 */       FileStore fileStoreA = Files.getFileStore(pathA);
/* 57 */       FileStore fileStoreB = Files.getFileStore(pathB);
/*    */       
/* 59 */       return fileStoreA.equals(fileStoreB);
/* 60 */     } catch (Exception e) {
/* 61 */       throw new RolloverFailure("Failed to check file store equality for [" + String.valueOf(a) + "] and [" + String.valueOf(b) + "]", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\helper\FileStoreUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */