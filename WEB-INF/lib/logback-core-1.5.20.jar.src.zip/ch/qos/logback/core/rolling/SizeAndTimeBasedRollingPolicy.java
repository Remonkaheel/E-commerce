/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ import ch.qos.logback.core.util.FileSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeAndTimeBasedRollingPolicy<E>
/*    */   extends TimeBasedRollingPolicy<E>
/*    */ {
/*    */   FileSize maxFileSize;
/*    */   
/*    */   public void start() {
/* 25 */     SizeAndTimeBasedFileNamingAndTriggeringPolicy<E> sizeAndTimeBasedFNATP = new SizeAndTimeBasedFileNamingAndTriggeringPolicy<>(SizeAndTimeBasedFileNamingAndTriggeringPolicy.Usage.EMBEDDED);
/* 26 */     if (this.maxFileSize == null) {
/* 27 */       addError("maxFileSize property is mandatory.");
/*    */       return;
/*    */     } 
/* 30 */     addInfo("Archive files will be limited to [" + String.valueOf(this.maxFileSize) + "] each.");
/*    */ 
/*    */     
/* 33 */     sizeAndTimeBasedFNATP.setMaxFileSize(this.maxFileSize);
/* 34 */     this.timeBasedFileNamingAndTriggeringPolicy = sizeAndTimeBasedFNATP;
/*    */     
/* 36 */     if (!isUnboundedTotalSizeCap() && this.totalSizeCap.getSize() < this.maxFileSize.getSize()) {
/* 37 */       addError("totalSizeCap of [" + String.valueOf(this.totalSizeCap) + "] is smaller than maxFileSize [" + String.valueOf(this.maxFileSize) + "] which is non-sensical");
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 43 */     super.start();
/*    */   }
/*    */   
/*    */   public void setMaxFileSize(FileSize aMaxFileSize) {
/* 47 */     this.maxFileSize = aMaxFileSize;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return "c.q.l.core.rolling.SizeAndTimeBasedRollingPolicy@" + hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\SizeAndTimeBasedRollingPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */