/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ import java.util.concurrent.atomic.LongAdder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthCounterBase
/*    */   implements LengthCounter
/*    */ {
/* 21 */   LongAdder counter = new LongAdder();
/*    */ 
/*    */   
/*    */   public void add(long len) {
/* 25 */     this.counter.add(len);
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLength() {
/* 30 */     return this.counter.longValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset() {
/* 35 */     this.counter.reset();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\LengthCounterBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */