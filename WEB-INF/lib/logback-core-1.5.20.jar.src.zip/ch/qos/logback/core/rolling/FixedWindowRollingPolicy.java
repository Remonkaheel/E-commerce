/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.rolling.helper.CompressionMode;
/*     */ import ch.qos.logback.core.rolling.helper.Compressor;
/*     */ import ch.qos.logback.core.rolling.helper.FileFilterUtil;
/*     */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*     */ import ch.qos.logback.core.rolling.helper.IntegerTokenConverter;
/*     */ import ch.qos.logback.core.rolling.helper.RenameUtil;
/*     */ import java.io.File;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedWindowRollingPolicy
/*     */   extends RollingPolicyBase
/*     */ {
/*     */   static final String FNP_NOT_SET = "The \"FileNamePattern\" property must be set before using FixedWindowRollingPolicy. ";
/*     */   static final String PRUDENT_MODE_UNSUPPORTED = "See also https://logback.qos.ch/codes.html#tbr_fnp_prudent_unsupported";
/*     */   static final String SEE_PARENT_FN_NOT_SET = "Please refer to https://logback.qos.ch/codes.html#fwrp_parentFileName_not_set";
/*     */   int maxIndex;
/*     */   int minIndex;
/*  39 */   RenameUtil util = new RenameUtil();
/*     */ 
/*     */   
/*     */   Compressor compressor;
/*     */ 
/*     */   
/*     */   public static final String ZIP_ENTRY_DATE_PATTERN = "yyyy-MM-dd_HHmm";
/*     */   
/*  47 */   private static int MAX_WINDOW_SIZE = 20;
/*     */   
/*     */   public FixedWindowRollingPolicy() {
/*  50 */     this.minIndex = 1;
/*  51 */     this.maxIndex = 7;
/*     */   }
/*     */   
/*     */   public void start() {
/*  55 */     this.util.setContext(this.context);
/*     */     
/*  57 */     if (this.fileNamePatternStr != null) {
/*  58 */       determineCompressionMode();
/*  59 */       adjustCompressionModeAndFileNamePatternStrIfNecessary();
/*  60 */       this.fileNamePattern = new FileNamePattern(this.fileNamePatternStr, this.context);
/*     */     } else {
/*  62 */       addError("The \"FileNamePattern\" property must be set before using FixedWindowRollingPolicy. ");
/*  63 */       addError("See also https://logback.qos.ch/codes.html#tbr_fnp_not_set");
/*  64 */       throw new IllegalStateException("The \"FileNamePattern\" property must be set before using FixedWindowRollingPolicy. See also https://logback.qos.ch/codes.html#tbr_fnp_not_set");
/*     */     } 
/*     */     
/*  67 */     if (isParentPrudent()) {
/*  68 */       addError("Prudent mode is not supported with FixedWindowRollingPolicy.");
/*  69 */       addError("See also https://logback.qos.ch/codes.html#tbr_fnp_prudent_unsupported");
/*  70 */       throw new IllegalStateException("Prudent mode is not supported.");
/*     */     } 
/*     */     
/*  73 */     if (getParentsRawFileProperty() == null) {
/*  74 */       addError("The File name property must be set before using this rolling policy.");
/*  75 */       addError("Please refer to https://logback.qos.ch/codes.html#fwrp_parentFileName_not_set");
/*  76 */       throw new IllegalStateException("The \"File\" option must be set.");
/*     */     } 
/*     */     
/*  79 */     if (this.maxIndex < this.minIndex) {
/*  80 */       addWarn("MaxIndex (" + this.maxIndex + ") cannot be smaller than MinIndex (" + this.minIndex + ").");
/*  81 */       addWarn("Setting maxIndex to equal minIndex.");
/*  82 */       this.maxIndex = this.minIndex;
/*     */     } 
/*     */     
/*  85 */     int maxWindowSize = getMaxWindowSize();
/*  86 */     if (this.maxIndex - this.minIndex > maxWindowSize) {
/*  87 */       addWarn("Large window sizes are not allowed.");
/*  88 */       this.maxIndex = this.minIndex + maxWindowSize;
/*  89 */       addWarn("MaxIndex reduced to " + this.maxIndex);
/*     */     } 
/*     */     
/*  92 */     IntegerTokenConverter itc = this.fileNamePattern.getIntegerTokenConverter();
/*     */     
/*  94 */     if (itc == null) {
/*  95 */       throw new IllegalStateException("FileNamePattern [" + this.fileNamePattern
/*  96 */           .getPattern() + "] does not contain a valid IntegerToken");
/*     */     }
/*     */     
/*  99 */     if (this.compressionMode == CompressionMode.ZIP) {
/* 100 */       String zipEntryFileNamePatternStr = transformFileNamePatternFromInt2Date(this.fileNamePatternStr);
/* 101 */       this.zipEntryFileNamePattern = new FileNamePattern(zipEntryFileNamePatternStr, this.context);
/*     */     } 
/* 103 */     this.compressor = new Compressor(this.compressionMode);
/* 104 */     this.compressor.setContext(this.context);
/* 105 */     super.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxWindowSize() {
/* 115 */     return MAX_WINDOW_SIZE;
/*     */   }
/*     */   
/*     */   private String transformFileNamePatternFromInt2Date(String fileNamePatternStr) {
/* 119 */     String slashified = FileFilterUtil.slashify(fileNamePatternStr);
/* 120 */     String stemOfFileNamePattern = FileFilterUtil.afterLastSlash(slashified);
/* 121 */     return stemOfFileNamePattern.replace("%i", "%d{yyyy-MM-dd_HHmm}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollover() throws RolloverFailure {
/* 129 */     if (this.maxIndex >= 0) {
/*     */       
/* 131 */       File file = new File(this.fileNamePattern.convertInt(this.maxIndex));
/*     */       
/* 133 */       if (file.exists()) {
/* 134 */         file.delete();
/*     */       }
/*     */ 
/*     */       
/* 138 */       for (int i = this.maxIndex - 1; i >= this.minIndex; i--) {
/* 139 */         String toRenameStr = this.fileNamePattern.convertInt(i);
/* 140 */         File toRename = new File(toRenameStr);
/*     */         
/* 142 */         if (toRename.exists()) {
/* 143 */           this.util.rename(toRenameStr, this.fileNamePattern.convertInt(i + 1));
/*     */         } else {
/* 145 */           addInfo("Skipping roll-over for inexistent file " + toRenameStr);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 150 */       switch (this.compressionMode) {
/*     */         case NONE:
/* 152 */           this.util.rename(getActiveFileName(), this.fileNamePattern.convertInt(this.minIndex));
/*     */           break;
/*     */         case GZ:
/*     */         case XZ:
/* 156 */           this.compressor.compress(getActiveFileName(), this.fileNamePattern.convertInt(this.minIndex), null);
/*     */           break;
/*     */         case ZIP:
/* 159 */           this.compressor.compress(getActiveFileName(), this.fileNamePattern.convertInt(this.minIndex), this.zipEntryFileNamePattern
/* 160 */               .convert(new Date()));
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActiveFileName() {
/* 170 */     return getParentsRawFileProperty();
/*     */   }
/*     */   
/*     */   public int getMaxIndex() {
/* 174 */     return this.maxIndex;
/*     */   }
/*     */   
/*     */   public int getMinIndex() {
/* 178 */     return this.minIndex;
/*     */   }
/*     */   
/*     */   public void setMaxIndex(int maxIndex) {
/* 182 */     this.maxIndex = maxIndex;
/*     */   }
/*     */   
/*     */   public void setMinIndex(int minIndex) {
/* 186 */     this.minIndex = minIndex;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\rolling\FixedWindowRollingPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */