package ch.qos.logback.core.recovery;

import java.io.IOException;

public interface RecoveryListener {
  void newFailure(IOException paramIOException);
  
  void recoveryOccured();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\recovery\RecoveryListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */