/*     */ package ch.qos.logback.core.recovery;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import ch.qos.logback.core.status.InfoStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResilientOutputStreamBase
/*     */   extends OutputStream
/*     */ {
/*     */   static final int STATUS_COUNT_LIMIT = 8;
/*  31 */   private int noContextWarning = 0;
/*  32 */   private int statusCount = 0;
/*     */   
/*     */   private Context context;
/*     */   
/*     */   private RecoveryCoordinator recoveryCoordinator;
/*     */   
/*     */   protected OutputStream os;
/*     */   protected boolean presumedClean = true;
/*  40 */   List<RecoveryListener> recoveryListeners = new ArrayList<>(0);
/*     */ 
/*     */   
/*     */   private boolean isPresumedInError() {
/*  44 */     return (this.recoveryCoordinator != null && !this.presumedClean);
/*     */   }
/*     */   
/*     */   public void addRecoveryListener(RecoveryListener listener) {
/*  48 */     this.recoveryListeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeRecoveryListener(RecoveryListener listener) {
/*  52 */     this.recoveryListeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int off, int len) {
/*  56 */     if (isPresumedInError()) {
/*  57 */       if (!this.recoveryCoordinator.isTooSoon()) {
/*  58 */         attemptRecovery();
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/*  64 */       this.os.write(b, off, len);
/*  65 */       postSuccessfulWrite();
/*  66 */     } catch (IOException e) {
/*  67 */       postIOFailure(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) {
/*  73 */     if (isPresumedInError()) {
/*  74 */       if (!this.recoveryCoordinator.isTooSoon()) {
/*  75 */         attemptRecovery();
/*     */       }
/*     */       return;
/*     */     } 
/*     */     try {
/*  80 */       this.os.write(b);
/*  81 */       postSuccessfulWrite();
/*  82 */     } catch (IOException e) {
/*  83 */       postIOFailure(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/*  89 */     if (this.os != null) {
/*     */       try {
/*  91 */         this.os.flush();
/*  92 */         postSuccessfulWrite();
/*  93 */       } catch (IOException e) {
/*  94 */         postIOFailure(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void postSuccessfulWrite() {
/* 104 */     if (this.recoveryCoordinator != null) {
/* 105 */       this.recoveryCoordinator = null;
/* 106 */       this.statusCount = 0;
/* 107 */       this.recoveryListeners.forEach(listener -> listener.recoveryOccured());
/* 108 */       addStatus((Status)new InfoStatus("Recovered from IO failure on " + getDescription(), this));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void postIOFailure(IOException e) {
/* 113 */     addStatusIfCountNotOverLimit((Status)new ErrorStatus("IO failure while writing to " + getDescription(), this, e));
/* 114 */     this.presumedClean = false;
/* 115 */     if (this.recoveryCoordinator == null) {
/* 116 */       this.recoveryCoordinator = new RecoveryCoordinator();
/* 117 */       this.recoveryListeners.forEach(listener -> listener.newFailure(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 123 */     if (this.os != null) {
/* 124 */       this.os.close();
/*     */     }
/*     */   }
/*     */   
/*     */   void attemptRecovery() {
/*     */     try {
/* 130 */       close();
/* 131 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 134 */     addStatusIfCountNotOverLimit((Status)new InfoStatus("Attempting to recover from IO failure on " + 
/* 135 */           getDescription(), this));
/*     */ 
/*     */     
/*     */     try {
/* 139 */       this.os = openNewOutputStream();
/* 140 */       this.presumedClean = true;
/* 141 */     } catch (IOException e) {
/* 142 */       addStatusIfCountNotOverLimit((Status)new ErrorStatus("Failed to open " + getDescription(), this, e));
/*     */     } 
/*     */   }
/*     */   
/*     */   void addStatusIfCountNotOverLimit(Status s) {
/* 147 */     this.statusCount++;
/* 148 */     if (this.statusCount < 8) {
/* 149 */       addStatus(s);
/*     */     }
/*     */     
/* 152 */     if (this.statusCount == 8) {
/* 153 */       addStatus(s);
/* 154 */       addStatus((Status)new InfoStatus("Will supress future messages regarding " + getDescription(), this));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addStatus(Status status) {
/* 159 */     if (this.context == null) {
/* 160 */       if (this.noContextWarning++ == 0) {
/* 161 */         System.out.println("LOGBACK: No context given for " + String.valueOf(this));
/*     */       }
/*     */       return;
/*     */     } 
/* 165 */     StatusManager sm = this.context.getStatusManager();
/* 166 */     if (sm != null) {
/* 167 */       sm.add(status);
/*     */     }
/*     */   }
/*     */   
/*     */   public Context getContext() {
/* 172 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(Context context) {
/* 176 */     this.context = context;
/*     */   }
/*     */   
/*     */   abstract String getDescription();
/*     */   
/*     */   abstract OutputStream openNewOutputStream() throws IOException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\recovery\ResilientOutputStreamBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */