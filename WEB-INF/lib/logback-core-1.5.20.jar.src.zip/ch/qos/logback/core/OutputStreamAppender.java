/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.encoder.Encoder;
/*     */ import ch.qos.logback.core.encoder.LayoutWrappingEncoder;
/*     */ import ch.qos.logback.core.spi.DeferredProcessingAware;
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputStreamAppender<E>
/*     */   extends UnsynchronizedAppenderBase<E>
/*     */ {
/*     */   protected Encoder<E> encoder;
/*  48 */   protected final ReentrantLock streamWriteLock = new ReentrantLock(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OutputStream outputStream;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean immediateFlush = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() {
/*  63 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  71 */     int errors = 0;
/*  72 */     if (this.encoder == null) {
/*  73 */       addStatus((Status)new ErrorStatus("No encoder set for the appender named \"" + this.name + "\".", this));
/*  74 */       errors++;
/*     */     } 
/*     */     
/*  77 */     if (this.outputStream == null) {
/*  78 */       addStatus((Status)new ErrorStatus("No output stream set for the appender named \"" + this.name + "\".", this));
/*  79 */       errors++;
/*     */     } 
/*     */     
/*  82 */     if (this.encoder == null) {
/*  83 */       addWarn("Encoder has not been set. Cannot invoke its init method.");
/*  84 */       errors++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  89 */     if (errors == 0) {
/*  90 */       super.start();
/*  91 */       encoderInit();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLayout(Layout<E> layout) {
/*  96 */     addWarn("This appender no longer admits a layout as a sub-component, set an encoder instead.");
/*  97 */     addWarn("To ensure compatibility, wrapping your layout in LayoutWrappingEncoder.");
/*  98 */     addWarn("See also https://logback.qos.ch/codes.html#layoutInsteadOfEncoder for details");
/*  99 */     LayoutWrappingEncoder<E> lwe = new LayoutWrappingEncoder();
/* 100 */     lwe.setLayout(layout);
/* 101 */     lwe.setContext(this.context);
/* 102 */     this.encoder = (Encoder<E>)lwe;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void append(E eventObject) {
/* 107 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/*     */     
/* 111 */     subAppend(eventObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 121 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/* 124 */     this.streamWriteLock.lock();
/*     */     try {
/* 126 */       closeOutputStream();
/* 127 */       super.stop();
/*     */     } finally {
/* 129 */       this.streamWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeOutputStream() {
/* 137 */     if (this.outputStream != null) {
/*     */       
/*     */       try {
/* 140 */         encoderClose();
/* 141 */         this.outputStream.close();
/* 142 */         this.outputStream = null;
/* 143 */       } catch (IOException e) {
/* 144 */         addStatus((Status)new ErrorStatus("Could not close output stream for OutputStreamAppender.", this, e));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void encoderClose() {
/* 150 */     if (this.encoder != null && this.outputStream != null) {
/*     */       try {
/* 152 */         byte[] footer = this.encoder.footerBytes();
/* 153 */         writeBytes(footer);
/* 154 */       } catch (IOException ioe) {
/* 155 */         this.started = false;
/* 156 */         addStatus((Status)new ErrorStatus("Failed to write footer for appender named [" + this.name + "].", this, ioe));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputStream(OutputStream outputStream) {
/* 171 */     this.streamWriteLock.lock();
/*     */     
/*     */     try {
/* 174 */       closeOutputStream();
/* 175 */       this.outputStream = outputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       if (isStarted()) {
/* 182 */         encoderInit();
/*     */       }
/*     */     } finally {
/* 185 */       this.streamWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void encoderInit() {
/* 190 */     if (this.encoder != null && this.outputStream != null) {
/*     */       try {
/* 192 */         byte[] header = this.encoder.headerBytes();
/* 193 */         writeBytes(header);
/* 194 */       } catch (IOException ioe) {
/* 195 */         this.started = false;
/* 196 */         addStatus((Status)new ErrorStatus("Failed to initialize encoder for appender named [" + this.name + "].", this, ioe));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeOut(E event) throws IOException {
/* 203 */     byte[] byteArray = this.encoder.encode(event);
/* 204 */     writeBytes(byteArray);
/*     */   }
/*     */   
/*     */   private void writeBytes(byte[] byteArray) throws IOException {
/* 208 */     if (byteArray == null || byteArray.length == 0) {
/*     */       return;
/*     */     }
/* 211 */     this.streamWriteLock.lock();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 216 */       if (isStarted()) {
/* 217 */         writeByteArrayToOutputStreamWithPossibleFlush(byteArray);
/* 218 */         updateByteCount(byteArray);
/*     */       } 
/*     */     } finally {
/* 221 */       this.streamWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateByteCount(byte[] byteArray) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void writeByteArrayToOutputStreamWithPossibleFlush(byte[] byteArray) throws IOException {
/* 234 */     this.outputStream.write(byteArray);
/* 235 */     if (this.immediateFlush) {
/* 236 */       this.outputStream.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void subAppend(E event) {
/* 249 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 254 */       if (event instanceof DeferredProcessingAware) {
/* 255 */         ((DeferredProcessingAware)event).prepareForDeferredProcessing();
/*     */       }
/* 257 */       writeOut(event);
/*     */     }
/* 259 */     catch (IOException ioe) {
/*     */ 
/*     */       
/* 262 */       this.started = false;
/* 263 */       addStatus((Status)new ErrorStatus("IO failure in appender", this, ioe));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Encoder<E> getEncoder() {
/* 268 */     return this.encoder;
/*     */   }
/*     */   
/*     */   public void setEncoder(Encoder<E> encoder) {
/* 272 */     this.encoder = encoder;
/*     */   }
/*     */   
/*     */   public boolean isImmediateFlush() {
/* 276 */     return this.immediateFlush;
/*     */   }
/*     */   
/*     */   public void setImmediateFlush(boolean immediateFlush) {
/* 280 */     this.immediateFlush = immediateFlush;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\OutputStreamAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */