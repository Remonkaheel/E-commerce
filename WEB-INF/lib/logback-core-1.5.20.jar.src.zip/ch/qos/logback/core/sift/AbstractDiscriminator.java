/*    */ package ch.qos.logback.core.sift;
/*    */ 
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDiscriminator<E>
/*    */   extends ContextAwareBase
/*    */   implements Discriminator<E>
/*    */ {
/*    */   protected boolean started;
/*    */   
/*    */   public void start() {
/* 30 */     this.started = true;
/*    */   }
/*    */   
/*    */   public void stop() {
/* 34 */     this.started = false;
/*    */   }
/*    */   
/*    */   public boolean isStarted() {
/* 38 */     return this.started;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\sift\AbstractDiscriminator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */