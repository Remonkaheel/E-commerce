/*    */ package ch.qos.logback.core.sift;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SiftProcessor<E>
/*    */   extends DefaultProcessor
/*    */ {
/*    */   public SiftProcessor(Context context, ModelInterpretationContext mic) {
/* 24 */     super(mic.getContext(), mic);
/*    */   }
/*    */   
/*    */   ModelInterpretationContext getModelInterpretationContext() {
/* 28 */     return this.mic;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\sift\SiftProcessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */