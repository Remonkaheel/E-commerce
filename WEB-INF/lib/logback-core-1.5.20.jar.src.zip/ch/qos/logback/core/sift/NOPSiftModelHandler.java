/*    */ package ch.qos.logback.core.sift;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.SiftModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NOPSiftModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   public NOPSiftModelHandler(Context context) {
/* 26 */     super(context);
/*    */   }
/*    */   
/*    */   public static NOPSiftModelHandler makeInstance(Context context, ModelInterpretationContext ic) {
/* 30 */     return new NOPSiftModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<SiftModel> getSupportedModelClass() {
/* 35 */     return SiftModel.class;
/*    */   }
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\sift\NOPSiftModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */