/*    */ package ch.qos.logback.core.sift;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.SiftModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SiftModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   static final String ONE_AND_ONLY_ONE_URL = "https://logback.qos.ch/codes.html#1andOnly1";
/*    */   
/*    */   public SiftModelHandler(Context context) {
/* 31 */     super(context);
/*    */   }
/*    */   
/*    */   public static SiftModelHandler makeInstance(Context context, ModelInterpretationContext ic) {
/* 35 */     return new SiftModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<SiftModel> getSupportedModelClass() {
/* 40 */     return SiftModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 47 */     SiftModel siftModel = (SiftModel)model;
/*    */     
/* 49 */     siftModel.markAsSkipped();
/*    */     
/* 51 */     long appenderModelCount = computeAppenderModelCount(siftModel);
/*    */     
/* 53 */     if (appenderModelCount == 0L) {
/* 54 */       String errMsg = "No nested appenders found within the <sift> element in SiftingAppender.";
/* 55 */       addError(errMsg);
/*    */       return;
/*    */     } 
/* 58 */     if (appenderModelCount > 1L) {
/* 59 */       String errMsg = "Only and only one appender can be nested the <sift> element in SiftingAppender. See also https://logback.qos.ch/codes.html#1andOnly1";
/* 60 */       addError(errMsg);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 65 */     Object o = mic.peekObject();
/* 66 */     if (o instanceof SiftingAppenderBase) {
/*    */       
/* 68 */       SiftingAppenderBase sa = (SiftingAppenderBase)o;
/*    */       
/* 70 */       String key = sa.getDiscriminatorKey();
/*    */       
/* 72 */       AppenderFactoryUsingSiftModel afusm = new AppenderFactoryUsingSiftModel(mic, (Model)siftModel, key);
/*    */       
/* 74 */       sa.setAppenderFactory(afusm);
/*    */     } else {
/*    */       
/* 77 */       addError("Unexpected object " + String.valueOf(o));
/*    */     } 
/*    */   }
/*    */   
/*    */   private long computeAppenderModelCount(SiftModel siftModel) {
/* 82 */     Stream<Model> stream = siftModel.getSubModels().stream();
/* 83 */     long count = stream.filter(m -> m instanceof ch.qos.logback.core.model.AppenderModel).count();
/* 84 */     return count;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\sift\SiftModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */