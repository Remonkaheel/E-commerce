/*     */ package ch.qos.logback.core.sift;
/*     */ 
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.AppenderBase;
/*     */ import ch.qos.logback.core.model.SiftModel;
/*     */ import ch.qos.logback.core.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SiftingAppenderBase<E>
/*     */   extends AppenderBase<E>
/*     */ {
/*     */   protected AppenderTracker<E> appenderTracker;
/*     */   AppenderFactory<E> appenderFactory;
/*  35 */   Duration timeout = new Duration(1800000L);
/*  36 */   int maxAppenderCount = Integer.MAX_VALUE;
/*     */   
/*     */   SiftModel siftModel;
/*     */   Discriminator<E> discriminator;
/*     */   
/*     */   public Duration getTimeout() {
/*  42 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public void setTimeout(Duration timeout) {
/*  46 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public SiftModel getSiftModel() {
/*  50 */     return this.siftModel;
/*     */   }
/*     */   
/*     */   public void setSiftModel(SiftModel siftModel) {
/*  54 */     this.siftModel = siftModel;
/*     */   }
/*     */   
/*     */   public int getMaxAppenderCount() {
/*  58 */     return this.maxAppenderCount;
/*     */   }
/*     */   
/*     */   public void setMaxAppenderCount(int maxAppenderCount) {
/*  62 */     this.maxAppenderCount = maxAppenderCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAppenderFactory(AppenderFactory<E> appenderFactory) {
/*  70 */     this.appenderFactory = appenderFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*  75 */     int errors = 0;
/*  76 */     if (this.discriminator == null) {
/*  77 */       addError("Missing discriminator. Aborting");
/*  78 */       errors++;
/*     */     } 
/*  80 */     if (!this.discriminator.isStarted()) {
/*  81 */       addError("Discriminator has not started successfully. Aborting");
/*  82 */       errors++;
/*     */     } 
/*  84 */     if (this.appenderFactory == null) {
/*  85 */       addError("AppenderFactory has not been set. Aborting");
/*  86 */       errors++;
/*     */     } else {
/*  88 */       this.appenderTracker = new AppenderTracker<>(this.context, this.appenderFactory);
/*  89 */       this.appenderTracker.setMaxComponents(this.maxAppenderCount);
/*  90 */       this.appenderTracker.setTimeout(this.timeout.getMilliseconds());
/*     */     } 
/*  92 */     if (errors == 0) {
/*  93 */       super.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/*  99 */     if (!isStarted())
/*     */       return; 
/* 101 */     for (Appender<E> appender : (Iterable<Appender<E>>)this.appenderTracker.allComponents()) {
/* 102 */       appender.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract long getTimestamp(E paramE);
/*     */   
/*     */   protected void append(E event) {
/* 110 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/* 113 */     String discriminatingValue = this.discriminator.getDiscriminatingValue(event);
/* 114 */     long timestamp = getTimestamp(event);
/*     */     
/* 116 */     Appender<E> appender = (Appender<E>)this.appenderTracker.getOrCreate(discriminatingValue, timestamp);
/*     */     
/* 118 */     if (eventMarksEndOfLife(event)) {
/* 119 */       this.appenderTracker.endOfLife(discriminatingValue);
/*     */     }
/* 121 */     this.appenderTracker.removeStaleComponents(timestamp);
/* 122 */     appender.doAppend(event);
/*     */   }
/*     */   
/*     */   protected abstract boolean eventMarksEndOfLife(E paramE);
/*     */   
/*     */   public Discriminator<E> getDiscriminator() {
/* 128 */     return this.discriminator;
/*     */   }
/*     */   
/*     */   public void setDiscriminator(Discriminator<E> discriminator) {
/* 132 */     this.discriminator = discriminator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AppenderTracker<E> getAppenderTracker() {
/* 145 */     return this.appenderTracker;
/*     */   }
/*     */   
/*     */   public String getDiscriminatorKey() {
/* 149 */     if (this.discriminator != null) {
/* 150 */       return this.discriminator.getKey();
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\sift\SiftingAppenderBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */