package ch.qos.logback.core.spi;

import ch.qos.logback.core.Appender;
import java.util.Iterator;

public interface AppenderAttachable<E> {
  void addAppender(Appender<E> paramAppender);
  
  Iterator<Appender<E>> iteratorForAppenders();
  
  Appender<E> getAppender(String paramString);
  
  boolean isAttached(Appender<E> paramAppender);
  
  void detachAndStopAllAppenders();
  
  boolean detachAppender(Appender<E> paramAppender);
  
  boolean detachAppender(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\spi\AppenderAttachable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */