package ch.qos.logback.core.spi;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.status.Status;

public interface ContextAware {
  void setContext(Context paramContext);
  
  Context getContext();
  
  void addStatus(Status paramStatus);
  
  void addInfo(String paramString);
  
  void addInfo(String paramString, Throwable paramThrowable);
  
  void addWarn(String paramString);
  
  void addWarn(String paramString, Throwable paramThrowable);
  
  void addError(String paramString);
  
  void addError(String paramString, Throwable paramThrowable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\spi\ContextAware.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */