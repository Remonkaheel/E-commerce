package ch.qos.logback.core.spi;

import ch.qos.logback.core.filter.Filter;
import java.util.List;

public interface FilterAttachable<E> {
  void addFilter(Filter<E> paramFilter);
  
  void clearAllFilters();
  
  List<Filter<E>> getCopyOfAttachedFiltersList();
  
  FilterReply getFilterChainDecision(E paramE);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\spi\FilterAttachable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */