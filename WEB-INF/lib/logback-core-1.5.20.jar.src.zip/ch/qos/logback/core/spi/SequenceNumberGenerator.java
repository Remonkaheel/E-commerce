package ch.qos.logback.core.spi;

public interface SequenceNumberGenerator extends ContextAware {
  long nextSequenceNumber();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\spi\SequenceNumberGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */