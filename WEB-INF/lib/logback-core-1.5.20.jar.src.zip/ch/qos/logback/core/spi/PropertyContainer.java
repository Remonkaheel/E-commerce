/*    */ package ch.qos.logback.core.spi;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PropertyContainer
/*    */ {
/*    */   void addSubstitutionProperty(String paramString1, String paramString2);
/*    */   
/*    */   String getProperty(String paramString);
/*    */   
/*    */   Map<String, String> getCopyOfPropertyMap();
/*    */   
/*    */   default void addSubstitutionProperties(Properties props) {
/* 29 */     if (props == null) {
/*    */       return;
/*    */     }
/* 32 */     props.forEach((k, v) -> addSubstitutionProperty((String)k, (String)v));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\spi\PropertyContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */