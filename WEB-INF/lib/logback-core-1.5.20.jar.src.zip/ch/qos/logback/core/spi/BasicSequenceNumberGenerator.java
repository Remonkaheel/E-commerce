/*    */ package ch.qos.logback.core.spi;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicSequenceNumberGenerator
/*    */   extends ContextAwareBase
/*    */   implements SequenceNumberGenerator
/*    */ {
/* 15 */   private final AtomicLong atomicLong = new AtomicLong();
/*    */ 
/*    */   
/*    */   public long nextSequenceNumber() {
/* 19 */     return this.atomicLong.incrementAndGet();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\spi\BasicSequenceNumberGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */