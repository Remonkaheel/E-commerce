/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.recovery.ResilientFileOutputStream;
/*     */ import ch.qos.logback.core.util.ContextUtil;
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import ch.qos.logback.core.util.FileUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileAppender<E>
/*     */   extends OutputStreamAppender<E>
/*     */ {
/*     */   public static final long DEFAULT_BUFFER_SIZE = 8192L;
/*  43 */   protected static String COLLISION_WITH_EARLIER_APPENDER_URL = "https://logback.qos.ch/codes.html#earlier_fa_collision";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean append = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   protected String fileName = null;
/*     */   
/*     */   private boolean prudent = false;
/*     */   
/*  59 */   private FileSize bufferSize = new FileSize(8192L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFile(String file) {
/*  66 */     if (file == null) {
/*  67 */       this.fileName = file;
/*     */     }
/*     */     else {
/*     */       
/*  71 */       this.fileName = file.trim();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAppend() {
/*  79 */     return this.append;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String rawFileProperty() {
/*  89 */     return this.fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFile() {
/* 100 */     return this.fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 108 */     int errors = 0;
/* 109 */     if (getFile() != null) {
/* 110 */       addInfo("File property is set to [" + this.fileName + "]");
/*     */       
/* 112 */       if (this.prudent && 
/* 113 */         !isAppend()) {
/* 114 */         setAppend(true);
/* 115 */         addWarn("Setting \"Append\" property to true on account of \"Prudent\" mode");
/*     */       } 
/*     */ 
/*     */       
/* 119 */       if (checkForFileCollisionInPreviousFileAppenders()) {
/* 120 */         addError("Collisions detected with FileAppender/RollingAppender instances defined earlier. Aborting.");
/* 121 */         addError("For more information, please visit " + COLLISION_WITH_EARLIER_APPENDER_URL);
/* 122 */         errors++;
/*     */       } else {
/*     */         
/*     */         try {
/* 126 */           openFile(getFile());
/* 127 */         } catch (IOException e) {
/* 128 */           errors++;
/* 129 */           addError("openFile(" + this.fileName + "," + this.append + ") call failed.", e);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 133 */       errors++;
/* 134 */       addError("\"File\" property not set for appender named [" + this.name + "].");
/*     */     } 
/* 136 */     if (errors == 0) {
/* 137 */       super.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 143 */     if (!isStarted()) {
/*     */       return;
/*     */     }
/* 146 */     super.stop();
/*     */     
/* 148 */     Map<String, String> map = ContextUtil.getFilenameCollisionMap(this.context);
/* 149 */     if (map == null || getName() == null) {
/*     */       return;
/*     */     }
/* 152 */     map.remove(getName());
/*     */   }
/*     */   
/*     */   protected boolean checkForFileCollisionInPreviousFileAppenders() {
/* 156 */     boolean collisionsDetected = false;
/* 157 */     if (this.fileName == null) {
/* 158 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 162 */     Map<String, String> previousFilesMap = (Map<String, String>)this.context.getObject("FA_FILENAMES_MAP");
/* 163 */     if (previousFilesMap == null) {
/* 164 */       return collisionsDetected;
/*     */     }
/* 166 */     for (Map.Entry<String, String> entry : previousFilesMap.entrySet()) {
/* 167 */       if (this.fileName.equals(entry.getValue())) {
/* 168 */         addErrorForCollision("File", entry.getValue(), entry.getKey());
/* 169 */         collisionsDetected = true;
/*     */       } 
/*     */     } 
/* 172 */     if (this.name != null) {
/* 173 */       previousFilesMap.put(getName(), this.fileName);
/*     */     }
/* 175 */     return collisionsDetected;
/*     */   }
/*     */   
/*     */   protected void addErrorForCollision(String optionName, String optionValue, String appenderName) {
/* 179 */     addError("'" + optionName + "' option has the same value \"" + optionValue + "\" as that given for appender [" + appenderName + "] defined earlier.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void openFile(String file_name) throws IOException {
/* 198 */     this.streamWriteLock.lock();
/*     */     try {
/* 200 */       File file = new File(file_name);
/* 201 */       boolean result = FileUtil.createMissingParentDirectories(file);
/* 202 */       if (!result) {
/* 203 */         addError("Failed to create parent directories for [" + file.getAbsolutePath() + "]");
/*     */       }
/*     */       
/* 206 */       ResilientFileOutputStream resilientFos = new ResilientFileOutputStream(file, this.append, this.bufferSize.getSize());
/* 207 */       resilientFos.setContext(this.context);
/* 208 */       setOutputStream((OutputStream)resilientFos);
/*     */     } finally {
/* 210 */       this.streamWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrudent() {
/* 220 */     return this.prudent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrudent(boolean prudent) {
/* 230 */     this.prudent = prudent;
/*     */   }
/*     */   
/*     */   public void setAppend(boolean append) {
/* 234 */     this.append = append;
/*     */   }
/*     */   
/*     */   public void setBufferSize(FileSize bufferSize) {
/* 238 */     addInfo("Setting bufferSize to [" + bufferSize.toString() + "]");
/* 239 */     this.bufferSize = bufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeOut(E event) throws IOException {
/* 244 */     if (this.prudent) {
/* 245 */       safeWriteOut(event);
/*     */     } else {
/* 247 */       super.writeOut(event);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void safeWriteOut(E event) {
/* 252 */     byte[] byteArray = this.encoder.encode(event);
/* 253 */     if (byteArray == null || byteArray.length == 0) {
/*     */       return;
/*     */     }
/* 256 */     this.streamWriteLock.lock();
/*     */     try {
/* 258 */       safeWriteBytes(byteArray);
/*     */     } finally {
/* 260 */       this.streamWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void safeWriteBytes(byte[] byteArray) {
/* 265 */     ResilientFileOutputStream resilientFOS = (ResilientFileOutputStream)getOutputStream();
/* 266 */     FileChannel fileChannel = resilientFOS.getChannel();
/* 267 */     if (fileChannel == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 272 */     boolean interrupted = Thread.interrupted();
/*     */     
/* 274 */     FileLock fileLock = null;
/*     */     try {
/* 276 */       fileLock = fileChannel.lock();
/* 277 */       long position = fileChannel.position();
/* 278 */       long size = fileChannel.size();
/* 279 */       if (size != position) {
/* 280 */         fileChannel.position(size);
/*     */       }
/* 282 */       writeByteArrayToOutputStreamWithPossibleFlush(byteArray);
/* 283 */     } catch (IOException e) {
/*     */       
/* 285 */       resilientFOS.postIOFailure(e);
/*     */     } finally {
/* 287 */       releaseFileLock(fileLock);
/*     */ 
/*     */       
/* 290 */       if (interrupted) {
/* 291 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void releaseFileLock(FileLock fileLock) {
/* 297 */     if (fileLock != null && fileLock.isValid())
/*     */       try {
/* 299 */         fileLock.release();
/* 300 */       } catch (IOException e) {
/* 301 */         addError("failed to release lock", e);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\ch\qos\logback\core\FileAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */