/*    */ package META-INF.versions.21.ch.qos.logback.core.property;
/*    */ 
/*    */ import ch.qos.logback.core.PropertyDefinerBase;
/*    */ import java.io.Console;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConsoleCharsetPropertyDefiner
/*    */   extends PropertyDefinerBase
/*    */ {
/*    */   public String getPropertyValue() {
/* 32 */     Console console = System.console();
/* 33 */     if (console != null) {
/* 34 */       Charset charset = console.charset();
/* 35 */       if (charset != null) {
/* 36 */         String charsetName = charset.name();
/* 37 */         addInfo("Found value '" + charsetName + "' as returned by System.console().");
/* 38 */         return charsetName;
/*    */       } 
/* 40 */       addInfo("System.console() returned null charset. Returning \"NULL\" string as defined value.");
/* 41 */       return "null";
/*    */     } 
/*    */     
/* 44 */     addWarn("System.console() returned null. Cannot compute console's charset, returning the \"NULL\" string, i.e. the default JVM charset");
/* 45 */     return "null";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-core-1.5.20.jar!\META-INF\versions\21\ch\qos\logback\core\property\ConsoleCharsetPropertyDefiner.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */