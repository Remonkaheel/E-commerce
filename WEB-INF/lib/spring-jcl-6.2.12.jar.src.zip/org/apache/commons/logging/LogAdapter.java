/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*     */ import org.apache.logging.log4j.spi.LoggerContext;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LogAdapter
/*     */ {
/*  41 */   private static final boolean log4jSpiPresent = isPresent("org.apache.logging.log4j.spi.ExtendedLogger");
/*     */   
/*  43 */   private static final boolean log4jSlf4jProviderPresent = isPresent("org.apache.logging.slf4j.SLF4JProvider");
/*     */   
/*  45 */   private static final boolean slf4jSpiPresent = isPresent("org.slf4j.spi.LocationAwareLogger");
/*     */   
/*  47 */   private static final boolean slf4jApiPresent = isPresent("org.slf4j.Logger");
/*     */   
/*     */   private static final Function<String, Log> createLog;
/*     */ 
/*     */   
/*     */   static {
/*  53 */     if (log4jSpiPresent) {
/*  54 */       if (log4jSlf4jProviderPresent && slf4jSpiPresent)
/*     */       {
/*     */ 
/*     */         
/*  58 */         createLog = Slf4jAdapter::createLocationAwareLog;
/*     */       }
/*     */       else
/*     */       {
/*  62 */         createLog = Log4jAdapter::createLog;
/*     */       }
/*     */     
/*  65 */     } else if (slf4jSpiPresent) {
/*     */       
/*  67 */       createLog = Slf4jAdapter::createLocationAwareLog;
/*     */     }
/*  69 */     else if (slf4jApiPresent) {
/*     */       
/*  71 */       createLog = Slf4jAdapter::createLog;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  81 */       createLog = JavaUtilAdapter::createLog;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log createLog(String name) {
/*  95 */     return createLog.apply(name);
/*     */   }
/*     */   
/*     */   private static boolean isPresent(String className) {
/*     */     try {
/* 100 */       Class.forName(className, false, LogAdapter.class.getClassLoader());
/* 101 */       return true;
/*     */     }
/* 103 */     catch (Throwable ex) {
/*     */       
/* 105 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Log4jAdapter
/*     */   {
/*     */     public static Log createLog(String name) {
/* 113 */       return new LogAdapter.Log4jLog(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Slf4jAdapter
/*     */   {
/*     */     public static Log createLocationAwareLog(String name) {
/* 121 */       Logger logger = LoggerFactory.getLogger(name);
/* 122 */       LocationAwareLogger locationAwareLogger = (LocationAwareLogger)logger; return (logger instanceof LocationAwareLogger) ? 
/* 123 */         new LogAdapter.Slf4jLocationAwareLog(locationAwareLogger) : new LogAdapter.Slf4jLog<>(logger);
/*     */     }
/*     */     
/*     */     public static Log createLog(String name) {
/* 127 */       return new LogAdapter.Slf4jLog<>(LoggerFactory.getLogger(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JavaUtilAdapter
/*     */   {
/*     */     public static Log createLog(String name) {
/* 135 */       return new LogAdapter.JavaUtilLog(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Log4jLog
/*     */     implements Log, Serializable
/*     */   {
/* 143 */     private static final String FQCN = Log4jLog.class.getName();
/*     */ 
/*     */     
/* 146 */     private static final LoggerContext loggerContext = LogManager.getContext(Log4jLog.class.getClassLoader(), false);
/*     */     
/*     */     private final String name;
/*     */     
/*     */     private final transient ExtendedLogger logger;
/*     */     
/*     */     public Log4jLog(String name) {
/* 153 */       this.name = name;
/* 154 */       LoggerContext context = loggerContext;
/* 155 */       if (context == null)
/*     */       {
/* 157 */         context = LogManager.getContext(Log4jLog.class.getClassLoader(), false);
/*     */       }
/* 159 */       this.logger = context.getLogger(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFatalEnabled() {
/* 164 */       return this.logger.isEnabled(Level.FATAL);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 169 */       return this.logger.isEnabled(Level.ERROR);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 174 */       return this.logger.isEnabled(Level.WARN);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 179 */       return this.logger.isEnabled(Level.INFO);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 184 */       return this.logger.isEnabled(Level.DEBUG);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 189 */       return this.logger.isEnabled(Level.TRACE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message) {
/* 194 */       log(Level.FATAL, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message, Throwable exception) {
/* 199 */       log(Level.FATAL, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message) {
/* 204 */       log(Level.ERROR, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message, Throwable exception) {
/* 209 */       log(Level.ERROR, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message) {
/* 214 */       log(Level.WARN, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message, Throwable exception) {
/* 219 */       log(Level.WARN, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message) {
/* 224 */       log(Level.INFO, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message, Throwable exception) {
/* 229 */       log(Level.INFO, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message) {
/* 234 */       log(Level.DEBUG, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message, Throwable exception) {
/* 239 */       log(Level.DEBUG, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message) {
/* 244 */       log(Level.TRACE, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message, Throwable exception) {
/* 249 */       log(Level.TRACE, message, exception);
/*     */     }
/*     */     
/*     */     private void log(Level level, Object message, Throwable exception) {
/* 253 */       if (message instanceof String) { String text = (String)message;
/*     */ 
/*     */         
/* 256 */         if (exception != null) {
/* 257 */           this.logger.logIfEnabled(FQCN, level, null, text, exception);
/*     */         } else {
/*     */           
/* 260 */           this.logger.logIfEnabled(FQCN, level, null, text);
/*     */         }  }
/*     */       else
/*     */       
/* 264 */       { this.logger.logIfEnabled(FQCN, level, null, message, exception); }
/*     */     
/*     */     }
/*     */     
/*     */     protected Object readResolve() {
/* 269 */       return new Log4jLog(this.name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Slf4jLog<T extends Logger>
/*     */     implements Log, Serializable
/*     */   {
/*     */     protected final String name;
/*     */     
/*     */     protected final transient T logger;
/*     */     
/*     */     public Slf4jLog(T logger) {
/* 282 */       this.name = logger.getName();
/* 283 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFatalEnabled() {
/* 288 */       return isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 293 */       return this.logger.isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 298 */       return this.logger.isWarnEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 303 */       return this.logger.isInfoEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 308 */       return this.logger.isDebugEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 313 */       return this.logger.isTraceEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message) {
/* 318 */       error(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message, Throwable exception) {
/* 323 */       error(message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message) {
/* 328 */       if (message instanceof String || this.logger.isErrorEnabled()) {
/* 329 */         this.logger.error(String.valueOf(message));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message, Throwable exception) {
/* 335 */       if (message instanceof String || this.logger.isErrorEnabled()) {
/* 336 */         this.logger.error(String.valueOf(message), exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message) {
/* 342 */       if (message instanceof String || this.logger.isWarnEnabled()) {
/* 343 */         this.logger.warn(String.valueOf(message));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message, Throwable exception) {
/* 349 */       if (message instanceof String || this.logger.isWarnEnabled()) {
/* 350 */         this.logger.warn(String.valueOf(message), exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message) {
/* 356 */       if (message instanceof String || this.logger.isInfoEnabled()) {
/* 357 */         this.logger.info(String.valueOf(message));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message, Throwable exception) {
/* 363 */       if (message instanceof String || this.logger.isInfoEnabled()) {
/* 364 */         this.logger.info(String.valueOf(message), exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message) {
/* 370 */       if (message instanceof String || this.logger.isDebugEnabled()) {
/* 371 */         this.logger.debug(String.valueOf(message));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message, Throwable exception) {
/* 377 */       if (message instanceof String || this.logger.isDebugEnabled()) {
/* 378 */         this.logger.debug(String.valueOf(message), exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message) {
/* 384 */       if (message instanceof String || this.logger.isTraceEnabled()) {
/* 385 */         this.logger.trace(String.valueOf(message));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message, Throwable exception) {
/* 391 */       if (message instanceof String || this.logger.isTraceEnabled()) {
/* 392 */         this.logger.trace(String.valueOf(message), exception);
/*     */       }
/*     */     }
/*     */     
/*     */     protected Object readResolve() {
/* 397 */       return LogAdapter.Slf4jAdapter.createLog(this.name);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Slf4jLocationAwareLog
/*     */     extends Slf4jLog<LocationAwareLogger>
/*     */     implements Serializable
/*     */   {
/* 405 */     private static final String FQCN = Slf4jLocationAwareLog.class.getName();
/*     */     
/*     */     public Slf4jLocationAwareLog(LocationAwareLogger logger) {
/* 408 */       super(logger);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message) {
/* 413 */       error(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message, Throwable exception) {
/* 418 */       error(message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message) {
/* 423 */       if (message instanceof String || this.logger.isErrorEnabled()) {
/* 424 */         this.logger.log(null, FQCN, 40, String.valueOf(message), null, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message, Throwable exception) {
/* 430 */       if (message instanceof String || this.logger.isErrorEnabled()) {
/* 431 */         this.logger.log(null, FQCN, 40, String.valueOf(message), null, exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message) {
/* 437 */       if (message instanceof String || this.logger.isWarnEnabled()) {
/* 438 */         this.logger.log(null, FQCN, 30, String.valueOf(message), null, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message, Throwable exception) {
/* 444 */       if (message instanceof String || this.logger.isWarnEnabled()) {
/* 445 */         this.logger.log(null, FQCN, 30, String.valueOf(message), null, exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message) {
/* 451 */       if (message instanceof String || this.logger.isInfoEnabled()) {
/* 452 */         this.logger.log(null, FQCN, 20, String.valueOf(message), null, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message, Throwable exception) {
/* 458 */       if (message instanceof String || this.logger.isInfoEnabled()) {
/* 459 */         this.logger.log(null, FQCN, 20, String.valueOf(message), null, exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message) {
/* 465 */       if (message instanceof String || this.logger.isDebugEnabled()) {
/* 466 */         this.logger.log(null, FQCN, 10, String.valueOf(message), null, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message, Throwable exception) {
/* 472 */       if (message instanceof String || this.logger.isDebugEnabled()) {
/* 473 */         this.logger.log(null, FQCN, 10, String.valueOf(message), null, exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message) {
/* 479 */       if (message instanceof String || this.logger.isTraceEnabled()) {
/* 480 */         this.logger.log(null, FQCN, 0, String.valueOf(message), null, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message, Throwable exception) {
/* 486 */       if (message instanceof String || this.logger.isTraceEnabled()) {
/* 487 */         this.logger.log(null, FQCN, 0, String.valueOf(message), null, exception);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 493 */       return LogAdapter.Slf4jAdapter.createLocationAwareLog(this.name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JavaUtilLog
/*     */     implements Log, Serializable
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final transient Logger logger;
/*     */     
/*     */     public JavaUtilLog(String name) {
/* 506 */       this.name = name;
/* 507 */       this.logger = Logger.getLogger(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFatalEnabled() {
/* 512 */       return isErrorEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isErrorEnabled() {
/* 517 */       return this.logger.isLoggable(Level.SEVERE);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isWarnEnabled() {
/* 522 */       return this.logger.isLoggable(Level.WARNING);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInfoEnabled() {
/* 527 */       return this.logger.isLoggable(Level.INFO);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDebugEnabled() {
/* 532 */       return this.logger.isLoggable(Level.FINE);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTraceEnabled() {
/* 537 */       return this.logger.isLoggable(Level.FINEST);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message) {
/* 542 */       error(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatal(Object message, Throwable exception) {
/* 547 */       error(message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message) {
/* 552 */       log(Level.SEVERE, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Object message, Throwable exception) {
/* 557 */       log(Level.SEVERE, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message) {
/* 562 */       log(Level.WARNING, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warn(Object message, Throwable exception) {
/* 567 */       log(Level.WARNING, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message) {
/* 572 */       log(Level.INFO, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void info(Object message, Throwable exception) {
/* 577 */       log(Level.INFO, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message) {
/* 582 */       log(Level.FINE, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void debug(Object message, Throwable exception) {
/* 587 */       log(Level.FINE, message, exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message) {
/* 592 */       log(Level.FINEST, message, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void trace(Object message, Throwable exception) {
/* 597 */       log(Level.FINEST, message, exception);
/*     */     }
/*     */     
/*     */     private void log(Level level, Object message, Throwable exception) {
/* 601 */       if (this.logger.isLoggable(level)) {
/*     */         LogRecord rec;
/* 603 */         if (message instanceof LogRecord) { LogRecord logRecord = (LogRecord)message;
/* 604 */           rec = logRecord; }
/*     */         else
/*     */         
/* 607 */         { rec = new LogAdapter.LocationResolvingLogRecord(level, String.valueOf(message));
/* 608 */           rec.setLoggerName(this.name);
/* 609 */           rec.setResourceBundleName(this.logger.getResourceBundleName());
/* 610 */           rec.setResourceBundle(this.logger.getResourceBundle());
/* 611 */           rec.setThrown(exception); }
/*     */         
/* 613 */         this.logger.log(rec);
/*     */       } 
/*     */     }
/*     */     
/*     */     protected Object readResolve() {
/* 618 */       return new JavaUtilLog(this.name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LocationResolvingLogRecord
/*     */     extends LogRecord
/*     */   {
/* 626 */     private static final String FQCN = LogAdapter.JavaUtilLog.class.getName();
/*     */     
/*     */     private volatile boolean resolved;
/*     */     
/*     */     public LocationResolvingLogRecord(Level level, String msg) {
/* 631 */       super(level, msg);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSourceClassName() {
/* 636 */       if (!this.resolved) {
/* 637 */         resolve();
/*     */       }
/* 639 */       return super.getSourceClassName();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSourceClassName(String sourceClassName) {
/* 644 */       super.setSourceClassName(sourceClassName);
/* 645 */       this.resolved = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSourceMethodName() {
/* 650 */       if (!this.resolved) {
/* 651 */         resolve();
/*     */       }
/* 653 */       return super.getSourceMethodName();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSourceMethodName(String sourceMethodName) {
/* 658 */       super.setSourceMethodName(sourceMethodName);
/* 659 */       this.resolved = true;
/*     */     }
/*     */     
/*     */     private void resolve() {
/* 663 */       StackTraceElement[] stack = (new Throwable()).getStackTrace();
/* 664 */       String sourceClassName = null;
/* 665 */       String sourceMethodName = null;
/* 666 */       boolean found = false;
/* 667 */       for (StackTraceElement element : stack) {
/* 668 */         String className = element.getClassName();
/* 669 */         if (FQCN.equals(className)) {
/* 670 */           found = true;
/*     */         }
/* 672 */         else if (found) {
/* 673 */           sourceClassName = className;
/* 674 */           sourceMethodName = element.getMethodName();
/*     */           break;
/*     */         } 
/*     */       } 
/* 678 */       setSourceClassName(sourceClassName);
/* 679 */       setSourceMethodName(sourceMethodName);
/*     */     }
/*     */     
/*     */     protected Object writeReplace() {
/* 683 */       LogRecord serialized = new LogRecord(getLevel(), getMessage());
/* 684 */       serialized.setLoggerName(getLoggerName());
/* 685 */       serialized.setResourceBundle(getResourceBundle());
/* 686 */       serialized.setResourceBundleName(getResourceBundleName());
/* 687 */       serialized.setSourceClassName(getSourceClassName());
/* 688 */       serialized.setSourceMethodName(getSourceMethodName());
/* 689 */       serialized.setSequenceNumber(getSequenceNumber());
/* 690 */       serialized.setParameters(getParameters());
/* 691 */       serialized.setLongThreadID(getLongThreadID());
/* 692 */       serialized.setInstant(getInstant());
/* 693 */       serialized.setThrown(getThrown());
/* 694 */       return serialized;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\LogAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */