/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Slf4jLog<T extends Logger>
/*     */   implements Log, Serializable
/*     */ {
/*     */   protected final String name;
/*     */   protected final transient T logger;
/*     */   
/*     */   public Slf4jLog(T logger) {
/* 282 */     this.name = logger.getName();
/* 283 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/* 288 */     return isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 293 */     return this.logger.isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 298 */     return this.logger.isWarnEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 303 */     return this.logger.isInfoEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 308 */     return this.logger.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 313 */     return this.logger.isTraceEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/* 318 */     error(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable exception) {
/* 323 */     error(message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/* 328 */     if (message instanceof String || this.logger.isErrorEnabled()) {
/* 329 */       this.logger.error(String.valueOf(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable exception) {
/* 335 */     if (message instanceof String || this.logger.isErrorEnabled()) {
/* 336 */       this.logger.error(String.valueOf(message), exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 342 */     if (message instanceof String || this.logger.isWarnEnabled()) {
/* 343 */       this.logger.warn(String.valueOf(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable exception) {
/* 349 */     if (message instanceof String || this.logger.isWarnEnabled()) {
/* 350 */       this.logger.warn(String.valueOf(message), exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 356 */     if (message instanceof String || this.logger.isInfoEnabled()) {
/* 357 */       this.logger.info(String.valueOf(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable exception) {
/* 363 */     if (message instanceof String || this.logger.isInfoEnabled()) {
/* 364 */       this.logger.info(String.valueOf(message), exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message) {
/* 370 */     if (message instanceof String || this.logger.isDebugEnabled()) {
/* 371 */       this.logger.debug(String.valueOf(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable exception) {
/* 377 */     if (message instanceof String || this.logger.isDebugEnabled()) {
/* 378 */       this.logger.debug(String.valueOf(message), exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message) {
/* 384 */     if (message instanceof String || this.logger.isTraceEnabled()) {
/* 385 */       this.logger.trace(String.valueOf(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message, Throwable exception) {
/* 391 */     if (message instanceof String || this.logger.isTraceEnabled()) {
/* 392 */       this.logger.trace(String.valueOf(message), exception);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object readResolve() {
/* 397 */     return LogAdapter.Slf4jAdapter.createLog(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\LogAdapter$Slf4jLog.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */