/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LogFactory
/*     */ {
/*     */   public static Log getLog(Class<?> clazz) {
/*  59 */     return getLog(clazz.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log getLog(String name) {
/*  67 */     return LogAdapter.createLog(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static LogFactory getFactory() {
/*  80 */     return new LogFactory()
/*     */       {
/*     */         public Object getAttribute(String name) {
/*  83 */           return null;
/*     */         }
/*     */         
/*     */         public String[] getAttributeNames() {
/*  87 */           return new String[0];
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void removeAttribute(String name) {}
/*     */ 
/*     */ 
/*     */         
/*     */         public void setAttribute(String name, Object value) {}
/*     */ 
/*     */ 
/*     */         
/*     */         public void release() {}
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Log getInstance(Class<?> clazz) {
/* 109 */     return getLog(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Log getInstance(String name) {
/* 120 */     return getLog(name);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract Object getAttribute(String paramString);
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract String[] getAttributeNames();
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract void removeAttribute(String paramString);
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract void setAttribute(String paramString, Object paramObject);
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract void release();
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void release(ClassLoader classLoader) {}
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void releaseAll() {}
/*     */   
/*     */   @Deprecated
/*     */   public static String objectId(Object o) {
/* 153 */     return (o == null) ? "null" : (o.getClass().getName() + "@" + o.getClass().getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\LogFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */