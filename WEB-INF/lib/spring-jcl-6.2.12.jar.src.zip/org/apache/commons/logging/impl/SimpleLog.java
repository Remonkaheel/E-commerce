/*    */ package org.apache.commons.logging.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class SimpleLog
/*    */   extends NoOpLog
/*    */ {
/*    */   public SimpleLog(String name) {
/* 35 */     super(name);
/* 36 */     System.out.println(SimpleLog.class.getName() + " is deprecated and equivalent to NoOpLog in spring-jcl. Use a standard LogFactory.getLog(Class/String) call instead.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\impl\SimpleLog.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */