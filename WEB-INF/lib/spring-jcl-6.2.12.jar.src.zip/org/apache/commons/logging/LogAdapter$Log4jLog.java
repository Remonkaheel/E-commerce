/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*     */ import org.apache.logging.log4j.spi.LoggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Log4jLog
/*     */   implements Log, Serializable
/*     */ {
/* 143 */   private static final String FQCN = Log4jLog.class.getName();
/*     */ 
/*     */   
/* 146 */   private static final LoggerContext loggerContext = LogManager.getContext(Log4jLog.class.getClassLoader(), false);
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final transient ExtendedLogger logger;
/*     */   
/*     */   public Log4jLog(String name) {
/* 153 */     this.name = name;
/* 154 */     LoggerContext context = loggerContext;
/* 155 */     if (context == null)
/*     */     {
/* 157 */       context = LogManager.getContext(Log4jLog.class.getClassLoader(), false);
/*     */     }
/* 159 */     this.logger = context.getLogger(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/* 164 */     return this.logger.isEnabled(Level.FATAL);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 169 */     return this.logger.isEnabled(Level.ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 174 */     return this.logger.isEnabled(Level.WARN);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 179 */     return this.logger.isEnabled(Level.INFO);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 184 */     return this.logger.isEnabled(Level.DEBUG);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 189 */     return this.logger.isEnabled(Level.TRACE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/* 194 */     log(Level.FATAL, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable exception) {
/* 199 */     log(Level.FATAL, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/* 204 */     log(Level.ERROR, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable exception) {
/* 209 */     log(Level.ERROR, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 214 */     log(Level.WARN, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable exception) {
/* 219 */     log(Level.WARN, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 224 */     log(Level.INFO, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable exception) {
/* 229 */     log(Level.INFO, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message) {
/* 234 */     log(Level.DEBUG, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable exception) {
/* 239 */     log(Level.DEBUG, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message) {
/* 244 */     log(Level.TRACE, message, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message, Throwable exception) {
/* 249 */     log(Level.TRACE, message, exception);
/*     */   }
/*     */   
/*     */   private void log(Level level, Object message, Throwable exception) {
/* 253 */     if (message instanceof String) { String text = (String)message;
/*     */ 
/*     */       
/* 256 */       if (exception != null) {
/* 257 */         this.logger.logIfEnabled(FQCN, level, null, text, exception);
/*     */       } else {
/*     */         
/* 260 */         this.logger.logIfEnabled(FQCN, level, null, text);
/*     */       }  }
/*     */     else
/*     */     
/* 264 */     { this.logger.logIfEnabled(FQCN, level, null, message, exception); }
/*     */   
/*     */   }
/*     */   
/*     */   protected Object readResolve() {
/* 269 */     return new Log4jLog(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\LogAdapter$Log4jLog.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */