/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Slf4jLocationAwareLog
/*     */   extends LogAdapter.Slf4jLog<LocationAwareLogger>
/*     */   implements Serializable
/*     */ {
/* 405 */   private static final String FQCN = Slf4jLocationAwareLog.class.getName();
/*     */   
/*     */   public Slf4jLocationAwareLog(LocationAwareLogger logger) {
/* 408 */     super(logger);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/* 413 */     error(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable exception) {
/* 418 */     error(message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/* 423 */     if (message instanceof String || this.logger.isErrorEnabled()) {
/* 424 */       this.logger.log(null, FQCN, 40, String.valueOf(message), null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable exception) {
/* 430 */     if (message instanceof String || this.logger.isErrorEnabled()) {
/* 431 */       this.logger.log(null, FQCN, 40, String.valueOf(message), null, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 437 */     if (message instanceof String || this.logger.isWarnEnabled()) {
/* 438 */       this.logger.log(null, FQCN, 30, String.valueOf(message), null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable exception) {
/* 444 */     if (message instanceof String || this.logger.isWarnEnabled()) {
/* 445 */       this.logger.log(null, FQCN, 30, String.valueOf(message), null, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 451 */     if (message instanceof String || this.logger.isInfoEnabled()) {
/* 452 */       this.logger.log(null, FQCN, 20, String.valueOf(message), null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable exception) {
/* 458 */     if (message instanceof String || this.logger.isInfoEnabled()) {
/* 459 */       this.logger.log(null, FQCN, 20, String.valueOf(message), null, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message) {
/* 465 */     if (message instanceof String || this.logger.isDebugEnabled()) {
/* 466 */       this.logger.log(null, FQCN, 10, String.valueOf(message), null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable exception) {
/* 472 */     if (message instanceof String || this.logger.isDebugEnabled()) {
/* 473 */       this.logger.log(null, FQCN, 10, String.valueOf(message), null, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message) {
/* 479 */     if (message instanceof String || this.logger.isTraceEnabled()) {
/* 480 */       this.logger.log(null, FQCN, 0, String.valueOf(message), null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(Object message, Throwable exception) {
/* 486 */     if (message instanceof String || this.logger.isTraceEnabled()) {
/* 487 */       this.logger.log(null, FQCN, 0, String.valueOf(message), null, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/* 493 */     return LogAdapter.Slf4jAdapter.createLocationAwareLog(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\LogAdapter$Slf4jLocationAwareLog.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */