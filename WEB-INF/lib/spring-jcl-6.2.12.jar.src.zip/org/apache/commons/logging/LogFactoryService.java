/*    */ package org.apache.commons.logging;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class LogFactoryService
/*    */   extends LogFactory
/*    */ {
/* 36 */   private final Map<String, Object> attributes = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   public LogFactoryService() {
/* 40 */     System.out.println("Standard Commons Logging discovery in action with spring-jcl: please remove commons-logging.jar from classpath in order to avoid potential conflicts");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Log getInstance(Class<?> clazz) {
/* 47 */     return getInstance(clazz.getName());
/*    */   }
/*    */ 
/*    */   
/*    */   public Log getInstance(String name) {
/* 52 */     return LogAdapter.createLog(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAttribute(String name, Object value) {
/* 60 */     if (value != null) {
/* 61 */       this.attributes.put(name, value);
/*    */     } else {
/*    */       
/* 64 */       this.attributes.remove(name);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeAttribute(String name) {
/* 70 */     this.attributes.remove(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getAttribute(String name) {
/* 75 */     return this.attributes.get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getAttributeNames() {
/* 80 */     return (String[])this.attributes.keySet().toArray((Object[])new String[0]);
/*    */   }
/*    */   
/*    */   public void release() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-jcl-6.2.12.jar!\org\apache\commons\logging\LogFactoryService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */