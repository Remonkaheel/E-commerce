/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.AbstractList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodInfoGenerator
/*    */   extends AbstractList<MethodInfo>
/*    */ {
/*    */   private final MethodInternal[] methods;
/*    */   private final ClassInfo clazz;
/*    */   private final byte[] positions;
/*    */   
/*    */   public MethodInfoGenerator(ClassInfo clazz, MethodInternal[] methods, byte[] positions) {
/* 35 */     this.clazz = clazz;
/* 36 */     this.methods = methods;
/* 37 */     this.positions = positions;
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodInfo get(int i) {
/* 42 */     MethodInternal method = (this.positions.length > 0) ? this.methods[this.positions[i] & 0xFF] : this.methods[i];
/* 43 */     return new MethodInfo(this.clazz, method);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 48 */     return this.methods.length;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MethodInfoGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */