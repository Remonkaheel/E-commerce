/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodParameterTypeTarget
/*    */   extends PositionBasedTypeTarget
/*    */ {
/*    */   MethodParameterTypeTarget(MethodInfo enclosingTarget, int position) {
/* 42 */     super(enclosingTarget, position);
/*    */   }
/*    */   
/*    */   MethodParameterTypeTarget(AnnotationTarget enclosingTarget, Type target, int position) {
/* 46 */     super(enclosingTarget, target, position);
/*    */   }
/*    */ 
/*    */   
/*    */   public final TypeTarget.Usage usage() {
/* 51 */     return TypeTarget.Usage.METHOD_PARAMETER;
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodInfo enclosingTarget() {
/* 56 */     return (MethodInfo)super.enclosingTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodParameterTypeTarget asMethodParameterType() {
/* 61 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MethodParameterTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */