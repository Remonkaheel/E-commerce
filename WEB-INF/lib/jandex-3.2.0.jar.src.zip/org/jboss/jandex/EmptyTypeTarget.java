/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyTypeTarget
/*    */   extends TypeTarget
/*    */ {
/*    */   private boolean receiver;
/*    */   
/*    */   EmptyTypeTarget(AnnotationTarget enclosingTarget, boolean receiver) {
/* 42 */     super(enclosingTarget);
/* 43 */     this.receiver = receiver;
/*    */   }
/*    */   
/*    */   EmptyTypeTarget(AnnotationTarget enclosingTarget, Type target, boolean receiver) {
/* 47 */     super(enclosingTarget, target);
/* 48 */     this.receiver = receiver;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isReceiver() {
/* 59 */     return this.receiver;
/*    */   }
/*    */ 
/*    */   
/*    */   public final TypeTarget.Usage usage() {
/* 64 */     return TypeTarget.Usage.EMPTY;
/*    */   }
/*    */ 
/*    */   
/*    */   public EmptyTypeTarget asEmpty() {
/* 69 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\EmptyTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */