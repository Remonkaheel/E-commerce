/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MethodParamList
/*     */ {
/*     */   private final MethodInfo method;
/*  14 */   private final List<ParamData> proper = new ArrayList<>();
/*     */   
/*  16 */   private final List<ParamData> debug = new ArrayList<>();
/*     */   
/*     */   private ParamData[] possiblyNamed;
/*     */   
/*     */   private boolean firstIsEnclosingInstance;
/*     */   
/*     */   MethodParamList(MethodInfo method) {
/*  23 */     this.method = method;
/*     */   }
/*     */   
/*     */   void appendProper(byte[] parameterName, boolean synthetic) {
/*  27 */     this.proper.add(new ParamData(parameterName, synthetic));
/*     */   }
/*     */   
/*     */   void appendDebug(byte[] parameterName, boolean synthetic) {
/*  31 */     this.debug.add(new ParamData(parameterName, synthetic));
/*     */   }
/*     */   
/*     */   void finish() {
/*  35 */     List<ParamData> proper = this.proper;
/*  36 */     List<ParamData> debug = this.debug;
/*     */     
/*  38 */     if (proper.isEmpty() && debug.isEmpty()) {
/*  39 */       this.possiblyNamed = ParamData.EMPTY_ARRAY;
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  47 */     if (proper.isEmpty()) {
/*  48 */       List<ParamData> list = debug;
/*  49 */       if (((ParamData)debug.get(0)).syntheticOrMandated) {
/*  50 */         list = debug.subList(1, debug.size());
/*  51 */         this.firstIsEnclosingInstance = true;
/*     */       } 
/*  53 */       this.possiblyNamed = list.<ParamData>toArray(ParamData.EMPTY_ARRAY);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  59 */     if (this.method.isConstructor() && 
/*  60 */       !this.method.declaringClass().isRecord())
/*     */     {
/*  62 */       if (this.method.declaringClass().isEnum()) {
/*     */         
/*  64 */         proper = proper.subList(2, this.method.parametersCount());
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/*  72 */         if (((ParamData)proper.get(0)).syntheticOrMandated && !debug.isEmpty() && ((ParamData)debug.get(0)).syntheticOrMandated) {
/*  73 */           debug.remove(0);
/*  74 */           this.firstIsEnclosingInstance = true;
/*     */         } 
/*  76 */         for (Iterator<ParamData> it = proper.iterator(); it.hasNext(); ) {
/*  77 */           ParamData param = it.next();
/*  78 */           if (param.syntheticOrMandated) {
/*  79 */             it.remove();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  86 */     if (debug.isEmpty()) {
/*  87 */       this.possiblyNamed = proper.<ParamData>toArray(ParamData.EMPTY_ARRAY);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  92 */     int size = Math.min(proper.size(), debug.size());
/*  93 */     ParamData[] result = new ParamData[size];
/*  94 */     for (int i = 0; i < size; i++) {
/*  95 */       ParamData properParameter = proper.get(i);
/*  96 */       ParamData debugParameter = debug.get(i);
/*     */       
/*  98 */       ParamData resultParameter = new ParamData((properParameter.name != null) ? properParameter.name : debugParameter.name, (properParameter.syntheticOrMandated || debugParameter.syntheticOrMandated));
/*     */       
/* 100 */       result[i] = resultParameter;
/*     */     } 
/* 102 */     this.possiblyNamed = result;
/*     */   }
/*     */   
/*     */   boolean firstIsEnclosingInstance() {
/* 106 */     return this.firstIsEnclosingInstance;
/*     */   }
/*     */   
/*     */   byte[][] getNames() {
/* 110 */     ParamData[] params = this.possiblyNamed;
/*     */ 
/*     */     
/* 113 */     int count = 0;
/* 114 */     boolean seenNamed = false;
/* 115 */     for (int i = params.length - 1; i >= 0; i--) {
/* 116 */       if (seenNamed || (params[i]).name != null) {
/*     */ 
/*     */ 
/*     */         
/* 120 */         seenNamed = true;
/* 121 */         count++;
/*     */       } 
/* 123 */     }  if (count == 0) {
/* 124 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 128 */     byte[][] result = new byte[count][];
/* 129 */     int pos = 0;
/* 130 */     for (int j = 0; j < params.length; j++) {
/* 131 */       result[pos] = (params[j]).name;
/* 132 */       pos++;
/* 133 */       if (pos >= result.length) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     for (byte[] name : result) {
/* 142 */       if (name == null)
/*     */       {
/*     */         
/* 145 */         return null;
/*     */       }
/*     */     } 
/* 148 */     return result;
/*     */   }
/*     */   
/*     */   static final class ParamData {
/* 152 */     static final ParamData[] EMPTY_ARRAY = new ParamData[0];
/*     */     
/*     */     final byte[] name;
/*     */     final boolean syntheticOrMandated;
/*     */     
/*     */     ParamData(byte[] name, boolean syntheticOrMandated) {
/* 158 */       this.name = name;
/* 159 */       this.syntheticOrMandated = syntheticOrMandated;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 165 */       return ((this.name == null) ? "<null>" : Utils.fromUTF8(this.name)) + (this.syntheticOrMandated ? "<synth>" : "");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MethodParamList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */