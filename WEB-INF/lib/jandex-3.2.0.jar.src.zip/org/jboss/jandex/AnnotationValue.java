/*      */ package org.jboss.jandex;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AnnotationValue
/*      */ {
/*   76 */   static final AnnotationValue[] EMPTY_ARRAY = new AnnotationValue[0];
/*      */   
/*      */   private final String name;
/*      */ 
/*      */   
/*      */   public enum Kind
/*      */   {
/*   83 */     BYTE,
/*      */     
/*   85 */     SHORT,
/*      */     
/*   87 */     INTEGER,
/*      */     
/*   89 */     CHARACTER,
/*      */     
/*   91 */     FLOAT,
/*      */     
/*   93 */     DOUBLE,
/*      */     
/*   95 */     LONG,
/*      */     
/*   97 */     BOOLEAN,
/*      */     
/*   99 */     CLASS,
/*      */     
/*  101 */     STRING,
/*      */     
/*  103 */     ENUM,
/*      */     
/*  105 */     ARRAY,
/*      */     
/*  107 */     NESTED,
/*      */     
/*  109 */     UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   AnnotationValue(String name) {
/*  115 */     this.name = name;
/*      */   }
/*      */   
/*      */   public static AnnotationValue createByteValue(String name, byte b) {
/*  119 */     return new ByteValue(name, b);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createShortValue(String name, short s) {
/*  123 */     return new ShortValue(name, s);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createIntegerValue(String name, int i) {
/*  127 */     return new IntegerValue(name, i);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createCharacterValue(String name, char c) {
/*  131 */     return new CharacterValue(name, c);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createFloatValue(String name, float f) {
/*  135 */     return new FloatValue(name, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static AnnotationValue createDouleValue(String name, double d) {
/*  143 */     return createDoubleValue(name, d);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createDoubleValue(String name, double d) {
/*  147 */     return new DoubleValue(name, d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static AnnotationValue createLongalue(String name, long l) {
/*  155 */     return createLongValue(name, l);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createLongValue(String name, long l) {
/*  159 */     return new LongValue(name, l);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createBooleanValue(String name, boolean bool) {
/*  163 */     return new BooleanValue(name, bool);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createStringValue(String name, String string) {
/*  167 */     return new StringValue(name, string);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createClassValue(String name, Type type) {
/*  171 */     return new ClassValue(name, type);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createEnumValue(String name, DotName typeName, String value) {
/*  175 */     return new EnumValue(name, typeName, value);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createArrayValue(String name, AnnotationValue[] values) {
/*  179 */     return new ArrayValue(name, values);
/*      */   }
/*      */   
/*      */   public static AnnotationValue createArrayValue(String name, List<AnnotationValue> values) {
/*  183 */     return createArrayValue(name, values.<AnnotationValue>toArray(EMPTY_ARRAY));
/*      */   }
/*      */   
/*      */   public static AnnotationValue createNestedAnnotationValue(String name, AnnotationInstance instance) {
/*  187 */     return new NestedAnnotation(name, instance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String name() {
/*  198 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Kind componentKind() {
/*  233 */     throw new IllegalArgumentException("Not an array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int asInt() {
/*  244 */     throw new IllegalArgumentException("Not a number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long asLong() {
/*  255 */     throw new IllegalArgumentException("Not a number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short asShort() {
/*  266 */     throw new IllegalArgumentException("Not a number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte asByte() {
/*  277 */     throw new IllegalArgumentException("Not a number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float asFloat() {
/*  288 */     throw new IllegalArgumentException("Not a number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double asDouble() {
/*  299 */     throw new IllegalArgumentException("Not a number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char asChar() {
/*  309 */     throw new IllegalArgumentException("Not a character");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean asBoolean() {
/*  319 */     throw new IllegalArgumentException("Not a boolean");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String asString() {
/*  331 */     return value().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String asEnum() {
/*  343 */     throw new IllegalArgumentException("Not an enum");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DotName asEnumType() {
/*  355 */     throw new IllegalArgumentException("Not an enum");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type asClass() {
/*  369 */     throw new IllegalArgumentException("Not a class");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstance asNested() {
/*  380 */     throw new IllegalArgumentException("Not a nested annotation");
/*      */   }
/*      */   
/*      */   AnnotationValue[] asArray() {
/*  384 */     throw new IllegalArgumentException("Not an array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<AnnotationValue> asArrayList() {
/*  394 */     throw new IllegalArgumentException("Not an array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] asIntArray() {
/*  405 */     throw new IllegalArgumentException("Not a numerical array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] asLongArray() {
/*  416 */     throw new IllegalArgumentException("Not a numerical array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short[] asShortArray() {
/*  426 */     throw new IllegalArgumentException("Not a numerical array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] asByteArray() {
/*  436 */     throw new IllegalArgumentException("Not a numerical array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] asFloatArray() {
/*  446 */     throw new IllegalArgumentException("Not a numerical array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] asDoubleArray() {
/*  457 */     throw new IllegalArgumentException("Not a numerical array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] asCharArray() {
/*  467 */     throw new IllegalArgumentException("Not a character array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] asBooleanArray() {
/*  477 */     throw new IllegalArgumentException("Not a boolean array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] asStringArray() {
/*  489 */     throw new IllegalArgumentException("Not a string array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] asEnumArray() {
/*  501 */     throw new IllegalArgumentException("Not an enum array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DotName[] asEnumTypeArray() {
/*  515 */     throw new IllegalArgumentException("Not an enum array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type[] asClassArray() {
/*  526 */     throw new IllegalArgumentException("Not a class array");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstance[] asNestedArray() {
/*  537 */     throw new IllegalArgumentException("Not a nested annotation array");
/*      */   }
/*      */   
/*      */   public String toString() {
/*  541 */     return toString(true);
/*      */   }
/*      */   
/*      */   String toString(boolean includeName) {
/*  545 */     StringBuilder builder = new StringBuilder();
/*  546 */     if (includeName && this.name.length() > 0)
/*  547 */       builder.append(this.name).append(" = "); 
/*  548 */     return builder.append(value()).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  560 */     if (this == o) {
/*  561 */       return true;
/*      */     }
/*  563 */     if (o == null || getClass() != o.getClass()) {
/*  564 */       return false;
/*      */     }
/*      */     
/*  567 */     AnnotationValue that = (AnnotationValue)o;
/*  568 */     return this.name.equals(that.name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  579 */     return this.name.hashCode();
/*      */   }
/*      */   public abstract Object value();
/*      */   
/*      */   public abstract Kind kind();
/*      */   
/*      */   static final class StringValue extends AnnotationValue { StringValue(String name, String value) {
/*  586 */       super(name);
/*  587 */       this.value = value;
/*      */     }
/*      */     private final String value;
/*      */     public String value() {
/*  591 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  596 */       return AnnotationValue.Kind.STRING;
/*      */     }
/*      */     
/*      */     String toString(boolean includeName) {
/*  600 */       StringBuilder builder = new StringBuilder();
/*  601 */       if (includeName && this.name.length() > 0) {
/*  602 */         builder.append(this.name).append(" = ");
/*      */       }
/*  604 */       return builder.append('"').append(this.value).append('"').toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  609 */       if (this == o) {
/*  610 */         return true;
/*      */       }
/*  612 */       if (o == null || getClass() != o.getClass()) {
/*  613 */         return false;
/*      */       }
/*      */       
/*  616 */       StringValue that = (StringValue)o;
/*  617 */       return (super.equals(o) && this.value.equals(that.value));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  622 */       int result = super.hashCode();
/*  623 */       result = 31 * result + this.value.hashCode();
/*  624 */       return result;
/*      */     } }
/*      */ 
/*      */   
/*      */   static final class ByteValue extends AnnotationValue {
/*      */     private final byte value;
/*      */     
/*      */     ByteValue(String name, byte value) {
/*  632 */       super(name);
/*  633 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Byte value() {
/*  637 */       return Byte.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  642 */       return AnnotationValue.Kind.BYTE;
/*      */     }
/*      */     
/*      */     public int asInt() {
/*  646 */       return this.value;
/*      */     }
/*      */     
/*      */     public long asLong() {
/*  650 */       return this.value;
/*      */     }
/*      */     
/*      */     public short asShort() {
/*  654 */       return (short)this.value;
/*      */     }
/*      */     
/*      */     public byte asByte() {
/*  658 */       return this.value;
/*      */     }
/*      */     
/*      */     public float asFloat() {
/*  662 */       return this.value;
/*      */     }
/*      */     
/*      */     public double asDouble() {
/*  666 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  671 */       if (this == o) {
/*  672 */         return true;
/*      */       }
/*  674 */       if (o == null || getClass() != o.getClass()) {
/*  675 */         return false;
/*      */       }
/*      */       
/*  678 */       ByteValue byteValue = (ByteValue)o;
/*  679 */       return (this.value == byteValue.value && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  684 */       int result = super.hashCode();
/*  685 */       result = 31 * result + this.value;
/*  686 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class CharacterValue extends AnnotationValue {
/*      */     private final char value;
/*      */     
/*      */     CharacterValue(String name, char value) {
/*  694 */       super(name);
/*  695 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Character value() {
/*  699 */       return Character.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  704 */       return AnnotationValue.Kind.CHARACTER;
/*      */     }
/*      */     
/*      */     public char asChar() {
/*  708 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  713 */       if (this == o) {
/*  714 */         return true;
/*      */       }
/*  716 */       if (o == null || getClass() != o.getClass()) {
/*  717 */         return false;
/*      */       }
/*      */       
/*  720 */       CharacterValue that = (CharacterValue)o;
/*  721 */       return (this.value == that.value && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  726 */       int result = super.hashCode();
/*  727 */       result = 31 * result + this.value;
/*  728 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class DoubleValue extends AnnotationValue {
/*      */     private final double value;
/*      */     
/*      */     public DoubleValue(String name, double value) {
/*  736 */       super(name);
/*  737 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Double value() {
/*  741 */       return Double.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  746 */       return AnnotationValue.Kind.DOUBLE;
/*      */     }
/*      */     
/*      */     public int asInt() {
/*  750 */       return (int)this.value;
/*      */     }
/*      */     
/*      */     public long asLong() {
/*  754 */       return (long)this.value;
/*      */     }
/*      */     
/*      */     public short asShort() {
/*  758 */       return (short)(int)this.value;
/*      */     }
/*      */     
/*      */     public byte asByte() {
/*  762 */       return (byte)(int)this.value;
/*      */     }
/*      */     
/*      */     public float asFloat() {
/*  766 */       return (float)this.value;
/*      */     }
/*      */     
/*      */     public double asDouble() {
/*  770 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  775 */       if (this == o) {
/*  776 */         return true;
/*      */       }
/*  778 */       if (o == null || getClass() != o.getClass()) {
/*  779 */         return false;
/*      */       }
/*      */       
/*  782 */       DoubleValue that = (DoubleValue)o;
/*      */       
/*  784 */       return (Double.compare(that.value, this.value) == 0 && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  789 */       int result = super.hashCode();
/*      */       
/*  791 */       long temp = Double.doubleToLongBits(this.value);
/*  792 */       result = 31 * result + (int)(temp ^ temp >>> 32L);
/*  793 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class FloatValue extends AnnotationValue {
/*      */     private final float value;
/*      */     
/*      */     FloatValue(String name, float value) {
/*  801 */       super(name);
/*  802 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Float value() {
/*  806 */       return Float.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  811 */       return AnnotationValue.Kind.FLOAT;
/*      */     }
/*      */     
/*      */     public int asInt() {
/*  815 */       return (int)this.value;
/*      */     }
/*      */     
/*      */     public long asLong() {
/*  819 */       return (long)this.value;
/*      */     }
/*      */     
/*      */     public short asShort() {
/*  823 */       return (short)(int)this.value;
/*      */     }
/*      */     
/*      */     public byte asByte() {
/*  827 */       return (byte)(int)this.value;
/*      */     }
/*      */     
/*      */     public float asFloat() {
/*  831 */       return this.value;
/*      */     }
/*      */     
/*      */     public double asDouble() {
/*  835 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  840 */       if (this == o) {
/*  841 */         return true;
/*      */       }
/*  843 */       if (o == null || getClass() != o.getClass()) {
/*  844 */         return false;
/*      */       }
/*      */       
/*  847 */       FloatValue that = (FloatValue)o;
/*      */       
/*  849 */       return (Float.compare(that.value, this.value) == 0 && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  854 */       int result = super.hashCode();
/*  855 */       result = 31 * result + ((this.value != 0.0F) ? Float.floatToIntBits(this.value) : 0);
/*  856 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ShortValue extends AnnotationValue {
/*      */     private final short value;
/*      */     
/*      */     ShortValue(String name, short value) {
/*  864 */       super(name);
/*  865 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Short value() {
/*  869 */       return Short.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  874 */       return AnnotationValue.Kind.SHORT;
/*      */     }
/*      */     
/*      */     public int asInt() {
/*  878 */       return this.value;
/*      */     }
/*      */     
/*      */     public long asLong() {
/*  882 */       return this.value;
/*      */     }
/*      */     
/*      */     public short asShort() {
/*  886 */       return this.value;
/*      */     }
/*      */     
/*      */     public byte asByte() {
/*  890 */       return (byte)this.value;
/*      */     }
/*      */     
/*      */     public float asFloat() {
/*  894 */       return this.value;
/*      */     }
/*      */     
/*      */     public double asDouble() {
/*  898 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  903 */       if (this == o) {
/*  904 */         return true;
/*      */       }
/*  906 */       if (o == null || getClass() != o.getClass()) {
/*  907 */         return false;
/*      */       }
/*      */       
/*  910 */       ShortValue that = (ShortValue)o;
/*      */       
/*  912 */       return (this.value == that.value && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  917 */       int result = super.hashCode();
/*  918 */       result = 31 * result + this.value;
/*  919 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class IntegerValue extends AnnotationValue {
/*      */     private final int value;
/*      */     
/*      */     IntegerValue(String name, int value) {
/*  927 */       super(name);
/*  928 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Integer value() {
/*  932 */       return Integer.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/*  937 */       return AnnotationValue.Kind.INTEGER;
/*      */     }
/*      */     
/*      */     public int asInt() {
/*  941 */       return this.value;
/*      */     }
/*      */     
/*      */     public long asLong() {
/*  945 */       return this.value;
/*      */     }
/*      */     
/*      */     public short asShort() {
/*  949 */       return (short)this.value;
/*      */     }
/*      */     
/*      */     public byte asByte() {
/*  953 */       return (byte)this.value;
/*      */     }
/*      */     
/*      */     public float asFloat() {
/*  957 */       return this.value;
/*      */     }
/*      */     
/*      */     public double asDouble() {
/*  961 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  966 */       if (this == o) {
/*  967 */         return true;
/*      */       }
/*  969 */       if (o == null || getClass() != o.getClass()) {
/*  970 */         return false;
/*      */       }
/*      */       
/*  973 */       IntegerValue that = (IntegerValue)o;
/*      */       
/*  975 */       return (this.value == that.value && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  980 */       int result = super.hashCode();
/*  981 */       result = 31 * result + this.value;
/*  982 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class LongValue extends AnnotationValue {
/*      */     private final long value;
/*      */     
/*      */     LongValue(String name, long value) {
/*  990 */       super(name);
/*  991 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Long value() {
/*  995 */       return Long.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/* 1000 */       return AnnotationValue.Kind.LONG;
/*      */     }
/*      */     
/*      */     public int asInt() {
/* 1004 */       return (int)this.value;
/*      */     }
/*      */     
/*      */     public long asLong() {
/* 1008 */       return this.value;
/*      */     }
/*      */     
/*      */     public short asShort() {
/* 1012 */       return (short)(int)this.value;
/*      */     }
/*      */     
/*      */     public byte asByte() {
/* 1016 */       return (byte)(int)this.value;
/*      */     }
/*      */     
/*      */     public float asFloat() {
/* 1020 */       return (float)this.value;
/*      */     }
/*      */     
/*      */     public double asDouble() {
/* 1024 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1029 */       if (this == o) {
/* 1030 */         return true;
/*      */       }
/* 1032 */       if (o == null || getClass() != o.getClass()) {
/* 1033 */         return false;
/*      */       }
/*      */       
/* 1036 */       LongValue longValue = (LongValue)o;
/*      */       
/* 1038 */       return (this.value == longValue.value && super.equals(o));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1043 */       int result = super.hashCode();
/* 1044 */       result = 31 * result + (int)(this.value ^ this.value >>> 32L);
/* 1045 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BooleanValue extends AnnotationValue {
/*      */     private final boolean value;
/*      */     
/*      */     BooleanValue(String name, boolean value) {
/* 1053 */       super(name);
/* 1054 */       this.value = value;
/*      */     }
/*      */     
/*      */     public Boolean value() {
/* 1058 */       return Boolean.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/* 1063 */       return AnnotationValue.Kind.BOOLEAN;
/*      */     }
/*      */     
/*      */     public boolean asBoolean() {
/* 1067 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1072 */       int result = super.hashCode();
/* 1073 */       result = 31 * result + (this.value ? 1231 : 1237);
/* 1074 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1079 */       if (this == obj) {
/* 1080 */         return true;
/*      */       }
/* 1082 */       if (!super.equals(obj)) {
/* 1083 */         return false;
/*      */       }
/* 1085 */       if (getClass() != obj.getClass()) {
/* 1086 */         return false;
/*      */       }
/* 1088 */       BooleanValue other = (BooleanValue)obj;
/* 1089 */       return (this.value == other.value);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EnumValue
/*      */     extends AnnotationValue {
/*      */     private final String value;
/*      */     private final DotName typeName;
/*      */     
/*      */     EnumValue(String name, DotName typeName, String value) {
/* 1099 */       super(name);
/* 1100 */       this.typeName = typeName;
/* 1101 */       this.value = value;
/*      */     }
/*      */     
/*      */     public String value() {
/* 1105 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/* 1110 */       return AnnotationValue.Kind.ENUM;
/*      */     }
/*      */     
/*      */     public String asEnum() {
/* 1114 */       return this.value;
/*      */     }
/*      */     
/*      */     public DotName asEnumType() {
/* 1118 */       return this.typeName;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1123 */       if (this == o) {
/* 1124 */         return true;
/*      */       }
/*      */       
/* 1127 */       if (o == null || getClass() != o.getClass()) {
/* 1128 */         return false;
/*      */       }
/*      */       
/* 1131 */       EnumValue enumValue = (EnumValue)o;
/*      */       
/* 1133 */       return (super.equals(o) && this.typeName.equals(enumValue.typeName) && this.value.equals(enumValue.value));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1138 */       int result = super.hashCode();
/* 1139 */       result = 31 * result + this.value.hashCode();
/* 1140 */       result = 31 * result + this.typeName.hashCode();
/* 1141 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ClassValue extends AnnotationValue {
/*      */     private final Type type;
/*      */     
/*      */     ClassValue(String name, Type type) {
/* 1149 */       super(name);
/* 1150 */       this.type = type;
/*      */     }
/*      */     
/*      */     public Type value() {
/* 1154 */       return this.type;
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/* 1159 */       return AnnotationValue.Kind.CLASS;
/*      */     }
/*      */     
/*      */     public Type asClass() {
/* 1163 */       return this.type;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1168 */       if (this == o) {
/* 1169 */         return true;
/*      */       }
/* 1171 */       if (o == null || getClass() != o.getClass()) {
/* 1172 */         return false;
/*      */       }
/*      */       
/* 1175 */       ClassValue that = (ClassValue)o;
/*      */       
/* 1177 */       return (super.equals(o) && this.type.equals(that.type));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1182 */       int result = super.hashCode();
/* 1183 */       result = 31 * result + this.type.hashCode();
/* 1184 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class NestedAnnotation extends AnnotationValue {
/*      */     private final AnnotationInstance value;
/*      */     
/*      */     NestedAnnotation(String name, AnnotationInstance value) {
/* 1192 */       super(name);
/* 1193 */       this.value = value;
/*      */     }
/*      */     
/*      */     public AnnotationInstance value() {
/* 1197 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/* 1202 */       return AnnotationValue.Kind.NESTED;
/*      */     }
/*      */     
/*      */     public AnnotationInstance asNested() {
/* 1206 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1211 */       if (this == o) {
/* 1212 */         return true;
/*      */       }
/* 1214 */       if (o == null || getClass() != o.getClass()) {
/* 1215 */         return false;
/*      */       }
/*      */       
/* 1218 */       NestedAnnotation that = (NestedAnnotation)o;
/*      */       
/* 1220 */       return (super.equals(o) && this.value.equals(that.value));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1225 */       int result = super.hashCode();
/* 1226 */       result = 31 * result + this.value.hashCode();
/* 1227 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ArrayValue extends AnnotationValue {
/*      */     private final AnnotationValue[] value;
/*      */     
/*      */     ArrayValue(String name, AnnotationValue[] value) {
/* 1235 */       super(name);
/* 1236 */       this.value = (value.length > 0) ? value : EMPTY_ARRAY;
/*      */     }
/*      */     
/*      */     public AnnotationValue[] value() {
/* 1240 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind kind() {
/* 1245 */       return AnnotationValue.Kind.ARRAY;
/*      */     }
/*      */ 
/*      */     
/*      */     public AnnotationValue.Kind componentKind() {
/* 1250 */       return (this.value.length > 0) ? this.value[0].kind() : AnnotationValue.Kind.UNKNOWN;
/*      */     }
/*      */     
/*      */     AnnotationValue[] asArray() {
/* 1254 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<AnnotationValue> asArrayList() {
/* 1259 */       return new ArrayList<>(Arrays.asList(this.value));
/*      */     }
/*      */     
/*      */     String toString(boolean includeName) {
/* 1263 */       StringBuilder builder = new StringBuilder();
/* 1264 */       if (includeName && this.name.length() > 0)
/* 1265 */         builder.append(this.name).append(" = "); 
/* 1266 */       builder.append('[');
/* 1267 */       for (int i = 0; i < this.value.length; i++) {
/* 1268 */         builder.append(this.value[i]);
/* 1269 */         if (i < this.value.length - 1)
/* 1270 */           builder.append(','); 
/*      */       } 
/* 1272 */       return builder.append(']').toString();
/*      */     }
/*      */     
/*      */     public int[] asIntArray() {
/* 1276 */       int length = this.value.length;
/* 1277 */       int[] array = new int[length];
/*      */       
/* 1279 */       for (int i = 0; i < length; i++) {
/* 1280 */         array[i] = this.value[i].asInt();
/*      */       }
/*      */       
/* 1283 */       return array;
/*      */     }
/*      */     
/*      */     public long[] asLongArray() {
/* 1287 */       int length = this.value.length;
/* 1288 */       long[] array = new long[length];
/*      */       
/* 1290 */       for (int i = 0; i < length; i++) {
/* 1291 */         array[i] = this.value[i].asLong();
/*      */       }
/*      */       
/* 1294 */       return array;
/*      */     }
/*      */     
/*      */     public short[] asShortArray() {
/* 1298 */       int length = this.value.length;
/* 1299 */       short[] array = new short[length];
/*      */       
/* 1301 */       for (int i = 0; i < length; i++) {
/* 1302 */         array[i] = this.value[i].asShort();
/*      */       }
/*      */       
/* 1305 */       return array;
/*      */     }
/*      */     
/*      */     public byte[] asByteArray() {
/* 1309 */       int length = this.value.length;
/* 1310 */       byte[] array = new byte[length];
/*      */       
/* 1312 */       for (int i = 0; i < length; i++) {
/* 1313 */         array[i] = this.value[i].asByte();
/*      */       }
/*      */       
/* 1316 */       return array;
/*      */     }
/*      */     
/*      */     public float[] asFloatArray() {
/* 1320 */       int length = this.value.length;
/* 1321 */       float[] array = new float[length];
/*      */       
/* 1323 */       for (int i = 0; i < length; i++) {
/* 1324 */         array[i] = this.value[i].asFloat();
/*      */       }
/*      */       
/* 1327 */       return array;
/*      */     }
/*      */     
/*      */     public double[] asDoubleArray() {
/* 1331 */       int length = this.value.length;
/* 1332 */       double[] array = new double[length];
/*      */       
/* 1334 */       for (int i = 0; i < length; i++) {
/* 1335 */         array[i] = this.value[i].asDouble();
/*      */       }
/* 1337 */       return array;
/*      */     }
/*      */     
/*      */     public char[] asCharArray() {
/* 1341 */       int length = this.value.length;
/* 1342 */       char[] array = new char[length];
/*      */       
/* 1344 */       for (int i = 0; i < length; i++) {
/* 1345 */         array[i] = this.value[i].asChar();
/*      */       }
/*      */       
/* 1348 */       return array;
/*      */     }
/*      */     
/*      */     public boolean[] asBooleanArray() {
/* 1352 */       int length = this.value.length;
/* 1353 */       boolean[] array = new boolean[length];
/*      */       
/* 1355 */       for (int i = 0; i < length; i++) {
/* 1356 */         array[i] = this.value[i].asBoolean();
/*      */       }
/*      */       
/* 1359 */       return array;
/*      */     }
/*      */     
/*      */     public String[] asStringArray() {
/* 1363 */       int length = this.value.length;
/* 1364 */       String[] array = new String[length];
/*      */       
/* 1366 */       for (int i = 0; i < length; i++) {
/* 1367 */         array[i] = this.value[i].asString();
/*      */       }
/*      */       
/* 1370 */       return array;
/*      */     }
/*      */     
/*      */     public String[] asEnumArray() {
/* 1374 */       int length = this.value.length;
/* 1375 */       String[] array = new String[length];
/*      */       
/* 1377 */       for (int i = 0; i < length; i++) {
/* 1378 */         array[i] = this.value[i].asEnum();
/*      */       }
/*      */       
/* 1381 */       return array;
/*      */     }
/*      */     
/*      */     public Type[] asClassArray() {
/* 1385 */       int length = this.value.length;
/* 1386 */       Type[] array = new Type[length];
/*      */       
/* 1388 */       for (int i = 0; i < length; i++) {
/* 1389 */         array[i] = this.value[i].asClass();
/*      */       }
/*      */       
/* 1392 */       return array;
/*      */     }
/*      */     
/*      */     public AnnotationInstance[] asNestedArray() {
/* 1396 */       int length = this.value.length;
/* 1397 */       AnnotationInstance[] array = new AnnotationInstance[length];
/*      */       
/* 1399 */       for (int i = 0; i < length; i++) {
/* 1400 */         array[i] = this.value[i].asNested();
/*      */       }
/*      */       
/* 1403 */       return array;
/*      */     }
/*      */     
/*      */     public DotName[] asEnumTypeArray() {
/* 1407 */       int length = this.value.length;
/* 1408 */       DotName[] array = new DotName[length];
/*      */       
/* 1410 */       for (int i = 0; i < length; i++) {
/* 1411 */         array[i] = this.value[i].asEnumType();
/*      */       }
/*      */       
/* 1414 */       return array;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1419 */       if (this == o) {
/* 1420 */         return true;
/*      */       }
/* 1422 */       if (o == null || getClass() != o.getClass()) {
/* 1423 */         return false;
/*      */       }
/*      */       
/* 1426 */       ArrayValue that = (ArrayValue)o;
/* 1427 */       return (super.equals(o) && Arrays.equals((Object[])this.value, (Object[])that.value));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1432 */       int result = super.hashCode();
/* 1433 */       result = 31 * result + Arrays.hashCode((Object[])this.value);
/* 1434 */       return result;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */