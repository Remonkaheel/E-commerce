/*      */ package org.jboss.jandex;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Deque;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Indexer
/*      */ {
/*      */   private static final int CONSTANT_CLASS = 7;
/*      */   private static final int CONSTANT_FIELDREF = 9;
/*      */   private static final int CONSTANT_METHODREF = 10;
/*      */   private static final int CONSTANT_INTERFACEMETHODREF = 11;
/*      */   private static final int CONSTANT_STRING = 8;
/*      */   private static final int CONSTANT_INTEGER = 3;
/*      */   private static final int CONSTANT_FLOAT = 4;
/*      */   private static final int CONSTANT_LONG = 5;
/*      */   private static final int CONSTANT_DOUBLE = 6;
/*      */   private static final int CONSTANT_NAMEANDTYPE = 12;
/*      */   private static final int CONSTANT_UTF8 = 1;
/*      */   private static final int CONSTANT_INVOKEDYNAMIC = 18;
/*      */   private static final int CONSTANT_METHODHANDLE = 15;
/*      */   private static final int CONSTANT_METHODTYPE = 16;
/*      */   private static final int CONSTANT_MODULE = 19;
/*      */   private static final int CONSTANT_PACKAGE = 20;
/*      */   private static final int CONSTANT_DYNAMIC = 17;
/*   94 */   private static final byte[] RUNTIME_ANNOTATIONS = new byte[] { 82, 117, 110, 116, 105, 109, 101, 86, 105, 115, 105, 98, 108, 101, 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  101 */   private static final byte[] RUNTIME_PARAM_ANNOTATIONS = new byte[] { 82, 117, 110, 116, 105, 109, 101, 86, 105, 115, 105, 98, 108, 101, 80, 97, 114, 97, 109, 101, 116, 101, 114, 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  108 */   private static final byte[] RUNTIME_TYPE_ANNOTATIONS = new byte[] { 82, 117, 110, 116, 105, 109, 101, 86, 105, 115, 105, 98, 108, 101, 84, 121, 112, 101, 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  115 */   private static final byte[] ANNOTATION_DEFAULT = new byte[] { 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 68, 101, 102, 97, 117, 108, 116 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   private static final byte[] SIGNATURE = new byte[] { 83, 105, 103, 110, 97, 116, 117, 114, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  126 */   private static final byte[] EXCEPTIONS = new byte[] { 69, 120, 99, 101, 112, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  131 */   private static final byte[] INNER_CLASSES = new byte[] { 73, 110, 110, 101, 114, 67, 108, 97, 115, 115, 101, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  136 */   private static final byte[] ENCLOSING_METHOD = new byte[] { 69, 110, 99, 108, 111, 115, 105, 110, 103, 77, 101, 116, 104, 111, 100 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   private static final byte[] METHOD_PARAMETERS = new byte[] { 77, 101, 116, 104, 111, 100, 80, 97, 114, 97, 109, 101, 116, 101, 114, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  146 */   private static final byte[] LOCAL_VARIABLE_TABLE = new byte[] { 76, 111, 99, 97, 108, 86, 97, 114, 105, 97, 98, 108, 101, 84, 97, 98, 108, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   private static final byte[] CODE = new byte[] { 67, 111, 100, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   private static final byte[] MODULE = new byte[] { 77, 111, 100, 117, 108, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   private static final byte[] MODULE_PACKAGES = new byte[] { 77, 111, 100, 117, 108, 101, 80, 97, 99, 107, 97, 103, 101, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  168 */   private static final byte[] MODULE_MAIN_CLASS = new byte[] { 77, 111, 100, 117, 108, 101, 77, 97, 105, 110, 67, 108, 97, 115, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  174 */   private static final byte[] RECORD = new byte[] { 82, 101, 99, 111, 114, 100 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  180 */   private static final byte[] RUNTIME_INVISIBLE_ANNOTATIONS = new byte[] { 82, 117, 110, 116, 105, 109, 101, 73, 110, 118, 105, 115, 105, 98, 108, 101, 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   private static final byte[] RUNTIME_INVISIBLE_PARAM_ANNOTATIONS = new byte[] { 82, 117, 110, 116, 105, 109, 101, 73, 110, 118, 105, 115, 105, 98, 108, 101, 80, 97, 114, 97, 109, 101, 116, 101, 114, 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   private static final byte[] RUNTIME_INVISIBLE_TYPE_ANNOTATIONS = new byte[] { 82, 117, 110, 116, 105, 109, 101, 73, 110, 118, 105, 115, 105, 98, 108, 101, 84, 121, 112, 101, 65, 110, 110, 111, 116, 97, 116, 105, 111, 110, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  214 */   private static final byte[] PERMITTED_SUBCLASSES = new byte[] { 80, 101, 114, 109, 105, 116, 116, 101, 100, 83, 117, 98, 99, 108, 97, 115, 115, 101, 115 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  221 */   private static final int RUNTIME_ANNOTATIONS_LEN = RUNTIME_ANNOTATIONS.length;
/*  222 */   private static final int RUNTIME_PARAM_ANNOTATIONS_LEN = RUNTIME_PARAM_ANNOTATIONS.length;
/*  223 */   private static final int RUNTIME_TYPE_ANNOTATIONS_LEN = RUNTIME_TYPE_ANNOTATIONS.length;
/*  224 */   private static final int ANNOTATION_DEFAULT_LEN = ANNOTATION_DEFAULT.length;
/*  225 */   private static final int SIGNATURE_LEN = SIGNATURE.length;
/*  226 */   private static final int EXCEPTIONS_LEN = EXCEPTIONS.length;
/*  227 */   private static final int INNER_CLASSES_LEN = INNER_CLASSES.length;
/*  228 */   private static final int ENCLOSING_METHOD_LEN = ENCLOSING_METHOD.length;
/*  229 */   private static final int METHOD_PARAMETERS_LEN = METHOD_PARAMETERS.length;
/*  230 */   private static final int LOCAL_VARIABLE_TABLE_LEN = LOCAL_VARIABLE_TABLE.length;
/*  231 */   private static final int CODE_LEN = CODE.length;
/*  232 */   private static final int MODULE_LEN = MODULE.length;
/*  233 */   private static final int MODULE_PACKAGES_LEN = MODULE_PACKAGES.length;
/*  234 */   private static final int MODULE_MAIN_CLASS_LEN = MODULE_MAIN_CLASS.length;
/*  235 */   private static final int RECORD_LEN = RECORD.length;
/*  236 */   private static final int RUNTIME_INVISIBLE_ANNOTATIONS_LEN = RUNTIME_INVISIBLE_ANNOTATIONS.length;
/*  237 */   private static final int RUNTIME_INVISIBLE_PARAM_ANNOTATIONS_LEN = RUNTIME_INVISIBLE_PARAM_ANNOTATIONS.length;
/*  238 */   private static final int RUNTIME_INVISIBLE_TYPE_ANNOTATIONS_LEN = RUNTIME_INVISIBLE_TYPE_ANNOTATIONS.length; private static final int HAS_RUNTIME_ANNOTATION = 1; private static final int HAS_RUNTIME_PARAM_ANNOTATION = 2; private static final int HAS_RUNTIME_TYPE_ANNOTATION = 3; private static final int HAS_SIGNATURE = 4; private static final int HAS_EXCEPTIONS = 5; private static final int HAS_INNER_CLASSES = 6; private static final int HAS_ENCLOSING_METHOD = 7; private static final int HAS_ANNOTATION_DEFAULT = 8; private static final int HAS_METHOD_PARAMETERS = 9; private static final int HAS_LOCAL_VARIABLE_TABLE = 10; private static final int HAS_CODE = 11; private static final int HAS_MODULE = 12; private static final int HAS_MODULE_PACKAGES = 13; private static final int HAS_MODULE_MAIN_CLASS = 14;
/*  239 */   private static final int PERMITTED_SUBCLASSES_LEN = PERMITTED_SUBCLASSES.length;
/*      */   
/*      */   private static final int HAS_RECORD = 15;
/*      */   
/*      */   private static final int HAS_RUNTIME_INVISIBLE_ANNOTATION = 16;
/*      */   
/*      */   private static final int HAS_RUNTIME_INVISIBLE_PARAM_ANNOTATION = 17;
/*      */   
/*      */   private static final int HAS_RUNTIME_INVISIBLE_TYPE_ANNOTATION = 18;
/*      */   
/*      */   private static final int HAS_PERMITTED_SUBCLASSES = 19;
/*      */   private int constantPoolSize;
/*      */   private byte[] constantPool;
/*      */   private int[] constantPoolOffsets;
/*      */   private byte[] constantPoolAnnoAttrributes;
/*      */   private ClassInfo currentClass;
/*      */   private HashMap<DotName, List<AnnotationInstance>> classAnnotations;
/*      */   private ArrayList<AnnotationInstance> elementAnnotations;
/*      */   private IdentityHashMap<AnnotationTarget, Object> signaturePresent;
/*      */   private List<Object> signatures;
/*      */   
/*      */   private static class InnerClassInfo
/*      */   {
/*      */     private InnerClassInfo(DotName innerClass, DotName enclosingClass, String simpleName, int flags) {
/*  263 */       this.innerClass = innerClass;
/*  264 */       this.enclosingClass = enclosingClass;
/*  265 */       this.simpleName = simpleName;
/*  266 */       this.flags = flags;
/*      */     }
/*      */ 
/*      */     
/*      */     private final DotName innerClass;
/*      */     private DotName enclosingClass;
/*      */     private String simpleName;
/*      */     private int flags;
/*      */   }
/*      */   
/*      */   private static boolean match(byte[] target, int offset, byte[] expected) {
/*  277 */     if (target.length - offset < expected.length) {
/*  278 */       return false;
/*      */     }
/*  280 */     for (int i = 0; i < expected.length; i++) {
/*  281 */       if (target[offset + i] != expected[i])
/*  282 */         return false; 
/*      */     } 
/*  284 */     return true;
/*      */   }
/*      */   
/*      */   private static byte[] sizeToFit(byte[] buf, int needed, int offset, int remainingEntries) {
/*  288 */     int oldLength = buf.length;
/*  289 */     if (offset + needed > oldLength) {
/*  290 */       int newLength = newLength(oldLength, needed, oldLength >> 1);
/*  291 */       buf = Arrays.copyOf(buf, newLength);
/*      */     } 
/*  293 */     return buf;
/*      */   }
/*      */   
/*      */   private static int newLength(int oldLength, int minGrowth, int prefGrowth) {
/*  297 */     int prefLength = oldLength + Math.max(minGrowth, prefGrowth);
/*  298 */     return (prefLength > 0) ? prefLength : minLength(oldLength, minGrowth);
/*      */   }
/*      */   
/*      */   private static int minLength(int oldLength, int minGrowth) {
/*  302 */     int minLength = oldLength + minGrowth;
/*  303 */     if (minLength < 0) {
/*  304 */       throw new OutOfMemoryError("Cannot allocate a large enough array: " + oldLength + " + " + minGrowth + " is too large");
/*      */     }
/*      */     
/*  307 */     return minLength;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void skipFully(InputStream s, long n) throws IOException {
/*  312 */     long total = 0L;
/*      */     
/*  314 */     while (total < n) {
/*  315 */       long skipped = s.skip(n - total);
/*  316 */       if (skipped < 0L)
/*  317 */         throw new EOFException(); 
/*  318 */       total += skipped;
/*      */ 
/*      */       
/*  321 */       if (skipped == 0L) {
/*  322 */         if (s.read() < 0) {
/*  323 */           throw new EOFException();
/*      */         }
/*  325 */         total++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final class TmpObjects { private Utils.ReusableBufferedDataInputStream dataInputStream;
/*      */     private byte[] constantPool;
/*      */     private int[] constantPoolOffsets;
/*      */     private byte[] constantPoolAnnoAttributes;
/*      */     
/*      */     private TmpObjects() {}
/*      */     
/*      */     DataInputStream dataInputStreamOf(InputStream inputStream) {
/*  338 */       Utils.ReusableBufferedDataInputStream stream = this.dataInputStream;
/*  339 */       if (stream == null) {
/*  340 */         stream = new Utils.ReusableBufferedDataInputStream();
/*  341 */         this.dataInputStream = stream;
/*      */       } 
/*  343 */       stream.setInputStream(inputStream);
/*  344 */       return stream;
/*      */     }
/*      */     
/*      */     byte[] borrowConstantPool(int poolSize) {
/*  348 */       byte[] buf = this.constantPool;
/*  349 */       if (buf == null || buf.length < 20 * poolSize) {
/*  350 */         buf = new byte[20 * poolSize];
/*      */       } else {
/*  352 */         Arrays.fill(buf, 0, poolSize, (byte)0);
/*      */       } 
/*  354 */       this.constantPool = null;
/*  355 */       return buf;
/*      */     }
/*      */     
/*      */     void returnConstantPool(byte[] buf) {
/*  359 */       this.constantPool = buf;
/*      */     }
/*      */     
/*      */     int[] borrowConstantPoolOffsets(int poolSize) {
/*  363 */       int[] buf = this.constantPoolOffsets;
/*  364 */       if (buf == null || buf.length < poolSize) {
/*  365 */         buf = new int[poolSize];
/*      */       } else {
/*  367 */         Arrays.fill(buf, 0, poolSize, 0);
/*      */       } 
/*  369 */       this.constantPoolOffsets = null;
/*  370 */       return buf;
/*      */     }
/*      */     
/*      */     void returnConstantPoolOffsets(int[] offsets) {
/*  374 */       this.constantPoolOffsets = offsets;
/*      */     }
/*      */     
/*      */     byte[] borrowConstantPoolAnnoAttributes(int poolSize) {
/*  378 */       byte[] buf = this.constantPoolAnnoAttributes;
/*  379 */       if (buf == null || buf.length < poolSize) {
/*  380 */         buf = new byte[poolSize];
/*      */       } else {
/*  382 */         Arrays.fill(buf, 0, poolSize, (byte)0);
/*      */       } 
/*  384 */       this.constantPoolAnnoAttributes = null;
/*  385 */       return buf;
/*      */     }
/*      */     
/*      */     void returnConstantAnnoAttributes(byte[] attributes) {
/*  389 */       this.constantPoolAnnoAttributes = attributes;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  404 */   private int classSignatureIndex = -1;
/*      */   
/*      */   private Map<DotName, InnerClassInfo> innerClasses;
/*      */   
/*      */   private IdentityHashMap<AnnotationTarget, List<TypeAnnotationState>> typeAnnotations;
/*      */   private List<MethodInfo> methods;
/*      */   private List<FieldInfo> fields;
/*      */   private List<RecordComponentInfo> recordComponents;
/*      */   private IdentityHashMap<MethodInfo, MethodParamList> methodParams;
/*      */   private List<DotName> modulePackages;
/*      */   private DotName moduleMainClass;
/*      */   private Map<DotName, List<AnnotationInstance>> masterAnnotations;
/*      */   private Map<DotName, List<ClassInfo>> subclasses;
/*      */   private Map<DotName, List<ClassInfo>> subinterfaces;
/*      */   private Map<DotName, List<ClassInfo>> implementors;
/*      */   private Map<DotName, ClassInfo> classes;
/*      */   private Map<DotName, ModuleInfo> modules;
/*      */   private Map<DotName, Set<ClassInfo>> users;
/*      */   private NameTable names;
/*      */   private GenericSignatureParser signatureParser;
/*  424 */   private final TmpObjects tmpObjects = new TmpObjects();
/*      */   
/*      */   private void initIndexMaps() {
/*  427 */     if (this.masterAnnotations == null) {
/*  428 */       this.masterAnnotations = new HashMap<>();
/*      */     }
/*  430 */     if (this.subclasses == null) {
/*  431 */       this.subclasses = new HashMap<>();
/*      */     }
/*  433 */     if (this.subinterfaces == null) {
/*  434 */       this.subinterfaces = new HashMap<>();
/*      */     }
/*  436 */     if (this.implementors == null) {
/*  437 */       this.implementors = new HashMap<>();
/*      */     }
/*  439 */     if (this.classes == null) {
/*  440 */       this.classes = new HashMap<>();
/*      */     }
/*  442 */     if (this.modules == null) {
/*  443 */       this.modules = new HashMap<>();
/*      */     }
/*  445 */     if (this.users == null) {
/*  446 */       this.users = new HashMap<>();
/*      */     }
/*  448 */     if (this.names == null) {
/*  449 */       this.names = new NameTable();
/*      */     }
/*  451 */     if (this.signatureParser == null) {
/*  452 */       this.signatureParser = new GenericSignatureParser(this.names);
/*      */     }
/*      */   }
/*      */   
/*      */   private void initClassFields() {
/*  457 */     this.classAnnotations = new HashMap<>();
/*  458 */     this.elementAnnotations = new ArrayList<>();
/*  459 */     this.signaturePresent = new IdentityHashMap<>();
/*  460 */     this.signatures = new ArrayList();
/*  461 */     this.typeAnnotations = new IdentityHashMap<>();
/*      */ 
/*      */ 
/*      */     
/*  465 */     this.recordComponents = new ArrayList<>();
/*      */     
/*  467 */     this.methodParams = new IdentityHashMap<>();
/*      */   }
/*      */   
/*      */   private void processMethodInfo(DataInputStream data) throws IOException {
/*  471 */     int numMethods = data.readUnsignedShort();
/*      */     
/*  473 */     List<MethodInfo> methods = (numMethods > 0) ? new ArrayList<>(numMethods) : Collections.<MethodInfo>emptyList();
/*      */     
/*  475 */     for (int i = 0; i < numMethods; i++) {
/*  476 */       short flags = (short)data.readUnsignedShort();
/*  477 */       byte[] name = intern(decodeUtf8EntryAsBytes(data.readUnsignedShort()));
/*  478 */       String descriptor = decodeUtf8Entry(data.readUnsignedShort());
/*      */       
/*  480 */       IntegerHolder pos = new IntegerHolder();
/*  481 */       Type[] parameters = intern(parseMethodArgs(descriptor, pos));
/*  482 */       Type returnType = parseType(descriptor, pos);
/*      */       
/*  484 */       MethodInfo method = new MethodInfo(this.currentClass, name, MethodInternal.EMPTY_PARAMETER_NAMES, parameters, returnType, flags);
/*      */ 
/*      */       
/*  487 */       if (parameters.length == 0 && Arrays.equals(Utils.INIT_METHOD_NAME, name)) {
/*  488 */         this.currentClass.setHasNoArgsConstructor(true);
/*      */       }
/*  490 */       MethodParamList parameterList = new MethodParamList(method);
/*  491 */       this.methodParams.put(method, parameterList);
/*  492 */       processAttributes(data, method);
/*  493 */       method.setAnnotations(this.elementAnnotations);
/*  494 */       this.elementAnnotations.clear();
/*  495 */       parameterList.finish();
/*      */       
/*  497 */       byte[][] parameterNames = parameterList.getNames();
/*  498 */       if (parameterNames != null) {
/*  499 */         method.methodInternal().setParameterNames(parameterNames);
/*      */       }
/*      */       
/*  502 */       methods.add(method);
/*      */     } 
/*      */     
/*  505 */     this.methods = methods;
/*      */   }
/*      */   
/*      */   private void processFieldInfo(DataInputStream data) throws IOException {
/*  509 */     int numFields = data.readUnsignedShort();
/*  510 */     List<FieldInfo> fields = (numFields > 0) ? new ArrayList<>(numFields) : Collections.<FieldInfo>emptyList();
/*  511 */     for (int i = 0; i < numFields; i++) {
/*  512 */       short flags = (short)data.readUnsignedShort();
/*  513 */       byte[] name = intern(decodeUtf8EntryAsBytes(data.readUnsignedShort()));
/*  514 */       Type type = parseType(decodeUtf8Entry(data.readUnsignedShort()));
/*  515 */       FieldInfo field = new FieldInfo(this.currentClass, name, type, flags);
/*      */       
/*  517 */       processAttributes(data, field);
/*  518 */       field.setAnnotations(this.elementAnnotations);
/*  519 */       this.elementAnnotations.clear();
/*  520 */       fields.add(field);
/*      */     } 
/*  522 */     this.fields = fields;
/*      */   }
/*      */   
/*      */   private void processRecordComponents(DataInputStream data) throws IOException {
/*  526 */     int numComponents = data.readUnsignedShort();
/*      */     
/*  528 */     List<RecordComponentInfo> recordComponents = (numComponents > 0) ? new ArrayList<>(numComponents) : Collections.<RecordComponentInfo>emptyList();
/*  529 */     for (int i = 0; i < numComponents; i++) {
/*  530 */       byte[] name = intern(decodeUtf8EntryAsBytes(data.readUnsignedShort()));
/*  531 */       Type type = intern(parseType(decodeUtf8Entry(data.readUnsignedShort())));
/*  532 */       RecordComponentInfo component = new RecordComponentInfo(this.currentClass, name, type);
/*      */       
/*  534 */       processAttributes(data, component);
/*  535 */       component.setAnnotations(this.elementAnnotations);
/*  536 */       this.elementAnnotations.clear();
/*  537 */       recordComponents.add(component);
/*      */     } 
/*  539 */     this.recordComponents = recordComponents;
/*      */   }
/*      */   
/*      */   private void processPermittedSubclasses(DataInputStream data, ClassInfo target) throws IOException {
/*  543 */     int numPermittedSubclasses = data.readUnsignedShort();
/*  544 */     if (numPermittedSubclasses > 0) {
/*  545 */       Set<DotName> permittedSubclasses = new HashSet<>(numPermittedSubclasses);
/*  546 */       for (int i = 0; i < numPermittedSubclasses; i++) {
/*  547 */         DotName name = decodeClassEntry(data.readUnsignedShort());
/*  548 */         permittedSubclasses.add(name);
/*      */       } 
/*  550 */       target.setPermittedSubclasses(permittedSubclasses);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processAttributes(DataInputStream data, AnnotationTarget target) throws IOException {
/*  555 */     int numAttrs = data.readUnsignedShort();
/*  556 */     byte[] constantPoolAnnoAttrributes = this.constantPoolAnnoAttrributes;
/*  557 */     for (int a = 0; a < numAttrs; a++) {
/*  558 */       int index = data.readUnsignedShort();
/*  559 */       long attributeLen = data.readInt() & 0xFFFFFFFFL;
/*  560 */       byte annotationAttribute = constantPoolAnnoAttrributes[index - 1];
/*  561 */       if (annotationAttribute == 1 || annotationAttribute == 16) {
/*  562 */         processAnnotations(data, target, (annotationAttribute == 1));
/*  563 */       } else if (annotationAttribute == 2 || annotationAttribute == 17) {
/*      */         
/*  565 */         if (!(target instanceof MethodInfo)) {
/*  566 */           if (annotationAttribute == 2) {
/*  567 */             throw new IllegalStateException("RuntimeVisibleParameterAnnotations appeared on a non-method");
/*      */           }
/*  569 */           throw new IllegalStateException("RuntimeInvisibleParameterAnnotations appeared on a non-method");
/*      */         } 
/*      */         
/*  572 */         int numParameters = data.readUnsignedByte();
/*  573 */         if (target.asMethod().parametersCount() > 255)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  578 */           numParameters = target.asMethod().parametersCount(); } 
/*      */         short p;
/*  580 */         for (p = 0; p < numParameters; p = (short)(p + 1)) {
/*  581 */           processAnnotations(data, new MethodParameterInfo((MethodInfo)target, p), (annotationAttribute == 2));
/*      */         }
/*      */       }
/*  584 */       else if (annotationAttribute == 3 || annotationAttribute == 18) {
/*      */         
/*  586 */         processTypeAnnotations(data, target, (annotationAttribute == 3));
/*  587 */       } else if (annotationAttribute == 4) {
/*  588 */         processSignature(data, target);
/*  589 */       } else if (annotationAttribute == 5 && target instanceof MethodInfo) {
/*  590 */         processExceptions(data, (MethodInfo)target);
/*  591 */       } else if (annotationAttribute == 6 && target instanceof ClassInfo) {
/*  592 */         processInnerClasses(data, (ClassInfo)target);
/*  593 */       } else if (annotationAttribute == 7 && target instanceof ClassInfo) {
/*  594 */         processEnclosingMethod(data, (ClassInfo)target);
/*  595 */       } else if (annotationAttribute == 8 && target instanceof MethodInfo) {
/*  596 */         processAnnotationDefault(data, (MethodInfo)target);
/*  597 */       } else if (annotationAttribute == 9 && target instanceof MethodInfo) {
/*  598 */         processMethodParameters(data, (MethodInfo)target);
/*  599 */       } else if (annotationAttribute == 11 && target instanceof MethodInfo) {
/*  600 */         processCode(data, (MethodInfo)target);
/*  601 */       } else if (annotationAttribute == 12 && target instanceof ClassInfo) {
/*  602 */         processModule(data, (ClassInfo)target);
/*  603 */       } else if (annotationAttribute == 13 && target instanceof ClassInfo) {
/*  604 */         processModulePackages(data, (ClassInfo)target);
/*  605 */       } else if (annotationAttribute == 14 && target instanceof ClassInfo) {
/*  606 */         processModuleMainClass(data, (ClassInfo)target);
/*  607 */       } else if (annotationAttribute == 15 && target instanceof ClassInfo) {
/*  608 */         processRecordComponents(data);
/*  609 */       } else if (annotationAttribute == 19 && target instanceof ClassInfo) {
/*  610 */         processPermittedSubclasses(data, (ClassInfo)target);
/*      */       } else {
/*  612 */         skipFully(data, attributeLen);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processModule(DataInputStream data, ClassInfo target) throws IOException {
/*  618 */     if (!target.isModule()) {
/*  619 */       throw new IllegalStateException("Module attribute appeared in a non-module class file");
/*      */     }
/*      */     
/*  622 */     DotName moduleName = decodeModuleEntry(data.readUnsignedShort());
/*  623 */     int flags = data.readUnsignedShort();
/*  624 */     String version = decodeOptionalUtf8Entry(data.readUnsignedShort());
/*      */     
/*  626 */     ModuleInfo module = new ModuleInfo(target, moduleName, (short)flags, version);
/*  627 */     module.setRequires(processModuleRequires(data));
/*  628 */     module.setExports(processModuleExports(data));
/*  629 */     module.setOpens(processModuleOpens(data));
/*  630 */     module.setUses(processModuleUses(data));
/*  631 */     module.setProvides(processModuleProvides(data));
/*      */ 
/*      */     
/*  634 */     this.modules.put(moduleName, module);
/*      */   }
/*      */   
/*      */   private List<ModuleInfo.RequiredModuleInfo> processModuleRequires(DataInputStream data) throws IOException {
/*  638 */     int requiresCount = data.readUnsignedShort();
/*  639 */     List<ModuleInfo.RequiredModuleInfo> requires = Utils.listOfCapacity(requiresCount);
/*      */     
/*  641 */     for (int i = 0; i < requiresCount; i++) {
/*  642 */       DotName name = decodeModuleEntry(data.readUnsignedShort());
/*  643 */       int flags = data.readUnsignedShort();
/*  644 */       String version = decodeOptionalUtf8Entry(data.readUnsignedShort());
/*  645 */       requires.add(new ModuleInfo.RequiredModuleInfo(name, flags, version));
/*      */     } 
/*      */     
/*  648 */     return requires;
/*      */   }
/*      */   
/*      */   private List<ModuleInfo.ExportedPackageInfo> processModuleExports(DataInputStream data) throws IOException {
/*  652 */     int exportsCount = data.readUnsignedShort();
/*  653 */     List<ModuleInfo.ExportedPackageInfo> exports = Utils.listOfCapacity(exportsCount);
/*      */     
/*  655 */     for (int i = 0; i < exportsCount; i++) {
/*  656 */       DotName source = decodePackageEntry(data.readUnsignedShort());
/*  657 */       int flags = data.readUnsignedShort();
/*  658 */       int targetCount = data.readUnsignedShort();
/*  659 */       List<DotName> targets = Utils.listOfCapacity(targetCount);
/*      */       
/*  661 */       for (int j = 0; j < targetCount; j++) {
/*  662 */         targets.add(decodeModuleEntry(data.readUnsignedShort()));
/*      */       }
/*      */       
/*  665 */       exports.add(new ModuleInfo.ExportedPackageInfo(source, flags, targets));
/*      */     } 
/*      */     
/*  668 */     return exports;
/*      */   }
/*      */   
/*      */   private List<ModuleInfo.OpenedPackageInfo> processModuleOpens(DataInputStream data) throws IOException {
/*  672 */     int opensCount = data.readUnsignedShort();
/*  673 */     List<ModuleInfo.OpenedPackageInfo> opens = Utils.listOfCapacity(opensCount);
/*      */     
/*  675 */     for (int i = 0; i < opensCount; i++) {
/*  676 */       DotName source = decodePackageEntry(data.readUnsignedShort());
/*  677 */       int flags = data.readUnsignedShort();
/*  678 */       int targetCount = data.readUnsignedShort();
/*  679 */       List<DotName> targets = Utils.listOfCapacity(targetCount);
/*      */       
/*  681 */       for (int j = 0; j < targetCount; j++) {
/*  682 */         targets.add(decodeModuleEntry(data.readUnsignedShort()));
/*      */       }
/*      */       
/*  685 */       opens.add(new ModuleInfo.OpenedPackageInfo(source, flags, targets));
/*      */     } 
/*      */     
/*  688 */     return opens;
/*      */   }
/*      */   
/*      */   private List<DotName> processModuleUses(DataInputStream data) throws IOException {
/*  692 */     int usesCount = data.readUnsignedShort();
/*  693 */     List<DotName> usesServices = Utils.listOfCapacity(usesCount);
/*      */     
/*  695 */     for (int j = 0; j < usesCount; j++) {
/*  696 */       usesServices.add(decodeClassEntry(data.readUnsignedShort()));
/*      */     }
/*      */     
/*  699 */     return usesServices;
/*      */   }
/*      */   
/*      */   private List<ModuleInfo.ProvidedServiceInfo> processModuleProvides(DataInputStream data) throws IOException {
/*  703 */     int providesCount = data.readUnsignedShort();
/*  704 */     List<ModuleInfo.ProvidedServiceInfo> provides = Utils.listOfCapacity(providesCount);
/*      */     
/*  706 */     for (int i = 0; i < providesCount; i++) {
/*  707 */       DotName service = decodeClassEntry(data.readUnsignedShort());
/*  708 */       int providerCount = data.readUnsignedShort();
/*  709 */       List<DotName> providers = Utils.listOfCapacity(providerCount);
/*      */       
/*  711 */       for (int j = 0; j < providerCount; j++) {
/*  712 */         providers.add(decodeClassEntry(data.readUnsignedShort()));
/*      */       }
/*      */       
/*  715 */       provides.add(new ModuleInfo.ProvidedServiceInfo(service, providers));
/*      */     } 
/*      */     
/*  718 */     return provides;
/*      */   }
/*      */   
/*      */   private void processModulePackages(DataInputStream data, ClassInfo target) throws IOException {
/*  722 */     if (!target.isModule()) {
/*  723 */       throw new IllegalStateException("ModulePackages attribute appeared in a non-module class file");
/*      */     }
/*      */     
/*  726 */     int packagesCount = data.readUnsignedShort();
/*  727 */     List<DotName> packages = Utils.listOfCapacity(packagesCount);
/*      */     
/*  729 */     for (int j = 0; j < packagesCount; j++) {
/*  730 */       packages.add(decodePackageEntry(data.readUnsignedShort()));
/*      */     }
/*      */     
/*  733 */     this.modulePackages = packages;
/*      */   }
/*      */   
/*      */   private void processModuleMainClass(DataInputStream data, ClassInfo target) throws IOException {
/*  737 */     if (!target.isModule()) {
/*  738 */       throw new IllegalStateException("ModuleMainClass attribute appeared in a non-module class file");
/*      */     }
/*      */     
/*  741 */     this.moduleMainClass = decodeClassEntry(data.readUnsignedShort());
/*      */   }
/*      */   
/*      */   private void processCode(DataInputStream data, MethodInfo target) throws IOException {
/*  745 */     data.skipBytes(4);
/*  746 */     long h = data.readUnsignedShort();
/*  747 */     long l = data.readUnsignedShort();
/*  748 */     long codeLength = h << 16L | l;
/*  749 */     skipFully(data, codeLength);
/*  750 */     int exceptionTableLength = data.readUnsignedShort();
/*  751 */     skipFully(data, (exceptionTableLength * 8));
/*  752 */     byte[] constantPoolAnnoAttrributes = this.constantPoolAnnoAttrributes;
/*  753 */     int numAttrs = data.readUnsignedShort();
/*  754 */     for (int a = 0; a < numAttrs; a++) {
/*  755 */       int index = data.readUnsignedShort();
/*  756 */       long attributeLen = data.readInt() & 0xFFFFFFFFL;
/*  757 */       byte annotationAttribute = constantPoolAnnoAttrributes[index - 1];
/*  758 */       if (annotationAttribute == 10 && target instanceof MethodInfo) {
/*  759 */         processLocalVariableTable(data, target);
/*      */       } else {
/*  761 */         skipFully(data, attributeLen);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processAnnotationDefault(DataInputStream data, MethodInfo target) throws IOException {
/*  767 */     target.setDefaultValue(processAnnotationElementValue(target.name(), data));
/*      */   }
/*      */   
/*      */   private void processAnnotations(DataInputStream data, AnnotationTarget target, boolean visible) throws IOException {
/*  771 */     int numAnnotations = data.readUnsignedShort();
/*  772 */     while (numAnnotations-- > 0)
/*  773 */       processAnnotation(data, target, visible); 
/*      */   }
/*      */   
/*      */   private void processInnerClasses(DataInputStream data, ClassInfo target) throws IOException {
/*  777 */     int numClasses = data.readUnsignedShort();
/*  778 */     this.innerClasses = (numClasses > 0) ? new HashMap<>(numClasses) : Collections.<DotName, InnerClassInfo>emptyMap();
/*  779 */     Set<DotName> memberClasses = new HashSet<>();
/*  780 */     for (int i = 0; i < numClasses; i++) {
/*  781 */       DotName innerClass = decodeClassEntry(data.readUnsignedShort());
/*  782 */       int outerIndex = data.readUnsignedShort();
/*  783 */       DotName outerClass = (outerIndex == 0) ? null : decodeClassEntry(outerIndex);
/*  784 */       int simpleIndex = data.readUnsignedShort();
/*  785 */       String simpleName = (simpleIndex == 0) ? null : decodeUtf8Entry(simpleIndex);
/*  786 */       int flags = data.readUnsignedShort();
/*      */       
/*  788 */       if (innerClass.equals(target.name())) {
/*  789 */         target.setInnerClassInfo(outerClass, simpleName, true);
/*  790 */         target.setFlags((short)flags);
/*      */       } 
/*  792 */       if (outerClass != null && outerClass.equals(target.name())) {
/*  793 */         memberClasses.add(innerClass);
/*      */       }
/*      */       
/*  796 */       this.innerClasses.put(innerClass, new InnerClassInfo(innerClass, outerClass, simpleName, flags));
/*      */     } 
/*  798 */     if (!memberClasses.isEmpty()) {
/*  799 */       target.setMemberClasses(memberClasses);
/*      */     }
/*      */   }
/*      */   
/*      */   private void processMethodParameters(DataInputStream data, MethodInfo target) throws IOException {
/*  804 */     int numParameters = data.readUnsignedByte();
/*  805 */     if (target.parametersCount() > 255)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  810 */       numParameters = target.parametersCount();
/*      */     }
/*  812 */     for (int i = 0; i < numParameters; i++) {
/*  813 */       int nameIndex = data.readUnsignedShort();
/*  814 */       byte[] parameterName = (nameIndex == 0) ? null : decodeUtf8EntryAsBytes(nameIndex);
/*  815 */       int flags = data.readUnsignedShort();
/*  816 */       boolean syntheticOrMandated = ((flags & 0x9000) != 0);
/*      */       
/*  818 */       if (this.methodParams.containsKey(target)) {
/*  819 */         ((MethodParamList)this.methodParams.get(target)).appendProper(parameterName, syntheticOrMandated);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processLocalVariableTable(DataInputStream data, MethodInfo target) throws IOException {
/*  825 */     int numVariables = data.readUnsignedShort();
/*  826 */     int numParameters = 0;
/*  827 */     for (int i = 0; i < numVariables; i++) {
/*  828 */       int startPc = data.readUnsignedShort();
/*  829 */       int length = data.readUnsignedShort();
/*  830 */       int nameIndex = data.readUnsignedShort();
/*  831 */       int descriptorIndex = data.readUnsignedShort();
/*  832 */       int index = data.readUnsignedShort();
/*      */ 
/*      */       
/*  835 */       if (startPc == 0) {
/*      */ 
/*      */ 
/*      */         
/*  839 */         byte[] parameterName = (nameIndex == 0) ? null : decodeUtf8EntryAsBytes(nameIndex);
/*      */ 
/*      */         
/*  842 */         if (numParameters != 0 || parameterName == null || parameterName.length != 4 || parameterName[0] != 116 || parameterName[1] != 104 || parameterName[2] != 105 || parameterName[3] != 115) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  851 */           boolean synthetic = false;
/*  852 */           if (numParameters == 0 && parameterName != null && parameterName.length > 5 && parameterName[0] == 116 && parameterName[1] == 104 && parameterName[2] == 105 && parameterName[3] == 115 && parameterName[4] == 36)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  858 */             synthetic = true;
/*      */           }
/*      */           
/*  861 */           if (this.methodParams.containsKey(target)) {
/*  862 */             ((MethodParamList)this.methodParams.get(target)).appendDebug(parameterName, synthetic);
/*      */           }
/*      */           
/*  865 */           numParameters++;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   } private void processEnclosingMethod(DataInputStream data, ClassInfo target) throws IOException {
/*  870 */     int classIndex = data.readUnsignedShort();
/*  871 */     int index = data.readUnsignedShort();
/*  872 */     if (index == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  876 */     DotName enclosingClass = decodeClassEntry(classIndex);
/*  877 */     NameAndType nameAndType = decodeNameAndTypeEntry(index);
/*      */     
/*  879 */     IntegerHolder pos = new IntegerHolder();
/*  880 */     Type[] parameters = intern(parseMethodArgs(nameAndType.descriptor, pos));
/*  881 */     Type returnType = parseType(nameAndType.descriptor, pos);
/*      */     
/*  883 */     ClassInfo.EnclosingMethodInfo method = new ClassInfo.EnclosingMethodInfo(nameAndType.name, returnType, parameters, enclosingClass);
/*  884 */     target.setEnclosingMethod(method);
/*      */   }
/*      */   
/*      */   private void processTypeAnnotations(DataInputStream data, AnnotationTarget target, boolean visible) throws IOException {
/*  888 */     int numAnnotations = data.readUnsignedShort();
/*  889 */     List<TypeAnnotationState> annotations = new ArrayList<>(numAnnotations);
/*      */     
/*  891 */     for (int i = 0; i < numAnnotations; i++) {
/*  892 */       TypeAnnotationState annotation = processTypeAnnotation(data, target, visible);
/*  893 */       if (annotation != null) {
/*  894 */         annotations.add(annotation);
/*      */       }
/*      */     } 
/*      */     
/*  898 */     this.typeAnnotations.put(target, annotations);
/*      */   }
/*      */ 
/*      */   
/*      */   private TypeAnnotationState processTypeAnnotation(DataInputStream data, AnnotationTarget target, boolean visible) throws IOException {
/*  903 */     int position, targetType = data.readUnsignedByte();
/*  904 */     TypeTarget typeTarget = null;
/*  905 */     switch (targetType) {
/*      */       
/*      */       case 0:
/*      */       case 1:
/*  909 */         typeTarget = new TypeParameterTypeTarget(target, data.readUnsignedByte());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 16:
/*  914 */         position = data.readUnsignedShort();
/*      */ 
/*      */         
/*  917 */         if (target instanceof ClassInfo) {
/*  918 */           typeTarget = new ClassExtendsTypeTarget((ClassInfo)target, position);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 17:
/*      */       case 18:
/*  925 */         typeTarget = new TypeParameterBoundTypeTarget(target, data.readUnsignedByte(), data.readUnsignedByte());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*  933 */         if (target.kind() == AnnotationTarget.Kind.METHOD && targetType == 19) {
/*      */           break;
/*      */         }
/*  936 */         typeTarget = new EmptyTypeTarget(target, (targetType == 21));
/*      */         break;
/*      */       
/*      */       case 22:
/*  940 */         position = data.readUnsignedByte();
/*  941 */         if (target instanceof MethodInfo) {
/*  942 */           typeTarget = new MethodParameterTypeTarget((MethodInfo)target, position);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 23:
/*  948 */         position = data.readUnsignedShort();
/*  949 */         if (target instanceof MethodInfo) {
/*  950 */           typeTarget = new ThrowsTypeTarget((MethodInfo)target, position);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 64:
/*      */       case 65:
/*  958 */         skipFully(data, (data.readUnsignedShort() * 6));
/*      */         break;
/*      */       case 66:
/*  961 */         skipFully(data, 2L);
/*      */         break;
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*  967 */         skipFully(data, 2L);
/*      */         break;
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*  974 */         skipFully(data, 3L);
/*      */         break;
/*      */       default:
/*  977 */         throw new IllegalStateException("Invalid type annotation target type");
/*      */     } 
/*      */ 
/*      */     
/*  981 */     if (typeTarget == null) {
/*  982 */       skipTargetPath(data);
/*      */ 
/*      */       
/*  985 */       processAnnotation(data, null, visible);
/*  986 */       return null;
/*      */     } 
/*      */     
/*  989 */     BooleanHolder genericsRequired = new BooleanHolder();
/*  990 */     BooleanHolder bridgeIncompatible = new BooleanHolder();
/*      */     
/*  992 */     if (typeTarget.usage() == TypeTarget.Usage.TYPE_PARAMETER || typeTarget
/*  993 */       .usage() == TypeTarget.Usage.TYPE_PARAMETER_BOUND) {
/*  994 */       genericsRequired.bool = true;
/*      */     }
/*      */     
/*  997 */     ArrayList<PathElement> pathElements = processTargetPath(data, genericsRequired, bridgeIncompatible);
/*  998 */     AnnotationInstance annotation = processAnnotation(data, typeTarget, visible);
/*  999 */     return new TypeAnnotationState(typeTarget, annotation, pathElements, genericsRequired.bool, bridgeIncompatible.bool);
/*      */   }
/*      */   
/*      */   private void adjustMethodParameters() {
/* 1003 */     IdentityHashMap<MethodInfo, Object> alreadyProcessedMethods = new IdentityHashMap<>();
/* 1004 */     for (MethodInfo method : this.methods) {
/* 1005 */       if (alreadyProcessedMethods.containsKey(method)) {
/*      */         continue;
/*      */       }
/* 1008 */       alreadyProcessedMethods.put(method, null);
/*      */       
/* 1010 */       if (this.signaturePresent.containsKey(method)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1016 */       if (isInnerConstructor(method)) {
/*      */         
/* 1018 */         DotName enclosingClass = null;
/* 1019 */         if (method.declaringClass().enclosingClass() != null) {
/* 1020 */           enclosingClass = method.declaringClass().enclosingClass();
/* 1021 */         } else if (method.declaringClass().enclosingMethod() != null) {
/* 1022 */           enclosingClass = method.declaringClass().enclosingMethod().enclosingClass();
/*      */         } 
/*      */         
/* 1025 */         Type[] parameterTypes = method.methodInternal().parameterTypesArray();
/* 1026 */         if (parameterTypes.length > 0 && parameterTypes[0].name().equals(enclosingClass)) {
/* 1027 */           Type[] newParameterTypes = new Type[parameterTypes.length - 1];
/* 1028 */           System.arraycopy(parameterTypes, 1, newParameterTypes, 0, parameterTypes.length - 1);
/* 1029 */           method.setParameters(intern(newParameterTypes));
/*      */         }  continue;
/* 1031 */       }  if (isEnumConstructor(method)) {
/*      */         
/* 1033 */         Type[] parameterTypes = method.methodInternal().parameterTypesArray();
/* 1034 */         if (parameterTypes.length >= 2 && parameterTypes[0]
/* 1035 */           .kind() == Type.Kind.CLASS && parameterTypes[0]
/* 1036 */           .name().equals(DotName.STRING_NAME) && parameterTypes[1]
/* 1037 */           .kind() == Type.Kind.PRIMITIVE && parameterTypes[1]
/* 1038 */           .asPrimitiveType().primitive() == PrimitiveType.Primitive.INT) {
/*      */           Type[] newParameterTypes;
/* 1040 */           if (parameterTypes.length == 2) {
/* 1041 */             newParameterTypes = Type.EMPTY_ARRAY;
/*      */           } else {
/* 1043 */             newParameterTypes = new Type[parameterTypes.length - 2];
/* 1044 */             System.arraycopy(parameterTypes, 2, newParameterTypes, 0, parameterTypes.length - 2);
/*      */           } 
/* 1046 */           method.setParameters(intern(newParameterTypes));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isInnerConstructor(MethodInfo method) {
/* 1053 */     if (!method.isConstructor()) {
/* 1054 */       return false;
/*      */     }
/*      */     
/* 1057 */     ClassInfo klass = method.declaringClass();
/*      */ 
/*      */ 
/*      */     
/* 1061 */     if (klass.nestingType() == ClassInfo.NestingType.LOCAL || klass
/* 1062 */       .nestingType() == ClassInfo.NestingType.ANONYMOUS) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1071 */       MethodParamList parameters = this.methodParams.get(method);
/* 1072 */       if (parameters != null && parameters.firstIsEnclosingInstance()) {
/* 1073 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1082 */       for (FieldInfo field : this.fields) {
/* 1083 */         if (Modifiers.isSynthetic(field.flags()) && field.name().startsWith("this$")) {
/* 1084 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 1088 */       return false;
/*      */     } 
/*      */     
/* 1091 */     return (klass.nestingType() == ClassInfo.NestingType.INNER && !Modifier.isStatic(klass.flags()));
/*      */   }
/*      */   
/*      */   private static boolean isEnumConstructor(MethodInfo method) {
/* 1095 */     return (method.declaringClass().isEnum() && method.isConstructor());
/*      */   }
/*      */   
/*      */   private void resolveTypeAnnotations() {
/* 1099 */     for (Map.Entry<AnnotationTarget, List<TypeAnnotationState>> entry : this.typeAnnotations.entrySet()) {
/* 1100 */       AnnotationTarget key = entry.getKey();
/* 1101 */       List<TypeAnnotationState> annotations = entry.getValue();
/*      */       
/* 1103 */       for (TypeAnnotationState annotation : annotations) {
/* 1104 */         resolveTypeAnnotation(key, annotation);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void resolveUsers() throws IOException {
/* 1111 */     int poolSize = this.constantPoolSize;
/* 1112 */     byte[] pool = this.constantPool;
/* 1113 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 1115 */     for (int i = 0; i < poolSize; i++) {
/* 1116 */       int offset = offsets[i];
/* 1117 */       if (pool[offset] == 7) {
/* 1118 */         int nameIndex = (pool[++offset] & 0xFF) << 8 | pool[++offset] & 0xFF;
/* 1119 */         DotName usedClass = this.names.convertToName(decodeUtf8Entry(nameIndex), '/');
/* 1120 */         recordUsedClass(usedClass);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1125 */     for (TypeVariable typeParameter : this.currentClass.typeParameters()) {
/* 1126 */       recordUsedType(typeParameter);
/*      */     }
/* 1128 */     recordUsedType(this.currentClass.superClassType());
/* 1129 */     for (Type interfaceType : this.currentClass.interfaceTypes()) {
/* 1130 */       recordUsedType(interfaceType);
/*      */     }
/* 1132 */     for (DotName permittedSubclass : this.currentClass.permittedSubclasses()) {
/* 1133 */       recordUsedClass(permittedSubclass);
/*      */     }
/*      */     
/* 1136 */     for (FieldInfo field : this.fields) {
/* 1137 */       recordUsedType(field.type());
/*      */     }
/*      */     
/* 1140 */     for (MethodInfo method : this.methods) {
/* 1141 */       for (TypeVariable typeParameter : method.typeParameters()) {
/* 1142 */         recordUsedType(typeParameter);
/*      */       }
/* 1144 */       recordUsedType(method.returnType());
/* 1145 */       for (Type parameterType : method.parameterTypes()) {
/* 1146 */         recordUsedType(parameterType);
/*      */       }
/* 1148 */       for (Type exceptionType : method.exceptions()) {
/* 1149 */         recordUsedType(exceptionType);
/*      */       }
/*      */     } 
/*      */     
/* 1153 */     for (RecordComponentInfo recordComponent : this.recordComponents) {
/* 1154 */       recordUsedType(recordComponent.type());
/*      */     }
/*      */   }
/*      */   
/*      */   private void recordUsedType(Type type) {
/* 1159 */     if (type == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1163 */     switch (type.kind()) {
/*      */       case EMPTY:
/* 1165 */         recordUsedClass(type.asClassType().name());
/*      */         break;
/*      */       case CLASS_EXTENDS:
/* 1168 */         recordUsedClass(type.asParameterizedType().name());
/* 1169 */         for (Type typeArgument : type.asParameterizedType().arguments()) {
/* 1170 */           recordUsedType(typeArgument);
/*      */         }
/*      */         break;
/*      */       case METHOD_PARAMETER:
/* 1174 */         recordUsedType(type.asArrayType().elementType());
/*      */         break;
/*      */       case TYPE_PARAMETER:
/* 1177 */         recordUsedType(type.asWildcardType().bound());
/*      */         break;
/*      */       case TYPE_PARAMETER_BOUND:
/* 1180 */         for (Type bound : type.asTypeVariable().boundArray()) {
/* 1181 */           recordUsedType(bound);
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void recordUsedClass(DotName usedClass) {
/* 1188 */     Set<ClassInfo> usersOfClass = this.users.get(usedClass);
/* 1189 */     if (usersOfClass == null) {
/* 1190 */       usersOfClass = new LinkedHashSet<>();
/* 1191 */       this.users.put(usedClass, usersOfClass);
/*      */     } 
/* 1193 */     usersOfClass.add(this.currentClass);
/*      */   }
/*      */   
/*      */   private void updateTypeTargets() {
/* 1197 */     for (Map.Entry<AnnotationTarget, List<TypeAnnotationState>> entry : this.typeAnnotations.entrySet()) {
/* 1198 */       AnnotationTarget key = entry.getKey();
/* 1199 */       List<TypeAnnotationState> annotations = entry.getValue();
/*      */       
/* 1201 */       for (TypeAnnotationState annotation : annotations) {
/* 1202 */         updateTypeTarget(key, annotation);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Type[] getTypeParameters(AnnotationTarget target) {
/* 1208 */     if (target instanceof ClassInfo)
/* 1209 */       return ((ClassInfo)target).typeParameterArray(); 
/* 1210 */     if (target instanceof MethodInfo) {
/* 1211 */       return ((MethodInfo)target).typeParameterArray();
/*      */     }
/*      */     
/* 1214 */     throw new IllegalStateException("Type annotation referred to type parameters on an invalid target: " + target);
/*      */   }
/*      */   
/*      */   private static Type[] copyTypeParameters(AnnotationTarget target) {
/* 1218 */     if (target instanceof ClassInfo)
/* 1219 */       return (Type[])((ClassInfo)target).typeParameterArray().clone(); 
/* 1220 */     if (target instanceof MethodInfo) {
/* 1221 */       return (Type[])((MethodInfo)target).typeParameterArray().clone();
/*      */     }
/*      */     
/* 1224 */     throw new IllegalStateException("Type annotation referred to type parameters on an invalid target: " + target);
/*      */   }
/*      */   
/*      */   private static void setTypeParameters(AnnotationTarget target, Type[] typeParameters) {
/* 1228 */     if (target instanceof ClassInfo) {
/* 1229 */       ((ClassInfo)target).setTypeParameters(typeParameters); return;
/*      */     } 
/* 1231 */     if (target instanceof MethodInfo) {
/* 1232 */       ((MethodInfo)target).setTypeParameters(typeParameters);
/*      */       
/*      */       return;
/*      */     } 
/* 1236 */     throw new IllegalStateException("Type annotation referred to type parameters on an invalid target: " + target);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveTypeAnnotation(AnnotationTarget target, TypeAnnotationState typeAnnotationState) {
/* 1242 */     if (typeAnnotationState.genericsRequired && !this.signaturePresent.containsKey(target)) {
/* 1243 */       typeAnnotationState.target.setTarget(VoidType.VOID);
/*      */       
/*      */       return;
/*      */     } 
/* 1247 */     TypeTarget typeTarget = typeAnnotationState.target;
/*      */     
/* 1249 */     if (typeTarget.usage() == TypeTarget.Usage.TYPE_PARAMETER_BOUND) {
/* 1250 */       TypeParameterBoundTypeTarget bound = (TypeParameterBoundTypeTarget)typeTarget;
/* 1251 */       Type[] types = copyTypeParameters(target);
/* 1252 */       int index = bound.position();
/* 1253 */       if (index >= types.length) {
/*      */         return;
/*      */       }
/*      */       
/* 1257 */       TypeVariable type = types[index].asTypeVariable();
/* 1258 */       if (type.hasImplicitObjectBound()) {
/* 1259 */         bound.adjustBoundDown();
/*      */       }
/* 1261 */       int boundIndex = bound.boundPosition();
/* 1262 */       if (boundIndex >= (type.boundArray()).length) {
/*      */         return;
/*      */       }
/* 1265 */       type = type.copyType(boundIndex, resolveTypePath(type.boundArray()[boundIndex], typeAnnotationState));
/* 1266 */       types[index] = intern(type);
/* 1267 */       setTypeParameters(target, intern(types));
/* 1268 */     } else if (typeTarget.usage() == TypeTarget.Usage.TYPE_PARAMETER) {
/* 1269 */       TypeParameterTypeTarget parameter = (TypeParameterTypeTarget)typeTarget;
/* 1270 */       Type[] types = copyTypeParameters(target);
/* 1271 */       int index = parameter.position();
/* 1272 */       if (index >= types.length) {
/*      */         return;
/*      */       }
/*      */       
/* 1276 */       types[index] = resolveTypePath(types[index], typeAnnotationState);
/* 1277 */       setTypeParameters(target, intern(types));
/* 1278 */     } else if (typeTarget.usage() == TypeTarget.Usage.CLASS_EXTENDS) {
/* 1279 */       ClassInfo clazz = (ClassInfo)target;
/* 1280 */       ClassExtendsTypeTarget extendsTarget = (ClassExtendsTypeTarget)typeTarget;
/* 1281 */       int index = extendsTarget.position();
/* 1282 */       if (index == 65535) {
/* 1283 */         clazz.setSuperClassType(resolveTypePath(clazz.superClassType(), typeAnnotationState));
/* 1284 */       } else if (index < clazz.interfaceTypes().size()) {
/* 1285 */         Type[] types = clazz.copyInterfaceTypes();
/* 1286 */         types[index] = resolveTypePath(types[index], typeAnnotationState);
/* 1287 */         clazz.setInterfaceTypes(intern(types));
/*      */       } 
/* 1289 */     } else if (typeTarget.usage() == TypeTarget.Usage.METHOD_PARAMETER) {
/* 1290 */       MethodInfo method = (MethodInfo)target;
/* 1291 */       if (skipBridge(typeAnnotationState, method)) {
/*      */         return;
/*      */       }
/*      */       
/* 1295 */       MethodParameterTypeTarget parameter = (MethodParameterTypeTarget)typeTarget;
/* 1296 */       int index = parameter.position();
/* 1297 */       Type[] types = method.copyParameters();
/* 1298 */       types[index] = resolveTypePath(types[index], typeAnnotationState);
/* 1299 */       method.setParameters(intern(types));
/* 1300 */     } else if (typeTarget.usage() == TypeTarget.Usage.EMPTY && target instanceof FieldInfo) {
/* 1301 */       FieldInfo field = (FieldInfo)target;
/* 1302 */       field.setType(resolveTypePath(field.type(), typeAnnotationState));
/* 1303 */     } else if (typeTarget.usage() == TypeTarget.Usage.EMPTY && target instanceof MethodInfo) {
/* 1304 */       MethodInfo method = (MethodInfo)target;
/*      */       
/* 1306 */       if (((EmptyTypeTarget)typeTarget).isReceiver()) {
/* 1307 */         method.setReceiverType(resolveTypePath(method.receiverType(), typeAnnotationState));
/*      */       } else {
/* 1309 */         Type returnType = method.returnType();
/* 1310 */         if (skipBridge(typeAnnotationState, method)) {
/*      */           return;
/*      */         }
/* 1313 */         if (!method.isConstructor()) {
/* 1314 */           method.setReturnType(resolveTypePath(returnType, typeAnnotationState));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1319 */           Type newType = new ClassType(method.declaringClass().name());
/* 1320 */           newType = resolveTypePath(newType, typeAnnotationState);
/* 1321 */           returnType = returnType.copyType(newType.annotationArray());
/*      */           
/* 1323 */           typeAnnotationState.target.setTarget(returnType);
/* 1324 */           method.setReturnType(returnType);
/*      */         } 
/*      */       } 
/* 1327 */     } else if (typeTarget.usage() == TypeTarget.Usage.EMPTY && target instanceof RecordComponentInfo) {
/* 1328 */       RecordComponentInfo recordComponent = (RecordComponentInfo)target;
/* 1329 */       recordComponent.setType(resolveTypePath(recordComponent.type(), typeAnnotationState));
/* 1330 */     } else if (typeTarget.usage() == TypeTarget.Usage.THROWS && target instanceof MethodInfo) {
/* 1331 */       MethodInfo method = (MethodInfo)target;
/* 1332 */       int position = ((ThrowsTypeTarget)typeTarget).position();
/* 1333 */       Type[] exceptions = method.copyExceptions();
/*      */       
/* 1335 */       if (position >= exceptions.length) {
/*      */         return;
/*      */       }
/*      */       
/* 1339 */       exceptions[position] = resolveTypePath(exceptions[position], typeAnnotationState);
/* 1340 */       method.setExceptions(intern(exceptions));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipBridge(TypeAnnotationState typeAnnotationState, MethodInfo method) {
/* 1352 */     return (typeAnnotationState.bridgeIncompatible && isBridge(method));
/*      */   }
/*      */   
/*      */   private boolean isBridge(MethodInfo methodInfo) {
/* 1356 */     int bridgeModifiers = 4160;
/* 1357 */     return ((methodInfo.flags() & bridgeModifiers) == bridgeModifiers);
/*      */   }
/*      */   
/*      */   private boolean targetsArray(TypeAnnotationState typeAnnotationState) {
/* 1361 */     if (typeAnnotationState.pathElements.size() == 0) {
/* 1362 */       return false;
/*      */     }
/* 1364 */     PathElement pathElement = typeAnnotationState.pathElements.peek();
/* 1365 */     return (pathElement != null && pathElement.kind == PathElement.Kind.ARRAY); } private Type resolveTypePath(Type type, TypeAnnotationState typeAnnotationState) { ArrayType arrayType; ParameterizedType parameterizedType; WildcardType wildcardType;
/*      */     int depth, dimensions;
/*      */     Type arguments[], bound, nested;
/*      */     int pos;
/* 1369 */     PathElementStack elements = typeAnnotationState.pathElements;
/* 1370 */     PathElement element = elements.pop();
/* 1371 */     if (element == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1377 */       boolean isTypePathEmpty = elements.pathElements.isEmpty();
/*      */       
/* 1379 */       boolean canBeNested = (type.kind() == Type.Kind.CLASS || type.kind() == Type.Kind.PARAMETERIZED_TYPE);
/* 1380 */       boolean isNestedType = (canBeNested && this.innerClasses != null && this.innerClasses.containsKey(type.name()));
/* 1381 */       if (isTypePathEmpty && isNestedType) {
/*      */         
/* 1383 */         ArrayDeque<InnerClassInfo> innerClasses = buildClassesQueue(type);
/* 1384 */         InnerClassInfo outermostInfo = innerClasses.getFirst();
/* 1385 */         if (Modifier.isStatic(outermostInfo.flags))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1391 */           innerClasses.pollFirst();
/*      */         }
/*      */         
/* 1394 */         DotName outermostName = Modifier.isStatic(outermostInfo.flags) ? outermostInfo.innerClass : outermostInfo.enclosingClass;
/*      */         
/* 1396 */         Type outermost = null;
/* 1397 */         if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 1398 */           Type candidate = type;
/* 1399 */           while (candidate != null) {
/* 1400 */             if (outermostName.equals(candidate.name())) {
/* 1401 */               outermost = candidate;
/*      */               break;
/*      */             } 
/* 1404 */             if (candidate.kind() != Type.Kind.PARAMETERIZED_TYPE) {
/*      */               break;
/*      */             }
/* 1407 */             candidate = candidate.asParameterizedType().owner();
/*      */           } 
/*      */         } 
/* 1410 */         if (outermost == null) {
/* 1411 */           outermost = outermostName.equals(type.name()) ? type : intern(new ClassType(outermostName));
/*      */         }
/*      */         
/* 1414 */         outermost = intern(outermost.addAnnotation(AnnotationInstance.create(typeAnnotationState.annotation, null)));
/* 1415 */         return rebuildNestedType(outermost, innerClasses, type, 0, typeAnnotationState);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1420 */       type = intern(type.addAnnotation(AnnotationInstance.create(typeAnnotationState.annotation, null)));
/* 1421 */       typeAnnotationState.target.setTarget(type);
/* 1422 */       return type;
/*      */     } 
/*      */     
/* 1425 */     switch (element.kind) {
/*      */       case EMPTY:
/* 1427 */         arrayType = type.asArrayType();
/* 1428 */         dimensions = arrayType.dimensions();
/* 1429 */         while (--dimensions > 0 && elements.size() > 0 && (elements.peek()).kind == PathElement.Kind.ARRAY) {
/* 1430 */           elements.pop();
/*      */         }
/*      */         
/* 1433 */         nested = (dimensions > 0) ? new ArrayType(arrayType.component(), dimensions) : arrayType.component();
/* 1434 */         nested = resolveTypePath(nested, typeAnnotationState);
/*      */         
/* 1436 */         return intern(arrayType.copyType(nested, arrayType.dimensions() - dimensions));
/*      */ 
/*      */ 
/*      */       
/*      */       case CLASS_EXTENDS:
/* 1441 */         if (type.kind() == Type.Kind.WILDCARD_TYPE && type
/* 1442 */           .asWildcardType().bound() != null && type
/* 1443 */           .asWildcardType().bound().kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 1444 */           return type;
/*      */         }
/*      */         
/* 1447 */         parameterizedType = type.asParameterizedType();
/* 1448 */         arguments = (Type[])parameterizedType.argumentsArray().clone();
/* 1449 */         pos = element.pos;
/* 1450 */         if (pos >= arguments.length) {
/* 1451 */           throw new IllegalStateException("Type annotation referred to a type argument that does not exist");
/*      */         }
/*      */         
/* 1454 */         arguments[pos] = resolveTypePath(arguments[pos], typeAnnotationState);
/* 1455 */         return intern(parameterizedType.copyType(arguments));
/*      */       
/*      */       case METHOD_PARAMETER:
/* 1458 */         wildcardType = type.asWildcardType();
/* 1459 */         bound = resolveTypePath(wildcardType.bound(), typeAnnotationState);
/* 1460 */         return intern(wildcardType.copyType(bound));
/*      */       
/*      */       case TYPE_PARAMETER:
/* 1463 */         depth = popNestedDepth(elements);
/* 1464 */         return rebuildNestedType(null, buildClassesQueue(type), type, depth, typeAnnotationState);
/*      */     } 
/*      */ 
/*      */     
/* 1468 */     throw new IllegalStateException("Unknown path element"); }
/*      */ 
/*      */   
/*      */   private int popNestedDepth(PathElementStack elements) {
/* 1472 */     int depth = 1;
/* 1473 */     while (elements.size() > 0 && (elements.peek()).kind == PathElement.Kind.NESTED) {
/* 1474 */       elements.pop();
/* 1475 */       depth++;
/*      */     } 
/* 1477 */     return depth; } private void updateTypeTarget(AnnotationTarget enclosingTarget, TypeAnnotationState typeAnnotationState) { MethodInfo methodInfo1;
/*      */     ClassInfo clazz;
/*      */     MethodInfo method;
/*      */     TypeParameterBoundTypeTarget boundTarget;
/*      */     int position;
/* 1482 */     if (typeAnnotationState.genericsRequired && !this.signaturePresent.containsKey(enclosingTarget)) {
/*      */       return;
/*      */     }
/*      */     
/* 1486 */     typeAnnotationState.pathElements.reset();
/*      */     
/* 1488 */     TypeTarget target = typeAnnotationState.target;
/*      */     
/* 1490 */     switch (target.usage()) {
/*      */       case EMPTY:
/* 1492 */         if (enclosingTarget instanceof FieldInfo) {
/* 1493 */           Type type1 = ((FieldInfo)enclosingTarget).type(); break;
/* 1494 */         }  if (enclosingTarget instanceof RecordComponentInfo) {
/* 1495 */           Type type1 = ((RecordComponentInfo)enclosingTarget).type(); break;
/*      */         } 
/* 1497 */         methodInfo1 = (MethodInfo)enclosingTarget;
/* 1498 */         type = target.asEmpty().isReceiver() ? methodInfo1.receiverType() : methodInfo1.returnType();
/* 1499 */         if (skipBridge(typeAnnotationState, methodInfo1)) {
/*      */           return;
/*      */         }
/* 1502 */         if (methodInfo1.isConstructor()) {
/*      */           return;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case CLASS_EXTENDS:
/* 1509 */         clazz = (ClassInfo)enclosingTarget;
/* 1510 */         position = target.asClassExtends().position();
/* 1511 */         type = (position == 65535) ? clazz.superClassType() : clazz.interfaceTypeArray()[position];
/*      */         break;
/*      */       
/*      */       case METHOD_PARAMETER:
/* 1515 */         method = (MethodInfo)enclosingTarget;
/* 1516 */         if (skipBridge(typeAnnotationState, method)) {
/*      */           return;
/*      */         }
/* 1519 */         type = method.methodInternal().parameterTypesArray()[target.asMethodParameterType().position()];
/*      */         break;
/*      */ 
/*      */       
/*      */       case TYPE_PARAMETER:
/* 1524 */         type = getTypeParameters(enclosingTarget)[target.asTypeParameter().position()];
/*      */         break;
/*      */       
/*      */       case TYPE_PARAMETER_BOUND:
/* 1528 */         boundTarget = target.asTypeParameterBound();
/*      */         
/* 1530 */         type = getTypeParameters(enclosingTarget)[boundTarget.position()].asTypeVariable().boundArray()[boundTarget.boundPosition()];
/*      */         break;
/*      */       
/*      */       case THROWS:
/* 1534 */         type = ((MethodInfo)enclosingTarget).methodInternal().exceptionArray()[target.asThrows().position()];
/*      */         break;
/*      */       
/*      */       default:
/* 1538 */         throw new IllegalStateException("Unknown type target: " + target.usage());
/*      */     } 
/*      */     
/* 1541 */     Type type = searchTypePath(type, typeAnnotationState);
/* 1542 */     target.setTarget(type); } private Type searchTypePath(Type type, TypeAnnotationState typeAnnotationState) {
/*      */     ArrayType arrayType;
/*      */     ParameterizedType parameterizedType;
/*      */     int depth, dimensions;
/* 1546 */     PathElementStack elements = typeAnnotationState.pathElements;
/* 1547 */     PathElement element = elements.pop();
/* 1548 */     if (element == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1554 */       boolean isTypePathEmpty = elements.pathElements.isEmpty();
/*      */       
/* 1556 */       boolean canBeNested = (type.kind() == Type.Kind.CLASS || type.kind() == Type.Kind.PARAMETERIZED_TYPE);
/* 1557 */       boolean isNestedType = (canBeNested && this.innerClasses != null && this.innerClasses.containsKey(type.name()));
/* 1558 */       if (isTypePathEmpty && isNestedType) {
/*      */         
/* 1560 */         DotName outermostName = outermostAnnotableTypeName(type);
/* 1561 */         return buildOwnerMap(type).get(outermostName);
/*      */       } 
/*      */ 
/*      */       
/* 1565 */       return type;
/*      */     } 
/*      */     
/* 1568 */     switch (element.kind) {
/*      */       case EMPTY:
/* 1570 */         arrayType = type.asArrayType();
/* 1571 */         dimensions = arrayType.dimensions();
/* 1572 */         while (--dimensions > 0 && elements.size() > 0 && (elements.peek()).kind == PathElement.Kind.ARRAY) {
/* 1573 */           elements.pop();
/*      */         }
/* 1575 */         assert dimensions == 0;
/* 1576 */         return searchTypePath(arrayType.component(), typeAnnotationState);
/*      */ 
/*      */ 
/*      */       
/*      */       case CLASS_EXTENDS:
/* 1581 */         if (type.kind() == Type.Kind.WILDCARD_TYPE && type
/* 1582 */           .asWildcardType().bound() != null && type
/* 1583 */           .asWildcardType().bound().kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 1584 */           return type;
/*      */         }
/*      */         
/* 1587 */         parameterizedType = type.asParameterizedType();
/* 1588 */         return searchTypePath(parameterizedType.argumentsArray()[element.pos], typeAnnotationState);
/*      */       
/*      */       case METHOD_PARAMETER:
/* 1591 */         return searchTypePath(type.asWildcardType().bound(), typeAnnotationState);
/*      */       
/*      */       case TYPE_PARAMETER:
/* 1594 */         depth = popNestedDepth(elements);
/* 1595 */         return searchNestedType(type, depth, typeAnnotationState);
/*      */     } 
/*      */ 
/*      */     
/* 1599 */     throw new IllegalStateException("Unknown path element");
/*      */   }
/*      */ 
/*      */   
/*      */   private Type rebuildNestedType(Type last, ArrayDeque<InnerClassInfo> classes, Type type, int depth, TypeAnnotationState typeAnnotationState) {
/* 1604 */     Map<DotName, Type> ownerMap = buildOwnerMap(type);
/*      */ 
/*      */     
/* 1607 */     if (!classes.isEmpty() && Modifier.isStatic((classes.getFirst()).flags)) {
/* 1608 */       depth++;
/*      */     }
/*      */     
/* 1611 */     for (InnerClassInfo current : classes) {
/* 1612 */       DotName currentName = current.innerClass;
/* 1613 */       Type oType = ownerMap.get(currentName);
/* 1614 */       depth--;
/*      */       
/* 1616 */       if (last != null) {
/* 1617 */         last = intern((oType != null) ? convertParameterized(oType).copyType(last) : 
/* 1618 */             new ParameterizedType(currentName, null, last));
/* 1619 */       } else if (oType != null) {
/* 1620 */         last = oType;
/*      */       } 
/*      */       
/* 1623 */       if (depth == 0) {
/* 1624 */         if (last == null) {
/* 1625 */           last = intern(new ClassType(currentName));
/*      */         }
/*      */         
/* 1628 */         last = resolveTypePath(last, typeAnnotationState);
/*      */ 
/*      */         
/* 1631 */         depth--;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1638 */     if (depth > 0 && hasAnonymousEncloser(typeAnnotationState)) {
/* 1639 */       return resolveTypePath(type, typeAnnotationState);
/*      */     }
/*      */ 
/*      */     
/* 1643 */     if (depth > 0 && hasLocalEncloser(typeAnnotationState)) {
/* 1644 */       return resolveTypePath(type, typeAnnotationState);
/*      */     }
/*      */     
/* 1647 */     if (last == null) {
/* 1648 */       throw new IllegalStateException("Required class information is missing on: " + typeAnnotationState
/* 1649 */           .target.enclosingTarget().asClass().name().toString());
/*      */     }
/*      */     
/* 1652 */     return last;
/*      */   }
/*      */   
/*      */   private ParameterizedType convertParameterized(Type oType) {
/* 1656 */     return (oType instanceof ClassType) ? oType.asClassType().toParameterizedType() : oType.asParameterizedType();
/*      */   }
/*      */   
/*      */   private Type searchNestedType(Type type, int depth, TypeAnnotationState typeAnnotationState) {
/* 1660 */     Map<DotName, Type> ownerMap = buildOwnerMap(type);
/* 1661 */     ArrayDeque<InnerClassInfo> classes = buildClassesQueue(type);
/*      */ 
/*      */     
/* 1664 */     if (!classes.isEmpty() && Modifier.isStatic((classes.getFirst()).flags)) {
/* 1665 */       depth++;
/*      */     }
/*      */     
/* 1668 */     Type last = null;
/* 1669 */     for (InnerClassInfo current : classes) {
/* 1670 */       DotName currentName = current.innerClass;
/* 1671 */       depth--;
/*      */       
/* 1673 */       if (ownerMap.containsKey(currentName)) {
/* 1674 */         last = ownerMap.get(currentName);
/*      */       }
/*      */       
/* 1677 */       if (depth == 0) {
/* 1678 */         return searchTypePath((last == null) ? type : last, typeAnnotationState);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1683 */     if (hasAnonymousEncloser(typeAnnotationState)) {
/* 1684 */       return searchTypePath(type, typeAnnotationState);
/*      */     }
/* 1686 */     if (depth > 0 && hasLocalEncloser(typeAnnotationState)) {
/* 1687 */       return searchTypePath(type, typeAnnotationState);
/*      */     }
/*      */     
/* 1690 */     if (last == null) {
/* 1691 */       throw new IllegalStateException("Required class information is missing");
/*      */     }
/*      */     
/* 1694 */     return last;
/*      */   }
/*      */   
/*      */   private boolean hasAnonymousEncloser(TypeAnnotationState typeAnnotationState) {
/* 1698 */     return (typeAnnotationState.target instanceof ClassExtendsTypeTarget && typeAnnotationState
/* 1699 */       .target.enclosingTarget().asClass().nestingType() == ClassInfo.NestingType.ANONYMOUS);
/*      */   }
/*      */   
/*      */   private boolean hasLocalEncloser(TypeAnnotationState typeAnnotationState) {
/* 1703 */     if (typeAnnotationState.target instanceof ClassExtendsTypeTarget && typeAnnotationState
/* 1704 */       .target.enclosingTarget().asClass().nestingType() == ClassInfo.NestingType.LOCAL) {
/* 1705 */       return true;
/*      */     }
/*      */     
/* 1708 */     AnnotationTarget enclosingTarget = typeAnnotationState.target.enclosingTarget();
/*      */     
/* 1710 */     ClassInfo enclosingClass = null;
/* 1711 */     if (enclosingTarget.kind() == AnnotationTarget.Kind.FIELD) {
/* 1712 */       enclosingClass = enclosingTarget.asField().declaringClass();
/* 1713 */     } else if (enclosingTarget.kind() == AnnotationTarget.Kind.METHOD) {
/* 1714 */       enclosingClass = enclosingTarget.asMethod().declaringClass();
/* 1715 */     } else if (enclosingTarget.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/* 1716 */       enclosingClass = enclosingTarget.asMethodParameter().method().declaringClass();
/* 1717 */     } else if (enclosingTarget.kind() == AnnotationTarget.Kind.RECORD_COMPONENT) {
/* 1718 */       enclosingClass = enclosingTarget.asRecordComponent().declaringClass();
/*      */     } 
/*      */     
/* 1721 */     return (enclosingClass != null && enclosingClass.nestingType() == ClassInfo.NestingType.LOCAL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DotName outermostAnnotableTypeName(Type type) {
/* 1735 */     DotName name = type.name();
/* 1736 */     if (!this.innerClasses.containsKey(name)) {
/* 1737 */       return name;
/*      */     }
/*      */     
/*      */     while (true) {
/* 1741 */       InnerClassInfo info = this.innerClasses.get(name);
/* 1742 */       if (Modifier.isStatic(info.flags)) {
/* 1743 */         return info.innerClass;
/*      */       }
/*      */       
/* 1746 */       name = info.enclosingClass;
/* 1747 */       if (!this.innerClasses.containsKey(name)) {
/* 1748 */         return name;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayDeque<InnerClassInfo> buildClassesQueue(Type type) {
/* 1761 */     ArrayDeque<InnerClassInfo> result = new ArrayDeque<>();
/*      */     
/* 1763 */     InnerClassInfo info = this.innerClasses.get(type.name());
/* 1764 */     while (info != null) {
/* 1765 */       result.addFirst(info);
/* 1766 */       if (Modifier.isStatic(info.flags)) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1772 */       DotName name = info.enclosingClass;
/* 1773 */       info = (name != null) ? this.innerClasses.get(name) : null;
/*      */     } 
/*      */     
/* 1776 */     return result;
/*      */   }
/*      */   
/*      */   private Map<DotName, Type> buildOwnerMap(Type type) {
/* 1780 */     Map<DotName, Type> owners = new HashMap<>();
/*      */     while (true) {
/* 1782 */       owners.put(type.name(), type);
/* 1783 */       type = (type instanceof ParameterizedType) ? type.asParameterizedType().owner() : null;
/* 1784 */       if (type == null)
/* 1785 */         return owners; 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class PathElement { private enum Kind {
/* 1790 */       ARRAY,
/* 1791 */       NESTED,
/* 1792 */       WILDCARD_BOUND,
/* 1793 */       PARAMETERIZED;
/*      */     }
/*      */     
/* 1796 */     private static Kind[] KINDS = Kind.values();
/*      */     private Kind kind;
/*      */     private int pos;
/*      */     
/*      */     private PathElement(Kind kind, int pos) {
/* 1801 */       this.kind = kind;
/* 1802 */       this.pos = pos;
/*      */     } }
/*      */   
/*      */   private enum Kind { ARRAY, NESTED, WILDCARD_BOUND, PARAMETERIZED; }
/*      */   
/*      */   private static class PathElementStack { private int elementPos;
/*      */     private final ArrayList<Indexer.PathElement> pathElements;
/*      */     
/*      */     PathElementStack(ArrayList<Indexer.PathElement> pathElements) {
/* 1811 */       this.pathElements = pathElements;
/*      */     }
/*      */     
/*      */     Indexer.PathElement pop() {
/* 1815 */       if (this.elementPos >= this.pathElements.size()) {
/* 1816 */         return null;
/*      */       }
/*      */       
/* 1819 */       return this.pathElements.get(this.elementPos++);
/*      */     }
/*      */     
/*      */     Indexer.PathElement peek() {
/* 1823 */       return this.pathElements.get(this.elementPos);
/*      */     }
/*      */     
/*      */     int size() {
/* 1827 */       return this.pathElements.size() - this.elementPos;
/*      */     }
/*      */     
/*      */     void reset() {
/* 1831 */       this.elementPos = 0;
/*      */     } }
/*      */ 
/*      */   
/*      */   private static class TypeAnnotationState
/*      */   {
/*      */     private final TypeTarget target;
/*      */     private final AnnotationInstance annotation;
/*      */     private final boolean genericsRequired;
/*      */     private final boolean bridgeIncompatible;
/*      */     private final Indexer.PathElementStack pathElements;
/*      */     
/*      */     TypeAnnotationState(TypeTarget target, AnnotationInstance annotation, ArrayList<Indexer.PathElement> pathElements, boolean genericsRequired, boolean bridgeIncompatible) {
/* 1844 */       this.target = target;
/* 1845 */       this.annotation = annotation;
/* 1846 */       this.pathElements = new Indexer.PathElementStack(pathElements);
/* 1847 */       this.genericsRequired = genericsRequired;
/* 1848 */       this.bridgeIncompatible = bridgeIncompatible;
/*      */     } }
/*      */   
/*      */   private static class BooleanHolder {
/*      */     boolean bool;
/*      */     
/*      */     private BooleanHolder() {}
/*      */   }
/*      */   
/*      */   private ArrayList<PathElement> processTargetPath(DataInputStream data, BooleanHolder genericsRequired, BooleanHolder bridgeIncompatible) throws IOException {
/* 1858 */     int numElements = data.readUnsignedByte();
/*      */     
/* 1860 */     ArrayList<PathElement> elements = new ArrayList<>(numElements);
/* 1861 */     for (int i = 0; i < numElements; i++) {
/* 1862 */       int kindIndex = data.readUnsignedByte();
/* 1863 */       int pos = data.readUnsignedByte();
/* 1864 */       PathElement.Kind kind = PathElement.KINDS[kindIndex];
/* 1865 */       if (kind == PathElement.Kind.WILDCARD_BOUND || kind == PathElement.Kind.PARAMETERIZED) {
/* 1866 */         genericsRequired.bool = true;
/* 1867 */       } else if (kind == PathElement.Kind.ARRAY || kind == PathElement.Kind.NESTED) {
/* 1868 */         bridgeIncompatible.bool = true;
/*      */       } 
/* 1870 */       elements.add(new PathElement(kind, pos));
/*      */     } 
/*      */     
/* 1873 */     return elements;
/*      */   }
/*      */   
/*      */   private void skipTargetPath(DataInputStream data) throws IOException {
/* 1877 */     int numElements = data.readUnsignedByte();
/* 1878 */     skipFully(data, (numElements * 2));
/*      */   }
/*      */   
/*      */   private void processExceptions(DataInputStream data, MethodInfo target) throws IOException {
/* 1882 */     int numExceptions = data.readUnsignedShort();
/*      */     
/* 1884 */     Type[] exceptions = (numExceptions <= 0) ? Type.EMPTY_ARRAY : new Type[numExceptions];
/* 1885 */     for (int i = 0; i < numExceptions; i++) {
/* 1886 */       exceptions[i] = intern(new ClassType(decodeClassEntry(data.readUnsignedShort())));
/*      */     }
/*      */ 
/*      */     
/* 1890 */     if (numExceptions > 0 && target.exceptions().size() == 0) {
/* 1891 */       target.setExceptions(exceptions);
/*      */     }
/*      */   }
/*      */   
/*      */   private void processSignature(DataInputStream data, AnnotationTarget target) throws IOException {
/* 1896 */     String signature = decodeUtf8Entry(data.readUnsignedShort());
/* 1897 */     if (target instanceof ClassInfo) {
/* 1898 */       this.classSignatureIndex = this.signatures.size();
/*      */     }
/* 1900 */     this.signatures.add(signature);
/* 1901 */     this.signatures.add(target);
/* 1902 */     this.signaturePresent.put(target, null);
/*      */   }
/*      */   
/*      */   private void applySignatures() {
/* 1906 */     int end = this.signatures.size();
/*      */ 
/*      */     
/* 1909 */     this.signatureParser.beforeNewClass(this.currentClass.name());
/* 1910 */     if (this.classSignatureIndex >= 0) {
/* 1911 */       String elementSignature = (String)this.signatures.get(this.classSignatureIndex);
/* 1912 */       Object element = this.signatures.get(this.classSignatureIndex + 1);
/* 1913 */       parseClassSignature(elementSignature, (ClassInfo)element);
/*      */     } 
/*      */     
/* 1916 */     for (int i = 0; i < end; i += 2) {
/* 1917 */       if (i != this.classSignatureIndex) {
/*      */ 
/*      */ 
/*      */         
/* 1921 */         this.signatureParser.beforeNewElement();
/*      */         
/* 1923 */         String elementSignature = (String)this.signatures.get(i);
/* 1924 */         Object element = this.signatures.get(i + 1);
/*      */         
/* 1926 */         if (element instanceof FieldInfo) {
/* 1927 */           parseFieldSignature(elementSignature, (FieldInfo)element);
/* 1928 */         } else if (element instanceof MethodInfo) {
/* 1929 */           parseMethodSignature(elementSignature, (MethodInfo)element);
/* 1930 */         } else if (element instanceof RecordComponentInfo) {
/* 1931 */           parseRecordComponentSignature(elementSignature, (RecordComponentInfo)element);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void parseClassSignature(String signature, ClassInfo clazz) {
/*      */     GenericSignatureParser.ClassSignature classSignature;
/*      */     try {
/* 1939 */       classSignature = this.signatureParser.parseClassSignature(signature, clazz.name());
/* 1940 */     } catch (Exception e) {
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1946 */     clazz.setInterfaceTypes(classSignature.interfaces());
/* 1947 */     clazz.setSuperClassType(classSignature.superClass());
/* 1948 */     clazz.setTypeParameters(classSignature.parameters());
/*      */   }
/*      */   
/*      */   private void parseFieldSignature(String signature, FieldInfo field) {
/*      */     Type type;
/*      */     try {
/* 1954 */       type = this.signatureParser.parseFieldSignature(signature);
/* 1955 */     } catch (Exception e) {
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1961 */     field.setType(type);
/*      */   }
/*      */   
/*      */   private void parseMethodSignature(String signature, MethodInfo method) {
/*      */     GenericSignatureParser.MethodSignature methodSignature;
/*      */     try {
/* 1967 */       methodSignature = this.signatureParser.parseMethodSignature(signature);
/* 1968 */     } catch (Exception e) {
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1974 */     method.setParameters(methodSignature.methodParameters());
/* 1975 */     method.setReturnType(methodSignature.returnType());
/* 1976 */     method.setTypeParameters(methodSignature.typeParameters());
/* 1977 */     if ((methodSignature.throwables()).length > 0) {
/* 1978 */       method.setExceptions(methodSignature.throwables());
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseRecordComponentSignature(String signature, RecordComponentInfo recordComponent) {
/* 1983 */     Type type = null;
/*      */     
/*      */     try {
/* 1986 */       type = this.signatureParser.parseFieldSignature(signature);
/* 1987 */     } catch (Exception e) {
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1993 */     recordComponent.setType(type);
/*      */   }
/*      */ 
/*      */   
/*      */   private AnnotationInstance processAnnotation(DataInputStream data, AnnotationTarget target, boolean visible) throws IOException {
/* 1998 */     String annotation = convertClassFieldDescriptor(decodeUtf8Entry(data.readUnsignedShort()));
/* 1999 */     int valuePairs = data.readUnsignedShort();
/*      */     
/* 2001 */     AnnotationValue[] values = new AnnotationValue[valuePairs];
/* 2002 */     for (int v = 0; v < valuePairs; v++) {
/* 2003 */       String name = intern(decodeUtf8Entry(data.readUnsignedShort()));
/* 2004 */       values[v] = processAnnotationElementValue(name, data);
/*      */     } 
/*      */ 
/*      */     
/* 2008 */     Arrays.sort(values, new Comparator<AnnotationValue>() {
/*      */           public int compare(AnnotationValue o1, AnnotationValue o2) {
/* 2010 */             return o1.name().compareTo(o2.name());
/*      */           }
/*      */         });
/*      */     
/* 2014 */     DotName annotationName = this.names.convertToName(annotation);
/* 2015 */     AnnotationInstance instance = AnnotationInstance.create(annotationName, visible, target, values);
/*      */ 
/*      */     
/* 2018 */     if (target != null) {
/* 2019 */       recordAnnotation(this.classAnnotations, annotationName, instance);
/* 2020 */       recordAnnotation(this.masterAnnotations, annotationName, instance);
/*      */       
/* 2022 */       if (target instanceof FieldInfo || target instanceof MethodInfo || target instanceof MethodParameterInfo || target instanceof RecordComponentInfo || (target instanceof TypeTarget && ((TypeTarget)target)
/*      */ 
/*      */         
/* 2025 */         .enclosingTarget().kind() != AnnotationTarget.Kind.CLASS)) {
/* 2026 */         this.elementAnnotations.add(instance);
/*      */       }
/*      */     } 
/*      */     
/* 2030 */     return instance;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void recordAnnotation(Map<DotName, List<AnnotationInstance>> classAnnotations, DotName annotation, AnnotationInstance instance) {
/* 2036 */     List<AnnotationInstance> list = classAnnotations.get(annotation);
/* 2037 */     if (list == null) {
/* 2038 */       list = new ArrayList<>();
/* 2039 */       classAnnotations.put(annotation, list);
/*      */     } 
/*      */     
/* 2042 */     list.add(instance);
/*      */   }
/*      */   
/*      */   private String intern(String string) {
/* 2046 */     return this.names.intern(string);
/*      */   }
/*      */   
/*      */   private byte[] intern(byte[] bytes) {
/* 2050 */     return this.names.intern(bytes);
/*      */   }
/*      */   
/*      */   private Type intern(Type type) {
/* 2054 */     return this.names.intern(type);
/*      */   }
/*      */   
/*      */   private Type[] intern(Type[] type) {
/* 2058 */     return this.names.intern(type); } private AnnotationValue processAnnotationElementValue(String name, DataInputStream data) throws IOException { DotName type;
/*      */     int numValues;
/*      */     String value;
/*      */     AnnotationValue[] values;
/* 2062 */     int i, tag = data.readUnsignedByte();
/* 2063 */     switch (tag) {
/*      */       case 66:
/* 2065 */         return new AnnotationValue.ByteValue(name, (byte)decodeIntegerEntry(data.readUnsignedShort()));
/*      */       case 67:
/* 2067 */         return new AnnotationValue.CharacterValue(name, (char)decodeIntegerEntry(data.readUnsignedShort()));
/*      */       case 73:
/* 2069 */         return new AnnotationValue.IntegerValue(name, decodeIntegerEntry(data.readUnsignedShort()));
/*      */       case 83:
/* 2071 */         return new AnnotationValue.ShortValue(name, (short)decodeIntegerEntry(data.readUnsignedShort()));
/*      */       
/*      */       case 90:
/* 2074 */         return new AnnotationValue.BooleanValue(name, (decodeIntegerEntry(data.readUnsignedShort()) > 0));
/*      */       
/*      */       case 70:
/* 2077 */         return new AnnotationValue.FloatValue(name, decodeFloatEntry(data.readUnsignedShort()));
/*      */       
/*      */       case 68:
/* 2080 */         return new AnnotationValue.DoubleValue(name, decodeDoubleEntry(data.readUnsignedShort()));
/*      */       case 74:
/* 2082 */         return new AnnotationValue.LongValue(name, decodeLongEntry(data.readUnsignedShort()));
/*      */       
/*      */       case 115:
/* 2085 */         return new AnnotationValue.StringValue(name, decodeUtf8Entry(data.readUnsignedShort()));
/*      */       case 99:
/* 2087 */         return new AnnotationValue.ClassValue(name, parseType(decodeUtf8Entry(data.readUnsignedShort())));
/*      */       case 101:
/* 2089 */         type = parseType(decodeUtf8Entry(data.readUnsignedShort())).name();
/* 2090 */         value = decodeUtf8Entry(data.readUnsignedShort());
/* 2091 */         return new AnnotationValue.EnumValue(name, type, value);
/*      */       
/*      */       case 64:
/* 2094 */         return new AnnotationValue.NestedAnnotation(name, processAnnotation(data, null, true));
/*      */       case 91:
/* 2096 */         numValues = data.readUnsignedShort();
/* 2097 */         values = new AnnotationValue[numValues];
/* 2098 */         for (i = 0; i < numValues; i++)
/* 2099 */           values[i] = processAnnotationElementValue("", data); 
/* 2100 */         return new AnnotationValue.ArrayValue(name, values);
/*      */     } 
/*      */     
/* 2103 */     throw new IllegalStateException("Invalid tag value: " + tag); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processClassInfo(DataInputStream data) throws IOException {
/* 2109 */     short flags = (short)data.readUnsignedShort();
/* 2110 */     DotName thisName = decodeClassEntry(data.readUnsignedShort());
/* 2111 */     int superIndex = data.readUnsignedShort();
/* 2112 */     DotName superName = (superIndex != 0) ? decodeClassEntry(superIndex) : null;
/*      */     
/* 2114 */     int numInterfaces = data.readUnsignedShort();
/* 2115 */     List<Type> interfaces = new ArrayList<>(numInterfaces);
/*      */     
/* 2117 */     for (int i = 0; i < numInterfaces; i++) {
/* 2118 */       interfaces.add(intern(new ClassType(decodeClassEntry(data.readUnsignedShort()))));
/*      */     }
/* 2120 */     Type[] interfaceTypes = intern(interfaces.<Type>toArray(new Type[interfaces.size()]));
/* 2121 */     Type superClassType = (superName == null) ? null : intern(new ClassType(superName));
/*      */     
/* 2123 */     this.currentClass = new ClassInfo(thisName, superClassType, flags, interfaceTypes);
/*      */     
/* 2125 */     if (superName != null) {
/* 2126 */       addSubclass(superName, this.currentClass);
/*      */     }
/* 2128 */     for (int j = 0; j < numInterfaces; j++) {
/* 2129 */       DotName superInterface = ((Type)interfaces.get(j)).name();
/*      */ 
/*      */       
/* 2132 */       addImplementor(superInterface, this.currentClass);
/* 2133 */       if (Modifier.isInterface(this.currentClass.flags())) {
/* 2134 */         addSubinterface(superInterface, this.currentClass);
/*      */       }
/*      */     } 
/*      */     
/* 2138 */     if (!this.currentClass.isModule()) {
/* 2139 */       this.classes.put(this.currentClass.name(), this.currentClass);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addSubclass(DotName superName, ClassInfo currentClass) {
/* 2144 */     List<ClassInfo> list = this.subclasses.get(superName);
/* 2145 */     if (list == null) {
/* 2146 */       list = new ArrayList<>();
/* 2147 */       this.subclasses.put(superName, list);
/*      */     } 
/*      */     
/* 2150 */     list.add(currentClass);
/*      */   }
/*      */   
/*      */   private void addSubinterface(DotName superName, ClassInfo currentClass) {
/* 2154 */     List<ClassInfo> list = this.subinterfaces.get(superName);
/* 2155 */     if (list == null) {
/* 2156 */       list = new ArrayList<>();
/* 2157 */       this.subinterfaces.put(superName, list);
/*      */     } 
/*      */     
/* 2160 */     list.add(currentClass);
/*      */   }
/*      */   
/*      */   private void addImplementor(DotName interfaceName, ClassInfo currentClass) {
/* 2164 */     List<ClassInfo> list = this.implementors.get(interfaceName);
/* 2165 */     if (list == null) {
/* 2166 */       list = new ArrayList<>();
/* 2167 */       this.implementors.put(interfaceName, list);
/*      */     } 
/*      */     
/* 2170 */     list.add(currentClass);
/*      */   }
/*      */   
/*      */   private boolean isJDK11OrNewer(DataInputStream stream) throws IOException {
/* 2174 */     int minor = stream.readUnsignedShort();
/* 2175 */     int major = stream.readUnsignedShort();
/* 2176 */     return (major > 45 || (major == 45 && minor >= 3));
/*      */   }
/*      */   
/*      */   private void verifyMagic(DataInputStream stream) throws IOException {
/*      */     int magic;
/*      */     try {
/* 2182 */       magic = stream.readInt();
/* 2183 */     } catch (EOFException e) {
/* 2184 */       throw new EOFException("Input is not a valid class file; must begin with a 4-byte integer 0xCAFEBABE");
/*      */     } 
/* 2186 */     if (magic != -889275714) {
/* 2187 */       throw new IOException("Input is not a valid class file; must begin with a 4-byte integer 0xCAFEBABE, but seen 0x" + 
/* 2188 */           Integer.toHexString(magic).toUpperCase());
/*      */     }
/*      */   }
/*      */   
/*      */   private DotName decodeClassEntry(int index) throws IOException {
/* 2193 */     return (index == 0) ? null : decodeDotNameEntry(index, 7, "Class_info", '/');
/*      */   }
/*      */   
/*      */   private DotName decodeModuleEntry(int index) throws IOException {
/* 2197 */     return (index == 0) ? null : decodeDotNameEntry(index, 19, "Module_info", '.');
/*      */   }
/*      */   
/*      */   private DotName decodePackageEntry(int index) throws IOException {
/* 2201 */     return (index == 0) ? null : decodeDotNameEntry(index, 20, "Package_info", '/');
/*      */   }
/*      */   
/*      */   private DotName decodeDotNameEntry(int index, int constantType, String typeName, char delim) throws IOException {
/* 2205 */     byte[] pool = this.constantPool;
/* 2206 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2208 */     int pos = offsets[index - 1];
/*      */     
/* 2210 */     if (pool[pos] != constantType) {
/* 2211 */       throw new IllegalStateException(
/* 2212 */           String.format(Locale.ROOT, "Constant pool entry is not a %s type: %d:%d", new Object[] { typeName, Integer.valueOf(index), Integer.valueOf(pos) }));
/*      */     }
/*      */     
/* 2215 */     int nameIndex = (pool[++pos] & 0xFF) << 8 | pool[++pos] & 0xFF;
/* 2216 */     return this.names.convertToName(decodeUtf8Entry(nameIndex), delim);
/*      */   }
/*      */   
/*      */   private String decodeOptionalUtf8Entry(int index) throws IOException {
/* 2220 */     return (index == 0) ? null : decodeUtf8Entry(index);
/*      */   }
/*      */   
/*      */   private String decodeUtf8Entry(int index) throws IOException {
/* 2224 */     byte[] pool = this.constantPool;
/* 2225 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2227 */     int pos = offsets[index - 1];
/* 2228 */     if (pool[pos] != 1) {
/* 2229 */       throw new IllegalStateException("Constant pool entry is not a utf8 info type: " + index + ":" + pos);
/*      */     }
/* 2231 */     pos++;
/*      */     
/* 2233 */     int len = (pool[pos] & 0xFF) << 8 | pool[pos + 1] & 0xFF;
/* 2234 */     if (BitTricks.isAsciiOnly(pool, pos + 2, len))
/*      */     {
/* 2236 */       return new String(pool, 0, pos + 2, len);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2241 */     return (new DataInputStream(new ByteArrayInputStream(pool, pos, len + 2))).readUTF();
/*      */   }
/*      */   
/*      */   private byte[] decodeUtf8EntryAsBytes(int index) {
/* 2245 */     byte[] pool = this.constantPool;
/* 2246 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2248 */     int pos = offsets[index - 1];
/* 2249 */     if (pool[pos] != 1) {
/* 2250 */       throw new IllegalStateException("Constant pool entry is not a utf8 info type: " + index + ":" + pos);
/*      */     }
/* 2252 */     int len = (pool[++pos] & 0xFF) << 8 | pool[++pos] & 0xFF;
/*      */     
/* 2254 */     return Arrays.copyOfRange(pool, ++pos, len + pos);
/*      */   }
/*      */   
/*      */   private static class NameAndType {
/*      */     private String name;
/*      */     private String descriptor;
/*      */     
/*      */     private NameAndType(String name, String descriptor) {
/* 2262 */       this.name = name;
/* 2263 */       this.descriptor = descriptor;
/*      */     }
/*      */   }
/*      */   
/*      */   private NameAndType decodeNameAndTypeEntry(int index) throws IOException {
/* 2268 */     byte[] pool = this.constantPool;
/* 2269 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2271 */     int pos = offsets[index - 1];
/* 2272 */     if (pool[pos] != 12) {
/* 2273 */       throw new IllegalStateException("Constant pool entry is not a name and type type: " + index + ":" + pos);
/*      */     }
/* 2275 */     int nameIndex = (pool[++pos] & 0xFF) << 8 | pool[++pos] & 0xFF;
/* 2276 */     int descriptorIndex = (pool[++pos] & 0xFF) << 8 | pool[++pos] & 0xFF;
/*      */     
/* 2278 */     return new NameAndType(intern(decodeUtf8Entry(nameIndex)), decodeUtf8Entry(descriptorIndex));
/*      */   }
/*      */   
/*      */   private int bitsToInt(byte[] pool, int pos) {
/* 2282 */     return (pool[++pos] & 0xFF) << 24 | (pool[++pos] & 0xFF) << 16 | (pool[++pos] & 0xFF) << 8 | pool[++pos] & 0xFF;
/*      */   }
/*      */   
/*      */   private long bitsToLong(byte[] pool, int pos) {
/* 2286 */     return (pool[++pos] & 0xFF) << 56L | (pool[++pos] & 0xFF) << 48L | (pool[++pos] & 0xFF) << 40L | (pool[++pos] & 0xFF) << 32L | (pool[++pos] & 0xFF) << 24L | (pool[++pos] & 0xFF) << 16L | (pool[++pos] & 0xFF) << 8L | (pool[++pos] & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int decodeIntegerEntry(int index) {
/* 2297 */     byte[] pool = this.constantPool;
/* 2298 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2300 */     int pos = offsets[index - 1];
/* 2301 */     if (pool[pos] != 3) {
/* 2302 */       throw new IllegalStateException("Constant pool entry is not an integer info type: " + index + ":" + pos);
/*      */     }
/* 2304 */     return bitsToInt(pool, pos);
/*      */   }
/*      */   
/*      */   private long decodeLongEntry(int index) {
/* 2308 */     byte[] pool = this.constantPool;
/* 2309 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2311 */     int pos = offsets[index - 1];
/* 2312 */     if (pool[pos] != 5) {
/* 2313 */       throw new IllegalStateException("Constant pool entry is not an long info type: " + index + ":" + pos);
/*      */     }
/* 2315 */     return bitsToLong(pool, pos);
/*      */   }
/*      */   
/*      */   private float decodeFloatEntry(int index) {
/* 2319 */     byte[] pool = this.constantPool;
/* 2320 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2322 */     int pos = offsets[index - 1];
/* 2323 */     if (pool[pos] != 4) {
/* 2324 */       throw new IllegalStateException("Constant pool entry is not an float info type: " + index + ":" + pos);
/*      */     }
/* 2326 */     return Float.intBitsToFloat(bitsToInt(pool, pos));
/*      */   }
/*      */   
/*      */   private double decodeDoubleEntry(int index) {
/* 2330 */     byte[] pool = this.constantPool;
/* 2331 */     int[] offsets = this.constantPoolOffsets;
/*      */     
/* 2333 */     int pos = offsets[index - 1];
/* 2334 */     if (pool[pos] != 6) {
/* 2335 */       throw new IllegalStateException("Constant pool entry is not an double info type: " + index + ":" + pos);
/*      */     }
/* 2337 */     return Double.longBitsToDouble(bitsToLong(pool, pos));
/*      */   }
/*      */   
/*      */   private static String convertClassFieldDescriptor(String descriptor) {
/* 2341 */     if (descriptor.charAt(0) != 'L')
/* 2342 */       throw new IllegalArgumentException("Non class descriptor: " + descriptor); 
/* 2343 */     return descriptor.substring(1, descriptor.length() - 1).replace('/', '.');
/*      */   }
/*      */   private static class IntegerHolder {
/*      */     private int i;
/*      */     
/*      */     private IntegerHolder() {} }
/*      */   
/*      */   private Type[] parseMethodArgs(String descriptor, IntegerHolder pos) {
/* 2351 */     if (descriptor.charAt(pos.i) != '(') {
/* 2352 */       throw new IllegalArgumentException("Invalid descriptor: " + descriptor);
/*      */     }
/* 2354 */     ArrayList<Type> types = new ArrayList<>();
/* 2355 */     while (descriptor.charAt(++pos.i) != ')') {
/* 2356 */       types.add(parseType(descriptor, pos));
/*      */     }
/*      */     
/* 2359 */     pos.i++;
/* 2360 */     return types.<Type>toArray(new Type[types.size()]);
/*      */   }
/*      */   
/*      */   private Type parseType(String descriptor) {
/* 2364 */     return parseType(descriptor, new IntegerHolder());
/*      */   }
/*      */   private Type parseType(String descriptor, IntegerHolder pos) {
/*      */     DotName name;
/* 2368 */     int end, depth, start = pos.i;
/*      */     
/* 2370 */     char c = descriptor.charAt(start);
/*      */     
/* 2372 */     Type type = PrimitiveType.decode(c);
/* 2373 */     if (type != null) {
/* 2374 */       return type;
/*      */     }
/*      */ 
/*      */     
/* 2378 */     switch (c) {
/*      */       case 'V':
/* 2380 */         return VoidType.VOID;
/*      */       case 'L':
/* 2382 */         end = start;
/* 2383 */         while (descriptor.charAt(++end) != ';');
/*      */         
/* 2385 */         name = this.names.convertToName(descriptor.substring(start + 1, end), '/');
/* 2386 */         pos.i = end;
/* 2387 */         return this.names.intern(new ClassType(name));
/*      */       
/*      */       case '[':
/* 2390 */         end = start;
/* 2391 */         while (descriptor.charAt(++end) == '[');
/*      */         
/* 2393 */         depth = end - start;
/* 2394 */         pos.i = end;
/* 2395 */         type = parseType(descriptor, pos);
/* 2396 */         return this.names.intern(new ArrayType(type, depth));
/*      */     } 
/*      */     
/* 2399 */     throw new IllegalArgumentException("Invalid descriptor: " + descriptor + " pos " + start);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean processConstantPool(DataInputStream stream) throws IOException {
/* 2404 */     int size = stream.readUnsignedShort() - 1;
/* 2405 */     byte[] buf = this.tmpObjects.borrowConstantPool(size);
/* 2406 */     byte[] annoAttributes = this.tmpObjects.borrowConstantPoolAnnoAttributes(size);
/* 2407 */     int[] offsets = this.tmpObjects.borrowConstantPoolOffsets(size);
/* 2408 */     boolean hasAnnotations = false;
/*      */     
/* 2410 */     for (int pos = 0, offset = 0; pos < size; pos++) {
/* 2411 */       int len, tag = stream.readUnsignedByte();
/* 2412 */       offsets[pos] = offset;
/* 2413 */       switch (tag) {
/*      */         case 7:
/*      */         case 8:
/*      */         case 16:
/*      */         case 19:
/*      */         case 20:
/* 2419 */           buf = sizeToFit(buf, 3, offset, size - pos);
/* 2420 */           buf[offset++] = (byte)tag;
/* 2421 */           stream.readFully(buf, offset, 2);
/* 2422 */           offset += 2;
/*      */           break;
/*      */         case 3:
/*      */         case 4:
/*      */         case 9:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 17:
/*      */         case 18:
/* 2432 */           buf = sizeToFit(buf, 5, offset, size - pos);
/* 2433 */           buf[offset++] = (byte)tag;
/* 2434 */           stream.readFully(buf, offset, 4);
/* 2435 */           offset += 4;
/*      */           break;
/*      */         case 5:
/*      */         case 6:
/* 2439 */           buf = sizeToFit(buf, 9, offset, size - pos);
/* 2440 */           buf[offset++] = (byte)tag;
/* 2441 */           stream.readFully(buf, offset, 8);
/* 2442 */           offset += 8;
/* 2443 */           pos++;
/*      */           break;
/*      */         case 15:
/* 2446 */           buf = sizeToFit(buf, 4, offset, size - pos);
/* 2447 */           buf[offset++] = (byte)tag;
/* 2448 */           stream.readFully(buf, offset, 3);
/* 2449 */           offset += 3;
/*      */           break;
/*      */         case 1:
/* 2452 */           len = stream.readUnsignedShort();
/* 2453 */           buf = sizeToFit(buf, len + 3, offset, size - pos);
/* 2454 */           buf[offset++] = (byte)tag;
/* 2455 */           buf[offset++] = (byte)(len >>> 8);
/* 2456 */           buf[offset++] = (byte)len;
/*      */           
/* 2458 */           stream.readFully(buf, offset, len);
/* 2459 */           if (len == RUNTIME_ANNOTATIONS_LEN && match(buf, offset, RUNTIME_ANNOTATIONS)) {
/* 2460 */             annoAttributes[pos] = 1;
/* 2461 */             hasAnnotations = true;
/* 2462 */           } else if (len == RUNTIME_PARAM_ANNOTATIONS_LEN && match(buf, offset, RUNTIME_PARAM_ANNOTATIONS)) {
/* 2463 */             annoAttributes[pos] = 2;
/* 2464 */             hasAnnotations = true;
/* 2465 */           } else if (len == RUNTIME_TYPE_ANNOTATIONS_LEN && match(buf, offset, RUNTIME_TYPE_ANNOTATIONS)) {
/* 2466 */             annoAttributes[pos] = 3;
/* 2467 */           } else if (len == SIGNATURE_LEN && match(buf, offset, SIGNATURE)) {
/* 2468 */             annoAttributes[pos] = 4;
/* 2469 */           } else if (len == EXCEPTIONS_LEN && match(buf, offset, EXCEPTIONS)) {
/* 2470 */             annoAttributes[pos] = 5;
/* 2471 */           } else if (len == INNER_CLASSES_LEN && match(buf, offset, INNER_CLASSES)) {
/* 2472 */             annoAttributes[pos] = 6;
/* 2473 */           } else if (len == ENCLOSING_METHOD_LEN && match(buf, offset, ENCLOSING_METHOD)) {
/* 2474 */             annoAttributes[pos] = 7;
/* 2475 */           } else if (len == ANNOTATION_DEFAULT_LEN && match(buf, offset, ANNOTATION_DEFAULT)) {
/* 2476 */             annoAttributes[pos] = 8;
/* 2477 */           } else if (len == METHOD_PARAMETERS_LEN && match(buf, offset, METHOD_PARAMETERS)) {
/* 2478 */             annoAttributes[pos] = 9;
/* 2479 */           } else if (len == LOCAL_VARIABLE_TABLE_LEN && match(buf, offset, LOCAL_VARIABLE_TABLE)) {
/* 2480 */             annoAttributes[pos] = 10;
/* 2481 */           } else if (len == CODE_LEN && match(buf, offset, CODE)) {
/* 2482 */             annoAttributes[pos] = 11;
/* 2483 */           } else if (len == MODULE_LEN && match(buf, offset, MODULE)) {
/* 2484 */             annoAttributes[pos] = 12;
/* 2485 */           } else if (len == MODULE_PACKAGES_LEN && match(buf, offset, MODULE_PACKAGES)) {
/* 2486 */             annoAttributes[pos] = 13;
/* 2487 */           } else if (len == MODULE_MAIN_CLASS_LEN && match(buf, offset, MODULE_MAIN_CLASS)) {
/* 2488 */             annoAttributes[pos] = 14;
/* 2489 */           } else if (len == RECORD_LEN && match(buf, offset, RECORD)) {
/* 2490 */             annoAttributes[pos] = 15;
/* 2491 */           } else if (len == RUNTIME_INVISIBLE_ANNOTATIONS_LEN && match(buf, offset, RUNTIME_INVISIBLE_ANNOTATIONS)) {
/* 2492 */             annoAttributes[pos] = 16;
/* 2493 */           } else if (len == RUNTIME_INVISIBLE_PARAM_ANNOTATIONS_LEN && 
/* 2494 */             match(buf, offset, RUNTIME_INVISIBLE_PARAM_ANNOTATIONS)) {
/* 2495 */             annoAttributes[pos] = 17;
/* 2496 */           } else if (len == RUNTIME_INVISIBLE_TYPE_ANNOTATIONS_LEN && 
/* 2497 */             match(buf, offset, RUNTIME_INVISIBLE_TYPE_ANNOTATIONS)) {
/* 2498 */             annoAttributes[pos] = 18;
/* 2499 */           } else if (len == PERMITTED_SUBCLASSES_LEN && match(buf, offset, PERMITTED_SUBCLASSES)) {
/* 2500 */             annoAttributes[pos] = 19;
/*      */           } 
/* 2502 */           offset += len;
/*      */           break;
/*      */         default:
/* 2505 */           throw new IllegalStateException(
/* 2506 */               String.format(Locale.ROOT, "Unknown tag %s! pos = %s poolSize = %s", new Object[] { Integer.valueOf(tag), Integer.valueOf(pos), Integer.valueOf(size) }));
/*      */       } 
/*      */     
/*      */     } 
/* 2510 */     this.constantPoolSize = size;
/* 2511 */     this.constantPool = buf;
/* 2512 */     this.constantPoolOffsets = offsets;
/* 2513 */     this.constantPoolAnnoAttrributes = annoAttributes;
/*      */     
/* 2515 */     return hasAnnotations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void indexClass(Class<?> clazz) throws IOException {
/* 2527 */     if (clazz == null) {
/* 2528 */       throw new IllegalArgumentException("clazz cannot be null");
/*      */     }
/* 2530 */     String resourceName = '/' + clazz.getName().replace('.', '/') + ".class";
/* 2531 */     InputStream resource = clazz.getResourceAsStream(resourceName); try {
/* 2532 */       index(resource);
/* 2533 */       if (resource != null) resource.close();
/*      */     
/*      */     } catch (Throwable throwable) {
/*      */       if (resource != null) {
/*      */         try {
/*      */           resource.close();
/*      */         } catch (Throwable throwable1) {
/*      */           throwable.addSuppressed(throwable1);
/*      */         } 
/*      */       }
/*      */       throw throwable;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void index(InputStream stream) throws IOException {
/* 2552 */     indexWithSummary(stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassSummary indexWithSummary(InputStream stream) throws IOException {
/* 2575 */     if (stream == null) {
/* 2576 */       throw new IllegalArgumentException("stream cannot be null");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */     
/*      */     } finally {
/* 2614 */       this.constantPoolSize = 0;
/* 2615 */       this.tmpObjects.returnConstantPool(this.constantPool);
/* 2616 */       this.constantPool = null;
/* 2617 */       this.tmpObjects.returnConstantPoolOffsets(this.constantPoolOffsets);
/* 2618 */       this.constantPoolOffsets = null;
/* 2619 */       this.tmpObjects.returnConstantAnnoAttributes(this.constantPoolAnnoAttrributes);
/* 2620 */       this.constantPoolAnnoAttrributes = null;
/*      */       
/* 2622 */       this.currentClass = null;
/* 2623 */       this.classAnnotations = null;
/* 2624 */       this.elementAnnotations = null;
/* 2625 */       this.signaturePresent = null;
/* 2626 */       this.signatures = null;
/* 2627 */       this.classSignatureIndex = -1;
/* 2628 */       this.innerClasses = null;
/* 2629 */       this.typeAnnotations = null;
/* 2630 */       this.methods = null;
/* 2631 */       this.fields = null;
/* 2632 */       this.recordComponents = null;
/* 2633 */       this.methodParams = null;
/* 2634 */       this.modulePackages = null;
/* 2635 */       this.moduleMainClass = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Index complete() {
/* 2646 */     initIndexMaps();
/*      */ 
/*      */ 
/*      */     
/* 2650 */     propagateTypeParameterBounds();
/* 2651 */     propagateTypeVariables();
/*      */     
/*      */     try {
/* 2654 */       Map<DotName, List<ClassInfo>> userLists = new HashMap<>();
/* 2655 */       for (Map.Entry<DotName, Set<ClassInfo>> entry : this.users.entrySet()) {
/* 2656 */         userLists.put(entry.getKey(), new ArrayList<>(entry.getValue()));
/*      */       }
/* 2658 */       return Index.create(this.masterAnnotations, this.subclasses, this.subinterfaces, this.implementors, this.classes, this.modules, userLists);
/*      */     } finally {
/* 2660 */       this.masterAnnotations = null;
/* 2661 */       this.subclasses = null;
/* 2662 */       this.subinterfaces = null;
/* 2663 */       this.implementors = null;
/* 2664 */       this.classes = null;
/* 2665 */       this.modules = null;
/* 2666 */       this.users = null;
/* 2667 */       this.names = null;
/* 2668 */       this.signatureParser = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void propagateTypeParameterBounds() {
/* 2682 */     final Map<DotName, Integer> nestingLevels = new HashMap<>();
/* 2683 */     for (ClassInfo clazz : this.classes.values()) {
/* 2684 */       DotName name = clazz.name();
/* 2685 */       int nestingLevel = 0;
/* 2686 */       while (clazz != null) {
/* 2687 */         if (clazz.enclosingClass() != null) {
/* 2688 */           clazz = this.classes.get(clazz.enclosingClass());
/* 2689 */           nestingLevel++; continue;
/* 2690 */         }  if (clazz.enclosingMethod() != null) {
/* 2691 */           clazz = this.classes.get(clazz.enclosingMethod().enclosingClass());
/* 2692 */           nestingLevel++; continue;
/*      */         } 
/* 2694 */         clazz = null;
/*      */       } 
/*      */       
/* 2697 */       nestingLevels.put(name, Integer.valueOf(nestingLevel));
/*      */     } 
/*      */     
/* 2700 */     List<ClassInfo> classes = new ArrayList<>(this.classes.values());
/* 2701 */     classes.sort(new Comparator<ClassInfo>()
/*      */         {
/*      */           public int compare(ClassInfo c1, ClassInfo c2) {
/* 2704 */             int diff = Integer.compare(((Integer)nestingLevels.get(c1.name())).intValue(), ((Integer)nestingLevels.get(c2.name())).intValue());
/* 2705 */             if (diff != 0) {
/* 2706 */               return diff;
/*      */             }
/* 2708 */             return c1.name().compareTo(c2.name());
/*      */           }
/*      */         });
/*      */ 
/*      */     
/* 2713 */     Deque<TypeVariable> sharedTypeVarStack = new ArrayDeque<>();
/*      */     
/* 2715 */     for (ClassInfo clazz : classes) {
/* 2716 */       propagateTypeParameterBounds(clazz, sharedTypeVarStack);
/* 2717 */       for (MethodInfo method : clazz.methods()) {
/* 2718 */         propagateTypeParameterBounds(method, sharedTypeVarStack);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void propagateTypeParameterBounds(AnnotationTarget target, Deque<TypeVariable> sharedTypeVarStack) {
/* 2724 */     Type[] typeParameters = copyTypeParameters(target);
/*      */     int i;
/* 2726 */     for (i = 0; i < typeParameters.length; i++) {
/* 2727 */       TypeVariable typeParameter = (TypeVariable)typeParameters[i];
/* 2728 */       Type[] typeParameterBounds = (Type[])typeParameter.boundArray().clone();
/* 2729 */       for (int j = 0; j < typeParameterBounds.length; j++) {
/* 2730 */         Type typeParameterBound = typeParameterBounds[j];
/*      */         
/* 2732 */         Type newTypeParameterBound = propagateOneTypeParameterBound(typeParameterBound, typeParameters, target);
/* 2733 */         if (newTypeParameterBound != typeParameterBound) {
/* 2734 */           Type newTypeParameter = intern(typeParameter.copyType(j, newTypeParameterBound));
/* 2735 */           typeParameters[i] = newTypeParameter;
/*      */           
/* 2737 */           retargetTypeAnnotations(target, typeParameter, newTypeParameter);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2745 */     setTypeParameters(target, intern(typeParameters));
/*      */ 
/*      */ 
/*      */     
/* 2749 */     for (i = 0; i < typeParameters.length; i++) {
/* 2750 */       sharedTypeVarStack.clear();
/* 2751 */       patchTypeVariableReferences(typeParameters[i], sharedTypeVarStack, target);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private Type propagateOneTypeParameterBound(Type type, Type[] allTypeParams, AnnotationTarget target) {
/* 2757 */     if (type.kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE || type.kind() == Type.Kind.TYPE_VARIABLE) {
/* 2758 */       String identifier = getTypeVariableIdentifier(type);
/* 2759 */       TypeVariable resolved = findTypeParameter(allTypeParams, identifier);
/* 2760 */       if (resolved == null) {
/* 2761 */         resolved = resolveTypeParameter(target, identifier);
/*      */       }
/* 2763 */       if (resolved != null) {
/*      */ 
/*      */ 
/*      */         
/* 2767 */         Type newTypeVariable = intern(deepCopyTypeIfNeeded(resolved).copyType(type.annotationArray()));
/* 2768 */         retargetTypeAnnotations(target, type, newTypeVariable);
/* 2769 */         return newTypeVariable;
/*      */       } 
/* 2771 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 2772 */       ParameterizedType parameterized = type.asParameterizedType();
/* 2773 */       if (parameterized.owner() != null) {
/* 2774 */         Type newOwner = propagateOneTypeParameterBound(parameterized.owner(), allTypeParams, target);
/* 2775 */         if (parameterized.owner() != newOwner) {
/* 2776 */           parameterized = (ParameterizedType)intern(parameterized.copyType(newOwner));
/*      */         }
/*      */       } 
/* 2779 */       Type[] typeArguments = parameterized.argumentsArray();
/* 2780 */       for (int i = 0; i < typeArguments.length; i++) {
/* 2781 */         Type newTypeArgument = propagateOneTypeParameterBound(typeArguments[i], allTypeParams, target);
/* 2782 */         if (newTypeArgument != typeArguments[i]) {
/* 2783 */           parameterized = (ParameterizedType)intern(parameterized.copyType(i, newTypeArgument));
/*      */         }
/*      */       } 
/* 2786 */       if (parameterized != type) {
/* 2787 */         retargetTypeAnnotations(target, type, parameterized);
/* 2788 */         return parameterized;
/*      */       } 
/* 2790 */     } else if (type.kind() == Type.Kind.WILDCARD_TYPE) {
/* 2791 */       WildcardType wildcard = type.asWildcardType();
/* 2792 */       Type newBound = propagateOneTypeParameterBound(wildcard.bound(), allTypeParams, target);
/* 2793 */       if (newBound != wildcard.bound()) {
/* 2794 */         Type newWildcard = intern(wildcard.copyType(newBound));
/* 2795 */         retargetTypeAnnotations(target, type, newWildcard);
/* 2796 */         return newWildcard;
/*      */       } 
/* 2798 */     } else if (type.kind() == Type.Kind.ARRAY) {
/* 2799 */       ArrayType array = type.asArrayType();
/* 2800 */       Type newComponent = propagateOneTypeParameterBound(array.component(), allTypeParams, target);
/* 2801 */       if (newComponent != array.component()) {
/* 2802 */         Type newArray = intern(array.copyType(newComponent, array.dimensions()));
/* 2803 */         retargetTypeAnnotations(target, type, newArray);
/* 2804 */         return newArray;
/*      */       } 
/*      */     } 
/*      */     
/* 2808 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Type deepCopyTypeIfNeeded(Type type) {
/* 2819 */     if (type.kind() == Type.Kind.TYPE_VARIABLE_REFERENCE)
/*      */     {
/* 2821 */       return new TypeVariableReference(type.asTypeVariableReference().identifier(), null, type.annotationArray(), type
/* 2822 */           .asTypeVariableReference().internalClassName()); } 
/* 2823 */     if (type.kind() == Type.Kind.TYPE_VARIABLE) {
/* 2824 */       TypeVariable typeVariable = type.asTypeVariable();
/* 2825 */       Type[] bounds = typeVariable.boundArray();
/* 2826 */       for (int i = 0; i < bounds.length; i++) {
/* 2827 */         Type newBound = deepCopyTypeIfNeeded(bounds[i]);
/* 2828 */         if (newBound != bounds[i]) {
/* 2829 */           typeVariable = (TypeVariable)intern(typeVariable.copyType(i, newBound));
/*      */         }
/*      */       } 
/* 2832 */       if (typeVariable != type) {
/* 2833 */         return typeVariable;
/*      */       }
/* 2835 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 2836 */       ParameterizedType parameterized = type.asParameterizedType();
/* 2837 */       if (parameterized.owner() != null) {
/* 2838 */         Type newOwner = deepCopyTypeIfNeeded(parameterized.owner());
/* 2839 */         if (parameterized.owner() != newOwner) {
/* 2840 */           parameterized = (ParameterizedType)intern(parameterized.copyType(newOwner));
/*      */         }
/*      */       } 
/* 2843 */       Type[] typeArguments = parameterized.argumentsArray();
/* 2844 */       for (int i = 0; i < typeArguments.length; i++) {
/* 2845 */         Type newTypeArgument = deepCopyTypeIfNeeded(typeArguments[i]);
/* 2846 */         if (newTypeArgument != typeArguments[i]) {
/* 2847 */           parameterized = (ParameterizedType)intern(parameterized.copyType(i, newTypeArgument));
/*      */         }
/*      */       } 
/* 2850 */       if (parameterized != type) {
/* 2851 */         return parameterized;
/*      */       }
/* 2853 */     } else if (type.kind() == Type.Kind.WILDCARD_TYPE) {
/* 2854 */       WildcardType wildcard = type.asWildcardType();
/* 2855 */       Type newBound = deepCopyTypeIfNeeded(wildcard.bound());
/* 2856 */       if (newBound != wildcard.bound()) {
/* 2857 */         return intern(wildcard.copyType(newBound));
/*      */       }
/* 2859 */     } else if (type.kind() == Type.Kind.ARRAY) {
/* 2860 */       ArrayType array = type.asArrayType();
/* 2861 */       Type newComponent = deepCopyTypeIfNeeded(array.component());
/* 2862 */       if (newComponent != array.component()) {
/* 2863 */         return intern(array.copyType(newComponent, array.dimensions()));
/*      */       }
/*      */     } 
/*      */     
/* 2867 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void patchTypeVariableReferences(Type type, Deque<TypeVariable> typeVarStack, AnnotationTarget parametricEncloser) {
/* 2877 */     if (type.kind() == Type.Kind.TYPE_VARIABLE_REFERENCE) {
/* 2878 */       String identifier = type.asTypeVariableReference().identifier();
/*      */       
/* 2880 */       for (TypeVariable typeVariable : typeVarStack) {
/* 2881 */         if (identifier.equals(typeVariable.identifier())) {
/* 2882 */           type.asTypeVariableReference().setTarget(typeVariable);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/* 2887 */       TypeVariable typeParameter = resolveTypeParameter(parametricEncloser, identifier);
/* 2888 */       if (typeParameter != null) {
/* 2889 */         type.asTypeVariableReference().setTarget(typeParameter);
/*      */       }
/* 2891 */     } else if (type.kind() == Type.Kind.TYPE_VARIABLE) {
/* 2892 */       typeVarStack.push(type.asTypeVariable());
/* 2893 */       for (Type bound : type.asTypeVariable().boundArray()) {
/* 2894 */         patchTypeVariableReferences(bound, typeVarStack, parametricEncloser);
/*      */       }
/* 2896 */       typeVarStack.pop();
/* 2897 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 2898 */       if (type.asParameterizedType().owner() != null) {
/* 2899 */         patchTypeVariableReferences(type.asParameterizedType().owner(), typeVarStack, parametricEncloser);
/*      */       }
/* 2901 */       for (Type typeArg : type.asParameterizedType().argumentsArray()) {
/* 2902 */         patchTypeVariableReferences(typeArg, typeVarStack, parametricEncloser);
/*      */       }
/* 2904 */     } else if (type.kind() == Type.Kind.WILDCARD_TYPE) {
/* 2905 */       patchTypeVariableReferences(type.asWildcardType().bound(), typeVarStack, parametricEncloser);
/* 2906 */     } else if (type.kind() == Type.Kind.ARRAY) {
/* 2907 */       patchTypeVariableReferences(type.asArrayType().component(), typeVarStack, parametricEncloser);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeVariable findTypeParameter(Type[] typeParameters, String identifier) {
/* 2916 */     for (Type typeParameter : typeParameters) {
/* 2917 */       if (typeParameter.kind() == Type.Kind.TYPE_VARIABLE && 
/* 2918 */         typeParameter.asTypeVariable().identifier().equals(identifier)) {
/* 2919 */         return typeParameter.asTypeVariable();
/*      */       }
/*      */     } 
/*      */     
/* 2923 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeVariable resolveTypeParameter(AnnotationTarget target, String identifier) {
/* 2933 */     if (target.kind() == AnnotationTarget.Kind.CLASS) {
/* 2934 */       ClassInfo clazz = target.asClass();
/* 2935 */       TypeVariable found = findTypeParameter(clazz.typeParameterArray(), identifier);
/* 2936 */       if (found != null) {
/* 2937 */         return found;
/*      */       }
/* 2939 */       if (!Modifier.isStatic(clazz.flags())) {
/* 2940 */         if (clazz.enclosingClass() != null) {
/* 2941 */           ClassInfo enclosingClass = this.classes.get(clazz.enclosingClass());
/* 2942 */           if (enclosingClass != null) {
/* 2943 */             return resolveTypeParameter(enclosingClass, identifier);
/*      */           }
/* 2945 */         } else if (clazz.enclosingMethod() != null) {
/* 2946 */           ClassInfo enclosingClass = this.classes.get(clazz.enclosingMethod().enclosingClass());
/* 2947 */           if (enclosingClass != null) {
/* 2948 */             MethodInfo enclosingMethod = enclosingClass.method(clazz.enclosingMethod().name(), clazz
/* 2949 */                 .enclosingMethod().parametersArray());
/* 2950 */             if (enclosingMethod != null) {
/* 2951 */               return resolveTypeParameter(enclosingMethod, identifier);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/* 2956 */     } else if (target.kind() == AnnotationTarget.Kind.METHOD) {
/* 2957 */       MethodInfo method = target.asMethod();
/* 2958 */       TypeVariable found = findTypeParameter(method.typeParameterArray(), identifier);
/* 2959 */       if (found != null) {
/* 2960 */         return found;
/*      */       }
/* 2962 */       if (!Modifier.isStatic(method.flags())) {
/* 2963 */         return resolveTypeParameter(method.declaringClass(), identifier);
/*      */       }
/*      */     } 
/* 2966 */     return null;
/*      */   }
/*      */   
/*      */   private String getTypeVariableIdentifier(Type typeVariable) {
/* 2970 */     if (typeVariable.kind() == Type.Kind.TYPE_VARIABLE)
/* 2971 */       return typeVariable.asTypeVariable().identifier(); 
/* 2972 */     if (typeVariable.kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE) {
/* 2973 */       return typeVariable.asUnresolvedTypeVariable().identifier();
/*      */     }
/* 2975 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void propagateTypeVariables() {
/* 2980 */     for (ClassInfo clazz : this.classes.values()) {
/* 2981 */       if (clazz.superClassType() != null) {
/* 2982 */         clazz.setSuperClassType(propagateTypeVariables(clazz.superClassType(), clazz));
/*      */       }
/*      */       
/* 2985 */       Type[] interfaces = (Type[])clazz.interfaceTypeArray().clone();
/* 2986 */       for (int i = 0; i < interfaces.length; i++) {
/* 2987 */         interfaces[i] = propagateTypeVariables(interfaces[i], clazz);
/*      */       }
/* 2989 */       clazz.setInterfaceTypes(intern(interfaces));
/*      */       
/* 2991 */       for (FieldInternal field : clazz.fieldArray()) {
/* 2992 */         field.setType(propagateTypeVariables(field.type(), clazz));
/*      */       }
/*      */       
/* 2995 */       for (MethodInternal method : clazz.methodArray()) {
/* 2996 */         MethodInfo m = new MethodInfo(clazz, method);
/*      */ 
/*      */ 
/*      */         
/* 3000 */         method.setReturnType(propagateTypeVariables(method.returnType(), m));
/*      */         
/* 3002 */         if (method.receiverTypeField() != null) {
/* 3003 */           method.setReceiverType(propagateTypeVariables(method.receiverTypeField(), m));
/*      */         }
/*      */         
/* 3006 */         Type[] parameterTypes = (Type[])method.parameterTypesArray().clone();
/* 3007 */         for (int j = 0; j < parameterTypes.length; j++) {
/* 3008 */           parameterTypes[j] = propagateTypeVariables(parameterTypes[j], m);
/*      */         }
/* 3010 */         method.setParameterTypes(intern(parameterTypes));
/*      */         
/* 3012 */         Type[] exceptionTypes = (Type[])method.exceptionArray().clone();
/* 3013 */         for (int k = 0; k < exceptionTypes.length; k++) {
/* 3014 */           exceptionTypes[k] = propagateTypeVariables(exceptionTypes[k], m);
/*      */         }
/* 3016 */         method.setExceptions(intern(exceptionTypes));
/*      */       } 
/*      */       
/* 3019 */       for (RecordComponentInternal recordComponent : clazz.recordComponentArray()) {
/* 3020 */         recordComponent.setType(propagateTypeVariables(recordComponent.type(), clazz));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Type propagateTypeVariables(Type type, AnnotationTarget parametricEncloser) {
/* 3028 */     if (type.kind() == Type.Kind.TYPE_VARIABLE || type.kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE) {
/* 3029 */       String identifier = getTypeVariableIdentifier(type);
/* 3030 */       TypeVariable resolved = resolveTypeParameter(parametricEncloser, identifier);
/* 3031 */       if (resolved != null) {
/*      */ 
/*      */ 
/*      */         
/* 3035 */         Type newTypeVariable = intern(deepCopyTypeIfNeeded(resolved).copyType(type.annotationArray()));
/* 3036 */         patchTypeVariableReferences(newTypeVariable, new ArrayDeque<>(), parametricEncloser);
/* 3037 */         retargetTypeAnnotations(parametricEncloser, type, newTypeVariable);
/* 3038 */         return newTypeVariable;
/*      */       } 
/* 3040 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 3041 */       ParameterizedType parameterized = type.asParameterizedType();
/* 3042 */       if (parameterized.owner() != null) {
/* 3043 */         Type newOwner = propagateTypeVariables(parameterized.owner(), parametricEncloser);
/* 3044 */         if (parameterized.owner() != newOwner) {
/* 3045 */           parameterized = (ParameterizedType)intern(parameterized.copyType(newOwner));
/*      */         }
/*      */       } 
/* 3048 */       Type[] typeArguments = parameterized.argumentsArray();
/* 3049 */       for (int i = 0; i < typeArguments.length; i++) {
/* 3050 */         Type newTypeArgument = propagateTypeVariables(typeArguments[i], parametricEncloser);
/* 3051 */         if (newTypeArgument != typeArguments[i]) {
/* 3052 */           parameterized = (ParameterizedType)intern(parameterized.copyType(i, newTypeArgument));
/*      */         }
/*      */       } 
/* 3055 */       if (parameterized != type) {
/* 3056 */         retargetTypeAnnotations(parametricEncloser, type, parameterized);
/* 3057 */         return parameterized;
/*      */       } 
/* 3059 */     } else if (type.kind() == Type.Kind.WILDCARD_TYPE) {
/* 3060 */       WildcardType wildcard = type.asWildcardType();
/* 3061 */       Type newBound = propagateTypeVariables(wildcard.bound(), parametricEncloser);
/* 3062 */       if (newBound != wildcard.bound()) {
/* 3063 */         Type newWildcard = intern(wildcard.copyType(newBound));
/* 3064 */         retargetTypeAnnotations(parametricEncloser, type, newWildcard);
/* 3065 */         return newWildcard;
/*      */       } 
/* 3067 */     } else if (type.kind() == Type.Kind.ARRAY) {
/* 3068 */       ArrayType array = type.asArrayType();
/* 3069 */       Type newComponent = propagateTypeVariables(array.component(), parametricEncloser);
/* 3070 */       if (newComponent != array.component()) {
/* 3071 */         Type newArray = intern(array.copyType(newComponent, array.dimensions()));
/* 3072 */         retargetTypeAnnotations(parametricEncloser, type, newArray);
/* 3073 */         return newArray;
/*      */       } 
/*      */     } 
/*      */     
/* 3077 */     return type;
/*      */   }
/*      */   
/*      */   private void retargetTypeAnnotations(AnnotationTarget parametricEncloser, Type oldType, Type newType) {
/*      */     ClassInfo clazz;
/* 3082 */     if (parametricEncloser instanceof ClassInfo) {
/* 3083 */       clazz = (ClassInfo)parametricEncloser;
/* 3084 */     } else if (parametricEncloser instanceof MethodInfo) {
/* 3085 */       clazz = ((MethodInfo)parametricEncloser).declaringClass();
/*      */     } else {
/* 3087 */       throw new IllegalArgumentException("Expected class or method: " + parametricEncloser);
/*      */     } 
/*      */     
/* 3090 */     for (List<AnnotationInstance> annotationsList : clazz.annotationsMap().values()) {
/* 3091 */       for (AnnotationInstance annotation : annotationsList) {
/* 3092 */         if (annotation.target().kind() != AnnotationTarget.Kind.TYPE) {
/*      */           continue;
/*      */         }
/*      */         
/* 3096 */         TypeTarget typeTarget = annotation.target().asType();
/* 3097 */         if (typeTarget.target() == oldType)
/* 3098 */           typeTarget.setTarget(newType); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Indexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */