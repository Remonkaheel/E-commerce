/*     */ package org.jboss.jandex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassType
/*     */   extends Type
/*     */ {
/*  31 */   public static final ClassType OBJECT_TYPE = new ClassType(DotName.OBJECT_NAME);
/*     */   
/*  33 */   public static final ClassType BYTE_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Byte"));
/*  34 */   public static final ClassType CHARACTER_CLASS = new ClassType(
/*  35 */       DotName.createComponentized(DotName.JAVA_LANG_NAME, "Character"));
/*  36 */   public static final ClassType DOUBLE_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Double"));
/*  37 */   public static final ClassType FLOAT_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Float"));
/*  38 */   public static final ClassType INTEGER_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Integer"));
/*  39 */   public static final ClassType LONG_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Long"));
/*  40 */   public static final ClassType SHORT_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Short"));
/*  41 */   public static final ClassType BOOLEAN_CLASS = new ClassType(DotName.createComponentized(DotName.JAVA_LANG_NAME, "Boolean"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassType create(DotName name) {
/*  55 */     return new ClassType(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassType create(String name) {
/*  70 */     return create(DotName.createSimple(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassType create(Class<?> clazz) {
/*  85 */     return create(DotName.createSimple(clazz.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(DotName name) {
/*  96 */     return new Builder(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(Class<?> clazz) {
/* 107 */     return builder(DotName.createSimple(clazz.getName()));
/*     */   }
/*     */   
/*     */   ClassType(DotName name) {
/* 111 */     this(name, (AnnotationInstance[])null);
/*     */   }
/*     */   
/*     */   ClassType(DotName name, AnnotationInstance[] annotations) {
/* 115 */     super(name, annotations);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 120 */     return Type.Kind.CLASS;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassType asClassType() {
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 130 */     return new ClassType(name(), newAnnotations);
/*     */   }
/*     */   
/*     */   ParameterizedType toParameterizedType() {
/* 134 */     return new ParameterizedType(name(), null, null, annotationArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */     extends Type.Builder<Builder>
/*     */   {
/*     */     Builder(DotName name) {
/* 145 */       super(name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassType build() {
/* 154 */       return new ClassType(this.name, annotationsArray());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ClassType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */