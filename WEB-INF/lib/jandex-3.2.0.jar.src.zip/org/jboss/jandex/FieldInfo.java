/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldInfo
/*     */   implements Declaration, Descriptor, GenericSignature
/*     */ {
/*     */   private ClassInfo clazz;
/*     */   private FieldInternal internal;
/*     */   
/*     */   FieldInfo() {}
/*     */   
/*     */   FieldInfo(ClassInfo clazz, FieldInternal internal) {
/*  47 */     this.clazz = clazz;
/*  48 */     this.internal = internal;
/*     */   }
/*     */   
/*     */   FieldInfo(ClassInfo clazz, byte[] name, Type type, short flags) {
/*  52 */     this(clazz, new FieldInternal(name, type, flags));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FieldInfo create(ClassInfo clazz, String name, Type type, short flags) {
/*  65 */     if (clazz == null) {
/*  66 */       throw new IllegalArgumentException("Clazz can't be null");
/*     */     }
/*  68 */     if (name == null) {
/*  69 */       throw new IllegalArgumentException("Name can't be null");
/*     */     }
/*  71 */     return new FieldInfo(clazz, Utils.toUTF8(name), type, flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String name() {
/*  80 */     return this.internal.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ClassInfo declaringClass() {
/*  89 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type type() {
/*  98 */     return this.internal.type();
/*     */   }
/*     */   
/*     */   public final AnnotationTarget.Kind kind() {
/* 102 */     return AnnotationTarget.Kind.FIELD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnnotation(DotName name) {
/* 114 */     return this.internal.hasAnnotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationInstance annotation(DotName name) {
/* 139 */     return this.internal.annotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotations(DotName name) {
/* 163 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 164 */     for (AnnotationInstance instance : this.internal.annotationArray()) {
/* 165 */       if (instance.name().equals(name)) {
/* 166 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 169 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 190 */     if (index == null) {
/* 191 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 193 */     List<AnnotationInstance> instances = new ArrayList<>(annotations(name));
/* 194 */     ClassInfo annotationClass = index.getClassByName(name);
/* 195 */     if (annotationClass == null) {
/* 196 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 198 */     if (!annotationClass.isAnnotation()) {
/* 199 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 201 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 202 */     if (repeatable != null) {
/* 203 */       Type containingType = repeatable.value().asClass();
/* 204 */       for (AnnotationInstance container : annotations(containingType.name())) {
/* 205 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 206 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       } 
/*     */     } 
/* 210 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotations() {
/* 230 */     return this.internal.annotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasDeclaredAnnotation(DotName name) {
/* 246 */     return (declaredAnnotation(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationInstance declaredAnnotation(DotName name) {
/* 262 */     for (AnnotationInstance instance : this.internal.annotationArray()) {
/* 263 */       if (instance.target().kind() == AnnotationTarget.Kind.FIELD && instance.name().equals(name)) {
/* 264 */         return instance;
/*     */       }
/*     */     } 
/* 267 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> declaredAnnotationsWithRepeatable(DotName name, IndexView index) {
/* 290 */     if (index == null) {
/* 291 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 293 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 294 */     AnnotationInstance declaredInstance = declaredAnnotation(name);
/* 295 */     if (declaredInstance != null) {
/* 296 */       instances.add(declaredInstance);
/*     */     }
/* 298 */     ClassInfo annotationClass = index.getClassByName(name);
/* 299 */     if (annotationClass == null) {
/* 300 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 302 */     if (!annotationClass.isAnnotation()) {
/* 303 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 305 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 306 */     if (repeatable != null) {
/* 307 */       Type containingType = repeatable.value().asClass();
/* 308 */       AnnotationInstance container = declaredAnnotation(containingType.name());
/* 309 */       if (container != null) {
/* 310 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 311 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       }
/*     */     } 
/* 315 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> declaredAnnotations() {
/* 330 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 331 */     for (AnnotationInstance instance : this.internal.annotationArray()) {
/* 332 */       if (instance.target().kind() == AnnotationTarget.Kind.FIELD) {
/* 333 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 336 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnumConstant() {
/* 347 */     return this.internal.isEnumConstant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final short flags() {
/* 356 */     return this.internal.flags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSynthetic() {
/* 364 */     return Modifiers.isSynthetic(this.internal.flags());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int enumConstantOrdinal() {
/* 384 */     return this.clazz.enumConstantOrdinal(this.internal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresGenericSignature() {
/* 395 */     return GenericSignatureReconstruction.requiresGenericSignature(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String genericSignature(Function<String, Type> typeVariableSubstitution) {
/* 415 */     return GenericSignatureReconstruction.reconstructGenericSignature(this, typeVariableSubstitution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String descriptor(Function<String, Type> typeVariableSubstitution) {
/* 432 */     return DescriptorReconstruction.fieldDescriptor(this, typeVariableSubstitution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 442 */     return this.internal.toString(this.clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ClassInfo asClass() {
/* 447 */     throw new IllegalArgumentException("Not a class");
/*     */   }
/*     */ 
/*     */   
/*     */   public final FieldInfo asField() {
/* 452 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodInfo asMethod() {
/* 457 */     throw new IllegalArgumentException("Not a method");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodParameterInfo asMethodParameter() {
/* 462 */     throw new IllegalArgumentException("Not a method parameter");
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypeTarget asType() {
/* 467 */     throw new IllegalArgumentException("Not a type");
/*     */   }
/*     */ 
/*     */   
/*     */   public final RecordComponentInfo asRecordComponent() {
/* 472 */     throw new IllegalArgumentException("Not a record component");
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 477 */     int result = 1;
/* 478 */     result = 31 * result + this.clazz.hashCode();
/* 479 */     result = 31 * result + this.internal.hashCode();
/* 480 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 485 */     if (this == o) {
/* 486 */       return true;
/*     */     }
/* 488 */     if (o == null || getClass() != o.getClass()) {
/* 489 */       return false;
/*     */     }
/* 491 */     FieldInfo other = (FieldInfo)o;
/* 492 */     return (this.clazz.equals(other.clazz) && this.internal.equals(other.internal));
/*     */   }
/*     */   
/*     */   void setType(Type type) {
/* 496 */     this.internal.setType(type);
/*     */   }
/*     */   
/*     */   void setAnnotations(List<AnnotationInstance> annotations) {
/* 500 */     this.internal.setAnnotations(annotations);
/*     */   }
/*     */   
/*     */   FieldInternal fieldInternal() {
/* 504 */     return this.internal;
/*     */   }
/*     */   
/*     */   void setFieldInternal(FieldInternal internal) {
/* 508 */     this.internal = internal;
/*     */   }
/*     */   
/*     */   void setClassInfo(ClassInfo clazz) {
/* 512 */     this.clazz = clazz;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\FieldInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */