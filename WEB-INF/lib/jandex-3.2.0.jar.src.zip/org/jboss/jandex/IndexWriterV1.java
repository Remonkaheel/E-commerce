/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class IndexWriterV1
/*     */   extends IndexWriterImpl
/*     */ {
/*     */   private static final int MAGIC = -1161945323;
/*     */   static final int MIN_VERSION = 1;
/*     */   static final int MAX_VERSION = 3;
/*     */   private static final byte FIELD_TAG = 1;
/*     */   private static final byte METHOD_TAG = 2;
/*     */   private static final byte METHOD_PARAMETER_TAG = 3;
/*     */   private static final byte CLASS_TAG = 4;
/*     */   private static final int AVALUE_BYTE = 1;
/*     */   private static final int AVALUE_SHORT = 2;
/*     */   private static final int AVALUE_INT = 3;
/*     */   private static final int AVALUE_CHAR = 4;
/*     */   private static final int AVALUE_FLOAT = 5;
/*     */   private static final int AVALUE_DOUBLE = 6;
/*     */   private static final int AVALUE_LONG = 7;
/*     */   private static final int AVALUE_BOOLEAN = 8;
/*     */   private static final int AVALUE_STRING = 9;
/*     */   private static final int AVALUE_CLASS = 10;
/*     */   private static final int AVALUE_ENUM = 11;
/*     */   private static final int AVALUE_ARRAY = 12;
/*     */   private static final int AVALUE_NESTED = 13;
/*     */   private final OutputStream out;
/*     */   private final int version;
/*     */   private StrongInternPool<String> pool;
/*     */   StrongInternPool<String>.Index poolIndex;
/*     */   private TreeMap<DotName, Integer> classTable;
/*     */   
/*     */   IndexWriterV1(OutputStream out, int version) {
/*  87 */     this.out = out;
/*  88 */     this.version = version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int write(Index index) throws IOException {
/* 102 */     if (this.version < 1 || this.version > 3) {
/* 103 */       throw new UnsupportedVersion("Can't write index version " + this.version + "; this IndexWriterV1 only supports index versions " + '\001' + "-" + '\003');
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 108 */     PackedDataOutputStream stream = new PackedDataOutputStream(new BufferedOutputStream(this.out));
/* 109 */     stream.writeInt(-1161945323);
/* 110 */     stream.writeByte(this.version);
/*     */     
/* 112 */     buildTables(index);
/* 113 */     writeClassTable(stream);
/* 114 */     writeStringTable(stream);
/* 115 */     writeClasses(stream, index);
/* 116 */     stream.flush();
/* 117 */     return stream.size();
/*     */   }
/*     */   
/*     */   private void writeStringTable(PackedDataOutputStream stream) throws IOException {
/* 121 */     stream.writePackedU32(this.pool.size());
/* 122 */     Iterator<String> iter = this.pool.iterator();
/* 123 */     while (iter.hasNext()) {
/* 124 */       String string = iter.next();
/* 125 */       stream.writeUTF(string);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeClassTable(PackedDataOutputStream stream) throws IOException {
/* 130 */     stream.writePackedU32(this.classTable.size());
/*     */ 
/*     */     
/* 133 */     int pos = 1;
/* 134 */     for (Map.Entry<DotName, Integer> entry : this.classTable.entrySet()) {
/* 135 */       entry.setValue(Integer.valueOf(pos++));
/* 136 */       DotName name = entry.getKey();
/* 137 */       assert name.isComponentized();
/*     */       
/* 139 */       int nameDepth = 0;
/* 140 */       for (DotName prefix = name.prefix(); prefix != null; prefix = prefix.prefix()) {
/* 141 */         nameDepth++;
/*     */       }
/* 143 */       stream.writePackedU32(nameDepth);
/* 144 */       stream.writeUTF(name.local());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int positionOf(String string) {
/* 150 */     int i = this.poolIndex.positionOf((E)string) - 1;
/* 151 */     if (i < 0) {
/* 152 */       throw new IllegalStateException();
/*     */     }
/* 154 */     return i;
/*     */   }
/*     */   
/*     */   private int positionOf(DotName className) {
/* 158 */     className = downgradeName(className);
/* 159 */     Integer i = this.classTable.get(className);
/* 160 */     if (i == null) {
/* 161 */       throw new IllegalStateException("Class not found in class table:" + className);
/*     */     }
/* 163 */     return i.intValue();
/*     */   }
/*     */   
/*     */   private void writeClasses(PackedDataOutputStream stream, Index index) throws IOException {
/* 167 */     Collection<ClassInfo> classes = index.getKnownClasses();
/* 168 */     stream.writePackedU32(classes.size());
/* 169 */     for (ClassInfo clazz : classes) {
/* 170 */       stream.writePackedU32(positionOf(clazz.name()));
/* 171 */       stream.writePackedU32((clazz.superName() == null) ? 0 : positionOf(clazz.superName()));
/* 172 */       stream.writeShort(clazz.flags());
/*     */ 
/*     */       
/* 175 */       if (this.version >= 3) {
/* 176 */         stream.writeBoolean(clazz.hasNoArgsConstructor());
/*     */       }
/*     */       
/* 179 */       DotName[] interfaces = clazz.interfaces();
/* 180 */       stream.writePackedU32(interfaces.length);
/* 181 */       for (DotName intf : interfaces) {
/* 182 */         stream.writePackedU32(positionOf(intf));
/*     */       }
/* 184 */       Set<Map.Entry<DotName, List<AnnotationInstance>>> entrySet = clazz.annotationsMap().entrySet();
/* 185 */       stream.writePackedU32(entrySet.size());
/* 186 */       for (Map.Entry<DotName, List<AnnotationInstance>> entry : entrySet) {
/* 187 */         stream.writePackedU32(positionOf(entry.getKey()));
/*     */         
/* 189 */         List<AnnotationInstance> instances = entry.getValue();
/* 190 */         stream.writePackedU32(instances.size());
/* 191 */         for (AnnotationInstance instance : instances) {
/* 192 */           AnnotationTarget target = instance.target();
/* 193 */           if (target instanceof FieldInfo) {
/* 194 */             FieldInfo field = (FieldInfo)target;
/* 195 */             stream.writeByte(1);
/* 196 */             stream.writePackedU32(positionOf(field.name()));
/* 197 */             writeType(stream, field.type());
/* 198 */             stream.writeShort(field.flags());
/* 199 */           } else if (target instanceof MethodInfo) {
/* 200 */             MethodInfo method = (MethodInfo)target;
/* 201 */             stream.writeByte(2);
/* 202 */             stream.writePackedU32(positionOf(method.name()));
/* 203 */             stream.writePackedU32((method.copyParameters()).length);
/* 204 */             for (int i = 0; i < (method.copyParameters()).length; i++) {
/* 205 */               writeType(stream, method.copyParameters()[i]);
/*     */             }
/* 207 */             writeType(stream, method.returnType());
/* 208 */             stream.writeShort(method.flags());
/* 209 */           } else if (target instanceof MethodParameterInfo) {
/* 210 */             MethodParameterInfo param = (MethodParameterInfo)target;
/* 211 */             MethodInfo method = param.method();
/* 212 */             stream.writeByte(3);
/* 213 */             stream.writePackedU32(positionOf(method.name()));
/* 214 */             stream.writePackedU32((method.copyParameters()).length);
/* 215 */             for (int i = 0; i < (method.copyParameters()).length; i++) {
/* 216 */               writeType(stream, method.copyParameters()[i]);
/*     */             }
/* 218 */             writeType(stream, method.returnType());
/* 219 */             stream.writeShort(method.flags());
/* 220 */             stream.writePackedU32(param.position());
/* 221 */           } else if (target instanceof ClassInfo) {
/* 222 */             stream.writeByte(4);
/*     */           } else {
/* 224 */             throw new IllegalStateException("Unknown target");
/*     */           } 
/* 226 */           Collection<AnnotationValue> values = instance.values();
/* 227 */           writeAnnotationValues(stream, values);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeAnnotationValues(PackedDataOutputStream stream, Collection<AnnotationValue> values) throws IOException {
/* 234 */     stream.writePackedU32(values.size());
/* 235 */     for (AnnotationValue value : values) {
/* 236 */       writeAnnotationValue(stream, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeAnnotationValue(PackedDataOutputStream stream, AnnotationValue value) throws IOException {
/* 241 */     stream.writePackedU32(positionOf(value.name()));
/* 242 */     if (value instanceof AnnotationValue.ByteValue) {
/* 243 */       stream.writeByte(1);
/* 244 */       stream.writeByte(value.asByte() & 0xFF);
/* 245 */     } else if (value instanceof AnnotationValue.ShortValue) {
/* 246 */       stream.writeByte(2);
/* 247 */       stream.writePackedU32(value.asShort() & 0xFFFF);
/* 248 */     } else if (value instanceof AnnotationValue.IntegerValue) {
/* 249 */       stream.writeByte(3);
/* 250 */       stream.writePackedU32(value.asInt());
/* 251 */     } else if (value instanceof AnnotationValue.CharacterValue) {
/* 252 */       stream.writeByte(4);
/* 253 */       stream.writePackedU32(value.asChar());
/* 254 */     } else if (value instanceof AnnotationValue.FloatValue) {
/* 255 */       stream.writeByte(5);
/* 256 */       stream.writeFloat(value.asFloat());
/* 257 */     } else if (value instanceof AnnotationValue.DoubleValue) {
/* 258 */       stream.writeByte(6);
/* 259 */       stream.writeDouble(value.asDouble());
/* 260 */     } else if (value instanceof AnnotationValue.LongValue) {
/* 261 */       stream.writeByte(7);
/* 262 */       stream.writeLong(value.asLong());
/* 263 */     } else if (value instanceof AnnotationValue.BooleanValue) {
/* 264 */       stream.writeByte(8);
/* 265 */       stream.writeBoolean(value.asBoolean());
/* 266 */     } else if (value instanceof AnnotationValue.StringValue) {
/* 267 */       stream.writeByte(9);
/* 268 */       stream.writePackedU32(positionOf(value.asString()));
/* 269 */     } else if (value instanceof AnnotationValue.ClassValue) {
/* 270 */       stream.writeByte(10);
/* 271 */       writeType(stream, value.asClass());
/* 272 */     } else if (value instanceof AnnotationValue.EnumValue) {
/* 273 */       stream.writeByte(11);
/* 274 */       stream.writePackedU32(positionOf(value.asEnumType()));
/* 275 */       stream.writePackedU32(positionOf(value.asEnum()));
/* 276 */     } else if (value instanceof AnnotationValue.ArrayValue) {
/* 277 */       AnnotationValue[] array = value.asArray();
/* 278 */       int length = array.length;
/* 279 */       stream.writeByte(12);
/* 280 */       stream.writePackedU32(length);
/*     */       
/* 282 */       for (int i = 0; i < length; i++) {
/* 283 */         writeAnnotationValue(stream, array[i]);
/*     */       }
/* 285 */     } else if (value instanceof AnnotationValue.NestedAnnotation) {
/* 286 */       AnnotationInstance instance = value.asNested();
/* 287 */       Collection<AnnotationValue> values = instance.values();
/*     */       
/* 289 */       stream.writeByte(13);
/* 290 */       stream.writePackedU32(positionOf(instance.name()));
/* 291 */       writeAnnotationValues(stream, values);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeType(PackedDataOutputStream stream, Type type) throws IOException {
/* 296 */     stream.writeByte(type.kind().ordinal());
/* 297 */     stream.writePackedU32(positionOf(type.name()));
/*     */   }
/*     */   
/*     */   private void buildTables(Index index) {
/* 301 */     this.pool = StrongInternPool.forStrings();
/* 302 */     this.classTable = new TreeMap<>();
/*     */ 
/*     */     
/* 305 */     for (ClassInfo clazz : index.getKnownClasses()) {
/* 306 */       addClassName(clazz.name());
/* 307 */       if (clazz.superName() != null) {
/* 308 */         addClassName(clazz.superName());
/*     */       }
/* 310 */       for (DotName intf : clazz.interfaces()) {
/* 311 */         addClassName(intf);
/*     */       }
/* 313 */       for (Map.Entry<DotName, List<AnnotationInstance>> entry : clazz.annotationsMap().entrySet()) {
/* 314 */         addClassName(entry.getKey());
/*     */         
/* 316 */         for (AnnotationInstance instance : entry.getValue()) {
/* 317 */           AnnotationTarget target = instance.target();
/* 318 */           if (target instanceof FieldInfo) {
/* 319 */             FieldInfo field = (FieldInfo)target;
/* 320 */             intern(field.name());
/* 321 */             addClassName(field.type().name());
/*     */           }
/* 323 */           else if (target instanceof MethodInfo) {
/* 324 */             MethodInfo method = (MethodInfo)target;
/* 325 */             intern(method.name());
/* 326 */             for (Type type : method.copyParameters()) {
/* 327 */               addClassName(type.name());
/*     */             }
/* 329 */             addClassName(method.returnType().name());
/* 330 */           } else if (target instanceof MethodParameterInfo) {
/* 331 */             MethodParameterInfo param = (MethodParameterInfo)target;
/* 332 */             intern(param.method().name());
/* 333 */             for (Type type : param.method().copyParameters()) {
/* 334 */               addClassName(type.name());
/*     */             }
/* 336 */             addClassName(param.method().returnType().name());
/*     */           } 
/*     */           
/* 339 */           for (AnnotationValue value : instance.values()) {
/* 340 */             buildAValueEntries(index, value);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 346 */     this.poolIndex = this.pool.index();
/*     */   }
/*     */   
/*     */   private void buildAValueEntries(Index index, AnnotationValue value) {
/* 350 */     intern(value.name());
/*     */     
/* 352 */     if (value instanceof AnnotationValue.StringValue) {
/* 353 */       intern(value.asString());
/* 354 */     } else if (value instanceof AnnotationValue.ClassValue) {
/* 355 */       addClassName(value.asClass().name());
/* 356 */     } else if (value instanceof AnnotationValue.EnumValue) {
/* 357 */       addClassName(value.asEnumType());
/* 358 */       intern(value.asEnum());
/* 359 */     } else if (value instanceof AnnotationValue.ArrayValue) {
/* 360 */       for (AnnotationValue entry : value.asArray())
/* 361 */         buildAValueEntries(index, entry); 
/* 362 */     } else if (value instanceof AnnotationValue.NestedAnnotation) {
/* 363 */       AnnotationInstance instance = value.asNested();
/* 364 */       Collection<AnnotationValue> values = instance.values();
/*     */       
/* 366 */       addClassName(instance.name());
/* 367 */       for (AnnotationValue entry : values) {
/* 368 */         buildAValueEntries(index, entry);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private String intern(String name) {
/* 374 */     return this.pool.intern(name);
/*     */   }
/*     */   
/*     */   private void addClassName(DotName name) {
/* 378 */     name = downgradeName(name);
/*     */     
/* 380 */     if (!this.classTable.containsKey(name)) {
/* 381 */       this.classTable.put(name, null);
/*     */     }
/* 383 */     DotName prefix = name.prefix();
/* 384 */     if (prefix != null)
/* 385 */       addClassName(prefix); 
/*     */   }
/*     */   
/*     */   private DotName downgradeName(DotName name) {
/* 389 */     DotName n = name;
/* 390 */     StringBuilder builder = null;
/* 391 */     while (n.isInner()) {
/* 392 */       if (builder == null) {
/* 393 */         builder = new StringBuilder();
/*     */       }
/*     */       
/* 396 */       builder.insert(0, n.local()).insert(0, '$');
/* 397 */       if (!n.prefix().isInner()) {
/* 398 */         builder.insert(0, n.prefix().local());
/* 399 */         name = new DotName(n.prefix().prefix(), builder.toString(), true, false);
/*     */       } 
/*     */       
/* 402 */       n = n.prefix();
/*     */     } 
/* 404 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexWriterV1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */