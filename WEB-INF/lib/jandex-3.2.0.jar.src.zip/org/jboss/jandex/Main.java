/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   private boolean modify;
/*     */   private boolean verbose;
/*     */   private boolean dump;
/*     */   private boolean jarFile;
/*     */   private File outputFile;
/*     */   private File source;
/*     */   private Index index;
/*     */   
/*     */   public static void main(String[] args) {
/*  47 */     if (args.length == 0) {
/*  48 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/*  52 */     Main main = new Main();
/*  53 */     main.execute(args);
/*     */   }
/*     */   
/*     */   private void execute(String[] args) {
/*  57 */     boolean printUsage = true;
/*     */     try {
/*  59 */       parseOptions(args);
/*     */       
/*  61 */       printUsage = false;
/*  62 */       if (this.dump) {
/*  63 */         dumpIndex(this.source);
/*     */         
/*     */         return;
/*     */       } 
/*  67 */       long start = System.currentTimeMillis();
/*  68 */       this.index = getIndex(start);
/*  69 */       this.outputFile = null;
/*  70 */       this.source = null;
/*  71 */     } catch (Exception e) {
/*  72 */       if (!this.verbose && (e instanceof IllegalArgumentException || e instanceof FileNotFoundException)) {
/*  73 */         System.err.println((e.getMessage() == null) ? e.getClass().getSimpleName() : ("ERROR: " + e.getMessage()));
/*     */       } else {
/*  75 */         e.printStackTrace(System.err);
/*     */       } 
/*     */       
/*  78 */       if (printUsage) {
/*  79 */         System.out.println();
/*  80 */         printUsage();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Index getIndex(long start) throws IOException {
/*  86 */     Indexer indexer = new Indexer();
/*     */     
/*  88 */     Result result = this.source.isDirectory() ? indexDirectory(this.source, indexer) : JarIndexer.createJarIndex(this.source, indexer, this.outputFile, this.modify, this.jarFile, this.verbose);
/*     */     
/*  90 */     double time = (System.currentTimeMillis() - start) / 1000.0D;
/*  91 */     System.out.printf(Locale.ROOT, "Wrote %s in %.4f seconds (%d classes, %d annotations, %d instances, %d class usages, %d bytes)\n", new Object[] { result
/*     */           
/*  93 */           .getName(), Double.valueOf(time), Integer.valueOf(result.getClasses()), Integer.valueOf(result.getAnnotations()), Integer.valueOf(result.getInstances()), Integer.valueOf(result.getUsages()), 
/*  94 */           Integer.valueOf(result.getBytes()) });
/*  95 */     return result.getIndex();
/*     */   }
/*     */   
/*     */   private void dumpIndex(File source) throws IOException {
/*  99 */     FileInputStream input = new FileInputStream(source);
/* 100 */     IndexReader reader = new IndexReader(input);
/*     */     
/* 102 */     long start = System.currentTimeMillis();
/* 103 */     Index index = reader.read();
/* 104 */     long end = System.currentTimeMillis() - start;
/* 105 */     System.out.println("Dump index v" + reader.getIndexVersion() + " (current: v" + '\f' + ") file: " + source);
/*     */     
/* 107 */     index.printAnnotations();
/* 108 */     index.printSubclasses();
/*     */     
/* 110 */     System.out.printf(Locale.ROOT, "%nRead %s in %.04f seconds%n", new Object[] { source.getName(), Double.valueOf(end / 1000.0D) });
/*     */   }
/*     */   
/*     */   private Result indexDirectory(File source, Indexer indexer) throws FileNotFoundException, IOException {
/* 114 */     File outputFile = this.outputFile;
/* 115 */     scanFile(source, indexer);
/*     */     
/* 117 */     if (this.modify) {
/* 118 */       (new File(source, "META-INF")).mkdirs();
/* 119 */       outputFile = new File(source, "META-INF/jandex.idx");
/*     */     } 
/* 121 */     if (outputFile == null) {
/* 122 */       outputFile = new File(source.getName().replace('.', '-') + ".idx");
/*     */     }
/*     */     
/* 125 */     FileOutputStream out = new FileOutputStream(outputFile);
/* 126 */     IndexWriter writer = new IndexWriter(out);
/*     */     
/*     */     try {
/* 129 */       Index index = indexer.complete();
/* 130 */       int bytes = writer.write(index);
/* 131 */       return new Result(index, outputFile.getPath(), bytes, outputFile);
/*     */     } finally {
/* 133 */       out.flush();
/* 134 */       out.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void printIndexEntryInfo(ClassSummary info) {
/* 139 */     System.out.println("Indexed " + info.name() + " (" + info.annotationsCount() + " annotations)");
/*     */   }
/*     */   
/*     */   private void scanFile(File source, Indexer indexer) throws FileNotFoundException, IOException {
/* 143 */     if (source.isDirectory()) {
/* 144 */       File[] children = source.listFiles();
/* 145 */       if (children == null) {
/* 146 */         throw new FileNotFoundException("Source directory disappeared: " + source);
/*     */       }
/* 148 */       for (File child : children) {
/* 149 */         scanFile(child, indexer);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     if (!source.getName().endsWith(".class")) {
/*     */       return;
/*     */     }
/* 157 */     FileInputStream input = new FileInputStream(source);
/*     */     
/*     */     try {
/* 160 */       ClassSummary info = indexer.indexWithSummary(input);
/* 161 */       if (this.verbose && info != null)
/* 162 */         printIndexEntryInfo(info); 
/* 163 */     } catch (Exception e) {
/* 164 */       String message = (e.getMessage() == null) ? e.getClass().getSimpleName() : e.getMessage();
/* 165 */       System.err.println("ERROR: Could not index " + source.getName() + ": " + message);
/* 166 */       if (this.verbose)
/* 167 */         e.printStackTrace(System.err); 
/*     */     } finally {
/* 169 */       safeClose(input);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void safeClose(FileInputStream input) {
/* 174 */     if (input != null) {
/*     */       try {
/* 176 */         input.close();
/* 177 */       } catch (Throwable throwable) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printUsage() {
/* 184 */     System.out.println("Usage: jandex [-v] [-m] [-o file-name] <directory> | <jar>");
/* 185 */     System.out.println("        -or-");
/* 186 */     System.out.println("       jandex [-d] <index-file-name>");
/* 187 */     System.out.println("Options:");
/* 188 */     System.out.println("  -v  verbose output");
/* 189 */     System.out.println("  -m  modify directory or jar instead of creating an external index file");
/* 190 */     System.out.println("  -o  name the external index file file-name");
/* 191 */     System.out.println("  -j  export the index file to a jar file");
/* 192 */     System.out.println("  -d  dump the index file index-file-name");
/* 193 */     System.out.println("\nThe default behavior, with no options specified, is to autogenerate an external index file");
/*     */   }
/*     */   
/*     */   private void parseOptions(String[] args) {
/* 197 */     int optionCount = 0;
/*     */     
/* 199 */     for (int i = 0; i < args.length; i++) {
/* 200 */       String arg = args[i];
/* 201 */       if (arg.length() < 2 || arg.charAt(0) != '-') {
/* 202 */         if (this.source != null) {
/* 203 */           throw new IllegalArgumentException("Only one source location can be specified");
/*     */         }
/* 205 */         this.source = new File(arg);
/* 206 */         if (!this.source.exists()) {
/* 207 */           throw new IllegalArgumentException("Source directory/jar not found: " + this.source.getName());
/*     */         }
/*     */       } else {
/*     */         String name;
/*     */         
/* 212 */         switch (arg.charAt(1)) {
/*     */           case 'm':
/* 214 */             this.modify = true;
/* 215 */             optionCount++;
/*     */             break;
/*     */           case 'd':
/* 218 */             this.dump = true;
/* 219 */             optionCount++;
/*     */             break;
/*     */           case 'v':
/* 222 */             this.verbose = true;
/* 223 */             optionCount++;
/*     */             break;
/*     */           case 'j':
/* 226 */             this.jarFile = true;
/* 227 */             optionCount++;
/*     */             break;
/*     */           case 'o':
/* 230 */             if (i >= args.length) {
/* 231 */               throw new IllegalArgumentException("-o requires an output file name");
/*     */             }
/* 233 */             name = args[++i];
/* 234 */             if (name.length() < 1) {
/* 235 */               throw new IllegalArgumentException("-o requires an output file name");
/*     */             }
/* 237 */             this.outputFile = new File(name);
/* 238 */             optionCount++;
/*     */             break;
/*     */           default:
/* 241 */             throw new IllegalArgumentException("Option not understood: " + arg);
/*     */         } 
/*     */       } 
/*     */     } 
/* 245 */     if (this.source == null) {
/* 246 */       throw new IllegalArgumentException("Source location not specified");
/*     */     }
/* 248 */     if (this.outputFile != null && this.modify) {
/* 249 */       throw new IllegalArgumentException("-o and -m are mutually exclusive");
/*     */     }
/* 251 */     if (this.dump && optionCount != 1)
/* 252 */       throw new IllegalArgumentException("-d can not be specified with other options"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */