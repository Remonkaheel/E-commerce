/*      */ package org.jboss.jandex;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class IndexWriterV2
/*      */   extends IndexWriterImpl
/*      */ {
/*      */   static final int MIN_VERSION = 6;
/*      */   static final int MAX_VERSION = 12;
/*      */   private static final int MAGIC = -1161945323;
/*      */   private static final byte NULL_TARGET_TAG = 0;
/*      */   private static final byte FIELD_TAG = 1;
/*      */   private static final byte METHOD_TAG = 2;
/*      */   private static final byte METHOD_PARAMETER_TAG = 3;
/*      */   private static final byte CLASS_TAG = 4;
/*      */   private static final byte EMPTY_TYPE_TAG = 5;
/*      */   private static final byte CLASS_EXTENDS_TYPE_TAG = 6;
/*      */   private static final byte TYPE_PARAMETER_TAG = 7;
/*      */   private static final byte TYPE_PARAMETER_BOUND_TAG = 8;
/*      */   private static final byte METHOD_PARAMETER_TYPE_TAG = 9;
/*      */   private static final byte THROWS_TYPE_TAG = 10;
/*      */   private static final byte RECORD_COMPONENT_TAG = 11;
/*      */   private static final int AVALUE_BYTE = 1;
/*      */   private static final int AVALUE_SHORT = 2;
/*      */   private static final int AVALUE_INT = 3;
/*      */   private static final int AVALUE_CHAR = 4;
/*      */   private static final int AVALUE_FLOAT = 5;
/*      */   private static final int AVALUE_DOUBLE = 6;
/*      */   private static final int AVALUE_LONG = 7;
/*      */   private static final int AVALUE_BOOLEAN = 8;
/*      */   private static final int AVALUE_STRING = 9;
/*      */   private static final int AVALUE_CLASS = 10;
/*      */   private static final int AVALUE_ENUM = 11;
/*      */   private static final int AVALUE_ARRAY = 12;
/*      */   private static final int AVALUE_NESTED = 13;
/*      */   private static final int HAS_ENCLOSING_METHOD = 1;
/*      */   private static final int NO_ENCLOSING_METHOD = 0;
/*      */   private static final int NO_NESTING = 0;
/*      */   private static final int HAS_NESTING = 1;
/*      */   private final OutputStream out;
/*      */   private final int version;
/*      */   private NameTable names;
/*      */   private HashMap<DotName, Integer> nameTable;
/*      */   private TreeMap<String, DotName> sortedNameTable;
/*      */   private ReferenceTable<AnnotationInstance> annotationTable;
/*      */   private ReferenceTable<Type> typeTable;
/*      */   private ReferenceTable<Type[]> typeListTable;
/*      */   
/*      */   static class ReferenceEntry
/*      */   {
/*      */     private int index;
/*      */     private boolean written;
/*      */     
/*      */     ReferenceEntry(int index) {
/*  106 */       this.index = index;
/*      */     }
/*      */   }
/*      */   
/*      */   static class ReferenceTable<T> {
/*  111 */     private IdentityHashMap<T, IndexWriterV2.ReferenceEntry> references = new IdentityHashMap<>();
/*  112 */     private List<T> table = new ArrayList<>();
/*  113 */     private int counter = 1;
/*      */     
/*      */     void addReference(T reference) {
/*  116 */       if (this.references.containsKey(reference)) {
/*      */         return;
/*      */       }
/*      */       
/*  120 */       int index = this.counter++;
/*  121 */       this.references.put(reference, new IndexWriterV2.ReferenceEntry(index));
/*  122 */       this.table.add(reference);
/*      */     }
/*      */     
/*      */     private IndexWriterV2.ReferenceEntry getReferenceEntry(T reference) {
/*  126 */       IndexWriterV2.ReferenceEntry entry = this.references.get(reference);
/*  127 */       if (entry == null) {
/*  128 */         throw new IllegalStateException("Missing in reference table: " + reference);
/*      */       }
/*  130 */       return entry;
/*      */     }
/*      */     
/*      */     int positionOf(T reference) {
/*  134 */       IndexWriterV2.ReferenceEntry entry = getReferenceEntry(reference);
/*      */       
/*  136 */       return entry.index;
/*      */     }
/*      */     
/*      */     boolean markWritten(T reference) {
/*  140 */       IndexWriterV2.ReferenceEntry entry = getReferenceEntry(reference);
/*      */       
/*  142 */       boolean ret = entry.written;
/*  143 */       if (!ret) {
/*  144 */         entry.written = true;
/*      */       }
/*      */       
/*  147 */       return !ret;
/*      */     }
/*      */     
/*      */     List<T> list() {
/*  151 */       return this.table;
/*      */     }
/*      */     
/*      */     int size() {
/*  155 */       return this.references.size();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IndexWriterV2(OutputStream out, int version) {
/*  165 */     this.out = out;
/*  166 */     this.version = version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int write(Index index) throws IOException {
/*  180 */     if (this.version < 6 || this.version > 12) {
/*  181 */       throw new UnsupportedVersion("Can't write index version " + this.version + "; this IndexWriterV2 only supports index versions " + '\006' + "-" + '\f');
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  186 */     PackedDataOutputStream stream = new PackedDataOutputStream(new BufferedOutputStream(this.out));
/*  187 */     stream.writeInt(-1161945323);
/*  188 */     stream.writeByte(this.version);
/*  189 */     stream.writePackedU32(index.annotations.size());
/*  190 */     stream.writePackedU32(index.implementors.size());
/*  191 */     if (this.version >= 11) {
/*  192 */       stream.writePackedU32(index.subinterfaces.size());
/*      */     }
/*  194 */     stream.writePackedU32(index.subclasses.size());
/*  195 */     if (this.version >= 10) {
/*  196 */       stream.writePackedU32(index.users.size());
/*      */     }
/*      */     
/*  199 */     buildTables(index);
/*  200 */     writeByteTable(stream);
/*  201 */     writeStringTable(stream);
/*  202 */     writeNameTable(stream);
/*      */ 
/*      */     
/*  205 */     stream.writePackedU32(this.typeTable.size());
/*  206 */     stream.writePackedU32(this.typeListTable.size());
/*  207 */     stream.writePackedU32(this.annotationTable.size());
/*      */     
/*  209 */     writeTypeTable(stream);
/*  210 */     writeTypeListTable(stream);
/*  211 */     if (this.version >= 10) {
/*  212 */       writeUsersTable(stream, index.users);
/*      */     }
/*  214 */     writeMethodTable(stream);
/*  215 */     writeFieldTable(stream);
/*  216 */     if (this.version >= 10) {
/*  217 */       writeRecordComponentTable(stream);
/*      */     }
/*  219 */     writeClasses(stream, index);
/*      */     
/*  221 */     if (this.version >= 10) {
/*  222 */       writeModules(stream, index);
/*      */     }
/*      */     
/*  225 */     stream.flush();
/*  226 */     return stream.size();
/*      */   }
/*      */   
/*      */   private void writeUsersTable(PackedDataOutputStream stream, Map<DotName, ClassInfo[]> users) throws IOException {
/*  230 */     for (Map.Entry<DotName, ClassInfo[]> entry : users.entrySet()) {
/*  231 */       writeUsersSet(stream, entry.getKey(), entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeUsersSet(PackedDataOutputStream stream, DotName user, ClassInfo[] uses) throws IOException {
/*  236 */     stream.writePackedU32(positionOf(user));
/*  237 */     stream.writePackedU32(uses.length);
/*  238 */     for (ClassInfo use : uses) {
/*  239 */       stream.writePackedU32(positionOf(use.name()));
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeStringTable(PackedDataOutputStream stream) throws IOException {
/*  244 */     StrongInternPool<String> stringPool = this.names.stringPool();
/*  245 */     stream.writePackedU32(stringPool.size());
/*  246 */     Iterator<String> iterator = stringPool.iterator();
/*  247 */     while (iterator.hasNext()) {
/*  248 */       String string = iterator.next();
/*  249 */       stream.writeUTF(string);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeByteTable(PackedDataOutputStream stream) throws IOException {
/*  254 */     StrongInternPool<byte[]> bytePool = this.names.bytePool();
/*  255 */     stream.writePackedU32(bytePool.size());
/*  256 */     Iterator<byte[]> iterator = (Iterator)bytePool.iterator();
/*  257 */     while (iterator.hasNext()) {
/*  258 */       byte[] bytes = iterator.next();
/*  259 */       stream.writePackedU32(bytes.length);
/*  260 */       stream.write(bytes);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeTypeTable(PackedDataOutputStream stream) throws IOException {
/*  265 */     List<Type> types = this.typeTable.list();
/*  266 */     for (Type type : types) {
/*  267 */       writeTypeEntry(stream, type);
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeTypeListTable(PackedDataOutputStream stream) throws IOException {
/*  272 */     List<Type[]> typeLists = (List)this.typeListTable.list();
/*  273 */     for (Type[] types : typeLists) {
/*  274 */       if (markWritten(types)) {
/*  275 */         writeTypeListEntry(stream, types);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeTypeListEntry(PackedDataOutputStream stream, Type[] types) throws IOException {
/*  281 */     stream.writePackedU32(types.length);
/*  282 */     for (Type type : types) {
/*  283 */       stream.writePackedU32(positionOf(type));
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeMethodTable(PackedDataOutputStream stream) throws IOException {
/*  288 */     StrongInternPool<MethodInternal> methodPool = this.names.methodPool();
/*  289 */     stream.writePackedU32(methodPool.size());
/*  290 */     Iterator<MethodInternal> iterator = methodPool.iterator();
/*  291 */     while (iterator.hasNext()) {
/*  292 */       writeMethodEntry(stream, iterator.next());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeFieldTable(PackedDataOutputStream stream) throws IOException {
/*  297 */     StrongInternPool<FieldInternal> fieldPool = this.names.fieldPool();
/*  298 */     stream.writePackedU32(fieldPool.size());
/*  299 */     Iterator<FieldInternal> iterator = fieldPool.iterator();
/*  300 */     while (iterator.hasNext()) {
/*  301 */       writeFieldEntry(stream, iterator.next());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeRecordComponentTable(PackedDataOutputStream stream) throws IOException {
/*  306 */     StrongInternPool<RecordComponentInternal> recordComponentPool = this.names.recordComponentPool();
/*  307 */     stream.writePackedU32(recordComponentPool.size());
/*  308 */     Iterator<RecordComponentInternal> iterator = recordComponentPool.iterator();
/*  309 */     while (iterator.hasNext()) {
/*  310 */       writeRecordComponentEntry(stream, iterator.next());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeFieldEntry(PackedDataOutputStream stream, FieldInternal field) throws IOException {
/*  315 */     stream.writePackedU32(positionOf(field.nameBytes()));
/*  316 */     stream.writePackedU32(field.flags());
/*  317 */     stream.writePackedU32(positionOf(field.type()));
/*  318 */     writeAnnotations(stream, field.annotationArray());
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeRecordComponentEntry(PackedDataOutputStream stream, RecordComponentInternal recordComponent) throws IOException {
/*  323 */     stream.writePackedU32(positionOf(recordComponent.nameBytes()));
/*  324 */     stream.writePackedU32(positionOf(recordComponent.type()));
/*  325 */     writeAnnotations(stream, recordComponent.annotationArray());
/*      */   }
/*      */   
/*      */   private void writeMethodEntry(PackedDataOutputStream stream, MethodInternal method) throws IOException {
/*  329 */     stream.writePackedU32(positionOf(method.nameBytes()));
/*  330 */     stream.writePackedU32(method.flags());
/*  331 */     stream.writePackedU32(positionOf(method.typeParameterArray()));
/*  332 */     Type receiverType = method.receiverTypeField();
/*  333 */     stream.writePackedU32((receiverType == null) ? 0 : positionOf(receiverType));
/*  334 */     stream.writePackedU32(positionOf(method.returnType()));
/*  335 */     stream.writePackedU32(positionOf(method.parameterTypesArray()));
/*  336 */     if (this.version >= 11) {
/*  337 */       stream.writePackedU32(positionOf(method.descriptorParameterTypesArray()));
/*      */     }
/*  339 */     stream.writePackedU32(positionOf(method.exceptionArray()));
/*  340 */     if (this.version >= 7) {
/*  341 */       AnnotationValue defaultValue = method.defaultValue();
/*  342 */       stream.writeByte((defaultValue != null) ? 1 : 0);
/*  343 */       if (defaultValue != null) {
/*  344 */         writeAnnotationValue(stream, defaultValue);
/*      */       }
/*      */     } 
/*  347 */     if (this.version >= 8) {
/*  348 */       byte[][] parameterNamesBytes = method.parameterNamesBytes();
/*  349 */       stream.writePackedU32(parameterNamesBytes.length);
/*  350 */       for (byte[] parameterName : parameterNamesBytes) {
/*  351 */         stream.writePackedU32(positionOf(parameterName));
/*      */       }
/*      */     } 
/*      */     
/*  355 */     writeAnnotations(stream, method.annotationArray());
/*      */   }
/*      */   
/*      */   private void writeAnnotation(PackedDataOutputStream stream, AnnotationInstance instance) throws IOException {
/*  359 */     stream.writePackedU32(positionOf(instance.name()));
/*  360 */     AnnotationTarget target = instance.target();
/*  361 */     writeAnnotationTarget(stream, target);
/*  362 */     writeAnnotationValues(stream, instance.values());
/*  363 */     if (this.version >= 11) {
/*  364 */       stream.writeBoolean(instance.runtimeVisible());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeAnnotationTarget(PackedDataOutputStream stream, AnnotationTarget target) throws IOException {
/*  369 */     if (target instanceof FieldInfo) {
/*  370 */       stream.writeByte(1);
/*  371 */     } else if (target instanceof MethodInfo) {
/*  372 */       stream.writeByte(2);
/*  373 */     } else if (target instanceof MethodParameterInfo) {
/*  374 */       MethodParameterInfo param = (MethodParameterInfo)target;
/*  375 */       stream.writeByte(3);
/*  376 */       stream.writePackedU32(param.position());
/*  377 */     } else if (target instanceof ClassInfo) {
/*  378 */       stream.writeByte(4);
/*  379 */     } else if (target instanceof TypeTarget) {
/*  380 */       writeTypeTarget(stream, (TypeTarget)target);
/*  381 */     } else if (target instanceof RecordComponentInfo) {
/*  382 */       stream.writeByte(11);
/*  383 */     } else if (target == null) {
/*  384 */       stream.writeByte(0);
/*      */     } else {
/*  386 */       throw new IllegalStateException("Unknown target");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeTypeTarget(PackedDataOutputStream stream, TypeTarget typeTarget) throws IOException {
/*  391 */     switch (typeTarget.usage()) {
/*      */       case CLASS:
/*  393 */         writeTypeTargetFields(stream, (byte)5, typeTarget);
/*  394 */         stream.writeByte(typeTarget.asEmpty().isReceiver() ? 1 : 0);
/*      */         break;
/*      */       
/*      */       case ARRAY:
/*  398 */         writeTypeTargetFields(stream, (byte)6, typeTarget);
/*  399 */         stream.writePackedU32(typeTarget.asClassExtends().position());
/*      */         break;
/*      */       
/*      */       case PRIMITIVE:
/*  403 */         writeTypeTargetFields(stream, (byte)9, typeTarget);
/*  404 */         stream.writePackedU32(typeTarget.asMethodParameterType().position());
/*      */         break;
/*      */       
/*      */       case VOID:
/*  408 */         writeTypeTargetFields(stream, (byte)7, typeTarget);
/*  409 */         stream.writePackedU32(typeTarget.asTypeParameter().position());
/*      */         break;
/*      */       
/*      */       case TYPE_VARIABLE:
/*  413 */         writeTypeTargetFields(stream, (byte)8, typeTarget);
/*  414 */         stream.writePackedU32(typeTarget.asTypeParameterBound().position());
/*  415 */         stream.writePackedU32(typeTarget.asTypeParameterBound().boundPosition());
/*      */         break;
/*      */       
/*      */       case UNRESOLVED_TYPE_VARIABLE:
/*  419 */         writeTypeTargetFields(stream, (byte)10, typeTarget);
/*  420 */         stream.writePackedU32(typeTarget.asThrows().position());
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeTypeTargetFields(PackedDataOutputStream stream, byte tag, TypeTarget target) throws IOException {
/*  427 */     stream.writeByte(tag);
/*  428 */     Type type = target.target();
/*  429 */     stream.writePackedU32((type == null) ? 0 : positionOf(type));
/*      */   }
/*      */   
/*      */   private void writeNameTable(PackedDataOutputStream stream) throws IOException {
/*  433 */     stream.writePackedU32(this.nameTable.size());
/*      */ 
/*      */     
/*  436 */     int pos = 1;
/*  437 */     for (Map.Entry<String, DotName> entry : this.sortedNameTable.entrySet()) {
/*  438 */       this.nameTable.put(entry.getValue(), Integer.valueOf(pos));
/*  439 */       DotName name = entry.getValue();
/*  440 */       assert name.isComponentized();
/*      */       
/*  442 */       if (this.version >= 11) {
/*      */ 
/*      */ 
/*      */         
/*  446 */         int prefixPosition = (name.prefix() == null) ? 0 : positionOf(name.prefix());
/*  447 */         int prefixOffset = (prefixPosition == 0) ? 0 : (pos - prefixPosition);
/*      */         
/*  449 */         int prefixOffsetToWrite = prefixOffset << 1 | (name.isInner() ? 1 : 0);
/*  450 */         stream.writePackedU32(prefixOffsetToWrite);
/*  451 */         stream.writePackedU32(positionOf(name.local()));
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  456 */         int nameDepth = 0;
/*  457 */         for (DotName prefix = name.prefix(); prefix != null; prefix = prefix.prefix()) {
/*  458 */           nameDepth++;
/*      */         }
/*  460 */         nameDepth = nameDepth << 1 | (name.isInner() ? 1 : 0);
/*      */         
/*  462 */         stream.writePackedU32(nameDepth);
/*  463 */         stream.writePackedU32(positionOf(name.local()));
/*      */       } 
/*      */       
/*  466 */       pos++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int positionOf(String string) {
/*  471 */     int pos = this.names.positionOf(string);
/*  472 */     if (pos < 1) {
/*  473 */       throw new IllegalStateException("Intern tables incomplete");
/*      */     }
/*      */     
/*  476 */     return pos;
/*      */   }
/*      */   
/*      */   private int positionOf(byte[] bytes) {
/*  480 */     int pos = this.names.positionOf(bytes);
/*  481 */     if (pos < 1) {
/*  482 */       throw new IllegalStateException("Intern tables incomplete");
/*      */     }
/*  484 */     return pos;
/*      */   }
/*      */   
/*      */   private int positionOf(MethodInternal method) {
/*  488 */     int pos = this.names.positionOf(method);
/*  489 */     if (pos < 1) {
/*  490 */       throw new IllegalStateException("Intern tables incomplete");
/*      */     }
/*  492 */     return pos;
/*      */   }
/*      */   
/*      */   private int positionOf(FieldInternal field) {
/*  496 */     int pos = this.names.positionOf(field);
/*  497 */     if (pos < 1) {
/*  498 */       throw new IllegalStateException("Intern tables incomplete");
/*      */     }
/*  500 */     return pos;
/*      */   }
/*      */   
/*      */   private int positionOf(RecordComponentInternal recordComponent) {
/*  504 */     int pos = this.names.positionOf(recordComponent);
/*  505 */     if (pos < 1) {
/*  506 */       throw new IllegalStateException("Intern tables incomplete");
/*      */     }
/*  508 */     return pos;
/*      */   }
/*      */   
/*      */   private int positionOf(DotName className) {
/*  512 */     Integer i = this.nameTable.get(className);
/*  513 */     if (i == null) {
/*  514 */       throw new IllegalStateException("Class not found in class table: " + className);
/*      */     }
/*  516 */     return i.intValue();
/*      */   }
/*      */   
/*      */   private int positionOf(Type type) {
/*  520 */     return this.typeTable.positionOf(type);
/*      */   }
/*      */   
/*      */   private int positionOf(Type[] types) {
/*  524 */     return this.typeListTable.positionOf(types);
/*      */   }
/*      */   
/*      */   private int positionOf(AnnotationInstance instance) {
/*  528 */     return this.annotationTable.positionOf(instance);
/*      */   }
/*      */   
/*      */   private boolean markWritten(Type[] types) {
/*  532 */     return this.typeListTable.markWritten(types);
/*      */   }
/*      */   
/*      */   private boolean markWritten(AnnotationInstance annotation) {
/*  536 */     return this.annotationTable.markWritten(annotation);
/*      */   }
/*      */   
/*      */   private void writeClasses(PackedDataOutputStream stream, Index index) throws IOException {
/*  540 */     Collection<ClassInfo> classes = index.getKnownClasses();
/*  541 */     stream.writePackedU32(classes.size());
/*  542 */     for (ClassInfo clazz : classes) {
/*  543 */       writeClassEntry(stream, clazz);
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeModules(PackedDataOutputStream stream, Index index) throws IOException {
/*  548 */     Collection<ModuleInfo> modules = index.getKnownModules();
/*  549 */     stream.writePackedU32(modules.size());
/*  550 */     addClassName(DotName.createSimple("module-info"));
/*      */     
/*  552 */     for (ModuleInfo module : modules) {
/*  553 */       writeClassEntry(stream, module.moduleInfoClass());
/*  554 */       writeModuleEntry(stream, module);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeClassEntry(PackedDataOutputStream stream, ClassInfo clazz) throws IOException {
/*  559 */     stream.writePackedU32(positionOf(clazz.name()));
/*  560 */     stream.writePackedU32(clazz.flags());
/*  561 */     if (this.version >= 11) {
/*  562 */       stream.writeBoolean(clazz.hasNoArgsConstructor());
/*      */     }
/*  564 */     stream.writePackedU32((clazz.superClassType() == null) ? 0 : positionOf(clazz.superClassType()));
/*      */     
/*  566 */     stream.writePackedU32(positionOf(clazz.typeParameterArray()));
/*  567 */     stream.writePackedU32(positionOf(clazz.interfaceTypeArray()));
/*      */     
/*  569 */     ClassInfo.EnclosingMethodInfo enclosingMethod = clazz.enclosingMethod();
/*  570 */     boolean hasNesting = (clazz.nestingType() != ClassInfo.NestingType.TOP_LEVEL);
/*      */     
/*  572 */     if (this.version >= 9) {
/*  573 */       int mask = 0;
/*  574 */       if (hasNesting) {
/*  575 */         mask = ((enclosingMethod != null) ? 2 : 0) | 0x1;
/*      */       }
/*  577 */       stream.writeByte(mask);
/*      */     } 
/*      */     
/*  580 */     if (hasNesting || this.version < 9) {
/*  581 */       DotName enclosingClass = clazz.enclosingClass();
/*  582 */       String simpleName = clazz.nestingSimpleName();
/*      */       
/*  584 */       stream.writePackedU32((enclosingClass == null) ? 0 : positionOf(enclosingClass));
/*  585 */       stream.writePackedU32((simpleName == null) ? 0 : positionOf(simpleName));
/*      */       
/*  587 */       if (enclosingMethod == null) {
/*  588 */         if (this.version < 9) {
/*  589 */           stream.writeByte(0);
/*      */         }
/*      */       } else {
/*  592 */         if (this.version < 9) {
/*  593 */           stream.writeByte(1);
/*      */         }
/*  595 */         stream.writePackedU32(positionOf(enclosingMethod.name()));
/*  596 */         stream.writePackedU32(positionOf(enclosingMethod.enclosingClass()));
/*  597 */         stream.writePackedU32(positionOf(enclosingMethod.returnType()));
/*  598 */         stream.writePackedU32(positionOf(enclosingMethod.parametersArray()));
/*      */       } 
/*      */     } 
/*      */     
/*  602 */     if (this.version >= 11) {
/*  603 */       stream.writePackedU32(clazz.memberClasses().size());
/*  604 */       for (DotName memberClass : clazz.memberClasses()) {
/*  605 */         stream.writePackedU32(positionOf(memberClass));
/*      */       }
/*      */     } 
/*      */     
/*  609 */     if (this.version >= 12) {
/*  610 */       stream.writePackedU32(clazz.permittedSubclasses().size());
/*  611 */       for (DotName permittedSubclass : clazz.permittedSubclasses()) {
/*  612 */         stream.writePackedU32(positionOf(permittedSubclass));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  617 */     stream.writePackedU32(clazz.annotationsMap().size());
/*      */     
/*  619 */     FieldInternal[] fields = clazz.fieldArray();
/*  620 */     stream.writePackedU32(fields.length);
/*  621 */     for (FieldInternal field : fields) {
/*  622 */       stream.writePackedU32(positionOf(field));
/*      */     }
/*      */     
/*  625 */     if (this.version >= 10) {
/*  626 */       stream.writePackedU32(positionOf(clazz.fieldPositionArray()));
/*      */     }
/*      */     
/*  629 */     MethodInternal[] methods = clazz.methodArray();
/*  630 */     stream.writePackedU32(methods.length);
/*  631 */     for (MethodInternal method : methods) {
/*  632 */       stream.writePackedU32(positionOf(method));
/*      */     }
/*      */     
/*  635 */     if (this.version >= 10) {
/*  636 */       stream.writePackedU32(positionOf(clazz.methodPositionArray()));
/*      */     }
/*      */     
/*  639 */     if (this.version >= 10) {
/*  640 */       RecordComponentInternal[] recordComponents = clazz.recordComponentArray();
/*  641 */       stream.writePackedU32(recordComponents.length);
/*  642 */       for (RecordComponentInternal recordComponent : recordComponents) {
/*  643 */         stream.writePackedU32(positionOf(recordComponent));
/*      */       }
/*      */       
/*  646 */       stream.writePackedU32(positionOf(clazz.recordComponentPositionArray()));
/*      */     } 
/*      */     
/*  649 */     Set<Map.Entry<DotName, List<AnnotationInstance>>> entrySet = clazz.annotationsMap().entrySet();
/*  650 */     for (Map.Entry<DotName, List<AnnotationInstance>> entry : entrySet) {
/*  651 */       writeAnnotations(stream, entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeModuleEntry(PackedDataOutputStream stream, ModuleInfo module) throws IOException {
/*  656 */     stream.writePackedU32(positionOf(module.name()));
/*  657 */     stream.writePackedU32(module.flags());
/*  658 */     stream.writePackedU32((module.version() == null) ? 0 : positionOf(module.version()));
/*  659 */     stream.writePackedU32((module.mainClass() == null) ? 0 : positionOf(module.mainClass()));
/*      */ 
/*      */     
/*  662 */     List<ModuleInfo.RequiredModuleInfo> requires = module.requiresList();
/*  663 */     stream.writePackedU32(requires.size());
/*      */     
/*  665 */     for (ModuleInfo.RequiredModuleInfo required : requires) {
/*  666 */       stream.writePackedU32(positionOf(required.name()));
/*  667 */       stream.writePackedU32(required.flags());
/*  668 */       stream.writePackedU32((required.version() == null) ? 0 : positionOf(required.version()));
/*      */     } 
/*      */ 
/*      */     
/*  672 */     List<ModuleInfo.ExportedPackageInfo> exports = module.exportsList();
/*  673 */     stream.writePackedU32(exports.size());
/*      */     
/*  675 */     for (ModuleInfo.ExportedPackageInfo exported : exports) {
/*  676 */       stream.writePackedU32(positionOf(exported.source()));
/*  677 */       stream.writePackedU32(exported.flags());
/*  678 */       writeDotNames(stream, exported.targetsList());
/*      */     } 
/*      */ 
/*      */     
/*  682 */     writeDotNames(stream, module.usesList());
/*      */ 
/*      */     
/*  685 */     List<ModuleInfo.OpenedPackageInfo> opens = module.opensList();
/*  686 */     stream.writePackedU32(opens.size());
/*      */     
/*  688 */     for (ModuleInfo.OpenedPackageInfo opened : opens) {
/*  689 */       stream.writePackedU32(positionOf(opened.source()));
/*  690 */       stream.writePackedU32(opened.flags());
/*  691 */       writeDotNames(stream, opened.targetsList());
/*      */     } 
/*      */ 
/*      */     
/*  695 */     List<ModuleInfo.ProvidedServiceInfo> provides = module.providesList();
/*  696 */     stream.writePackedU32(provides.size());
/*      */     
/*  698 */     for (ModuleInfo.ProvidedServiceInfo provided : provides) {
/*  699 */       stream.writePackedU32(positionOf(provided.service()));
/*  700 */       writeDotNames(stream, provided.providersList());
/*      */     } 
/*      */ 
/*      */     
/*  704 */     writeDotNames(stream, module.packagesList());
/*      */   }
/*      */   
/*      */   private void writeDotNames(PackedDataOutputStream stream, List<DotName> names) throws IOException {
/*  708 */     stream.writePackedU32(names.size());
/*      */     
/*  710 */     for (DotName name : names) {
/*  711 */       stream.writePackedU32(positionOf(name));
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeAnnotationValues(PackedDataOutputStream stream, Collection<AnnotationValue> values) throws IOException {
/*  716 */     stream.writePackedU32(values.size());
/*  717 */     for (AnnotationValue value : values) {
/*  718 */       writeAnnotationValue(stream, value);
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeAnnotationValue(PackedDataOutputStream stream, AnnotationValue value) throws IOException {
/*  723 */     stream.writePackedU32(positionOf(value.name()));
/*  724 */     if (value instanceof AnnotationValue.ByteValue) {
/*  725 */       stream.writeByte(1);
/*  726 */       stream.writeByte(value.asByte() & 0xFF);
/*  727 */     } else if (value instanceof AnnotationValue.ShortValue) {
/*  728 */       stream.writeByte(2);
/*  729 */       stream.writePackedU32(value.asShort() & 0xFFFF);
/*  730 */     } else if (value instanceof AnnotationValue.IntegerValue) {
/*  731 */       stream.writeByte(3);
/*  732 */       stream.writePackedU32(value.asInt());
/*  733 */     } else if (value instanceof AnnotationValue.CharacterValue) {
/*  734 */       stream.writeByte(4);
/*  735 */       stream.writePackedU32(value.asChar());
/*  736 */     } else if (value instanceof AnnotationValue.FloatValue) {
/*  737 */       stream.writeByte(5);
/*  738 */       stream.writeFloat(value.asFloat());
/*  739 */     } else if (value instanceof AnnotationValue.DoubleValue) {
/*  740 */       stream.writeByte(6);
/*  741 */       stream.writeDouble(value.asDouble());
/*  742 */     } else if (value instanceof AnnotationValue.LongValue) {
/*  743 */       stream.writeByte(7);
/*  744 */       stream.writeLong(value.asLong());
/*  745 */     } else if (value instanceof AnnotationValue.BooleanValue) {
/*  746 */       stream.writeByte(8);
/*  747 */       stream.writeBoolean(value.asBoolean());
/*  748 */     } else if (value instanceof AnnotationValue.StringValue) {
/*  749 */       stream.writeByte(9);
/*  750 */       stream.writePackedU32(positionOf(value.asString()));
/*  751 */     } else if (value instanceof AnnotationValue.ClassValue) {
/*  752 */       stream.writeByte(10);
/*  753 */       stream.writePackedU32(positionOf(value.asClass()));
/*  754 */     } else if (value instanceof AnnotationValue.EnumValue) {
/*  755 */       stream.writeByte(11);
/*  756 */       stream.writePackedU32(positionOf(value.asEnumType()));
/*  757 */       stream.writePackedU32(positionOf(value.asEnum()));
/*  758 */     } else if (value instanceof AnnotationValue.ArrayValue) {
/*  759 */       AnnotationValue[] array = value.asArray();
/*  760 */       int length = array.length;
/*  761 */       stream.writeByte(12);
/*  762 */       stream.writePackedU32(length);
/*      */       
/*  764 */       for (AnnotationValue anArray : array) {
/*  765 */         writeAnnotationValue(stream, anArray);
/*      */       }
/*  767 */     } else if (value instanceof AnnotationValue.NestedAnnotation) {
/*  768 */       AnnotationInstance instance = value.asNested();
/*      */       
/*  770 */       stream.writeByte(13);
/*  771 */       writeReferenceOrFull(stream, instance);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeReference(PackedDataOutputStream stream, Type type, boolean nullable) throws IOException {
/*  776 */     if (nullable && type == null) {
/*  777 */       stream.writePackedU32(0);
/*      */       
/*      */       return;
/*      */     } 
/*  781 */     stream.writePackedU32(positionOf(type));
/*      */   }
/*      */   
/*      */   private void writeAnnotations(PackedDataOutputStream stream, AnnotationInstance[] annotations) throws IOException {
/*  785 */     if (this.version >= 11) {
/*  786 */       stream.writePackedU32(annotations.length);
/*      */       
/*  788 */       for (AnnotationInstance annotation : annotations) {
/*  789 */         writeReferenceOrFull(stream, annotation);
/*      */       }
/*      */     } else {
/*      */       
/*  793 */       int count = 0;
/*      */       
/*  795 */       for (AnnotationInstance annotation : annotations) {
/*  796 */         if (annotation.runtimeVisible()) {
/*  797 */           count++;
/*      */         }
/*      */       } 
/*      */       
/*  801 */       stream.writePackedU32(count);
/*      */       
/*  803 */       if (count > 0) {
/*  804 */         for (AnnotationInstance annotation : annotations) {
/*  805 */           if (annotation.runtimeVisible()) {
/*  806 */             writeReferenceOrFull(stream, annotation);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeAnnotations(PackedDataOutputStream stream, Collection<AnnotationInstance> annotations) throws IOException {
/*  815 */     if (annotations.isEmpty()) {
/*  816 */       writeAnnotations(stream, AnnotationInstance.EMPTY_ARRAY);
/*      */     } else {
/*  818 */       writeAnnotations(stream, annotations.<AnnotationInstance>toArray(new AnnotationInstance[annotations.size()]));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeReferenceOrFull(PackedDataOutputStream stream, AnnotationInstance annotation) throws IOException {
/*  823 */     stream.writePackedU32(positionOf(annotation));
/*  824 */     if (markWritten(annotation)) {
/*  825 */       writeAnnotation(stream, annotation);
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeReferenceOrFull(PackedDataOutputStream stream, Type[] types) throws IOException {
/*  830 */     stream.writePackedU32(positionOf(types));
/*  831 */     if (markWritten(types))
/*  832 */       writeTypeListEntry(stream, types);  } private void writeTypeEntry(PackedDataOutputStream stream, Type type) throws IOException { ArrayType arrayType; TypeVariable typeVariable; WildcardType wildcardType;
/*      */     boolean hasImplicitBound;
/*      */     ParameterizedType parameterizedType;
/*      */     Type owner;
/*      */     TypeVariableReference reference;
/*  837 */     if (this.version < 11 && type.kind() == Type.Kind.TYPE_VARIABLE_REFERENCE) {
/*      */       
/*  839 */       stream.writeByte(Type.Kind.UNRESOLVED_TYPE_VARIABLE.ordinal());
/*      */     } else {
/*  841 */       stream.writeByte(type.kind().ordinal());
/*      */     } 
/*      */     
/*  844 */     switch (type.kind()) {
/*      */       case CLASS:
/*  846 */         stream.writePackedU32(positionOf(type.name()));
/*      */         break;
/*      */       case ARRAY:
/*  849 */         arrayType = type.asArrayType();
/*  850 */         stream.writePackedU32(arrayType.dimensions());
/*  851 */         writeReference(stream, arrayType.component(), false);
/*      */         break;
/*      */       case PRIMITIVE:
/*  854 */         stream.writeByte(type.asPrimitiveType().primitive().ordinal());
/*      */         break;
/*      */ 
/*      */       
/*      */       case TYPE_VARIABLE:
/*  859 */         typeVariable = type.asTypeVariable();
/*  860 */         stream.writePackedU32(positionOf(typeVariable.identifier()));
/*  861 */         writeReferenceOrFull(stream, typeVariable.boundArray());
/*      */         break;
/*      */       case UNRESOLVED_TYPE_VARIABLE:
/*  864 */         stream.writePackedU32(positionOf(type.asUnresolvedTypeVariable().identifier()));
/*      */         break;
/*      */       case WILDCARD_TYPE:
/*  867 */         wildcardType = type.asWildcardType();
/*  868 */         stream.writePackedU32(wildcardType.isExtends() ? 1 : 0);
/*  869 */         hasImplicitBound = wildcardType.hasImplicitObjectBound();
/*  870 */         writeReference(stream, hasImplicitBound ? null : wildcardType.bound(), hasImplicitBound);
/*      */         break;
/*      */       case PARAMETERIZED_TYPE:
/*  873 */         parameterizedType = type.asParameterizedType();
/*  874 */         owner = parameterizedType.owner();
/*  875 */         stream.writePackedU32(positionOf(parameterizedType.name()));
/*  876 */         writeReference(stream, owner, true);
/*  877 */         writeReferenceOrFull(stream, parameterizedType.argumentsArray());
/*      */         break;
/*      */       case TYPE_VARIABLE_REFERENCE:
/*  880 */         if (this.version < 11) {
/*      */           
/*  882 */           stream.writePackedU32(positionOf(type.asTypeVariableReference().identifier())); break;
/*      */         } 
/*  884 */         reference = type.asTypeVariableReference();
/*  885 */         stream.writePackedU32(positionOf(reference.identifier()));
/*  886 */         stream.writePackedU32(positionOf(reference.follow()));
/*  887 */         if (this.version >= 12) {
/*  888 */           stream.writePackedU32(positionOf(reference.internalClassName()));
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  894 */     writeAnnotations(stream, type.annotationArray()); }
/*      */ 
/*      */   
/*      */   private void buildTables(Index index) {
/*  898 */     this.nameTable = new HashMap<>();
/*  899 */     this.sortedNameTable = new TreeMap<>();
/*      */     
/*  901 */     this.annotationTable = new ReferenceTable<>();
/*  902 */     this.typeTable = new ReferenceTable<>();
/*  903 */     this.typeListTable = (ReferenceTable)new ReferenceTable<>();
/*  904 */     this.names = new NameTable();
/*      */ 
/*      */     
/*  907 */     for (ClassInfo clazz : index.getKnownClasses()) {
/*  908 */       addClass(clazz);
/*      */     }
/*      */     
/*  911 */     if (this.version >= 10) {
/*  912 */       for (ModuleInfo module : index.getKnownModules()) {
/*  913 */         addClass(module.moduleInfoClass());
/*  914 */         addModule(module);
/*      */       } 
/*      */       
/*  917 */       if (index.users != null) {
/*  918 */         for (Map.Entry<DotName, ClassInfo[]> entry : index.users.entrySet()) {
/*  919 */           addClassName(entry.getKey());
/*  920 */           for (ClassInfo classInfo : (ClassInfo[])entry.getValue()) {
/*  921 */             addClassName(classInfo.name());
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addClass(ClassInfo clazz) {
/*  929 */     addClassName(clazz.name());
/*  930 */     if (clazz.superName() != null) {
/*  931 */       addClassName(clazz.superName());
/*      */     }
/*  933 */     addTypeList(clazz.typeParameterArray());
/*  934 */     addTypeList(clazz.interfaceTypeArray());
/*  935 */     addType(clazz.superClassType());
/*      */ 
/*      */     
/*  938 */     DotName enclosingClass = clazz.enclosingClass();
/*  939 */     if (enclosingClass != null) {
/*  940 */       addClassName(enclosingClass);
/*      */     }
/*  942 */     String name = clazz.nestingSimpleName();
/*  943 */     if (name != null) {
/*  944 */       addString(name);
/*      */     }
/*  946 */     addEnclosingMethod(clazz.enclosingMethod());
/*      */     
/*  948 */     for (DotName memberClass : clazz.memberClasses()) {
/*  949 */       addClassName(memberClass);
/*      */     }
/*  951 */     for (DotName permittedSubclass : clazz.permittedSubclasses()) {
/*  952 */       addClassName(permittedSubclass);
/*      */     }
/*      */     
/*  955 */     addMethodList(clazz.methodArray());
/*  956 */     this.names.intern(clazz.methodPositionArray());
/*      */     
/*  958 */     addFieldList(clazz.fieldArray());
/*  959 */     this.names.intern(clazz.fieldPositionArray());
/*      */     
/*  961 */     addRecordComponentList(clazz.recordComponentArray());
/*  962 */     this.names.intern(clazz.recordComponentPositionArray());
/*      */     
/*  964 */     for (Map.Entry<DotName, List<AnnotationInstance>> entry : clazz.annotationsMap().entrySet()) {
/*  965 */       addClassName(entry.getKey());
/*      */       
/*  967 */       for (AnnotationInstance instance : entry.getValue()) {
/*  968 */         addAnnotation(instance);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addModule(ModuleInfo module) {
/*  974 */     addClassName(module.name());
/*  975 */     addNullableString(module.version());
/*  976 */     DotName mainClass = module.mainClass();
/*  977 */     if (mainClass != null) {
/*  978 */       addClassName(mainClass);
/*      */     }
/*      */     
/*  981 */     for (ModuleInfo.RequiredModuleInfo required : module.requires()) {
/*  982 */       addClassName(required.name());
/*  983 */       addNullableString(required.version());
/*      */     } 
/*      */     
/*  986 */     for (ModuleInfo.ExportedPackageInfo exported : module.exports()) {
/*  987 */       addClassName(exported.source());
/*  988 */       addClassNames(exported.targets());
/*      */     } 
/*      */     
/*  991 */     for (ModuleInfo.OpenedPackageInfo opened : module.opens()) {
/*  992 */       addClassName(opened.source());
/*  993 */       addClassNames(opened.targets());
/*      */     } 
/*      */     
/*  996 */     addClassNames(module.uses());
/*      */     
/*  998 */     for (ModuleInfo.ProvidedServiceInfo provided : module.provides()) {
/*  999 */       addClassName(provided.service());
/* 1000 */       addClassNames(provided.providers());
/*      */     } 
/*      */     
/* 1003 */     addClassNames(module.packages());
/*      */   }
/*      */   
/*      */   private void addAnnotation(AnnotationInstance instance) {
/* 1007 */     addClassName(instance.name());
/* 1008 */     for (AnnotationValue value : instance.values()) {
/* 1009 */       buildAValueEntries(value);
/*      */     }
/*      */     
/* 1012 */     addAnnotationTarget(instance.target());
/* 1013 */     this.annotationTable.addReference(instance);
/*      */   }
/*      */ 
/*      */   
/*      */   private void addAnnotationTarget(AnnotationTarget target) {}
/*      */ 
/*      */   
/*      */   private void addFieldList(FieldInternal[] fields) {
/* 1021 */     for (FieldInternal field : fields) {
/* 1022 */       deepIntern(field);
/*      */     }
/*      */   }
/*      */   
/*      */   private void deepIntern(FieldInternal field) {
/* 1027 */     addType(field.type());
/* 1028 */     this.names.intern(field.nameBytes());
/* 1029 */     this.names.intern(field);
/*      */   }
/*      */   
/*      */   private void addMethodList(MethodInternal[] methods) {
/* 1033 */     for (MethodInternal method : methods) {
/* 1034 */       deepIntern(method);
/*      */     }
/*      */   }
/*      */   
/*      */   private void deepIntern(MethodInternal method) {
/* 1039 */     addType(method.returnType());
/* 1040 */     addType(method.receiverTypeField());
/* 1041 */     addTypeList(method.typeParameterArray());
/* 1042 */     addTypeList(method.parameterTypesArray());
/* 1043 */     addTypeList(method.descriptorParameterTypesArray());
/* 1044 */     addTypeList(method.exceptionArray());
/* 1045 */     AnnotationValue defaultValue = method.defaultValue();
/* 1046 */     if (defaultValue != null) {
/* 1047 */       buildAValueEntries(defaultValue);
/*      */     }
/* 1049 */     for (byte[] parameterName : method.parameterNamesBytes()) {
/* 1050 */       this.names.intern(parameterName);
/*      */     }
/* 1052 */     this.names.intern(method.nameBytes());
/* 1053 */     this.names.intern(method);
/*      */   }
/*      */   
/*      */   private void addRecordComponentList(RecordComponentInternal[] recordComponents) {
/* 1057 */     for (RecordComponentInternal recordComponent : recordComponents) {
/* 1058 */       deepIntern(recordComponent);
/*      */     }
/*      */   }
/*      */   
/*      */   private void deepIntern(RecordComponentInternal recordComponent) {
/* 1063 */     addType(recordComponent.type());
/* 1064 */     this.names.intern(recordComponent.nameBytes());
/* 1065 */     this.names.intern(recordComponent);
/*      */   }
/*      */   
/*      */   private void addEnclosingMethod(ClassInfo.EnclosingMethodInfo enclosingMethod) {
/* 1069 */     if (enclosingMethod == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1073 */     addString(enclosingMethod.name());
/* 1074 */     addType(enclosingMethod.returnType());
/* 1075 */     addTypeList(enclosingMethod.parametersArray());
/* 1076 */     addClassName(enclosingMethod.enclosingClass());
/*      */   }
/*      */   
/*      */   private void addTypeList(Type[] types) {
/* 1080 */     for (Type type : types) {
/* 1081 */       addType(type);
/*      */     }
/*      */     
/* 1084 */     this.typeListTable.addReference(types);
/*      */   } private void addType(Type type) {
/*      */     TypeVariable typeVariable;
/*      */     ParameterizedType parameterizedType;
/* 1088 */     if (type == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1092 */     switch (type.kind()) {
/*      */       case CLASS:
/* 1094 */         addClassName(type.asClassType().name());
/*      */         break;
/*      */       case ARRAY:
/* 1097 */         addType(type.asArrayType().component());
/*      */         break;
/*      */       case TYPE_VARIABLE:
/* 1100 */         typeVariable = type.asTypeVariable();
/* 1101 */         addString(typeVariable.identifier());
/* 1102 */         addTypeList(typeVariable.boundArray());
/*      */         break;
/*      */       
/*      */       case UNRESOLVED_TYPE_VARIABLE:
/* 1106 */         addString(type.asUnresolvedTypeVariable().identifier());
/*      */         break;
/*      */       case WILDCARD_TYPE:
/* 1109 */         addType(type.asWildcardType().bound());
/*      */         break;
/*      */       case PARAMETERIZED_TYPE:
/* 1112 */         parameterizedType = type.asParameterizedType();
/* 1113 */         addClassName(parameterizedType.name());
/* 1114 */         addType(parameterizedType.owner());
/* 1115 */         addTypeList(parameterizedType.argumentsArray());
/*      */         break;
/*      */       case TYPE_VARIABLE_REFERENCE:
/* 1118 */         addString(type.asTypeVariableReference().identifier());
/* 1119 */         addClassName(type.asTypeVariableReference().internalClassName());
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1128 */     for (AnnotationInstance instance : type.annotationArray()) {
/* 1129 */       addAnnotation(instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     this.typeTable.addReference(type);
/*      */   }
/*      */   
/*      */   private void buildAValueEntries(AnnotationValue value) {
/* 1140 */     addString(value.name());
/*      */     
/* 1142 */     if (value instanceof AnnotationValue.StringValue) {
/* 1143 */       addString(value.asString());
/* 1144 */     } else if (value instanceof AnnotationValue.ClassValue) {
/* 1145 */       addType(value.asClass());
/* 1146 */     } else if (value instanceof AnnotationValue.EnumValue) {
/* 1147 */       addClassName(value.asEnumType());
/* 1148 */       addString(value.asEnum());
/* 1149 */     } else if (value instanceof AnnotationValue.ArrayValue) {
/* 1150 */       for (AnnotationValue entry : value.asArray())
/* 1151 */         buildAValueEntries(entry); 
/* 1152 */     } else if (value instanceof AnnotationValue.NestedAnnotation) {
/* 1153 */       AnnotationInstance instance = value.asNested();
/* 1154 */       addAnnotation(instance);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String addNullableString(String name) {
/* 1159 */     if (name != null) {
/* 1160 */       return addString(name);
/*      */     }
/* 1162 */     return null;
/*      */   }
/*      */   
/*      */   private String addString(String name) {
/* 1166 */     return this.names.intern(name);
/*      */   }
/*      */   
/*      */   private void addClassNames(List<DotName> names) {
/* 1170 */     for (DotName name : names) {
/* 1171 */       addClassName(name);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addClassName(DotName name) {
/* 1176 */     if (!this.nameTable.containsKey(name)) {
/* 1177 */       addString(name.local());
/* 1178 */       this.nameTable.put(name, null);
/* 1179 */       this.sortedNameTable.put(name.toString(), name);
/*      */     } 
/*      */     
/* 1182 */     DotName prefix = name.prefix();
/* 1183 */     if (prefix != null)
/* 1184 */       addClassName(prefix); 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexWriterV2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */