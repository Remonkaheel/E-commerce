/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NameTable
/*     */ {
/*  30 */   private StrongInternPool<String> stringPool = StrongInternPool.forStrings();
/*  31 */   private StrongInternPool<Type> typePool = StrongInternPool.forTypes();
/*  32 */   private StrongInternPool<Type[]> typeListPool = StrongInternPool.forTypeArrays();
/*  33 */   private StrongInternPool<byte[]> bytePool = StrongInternPool.forByteArrays();
/*  34 */   private StrongInternPool<MethodInternal> methodPool = StrongInternPool.forMethods();
/*  35 */   private StrongInternPool<FieldInternal> fieldPool = StrongInternPool.forFields();
/*  36 */   private StrongInternPool<RecordComponentInternal> recordComponentPool = StrongInternPool.forRecordComponents();
/*  37 */   private Map<String, DotName> names = new HashMap<>();
/*     */   
/*     */   DotName convertToName(String name) {
/*  40 */     return convertToName(name, '.');
/*     */   }
/*     */   
/*     */   DotName convertToName(String name, char delim) {
/*  44 */     DotName result = this.names.get(name);
/*  45 */     if (result != null) {
/*  46 */       return result;
/*     */     }
/*  48 */     int loc = lastIndexOf(name, delim);
/*  49 */     String local = intern(name.substring(loc + 1));
/*  50 */     DotName prefix = (loc < 1) ? null : convertToName(intern(name.substring(0, loc)), delim);
/*  51 */     result = new DotName(prefix, local, true, (loc > 0 && name.charAt(loc) == '$'));
/*     */     
/*  53 */     this.names.put(name, result);
/*     */     
/*  55 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private int lastIndexOf(String name, char delim) {
/*  60 */     int pos = name.length() - 1;
/*  61 */     while (--pos >= 0) {
/*  62 */       char c = name.charAt(pos);
/*  63 */       if (c == delim || c == '$') {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     if (pos >= 0 && name.charAt(pos) == '$' && (pos == 0 || name.charAt(pos - 1) == delim)) {
/*  72 */       pos--;
/*     */     }
/*     */     
/*  75 */     return pos;
/*     */   }
/*     */   
/*     */   DotName wrap(DotName prefix, String local, boolean inner) {
/*  79 */     DotName name = new DotName(prefix, intern(local), true, true);
/*     */     
/*  81 */     return intern(name, '.');
/*     */   }
/*     */   
/*     */   String intern(String string) {
/*  85 */     return this.stringPool.intern(string);
/*     */   }
/*     */   
/*     */   int positionOf(String string) {
/*  89 */     return this.stringPool.index().positionOf((E)string);
/*     */   }
/*     */   
/*     */   Type intern(Type type) {
/*  93 */     return this.typePool.intern(type);
/*     */   }
/*     */   
/*     */   Type[] intern(Type[] types) {
/*  97 */     return this.typeListPool.intern(types);
/*     */   }
/*     */   
/*     */   byte[] intern(byte[] bytes) {
/* 101 */     return this.bytePool.intern(bytes);
/*     */   }
/*     */   
/*     */   int positionOf(byte[] bytes) {
/* 105 */     return this.bytePool.index().positionOf((E)bytes);
/*     */   }
/*     */   
/*     */   MethodInternal intern(MethodInternal methodInternal) {
/* 109 */     return this.methodPool.intern(methodInternal);
/*     */   }
/*     */   
/*     */   int positionOf(MethodInternal methodInternal) {
/* 113 */     return this.methodPool.index().positionOf((E)methodInternal);
/*     */   }
/*     */   
/*     */   FieldInternal intern(FieldInternal fieldInternal) {
/* 117 */     return this.fieldPool.intern(fieldInternal);
/*     */   }
/*     */   
/*     */   int positionOf(FieldInternal fieldInternal) {
/* 121 */     return this.fieldPool.index().positionOf((E)fieldInternal);
/*     */   }
/*     */   
/*     */   RecordComponentInternal intern(RecordComponentInternal recordComponentInternal) {
/* 125 */     return this.recordComponentPool.intern(recordComponentInternal);
/*     */   }
/*     */   
/*     */   int positionOf(RecordComponentInternal recordComponentInternal) {
/* 129 */     return this.recordComponentPool.index().positionOf((E)recordComponentInternal);
/*     */   }
/*     */   
/*     */   StrongInternPool<String> stringPool() {
/* 133 */     return this.stringPool;
/*     */   }
/*     */   
/*     */   StrongInternPool<byte[]> bytePool() {
/* 137 */     return this.bytePool;
/*     */   }
/*     */   
/*     */   StrongInternPool<MethodInternal> methodPool() {
/* 141 */     return this.methodPool;
/*     */   }
/*     */   
/*     */   StrongInternPool<FieldInternal> fieldPool() {
/* 145 */     return this.fieldPool;
/*     */   }
/*     */   
/*     */   StrongInternPool<RecordComponentInternal> recordComponentPool() {
/* 149 */     return this.recordComponentPool;
/*     */   }
/*     */   
/*     */   DotName intern(DotName dotName, char delim) {
/* 153 */     String name = dotName.toString(delim);
/* 154 */     DotName old = this.names.get(name);
/* 155 */     if (old == null) {
/* 156 */       old = dotName;
/* 157 */       this.names.put(name, dotName);
/*     */     } 
/*     */     
/* 160 */     return old;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\NameTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */