/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AnnotationOverlay
/*     */ {
/*     */   static Builder builder(IndexView index, Collection<AnnotationTransformation> annotationTransformations) {
/*  35 */     Objects.requireNonNull(index);
/*  36 */     if (annotationTransformations == null) {
/*  37 */       annotationTransformations = Collections.emptyList();
/*     */     }
/*  39 */     return new Builder(index, annotationTransformations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IndexView index();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasAnnotation(Declaration paramDeclaration, DotName paramDotName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasAnnotation(Declaration declaration, Class<? extends Annotation> clazz) {
/*  77 */     return hasAnnotation(declaration, DotName.createSimple(clazz.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasAnyAnnotation(Declaration paramDeclaration, Set<DotName> paramSet);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasAnyAnnotation(Declaration declaration, Class<? extends Annotation>... classes) {
/* 105 */     Set<DotName> names = new HashSet<>(classes.length);
/* 106 */     for (Class<? extends Annotation> clazz : classes) {
/* 107 */       names.add(DotName.createSimple(clazz.getName()));
/*     */     }
/* 109 */     return hasAnyAnnotation(declaration, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationInstance annotation(Declaration paramDeclaration, DotName paramDotName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default AnnotationInstance annotation(Declaration declaration, Class<? extends Annotation> clazz) {
/* 140 */     return annotation(declaration, DotName.createSimple(clazz.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<AnnotationInstance> annotationsWithRepeatable(Declaration paramDeclaration, DotName paramDotName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Collection<AnnotationInstance> annotationsWithRepeatable(Declaration declaration, Class<? extends Annotation> clazz) {
/* 182 */     return annotationsWithRepeatable(declaration, DotName.createSimple(clazz.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<AnnotationInstance> annotations(Declaration paramDeclaration);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final IndexView index;
/*     */ 
/*     */     
/*     */     private final Collection<AnnotationTransformation> annotationTransformations;
/*     */ 
/*     */     
/*     */     private boolean compatibleMode;
/*     */ 
/*     */     
/*     */     private boolean runtimeAnnotationsOnly;
/*     */ 
/*     */     
/*     */     private boolean inheritedAnnotations;
/*     */ 
/*     */ 
/*     */     
/*     */     Builder(IndexView index, Collection<AnnotationTransformation> annotationTransformations) {
/* 210 */       this.index = index;
/* 211 */       this.annotationTransformations = annotationTransformations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder compatibleMode() {
/* 226 */       this.compatibleMode = true;
/* 227 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder runtimeAnnotationsOnly() {
/* 240 */       this.runtimeAnnotationsOnly = true;
/* 241 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder inheritedAnnotations() {
/* 251 */       this.inheritedAnnotations = true;
/* 252 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationOverlay build() {
/* 261 */       return new AnnotationOverlayImpl(this.index, this.compatibleMode, this.runtimeAnnotationsOnly, this.inheritedAnnotations, this.annotationTransformations);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */