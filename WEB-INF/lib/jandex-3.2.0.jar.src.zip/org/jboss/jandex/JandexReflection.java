/*     */ package org.jboss.jandex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JandexReflection
/*     */ {
/*     */   public static Class<?> loadRawType(Type type) {
/*  39 */     if (type == null) {
/*  40 */       return null;
/*     */     }
/*     */     
/*  43 */     switch (type.kind()) {
/*     */       case VOID:
/*  45 */         return void.class;
/*     */       case PRIMITIVE:
/*  47 */         switch (type.asPrimitiveType().primitive()) {
/*     */           case VOID:
/*  49 */             return boolean.class;
/*     */           case PRIMITIVE:
/*  51 */             return byte.class;
/*     */           case CLASS:
/*  53 */             return short.class;
/*     */           case PARAMETERIZED_TYPE:
/*  55 */             return int.class;
/*     */           case ARRAY:
/*  57 */             return long.class;
/*     */           case WILDCARD_TYPE:
/*  59 */             return float.class;
/*     */           case TYPE_VARIABLE:
/*  61 */             return double.class;
/*     */           case TYPE_VARIABLE_REFERENCE:
/*  63 */             return char.class;
/*     */         } 
/*  65 */         throw new IllegalArgumentException("Unknown primitive type: " + type);
/*     */       
/*     */       case CLASS:
/*     */       case PARAMETERIZED_TYPE:
/*     */       case ARRAY:
/*     */       case WILDCARD_TYPE:
/*     */       case TYPE_VARIABLE:
/*     */       case TYPE_VARIABLE_REFERENCE:
/*  73 */         return load(type.name());
/*     */       case UNRESOLVED_TYPE_VARIABLE:
/*  75 */         return Object.class;
/*     */     } 
/*  77 */     throw new IllegalArgumentException("Unknown type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(ClassInfo clazz) {
/*  90 */     if (clazz == null) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     return load(clazz.name());
/*     */   }
/*     */   
/*     */   private static Class<?> load(DotName name) {
/*     */     try {
/*  99 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 100 */       if (cl == null) {
/* 101 */         cl = JandexReflection.class.getClassLoader();
/*     */       }
/* 103 */       return Class.forName(name.toString(), false, cl);
/* 104 */     } catch (ClassNotFoundException e) {
/* 105 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\JandexReflection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */