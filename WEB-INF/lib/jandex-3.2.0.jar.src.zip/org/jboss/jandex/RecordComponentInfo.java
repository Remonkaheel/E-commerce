/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RecordComponentInfo
/*     */   implements Declaration, Descriptor, GenericSignature
/*     */ {
/*     */   private ClassInfo clazz;
/*     */   private RecordComponentInternal internal;
/*     */   
/*     */   RecordComponentInfo() {}
/*     */   
/*     */   RecordComponentInfo(ClassInfo clazz, RecordComponentInternal internal) {
/*  43 */     this.clazz = clazz;
/*  44 */     this.internal = internal;
/*     */   }
/*     */   
/*     */   RecordComponentInfo(ClassInfo clazz, byte[] name, Type type) {
/*  48 */     this(clazz, new RecordComponentInternal(name, type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecordComponentInfo create(ClassInfo clazz, String name, Type type) {
/*  60 */     if (clazz == null) {
/*  61 */       throw new IllegalArgumentException("Clazz can't be null");
/*     */     }
/*  63 */     if (name == null) {
/*  64 */       throw new IllegalArgumentException("Name can't be null");
/*     */     }
/*  66 */     return new RecordComponentInfo(clazz, Utils.toUTF8(name), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ClassInfo declaringClass() {
/*  75 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final FieldInfo field() {
/*  84 */     return this.clazz.field(this.internal.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MethodInfo accessor() {
/*  93 */     return this.clazz.method(this.internal.name(), new Type[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String name() {
/* 102 */     return this.internal.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type type() {
/* 111 */     return this.internal.type();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnnotation(DotName name) {
/* 123 */     return this.internal.hasAnnotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationInstance annotation(DotName name) {
/* 139 */     return this.internal.annotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotations(DotName name) {
/* 155 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 156 */     for (AnnotationInstance instance : this.internal.annotationArray()) {
/* 157 */       if (instance.name().equals(name)) {
/* 158 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 161 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 182 */     if (index == null) {
/* 183 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 185 */     List<AnnotationInstance> instances = new ArrayList<>(annotations(name));
/* 186 */     ClassInfo annotationClass = index.getClassByName(name);
/* 187 */     if (annotationClass == null) {
/* 188 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 190 */     if (!annotationClass.isAnnotation()) {
/* 191 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 193 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 194 */     if (repeatable != null) {
/* 195 */       Type containingType = repeatable.value().asClass();
/* 196 */       for (AnnotationInstance container : annotations(containingType.name())) {
/* 197 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 198 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       } 
/*     */     } 
/* 202 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotations() {
/* 213 */     return this.internal.annotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasDeclaredAnnotation(DotName name) {
/* 229 */     return (declaredAnnotation(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationInstance declaredAnnotation(DotName name) {
/* 245 */     for (AnnotationInstance instance : this.internal.annotationArray()) {
/* 246 */       if (instance.target().kind() == AnnotationTarget.Kind.RECORD_COMPONENT && instance.name().equals(name)) {
/* 247 */         return instance;
/*     */       }
/*     */     } 
/* 250 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> declaredAnnotationsWithRepeatable(DotName name, IndexView index) {
/* 273 */     if (index == null) {
/* 274 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 276 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 277 */     AnnotationInstance declaredInstance = declaredAnnotation(name);
/* 278 */     if (declaredInstance != null) {
/* 279 */       instances.add(declaredInstance);
/*     */     }
/* 281 */     ClassInfo annotationClass = index.getClassByName(name);
/* 282 */     if (annotationClass == null) {
/* 283 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 285 */     if (!annotationClass.isAnnotation()) {
/* 286 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 288 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 289 */     if (repeatable != null) {
/* 290 */       Type containingType = repeatable.value().asClass();
/* 291 */       AnnotationInstance container = declaredAnnotation(containingType.name());
/* 292 */       if (container != null) {
/* 293 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 294 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       }
/*     */     } 
/* 298 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> declaredAnnotations() {
/* 313 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 314 */     for (AnnotationInstance instance : this.internal.annotationArray()) {
/* 315 */       if (instance.target().kind() == AnnotationTarget.Kind.RECORD_COMPONENT) {
/* 316 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 319 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresGenericSignature() {
/* 330 */     return GenericSignatureReconstruction.requiresGenericSignature(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String genericSignature(Function<String, Type> typeVariableSubstitution) {
/* 350 */     return GenericSignatureReconstruction.reconstructGenericSignature(this, typeVariableSubstitution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String descriptor(Function<String, Type> typeVariableSubstitution) {
/* 368 */     return DescriptorReconstruction.recordComponentDescriptor(this, typeVariableSubstitution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 378 */     return this.internal.toString(this.clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ClassInfo asClass() {
/* 383 */     throw new IllegalArgumentException("Not a class");
/*     */   }
/*     */ 
/*     */   
/*     */   public final FieldInfo asField() {
/* 388 */     throw new IllegalArgumentException("Not a field");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodInfo asMethod() {
/* 393 */     throw new IllegalArgumentException("Not a method");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodParameterInfo asMethodParameter() {
/* 398 */     throw new IllegalArgumentException("Not a method parameter");
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypeTarget asType() {
/* 403 */     throw new IllegalArgumentException("Not a type");
/*     */   }
/*     */ 
/*     */   
/*     */   public final RecordComponentInfo asRecordComponent() {
/* 408 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationTarget.Kind kind() {
/* 413 */     return AnnotationTarget.Kind.RECORD_COMPONENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 418 */     int result = 1;
/* 419 */     result = 31 * result + this.clazz.hashCode();
/* 420 */     result = 31 * result + this.internal.hashCode();
/* 421 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 426 */     if (this == o) {
/* 427 */       return true;
/*     */     }
/* 429 */     if (o == null || getClass() != o.getClass()) {
/* 430 */       return false;
/*     */     }
/* 432 */     RecordComponentInfo other = (RecordComponentInfo)o;
/* 433 */     return (this.clazz.equals(other.clazz) && this.internal.equals(other.internal));
/*     */   }
/*     */   
/*     */   void setType(Type type) {
/* 437 */     this.internal.setType(type);
/*     */   }
/*     */   
/*     */   void setAnnotations(List<AnnotationInstance> annotations) {
/* 441 */     this.internal.setAnnotations(annotations);
/*     */   }
/*     */   
/*     */   RecordComponentInternal recordComponentInternal() {
/* 445 */     return this.internal;
/*     */   }
/*     */   
/*     */   void setRecordComponentInternal(RecordComponentInternal internal) {
/* 449 */     this.internal = internal;
/*     */   }
/*     */   
/*     */   void setClassInfo(ClassInfo clazz) {
/* 453 */     this.clazz = clazz;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\RecordComponentInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */