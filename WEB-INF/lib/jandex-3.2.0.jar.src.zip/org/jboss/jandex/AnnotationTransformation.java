/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AnnotationTransformation
/*     */ {
/*     */   public static final int DEFAULT_PRIORITY_VALUE = 1000;
/*     */   
/*     */   default int priority() {
/*  41 */     return 1000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean supports(AnnotationTarget.Kind kind) {
/*  55 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void apply(TransformationContext paramTransformationContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean requiresCompatibleMode() {
/*  76 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DeclarationBuilder builder() {
/* 194 */     return new DeclarationBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClassBuilder forClasses() {
/* 203 */     return new ClassBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FieldBuilder forFields() {
/* 212 */     return new FieldBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MethodBuilder forMethods() {
/* 221 */     return new MethodBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MethodParameterBuilder forMethodParameters() {
/* 230 */     return new MethodParameterBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RecordComponentBuilder forRecordComponents() {
/* 239 */     return new RecordComponentBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Builder<THIS extends Builder<THIS>>
/*     */   {
/*     */     private final AnnotationTarget.Kind kind;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Predicate<AnnotationTransformation.TransformationContext> predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder(AnnotationTarget.Kind kind) {
/* 274 */       this.kind = kind;
/* 275 */       this.priority = 1000;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS priority(int priority) {
/* 286 */       this.priority = priority;
/* 287 */       return self();
/*     */     }
/*     */     
/*     */     @SafeVarargs
/*     */     private static Predicate<AnnotationInstance> annotationPredicate(Class<? extends Annotation>... classes) {
/* 292 */       Objects.requireNonNull(classes);
/* 293 */       return annotation -> {
/*     */           String annotationName = annotation.name().toString();
/*     */           for (Class<? extends Annotation> clazz : classes) {
/*     */             if (annotationName.equals(clazz.getName())) {
/*     */               return true;
/*     */             }
/*     */           } 
/*     */           return false;
/*     */         };
/*     */     }
/*     */     
/*     */     private static Predicate<AnnotationInstance> annotationPredicate(DotName... classes) {
/* 305 */       Objects.requireNonNull(classes);
/* 306 */       return annotation -> {
/*     */           DotName annotationName = annotation.name();
/*     */           for (DotName clazz : classes) {
/*     */             if (annotationName.equals(clazz)) {
/*     */               return true;
/*     */             }
/*     */           } 
/*     */           return false;
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SafeVarargs
/*     */     public final THIS whenAnyMatch(Class<? extends Annotation>... classes) {
/* 328 */       Objects.requireNonNull(classes);
/* 329 */       return whenAnyMatch(annotationPredicate(classes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenAnyMatch(DotName... classes) {
/* 342 */       Objects.requireNonNull(classes);
/* 343 */       return whenAnyMatch(annotationPredicate(classes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenAnyMatch(List<DotName> classes) {
/* 356 */       Objects.requireNonNull(classes);
/* 357 */       return whenAnyMatch(classes.<DotName>toArray(new DotName[0]));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenAnyMatch(Predicate<AnnotationInstance> predicate) {
/* 370 */       Objects.requireNonNull(predicate);
/* 371 */       return when(ctx -> {
/*     */             Collection<AnnotationInstance> annotations = ctx.annotations();
/*     */             for (AnnotationInstance annotation : annotations) {
/*     */               if (predicate.test(annotation)) {
/*     */                 return true;
/*     */               }
/*     */             } 
/*     */             return false;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SafeVarargs
/*     */     public final THIS whenAllMatch(Class<? extends Annotation>... classes) {
/* 393 */       Objects.requireNonNull(classes);
/* 394 */       return whenAllMatch(annotationPredicate(classes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenAllMatch(DotName... classes) {
/* 407 */       Objects.requireNonNull(classes);
/* 408 */       return whenAllMatch(annotationPredicate(classes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenAllMatch(List<DotName> classes) {
/* 421 */       Objects.requireNonNull(classes);
/* 422 */       return whenAllMatch(classes.<DotName>toArray(new DotName[0]));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenAllMatch(Predicate<AnnotationInstance> predicate) {
/* 435 */       Objects.requireNonNull(predicate);
/* 436 */       return when(ctx -> {
/*     */             Collection<AnnotationInstance> annotations = ctx.annotations();
/*     */             for (AnnotationInstance annotation : annotations) {
/*     */               if (!predicate.test(annotation)) {
/*     */                 return false;
/*     */               }
/*     */             } 
/*     */             return true;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SafeVarargs
/*     */     public final THIS whenNoneMatch(Class<? extends Annotation>... classes) {
/* 458 */       Objects.requireNonNull(classes);
/* 459 */       return whenNoneMatch(annotationPredicate(classes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenNoneMatch(DotName... classes) {
/* 472 */       Objects.requireNonNull(classes);
/* 473 */       return whenNoneMatch(annotationPredicate(classes));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenNoneMatch(List<DotName> classes) {
/* 486 */       Objects.requireNonNull(classes);
/* 487 */       return whenNoneMatch(classes.<DotName>toArray(new DotName[0]));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final THIS whenNoneMatch(Predicate<AnnotationInstance> predicate) {
/* 500 */       Objects.requireNonNull(predicate);
/* 501 */       return when(ctx -> {
/*     */             Collection<AnnotationInstance> annotations = ctx.annotations();
/*     */             for (AnnotationInstance annotation : annotations) {
/*     */               if (predicate.test(annotation)) {
/*     */                 return false;
/*     */               }
/*     */             } 
/*     */             return true;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public THIS when(Predicate<AnnotationTransformation.TransformationContext> predicate) {
/* 521 */       Objects.requireNonNull(predicate);
/* 522 */       if (this.predicate == null) {
/* 523 */         this.predicate = predicate;
/*     */       } else {
/* 525 */         this.predicate = this.predicate.and(predicate);
/*     */       } 
/* 527 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationTransformation transform(final Consumer<AnnotationTransformation.TransformationContext> transformation) {
/* 537 */       Objects.requireNonNull(transformation);
/*     */       
/* 539 */       return new AnnotationTransformation()
/*     */         {
/*     */           public int priority() {
/* 542 */             return AnnotationTransformation.Builder.this.priority;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean supports(AnnotationTarget.Kind kind) {
/* 547 */             return (AnnotationTransformation.Builder.this.kind == null || AnnotationTransformation.Builder.this.kind == kind);
/*     */           }
/*     */ 
/*     */           
/*     */           public void apply(AnnotationTransformation.TransformationContext context) {
/* 552 */             if (AnnotationTransformation.Builder.this.predicate == null || AnnotationTransformation.Builder.this.predicate.test(context)) {
/* 553 */               transformation.accept(context);
/*     */             }
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     THIS self() {
/* 561 */       return (THIS)this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DeclarationBuilder
/*     */     extends Builder<DeclarationBuilder>
/*     */   {
/*     */     DeclarationBuilder() {
/* 573 */       super(null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DeclarationBuilder whenDeclaration(Predicate<Declaration> predicate) {
/* 586 */       Objects.requireNonNull(predicate);
/* 587 */       return when(ctx -> predicate.test(ctx.declaration()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ClassBuilder
/*     */     extends Builder<ClassBuilder>
/*     */   {
/*     */     ClassBuilder() {
/* 601 */       super(AnnotationTarget.Kind.CLASS);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassBuilder whenClass(Class<?> clazz) {
/* 614 */       Objects.requireNonNull(clazz);
/* 615 */       return whenClass(DotName.createSimple(clazz));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassBuilder whenClass(DotName name) {
/* 628 */       Objects.requireNonNull(name);
/* 629 */       return whenClass(clazz -> clazz.name().equals(name));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassBuilder whenClass(Predicate<ClassInfo> predicate) {
/* 642 */       Objects.requireNonNull(predicate);
/* 643 */       return when(ctx -> predicate.test(ctx.declaration().asClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FieldBuilder
/*     */     extends Builder<FieldBuilder>
/*     */   {
/*     */     FieldBuilder() {
/* 657 */       super(AnnotationTarget.Kind.FIELD);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldBuilder whenField(Class<?> clazz, String name) {
/* 671 */       Objects.requireNonNull(clazz);
/* 672 */       return whenField(DotName.createSimple(clazz), name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldBuilder whenField(DotName clazz, String name) {
/* 686 */       Objects.requireNonNull(clazz);
/* 687 */       Objects.requireNonNull(name);
/* 688 */       return whenField(field -> (field.name().equals(name) && field.declaringClass().name().equals(clazz)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldBuilder whenField(Predicate<FieldInfo> predicate) {
/* 701 */       Objects.requireNonNull(predicate);
/* 702 */       return when(ctx -> predicate.test(ctx.declaration().asField()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MethodBuilder
/*     */     extends Builder<MethodBuilder>
/*     */   {
/*     */     MethodBuilder() {
/* 716 */       super(AnnotationTarget.Kind.METHOD);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodBuilder whenMethod(Class<?> clazz, String name) {
/* 730 */       Objects.requireNonNull(clazz);
/* 731 */       return whenMethod(DotName.createSimple(clazz), name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodBuilder whenMethod(DotName clazz, String name) {
/* 745 */       Objects.requireNonNull(clazz);
/* 746 */       Objects.requireNonNull(name);
/* 747 */       return whenMethod(method -> (method.name().equals(name) && method.declaringClass().name().equals(clazz)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodBuilder whenMethod(Predicate<MethodInfo> predicate) {
/* 760 */       Objects.requireNonNull(predicate);
/* 761 */       return when(ctx -> predicate.test(ctx.declaration().asMethod()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MethodParameterBuilder
/*     */     extends Builder<MethodParameterBuilder>
/*     */   {
/*     */     MethodParameterBuilder() {
/* 775 */       super(AnnotationTarget.Kind.METHOD_PARAMETER);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodParameterBuilder whenMethodParameter(Class<?> clazz, String name) {
/* 789 */       Objects.requireNonNull(clazz);
/* 790 */       return whenMethodParameter(DotName.createSimple(clazz), name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodParameterBuilder whenMethodParameter(DotName clazz, String name) {
/* 804 */       Objects.requireNonNull(clazz);
/* 805 */       Objects.requireNonNull(name);
/* 806 */       return whenMethodParameter(param -> (param.method().name().equals(name) && param.method().declaringClass().name().equals(clazz)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodParameterBuilder whenMethodParameter(Predicate<MethodParameterInfo> predicate) {
/* 820 */       Objects.requireNonNull(predicate);
/* 821 */       return when(ctx -> predicate.test(ctx.declaration().asMethodParameter()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RecordComponentBuilder
/*     */     extends Builder<RecordComponentBuilder>
/*     */   {
/*     */     RecordComponentBuilder() {
/* 835 */       super(AnnotationTarget.Kind.RECORD_COMPONENT);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentBuilder whenRecordComponent(Class<?> clazz, String name) {
/* 849 */       Objects.requireNonNull(clazz);
/* 850 */       return whenRecordComponent(DotName.createSimple(clazz), name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentBuilder whenRecordComponent(DotName clazz, String name) {
/* 864 */       Objects.requireNonNull(clazz);
/* 865 */       Objects.requireNonNull(name);
/* 866 */       return whenRecordComponent(component -> (component.name().equals(name) && component.declaringClass().name().equals(clazz)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentBuilder whenRecordComponent(Predicate<RecordComponentInfo> predicate) {
/* 880 */       Objects.requireNonNull(predicate);
/* 881 */       return when(ctx -> predicate.test(ctx.declaration().asRecordComponent()));
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface TransformationContext {
/*     */     Declaration declaration();
/*     */     
/*     */     Collection<AnnotationInstance> annotations();
/*     */     
/*     */     boolean hasAnnotation(Class<? extends Annotation> param1Class);
/*     */     
/*     */     boolean hasAnnotation(DotName param1DotName);
/*     */     
/*     */     boolean hasAnnotation(Predicate<AnnotationInstance> param1Predicate);
/*     */     
/*     */     void add(Class<? extends Annotation> param1Class);
/*     */     
/*     */     void add(AnnotationInstance param1AnnotationInstance);
/*     */     
/*     */     void addAll(AnnotationInstance... param1VarArgs);
/*     */     
/*     */     void addAll(Collection<AnnotationInstance> param1Collection);
/*     */     
/*     */     void remove(Predicate<AnnotationInstance> param1Predicate);
/*     */     
/*     */     void removeAll();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationTransformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */