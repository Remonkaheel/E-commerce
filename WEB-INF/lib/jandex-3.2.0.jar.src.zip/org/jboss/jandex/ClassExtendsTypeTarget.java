/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassExtendsTypeTarget
/*    */   extends PositionBasedTypeTarget
/*    */ {
/*    */   ClassExtendsTypeTarget(ClassInfo enclosingTarget, int position) {
/* 46 */     super(enclosingTarget, position);
/*    */   }
/*    */   
/*    */   public ClassExtendsTypeTarget(AnnotationTarget enclosingTarget, Type target, int position) {
/* 50 */     super(enclosingTarget, target, position);
/*    */   }
/*    */ 
/*    */   
/*    */   public final TypeTarget.Usage usage() {
/* 55 */     return TypeTarget.Usage.CLASS_EXTENDS;
/*    */   }
/*    */ 
/*    */   
/*    */   public ClassInfo enclosingTarget() {
/* 60 */     return (ClassInfo)super.enclosingTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public ClassExtendsTypeTarget asClassExtends() {
/* 65 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ClassExtendsTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */