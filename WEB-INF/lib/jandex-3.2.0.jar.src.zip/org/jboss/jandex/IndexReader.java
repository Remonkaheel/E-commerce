/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IndexReader
/*     */ {
/*     */   private static final int MAGIC = -1161945323;
/*     */   private PackedDataInputStream input;
/*  49 */   private int version = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private IndexReaderImpl reader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexReader(InputStream input) {
/*  59 */     this.input = new PackedDataInputStream(new BufferedInputStream(input));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Index read() throws IOException {
/*  72 */     if (this.version == -1) {
/*  73 */       readVersion();
/*     */     }
/*     */     
/*  76 */     return this.reader.read();
/*     */   }
/*     */   
/*     */   private void initReader(int version) throws IOException {
/*     */     IndexReaderImpl reader;
/*  81 */     if (version >= 2 && version <= 3) {
/*  82 */       reader = new IndexReaderV1(this.input, version);
/*  83 */     } else if (version >= 6 && version <= 12) {
/*  84 */       reader = new IndexReaderV2(this.input, version);
/*     */     } else {
/*  86 */       this.input.close();
/*  87 */       throw new UnsupportedVersion("Can't read index version " + version + "; this IndexReader only supports index versions " + '\002' + "-" + '\003' + "," + '\006' + "-" + '\f');
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     this.reader = reader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndexVersion() throws IOException {
/* 105 */     if (this.version == -1) {
/* 106 */       readVersion();
/*     */     }
/*     */     
/* 109 */     return this.version;
/*     */   }
/*     */   
/*     */   private void readVersion() throws IOException {
/* 113 */     if (this.input.readInt() != -1161945323) {
/* 114 */       this.input.close();
/* 115 */       throw new IllegalArgumentException("Not a jandex index");
/*     */     } 
/*     */     
/* 118 */     this.version = this.input.readUnsignedByte();
/* 119 */     initReader(this.version);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */