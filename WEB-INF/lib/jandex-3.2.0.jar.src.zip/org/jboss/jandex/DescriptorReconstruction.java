/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ 
/*     */ final class DescriptorReconstruction {
/*     */   static String fieldDescriptor(FieldInfo field, Function<String, Type> typeVariableSubstitution) {
/*   7 */     FieldInternal internal = field.fieldInternal();
/*     */     
/*   9 */     StringBuilder result = new StringBuilder();
/*  10 */     typeDescriptor(internal.type(), typeVariableSubstitution, result);
/*  11 */     return result.toString();
/*     */   }
/*     */   
/*     */   static String methodDescriptor(MethodInfo method, Function<String, Type> typeVariableSubstitution) {
/*  15 */     MethodInternal internal = method.methodInternal();
/*     */     
/*  17 */     StringBuilder result = new StringBuilder();
/*  18 */     result.append('(');
/*  19 */     for (Type parameterType : internal.parameterTypesArray()) {
/*  20 */       typeDescriptor(parameterType, typeVariableSubstitution, result);
/*     */     }
/*  22 */     result.append(')');
/*  23 */     typeDescriptor(internal.returnType(), typeVariableSubstitution, result);
/*  24 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static String recordComponentDescriptor(RecordComponentInfo recordComponent, Function<String, Type> typeVariableSubstitution) {
/*  29 */     RecordComponentInternal internal = recordComponent.recordComponentInternal();
/*     */     
/*  31 */     StringBuilder result = new StringBuilder();
/*  32 */     typeDescriptor(internal.type(), typeVariableSubstitution, result);
/*  33 */     return result.toString(); } static void typeDescriptor(Type type, Function<String, Type> substitution, StringBuilder result) {
/*     */     PrimitiveType.Primitive primitive;
/*     */     ArrayType arrayType;
/*     */     int i;
/*  37 */     switch (type.kind()) {
/*     */       case VOID:
/*  39 */         result.append('V');
/*     */         return;
/*     */       case PRIMITIVE:
/*  42 */         primitive = type.asPrimitiveType().primitive();
/*  43 */         switch (primitive) {
/*     */           case VOID:
/*  45 */             result.append('Z');
/*     */             return;
/*     */           case PRIMITIVE:
/*  48 */             result.append('B');
/*     */             return;
/*     */           case ARRAY:
/*  51 */             result.append('S');
/*     */             return;
/*     */           case CLASS:
/*  54 */             result.append('I');
/*     */             return;
/*     */           case PARAMETERIZED_TYPE:
/*  57 */             result.append('J');
/*     */             return;
/*     */           case WILDCARD_TYPE:
/*  60 */             result.append('F');
/*     */             return;
/*     */           case TYPE_VARIABLE:
/*  63 */             result.append('D');
/*     */             return;
/*     */           case UNRESOLVED_TYPE_VARIABLE:
/*  66 */             result.append('C');
/*     */             return;
/*     */         } 
/*  69 */         throw new IllegalArgumentException("unkown primitive type " + primitive);
/*     */       
/*     */       case ARRAY:
/*  72 */         arrayType = type.asArrayType();
/*  73 */         for (i = 0; i < arrayType.dimensions(); i++) {
/*  74 */           result.append('[');
/*     */         }
/*  76 */         typeDescriptor(arrayType.component(), substitution, result);
/*     */         return;
/*     */       case CLASS:
/*     */       case PARAMETERIZED_TYPE:
/*     */       case WILDCARD_TYPE:
/*  81 */         objectTypeDescriptor(type.name(), result);
/*     */         return;
/*     */       case TYPE_VARIABLE:
/*  84 */         typeVariableDescriptor(type, type.asTypeVariable().identifier(), substitution, result);
/*     */         return;
/*     */       case UNRESOLVED_TYPE_VARIABLE:
/*  87 */         typeVariableDescriptor(type, type.asUnresolvedTypeVariable().identifier(), substitution, result);
/*     */         return;
/*     */       case TYPE_VARIABLE_REFERENCE:
/*  90 */         typeVariableDescriptor(type, type.asTypeVariableReference().identifier(), substitution, result);
/*     */         return;
/*     */     } 
/*  93 */     throw new IllegalArgumentException("unknown type " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   static void objectTypeDescriptor(DotName name, StringBuilder result) {
/*  98 */     result.append('L').append(name.toString('/')).append(';');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void typeVariableDescriptor(Type typeVariable, String typeVariableIdentifier, Function<String, Type> substitution, StringBuilder result) {
/* 105 */     Type type = (substitution == null) ? null : substitution.apply(typeVariableIdentifier);
/* 106 */     if (type == null || type == typeVariable) {
/* 107 */       objectTypeDescriptor(typeVariable.name(), result);
/*     */     } else {
/* 109 */       typeDescriptor(type, substitution, result);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\DescriptorReconstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */