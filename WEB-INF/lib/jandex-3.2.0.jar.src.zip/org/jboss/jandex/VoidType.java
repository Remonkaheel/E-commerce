/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidType
/*    */   extends Type
/*    */ {
/* 28 */   public static final VoidType VOID = new VoidType(null);
/*    */   
/*    */   private VoidType(AnnotationInstance[] annotations) {
/* 31 */     super(new DotName(null, "void", true, false), annotations);
/*    */   }
/*    */ 
/*    */   
/*    */   public Type.Kind kind() {
/* 36 */     return Type.Kind.VOID;
/*    */   }
/*    */ 
/*    */   
/*    */   public VoidType asVoidType() {
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 46 */     return new VoidType(newAnnotations);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\VoidType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */