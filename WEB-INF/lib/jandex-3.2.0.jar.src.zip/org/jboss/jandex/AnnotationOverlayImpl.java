/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ class AnnotationOverlayImpl
/*     */   implements AnnotationOverlay
/*     */ {
/*  19 */   private static final Set<AnnotationInstance> SENTINEL = Collections.unmodifiableSet(new HashSet<>());
/*     */   
/*     */   final IndexView index;
/*     */   final boolean compatibleMode;
/*     */   final boolean runtimeAnnotationsOnly;
/*     */   final boolean inheritedAnnotations;
/*     */   final List<AnnotationTransformation> transformations;
/*  26 */   final Map<EquivalenceKey, Set<AnnotationInstance>> overlay = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   AnnotationOverlayImpl(IndexView index, boolean compatibleMode, boolean runtimeAnnotationsOnly, boolean inheritedAnnotations, Collection<AnnotationTransformation> annotationTransformations) {
/*  30 */     this.index = index;
/*  31 */     this.compatibleMode = compatibleMode;
/*  32 */     this.runtimeAnnotationsOnly = runtimeAnnotationsOnly;
/*  33 */     this.inheritedAnnotations = inheritedAnnotations;
/*  34 */     if (!compatibleMode) {
/*  35 */       for (AnnotationTransformation transformation : annotationTransformations) {
/*  36 */         if (transformation.requiresCompatibleMode()) {
/*  37 */           throw new IllegalStateException("Compatible mode required by " + transformation);
/*     */         }
/*     */       } 
/*     */     }
/*  41 */     List<AnnotationTransformation> transformations = new ArrayList<>(annotationTransformations);
/*  42 */     transformations.sort(new Comparator<AnnotationTransformation>()
/*     */         {
/*     */           public int compare(AnnotationTransformation o1, AnnotationTransformation o2) {
/*  45 */             return Integer.compare(o2.priority(), o1.priority());
/*     */           }
/*     */         });
/*  48 */     this.transformations = transformations;
/*     */   }
/*     */ 
/*     */   
/*     */   public final IndexView index() {
/*  53 */     return this.index;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasAnnotation(Declaration declaration, DotName name) {
/*  58 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/*  59 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*  62 */     Collection<AnnotationInstance> annotations = getAnnotationsFor(declaration);
/*  63 */     for (AnnotationInstance annotation : annotations) {
/*  64 */       if (annotation.name().equals(name)) {
/*  65 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  69 */     if (this.inheritedAnnotations && declaration.kind() == AnnotationTarget.Kind.CLASS) {
/*  70 */       ClassInfo clazz = this.index.getClassByName(declaration.asClass().superName());
/*  71 */       while (clazz != null && !DotName.OBJECT_NAME.equals(clazz.name())) {
/*  72 */         for (AnnotationInstance annotation : getAnnotationsFor(clazz)) {
/*  73 */           ClassInfo annotationClass = this.index.getClassByName(annotation.name());
/*  74 */           if (annotationClass != null && annotationClass
/*  75 */             .hasDeclaredAnnotation(DotName.INHERITED_NAME) && annotation
/*  76 */             .name().equals(name)) {
/*  77 */             return true;
/*     */           }
/*     */         } 
/*  80 */         clazz = this.index.getClassByName(clazz.superName());
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasAnyAnnotation(Declaration declaration, Set<DotName> names) {
/*  89 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/*  90 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*  93 */     Collection<AnnotationInstance> annotations = getAnnotationsFor(declaration);
/*  94 */     for (AnnotationInstance annotation : annotations) {
/*  95 */       for (DotName name : names) {
/*  96 */         if (annotation.name().equals(name)) {
/*  97 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 102 */     if (this.inheritedAnnotations && declaration.kind() == AnnotationTarget.Kind.CLASS) {
/* 103 */       ClassInfo clazz = this.index.getClassByName(declaration.asClass().superName());
/* 104 */       while (clazz != null && !DotName.OBJECT_NAME.equals(clazz.name())) {
/* 105 */         for (AnnotationInstance annotation : getAnnotationsFor(clazz)) {
/* 106 */           ClassInfo annotationClass = this.index.getClassByName(annotation.name());
/* 107 */           if (annotationClass != null && annotationClass.hasDeclaredAnnotation(DotName.INHERITED_NAME)) {
/* 108 */             for (DotName name : names) {
/* 109 */               if (annotation.name().equals(name)) {
/* 110 */                 return true;
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/* 115 */         clazz = this.index.getClassByName(clazz.superName());
/*     */       } 
/*     */     } 
/*     */     
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final AnnotationInstance annotation(Declaration declaration, DotName name) {
/* 124 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/* 125 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/* 128 */     Collection<AnnotationInstance> annotations = getAnnotationsFor(declaration);
/* 129 */     for (AnnotationInstance annotation : annotations) {
/* 130 */       if (annotation.name().equals(name)) {
/* 131 */         return annotation;
/*     */       }
/*     */     } 
/*     */     
/* 135 */     if (this.inheritedAnnotations && declaration.kind() == AnnotationTarget.Kind.CLASS) {
/* 136 */       ClassInfo clazz = this.index.getClassByName(declaration.asClass().superName());
/* 137 */       while (clazz != null && !DotName.OBJECT_NAME.equals(clazz.name())) {
/* 138 */         for (AnnotationInstance annotation : getAnnotationsFor(clazz)) {
/* 139 */           ClassInfo annotationClass = this.index.getClassByName(annotation.name());
/* 140 */           if (annotationClass != null && annotationClass
/* 141 */             .hasDeclaredAnnotation(DotName.INHERITED_NAME) && annotation
/* 142 */             .name().equals(name)) {
/* 143 */             return annotation;
/*     */           }
/*     */         } 
/* 146 */         clazz = this.index.getClassByName(clazz.superName());
/*     */       } 
/*     */     } 
/*     */     
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Collection<AnnotationInstance> annotationsWithRepeatable(Declaration declaration, DotName name) {
/* 155 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/* 156 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/* 159 */     DotName containerName = null;
/*     */     
/* 161 */     ClassInfo annotationClass = this.index.getClassByName(name);
/* 162 */     if (annotationClass != null) {
/* 163 */       AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 164 */       if (repeatable != null) {
/* 165 */         containerName = repeatable.value().asClass().name();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 170 */     List<AnnotationInstance> result = new ArrayList<>();
/* 171 */     for (AnnotationInstance annotation : getAnnotationsFor(declaration)) {
/* 172 */       if (annotation.name().equals(name)) {
/* 173 */         result.add(annotation); continue;
/* 174 */       }  if (annotation.name().equals(containerName)) {
/* 175 */         AnnotationInstance[] nestedAnnotations = annotation.value().asNestedArray();
/* 176 */         for (AnnotationInstance nestedAnnotation : nestedAnnotations) {
/* 177 */           result.add(AnnotationInstance.create(nestedAnnotation, annotation.target()));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     if (this.inheritedAnnotations && declaration.kind() == AnnotationTarget.Kind.CLASS) {
/* 183 */       ClassInfo clazz = this.index.getClassByName(declaration.asClass().superName());
/* 184 */       while (result.isEmpty() && clazz != null && !DotName.OBJECT_NAME.equals(clazz.name())) {
/* 185 */         for (AnnotationInstance annotation : getAnnotationsFor(clazz)) {
/* 186 */           ClassInfo classInfo = this.index.getClassByName(annotation.name());
/* 187 */           if (classInfo != null && classInfo.hasDeclaredAnnotation(DotName.INHERITED_NAME)) {
/* 188 */             if (annotation.name().equals(name)) {
/* 189 */               result.add(annotation); continue;
/* 190 */             }  if (annotation.name().equals(containerName)) {
/* 191 */               AnnotationInstance[] nestedAnnotations = annotation.value().asNestedArray();
/* 192 */               for (AnnotationInstance nestedAnnotation : nestedAnnotations) {
/* 193 */                 result.add(AnnotationInstance.create(nestedAnnotation, annotation.target()));
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 198 */         clazz = this.index.getClassByName(clazz.superName());
/*     */       } 
/*     */     } 
/*     */     
/* 202 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Collection<AnnotationInstance> annotations(Declaration declaration) {
/* 207 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/* 208 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/* 211 */     Collection<AnnotationInstance> result = getAnnotationsFor(declaration);
/*     */     
/* 213 */     if (this.inheritedAnnotations && declaration.kind() == AnnotationTarget.Kind.CLASS) {
/* 214 */       result = new ArrayList<>(result);
/* 215 */       ClassInfo clazz = this.index.getClassByName(declaration.asClass().superName());
/* 216 */       while (clazz != null && !DotName.OBJECT_NAME.equals(clazz.name())) {
/* 217 */         for (AnnotationInstance annotation : getAnnotationsFor(clazz)) {
/* 218 */           ClassInfo annotationClass = this.index.getClassByName(annotation.name());
/* 219 */           if (annotationClass != null && annotationClass
/* 220 */             .hasDeclaredAnnotation(DotName.INHERITED_NAME) && result
/* 221 */             .stream().noneMatch(it -> it.name().equals(annotation.name()))) {
/* 222 */             result.add(annotation);
/*     */           }
/*     */         } 
/* 225 */         clazz = this.index.getClassByName(clazz.superName());
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     return Collections.unmodifiableCollection(result);
/*     */   }
/*     */   
/*     */   Set<AnnotationInstance> getAnnotationsFor(Declaration declaration) {
/* 233 */     EquivalenceKey key = EquivalenceKey.of(declaration);
/* 234 */     Set<AnnotationInstance> annotations = this.overlay.get(key);
/*     */     
/* 236 */     if (annotations == null) {
/* 237 */       Collection<AnnotationInstance> original = new HashSet<>(getOriginalAnnotations(declaration));
/* 238 */       TransformationContextImpl transformationContext = new TransformationContextImpl(declaration, original);
/* 239 */       for (AnnotationTransformation transformation : this.transformations) {
/* 240 */         if (transformation.supports(declaration.kind())) {
/* 241 */           transformation.apply(transformationContext);
/*     */         }
/*     */       } 
/* 244 */       Set<AnnotationInstance> result = transformationContext.annotations;
/* 245 */       annotations = original.equals(result) ? SENTINEL : Collections.<AnnotationInstance>unmodifiableSet(result);
/* 246 */       this.overlay.put(key, annotations);
/*     */     } 
/*     */     
/* 249 */     if (annotations == SENTINEL) {
/* 250 */       annotations = getOriginalAnnotations(declaration);
/*     */     }
/* 252 */     return annotations;
/*     */   }
/*     */   
/*     */   final Set<AnnotationInstance> getOriginalAnnotations(Declaration declaration) {
/* 256 */     Set<AnnotationInstance> result = new HashSet<>();
/* 257 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD) {
/* 258 */       for (AnnotationInstance annotation : declaration.asMethod().annotations()) {
/* 259 */         if (annotation.target() != null && (annotation
/* 260 */           .target().kind() == AnnotationTarget.Kind.METHOD || annotation
/* 261 */           .target().kind() == AnnotationTarget.Kind.METHOD_PARAMETER) && (!this.runtimeAnnotationsOnly || annotation
/* 262 */           .runtimeVisible())) {
/* 263 */           result.add(annotation);
/*     */         }
/*     */       } 
/*     */     } else {
/* 267 */       for (AnnotationInstance annotation : declaration.declaredAnnotations()) {
/* 268 */         if (!this.runtimeAnnotationsOnly || annotation.runtimeVisible()) {
/* 269 */           result.add(annotation);
/*     */         }
/*     */       } 
/*     */     } 
/* 273 */     return result;
/*     */   }
/*     */   
/*     */   private static final class TransformationContextImpl implements AnnotationTransformation.TransformationContext {
/*     */     private final Declaration declaration;
/*     */     private final Set<AnnotationInstance> annotations;
/*     */     
/*     */     TransformationContextImpl(Declaration declaration, Collection<AnnotationInstance> annotations) {
/* 281 */       this.declaration = declaration;
/* 282 */       this.annotations = new HashSet<>(annotations);
/*     */     }
/*     */ 
/*     */     
/*     */     public Declaration declaration() {
/* 287 */       return this.declaration;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<AnnotationInstance> annotations() {
/* 292 */       return this.annotations;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasAnnotation(Class<? extends Annotation> annotationClass) {
/* 297 */       Objects.requireNonNull(annotationClass);
/* 298 */       return hasAnnotation(DotName.createSimple(annotationClass));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasAnnotation(DotName annotationName) {
/* 303 */       Objects.requireNonNull(annotationName);
/* 304 */       for (AnnotationInstance annotation : this.annotations) {
/* 305 */         if (annotation.name().equals(annotationName)) {
/* 306 */           return true;
/*     */         }
/*     */       } 
/* 309 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasAnnotation(Predicate<AnnotationInstance> predicate) {
/* 314 */       Objects.requireNonNull(predicate);
/* 315 */       for (AnnotationInstance annotation : this.annotations) {
/* 316 */         if (predicate.test(annotation)) {
/* 317 */           return true;
/*     */         }
/*     */       } 
/* 320 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(Class<? extends Annotation> annotationClass) {
/* 325 */       Objects.requireNonNull(annotationClass);
/* 326 */       this.annotations.add(AnnotationInstance.builder(annotationClass).build());
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(AnnotationInstance annotation) {
/* 331 */       this.annotations.add(Objects.<AnnotationInstance>requireNonNull(annotation));
/*     */     }
/*     */ 
/*     */     
/*     */     public void addAll(AnnotationInstance... annotations) {
/* 336 */       Collections.addAll(this.annotations, Objects.<AnnotationInstance[]>requireNonNull(annotations));
/*     */     }
/*     */ 
/*     */     
/*     */     public void addAll(Collection<AnnotationInstance> annotations) {
/* 341 */       this.annotations.addAll(Objects.<Collection<? extends AnnotationInstance>>requireNonNull(annotations));
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove(Predicate<AnnotationInstance> predicate) {
/* 346 */       this.annotations.removeIf(Objects.<Predicate<? super AnnotationInstance>>requireNonNull(predicate));
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeAll() {
/* 351 */       this.annotations.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationOverlayImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */