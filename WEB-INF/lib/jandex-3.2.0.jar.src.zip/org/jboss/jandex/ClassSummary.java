/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClassSummary
/*    */ {
/*    */   private final DotName name;
/*    */   private final DotName superclassName;
/*    */   private final Set<DotName> annotations;
/*    */   
/*    */   ClassSummary(DotName name, DotName superclassName, Set<DotName> annotations) {
/* 20 */     this.name = name;
/* 21 */     this.superclassName = superclassName;
/* 22 */     this.annotations = annotations;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DotName name() {
/* 29 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DotName superclassName() {
/* 36 */     return this.superclassName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<DotName> annotations() {
/* 43 */     return this.annotations;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int annotationsCount() {
/* 50 */     return this.annotations.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ClassSummary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */