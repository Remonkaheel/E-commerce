/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeParameterTypeTarget
/*    */   extends PositionBasedTypeTarget
/*    */ {
/*    */   TypeParameterTypeTarget(AnnotationTarget enclosingTarget, int position) {
/* 43 */     super(enclosingTarget, position);
/*    */   }
/*    */   
/*    */   TypeParameterTypeTarget(AnnotationTarget enclosingTarget, Type target, int position) {
/* 47 */     super(enclosingTarget, target, position);
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeTarget.Usage usage() {
/* 52 */     return TypeTarget.Usage.TYPE_PARAMETER;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeParameterTypeTarget asTypeParameter() {
/* 57 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\TypeParameterTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */