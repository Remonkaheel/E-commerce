package org.jboss.jandex;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */