/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Descriptor
/*    */ {
/*    */   public static final Function<String, Type> NO_SUBSTITUTION = ignored -> null;
/*    */   
/*    */   default String descriptor() {
/* 20 */     return descriptor(NO_SUBSTITUTION);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void forType(Type type, Function<String, Type> typeVariableSubstitution, StringBuilder result) {
/* 55 */     DescriptorReconstruction.typeDescriptor(type, typeVariableSubstitution, result);
/*    */   }
/*    */   
/*    */   String descriptor(Function<String, Type> paramFunction);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Descriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */