/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Modifiers
/*    */ {
/*    */   static final int BRIDGE = 64;
/*    */   static final int SYNTHETIC = 4096;
/*    */   static final int ANNOTATION = 8192;
/*    */   static final int ENUM = 16384;
/*    */   static final int MANDATED = 32768;
/*    */   
/*    */   static boolean isAnnotation(int mod) {
/* 36 */     return ((mod & 0x2000) != 0);
/*    */   }
/*    */   
/*    */   static boolean isEnum(int mod) {
/* 40 */     return ((mod & 0x4000) != 0);
/*    */   }
/*    */   
/*    */   static boolean isSynthetic(int mod) {
/* 44 */     return ((mod & 0x1000) != 0);
/*    */   }
/*    */   
/*    */   static boolean isBridge(int mod) {
/* 48 */     return ((mod & 0x40) != 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Modifiers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */