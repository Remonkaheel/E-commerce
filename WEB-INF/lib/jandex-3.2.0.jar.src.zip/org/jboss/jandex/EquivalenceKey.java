/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.StringJoiner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EquivalenceKey
/*     */ {
/*     */   public static EquivalenceKey of(AnnotationTarget annotationTarget) {
/*  68 */     if (annotationTarget == null) {
/*  69 */       return null;
/*     */     }
/*     */     
/*  72 */     if (annotationTarget.isDeclaration()) {
/*  73 */       return of(annotationTarget.asDeclaration());
/*     */     }
/*  75 */     if (annotationTarget.kind() == AnnotationTarget.Kind.TYPE) {
/*  76 */       return of(annotationTarget.asType());
/*     */     }
/*     */     
/*  79 */     throw new IllegalArgumentException("Unknown annotation target: " + annotationTarget);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DeclarationEquivalenceKey of(Declaration declaration) {
/*  90 */     if (declaration == null) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     switch (declaration.kind()) {
/*     */       case ARRAY:
/*  96 */         return of(declaration.asClass());
/*     */       case CLASS:
/*  98 */         return of(declaration.asMethod());
/*     */       case PARAMETERIZED_TYPE:
/* 100 */         return of(declaration.asMethodParameter());
/*     */       case PRIMITIVE:
/* 102 */         return of(declaration.asField());
/*     */       case TYPE_VARIABLE:
/* 104 */         return of(declaration.asRecordComponent());
/*     */     } 
/* 106 */     throw new IllegalArgumentException("Unknown declaration: " + declaration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassEquivalenceKey of(ClassInfo clazz) {
/* 117 */     if (clazz == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     return new ClassEquivalenceKey(clazz.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodEquivalenceKey of(MethodInfo method) {
/* 130 */     if (method == null) {
/* 131 */       return null;
/*     */     }
/* 133 */     return new MethodEquivalenceKey(method.declaringClass().name(), method.methodInternal().nameBytes(), 
/* 134 */         of(method.methodInternal().parameterTypesArray()), of(method.returnType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodParameterEquivalenceKey of(MethodParameterInfo parameter) {
/* 144 */     if (parameter == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     return new MethodParameterEquivalenceKey(of(parameter.method()), parameter.position());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FieldEquivalenceKey of(FieldInfo field) {
/* 157 */     if (field == null) {
/* 158 */       return null;
/*     */     }
/* 160 */     return new FieldEquivalenceKey(field.declaringClass().name(), field.fieldInternal().nameBytes(), of(field.type()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecordComponentEquivalenceKey of(RecordComponentInfo recordComponent) {
/* 170 */     if (recordComponent == null) {
/* 171 */       return null;
/*     */     }
/* 173 */     return new RecordComponentEquivalenceKey(recordComponent.declaringClass().name(), recordComponent
/* 174 */         .recordComponentInternal().nameBytes(), of(recordComponent.type()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeEquivalenceKey of(TypeTarget typeTarget) {
/* 185 */     if (typeTarget == null) {
/* 186 */       return null;
/*     */     }
/* 188 */     return of(typeTarget.target());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeEquivalenceKey of(Type type) {
/* 198 */     if (type == null) {
/* 199 */       return null;
/*     */     }
/*     */     
/* 202 */     switch (type.kind()) {
/*     */       case ARRAY:
/* 204 */         return new ArrayTypeEquivalenceKey(of(type.asArrayType().constituent()), type
/* 205 */             .asArrayType().dimensions());
/*     */       case CLASS:
/* 207 */         return new ClassTypeEquivalenceKey(type.asClassType().name());
/*     */       case PARAMETERIZED_TYPE:
/* 209 */         return new ParameterizedTypeEquivalenceKey(type.asParameterizedType().name(), 
/* 210 */             of(type.asParameterizedType().argumentsArray()));
/*     */       case PRIMITIVE:
/* 212 */         return new PrimitiveTypeEquivalenceKey(type.asPrimitiveType().primitive());
/*     */       case TYPE_VARIABLE:
/* 214 */         return new TypeVariableEquivalenceKey(type.asTypeVariable().identifier(), 
/* 215 */             of(type.asTypeVariable().boundArray()));
/*     */       case TYPE_VARIABLE_REFERENCE:
/* 217 */         return new TypeVariableReferenceEquivalenceKey(type.asTypeVariableReference().identifier());
/*     */       case UNRESOLVED_TYPE_VARIABLE:
/* 219 */         return new UnresolvedTypeVariableEquivalenceKey(type.asUnresolvedTypeVariable().identifier());
/*     */       case VOID:
/* 221 */         return VoidTypeEquivalenceKey.SINGLETON;
/*     */       case WILDCARD_TYPE:
/* 223 */         return new WildcardTypeEquivalenceKey(of(type.asWildcardType().bound()), type.asWildcardType().isExtends(), type
/* 224 */             .asWildcardType().hasImplicitObjectBound());
/*     */     } 
/* 226 */     throw new IllegalArgumentException("Unknown type: " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   private static TypeEquivalenceKey[] of(Type[] types) {
/* 231 */     TypeEquivalenceKey[] result = new TypeEquivalenceKey[types.length];
/* 232 */     for (int i = 0; i < types.length; i++) {
/* 233 */       result[i] = of(types[i]);
/*     */     }
/* 235 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private EquivalenceKey() {}
/*     */ 
/*     */   
/*     */   String toStringWithWhere(Set<TypeVariableEquivalenceKey> typeVariables) {
/* 244 */     return toString();
/*     */   }
/*     */   
/*     */   private static String toStringWhereClause(Set<TypeVariableEquivalenceKey> typeVariables) {
/* 248 */     if (typeVariables == null || typeVariables.isEmpty()) {
/* 249 */       return "";
/*     */     }
/*     */     
/* 252 */     StringJoiner typeVariablesJoiner = new StringJoiner(", ");
/* 253 */     for (TypeVariableEquivalenceKey typeVariable : typeVariables) {
/* 254 */       typeVariablesJoiner.add(typeVariable.toString());
/*     */     }
/* 256 */     return " where " + typeVariablesJoiner;
/*     */   }
/*     */   
/*     */   public static abstract class DeclarationEquivalenceKey
/*     */     extends EquivalenceKey
/*     */   {
/*     */     private DeclarationEquivalenceKey() {}
/*     */   }
/*     */   
/*     */   public static final class ClassEquivalenceKey
/*     */     extends DeclarationEquivalenceKey {
/*     */     private final DotName className;
/*     */     
/*     */     private ClassEquivalenceKey(DotName className) {
/* 270 */       this.className = className;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 275 */       if (this == o)
/* 276 */         return true; 
/* 277 */       if (!(o instanceof ClassEquivalenceKey))
/* 278 */         return false; 
/* 279 */       ClassEquivalenceKey that = (ClassEquivalenceKey)o;
/* 280 */       return Objects.equals(this.className, that.className);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 285 */       return Objects.hash(new Object[] { this.className });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 290 */       return "class " + this.className.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class MethodEquivalenceKey
/*     */     extends DeclarationEquivalenceKey {
/*     */     private final DotName className;
/*     */     private final byte[] methodName;
/*     */     private final EquivalenceKey.TypeEquivalenceKey[] parameterTypes;
/*     */     private final EquivalenceKey.TypeEquivalenceKey returnType;
/*     */     
/*     */     private MethodEquivalenceKey(DotName className, byte[] methodName, EquivalenceKey.TypeEquivalenceKey[] parameterTypes, EquivalenceKey.TypeEquivalenceKey returnType) {
/* 302 */       this.className = className;
/* 303 */       this.methodName = methodName;
/* 304 */       this.parameterTypes = parameterTypes;
/* 305 */       this.returnType = returnType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 310 */       if (this == o)
/* 311 */         return true; 
/* 312 */       if (!(o instanceof MethodEquivalenceKey))
/* 313 */         return false; 
/* 314 */       MethodEquivalenceKey that = (MethodEquivalenceKey)o;
/* 315 */       return (Objects.equals(this.className, that.className) && 
/* 316 */         Arrays.equals(this.methodName, that.methodName) && 
/* 317 */         Arrays.equals((Object[])this.parameterTypes, (Object[])that.parameterTypes) && 
/* 318 */         Objects.equals(this.returnType, that.returnType));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 323 */       int result = Objects.hash(new Object[] { this.className, this.returnType });
/* 324 */       result = 31 * result + Arrays.hashCode(this.methodName);
/* 325 */       result = 31 * result + Arrays.hashCode((Object[])this.parameterTypes);
/* 326 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 331 */       Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables = new HashSet<>();
/* 332 */       StringJoiner parameterTypesJoiner = new StringJoiner(", ", "(", ")");
/* 333 */       for (EquivalenceKey.TypeEquivalenceKey parameterType : this.parameterTypes) {
/* 334 */         parameterTypesJoiner.add(parameterType.toStringWithWhere(typeVariables));
/*     */       }
/* 336 */       return "method " + this.className + "#" + Utils.fromUTF8(this.methodName) + parameterTypesJoiner + " -> " + this.returnType
/* 337 */         .toStringWithWhere(typeVariables) + EquivalenceKey.toStringWhereClause(typeVariables);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class MethodParameterEquivalenceKey extends DeclarationEquivalenceKey {
/*     */     private final EquivalenceKey.MethodEquivalenceKey method;
/*     */     private final short position;
/*     */     
/*     */     private MethodParameterEquivalenceKey(EquivalenceKey.MethodEquivalenceKey method, short position) {
/* 346 */       this.method = method;
/* 347 */       this.position = position;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 352 */       if (this == o)
/* 353 */         return true; 
/* 354 */       if (!(o instanceof MethodParameterEquivalenceKey))
/* 355 */         return false; 
/* 356 */       MethodParameterEquivalenceKey that = (MethodParameterEquivalenceKey)o;
/* 357 */       return (this.position == that.position && Objects.equals(this.method, that.method));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 362 */       return Objects.hash(new Object[] { this.method, Short.valueOf(this.position) });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 367 */       return "parameter " + this.position + " of " + this.method;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class FieldEquivalenceKey extends DeclarationEquivalenceKey {
/*     */     private final DotName className;
/*     */     private final byte[] fieldName;
/*     */     private final EquivalenceKey.TypeEquivalenceKey type;
/*     */     
/*     */     private FieldEquivalenceKey(DotName className, byte[] fieldName, EquivalenceKey.TypeEquivalenceKey type) {
/* 377 */       this.className = className;
/* 378 */       this.fieldName = fieldName;
/* 379 */       this.type = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 384 */       if (this == o)
/* 385 */         return true; 
/* 386 */       if (!(o instanceof FieldEquivalenceKey))
/* 387 */         return false; 
/* 388 */       FieldEquivalenceKey that = (FieldEquivalenceKey)o;
/* 389 */       return (Objects.equals(this.className, that.className) && Arrays.equals(this.fieldName, that.fieldName) && 
/* 390 */         Objects.equals(this.type, that.type));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 395 */       int result = Objects.hash(new Object[] { this.className, this.type });
/* 396 */       result = 31 * result + Arrays.hashCode(this.fieldName);
/* 397 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 402 */       Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables = new HashSet<>();
/* 403 */       return "field " + this.className + "#" + Utils.fromUTF8(this.fieldName) + " of type " + this.type
/* 404 */         .toStringWithWhere(typeVariables) + EquivalenceKey.toStringWhereClause(typeVariables);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class RecordComponentEquivalenceKey extends DeclarationEquivalenceKey {
/*     */     private final DotName className;
/*     */     private final byte[] recordComponentName;
/*     */     private final EquivalenceKey.TypeEquivalenceKey type;
/*     */     
/*     */     private RecordComponentEquivalenceKey(DotName className, byte[] recordComponentName, EquivalenceKey.TypeEquivalenceKey type) {
/* 414 */       this.className = className;
/* 415 */       this.recordComponentName = recordComponentName;
/* 416 */       this.type = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 421 */       if (this == o)
/* 422 */         return true; 
/* 423 */       if (!(o instanceof RecordComponentEquivalenceKey))
/* 424 */         return false; 
/* 425 */       RecordComponentEquivalenceKey that = (RecordComponentEquivalenceKey)o;
/* 426 */       return (Objects.equals(this.className, that.className) && Arrays.equals(this.recordComponentName, that.recordComponentName) && 
/* 427 */         Objects.equals(this.type, that.type));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 432 */       int result = Objects.hash(new Object[] { this.className, this.type });
/* 433 */       result = 31 * result + Arrays.hashCode(this.recordComponentName);
/* 434 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 439 */       Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables = new HashSet<>();
/* 440 */       return "record component " + this.className + "#" + Utils.fromUTF8(this.recordComponentName) + " of type " + this.type
/* 441 */         .toStringWithWhere(typeVariables) + EquivalenceKey.toStringWhereClause(typeVariables);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class TypeEquivalenceKey
/*     */     extends EquivalenceKey {
/*     */     private TypeEquivalenceKey() {}
/*     */   }
/*     */   
/*     */   public static final class ArrayTypeEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final EquivalenceKey.TypeEquivalenceKey constituent;
/*     */     private final int dimensions;
/*     */     
/*     */     private ArrayTypeEquivalenceKey(EquivalenceKey.TypeEquivalenceKey constituent, int dimensions) {
/* 455 */       this.constituent = constituent;
/* 456 */       this.dimensions = dimensions;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 461 */       if (this == o)
/* 462 */         return true; 
/* 463 */       if (!(o instanceof ArrayTypeEquivalenceKey))
/* 464 */         return false; 
/* 465 */       ArrayTypeEquivalenceKey that = (ArrayTypeEquivalenceKey)o;
/* 466 */       return (this.dimensions == that.dimensions && Objects.equals(this.constituent, that.constituent));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 471 */       return Objects.hash(new Object[] { this.constituent, Integer.valueOf(this.dimensions) });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 476 */       Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables = new HashSet<>();
/* 477 */       StringBuilder result = new StringBuilder();
/* 478 */       result.append(this.constituent.toStringWithWhere(typeVariables));
/* 479 */       for (int i = 0; i < this.dimensions; i++) {
/* 480 */         result.append("[]");
/*     */       }
/* 482 */       return result + EquivalenceKey.toStringWhereClause(typeVariables);
/*     */     }
/*     */ 
/*     */     
/*     */     String toStringWithWhere(Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables) {
/* 487 */       StringBuilder result = new StringBuilder();
/* 488 */       result.append(this.constituent.toStringWithWhere(typeVariables));
/* 489 */       for (int i = 0; i < this.dimensions; i++) {
/* 490 */         result.append("[]");
/*     */       }
/* 492 */       return result.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ClassTypeEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final DotName name;
/*     */     
/*     */     private ClassTypeEquivalenceKey(DotName name) {
/* 500 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 505 */       if (this == o)
/* 506 */         return true; 
/* 507 */       if (!(o instanceof ClassTypeEquivalenceKey))
/* 508 */         return false; 
/* 509 */       ClassTypeEquivalenceKey that = (ClassTypeEquivalenceKey)o;
/* 510 */       return Objects.equals(this.name, that.name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 515 */       return Objects.hash(new Object[] { this.name });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 520 */       return this.name.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ParameterizedTypeEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final DotName genericClass;
/*     */     private final EquivalenceKey.TypeEquivalenceKey[] typeArguments;
/*     */     
/*     */     private ParameterizedTypeEquivalenceKey(DotName genericClass, EquivalenceKey.TypeEquivalenceKey[] typeArguments) {
/* 529 */       this.genericClass = genericClass;
/* 530 */       this.typeArguments = typeArguments;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 535 */       if (this == o)
/* 536 */         return true; 
/* 537 */       if (!(o instanceof ParameterizedTypeEquivalenceKey))
/* 538 */         return false; 
/* 539 */       ParameterizedTypeEquivalenceKey that = (ParameterizedTypeEquivalenceKey)o;
/* 540 */       return (Objects.equals(this.genericClass, that.genericClass) && Arrays.equals((Object[])this.typeArguments, (Object[])that.typeArguments));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 545 */       int result = Objects.hash(new Object[] { this.genericClass });
/* 546 */       result = 31 * result + Arrays.hashCode((Object[])this.typeArguments);
/* 547 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 552 */       Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables = new HashSet<>();
/* 553 */       StringJoiner typeArgumentsJoiner = new StringJoiner(", ", "<", ">");
/* 554 */       for (EquivalenceKey.TypeEquivalenceKey typeArgument : this.typeArguments) {
/* 555 */         typeArgumentsJoiner.add(typeArgument.toStringWithWhere(typeVariables));
/*     */       }
/* 557 */       return this.genericClass + typeArgumentsJoiner.toString() + EquivalenceKey.toStringWhereClause(typeVariables);
/*     */     }
/*     */ 
/*     */     
/*     */     String toStringWithWhere(Set<EquivalenceKey.TypeVariableEquivalenceKey> typeVariables) {
/* 562 */       StringJoiner typeArgumentsJoiner = new StringJoiner(", ", "<", ">");
/* 563 */       for (EquivalenceKey.TypeEquivalenceKey typeArgument : this.typeArguments) {
/* 564 */         typeArgumentsJoiner.add(typeArgument.toStringWithWhere(typeVariables));
/*     */       }
/* 566 */       return this.genericClass + typeArgumentsJoiner.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class PrimitiveTypeEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final PrimitiveType.Primitive kind;
/*     */     
/*     */     private PrimitiveTypeEquivalenceKey(PrimitiveType.Primitive kind) {
/* 574 */       this.kind = kind;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 579 */       if (this == o)
/* 580 */         return true; 
/* 581 */       if (!(o instanceof PrimitiveTypeEquivalenceKey))
/* 582 */         return false; 
/* 583 */       PrimitiveTypeEquivalenceKey that = (PrimitiveTypeEquivalenceKey)o;
/* 584 */       return (this.kind == that.kind);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 589 */       return Objects.hash(new Object[] { this.kind });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 594 */       return this.kind.name().toLowerCase(Locale.ROOT);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class TypeVariableEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final String name;
/*     */     private final EquivalenceKey.TypeEquivalenceKey[] bounds;
/*     */     
/*     */     private TypeVariableEquivalenceKey(String name, EquivalenceKey.TypeEquivalenceKey[] bounds) {
/* 603 */       this.name = name;
/* 604 */       this.bounds = bounds;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 609 */       if (this == o)
/* 610 */         return true; 
/* 611 */       if (!(o instanceof TypeVariableEquivalenceKey))
/* 612 */         return false; 
/* 613 */       TypeVariableEquivalenceKey that = (TypeVariableEquivalenceKey)o;
/* 614 */       return (Objects.equals(this.name, that.name) && Arrays.equals((Object[])this.bounds, (Object[])that.bounds));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 619 */       int result = Objects.hash(new Object[] { this.name });
/* 620 */       result = 31 * result + Arrays.hashCode((Object[])this.bounds);
/* 621 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 626 */       if (this.bounds.length == 0) {
/* 627 */         return this.name;
/*     */       }
/* 629 */       StringJoiner boundsJoiner = new StringJoiner(" & ");
/* 630 */       for (EquivalenceKey.TypeEquivalenceKey bound : this.bounds) {
/* 631 */         boundsJoiner.add(bound.toString());
/*     */       }
/* 633 */       return this.name + " extends " + boundsJoiner;
/*     */     }
/*     */     
/*     */     String toStringWithWhere(Set<TypeVariableEquivalenceKey> typeVariables) {
/* 637 */       typeVariables.add(this);
/* 638 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class TypeVariableReferenceEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final String name;
/*     */     
/*     */     private TypeVariableReferenceEquivalenceKey(String name) {
/* 646 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 651 */       if (this == o)
/* 652 */         return true; 
/* 653 */       if (!(o instanceof TypeVariableReferenceEquivalenceKey))
/* 654 */         return false; 
/* 655 */       TypeVariableReferenceEquivalenceKey that = (TypeVariableReferenceEquivalenceKey)o;
/* 656 */       return Objects.equals(this.name, that.name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 661 */       return Objects.hash(new Object[] { this.name });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 666 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class UnresolvedTypeVariableEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final String name;
/*     */     
/*     */     private UnresolvedTypeVariableEquivalenceKey(String name) {
/* 674 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 679 */       if (this == o)
/* 680 */         return true; 
/* 681 */       if (!(o instanceof UnresolvedTypeVariableEquivalenceKey))
/* 682 */         return false; 
/* 683 */       UnresolvedTypeVariableEquivalenceKey that = (UnresolvedTypeVariableEquivalenceKey)o;
/* 684 */       return Objects.equals(this.name, that.name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 689 */       return Objects.hash(new Object[] { this.name });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 694 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class VoidTypeEquivalenceKey extends TypeEquivalenceKey {
/* 699 */     private static final VoidTypeEquivalenceKey SINGLETON = new VoidTypeEquivalenceKey();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 706 */       return "void";
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class WildcardTypeEquivalenceKey extends TypeEquivalenceKey {
/*     */     private final EquivalenceKey.TypeEquivalenceKey bound;
/*     */     private final boolean isExtends;
/*     */     private final boolean hasImplicitObjectBound;
/*     */     
/*     */     private WildcardTypeEquivalenceKey(EquivalenceKey.TypeEquivalenceKey bound, boolean isExtends, boolean hasImplicitObjectBound) {
/* 716 */       this.bound = bound;
/* 717 */       this.isExtends = isExtends;
/* 718 */       this.hasImplicitObjectBound = hasImplicitObjectBound;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 723 */       if (this == o)
/* 724 */         return true; 
/* 725 */       if (!(o instanceof WildcardTypeEquivalenceKey))
/* 726 */         return false; 
/* 727 */       WildcardTypeEquivalenceKey that = (WildcardTypeEquivalenceKey)o;
/* 728 */       return (this.isExtends == that.isExtends && this.hasImplicitObjectBound == that.hasImplicitObjectBound && 
/* 729 */         Objects.equals(this.bound, that.bound));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 734 */       return Objects.hash(new Object[] { this.bound, Boolean.valueOf(this.isExtends), Boolean.valueOf(this.hasImplicitObjectBound) });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 739 */       if (this.bound == null || this.hasImplicitObjectBound) {
/* 740 */         return "?";
/*     */       }
/* 742 */       if (this.isExtends) {
/* 743 */         return "? extends " + this.bound;
/*     */       }
/* 745 */       return "? super " + this.bound;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\EquivalenceKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */