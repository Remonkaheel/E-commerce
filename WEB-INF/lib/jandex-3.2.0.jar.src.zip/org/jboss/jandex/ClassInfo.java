/*      */ package org.jboss.jandex;
/*      */ 
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ClassInfo
/*      */   implements Declaration, Descriptor, GenericSignature
/*      */ {
/*      */   private static final int MAX_POSITIONS = 256;
/*   59 */   private static final byte[] EMPTY_POSITIONS = new byte[0];
/*      */   
/*      */   private final DotName name;
/*      */   
/*      */   private Map<DotName, List<AnnotationInstance>> annotations;
/*      */   
/*      */   private short flags;
/*      */   private boolean hasNoArgsConstructor;
/*      */   private Type[] interfaceTypes;
/*      */   private Type superClassType;
/*      */   private MethodInternal[] methods;
/*      */   private FieldInternal[] fields;
/*   71 */   private byte[] methodPositions = EMPTY_POSITIONS;
/*   72 */   private byte[] fieldPositions = EMPTY_POSITIONS;
/*      */   
/*      */   private NestingInfo nestingInfo;
/*      */   private ExtraInfo extra;
/*      */   
/*      */   public enum NestingType
/*      */   {
/*   79 */     TOP_LEVEL,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   84 */     INNER,
/*      */ 
/*      */     
/*   87 */     LOCAL,
/*      */ 
/*      */     
/*   90 */     ANONYMOUS;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class ExtraInfo
/*      */   {
/*      */     private Type[] typeParameters;
/*   97 */     private byte[] recordComponentPositions = ClassInfo.EMPTY_POSITIONS;
/*      */     
/*      */     private RecordComponentInternal[] recordComponents;
/*      */     
/*      */     private ExtraInfo() {}
/*      */     
/*      */     private Set<DotName> memberClasses;
/*      */     private Set<DotName> permittedSubclasses;
/*      */     private ModuleInfo module;
/*      */   }
/*      */   
/*      */   private static final class NestingInfo
/*      */   {
/*      */     private DotName enclosingClass;
/*      */     private String simpleName;
/*      */     private ClassInfo.EnclosingMethodInfo enclosingMethod;
/*      */     
/*      */     private NestingInfo() {}
/*      */   }
/*      */   
/*      */   public static final class EnclosingMethodInfo
/*      */   {
/*      */     private String name;
/*      */     private Type returnType;
/*      */     private Type[] parameters;
/*      */     private DotName enclosingClass;
/*      */     
/*      */     public String name() {
/*  125 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Type returnType() {
/*  134 */       return this.returnType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<Type> parameters() {
/*  144 */       return new ImmutableArrayList<>(this.parameters);
/*      */     }
/*      */     
/*      */     Type[] parametersArray() {
/*  148 */       return this.parameters;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DotName enclosingClass() {
/*  157 */       return this.enclosingClass;
/*      */     }
/*      */     
/*      */     EnclosingMethodInfo(String name, Type returnType, Type[] parameters, DotName enclosingClass) {
/*  161 */       this.name = name;
/*  162 */       this.returnType = returnType;
/*  163 */       this.parameters = parameters;
/*  164 */       this.enclosingClass = enclosingClass;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  168 */       StringBuilder builder = new StringBuilder();
/*  169 */       builder.append(this.returnType).append(' ').append(this.enclosingClass).append('.').append(this.name).append('(');
/*  170 */       for (int i = 0; i < this.parameters.length; i++) {
/*  171 */         builder.append(this.parameters[i]);
/*  172 */         if (i + 1 < this.parameters.length)
/*  173 */           builder.append(", "); 
/*      */       } 
/*  175 */       builder.append(')');
/*  176 */       return builder.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   ClassInfo(DotName name, Type superClassType, short flags, Type[] interfaceTypes) {
/*  182 */     this(name, superClassType, flags, interfaceTypes, false);
/*      */   }
/*      */   
/*      */   ClassInfo(DotName name, Type superClassType, short flags, Type[] interfaceTypes, boolean hasNoArgsConstructor) {
/*  186 */     this.name = name;
/*  187 */     this.superClassType = superClassType;
/*  188 */     this.flags = flags;
/*  189 */     this.interfaceTypes = (interfaceTypes.length == 0) ? Type.EMPTY_ARRAY : interfaceTypes;
/*  190 */     this.hasNoArgsConstructor = hasNoArgsConstructor;
/*  191 */     this.methods = MethodInternal.EMPTY_ARRAY;
/*  192 */     this.fields = FieldInternal.EMPTY_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static ClassInfo create(DotName name, DotName superName, short flags, DotName[] interfaces, Map<DotName, List<AnnotationInstance>> annotations, boolean hasNoArgsConstructor) {
/*  210 */     Type[] interfaceTypes = new Type[interfaces.length];
/*  211 */     for (int i = 0; i < interfaces.length; i++) {
/*  212 */       interfaceTypes[i] = new ClassType(interfaces[i]);
/*      */     }
/*      */     
/*  215 */     ClassType superClassType = (superName == null) ? null : new ClassType(superName);
/*  216 */     ClassInfo clazz = new ClassInfo(name, superClassType, flags, interfaceTypes, hasNoArgsConstructor);
/*  217 */     clazz.setAnnotations(annotations);
/*  218 */     return clazz;
/*      */   }
/*      */ 
/*      */   
/*      */   public final AnnotationTarget.Kind kind() {
/*  223 */     return AnnotationTarget.Kind.CLASS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  232 */     return this.name.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DotName name() {
/*  241 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final short flags() {
/*  251 */     return this.flags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isSynthetic() {
/*  259 */     return Modifiers.isSynthetic(this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isInterface() {
/*  267 */     return Modifier.isInterface(this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isFinal() {
/*  276 */     return Modifier.isFinal(this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isAbstract() {
/*  285 */     return Modifier.isAbstract(this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnum() {
/*  293 */     return (Modifiers.isEnum(this.flags) && DotName.ENUM_NAME.equals(superName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isAnnotation() {
/*  301 */     return Modifiers.isAnnotation(this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isRecord() {
/*  310 */     return DotName.RECORD_NAME.equals(superName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isModule() {
/*  317 */     return ((this.flags & 0x8000) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DotName superName() {
/*  329 */     return (this.superClassType == null) ? null : this.superClassType.name();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final DotName[] interfaces() {
/*  340 */     DotName[] interfaces = new DotName[this.interfaceTypes.length];
/*  341 */     for (int i = 0; i < this.interfaceTypes.length; i++) {
/*  342 */       interfaces[i] = this.interfaceTypes[i].name();
/*      */     }
/*  344 */     return interfaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasAnnotation(DotName name) {
/*  358 */     return (this.annotations.containsKey(name) && !((List)this.annotations.get(name)).isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AnnotationInstance annotation(DotName name) {
/*  397 */     if (this.annotations.containsKey(name) && !((List)this.annotations.get(name)).isEmpty()) {
/*  398 */       return ((List<AnnotationInstance>)this.annotations.get(name)).get(0);
/*      */     }
/*  400 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<AnnotationInstance> annotations(DotName name) {
/*  437 */     if (this.annotations.containsKey(name)) {
/*  438 */       return Collections.unmodifiableList(this.annotations.get(name));
/*      */     }
/*  440 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/*  463 */     if (index == null) {
/*  464 */       throw new IllegalArgumentException("Index must not be null");
/*      */     }
/*  466 */     List<AnnotationInstance> instances = new ArrayList<>(annotations(name));
/*  467 */     ClassInfo annotationClass = index.getClassByName(name);
/*  468 */     if (annotationClass == null) {
/*  469 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*      */     }
/*  471 */     if (!annotationClass.isAnnotation()) {
/*  472 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*      */     }
/*  474 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/*  475 */     if (repeatable != null) {
/*  476 */       Type containingType = repeatable.value().asClass();
/*  477 */       for (AnnotationInstance container : annotations(containingType.name())) {
/*  478 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/*  479 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*      */         }
/*      */       } 
/*      */     } 
/*  483 */     return Collections.unmodifiableList(instances);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<AnnotationInstance> annotations() {
/*  517 */     List<AnnotationInstance> result = new ArrayList<>();
/*  518 */     for (List<AnnotationInstance> list : this.annotations.values()) {
/*  519 */       for (AnnotationInstance instance : list) {
/*  520 */         result.add(instance);
/*      */       }
/*      */     } 
/*  523 */     return Collections.unmodifiableList(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasDeclaredAnnotation(DotName name) {
/*  539 */     return (declaredAnnotation(name) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AnnotationInstance declaredAnnotation(DotName name) {
/*  555 */     List<AnnotationInstance> instances = this.annotations.get(name);
/*  556 */     if (instances != null) {
/*  557 */       for (AnnotationInstance instance : instances) {
/*  558 */         if (instance.target().kind() == AnnotationTarget.Kind.CLASS) {
/*  559 */           return instance;
/*      */         }
/*      */       } 
/*      */     }
/*  563 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<AnnotationInstance> declaredAnnotationsWithRepeatable(DotName name, IndexView index) {
/*  586 */     if (index == null) {
/*  587 */       throw new IllegalArgumentException("Index must not be null");
/*      */     }
/*  589 */     List<AnnotationInstance> instances = new ArrayList<>();
/*  590 */     AnnotationInstance declaredInstance = declaredAnnotation(name);
/*  591 */     if (declaredInstance != null) {
/*  592 */       instances.add(declaredInstance);
/*      */     }
/*  594 */     ClassInfo annotationClass = index.getClassByName(name);
/*  595 */     if (annotationClass == null) {
/*  596 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*      */     }
/*  598 */     if (!annotationClass.isAnnotation()) {
/*  599 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*      */     }
/*  601 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/*  602 */     if (repeatable != null) {
/*  603 */       Type containingType = repeatable.value().asClass();
/*  604 */       AnnotationInstance container = declaredAnnotation(containingType.name());
/*  605 */       if (container != null) {
/*  606 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/*  607 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*      */         }
/*      */       }
/*      */     } 
/*  611 */     return Collections.unmodifiableList(instances);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<AnnotationInstance> declaredAnnotations() {
/*  626 */     List<AnnotationInstance> instances = new ArrayList<>();
/*  627 */     for (List<AnnotationInstance> list : this.annotations.values()) {
/*  628 */       for (AnnotationInstance instance : list) {
/*  629 */         if (instance.target().kind() == AnnotationTarget.Kind.CLASS) {
/*  630 */           instances.add(instance);
/*      */         }
/*      */       } 
/*      */     } 
/*  634 */     return Collections.unmodifiableList(instances);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Map<DotName, List<AnnotationInstance>> annotationsMap() {
/*  648 */     return Collections.unmodifiableMap(this.annotations);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setAnnotations(Map<DotName, List<AnnotationInstance>> annotations) {
/*  657 */     this.annotations = annotations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Collection<AnnotationInstance> classAnnotations() {
/*  668 */     return declaredAnnotations();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final AnnotationInstance classAnnotation(DotName name) {
/*  680 */     return declaredAnnotation(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final List<AnnotationInstance> classAnnotationsWithRepeatable(DotName name, IndexView index) {
/*  696 */     return declaredAnnotationsWithRepeatable(name, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<MethodInfo> methods() {
/*  710 */     return new MethodInfoGenerator(this, this.methods, EMPTY_POSITIONS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<MethodInfo> unsortedMethods() {
/*  726 */     return new MethodInfoGenerator(this, this.methods, this.methodPositions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<MethodInfo> constructors() {
/*  738 */     List<MethodInfo> constructors = new ArrayList<>(1);
/*  739 */     for (MethodInfo method : methods()) {
/*  740 */       if (method.isConstructor()) {
/*  741 */         constructors.add(method);
/*      */       }
/*      */     } 
/*  744 */     return constructors;
/*      */   }
/*      */   
/*      */   final MethodInternal[] methodArray() {
/*  748 */     return this.methods;
/*      */   }
/*      */   
/*      */   final byte[] methodPositionArray() {
/*  752 */     return this.methodPositions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MethodInfo method(String name, Type... parameters) {
/*  770 */     MethodInternal key = new MethodInternal(Utils.toUTF8(name), MethodInternal.EMPTY_PARAMETER_NAMES, parameters, null, (short)0);
/*      */     
/*  772 */     int i = Arrays.binarySearch(this.methods, key, MethodInternal.NAME_AND_PARAMETER_COMPONENT_COMPARATOR);
/*  773 */     return (i >= 0) ? new MethodInfo(this, this.methods[i]) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MethodInfo method(String name, List<Type> parameters) {
/*  791 */     return method(name, parameters.<Type>toArray(Type.EMPTY_ARRAY));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MethodInfo firstMethod(String name) {
/*  804 */     MethodInternal key = new MethodInternal(Utils.toUTF8(name), MethodInternal.EMPTY_PARAMETER_NAMES, Type.EMPTY_ARRAY, null, (short)0);
/*      */     
/*  806 */     int i = Arrays.binarySearch(this.methods, key, MethodInternal.NAME_AND_PARAMETER_COMPONENT_COMPARATOR);
/*  807 */     if (i < -this.methods.length) {
/*  808 */       return null;
/*      */     }
/*      */     
/*  811 */     MethodInfo method = new MethodInfo(this, (i >= 0) ? this.methods[i] : this.methods[++i * -1]);
/*  812 */     return method.name().equals(name) ? method : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final FieldInfo field(String name) {
/*  823 */     FieldInternal key = new FieldInternal(Utils.toUTF8(name), VoidType.VOID, (short)0);
/*  824 */     int i = Arrays.binarySearch(this.fields, key, FieldInternal.NAME_COMPARATOR);
/*  825 */     if (i < 0) {
/*  826 */       return null;
/*      */     }
/*      */     
/*  829 */     return new FieldInfo(this, this.fields[i]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<FieldInfo> fields() {
/*  840 */     return new FieldInfoGenerator(this, this.fields, EMPTY_POSITIONS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<FieldInfo> unsortedFields() {
/*  856 */     return new FieldInfoGenerator(this, this.fields, this.fieldPositions);
/*      */   }
/*      */   
/*      */   final FieldInternal[] fieldArray() {
/*  860 */     return this.fields;
/*      */   }
/*      */   
/*      */   final byte[] fieldPositionArray() {
/*  864 */     return this.fieldPositions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RecordComponentInfo recordComponent(String name) {
/*  874 */     if (this.extra == null || this.extra.recordComponents == null) {
/*  875 */       return null;
/*      */     }
/*      */     
/*  878 */     RecordComponentInternal key = new RecordComponentInternal(Utils.toUTF8(name), VoidType.VOID);
/*  879 */     int i = Arrays.binarySearch(this.extra.recordComponents, key, RecordComponentInternal.NAME_COMPARATOR);
/*  880 */     if (i < 0) {
/*  881 */       return null;
/*      */     }
/*  883 */     return new RecordComponentInfo(this, this.extra.recordComponents[i]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<RecordComponentInfo> recordComponents() {
/*  895 */     if (!isRecord() || this.extra == null || this.extra.recordComponents == null) {
/*  896 */       return Collections.emptyList();
/*      */     }
/*      */     
/*  899 */     return new RecordComponentInfoGenerator(this, this.extra.recordComponents, EMPTY_POSITIONS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<RecordComponentInfo> unsortedRecordComponents() {
/*  916 */     if (this.extra == null || this.extra.recordComponents == null) {
/*  917 */       return Collections.emptyList();
/*      */     }
/*      */     
/*  920 */     return new RecordComponentInfoGenerator(this, this.extra.recordComponents, this.extra.recordComponentPositions);
/*      */   }
/*      */   
/*      */   final RecordComponentInternal[] recordComponentArray() {
/*  924 */     return (this.extra != null && this.extra.recordComponents != null) ? this.extra.recordComponents : RecordComponentInternal.EMPTY_ARRAY;
/*      */   }
/*      */   
/*      */   final byte[] recordComponentPositionArray() {
/*  928 */     return (this.extra != null && this.extra.recordComponentPositions != null) ? this.extra.recordComponentPositions : EMPTY_POSITIONS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<FieldInfo> enumConstants() {
/*  947 */     if (!isEnum()) {
/*  948 */       return Collections.emptyList();
/*      */     }
/*      */     
/*  951 */     List<FieldInfo> result = new ArrayList<>();
/*  952 */     byte[] positions = this.fieldPositions;
/*  953 */     for (int i = 0; i < this.fields.length; i++) {
/*  954 */       FieldInternal field = (positions.length > 0) ? this.fields[positions[i] & 0xFF] : this.fields[i];
/*  955 */       if (field.isEnumConstant()) {
/*  956 */         result.add(new FieldInfo(this, field));
/*      */       }
/*      */     } 
/*  959 */     return Collections.unmodifiableList(result);
/*      */   }
/*      */   
/*      */   final int enumConstantOrdinal(FieldInternal enumConstant) {
/*  963 */     if (!isEnum()) {
/*  964 */       return -1;
/*      */     }
/*      */     
/*  967 */     int counter = 0;
/*  968 */     byte[] positions = this.fieldPositions;
/*  969 */     for (int i = 0; i < this.fields.length; i++) {
/*  970 */       FieldInternal field = (positions.length > 0) ? this.fields[positions[i] & 0xFF] : this.fields[i];
/*  971 */       if (field.isEnumConstant()) {
/*  972 */         if (field.equals(enumConstant)) {
/*  973 */           return counter;
/*      */         }
/*  975 */         counter++;
/*      */       } 
/*      */     } 
/*      */     
/*  979 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<DotName> interfaceNames() {
/*  991 */     return new AbstractList<DotName>()
/*      */       {
/*      */         public DotName get(int i) {
/*  994 */           return ClassInfo.this.interfaceTypes[i].name();
/*      */         }
/*      */ 
/*      */         
/*      */         public int size() {
/*  999 */           return ClassInfo.this.interfaceTypes.length;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<Type> interfaceTypes() {
/* 1011 */     return new ImmutableArrayList<>(this.interfaceTypes);
/*      */   }
/*      */   
/*      */   final Type[] interfaceTypeArray() {
/* 1015 */     return this.interfaceTypes;
/*      */   }
/*      */   
/*      */   final Type[] copyInterfaceTypes() {
/* 1019 */     return (Type[])this.interfaceTypes.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Type superClassType() {
/* 1028 */     return this.superClassType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<TypeVariable> typeParameters() {
/* 1038 */     if (this.extra == null || this.extra.typeParameters == null) {
/* 1039 */       return Collections.emptyList();
/*      */     }
/*      */ 
/*      */     
/* 1043 */     return (List)new ImmutableArrayList<>(this.extra.typeParameters);
/*      */   }
/*      */   
/*      */   final Type[] typeParameterArray() {
/* 1047 */     if (this.extra == null || this.extra.typeParameters == null) {
/* 1048 */       return Type.EMPTY_ARRAY;
/*      */     }
/*      */     
/* 1051 */     return this.extra.typeParameters;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasNoArgsConstructor() {
/* 1069 */     return this.hasNoArgsConstructor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NestingType nestingType() {
/* 1083 */     if (this.nestingInfo == null)
/* 1084 */       return NestingType.TOP_LEVEL; 
/* 1085 */     if (this.nestingInfo.enclosingClass != null)
/* 1086 */       return NestingType.INNER; 
/* 1087 */     if (this.nestingInfo.simpleName != null) {
/* 1088 */       return NestingType.LOCAL;
/*      */     }
/*      */     
/* 1091 */     return NestingType.ANONYMOUS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String simpleName() {
/* 1101 */     return (this.nestingInfo != null) ? this.nestingInfo.simpleName : this.name.local();
/*      */   }
/*      */   
/*      */   String nestingSimpleName() {
/* 1105 */     return (this.nestingInfo != null) ? this.nestingInfo.simpleName : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DotName enclosingClass() {
/* 1115 */     return (this.nestingInfo != null) ? this.nestingInfo.enclosingClass : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnclosingMethodInfo enclosingMethod() {
/* 1127 */     return (this.nestingInfo != null) ? this.nestingInfo.enclosingMethod : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<DotName> memberClasses() {
/* 1142 */     if (this.extra == null || this.extra.memberClasses == null) {
/* 1143 */       return Collections.emptySet();
/*      */     }
/* 1145 */     return Collections.unmodifiableSet(this.extra.memberClasses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleInfo module() {
/* 1154 */     return (this.extra != null) ? this.extra.module : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<DotName> permittedSubclasses() {
/* 1165 */     if (this.extra == null || this.extra.permittedSubclasses == null) {
/* 1166 */       return Collections.emptySet();
/*      */     }
/* 1168 */     return Collections.unmodifiableSet(this.extra.permittedSubclasses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSealed() {
/* 1176 */     return (this.extra != null && this.extra.permittedSubclasses != null && !this.extra.permittedSubclasses.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresGenericSignature() {
/* 1187 */     return GenericSignatureReconstruction.requiresGenericSignature(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String genericSignature(Function<String, Type> typeVariableSubstitution) {
/* 1208 */     return GenericSignatureReconstruction.reconstructGenericSignature(this, typeVariableSubstitution);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String descriptor(Function<String, Type> typeVariableSubstitution) {
/* 1221 */     StringBuilder result = new StringBuilder();
/* 1222 */     DescriptorReconstruction.objectTypeDescriptor(this.name, result);
/* 1223 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public ClassInfo asClass() {
/* 1228 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public FieldInfo asField() {
/* 1233 */     throw new IllegalArgumentException("Not a field");
/*      */   }
/*      */ 
/*      */   
/*      */   public MethodInfo asMethod() {
/* 1238 */     throw new IllegalArgumentException("Not a method");
/*      */   }
/*      */ 
/*      */   
/*      */   public MethodParameterInfo asMethodParameter() {
/* 1243 */     throw new IllegalArgumentException("Not a method parameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeTarget asType() {
/* 1248 */     throw new IllegalArgumentException("Not a type");
/*      */   }
/*      */ 
/*      */   
/*      */   public RecordComponentInfo asRecordComponent() {
/* 1253 */     throw new IllegalArgumentException("Not a record component");
/*      */   }
/*      */   
/*      */   void setHasNoArgsConstructor(boolean hasNoArgsConstructor) {
/* 1257 */     this.hasNoArgsConstructor = hasNoArgsConstructor;
/*      */   }
/*      */   
/*      */   void setFields(List<FieldInfo> fields, NameTable names) {
/* 1261 */     int size = fields.size();
/*      */     
/* 1263 */     if (size == 0) {
/* 1264 */       this.fields = FieldInternal.EMPTY_ARRAY;
/*      */       
/*      */       return;
/*      */     } 
/* 1268 */     this.fields = new FieldInternal[size];
/*      */     
/* 1270 */     for (int i = 0; i < size; i++) {
/* 1271 */       FieldInfo fieldInfo = fields.get(i);
/* 1272 */       FieldInternal internal = names.intern(fieldInfo.fieldInternal());
/* 1273 */       fieldInfo.setFieldInternal(internal);
/* 1274 */       this.fields[i] = internal;
/*      */     } 
/*      */     
/* 1277 */     this.fieldPositions = sortAndGetPositions(this.fields, FieldInternal.NAME_COMPARATOR, names);
/*      */   }
/*      */   
/*      */   void setFieldArray(FieldInternal[] fields) {
/* 1281 */     this.fields = fields;
/*      */   }
/*      */   
/*      */   void setFieldPositionArray(byte[] fieldPositions) {
/* 1285 */     this.fieldPositions = fieldPositions;
/*      */   }
/*      */   
/*      */   void setMethodArray(MethodInternal[] methods) {
/* 1289 */     this.methods = methods;
/*      */   }
/*      */   
/*      */   void setMethodPositionArray(byte[] methodPositions) {
/* 1293 */     this.methodPositions = methodPositions;
/*      */   }
/*      */   
/*      */   void setMethods(List<MethodInfo> methods, NameTable names) {
/* 1297 */     int size = methods.size();
/*      */     
/* 1299 */     if (size == 0) {
/* 1300 */       this.methods = MethodInternal.EMPTY_ARRAY;
/*      */       
/*      */       return;
/*      */     } 
/* 1304 */     this.methods = new MethodInternal[size];
/*      */     
/* 1306 */     for (int i = 0; i < size; i++) {
/* 1307 */       MethodInfo methodInfo = methods.get(i);
/* 1308 */       MethodInternal internal = names.intern(methodInfo.methodInternal());
/* 1309 */       methodInfo.setMethodInternal(internal);
/* 1310 */       this.methods[i] = internal;
/*      */     } 
/*      */     
/* 1313 */     this.methodPositions = sortAndGetPositions(this.methods, MethodInternal.NAME_AND_PARAMETER_COMPONENT_COMPARATOR, names);
/*      */   }
/*      */   
/*      */   void setRecordComponentArray(RecordComponentInternal[] recordComponents) {
/* 1317 */     if (recordComponents.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1321 */     if (this.extra == null) {
/* 1322 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1325 */     this.extra.recordComponents = recordComponents;
/*      */   }
/*      */   
/*      */   void setRecordComponentPositionArray(byte[] recordComponentPositions) {
/* 1329 */     if (recordComponentPositions.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1333 */     if (this.extra == null) {
/* 1334 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1337 */     this.extra.recordComponentPositions = recordComponentPositions;
/*      */   }
/*      */   
/*      */   void setRecordComponents(List<RecordComponentInfo> recordComponents, NameTable names) {
/* 1341 */     int size = recordComponents.size();
/*      */     
/* 1343 */     if (size == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1347 */     if (this.extra == null) {
/* 1348 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1351 */     this.extra.recordComponents = new RecordComponentInternal[size];
/*      */     
/* 1353 */     for (int i = 0; i < size; i++) {
/* 1354 */       RecordComponentInfo recordComponentInfo = recordComponents.get(i);
/* 1355 */       RecordComponentInternal internal = names.intern(recordComponentInfo.recordComponentInternal());
/* 1356 */       recordComponentInfo.setRecordComponentInternal(internal);
/* 1357 */       this.extra.recordComponents[i] = internal;
/*      */     } 
/*      */     
/* 1360 */     this.extra.recordComponentPositions = sortAndGetPositions(this.extra.recordComponents, RecordComponentInternal.NAME_COMPARATOR, names);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> byte[] sortAndGetPositions(T[] internals, Comparator<T> comparator, NameTable names) {
/*      */     Map<T, Integer> originalPositions;
/*      */     byte[] positions;
/* 1375 */     int size = internals.length;
/* 1376 */     boolean storePositions = (size > 1 && size <= 256);
/*      */ 
/*      */ 
/*      */     
/* 1380 */     if (storePositions) {
/* 1381 */       originalPositions = new IdentityHashMap<>(size);
/* 1382 */       for (int i = 0; i < size; i++) {
/* 1383 */         originalPositions.put(internals[i], Integer.valueOf(i));
/*      */       }
/*      */     } else {
/* 1386 */       originalPositions = null;
/*      */     } 
/*      */     
/* 1389 */     Arrays.sort(internals, comparator);
/*      */     
/* 1391 */     if (storePositions) {
/* 1392 */       positions = new byte[size];
/*      */       
/* 1394 */       for (int i = 0; i < size; i++)
/*      */       {
/* 1396 */         positions[((Integer)originalPositions.get(internals[i])).intValue()] = (byte)i;
/*      */       }
/*      */     } else {
/* 1399 */       positions = EMPTY_POSITIONS;
/*      */     } 
/*      */     
/* 1402 */     return names.intern(positions);
/*      */   }
/*      */   
/*      */   void setSuperClassType(Type superClassType) {
/* 1406 */     this.superClassType = superClassType;
/*      */   }
/*      */   
/*      */   void setInterfaceTypes(Type[] interfaceTypes) {
/* 1410 */     this.interfaceTypes = (interfaceTypes.length == 0) ? Type.EMPTY_ARRAY : interfaceTypes;
/*      */   }
/*      */   
/*      */   void setTypeParameters(Type[] typeParameters) {
/* 1414 */     if (typeParameters.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1418 */     if (this.extra == null) {
/* 1419 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1422 */     this.extra.typeParameters = typeParameters;
/*      */   }
/*      */   
/*      */   void setInnerClassInfo(DotName enclosingClass, String simpleName, boolean knownInnerClass) {
/* 1426 */     boolean setValues = (enclosingClass != null || simpleName != null);
/*      */ 
/*      */ 
/*      */     
/* 1430 */     if (this.nestingInfo == null && (knownInnerClass || setValues)) {
/* 1431 */       this.nestingInfo = new NestingInfo();
/*      */     }
/*      */     
/* 1434 */     if (!setValues) {
/*      */       return;
/*      */     }
/*      */     
/* 1438 */     this.nestingInfo.enclosingClass = enclosingClass;
/* 1439 */     this.nestingInfo.simpleName = simpleName;
/*      */   }
/*      */   
/*      */   void setMemberClasses(Set<DotName> memberClasses) {
/* 1443 */     if (memberClasses == null || memberClasses.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/* 1447 */     if (this.extra == null) {
/* 1448 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1451 */     this.extra.memberClasses = memberClasses;
/*      */   }
/*      */   
/*      */   void setEnclosingMethod(EnclosingMethodInfo enclosingMethod) {
/* 1455 */     if (enclosingMethod == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1459 */     if (this.nestingInfo == null) {
/* 1460 */       this.nestingInfo = new NestingInfo();
/*      */     }
/*      */     
/* 1463 */     this.nestingInfo.enclosingMethod = enclosingMethod;
/*      */   }
/*      */   
/*      */   void setModule(ModuleInfo module) {
/* 1467 */     if (module == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1471 */     if (this.extra == null) {
/* 1472 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1475 */     this.extra.module = module;
/*      */   }
/*      */   
/*      */   void setFlags(short flags) {
/* 1479 */     this.flags = flags;
/*      */   }
/*      */   
/*      */   void setPermittedSubclasses(Set<DotName> permittedSubclasses) {
/* 1483 */     if (permittedSubclasses == null || permittedSubclasses.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/* 1487 */     if (this.extra == null) {
/* 1488 */       this.extra = new ExtraInfo();
/*      */     }
/*      */     
/* 1491 */     this.extra.permittedSubclasses = permittedSubclasses;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ClassInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */