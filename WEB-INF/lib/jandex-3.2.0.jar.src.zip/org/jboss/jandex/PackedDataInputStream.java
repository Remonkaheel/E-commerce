/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PackedDataInputStream
/*    */   extends DataInputStream
/*    */ {
/*    */   static final int MAX_1BYTE = 127;
/*    */   
/*    */   public PackedDataInputStream(InputStream in) {
/* 41 */     super(in);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int readPackedU32() throws IOException {
/*    */     byte b;
/* 55 */     int i = 0;
/*    */     
/*    */     do {
/* 58 */       b = readByte();
/* 59 */       i = i << 7 | b & Byte.MAX_VALUE;
/* 60 */     } while ((b & 0x80) == 128);
/*    */     
/* 62 */     return i;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\PackedDataInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */