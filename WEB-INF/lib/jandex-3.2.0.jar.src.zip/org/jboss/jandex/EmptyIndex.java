/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EmptyIndex
/*    */   implements IndexView
/*    */ {
/* 14 */   public static final EmptyIndex INSTANCE = new EmptyIndex();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getKnownClasses() {
/* 21 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public ClassInfo getClassByName(DotName className) {
/* 26 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getKnownDirectSubclasses(DotName className) {
/* 31 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getAllKnownSubclasses(DotName className) {
/* 36 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getKnownDirectSubinterfaces(DotName interfaceName) {
/* 41 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getAllKnownSubinterfaces(DotName interfaceName) {
/* 46 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getKnownDirectImplementors(DotName interfaceName) {
/* 51 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getAllKnownImplementors(DotName interfaceName) {
/* 56 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<AnnotationInstance> getAnnotations(DotName annotationName) {
/* 61 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<AnnotationInstance> getAnnotationsWithRepeatable(DotName annotationName, IndexView index) {
/* 66 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ModuleInfo> getKnownModules() {
/* 71 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleInfo getModuleByName(DotName moduleName) {
/* 76 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getKnownUsers(DotName className) {
/* 81 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ClassInfo> getClassesInPackage(DotName packageName) {
/* 86 */     return Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<DotName> getSubpackages(DotName packageName) {
/* 91 */     return Collections.emptySet();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\EmptyIndex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */