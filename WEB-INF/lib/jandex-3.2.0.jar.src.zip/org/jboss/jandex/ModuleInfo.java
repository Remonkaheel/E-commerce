/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleInfo
/*     */ {
/*     */   static final int MODULE = 32768;
/*     */   private static final int OPEN = 32;
/*     */   private final ClassInfo moduleInfoClass;
/*     */   private final DotName name;
/*     */   private final short flags;
/*     */   private final String version;
/*     */   private DotName mainClass;
/*     */   private List<RequiredModuleInfo> requires;
/*     */   private List<ExportedPackageInfo> exports;
/*     */   private List<OpenedPackageInfo> opens;
/*     */   private List<DotName> uses;
/*     */   private List<ProvidedServiceInfo> provides;
/*     */   private List<DotName> packages;
/*     */   
/*     */   ModuleInfo(ClassInfo moduleInfoClass, DotName name, short flags, String version) {
/*  54 */     this.moduleInfoClass = moduleInfoClass;
/*  55 */     this.name = name;
/*  56 */     this.flags = flags;
/*  57 */     this.version = version;
/*  58 */     this.packages = Collections.emptyList();
/*  59 */     moduleInfoClass.setModule(this);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  63 */     return this.name.toString();
/*     */   }
/*     */   
/*     */   public ClassInfo moduleInfoClass() {
/*  67 */     return this.moduleInfoClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DotName name() {
/*  76 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short flags() {
/*  86 */     return this.flags;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/*  90 */     return ((this.flags & 0x20) != 0);
/*     */   }
/*     */   
/*     */   public String version() {
/*  94 */     return this.version;
/*     */   }
/*     */   
/*     */   public DotName mainClass() {
/*  98 */     return this.mainClass;
/*     */   }
/*     */   
/*     */   List<RequiredModuleInfo> requiresList() {
/* 102 */     return this.requires;
/*     */   }
/*     */   
/*     */   public List<RequiredModuleInfo> requires() {
/* 106 */     return Collections.unmodifiableList(this.requires);
/*     */   }
/*     */   
/*     */   List<ExportedPackageInfo> exportsList() {
/* 110 */     return this.exports;
/*     */   }
/*     */   
/*     */   public List<ExportedPackageInfo> exports() {
/* 114 */     return Collections.unmodifiableList(this.exports);
/*     */   }
/*     */   
/*     */   List<OpenedPackageInfo> opensList() {
/* 118 */     return this.opens;
/*     */   }
/*     */   
/*     */   public List<OpenedPackageInfo> opens() {
/* 122 */     return Collections.unmodifiableList(this.opens);
/*     */   }
/*     */   
/*     */   List<DotName> usesList() {
/* 126 */     return this.uses;
/*     */   }
/*     */   
/*     */   public List<DotName> uses() {
/* 130 */     return Collections.unmodifiableList(this.uses);
/*     */   }
/*     */   
/*     */   List<ProvidedServiceInfo> providesList() {
/* 134 */     return this.provides;
/*     */   }
/*     */   
/*     */   public List<ProvidedServiceInfo> provides() {
/* 138 */     return Collections.unmodifiableList(this.provides);
/*     */   }
/*     */   
/*     */   List<DotName> packagesList() {
/* 142 */     return this.packages;
/*     */   }
/*     */   
/*     */   public List<DotName> packages() {
/* 146 */     return Collections.unmodifiableList(this.packages);
/*     */   }
/*     */   
/*     */   public final boolean hasAnnotation(DotName name) {
/* 150 */     return this.moduleInfoClass.hasDeclaredAnnotation(name);
/*     */   }
/*     */   
/*     */   public final AnnotationInstance annotation(DotName name) {
/* 154 */     return this.moduleInfoClass.declaredAnnotation(name);
/*     */   }
/*     */   
/*     */   public final List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 158 */     return this.moduleInfoClass.declaredAnnotationsWithRepeatable(name, index);
/*     */   }
/*     */   
/*     */   public final Collection<AnnotationInstance> annotations() {
/* 162 */     return this.moduleInfoClass.declaredAnnotations();
/*     */   }
/*     */   
/*     */   void setMainClass(DotName mainClass) {
/* 166 */     this.mainClass = mainClass;
/*     */   }
/*     */   
/*     */   void setRequires(List<RequiredModuleInfo> requires) {
/* 170 */     this.requires = requires;
/*     */   }
/*     */   
/*     */   void setExports(List<ExportedPackageInfo> exports) {
/* 174 */     this.exports = exports;
/*     */   }
/*     */   
/*     */   void setOpens(List<OpenedPackageInfo> opens) {
/* 178 */     this.opens = opens;
/*     */   }
/*     */   
/*     */   void setUses(List<DotName> uses) {
/* 182 */     this.uses = uses;
/*     */   }
/*     */   
/*     */   void setProvides(List<ProvidedServiceInfo> provides) {
/* 186 */     this.provides = provides;
/*     */   }
/*     */   
/*     */   void setPackages(List<DotName> packages) {
/* 190 */     this.packages = packages;
/*     */   }
/*     */   
/*     */   public static final class RequiredModuleInfo
/*     */   {
/*     */     private static final int TRANSITIVE = 32;
/*     */     private static final int STATIC = 64;
/*     */     private final DotName name;
/*     */     private final int flags;
/*     */     private final String version;
/*     */     
/*     */     RequiredModuleInfo(DotName name, int flags, String version) {
/* 202 */       this.name = name;
/* 203 */       this.flags = flags;
/* 204 */       this.version = version;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 209 */       StringBuilder result = new StringBuilder("requires ");
/*     */       
/* 211 */       if (isStatic()) {
/* 212 */         result.append("static ");
/*     */       }
/*     */       
/* 215 */       if (isTransitive()) {
/* 216 */         result.append("transitive ");
/*     */       }
/*     */       
/* 219 */       result.append(this.name.toString());
/*     */       
/* 221 */       if (this.version != null) {
/* 222 */         result.append('@');
/* 223 */         result.append(this.version);
/*     */       } 
/*     */       
/* 226 */       return result.toString();
/*     */     }
/*     */     
/*     */     public DotName name() {
/* 230 */       return this.name;
/*     */     }
/*     */     
/*     */     public int flags() {
/* 234 */       return this.flags;
/*     */     }
/*     */     
/*     */     public String version() {
/* 238 */       return this.version;
/*     */     }
/*     */     
/*     */     public boolean isStatic() {
/* 242 */       return ((this.flags & 0x40) != 0);
/*     */     }
/*     */     
/*     */     public boolean isTransitive() {
/* 246 */       return ((this.flags & 0x20) != 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ExportedPackageInfo {
/*     */     private final DotName source;
/*     */     private final int flags;
/*     */     private final List<DotName> targets;
/*     */     
/*     */     ExportedPackageInfo(DotName source, int flags, List<DotName> targets) {
/* 256 */       this.source = source;
/* 257 */       this.flags = flags;
/* 258 */       this.targets = targets;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 263 */       StringBuilder result = new StringBuilder("exports ");
/*     */       
/* 265 */       result.append(this.source.toString());
/*     */       
/* 267 */       if (!this.targets.isEmpty()) {
/* 268 */         result.append(" to ");
/*     */         
/* 270 */         for (int i = 0, m = this.targets.size(); i < m; i++) {
/* 271 */           if (i > 0) {
/* 272 */             result.append(", ");
/*     */           }
/*     */           
/* 275 */           result.append(this.targets.get(i));
/*     */         } 
/*     */       } 
/*     */       
/* 279 */       return result.toString();
/*     */     }
/*     */     
/*     */     public DotName source() {
/* 283 */       return this.source;
/*     */     }
/*     */     
/*     */     public int flags() {
/* 287 */       return this.flags;
/*     */     }
/*     */     
/*     */     public boolean isQualified() {
/* 291 */       return !this.targets.isEmpty();
/*     */     }
/*     */     
/*     */     List<DotName> targetsList() {
/* 295 */       return this.targets;
/*     */     }
/*     */     
/*     */     public List<DotName> targets() {
/* 299 */       return Collections.unmodifiableList(this.targets);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class OpenedPackageInfo {
/*     */     private final DotName source;
/*     */     private final int flags;
/*     */     private final List<DotName> targets;
/*     */     
/*     */     OpenedPackageInfo(DotName source, int flags, List<DotName> targets) {
/* 309 */       this.source = source;
/* 310 */       this.flags = flags;
/* 311 */       this.targets = targets;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 316 */       StringBuilder result = new StringBuilder("opens ");
/*     */       
/* 318 */       result.append(this.source.toString());
/*     */       
/* 320 */       if (!this.targets.isEmpty()) {
/* 321 */         result.append(" to ");
/*     */         
/* 323 */         for (int i = 0, m = this.targets.size(); i < m; i++) {
/* 324 */           if (i > 0) {
/* 325 */             result.append(", ");
/*     */           }
/*     */           
/* 328 */           result.append(this.targets.get(i));
/*     */         } 
/*     */       } 
/*     */       
/* 332 */       return result.toString();
/*     */     }
/*     */     
/*     */     public DotName source() {
/* 336 */       return this.source;
/*     */     }
/*     */     
/*     */     public int flags() {
/* 340 */       return this.flags;
/*     */     }
/*     */     
/*     */     public boolean isQualified() {
/* 344 */       return !this.targets.isEmpty();
/*     */     }
/*     */     
/*     */     List<DotName> targetsList() {
/* 348 */       return this.targets;
/*     */     }
/*     */     
/*     */     public List<DotName> targets() {
/* 352 */       return Collections.unmodifiableList(this.targets);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ProvidedServiceInfo {
/*     */     private final DotName service;
/*     */     private final List<DotName> providers;
/*     */     
/*     */     ProvidedServiceInfo(DotName name, List<DotName> providers) {
/* 361 */       this.service = name;
/* 362 */       this.providers = providers;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 367 */       StringBuilder result = new StringBuilder("provides ");
/*     */       
/* 369 */       result.append(this.service.toString());
/*     */       
/* 371 */       if (!this.providers.isEmpty()) {
/* 372 */         result.append(" with ");
/*     */         
/* 374 */         for (int i = 0, m = this.providers.size(); i < m; i++) {
/* 375 */           if (i > 0) {
/* 376 */             result.append(", ");
/*     */           }
/*     */           
/* 379 */           result.append(this.providers.get(i));
/*     */         } 
/*     */       } 
/*     */       
/* 383 */       return result.toString();
/*     */     }
/*     */     
/*     */     public DotName service() {
/* 387 */       return this.service;
/*     */     }
/*     */     
/*     */     List<DotName> providersList() {
/* 391 */       return this.providers;
/*     */     }
/*     */     
/*     */     public List<DotName> providers() {
/* 395 */       return Collections.unmodifiableList(this.providers);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ModuleInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */