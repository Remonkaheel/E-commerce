/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeVariableReference
/*     */   extends Type
/*     */ {
/*     */   private final String name;
/*     */   private TypeVariable target;
/*     */   private final DotName internalClassName;
/*     */   
/*     */   TypeVariableReference(String name, DotName internalClassName) {
/*  50 */     this(name, null, null, internalClassName);
/*     */   }
/*     */   
/*     */   TypeVariableReference(String name, TypeVariable target, AnnotationInstance[] annotations, DotName internalClassName) {
/*  54 */     super(DotName.OBJECT_NAME, annotations);
/*  55 */     this.name = name;
/*  56 */     this.target = target;
/*     */     
/*  58 */     this.internalClassName = internalClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public DotName name() {
/*  63 */     if (this.target == null) {
/*  64 */       throw new IllegalStateException("Type variable reference " + this.name + " was not patched correctly");
/*     */     }
/*  66 */     return this.target.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String identifier() {
/*  84 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeVariable follow() {
/*  91 */     if (this.target == null) {
/*  92 */       throw new IllegalStateException("Type variable reference " + this.name + " was not patched correctly");
/*     */     }
/*  94 */     return this.target;
/*     */   }
/*     */   
/*     */   DotName internalClassName() {
/*  98 */     return this.internalClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 103 */     return Type.Kind.TYPE_VARIABLE_REFERENCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeVariableReference asTypeVariableReference() {
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 113 */     return new TypeVariableReference(this.name, this.target, newAnnotations, this.internalClassName);
/*     */   }
/*     */   
/*     */   void setTarget(TypeVariable target) {
/* 117 */     if (target == null) {
/* 118 */       throw new IllegalArgumentException("Type variable reference target must not be null");
/*     */     }
/* 120 */     this.target = target;
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(boolean simple) {
/* 125 */     StringBuilder builder = new StringBuilder();
/* 126 */     appendAnnotations(builder);
/* 127 */     builder.append(this.name);
/* 128 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 133 */     if (this.target == null) {
/* 134 */       throw new IllegalStateException("Type variable reference " + this.name + " was not patched correctly");
/*     */     }
/*     */     
/* 137 */     if (this == o) {
/* 138 */       return true;
/*     */     }
/*     */     
/* 141 */     if (!super.equals(o)) {
/* 142 */       return false;
/*     */     }
/*     */     
/* 145 */     TypeVariableReference that = (TypeVariableReference)o;
/*     */     
/* 147 */     return this.name.equals(that.name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 152 */     if (this.target == null) {
/* 153 */       throw new IllegalStateException("Type variable reference " + this.name + " was not patched correctly");
/*     */     }
/*     */     
/* 156 */     int hash = super.hashCode();
/* 157 */     hash = 31 * hash + this.name.hashCode();
/* 158 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 164 */     return (this == o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 170 */     return Objects.hash(new Object[] { this.name, this.internalClassName });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\TypeVariableReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */