/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Array;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Utils
/*     */ {
/*  39 */   static final byte[] INIT_METHOD_NAME = toUTF8("<init>");
/*     */   
/*  41 */   static final byte[] CLINIT_METHOD_NAME = toUTF8("<clinit>");
/*     */   
/*     */   static byte[] toUTF8(String string) {
/*  44 */     return string.getBytes(StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   static String fromUTF8(byte[] bytes) {
/*  48 */     return new String(bytes, StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   static <K, V> Map<K, V[]> unfold(Map<K, List<V>> map, Class<V> listElementType) {
/*  52 */     if (map.isEmpty()) {
/*  53 */       return Collections.emptyMap();
/*     */     }
/*     */     
/*  56 */     Map<K, V[]> result = new HashMap<>();
/*  57 */     map.forEach((key, value) -> {
/*     */           V[] array = (V[])Array.newInstance(listElementType, value.size());
/*     */           result.put(key, value.toArray((Object[])array));
/*     */         });
/*  61 */     return result;
/*     */   }
/*     */   
/*     */   static <T> List<T> listOfCapacity(int capacity) {
/*  65 */     return (capacity > 0) ? new ArrayList<>(capacity) : Collections.<T>emptyList();
/*     */   }
/*     */   
/*     */   static final class ReusableBufferedDataInputStream extends DataInputStream {
/*  69 */     private Utils.ReusableBufferedInputStream reusableBuffered = null;
/*     */     
/*     */     ReusableBufferedDataInputStream() {
/*  72 */       super((InputStream)null);
/*     */     }
/*     */     
/*     */     void setInputStream(InputStream in) {
/*  76 */       Objects.requireNonNull(in);
/*     */       
/*  78 */       if (in instanceof BufferedInputStream) {
/*  79 */         assert !(in instanceof Utils.ReusableBufferedInputStream);
/*  80 */         this.in = in;
/*     */       } else {
/*  82 */         if (this.in == null) {
/*  83 */           if (this.reusableBuffered == null) {
/*  84 */             this.reusableBuffered = new Utils.ReusableBufferedInputStream();
/*     */           }
/*  86 */           this.in = this.reusableBuffered;
/*     */         } 
/*  88 */         this.reusableBuffered.setInputStream(in);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/*  94 */       if (this.in == this.reusableBuffered) {
/*  95 */         this.reusableBuffered.close();
/*     */       } else {
/*  97 */         this.in = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean markSupported() {
/* 103 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public synchronized void mark(int readlimit) {
/* 109 */       throw new UnsupportedOperationException("mark/reset not supported");
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public synchronized void reset() {
/* 115 */       throw new UnsupportedOperationException("mark/reset not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ReusableBufferedInputStream extends BufferedInputStream {
/*     */     private ReusableBufferedInputStream() {
/* 121 */       super((InputStream)null);
/*     */     }
/*     */     
/*     */     void setInputStream(InputStream in) {
/* 125 */       Objects.requireNonNull(in);
/* 126 */       if (this.pos != 0 && this.in != null) {
/* 127 */         throw new IllegalStateException("the stream cannot be reused");
/*     */       }
/* 129 */       this.in = in;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 134 */       this.in = null;
/* 135 */       this.count = 0;
/* 136 */       this.pos = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean markSupported() {
/* 141 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public synchronized void mark(int readlimit) {
/* 147 */       throw new UnsupportedOperationException("mark/reset not supported");
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public synchronized void reset() {
/* 153 */       throw new UnsupportedOperationException("mark/reset not supported");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */