/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class StrongInternPool<E>
/*     */   implements Cloneable, Serializable
/*     */ {
/*  45 */   private static final Object NULL = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 10929568968762L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_CAPACITY = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MAXIMUM_CAPACITY = 1073741824;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.67F;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<E> elementType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Object[] table;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int size;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int threshold;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final float loadFactor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int modCount;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Index index;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StrongInternPool(Class<E> elementType, int initialCapacity, float loadFactor) {
/* 106 */     if (elementType == null) {
/* 107 */       throw new IllegalArgumentException("Element type must be set");
/*     */     }
/* 109 */     if (initialCapacity < 0) {
/* 110 */       throw new IllegalArgumentException("Can not have a negative size table!");
/*     */     }
/* 112 */     if (initialCapacity > 1073741824) {
/* 113 */       initialCapacity = 1073741824;
/*     */     }
/* 115 */     if (loadFactor <= 0.0F || loadFactor > 1.0F) {
/* 116 */       throw new IllegalArgumentException("Load factor must be greater than 0 and less than or equal to 1");
/*     */     }
/* 118 */     this.elementType = elementType;
/* 119 */     this.loadFactor = loadFactor;
/* 120 */     init(initialCapacity, loadFactor);
/*     */   }
/*     */   
/*     */   private void init(int initialCapacity, float loadFactor) {
/* 124 */     int c = 1;
/* 125 */     for (; c < initialCapacity; c <<= 1);
/*     */     
/* 127 */     this.threshold = (int)(c * loadFactor);
/*     */ 
/*     */     
/* 130 */     if (initialCapacity > this.threshold && c < 1073741824) {
/* 131 */       c <<= 1;
/* 132 */       this.threshold = (int)(c * loadFactor);
/*     */     } 
/*     */     
/* 135 */     this.table = new Object[c];
/*     */   }
/*     */   
/*     */   StrongInternPool(Class<E> elementType, int initialCapacity) {
/* 139 */     this(elementType, initialCapacity, 0.67F);
/*     */   }
/*     */   
/*     */   StrongInternPool(Class<E> elementType) {
/* 143 */     this(elementType, 8);
/*     */   }
/*     */   
/*     */   boolean mayContain(Object o) {
/* 147 */     return (o == null || o.getClass() == this.elementType);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean eq(Object o1, Object o2) {
/* 152 */     if (o1 == NULL || o2 == NULL) {
/* 153 */       return (o1 == o2);
/*     */     }
/* 155 */     return equality((E)o1, (E)o2);
/*     */   }
/*     */ 
/*     */   
/*     */   int hash(Object o) {
/* 160 */     if (o == NULL) {
/* 161 */       return 0;
/*     */     }
/* 163 */     return hashCode((E)o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <K> K maskNull(K key) {
/* 172 */     return (key == null) ? (K)NULL : key;
/*     */   }
/*     */   
/*     */   private static <K> K unmaskNull(K key) {
/* 176 */     return (key == NULL) ? null : key;
/*     */   }
/*     */   
/*     */   private int nextIndex(int index, int length) {
/* 180 */     index = (index >= length - 1) ? 0 : (index + 1);
/* 181 */     return index;
/*     */   }
/*     */   
/*     */   private static int index(int hashCode, int length) {
/* 185 */     return hashCode & length - 1;
/*     */   }
/*     */   
/*     */   public int size() {
/* 189 */     return this.size;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 193 */     return (this.size == 0);
/*     */   }
/*     */   
/*     */   public boolean contains(Object entry) {
/* 197 */     if (!mayContain(entry)) {
/* 198 */       return false;
/*     */     }
/*     */     
/* 201 */     entry = maskNull(entry);
/*     */     
/* 203 */     int hash = hash(entry);
/* 204 */     int length = this.table.length;
/* 205 */     int index = index(hash, length);
/*     */     
/* 207 */     int start = index; while (true) {
/* 208 */       Object e = this.table[index];
/* 209 */       if (e == null) {
/* 210 */         return false;
/*     */       }
/* 212 */       if (eq(entry, e)) {
/* 213 */         return true;
/*     */       }
/* 215 */       index = nextIndex(index, length);
/* 216 */       if (index == start)
/* 217 */         return false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int offset(Object entry) {
/* 222 */     entry = maskNull(entry);
/*     */     
/* 224 */     int hash = hash(entry);
/* 225 */     int length = this.table.length;
/* 226 */     int index = index(hash, length);
/*     */     
/* 228 */     int start = index; while (true) {
/* 229 */       Object e = this.table[index];
/* 230 */       if (e == null) {
/* 231 */         return -1;
/*     */       }
/* 233 */       if (eq(entry, e)) {
/* 234 */         return index;
/*     */       }
/* 236 */       index = nextIndex(index, length);
/* 237 */       if (index == start) {
/* 238 */         return -1;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E intern(E entry) {
/* 252 */     entry = maskNull(entry);
/*     */     
/* 254 */     Object[] table = this.table;
/* 255 */     int hash = hash(entry);
/* 256 */     int length = table.length;
/* 257 */     int index = index(hash, length);
/*     */     
/* 259 */     int start = index; while (true) {
/* 260 */       Object e = table[index];
/* 261 */       if (e == null) {
/*     */         break;
/*     */       }
/* 264 */       if (eq(entry, e)) {
/* 265 */         return unmaskNull((E)e);
/*     */       }
/* 267 */       index = nextIndex(index, length);
/* 268 */       if (index == start) {
/* 269 */         throw new IllegalStateException("Table is full!");
/*     */       }
/*     */     } 
/* 272 */     this.modCount++;
/* 273 */     table[index] = entry;
/* 274 */     if (++this.size >= this.threshold) {
/* 275 */       resize(length);
/*     */     }
/* 277 */     return unmaskNull(entry);
/*     */   }
/*     */   
/*     */   private void resize(int from) {
/* 281 */     int newLength = from << 1;
/*     */ 
/*     */     
/* 284 */     if (newLength > 1073741824 || newLength <= from) {
/*     */       return;
/*     */     }
/* 287 */     Object[] newTable = new Object[newLength];
/* 288 */     Object[] old = this.table;
/*     */     
/* 290 */     for (Object e : old) {
/* 291 */       if (e != null) {
/*     */ 
/*     */         
/* 294 */         int index = index(hash(e), newLength);
/* 295 */         while (newTable[index] != null) {
/* 296 */           index = nextIndex(index, newLength);
/*     */         }
/* 298 */         newTable[index] = e;
/*     */       } 
/*     */     } 
/* 301 */     this.threshold = (int)(this.loadFactor * newLength);
/* 302 */     this.table = newTable;
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 306 */     if (!mayContain(o)) {
/* 307 */       return false;
/*     */     }
/*     */     
/* 310 */     o = maskNull(o);
/*     */     
/* 312 */     Object[] table = this.table;
/* 313 */     int length = table.length;
/* 314 */     int hash = hash(o);
/* 315 */     int start = index(hash, length);
/*     */     
/* 317 */     int index = start; while (true) {
/* 318 */       Object e = table[index];
/* 319 */       if (e == null) {
/* 320 */         return false;
/*     */       }
/* 322 */       if (eq(e, o)) {
/* 323 */         table[index] = null;
/* 324 */         relocate(index);
/* 325 */         this.modCount++;
/* 326 */         this.size--;
/* 327 */         return true;
/*     */       } 
/*     */       
/* 330 */       index = nextIndex(index, length);
/* 331 */       if (index == start)
/* 332 */         return false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void relocate(int start) {
/* 337 */     Object[] table = this.table;
/* 338 */     int length = table.length;
/* 339 */     int current = nextIndex(start, length);
/*     */     
/*     */     while (true) {
/* 342 */       Object e = table[current];
/* 343 */       if (e == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 349 */       int prefer = index(hash(e), length);
/* 350 */       if ((current < prefer && (prefer <= start || start <= current)) || (prefer <= start && start <= current)) {
/* 351 */         table[start] = e;
/* 352 */         table[current] = null;
/* 353 */         start = current;
/*     */       } 
/*     */       
/* 356 */       current = nextIndex(current, length);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/* 361 */     this.modCount++;
/* 362 */     Object[] table = this.table;
/* 363 */     for (int i = 0; i < table.length; i++) {
/* 364 */       table[i] = null;
/*     */     }
/* 366 */     this.size = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public StrongInternPool<E> clone() {
/*     */     try {
/* 372 */       StrongInternPool<E> clone = (StrongInternPool<E>)super.clone();
/* 373 */       clone.table = (Object[])this.table.clone();
/* 374 */       return clone;
/* 375 */     } catch (CloneNotSupportedException e) {
/*     */       
/* 377 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toInternalArray() {
/* 391 */     return this.table;
/*     */   }
/*     */   
/*     */   public void printDebugStats() {
/* 395 */     int optimal = 0;
/* 396 */     int total = 0;
/* 397 */     int totalSkew = 0;
/* 398 */     int maxSkew = 0;
/* 399 */     for (int i = 0; i < this.table.length; i++) {
/* 400 */       Object e = this.table[i];
/* 401 */       if (e != null) {
/*     */         
/* 403 */         total++;
/* 404 */         int target = index(hash(e), this.table.length);
/* 405 */         if (i == target) {
/* 406 */           optimal++;
/*     */         } else {
/* 408 */           int skew = Math.abs(i - target);
/* 409 */           if (skew > maxSkew)
/* 410 */             maxSkew = skew; 
/* 411 */           totalSkew += skew;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 417 */     System.out.println(" Size:            " + this.size);
/* 418 */     System.out.println(" Real Size:       " + total);
/* 419 */     System.out.println(" Optimal:         " + optimal + " (" + (optimal * 100.0F / total) + "%)");
/* 420 */     System.out.println(" Average Distnce: " + (totalSkew / (total - optimal)));
/* 421 */     System.out.println(" Max Distance:    " + maxSkew);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 426 */     s.defaultReadObject();
/*     */     
/* 428 */     int size = s.readInt();
/*     */     
/* 430 */     init(size, this.loadFactor);
/*     */     
/* 432 */     for (int i = 0; i < size; i++) {
/* 433 */       putForCreate((E)s.readObject());
/*     */     }
/*     */     
/* 436 */     this.size = size;
/*     */   }
/*     */   
/*     */   private void putForCreate(E entry) {
/* 440 */     entry = maskNull(entry);
/*     */     
/* 442 */     Object[] table = this.table;
/* 443 */     int hash = hash(entry);
/* 444 */     int length = table.length;
/* 445 */     int index = index(hash, length);
/*     */     
/* 447 */     Object e = table[index];
/* 448 */     while (e != null) {
/* 449 */       index = nextIndex(index, length);
/* 450 */       e = table[index];
/*     */     } 
/*     */     
/* 453 */     table[index] = entry;
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream s) throws IOException {
/* 457 */     s.defaultWriteObject();
/* 458 */     s.writeInt(this.size);
/*     */     
/* 460 */     for (Object e : this.table) {
/* 461 */       if (e != null) {
/* 462 */         s.writeObject(unmaskNull(e));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Iterator<E> iterator() {
/* 468 */     return new IdentityHashSetIterator();
/*     */   }
/*     */   
/*     */   public Index index() {
/* 472 */     if (this.index == null || this.index.modCount != this.modCount) {
/* 473 */       this.index = new Index();
/*     */     }
/*     */     
/* 476 */     return this.index;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 480 */     Iterator<E> i = iterator();
/* 481 */     if (!i.hasNext()) {
/* 482 */       return "[]";
/*     */     }
/* 484 */     StringBuilder sb = new StringBuilder();
/* 485 */     sb.append('[');
/*     */     while (true) {
/* 487 */       E e = i.next();
/* 488 */       sb.append(e);
/* 489 */       if (!i.hasNext())
/* 490 */         return sb.append(']').toString(); 
/* 491 */       sb.append(", ");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Index
/*     */   {
/* 500 */     private int[] offsets = new int[StrongInternPool.this.table.length]; private int modCount; Index() {
/* 501 */       for (int i = 0, c = 1; i < this.offsets.length; i++) {
/* 502 */         if (StrongInternPool.this.table[i] != null)
/* 503 */           this.offsets[i] = c++; 
/*     */       } 
/* 505 */       this.modCount = StrongInternPool.this.modCount;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int positionOf(E e) {
/* 516 */       int offset = StrongInternPool.this.offset(e);
/* 517 */       return (offset < 0) ? -1 : this.offsets[offset];
/*     */     }
/*     */   }
/*     */   
/*     */   private class IdentityHashSetIterator implements Iterator<E> {
/* 522 */     private int next = 0;
/* 523 */     private int expectedCount = StrongInternPool.this.modCount;
/* 524 */     private int current = -1;
/*     */     private boolean hasNext;
/* 526 */     Object[] table = StrongInternPool.this.table;
/*     */     
/*     */     public boolean hasNext() {
/* 529 */       if (this.hasNext) {
/* 530 */         return true;
/*     */       }
/* 532 */       Object[] table = this.table;
/* 533 */       for (int i = this.next; i < table.length; i++) {
/* 534 */         if (table[i] != null) {
/* 535 */           this.next = i;
/* 536 */           return this.hasNext = true;
/*     */         } 
/*     */       } 
/*     */       
/* 540 */       this.next = table.length;
/* 541 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 546 */       if (StrongInternPool.this.modCount != this.expectedCount) {
/* 547 */         throw new ConcurrentModificationException();
/*     */       }
/* 549 */       if (!this.hasNext && !hasNext()) {
/* 550 */         throw new NoSuchElementException();
/*     */       }
/* 552 */       this.current = this.next++;
/* 553 */       this.hasNext = false;
/*     */       
/* 555 */       return (E)StrongInternPool.unmaskNull((K)this.table[this.current]);
/*     */     }
/*     */     
/*     */     public void remove() {
/* 559 */       if (StrongInternPool.this.modCount != this.expectedCount) {
/* 560 */         throw new ConcurrentModificationException();
/*     */       }
/* 562 */       int current = this.current;
/* 563 */       int delete = current;
/*     */       
/* 565 */       if (current == -1) {
/* 566 */         throw new IllegalStateException();
/*     */       }
/*     */       
/* 569 */       this.current = -1;
/*     */ 
/*     */       
/* 572 */       this.next = delete;
/*     */       
/* 574 */       Object[] table = this.table;
/* 575 */       if (table != StrongInternPool.this.table) {
/* 576 */         StrongInternPool.this.remove(table[delete]);
/* 577 */         table[delete] = null;
/* 578 */         this.expectedCount = StrongInternPool.this.modCount;
/*     */         
/*     */         return;
/*     */       } 
/* 582 */       int length = table.length;
/* 583 */       int i = delete;
/*     */       
/* 585 */       table[delete] = null;
/* 586 */       StrongInternPool.this.size--;
/*     */       
/*     */       while (true) {
/* 589 */         i = StrongInternPool.this.nextIndex(i, length);
/* 590 */         Object e = table[i];
/* 591 */         if (e == null) {
/*     */           break;
/*     */         }
/* 594 */         int prefer = StrongInternPool.index(StrongInternPool.this.hash(e), length);
/* 595 */         if ((i < prefer && (prefer <= delete || delete <= i)) || (prefer <= delete && delete <= i)) {
/*     */ 
/*     */ 
/*     */           
/* 599 */           if (i < current && current <= delete && table == StrongInternPool.this.table) {
/* 600 */             int remaining = length - current;
/* 601 */             Object[] newTable = new Object[remaining];
/* 602 */             System.arraycopy(table, current, newTable, 0, remaining);
/*     */ 
/*     */ 
/*     */             
/* 606 */             this.table = newTable;
/* 607 */             this.next = 0;
/*     */           } 
/*     */ 
/*     */           
/* 611 */           table[delete] = e;
/* 612 */           table[i] = null;
/* 613 */           delete = i;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private IdentityHashSetIterator() {}
/*     */   }
/*     */   
/*     */   static StrongInternPool<byte[]> forByteArrays() {
/* 623 */     return new ByteArrayInternPool();
/*     */   }
/*     */   
/*     */   static StrongInternPool<String> forStrings() {
/* 627 */     return new StringInternPool();
/*     */   }
/*     */   
/*     */   static StrongInternPool<Type> forTypes() {
/* 631 */     return new TypeInternPool();
/*     */   }
/*     */   
/*     */   static StrongInternPool<Type[]> forTypeArrays() {
/* 635 */     return new TypeArrayInternPool();
/*     */   }
/*     */   
/*     */   static StrongInternPool<MethodInternal> forMethods() {
/* 639 */     return new MethodInternPool();
/*     */   }
/*     */   
/*     */   static StrongInternPool<FieldInternal> forFields() {
/* 643 */     return new FieldInternPool();
/*     */   }
/*     */   abstract boolean equality(E paramE1, E paramE2);
/*     */   static StrongInternPool<RecordComponentInternal> forRecordComponents() {
/* 647 */     return new RecordComponentInternPool();
/*     */   }
/*     */   abstract int hashCode(E paramE);
/*     */   
/*     */   private static final class ByteArrayInternPool extends StrongInternPool<byte[]> { ByteArrayInternPool() {
/* 652 */       super((Class)byte[].class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(byte[] o1, byte[] o2) {
/* 657 */       return Arrays.equals(o1, o2);
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(byte[] o) {
/* 662 */       return Arrays.hashCode(o);
/*     */     } }
/*     */ 
/*     */   
/*     */   private static final class StringInternPool extends StrongInternPool<String> {
/*     */     public StringInternPool() {
/* 668 */       super(String.class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(String o1, String o2) {
/* 673 */       return (o1 != null && o1.equals(o2));
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(String o) {
/* 678 */       return o.hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class TypeInternPool extends StrongInternPool<Type> {
/*     */     public TypeInternPool() {
/* 684 */       super(Type.class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(Type o1, Type o2) {
/* 689 */       return (o1 != null && o1.internEquals(o2));
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(Type o) {
/* 694 */       return o.internHashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class TypeArrayInternPool extends StrongInternPool<Type[]> {
/*     */     public TypeArrayInternPool() {
/* 700 */       super((Class)Type[].class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(Type[] o1, Type[] o2) {
/* 705 */       return TypeInterning.arrayEquals(o1, o2);
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(Type[] o) {
/* 710 */       return TypeInterning.arrayHashCode(o);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class MethodInternPool extends StrongInternPool<MethodInternal> {
/*     */     public MethodInternPool() {
/* 716 */       super(MethodInternal.class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(MethodInternal o1, MethodInternal o2) {
/* 721 */       return (o1 != null && o1.internEquals(o2));
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(MethodInternal o) {
/* 726 */       return o.internHashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class FieldInternPool extends StrongInternPool<FieldInternal> {
/*     */     public FieldInternPool() {
/* 732 */       super(FieldInternal.class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(FieldInternal o1, FieldInternal o2) {
/* 737 */       return (o1 != null && o1.internEquals(o2));
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(FieldInternal o) {
/* 742 */       return o.internHashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class RecordComponentInternPool extends StrongInternPool<RecordComponentInternal> {
/*     */     public RecordComponentInternPool() {
/* 748 */       super(RecordComponentInternal.class);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean equality(RecordComponentInternal o1, RecordComponentInternal o2) {
/* 753 */       return (o1 != null && o1.internEquals(o2));
/*     */     }
/*     */ 
/*     */     
/*     */     int hashCode(RecordComponentInternal o) {
/* 758 */       return o.internHashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\StrongInternPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */