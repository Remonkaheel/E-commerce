/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.AbstractList;
/*    */ 
/*    */ final class ImmutableArrayList<T> extends AbstractList<T> {
/*    */   private final T[] array;
/*    */   
/*    */   ImmutableArrayList(T[] array) {
/*  9 */     this.array = array;
/*    */   }
/*    */ 
/*    */   
/*    */   public T get(int index) {
/* 14 */     return this.array[index];
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 19 */     return this.array.length;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ImmutableArrayList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */