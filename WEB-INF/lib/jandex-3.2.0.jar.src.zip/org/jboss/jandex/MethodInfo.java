/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodInfo
/*     */   implements Declaration, Descriptor, GenericSignature
/*     */ {
/*  54 */   static final String[] EMPTY_PARAMETER_NAMES = new String[0];
/*     */   
/*     */   private MethodInternal methodInternal;
/*     */   private ClassInfo clazz;
/*     */   
/*     */   MethodInfo() {}
/*     */   
/*     */   MethodInfo(ClassInfo clazz, MethodInternal methodInternal) {
/*  62 */     this.methodInternal = methodInternal;
/*  63 */     this.clazz = clazz;
/*     */   }
/*     */   
/*     */   MethodInfo(ClassInfo clazz, byte[] name, byte[][] parameterNames, Type[] parameterTypes, Type returnType, short flags) {
/*  67 */     this(clazz, new MethodInternal(name, parameterNames, parameterTypes, returnType, flags));
/*     */   }
/*     */ 
/*     */   
/*     */   MethodInfo(ClassInfo clazz, byte[] name, byte[][] parameterNames, Type[] parameterTypes, Type returnType, short flags, Type[] typeParameters, Type[] exceptions) {
/*  72 */     this(clazz, new MethodInternal(name, parameterNames, parameterTypes, returnType, flags, typeParameters, exceptions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInfo create(ClassInfo clazz, String name, Type[] parameterTypes, Type returnType, short flags) {
/*  86 */     return create(clazz, name, parameterTypes, returnType, flags, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInfo create(ClassInfo clazz, String name, Type[] parameterTypes, Type returnType, short flags, TypeVariable[] typeParameters, Type[] exceptions) {
/* 105 */     return create(clazz, name, EMPTY_PARAMETER_NAMES, parameterTypes, returnType, flags, typeParameters, exceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInfo create(ClassInfo clazz, String name, String[] parameterNames, Type[] parameterTypes, Type returnType, short flags, TypeVariable[] typeParameters, Type[] exceptions) {
/*     */     byte[] bytes;
/*     */     byte[][] parameterNameBytes;
/* 125 */     if (clazz == null) {
/* 126 */       throw new IllegalArgumentException("Clazz can't be null");
/*     */     }
/* 128 */     if (name == null) {
/* 129 */       throw new IllegalArgumentException("Name can't be null");
/*     */     }
/* 131 */     if (parameterTypes == null) {
/* 132 */       throw new IllegalArgumentException("Parameter types can't be null");
/*     */     }
/* 134 */     if (parameterNames == null) {
/* 135 */       throw new IllegalArgumentException("Parameter names can't be null");
/*     */     }
/* 137 */     if (returnType == null) {
/* 138 */       throw new IllegalArgumentException("Return type can't be null");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 143 */       bytes = name.getBytes("UTF-8");
/* 144 */       parameterNameBytes = new byte[parameterNames.length][];
/* 145 */       for (int i = 0; i < parameterNames.length; i++) {
/* 146 */         parameterNameBytes[i] = parameterNames[i].getBytes("UTF-8");
/*     */       }
/* 148 */     } catch (UnsupportedEncodingException e) {
/* 149 */       throw new IllegalArgumentException(e);
/*     */     } 
/* 151 */     return new MethodInfo(clazz, bytes, parameterNameBytes, parameterTypes, returnType, flags, (Type[])typeParameters, exceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String name() {
/* 160 */     return this.methodInternal.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String parameterName(int i) {
/* 170 */     return this.methodInternal.parameterName(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type parameterType(int i) {
/* 180 */     return this.methodInternal.parameterTypesArray()[i];
/*     */   }
/*     */   
/*     */   public final AnnotationTarget.Kind kind() {
/* 184 */     return AnnotationTarget.Kind.METHOD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ClassInfo declaringClass() {
/* 193 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final Type[] args() {
/* 208 */     return this.methodInternal.copyParameterTypes();
/*     */   }
/*     */   
/*     */   final Type[] copyParameters() {
/* 212 */     return this.methodInternal.copyParameterTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int parametersCount() {
/* 222 */     return this.methodInternal.parametersCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<Type> parameterTypes() {
/* 234 */     return this.methodInternal.parameterTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<MethodParameterInfo> parameters() {
/* 244 */     int parametersCount = this.methodInternal.parametersCount();
/* 245 */     List<MethodParameterInfo> parameters = new ArrayList<>(parametersCount);
/* 246 */     for (short i = 0; i < parametersCount; i = (short)(i + 1)) {
/* 247 */       parameters.add(new MethodParameterInfo(this, i));
/*     */     }
/* 249 */     return Collections.unmodifiableList(parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int descriptorParametersCount() {
/* 259 */     return (this.methodInternal.descriptorParameterTypesArray()).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<Type> descriptorParameterTypes() {
/* 269 */     return this.methodInternal.descriptorParameterTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type returnType() {
/* 279 */     return this.methodInternal.returnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type receiverType() {
/* 289 */     return this.methodInternal.receiverType(this.clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<Type> exceptions() {
/* 299 */     return this.methodInternal.exceptions();
/*     */   }
/*     */   
/*     */   final Type[] copyExceptions() {
/* 303 */     return this.methodInternal.copyExceptions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<TypeVariable> typeParameters() {
/* 313 */     return this.methodInternal.typeParameters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnnotation(DotName name) {
/* 325 */     return this.methodInternal.hasAnnotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationInstance annotation(DotName name) {
/* 355 */     return this.methodInternal.annotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotations(DotName name) {
/* 382 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 383 */     for (AnnotationInstance instance : this.methodInternal.annotationArray()) {
/* 384 */       if (instance.name().equals(name)) {
/* 385 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 388 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 409 */     if (index == null) {
/* 410 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 412 */     List<AnnotationInstance> instances = new ArrayList<>(annotations(name));
/* 413 */     ClassInfo annotationClass = index.getClassByName(name);
/* 414 */     if (annotationClass == null) {
/* 415 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 417 */     if (!annotationClass.isAnnotation()) {
/* 418 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 420 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 421 */     if (repeatable != null) {
/* 422 */       Type containingType = repeatable.value().asClass();
/* 423 */       for (AnnotationInstance container : annotations(containingType.name())) {
/* 424 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 425 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       } 
/*     */     } 
/* 429 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotations() {
/* 453 */     return this.methodInternal.annotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeclaredAnnotation(DotName name) {
/* 469 */     return (declaredAnnotation(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationInstance declaredAnnotation(DotName name) {
/* 485 */     for (AnnotationInstance instance : this.methodInternal.annotationArray()) {
/* 486 */       if (instance.target().kind() == AnnotationTarget.Kind.METHOD && instance.name().equals(name)) {
/* 487 */         return instance;
/*     */       }
/*     */     } 
/* 490 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> declaredAnnotationsWithRepeatable(DotName name, IndexView index) {
/* 513 */     if (index == null) {
/* 514 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 516 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 517 */     AnnotationInstance declaredInstance = declaredAnnotation(name);
/* 518 */     if (declaredInstance != null) {
/* 519 */       instances.add(declaredInstance);
/*     */     }
/* 521 */     ClassInfo annotationClass = index.getClassByName(name);
/* 522 */     if (annotationClass == null) {
/* 523 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 525 */     if (!annotationClass.isAnnotation()) {
/* 526 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 528 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 529 */     if (repeatable != null) {
/* 530 */       Type containingType = repeatable.value().asClass();
/* 531 */       AnnotationInstance container = declaredAnnotation(containingType.name());
/* 532 */       if (container != null) {
/* 533 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 534 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       }
/*     */     } 
/* 538 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> declaredAnnotations() {
/* 553 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 554 */     for (AnnotationInstance instance : this.methodInternal.annotationArray()) {
/* 555 */       if (instance.target().kind() == AnnotationTarget.Kind.METHOD) {
/* 556 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 559 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationValue defaultValue() {
/* 570 */     return this.methodInternal.defaultValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final short flags() {
/* 579 */     return this.methodInternal.flags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 587 */     return Modifiers.isSynthetic(this.methodInternal.flags());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBridge() {
/* 595 */     return Modifiers.isBridge(this.methodInternal.flags());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConstructor() {
/* 602 */     return Arrays.equals(Utils.INIT_METHOD_NAME, this.methodInternal.nameBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStaticInitializer() {
/* 609 */     return Arrays.equals(Utils.CLINIT_METHOD_NAME, this.methodInternal.nameBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/* 618 */     if (!this.clazz.isInterface()) {
/* 619 */       return false;
/*     */     }
/* 621 */     short flags = this.methodInternal.flags();
/* 622 */     return (Modifier.isPublic(flags) && !Modifier.isStatic(flags) && !Modifier.isAbstract(flags));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresGenericSignature() {
/* 633 */     return GenericSignatureReconstruction.requiresGenericSignature(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String genericSignature(Function<String, Type> typeVariableSubstitution) {
/* 654 */     return GenericSignatureReconstruction.reconstructGenericSignature(this, typeVariableSubstitution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String descriptor(Function<String, Type> typeVariableSubstitution) {
/* 671 */     return DescriptorReconstruction.methodDescriptor(this, typeVariableSubstitution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 681 */     return this.methodInternal.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 686 */     if (this == o)
/* 687 */       return true; 
/* 688 */     if (o == null || getClass() != o.getClass()) {
/* 689 */       return false;
/*     */     }
/* 691 */     MethodInfo that = (MethodInfo)o;
/* 692 */     return (this.clazz.equals(that.clazz) && this.methodInternal.equals(that.methodInternal));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 697 */     return 31 * this.clazz.hashCode() + this.methodInternal.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public final ClassInfo asClass() {
/* 702 */     throw new IllegalArgumentException("Not a class");
/*     */   }
/*     */ 
/*     */   
/*     */   public final FieldInfo asField() {
/* 707 */     throw new IllegalArgumentException("Not a field");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodInfo asMethod() {
/* 712 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodParameterInfo asMethodParameter() {
/* 717 */     throw new IllegalArgumentException("Not a method parameter");
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypeTarget asType() {
/* 722 */     throw new IllegalArgumentException("Not a type");
/*     */   }
/*     */ 
/*     */   
/*     */   public final RecordComponentInfo asRecordComponent() {
/* 727 */     throw new IllegalArgumentException("Not a record component");
/*     */   }
/*     */   
/*     */   final MethodInternal methodInternal() {
/* 731 */     return this.methodInternal;
/*     */   }
/*     */   
/*     */   final void setMethodInternal(MethodInternal methodInternal) {
/* 735 */     this.methodInternal = methodInternal;
/*     */   }
/*     */   
/*     */   final void setClassInfo(ClassInfo clazz) {
/* 739 */     this.clazz = clazz;
/*     */   }
/*     */   
/*     */   final Type[] typeParameterArray() {
/* 743 */     return this.methodInternal.typeParameterArray();
/*     */   }
/*     */   
/*     */   void setTypeParameters(Type[] typeParameters) {
/* 747 */     this.methodInternal.setTypeParameters(typeParameters);
/*     */   }
/*     */   
/*     */   void setParameters(Type[] parameters) {
/* 751 */     this.methodInternal.setParameterTypes(parameters);
/*     */   }
/*     */   
/*     */   void setReturnType(Type returnType) {
/* 755 */     this.methodInternal.setReturnType(returnType);
/*     */   }
/*     */   
/*     */   void setExceptions(Type[] exceptions) {
/* 759 */     this.methodInternal.setExceptions(exceptions);
/*     */   }
/*     */   
/*     */   void setReceiverType(Type receiverType) {
/* 763 */     this.methodInternal.setReceiverType(receiverType);
/*     */   }
/*     */   
/*     */   void setAnnotations(List<AnnotationInstance> annotations) {
/* 767 */     this.methodInternal.setAnnotations(annotations);
/*     */   }
/*     */   
/*     */   void setDefaultValue(AnnotationValue defaultValue) {
/* 771 */     this.methodInternal.setDefaultValue(defaultValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MethodInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */