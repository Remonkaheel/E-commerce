/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThrowsTypeTarget
/*    */   extends PositionBasedTypeTarget
/*    */ {
/*    */   ThrowsTypeTarget(MethodInfo enclosingTarget, int position) {
/* 42 */     super(enclosingTarget, position);
/*    */   }
/*    */   
/*    */   ThrowsTypeTarget(AnnotationTarget enclosingTarget, Type target, int position) {
/* 46 */     super(enclosingTarget, target, position);
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeTarget.Usage usage() {
/* 51 */     return TypeTarget.Usage.THROWS;
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodInfo enclosingTarget() {
/* 56 */     return (MethodInfo)super.enclosingTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public ThrowsTypeTarget asThrows() {
/* 61 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ThrowsTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */