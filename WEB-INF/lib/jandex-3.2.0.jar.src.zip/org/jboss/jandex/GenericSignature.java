/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface GenericSignature
/*     */ {
/*     */   public static final Function<String, Type> NO_SUBSTITUTION = ignored -> null;
/*     */   
/*     */   default String genericSignature() {
/*  31 */     return genericSignature(NO_SUBSTITUTION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String genericSignatureIfRequired() {
/*  59 */     return genericSignatureIfRequired(NO_SUBSTITUTION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String genericSignatureIfRequired(Function<String, Type> typeVariableSubstitution) {
/*  71 */     return requiresGenericSignature() ? genericSignature(typeVariableSubstitution) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void forTypeParameters(List<TypeVariable> typeParameters, Function<String, Type> typeVariableSubstitution, StringBuilder result) {
/*  92 */     GenericSignatureReconstruction.typeParametersSignature(typeParameters, typeVariableSubstitution, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void forType(Type type, Function<String, Type> typeVariableSubstitution, StringBuilder result) {
/* 108 */     GenericSignatureReconstruction.typeSignature(type, typeVariableSubstitution, result);
/*     */   }
/*     */   
/*     */   boolean requiresGenericSignature();
/*     */   
/*     */   String genericSignature(Function<String, Type> paramFunction);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\GenericSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */