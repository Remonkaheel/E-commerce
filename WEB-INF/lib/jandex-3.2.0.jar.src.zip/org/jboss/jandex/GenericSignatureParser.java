/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GenericSignatureParser
/*     */ {
/* 120 */   private static final WildcardType UNBOUNDED_WILDCARD = new WildcardType(null, true);
/*     */   private String signature;
/*     */   private int pos;
/*     */   private NameTable names;
/*     */   private Map<String, TypeVariable> typeParameters;
/* 125 */   private Map<String, TypeVariable> elementTypeParameters = new HashMap<>();
/* 126 */   private Map<String, TypeVariable> classTypeParameters = new HashMap<>();
/*     */ 
/*     */   
/*     */   private DotName currentClassName;
/*     */ 
/*     */   
/* 132 */   private Deque<TypeVariable> typeVariableStack = new ArrayDeque<>();
/*     */   
/*     */   GenericSignatureParser(NameTable names) {
/* 135 */     names.intern(DotName.OBJECT_NAME, '/');
/* 136 */     this.names = names;
/*     */   }
/*     */   
/*     */   static class ClassSignature {
/*     */     private final Type[] parameters;
/*     */     private final Type superClass;
/*     */     private final Type[] interfaces;
/*     */     
/*     */     private ClassSignature(Type[] parameters, Type superClass, Type[] interfaces) {
/* 145 */       this.parameters = parameters;
/* 146 */       this.superClass = superClass;
/* 147 */       this.interfaces = interfaces;
/*     */     }
/*     */     
/*     */     Type[] parameters() {
/* 151 */       return this.parameters;
/*     */     }
/*     */     
/*     */     Type superClass() {
/* 155 */       return this.superClass;
/*     */     }
/*     */     
/*     */     Type[] interfaces() {
/* 159 */       return this.interfaces;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 163 */       StringBuilder builder = new StringBuilder();
/* 164 */       if (this.parameters.length > 0) {
/* 165 */         builder.append('<');
/* 166 */         builder.append(this.parameters[0]);
/* 167 */         for (int i = 1; i < this.parameters.length; i++) {
/* 168 */           builder.append(", ").append(this.parameters[i]);
/*     */         }
/* 170 */         builder.append('>');
/*     */       } 
/*     */       
/* 173 */       if (this.superClass.name() != DotName.OBJECT_NAME) {
/* 174 */         builder.append(" extends ").append(this.superClass);
/*     */       }
/*     */       
/* 177 */       if (this.interfaces.length > 0) {
/* 178 */         builder.append(" implements ").append(this.interfaces[0]);
/*     */         
/* 180 */         for (int i = 1; i < this.interfaces.length; i++) {
/* 181 */           builder.append(", ").append(this.interfaces[i]);
/*     */         }
/*     */       } 
/*     */       
/* 185 */       return builder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static class MethodSignature {
/*     */     private final Type[] typeParameters;
/*     */     private final Type[] methodParameters;
/*     */     private final Type returnType;
/*     */     private final Type[] throwables;
/*     */     
/*     */     private MethodSignature(Type[] typeParameters, Type[] methodParameters, Type returnType, Type[] throwables) {
/* 196 */       this.typeParameters = typeParameters;
/* 197 */       this.methodParameters = methodParameters;
/* 198 */       this.returnType = returnType;
/* 199 */       this.throwables = throwables;
/*     */     }
/*     */     
/*     */     public Type[] typeParameters() {
/* 203 */       return this.typeParameters;
/*     */     }
/*     */     
/*     */     public Type returnType() {
/* 207 */       return this.returnType;
/*     */     }
/*     */     
/*     */     public Type[] methodParameters() {
/* 211 */       return this.methodParameters;
/*     */     }
/*     */     
/*     */     public Type[] throwables() {
/* 215 */       return this.throwables;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 219 */       StringBuilder builder = new StringBuilder();
/* 220 */       if (this.typeParameters.length > 0) {
/* 221 */         builder.append("<");
/* 222 */         builder.append(this.typeParameters[0]);
/* 223 */         for (int i = 1; i < this.typeParameters.length; i++) {
/* 224 */           builder.append(", ").append(this.typeParameters[i]);
/*     */         }
/* 226 */         builder.append("> ");
/*     */       } 
/*     */       
/* 229 */       builder.append(this.returnType).append(" (");
/* 230 */       if (this.methodParameters.length > 0) {
/* 231 */         builder.append(this.methodParameters[0]);
/*     */         
/* 233 */         for (int i = 1; i < this.methodParameters.length; i++) {
/* 234 */           builder.append(", ").append(this.methodParameters[i]);
/*     */         }
/*     */       } 
/* 237 */       builder.append(')');
/*     */       
/* 239 */       if (this.throwables.length > 0) {
/* 240 */         builder.append(" throws ").append(this.throwables[0]);
/*     */         
/* 242 */         for (int i = 1; i < this.throwables.length; i++) {
/* 243 */           builder.append(", ").append(this.throwables[i]);
/*     */         }
/*     */       } 
/*     */       
/* 247 */       return builder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void beforeNewClass(DotName className) {
/* 253 */     this.currentClassName = className;
/* 254 */     this.classTypeParameters.clear();
/* 255 */     this.elementTypeParameters.clear();
/*     */   }
/*     */   
/*     */   void beforeNewElement() {
/* 259 */     this.elementTypeParameters.clear();
/*     */   }
/*     */   
/*     */   ClassSignature parseClassSignature(String signature, DotName className) {
/* 263 */     beforeNewClass(className);
/* 264 */     this.signature = signature;
/* 265 */     this.typeParameters = this.classTypeParameters;
/* 266 */     this.pos = 0;
/* 267 */     Type[] parameters = parseTypeParameters();
/* 268 */     Type superClass = this.names.intern(parseClassTypeSignature());
/* 269 */     int end = signature.length();
/* 270 */     List<Type> interfaces = new ArrayList<>();
/* 271 */     while (this.pos < end) {
/* 272 */       interfaces.add(this.names.intern(parseClassTypeSignature()));
/*     */     }
/*     */     
/* 275 */     Type[] intfArray = this.names.intern(interfaces.<Type>toArray(new Type[interfaces.size()]));
/* 276 */     return new ClassSignature(parameters, superClass, intfArray);
/*     */   }
/*     */   
/*     */   private void expect(char c) {
/* 280 */     if (this.signature.charAt(this.pos++) != c) {
/* 281 */       throw new IllegalArgumentException("Expected character '" + c + "' at position " + (this.pos - 1));
/*     */     }
/*     */   }
/*     */   
/*     */   Type parseFieldSignature(String signature) {
/* 286 */     beforeNewElement();
/* 287 */     this.signature = signature;
/* 288 */     this.typeParameters = this.elementTypeParameters;
/* 289 */     this.pos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     return parseJavaType();
/*     */   }
/*     */   
/*     */   MethodSignature parseMethodSignature(String signature) {
/* 302 */     beforeNewElement();
/* 303 */     this.signature = signature;
/* 304 */     this.typeParameters = this.elementTypeParameters;
/* 305 */     this.pos = 0;
/*     */     
/* 307 */     Type[] typeParameters = parseTypeParameters();
/*     */     
/* 309 */     expect('(');
/* 310 */     List<Type> parameters = new ArrayList<>();
/* 311 */     while (signature.charAt(this.pos) != ')') {
/* 312 */       Type type = parseJavaType();
/* 313 */       if (type == null) {
/* 314 */         throw new IllegalArgumentException("Corrupted argument, or unclosed brace at: " + this.pos);
/*     */       }
/* 316 */       parameters.add(type);
/*     */     } 
/* 318 */     this.pos++;
/*     */     
/* 320 */     Type returnType = parseReturnType();
/* 321 */     List<Type> exceptions = new ArrayList<>();
/* 322 */     while (this.pos < signature.length()) {
/* 323 */       expect('^');
/* 324 */       exceptions.add(parseReferenceType());
/*     */     } 
/*     */     
/* 327 */     Type[] exceptionsArray = this.names.intern(exceptions.<Type>toArray(new Type[exceptions.size()]));
/* 328 */     Type[] types = this.names.intern(parameters.<Type>toArray(new Type[parameters.size()]));
/* 329 */     return new MethodSignature(typeParameters, types, returnType, exceptionsArray);
/*     */   }
/*     */ 
/*     */   
/*     */   private Type parseClassTypeSignature() {
/* 334 */     String signature = this.signature;
/* 335 */     DotName name = parseName();
/* 336 */     Type[] types = parseTypeArguments();
/* 337 */     Type type = null;
/*     */     
/* 339 */     if (types.length > 0) {
/* 340 */       type = new ParameterizedType(name, types, null);
/*     */     }
/*     */ 
/*     */     
/* 344 */     while (signature.charAt(this.pos) == '.') {
/* 345 */       int mark = ++this.pos;
/* 346 */       int suffixEnd = advanceNameEnd();
/* 347 */       name = this.names.wrap(name, signature.substring(mark, suffixEnd), true);
/* 348 */       types = parseTypeArguments();
/*     */ 
/*     */ 
/*     */       
/* 352 */       if (type == null && types.length > 0) {
/* 353 */         type = this.names.intern(new ClassType(name.prefix()));
/*     */       }
/*     */       
/* 356 */       if (type != null) {
/* 357 */         type = this.names.intern(new ParameterizedType(name, types, type));
/*     */       }
/*     */     } 
/* 360 */     this.pos++;
/* 361 */     return (type != null) ? type : this.names.intern(new ClassType(name));
/*     */   }
/*     */   
/*     */   private Type[] parseTypeArguments() {
/* 365 */     return parseTypeList(true);
/*     */   }
/*     */   
/*     */   private Type[] parseTypeParameters() {
/* 369 */     return parseTypeList(false);
/*     */   }
/*     */   
/*     */   private Type[] parseTypeList(boolean argument) {
/* 373 */     String signature = this.signature;
/* 374 */     if (signature.charAt(this.pos) != '<') {
/* 375 */       return Type.EMPTY_ARRAY;
/*     */     }
/* 377 */     this.pos++;
/*     */     
/* 379 */     ArrayList<Type> types = new ArrayList<>();
/*     */     while (true) {
/* 381 */       Type t = argument ? parseTypeArgument() : parseTypeParameter();
/* 382 */       if (t == null) {
/*     */         break;
/*     */       }
/* 385 */       types.add(t);
/*     */     } 
/* 387 */     if (!argument) {
/* 388 */       resolveTypeList(types);
/*     */     }
/* 390 */     return this.names.intern(types.<Type>toArray(new Type[types.size()]));
/*     */   }
/*     */   
/*     */   private Type parseTypeArgument() {
/* 394 */     char c = this.signature.charAt(this.pos++);
/* 395 */     switch (c) {
/*     */       case '>':
/* 397 */         return null;
/*     */       case '*':
/* 399 */         return UNBOUNDED_WILDCARD;
/*     */       case '-':
/* 401 */         return parseWildCard(false);
/*     */       
/*     */       case '+':
/* 404 */         return parseWildCard(true);
/*     */     } 
/*     */     
/* 407 */     this.pos--;
/* 408 */     return parseReferenceType();
/*     */   }
/*     */ 
/*     */   
/*     */   private Type parseWildCard(boolean isExtends) {
/* 413 */     Type bound = parseReferenceType();
/* 414 */     return new WildcardType(bound, isExtends);
/*     */   }
/*     */   
/*     */   private Type parseTypeParameter() {
/* 418 */     int start = this.pos;
/* 419 */     String signature = this.signature;
/*     */     
/* 421 */     if (signature.charAt(start) == '>') {
/* 422 */       this.pos++;
/* 423 */       return null;
/*     */     } 
/*     */     
/* 426 */     int bound = advancePast(':');
/* 427 */     String name = this.names.intern(signature.substring(start, bound));
/*     */ 
/*     */ 
/*     */     
/* 431 */     this.typeParameters.put(name, null);
/*     */     
/* 433 */     ArrayList<Type> bounds = new ArrayList<>();
/*     */ 
/*     */     
/* 436 */     if (signature.charAt(this.pos) != ':') {
/* 437 */       bounds.add(parseReferenceType());
/*     */     }
/*     */     
/* 440 */     boolean implicitObjectBound = false;
/*     */     
/* 442 */     while (signature.charAt(this.pos) == ':') {
/* 443 */       this.pos++;
/*     */       
/* 445 */       if (bounds.size() == 0) {
/* 446 */         implicitObjectBound = true;
/*     */       }
/* 448 */       bounds.add(parseReferenceType());
/*     */     } 
/*     */     
/* 451 */     TypeVariable type = new TypeVariable(name, bounds.<Type>toArray(new Type[bounds.size()]), null, implicitObjectBound);
/* 452 */     this.typeParameters.put(name, type);
/* 453 */     return type;
/*     */   }
/*     */   
/*     */   private Type parseReturnType() {
/* 457 */     if (this.signature.charAt(this.pos) == 'V') {
/* 458 */       this.pos++;
/* 459 */       return VoidType.VOID;
/*     */     } 
/*     */     
/* 462 */     return parseJavaType();
/*     */   }
/*     */   private Type parseReferenceType() {
/*     */     Type type;
/* 466 */     int mark = this.pos;
/* 467 */     char c = this.signature.charAt(mark);
/*     */     
/* 469 */     switch (c) {
/*     */       case 'T':
/* 471 */         type = parseTypeVariable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 483 */         return this.names.intern(type);case 'L': type = parseClassTypeSignature(); return this.names.intern(type);case '[': type = parseArrayType(); return this.names.intern(type);
/*     */     } 
/*     */     return null;
/*     */   } private Type parseArrayType() {
/* 487 */     int mark = this.pos;
/* 488 */     int last = advanceNot('[');
/* 489 */     return new ArrayType(parseJavaType(), last - mark);
/*     */   }
/*     */   
/*     */   private Type parseTypeVariable() {
/* 493 */     String name = this.names.intern(this.signature.substring(this.pos + 1, advancePast(';')));
/* 494 */     Type type = resolveType(name);
/* 495 */     return (type == null) ? new UnresolvedTypeVariable(name) : type;
/*     */   }
/*     */   
/*     */   private void resolveTypeList(ArrayList<Type> list) {
/* 499 */     int size = list.size(); int i;
/* 500 */     for (i = 0; i < size; i++) {
/* 501 */       this.typeVariableStack.clear();
/* 502 */       boolean isRecursive = isRecursive(list.get(i));
/* 503 */       Type type = resolveType(list.get(i), isRecursive);
/* 504 */       if (type != null) {
/* 505 */         list.set(i, type);
/* 506 */         this.typeParameters.put(type.asTypeVariable().identifier(), type.asTypeVariable());
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 512 */     for (i = 0; i < list.size(); i++) {
/* 513 */       this.typeVariableStack.clear();
/* 514 */       patchTypeVariableReferences(list.get(i));
/*     */     } 
/*     */   }
/*     */   
/*     */   private TypeVariable findOnTypeVariableStack(String typeVariableIdentifier) {
/* 519 */     for (TypeVariable typeVariable : this.typeVariableStack) {
/* 520 */       if (typeVariable.identifier().equals(typeVariableIdentifier)) {
/* 521 */         return typeVariable;
/*     */       }
/*     */     } 
/* 524 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isRecursive(Type type) {
/* 528 */     if (type.kind() == Type.Kind.TYPE_VARIABLE_REFERENCE)
/* 529 */       return (findOnTypeVariableStack(type.asTypeVariableReference().identifier()) != null); 
/* 530 */     if (type.kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE) {
/* 531 */       String unresolvedIdentifier = type.asUnresolvedTypeVariable().identifier();
/* 532 */       if (findOnTypeVariableStack(unresolvedIdentifier) != null) {
/* 533 */         return true;
/*     */       }
/* 535 */       if (this.typeParameters.containsKey(unresolvedIdentifier)) {
/* 536 */         return isRecursive(this.typeParameters.get(unresolvedIdentifier));
/*     */       }
/* 538 */     } else if (type.kind() == Type.Kind.TYPE_VARIABLE) {
/* 539 */       if (findOnTypeVariableStack(type.asTypeVariable().identifier()) != null) {
/* 540 */         return true;
/*     */       }
/* 542 */       this.typeVariableStack.push(type.asTypeVariable());
/* 543 */       Type[] bounds = type.asTypeVariable().boundArray();
/* 544 */       for (int i = 0; i < bounds.length; i++) {
/* 545 */         if (isRecursive(bounds[i])) {
/* 546 */           return true;
/*     */         }
/*     */       } 
/* 549 */       this.typeVariableStack.pop();
/* 550 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 551 */       if (type.asParameterizedType().owner() != null && isRecursive(type.asParameterizedType().owner())) {
/* 552 */         return true;
/*     */       }
/* 554 */       Type[] typeArguments = type.asParameterizedType().argumentsArray();
/* 555 */       for (int i = 0; i < typeArguments.length; i++) {
/* 556 */         if (isRecursive(typeArguments[i]))
/* 557 */           return true; 
/*     */       } 
/*     */     } else {
/* 560 */       if (type.kind() == Type.Kind.WILDCARD_TYPE)
/* 561 */         return isRecursive(type.asWildcardType().bound()); 
/* 562 */       if (type.kind() == Type.Kind.ARRAY)
/* 563 */         return isRecursive(type.asArrayType().component()); 
/*     */     } 
/* 565 */     return false;
/*     */   }
/*     */   
/*     */   private Type resolveType(Type type, boolean isRecursive) {
/* 569 */     if (type.kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE) {
/* 570 */       String identifier = type.asUnresolvedTypeVariable().identifier();
/* 571 */       if (isRecursive && this.typeParameters.containsKey(identifier))
/* 572 */         return new TypeVariableReference(identifier, this.currentClassName); 
/* 573 */       if (this.elementTypeParameters.containsKey(identifier))
/* 574 */         return this.elementTypeParameters.get(identifier); 
/* 575 */       if (this.classTypeParameters.containsKey(identifier)) {
/* 576 */         return this.classTypeParameters.get(identifier);
/*     */       
/*     */       }
/*     */     }
/* 580 */     else if (type.kind() == Type.Kind.TYPE_VARIABLE) {
/* 581 */       TypeVariable variable = type.asTypeVariable();
/* 582 */       Type[] bounds = variable.boundArray();
/* 583 */       for (int i = 0; i < bounds.length; i++) {
/* 584 */         Type newBound = resolveType(bounds[i], isRecursive);
/* 585 */         if (newBound != null && newBound != bounds[i]) {
/* 586 */           variable = variable.copyType(i, newBound);
/*     */         }
/*     */       } 
/* 589 */       if (variable != type) {
/* 590 */         return variable;
/*     */       }
/* 592 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 593 */       ParameterizedType parameterized = type.asParameterizedType();
/* 594 */       if (parameterized.owner() != null) {
/* 595 */         Type newOwner = resolveType(parameterized.owner(), isRecursive);
/* 596 */         if (newOwner != null && newOwner != parameterized.owner()) {
/* 597 */           parameterized = parameterized.copyType(newOwner);
/*     */         }
/*     */       } 
/* 600 */       Type[] typeArguments = parameterized.argumentsArray();
/* 601 */       for (int i = 0; i < typeArguments.length; i++) {
/* 602 */         Type newTypeArgument = resolveType(typeArguments[i], isRecursive);
/* 603 */         if (newTypeArgument != null && newTypeArgument != typeArguments[i]) {
/* 604 */           parameterized = parameterized.copyType(i, newTypeArgument);
/*     */         }
/*     */       } 
/* 607 */       if (parameterized != type) {
/* 608 */         return parameterized;
/*     */       }
/* 610 */     } else if (type.kind() == Type.Kind.WILDCARD_TYPE) {
/* 611 */       WildcardType wildcard = type.asWildcardType();
/* 612 */       Type newBound = resolveType(wildcard.bound(), isRecursive);
/* 613 */       if (newBound != null && newBound != wildcard.bound()) {
/* 614 */         return wildcard.copyType(newBound);
/*     */       }
/* 616 */     } else if (type.kind() == Type.Kind.ARRAY) {
/* 617 */       ArrayType array = type.asArrayType();
/* 618 */       Type newComponent = resolveType(array.component(), isRecursive);
/* 619 */       if (newComponent != null && newComponent != array.component()) {
/* 620 */         return array.copyType(newComponent, array.dimensions());
/*     */       }
/*     */     } 
/*     */     
/* 624 */     return null;
/*     */   }
/*     */   
/*     */   private void patchTypeVariableReferences(Type type) {
/* 628 */     if (type.kind() == Type.Kind.TYPE_VARIABLE_REFERENCE) {
/* 629 */       String identifier = type.asTypeVariableReference().identifier();
/*     */       
/* 631 */       TypeVariable typeVariable = findOnTypeVariableStack(identifier);
/* 632 */       if (typeVariable != null) {
/* 633 */         type.asTypeVariableReference().setTarget(typeVariable);
/*     */         
/*     */         return;
/*     */       } 
/* 637 */       TypeVariable typeParameter = this.typeParameters.get(identifier);
/* 638 */       if (typeParameter != null) {
/* 639 */         type.asTypeVariableReference().setTarget(typeParameter);
/*     */       }
/* 641 */     } else if (type.kind() == Type.Kind.TYPE_VARIABLE) {
/* 642 */       this.typeVariableStack.push(type.asTypeVariable());
/* 643 */       Type[] bounds = type.asTypeVariable().boundArray();
/* 644 */       for (int i = 0; i < bounds.length; i++) {
/* 645 */         patchTypeVariableReferences(bounds[i]);
/*     */       }
/* 647 */       this.typeVariableStack.pop();
/* 648 */     } else if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 649 */       if (type.asParameterizedType().owner() != null) {
/* 650 */         patchTypeVariableReferences(type.asParameterizedType().owner());
/*     */       }
/* 652 */       Type[] typeArguments = type.asParameterizedType().argumentsArray();
/* 653 */       for (int i = 0; i < typeArguments.length; i++) {
/* 654 */         patchTypeVariableReferences(typeArguments[i]);
/*     */       }
/* 656 */     } else if (type.kind() == Type.Kind.WILDCARD_TYPE) {
/* 657 */       patchTypeVariableReferences(type.asWildcardType().bound());
/* 658 */     } else if (type.kind() == Type.Kind.ARRAY) {
/* 659 */       patchTypeVariableReferences(type.asArrayType().component());
/*     */     } 
/*     */   }
/*     */   
/*     */   private TypeVariable resolveType(String identifier) {
/* 664 */     if (this.elementTypeParameters.containsKey(identifier))
/*     */     {
/*     */       
/* 667 */       return this.elementTypeParameters.get(identifier);
/*     */     }
/* 669 */     return this.classTypeParameters.get(identifier);
/*     */   }
/*     */   
/*     */   private Type parseJavaType() {
/* 673 */     Type type = PrimitiveType.decode(this.signature.charAt(this.pos));
/* 674 */     if (type != null) {
/* 675 */       this.pos++;
/* 676 */       return type;
/*     */     } 
/* 678 */     return parseReferenceType();
/*     */   }
/*     */   
/*     */   private int advancePast(char c) {
/* 682 */     int pos = this.signature.indexOf(c, this.pos);
/* 683 */     if (pos == -1) {
/* 684 */       throw new IllegalStateException("Corruption");
/*     */     }
/*     */     
/* 687 */     this.pos = pos + 1;
/* 688 */     return pos;
/*     */   }
/*     */   
/*     */   private int advanceNot(char c) {
/* 692 */     while (this.signature.charAt(this.pos) == c) {
/* 693 */       this.pos++;
/*     */     }
/*     */     
/* 696 */     return this.pos;
/*     */   }
/*     */   
/*     */   private DotName parseName() {
/* 700 */     int start = this.pos;
/* 701 */     int end = advanceNameEnd();
/*     */     
/* 703 */     if (this.signature.charAt(start++) != 'L') {
/* 704 */       throw new IllegalArgumentException("Invalid signature, invalid class designator");
/*     */     }
/*     */     
/* 707 */     return this.names.convertToName(this.signature.substring(start, end), '/');
/*     */   }
/*     */   
/*     */   private int advanceNameEnd() {
/* 711 */     int end = this.pos;
/* 712 */     String signature = this.signature;
/*     */     
/* 714 */     for (; end < signature.length(); end++) {
/* 715 */       char c = signature.charAt(end);
/* 716 */       if (c == '.' || c == '<' || c == ';') {
/* 717 */         return this.pos = end;
/*     */       }
/*     */     } 
/*     */     
/* 721 */     throw new IllegalStateException("Corrupted name");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/* 726 */     GenericSignatureParser parser = new GenericSignatureParser(new NameTable());
/* 727 */     MethodSignature sig1 = parser.parseMethodSignature("<U:Ljava/lang/Foo;>(Ljava/lang/Class<TU;>;TU;)Ljava/lang/Class<+TU;>;");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\GenericSignatureParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */