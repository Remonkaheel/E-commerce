/*      */ package org.jboss.jandex;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.function.Consumer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class AnnotationInstanceBuilder
/*      */ {
/*      */   private static final String VALUE = "value";
/*      */   private final DotName annotationType;
/*      */   private final boolean runtimeVisible;
/*   25 */   private final List<AnnotationValue> values = new ArrayList<>();
/*   26 */   private final Set<String> alreadyAdded = new HashSet<>();
/*      */   
/*      */   AnnotationInstanceBuilder(DotName annotationType, boolean runtimeVisible) {
/*   29 */     this.annotationType = annotationType;
/*   30 */     this.runtimeVisible = runtimeVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(AnnotationValue value) {
/*   40 */     if (!this.alreadyAdded.add(value.name())) {
/*   41 */       throw new IllegalArgumentException("Annotation member '" + value.name() + "' already added");
/*      */     }
/*      */     
/*   44 */     this.values.add(value);
/*   45 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder addAll(List<AnnotationValue> values) {
/*   55 */     for (AnnotationValue value : values) {
/*   56 */       add(value);
/*      */     }
/*   58 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, boolean value) {
/*   71 */     if (name == null) {
/*   72 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*   74 */     if (!this.alreadyAdded.add(name)) {
/*   75 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*   78 */     this.values.add(AnnotationValue.createBooleanValue(name, value));
/*   79 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, boolean[] values) {
/*   90 */     if (name == null) {
/*   91 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*   93 */     if (!this.alreadyAdded.add(name)) {
/*   94 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*   97 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*   98 */     for (int i = 0; i < values.length; i++) {
/*   99 */       array[i] = AnnotationValue.createBooleanValue(name, values[i]);
/*      */     }
/*  101 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  102 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, byte value) {
/*  113 */     if (name == null) {
/*  114 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  116 */     if (!this.alreadyAdded.add(name)) {
/*  117 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  120 */     this.values.add(AnnotationValue.createByteValue(name, value));
/*  121 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, byte[] values) {
/*  132 */     if (name == null) {
/*  133 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  135 */     if (!this.alreadyAdded.add(name)) {
/*  136 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  139 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  140 */     for (int i = 0; i < values.length; i++) {
/*  141 */       array[i] = AnnotationValue.createByteValue(name, values[i]);
/*      */     }
/*  143 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  144 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, short value) {
/*  155 */     if (name == null) {
/*  156 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  158 */     if (!this.alreadyAdded.add(name)) {
/*  159 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  162 */     this.values.add(AnnotationValue.createShortValue(name, value));
/*  163 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, short[] values) {
/*  174 */     if (name == null) {
/*  175 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  177 */     if (!this.alreadyAdded.add(name)) {
/*  178 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  181 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  182 */     for (int i = 0; i < values.length; i++) {
/*  183 */       array[i] = AnnotationValue.createShortValue(name, values[i]);
/*      */     }
/*  185 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  186 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, int value) {
/*  197 */     if (name == null) {
/*  198 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  200 */     if (!this.alreadyAdded.add(name)) {
/*  201 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  204 */     this.values.add(AnnotationValue.createIntegerValue(name, value));
/*  205 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, int[] values) {
/*  216 */     if (name == null) {
/*  217 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  219 */     if (!this.alreadyAdded.add(name)) {
/*  220 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  223 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  224 */     for (int i = 0; i < values.length; i++) {
/*  225 */       array[i] = AnnotationValue.createIntegerValue(name, values[i]);
/*      */     }
/*  227 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  228 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, long value) {
/*  239 */     if (name == null) {
/*  240 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  242 */     if (!this.alreadyAdded.add(name)) {
/*  243 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  246 */     this.values.add(AnnotationValue.createLongValue(name, value));
/*  247 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, long[] values) {
/*  258 */     if (name == null) {
/*  259 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  261 */     if (!this.alreadyAdded.add(name)) {
/*  262 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  265 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  266 */     for (int i = 0; i < values.length; i++) {
/*  267 */       array[i] = AnnotationValue.createLongValue(name, values[i]);
/*      */     }
/*  269 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  270 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, float value) {
/*  281 */     if (name == null) {
/*  282 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  284 */     if (!this.alreadyAdded.add(name)) {
/*  285 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  288 */     this.values.add(AnnotationValue.createFloatValue(name, value));
/*  289 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, float[] values) {
/*  300 */     if (name == null) {
/*  301 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  303 */     if (!this.alreadyAdded.add(name)) {
/*  304 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  307 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  308 */     for (int i = 0; i < values.length; i++) {
/*  309 */       array[i] = AnnotationValue.createFloatValue(name, values[i]);
/*      */     }
/*  311 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  312 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, double value) {
/*  323 */     if (name == null) {
/*  324 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  326 */     if (!this.alreadyAdded.add(name)) {
/*  327 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  330 */     this.values.add(AnnotationValue.createDoubleValue(name, value));
/*  331 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, double[] values) {
/*  342 */     if (name == null) {
/*  343 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  345 */     if (!this.alreadyAdded.add(name)) {
/*  346 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  349 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  350 */     for (int i = 0; i < values.length; i++) {
/*  351 */       array[i] = AnnotationValue.createDoubleValue(name, values[i]);
/*      */     }
/*  353 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  354 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, char value) {
/*  365 */     if (name == null) {
/*  366 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  368 */     if (!this.alreadyAdded.add(name)) {
/*  369 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  372 */     this.values.add(AnnotationValue.createCharacterValue(name, value));
/*  373 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, char[] values) {
/*  384 */     if (name == null) {
/*  385 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  387 */     if (!this.alreadyAdded.add(name)) {
/*  388 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  391 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  392 */     for (int i = 0; i < values.length; i++) {
/*  393 */       array[i] = AnnotationValue.createCharacterValue(name, values[i]);
/*      */     }
/*  395 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  396 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, String value) {
/*  407 */     if (name == null) {
/*  408 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  410 */     if (!this.alreadyAdded.add(name)) {
/*  411 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  414 */     this.values.add(AnnotationValue.createStringValue(name, value));
/*  415 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, String[] values) {
/*  426 */     if (name == null) {
/*  427 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  429 */     if (!this.alreadyAdded.add(name)) {
/*  430 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  433 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  434 */     for (int i = 0; i < values.length; i++) {
/*  435 */       array[i] = AnnotationValue.createStringValue(name, values[i]);
/*      */     }
/*  437 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  438 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Enum<?> value) {
/*  449 */     if (name == null) {
/*  450 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  452 */     if (!this.alreadyAdded.add(name)) {
/*  453 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  456 */     DotName enumTypeName = DotName.createSimple(value.getDeclaringClass().getName());
/*  457 */     String enumValue = value.name();
/*  458 */     this.values.add(AnnotationValue.createEnumValue(name, enumTypeName, enumValue));
/*  459 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Enum<?>[] values) {
/*  470 */     if (name == null) {
/*  471 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  473 */     if (!this.alreadyAdded.add(name)) {
/*  474 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  477 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  478 */     for (int i = 0; i < values.length; i++) {
/*  479 */       DotName enumTypeName = DotName.createSimple(values[i].getDeclaringClass().getName());
/*  480 */       String enumValue = values[i].name();
/*  481 */       array[i] = AnnotationValue.createEnumValue(name, enumTypeName, enumValue);
/*      */     } 
/*  483 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  484 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Class<? extends Enum<?>> enumType, String enumValue) {
/*  496 */     if (name == null) {
/*  497 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  499 */     if (!this.alreadyAdded.add(name)) {
/*  500 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  503 */     DotName enumTypeName = DotName.createSimple(enumType.getName());
/*  504 */     this.values.add(AnnotationValue.createEnumValue(name, enumTypeName, enumValue));
/*  505 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Class<? extends Enum<?>> enumType, String[] enumValues) {
/*  517 */     if (name == null) {
/*  518 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  520 */     if (!this.alreadyAdded.add(name)) {
/*  521 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  524 */     AnnotationValue[] array = new AnnotationValue[enumValues.length];
/*  525 */     DotName enumTypeName = DotName.createSimple(enumType.getName());
/*  526 */     for (int i = 0; i < enumValues.length; i++) {
/*  527 */       array[i] = AnnotationValue.createEnumValue(name, enumTypeName, enumValues[i]);
/*      */     }
/*  529 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  530 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, ClassInfo enumType, String enumValue) {
/*  542 */     if (name == null) {
/*  543 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  545 */     if (!this.alreadyAdded.add(name)) {
/*  546 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  549 */     DotName enumTypeName = enumType.name();
/*  550 */     this.values.add(AnnotationValue.createEnumValue(name, enumTypeName, enumValue));
/*  551 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, ClassInfo enumType, String[] enumValues) {
/*  563 */     if (name == null) {
/*  564 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  566 */     if (!this.alreadyAdded.add(name)) {
/*  567 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  570 */     AnnotationValue[] array = new AnnotationValue[enumValues.length];
/*  571 */     DotName enumTypeName = enumType.name();
/*  572 */     for (int i = 0; i < enumValues.length; i++) {
/*  573 */       array[i] = AnnotationValue.createEnumValue(name, enumTypeName, enumValues[i]);
/*      */     }
/*  575 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  576 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Class<?> value) {
/*  587 */     if (name == null) {
/*  588 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  590 */     if (!this.alreadyAdded.add(name)) {
/*  591 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  594 */     Type clazz = Type.create(value);
/*  595 */     this.values.add(AnnotationValue.createClassValue(name, clazz));
/*  596 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Class<?>[] values) {
/*  607 */     if (name == null) {
/*  608 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  610 */     if (!this.alreadyAdded.add(name)) {
/*  611 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  614 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  615 */     for (int i = 0; i < values.length; i++) {
/*  616 */       Type clazz = Type.create(values[i]);
/*  617 */       array[i] = AnnotationValue.createClassValue(name, clazz);
/*      */     } 
/*  619 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  620 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, ClassInfo value) {
/*  631 */     if (name == null) {
/*  632 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  634 */     if (!this.alreadyAdded.add(name)) {
/*  635 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  638 */     DotName className = value.name();
/*  639 */     Type jandexClass = Type.create(className, Type.Kind.CLASS);
/*  640 */     this.values.add(AnnotationValue.createClassValue(name, jandexClass));
/*  641 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, ClassInfo[] values) {
/*  652 */     if (name == null) {
/*  653 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  655 */     if (!this.alreadyAdded.add(name)) {
/*  656 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  659 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  660 */     for (int i = 0; i < values.length; i++) {
/*  661 */       DotName className = values[i].name();
/*  662 */       Type jandexClass = Type.create(className, Type.Kind.CLASS);
/*  663 */       array[i] = AnnotationValue.createClassValue(name, jandexClass);
/*      */     } 
/*  665 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  666 */     return this;
/*      */   }
/*      */   
/*      */   private void validateType(Type type) {
/*  670 */     Type.Kind kind = type.kind();
/*  671 */     if (kind == Type.Kind.VOID || kind == Type.Kind.PRIMITIVE || kind == Type.Kind.CLASS) {
/*      */       return;
/*      */     }
/*  674 */     if (kind == Type.Kind.ARRAY) {
/*  675 */       Type.Kind element = type.asArrayType().elementType().kind();
/*  676 */       if (element == Type.Kind.PRIMITIVE || element == Type.Kind.CLASS) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/*  681 */     throw new IllegalArgumentException("Type can't be present in annotation: " + type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Type value) {
/*  701 */     if (name == null) {
/*  702 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  704 */     if (!this.alreadyAdded.add(name)) {
/*  705 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  708 */     validateType(value);
/*  709 */     this.values.add(AnnotationValue.createClassValue(name, value));
/*  710 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, Type[] values) {
/*  729 */     if (name == null) {
/*  730 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  732 */     if (!this.alreadyAdded.add(name)) {
/*  733 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  736 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  737 */     for (int i = 0; i < values.length; i++) {
/*  738 */       validateType(values[i]);
/*  739 */       array[i] = AnnotationValue.createClassValue(name, values[i]);
/*      */     } 
/*  741 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  742 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, AnnotationInstance value) {
/*  753 */     if (name == null) {
/*  754 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  756 */     if (!this.alreadyAdded.add(name)) {
/*  757 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  760 */     this.values.add(AnnotationValue.createNestedAnnotationValue(name, value));
/*  761 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder add(String name, AnnotationInstance[] values) {
/*  772 */     if (name == null) {
/*  773 */       throw new IllegalArgumentException("Annotation member name must be set");
/*      */     }
/*  775 */     if (!this.alreadyAdded.add(name)) {
/*  776 */       throw new IllegalArgumentException("Annotation member '" + name + "' already added");
/*      */     }
/*      */     
/*  779 */     AnnotationValue[] array = new AnnotationValue[values.length];
/*  780 */     for (int i = 0; i < values.length; i++) {
/*  781 */       array[i] = AnnotationValue.createNestedAnnotationValue(name, values[i]);
/*      */     }
/*  783 */     this.values.add(AnnotationValue.createArrayValue(name, array));
/*  784 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(boolean value) {
/*  796 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(boolean[] values) {
/*  806 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(byte value) {
/*  816 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(byte[] values) {
/*  826 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(short value) {
/*  836 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(short[] values) {
/*  846 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(int value) {
/*  856 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(int[] values) {
/*  866 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(long value) {
/*  876 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(long[] values) {
/*  886 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(float value) {
/*  896 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(float[] values) {
/*  906 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(double value) {
/*  916 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(double[] values) {
/*  926 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(char value) {
/*  936 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(char[] values) {
/*  946 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(String value) {
/*  956 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(String[] values) {
/*  966 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Enum<?> value) {
/*  976 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Enum<?>[] values) {
/*  986 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Class<? extends Enum<?>> enumType, String enumValue) {
/*  997 */     return add("value", enumType, enumValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Class<? extends Enum<?>> enumType, String[] enumValues) {
/* 1008 */     return add("value", enumType, enumValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(ClassInfo enumType, String enumValue) {
/* 1019 */     return add("value", enumType, enumValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(ClassInfo enumType, String[] enumValues) {
/* 1030 */     return add("value", enumType, enumValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Class<?> value) {
/* 1040 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Class<?>[] values) {
/* 1050 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(ClassInfo value) {
/* 1060 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(ClassInfo[] values) {
/* 1070 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Type value) {
/* 1088 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(Type[] values) {
/* 1106 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(AnnotationInstance value) {
/* 1116 */     return add("value", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder value(AnnotationInstance[] values) {
/* 1126 */     return add("value", values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstanceBuilder with(Consumer<AnnotationInstanceBuilder> action) {
/* 1140 */     if (action == null) {
/* 1141 */       throw new IllegalArgumentException("AnnotationInstanceBuilder#with action must be set");
/*      */     }
/*      */     
/* 1144 */     action.accept(this);
/* 1145 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstance build() {
/* 1158 */     return AnnotationInstance.create(this.annotationType, this.runtimeVisible, (AnnotationTarget)null, this.values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationInstance buildWithTarget(AnnotationTarget target) {
/* 1170 */     return AnnotationInstance.create(this.annotationType, this.runtimeVisible, target, this.values);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationInstanceBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */