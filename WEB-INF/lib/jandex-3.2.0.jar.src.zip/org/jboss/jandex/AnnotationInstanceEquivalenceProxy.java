/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnnotationInstanceEquivalenceProxy
/*    */ {
/*    */   private final AnnotationInstance annotation;
/*    */   
/*    */   AnnotationInstanceEquivalenceProxy(AnnotationInstance annotation) {
/* 23 */     this.annotation = Objects.<AnnotationInstance>requireNonNull(annotation);
/*    */   }
/*    */   
/*    */   public AnnotationInstance get() {
/* 27 */     return this.annotation;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 32 */     if (this == o)
/* 33 */       return true; 
/* 34 */     if (o == null || getClass() != o.getClass())
/* 35 */       return false; 
/* 36 */     return this.annotation.equivalentTo(((AnnotationInstanceEquivalenceProxy)o).annotation);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 41 */     return this.annotation.equivalenceHashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationInstanceEquivalenceProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */