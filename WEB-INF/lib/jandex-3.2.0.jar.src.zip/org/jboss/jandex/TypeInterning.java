/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TypeInterning
/*    */ {
/*    */   static boolean arrayEquals(Type[] a, Type[] b) {
/* 30 */     if (a == b) {
/* 31 */       return true;
/*    */     }
/* 33 */     if (a == null || b == null) {
/* 34 */       return false;
/*    */     }
/*    */     
/* 37 */     if (a.length != b.length) {
/* 38 */       return false;
/*    */     }
/*    */     
/* 41 */     for (int i = 0; i < a.length; i++) {
/* 42 */       if (!a[i].internEquals(b[i])) {
/* 43 */         return false;
/*    */       }
/*    */     } 
/*    */     
/* 47 */     return true;
/*    */   }
/*    */   
/*    */   static int arrayHashCode(Type[] array) {
/* 51 */     if (array == null) {
/* 52 */       return 0;
/*    */     }
/*    */     
/* 55 */     int result = 1;
/*    */     
/* 57 */     for (int i = 0; i < array.length; i++) {
/* 58 */       Type item = array[i];
/* 59 */       result = 31 * result + ((item == null) ? 0 : item.internHashCode());
/*    */     } 
/*    */     
/* 62 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\TypeInterning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */