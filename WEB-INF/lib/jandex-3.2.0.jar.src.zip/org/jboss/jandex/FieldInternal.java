/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FieldInternal
/*     */ {
/*  31 */   static final FieldInternal[] EMPTY_ARRAY = new FieldInternal[0];
/*     */   
/*     */   private final byte[] name;
/*     */   private Type type;
/*     */   private final short flags;
/*     */   private AnnotationInstance[] annotations;
/*  37 */   static final NameComparator NAME_COMPARATOR = new NameComparator();
/*     */   
/*     */   static class NameComparator
/*     */     implements Comparator<FieldInternal> {
/*     */     private int compare(byte[] left, byte[] right) {
/*  42 */       for (int i = 0, j = 0; i < left.length && j < right.length; i++, j++) {
/*  43 */         int a = left[i] & 0xFF;
/*  44 */         int b = right[j] & 0xFF;
/*  45 */         if (a != b) {
/*  46 */           return a - b;
/*     */         }
/*     */       } 
/*  49 */       return left.length - right.length;
/*     */     }
/*     */     
/*     */     public int compare(FieldInternal instance, FieldInternal instance2) {
/*  53 */       return compare(instance.name, instance2.name);
/*     */     }
/*     */   }
/*     */   
/*     */   FieldInternal(byte[] name, Type type, short flags) {
/*  58 */     this(name, type, flags, AnnotationInstance.EMPTY_ARRAY);
/*     */   }
/*     */   
/*     */   FieldInternal(byte[] name, Type type, short flags, AnnotationInstance[] annotations) {
/*  62 */     this.name = name;
/*  63 */     this.type = type;
/*  64 */     this.flags = flags;
/*  65 */     this.annotations = annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  70 */     if (this == o) {
/*  71 */       return true;
/*     */     }
/*  73 */     if (o == null || getClass() != o.getClass()) {
/*  74 */       return false;
/*     */     }
/*     */     
/*  77 */     FieldInternal that = (FieldInternal)o;
/*     */     
/*  79 */     if (this.flags != that.flags) {
/*  80 */       return false;
/*     */     }
/*  82 */     if (!Arrays.equals((Object[])this.annotations, (Object[])that.annotations)) {
/*  83 */       return false;
/*     */     }
/*  85 */     if (!Arrays.equals(this.name, that.name)) {
/*  86 */       return false;
/*     */     }
/*  88 */     if (!this.type.equals(that.type)) {
/*  89 */       return false;
/*     */     }
/*     */     
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     int result = Arrays.hashCode(this.name);
/*  98 */     result = 31 * result + this.type.hashCode();
/*  99 */     result = 31 * result + this.flags;
/* 100 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/* 101 */     return result;
/*     */   }
/*     */   
/*     */   boolean internEquals(Object o) {
/* 105 */     if (this == o) {
/* 106 */       return true;
/*     */     }
/* 108 */     if (o == null || getClass() != o.getClass()) {
/* 109 */       return false;
/*     */     }
/*     */     
/* 112 */     FieldInternal that = (FieldInternal)o;
/*     */     
/* 114 */     if (this.flags != that.flags) {
/* 115 */       return false;
/*     */     }
/* 117 */     if (!Arrays.equals((Object[])this.annotations, (Object[])that.annotations)) {
/* 118 */       return false;
/*     */     }
/* 120 */     if (!Arrays.equals(this.name, that.name)) {
/* 121 */       return false;
/*     */     }
/* 123 */     if (!this.type.internEquals(that.type)) {
/* 124 */       return false;
/*     */     }
/*     */     
/* 127 */     return true;
/*     */   }
/*     */   
/*     */   int internHashCode() {
/* 131 */     int result = Arrays.hashCode(this.name);
/* 132 */     result = 31 * result + this.type.internHashCode();
/* 133 */     result = 31 * result + this.flags;
/* 134 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   final String name() {
/* 139 */     return Utils.fromUTF8(this.name);
/*     */   }
/*     */   
/*     */   final byte[] nameBytes() {
/* 143 */     return this.name;
/*     */   }
/*     */   
/*     */   final Type type() {
/* 147 */     return this.type;
/*     */   }
/*     */   
/*     */   final List<AnnotationInstance> annotations() {
/* 151 */     return new ImmutableArrayList<>(this.annotations);
/*     */   }
/*     */   
/*     */   final AnnotationInstance[] annotationArray() {
/* 155 */     return this.annotations;
/*     */   }
/*     */   
/*     */   final AnnotationInstance annotation(DotName name) {
/* 159 */     return AnnotationInstance.binarySearch(this.annotations, name);
/*     */   }
/*     */   
/*     */   final boolean hasAnnotation(DotName name) {
/* 163 */     return (annotation(name) != null);
/*     */   }
/*     */   
/*     */   final short flags() {
/* 167 */     return this.flags;
/*     */   }
/*     */   
/*     */   final boolean isEnumConstant() {
/* 171 */     return ((this.flags & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     return this.type.toString(true) + " " + name();
/*     */   }
/*     */   
/*     */   public String toString(ClassInfo clazz) {
/* 180 */     return this.type.toString(true) + " " + clazz.name() + "." + name();
/*     */   }
/*     */   
/*     */   void setType(Type type) {
/* 184 */     this.type = type;
/*     */   }
/*     */   
/*     */   void setAnnotations(List<AnnotationInstance> annotations) {
/* 188 */     if (annotations.size() > 0) {
/* 189 */       this.annotations = annotations.<AnnotationInstance>toArray(new AnnotationInstance[annotations.size()]);
/* 190 */       Arrays.sort(this.annotations, AnnotationInstance.NAME_COMPARATOR);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\FieldInternal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */