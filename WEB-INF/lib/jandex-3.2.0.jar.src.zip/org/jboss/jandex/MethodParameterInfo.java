/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodParameterInfo
/*     */   implements Declaration
/*     */ {
/*     */   private final MethodInfo method;
/*     */   private final short position;
/*     */   
/*     */   MethodParameterInfo(MethodInfo method, short position) {
/*  40 */     this.method = method;
/*  41 */     this.position = position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodParameterInfo create(MethodInfo method, short parameter) {
/*  52 */     return new MethodParameterInfo(method, parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MethodInfo method() {
/*  61 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final short position() {
/*  70 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String name() {
/*  79 */     return this.method.parameterName(this.position);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type type() {
/*  89 */     return this.method.parameterType(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean targetsThis(AnnotationInstance annotation) {
/*  94 */     return (annotation.target().kind() == AnnotationTarget.Kind.METHOD_PARAMETER && 
/*  95 */       (annotation.target().asMethodParameter()).position == this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean targetsThisOrNested(AnnotationInstance annotation) {
/* 100 */     return (targetsThis(annotation) || (annotation
/* 101 */       .target().kind() == AnnotationTarget.Kind.TYPE && annotation
/* 102 */       .target().asType().usage() == TypeTarget.Usage.METHOD_PARAMETER && annotation
/* 103 */       .target().asType().asMethodParameterType().position() == this.position));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAnnotation(DotName name) {
/* 117 */     return (annotation(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationInstance annotation(DotName name) {
/* 135 */     for (AnnotationInstance instance : this.method.methodInternal().annotationArray()) {
/* 136 */       if (targetsThisOrNested(instance) && instance.name().equals(name)) {
/* 137 */         return instance;
/*     */       }
/*     */     } 
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotations(DotName name) {
/* 156 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 157 */     for (AnnotationInstance instance : this.method.methodInternal().annotationArray()) {
/* 158 */       if (targetsThisOrNested(instance) && instance.name().equals(name)) {
/* 159 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 162 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 185 */     if (index == null) {
/* 186 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 188 */     List<AnnotationInstance> instances = new ArrayList<>(annotations(name));
/* 189 */     ClassInfo annotationClass = index.getClassByName(name);
/* 190 */     if (annotationClass == null) {
/* 191 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 193 */     if (!annotationClass.isAnnotation()) {
/* 194 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 196 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 197 */     if (repeatable != null) {
/* 198 */       Type containingType = repeatable.value().asClass();
/* 199 */       for (AnnotationInstance container : annotations(containingType.name())) {
/* 200 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 201 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       } 
/*     */     } 
/* 205 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotations() {
/* 218 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 219 */     for (AnnotationInstance instance : this.method.methodInternal().annotationArray()) {
/* 220 */       if (targetsThisOrNested(instance)) {
/* 221 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 224 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeclaredAnnotation(DotName name) {
/* 240 */     return (declaredAnnotation(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationInstance declaredAnnotation(DotName name) {
/* 256 */     for (AnnotationInstance instance : this.method.methodInternal().annotationArray()) {
/* 257 */       if (targetsThis(instance) && instance.name().equals(name)) {
/* 258 */         return instance;
/*     */       }
/*     */     } 
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> declaredAnnotationsWithRepeatable(DotName name, IndexView index) {
/* 284 */     if (index == null) {
/* 285 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 287 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 288 */     AnnotationInstance declaredInstance = declaredAnnotation(name);
/* 289 */     if (declaredInstance != null) {
/* 290 */       instances.add(declaredInstance);
/*     */     }
/* 292 */     ClassInfo annotationClass = index.getClassByName(name);
/* 293 */     if (annotationClass == null) {
/* 294 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 296 */     if (!annotationClass.isAnnotation()) {
/* 297 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 299 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 300 */     if (repeatable != null) {
/* 301 */       Type containingType = repeatable.value().asClass();
/* 302 */       AnnotationInstance container = declaredAnnotation(containingType.name());
/* 303 */       if (container != null) {
/* 304 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 305 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       }
/*     */     } 
/* 309 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> declaredAnnotations() {
/* 324 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 325 */     for (AnnotationInstance instance : this.method.methodInternal().annotationArray()) {
/* 326 */       if (targetsThis(instance)) {
/* 327 */         instances.add(instance);
/*     */       }
/*     */     } 
/* 330 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 340 */     return this.method + " #" + this.position;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ClassInfo asClass() {
/* 345 */     throw new IllegalArgumentException("Not a class");
/*     */   }
/*     */ 
/*     */   
/*     */   public final FieldInfo asField() {
/* 350 */     throw new IllegalArgumentException("Not a field");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodInfo asMethod() {
/* 355 */     throw new IllegalArgumentException("Not a method");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodParameterInfo asMethodParameter() {
/* 360 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypeTarget asType() {
/* 365 */     throw new IllegalArgumentException("Not a type");
/*     */   }
/*     */ 
/*     */   
/*     */   public final RecordComponentInfo asRecordComponent() {
/* 370 */     throw new IllegalArgumentException("Not a record component");
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationTarget.Kind kind() {
/* 375 */     return AnnotationTarget.Kind.METHOD_PARAMETER;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 380 */     int result = 1;
/* 381 */     result = 31 * result + this.method.hashCode();
/* 382 */     result = 31 * result + this.position;
/* 383 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 388 */     if (this == o) {
/* 389 */       return true;
/*     */     }
/* 391 */     if (o == null || getClass() != o.getClass()) {
/* 392 */       return false;
/*     */     }
/* 394 */     MethodParameterInfo other = (MethodParameterInfo)o;
/* 395 */     return (this.method.equals(other.method) && this.position == other.position);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MethodParameterInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */