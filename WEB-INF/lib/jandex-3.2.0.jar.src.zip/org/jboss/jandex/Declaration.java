/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Declaration
/*    */   extends AnnotationTarget
/*    */ {
/*    */   default boolean isDeclaration() {
/* 16 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   default Declaration asDeclaration() {
/* 21 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Declaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */