/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarIndexer
/*     */ {
/*     */   private static File getIndexFile(File jarFile, boolean newJar) {
/*  39 */     String name = jarFile.getName();
/*  40 */     int p = name.lastIndexOf(".");
/*  41 */     if (p < 0) {
/*  42 */       throw new IllegalArgumentException("File has no extension / ext: " + jarFile);
/*     */     }
/*     */     
/*  45 */     String ext = name.substring(p);
/*  46 */     String pattern = "\\" + ext + "$";
/*     */     
/*  48 */     if (newJar) {
/*  49 */       return new File(jarFile.getAbsolutePath().replaceAll(pattern, "-jandex" + ext));
/*     */     }
/*  51 */     return new File(jarFile.getAbsolutePath().replaceAll(pattern, "-" + ext.substring(1)) + ".idx");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Result createJarIndex(File jarFile, Indexer indexer, boolean modify, boolean newJar, boolean verbose) throws IOException {
/*  69 */     return createJarIndex(jarFile, indexer, modify, newJar, verbose, System.out, System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Result createJarIndex(File jarFile, Indexer indexer, File outputFile, boolean modify, boolean newJar, boolean verbose) throws IOException {
/*  88 */     return createJarIndex(jarFile, indexer, outputFile, modify, newJar, verbose, System.out, System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Result createJarIndex(File jarFile, Indexer indexer, boolean modify, boolean newJar, boolean verbose, PrintStream infoStream, PrintStream errStream) throws IOException {
/* 109 */     return createJarIndex(jarFile, indexer, null, modify, newJar, verbose, infoStream, errStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Result createJarIndex(File jarFile, Indexer indexer, File outputFile, boolean modify, boolean newJar, boolean verbose, PrintStream infoStream, PrintStream errStream) throws IOException {
/*     */     OutputStream out;
/* 131 */     File tmpCopy = null;
/* 132 */     ZipOutputStream zo = null;
/*     */ 
/*     */     
/* 135 */     JarFile jar = new JarFile(jarFile);
/*     */     
/* 137 */     if (modify) {
/* 138 */       tmpCopy = File.createTempFile(jarFile.getName().substring(0, jarFile.getName().lastIndexOf('.')) + "00", "jmp");
/* 139 */       out = zo = new ZipOutputStream(new FileOutputStream(tmpCopy));
/* 140 */       outputFile = jarFile;
/* 141 */     } else if (newJar) {
/* 142 */       outputFile = getIndexFile(jarFile, newJar);
/* 143 */       out = zo = new ZipOutputStream(new FileOutputStream(outputFile));
/*     */     } else {
/* 145 */       if (outputFile == null) {
/* 146 */         outputFile = getIndexFile(jarFile, newJar);
/*     */       }
/* 148 */       out = new FileOutputStream(outputFile);
/*     */     } 
/*     */     
/*     */     try {
/* 152 */       Enumeration<JarEntry> entries = jar.entries();
/* 153 */       while (entries.hasMoreElements()) {
/* 154 */         JarEntry entry = entries.nextElement();
/* 155 */         if (modify && 
/* 156 */           !"META-INF/jandex.idx".equals(entry.getName())) {
/* 157 */           JarEntry clone = (JarEntry)entry.clone();
/*     */           
/* 159 */           if (clone.getMethod() != 0)
/* 160 */             clone.setCompressedSize(-1L); 
/* 161 */           zo.putNextEntry(clone);
/* 162 */           InputStream stream = jar.getInputStream(entry);
/*     */           try {
/* 164 */             copy(stream, zo);
/*     */           } finally {
/* 166 */             safeClose(stream);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 171 */         if (entry.getName().endsWith(".class")) {
/*     */           try {
/* 173 */             ClassSummary info; InputStream stream = jar.getInputStream(entry);
/*     */             
/*     */             try {
/* 176 */               info = indexer.indexWithSummary(stream);
/*     */             } finally {
/* 178 */               safeClose(stream);
/*     */             } 
/* 180 */             if (verbose && info != null && infoStream != null)
/* 181 */               printIndexEntryInfo(info, infoStream); 
/* 182 */           } catch (Exception e) {
/* 183 */             String message = (e.getMessage() == null) ? e.getClass().getSimpleName() : e.getMessage();
/* 184 */             errStream.println("ERROR: Could not index " + entry.getName() + ": " + message);
/* 185 */             if (verbose) {
/* 186 */               e.printStackTrace(errStream);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/* 191 */       if (modify || newJar) {
/* 192 */         zo.putNextEntry(new ZipEntry("META-INF/jandex.idx"));
/*     */       }
/*     */       
/* 195 */       IndexWriter writer = new IndexWriter(out);
/* 196 */       Index index = indexer.complete();
/* 197 */       int bytes = writer.write(index);
/*     */       
/* 199 */       out.close();
/*     */       
/* 201 */       if (modify) {
/* 202 */         jarFile.delete();
/* 203 */         if (!tmpCopy.renameTo(jarFile)) {
/* 204 */           copy(jarFile, tmpCopy);
/* 205 */           tmpCopy.delete();
/*     */         } 
/* 207 */         tmpCopy = null;
/*     */       } 
/* 209 */       return new Result(index, modify ? "META-INF/jandex.idx" : outputFile.getPath(), bytes, outputFile);
/*     */     } finally {
/* 211 */       safeClose(out);
/* 212 */       safeClose(jar);
/* 213 */       if (tmpCopy != null)
/* 214 */         tmpCopy.delete(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void copy(File dest, File source) throws IOException {
/* 219 */     FileInputStream fis = new FileInputStream(source);
/* 220 */     FileOutputStream fos = new FileOutputStream(new File(dest.getAbsolutePath()));
/*     */     try {
/* 222 */       byte[] b = new byte[8196];
/* 223 */       for (int count = 0; (count = fis.read(b, 0, 8196)) >= 0;) {
/* 224 */         fos.write(b, 0, count);
/*     */       }
/*     */     } finally {
/* 227 */       fis.close();
/* 228 */       fos.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void printIndexEntryInfo(ClassSummary info, PrintStream infoStream) {
/* 233 */     infoStream.println("Indexed " + info.name() + " (" + info.annotationsCount() + " annotations)");
/*     */   }
/*     */   
/*     */   private static void copy(InputStream in, OutputStream out) throws IOException {
/* 237 */     byte[] buf = new byte[8192];
/*     */     int len;
/* 239 */     while ((len = in.read(buf)) > 0) {
/* 240 */       out.write(buf, 0, len);
/*     */     }
/* 242 */     out.flush();
/*     */   }
/*     */   
/*     */   private static void safeClose(JarFile close) {
/*     */     try {
/* 247 */       close.close();
/* 248 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static void safeClose(Closeable close) {
/*     */     try {
/* 254 */       close.close();
/* 255 */     } catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\JarIndexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */