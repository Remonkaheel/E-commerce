/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PackedDataOutputStream
/*    */   extends DataOutputStream
/*    */ {
/*    */   static final int MAX_1BYTE = 127;
/*    */   static final int MAX_2BYTE = 16383;
/*    */   static final int MAX_3BYTE = 2097151;
/*    */   static final int MAX_4BYTE = 268435455;
/*    */   
/*    */   public PackedDataOutputStream(OutputStream out) {
/* 44 */     super(out);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writePackedU32(int i) throws IOException {
/* 62 */     if ((i & 0xFFFFFF80) == 0) {
/* 63 */       writeByte(i);
/* 64 */     } else if ((i & 0xFFFFC000) == 0) {
/* 65 */       writeByte(i >>> 7 & 0x7F | 0x80);
/* 66 */       writeByte(i & 0x7F);
/* 67 */     } else if ((i & 0xFFE00000) == 0) {
/* 68 */       writeByte(i >>> 14 & 0x7F | 0x80);
/* 69 */       writeByte(i >>> 7 & 0x7F | 0x80);
/* 70 */       writeByte(i & 0x7F);
/* 71 */     } else if ((i & 0xF0000000) == 0) {
/* 72 */       writeByte(i >>> 21 & 0x7F | 0x80);
/* 73 */       writeByte(i >>> 14 & 0x7F | 0x80);
/* 74 */       writeByte(i >>> 7 & 0x7F | 0x80);
/* 75 */       writeByte(i & 0x7F);
/*    */     } else {
/* 77 */       writeByte(i >>> 28 & 0x7F | 0x80);
/* 78 */       writeByte(i >>> 21 & 0x7F | 0x80);
/* 79 */       writeByte(i >>> 14 & 0x7F | 0x80);
/* 80 */       writeByte(i >>> 7 & 0x7F | 0x80);
/* 81 */       writeByte(i & 0x7F);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\PackedDataOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */