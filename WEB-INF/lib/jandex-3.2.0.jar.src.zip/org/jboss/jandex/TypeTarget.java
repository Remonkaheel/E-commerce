/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeTarget
/*     */   implements AnnotationTarget
/*     */ {
/*     */   private final AnnotationTarget enclosingTarget;
/*     */   private Type target;
/*     */   
/*     */   public enum Usage
/*     */   {
/*  51 */     EMPTY,
/*     */ 
/*     */     
/*  54 */     CLASS_EXTENDS,
/*     */ 
/*     */     
/*  57 */     METHOD_PARAMETER,
/*     */ 
/*     */     
/*  60 */     TYPE_PARAMETER,
/*     */ 
/*     */     
/*  63 */     TYPE_PARAMETER_BOUND,
/*     */ 
/*     */     
/*  66 */     THROWS;
/*     */   }
/*     */   
/*     */   TypeTarget(AnnotationTarget enclosingTarget, Type target) {
/*  70 */     this.enclosingTarget = enclosingTarget;
/*  71 */     this.target = target;
/*     */   }
/*     */   
/*     */   TypeTarget(AnnotationTarget enclosingTarget) {
/*  75 */     this(enclosingTarget, null);
/*     */   }
/*     */   
/*     */   void setTarget(Type target) {
/*  79 */     this.target = target;
/*     */   }
/*     */ 
/*     */   
/*     */   public final AnnotationTarget.Kind kind() {
/*  84 */     return AnnotationTarget.Kind.TYPE;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeclaration() {
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Declaration asDeclaration() {
/*  94 */     throw new IllegalArgumentException("Not a declaration");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTarget enclosingTarget() {
/* 103 */     return this.enclosingTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type target() {
/* 114 */     return this.target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmptyTypeTarget asEmpty() {
/* 126 */     throw new IllegalArgumentException("Not an empty type target");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassExtendsTypeTarget asClassExtends() {
/* 137 */     throw new IllegalArgumentException("Not a class extends type target");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodParameterTypeTarget asMethodParameterType() {
/* 148 */     throw new IllegalArgumentException("Not a method parameter type target");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeParameterTypeTarget asTypeParameter() {
/* 159 */     throw new IllegalArgumentException("Not a type parameter target");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeParameterBoundTypeTarget asTypeParameterBound() {
/* 170 */     throw new IllegalArgumentException("Not a type parameter bound target");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThrowsTypeTarget asThrows() {
/* 181 */     throw new IllegalArgumentException("Not a throws type target");
/*     */   }
/*     */ 
/*     */   
/*     */   public final ClassInfo asClass() {
/* 186 */     throw new IllegalArgumentException("Not a class");
/*     */   }
/*     */ 
/*     */   
/*     */   public final FieldInfo asField() {
/* 191 */     throw new IllegalArgumentException("Not a field");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodInfo asMethod() {
/* 196 */     throw new IllegalArgumentException("Not a method");
/*     */   }
/*     */ 
/*     */   
/*     */   public final MethodParameterInfo asMethodParameter() {
/* 201 */     throw new IllegalArgumentException("Not a method parameter");
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypeTarget asType() {
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final RecordComponentInfo asRecordComponent() {
/* 211 */     throw new IllegalArgumentException("Not a record component");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAnnotation(DotName name) {
/* 228 */     if (this.target == null) {
/* 229 */       return false;
/*     */     }
/* 231 */     return this.target.hasAnnotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationInstance annotation(DotName name) {
/* 248 */     if (this.target == null) {
/* 249 */       return null;
/*     */     }
/* 251 */     return this.target.annotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotations(DotName name) {
/* 270 */     if (this.target == null) {
/* 271 */       return Collections.emptyList();
/*     */     }
/* 273 */     return Collections.singletonList(this.target.annotation(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 298 */     if (this.target == null) {
/* 299 */       return Collections.emptyList();
/*     */     }
/* 301 */     return this.target.annotationsWithRepeatable(name, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotations() {
/* 316 */     if (this.target == null) {
/* 317 */       return Collections.emptyList();
/*     */     }
/* 319 */     return this.target.annotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeclaredAnnotation(DotName name) {
/* 332 */     return hasAnnotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationInstance declaredAnnotation(DotName name) {
/* 345 */     return annotation(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> declaredAnnotationsWithRepeatable(DotName name, IndexView index) {
/* 365 */     return annotationsWithRepeatable(name, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> declaredAnnotations() {
/* 377 */     return annotations();
/*     */   }
/*     */   
/*     */   public abstract Usage usage();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\TypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */