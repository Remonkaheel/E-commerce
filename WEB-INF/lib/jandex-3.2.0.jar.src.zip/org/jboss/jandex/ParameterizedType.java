/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizedType
/*     */   extends Type
/*     */ {
/*     */   private final Type[] arguments;
/*     */   private final Type owner;
/*     */   private int hash;
/*     */   
/*     */   public static ParameterizedType create(DotName name, Type... arguments) {
/*  77 */     return new ParameterizedType(name, arguments, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParameterizedType create(String name, Type... arguments) {
/*  92 */     return create(DotName.createSimple(name), arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParameterizedType create(Class<?> clazz, Type... arguments) {
/* 107 */     return create(DotName.createSimple(clazz.getName()), arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParameterizedType create(DotName name, Type[] arguments, Type owner) {
/* 125 */     return new ParameterizedType(name, arguments, owner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParameterizedType create(String name, Type[] arguments, Type owner) {
/* 143 */     return create(DotName.createSimple(name), arguments, owner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParameterizedType create(Class<?> clazz, Type[] arguments, Type owner) {
/* 161 */     return create(DotName.createSimple(clazz.getName()), arguments, owner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(DotName name) {
/* 172 */     return new Builder(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(Class<?> clazz) {
/* 183 */     return builder(DotName.createSimple(clazz.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ParameterizedType(DotName name, Type[] arguments, Type owner) {
/* 191 */     this(name, arguments, owner, (AnnotationInstance[])null);
/*     */   }
/*     */   
/*     */   ParameterizedType(DotName name, Type[] arguments, Type owner, AnnotationInstance[] annotations) {
/* 195 */     super(name, annotations);
/* 196 */     this.arguments = (arguments == null) ? EMPTY_ARRAY : arguments;
/* 197 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Type> arguments() {
/* 206 */     return new ImmutableArrayList<>(this.arguments);
/*     */   }
/*     */   
/*     */   Type[] argumentsArray() {
/* 210 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type owner() {
/* 234 */     return this.owner;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 239 */     return Type.Kind.PARAMETERIZED_TYPE;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParameterizedType asParameterizedType() {
/* 244 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   ParameterizedType copyType(AnnotationInstance[] newAnnotations) {
/* 249 */     return new ParameterizedType(name(), this.arguments, this.owner, newAnnotations);
/*     */   }
/*     */   
/*     */   ParameterizedType copyType(Type[] arguments) {
/* 253 */     return new ParameterizedType(name(), arguments, this.owner, annotationArray());
/*     */   }
/*     */   
/*     */   ParameterizedType copyType(int argumentIndex, Type argument) {
/* 257 */     if (argumentIndex > this.arguments.length) {
/* 258 */       throw new IllegalArgumentException("Type argument index outside of bounds");
/*     */     }
/*     */     
/* 261 */     Type[] arguments = (Type[])this.arguments.clone();
/* 262 */     arguments[argumentIndex] = argument;
/* 263 */     return new ParameterizedType(name(), arguments, this.owner, annotationArray());
/*     */   }
/*     */   
/*     */   ParameterizedType copyType(Type owner) {
/* 267 */     return new ParameterizedType(name(), this.arguments, owner, annotationArray());
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(boolean simple) {
/* 272 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 274 */     if (this.owner != null) {
/* 275 */       builder.append(this.owner);
/* 276 */       builder.append('.');
/* 277 */       appendAnnotations(builder);
/* 278 */       builder.append(name().local());
/*     */     } else {
/* 280 */       String packagePrefix = name().packagePrefix();
/* 281 */       if (packagePrefix != null) {
/* 282 */         builder.append(packagePrefix).append('.');
/*     */       }
/* 284 */       appendAnnotations(builder);
/* 285 */       builder.append(name().withoutPackagePrefix());
/*     */     } 
/*     */     
/* 288 */     if (this.arguments.length > 0) {
/* 289 */       builder.append('<');
/* 290 */       builder.append(this.arguments[0].toString(true));
/* 291 */       for (int i = 1; i < this.arguments.length; i++) {
/* 292 */         builder.append(", ").append(this.arguments[i].toString(true));
/*     */       }
/* 294 */       builder.append('>');
/*     */     } 
/*     */     
/* 297 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 302 */     if (this == o) {
/* 303 */       return true;
/*     */     }
/*     */     
/* 306 */     if (!super.equals(o)) {
/* 307 */       return false;
/*     */     }
/*     */     
/* 310 */     ParameterizedType other = (ParameterizedType)o;
/*     */     
/* 312 */     return ((this.owner == other.owner || (this.owner != null && this.owner.equals(other.owner))) && 
/* 313 */       Arrays.equals((Object[])this.arguments, (Object[])other.arguments));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 318 */     int hash = this.hash;
/* 319 */     if (hash != 0) {
/* 320 */       return hash;
/*     */     }
/*     */     
/* 323 */     hash = super.hashCode();
/* 324 */     hash = 31 * hash + Arrays.hashCode((Object[])this.arguments);
/* 325 */     hash = 31 * hash + ((this.owner != null) ? this.owner.hashCode() : 0);
/* 326 */     return this.hash = hash;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 331 */     if (this == o) {
/* 332 */       return true;
/*     */     }
/*     */     
/* 335 */     if (!super.internEquals(o)) {
/* 336 */       return false;
/*     */     }
/*     */     
/* 339 */     ParameterizedType other = (ParameterizedType)o;
/*     */     
/* 341 */     return ((this.owner == other.owner || (this.owner != null && this.owner.internEquals(other.owner))) && 
/* 342 */       TypeInterning.arrayEquals(this.arguments, other.arguments));
/*     */   }
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 347 */     int hash = super.internHashCode();
/* 348 */     hash = 31 * hash + TypeInterning.arrayHashCode(this.arguments);
/* 349 */     hash = 31 * hash + ((this.owner != null) ? this.owner.internHashCode() : 0);
/* 350 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */     extends Type.Builder<Builder>
/*     */   {
/*     */     private List<Type> arguments;
/*     */     
/*     */     private Type owner;
/*     */ 
/*     */     
/*     */     Builder(DotName name) {
/* 364 */       super(name);
/* 365 */       this.arguments = new ArrayList<>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addArgument(Type argument) {
/* 375 */       this.arguments.add(Objects.<Type>requireNonNull(argument));
/* 376 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addArgument(Class<?> clazz) {
/* 386 */       return addArgument(ClassType.create(clazz));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setOwner(Type owner) {
/* 397 */       this.owner = Objects.<Type>requireNonNull(owner);
/* 398 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ParameterizedType build() {
/* 407 */       return new ParameterizedType(this.name, this.arguments.isEmpty() ? Type.EMPTY_ARRAY : this.arguments.<Type>toArray(Type.EMPTY_ARRAY), this.owner, 
/* 408 */           annotationsArray());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ParameterizedType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */