package org.jboss.jandex;

import java.io.IOException;

abstract class IndexReaderImpl {
  abstract Index read() throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexReaderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */