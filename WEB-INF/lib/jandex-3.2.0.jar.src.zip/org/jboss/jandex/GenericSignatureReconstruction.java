/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class GenericSignatureReconstruction
/*     */ {
/*     */   static boolean requiresGenericSignature(ClassInfo clazz) {
/*  15 */     if (!clazz.typeParameters().isEmpty()) {
/*  16 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  20 */     Type superType = clazz.superClassType();
/*  21 */     if (superType.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/*  22 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  26 */     for (Type type : clazz.interfaceTypes()) {
/*  27 */       if (type.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/*  28 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  32 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean requiresGenericSignature(MethodInfo method) {
/*  48 */     if (!method.typeParameters().isEmpty()) {
/*  49 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  53 */     if (requiresGenericSignature(method.returnType())) {
/*  54 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  58 */     for (Type parameterType : method.parameterTypes()) {
/*  59 */       if (requiresGenericSignature(parameterType)) {
/*  60 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  64 */     if (hasThrowsSignature(method)) {
/*  65 */       return true;
/*     */     }
/*     */     
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean requiresGenericSignature(FieldInfo field) {
/*  79 */     return requiresGenericSignature(field.type());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean requiresGenericSignature(RecordComponentInfo recordComponent) {
/*  90 */     return requiresGenericSignature(recordComponent.type());
/*     */   }
/*     */   
/*     */   private static boolean requiresGenericSignature(Type type) {
/*  94 */     return (type.kind() == Type.Kind.TYPE_VARIABLE || type
/*  95 */       .kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE || type
/*  96 */       .kind() == Type.Kind.PARAMETERIZED_TYPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String reconstructGenericSignature(ClassInfo clazz, Function<String, Type> typeVariableSubstitution) {
/* 103 */     StringBuilder result = new StringBuilder();
/*     */     
/* 105 */     if (!clazz.typeParameters().isEmpty()) {
/* 106 */       typeParametersSignature(clazz.typeParameters(), typeVariableSubstitution, result);
/*     */     }
/*     */     
/* 109 */     typeSignature(clazz.superClassType(), typeVariableSubstitution, result);
/*     */     
/* 111 */     for (Type interfaceType : clazz.interfaceTypes()) {
/* 112 */       typeSignature(interfaceType, typeVariableSubstitution, result);
/*     */     }
/*     */     
/* 115 */     return result.toString();
/*     */   }
/*     */   
/*     */   static String reconstructGenericSignature(MethodInfo method, Function<String, Type> typeVariableSubstitution) {
/* 119 */     StringBuilder result = new StringBuilder();
/*     */     
/* 121 */     if (!method.typeParameters().isEmpty()) {
/* 122 */       typeParametersSignature(method.typeParameters(), typeVariableSubstitution, result);
/*     */     }
/*     */     
/* 125 */     result.append('(');
/* 126 */     for (Type parameter : method.parameterTypes()) {
/* 127 */       typeSignature(parameter, typeVariableSubstitution, result);
/*     */     }
/* 129 */     result.append(')');
/*     */     
/* 131 */     typeSignature(method.returnType(), typeVariableSubstitution, result);
/*     */     
/* 133 */     if (hasThrowsSignature(method)) {
/* 134 */       for (Type exception : method.exceptions()) {
/* 135 */         result.append('^');
/* 136 */         typeSignature(exception, typeVariableSubstitution, result);
/*     */       } 
/*     */     }
/*     */     
/* 140 */     return result.toString();
/*     */   }
/*     */   
/*     */   static String reconstructGenericSignature(FieldInfo field, Function<String, Type> typeVariableSubstitution) {
/* 144 */     StringBuilder result = new StringBuilder();
/*     */     
/* 146 */     typeSignature(field.type(), typeVariableSubstitution, result);
/*     */     
/* 148 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static String reconstructGenericSignature(RecordComponentInfo recordComponent, Function<String, Type> typeVariableSubstitution) {
/* 153 */     StringBuilder result = new StringBuilder();
/*     */     
/* 155 */     typeSignature(recordComponent.type(), typeVariableSubstitution, result);
/*     */     
/* 157 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasThrowsSignature(MethodInfo method) {
/* 173 */     for (Type type : method.exceptions()) {
/* 174 */       if (type.kind() == Type.Kind.TYPE_VARIABLE || type
/* 175 */         .kind() == Type.Kind.UNRESOLVED_TYPE_VARIABLE) {
/* 176 */         return true;
/*     */       }
/*     */     } 
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void typeParametersSignature(List<TypeVariable> typeParameters, Function<String, Type> substitution, StringBuilder result) {
/* 185 */     if (typeParameters.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     result.append('<');
/* 193 */     for (TypeVariable typeParameter : typeParameters) {
/* 194 */       result.append(typeParameter.identifier());
/*     */       
/* 196 */       if (typeParameter.hasImplicitObjectBound()) {
/* 197 */         result.append(':');
/*     */       }
/* 199 */       for (Type bound : typeParameter.bounds()) {
/* 200 */         result.append(':');
/* 201 */         typeSignature(bound, substitution, result);
/*     */       } 
/*     */     } 
/* 204 */     result.append('>'); } static void typeSignature(Type type, Function<String, Type> substitution, StringBuilder result) { PrimitiveType.Primitive primitive; ClassType classType; ArrayType arrayType; int i;
/*     */     ParameterizedType parameterizedType;
/*     */     Type owner;
/*     */     WildcardType wildcardType;
/* 208 */     switch (type.kind()) {
/*     */       case VOID:
/* 210 */         result.append('V');
/*     */         return;
/*     */       case PRIMITIVE:
/* 213 */         primitive = type.asPrimitiveType().primitive();
/* 214 */         switch (primitive) {
/*     */           case VOID:
/* 216 */             result.append('Z');
/*     */             return;
/*     */           case PRIMITIVE:
/* 219 */             result.append('C');
/*     */             return;
/*     */           case CLASS:
/* 222 */             result.append('B');
/*     */             return;
/*     */           case ARRAY:
/* 225 */             result.append('S');
/*     */             return;
/*     */           case PARAMETERIZED_TYPE:
/* 228 */             result.append('I');
/*     */             return;
/*     */           case TYPE_VARIABLE:
/* 231 */             result.append('J');
/*     */             return;
/*     */           case UNRESOLVED_TYPE_VARIABLE:
/* 234 */             result.append('F');
/*     */             return;
/*     */           case TYPE_VARIABLE_REFERENCE:
/* 237 */             result.append('D');
/*     */             return;
/*     */         } 
/* 240 */         throw new IllegalArgumentException("unkown primitive type " + primitive);
/*     */       
/*     */       case CLASS:
/* 243 */         classType = type.asClassType();
/* 244 */         result.append('L').append(classType.name().toString('/')).append(';');
/*     */         return;
/*     */       case ARRAY:
/* 247 */         arrayType = type.asArrayType();
/* 248 */         for (i = 0; i < arrayType.dimensions(); i++) {
/* 249 */           result.append('[');
/*     */         }
/* 251 */         typeSignature(arrayType.component(), substitution, result);
/*     */         return;
/*     */       case PARAMETERIZED_TYPE:
/* 254 */         parameterizedType = type.asParameterizedType();
/* 255 */         owner = parameterizedType.owner();
/* 256 */         if (owner != null && owner.kind() == Type.Kind.PARAMETERIZED_TYPE) {
/* 257 */           typeSignature(owner, substitution, result);
/*     */ 
/*     */           
/* 260 */           assert result.charAt(result.length() - 1) == ';';
/* 261 */           result.setCharAt(result.length() - 1, '.');
/* 262 */           result.append(parameterizedType.name().local());
/*     */         } else {
/* 264 */           result.append('L').append(parameterizedType.name().toString('/'));
/*     */         } 
/* 266 */         if (!parameterizedType.arguments().isEmpty()) {
/* 267 */           result.append('<');
/* 268 */           for (Type argument : parameterizedType.arguments()) {
/* 269 */             typeSignature(argument, substitution, result);
/*     */           }
/* 271 */           result.append('>');
/*     */         } 
/* 273 */         result.append(';');
/*     */         return;
/*     */       case TYPE_VARIABLE:
/* 276 */         typeVariableSignature(type, type.asTypeVariable().identifier(), substitution, result);
/*     */         return;
/*     */       case UNRESOLVED_TYPE_VARIABLE:
/* 279 */         typeVariableSignature(type, type.asUnresolvedTypeVariable().identifier(), substitution, result);
/*     */         return;
/*     */       case TYPE_VARIABLE_REFERENCE:
/* 282 */         typeVariableSignature(type, type.asTypeVariableReference().identifier(), substitution, result);
/*     */         return;
/*     */       case WILDCARD_TYPE:
/* 285 */         wildcardType = type.asWildcardType();
/* 286 */         if (wildcardType.superBound() != null) {
/* 287 */           result.append('-');
/* 288 */           typeSignature(wildcardType.superBound(), substitution, result);
/* 289 */         } else if (ClassType.OBJECT_TYPE.equals(wildcardType.extendsBound())) {
/* 290 */           result.append('*');
/*     */         } else {
/* 292 */           result.append('+');
/* 293 */           typeSignature(wildcardType.extendsBound(), substitution, result);
/*     */         } 
/*     */         return;
/*     */     } 
/* 297 */     throw new IllegalArgumentException("unknown type " + type); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void typeVariableSignature(Type typeVariable, String typeVariableIdentifier, Function<String, Type> substitution, StringBuilder result) {
/* 305 */     Type type = (substitution == null) ? null : substitution.apply(typeVariableIdentifier);
/* 306 */     if (type == null || type == typeVariable) {
/* 307 */       result.append('T').append(typeVariableIdentifier).append(';');
/*     */     } else {
/* 309 */       typeSignature(type, substitution, result);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\GenericSignatureReconstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */