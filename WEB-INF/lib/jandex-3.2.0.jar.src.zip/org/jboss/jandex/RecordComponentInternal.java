/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RecordComponentInternal
/*     */ {
/*  29 */   static final RecordComponentInternal[] EMPTY_ARRAY = new RecordComponentInternal[0];
/*     */   
/*     */   private final byte[] name;
/*     */   private Type type;
/*     */   private AnnotationInstance[] annotations;
/*  34 */   static final NameComparator NAME_COMPARATOR = new NameComparator();
/*     */   
/*     */   static class NameComparator implements Comparator<RecordComponentInternal> {
/*     */     private int compare(byte[] left, byte[] right) {
/*  38 */       for (int i = 0, j = 0; i < left.length && j < right.length; i++, j++) {
/*  39 */         int a = left[i] & 0xFF;
/*  40 */         int b = right[j] & 0xFF;
/*  41 */         if (a != b) {
/*  42 */           return a - b;
/*     */         }
/*     */       } 
/*  45 */       return left.length - right.length;
/*     */     }
/*     */     
/*     */     public int compare(RecordComponentInternal instance, RecordComponentInternal instance2) {
/*  49 */       return compare(instance.name, instance2.name);
/*     */     }
/*     */   }
/*     */   
/*     */   RecordComponentInternal(byte[] name, Type type) {
/*  54 */     this(name, type, AnnotationInstance.EMPTY_ARRAY);
/*     */   }
/*     */   
/*     */   RecordComponentInternal(byte[] name, Type type, AnnotationInstance[] annotations) {
/*  58 */     this.name = name;
/*  59 */     this.type = type;
/*  60 */     this.annotations = annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  65 */     if (this == o) {
/*  66 */       return true;
/*     */     }
/*  68 */     if (o == null || getClass() != o.getClass()) {
/*  69 */       return false;
/*     */     }
/*     */     
/*  72 */     RecordComponentInternal that = (RecordComponentInternal)o;
/*     */     
/*  74 */     if (!Arrays.equals((Object[])this.annotations, (Object[])that.annotations)) {
/*  75 */       return false;
/*     */     }
/*  77 */     if (!Arrays.equals(this.name, that.name)) {
/*  78 */       return false;
/*     */     }
/*  80 */     if (!this.type.equals(that.type)) {
/*  81 */       return false;
/*     */     }
/*     */     
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  89 */     int result = Arrays.hashCode(this.name);
/*  90 */     result = 31 * result + this.type.hashCode();
/*  91 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/*  92 */     return result;
/*     */   }
/*     */   
/*     */   boolean internEquals(Object o) {
/*  96 */     if (this == o) {
/*  97 */       return true;
/*     */     }
/*  99 */     if (o == null || getClass() != o.getClass()) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     RecordComponentInternal that = (RecordComponentInternal)o;
/*     */     
/* 105 */     if (!Arrays.equals((Object[])this.annotations, (Object[])that.annotations)) {
/* 106 */       return false;
/*     */     }
/* 108 */     if (!Arrays.equals(this.name, that.name)) {
/* 109 */       return false;
/*     */     }
/* 111 */     if (!this.type.internEquals(that.type)) {
/* 112 */       return false;
/*     */     }
/*     */     
/* 115 */     return true;
/*     */   }
/*     */   
/*     */   int internHashCode() {
/* 119 */     int result = Arrays.hashCode(this.name);
/* 120 */     result = 31 * result + this.type.internHashCode();
/* 121 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/* 122 */     return result;
/*     */   }
/*     */   
/*     */   final String name() {
/* 126 */     return Utils.fromUTF8(this.name);
/*     */   }
/*     */   
/*     */   final byte[] nameBytes() {
/* 130 */     return this.name;
/*     */   }
/*     */   
/*     */   final Type type() {
/* 134 */     return this.type;
/*     */   }
/*     */   
/*     */   final List<AnnotationInstance> annotations() {
/* 138 */     return new ImmutableArrayList<>(this.annotations);
/*     */   }
/*     */   
/*     */   final AnnotationInstance[] annotationArray() {
/* 142 */     return this.annotations;
/*     */   }
/*     */   
/*     */   final AnnotationInstance annotation(DotName name) {
/* 146 */     return AnnotationInstance.binarySearch(this.annotations, name);
/*     */   }
/*     */   
/*     */   final boolean hasAnnotation(DotName name) {
/* 150 */     return (annotation(name) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     return this.type.toString(true) + " " + name();
/*     */   }
/*     */   
/*     */   public String toString(ClassInfo clazz) {
/* 159 */     return this.type.toString(true) + " " + clazz.name() + "." + name();
/*     */   }
/*     */   
/*     */   void setType(Type type) {
/* 163 */     this.type = type;
/*     */   }
/*     */   
/*     */   void setAnnotations(List<AnnotationInstance> annotations) {
/* 167 */     if (annotations.size() > 0) {
/* 168 */       this.annotations = annotations.<AnnotationInstance>toArray(new AnnotationInstance[annotations.size()]);
/* 169 */       Arrays.sort(this.annotations, AnnotationInstance.NAME_COMPARATOR);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\RecordComponentInternal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */