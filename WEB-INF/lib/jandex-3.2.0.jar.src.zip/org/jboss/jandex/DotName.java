/*     */ package org.jboss.jandex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DotName
/*     */   implements Comparable<DotName>
/*     */ {
/*  63 */   static final DotName JAVA_NAME = new DotName(null, "java", true, false);
/*  64 */   static final DotName JAVA_LANG_NAME = new DotName(JAVA_NAME, "lang", true, false);
/*  65 */   static final DotName JAVA_LANG_ANNOTATION_NAME = new DotName(JAVA_LANG_NAME, "annotation", true, false);
/*  66 */   public static final DotName OBJECT_NAME = new DotName(JAVA_LANG_NAME, "Object", true, false);
/*  67 */   public static final DotName ENUM_NAME = new DotName(JAVA_LANG_NAME, "Enum", true, false);
/*  68 */   public static final DotName RECORD_NAME = new DotName(JAVA_LANG_NAME, "Record", true, false);
/*  69 */   public static final DotName STRING_NAME = new DotName(JAVA_LANG_NAME, "String", true, false);
/*  70 */   public static final DotName INHERITED_NAME = new DotName(JAVA_LANG_ANNOTATION_NAME, "Inherited", true, false);
/*  71 */   public static final DotName REPEATABLE_NAME = new DotName(JAVA_LANG_ANNOTATION_NAME, "Repeatable", true, false);
/*  72 */   public static final DotName RETENTION_NAME = new DotName(JAVA_LANG_ANNOTATION_NAME, "Retention", true, false);
/*     */   
/*     */   private final DotName prefix;
/*     */   
/*     */   private final String local;
/*     */   
/*     */   private int hash;
/*     */   private final boolean componentized;
/*     */   private final boolean innerClass;
/*     */   
/*     */   public static DotName createSimple(String name) {
/*  83 */     return new DotName(null, name, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DotName createSimple(Class<?> clazz) {
/*  97 */     return createSimple(clazz.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DotName createComponentized(DotName prefix, String localName) {
/* 113 */     if (localName.indexOf('.') != -1) {
/* 114 */       throw new IllegalArgumentException("A componentized DotName must not contain '.' characters in a local name");
/*     */     }
/* 116 */     return new DotName(prefix, localName, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DotName createComponentized(DotName prefix, String localName, boolean innerClass) {
/* 134 */     if (localName.indexOf('.') != -1) {
/* 135 */       throw new IllegalArgumentException("A componentized DotName must not contain '.' characters in a local name");
/*     */     }
/*     */     
/* 138 */     return new DotName(prefix, localName, true, innerClass);
/*     */   }
/*     */   
/*     */   DotName(DotName prefix, String local, boolean noDots, boolean innerClass) {
/* 142 */     if (local == null) {
/* 143 */       throw new IllegalArgumentException("Local name must not be null");
/*     */     }
/*     */     
/* 146 */     if (prefix != null && !prefix.componentized) {
/* 147 */       throw new IllegalArgumentException("A componentized DotName must not have a non-componentized prefix");
/*     */     }
/*     */     
/* 150 */     this.prefix = prefix;
/* 151 */     this.local = local;
/* 152 */     this.componentized = noDots;
/* 153 */     this.innerClass = innerClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DotName prefix() {
/* 163 */     return this.prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String local() {
/* 179 */     return this.local;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String withoutPackagePrefix() {
/* 191 */     if (this.componentized) {
/* 192 */       StringBuilder builder = new StringBuilder();
/* 193 */       stripPackage(builder);
/* 194 */       return builder.toString();
/*     */     } 
/* 196 */     int index = this.local.lastIndexOf('.');
/* 197 */     return (index == -1) ? this.local : ((index < this.local.length() - 1) ? this.local.substring(index + 1) : "");
/*     */   }
/*     */ 
/*     */   
/*     */   private void stripPackage(StringBuilder builder) {
/* 202 */     if (this.innerClass) {
/* 203 */       this.prefix.stripPackage(builder);
/* 204 */       builder.append('$');
/*     */     } 
/* 206 */     builder.append(this.local);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String packagePrefix() {
/* 216 */     if (this.componentized) {
/* 217 */       if (this.prefix == null) {
/* 218 */         return null;
/*     */       }
/* 220 */       if (this.innerClass) {
/* 221 */         return this.prefix.packagePrefix();
/*     */       }
/* 223 */       return this.prefix.toString();
/*     */     } 
/* 225 */     int index = this.local.lastIndexOf('.');
/* 226 */     return (index == -1) ? null : this.local.substring(0, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DotName packagePrefixName() {
/* 238 */     if (this.componentized) {
/* 239 */       if (this.prefix == null) {
/* 240 */         return null;
/*     */       }
/* 242 */       if (this.innerClass) {
/* 243 */         return this.prefix.packagePrefixName();
/*     */       }
/* 245 */       return this.prefix;
/*     */     } 
/* 247 */     int index = this.local.lastIndexOf('.');
/* 248 */     return (index == -1) ? null : createSimple(this.local.substring(0, index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComponentized() {
/* 258 */     return this.componentized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInner() {
/* 280 */     return this.innerClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 289 */     return toString('.');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(char delim) {
/* 300 */     if (this.componentized) {
/* 301 */       StringBuilder builder = new StringBuilder();
/* 302 */       buildString(delim, builder);
/* 303 */       return builder.toString();
/*     */     } 
/* 305 */     return (delim == '.') ? this.local : this.local.replace('.', delim);
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildString(char delim, StringBuilder builder) {
/* 310 */     if (this.prefix != null) {
/* 311 */       this.prefix.buildString(delim, builder);
/* 312 */       builder.append(this.innerClass ? 36 : delim);
/*     */     } 
/* 314 */     builder.append(this.local);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 328 */     int hash = this.hash;
/* 329 */     if (hash != 0) {
/* 330 */       return hash;
/*     */     }
/*     */     
/* 333 */     if (this.prefix != null) {
/* 334 */       hash = this.prefix.hashCode() * 31 + (this.innerClass ? 36 : 46);
/*     */ 
/*     */       
/* 337 */       for (int i = 0; i < this.local.length(); i++) {
/* 338 */         hash = 31 * hash + this.local.charAt(i);
/*     */       }
/*     */     } else {
/* 341 */       hash = this.local.hashCode();
/*     */     } 
/*     */     
/* 344 */     return this.hash = hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 358 */     if (this == o) {
/* 359 */       return true;
/*     */     }
/* 361 */     if (!(o instanceof DotName)) {
/* 362 */       return false;
/*     */     }
/* 364 */     DotName other = (DotName)o;
/* 365 */     if (this.prefix == null && other.prefix == null) {
/* 366 */       return (this.local.equals(other.local) && this.innerClass == other.innerClass);
/*     */     }
/* 368 */     if (this.hash != 0 && other.hash != 0 && this.hash != other.hash) {
/* 369 */       return false;
/*     */     }
/* 371 */     return componentizedEquals(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean componentizedEquals(DotName a, DotName b) {
/* 376 */     if (a == null && b == null) {
/* 377 */       return true;
/*     */     }
/* 379 */     if (a == null || b == null) {
/* 380 */       return false;
/*     */     }
/* 382 */     if (a.innerClass == b.innerClass && a.local.equals(b.local)) {
/* 383 */       return componentizedEquals(a.prefix, b.prefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 398 */     String aLocal = a.local;
/* 399 */     String bLocal = b.local;
/* 400 */     int aPos = aLocal.length() - 1;
/* 401 */     int bPos = bLocal.length() - 1;
/* 402 */     while (a != null && b != null) {
/* 403 */       char aChar = (aPos >= 0) ? aLocal.charAt(aPos) : (a.innerClass ? '$' : '.');
/* 404 */       char bChar = (bPos >= 0) ? bLocal.charAt(bPos) : (b.innerClass ? '$' : '.');
/*     */       
/* 406 */       if (aChar != bChar) {
/* 407 */         return false;
/*     */       }
/*     */       
/* 410 */       aPos--;
/* 411 */       if (aPos < -1) {
/* 412 */         a = a.prefix;
/* 413 */         if (a != null) {
/* 414 */           aLocal = a.local;
/* 415 */           aPos = aLocal.length() - 1;
/*     */         } 
/*     */       } 
/*     */       
/* 419 */       bPos--;
/* 420 */       if (bPos < -1) {
/* 421 */         b = b.prefix;
/* 422 */         if (b != null) {
/* 423 */           bLocal = b.local;
/* 424 */           bPos = bLocal.length() - 1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 428 */     return (a == null && b == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(DotName other) {
/* 444 */     if (this == other) {
/* 445 */       return 0;
/*     */     }
/* 447 */     if (this.prefix == null && other.prefix == null) {
/* 448 */       if (this.innerClass != other.innerClass) {
/* 449 */         return this.innerClass ? -1 : 1;
/*     */       }
/* 451 */       return this.local.compareTo(other.local);
/*     */     } 
/*     */     
/* 454 */     return componentizedCompare(flatten(this), flatten(other));
/*     */   }
/*     */ 
/*     */   
/*     */   private static int componentizedCompare(DotName[] a, DotName[] b) {
/* 459 */     int aPos = 0;
/* 460 */     DotName aCur = a[aPos];
/*     */     
/* 462 */     int bPos = 0;
/* 463 */     DotName bCur = b[bPos];
/*     */ 
/*     */     
/* 466 */     while (aCur == bCur) {
/* 467 */       aPos++;
/* 468 */       aCur = a[aPos];
/*     */       
/* 470 */       bPos++;
/* 471 */       bCur = b[bPos];
/*     */     } 
/*     */     
/* 474 */     String aCurLocal = null;
/* 475 */     int aCurLocalLength = 0;
/* 476 */     int aCharPos = -1;
/* 477 */     if (aCur != null) {
/* 478 */       aCurLocal = aCur.local;
/* 479 */       aCurLocalLength = aCurLocal.length();
/*     */     } 
/*     */     
/* 482 */     String bCurLocal = null;
/* 483 */     int bCurLocalLength = 0;
/* 484 */     int bCharPos = -1;
/* 485 */     if (bCur != null) {
/* 486 */       bCurLocal = bCur.local;
/* 487 */       bCurLocalLength = bCurLocal.length();
/*     */     } 
/*     */ 
/*     */     
/* 491 */     while (aCur != null && bCur != null) {
/* 492 */       char aChar = (aCharPos >= 0) ? aCurLocal.charAt(aCharPos) : (aCur.innerClass ? '$' : '.');
/* 493 */       char bChar = (bCharPos >= 0) ? bCurLocal.charAt(bCharPos) : (bCur.innerClass ? '$' : '.');
/* 494 */       if (aChar != bChar) {
/* 495 */         return aChar - bChar;
/*     */       }
/*     */       
/* 498 */       aCharPos++;
/* 499 */       if (aCharPos == aCurLocalLength) {
/* 500 */         aPos++;
/* 501 */         aCharPos = -1;
/* 502 */         aCur = a[aPos];
/* 503 */         if (aCur != null) {
/* 504 */           aCurLocal = aCur.local;
/* 505 */           aCurLocalLength = aCurLocal.length();
/*     */         } 
/*     */       } 
/*     */       
/* 509 */       bCharPos++;
/* 510 */       if (bCharPos == bCurLocalLength) {
/* 511 */         bPos++;
/* 512 */         bCharPos = -1;
/* 513 */         bCur = b[bPos];
/* 514 */         if (bCur != null) {
/* 515 */           bCurLocal = bCur.local;
/* 516 */           bCurLocalLength = bCurLocal.length();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 522 */     if (aCur == null && bCur == null)
/*     */     {
/* 524 */       return 0; } 
/* 525 */     if (aCur != null)
/*     */     {
/* 527 */       return 1;
/*     */     }
/*     */     
/* 530 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static DotName[] flatten(DotName name) {
/* 535 */     int count = 0;
/*     */     
/* 537 */     DotName tmp = name;
/* 538 */     while (tmp != null) {
/* 539 */       count++;
/* 540 */       tmp = tmp.prefix;
/*     */     } 
/*     */ 
/*     */     
/* 544 */     DotName[] result = new DotName[count + 1];
/*     */     
/* 546 */     result[count] = null;
/*     */     
/* 548 */     DotName dotName1 = name;
/* 549 */     int index = count - 1;
/* 550 */     while (dotName1 != null) {
/* 551 */       result[index] = dotName1;
/* 552 */       index--;
/* 553 */       dotName1 = dotName1.prefix;
/*     */     } 
/*     */ 
/*     */     
/* 557 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\DotName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */