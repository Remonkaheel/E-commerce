/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PositionBasedTypeTarget
/*    */   extends TypeTarget
/*    */ {
/*    */   private final short position;
/*    */   
/*    */   PositionBasedTypeTarget(AnnotationTarget enclosingTarget, int position) {
/* 37 */     super(enclosingTarget);
/* 38 */     this.position = (short)position;
/*    */   }
/*    */   
/*    */   PositionBasedTypeTarget(AnnotationTarget enclosingTarget, Type target, int position) {
/* 42 */     super(enclosingTarget, target);
/* 43 */     this.position = (short)position;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int position() {
/* 52 */     return this.position & 0xFFFF;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\PositionBasedTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */