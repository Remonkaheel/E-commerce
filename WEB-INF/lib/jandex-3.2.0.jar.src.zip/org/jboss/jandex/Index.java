/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Index
/*     */   implements IndexView
/*     */ {
/*  67 */   private static final List<AnnotationInstance> EMPTY_ANNOTATION_LIST = Collections.emptyList();
/*  68 */   private static final List<ClassInfo> EMPTY_CLASSINFO_LIST = Collections.emptyList();
/*     */   
/*     */   final Map<DotName, AnnotationInstance[]> annotations;
/*     */   
/*     */   final Map<DotName, ClassInfo[]> subclasses;
/*     */   
/*     */   final Map<DotName, ClassInfo[]> subinterfaces;
/*     */   
/*     */   final Map<DotName, ClassInfo[]> implementors;
/*     */   
/*     */   final Map<DotName, ClassInfo> classes;
/*     */   final Map<DotName, ModuleInfo> modules;
/*     */   final Map<DotName, ClassInfo[]> users;
/*     */   volatile Map<DotName, Collection<ClassInfo>> classesInPackage;
/*     */   volatile Map<DotName, Set<DotName>> subpackages;
/*     */   
/*     */   Index(Map<DotName, AnnotationInstance[]> annotations, Map<DotName, ClassInfo[]> subclasses, Map<DotName, ClassInfo[]> subinterfaces, Map<DotName, ClassInfo[]> implementors, Map<DotName, ClassInfo> classes, Map<DotName, ModuleInfo> modules, Map<DotName, ClassInfo[]> users) {
/*  85 */     this.annotations = annotations;
/*  86 */     this.classes = classes;
/*  87 */     this.subclasses = subclasses;
/*  88 */     this.subinterfaces = subinterfaces;
/*  89 */     this.implementors = implementors;
/*  90 */     this.modules = modules;
/*  91 */     this.users = users;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index create(Map<DotName, List<AnnotationInstance>> annotations, Map<DotName, List<ClassInfo>> subclasses, Map<DotName, List<ClassInfo>> implementors, Map<DotName, ClassInfo> classes) {
/* 108 */     return new Index(Utils.unfold(annotations, AnnotationInstance.class), 
/* 109 */         Utils.unfold(subclasses, ClassInfo.class), 
/* 110 */         (Map)Collections.emptyMap(), 
/* 111 */         Utils.unfold(implementors, ClassInfo.class), classes, 
/*     */         
/* 113 */         Collections.emptyMap(), 
/* 114 */         (Map)Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index create(Map<DotName, List<AnnotationInstance>> annotations, Map<DotName, List<ClassInfo>> subclasses, Map<DotName, List<ClassInfo>> implementors, Map<DotName, ClassInfo> classes, Map<DotName, List<ClassInfo>> users) {
/* 132 */     return new Index(Utils.unfold(annotations, AnnotationInstance.class), 
/* 133 */         Utils.unfold(subclasses, ClassInfo.class), 
/* 134 */         (Map)Collections.emptyMap(), 
/* 135 */         Utils.unfold(implementors, ClassInfo.class), classes, 
/*     */         
/* 137 */         Collections.emptyMap(), 
/* 138 */         Utils.unfold(users, ClassInfo.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index create(Map<DotName, List<AnnotationInstance>> annotations, Map<DotName, List<ClassInfo>> subclasses, Map<DotName, List<ClassInfo>> subinterfaces, Map<DotName, List<ClassInfo>> implementors, Map<DotName, ClassInfo> classes, Map<DotName, List<ClassInfo>> users) {
/* 158 */     return new Index(Utils.unfold(annotations, AnnotationInstance.class), 
/* 159 */         Utils.unfold(subclasses, ClassInfo.class), 
/* 160 */         Utils.unfold(subinterfaces, ClassInfo.class), 
/* 161 */         Utils.unfold(implementors, ClassInfo.class), classes, 
/*     */         
/* 163 */         Collections.emptyMap(), 
/* 164 */         Utils.unfold(users, ClassInfo.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index create(Map<DotName, List<AnnotationInstance>> annotations, Map<DotName, List<ClassInfo>> subclasses, Map<DotName, List<ClassInfo>> subinterfaces, Map<DotName, List<ClassInfo>> implementors, Map<DotName, ClassInfo> classes, Map<DotName, ModuleInfo> modules, Map<DotName, List<ClassInfo>> users) {
/* 185 */     return new Index(Utils.unfold(annotations, AnnotationInstance.class), 
/* 186 */         Utils.unfold(subclasses, ClassInfo.class), 
/* 187 */         Utils.unfold(subinterfaces, ClassInfo.class), 
/* 188 */         Utils.unfold(implementors, ClassInfo.class), classes, modules, 
/*     */ 
/*     */         
/* 191 */         Utils.unfold(users, ClassInfo.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index of(Iterable<Class<?>> classes) throws IOException {
/* 201 */     Indexer indexer = new Indexer();
/*     */     
/* 203 */     for (Class<?> clazz : classes) {
/* 204 */       indexer.indexClass(clazz);
/*     */     }
/*     */     
/* 207 */     return indexer.complete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index of(Class<?>... classes) throws IOException {
/* 217 */     return of(Arrays.asList(classes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Index of(File... files) throws IOException {
/* 229 */     Indexer indexer = new Indexer();
/*     */     
/* 231 */     for (File file : files) {
/* 232 */       if (file == null)
/* 233 */         throw new IllegalArgumentException("File must not be null"); 
/* 234 */       if (file.isDirectory())
/* 235 */       { File[] classFiles = file.listFiles(new FileFilter()
/*     */             {
/*     */               public boolean accept(File pathname) {
/* 238 */                 return (pathname.isFile() && pathname.getName().endsWith(".class"));
/*     */               }
/*     */             });
/*     */         
/* 242 */         for (File classFile : classFiles) {
/* 243 */           InputStream in = new FileInputStream(classFile); 
/* 244 */           try { indexer.index(in);
/* 245 */             in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/*     */         }  }
/* 247 */       else if (file.isFile() && file.getName().endsWith(".class"))
/* 248 */       { InputStream in = new FileInputStream(file); 
/* 249 */         try { indexer.index(in);
/* 250 */           in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  }
/* 251 */       else if (file.isFile() && file.getName().endsWith(".jar"))
/* 252 */       { JarFile jarFile = new JarFile(file); 
/* 253 */         try { Enumeration<JarEntry> entries = jarFile.entries();
/* 254 */           while (entries.hasMoreElements()) {
/* 255 */             JarEntry entry = entries.nextElement();
/* 256 */             if (entry.getName().endsWith(".class")) {
/* 257 */               InputStream in = jarFile.getInputStream(entry); 
/* 258 */               try { indexer.index(in);
/* 259 */                 if (in != null) in.close();  } catch (Throwable throwable) { if (in != null)
/*     */                   try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/*     */             } 
/* 262 */           }  jarFile.close(); } catch (Throwable throwable) { try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */          }
/* 264 */       else { throw new IllegalArgumentException("Not a class file, JAR file or directory: " + file); }
/*     */     
/*     */     } 
/*     */     
/* 268 */     return indexer.complete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassInfo singleClass(Class<?> clazz) throws IOException {
/* 279 */     Indexer indexer = new Indexer();
/* 280 */     indexer.indexClass(clazz);
/* 281 */     Index index = indexer.complete();
/* 282 */     return index.getKnownClasses().iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassInfo singleClass(byte[] classData) throws IOException {
/* 293 */     return singleClass(new ByteArrayInputStream(classData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassInfo singleClass(InputStream classData) throws IOException {
/* 305 */     Indexer indexer = new Indexer();
/* 306 */     indexer.index(classData);
/* 307 */     Index index = indexer.complete();
/* 308 */     return index.getKnownClasses().iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> getAnnotations(DotName annotationName) {
/* 318 */     AnnotationInstance[] list = this.annotations.get(annotationName);
/* 319 */     return (list == null) ? EMPTY_ANNOTATION_LIST : new ImmutableArrayList<>(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<AnnotationInstance> getAnnotationsWithRepeatable(DotName annotationName, IndexView index) {
/* 327 */     ClassInfo annotationClass = index.getClassByName(annotationName);
/* 328 */     if (annotationClass == null) {
/* 329 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + annotationName);
/*     */     }
/* 331 */     if (!annotationClass.isAnnotation()) {
/* 332 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 334 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 335 */     if (repeatable == null)
/*     */     {
/* 337 */       return getAnnotations(annotationName);
/*     */     }
/* 339 */     Type containing = repeatable.value().asClass();
/* 340 */     return getRepeatableAnnotations(annotationName, containing.name());
/*     */   }
/*     */   
/*     */   private Collection<AnnotationInstance> getRepeatableAnnotations(DotName annotationName, DotName containingAnnotationName) {
/* 344 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 345 */     instances.addAll(getAnnotations(annotationName));
/* 346 */     for (AnnotationInstance containingInstance : getAnnotations(containingAnnotationName)) {
/* 347 */       for (AnnotationInstance nestedInstance : containingInstance.value().asNestedArray())
/*     */       {
/* 349 */         instances.add(AnnotationInstance.create(nestedInstance, containingInstance.target()));
/*     */       }
/*     */     } 
/* 352 */     return instances;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ClassInfo> getKnownDirectSubclasses(DotName className) {
/* 360 */     ClassInfo[] list = this.subclasses.get(className);
/* 361 */     return (list == null) ? EMPTY_CLASSINFO_LIST : new ImmutableArrayList<>(list);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getAllKnownSubclasses(DotName className) {
/* 366 */     Set<ClassInfo> allKnown = new HashSet<>();
/* 367 */     Set<DotName> processedClasses = new HashSet<>();
/* 368 */     getAllKnownSubClasses(className, allKnown, processedClasses);
/* 369 */     return allKnown;
/*     */   }
/*     */   
/*     */   private void getAllKnownSubClasses(DotName className, Set<ClassInfo> allKnown, Set<DotName> processedClasses) {
/* 373 */     Set<DotName> subClassesToProcess = new HashSet<>();
/* 374 */     subClassesToProcess.add(className);
/* 375 */     while (!subClassesToProcess.isEmpty()) {
/* 376 */       Iterator<DotName> toProcess = subClassesToProcess.iterator();
/* 377 */       DotName name = toProcess.next();
/* 378 */       toProcess.remove();
/* 379 */       processedClasses.add(name);
/* 380 */       getAllKnownSubClasses(name, allKnown, subClassesToProcess, processedClasses);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void getAllKnownSubClasses(DotName name, Set<ClassInfo> allKnown, Set<DotName> subClassesToProcess, Set<DotName> processedClasses) {
/* 386 */     List<ClassInfo> list = getKnownDirectSubclasses(name);
/* 387 */     if (list != null) {
/* 388 */       for (ClassInfo clazz : list) {
/* 389 */         DotName className = clazz.name();
/* 390 */         if (!processedClasses.contains(className)) {
/* 391 */           allKnown.add(clazz);
/* 392 */           subClassesToProcess.add(className);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ClassInfo> getKnownDirectSubinterfaces(DotName interfaceName) {
/* 403 */     ClassInfo[] list = this.subinterfaces.get(interfaceName);
/* 404 */     return (list == null) ? EMPTY_CLASSINFO_LIST : new ImmutableArrayList<>(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getAllKnownSubinterfaces(DotName interfaceName) {
/* 412 */     Set<ClassInfo> result = new HashSet<>();
/*     */     
/* 414 */     Queue<DotName> workQueue = new ArrayDeque<>();
/* 415 */     Set<DotName> alreadyProcessed = new HashSet<>();
/*     */     
/* 417 */     workQueue.add(interfaceName);
/* 418 */     while (!workQueue.isEmpty()) {
/* 419 */       DotName iface = workQueue.remove();
/* 420 */       if (!alreadyProcessed.add(iface)) {
/*     */         continue;
/*     */       }
/*     */       
/* 424 */       for (ClassInfo directSubinterface : getKnownDirectSubinterfaces(iface)) {
/* 425 */         result.add(directSubinterface);
/* 426 */         workQueue.add(directSubinterface.name());
/*     */       } 
/*     */     } 
/*     */     
/* 430 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ClassInfo> getKnownDirectImplementors(DotName interfaceName) {
/* 438 */     ClassInfo[] list = this.implementors.get(interfaceName);
/* 439 */     return (list == null) ? EMPTY_CLASSINFO_LIST : new ImmutableArrayList<>(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ClassInfo> getAllKnownImplementors(DotName interfaceName) {
/* 447 */     Set<ClassInfo> allKnown = new HashSet<>();
/* 448 */     Set<DotName> subInterfacesToProcess = new HashSet<>();
/* 449 */     Set<DotName> processedClasses = new HashSet<>();
/* 450 */     subInterfacesToProcess.add(interfaceName);
/* 451 */     while (!subInterfacesToProcess.isEmpty()) {
/* 452 */       Iterator<DotName> toProcess = subInterfacesToProcess.iterator();
/* 453 */       DotName name = toProcess.next();
/* 454 */       toProcess.remove();
/* 455 */       processedClasses.add(name);
/* 456 */       getKnownImplementors(name, allKnown, subInterfacesToProcess, processedClasses);
/*     */     } 
/* 458 */     return allKnown;
/*     */   }
/*     */ 
/*     */   
/*     */   private void getKnownImplementors(DotName name, Set<ClassInfo> allKnown, Set<DotName> subInterfacesToProcess, Set<DotName> processedClasses) {
/* 463 */     List<ClassInfo> list = getKnownDirectImplementors(name);
/* 464 */     if (list != null) {
/* 465 */       for (ClassInfo clazz : list) {
/* 466 */         DotName className = clazz.name();
/* 467 */         if (!processedClasses.contains(className)) {
/* 468 */           if (Modifier.isInterface(clazz.flags())) {
/* 469 */             subInterfacesToProcess.add(className); continue;
/*     */           } 
/* 471 */           if (!allKnown.contains(clazz)) {
/* 472 */             allKnown.add(clazz);
/* 473 */             processedClasses.add(className);
/* 474 */             getAllKnownSubClasses(className, allKnown, processedClasses);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassInfo getClassByName(DotName className) {
/* 487 */     return this.classes.get(className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownClasses() {
/* 495 */     return this.classes.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ModuleInfo> getKnownModules() {
/* 503 */     return this.modules.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleInfo getModuleByName(DotName moduleName) {
/* 511 */     return this.modules.get(moduleName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ClassInfo> getKnownUsers(DotName className) {
/* 519 */     ClassInfo[] ret = this.users.get(className);
/* 520 */     return (ret == null) ? EMPTY_CLASSINFO_LIST : new ImmutableArrayList<>(ret);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getClassesInPackage(DotName packageName) {
/* 528 */     if (this.classesInPackage == null) {
/* 529 */       synchronized (this) {
/* 530 */         if (this.classesInPackage == null) {
/* 531 */           Map<DotName, Collection<ClassInfo>> map = new HashMap<>();
/* 532 */           for (ClassInfo clazz : this.classes.values()) {
/* 533 */             DotName pkg = clazz.name().packagePrefixName();
/* 534 */             ((Collection<ClassInfo>)map.computeIfAbsent(pkg, ignored -> new ArrayList())).add(clazz);
/*     */           } 
/* 536 */           this.classesInPackage = Collections.unmodifiableMap(map);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 541 */     Collection<ClassInfo> result = this.classesInPackage.get(packageName);
/* 542 */     return (result != null) ? Collections.<ClassInfo>unmodifiableCollection(result) : EMPTY_CLASSINFO_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<DotName> getSubpackages(DotName packageName) {
/* 550 */     if (this.subpackages == null) {
/* 551 */       synchronized (this) {
/* 552 */         if (this.subpackages == null) {
/* 553 */           Map<DotName, Set<DotName>> map = new HashMap<>();
/* 554 */           for (ClassInfo clazz : this.classes.values()) {
/* 555 */             DotName pkg = clazz.name().packagePrefixName();
/* 556 */             while (pkg != null) {
/* 557 */               DotName superPkg = pkg.packagePrefixName();
/* 558 */               if (superPkg != null) {
/* 559 */                 ((Set<DotName>)map.computeIfAbsent(superPkg, ignored -> new HashSet())).add(pkg);
/*     */               }
/* 561 */               pkg = superPkg;
/*     */             } 
/*     */           } 
/* 564 */           this.subpackages = Collections.unmodifiableMap(map);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 569 */     Set<DotName> result = this.subpackages.get(packageName);
/* 570 */     return (result != null) ? Collections.<DotName>unmodifiableSet(result) : Collections.<DotName>emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printAnnotations() {
/* 579 */     System.out.println("Annotations:");
/* 580 */     for (Map.Entry<DotName, AnnotationInstance[]> e : this.annotations.entrySet()) {
/* 581 */       System.out.println((new StringBuilder()).append(e.getKey()).append(":").toString());
/* 582 */       for (AnnotationInstance instance : (AnnotationInstance[])e.getValue()) {
/* 583 */         AnnotationTarget target = instance.target();
/*     */         
/* 585 */         if (target instanceof ClassInfo) {
/* 586 */           System.out.println("    Class: " + target);
/* 587 */         } else if (target instanceof FieldInfo) {
/* 588 */           System.out.println("    Field: " + target);
/* 589 */         } else if (target instanceof MethodInfo) {
/* 590 */           System.out.println("    Method: " + target);
/* 591 */         } else if (target instanceof MethodParameterInfo) {
/* 592 */           System.out.println("    Parameter: " + target);
/*     */         } 
/*     */         
/* 595 */         List<AnnotationValue> values = instance.values();
/* 596 */         if (values.size() >= 1) {
/*     */ 
/*     */           
/* 599 */           StringBuilder builder = new StringBuilder("        (");
/*     */           
/* 601 */           for (int i = 0; i < values.size(); i++) {
/* 602 */             builder.append(values.get(i));
/* 603 */             if (i < values.size() - 1)
/* 604 */               builder.append(", "); 
/*     */           } 
/* 606 */           builder.append(')');
/* 607 */           System.out.println(builder.toString());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void printSubclasses() {
/* 616 */     System.out.println("Subclasses:");
/* 617 */     for (Map.Entry<DotName, ClassInfo[]> entry : this.subclasses.entrySet()) {
/* 618 */       System.out.println((new StringBuilder()).append(entry.getKey()).append(":").toString());
/* 619 */       for (ClassInfo clazz : (ClassInfo[])entry.getValue())
/* 620 */         System.out.println("    " + clazz.name()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Index.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */