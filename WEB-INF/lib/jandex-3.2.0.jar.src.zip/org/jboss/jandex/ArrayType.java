/*     */ package org.jboss.jandex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ArrayType
/*     */   extends Type
/*     */ {
/*     */   private final Type constituent;
/*     */   private final int dimensions;
/*     */   private int hash;
/*     */   
/*     */   public static ArrayType create(Type constituent, int dimensions) {
/*  65 */     return new ArrayType(constituent, dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(Type constituent, int dimensions) {
/*  79 */     return new Builder(constituent, dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayType(Type constituent, int dimensions) {
/*  87 */     this(constituent, dimensions, (AnnotationInstance[])null);
/*     */   }
/*     */   
/*     */   ArrayType(Type constituent, int dimensions, AnnotationInstance[] annotations) {
/*  91 */     super(DotName.OBJECT_NAME, annotations);
/*  92 */     this.dimensions = dimensions;
/*  93 */     this.constituent = constituent;
/*  94 */     if (dimensions < 1) {
/*  95 */       throw new IllegalArgumentException("Number of dimensions of an array type must be >= 1");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Type component() {
/* 109 */     return this.constituent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type constituent() {
/* 126 */     return this.constituent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type elementType() {
/* 139 */     Type element = this.constituent;
/* 140 */     while (element.kind() == Type.Kind.ARRAY) {
/* 141 */       element = (element.asArrayType()).constituent;
/*     */     }
/* 143 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type componentType() {
/* 155 */     if (this.dimensions == 1) {
/* 156 */       return this.constituent;
/*     */     }
/* 158 */     return new ArrayType(this.constituent, this.dimensions - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int dimensions() {
/* 179 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int deepDimensions() {
/* 194 */     int result = this.dimensions;
/* 195 */     Type constituent = this.constituent;
/* 196 */     while (constituent.kind() == Type.Kind.ARRAY) {
/* 197 */       result += (constituent.asArrayType()).dimensions;
/* 198 */       constituent = (constituent.asArrayType()).constituent;
/*     */     } 
/* 200 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public DotName name() {
/* 205 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 207 */     Type type = this;
/* 208 */     while (type.kind() == Type.Kind.ARRAY) {
/* 209 */       int dimensions = (type.asArrayType()).dimensions;
/* 210 */       while (dimensions-- > 0) {
/* 211 */         builder.append('[');
/*     */       }
/* 213 */       type = (type.asArrayType()).constituent;
/*     */     } 
/*     */ 
/*     */     
/* 217 */     if (type.kind() == Type.Kind.PRIMITIVE) {
/* 218 */       builder.append(type.asPrimitiveType().toCode());
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 223 */       builder.append('L').append(type.name().toString()).append(';');
/*     */     } 
/*     */     
/* 226 */     return DotName.createSimple(builder.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 231 */     return Type.Kind.ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayType asArrayType() {
/* 236 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 241 */     return new ArrayType(this.constituent, this.dimensions, newAnnotations);
/*     */   }
/*     */   
/*     */   Type copyType(Type component, int dimensions) {
/* 245 */     return new ArrayType(component, dimensions, annotationArray());
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(boolean simple) {
/* 250 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 252 */     appendRootComponent(builder, true);
/* 253 */     appendArraySyntax(builder);
/*     */     
/* 255 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private void appendRootComponent(StringBuilder builder, boolean simple) {
/* 259 */     if (this.constituent.kind() == Type.Kind.ARRAY) {
/* 260 */       this.constituent.asArrayType().appendRootComponent(builder, simple);
/*     */     } else {
/* 262 */       builder.append(this.constituent.toString(simple));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void appendArraySyntax(StringBuilder builder) {
/* 267 */     if ((annotationArray()).length > 0) {
/* 268 */       builder.append(' ');
/* 269 */       appendAnnotations(builder);
/*     */     } 
/* 271 */     for (int i = 0; i < this.dimensions; i++) {
/* 272 */       builder.append("[]");
/*     */     }
/* 274 */     if (this.constituent.kind() == Type.Kind.ARRAY) {
/* 275 */       this.constituent.asArrayType().appendArraySyntax(builder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 281 */     if (this == o) {
/* 282 */       return true;
/*     */     }
/*     */     
/* 285 */     if (!(o instanceof ArrayType)) {
/* 286 */       return false;
/*     */     }
/* 288 */     ArrayType arrayType = (ArrayType)o;
/*     */     
/* 290 */     return (super.equals(o) && this.dimensions == arrayType.dimensions && this.constituent.equals(arrayType.constituent));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 295 */     int hash = this.hash;
/* 296 */     if (hash != 0) {
/* 297 */       return hash;
/*     */     }
/*     */     
/* 300 */     hash = super.hashCode();
/* 301 */     hash = 31 * hash + this.constituent.hashCode();
/* 302 */     hash = 31 * hash + this.dimensions;
/* 303 */     return this.hash = hash;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 308 */     if (this == o) {
/* 309 */       return true;
/*     */     }
/*     */     
/* 312 */     if (!(o instanceof ArrayType)) {
/* 313 */       return false;
/*     */     }
/* 315 */     ArrayType arrayType = (ArrayType)o;
/*     */     
/* 317 */     return (super.internEquals(o) && this.dimensions == arrayType.dimensions && this.constituent.internEquals(arrayType.constituent));
/*     */   }
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 322 */     int hash = super.internHashCode();
/* 323 */     hash = 31 * hash + this.constituent.internHashCode();
/* 324 */     hash = 31 * hash + this.dimensions;
/* 325 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */     extends Type.Builder<Builder>
/*     */   {
/*     */     private final Type constituent;
/*     */     
/*     */     private final int dimensions;
/*     */ 
/*     */     
/*     */     Builder(Type constituent, int dimensions) {
/* 339 */       super(DotName.OBJECT_NAME);
/* 340 */       this.constituent = constituent;
/* 341 */       this.dimensions = dimensions;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayType build() {
/* 350 */       return new ArrayType(this.constituent, this.dimensions, annotationsArray());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\ArrayType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */