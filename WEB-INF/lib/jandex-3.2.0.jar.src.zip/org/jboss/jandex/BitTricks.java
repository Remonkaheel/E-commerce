/*    */ package org.jboss.jandex;
/*    */ 
/*    */ class BitTricks
/*    */ {
/*    */   static boolean isAsciiOnly(byte[] chars, int off, int len) {
/*  6 */     int longRounds = len >>> 3;
/*  7 */     for (int i = 0; i < longRounds; i++) {
/*  8 */       long batch = chars[off] << 56L | chars[off + 1] << 48L | chars[off + 2] << 40L | chars[off + 3] << 32L | (chars[off + 4] << 24) | (chars[off + 5] << 16) | (chars[off + 6] << 8) | chars[off + 7];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 17 */       if ((batch & 0x8080808080808080L) != 0L) {
/* 18 */         return false;
/*    */       }
/* 20 */       off += 8;
/*    */     } 
/*    */     
/* 23 */     int byteRounds = len & 0x7;
/* 24 */     if (byteRounds > 0) {
/* 25 */       for (int j = 0; j < byteRounds; j++) {
/* 26 */         if ((chars[off + j] & 0x80) != 0) {
/* 27 */           return false;
/*    */         }
/*    */       } 
/*    */     }
/*    */     
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\BitTricks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */