/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrimitiveType
/*     */   extends Type
/*     */ {
/*  37 */   public static final PrimitiveType BYTE = new PrimitiveType(Primitive.BYTE);
/*  38 */   public static final PrimitiveType CHAR = new PrimitiveType(Primitive.CHAR);
/*  39 */   public static final PrimitiveType DOUBLE = new PrimitiveType(Primitive.DOUBLE);
/*  40 */   public static final PrimitiveType FLOAT = new PrimitiveType(Primitive.FLOAT);
/*  41 */   public static final PrimitiveType INT = new PrimitiveType(Primitive.INT);
/*  42 */   public static final PrimitiveType LONG = new PrimitiveType(Primitive.LONG);
/*  43 */   public static final PrimitiveType SHORT = new PrimitiveType(Primitive.SHORT);
/*  44 */   public static final PrimitiveType BOOLEAN = new PrimitiveType(Primitive.BOOLEAN);
/*     */   
/*  46 */   private static final Map<String, PrimitiveType> reverseMap = new HashMap<>();
/*     */   
/*  48 */   private static final Map<Primitive, ClassType> boxingMap = new HashMap<>();
/*  49 */   private static final Map<DotName, PrimitiveType> unboxingMap = new HashMap<>();
/*     */   
/*     */   static {
/*  52 */     reverseMap.put("byte", BYTE);
/*  53 */     reverseMap.put("char", CHAR);
/*  54 */     reverseMap.put("double", DOUBLE);
/*  55 */     reverseMap.put("float", FLOAT);
/*  56 */     reverseMap.put("int", INT);
/*  57 */     reverseMap.put("long", LONG);
/*  58 */     reverseMap.put("short", SHORT);
/*  59 */     reverseMap.put("boolean", BOOLEAN);
/*     */     
/*  61 */     boxingMap.put(Primitive.BYTE, ClassType.BYTE_CLASS);
/*  62 */     boxingMap.put(Primitive.CHAR, ClassType.CHARACTER_CLASS);
/*  63 */     boxingMap.put(Primitive.DOUBLE, ClassType.DOUBLE_CLASS);
/*  64 */     boxingMap.put(Primitive.FLOAT, ClassType.FLOAT_CLASS);
/*  65 */     boxingMap.put(Primitive.INT, ClassType.INTEGER_CLASS);
/*  66 */     boxingMap.put(Primitive.LONG, ClassType.LONG_CLASS);
/*  67 */     boxingMap.put(Primitive.SHORT, ClassType.SHORT_CLASS);
/*  68 */     boxingMap.put(Primitive.BOOLEAN, ClassType.BOOLEAN_CLASS);
/*     */     
/*  70 */     unboxingMap.put(ClassType.BYTE_CLASS.name(), BYTE);
/*  71 */     unboxingMap.put(ClassType.CHARACTER_CLASS.name(), CHAR);
/*  72 */     unboxingMap.put(ClassType.DOUBLE_CLASS.name(), DOUBLE);
/*  73 */     unboxingMap.put(ClassType.FLOAT_CLASS.name(), FLOAT);
/*  74 */     unboxingMap.put(ClassType.INTEGER_CLASS.name(), INT);
/*  75 */     unboxingMap.put(ClassType.LONG_CLASS.name(), LONG);
/*  76 */     unboxingMap.put(ClassType.SHORT_CLASS.name(), SHORT);
/*  77 */     unboxingMap.put(ClassType.BOOLEAN_CLASS.name(), BOOLEAN);
/*     */   }
/*     */ 
/*     */   
/*     */   private final Primitive primitive;
/*     */   
/*     */   public enum Primitive
/*     */   {
/*  85 */     BYTE,
/*     */     
/*  87 */     CHAR,
/*     */     
/*  89 */     DOUBLE,
/*     */     
/*  91 */     FLOAT,
/*     */     
/*  93 */     INT,
/*     */     
/*  95 */     LONG,
/*     */     
/*  97 */     SHORT,
/*     */     
/*  99 */     BOOLEAN;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private PrimitiveType(Primitive primitive) {
/* 105 */     this(primitive, null);
/*     */   }
/*     */   
/*     */   private PrimitiveType(Primitive primitive, AnnotationInstance[] annotations) {
/* 109 */     super(new DotName(null, primitive.name().toLowerCase(Locale.ENGLISH), true, false), annotations);
/* 110 */     this.primitive = primitive;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 115 */     return Type.Kind.PRIMITIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Primitive primitive() {
/* 124 */     return this.primitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassType box(PrimitiveType primitiveType) {
/* 136 */     if (primitiveType == null) {
/* 137 */       return null;
/*     */     }
/* 139 */     return boxingMap.get(primitiveType.primitive);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrimitiveType unbox(ClassType classType) {
/* 152 */     if (classType == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     return unboxingMap.get(classType.name());
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveType asPrimitiveType() {
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 165 */     return new PrimitiveType(this.primitive, newAnnotations);
/*     */   }
/*     */   
/*     */   char toCode() {
/* 169 */     Primitive primitive = this.primitive;
/* 170 */     if (primitive == Primitive.BYTE)
/* 171 */       return 'B'; 
/* 172 */     if (primitive == Primitive.CHAR)
/* 173 */       return 'C'; 
/* 174 */     if (primitive == Primitive.DOUBLE)
/* 175 */       return 'D'; 
/* 176 */     if (primitive == Primitive.FLOAT)
/* 177 */       return 'F'; 
/* 178 */     if (primitive == Primitive.INT)
/* 179 */       return 'I'; 
/* 180 */     if (primitive == Primitive.LONG)
/* 181 */       return 'J'; 
/* 182 */     if (primitive == Primitive.SHORT) {
/* 183 */       return 'S';
/*     */     }
/*     */ 
/*     */     
/* 187 */     return 'Z';
/*     */   }
/*     */   
/*     */   static PrimitiveType decode(String name) {
/* 191 */     return reverseMap.get(name);
/*     */   }
/*     */   
/*     */   static PrimitiveType decode(char c) {
/* 195 */     switch (c) {
/*     */       case 'B':
/* 197 */         return BYTE;
/*     */       case 'C':
/* 199 */         return CHAR;
/*     */       case 'D':
/* 201 */         return DOUBLE;
/*     */       case 'F':
/* 203 */         return FLOAT;
/*     */       case 'I':
/* 205 */         return INT;
/*     */       case 'J':
/* 207 */         return LONG;
/*     */       case 'S':
/* 209 */         return SHORT;
/*     */       case 'Z':
/* 211 */         return BOOLEAN;
/*     */     } 
/* 213 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static PrimitiveType fromOridinal(int ordinal) {
/* 218 */     switch (ordinal) {
/*     */       case 0:
/* 220 */         return BYTE;
/*     */       case 1:
/* 222 */         return CHAR;
/*     */       case 2:
/* 224 */         return DOUBLE;
/*     */       case 3:
/* 226 */         return FLOAT;
/*     */       case 4:
/* 228 */         return INT;
/*     */       case 5:
/* 230 */         return LONG;
/*     */       case 6:
/* 232 */         return SHORT;
/*     */       case 7:
/* 234 */         return BOOLEAN;
/*     */     } 
/* 236 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 242 */     if (this == o) {
/* 243 */       return true;
/*     */     }
/*     */     
/* 246 */     if (!(o instanceof PrimitiveType)) {
/* 247 */       return false;
/*     */     }
/*     */     
/* 250 */     PrimitiveType that = (PrimitiveType)o;
/* 251 */     return (super.equals(o) && this.primitive == that.primitive);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 256 */     int result = super.hashCode();
/* 257 */     result = 31 * result + this.primitive.name().hashCode();
/* 258 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 263 */     if (this == o) {
/* 264 */       return true;
/*     */     }
/*     */     
/* 267 */     if (!(o instanceof PrimitiveType)) {
/* 268 */       return false;
/*     */     }
/*     */     
/* 271 */     PrimitiveType that = (PrimitiveType)o;
/* 272 */     return (super.internEquals(o) && this.primitive == that.primitive);
/*     */   }
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 277 */     int result = super.internHashCode();
/* 278 */     result = 31 * result + this.primitive.name().hashCode();
/* 279 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\PrimitiveType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */