/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackedIndex
/*     */   implements IndexView
/*     */ {
/*     */   private final IndexView[] stack;
/*     */   
/*     */   private StackedIndex(IndexView[] stack) {
/*  25 */     this.stack = stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackedIndex create(List<IndexView> indexes) {
/*  36 */     return create(indexes.<IndexView>toArray(new IndexView[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackedIndex create(IndexView... indexes) {
/*  47 */     Objects.requireNonNull(indexes);
/*     */     
/*  49 */     List<IndexView> stack = new ArrayList<>();
/*  50 */     for (int i = indexes.length - 1; i >= 0; i--) {
/*  51 */       IndexView index = indexes[i];
/*  52 */       Objects.requireNonNull(index);
/*  53 */       if (index instanceof StackedIndex) {
/*  54 */         Collections.addAll(stack, ((StackedIndex)index).stack);
/*     */       } else {
/*  56 */         stack.add(index);
/*     */       } 
/*     */     } 
/*  59 */     return new StackedIndex(stack.<IndexView>toArray(new IndexView[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackedIndex pushIndex(IndexView index) {
/*     */     IndexView[] newStack;
/*  71 */     if (index instanceof StackedIndex) {
/*  72 */       IndexView[] indexes = ((StackedIndex)index).stack;
/*  73 */       newStack = new IndexView[indexes.length + this.stack.length];
/*  74 */       System.arraycopy(indexes, 0, newStack, 0, indexes.length);
/*  75 */       System.arraycopy(this.stack, 0, newStack, indexes.length, this.stack.length);
/*     */     } else {
/*  77 */       newStack = new IndexView[1 + this.stack.length];
/*  78 */       newStack[0] = index;
/*  79 */       System.arraycopy(this.stack, 0, newStack, 1, this.stack.length);
/*     */     } 
/*  81 */     return new StackedIndex(newStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownClasses() {
/*  88 */     List<ClassInfo> result = new ArrayList<>();
/*  89 */     Set<DotName> seen = new HashSet<>();
/*  90 */     for (IndexView idx : this.stack) {
/*  91 */       for (ClassInfo clazz : idx.getKnownClasses()) {
/*  92 */         if (seen.add(clazz.name())) {
/*  93 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/*  97 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassInfo getClassByName(DotName className) {
/* 102 */     for (IndexView index : this.stack) {
/* 103 */       ClassInfo result = index.getClassByName(className);
/* 104 */       if (result != null) {
/* 105 */         return result;
/*     */       }
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownDirectSubclasses(DotName className) {
/* 113 */     List<ClassInfo> result = new ArrayList<>();
/* 114 */     Set<DotName> seen = new HashSet<>();
/* 115 */     for (IndexView idx : this.stack) {
/* 116 */       for (ClassInfo clazz : idx.getKnownDirectSubclasses(className)) {
/* 117 */         if (seen.add(clazz.name())) {
/* 118 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/* 122 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getAllKnownSubclasses(DotName className) {
/* 127 */     List<ClassInfo> result = new ArrayList<>();
/*     */     
/* 129 */     Queue<DotName> worklist = new ArrayDeque<>();
/* 130 */     Set<DotName> seen = new HashSet<>();
/*     */     
/* 132 */     worklist.add(className);
/* 133 */     while (!worklist.isEmpty()) {
/* 134 */       DotName cls = worklist.remove();
/* 135 */       for (IndexView index : this.stack) {
/* 136 */         for (ClassInfo directSubclass : index.getKnownDirectSubclasses(cls)) {
/* 137 */           worklist.add(directSubclass.name());
/* 138 */           if (seen.add(directSubclass.name())) {
/* 139 */             result.add(directSubclass);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownDirectSubinterfaces(DotName interfaceName) {
/* 150 */     List<ClassInfo> result = new ArrayList<>();
/* 151 */     Set<DotName> seen = new HashSet<>();
/* 152 */     for (IndexView idx : this.stack) {
/* 153 */       for (ClassInfo clazz : idx.getKnownDirectSubinterfaces(interfaceName)) {
/* 154 */         if (seen.add(clazz.name())) {
/* 155 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/* 159 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getAllKnownSubinterfaces(DotName interfaceName) {
/* 164 */     List<ClassInfo> result = new ArrayList<>();
/*     */     
/* 166 */     Queue<DotName> worklist = new ArrayDeque<>();
/* 167 */     Set<DotName> seen = new HashSet<>();
/*     */     
/* 169 */     worklist.add(interfaceName);
/* 170 */     while (!worklist.isEmpty()) {
/* 171 */       DotName iface = worklist.remove();
/* 172 */       for (IndexView index : this.stack) {
/* 173 */         for (ClassInfo directSubinterface : index.getKnownDirectSubinterfaces(iface)) {
/* 174 */           worklist.add(directSubinterface.name());
/* 175 */           if (seen.add(directSubinterface.name())) {
/* 176 */             result.add(directSubinterface);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownDirectImplementors(DotName interfaceName) {
/* 187 */     List<ClassInfo> result = new ArrayList<>();
/* 188 */     Set<DotName> seen = new HashSet<>();
/* 189 */     for (IndexView idx : this.stack) {
/* 190 */       for (ClassInfo clazz : idx.getKnownDirectImplementors(interfaceName)) {
/* 191 */         if (seen.add(clazz.name())) {
/* 192 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/* 196 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getAllKnownImplementors(DotName interfaceName) {
/* 201 */     List<ClassInfo> result = new ArrayList<>();
/*     */     
/* 203 */     Queue<DotName> worklist = new ArrayDeque<>();
/* 204 */     Set<DotName> seen = new HashSet<>();
/*     */     
/* 206 */     worklist.add(interfaceName);
/* 207 */     while (!worklist.isEmpty()) {
/* 208 */       DotName iface = worklist.remove();
/* 209 */       for (IndexView index : this.stack) {
/* 210 */         for (ClassInfo directImplementor : index.getKnownDirectImplementors(iface)) {
/* 211 */           if (directImplementor.isInterface()) {
/* 212 */             worklist.add(directImplementor.name()); continue;
/* 213 */           }  if (seen.add(directImplementor.name())) {
/* 214 */             result.add(directImplementor);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 220 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<AnnotationInstance> getAnnotations(DotName annotationName) {
/* 225 */     List<AnnotationInstance> result = new ArrayList<>();
/* 226 */     Set<DotName> seen = new HashSet<>();
/* 227 */     Set<DotName> seenInThisIteration = new HashSet<>();
/* 228 */     for (IndexView idx : this.stack) {
/* 229 */       for (AnnotationInstance annotation : idx.getAnnotations(annotationName)) {
/* 230 */         DotName inClass = nameOfDeclaringClass(annotation.target());
/* 231 */         if (inClass == null) {
/*     */           continue;
/*     */         }
/* 234 */         if (!seen.contains(inClass)) {
/* 235 */           result.add(annotation);
/* 236 */           seenInThisIteration.add(inClass);
/*     */         } 
/*     */       } 
/* 239 */       seen.addAll(seenInThisIteration);
/* 240 */       seenInThisIteration.clear();
/*     */     } 
/* 242 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<AnnotationInstance> getAnnotationsWithRepeatable(DotName annotationName, IndexView index) {
/* 247 */     List<AnnotationInstance> result = new ArrayList<>();
/* 248 */     Set<DotName> seen = new HashSet<>();
/* 249 */     Set<DotName> seenInThisIteration = new HashSet<>();
/* 250 */     for (IndexView idx : this.stack) {
/* 251 */       for (AnnotationInstance annotation : idx.getAnnotationsWithRepeatable(annotationName, index)) {
/* 252 */         DotName inClass = nameOfDeclaringClass(annotation.target());
/* 253 */         if (inClass == null) {
/*     */           continue;
/*     */         }
/* 256 */         if (!seen.contains(inClass)) {
/* 257 */           result.add(annotation);
/* 258 */           seenInThisIteration.add(inClass);
/*     */         } 
/*     */       } 
/* 261 */       seen.addAll(seenInThisIteration);
/* 262 */       seenInThisIteration.clear();
/*     */     } 
/* 264 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */   
/*     */   private static DotName nameOfDeclaringClass(AnnotationTarget target) {
/* 268 */     if (target == null)
/* 269 */       return null; 
/* 270 */     if (target.kind() == AnnotationTarget.Kind.CLASS)
/* 271 */       return target.asClass().name(); 
/* 272 */     if (target.kind() == AnnotationTarget.Kind.METHOD)
/* 273 */       return target.asMethod().declaringClass().name(); 
/* 274 */     if (target.kind() == AnnotationTarget.Kind.METHOD_PARAMETER)
/* 275 */       return target.asMethodParameter().method().declaringClass().name(); 
/* 276 */     if (target.kind() == AnnotationTarget.Kind.FIELD)
/* 277 */       return target.asField().declaringClass().name(); 
/* 278 */     if (target.kind() == AnnotationTarget.Kind.RECORD_COMPONENT)
/* 279 */       return target.asRecordComponent().declaringClass().name(); 
/* 280 */     if (target.kind() == AnnotationTarget.Kind.TYPE) {
/* 281 */       return nameOfDeclaringClass(target.asType().enclosingTarget());
/*     */     }
/* 283 */     throw new IllegalArgumentException("Unknown annotation target: " + target);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ModuleInfo> getKnownModules() {
/* 289 */     List<ModuleInfo> result = new ArrayList<>();
/* 290 */     Set<DotName> seen = new HashSet<>();
/* 291 */     for (IndexView idx : this.stack) {
/* 292 */       for (ModuleInfo module : idx.getKnownModules()) {
/* 293 */         if (seen.add(module.name())) {
/* 294 */           result.add(module);
/*     */         }
/*     */       } 
/*     */     } 
/* 298 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleInfo getModuleByName(DotName moduleName) {
/* 303 */     for (IndexView idx : this.stack) {
/* 304 */       ModuleInfo result = idx.getModuleByName(moduleName);
/* 305 */       if (result != null) {
/* 306 */         return result;
/*     */       }
/*     */     } 
/* 309 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownUsers(DotName className) {
/* 314 */     List<ClassInfo> result = new ArrayList<>();
/* 315 */     Set<DotName> seen = new HashSet<>();
/* 316 */     for (IndexView idx : this.stack) {
/* 317 */       for (ClassInfo clazz : idx.getKnownUsers(className)) {
/* 318 */         if (seen.add(clazz.name())) {
/* 319 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/* 323 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getClassesInPackage(DotName packageName) {
/* 328 */     List<ClassInfo> result = new ArrayList<>();
/* 329 */     Set<DotName> seen = new HashSet<>();
/* 330 */     for (IndexView idx : this.stack) {
/* 331 */       for (ClassInfo clazz : idx.getClassesInPackage(packageName)) {
/* 332 */         if (seen.add(clazz.name())) {
/* 333 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/* 337 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<DotName> getSubpackages(DotName packageName) {
/* 342 */     Set<DotName> result = new HashSet<>();
/* 343 */     for (IndexView idx : this.stack) {
/* 344 */       result.addAll(idx.getSubpackages(packageName));
/*     */     }
/* 346 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\StackedIndex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */