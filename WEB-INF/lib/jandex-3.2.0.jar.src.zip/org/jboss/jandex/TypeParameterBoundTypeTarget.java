/*    */ package org.jboss.jandex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeParameterBoundTypeTarget
/*    */   extends TypeParameterTypeTarget
/*    */ {
/*    */   private short boundPosition;
/*    */   private boolean adjusted;
/*    */   
/*    */   TypeParameterBoundTypeTarget(AnnotationTarget enclosingTarget, int position, int boundPosition) {
/* 48 */     super(enclosingTarget, position);
/* 49 */     this.boundPosition = (short)boundPosition;
/*    */   }
/*    */   
/*    */   TypeParameterBoundTypeTarget(AnnotationTarget enclosingTarget, Type target, int position, int boundPosition) {
/* 53 */     super(enclosingTarget, target, position);
/* 54 */     this.boundPosition = (short)boundPosition;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int boundPosition() {
/* 63 */     return this.boundPosition & 0xFFFF;
/*    */   }
/*    */   
/*    */   void adjustBoundDown() {
/* 67 */     if (!this.adjusted) {
/* 68 */       this.boundPosition = (short)(this.boundPosition - 1);
/* 69 */       this.adjusted = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public final TypeTarget.Usage usage() {
/* 75 */     return TypeTarget.Usage.TYPE_PARAMETER_BOUND;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeParameterBoundTypeTarget asTypeParameterBound() {
/* 80 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\TypeParameterBoundTypeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */