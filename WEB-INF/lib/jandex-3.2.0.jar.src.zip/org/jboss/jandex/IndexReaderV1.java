/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class IndexReaderV1
/*     */   extends IndexReaderImpl
/*     */ {
/*     */   static final int MIN_VERSION = 2;
/*     */   static final int MAX_VERSION = 3;
/*     */   private static final byte FIELD_TAG = 1;
/*     */   private static final byte METHOD_TAG = 2;
/*     */   private static final byte METHOD_PARAMETER_TAG = 3;
/*     */   private static final byte CLASS_TAG = 4;
/*     */   private static final int AVALUE_BYTE = 1;
/*     */   private static final int AVALUE_SHORT = 2;
/*     */   private static final int AVALUE_INT = 3;
/*     */   private static final int AVALUE_CHAR = 4;
/*     */   private static final int AVALUE_FLOAT = 5;
/*     */   private static final int AVALUE_DOUBLE = 6;
/*     */   private static final int AVALUE_LONG = 7;
/*     */   private static final int AVALUE_BOOLEAN = 8;
/*     */   private static final int AVALUE_STRING = 9;
/*     */   private static final int AVALUE_CLASS = 10;
/*     */   private static final int AVALUE_ENUM = 11;
/*     */   private static final int AVALUE_ARRAY = 12;
/*     */   private static final int AVALUE_NESTED = 13;
/*     */   private final PackedDataInputStream input;
/*     */   private final int version;
/*     */   private DotName[] classTable;
/*     */   private String[] stringTable;
/*     */   private HashMap<DotName, List<AnnotationInstance>> masterAnnotations;
/*     */   
/*     */   IndexReaderV1(PackedDataInputStream input, int version) {
/*  80 */     this.input = input;
/*  81 */     this.version = version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Index read() throws IOException {
/*     */     try {
/*  95 */       PackedDataInputStream stream = this.input;
/*  96 */       this.masterAnnotations = new HashMap<>();
/*  97 */       readClassTable(stream);
/*  98 */       readStringTable(stream);
/*  99 */       return readClasses(stream);
/*     */     } finally {
/* 101 */       this.classTable = null;
/* 102 */       this.stringTable = null;
/* 103 */       this.masterAnnotations = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Index readClasses(PackedDataInputStream stream) throws IOException {
/* 108 */     int entries = stream.readPackedU32();
/* 109 */     HashMap<DotName, List<ClassInfo>> subclasses = new HashMap<>();
/* 110 */     HashMap<DotName, List<ClassInfo>> implementors = new HashMap<>();
/* 111 */     HashMap<DotName, ClassInfo> classes = new HashMap<>();
/* 112 */     Map<DotName, List<ClassInfo>> users = Collections.emptyMap();
/* 113 */     this.masterAnnotations = new HashMap<>();
/*     */     
/* 115 */     for (int i = 0; i < entries; i++) {
/* 116 */       DotName name = this.classTable[stream.readPackedU32()];
/* 117 */       DotName superName = this.classTable[stream.readPackedU32()];
/* 118 */       short flags = stream.readShort();
/*     */       
/* 120 */       boolean hasNoArgsConstructor = (this.version >= 3 && stream.readBoolean());
/*     */       
/* 122 */       int numIntfs = stream.readPackedU32();
/* 123 */       List<Type> interfaces = new ArrayList<>(numIntfs);
/* 124 */       for (int j = 0; j < numIntfs; j++) {
/* 125 */         interfaces.add(new ClassType(this.classTable[stream.readPackedU32()]));
/*     */       }
/*     */       
/* 128 */       Type[] interfaceTypes = interfaces.<Type>toArray(new Type[interfaces.size()]);
/*     */       
/* 130 */       Map<DotName, List<AnnotationInstance>> annotations = new HashMap<>();
/* 131 */       Type superClassType = (superName == null) ? null : new ClassType(superName);
/* 132 */       ClassInfo clazz = new ClassInfo(name, superClassType, flags, interfaceTypes, hasNoArgsConstructor);
/* 133 */       classes.put(name, clazz);
/* 134 */       addClassToMap(subclasses, superName, clazz);
/* 135 */       for (Type interfaceName : interfaces) {
/* 136 */         addClassToMap(implementors, interfaceName.name(), clazz);
/*     */       }
/* 138 */       readAnnotations(stream, annotations, clazz);
/* 139 */       clazz.setAnnotations(annotations);
/*     */     } 
/*     */     
/* 142 */     return Index.create(this.masterAnnotations, subclasses, implementors, classes, users);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readAnnotations(PackedDataInputStream stream, Map<DotName, List<AnnotationInstance>> annotations, ClassInfo clazz) throws IOException {
/* 147 */     int numAnnotations = stream.readPackedU32();
/* 148 */     for (int j = 0; j < numAnnotations; j++) {
/* 149 */       DotName annotationName = this.classTable[stream.readPackedU32()];
/*     */       
/* 151 */       int numTargets = stream.readPackedU32();
/* 152 */       for (int k = 0; k < numTargets; k++) {
/* 153 */         AnnotationTarget target; String name; MethodInfo method; Type type; short flags; int tag = stream.readPackedU32();
/*     */ 
/*     */         
/* 156 */         switch (tag) {
/*     */           case 1:
/* 158 */             name = this.stringTable[stream.readPackedU32()];
/* 159 */             type = readType(stream);
/* 160 */             flags = stream.readShort();
/* 161 */             target = new FieldInfo(clazz, Utils.toUTF8(name), type, flags);
/*     */             break;
/*     */           
/*     */           case 2:
/* 165 */             target = readMethod(clazz, stream);
/*     */             break;
/*     */           
/*     */           case 3:
/* 169 */             method = readMethod(clazz, stream);
/* 170 */             target = new MethodParameterInfo(method, (short)stream.readPackedU32());
/*     */             break;
/*     */           
/*     */           case 4:
/* 174 */             target = clazz;
/*     */             break;
/*     */           
/*     */           default:
/* 178 */             throw new UnsupportedOperationException();
/*     */         } 
/*     */         
/* 181 */         AnnotationValue[] values = readAnnotationValues(stream);
/* 182 */         AnnotationInstance instance = AnnotationInstance.create(annotationName, target, values);
/*     */         
/* 184 */         recordAnnotation(this.masterAnnotations, annotationName, instance);
/* 185 */         recordAnnotation(annotations, annotationName, instance);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private AnnotationValue[] readAnnotationValues(PackedDataInputStream stream) throws IOException {
/* 192 */     int numValues = stream.readPackedU32();
/* 193 */     AnnotationValue[] values = new AnnotationValue[numValues];
/*     */     
/* 195 */     for (int i = 0; i < numValues; i++) {
/*     */       AnnotationValue value; DotName nestedName; AnnotationInstance nestedInstance;
/* 197 */       String name = this.stringTable[stream.readPackedU32()];
/* 198 */       int tag = stream.readByte();
/*     */       
/* 200 */       switch (tag) {
/*     */         case 1:
/* 202 */           value = new AnnotationValue.ByteValue(name, stream.readByte());
/*     */           break;
/*     */         case 2:
/* 205 */           value = new AnnotationValue.ShortValue(name, (short)stream.readPackedU32());
/*     */           break;
/*     */         case 3:
/* 208 */           value = new AnnotationValue.IntegerValue(name, stream.readPackedU32());
/*     */           break;
/*     */         case 4:
/* 211 */           value = new AnnotationValue.CharacterValue(name, (char)stream.readPackedU32());
/*     */           break;
/*     */         case 5:
/* 214 */           value = new AnnotationValue.FloatValue(name, stream.readFloat());
/*     */           break;
/*     */         case 6:
/* 217 */           value = new AnnotationValue.DoubleValue(name, stream.readDouble());
/*     */           break;
/*     */         case 7:
/* 220 */           value = new AnnotationValue.LongValue(name, stream.readLong());
/*     */           break;
/*     */         case 8:
/* 223 */           value = new AnnotationValue.BooleanValue(name, stream.readBoolean());
/*     */           break;
/*     */         case 9:
/* 226 */           value = new AnnotationValue.StringValue(name, this.stringTable[stream.readPackedU32()]);
/*     */           break;
/*     */         case 10:
/* 229 */           value = new AnnotationValue.ClassValue(name, readType(stream));
/*     */           break;
/*     */         
/*     */         case 11:
/* 233 */           value = new AnnotationValue.EnumValue(name, this.classTable[stream.readPackedU32()], this.stringTable[stream.readPackedU32()]);
/*     */           break;
/*     */         case 12:
/* 236 */           value = new AnnotationValue.ArrayValue(name, readAnnotationValues(stream));
/*     */           break;
/*     */         case 13:
/* 239 */           nestedName = this.classTable[stream.readPackedU32()];
/* 240 */           nestedInstance = AnnotationInstance.create(nestedName, (AnnotationTarget)null, 
/* 241 */               readAnnotationValues(stream));
/* 242 */           value = new AnnotationValue.NestedAnnotation(name, nestedInstance);
/*     */           break;
/*     */         
/*     */         default:
/* 246 */           throw new IllegalStateException("Invalid annotation value tag:" + tag);
/*     */       } 
/*     */       
/* 249 */       values[i] = value;
/*     */     } 
/*     */     
/* 252 */     return values;
/*     */   }
/*     */   
/*     */   private MethodInfo readMethod(ClassInfo clazz, PackedDataInputStream stream) throws IOException {
/* 256 */     String name = this.stringTable[stream.readPackedU32()];
/* 257 */     int numArgs = stream.readPackedU32();
/* 258 */     List<Type> args = new ArrayList<>(numArgs);
/* 259 */     for (int i = 0; i < numArgs; i++) {
/* 260 */       args.add(readType(stream));
/*     */     }
/*     */     
/* 263 */     Type[] parameters = args.<Type>toArray(new Type[args.size()]);
/* 264 */     Type returnType = readType(stream);
/* 265 */     short flags = stream.readShort();
/*     */     
/* 267 */     byte[] bytes = Utils.toUTF8(name);
/* 268 */     return new MethodInfo(clazz, bytes, MethodInternal.EMPTY_PARAMETER_NAMES, parameters, returnType, flags);
/*     */   }
/*     */ 
/*     */   
/*     */   private void recordAnnotation(Map<DotName, List<AnnotationInstance>> annotations, DotName annotation, AnnotationInstance instance) {
/* 273 */     List<AnnotationInstance> list = annotations.get(annotation);
/* 274 */     if (list == null) {
/* 275 */       list = new ArrayList<>();
/* 276 */       annotations.put(annotation, list);
/*     */     } 
/*     */     
/* 279 */     list.add(instance);
/*     */   }
/*     */   
/*     */   private void addClassToMap(HashMap<DotName, List<ClassInfo>> map, DotName name, ClassInfo currentClass) {
/* 283 */     List<ClassInfo> list = map.get(name);
/* 284 */     if (list == null) {
/* 285 */       list = new ArrayList<>();
/* 286 */       map.put(name, list);
/*     */     } 
/*     */     
/* 289 */     list.add(currentClass);
/*     */   }
/*     */   
/*     */   private Type readType(PackedDataInputStream stream) throws IOException {
/* 293 */     Type.Kind kind = Type.Kind.fromOrdinal(stream.readByte());
/* 294 */     DotName name = this.classTable[stream.readPackedU32()];
/* 295 */     return Type.create(name, kind);
/*     */   }
/*     */   
/*     */   private void readStringTable(PackedDataInputStream stream) throws IOException {
/* 299 */     int entries = stream.readPackedU32();
/* 300 */     this.stringTable = new String[entries];
/*     */     
/* 302 */     for (int i = 0; i < entries; i++) {
/* 303 */       this.stringTable[i] = stream.readUTF();
/*     */     }
/*     */   }
/*     */   
/*     */   private void readClassTable(PackedDataInputStream stream) throws IOException {
/* 308 */     int entries = stream.readPackedU32();
/* 309 */     int lastDepth = -1;
/* 310 */     DotName curr = null;
/*     */ 
/*     */     
/* 313 */     this.classTable = new DotName[++entries];
/* 314 */     for (int i = 1; i < entries; i++) {
/* 315 */       int depth = stream.readPackedU32();
/* 316 */       String local = stream.readUTF();
/*     */       
/* 318 */       if (depth <= lastDepth) {
/* 319 */         while (lastDepth-- >= depth) {
/* 320 */           curr = curr.prefix();
/*     */         }
/*     */       }
/* 323 */       this.classTable[i] = curr = new DotName(curr, local, true, false);
/* 324 */       lastDepth = depth;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexReaderV1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */