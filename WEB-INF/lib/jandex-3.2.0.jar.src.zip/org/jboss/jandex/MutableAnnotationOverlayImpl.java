/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ final class MutableAnnotationOverlayImpl
/*     */   extends AnnotationOverlayImpl implements MutableAnnotationOverlay {
/*     */   private volatile boolean frozen;
/*     */   
/*     */   MutableAnnotationOverlayImpl(IndexView index, boolean compatibleMode, boolean runtimeAnnotationsOnly, boolean inheritedAnnotations) {
/*  13 */     super(index, compatibleMode, runtimeAnnotationsOnly, inheritedAnnotations, Collections.emptyList());
/*     */   }
/*     */ 
/*     */   
/*     */   Set<AnnotationInstance> getAnnotationsFor(Declaration declaration) {
/*  18 */     EquivalenceKey key = EquivalenceKey.of(declaration);
/*  19 */     Set<AnnotationInstance> annotations = this.overlay.get(key);
/*  20 */     if (annotations == null) {
/*  21 */       annotations = getOriginalAnnotations(declaration);
/*  22 */       this.overlay.put(key, annotations);
/*     */     } 
/*  24 */     return annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnnotation(Declaration declaration, AnnotationInstance annotation) {
/*  29 */     if (this.frozen) {
/*  30 */       throw new IllegalStateException("Mutable annotation overlay is already frozen");
/*     */     }
/*     */     
/*  33 */     if (annotation.target() == null) {
/*  34 */       annotation = AnnotationInstance.create(annotation, declaration);
/*     */     }
/*     */     
/*  37 */     getAnnotationsFor(declaration).add(annotation);
/*  38 */     this.transformations.add(addTransformation(declaration, annotation));
/*     */   }
/*     */ 
/*     */   
/*     */   private AnnotationTransformation addTransformation(Declaration declaration, final AnnotationInstance annotation) {
/*     */     final AnnotationTarget.Kind declarationKind;
/*     */     final EquivalenceKey key;
/*  45 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/*     */ 
/*     */       
/*  48 */       declarationKind = AnnotationTarget.Kind.METHOD;
/*  49 */       key = EquivalenceKey.of(declaration.asMethodParameter().method());
/*     */     } else {
/*  51 */       declarationKind = declaration.kind();
/*  52 */       key = EquivalenceKey.of(declaration);
/*     */     } 
/*     */     
/*  55 */     return new AnnotationTransformation()
/*     */       {
/*     */         public boolean supports(AnnotationTarget.Kind kind) {
/*  58 */           return (kind == declarationKind);
/*     */         }
/*     */ 
/*     */         
/*     */         public void apply(AnnotationTransformation.TransformationContext context) {
/*  63 */           if (key.equals(EquivalenceKey.of(context.declaration()))) {
/*  64 */             context.add(annotation);
/*     */           }
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean requiresCompatibleMode() {
/*  70 */           return MutableAnnotationOverlayImpl.this.compatibleMode;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAnnotations(Declaration declaration, Predicate<AnnotationInstance> predicate) {
/*  77 */     if (this.frozen) {
/*  78 */       throw new IllegalStateException("Mutable annotation overlay is already frozen");
/*     */     }
/*     */     
/*  81 */     getAnnotationsFor(declaration).removeIf(predicate);
/*  82 */     this.transformations.add(removeTransformation(declaration, predicate));
/*     */   }
/*     */ 
/*     */   
/*     */   private AnnotationTransformation removeTransformation(Declaration declaration, final Predicate<AnnotationInstance> predicate) {
/*     */     final AnnotationTarget.Kind declarationKind;
/*     */     final EquivalenceKey key;
/*     */     final Predicate<AnnotationInstance> finalPredicate;
/*  90 */     if (this.compatibleMode && declaration.kind() == AnnotationTarget.Kind.METHOD_PARAMETER) {
/*  91 */       declarationKind = AnnotationTarget.Kind.METHOD;
/*  92 */       key = EquivalenceKey.of(declaration.asMethodParameter().method());
/*  93 */       final int position = declaration.asMethodParameter().position();
/*  94 */       finalPredicate = new Predicate<AnnotationInstance>()
/*     */         {
/*     */           public boolean test(AnnotationInstance annotation) {
/*  97 */             return (annotation.target() != null && annotation
/*  98 */               .target().kind() == AnnotationTarget.Kind.METHOD_PARAMETER && annotation
/*  99 */               .target().asMethodParameter().position() == position && predicate
/* 100 */               .test(annotation));
/*     */           }
/*     */         };
/*     */     } else {
/* 104 */       declarationKind = declaration.kind();
/* 105 */       key = EquivalenceKey.of(declaration);
/* 106 */       finalPredicate = predicate;
/*     */     } 
/*     */     
/* 109 */     return new AnnotationTransformation()
/*     */       {
/*     */         public boolean supports(AnnotationTarget.Kind kind) {
/* 112 */           return (kind == declarationKind);
/*     */         }
/*     */ 
/*     */         
/*     */         public void apply(AnnotationTransformation.TransformationContext context) {
/* 117 */           if (key.equals(EquivalenceKey.of(context.declaration()))) {
/* 118 */             context.remove(finalPredicate);
/*     */           }
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean requiresCompatibleMode() {
/* 124 */           return MutableAnnotationOverlayImpl.this.compatibleMode;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotationTransformation> freeze() {
/* 131 */     this.frozen = true;
/* 132 */     return Collections.unmodifiableList(this.transformations);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MutableAnnotationOverlayImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */