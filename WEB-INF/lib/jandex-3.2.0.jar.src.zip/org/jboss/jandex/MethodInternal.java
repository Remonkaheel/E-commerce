/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MethodInternal
/*     */ {
/*  31 */   static final MethodInternal[] EMPTY_ARRAY = new MethodInternal[0];
/*  32 */   static final NameAndParameterComponentComparator NAME_AND_PARAMETER_COMPONENT_COMPARATOR = new NameAndParameterComponentComparator();
/*  33 */   static final byte[][] EMPTY_PARAMETER_NAMES = new byte[0][]; private byte[] name; private byte[][] parameterNames; private Type[] parameterTypes; private Type returnType; private Type[] exceptions; private short flags; private ExtraInfo extra;
/*     */   private final Type[] descriptorParameterTypes;
/*     */   
/*     */   private static final class NameAndParameterComponentComparator implements Comparator<MethodInternal> { private int compare(byte[] left, byte[] right) {
/*  37 */       for (int i = 0, j = 0; i < left.length && j < right.length; i++, j++) {
/*  38 */         int a = left[i] & 0xFF;
/*  39 */         int b = right[j] & 0xFF;
/*  40 */         if (a != b) {
/*  41 */           return a - b;
/*     */         }
/*     */       } 
/*  44 */       return left.length - right.length;
/*     */     }
/*     */     private NameAndParameterComponentComparator() {}
/*     */     public int compare(MethodInternal instance, MethodInternal instance2) {
/*  48 */       int x = compare(instance.name, instance2.name);
/*  49 */       if (x != 0) {
/*  50 */         return x;
/*     */       }
/*     */       
/*  53 */       Type[] parameterTypes1 = instance.parameterTypes;
/*  54 */       Type[] parameterTypes2 = instance2.parameterTypes;
/*     */       
/*  56 */       int min = Math.min(parameterTypes1.length, parameterTypes2.length);
/*  57 */       for (int i = 0; i < min; i++) {
/*  58 */         Type t1 = parameterTypes1[i];
/*  59 */         Type t2 = parameterTypes2[i];
/*     */         
/*  61 */         x = t1.name().compareTo(t2.name());
/*  62 */         if (x != 0) {
/*  63 */           return x;
/*     */         }
/*     */       } 
/*     */       
/*  67 */       x = parameterTypes1.length - parameterTypes2.length;
/*  68 */       if (x != 0) {
/*  69 */         return x;
/*     */       }
/*     */ 
/*     */       
/*  73 */       return (instance.flags & 0x1040) - (instance2
/*  74 */         .flags & 0x1040);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ExtraInfo
/*     */   {
/*     */     Type receiverType;
/*     */ 
/*     */     
/*     */     Type[] typeParameters;
/*     */     
/*     */     AnnotationValue defaultValue;
/*     */     
/*     */     AnnotationInstance[] annotations;
/*     */ 
/*     */     
/*     */     private ExtraInfo() {}
/*     */   }
/*     */ 
/*     */   
/*     */   MethodInternal(byte[] name, byte[][] parameterNames, Type[] parameterTypes, Type returnType, short flags) {
/*  97 */     this(name, parameterNames, parameterTypes, returnType, flags, Type.EMPTY_ARRAY, Type.EMPTY_ARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   MethodInternal(byte[] name, byte[][] parameterNames, Type[] parameterTypes, Type returnType, short flags, Type[] typeParameters, Type[] exceptions) {
/* 102 */     this(name, parameterNames, parameterTypes, returnType, flags, null, typeParameters, exceptions, AnnotationInstance.EMPTY_ARRAY, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodInternal(byte[] name, byte[][] parameterNames, Type[] parameterTypes, Type returnType, short flags, Type receiverType, Type[] typeParameters, Type[] exceptions, AnnotationInstance[] annotations, AnnotationValue defaultValue) {
/* 109 */     this.name = name;
/* 110 */     this.parameterNames = parameterNames;
/* 111 */     this.parameterTypes = (parameterTypes.length == 0) ? Type.EMPTY_ARRAY : parameterTypes;
/* 112 */     this.returnType = returnType;
/* 113 */     this.flags = flags;
/* 114 */     this.exceptions = exceptions;
/* 115 */     if (annotations != null && annotations.length > 0) {
/* 116 */       if (this.extra == null) {
/* 117 */         this.extra = new ExtraInfo();
/*     */       }
/* 119 */       this.extra.annotations = annotations;
/*     */     } 
/* 121 */     if (typeParameters != null && typeParameters.length > 0) {
/* 122 */       if (this.extra == null) {
/* 123 */         this.extra = new ExtraInfo();
/*     */       }
/* 125 */       this.extra.typeParameters = typeParameters;
/*     */     } 
/* 127 */     if (receiverType != null) {
/* 128 */       if (this.extra == null) {
/* 129 */         this.extra = new ExtraInfo();
/*     */       }
/* 131 */       this.extra.receiverType = receiverType;
/*     */     } 
/* 133 */     if (defaultValue != null) {
/* 134 */       if (this.extra == null) {
/* 135 */         this.extra = new ExtraInfo();
/*     */       }
/* 137 */       this.extra.defaultValue = defaultValue;
/*     */     } 
/*     */     
/* 140 */     this.descriptorParameterTypes = this.parameterTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 145 */     if (this == o) {
/* 146 */       return true;
/*     */     }
/* 148 */     if (o == null || getClass() != o.getClass()) {
/* 149 */       return false;
/*     */     }
/*     */     
/* 152 */     MethodInternal methodInternal = (MethodInternal)o;
/*     */     
/* 154 */     if ((this.extra != null && methodInternal.extra == null) || (this.extra == null && methodInternal.extra != null)) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     if (this.flags != methodInternal.flags) {
/* 159 */       return false;
/*     */     }
/* 161 */     if (this.extra != null && !Arrays.equals((Object[])this.extra.annotations, (Object[])methodInternal.extra.annotations)) {
/* 162 */       return false;
/*     */     }
/* 164 */     if (!Arrays.equals((Object[])this.exceptions, (Object[])methodInternal.exceptions)) {
/* 165 */       return false;
/*     */     }
/* 167 */     if (!Arrays.equals(this.name, methodInternal.name)) {
/* 168 */       return false;
/*     */     }
/* 170 */     if (!Arrays.deepEquals((Object[])this.parameterNames, (Object[])methodInternal.parameterNames)) {
/* 171 */       return false;
/*     */     }
/* 173 */     if (!Arrays.equals((Object[])this.parameterTypes, (Object[])methodInternal.parameterTypes)) {
/* 174 */       return false;
/*     */     }
/* 176 */     if (!Arrays.equals((Object[])this.descriptorParameterTypes, (Object[])methodInternal.descriptorParameterTypes)) {
/* 177 */       return false;
/*     */     }
/* 179 */     if (this.extra != null && ((this.extra.receiverType != null) ? !this.extra.receiverType.equals(methodInternal.extra.receiverType) : (methodInternal.extra.receiverType != null)))
/*     */     {
/* 181 */       return false;
/*     */     }
/* 183 */     if (!this.returnType.equals(methodInternal.returnType)) {
/* 184 */       return false;
/*     */     }
/* 186 */     if (this.extra != null && ((this.extra.defaultValue != null) ? !this.extra.defaultValue.equals(methodInternal.extra.defaultValue) : (methodInternal.extra.defaultValue != null)))
/*     */     {
/* 188 */       return false;
/*     */     }
/* 190 */     if (this.extra != null && !Arrays.equals((Object[])this.extra.typeParameters, (Object[])methodInternal.extra.typeParameters)) {
/* 191 */       return false;
/*     */     }
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 198 */     int result = Arrays.hashCode(this.name);
/* 199 */     result = 31 * result + Arrays.deepHashCode((Object[])this.parameterNames);
/* 200 */     result = 31 * result + Arrays.hashCode((Object[])this.parameterTypes);
/* 201 */     result = 31 * result + Arrays.hashCode((Object[])this.descriptorParameterTypes);
/* 202 */     result = 31 * result + this.returnType.hashCode();
/* 203 */     result = 31 * result + Arrays.hashCode((Object[])this.exceptions);
/* 204 */     result = 31 * result + ((this.extra != null && this.extra.receiverType != null) ? this.extra.receiverType.hashCode() : 0);
/* 205 */     result = 31 * result + ((this.extra != null) ? Arrays.hashCode((Object[])this.extra.typeParameters) : 0);
/* 206 */     result = 31 * result + ((this.extra != null) ? Arrays.hashCode((Object[])this.extra.annotations) : 0);
/* 207 */     result = 31 * result + ((this.extra != null && this.extra.defaultValue != null) ? this.extra.defaultValue.hashCode() : 0);
/* 208 */     result = 31 * result + this.flags;
/* 209 */     return result;
/*     */   }
/*     */   
/*     */   boolean internEquals(Object o) {
/* 213 */     if (this == o) {
/* 214 */       return true;
/*     */     }
/* 216 */     if (o == null || getClass() != o.getClass()) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     MethodInternal methodInternal = (MethodInternal)o;
/*     */     
/* 222 */     if ((this.extra != null && methodInternal.extra == null) || (this.extra == null && methodInternal.extra != null)) {
/* 223 */       return false;
/*     */     }
/*     */     
/* 226 */     if (this.flags != methodInternal.flags) {
/* 227 */       return false;
/*     */     }
/* 229 */     if (this.extra != null && !Arrays.equals((Object[])this.extra.annotations, (Object[])methodInternal.extra.annotations)) {
/* 230 */       return false;
/*     */     }
/* 232 */     if (!TypeInterning.arrayEquals(this.exceptions, methodInternal.exceptions)) {
/* 233 */       return false;
/*     */     }
/* 235 */     if (!Arrays.equals(this.name, methodInternal.name)) {
/* 236 */       return false;
/*     */     }
/* 238 */     if (!Arrays.deepEquals((Object[])this.parameterNames, (Object[])methodInternal.parameterNames)) {
/* 239 */       return false;
/*     */     }
/* 241 */     if (!TypeInterning.arrayEquals(this.parameterTypes, methodInternal.parameterTypes)) {
/* 242 */       return false;
/*     */     }
/* 244 */     if (!TypeInterning.arrayEquals(this.descriptorParameterTypes, methodInternal.descriptorParameterTypes)) {
/* 245 */       return false;
/*     */     }
/* 247 */     if (this.extra != null && ((this.extra.receiverType != null) ? !this.extra.receiverType.internEquals(methodInternal.extra.receiverType) : (methodInternal.extra.receiverType != null)))
/*     */     {
/* 249 */       return false;
/*     */     }
/* 251 */     if (!this.returnType.internEquals(methodInternal.returnType)) {
/* 252 */       return false;
/*     */     }
/* 254 */     if (this.extra != null && ((this.extra.defaultValue != null) ? !this.extra.defaultValue.equals(methodInternal.extra.defaultValue) : (methodInternal.extra.defaultValue != null)))
/*     */     {
/* 256 */       return false;
/*     */     }
/* 258 */     if (this.extra != null && !TypeInterning.arrayEquals(this.extra.typeParameters, methodInternal.extra.typeParameters)) {
/* 259 */       return false;
/*     */     }
/* 261 */     return true;
/*     */   }
/*     */   
/*     */   int internHashCode() {
/* 265 */     int result = Arrays.hashCode(this.name);
/* 266 */     result = 31 * result + Arrays.deepHashCode((Object[])this.parameterNames);
/* 267 */     result = 31 * result + TypeInterning.arrayHashCode(this.parameterTypes);
/* 268 */     result = 31 * result + TypeInterning.arrayHashCode(this.descriptorParameterTypes);
/* 269 */     result = 31 * result + this.returnType.internHashCode();
/* 270 */     result = 31 * result + TypeInterning.arrayHashCode(this.exceptions);
/* 271 */     result = 31 * result + ((this.extra != null && this.extra.receiverType != null) ? this.extra.receiverType.internHashCode() : 0);
/* 272 */     result = 31 * result + ((this.extra != null) ? TypeInterning.arrayHashCode(this.extra.typeParameters) : 0);
/* 273 */     result = 31 * result + ((this.extra != null) ? Arrays.hashCode((Object[])this.extra.annotations) : 0);
/* 274 */     result = 31 * result + ((this.extra != null && this.extra.defaultValue != null) ? this.extra.defaultValue.hashCode() : 0);
/* 275 */     result = 31 * result + this.flags;
/* 276 */     return result;
/*     */   }
/*     */   
/*     */   final String name() {
/* 280 */     return Utils.fromUTF8(this.name);
/*     */   }
/*     */   
/*     */   final int parametersCount() {
/* 284 */     return this.parameterTypes.length;
/*     */   }
/*     */   
/*     */   final String parameterName(int i) {
/* 288 */     if (i >= this.parameterNames.length)
/* 289 */       return null; 
/* 290 */     return Utils.fromUTF8(this.parameterNames[i]);
/*     */   }
/*     */   
/*     */   final byte[] nameBytes() {
/* 294 */     return this.name;
/*     */   }
/*     */   
/*     */   final byte[][] parameterNamesBytes() {
/* 298 */     return this.parameterNames;
/*     */   }
/*     */   
/*     */   final Type[] copyParameterTypes() {
/* 302 */     return (Type[])this.parameterTypes.clone();
/*     */   }
/*     */   
/*     */   final Type[] parameterTypesArray() {
/* 306 */     return this.parameterTypes;
/*     */   }
/*     */   
/*     */   final Type[] copyExceptions() {
/* 310 */     return (Type[])this.exceptions.clone();
/*     */   }
/*     */   
/*     */   final List<Type> parameterTypes() {
/* 314 */     return new ImmutableArrayList<>(this.parameterTypes);
/*     */   }
/*     */   
/*     */   final List<Type> descriptorParameterTypes() {
/* 318 */     return new ImmutableArrayList<>(this.descriptorParameterTypes);
/*     */   }
/*     */   
/*     */   final Type[] descriptorParameterTypesArray() {
/* 322 */     return this.descriptorParameterTypes;
/*     */   }
/*     */   
/*     */   final Type returnType() {
/* 326 */     return this.returnType;
/*     */   }
/*     */   
/*     */   final Type receiverType(ClassInfo clazz) {
/* 330 */     if (this.extra != null && this.extra.receiverType != null) {
/* 331 */       return this.extra.receiverType;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 336 */     if ((clazz.typeParameterArray()).length > 0) {
/* 337 */       Type[] classTypeParameters = clazz.typeParameterArray();
/* 338 */       Type[] receiverTypeArguments = new Type[classTypeParameters.length];
/* 339 */       for (int i = 0; i < classTypeParameters.length; i++) {
/* 340 */         receiverTypeArguments[i] = classTypeParameters[i].copyType(AnnotationInstance.EMPTY_ARRAY);
/*     */       }
/* 342 */       return new ParameterizedType(clazz.name(), receiverTypeArguments, null);
/*     */     } 
/* 344 */     return new ClassType(clazz.name());
/*     */   }
/*     */   
/*     */   final Type receiverTypeField() {
/* 348 */     return (this.extra != null) ? this.extra.receiverType : null;
/*     */   }
/*     */   
/*     */   final List<Type> exceptions() {
/* 352 */     return new ImmutableArrayList<>(this.exceptions);
/*     */   }
/*     */   
/*     */   final Type[] exceptionArray() {
/* 356 */     return this.exceptions;
/*     */   }
/*     */ 
/*     */   
/*     */   final List<TypeVariable> typeParameters() {
/* 361 */     return (this.extra != null && this.extra.typeParameters != null) ? (List)new ImmutableArrayList<>(this.extra.typeParameters) : 
/* 362 */       Collections.<TypeVariable>emptyList();
/*     */   }
/*     */   
/*     */   final List<AnnotationInstance> annotations() {
/* 366 */     return (this.extra != null && this.extra.annotations != null) ? new ImmutableArrayList<>(this.extra.annotations) : 
/* 367 */       Collections.<AnnotationInstance>emptyList();
/*     */   }
/*     */   
/*     */   final AnnotationInstance[] annotationArray() {
/* 371 */     return (this.extra != null && this.extra.annotations != null) ? this.extra.annotations : AnnotationInstance.EMPTY_ARRAY;
/*     */   }
/*     */   
/*     */   final AnnotationInstance annotation(DotName name) {
/* 375 */     return (this.extra != null && this.extra.annotations != null) ? AnnotationInstance.binarySearch(this.extra.annotations, name) : null;
/*     */   }
/*     */   
/*     */   final boolean hasAnnotation(DotName name) {
/* 379 */     return (annotation(name) != null);
/*     */   }
/*     */   
/*     */   final Type[] typeParameterArray() {
/* 383 */     return (this.extra != null && this.extra.typeParameters != null) ? this.extra.typeParameters : Type.EMPTY_ARRAY;
/*     */   }
/*     */   
/*     */   final AnnotationValue defaultValue() {
/* 387 */     return (this.extra != null) ? this.extra.defaultValue : null;
/*     */   }
/*     */   
/*     */   final short flags() {
/* 391 */     return this.flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 396 */     StringBuilder builder = new StringBuilder();
/* 397 */     String name = name();
/* 398 */     builder.append(this.returnType.toString(true)).append(' ').append(name).append('(');
/* 399 */     if (this.extra != null && this.extra.receiverType != null) {
/* 400 */       builder.append(this.extra.receiverType.toString(true)).append(" this");
/* 401 */       if (this.parameterTypes.length > 0)
/* 402 */         builder.append(", "); 
/*     */     } 
/*     */     int i;
/* 405 */     for (i = 0; i < this.parameterTypes.length; i++) {
/* 406 */       builder.append(this.parameterTypes[i].toString(true));
/* 407 */       String parameterName = parameterName(i);
/* 408 */       if (parameterName != null) {
/* 409 */         builder.append(' ');
/* 410 */         builder.append(parameterName);
/*     */       } 
/* 412 */       if (i + 1 < this.parameterTypes.length)
/* 413 */         builder.append(", "); 
/*     */     } 
/* 415 */     builder.append(')');
/*     */     
/* 417 */     if (this.exceptions.length > 0) {
/* 418 */       builder.append(" throws ");
/* 419 */       for (i = 0; i < this.exceptions.length; i++) {
/* 420 */         builder.append(this.exceptions[i].toString(true));
/* 421 */         if (i < this.exceptions.length - 1) {
/* 422 */           builder.append(", ");
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 427 */     return builder.toString();
/*     */   }
/*     */   
/*     */   void setTypeParameters(Type[] typeParameters) {
/* 431 */     if (typeParameters.length > 0) {
/* 432 */       if (this.extra == null) {
/* 433 */         this.extra = new ExtraInfo();
/*     */       }
/* 435 */       this.extra.typeParameters = typeParameters;
/*     */     } 
/*     */   }
/*     */   
/*     */   void setParameterNames(byte[][] parameterNames) {
/* 440 */     this.parameterNames = parameterNames;
/*     */   }
/*     */   
/*     */   void setParameterTypes(Type[] parameterTypes) {
/* 444 */     this.parameterTypes = (parameterTypes.length == 0) ? Type.EMPTY_ARRAY : parameterTypes;
/*     */   }
/*     */   
/*     */   void setReturnType(Type returnType) {
/* 448 */     this.returnType = returnType;
/*     */   }
/*     */   
/*     */   void setExceptions(Type[] exceptions) {
/* 452 */     this.exceptions = (exceptions.length == 0) ? Type.EMPTY_ARRAY : exceptions;
/*     */   }
/*     */   
/*     */   void setReceiverType(Type receiverType) {
/* 456 */     if (this.extra == null) {
/* 457 */       this.extra = new ExtraInfo();
/*     */     }
/* 459 */     this.extra.receiverType = receiverType;
/*     */   }
/*     */   
/*     */   void setAnnotations(List<AnnotationInstance> annotations) {
/* 463 */     if (!annotations.isEmpty()) {
/* 464 */       if (this.extra == null) {
/* 465 */         this.extra = new ExtraInfo();
/*     */       }
/* 467 */       this.extra.annotations = annotations.<AnnotationInstance>toArray(new AnnotationInstance[0]);
/* 468 */       Arrays.sort(this.extra.annotations, AnnotationInstance.NAME_COMPARATOR);
/*     */     } 
/*     */   }
/*     */   
/*     */   void setDefaultValue(AnnotationValue defaultValue) {
/* 473 */     if (this.extra == null) {
/* 474 */       this.extra = new ExtraInfo();
/*     */     }
/* 476 */     this.extra.defaultValue = defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MethodInternal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */