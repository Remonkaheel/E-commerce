/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeVariable
/*     */   extends Type
/*     */ {
/*     */   private static final int HASH_MASK = 2147483647;
/*     */   private static final int IMPLICIT_MASK = -2147483648;
/*     */   private final String identifier;
/*     */   private final Type[] bounds;
/*     */   private int hash;
/*     */   
/*     */   public static TypeVariable create(String identifier) {
/*  53 */     return new TypeVariable(identifier, new Type[] { ClassType.OBJECT_TYPE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(String identifier) {
/*  63 */     return new Builder(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeVariable(String name) {
/*  78 */     this(name, EMPTY_ARRAY);
/*     */   }
/*     */   
/*     */   TypeVariable(String name, Type[] bounds) {
/*  82 */     this(name, bounds, (AnnotationInstance[])null);
/*     */   }
/*     */   
/*     */   TypeVariable(String name, Type[] bounds, AnnotationInstance[] annotations) {
/*  86 */     this(name, bounds, annotations, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TypeVariable(String name, Type[] bounds, AnnotationInstance[] annotations, boolean implicitObjectBound) {
/*  92 */     super(DotName.OBJECT_NAME, annotations);
/*  93 */     this.identifier = name;
/*  94 */     this.bounds = bounds;
/*  95 */     this.hash = implicitObjectBound ? Integer.MIN_VALUE : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public DotName name() {
/* 100 */     if (this.bounds.length > 0) {
/* 101 */       return this.bounds[0].name();
/*     */     }
/* 103 */     return DotName.OBJECT_NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String identifier() {
/* 120 */     return this.identifier;
/*     */   }
/*     */   
/*     */   public List<Type> bounds() {
/* 124 */     return new ImmutableArrayList<>(this.bounds);
/*     */   }
/*     */   
/*     */   Type[] boundArray() {
/* 128 */     return this.bounds;
/*     */   }
/*     */   
/*     */   boolean hasImplicitObjectBound() {
/* 132 */     return ((this.hash & Integer.MIN_VALUE) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 137 */     return Type.Kind.TYPE_VARIABLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeVariable asTypeVariable() {
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 147 */     return new TypeVariable(this.identifier, this.bounds, newAnnotations, hasImplicitObjectBound());
/*     */   }
/*     */   
/*     */   TypeVariable copyType(int boundIndex, Type bound) {
/* 151 */     if (boundIndex > this.bounds.length) {
/* 152 */       throw new IllegalArgumentException("Bound index outside of bounds");
/*     */     }
/*     */     
/* 155 */     Type[] bounds = (Type[])this.bounds.clone();
/* 156 */     bounds[boundIndex] = bound;
/* 157 */     return new TypeVariable(this.identifier, bounds, annotationArray(), hasImplicitObjectBound());
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(boolean simple) {
/* 162 */     StringBuilder builder = new StringBuilder();
/* 163 */     appendAnnotations(builder);
/* 164 */     builder.append(this.identifier);
/*     */     
/* 166 */     if (!simple && this.bounds.length > 0 && (this.bounds.length != 1 || !ClassType.OBJECT_TYPE.equals(this.bounds[0]))) {
/* 167 */       builder.append(" extends ").append(this.bounds[0].toString(true));
/*     */       
/* 169 */       for (int i = 1; i < this.bounds.length; i++) {
/* 170 */         builder.append(" & ").append(this.bounds[i].toString(true));
/*     */       }
/*     */     } 
/*     */     
/* 174 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 179 */     if (this == o) {
/* 180 */       return true;
/*     */     }
/*     */     
/* 183 */     if (!super.equals(o)) {
/* 184 */       return false;
/*     */     }
/*     */     
/* 187 */     TypeVariable that = (TypeVariable)o;
/*     */     
/* 189 */     return (this.identifier.equals(that.identifier) && Arrays.equals((Object[])this.bounds, (Object[])that.bounds) && 
/* 190 */       hasImplicitObjectBound() == that.hasImplicitObjectBound());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 195 */     int hash = this.hash & Integer.MAX_VALUE;
/* 196 */     if (hash != 0) {
/* 197 */       return hash;
/*     */     }
/*     */     
/* 200 */     hash = super.hashCode();
/* 201 */     hash = 31 * hash + this.identifier.hashCode();
/* 202 */     hash = 31 * hash + Arrays.hashCode((Object[])this.bounds);
/* 203 */     hash &= Integer.MAX_VALUE;
/* 204 */     this.hash |= hash;
/* 205 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 210 */     if (this == o) {
/* 211 */       return true;
/*     */     }
/*     */     
/* 214 */     if (!super.internEquals(o)) {
/* 215 */       return false;
/*     */     }
/*     */     
/* 218 */     TypeVariable that = (TypeVariable)o;
/*     */     
/* 220 */     return (this.identifier.equals(that.identifier) && TypeInterning.arrayEquals(this.bounds, that.bounds) && 
/* 221 */       hasImplicitObjectBound() == that.hasImplicitObjectBound());
/*     */   }
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 226 */     int hash = super.internHashCode();
/* 227 */     hash = 31 * hash + this.identifier.hashCode();
/* 228 */     hash = 31 * hash + TypeInterning.arrayHashCode(this.bounds);
/* 229 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */     extends Type.Builder<Builder>
/*     */   {
/*     */     private final String identifier;
/*     */ 
/*     */     
/*     */     private final List<Type> bounds;
/*     */ 
/*     */     
/*     */     Builder(String identifier) {
/* 244 */       super(DotName.OBJECT_NAME);
/* 245 */       this.identifier = identifier;
/* 246 */       this.bounds = new ArrayList<>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addBound(Type bound) {
/* 256 */       this.bounds.add(Objects.<Type>requireNonNull(bound));
/* 257 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addBound(Class<?> clazz) {
/* 267 */       return addBound(ClassType.create(clazz));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeVariable build() {
/* 277 */       (new Type[1])[0] = ClassType.OBJECT_TYPE; return new TypeVariable(this.identifier, this.bounds.isEmpty() ? new Type[1] : this.bounds.<Type>toArray(Type.EMPTY_ARRAY), 
/* 278 */           annotationsArray());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\TypeVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */