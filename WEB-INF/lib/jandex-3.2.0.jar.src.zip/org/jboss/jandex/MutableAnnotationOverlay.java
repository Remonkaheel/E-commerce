/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MutableAnnotationOverlay
/*     */   extends AnnotationOverlay
/*     */ {
/*     */   static Builder builder(IndexView index) {
/*  29 */     Objects.requireNonNull(index);
/*  30 */     return new Builder(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addAnnotation(Declaration paramDeclaration, AnnotationInstance paramAnnotationInstance);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeAnnotations(Declaration paramDeclaration, Predicate<AnnotationInstance> paramPredicate);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<AnnotationTransformation> freeze();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final IndexView index;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean compatibleMode;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean runtimeAnnotationsOnly;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean inheritedAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder(IndexView index) {
/*  74 */       this.index = index;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder compatibleMode() {
/*  90 */       this.compatibleMode = true;
/*  91 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder runtimeAnnotationsOnly() {
/* 104 */       this.runtimeAnnotationsOnly = true;
/* 105 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder inheritedAnnotations() {
/* 115 */       this.inheritedAnnotations = true;
/* 116 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MutableAnnotationOverlay build() {
/* 125 */       return new MutableAnnotationOverlayImpl(this.index, this.compatibleMode, this.runtimeAnnotationsOnly, this.inheritedAnnotations);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\MutableAnnotationOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */