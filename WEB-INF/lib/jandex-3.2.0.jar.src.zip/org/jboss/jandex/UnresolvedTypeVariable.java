/*     */ package org.jboss.jandex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnresolvedTypeVariable
/*     */   extends Type
/*     */ {
/*     */   private final String name;
/*     */   
/*     */   UnresolvedTypeVariable(String name) {
/*  31 */     this(name, null);
/*     */   }
/*     */   
/*     */   UnresolvedTypeVariable(String name, AnnotationInstance[] annotations) {
/*  35 */     super(DotName.OBJECT_NAME, annotations);
/*  36 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String identifier() {
/*  52 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/*  57 */     return Type.Kind.UNRESOLVED_TYPE_VARIABLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnresolvedTypeVariable asUnresolvedTypeVariable() {
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/*  67 */     return new UnresolvedTypeVariable(this.name, newAnnotations);
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(boolean simple) {
/*  72 */     StringBuilder builder = new StringBuilder();
/*  73 */     appendAnnotations(builder);
/*  74 */     builder.append(this.name);
/*  75 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  80 */     if (this == o) {
/*  81 */       return true;
/*     */     }
/*     */     
/*  84 */     if (!(o instanceof UnresolvedTypeVariable)) {
/*  85 */       return false;
/*     */     }
/*     */     
/*  88 */     UnresolvedTypeVariable other = (UnresolvedTypeVariable)o;
/*     */     
/*  90 */     return (super.equals(other) && this.name.equals(other.name));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  95 */     int hash = super.hashCode();
/*  96 */     hash = 31 * hash + this.name.hashCode();
/*  97 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 102 */     if (this == o) {
/* 103 */       return true;
/*     */     }
/*     */     
/* 106 */     if (!(o instanceof UnresolvedTypeVariable)) {
/* 107 */       return false;
/*     */     }
/*     */     
/* 110 */     UnresolvedTypeVariable other = (UnresolvedTypeVariable)o;
/*     */     
/* 112 */     return (super.internEquals(other) && this.name.equals(other.name));
/*     */   }
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 117 */     int hash = super.internHashCode();
/* 118 */     hash = 31 * hash + this.name.hashCode();
/* 119 */     return hash;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\UnresolvedTypeVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */