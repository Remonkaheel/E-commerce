/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Type
/*     */   implements Descriptor
/*     */ {
/*  42 */   public static final Type[] EMPTY_ARRAY = new Type[0];
/*  43 */   private static final AnnotationInstance[] EMPTY_ANNOTATIONS = new AnnotationInstance[0];
/*     */ 
/*     */   
/*     */   private final DotName name;
/*     */ 
/*     */   
/*     */   private final AnnotationInstance[] annotations;
/*     */ 
/*     */   
/*     */   public enum Kind
/*     */   {
/*  54 */     CLASS,
/*     */ 
/*     */     
/*  57 */     ARRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     PRIMITIVE,
/*     */ 
/*     */     
/*  65 */     VOID,
/*     */ 
/*     */     
/*  68 */     TYPE_VARIABLE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     UNRESOLVED_TYPE_VARIABLE,
/*     */ 
/*     */     
/*  78 */     WILDCARD_TYPE,
/*     */ 
/*     */     
/*  81 */     PARAMETERIZED_TYPE,
/*     */ 
/*     */     
/*  84 */     TYPE_VARIABLE_REFERENCE;
/*     */ 
/*     */ 
/*     */     
/*     */     public static Kind fromOrdinal(int ordinal) {
/*  89 */       switch (ordinal)
/*     */       { case 0:
/*  91 */           return CLASS;
/*     */         case 1:
/*  93 */           return ARRAY;
/*     */         case 2:
/*  95 */           return PRIMITIVE;
/*     */         
/*     */         default:
/*  98 */           return VOID;
/*     */         case 4:
/* 100 */           return TYPE_VARIABLE;
/*     */         case 5:
/* 102 */           return UNRESOLVED_TYPE_VARIABLE;
/*     */         case 6:
/* 104 */           return WILDCARD_TYPE;
/*     */         case 7:
/* 106 */           return PARAMETERIZED_TYPE;
/*     */         case 8:
/* 108 */           break; }  return TYPE_VARIABLE_REFERENCE;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   Type(DotName name, AnnotationInstance[] annotations) {
/* 114 */     this.name = name;
/* 115 */     annotations = (annotations == null) ? EMPTY_ANNOTATIONS : annotations;
/*     */     
/* 117 */     if (annotations.length > 1) {
/* 118 */       Arrays.sort(annotations, AnnotationInstance.NAME_COMPARATOR);
/*     */     }
/*     */     
/* 121 */     this.annotations = annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type create(DotName name, Kind kind) {
/*     */     String string;
/*     */     int start;
/*     */     int depth;
/*     */     Type type;
/*     */     char c;
/*     */     int end;
/* 149 */     if (name == null) {
/* 150 */       throw new IllegalArgumentException("name can not be null!");
/*     */     }
/* 152 */     if (kind == null) {
/* 153 */       throw new IllegalArgumentException("kind can not be null!");
/*     */     }
/*     */     
/* 156 */     switch (kind) {
/*     */       case ARRAY:
/* 158 */         string = name.toString();
/* 159 */         start = string.lastIndexOf('[');
/* 160 */         if (start < 0) {
/* 161 */           throw new IllegalArgumentException("Not a valid array name");
/*     */         }
/* 163 */         depth = ++start;
/*     */         
/* 165 */         type = PrimitiveType.decode(string.charAt(start));
/* 166 */         if (type != null) {
/* 167 */           return new ArrayType(type, depth);
/*     */         }
/*     */         
/* 170 */         c = string.charAt(start);
/* 171 */         switch (c)
/*     */         { case 'V':
/* 173 */             type = VoidType.VOID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 189 */             return new ArrayType(type, depth);case 'L': end = start; while (string.charAt(++end) != ';'); type = new ClassType(DotName.createSimple(string.substring(start + 1, end))); return new ArrayType(type, depth); }  type = PrimitiveType.decode(string.charAt(start)); if (type == null) throw new IllegalArgumentException("Component type not supported: " + c);  return new ArrayType(type, depth);
/*     */       case CLASS:
/* 191 */         return new ClassType(name);
/*     */       case PRIMITIVE:
/* 193 */         return PrimitiveType.decode(name.toString());
/*     */       case VOID:
/* 195 */         return VoidType.VOID;
/*     */     } 
/* 197 */     throw new IllegalArgumentException("Kind not supported: " + kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type create(Class<?> clazz) {
/* 214 */     if (clazz.isArray()) {
/* 215 */       int dimensions = 1;
/* 216 */       Class<?> componentType = clazz.getComponentType();
/* 217 */       while (componentType.isArray()) {
/* 218 */         dimensions++;
/* 219 */         componentType = componentType.getComponentType();
/*     */       } 
/* 221 */       return ArrayType.create(create(componentType), dimensions);
/*     */     } 
/*     */     
/* 224 */     if (clazz.isPrimitive()) {
/* 225 */       if (clazz == void.class)
/* 226 */         return VoidType.VOID; 
/* 227 */       if (clazz == boolean.class)
/* 228 */         return PrimitiveType.BOOLEAN; 
/* 229 */       if (clazz == byte.class)
/* 230 */         return PrimitiveType.BYTE; 
/* 231 */       if (clazz == short.class)
/* 232 */         return PrimitiveType.SHORT; 
/* 233 */       if (clazz == int.class)
/* 234 */         return PrimitiveType.INT; 
/* 235 */       if (clazz == long.class)
/* 236 */         return PrimitiveType.LONG; 
/* 237 */       if (clazz == float.class)
/* 238 */         return PrimitiveType.FLOAT; 
/* 239 */       if (clazz == double.class)
/* 240 */         return PrimitiveType.DOUBLE; 
/* 241 */       if (clazz == char.class) {
/* 242 */         return PrimitiveType.CHAR;
/*     */       }
/* 244 */       throw new IllegalArgumentException("Unknown primitive type " + clazz);
/*     */     } 
/*     */ 
/*     */     
/* 248 */     return ClassType.create(DotName.createSimple(clazz.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type createWithAnnotations(DotName name, Kind kind, AnnotationInstance[] annotations) {
/* 262 */     Type type = create(name, kind);
/* 263 */     return (annotations == null) ? type : type.copyType(annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DotName name() {
/* 291 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Kind kind();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassType asClassType() {
/* 310 */     throw new IllegalArgumentException("Not a class type!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedType asParameterizedType() {
/* 322 */     throw new IllegalArgumentException("Not a parameterized type!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeVariable asTypeVariable() {
/* 334 */     throw new IllegalArgumentException("Not a type variable!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeVariableReference asTypeVariableReference() {
/* 346 */     throw new IllegalArgumentException("Not a type variable reference!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayType asArrayType() {
/* 358 */     throw new IllegalArgumentException("Not an array type!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WildcardType asWildcardType() {
/* 370 */     throw new IllegalArgumentException("Not a wildcard type!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedTypeVariable asUnresolvedTypeVariable() {
/* 382 */     throw new IllegalArgumentException("Not an unresolved type variable!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrimitiveType asPrimitiveType() {
/* 394 */     throw new IllegalArgumentException("Not a primitive type!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoidType asVoidType() {
/* 406 */     throw new IllegalArgumentException("Not a void type!");
/*     */   }
/*     */   
/*     */   AnnotationInstance[] annotationArray() {
/* 410 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAnnotation(DotName name) {
/* 421 */     return (annotation(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationInstance annotation(DotName name) {
/* 434 */     return AnnotationInstance.binarySearch(this.annotations, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<AnnotationInstance> annotationsWithRepeatable(DotName name, IndexView index) {
/* 456 */     if (index == null) {
/* 457 */       throw new IllegalArgumentException("Index must not be null");
/*     */     }
/* 459 */     List<AnnotationInstance> instances = new ArrayList<>();
/* 460 */     AnnotationInstance declaredInstance = annotation(name);
/* 461 */     if (declaredInstance != null) {
/* 462 */       instances.add(declaredInstance);
/*     */     }
/* 464 */     ClassInfo annotationClass = index.getClassByName(name);
/* 465 */     if (annotationClass == null) {
/* 466 */       throw new IllegalArgumentException("Index does not contain the annotation definition: " + name);
/*     */     }
/* 468 */     if (!annotationClass.isAnnotation()) {
/* 469 */       throw new IllegalArgumentException("Not an annotation type: " + annotationClass);
/*     */     }
/* 471 */     AnnotationInstance repeatable = annotationClass.declaredAnnotation(DotName.REPEATABLE_NAME);
/* 472 */     if (repeatable != null) {
/* 473 */       Type containingType = repeatable.value().asClass();
/* 474 */       AnnotationInstance container = annotation(containingType.name());
/* 475 */       if (container != null) {
/* 476 */         for (AnnotationInstance nestedInstance : container.value().asNestedArray()) {
/* 477 */           instances.add(AnnotationInstance.create(nestedInstance, container.target()));
/*     */         }
/*     */       }
/*     */     } 
/* 481 */     return Collections.unmodifiableList(instances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> annotations() {
/* 494 */     return new ImmutableArrayList<>(this.annotations);
/*     */   }
/*     */   
/*     */   Type addAnnotation(AnnotationInstance annotation) {
/* 498 */     AnnotationTarget target = annotation.target();
/* 499 */     if (target != null) {
/* 500 */       throw new IllegalArgumentException("Invalid target type");
/*     */     }
/*     */     
/* 503 */     AnnotationInstance[] newAnnotations = Arrays.<AnnotationInstance>copyOf(this.annotations, this.annotations.length + 1);
/* 504 */     newAnnotations[newAnnotations.length - 1] = annotation;
/* 505 */     return copyType(newAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Type copyType(AnnotationInstance[] paramArrayOfAnnotationInstance);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 517 */     return toString(false);
/*     */   }
/*     */   
/*     */   String toString(boolean simple) {
/* 521 */     StringBuilder builder = new StringBuilder();
/* 522 */     String packagePrefix = this.name.packagePrefix();
/* 523 */     if (packagePrefix != null) {
/* 524 */       builder.append(packagePrefix).append('.');
/*     */     }
/* 526 */     appendAnnotations(builder);
/* 527 */     builder.append(this.name.withoutPackagePrefix());
/*     */     
/* 529 */     return builder.toString();
/*     */   }
/*     */   
/*     */   void appendAnnotations(StringBuilder builder) {
/* 533 */     AnnotationInstance[] annotations = this.annotations;
/* 534 */     if (annotations.length > 0) {
/* 535 */       for (AnnotationInstance instance : annotations) {
/* 536 */         builder.append(instance.toString(true)).append(' ');
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String descriptor(Function<String, Type> typeVariableSubstitution) {
/* 573 */     StringBuilder result = new StringBuilder();
/* 574 */     DescriptorReconstruction.typeDescriptor(this, typeVariableSubstitution, result);
/* 575 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 589 */     if (this == o) {
/* 590 */       return true;
/*     */     }
/*     */     
/* 593 */     if (o == null || getClass() != o.getClass()) {
/* 594 */       return false;
/*     */     }
/*     */     
/* 597 */     Type type = (Type)o;
/*     */     
/* 599 */     return (this.name.equals(type.name) && Arrays.equals((Object[])this.annotations, (Object[])type.annotations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 609 */     int result = this.name.hashCode();
/* 610 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/* 611 */     return result;
/*     */   }
/*     */   
/*     */   boolean internEquals(Object o) {
/* 615 */     if (this == o) {
/* 616 */       return true;
/*     */     }
/*     */     
/* 619 */     if (o == null || getClass() != o.getClass()) {
/* 620 */       return false;
/*     */     }
/*     */     
/* 623 */     Type type = (Type)o;
/*     */     
/* 625 */     return (this.name.equals(type.name) && Arrays.equals((Object[])this.annotations, (Object[])type.annotations));
/*     */   }
/*     */   
/*     */   int internHashCode() {
/* 629 */     int result = this.name.hashCode();
/* 630 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/* 631 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class Builder<THIS extends Builder<THIS>>
/*     */   {
/*     */     protected final DotName name;
/*     */ 
/*     */     
/*     */     protected final List<AnnotationInstance> annotations;
/*     */ 
/*     */ 
/*     */     
/*     */     protected Builder(DotName name) {
/* 646 */       this.name = Objects.<DotName>requireNonNull(name);
/* 647 */       this.annotations = new ArrayList<>();
/*     */     }
/*     */ 
/*     */     
/*     */     protected THIS self() {
/* 652 */       return (THIS)this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected AnnotationInstance[] annotationsArray() {
/* 659 */       return this.annotations.isEmpty() ? null : this.annotations.<AnnotationInstance>toArray(AnnotationInstance.EMPTY_ARRAY);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public THIS addAnnotation(AnnotationInstance annotation) {
/* 671 */       this.annotations.add(Objects.<AnnotationInstance>requireNonNull(annotation));
/* 672 */       return self();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Type.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */