/*     */ package org.jboss.jandex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WildcardType
/*     */   extends Type
/*     */ {
/*  35 */   public static final WildcardType UNBOUNDED = new WildcardType(null, true);
/*     */ 
/*     */   
/*     */   private final boolean isExtends;
/*     */ 
/*     */   
/*     */   private final Type bound;
/*     */ 
/*     */   
/*     */   private int hash;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static WildcardType create(Type bound, boolean isExtends) {
/*  49 */     return new WildcardType(bound, isExtends);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WildcardType createUpperBound(Type upperBound) {
/*  60 */     return new WildcardType(upperBound, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WildcardType createUpperBound(Class<?> upperBound) {
/*  71 */     return createUpperBound(ClassType.create(upperBound));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WildcardType createLowerBound(Type lowerBound) {
/*  82 */     return new WildcardType(lowerBound, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WildcardType createLowerBound(Class<?> lowerBound) {
/*  93 */     return createLowerBound(ClassType.create(lowerBound));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 103 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WildcardType(Type bound, boolean isExtends) {
/* 111 */     this(bound, isExtends, (AnnotationInstance[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   WildcardType(Type bound, boolean isExtends, AnnotationInstance[] annotations) {
/* 117 */     super(DotName.OBJECT_NAME, annotations);
/* 118 */     this.bound = (isExtends && bound == null) ? ClassType.OBJECT_TYPE : bound;
/* 119 */     this.isExtends = isExtends;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DotName name() {
/* 125 */     if (this.isExtends && this.bound != null) {
/* 126 */       return this.bound.name();
/*     */     }
/* 128 */     return DotName.OBJECT_NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type extendsBound() {
/* 140 */     return this.isExtends ? this.bound : ClassType.OBJECT_TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type superBound() {
/* 152 */     return this.isExtends ? null : this.bound;
/*     */   }
/*     */   
/*     */   Type bound() {
/* 156 */     return this.bound;
/*     */   }
/*     */   
/*     */   boolean isExtends() {
/* 160 */     return this.isExtends;
/*     */   }
/*     */   
/*     */   boolean hasImplicitObjectBound() {
/* 164 */     return (this.isExtends && this.bound == ClassType.OBJECT_TYPE);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type.Kind kind() {
/* 169 */     return Type.Kind.WILDCARD_TYPE;
/*     */   }
/*     */ 
/*     */   
/*     */   public WildcardType asWildcardType() {
/* 174 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Type copyType(AnnotationInstance[] newAnnotations) {
/* 179 */     return new WildcardType(this.bound, this.isExtends, newAnnotations);
/*     */   }
/*     */   
/*     */   Type copyType(Type bound) {
/* 183 */     return new WildcardType(bound, this.isExtends, annotationArray());
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(boolean simple) {
/* 188 */     StringBuilder builder = new StringBuilder();
/* 189 */     appendAnnotations(builder);
/* 190 */     builder.append('?');
/*     */     
/* 192 */     if (this.isExtends && this.bound != ClassType.OBJECT_TYPE) {
/* 193 */       builder.append(" extends ").append(this.bound.toString(true));
/*     */     }
/*     */     
/* 196 */     if (!this.isExtends && this.bound != null) {
/* 197 */       builder.append(" super ").append(this.bound.toString(true));
/*     */     }
/*     */     
/* 200 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 205 */     if (this == o) {
/* 206 */       return true;
/*     */     }
/* 208 */     if (!super.equals(o)) {
/* 209 */       return false;
/*     */     }
/*     */     
/* 212 */     WildcardType other = (WildcardType)o;
/* 213 */     return (this.isExtends == other.isExtends && this.bound.equals(other.bound));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 218 */     int hash = this.hash;
/* 219 */     if (hash != 0) {
/* 220 */       return hash;
/*     */     }
/*     */     
/* 223 */     hash = super.hashCode();
/* 224 */     hash = 31 * hash + (this.isExtends ? 1 : 0);
/* 225 */     hash = 31 * hash + this.bound.hashCode();
/* 226 */     return this.hash = hash;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean internEquals(Object o) {
/* 231 */     if (this == o) {
/* 232 */       return true;
/*     */     }
/* 234 */     if (!super.internEquals(o)) {
/* 235 */       return false;
/*     */     }
/*     */     
/* 238 */     WildcardType other = (WildcardType)o;
/* 239 */     return (this.isExtends == other.isExtends && this.bound.internEquals(other.bound));
/*     */   }
/*     */ 
/*     */   
/*     */   int internHashCode() {
/* 244 */     int hash = super.internHashCode();
/* 245 */     hash = 31 * hash + (this.isExtends ? 1 : 0);
/* 246 */     hash = 31 * hash + this.bound.internHashCode();
/* 247 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */     extends Type.Builder<Builder>
/*     */   {
/*     */     private boolean isExtends = true;
/*     */ 
/*     */ 
/*     */     
/*     */     private Type bound;
/*     */ 
/*     */ 
/*     */     
/*     */     Builder() {
/* 265 */       super(DotName.OBJECT_NAME);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setUpperBound(Class<?> upperBound) {
/* 275 */       return setUpperBound(ClassType.create(upperBound));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setUpperBound(Type upperBound) {
/* 285 */       this.bound = upperBound;
/* 286 */       this.isExtends = true;
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setLowerBound(Class<?> lowerBound) {
/* 297 */       return setLowerBound(ClassType.create(lowerBound));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setLowerBound(Type lowerBound) {
/* 307 */       this.bound = lowerBound;
/* 308 */       this.isExtends = false;
/* 309 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WildcardType build() {
/* 318 */       return new WildcardType(this.bound, this.isExtends, annotationsArray());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\WildcardType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */