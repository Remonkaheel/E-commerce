/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JandexAntTask
/*     */   extends Task
/*     */ {
/*  37 */   private final List<FileSet> filesets = new ArrayList<>();
/*     */   
/*     */   private boolean modify = false;
/*     */   
/*     */   private boolean newJar = false;
/*     */   
/*     */   private boolean verbose = false;
/*     */   
/*     */   private boolean run = true;
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/*  49 */     if (!this.run) {
/*     */       return;
/*     */     }
/*  52 */     if (this.modify && this.newJar) {
/*  53 */       throw new BuildException("Specifying both modify and newJar does not make sense.");
/*     */     }
/*  55 */     Indexer indexer = new Indexer();
/*  56 */     for (FileSet fileset : this.filesets) {
/*  57 */       String[] files = fileset.getDirectoryScanner(getProject()).getIncludedFiles();
/*  58 */       for (String file : files) {
/*  59 */         if (file.endsWith(".jar")) {
/*     */           try {
/*  61 */             JarIndexer.createJarIndex(new File(fileset.getDir().getAbsolutePath() + "/" + file), indexer, this.modify, this.newJar, this.verbose);
/*     */           }
/*  63 */           catch (IOException e) {
/*  64 */             throw new BuildException(e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFileset(FileSet fileset) {
/*  73 */     this.filesets.add(fileset);
/*     */   }
/*     */   
/*     */   public boolean isModify() {
/*  77 */     return this.modify;
/*     */   }
/*     */   
/*     */   public void setModify(boolean modify) {
/*  81 */     this.modify = modify;
/*     */   }
/*     */   
/*     */   public boolean isVerbose() {
/*  85 */     return this.verbose;
/*     */   }
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/*  89 */     this.verbose = verbose;
/*     */   }
/*     */   
/*     */   public boolean isRun() {
/*  93 */     return this.run;
/*     */   }
/*     */   
/*     */   public void setRun(boolean run) {
/*  97 */     this.run = run;
/*     */   }
/*     */   
/*     */   public boolean isNewJar() {
/* 101 */     return this.newJar;
/*     */   }
/*     */   
/*     */   public void setNewJar(boolean newJar) {
/* 105 */     this.newJar = newJar;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\JandexAntTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */