/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.AbstractList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FieldInfoGenerator
/*    */   extends AbstractList<FieldInfo>
/*    */ {
/*    */   private final FieldInternal[] fields;
/*    */   private final ClassInfo clazz;
/*    */   private final byte[] positions;
/*    */   
/*    */   public FieldInfoGenerator(ClassInfo clazz, FieldInternal[] fields, byte[] positions) {
/* 35 */     this.clazz = clazz;
/* 36 */     this.fields = fields;
/* 37 */     this.positions = positions;
/*    */   }
/*    */ 
/*    */   
/*    */   public FieldInfo get(int i) {
/* 42 */     FieldInternal field = (this.positions.length > 0) ? this.fields[this.positions[i] & 0xFF] : this.fields[i];
/* 43 */     return new FieldInfo(this.clazz, field);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 48 */     return this.fields.length;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\FieldInfoGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */