/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.util.AbstractList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RecordComponentInfoGenerator
/*    */   extends AbstractList<RecordComponentInfo>
/*    */ {
/*    */   private final RecordComponentInternal[] recordComponents;
/*    */   private final ClassInfo clazz;
/*    */   private final byte[] positions;
/*    */   
/*    */   public RecordComponentInfoGenerator(ClassInfo clazz, RecordComponentInternal[] recordComponents, byte[] positions) {
/* 33 */     this.clazz = clazz;
/* 34 */     this.recordComponents = recordComponents;
/* 35 */     this.positions = positions;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordComponentInfo get(int i) {
/* 41 */     RecordComponentInternal recordComponent = (this.positions.length > 0) ? this.recordComponents[this.positions[i] & 0xFF] : this.recordComponents[i];
/* 42 */     return new RecordComponentInfo(this.clazz, recordComponent);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 47 */     return this.recordComponents.length;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\RecordComponentInfoGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */