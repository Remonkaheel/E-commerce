/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IndexWriter
/*     */ {
/*     */   private final OutputStream out;
/*     */   
/*     */   public IndexWriter(OutputStream out) {
/*  54 */     this.out = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int write(Index index) throws IOException {
/*  66 */     return write(index, 12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int write(Index index, byte version) throws IOException {
/*  80 */     return write(index, version & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int write(Index index, int version) throws IOException {
/*  94 */     IndexWriterImpl writer = getWriter(version);
/*  95 */     if (writer == null) {
/*  96 */       throw new UnsupportedVersion("Can't write index version " + version + "; this IndexWriter only supports index versions " + '\001' + "-" + '\003' + "," + '\006' + "-" + '\f');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     return writer.write(index);
/*     */   }
/*     */   
/*     */   private IndexWriterImpl getWriter(int version) {
/* 106 */     if (version >= 1 && version <= 3) {
/* 107 */       return new IndexWriterV1(this.out, version);
/*     */     }
/*     */     
/* 110 */     if (version >= 6 && version <= 12) {
/* 111 */       return new IndexWriterV2(this.out, version);
/*     */     }
/*     */     
/* 114 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */