/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class IndexReaderV2
/*     */   extends IndexReaderImpl
/*     */ {
/*     */   static final int MIN_VERSION = 6;
/*     */   static final int MAX_VERSION = 12;
/*     */   private static final byte NULL_TARGET_TAG = 0;
/*     */   private static final byte FIELD_TAG = 1;
/*     */   private static final byte METHOD_TAG = 2;
/*     */   private static final byte METHOD_PARAMETER_TAG = 3;
/*     */   private static final byte CLASS_TAG = 4;
/*     */   private static final byte EMPTY_TYPE_TAG = 5;
/*     */   private static final byte CLASS_EXTENDS_TYPE_TAG = 6;
/*     */   private static final byte TYPE_PARAMETER_TAG = 7;
/*     */   private static final byte TYPE_PARAMETER_BOUND_TAG = 8;
/*     */   private static final byte METHOD_PARAMETER_TYPE_TAG = 9;
/*     */   private static final byte THROWS_TYPE_TAG = 10;
/*     */   private static final byte RECORD_COMPONENT_TAG = 11;
/*     */   private static final int AVALUE_BYTE = 1;
/*     */   private static final int AVALUE_SHORT = 2;
/*     */   private static final int AVALUE_INT = 3;
/*     */   private static final int AVALUE_CHAR = 4;
/*     */   private static final int AVALUE_FLOAT = 5;
/*     */   private static final int AVALUE_DOUBLE = 6;
/*     */   private static final int AVALUE_LONG = 7;
/*     */   private static final int AVALUE_BOOLEAN = 8;
/*     */   private static final int AVALUE_STRING = 9;
/*     */   private static final int AVALUE_CLASS = 10;
/*     */   private static final int AVALUE_ENUM = 11;
/*     */   private static final int AVALUE_ARRAY = 12;
/*     */   private static final int AVALUE_NESTED = 13;
/*     */   private static final int HAS_ENCLOSING_METHOD = 1;
/*     */   private final PackedDataInputStream input;
/*     */   private final int version;
/*     */   private byte[][] byteTable;
/*     */   private String[] stringTable;
/*     */   private DotName[] nameTable;
/*     */   private Type[] typeTable;
/*     */   private Type[][] typeListTable;
/*     */   private AnnotationInstance[] annotationTable;
/*     */   private MethodInternal[] methodTable;
/*     */   private FieldInternal[] fieldTable;
/*     */   private RecordComponentInternal[] recordComponentTable;
/*     */   private HashMap<DotName, Set<DotName>> users;
/*     */   
/*     */   IndexReaderV2(PackedDataInputStream input, int version) {
/*  95 */     this.input = input;
/*  96 */     this.version = version;
/*     */   }
/*     */   
/*     */   Index read() throws IOException {
/*     */     try {
/* 101 */       PackedDataInputStream stream = this.input;
/* 102 */       int annotationsSize = stream.readPackedU32();
/* 103 */       int implementorsSize = stream.readPackedU32();
/* 104 */       int subinterfacesSize = 0;
/* 105 */       if (this.version >= 11) {
/* 106 */         subinterfacesSize = stream.readPackedU32();
/*     */       }
/* 108 */       int subclassesSize = stream.readPackedU32();
/* 109 */       int usersSize = 0;
/* 110 */       if (this.version >= 10) {
/* 111 */         usersSize = stream.readPackedU32();
/* 112 */         this.users = new HashMap<>(usersSize);
/*     */       } 
/*     */       
/* 115 */       readByteTable(stream);
/* 116 */       readStringTable(stream);
/* 117 */       readNameTable(stream);
/*     */       
/* 119 */       this.typeTable = new Type[stream.readPackedU32() + 1];
/* 120 */       this.typeListTable = new Type[stream.readPackedU32() + 1][];
/* 121 */       this.annotationTable = new AnnotationInstance[stream.readPackedU32() + 1];
/*     */       
/* 123 */       readTypeTable(stream);
/* 124 */       readTypeListTable(stream);
/* 125 */       if (this.version >= 10) {
/* 126 */         readUsers(stream, usersSize);
/*     */       }
/* 128 */       readMethodTable(stream);
/* 129 */       readFieldTable(stream);
/* 130 */       if (this.version >= 10) {
/* 131 */         readRecordComponentTable(stream);
/*     */       }
/* 133 */       return readClasses(stream, annotationsSize, implementorsSize, subinterfacesSize, subclassesSize);
/*     */     } finally {
/* 135 */       this.byteTable = null;
/* 136 */       this.stringTable = null;
/* 137 */       this.nameTable = null;
/* 138 */       this.typeTable = null;
/* 139 */       this.typeListTable = null;
/* 140 */       this.annotationTable = null;
/* 141 */       this.methodTable = null;
/* 142 */       this.fieldTable = null;
/* 143 */       this.recordComponentTable = null;
/* 144 */       this.users = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readUsers(PackedDataInputStream stream, int usersSize) throws IOException {
/* 149 */     for (int i = 0; i < usersSize; i++) {
/* 150 */       DotName user = this.nameTable[stream.readPackedU32()];
/* 151 */       int usesCount = stream.readPackedU32();
/* 152 */       Set<DotName> uses = new HashSet<>(usesCount);
/* 153 */       for (int j = 0; j < usesCount; j++) {
/* 154 */         uses.add(this.nameTable[stream.readPackedU32()]);
/*     */       }
/* 156 */       this.users.put(user, uses);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readByteTable(PackedDataInputStream stream) throws IOException {
/* 162 */     int size = stream.readPackedU32() + 1;
/* 163 */     byte[][] byteTable = this.byteTable = new byte[size][];
/* 164 */     for (int i = 1; i < size; i++) {
/* 165 */       int len = stream.readPackedU32();
/* 166 */       byteTable[i] = new byte[len];
/* 167 */       stream.readFully(byteTable[i], 0, len);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readStringTable(PackedDataInputStream stream) throws IOException {
/* 173 */     int size = stream.readPackedU32() + 1;
/* 174 */     String[] stringTable = this.stringTable = new String[size];
/* 175 */     for (int i = 1; i < size; i++) {
/* 176 */       stringTable[i] = stream.readUTF();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void readNameTable(PackedDataInputStream stream) throws IOException {
/* 182 */     int entries = stream.readPackedU32() + 1;
/* 183 */     int lastDepth = -1;
/* 184 */     DotName curr = null;
/*     */     
/* 186 */     this.nameTable = new DotName[entries];
/* 187 */     for (int i = 1; i < entries; i++) {
/*     */       
/* 189 */       if (this.version >= 11) {
/* 190 */         int prefixOffset = stream.readPackedU32();
/* 191 */         boolean inner = ((prefixOffset & 0x1) == 1);
/* 192 */         prefixOffset >>= 1;
/*     */         
/* 194 */         int prefixPosition = (prefixOffset == 0) ? 0 : (i - prefixOffset);
/* 195 */         DotName prefix = this.nameTable[prefixPosition];
/* 196 */         String local = this.stringTable[stream.readPackedU32()];
/* 197 */         this.nameTable[i] = new DotName(prefix, local, true, inner);
/*     */       } else {
/* 199 */         int depth = stream.readPackedU32();
/* 200 */         boolean inner = ((depth & 0x1) == 1);
/* 201 */         depth >>= 1;
/*     */         
/* 203 */         String local = this.stringTable[stream.readPackedU32()];
/*     */         
/* 205 */         if (depth <= lastDepth) {
/* 206 */           while (lastDepth-- >= depth) {
/* 207 */             assert curr != null;
/* 208 */             curr = curr.prefix();
/*     */           } 
/*     */         }
/*     */         
/* 212 */         this.nameTable[i] = curr = new DotName(curr, local, true, inner);
/* 213 */         lastDepth = depth;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readTypeTable(PackedDataInputStream stream) throws IOException {
/* 219 */     Map<TypeVariableReference, Integer> references = new IdentityHashMap<>();
/*     */ 
/*     */     
/* 222 */     for (int i = 1; i < this.typeTable.length; i++) {
/* 223 */       this.typeTable[i] = readTypeEntry(stream, references);
/*     */     }
/*     */ 
/*     */     
/* 227 */     for (Map.Entry<TypeVariableReference, Integer> entry : references.entrySet()) {
/* 228 */       TypeVariableReference reference = entry.getKey();
/* 229 */       Integer position = entry.getValue();
/* 230 */       assert position != null;
/* 231 */       assert this.typeTable[position.intValue()] instanceof TypeVariable;
/* 232 */       reference.setTarget((TypeVariable)this.typeTable[position.intValue()]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int findNextNull(Object[] array, int start) {
/* 237 */     while (start < array.length) {
/* 238 */       if (array[start] == null) {
/* 239 */         return start;
/*     */       }
/* 241 */       start++;
/*     */     } 
/*     */     
/* 244 */     return array.length;
/*     */   }
/*     */ 
/*     */   
/*     */   private void readTypeListTable(PackedDataInputStream stream) throws IOException {
/* 249 */     Type[][] typeListTable = this.typeListTable;
/*     */     
/* 251 */     for (int i = findNextNull((Object[])typeListTable, 1); i < typeListTable.length; i = findNextNull((Object[])typeListTable, i)) {
/* 252 */       typeListTable[i] = readTypeListEntry(stream);
/*     */     }
/*     */   }
/*     */   
/*     */   private AnnotationInstance[] readAnnotations(PackedDataInputStream stream, AnnotationTarget target) throws IOException {
/* 257 */     int size = stream.readPackedU32();
/* 258 */     if (size == 0) {
/* 259 */       return AnnotationInstance.EMPTY_ARRAY;
/*     */     }
/*     */     
/* 262 */     AnnotationInstance[] annotations = new AnnotationInstance[size];
/* 263 */     for (int i = 0; i < size; i++) {
/* 264 */       int reference = stream.readPackedU32();
/* 265 */       if (this.annotationTable[reference] == null) {
/* 266 */         this.annotationTable[reference] = readAnnotationEntry(stream, target);
/*     */       }
/*     */       
/* 269 */       annotations[i] = this.annotationTable[reference];
/*     */     } 
/* 271 */     return annotations;
/*     */   }
/*     */   
/*     */   private AnnotationValue[] readAnnotationValues(PackedDataInputStream stream) throws IOException {
/* 275 */     int numValues = stream.readPackedU32();
/* 276 */     AnnotationValue[] values = (numValues > 0) ? new AnnotationValue[numValues] : AnnotationValue.EMPTY_ARRAY;
/*     */     
/* 278 */     for (int i = 0; i < numValues; i++) {
/* 279 */       AnnotationValue value = readAnnotationValue(stream);
/* 280 */       values[i] = value;
/*     */     } 
/*     */     
/* 283 */     return values; } private AnnotationValue readAnnotationValue(PackedDataInputStream stream) throws IOException {
/*     */     AnnotationValue value;
/*     */     int reference;
/*     */     AnnotationInstance nestedInstance;
/* 287 */     String name = this.stringTable[stream.readPackedU32()];
/* 288 */     int tag = stream.readByte();
/*     */     
/* 290 */     switch (tag) {
/*     */       case 1:
/* 292 */         value = new AnnotationValue.ByteValue(name, stream.readByte());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 341 */         return value;case 2: value = new AnnotationValue.ShortValue(name, (short)stream.readPackedU32()); return value;case 3: value = new AnnotationValue.IntegerValue(name, stream.readPackedU32()); return value;case 4: value = new AnnotationValue.CharacterValue(name, (char)stream.readPackedU32()); return value;case 5: value = new AnnotationValue.FloatValue(name, stream.readFloat()); return value;case 6: value = new AnnotationValue.DoubleValue(name, stream.readDouble()); return value;case 7: value = new AnnotationValue.LongValue(name, stream.readLong()); return value;case 8: value = new AnnotationValue.BooleanValue(name, stream.readBoolean()); return value;case 9: value = new AnnotationValue.StringValue(name, this.stringTable[stream.readPackedU32()]); return value;case 10: value = new AnnotationValue.ClassValue(name, this.typeTable[stream.readPackedU32()]); return value;case 11: value = new AnnotationValue.EnumValue(name, this.nameTable[stream.readPackedU32()], this.stringTable[stream.readPackedU32()]); return value;case 12: value = new AnnotationValue.ArrayValue(name, readAnnotationValues(stream)); return value;case 13: reference = stream.readPackedU32(); nestedInstance = this.annotationTable[reference]; if (nestedInstance == null) nestedInstance = this.annotationTable[reference] = readAnnotationEntry(stream, null);  value = new AnnotationValue.NestedAnnotation(name, nestedInstance); return value;
/*     */     } 
/*     */     throw new IllegalStateException("Invalid annotation value tag:" + tag);
/*     */   } private AnnotationInstance readAnnotationEntry(PackedDataInputStream stream, AnnotationTarget caller) throws IOException {
/* 345 */     DotName name = this.nameTable[stream.readPackedU32()];
/* 346 */     AnnotationTarget target = readAnnotationTarget(stream, caller);
/* 347 */     AnnotationValue[] values = readAnnotationValues(stream);
/* 348 */     boolean visible = true;
/* 349 */     if (this.version >= 11) {
/* 350 */       visible = stream.readBoolean();
/*     */     }
/* 352 */     return AnnotationInstance.create(name, visible, target, values);
/*     */   }
/*     */   
/*     */   private Type[] readTypeListReference(PackedDataInputStream stream) throws IOException {
/* 356 */     int reference = stream.readPackedU32();
/* 357 */     Type[] types = this.typeListTable[reference];
/* 358 */     if (types != null) {
/* 359 */       return types;
/*     */     }
/*     */     
/* 362 */     this.typeListTable[reference] = readTypeListEntry(stream); return readTypeListEntry(stream);
/*     */   }
/*     */   
/*     */   private Type[] readTypeListEntry(PackedDataInputStream stream) throws IOException {
/* 366 */     int size = stream.readPackedU32();
/* 367 */     if (size == 0) {
/* 368 */       return Type.EMPTY_ARRAY;
/*     */     }
/*     */     
/* 371 */     Type[] types = new Type[size];
/* 372 */     for (int i = 0; i < size; i++) {
/* 373 */       types[i] = this.typeTable[stream.readPackedU32()];
/*     */     }
/*     */     
/* 376 */     return types; } private Type readTypeEntry(PackedDataInputStream stream, Map<TypeVariableReference, Integer> references) throws IOException { DotName dotName1; int dimensions, primitive; Type type; String str1; boolean isExtends; DotName name; String identifier; AnnotationInstance[] arrayOfAnnotationInstance2; Type component, type1; AnnotationInstance[] arrayOfAnnotationInstance1; Type[] bounds; AnnotationInstance[] annotations; Type bound; int reference, position; AnnotationInstance[] arrayOfAnnotationInstance3; Type owner;
/*     */     DotName className;
/*     */     Type[] parameters;
/*     */     AnnotationInstance[] arrayOfAnnotationInstance4, arrayOfAnnotationInstance5;
/*     */     TypeVariableReference typeVariableReference;
/* 381 */     Type.Kind kind = Type.Kind.fromOrdinal(stream.readUnsignedByte());
/*     */     
/* 383 */     switch (kind) {
/*     */       case CLASS:
/* 385 */         dotName1 = this.nameTable[stream.readPackedU32()];
/* 386 */         arrayOfAnnotationInstance2 = readAnnotations(stream, null);
/* 387 */         return new ClassType(dotName1, arrayOfAnnotationInstance2);
/*     */       
/*     */       case ARRAY:
/* 390 */         dimensions = stream.readPackedU32();
/* 391 */         component = this.typeTable[stream.readPackedU32()];
/* 392 */         arrayOfAnnotationInstance3 = readAnnotations(stream, null);
/* 393 */         return new ArrayType(component, dimensions, arrayOfAnnotationInstance3);
/*     */       
/*     */       case PRIMITIVE:
/* 396 */         primitive = stream.readUnsignedByte();
/* 397 */         type1 = PrimitiveType.fromOridinal(primitive);
/* 398 */         arrayOfAnnotationInstance3 = readAnnotations(stream, null);
/* 399 */         return (arrayOfAnnotationInstance3.length > 0) ? type1.copyType(arrayOfAnnotationInstance3) : type1;
/*     */       
/*     */       case VOID:
/* 402 */         type = VoidType.VOID;
/* 403 */         arrayOfAnnotationInstance1 = readAnnotations(stream, null);
/* 404 */         return (arrayOfAnnotationInstance1.length > 0) ? type.copyType(arrayOfAnnotationInstance1) : type;
/*     */       
/*     */       case TYPE_VARIABLE:
/* 407 */         str1 = this.stringTable[stream.readPackedU32()];
/* 408 */         bounds = readTypeListReference(stream);
/* 409 */         arrayOfAnnotationInstance3 = readAnnotations(stream, null);
/* 410 */         return new TypeVariable(str1, bounds, arrayOfAnnotationInstance3);
/*     */       
/*     */       case UNRESOLVED_TYPE_VARIABLE:
/* 413 */         str1 = this.stringTable[stream.readPackedU32()];
/* 414 */         annotations = readAnnotations(stream, null);
/* 415 */         return new UnresolvedTypeVariable(str1, annotations);
/*     */       
/*     */       case WILDCARD_TYPE:
/* 418 */         isExtends = (stream.readPackedU32() == 1);
/* 419 */         bound = this.typeTable[stream.readPackedU32()];
/* 420 */         arrayOfAnnotationInstance3 = readAnnotations(stream, null);
/* 421 */         return new WildcardType(bound, isExtends, arrayOfAnnotationInstance3);
/*     */ 
/*     */       
/*     */       case PARAMETERIZED_TYPE:
/* 425 */         name = this.nameTable[stream.readPackedU32()];
/* 426 */         reference = stream.readPackedU32();
/* 427 */         owner = this.typeTable[reference];
/* 428 */         parameters = readTypeListReference(stream);
/* 429 */         arrayOfAnnotationInstance5 = readAnnotations(stream, null);
/* 430 */         return new ParameterizedType(name, parameters, owner, arrayOfAnnotationInstance5);
/*     */       
/*     */       case TYPE_VARIABLE_REFERENCE:
/* 433 */         identifier = this.stringTable[stream.readPackedU32()];
/* 434 */         position = stream.readPackedU32();
/* 435 */         className = null;
/* 436 */         if (this.version >= 12) {
/* 437 */           className = this.nameTable[stream.readPackedU32()];
/*     */         }
/* 439 */         arrayOfAnnotationInstance4 = readAnnotations(stream, null);
/* 440 */         typeVariableReference = new TypeVariableReference(identifier, null, arrayOfAnnotationInstance4, className);
/* 441 */         references.put(typeVariableReference, Integer.valueOf(position));
/* 442 */         return typeVariableReference;
/*     */     } 
/*     */ 
/*     */     
/* 446 */     throw new IllegalStateException("Unrecognized type: " + kind); } private AnnotationTarget readAnnotationTarget(PackedDataInputStream stream, AnnotationTarget caller) throws IOException { short parameter;
/*     */     Type target;
/*     */     boolean isReceiver;
/*     */     int pos, bound;
/* 450 */     byte tag = stream.readByte();
/* 451 */     switch (tag) {
/*     */       case 0:
/* 453 */         return null;
/*     */       case 1:
/*     */       case 2:
/*     */       case 4:
/*     */       case 11:
/* 458 */         return caller;
/*     */       case 3:
/* 460 */         parameter = (short)stream.readPackedU32();
/* 461 */         return new MethodParameterInfo((MethodInfo)caller, parameter);
/*     */       
/*     */       case 5:
/* 464 */         target = this.typeTable[stream.readPackedU32()];
/* 465 */         isReceiver = (stream.readPackedU32() == 1);
/* 466 */         return new EmptyTypeTarget(caller, target, isReceiver);
/*     */       
/*     */       case 6:
/* 469 */         target = this.typeTable[stream.readPackedU32()];
/* 470 */         pos = stream.readPackedU32();
/* 471 */         return new ClassExtendsTypeTarget(caller, target, pos);
/*     */       
/*     */       case 7:
/* 474 */         target = this.typeTable[stream.readPackedU32()];
/* 475 */         pos = stream.readPackedU32();
/* 476 */         return new TypeParameterTypeTarget(caller, target, pos);
/*     */       
/*     */       case 8:
/* 479 */         target = this.typeTable[stream.readPackedU32()];
/* 480 */         pos = stream.readPackedU32();
/* 481 */         bound = stream.readPackedU32();
/* 482 */         return new TypeParameterBoundTypeTarget(caller, target, pos, bound);
/*     */       
/*     */       case 9:
/* 485 */         target = this.typeTable[stream.readPackedU32()];
/* 486 */         pos = stream.readPackedU32();
/* 487 */         return new MethodParameterTypeTarget(caller, target, pos);
/*     */       
/*     */       case 10:
/* 490 */         target = this.typeTable[stream.readPackedU32()];
/* 491 */         pos = stream.readPackedU32();
/* 492 */         return new ThrowsTypeTarget(caller, target, pos);
/*     */     } 
/*     */ 
/*     */     
/* 496 */     throw new IllegalStateException("Invalid tag: " + tag); }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readMethodTable(PackedDataInputStream stream) throws IOException {
/* 501 */     int size = stream.readPackedU32() + 1;
/* 502 */     this.methodTable = new MethodInternal[size];
/* 503 */     for (int i = 1; i < size; i++) {
/* 504 */       this.methodTable[i] = readMethodEntry(stream);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readFieldTable(PackedDataInputStream stream) throws IOException {
/* 511 */     int size = stream.readPackedU32() + 1;
/* 512 */     this.fieldTable = new FieldInternal[size];
/* 513 */     for (int i = 1; i < size; i++) {
/* 514 */       this.fieldTable[i] = readFieldEntry(stream);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void readRecordComponentTable(PackedDataInputStream stream) throws IOException {
/* 520 */     int size = stream.readPackedU32() + 1;
/* 521 */     this.recordComponentTable = new RecordComponentInternal[size];
/* 522 */     for (int i = 1; i < size; i++) {
/* 523 */       this.recordComponentTable[i] = readRecordComponentEntry(stream);
/*     */     }
/*     */   }
/*     */   
/*     */   private MethodInternal readMethodEntry(PackedDataInputStream stream) throws IOException {
/* 528 */     byte[] name = this.byteTable[stream.readPackedU32()];
/* 529 */     short flags = (short)stream.readPackedU32();
/* 530 */     Type[] typeParameters = this.typeListTable[stream.readPackedU32()];
/* 531 */     int reference = stream.readPackedU32();
/* 532 */     Type receiverType = this.typeTable[reference];
/* 533 */     Type returnType = this.typeTable[stream.readPackedU32()];
/* 534 */     Type[] parameters = this.typeListTable[stream.readPackedU32()];
/* 535 */     Type[] descriptorParameters = parameters;
/* 536 */     if (this.version >= 11) {
/* 537 */       descriptorParameters = this.typeListTable[stream.readPackedU32()];
/*     */     }
/* 539 */     Type[] exceptions = this.typeListTable[stream.readPackedU32()];
/* 540 */     AnnotationValue defaultValue = null;
/* 541 */     if (this.version >= 7) {
/* 542 */       boolean hasDefaultValue = (stream.readByte() > 0);
/* 543 */       if (hasDefaultValue) {
/* 544 */         defaultValue = readAnnotationValue(stream);
/*     */       }
/*     */     } 
/* 547 */     byte[][] methodParameterBytes = MethodInternal.EMPTY_PARAMETER_NAMES;
/* 548 */     if (this.version >= 8) {
/* 549 */       int size = stream.readPackedU32();
/* 550 */       if (size > 0) {
/* 551 */         methodParameterBytes = new byte[size][];
/* 552 */         for (int i = 0; i < size; i++) {
/* 553 */           methodParameterBytes[i] = this.byteTable[stream.readPackedU32()];
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 558 */     MethodInfo methodInfo = new MethodInfo();
/* 559 */     AnnotationInstance[] annotations = readAnnotations(stream, methodInfo);
/* 560 */     MethodInternal methodInternal = new MethodInternal(name, methodParameterBytes, descriptorParameters, returnType, flags, receiverType, typeParameters, exceptions, annotations, defaultValue);
/*     */ 
/*     */     
/* 563 */     methodInfo.setMethodInternal(methodInternal);
/* 564 */     methodInfo.setParameters(parameters);
/* 565 */     return methodInternal;
/*     */   }
/*     */   
/*     */   private FieldInternal readFieldEntry(PackedDataInputStream stream) throws IOException {
/* 569 */     byte[] name = this.byteTable[stream.readPackedU32()];
/* 570 */     short flags = (short)stream.readPackedU32();
/* 571 */     Type type = this.typeTable[stream.readPackedU32()];
/*     */     
/* 573 */     FieldInfo fieldInfo = new FieldInfo();
/* 574 */     AnnotationInstance[] annotations = readAnnotations(stream, fieldInfo);
/* 575 */     FieldInternal fieldInternal = new FieldInternal(name, type, flags, annotations);
/* 576 */     fieldInfo.setFieldInternal(fieldInternal);
/* 577 */     return fieldInternal;
/*     */   }
/*     */   
/*     */   private RecordComponentInternal readRecordComponentEntry(PackedDataInputStream stream) throws IOException {
/* 581 */     byte[] name = this.byteTable[stream.readPackedU32()];
/* 582 */     Type type = this.typeTable[stream.readPackedU32()];
/*     */     
/* 584 */     RecordComponentInfo recordComponentInfo = new RecordComponentInfo();
/* 585 */     AnnotationInstance[] annotations = readAnnotations(stream, recordComponentInfo);
/* 586 */     RecordComponentInternal recordComponentInternal = new RecordComponentInternal(name, type, annotations);
/* 587 */     recordComponentInfo.setRecordComponentInternal(recordComponentInternal);
/* 588 */     return recordComponentInternal;
/*     */   }
/*     */ 
/*     */   
/*     */   private ClassInfo readClassEntry(PackedDataInputStream stream, Map<DotName, List<AnnotationInstance>> masterAnnotations) throws IOException {
/* 593 */     DotName name = this.nameTable[stream.readPackedU32()];
/* 594 */     short flags = (short)stream.readPackedU32();
/* 595 */     boolean hasNoArgsConstructor = false;
/* 596 */     if (this.version >= 11) {
/* 597 */       hasNoArgsConstructor = stream.readBoolean();
/*     */     }
/* 599 */     Type superType = this.typeTable[stream.readPackedU32()];
/* 600 */     Type[] typeParameters = this.typeListTable[stream.readPackedU32()];
/* 601 */     Type[] interfaceTypes = this.typeListTable[stream.readPackedU32()];
/*     */     
/* 603 */     boolean hasEnclosingMethod = false;
/* 604 */     boolean hasNesting = false;
/* 605 */     if (this.version >= 9) {
/* 606 */       int nestingMask = stream.readUnsignedByte();
/* 607 */       if (nestingMask > 0) {
/* 608 */         hasNesting = true;
/* 609 */         hasEnclosingMethod = ((nestingMask & 0x2) == 2);
/*     */       } 
/*     */     } else {
/* 612 */       hasEnclosingMethod = hasNesting = true;
/*     */     } 
/*     */     
/* 615 */     DotName enclosingClass = null;
/* 616 */     ClassInfo.EnclosingMethodInfo enclosingMethod = null;
/* 617 */     String simpleName = null;
/*     */     
/* 619 */     if (hasNesting) {
/* 620 */       enclosingClass = this.nameTable[stream.readPackedU32()];
/* 621 */       simpleName = this.stringTable[stream.readPackedU32()];
/* 622 */       enclosingMethod = hasEnclosingMethod ? readEnclosingMethod(stream) : null;
/*     */     } 
/*     */     
/* 625 */     Set<DotName> memberClasses = null;
/* 626 */     if (this.version >= 11) {
/* 627 */       int memberClassesCount = stream.readPackedU32();
/* 628 */       if (memberClassesCount > 0) {
/* 629 */         memberClasses = new HashSet<>(memberClassesCount);
/* 630 */         for (int j = 0; j < memberClassesCount; j++) {
/* 631 */           memberClasses.add(this.nameTable[stream.readPackedU32()]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 636 */     Set<DotName> permittedSubclasses = null;
/* 637 */     if (this.version >= 12) {
/* 638 */       int permittedSubclassesCount = stream.readPackedU32();
/* 639 */       if (permittedSubclassesCount > 0) {
/* 640 */         permittedSubclasses = new HashSet<>(permittedSubclassesCount);
/* 641 */         for (int j = 0; j < permittedSubclassesCount; j++) {
/* 642 */           permittedSubclasses.add(this.nameTable[stream.readPackedU32()]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 647 */     int size = stream.readPackedU32();
/*     */ 
/*     */ 
/*     */     
/* 651 */     Map<DotName, List<AnnotationInstance>> annotations = (size > 0) ? new HashMap<>(size) : Collections.<DotName, List<AnnotationInstance>>emptyMap();
/* 652 */     ClassInfo clazz = new ClassInfo(name, superType, flags, interfaceTypes);
/* 653 */     clazz.setHasNoArgsConstructor(hasNoArgsConstructor);
/* 654 */     clazz.setTypeParameters(typeParameters);
/*     */     
/* 656 */     if (hasNesting) {
/* 657 */       clazz.setEnclosingMethod(enclosingMethod);
/*     */ 
/*     */       
/* 660 */       clazz.setInnerClassInfo(enclosingClass, simpleName, (this.version >= 9));
/*     */     } 
/* 662 */     if (memberClasses != null) {
/* 663 */       clazz.setMemberClasses(memberClasses);
/*     */     }
/* 665 */     if (permittedSubclasses != null) {
/* 666 */       clazz.setPermittedSubclasses(permittedSubclasses);
/*     */     }
/*     */     
/* 669 */     FieldInternal[] fields = readClassFields(stream, clazz);
/* 670 */     clazz.setFieldArray(fields);
/*     */     
/* 672 */     if (this.version >= 10) {
/* 673 */       clazz.setFieldPositionArray(this.byteTable[stream.readPackedU32()]);
/*     */     }
/*     */     
/* 676 */     MethodInternal[] methods = readClassMethods(stream, clazz);
/* 677 */     clazz.setMethodArray(methods);
/*     */     
/* 679 */     if (this.version >= 10) {
/* 680 */       clazz.setMethodPositionArray(this.byteTable[stream.readPackedU32()]);
/*     */     }
/*     */     
/* 683 */     if (this.version >= 10) {
/* 684 */       RecordComponentInternal[] recordComponents = readClassRecordComponents(stream, clazz);
/* 685 */       clazz.setRecordComponentArray(recordComponents);
/* 686 */       clazz.setRecordComponentPositionArray(this.byteTable[stream.readPackedU32()]);
/*     */     } 
/*     */     
/* 689 */     for (int i = 0; i < size; i++) {
/* 690 */       List<AnnotationInstance> instances = convertToList(readAnnotations(stream, clazz));
/* 691 */       if (instances.size() > 0) {
/* 692 */         DotName annotationName = ((AnnotationInstance)instances.get(0)).name();
/* 693 */         annotations.put(annotationName, instances);
/* 694 */         addToMaster(masterAnnotations, annotationName, instances);
/*     */       } 
/*     */     } 
/*     */     
/* 698 */     clazz.setAnnotations(annotations);
/*     */     
/* 700 */     return clazz;
/*     */   }
/*     */   
/*     */   private ModuleInfo readModuleEntry(PackedDataInputStream stream, ClassInfo moduleInfoClass) throws IOException {
/* 704 */     DotName moduleName = this.nameTable[stream.readPackedU32()];
/* 705 */     short moduleFlags = (short)stream.readPackedU32();
/* 706 */     String moduleVersion = this.stringTable[stream.readPackedU32()];
/* 707 */     DotName mainClass = this.nameTable[stream.readPackedU32()];
/*     */     
/* 709 */     ModuleInfo module = new ModuleInfo(moduleInfoClass, moduleName, moduleFlags, moduleVersion);
/* 710 */     module.setMainClass(mainClass);
/*     */ 
/*     */     
/* 713 */     int requiredCount = stream.readPackedU32();
/* 714 */     List<ModuleInfo.RequiredModuleInfo> requires = Utils.listOfCapacity(requiredCount);
/*     */     
/* 716 */     for (int i = 0; i < requiredCount; i++) {
/* 717 */       DotName name = this.nameTable[stream.readPackedU32()];
/* 718 */       short flags = (short)stream.readPackedU32();
/* 719 */       String version = this.stringTable[stream.readPackedU32()];
/* 720 */       requires.add(new ModuleInfo.RequiredModuleInfo(name, flags, version));
/*     */     } 
/*     */     
/* 723 */     module.setRequires(requires);
/*     */ 
/*     */     
/* 726 */     int exportedCount = stream.readPackedU32();
/* 727 */     List<ModuleInfo.ExportedPackageInfo> exports = Utils.listOfCapacity(exportedCount);
/*     */     
/* 729 */     for (int j = 0; j < exportedCount; j++) {
/* 730 */       DotName source = this.nameTable[stream.readPackedU32()];
/* 731 */       short flags = (short)stream.readPackedU32();
/* 732 */       List<DotName> targets = readDotNames(stream);
/* 733 */       exports.add(new ModuleInfo.ExportedPackageInfo(source, flags, targets));
/*     */     } 
/*     */     
/* 736 */     module.setExports(exports);
/*     */ 
/*     */     
/* 739 */     module.setUses(readDotNames(stream));
/*     */ 
/*     */     
/* 742 */     int openedCount = stream.readPackedU32();
/* 743 */     List<ModuleInfo.OpenedPackageInfo> opens = Utils.listOfCapacity(openedCount);
/*     */     
/* 745 */     for (int k = 0; k < openedCount; k++) {
/* 746 */       DotName source = this.nameTable[stream.readPackedU32()];
/* 747 */       short flags = (short)stream.readPackedU32();
/* 748 */       List<DotName> targets = readDotNames(stream);
/* 749 */       opens.add(new ModuleInfo.OpenedPackageInfo(source, flags, targets));
/*     */     } 
/*     */     
/* 752 */     module.setOpens(opens);
/*     */ 
/*     */     
/* 755 */     int providedCount = stream.readPackedU32();
/* 756 */     List<ModuleInfo.ProvidedServiceInfo> provides = Utils.listOfCapacity(providedCount);
/*     */     
/* 758 */     for (int m = 0; m < providedCount; m++) {
/* 759 */       DotName service = this.nameTable[stream.readPackedU32()];
/* 760 */       List<DotName> providers = readDotNames(stream);
/* 761 */       provides.add(new ModuleInfo.ProvidedServiceInfo(service, providers));
/*     */     } 
/*     */     
/* 764 */     module.setProvides(provides);
/*     */ 
/*     */     
/* 767 */     module.setPackages(readDotNames(stream));
/*     */     
/* 769 */     return module;
/*     */   }
/*     */   
/*     */   private List<DotName> readDotNames(PackedDataInputStream stream) throws IOException {
/* 773 */     int size = stream.readPackedU32();
/* 774 */     List<DotName> names = Utils.listOfCapacity(size);
/*     */     
/* 776 */     for (int i = 0; i < size; i++) {
/* 777 */       names.add(this.nameTable[stream.readPackedU32()]);
/*     */     }
/*     */     
/* 780 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToMaster(Map<DotName, List<AnnotationInstance>> masterAnnotations, DotName name, List<AnnotationInstance> annotations) {
/* 785 */     List<AnnotationInstance> entry = masterAnnotations.get(name);
/* 786 */     if (entry == null) {
/* 787 */       masterAnnotations.put(name, new ArrayList<>(annotations));
/*     */       
/*     */       return;
/*     */     } 
/* 791 */     entry.addAll(annotations);
/*     */   }
/*     */   
/*     */   private List<AnnotationInstance> convertToList(AnnotationInstance[] annotationInstances) {
/* 795 */     if (annotationInstances.length == 0) {
/* 796 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 799 */     return new ImmutableArrayList<>(annotationInstances);
/*     */   }
/*     */   
/*     */   private void addClassToMap(HashMap<DotName, List<ClassInfo>> map, DotName name, ClassInfo currentClass) {
/* 803 */     List<ClassInfo> list = map.get(name);
/* 804 */     if (list == null) {
/* 805 */       list = new ArrayList<>();
/* 806 */       map.put(name, list);
/*     */     } 
/*     */     
/* 809 */     list.add(currentClass);
/*     */   }
/*     */   
/*     */   private FieldInternal[] readClassFields(PackedDataInputStream stream, ClassInfo clazz) throws IOException {
/* 813 */     int len = stream.readPackedU32();
/* 814 */     FieldInternal[] fields = (len > 0) ? new FieldInternal[len] : FieldInternal.EMPTY_ARRAY;
/* 815 */     for (int i = 0; i < len; i++) {
/* 816 */       FieldInternal field = this.fieldTable[stream.readPackedU32()];
/* 817 */       updateAnnotationTargetInfo(field.annotationArray(), clazz);
/* 818 */       fields[i] = field;
/*     */     } 
/* 820 */     return fields;
/*     */   }
/*     */ 
/*     */   
/*     */   private RecordComponentInternal[] readClassRecordComponents(PackedDataInputStream stream, ClassInfo clazz) throws IOException {
/* 825 */     int len = stream.readPackedU32();
/*     */     
/* 827 */     RecordComponentInternal[] recordComponents = (len > 0) ? new RecordComponentInternal[len] : RecordComponentInternal.EMPTY_ARRAY;
/* 828 */     for (int i = 0; i < len; i++) {
/* 829 */       RecordComponentInternal recordComponent = this.recordComponentTable[stream.readPackedU32()];
/* 830 */       updateAnnotationTargetInfo(recordComponent.annotationArray(), clazz);
/* 831 */       recordComponents[i] = recordComponent;
/*     */     } 
/* 833 */     return recordComponents;
/*     */   }
/*     */   
/*     */   private MethodInternal[] readClassMethods(PackedDataInputStream stream, ClassInfo clazz) throws IOException {
/* 837 */     int len = stream.readPackedU32();
/* 838 */     MethodInternal[] methods = (len > 0) ? new MethodInternal[len] : MethodInternal.EMPTY_ARRAY;
/* 839 */     for (int i = 0; i < len; i++) {
/* 840 */       MethodInternal method = this.methodTable[stream.readPackedU32()];
/* 841 */       updateAnnotationTargetInfo(method.annotationArray(), clazz);
/* 842 */       methods[i] = method;
/*     */       
/* 844 */       if (this.version < 11 && (method.parameterTypesArray()).length == 0 && 
/* 845 */         Arrays.equals(Utils.INIT_METHOD_NAME, method.nameBytes())) {
/* 846 */         clazz.setHasNoArgsConstructor(true);
/*     */       }
/*     */     } 
/* 849 */     return methods;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateAnnotationTargetInfo(AnnotationInstance[] annotations, ClassInfo clazz) {
/* 855 */     for (AnnotationInstance annotation : annotations) {
/* 856 */       AnnotationTarget target = annotation.target();
/* 857 */       if (target instanceof TypeTarget) {
/* 858 */         target = ((TypeTarget)target).enclosingTarget();
/*     */       }
/* 860 */       if (target instanceof MethodInfo) {
/* 861 */         ((MethodInfo)target).setClassInfo(clazz);
/* 862 */       } else if (target instanceof MethodParameterInfo) {
/* 863 */         ((MethodParameterInfo)target).method().setClassInfo(clazz);
/* 864 */       } else if (target instanceof FieldInfo) {
/* 865 */         ((FieldInfo)target).setClassInfo(clazz);
/* 866 */       } else if (target instanceof RecordComponentInfo) {
/* 867 */         ((RecordComponentInfo)target).setClassInfo(clazz);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ClassInfo.EnclosingMethodInfo readEnclosingMethod(PackedDataInputStream stream) throws IOException {
/* 873 */     if (this.version < 9 && stream.readUnsignedByte() != 1) {
/* 874 */       return null;
/*     */     }
/*     */     
/* 877 */     String eName = this.stringTable[stream.readPackedU32()];
/* 878 */     DotName eClass = this.nameTable[stream.readPackedU32()];
/* 879 */     Type returnType = this.typeTable[stream.readPackedU32()];
/* 880 */     Type[] parameters = this.typeListTable[stream.readPackedU32()];
/* 881 */     return new ClassInfo.EnclosingMethodInfo(eName, returnType, parameters, eClass);
/*     */   }
/*     */ 
/*     */   
/*     */   private Index readClasses(PackedDataInputStream stream, int annotationsSize, int implementorsSize, int subinterfacesSize, int subclassesSize) throws IOException {
/* 886 */     int classesSize = stream.readPackedU32();
/* 887 */     HashMap<DotName, ClassInfo> classes = new HashMap<>(classesSize);
/* 888 */     HashMap<DotName, List<ClassInfo>> subclasses = new HashMap<>(subclassesSize);
/* 889 */     HashMap<DotName, List<ClassInfo>> subinterfaces = new HashMap<>(subinterfacesSize);
/* 890 */     HashMap<DotName, List<ClassInfo>> implementors = new HashMap<>(implementorsSize);
/* 891 */     HashMap<DotName, List<AnnotationInstance>> masterAnnotations = new HashMap<>(annotationsSize);
/*     */ 
/*     */     
/* 894 */     for (int i = 0; i < classesSize; i++) {
/* 895 */       ClassInfo clazz = readClassEntry(stream, masterAnnotations);
/* 896 */       addClassToMap(subclasses, clazz.superName(), clazz);
/* 897 */       for (Type interfaceType : clazz.interfaceTypeArray()) {
/* 898 */         if (Modifier.isInterface(clazz.flags())) {
/* 899 */           addClassToMap(subinterfaces, interfaceType.name(), clazz);
/*     */         }
/*     */ 
/*     */         
/* 903 */         addClassToMap(implementors, interfaceType.name(), clazz);
/*     */       } 
/* 905 */       classes.put(clazz.name(), clazz);
/*     */     } 
/* 907 */     Map<DotName, List<ClassInfo>> users = null;
/* 908 */     if (this.version >= 10) {
/* 909 */       users = new HashMap<>(this.users.size());
/* 910 */       for (Map.Entry<DotName, Set<DotName>> entry : this.users.entrySet()) {
/* 911 */         List<ClassInfo> usedBy = new ArrayList<>(((Set)entry.getValue()).size());
/* 912 */         users.put(entry.getKey(), usedBy);
/* 913 */         for (DotName usedByName : entry.getValue()) {
/* 914 */           usedBy.add(classes.get(usedByName));
/*     */         }
/*     */       } 
/*     */     } else {
/* 918 */       users = Collections.emptyMap();
/*     */     } 
/*     */ 
/*     */     
/* 922 */     Map<DotName, ModuleInfo> modules = (this.version >= 10) ? readModules(stream, masterAnnotations) : Collections.<DotName, ModuleInfo>emptyMap();
/*     */     
/* 924 */     return Index.create(masterAnnotations, subclasses, subinterfaces, implementors, classes, modules, users);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<DotName, ModuleInfo> readModules(PackedDataInputStream stream, Map<DotName, List<AnnotationInstance>> masterAnnotations) throws IOException {
/* 930 */     int modulesSize = stream.readPackedU32();
/*     */     
/* 932 */     Map<DotName, ModuleInfo> modules = (modulesSize > 0) ? new HashMap<>(modulesSize) : Collections.<DotName, ModuleInfo>emptyMap();
/*     */     
/* 934 */     for (int i = 0; i < modulesSize; i++) {
/* 935 */       ClassInfo clazz = readClassEntry(stream, masterAnnotations);
/* 936 */       ModuleInfo module = readModuleEntry(stream, clazz);
/* 937 */       modules.put(module.name(), module);
/*     */     } 
/*     */     
/* 940 */     return modules;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\IndexReaderV2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */