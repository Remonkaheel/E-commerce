/*    */ package org.jboss.jandex;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Result
/*    */ {
/*    */   private final Index index;
/*    */   private final int annotations;
/*    */   private final int instances;
/*    */   private final int classes;
/*    */   private final int usages;
/*    */   private final int bytes;
/*    */   private final String name;
/*    */   private final File outputFile;
/*    */   
/*    */   Result(Index index, String name, int bytes, File outputFile) {
/* 41 */     this.index = index;
/* 42 */     this.annotations = index.annotations.size();
/* 43 */     this.instances = countInstances(index);
/* 44 */     this.classes = index.classes.size();
/* 45 */     int usages = 0;
/* 46 */     for (ClassInfo[] usagesForOneClass : index.users.values()) {
/* 47 */       usages += usagesForOneClass.length;
/*    */     }
/* 49 */     this.usages = usages;
/* 50 */     this.bytes = bytes;
/* 51 */     this.name = name;
/* 52 */     this.outputFile = outputFile;
/*    */   }
/*    */   
/*    */   private int countInstances(Index index) {
/* 56 */     int c = 0;
/* 57 */     for (AnnotationInstance[] list : index.annotations.values()) {
/* 58 */       c += list.length;
/*    */     }
/* 60 */     return c;
/*    */   }
/*    */   
/*    */   public Index getIndex() {
/* 64 */     return this.index;
/*    */   }
/*    */   
/*    */   public int getAnnotations() {
/* 68 */     return this.annotations;
/*    */   }
/*    */   
/*    */   public int getBytes() {
/* 72 */     return this.bytes;
/*    */   }
/*    */   
/*    */   public int getClasses() {
/* 76 */     return this.classes;
/*    */   }
/*    */   
/*    */   public int getInstances() {
/* 80 */     return this.instances;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 84 */     return this.name;
/*    */   }
/*    */   
/*    */   public File getOutputFile() {
/* 88 */     return this.outputFile;
/*    */   }
/*    */   
/*    */   public int getUsages() {
/* 92 */     return this.usages;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\Result.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */