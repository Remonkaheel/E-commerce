/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotationInstance
/*     */ {
/*  45 */   static final NameComparator NAME_COMPARATOR = new NameComparator();
/*  46 */   static final AnnotationInstance[] EMPTY_ARRAY = new AnnotationInstance[0];
/*     */   private final DotName name;
/*     */   private final AnnotationTarget target;
/*     */   private final AnnotationValue[] values;
/*     */   private final boolean runtimeVisible;
/*     */   
/*     */   static class NameComparator
/*     */     implements Comparator<AnnotationInstance> {
/*     */     public int compare(AnnotationInstance instance1, AnnotationInstance instance2) {
/*  55 */       return instance1.name().compareTo(instance2.name());
/*     */     }
/*     */   }
/*     */   
/*     */   private AnnotationInstance(DotName name, AnnotationTarget target, AnnotationValue[] values, boolean runtimeVisible) {
/*  60 */     this.name = name;
/*  61 */     this.target = target;
/*  62 */     this.values = (values != null && values.length > 0) ? values : AnnotationValue.EMPTY_ARRAY;
/*  63 */     this.runtimeVisible = runtimeVisible;
/*     */   }
/*     */   
/*     */   static AnnotationInstance create(AnnotationInstance instance, AnnotationTarget target) {
/*  67 */     return new AnnotationInstance(instance.name, target, instance.values, instance.runtimeVisible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstanceBuilder builder(Class<? extends Annotation> annotationType) {
/*  78 */     if (annotationType == null) {
/*  79 */       throw new IllegalArgumentException("Annotation type can't be null");
/*     */     }
/*  81 */     DotName name = DotName.createSimple(annotationType.getName());
/*     */     
/*  83 */     boolean visible = (annotationType.isAnnotationPresent((Class)Retention.class) && ((Retention)annotationType.<Retention>getAnnotation(Retention.class)).value() == RetentionPolicy.RUNTIME);
/*  84 */     return new AnnotationInstanceBuilder(name, visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstanceBuilder builder(ClassInfo annotationType) {
/*  95 */     if (annotationType == null) {
/*  96 */       throw new IllegalArgumentException("Annotation type can't be null");
/*     */     }
/*  98 */     DotName name = annotationType.name();
/*     */     
/* 100 */     boolean visible = (annotationType.hasDeclaredAnnotation(DotName.RETENTION_NAME) && annotationType.declaredAnnotation(DotName.RETENTION_NAME).value().asString().equals("RUNTIME"));
/* 101 */     return new AnnotationInstanceBuilder(name, visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstanceBuilder builder(DotName annotationType) {
/* 114 */     return builder(annotationType, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstanceBuilder builder(DotName annotationType, boolean runtimeVisible) {
/* 126 */     if (annotationType == null) {
/* 127 */       throw new IllegalArgumentException("Annotation type can't be null");
/*     */     }
/* 129 */     return new AnnotationInstanceBuilder(annotationType, runtimeVisible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstance create(DotName name, AnnotationTarget target, AnnotationValue[] values) {
/* 142 */     return create(name, true, target, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstance create(DotName name, boolean visible, AnnotationTarget target, AnnotationValue[] values) {
/* 156 */     if (name == null) {
/* 157 */       throw new IllegalArgumentException("Name can't be null");
/*     */     }
/* 159 */     if (values == null) {
/* 160 */       throw new IllegalArgumentException("Values can't be null");
/*     */     }
/* 162 */     values = (AnnotationValue[])values.clone();
/*     */ 
/*     */     
/* 165 */     Arrays.sort(values, new Comparator<AnnotationValue>() {
/*     */           public int compare(AnnotationValue o1, AnnotationValue o2) {
/* 167 */             return o1.name().compareTo(o2.name());
/*     */           }
/*     */         });
/*     */     
/* 171 */     return new AnnotationInstance(name, target, values, visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstance create(DotName name, AnnotationTarget target, List<AnnotationValue> values) {
/* 184 */     return create(name, true, target, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationInstance create(DotName name, boolean visible, AnnotationTarget target, List<AnnotationValue> values) {
/* 198 */     if (name == null) {
/* 199 */       throw new IllegalArgumentException("Name can't be null");
/*     */     }
/* 201 */     if (values == null) {
/* 202 */       throw new IllegalArgumentException("Values can't be null");
/*     */     }
/* 204 */     return create(name, visible, target, values.<AnnotationValue>toArray(AnnotationValue.EMPTY_ARRAY));
/*     */   }
/*     */ 
/*     */   
/*     */   static AnnotationInstance binarySearch(AnnotationInstance[] annotations, DotName name) {
/* 209 */     AnnotationInstance key = new AnnotationInstance(name, null, null, false);
/* 210 */     int i = Arrays.binarySearch(annotations, key, NAME_COMPARATOR);
/* 211 */     return (i >= 0) ? annotations[i] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DotName name() {
/* 220 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTarget target() {
/* 232 */     return this.target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationValue value(final String name) {
/* 245 */     int result = Arrays.binarySearch((Object[])this.values, name, new Comparator() {
/*     */           public int compare(Object o1, Object o2) {
/* 247 */             return ((AnnotationValue)o1).name().compareTo(name);
/*     */           }
/*     */         });
/* 250 */     return (result >= 0) ? this.values[result] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationValue value() {
/* 259 */     return value("value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationValue valueWithDefault(IndexView index, String name) {
/* 285 */     ClassInfo definition = index.getClassByName(this.name);
/* 286 */     if (definition == null) {
/* 287 */       throw new IllegalArgumentException("Index did not contain annotation definition: " + this.name);
/*     */     }
/*     */     
/* 290 */     AnnotationValue result = value(name);
/* 291 */     if (result != null) {
/* 292 */       return result;
/*     */     }
/*     */     
/* 295 */     MethodInfo method = definition.method(name, new Type[0]);
/* 296 */     return (method == null) ? null : method.defaultValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationValue valueWithDefault(IndexView index) {
/* 321 */     return valueWithDefault(index, "value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationValue> valuesWithDefaults(IndexView index) {
/* 343 */     ClassInfo definition = index.getClassByName(this.name);
/* 344 */     if (definition == null) {
/* 345 */       throw new IllegalArgumentException("Index did not contain annotation definition: " + this.name);
/*     */     }
/*     */     
/* 348 */     List<MethodInfo> methods = definition.methods();
/* 349 */     ArrayList<AnnotationValue> result = new ArrayList<>(methods.size());
/* 350 */     for (MethodInfo method : methods) {
/* 351 */       AnnotationValue value = value(method.name());
/* 352 */       if (value == null) {
/* 353 */         value = method.defaultValue();
/*     */       }
/* 355 */       if (value != null) {
/* 356 */         result.add(value);
/*     */       }
/*     */     } 
/*     */     
/* 360 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationValue> values() {
/* 372 */     return new ImmutableArrayList<>(this.values);
/*     */   }
/*     */   
/*     */   AnnotationValue[] valueArray() {
/* 376 */     return this.values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean runtimeVisible() {
/* 386 */     return this.runtimeVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean simple) {
/* 399 */     StringBuilder builder = (new StringBuilder("@")).append(simple ? this.name.local() : this.name);
/*     */     
/* 401 */     if (simple && this.values.length == 1 && this.values[0].name().equals("value")) {
/* 402 */       builder.append("(");
/* 403 */       builder.append(this.values[0].toString(false));
/* 404 */       builder.append(')');
/* 405 */     } else if (this.values.length > 0) {
/* 406 */       builder.append("(");
/* 407 */       for (int i = 0; i < this.values.length; i++) {
/* 408 */         builder.append(this.values[i]);
/* 409 */         if (i < this.values.length - 1)
/* 410 */           builder.append(","); 
/*     */       } 
/* 412 */       builder.append(')');
/*     */     } 
/*     */     
/* 415 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 425 */     return toString(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 443 */     if (this == o)
/* 444 */       return true; 
/* 445 */     if (o == null || getClass() != o.getClass()) {
/* 446 */       return false;
/*     */     }
/* 448 */     AnnotationInstance instance = (AnnotationInstance)o;
/*     */     
/* 450 */     return (this.target == instance.target && this.name.equals(instance.name) && Arrays.equals((Object[])this.values, (Object[])instance.values));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 461 */     int result = this.name.hashCode();
/* 462 */     result = 31 * result + Arrays.hashCode((Object[])this.values);
/*     */     
/* 464 */     if (this.target != null) {
/* 465 */       switch (this.target.kind()) {
/*     */         case CLASS:
/* 467 */           result = 31 * result + this.target.asClass().name().hashCode();
/*     */           break;
/*     */         case METHOD:
/* 470 */           result = 31 * result + this.target.asMethod().declaringClass().name().hashCode();
/* 471 */           result = 31 * result + this.target.asMethod().name().hashCode();
/*     */           break;
/*     */         case FIELD:
/* 474 */           result = 31 * result + this.target.asField().declaringClass().name().hashCode();
/* 475 */           result = 31 * result + this.target.asField().name().hashCode();
/*     */           break;
/*     */         case METHOD_PARAMETER:
/* 478 */           result = 31 * result + this.target.asMethodParameter().method().declaringClass().name().hashCode();
/* 479 */           result = 31 * result + this.target.asMethodParameter().method().name().hashCode();
/* 480 */           result = 31 * result + this.target.asMethodParameter().position();
/*     */           break;
/*     */         case RECORD_COMPONENT:
/* 483 */           result = 31 * result + this.target.asRecordComponent().declaringClass().name().hashCode();
/* 484 */           result = 31 * result + this.target.asRecordComponent().name().hashCode();
/*     */           break;
/*     */         case TYPE:
/* 487 */           if (this.target.asType().target() != null) {
/* 488 */             result = 31 * result + this.target.asType().target().name().hashCode();
/*     */           }
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/* 494 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equivalentTo(AnnotationInstance other) {
/* 508 */     if (this == other) {
/* 509 */       return true;
/*     */     }
/* 511 */     if (other == null) {
/* 512 */       return false;
/*     */     }
/*     */     
/* 515 */     return (this.name.equals(other.name) && Arrays.equals((Object[])this.values, (Object[])other.values));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int equivalenceHashCode() {
/* 525 */     int result = this.name.hashCode();
/* 526 */     result = 31 * result + Arrays.hashCode((Object[])this.values);
/* 527 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationInstanceEquivalenceProxy createEquivalenceProxy() {
/* 534 */     return new AnnotationInstanceEquivalenceProxy(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\AnnotationInstance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */