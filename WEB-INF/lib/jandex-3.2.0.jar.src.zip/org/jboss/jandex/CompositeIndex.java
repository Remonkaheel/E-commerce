/*     */ package org.jboss.jandex;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeIndex
/*     */   implements IndexView
/*     */ {
/*     */   final Collection<IndexView> indexes;
/*     */   
/*     */   private CompositeIndex(Collection<IndexView> indexes) {
/*  46 */     this.indexes = indexes;
/*     */   }
/*     */   
/*     */   public static CompositeIndex create(Collection<IndexView> indexes) {
/*  50 */     return new CompositeIndex(indexes);
/*     */   }
/*     */   
/*     */   public static CompositeIndex create(IndexView... indexes) {
/*  54 */     return new CompositeIndex(Arrays.asList(indexes));
/*     */   }
/*     */   
/*     */   public static CompositeIndex createMerged(CompositeIndex... indexes) {
/*  58 */     ArrayList<IndexView> list = new ArrayList<>();
/*  59 */     for (CompositeIndex index : indexes) {
/*  60 */       list.addAll(index.indexes);
/*     */     }
/*  62 */     return create(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotationInstance> getAnnotations(DotName annotationName) {
/*  70 */     List<AnnotationInstance> allInstances = new ArrayList<>();
/*  71 */     for (IndexView index : this.indexes) {
/*  72 */       Collection<AnnotationInstance> list = index.getAnnotations(annotationName);
/*  73 */       if (list != null) {
/*  74 */         allInstances.addAll(list);
/*     */       }
/*     */     } 
/*  77 */     return Collections.unmodifiableList(allInstances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<AnnotationInstance> getAnnotationsWithRepeatable(DotName annotationName, IndexView index) {
/*  85 */     List<AnnotationInstance> allInstances = new ArrayList<>();
/*  86 */     for (IndexView i : this.indexes) {
/*  87 */       allInstances.addAll(i.getAnnotationsWithRepeatable(annotationName, index));
/*     */     }
/*  89 */     return Collections.unmodifiableList(allInstances);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ClassInfo> getKnownDirectSubclasses(DotName className) {
/*  97 */     Set<ClassInfo> allKnown = new HashSet<>();
/*  98 */     for (IndexView index : this.indexes) {
/*  99 */       Collection<ClassInfo> list = index.getKnownDirectSubclasses(className);
/* 100 */       if (list != null) {
/* 101 */         allKnown.addAll(list);
/*     */       }
/*     */     } 
/* 104 */     return Collections.unmodifiableSet(allKnown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ClassInfo> getAllKnownSubclasses(DotName className) {
/* 112 */     Set<ClassInfo> allKnown = new HashSet<>();
/* 113 */     Set<DotName> processedClasses = new HashSet<>();
/* 114 */     getAllKnownSubClasses(className, allKnown, processedClasses);
/* 115 */     return allKnown;
/*     */   }
/*     */   
/*     */   private void getAllKnownSubClasses(DotName className, Set<ClassInfo> allKnown, Set<DotName> processedClasses) {
/* 119 */     Set<DotName> subClassesToProcess = new HashSet<>();
/* 120 */     subClassesToProcess.add(className);
/* 121 */     while (!subClassesToProcess.isEmpty()) {
/* 122 */       Iterator<DotName> toProcess = subClassesToProcess.iterator();
/* 123 */       DotName name = toProcess.next();
/* 124 */       toProcess.remove();
/* 125 */       processedClasses.add(name);
/* 126 */       getAllKnownSubClasses(name, allKnown, subClassesToProcess, processedClasses);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void getAllKnownSubClasses(DotName name, Set<ClassInfo> allKnown, Set<DotName> subClassesToProcess, Set<DotName> processedClasses) {
/* 132 */     for (IndexView index : this.indexes) {
/* 133 */       Collection<ClassInfo> list = index.getKnownDirectSubclasses(name);
/* 134 */       if (list != null) {
/* 135 */         for (ClassInfo clazz : list) {
/* 136 */           DotName className = clazz.name();
/* 137 */           if (!processedClasses.contains(className)) {
/* 138 */             allKnown.add(clazz);
/* 139 */             subClassesToProcess.add(className);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownDirectSubinterfaces(DotName interfaceName) {
/* 151 */     Set<ClassInfo> allKnown = new HashSet<>();
/* 152 */     for (IndexView index : this.indexes) {
/* 153 */       Collection<ClassInfo> list = index.getKnownDirectSubinterfaces(interfaceName);
/* 154 */       if (list != null) {
/* 155 */         allKnown.addAll(list);
/*     */       }
/*     */     } 
/* 158 */     return Collections.unmodifiableSet(allKnown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getAllKnownSubinterfaces(DotName interfaceName) {
/* 166 */     Set<ClassInfo> result = new HashSet<>();
/*     */     
/* 168 */     Queue<DotName> workQueue = new ArrayDeque<>();
/* 169 */     Set<DotName> alreadyProcessed = new HashSet<>();
/*     */     
/* 171 */     workQueue.add(interfaceName);
/* 172 */     while (!workQueue.isEmpty()) {
/* 173 */       DotName iface = workQueue.remove();
/* 174 */       if (!alreadyProcessed.add(iface)) {
/*     */         continue;
/*     */       }
/*     */       
/* 178 */       for (IndexView index : this.indexes) {
/* 179 */         for (ClassInfo directSubinterface : index.getKnownDirectSubinterfaces(iface)) {
/* 180 */           result.add(directSubinterface);
/* 181 */           workQueue.add(directSubinterface.name());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 186 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownDirectImplementors(DotName interfaceName) {
/* 194 */     Set<ClassInfo> allKnown = new HashSet<>();
/* 195 */     for (IndexView index : this.indexes) {
/* 196 */       Collection<ClassInfo> list = index.getKnownDirectImplementors(interfaceName);
/* 197 */       if (list != null) {
/* 198 */         allKnown.addAll(list);
/*     */       }
/*     */     } 
/* 201 */     return Collections.unmodifiableSet(allKnown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ClassInfo> getAllKnownImplementors(DotName interfaceName) {
/* 209 */     Set<ClassInfo> allKnown = new HashSet<>();
/* 210 */     Set<DotName> subInterfacesToProcess = new HashSet<>();
/* 211 */     Set<DotName> processedClasses = new HashSet<>();
/* 212 */     subInterfacesToProcess.add(interfaceName);
/* 213 */     while (!subInterfacesToProcess.isEmpty()) {
/* 214 */       Iterator<DotName> toProcess = subInterfacesToProcess.iterator();
/* 215 */       DotName name = toProcess.next();
/* 216 */       toProcess.remove();
/* 217 */       processedClasses.add(name);
/* 218 */       getKnownImplementors(name, allKnown, subInterfacesToProcess, processedClasses);
/*     */     } 
/* 220 */     return allKnown;
/*     */   }
/*     */ 
/*     */   
/*     */   private void getKnownImplementors(DotName name, Set<ClassInfo> allKnown, Set<DotName> subInterfacesToProcess, Set<DotName> processedClasses) {
/* 225 */     for (IndexView index : this.indexes) {
/* 226 */       Collection<ClassInfo> list = index.getKnownDirectImplementors(name);
/* 227 */       if (list != null) {
/* 228 */         for (ClassInfo clazz : list) {
/* 229 */           DotName className = clazz.name();
/* 230 */           if (!processedClasses.contains(className)) {
/* 231 */             if (Modifier.isInterface(clazz.flags())) {
/* 232 */               subInterfacesToProcess.add(className); continue;
/*     */             } 
/* 234 */             if (!allKnown.contains(clazz)) {
/* 235 */               allKnown.add(clazz);
/* 236 */               processedClasses.add(className);
/* 237 */               getAllKnownSubClasses(className, allKnown, processedClasses);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassInfo getClassByName(DotName className) {
/* 251 */     for (IndexView index : this.indexes) {
/* 252 */       ClassInfo info = index.getClassByName(className);
/* 253 */       if (info != null) {
/* 254 */         return info;
/*     */       }
/*     */     } 
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownClasses() {
/* 265 */     List<ClassInfo> allKnown = new ArrayList<>();
/* 266 */     for (IndexView index : this.indexes) {
/* 267 */       Collection<ClassInfo> list = index.getKnownClasses();
/* 268 */       if (list != null) {
/* 269 */         allKnown.addAll(list);
/*     */       }
/*     */     } 
/* 272 */     return Collections.unmodifiableCollection(allKnown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleInfo getModuleByName(DotName moduleName) {
/* 280 */     for (IndexView index : this.indexes) {
/* 281 */       ModuleInfo info = index.getModuleByName(moduleName);
/* 282 */       if (info != null) {
/* 283 */         return info;
/*     */       }
/*     */     } 
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ModuleInfo> getKnownModules() {
/* 294 */     List<ModuleInfo> allKnown = new ArrayList<>();
/* 295 */     for (IndexView index : this.indexes) {
/* 296 */       Collection<ModuleInfo> list = index.getKnownModules();
/* 297 */       if (list != null) {
/* 298 */         allKnown.addAll(list);
/*     */       }
/*     */     } 
/* 301 */     return Collections.unmodifiableCollection(allKnown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getKnownUsers(DotName className) {
/* 309 */     List<ClassInfo> users = new ArrayList<>();
/* 310 */     Set<DotName> processedClasses = new HashSet<>();
/* 311 */     for (IndexView index : this.indexes) {
/* 312 */       Collection<ClassInfo> set = index.getKnownUsers(className);
/* 313 */       if (set != null) {
/* 314 */         for (ClassInfo classInfo : set) {
/* 315 */           if (processedClasses.add(classInfo.name())) {
/* 316 */             users.add(classInfo);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 321 */     return Collections.unmodifiableCollection(users);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ClassInfo> getClassesInPackage(DotName packageName) {
/* 329 */     List<ClassInfo> result = new ArrayList<>();
/* 330 */     Set<DotName> alreadySeen = new HashSet<>();
/* 331 */     for (IndexView index : this.indexes) {
/* 332 */       for (ClassInfo clazz : index.getClassesInPackage(packageName)) {
/* 333 */         if (alreadySeen.add(clazz.name())) {
/* 334 */           result.add(clazz);
/*     */         }
/*     */       } 
/*     */     } 
/* 338 */     return Collections.unmodifiableCollection(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<DotName> getSubpackages(DotName packageName) {
/* 346 */     Set<DotName> result = new HashSet<>();
/* 347 */     for (IndexView index : this.indexes) {
/* 348 */       result.addAll(index.getSubpackages(packageName));
/*     */     }
/* 350 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jandex-3.2.0.jar!\org\jboss\jandex\CompositeIndex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */