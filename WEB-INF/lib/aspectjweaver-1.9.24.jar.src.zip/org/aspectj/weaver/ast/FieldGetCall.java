/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.Member;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldGetCall
/*    */   extends Test
/*    */ {
/*    */   private final Member field;
/*    */   private final Member method;
/*    */   private final Expr[] args;
/*    */   
/*    */   public FieldGetCall(Member f, Member m, Expr[] args) {
/* 26 */     this.field = f;
/* 27 */     this.method = m;
/* 28 */     this.args = args;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 32 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public Expr[] getArgs() {
/* 36 */     return this.args;
/*    */   }
/*    */   
/*    */   public Member getMethod() {
/* 40 */     return this.method;
/*    */   }
/*    */   
/*    */   public Member getField() {
/* 44 */     return this.field;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\FieldGetCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */