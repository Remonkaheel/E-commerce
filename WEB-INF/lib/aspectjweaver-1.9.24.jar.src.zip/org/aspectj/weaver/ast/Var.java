/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Var
/*    */   extends Expr
/*    */ {
/* 18 */   public static final Var[] NONE = new Var[0];
/*    */   
/*    */   ResolvedType variableType;
/*    */   
/*    */   public Var(ResolvedType variableType) {
/* 23 */     this.variableType = variableType;
/*    */   }
/*    */   
/*    */   public ResolvedType getType() {
/* 27 */     return this.variableType;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 31 */     return "(Var " + this.variableType + ")";
/*    */   }
/*    */   
/*    */   public void accept(IExprVisitor v) {
/* 35 */     v.visit(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Var getAccessorForValue(ResolvedType formalType, String formalName) {
/* 47 */     throw new IllegalStateException("Only makes sense for annotation variables");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Var.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */