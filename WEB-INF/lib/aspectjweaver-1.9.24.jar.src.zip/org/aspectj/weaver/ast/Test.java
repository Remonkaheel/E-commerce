/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Test
/*    */   extends ASTNode
/*    */ {
/*    */   public abstract void accept(ITestVisitor paramITestVisitor);
/*    */   
/*    */   public static Test makeAnd(Test a, Test b) {
/* 30 */     if (a == Literal.TRUE) {
/* 31 */       if (b == Literal.TRUE) {
/* 32 */         return a;
/*    */       }
/* 34 */       return b;
/*    */     } 
/* 36 */     if (b == Literal.TRUE)
/* 37 */       return a; 
/* 38 */     if (a == Literal.FALSE || b == Literal.FALSE) {
/* 39 */       return Literal.FALSE;
/*    */     }
/* 41 */     return new And(a, b);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Test makeOr(Test a, Test b) {
/* 48 */     if (a == Literal.FALSE)
/* 49 */       return b; 
/* 50 */     if (b == Literal.FALSE)
/* 51 */       return a; 
/* 52 */     if (a == Literal.TRUE || b == Literal.TRUE) {
/* 53 */       return Literal.TRUE;
/*    */     }
/* 55 */     return new Or(a, b);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Test makeNot(Test a) {
/* 60 */     if (a instanceof Not)
/* 61 */       return ((Not)a).getBody(); 
/* 62 */     if (a == Literal.TRUE)
/* 63 */       return Literal.FALSE; 
/* 64 */     if (a == Literal.FALSE) {
/* 65 */       return Literal.TRUE;
/*    */     }
/*    */ 
/*    */     
/* 69 */     return new Not(a);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Test makeInstanceof(Var v, ResolvedType ty) {
/*    */     Test e;
/* 75 */     if (ty.equals(ResolvedType.OBJECT)) return Literal.TRUE;
/*    */ 
/*    */     
/* 78 */     if (ty.isAssignableFrom(v.getType())) { e = Literal.TRUE; }
/* 79 */     else if (!ty.isCoerceableFrom(v.getType())) { e = Literal.FALSE; }
/* 80 */     else { e = new Instanceof(v, (UnresolvedType)ty); }
/* 81 */      return e;
/*    */   }
/*    */   
/*    */   public static Test makeHasAnnotation(Var v, ResolvedType annTy) {
/* 85 */     return new HasAnnotation(v, annTy);
/*    */   }
/*    */   
/*    */   public static Test makeCall(Member m, Expr[] args) {
/* 89 */     return new Call(m, args);
/*    */   }
/*    */   public static Test makeFieldGetCall(Member f, Member m, Expr[] args) {
/* 92 */     return new FieldGetCall(f, m, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Test.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */