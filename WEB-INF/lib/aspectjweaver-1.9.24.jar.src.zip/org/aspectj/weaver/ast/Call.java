/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.Member;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Call
/*    */   extends Test
/*    */ {
/*    */   private final Member method;
/*    */   private final Expr[] args;
/*    */   
/*    */   public Call(Member m, Expr[] args) {
/* 25 */     this.method = m;
/* 26 */     this.args = args;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 30 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public Expr[] getArgs() {
/* 34 */     return this.args;
/*    */   }
/*    */   
/*    */   public Member getMethod() {
/* 38 */     return this.method;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Call.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */