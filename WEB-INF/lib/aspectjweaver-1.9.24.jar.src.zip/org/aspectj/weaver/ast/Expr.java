/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Expr
/*    */   extends ASTNode
/*    */ {
/* 24 */   public static final Expr[] NONE = new Expr[0];
/*    */   
/*    */   public abstract void accept(IExprVisitor paramIExprVisitor);
/*    */   
/*    */   public abstract ResolvedType getType();
/*    */   
/*    */   public static CallExpr makeCallExpr(Member member, Expr[] exprs, ResolvedType returnType) {
/* 31 */     return new CallExpr(member, exprs, returnType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Expr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */