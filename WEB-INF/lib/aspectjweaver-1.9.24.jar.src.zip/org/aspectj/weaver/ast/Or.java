/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Or
/*    */   extends Test
/*    */ {
/*    */   Test left;
/*    */   Test right;
/*    */   
/*    */   public Or(Test left, Test right) {
/* 21 */     this.left = left;
/* 22 */     this.right = right;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 26 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 30 */     return "(" + this.left + " || " + this.right + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 34 */     if (other instanceof Or) {
/* 35 */       Or o = (Or)other;
/* 36 */       return (o.left.equals(this.left) && o.right.equals(this.right));
/*    */     } 
/* 38 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 43 */     int result = 19;
/* 44 */     result = 37 * result + this.left.hashCode();
/* 45 */     result = 37 * result + this.right.hashCode();
/* 46 */     return result;
/*    */   }
/*    */   
/*    */   public Test getLeft() {
/* 50 */     return this.left;
/*    */   }
/*    */   
/*    */   public Test getRight() {
/* 54 */     return this.right;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Or.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */