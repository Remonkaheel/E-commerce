/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Not
/*    */   extends Test
/*    */ {
/*    */   Test test;
/*    */   
/*    */   public Not(Test test) {
/* 22 */     this.test = test;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 26 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public Test getBody() {
/* 30 */     return this.test;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 34 */     return "!" + this.test;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 38 */     if (other instanceof Not) {
/* 39 */       Not o = (Not)other;
/* 40 */       return o.test.equals(this.test);
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 47 */     return this.test.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Not.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */