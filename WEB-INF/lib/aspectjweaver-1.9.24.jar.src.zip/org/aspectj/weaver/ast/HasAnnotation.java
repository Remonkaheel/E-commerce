/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HasAnnotation
/*    */   extends Test
/*    */ {
/*    */   private Var v;
/*    */   private ResolvedType annType;
/*    */   
/*    */   public HasAnnotation(Var v, ResolvedType annType) {
/* 23 */     this.v = v;
/* 24 */     this.annType = annType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 31 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 35 */     return "(" + this.v + " has annotation @" + this.annType + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 39 */     if (other instanceof HasAnnotation) {
/* 40 */       HasAnnotation o = (HasAnnotation)other;
/* 41 */       return (o.v.equals(this.v) && o.annType.equals(this.annType));
/*    */     } 
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 48 */     return this.v.hashCode() * 37 + this.annType.hashCode();
/*    */   }
/*    */   
/*    */   public Var getVar() {
/* 52 */     return this.v;
/*    */   }
/*    */   
/*    */   public UnresolvedType getAnnotationType() {
/* 56 */     return (UnresolvedType)this.annType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\HasAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */