package org.aspectj.weaver.ast;

import org.aspectj.weaver.internal.tools.MatchingContextBasedTest;

public interface ITestVisitor {
  void visit(And paramAnd);
  
  void visit(Instanceof paramInstanceof);
  
  void visit(Not paramNot);
  
  void visit(Or paramOr);
  
  void visit(Literal paramLiteral);
  
  void visit(Call paramCall);
  
  void visit(FieldGetCall paramFieldGetCall);
  
  void visit(HasAnnotation paramHasAnnotation);
  
  void visit(MatchingContextBasedTest paramMatchingContextBasedTest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\ITestVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */