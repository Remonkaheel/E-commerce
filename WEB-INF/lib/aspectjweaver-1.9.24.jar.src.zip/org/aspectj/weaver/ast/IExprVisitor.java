package org.aspectj.weaver.ast;

public interface IExprVisitor {
  void visit(Var paramVar);
  
  void visit(FieldGet paramFieldGet);
  
  void visit(CallExpr paramCallExpr);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\IExprVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */