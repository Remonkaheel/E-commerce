/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldGet
/*    */   extends Expr
/*    */ {
/*    */   Member field;
/*    */   ResolvedType resolvedType;
/*    */   
/*    */   public FieldGet(Member field, ResolvedType resolvedType) {
/* 24 */     this.field = field;
/* 25 */     this.resolvedType = resolvedType;
/*    */   }
/*    */   
/*    */   public ResolvedType getType() {
/* 29 */     return this.resolvedType;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 33 */     return "(FieldGet " + this.field + ")";
/*    */   }
/*    */   
/*    */   public void accept(IExprVisitor v) {
/* 37 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public Member getField() {
/* 41 */     return this.field;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\FieldGet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */