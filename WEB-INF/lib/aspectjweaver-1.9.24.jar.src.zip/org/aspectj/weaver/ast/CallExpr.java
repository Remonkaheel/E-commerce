/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallExpr
/*    */   extends Expr
/*    */ {
/*    */   private final Member method;
/*    */   private final Expr[] args;
/*    */   private final ResolvedType returnType;
/*    */   
/*    */   public CallExpr(Member m, Expr[] args, ResolvedType returnType) {
/* 27 */     this.method = m;
/* 28 */     this.args = args;
/* 29 */     this.returnType = returnType;
/*    */   }
/*    */   
/*    */   public void accept(IExprVisitor v) {
/* 33 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public Expr[] getArgs() {
/* 37 */     return this.args;
/*    */   }
/*    */   
/*    */   public Member getMethod() {
/* 41 */     return this.method;
/*    */   }
/*    */   
/*    */   public ResolvedType getType() {
/* 45 */     return this.returnType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\CallExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */