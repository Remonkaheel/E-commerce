/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Literal
/*    */   extends Test
/*    */ {
/*    */   boolean noTest;
/*    */   boolean val;
/*    */   
/*    */   private Literal(boolean val, boolean noTest) {
/* 24 */     this.val = val;
/* 25 */     this.noTest = noTest;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 29 */     v.visit(this);
/*    */   }
/*    */   
/* 32 */   public static final Literal TRUE = new Literal(true, false);
/* 33 */   public static final Literal FALSE = new Literal(false, false);
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return this.noTest ? "NO_TEST" : (this.val ? "TRUE" : "FALSE");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Literal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */