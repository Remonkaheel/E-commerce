/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Instanceof
/*    */   extends Test
/*    */ {
/*    */   Var var;
/*    */   UnresolvedType type;
/*    */   
/*    */   public Instanceof(Var left, UnresolvedType right) {
/* 24 */     this.var = left;
/* 25 */     this.type = right;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 29 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 33 */     return "(" + this.var + " instanceof " + this.type + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 37 */     if (other instanceof Instanceof) {
/* 38 */       Instanceof o = (Instanceof)other;
/* 39 */       return (o.var.equals(this.var) && o.type.equals(this.type));
/*    */     } 
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 46 */     return this.var.hashCode() * 37 + this.type.hashCode();
/*    */   }
/*    */   
/*    */   public Var getVar() {
/* 50 */     return this.var;
/*    */   }
/*    */   
/*    */   public UnresolvedType getType() {
/* 54 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\Instanceof.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */