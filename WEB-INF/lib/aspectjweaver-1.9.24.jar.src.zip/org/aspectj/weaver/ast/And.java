/*    */ package org.aspectj.weaver.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class And
/*    */   extends Test
/*    */ {
/*    */   Test left;
/*    */   Test right;
/*    */   
/*    */   public And(Test left, Test right) {
/* 22 */     this.left = left;
/* 23 */     this.right = right;
/*    */   }
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 27 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 31 */     return "(" + this.left + " && " + this.right + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 35 */     if (other instanceof And) {
/* 36 */       And o = (And)other;
/* 37 */       return (o.left.equals(this.left) && o.right.equals(this.right));
/*    */     } 
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Test getLeft() {
/* 44 */     return this.left;
/*    */   }
/*    */   
/*    */   public Test getRight() {
/* 48 */     return this.right;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ast\And.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */