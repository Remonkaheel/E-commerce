/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.generic.Instruction;
/*    */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*    */ import org.aspectj.apache.bcel.generic.InstructionList;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelFieldRef
/*    */   extends BcelVar
/*    */ {
/*    */   private String className;
/*    */   private String fieldName;
/*    */   
/*    */   public BcelFieldRef(ResolvedType type, String className, String fieldName) {
/* 31 */     super(type, 0);
/* 32 */     this.className = className;
/* 33 */     this.fieldName = fieldName;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 37 */     return "BcelFieldRef(" + getType() + " " + this.className + "." + this.fieldName + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Instruction createLoad(InstructionFactory fact) {
/* 43 */     return (Instruction)fact.createFieldAccess(this.className, this.fieldName, BcelWorld.makeBcelType((UnresolvedType)getType()), (short)178);
/*    */   }
/*    */   
/*    */   public Instruction createStore(InstructionFactory fact) {
/* 47 */     return (Instruction)fact.createFieldAccess(this.className, this.fieldName, BcelWorld.makeBcelType((UnresolvedType)getType()), (short)179);
/*    */   }
/*    */   
/*    */   public InstructionList createCopyFrom(InstructionFactory fact, int oldSlot) {
/* 51 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelFieldRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */