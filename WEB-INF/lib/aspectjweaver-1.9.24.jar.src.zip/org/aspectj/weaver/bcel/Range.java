/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.InstructionTargeter;
/*     */ import org.aspectj.weaver.BCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Range
/*     */   implements InstructionTargeter
/*     */ {
/*     */   protected InstructionList body;
/*     */   protected InstructionHandle start;
/*     */   protected InstructionHandle end;
/*     */   
/*     */   protected Range(InstructionList il) {
/*  31 */     this.body = il;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final InstructionList getBody() {
/*  37 */     return this.body;
/*     */   }
/*     */   
/*     */   final InstructionHandle getStart() {
/*  41 */     return this.start;
/*     */   }
/*     */   
/*     */   final InstructionHandle getEnd() {
/*  45 */     return this.end;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/*  51 */     InstructionHandle ih = this.start;
/*     */     
/*  53 */     while (ih != this.end) {
/*     */       
/*  55 */       if (!isRangeHandle(ih)) {
/*  56 */         return false;
/*     */       }
/*  58 */       ih = ih.getNext();
/*     */     } 
/*  60 */     return true;
/*     */   }
/*     */   
/*     */   static InstructionHandle getRealStart(InstructionHandle ih) {
/*  64 */     while (isRangeHandle(ih)) {
/*  65 */       ih = ih.getNext();
/*     */     }
/*  67 */     return ih;
/*     */   }
/*     */   
/*     */   InstructionHandle getRealStart() {
/*  71 */     return getRealStart(this.start);
/*     */   }
/*     */   
/*     */   static InstructionHandle getRealEnd(InstructionHandle ih) {
/*  75 */     while (isRangeHandle(ih)) {
/*  76 */       ih = ih.getPrev();
/*     */     }
/*  78 */     return ih;
/*     */   }
/*     */   
/*     */   InstructionHandle getRealEnd() {
/*  82 */     return getRealEnd(this.end);
/*     */   }
/*     */   
/*     */   InstructionHandle getRealNext() {
/*  86 */     return getRealStart(this.end);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   InstructionHandle insert(Instruction i, Where where) {
/*  92 */     InstructionList il = new InstructionList();
/*  93 */     InstructionHandle ret = il.insert(i);
/*  94 */     insert(il, where);
/*  95 */     return ret;
/*     */   }
/*     */   
/*     */   void insert(InstructionList freshIl, Where where) {
/*     */     InstructionHandle h;
/* 100 */     if (where == InsideBefore || where == OutsideBefore) {
/* 101 */       h = getStart();
/*     */     } else {
/* 103 */       h = getEnd();
/*     */     } 
/* 105 */     if (where == InsideBefore || where == OutsideAfter) {
/* 106 */       this.body.append(h, freshIl);
/*     */     } else {
/* 108 */       InstructionHandle newStart = this.body.insert(h, freshIl);
/* 109 */       if (where == OutsideBefore)
/*     */       {
/*     */ 
/*     */         
/* 113 */         BcelShadow.retargetAllBranches(h, newStart);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   InstructionHandle append(Instruction i) {
/* 120 */     return insert(i, InsideAfter);
/*     */   }
/*     */   
/*     */   void append(InstructionList i) {
/* 124 */     insert(i, InsideAfter);
/*     */   }
/*     */   
/*     */   private static void setLineNumberFromNext(InstructionHandle ih) {
/* 128 */     int lineNumber = Utility.getSourceLine(ih.getNext());
/* 129 */     if (lineNumber != -1) {
/* 130 */       Utility.setSourceLine(ih, lineNumber);
/*     */     }
/*     */   }
/*     */   
/*     */   static InstructionHandle genStart(InstructionList body) {
/* 135 */     InstructionHandle ih = body.insert(RANGEINSTRUCTION);
/* 136 */     setLineNumberFromNext(ih);
/* 137 */     return ih;
/*     */   }
/*     */   
/*     */   static InstructionHandle genEnd(InstructionList body) {
/* 141 */     return body.append(RANGEINSTRUCTION);
/*     */   }
/*     */   
/*     */   static InstructionHandle genStart(InstructionList body, InstructionHandle ih) {
/* 145 */     if (ih == null) {
/* 146 */       return genStart(body);
/*     */     }
/* 148 */     InstructionHandle freshIh = body.insert(ih, RANGEINSTRUCTION);
/* 149 */     setLineNumberFromNext(freshIh);
/* 150 */     return freshIh;
/*     */   }
/*     */   
/*     */   static InstructionHandle genEnd(InstructionList body, InstructionHandle ih) {
/* 154 */     if (ih == null) {
/* 155 */       return genEnd(body);
/*     */     }
/* 157 */     return body.append(ih, RANGEINSTRUCTION);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTarget(InstructionHandle ih) {
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   public final void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 167 */     throw new RuntimeException("Ranges must be updated with an enclosing instructionList");
/*     */   }
/*     */   
/*     */   protected void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih, InstructionList new_il) {
/* 171 */     old_ih.removeTargeter(this);
/* 172 */     if (new_ih != null) {
/* 173 */       new_ih.addTargeter(this);
/*     */     }
/* 175 */     this.body = new_il;
/*     */     
/* 177 */     if (old_ih == this.start) {
/* 178 */       this.start = new_ih;
/*     */     }
/* 180 */     if (old_ih == this.end) {
/* 181 */       this.end = new_ih;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final boolean isRangeHandle(InstructionHandle ih) {
/* 186 */     if (ih == null) {
/* 187 */       return false;
/*     */     }
/* 189 */     return (ih.getInstruction() == RANGEINSTRUCTION);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static final Range getRange(InstructionHandle ih) {
/* 194 */     Range ret = null;
/* 195 */     for (InstructionTargeter targeter : ih.getTargeters()) {
/* 196 */       if (targeter instanceof Range) {
/* 197 */         Range r = (Range)targeter;
/* 198 */         if (r.getStart() != ih && r.getEnd() != ih) {
/*     */           continue;
/*     */         }
/* 201 */         if (ret != null) {
/* 202 */           throw new BCException("multiple ranges on same range handle: " + ret + ",  " + targeter);
/*     */         }
/* 204 */         ret = r;
/*     */       } 
/*     */     } 
/* 207 */     if (ret == null) {
/* 208 */       throw new BCException("shouldn't happen");
/*     */     }
/* 210 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 215 */   static final Where InsideBefore = new Where("insideBefore");
/* 216 */   static final Where InsideAfter = new Where("insideAfter");
/* 217 */   static final Where OutsideBefore = new Where("outsideBefore");
/* 218 */   static final Where OutsideAfter = new Where("outsideAfter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public static final Instruction RANGEINSTRUCTION = InstructionConstants.IMPDEP1;
/*     */ 
/*     */   
/*     */   static class Where
/*     */   {
/*     */     private String name;
/*     */     
/*     */     public Where(String name) {
/* 232 */       this.name = name;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 236 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\Range.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */