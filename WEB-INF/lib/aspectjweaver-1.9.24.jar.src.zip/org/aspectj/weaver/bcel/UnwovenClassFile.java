/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ import org.aspectj.util.FileUtil;
/*     */ import org.aspectj.weaver.IUnwovenClassFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnwovenClassFile
/*     */   implements IUnwovenClassFile
/*     */ {
/*     */   protected String filename;
/*     */   protected char[] charfilename;
/*     */   protected byte[] bytes;
/*  31 */   protected List<ChildClass> writtenChildClasses = Collections.emptyList();
/*  32 */   protected String className = null;
/*     */   protected boolean isModule = false;
/*     */   
/*     */   public UnwovenClassFile(String filename, byte[] bytes) {
/*  36 */     this.filename = filename;
/*  37 */     this.isModule = filename.toLowerCase().endsWith("module-info.java");
/*  38 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnwovenClassFile(String filename, String classname, byte[] bytes) {
/*  43 */     this.filename = filename;
/*  44 */     this.isModule = filename.toLowerCase().endsWith("module-info.class");
/*  45 */     this.className = classname;
/*  46 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldBeWoven() {
/*  51 */     return !this.isModule;
/*     */   }
/*     */   
/*     */   public String getFilename() {
/*  55 */     return this.filename;
/*     */   }
/*     */   
/*     */   public String makeInnerFileName(String innerName) {
/*  59 */     String prefix = this.filename.substring(0, this.filename.length() - 6);
/*  60 */     return prefix + "$" + innerName + ".class";
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/*  65 */     return this.bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass getJavaClass() {
/*  71 */     if (getBytes() == null) {
/*  72 */       System.out.println("no bytes for: " + getFilename());
/*     */       
/*  74 */       Thread.dumpStack();
/*     */     } 
/*  76 */     return Utility.makeJavaClass(this.filename, getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeUnchangedBytes() throws IOException {
/*  82 */     writeWovenBytes(getBytes(), Collections.emptyList());
/*     */   }
/*     */   
/*     */   public void writeWovenBytes(byte[] bytes, List<ChildClass> childClasses) throws IOException {
/*  86 */     writeChildClasses(childClasses);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     BufferedOutputStream os = FileUtil.makeOutputStream(new File(this.filename));
/*  98 */     os.write(bytes);
/*  99 */     os.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeChildClasses(List<ChildClass> childClasses) throws IOException {
/* 108 */     deleteAllChildClasses();
/*     */     
/* 110 */     childClasses.removeAll(this.writtenChildClasses);
/*     */     
/* 112 */     for (ChildClass childClass : childClasses) {
/* 113 */       writeChildClassFile(childClass.name, childClass.bytes);
/*     */     }
/*     */     
/* 116 */     this.writtenChildClasses = childClasses;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeChildClassFile(String innerName, byte[] bytes) throws IOException {
/* 121 */     BufferedOutputStream os = FileUtil.makeOutputStream(new File(makeInnerFileName(innerName)));
/* 122 */     os.write(bytes);
/* 123 */     os.close();
/*     */   }
/*     */   
/*     */   protected void deleteAllChildClasses() {
/* 127 */     for (ChildClass childClass : this.writtenChildClasses) {
/* 128 */       deleteChildClassFile(childClass.name);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void deleteChildClassFile(String innerName) {
/* 133 */     File childClassFile = new File(makeInnerFileName(innerName));
/* 134 */     childClassFile.delete();
/*     */   }
/*     */   
/*     */   static boolean unchanged(byte[] b1, byte[] b2) {
/* 138 */     int len = b1.length;
/* 139 */     if (b2.length != len)
/* 140 */       return false; 
/* 141 */     for (int i = 0; i < len; i++) {
/* 142 */       if (b1[i] != b2[i])
/* 143 */         return false; 
/*     */     } 
/* 145 */     return true;
/*     */   }
/*     */   
/*     */   public char[] getClassNameAsChars() {
/* 149 */     if (this.charfilename == null) {
/* 150 */       this.charfilename = getClassName().replace('.', '/').toCharArray();
/*     */     }
/* 152 */     return this.charfilename;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 156 */     if (this.className == null)
/* 157 */       this.className = getJavaClass().getClassName(); 
/* 158 */     return this.className;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     return "UnwovenClassFile(" + this.filename + ", " + getClassName() + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ChildClass
/*     */   {
/*     */     public final String name;
/*     */     
/*     */     public final byte[] bytes;
/*     */     
/*     */     ChildClass(String name, byte[] bytes) {
/* 174 */       this.name = name;
/* 175 */       this.bytes = bytes;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 180 */       if (!(other instanceof ChildClass))
/* 181 */         return false; 
/* 182 */       ChildClass o = (ChildClass)other;
/* 183 */       return (o.name.equals(this.name) && UnwovenClassFile.unchanged(o.bytes, this.bytes));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 188 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 193 */       return "(ChildClass " + this.name + ")";
/*     */     }
/*     */   }
/*     */   
/*     */   public void setClassNameAsChars(char[] classNameAsChars) {
/* 198 */     this.charfilename = classNameAsChars;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\UnwovenClassFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */