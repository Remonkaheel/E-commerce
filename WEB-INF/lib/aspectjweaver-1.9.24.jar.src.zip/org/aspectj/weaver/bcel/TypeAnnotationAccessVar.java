/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.generic.Instruction;
/*    */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*    */ import org.aspectj.apache.bcel.generic.InstructionList;
/*    */ import org.aspectj.apache.bcel.generic.ObjectType;
/*    */ import org.aspectj.apache.bcel.generic.Type;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeAnnotationAccessVar
/*    */   extends BcelVar
/*    */ {
/*    */   private BcelVar target;
/*    */   
/*    */   public TypeAnnotationAccessVar(ResolvedType type, BcelVar theAnnotatedTargetIsStoredHere) {
/* 33 */     super(type, 0);
/* 34 */     this.target = theAnnotatedTargetIsStoredHere;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 38 */     return "TypeAnnotationAccessVar(" + getType() + ")";
/*    */   }
/*    */   
/*    */   public Instruction createLoad(InstructionFactory fact) {
/* 42 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */   
/*    */   public Instruction createStore(InstructionFactory fact) {
/* 46 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */   
/*    */   public InstructionList createCopyFrom(InstructionFactory fact, int oldSlot) {
/* 50 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */   
/*    */   public void appendLoad(InstructionList il, InstructionFactory fact) {
/* 54 */     il.append(createLoadInstructions(getType(), fact));
/*    */   }
/*    */   
/*    */   public InstructionList createLoadInstructions(ResolvedType toType, InstructionFactory fact) {
/* 58 */     InstructionList il = new InstructionList();
/* 59 */     Type jlClass = BcelWorld.makeBcelType(UnresolvedType.JL_CLASS);
/* 60 */     Type jlaAnnotation = BcelWorld.makeBcelType(UnresolvedType.ANNOTATION);
/* 61 */     il.append(this.target.createLoad(fact));
/* 62 */     il.append((Instruction)fact.createInvoke("java/lang/Object", "getClass", jlClass, Type.NO_ARGS, (short)182));
/* 63 */     il.append(fact.createConstant(new ObjectType(toType.getName())));
/* 64 */     il.append((Instruction)fact.createInvoke("java/lang/Class", "getAnnotation", jlaAnnotation, new Type[] { jlClass }, (short)182));
/*    */     
/* 66 */     il.append(Utility.createConversion(fact, jlaAnnotation, BcelWorld.makeBcelType((UnresolvedType)toType)));
/* 67 */     return il;
/*    */   }
/*    */ 
/*    */   
/*    */   public void appendLoadAndConvert(InstructionList il, InstructionFactory fact, ResolvedType toType) {
/* 72 */     il.append(createLoadInstructions(toType, fact));
/*    */   }
/*    */ 
/*    */   
/*    */   public void insertLoad(InstructionList il, InstructionFactory fact) {
/* 77 */     il.insert(createLoadInstructions(getType(), fact));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\TypeAnnotationAccessVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */