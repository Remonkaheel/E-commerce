/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.classfile.Field;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionBranch;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationAccessVar
/*     */   extends BcelVar
/*     */ {
/*     */   private BcelShadow shadow;
/*     */   private Shadow.Kind kind;
/*     */   private UnresolvedType containingType;
/*     */   private Member member;
/*     */   private boolean isWithin;
/*     */   
/*     */   public AnnotationAccessVar(BcelShadow shadow, Shadow.Kind kind, ResolvedType annotationType, UnresolvedType theTargetIsStoredHere, Member sig, boolean isWithin) {
/*  46 */     super(annotationType, 0);
/*  47 */     this.shadow = shadow;
/*  48 */     this.kind = kind;
/*  49 */     this.containingType = theTargetIsStoredHere;
/*  50 */     this.member = sig;
/*  51 */     this.isWithin = isWithin;
/*     */   }
/*     */   
/*     */   public Shadow.Kind getKind() {
/*  55 */     return this.kind;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  60 */     return "AnnotationAccessVar(" + getType() + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public Instruction createLoad(InstructionFactory fact) {
/*  65 */     throw new IllegalStateException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public Instruction createStore(InstructionFactory fact) {
/*  70 */     throw new IllegalStateException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public InstructionList createCopyFrom(InstructionFactory fact, int oldSlot) {
/*  75 */     throw new IllegalStateException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendLoad(InstructionList il, InstructionFactory fact) {
/*  80 */     il.append(createLoadInstructions(getType(), fact));
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendLoadAndConvert(InstructionList il, InstructionFactory fact, ResolvedType toType) {
/*  85 */     il.append(createLoadInstructions(toType, fact));
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertLoad(InstructionList il, InstructionFactory fact) {
/*  90 */     il.insert(createLoadInstructions(getType(), fact));
/*     */   }
/*     */ 
/*     */   
/*     */   private InstructionList createLoadInstructions(ResolvedType toType, InstructionFactory fact) {
/*  95 */     InstructionList il = new InstructionList();
/*     */     
/*  97 */     Type jlClass = BcelWorld.makeBcelType(UnresolvedType.JL_CLASS);
/*  98 */     Type jlString = BcelWorld.makeBcelType(UnresolvedType.JL_STRING);
/*  99 */     Type jlClassArray = BcelWorld.makeBcelType(UnresolvedType.JAVA_LANG_CLASS_ARRAY);
/* 100 */     Type jlaAnnotation = BcelWorld.makeBcelType(UnresolvedType.JAVA_LANG_ANNOTATION);
/*     */     
/* 102 */     Instruction pushConstant = fact.createConstant(new ObjectType(toType.getName()));
/*     */     
/* 104 */     if (this.kind == Shadow.MethodCall || this.kind == Shadow.MethodExecution || this.kind == Shadow.PreInitialization || this.kind == Shadow.Initialization || this.kind == Shadow.ConstructorCall || this.kind == Shadow.ConstructorExecution || this.kind == Shadow.AdviceExecution || ((this.kind == Shadow.FieldGet || this.kind == Shadow.FieldSet) && this.member
/*     */ 
/*     */ 
/*     */       
/* 108 */       .getKind() == Member.METHOD)) {
/*     */       
/* 110 */       Type jlrMethod = BcelWorld.makeBcelType(UnresolvedType.forSignature("Ljava/lang/reflect/Method;"));
/* 111 */       Type jlAnnotation = BcelWorld.makeBcelType(UnresolvedType.forSignature("Ljava/lang/annotation/Annotation;"));
/* 112 */       Type[] paramTypes = BcelWorld.makeBcelTypes(this.member.getParameterTypes());
/*     */ 
/*     */ 
/*     */       
/* 116 */       if (this.kind == Shadow.MethodCall || this.kind == Shadow.MethodExecution || this.kind == Shadow.AdviceExecution || ((this.kind == Shadow.FieldGet || this.kind == Shadow.FieldSet) && this.member
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 121 */         .getKind() == Member.METHOD) || ((this.kind == Shadow.ConstructorCall || this.kind == Shadow.ConstructorExecution) && this.member
/* 122 */         .getKind() == Member.METHOD)) {
/*     */ 
/*     */         
/* 125 */         Field annotationCachingField = this.shadow.getEnclosingClass().getAnnotationCachingField(this.shadow, toType, this.isWithin);
/*     */ 
/*     */         
/* 128 */         il.append((Instruction)fact.createGetStatic(this.shadow.getEnclosingClass().getName(), annotationCachingField.getName(), jlAnnotation));
/* 129 */         il.append(InstructionConstants.DUP);
/* 130 */         InstructionBranch ifNonNull = InstructionFactory.createBranchInstruction((short)199, null);
/* 131 */         il.append(ifNonNull);
/* 132 */         il.append(InstructionConstants.POP);
/* 133 */         il.append(fact.createConstant(BcelWorld.makeBcelType(this.containingType)));
/*     */         
/* 135 */         il.append(fact.createConstant(this.member.getName()));
/* 136 */         buildArray(il, fact, jlClass, paramTypes, 1);
/*     */         
/* 138 */         il.append((Instruction)fact.createInvoke("java/lang/Class", "getDeclaredMethod", jlrMethod, new Type[] { jlString, jlClassArray }, (short)182));
/*     */         
/* 140 */         il.append(pushConstant);
/* 141 */         il.append((Instruction)fact.createInvoke("java/lang/reflect/Method", "getAnnotation", jlaAnnotation, new Type[] { jlClass }, (short)182));
/*     */         
/* 143 */         il.append(InstructionConstants.DUP);
/* 144 */         il.append((Instruction)fact.createPutStatic(this.shadow.getEnclosingClass().getName(), annotationCachingField.getName(), jlAnnotation));
/* 145 */         InstructionHandle ifNullElse = il.append(InstructionConstants.NOP);
/* 146 */         ifNonNull.setTarget(ifNullElse);
/*     */       } else {
/*     */         
/* 149 */         il.append(fact.createConstant(BcelWorld.makeBcelType(this.containingType)));
/* 150 */         buildArray(il, fact, jlClass, paramTypes, 1);
/* 151 */         Type jlrCtor = BcelWorld.makeBcelType(UnresolvedType.JAVA_LANG_REFLECT_CONSTRUCTOR);
/*     */ 
/*     */         
/* 154 */         il.append((Instruction)fact.createInvoke("java/lang/Class", "getDeclaredConstructor", jlrCtor, new Type[] { jlClassArray }, (short)182));
/*     */         
/* 156 */         il.append(pushConstant);
/* 157 */         il.append((Instruction)fact.createInvoke("java/lang/reflect/Constructor", "getAnnotation", jlaAnnotation, new Type[] { jlClass }, (short)182));
/*     */       }
/*     */     
/* 160 */     } else if (this.kind == Shadow.FieldSet || this.kind == Shadow.FieldGet) {
/* 161 */       generateBytecodeToAccessAnnotationAtFieldGetSetShadow(toType, fact, il, pushConstant);
/* 162 */     } else if (this.kind == Shadow.StaticInitialization || this.kind == Shadow.ExceptionHandler) {
/* 163 */       il.append(fact.createConstant(BcelWorld.makeBcelType(this.containingType)));
/* 164 */       il.append(pushConstant);
/* 165 */       il.append((Instruction)fact.createInvoke("java/lang/Class", "getAnnotation", jlaAnnotation, new Type[] { jlClass }, (short)182));
/*     */     } else {
/*     */       
/* 168 */       throw new RuntimeException("Don't understand this kind " + this.kind);
/*     */     } 
/* 170 */     il.append(Utility.createConversion(fact, jlaAnnotation, BcelWorld.makeBcelType((UnresolvedType)toType)));
/* 171 */     return il;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateBytecodeToAccessAnnotationAtFieldGetSetShadow(ResolvedType toType, InstructionFactory fact, InstructionList il, Instruction pushConstantAnnotationType) {
/* 180 */     Type jlClass = BcelWorld.makeBcelType(UnresolvedType.JL_CLASS);
/* 181 */     Type jlString = BcelWorld.makeBcelType(UnresolvedType.JL_STRING);
/* 182 */     Type jlaAnnotation = BcelWorld.makeBcelType(UnresolvedType.JAVA_LANG_ANNOTATION);
/* 183 */     Type jlrField = BcelWorld.makeBcelType(UnresolvedType.JAVA_LANG_REFLECT_FIELD);
/*     */     
/* 185 */     LazyClassGen shadowEnclosingClass = this.shadow.getEnclosingClass();
/*     */ 
/*     */     
/* 188 */     Field annotationCachingField = shadowEnclosingClass.getAnnotationCachingField(this.shadow, toType, this.isWithin);
/* 189 */     String annotationCachingFieldName = annotationCachingField.getName();
/*     */ 
/*     */     
/* 192 */     il.append((Instruction)fact.createGetStatic(shadowEnclosingClass.getName(), annotationCachingFieldName, jlaAnnotation));
/* 193 */     il.appendDUP();
/* 194 */     InstructionBranch ifNonNull = new InstructionBranch((short)199, null);
/* 195 */     il.append(ifNonNull);
/* 196 */     il.appendPOP();
/*     */ 
/*     */     
/* 199 */     il.append(fact.createConstant(BcelWorld.makeBcelType(this.containingType)));
/* 200 */     il.append(fact.createConstant(this.member.getName()));
/* 201 */     il.append((Instruction)fact.createInvoke("java/lang/Class", "getDeclaredField", jlrField, new Type[] { jlString }, (short)182));
/*     */     
/* 203 */     il.append(pushConstantAnnotationType);
/* 204 */     il.append((Instruction)fact.createInvoke("java/lang/reflect/Field", "getAnnotation", jlaAnnotation, new Type[] { jlClass }, (short)182));
/*     */     
/* 206 */     il.appendDUP();
/* 207 */     il.append((Instruction)fact.createPutStatic(shadowEnclosingClass.getName(), annotationCachingFieldName, jlaAnnotation));
/* 208 */     InstructionHandle ifNullElse = il.appendNOP();
/* 209 */     ifNonNull.setTarget(ifNullElse);
/*     */   }
/*     */   
/*     */   private void buildArray(InstructionList il, InstructionFactory fact, Type arrayElementType, Type[] arrayEntries, int dim) {
/* 213 */     il.append(fact.createConstant(Integer.valueOf((arrayEntries == null) ? 0 : arrayEntries.length)));
/* 214 */     il.append(fact.createNewArray(arrayElementType, (short)dim));
/* 215 */     if (arrayEntries == null) {
/*     */       return;
/*     */     }
/* 218 */     for (int i = 0; i < arrayEntries.length; i++) {
/* 219 */       il.append(InstructionFactory.createDup(1));
/* 220 */       il.append(fact.createConstant(Integer.valueOf(i)));
/* 221 */       switch (arrayEntries[i].getType()) {
/*     */         case 13:
/* 223 */           il.append(fact.createConstant(new ObjectType(arrayEntries[i].getSignature())));
/*     */           break;
/*     */         
/*     */         case 4:
/* 227 */           il.append((Instruction)fact.createGetStatic("java/lang/Boolean", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 8:
/* 230 */           il.append((Instruction)fact.createGetStatic("java/lang/Byte", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 5:
/* 233 */           il.append((Instruction)fact.createGetStatic("java/lang/Character", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 10:
/* 236 */           il.append((Instruction)fact.createGetStatic("java/lang/Integer", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 11:
/* 239 */           il.append((Instruction)fact.createGetStatic("java/lang/Long", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 7:
/* 242 */           il.append((Instruction)fact.createGetStatic("java/lang/Double", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 6:
/* 245 */           il.append((Instruction)fact.createGetStatic("java/lang/Float", "TYPE", arrayElementType));
/*     */           break;
/*     */         case 9:
/* 248 */           il.append((Instruction)fact.createGetStatic("java/lang/Short", "TYPE", arrayElementType));
/*     */           break;
/*     */         default:
/* 251 */           il.append(fact.createConstant(arrayEntries[i])); break;
/*     */       } 
/* 253 */       il.append(InstructionConstants.AASTORE);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Member getMember() {
/* 258 */     return this.member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Var getAccessorForValue(ResolvedType valueType, String formalName) {
/* 270 */     return new AnnotationAccessFieldVar(this, valueType, formalName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\AnnotationAccessVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */