/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.generic.FieldGen;
/*    */ import org.aspectj.apache.bcel.generic.Instruction;
/*    */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*    */ import org.aspectj.apache.bcel.generic.InstructionList;
/*    */ import org.aspectj.apache.bcel.generic.ObjectType;
/*    */ import org.aspectj.apache.bcel.generic.Type;
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedMember;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.ResolvedTypeMunger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelCflowCounterFieldAdder
/*    */   extends BcelTypeMunger
/*    */ {
/*    */   private ResolvedMember cflowCounterField;
/*    */   
/*    */   public BcelCflowCounterFieldAdder(ResolvedMember cflowCounterField) {
/* 33 */     super((ResolvedTypeMunger)null, (ResolvedType)cflowCounterField.getDeclaringType());
/* 34 */     this.cflowCounterField = cflowCounterField;
/*    */   }
/*    */   
/*    */   public boolean munge(BcelClassWeaver weaver) {
/* 38 */     LazyClassGen gen = weaver.getLazyClassGen();
/*    */ 
/*    */     
/* 41 */     if (!gen.getType().equals(this.cflowCounterField.getDeclaringType())) {
/* 42 */       return false;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 47 */     FieldGen f = new FieldGen(this.cflowCounterField.getModifiers(), BcelWorld.makeBcelType(this.cflowCounterField.getReturnType()), this.cflowCounterField.getName(), gen.getConstantPool());
/*    */     
/* 49 */     gen.addField(f, getSourceLocation());
/*    */ 
/*    */ 
/*    */     
/* 53 */     LazyMethodGen clinit = gen.getAjcPreClinit();
/* 54 */     InstructionList setup = new InstructionList();
/* 55 */     InstructionFactory fact = gen.getFactory();
/*    */     
/* 57 */     setup.append(fact.createNew(new ObjectType("org.aspectj.runtime.internal.CFlowCounter")));
/* 58 */     setup.append(InstructionFactory.createDup(1));
/* 59 */     setup.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.CFlowCounter", "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/*    */     
/* 61 */     setup.append(Utility.createSet(fact, (Member)this.cflowCounterField));
/* 62 */     clinit.getBody().insert(setup);
/*    */     
/* 64 */     return true;
/*    */   }
/*    */   
/*    */   public ResolvedMember getMatchingSyntheticMember(Member member) {
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   public ResolvedMember getSignature() {
/* 72 */     return this.cflowCounterField;
/*    */   }
/*    */   
/*    */   public boolean matches(ResolvedType onType) {
/* 76 */     return onType.equals(this.cflowCounterField.getDeclaringType());
/*    */   }
/*    */   
/*    */   public boolean existsToSupportShadowMunging() {
/* 80 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 84 */     return "(BcelTypeMunger: CflowField " + this.cflowCounterField.getDeclaringType().getName() + " " + this.cflowCounterField.getName() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelCflowCounterFieldAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */