/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectInstanceVar
/*     */   extends BcelVar
/*     */ {
/*     */   public AspectInstanceVar(ResolvedType type) {
/*  28 */     super(type, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createLoad(InstructionFactory fact) {
/*  34 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Instruction createStore(InstructionFactory fact) {
/*  39 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendStore(InstructionList il, InstructionFactory fact) {
/*  44 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendLoad(InstructionList il, InstructionFactory fact) {
/*  49 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendLoadAndConvert(InstructionList il, InstructionFactory fact, ResolvedType toType) {
/*  54 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertLoad(InstructionList il, InstructionFactory fact) {
/*  60 */     InstructionList loadInstructions = new InstructionList();
/*  61 */     loadInstructions.append((Instruction)fact.createInvoke(getType().getName(), "aspectOf", "()" + getType().getSignature(), (short)184));
/*     */     
/*  63 */     il.insert(loadInstructions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionList createCopyFrom(InstructionFactory fact, int oldSlot) {
/*  69 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void appendConvertableArrayLoad(InstructionList il, InstructionFactory fact, int index, ResolvedType convertTo) {
/*  78 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void appendConvertableArrayStore(InstructionList il, InstructionFactory fact, int index, BcelVar storee) {
/*  87 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InstructionList createConvertableArrayStore(InstructionFactory fact, int index, BcelVar storee) {
/*  97 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InstructionList createConvertableArrayLoad(InstructionFactory fact, int index, ResolvedType convertTo) {
/* 104 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPositionInAroundState() {
/* 111 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPositionInAroundState(int positionInAroundState) {
/* 116 */     throw new IllegalStateException();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\AspectInstanceVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */