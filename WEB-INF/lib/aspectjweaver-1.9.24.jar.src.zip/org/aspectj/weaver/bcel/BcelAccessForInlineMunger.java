/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.generic.FieldInstruction;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.InvokeInstruction;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.AjcMemberMaker;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.NameMangler;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.ResolvedTypeMunger;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BcelAccessForInlineMunger
/*     */   extends BcelTypeMunger
/*     */ {
/*     */   private Map<String, ResolvedMember> inlineAccessors;
/*     */   private LazyClassGen aspectGen;
/*     */   private Set<LazyMethodGen> inlineAccessorMethodGens;
/*     */   
/*     */   public BcelAccessForInlineMunger(ResolvedType aspectType) {
/*  68 */     super((ResolvedTypeMunger)null, aspectType);
/*  69 */     if (aspectType.getWorld().isXnoInline()) {
/*  70 */       throw new Error("This should not happen");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean munge(BcelClassWeaver weaver) {
/*  76 */     this.aspectGen = weaver.getLazyClassGen();
/*  77 */     this.inlineAccessors = new HashMap<>(0);
/*  78 */     this.inlineAccessorMethodGens = new HashSet<>();
/*     */ 
/*     */     
/*  81 */     for (LazyMethodGen methodGen : this.aspectGen.getMethodGens()) {
/*  82 */       if (methodGen.hasAnnotation(UnresolvedType.forName("org/aspectj/lang/annotation/Around"))) {
/*  83 */         openAroundAdvice(methodGen);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  88 */     for (LazyMethodGen lazyMethodGen : this.inlineAccessorMethodGens) {
/*  89 */       this.aspectGen.addMethodGen(lazyMethodGen);
/*     */     }
/*     */ 
/*     */     
/*  93 */     this.inlineAccessorMethodGens = null;
/*     */ 
/*     */     
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedMember getMatchingSyntheticMember(Member member) {
/* 104 */     String name = member.getName();
/*     */ 
/*     */     
/* 107 */     String signature = name.startsWith("ajc$superDispatch$") ? member.getSignature() : member.getSignature().replaceFirst("\\([^;]+;", "(");
/* 108 */     ResolvedMember rm = this.inlineAccessors.get(name + signature);
/*     */ 
/*     */     
/* 111 */     return rm;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolvedMember getSignature() {
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(ResolvedType onType) {
/* 124 */     return this.aspectType.equals(onType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void openAroundAdvice(LazyMethodGen aroundAdvice) {
/* 131 */     InstructionHandle curr = aroundAdvice.getBody().getStart();
/* 132 */     InstructionHandle end = aroundAdvice.getBody().getEnd();
/* 133 */     ConstantPool cpg = aroundAdvice.getEnclosingClass().getConstantPool();
/* 134 */     InstructionFactory factory = aroundAdvice.getEnclosingClass().getFactory();
/*     */     
/* 136 */     boolean realizedCannotInline = false;
/* 137 */     while (curr != end && 
/* 138 */       !realizedCannotInline) {
/*     */ 
/*     */ 
/*     */       
/* 142 */       InstructionHandle next = curr.getNext();
/* 143 */       Instruction inst = curr.getInstruction();
/*     */ 
/*     */       
/* 146 */       if (inst instanceof InvokeInstruction) {
/* 147 */         InvokeInstruction invoke = (InvokeInstruction)inst;
/* 148 */         if (invoke instanceof org.aspectj.apache.bcel.generic.InvokeDynamic) {
/* 149 */           realizedCannotInline = true;
/*     */           break;
/*     */         } 
/* 152 */         ResolvedType callee = this.aspectGen.getWorld().resolve(UnresolvedType.forName(invoke.getClassName(cpg)));
/*     */ 
/*     */         
/* 155 */         List<ResolvedMember> methods = callee.getMethodsWithoutIterator(false, true, false);
/* 156 */         for (ResolvedMember resolvedMember : methods) {
/* 157 */           if (invoke.getName(cpg).equals(resolvedMember.getName()) && invoke
/* 158 */             .getSignature(cpg).equals(resolvedMember.getSignature()) && !resolvedMember.isPublic()) {
/* 159 */             if ("<init>".equals(invoke.getName(cpg))) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 164 */               if (invoke.getClassName(cpg).equals(resolvedMember.getDeclaringType().getPackageName() + "." + resolvedMember
/* 165 */                   .getDeclaringType().getClassName())) {
/*     */ 
/*     */ 
/*     */                 
/* 169 */                 aroundAdvice.setCanInline(false);
/* 170 */                 realizedCannotInline = true;
/*     */               } 
/*     */               break;
/*     */             } 
/* 174 */             ResolvedType memberType = this.aspectGen.getWorld().resolve(resolvedMember.getDeclaringType());
/* 175 */             if (!this.aspectType.equals(memberType) && memberType.isAssignableFrom(this.aspectType)) {
/*     */ 
/*     */ 
/*     */               
/* 179 */               ResolvedMember resolvedMember1 = createOrGetInlineAccessorForSuperDispatch(resolvedMember);
/* 180 */               InvokeInstruction invokeInstruction = factory.createInvoke(this.aspectType.getName(), resolvedMember1.getName(), 
/* 181 */                   BcelWorld.makeBcelType(resolvedMember1.getReturnType()), 
/* 182 */                   BcelWorld.makeBcelTypes(resolvedMember1.getParameterTypes()), (short)182);
/* 183 */               curr.setInstruction((Instruction)invokeInstruction); break;
/*     */             } 
/* 185 */             ResolvedMember accessor = createOrGetInlineAccessorForMethod(resolvedMember);
/* 186 */             InvokeInstruction newInst = factory.createInvoke(this.aspectType.getName(), accessor.getName(), 
/* 187 */                 BcelWorld.makeBcelType(accessor.getReturnType()), 
/* 188 */                 BcelWorld.makeBcelTypes(accessor.getParameterTypes()), (short)184);
/* 189 */             curr.setInstruction((Instruction)newInst);
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 196 */       } else if (inst instanceof FieldInstruction) {
/* 197 */         FieldInstruction invoke = (FieldInstruction)inst;
/* 198 */         ResolvedType callee = this.aspectGen.getWorld().resolve(UnresolvedType.forName(invoke.getClassName(cpg)));
/* 199 */         for (int i = 0; i < (callee.getDeclaredJavaFields()).length; i++) {
/* 200 */           ResolvedMember resolvedMember = callee.getDeclaredJavaFields()[i];
/* 201 */           if (invoke.getName(cpg).equals(resolvedMember.getName()) && invoke
/* 202 */             .getSignature(cpg).equals(resolvedMember.getSignature()) && !resolvedMember.isPublic()) {
/*     */             ResolvedMember accessor;
/* 204 */             if (inst.opcode == 180 || inst.opcode == 178) {
/* 205 */               accessor = createOrGetInlineAccessorForFieldGet(resolvedMember);
/*     */             } else {
/* 207 */               accessor = createOrGetInlineAccessorForFieldSet(resolvedMember);
/*     */             } 
/* 209 */             InvokeInstruction newInst = factory.createInvoke(this.aspectType.getName(), accessor.getName(), 
/* 210 */                 BcelWorld.makeBcelType(accessor.getReturnType()), 
/* 211 */                 BcelWorld.makeBcelTypes(accessor.getParameterTypes()), (short)184);
/* 212 */             curr.setInstruction((Instruction)newInst);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 219 */       curr = next;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     if (!realizedCannotInline) {
/* 226 */       aroundAdvice.setCanInline(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedMember createOrGetInlineAccessorForMethod(ResolvedMember resolvedMember) {
/* 234 */     String accessorName = NameMangler.inlineAccessMethodForMethod(resolvedMember.getName(), resolvedMember.getDeclaringType(), (UnresolvedType)this.aspectType);
/*     */     
/* 236 */     String key = accessorName + resolvedMember.getSignature();
/* 237 */     ResolvedMember inlineAccessor = this.inlineAccessors.get(key);
/*     */     
/* 239 */     if (inlineAccessor == null) {
/*     */       
/* 241 */       inlineAccessor = AjcMemberMaker.inlineAccessMethodForMethod((UnresolvedType)this.aspectType, resolvedMember);
/*     */ 
/*     */       
/* 244 */       InstructionFactory factory = this.aspectGen.getFactory();
/* 245 */       LazyMethodGen method = makeMethodGen(this.aspectGen, inlineAccessor);
/* 246 */       method.makeSynthetic();
/* 247 */       List<AjAttribute> methodAttributes = new ArrayList<>();
/* 248 */       methodAttributes.add(new AjAttribute.AjSynthetic());
/* 249 */       methodAttributes.add(new AjAttribute.EffectiveSignatureAttribute(resolvedMember, Shadow.MethodCall, false));
/* 250 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(0), this.aspectGen.getConstantPool()));
/*     */       
/* 252 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(1), this.aspectGen.getConstantPool()));
/*     */       
/* 254 */       this.inlineAccessorMethodGens.add(method);
/*     */       
/* 256 */       InstructionList il = method.getBody();
/* 257 */       int register = 0;
/* 258 */       for (int i = 0, max = (inlineAccessor.getParameterTypes()).length; i < max; i++) {
/* 259 */         UnresolvedType ptype = inlineAccessor.getParameterTypes()[i];
/* 260 */         Type type = BcelWorld.makeBcelType(ptype);
/* 261 */         il.append((Instruction)InstructionFactory.createLoad(type, register));
/* 262 */         register += type.getSize();
/*     */       } 
/* 264 */       il.append(Utility.createInvoke(factory, Modifier.isStatic(resolvedMember.getModifiers()) ? 184 : 
/* 265 */             182, (Member)resolvedMember));
/* 266 */       il.append(InstructionFactory.createReturn(BcelWorld.makeBcelType(inlineAccessor.getReturnType())));
/*     */       
/* 268 */       this.inlineAccessors.put(key, new BcelMethod(this.aspectGen.getBcelObjectType(), method.getMethod(), methodAttributes));
/*     */     } 
/* 270 */     return inlineAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedMember createOrGetInlineAccessorForSuperDispatch(ResolvedMember resolvedMember) {
/* 277 */     String accessor = NameMangler.superDispatchMethod((UnresolvedType)this.aspectType, resolvedMember.getName());
/*     */     
/* 279 */     String key = accessor + resolvedMember.getSignature();
/* 280 */     ResolvedMember inlineAccessor = this.inlineAccessors.get(key);
/*     */     
/* 282 */     if (inlineAccessor == null) {
/*     */       
/* 284 */       inlineAccessor = AjcMemberMaker.superAccessMethod((UnresolvedType)this.aspectType, resolvedMember);
/*     */ 
/*     */       
/* 287 */       InstructionFactory factory = this.aspectGen.getFactory();
/* 288 */       LazyMethodGen method = makeMethodGen(this.aspectGen, inlineAccessor);
/*     */       
/* 290 */       method.makeSynthetic();
/* 291 */       List<AjAttribute> methodAttributes = new ArrayList<>();
/* 292 */       methodAttributes.add(new AjAttribute.AjSynthetic());
/* 293 */       methodAttributes.add(new AjAttribute.EffectiveSignatureAttribute(resolvedMember, Shadow.MethodCall, false));
/* 294 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(0), this.aspectGen.getConstantPool()));
/*     */       
/* 296 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(1), this.aspectGen.getConstantPool()));
/*     */       
/* 298 */       this.inlineAccessorMethodGens.add(method);
/*     */       
/* 300 */       InstructionList il = method.getBody();
/* 301 */       il.append((Instruction)InstructionConstants.ALOAD_0);
/* 302 */       int register = 1;
/* 303 */       for (int i = 0; i < (inlineAccessor.getParameterTypes()).length; i++) {
/* 304 */         UnresolvedType typeX = inlineAccessor.getParameterTypes()[i];
/* 305 */         Type type = BcelWorld.makeBcelType(typeX);
/* 306 */         il.append((Instruction)InstructionFactory.createLoad(type, register));
/* 307 */         register += type.getSize();
/*     */       } 
/* 309 */       il.append(Utility.createInvoke(factory, (short)183, (Member)resolvedMember));
/* 310 */       il.append(InstructionFactory.createReturn(BcelWorld.makeBcelType(inlineAccessor.getReturnType())));
/*     */       
/* 312 */       this.inlineAccessors.put(key, new BcelMethod(this.aspectGen.getBcelObjectType(), method.getMethod(), methodAttributes));
/*     */     } 
/* 314 */     return inlineAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedMember createOrGetInlineAccessorForFieldGet(ResolvedMember resolvedMember) {
/* 321 */     String accessor = NameMangler.inlineAccessMethodForFieldGet(resolvedMember.getName(), resolvedMember.getDeclaringType(), (UnresolvedType)this.aspectType);
/*     */     
/* 323 */     String key = accessor + "()" + resolvedMember.getSignature();
/* 324 */     ResolvedMember inlineAccessor = this.inlineAccessors.get(key);
/*     */     
/* 326 */     if (inlineAccessor == null) {
/*     */       
/* 328 */       inlineAccessor = AjcMemberMaker.inlineAccessMethodForFieldGet((UnresolvedType)this.aspectType, (Member)resolvedMember);
/*     */ 
/*     */       
/* 331 */       InstructionFactory factory = this.aspectGen.getFactory();
/* 332 */       LazyMethodGen method = makeMethodGen(this.aspectGen, inlineAccessor);
/*     */       
/* 334 */       method.makeSynthetic();
/* 335 */       List<AjAttribute> methodAttributes = new ArrayList<>();
/* 336 */       methodAttributes.add(new AjAttribute.AjSynthetic());
/* 337 */       methodAttributes.add(new AjAttribute.EffectiveSignatureAttribute(resolvedMember, Shadow.FieldGet, false));
/*     */       
/* 339 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(0), this.aspectGen.getConstantPool()));
/* 340 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(1), this.aspectGen.getConstantPool()));
/*     */       
/* 342 */       this.inlineAccessorMethodGens.add(method);
/*     */       
/* 344 */       InstructionList il = method.getBody();
/* 345 */       if (!Modifier.isStatic(resolvedMember.getModifiers()))
/*     */       {
/*     */         
/* 348 */         il.append((Instruction)InstructionConstants.ALOAD_0);
/*     */       }
/* 350 */       il.append(Utility.createGet(factory, (Member)resolvedMember));
/* 351 */       il.append(InstructionFactory.createReturn(BcelWorld.makeBcelType(inlineAccessor.getReturnType())));
/*     */       
/* 353 */       this.inlineAccessors.put(key, new BcelMethod(this.aspectGen.getBcelObjectType(), method.getMethod(), methodAttributes));
/*     */     } 
/* 355 */     return inlineAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedMember createOrGetInlineAccessorForFieldSet(ResolvedMember resolvedMember) {
/* 362 */     String accessor = NameMangler.inlineAccessMethodForFieldSet(resolvedMember.getName(), resolvedMember.getDeclaringType(), (UnresolvedType)this.aspectType);
/*     */     
/* 364 */     String key = accessor + "(" + resolvedMember.getSignature() + ")V";
/* 365 */     ResolvedMember inlineAccessor = this.inlineAccessors.get(key);
/*     */     
/* 367 */     if (inlineAccessor == null) {
/*     */       
/* 369 */       inlineAccessor = AjcMemberMaker.inlineAccessMethodForFieldSet((UnresolvedType)this.aspectType, (Member)resolvedMember);
/*     */ 
/*     */       
/* 372 */       InstructionFactory factory = this.aspectGen.getFactory();
/* 373 */       LazyMethodGen method = makeMethodGen(this.aspectGen, inlineAccessor);
/*     */       
/* 375 */       method.makeSynthetic();
/* 376 */       List<AjAttribute> methodAttributes = new ArrayList<>();
/* 377 */       methodAttributes.add(new AjAttribute.AjSynthetic());
/* 378 */       methodAttributes.add(new AjAttribute.EffectiveSignatureAttribute(resolvedMember, Shadow.FieldSet, false));
/* 379 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(0), this.aspectGen.getConstantPool()));
/*     */       
/* 381 */       method.addAttribute(Utility.bcelAttribute(methodAttributes.get(1), this.aspectGen.getConstantPool()));
/*     */       
/* 383 */       this.inlineAccessorMethodGens.add(method);
/*     */       
/* 385 */       InstructionList il = method.getBody();
/* 386 */       if (Modifier.isStatic(resolvedMember.getModifiers())) {
/*     */         
/* 388 */         il.append((Instruction)InstructionFactory.createLoad(BcelWorld.makeBcelType(resolvedMember.getReturnType()), 0));
/*     */       } else {
/* 390 */         il.append((Instruction)InstructionConstants.ALOAD_0);
/* 391 */         il.append((Instruction)InstructionFactory.createLoad(BcelWorld.makeBcelType(resolvedMember.getReturnType()), 1));
/*     */       } 
/* 393 */       il.append(Utility.createSet(factory, (Member)resolvedMember));
/* 394 */       il.append(InstructionConstants.RETURN);
/* 395 */       this.inlineAccessors.put(key, new BcelMethod(this.aspectGen.getBcelObjectType(), method.getMethod(), methodAttributes));
/*     */     } 
/* 397 */     return inlineAccessor;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelAccessForInlineMunger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */