/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.Field;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.generic.FieldGen;
/*     */ import org.aspectj.util.GenericSignature;
/*     */ import org.aspectj.util.GenericSignatureParser;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.AnnotationAJ;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedMemberImpl;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BcelField
/*     */   extends ResolvedMemberImpl
/*     */ {
/*  43 */   public static int AccSynthetic = 4096;
/*     */   
/*     */   private Field field;
/*     */   private boolean isAjSynthetic;
/*     */   private boolean isSynthetic = false;
/*     */   private AnnotationAJ[] annotations;
/*     */   private final World world;
/*     */   private final BcelObjectType bcelObjectType;
/*  51 */   private UnresolvedType genericFieldType = null;
/*     */   private boolean unpackedGenericSignature = false;
/*     */   private boolean annotationsOnFieldObjectAreOutOfDate = false;
/*     */   
/*     */   BcelField(BcelObjectType declaringType, Field field) {
/*  56 */     super(FIELD, (UnresolvedType)declaringType.getResolvedTypeX(), field.getModifiers(), field.getName(), field.getSignature());
/*  57 */     this.field = field;
/*  58 */     this.world = declaringType.getResolvedTypeX().getWorld();
/*  59 */     this.bcelObjectType = declaringType;
/*  60 */     unpackAttributes(this.world);
/*  61 */     this.checkedExceptions = UnresolvedType.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BcelField(String declaringTypeName, Field field, World world) {
/*  69 */     super(FIELD, UnresolvedType.forName(declaringTypeName), field.getModifiers(), field.getName(), field.getSignature());
/*  70 */     this.field = field;
/*  71 */     this.world = world;
/*  72 */     this.bcelObjectType = null;
/*  73 */     unpackAttributes(world);
/*  74 */     this.checkedExceptions = UnresolvedType.NONE;
/*     */   }
/*     */   
/*     */   private void unpackAttributes(World world) {
/*  78 */     Attribute[] attrs = this.field.getAttributes();
/*  79 */     if (attrs != null && attrs.length > 0) {
/*  80 */       ISourceContext sourceContext = getSourceContext(world);
/*  81 */       List<AjAttribute> as = Utility.readAjAttributes(getDeclaringType().getClassName(), attrs, sourceContext, world, 
/*  82 */           (this.bcelObjectType != null) ? this.bcelObjectType.getWeaverVersionAttribute() : AjAttribute.WeaverVersionInfo.CURRENT, new BcelConstantPoolReader(this.field
/*  83 */             .getConstantPool()));
/*  84 */       as.addAll(AtAjAttributes.readAj5FieldAttributes(this.field, this, world.resolve(getDeclaringType()), sourceContext, world
/*  85 */             .getMessageHandler()));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.isAjSynthetic = false;
/*     */     
/*  98 */     for (int i = attrs.length - 1; i >= 0; i--) {
/*  99 */       if (attrs[i] instanceof org.aspectj.apache.bcel.classfile.Synthetic) {
/* 100 */         this.isSynthetic = true;
/*     */       }
/*     */     } 
/*     */     
/* 104 */     if ((this.field.getModifiers() & AccSynthetic) != 0) {
/* 105 */       this.isSynthetic = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAjSynthetic() {
/* 112 */     return this.isAjSynthetic;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 117 */     return this.isSynthetic;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAnnotation(UnresolvedType ofType) {
/* 122 */     ensureAnnotationTypesRetrieved();
/* 123 */     for (ResolvedType aType : this.annotationTypes) {
/* 124 */       if (aType.equals(ofType)) {
/* 125 */         return true;
/*     */       }
/*     */     } 
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolvedType[] getAnnotationTypes() {
/* 133 */     ensureAnnotationTypesRetrieved();
/* 134 */     return this.annotationTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationAJ[] getAnnotations() {
/* 139 */     ensureAnnotationTypesRetrieved();
/* 140 */     return this.annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationAJ getAnnotationOfType(UnresolvedType ofType) {
/* 145 */     ensureAnnotationTypesRetrieved();
/* 146 */     for (AnnotationAJ annotation : this.annotations) {
/* 147 */       if (annotation.getTypeName().equals(ofType.getName())) {
/* 148 */         return annotation;
/*     */       }
/*     */     } 
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   private void ensureAnnotationTypesRetrieved() {
/* 155 */     if (this.annotationTypes == null) {
/* 156 */       AnnotationGen[] annos = this.field.getAnnotations();
/* 157 */       if (annos.length == 0) {
/* 158 */         this.annotationTypes = ResolvedType.EMPTY_ARRAY;
/* 159 */         this.annotations = AnnotationAJ.EMPTY_ARRAY;
/*     */       } else {
/* 161 */         int annosCount = annos.length;
/* 162 */         this.annotationTypes = new ResolvedType[annosCount];
/* 163 */         this.annotations = new AnnotationAJ[annosCount];
/* 164 */         for (int i = 0; i < annosCount; i++) {
/* 165 */           AnnotationGen anno = annos[i];
/* 166 */           this.annotations[i] = (AnnotationAJ)new BcelAnnotation(anno, this.world);
/* 167 */           this.annotationTypes[i] = this.annotations[i].getType();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnnotation(AnnotationAJ annotation) {
/* 175 */     ensureAnnotationTypesRetrieved();
/* 176 */     int len = this.annotations.length;
/* 177 */     AnnotationAJ[] ret = new AnnotationAJ[len + 1];
/* 178 */     System.arraycopy(this.annotations, 0, ret, 0, len);
/* 179 */     ret[len] = annotation;
/* 180 */     this.annotations = ret;
/*     */     
/* 182 */     ResolvedType[] newAnnotationTypes = new ResolvedType[len + 1];
/* 183 */     System.arraycopy(this.annotationTypes, 0, newAnnotationTypes, 0, len);
/* 184 */     newAnnotationTypes[len] = annotation.getType();
/* 185 */     this.annotationTypes = newAnnotationTypes;
/*     */     
/* 187 */     this.annotationsOnFieldObjectAreOutOfDate = true;
/*     */   }
/*     */   
/*     */   public void removeAnnotation(AnnotationAJ annotation) {
/* 191 */     ensureAnnotationTypesRetrieved();
/*     */     
/* 193 */     int len = this.annotations.length;
/* 194 */     AnnotationAJ[] ret = new AnnotationAJ[len - 1];
/* 195 */     int p = 0;
/* 196 */     for (AnnotationAJ anno : this.annotations) {
/* 197 */       if (!anno.getType().equals(annotation.getType())) {
/* 198 */         ret[p++] = anno;
/*     */       }
/*     */     } 
/* 201 */     this.annotations = ret;
/*     */     
/* 203 */     ResolvedType[] newAnnotationTypes = new ResolvedType[len - 1];
/* 204 */     p = 0;
/* 205 */     for (ResolvedType anno : this.annotationTypes) {
/* 206 */       if (!anno.equals(annotation.getType())) {
/* 207 */         newAnnotationTypes[p++] = anno;
/*     */       }
/*     */     } 
/* 210 */     this.annotationTypes = newAnnotationTypes;
/*     */     
/* 212 */     this.annotationsOnFieldObjectAreOutOfDate = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedType getGenericReturnType() {
/* 221 */     unpackGenericSignature();
/* 222 */     return this.genericFieldType;
/*     */   }
/*     */   
/*     */   public Field getFieldAsIs() {
/* 226 */     return this.field;
/*     */   }
/*     */   
/*     */   public Field getField(ConstantPool cpool) {
/* 230 */     if (!this.annotationsOnFieldObjectAreOutOfDate) {
/* 231 */       return this.field;
/*     */     }
/* 233 */     FieldGen newFieldGen = new FieldGen(this.field, cpool);
/* 234 */     newFieldGen.removeAnnotations();
/*     */ 
/*     */ 
/*     */     
/* 238 */     for (AnnotationAJ annotation : this.annotations) {
/* 239 */       newFieldGen.addAnnotation(new AnnotationGen(((BcelAnnotation)annotation).getBcelAnnotation(), cpool, true));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     this.field = newFieldGen.getField();
/* 256 */     this.annotationsOnFieldObjectAreOutOfDate = false;
/* 257 */     return this.field;
/*     */   }
/*     */   
/*     */   private void unpackGenericSignature() {
/* 261 */     if (this.unpackedGenericSignature) {
/*     */       return;
/*     */     }
/* 264 */     if (!this.world.isInJava5Mode()) {
/* 265 */       this.genericFieldType = getReturnType();
/*     */       return;
/*     */     } 
/* 268 */     this.unpackedGenericSignature = true;
/* 269 */     String gSig = this.field.getGenericSignature();
/* 270 */     if (gSig != null) {
/*     */       
/* 272 */       GenericSignature.FieldTypeSignature fts = (new GenericSignatureParser()).parseAsFieldSignature(gSig);
/* 273 */       GenericSignature.ClassSignature genericTypeSig = this.bcelObjectType.getGenericClassTypeSignature();
/*     */       
/* 275 */       GenericSignature.FormalTypeParameter[] parentFormals = this.bcelObjectType.getAllFormals();
/*     */       
/* 277 */       GenericSignature.FormalTypeParameter[] typeVars = (genericTypeSig == null) ? GenericSignature.FormalTypeParameter.NONE : genericTypeSig.formalTypeParameters;
/* 278 */       GenericSignature.FormalTypeParameter[] formals = new GenericSignature.FormalTypeParameter[parentFormals.length + typeVars.length];
/*     */ 
/*     */ 
/*     */       
/* 282 */       System.arraycopy(typeVars, 0, formals, 0, typeVars.length);
/* 283 */       System.arraycopy(parentFormals, 0, formals, typeVars.length, parentFormals.length);
/*     */       
/*     */       try {
/* 286 */         this.genericFieldType = (UnresolvedType)BcelGenericSignatureToTypeXConverter.fieldTypeSignature2TypeX(fts, formals, this.world);
/* 287 */       } catch (GenericSignatureFormatException e) {
/*     */         
/* 289 */         throw new IllegalStateException("While determing the generic field type of " + toString() + " with generic signature " + gSig + " the following error was detected: " + e
/* 290 */             .getMessage());
/*     */       } 
/*     */     } else {
/* 293 */       this.genericFieldType = getReturnType();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void evictWeavingState() {
/* 299 */     if (this.field != null) {
/* 300 */       unpackGenericSignature();
/* 301 */       unpackAttributes(this.world);
/* 302 */       ensureAnnotationTypesRetrieved();
/*     */       
/* 304 */       this.field = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */