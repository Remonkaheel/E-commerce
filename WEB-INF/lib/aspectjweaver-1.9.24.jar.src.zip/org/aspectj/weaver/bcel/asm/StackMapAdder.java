/*     */ package org.aspectj.weaver.bcel.asm;
/*     */ 
/*     */ import aj.org.objectweb.asm.ClassReader;
/*     */ import aj.org.objectweb.asm.ClassVisitor;
/*     */ import aj.org.objectweb.asm.ClassWriter;
/*     */ import aj.org.objectweb.asm.MethodVisitor;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackMapAdder
/*     */ {
/*     */   public static byte[] addStackMaps(World world, String classname, byte[] data) {
/*     */     try {
/*  42 */       ClassReader cr = new ClassReader(data);
/*  43 */       ClassWriter cw = new AspectJConnectClassWriter(cr, world);
/*  44 */       ClassVisitor cv = new AspectJClassVisitor((ClassVisitor)cw);
/*  45 */       cr.accept(cv, 0);
/*  46 */       return cw.toByteArray();
/*  47 */     } catch (Throwable t) {
/*     */       
/*  49 */       System.err.println("AspectJ Internal Error: unable to add stackmap attributes to class '" + classname + "'. " + t.getMessage());
/*  50 */       t.printStackTrace();
/*  51 */       AsmDetector.isAsmAround = false;
/*  52 */       AsmDetector.rootCause = t;
/*  53 */       return data;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class AspectJClassVisitor
/*     */     extends ClassVisitor {
/*     */     public AspectJClassVisitor(ClassVisitor classwriter) {
/*  60 */       super(589824, classwriter);
/*     */     }
/*     */ 
/*     */     
/*     */     public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/*  65 */       MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
/*  66 */       return new AJMethodVisitor(mv);
/*     */     }
/*     */     
/*     */     static class AJMethodVisitor
/*     */       extends MethodVisitor
/*     */     {
/*     */       public AJMethodVisitor(MethodVisitor mv) {
/*  73 */         super(589824, mv);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AspectJConnectClassWriter
/*     */     extends ClassWriter {
/*     */     private final World world;
/*     */     
/*     */     public AspectJConnectClassWriter(ClassReader cr, World w) {
/*  83 */       super(cr, 2);
/*  84 */       this.world = w;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String getCommonSuperClass(String type1, String type2) {
/*  92 */       ResolvedType resolvedType1 = this.world.resolve(UnresolvedType.forName(type1.replace('/', '.')));
/*  93 */       ResolvedType resolvedType2 = this.world.resolve(UnresolvedType.forName(type2.replace('/', '.')));
/*     */       
/*  95 */       if (resolvedType1.isAssignableFrom(resolvedType2)) {
/*  96 */         return type1;
/*     */       }
/*     */       
/*  99 */       if (resolvedType2.isAssignableFrom(resolvedType1)) {
/* 100 */         return type2;
/*     */       }
/*     */       
/* 103 */       if (resolvedType1.isInterface() || resolvedType2.isInterface()) {
/* 104 */         return "java/lang/Object";
/*     */       }
/*     */       while (true) {
/* 107 */         resolvedType1 = resolvedType1.getSuperclass();
/* 108 */         if (resolvedType1 == null)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 114 */           return "java/lang/Object";
/*     */         }
/* 116 */         if (resolvedType1.isParameterizedOrGenericType()) {
/* 117 */           resolvedType1 = resolvedType1.getRawType();
/*     */         }
/* 119 */         if (resolvedType1.isAssignableFrom(resolvedType2))
/* 120 */           return resolvedType1.getRawName().replace('.', '/'); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\asm\StackMapAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */