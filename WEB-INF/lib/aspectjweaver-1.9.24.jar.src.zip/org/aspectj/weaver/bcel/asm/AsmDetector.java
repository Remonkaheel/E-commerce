/*    */ package org.aspectj.weaver.bcel.asm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsmDetector
/*    */ {
/*    */   public static final String CLASS_READER = "aj.org.objectweb.asm.ClassReader";
/*    */   public static final String CLASS_VISITOR = "aj.org.objectweb.asm.ClassVisitor";
/*    */   public static boolean isAsmAround;
/*    */   public static Throwable rootCause;
/*    */   
/*    */   static {
/*    */     try {
/* 27 */       Class<?> reader = Class.forName("aj.org.objectweb.asm.ClassReader");
/* 28 */       Class<?> visitor = Class.forName("aj.org.objectweb.asm.ClassVisitor");
/* 29 */       reader.getMethod("accept", new Class[] { visitor, int.class });
/* 30 */       isAsmAround = true;
/* 31 */     } catch (Exception e) {
/* 32 */       isAsmAround = false;
/* 33 */       rootCause = e;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\asm\AsmDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */