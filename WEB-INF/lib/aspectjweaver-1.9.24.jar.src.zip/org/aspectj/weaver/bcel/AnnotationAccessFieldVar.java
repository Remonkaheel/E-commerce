/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.EnumElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.SimpleElementValue;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.weaver.AnnotationAJ;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationAccessFieldVar
/*     */   extends BcelVar
/*     */ {
/*     */   private AnnotationAccessVar annoAccessor;
/*     */   private ResolvedType annoFieldOfInterest;
/*     */   private String name;
/*     */   private int elementValueType;
/*     */   
/*     */   public AnnotationAccessFieldVar(AnnotationAccessVar aav, ResolvedType annoFieldOfInterest, String name) {
/*  45 */     super(annoFieldOfInterest, 0);
/*  46 */     this.annoAccessor = aav;
/*  47 */     this.name = name;
/*  48 */     String sig = annoFieldOfInterest.getSignature();
/*  49 */     if (sig.length() == 1) {
/*  50 */       switch (sig.charAt(0)) {
/*     */         case 'I':
/*  52 */           this.elementValueType = 73;
/*     */           break;
/*     */         default:
/*  55 */           throw new IllegalStateException(sig);
/*     */       } 
/*  57 */     } else if (sig.equals("Ljava/lang/String;")) {
/*  58 */       this.elementValueType = 115;
/*  59 */     } else if (annoFieldOfInterest.isEnum()) {
/*  60 */       this.elementValueType = 101;
/*     */     } else {
/*  62 */       throw new IllegalStateException(sig);
/*     */     } 
/*  64 */     this.annoFieldOfInterest = annoFieldOfInterest;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendLoadAndConvert(InstructionList il, InstructionFactory fact, ResolvedType toType) {
/*  70 */     if (this.annoAccessor.getKind() != Shadow.MethodExecution) {
/*     */       return;
/*     */     }
/*  73 */     String annotationOfInterestSignature = this.annoAccessor.getType().getSignature();
/*     */     
/*  75 */     Member holder = this.annoAccessor.getMember();
/*  76 */     AnnotationAJ[] annos = holder.getAnnotations();
/*  77 */     for (AnnotationAJ anno : annos) {
/*  78 */       AnnotationGen annotation = ((BcelAnnotation)anno).getBcelAnnotation();
/*  79 */       boolean foundValueInAnnotationUsage = false;
/*  80 */       if (annotation.getTypeSignature().equals(annotationOfInterestSignature)) {
/*     */         
/*  82 */         ResolvedMember[] annotationFields = toType.getWorld().resolve(UnresolvedType.forSignature(annotation.getTypeSignature())).getDeclaredMethods();
/*     */ 
/*     */         
/*  85 */         int countOfType = 0;
/*  86 */         for (ResolvedMember annotationField : annotationFields) {
/*  87 */           if (annotationField.getType().equals(this.annoFieldOfInterest)) {
/*  88 */             countOfType++;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/*  93 */         List<NameValuePair> nvps = annotation.getValues();
/*  94 */         for (NameValuePair nvp : nvps) {
/*     */           
/*  96 */           if (countOfType > 1 && 
/*  97 */             !nvp.getNameString().equals(this.name)) {
/*     */             continue;
/*     */           }
/*     */           
/* 101 */           ElementValue o = nvp.getValue();
/* 102 */           if (o.getElementValueType() != this.elementValueType) {
/*     */             continue;
/*     */           }
/* 105 */           if (o instanceof EnumElementValue) {
/* 106 */             EnumElementValue v = (EnumElementValue)o;
/* 107 */             String s = v.getEnumTypeString();
/* 108 */             ResolvedType rt = toType.getWorld().resolve(UnresolvedType.forSignature(s));
/* 109 */             if (rt.equals(toType)) {
/* 110 */               il.append((Instruction)fact.createGetStatic(rt.getName(), v.getEnumValueString(), Type.getType(rt.getSignature())));
/* 111 */               foundValueInAnnotationUsage = true;
/*     */             } 
/* 113 */           } else if (o instanceof SimpleElementValue) {
/* 114 */             SimpleElementValue v = (SimpleElementValue)o;
/* 115 */             switch (v.getElementValueType()) {
/*     */               case 73:
/* 117 */                 il.append(fact.createConstant(Integer.valueOf(v.getValueInt())));
/* 118 */                 foundValueInAnnotationUsage = true;
/*     */                 break;
/*     */               case 115:
/* 121 */                 il.append(fact.createConstant(v.getValueString()));
/* 122 */                 foundValueInAnnotationUsage = true;
/*     */                 break;
/*     */               default:
/* 125 */                 throw new IllegalStateException("NYI: Unsupported annotation value binding for " + o);
/*     */             } 
/*     */           } 
/* 128 */           if (foundValueInAnnotationUsage) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 133 */         if (!foundValueInAnnotationUsage)
/* 134 */           for (ResolvedMember annotationField : annotationFields) {
/* 135 */             if (countOfType <= 1 || 
/* 136 */               annotationField.getName().equals(this.name))
/*     */             {
/*     */ 
/*     */               
/* 140 */               if (annotationField.getType().getSignature().equals(this.annoFieldOfInterest.getSignature())) {
/*     */ 
/*     */                 
/* 143 */                 if (annotationField.getType().getSignature().equals("I")) {
/* 144 */                   int ivalue = Integer.parseInt(annotationField.getAnnotationDefaultValue());
/* 145 */                   il.append(fact.createConstant(Integer.valueOf(ivalue)));
/* 146 */                   foundValueInAnnotationUsage = true; break;
/*     */                 } 
/* 148 */                 if (annotationField.getType().getSignature().equals("Ljava/lang/String;")) {
/* 149 */                   String svalue = annotationField.getAnnotationDefaultValue();
/* 150 */                   il.append(fact.createConstant(svalue));
/* 151 */                   foundValueInAnnotationUsage = true;
/*     */                   break;
/*     */                 } 
/* 154 */                 String dvalue = annotationField.getAnnotationDefaultValue();
/*     */                 
/* 156 */                 String typename = dvalue.substring(0, dvalue.lastIndexOf(';') + 1);
/* 157 */                 String field = dvalue.substring(dvalue.lastIndexOf(';') + 1);
/* 158 */                 ResolvedType rt = toType.getWorld().resolve(UnresolvedType.forSignature(typename));
/* 159 */                 il.append((Instruction)fact.createGetStatic(rt.getName(), field, Type.getType(rt.getSignature())));
/* 160 */                 foundValueInAnnotationUsage = true;
/*     */                 break;
/*     */               } 
/*     */             }
/*     */           }  
/*     */       } 
/* 166 */       if (foundValueInAnnotationUsage) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertLoad(InstructionList il, InstructionFactory fact) {
/* 176 */     if (this.annoAccessor.getKind() != Shadow.MethodExecution) {
/*     */       return;
/*     */     }
/* 179 */     appendLoadAndConvert(il, fact, this.annoFieldOfInterest);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 184 */     return super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\AnnotationAccessFieldVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */