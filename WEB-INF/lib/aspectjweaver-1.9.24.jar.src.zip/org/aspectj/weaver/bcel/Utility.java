/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.ClassParser;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ import org.aspectj.apache.bcel.classfile.Unknown;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ArrayElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.SimpleElementValue;
/*     */ import org.aspectj.apache.bcel.generic.ArrayType;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionByte;
/*     */ import org.aspectj.apache.bcel.generic.InstructionCP;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.InstructionSelect;
/*     */ import org.aspectj.apache.bcel.generic.InstructionShort;
/*     */ import org.aspectj.apache.bcel.generic.InstructionTargeter;
/*     */ import org.aspectj.apache.bcel.generic.LineNumberTag;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ import org.aspectj.apache.bcel.generic.ReferenceType;
/*     */ import org.aspectj.apache.bcel.generic.SwitchBuilder;
/*     */ import org.aspectj.apache.bcel.generic.TargetLostException;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.AnnotationAJ;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.ConstantPoolReader;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.Lint;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.Utils;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utility
/*     */ {
/*  67 */   private static final char PACKAGE_INITIAL_CHAR = "org.aspectj.weaver".charAt(0);
/*     */ 
/*     */   
/*     */   public static List<AjAttribute> readAjAttributes(String classname, Attribute[] as, ISourceContext context, World w, AjAttribute.WeaverVersionInfo version, ConstantPoolReader dataDecompressor) {
/*  71 */     List<AjAttribute> attributes = new ArrayList<>();
/*     */ 
/*     */     
/*  74 */     List<Unknown> forSecondPass = new ArrayList<>(); int i;
/*  75 */     for (i = as.length - 1; i >= 0; i--) {
/*  76 */       Attribute a = as[i];
/*  77 */       if (a instanceof Unknown) {
/*  78 */         Unknown u = (Unknown)a;
/*  79 */         String name = u.getName();
/*  80 */         if (name.charAt(0) == PACKAGE_INITIAL_CHAR && 
/*  81 */           name.startsWith("org.aspectj.weaver")) {
/*  82 */           if (name.endsWith("org.aspectj.weaver.WeaverVersion")) {
/*  83 */             version = (AjAttribute.WeaverVersionInfo)AjAttribute.read(version, name, u.getBytes(), context, w, dataDecompressor);
/*     */             
/*  85 */             if (version.getMajorVersion() > AjAttribute.WeaverVersionInfo.getCurrentWeaverMajorVersion()) {
/*  86 */               throw new BCException("Unable to continue, this version of AspectJ supports classes built with weaver version " + 
/*     */                   
/*  88 */                   AjAttribute.WeaverVersionInfo.toCurrentVersionString() + " but the class " + classname + " is version " + version
/*  89 */                   .toString() + ".  Please update your AspectJ.");
/*     */             }
/*     */           } 
/*  92 */           forSecondPass.add(u);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  99 */     for (i = forSecondPass.size() - 1; i >= 0; i--) {
/* 100 */       Unknown a = forSecondPass.get(i);
/* 101 */       String name = a.getName();
/* 102 */       AjAttribute attr = AjAttribute.read(version, name, a.getBytes(), context, w, dataDecompressor);
/* 103 */       if (attr != null) {
/* 104 */         attributes.add(attr);
/*     */       }
/*     */     } 
/* 107 */     return attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String beautifyLocation(ISourceLocation isl) {
/* 114 */     StringBuilder nice = new StringBuilder();
/* 115 */     if (isl == null || isl.getSourceFile() == null || isl.getSourceFile().getName().contains("no debug info available")) {
/* 116 */       nice.append("no debug info available");
/*     */     }
/*     */     else {
/*     */       
/* 120 */       int takeFrom = isl.getSourceFile().getPath().lastIndexOf('/');
/* 121 */       if (takeFrom == -1) {
/* 122 */         takeFrom = isl.getSourceFile().getPath().lastIndexOf('\\');
/*     */       }
/* 124 */       nice.append(isl.getSourceFile().getPath().substring(takeFrom + 1));
/* 125 */       if (isl.getLine() != 0) {
/* 126 */         nice.append(":").append(isl.getLine());
/*     */       }
/*     */     } 
/* 129 */     return nice.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Instruction createSuperInvoke(InstructionFactory fact, BcelWorld world, Member signature) {
/* 134 */     if (Modifier.isInterface(signature.getModifiers()))
/* 135 */       throw new RuntimeException("bad"); 
/* 136 */     if (Modifier.isPrivate(signature.getModifiers()) || signature.getName().equals("<init>"))
/* 137 */       throw new RuntimeException("unimplemented, possibly bad"); 
/* 138 */     if (Modifier.isStatic(signature.getModifiers())) {
/* 139 */       throw new RuntimeException("bad");
/*     */     }
/* 141 */     short kind = 183;
/*     */ 
/*     */     
/* 144 */     return (Instruction)fact.createInvoke(signature.getDeclaringType().getName(), signature.getName(), 
/* 145 */         BcelWorld.makeBcelType(signature.getReturnType()), BcelWorld.makeBcelTypes(signature.getParameterTypes()), kind);
/*     */   }
/*     */   public static Instruction createInvoke(InstructionFactory fact, BcelWorld world, Member signature) {
/*     */     short kind;
/*     */     ReferenceType referenceType;
/* 150 */     int signatureModifiers = signature.getModifiers();
/* 151 */     if (Modifier.isInterface(signatureModifiers)) {
/* 152 */       kind = 185;
/* 153 */     } else if (Modifier.isStatic(signatureModifiers)) {
/* 154 */       kind = 184;
/* 155 */     } else if (Modifier.isPrivate(signatureModifiers) || signature.getName().equals("<init>")) {
/* 156 */       kind = 183;
/*     */     } else {
/* 158 */       kind = 182;
/*     */     } 
/*     */     
/* 161 */     UnresolvedType targetType = signature.getDeclaringType();
/* 162 */     if (targetType.isParameterizedType()) {
/* 163 */       referenceType = targetType.resolve(world).getGenericType();
/*     */     }
/* 165 */     return (Instruction)fact.createInvoke(referenceType.getName(), signature.getName(), BcelWorld.makeBcelType(signature.getReturnType()), 
/* 166 */         BcelWorld.makeBcelTypes(signature.getParameterTypes()), kind);
/*     */   }
/*     */   
/*     */   public static Instruction createGet(InstructionFactory fact, Member signature) {
/*     */     short kind;
/* 171 */     if (Modifier.isStatic(signature.getModifiers())) {
/* 172 */       kind = 178;
/*     */     } else {
/* 174 */       kind = 180;
/*     */     } 
/*     */     
/* 177 */     return (Instruction)fact.createFieldAccess(signature.getDeclaringType().getName(), signature.getName(), 
/* 178 */         BcelWorld.makeBcelType(signature.getReturnType()), kind);
/*     */   }
/*     */   
/*     */   public static Instruction createSet(InstructionFactory fact, Member signature) {
/*     */     short kind;
/* 183 */     if (Modifier.isStatic(signature.getModifiers())) {
/* 184 */       kind = 179;
/*     */     } else {
/* 186 */       kind = 181;
/*     */     } 
/*     */     
/* 189 */     return (Instruction)fact.createFieldAccess(signature.getDeclaringType().getName(), signature.getName(), 
/* 190 */         BcelWorld.makeBcelType(signature.getReturnType()), kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Instruction createInstanceof(InstructionFactory fact, ReferenceType t) {
/* 195 */     int cpoolEntry = (t instanceof ArrayType) ? fact.getConstantPool().addArrayClass((ArrayType)t) : fact.getConstantPool().addClass((ObjectType)t);
/* 196 */     return (Instruction)new InstructionCP((short)193, cpoolEntry);
/*     */   }
/*     */   
/*     */   public static Instruction createInvoke(InstructionFactory fact, LazyMethodGen m) {
/*     */     short kind;
/* 201 */     if (m.getEnclosingClass().isInterface()) {
/* 202 */       if (m.isStatic()) {
/*     */         
/* 204 */         kind = 184;
/*     */       } else {
/* 206 */         kind = 185;
/*     */       } 
/* 208 */     } else if (m.isStatic()) {
/* 209 */       kind = 184;
/* 210 */     } else if (m.isPrivate() || m.getName().equals("<init>")) {
/* 211 */       kind = 183;
/*     */     } else {
/* 213 */       kind = 182;
/*     */     } 
/*     */     
/* 216 */     return (Instruction)fact.createInvoke(m.getClassName(), m.getName(), m.getReturnType(), m.getArgumentTypes(), kind, m.getEnclosingClass().isInterface());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createInvoke(InstructionFactory fact, short kind, Member member) {
/* 228 */     return (Instruction)fact.createInvoke(member.getDeclaringType().getName(), member.getName(), 
/* 229 */         BcelWorld.makeBcelType(member.getReturnType()), BcelWorld.makeBcelTypes(member.getParameterTypes()), kind);
/*     */   }
/*     */   
/* 232 */   private static String[] argNames = new String[] { "arg0", "arg1", "arg2", "arg3", "arg4" };
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] makeArgNames(int n) {
/* 237 */     String[] ret = new String[n];
/* 238 */     for (int i = 0; i < n; i++) {
/* 239 */       if (i < 5) {
/* 240 */         ret[i] = argNames[i];
/*     */       } else {
/* 242 */         ret[i] = "arg" + i;
/*     */       } 
/*     */     } 
/* 245 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 250 */   private static Hashtable<String, String> validBoxing = new Hashtable<>();
/*     */   
/*     */   static {
/* 253 */     validBoxing.put("Ljava/lang/Byte;B", "byteObject");
/* 254 */     validBoxing.put("Ljava/lang/Character;C", "charObject");
/* 255 */     validBoxing.put("Ljava/lang/Double;D", "doubleObject");
/* 256 */     validBoxing.put("Ljava/lang/Float;F", "floatObject");
/* 257 */     validBoxing.put("Ljava/lang/Integer;I", "intObject");
/* 258 */     validBoxing.put("Ljava/lang/Long;J", "longObject");
/* 259 */     validBoxing.put("Ljava/lang/Short;S", "shortObject");
/* 260 */     validBoxing.put("Ljava/lang/Boolean;Z", "booleanObject");
/* 261 */     validBoxing.put("BLjava/lang/Byte;", "byteValue");
/* 262 */     validBoxing.put("CLjava/lang/Character;", "charValue");
/* 263 */     validBoxing.put("DLjava/lang/Double;", "doubleValue");
/* 264 */     validBoxing.put("FLjava/lang/Float;", "floatValue");
/* 265 */     validBoxing.put("ILjava/lang/Integer;", "intValue");
/* 266 */     validBoxing.put("JLjava/lang/Long;", "longValue");
/* 267 */     validBoxing.put("SLjava/lang/Short;", "shortValue");
/* 268 */     validBoxing.put("ZLjava/lang/Boolean;", "booleanValue");
/*     */   }
/*     */   
/*     */   public static void appendConversion(InstructionList il, InstructionFactory fact, ResolvedType fromType, ResolvedType toType) {
/* 272 */     if (!toType.isConvertableFrom(fromType) && !fromType.isConvertableFrom(toType)) {
/* 273 */       throw new BCException("can't convert from " + fromType + " to " + toType);
/*     */     }
/*     */     
/* 276 */     World w = toType.getWorld();
/* 277 */     if (w == null) {
/* 278 */       throw new IllegalStateException("Debug349636: Unexpectedly found world null for type " + toType.getName());
/*     */     }
/*     */     
/* 281 */     if (!w.isInJava5Mode()) {
/* 282 */       if (toType.needsNoConversionFrom(fromType)) {
/*     */         return;
/*     */       }
/*     */     }
/* 286 */     else if (toType.needsNoConversionFrom(fromType) && (toType.isPrimitiveType() ^ fromType.isPrimitiveType()) == 0) {
/*     */       return;
/*     */     } 
/*     */     
/* 290 */     if (toType.equals(UnresolvedType.VOID))
/*     */     
/* 292 */     { il.append(InstructionFactory.createPop(fromType.getSize())); }
/* 293 */     else { if (fromType.equals(UnresolvedType.VOID)) {
/*     */         
/* 295 */         il.append(InstructionFactory.createNull((Type)Type.OBJECT)); return;
/*     */       } 
/* 297 */       if (fromType.equals(UnresolvedType.OBJECT)) {
/* 298 */         Type to = BcelWorld.makeBcelType((UnresolvedType)toType);
/* 299 */         if (toType.isPrimitiveType()) {
/* 300 */           String name = toType.toString() + "Value";
/* 301 */           il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, to, new Type[] { (Type)Type.OBJECT }, (short)184));
/*     */         } else {
/*     */           
/* 304 */           il.append(fact.createCheckCast((ReferenceType)to));
/*     */         } 
/* 306 */       } else if (toType.equals(UnresolvedType.OBJECT)) {
/*     */         
/* 308 */         Type from = BcelWorld.makeBcelType((UnresolvedType)fromType);
/* 309 */         String name = fromType.toString() + "Object";
/* 310 */         il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, (Type)Type.OBJECT, new Type[] { from }, (short)184));
/*     */       }
/* 312 */       else if (toType.getWorld().isInJava5Mode() && validBoxing.get(toType.getSignature() + fromType.getSignature()) != null) {
/*     */ 
/*     */         
/* 315 */         Type from = BcelWorld.makeBcelType((UnresolvedType)fromType);
/* 316 */         Type to = BcelWorld.makeBcelType((UnresolvedType)toType);
/* 317 */         String name = validBoxing.get(toType.getSignature() + fromType.getSignature());
/* 318 */         if (toType.isPrimitiveType()) {
/* 319 */           il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, to, new Type[] { (Type)Type.OBJECT }, (short)184));
/*     */         } else {
/*     */           
/* 322 */           il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, (Type)Type.OBJECT, new Type[] { from }, (short)184));
/*     */           
/* 324 */           il.append(fact.createCheckCast((ReferenceType)to));
/*     */         } 
/* 326 */       } else if (fromType.isPrimitiveType()) {
/*     */         
/* 328 */         Type from = BcelWorld.makeBcelType((UnresolvedType)fromType);
/* 329 */         Type to = BcelWorld.makeBcelType((UnresolvedType)toType);
/*     */         try {
/* 331 */           Instruction i = fact.createCast(from, to);
/* 332 */           if (i != null) {
/* 333 */             il.append(i);
/*     */           } else {
/* 335 */             il.append(fact.createCast(from, (Type)Type.INT));
/* 336 */             il.append(fact.createCast((Type)Type.INT, to));
/*     */           } 
/* 338 */         } catch (RuntimeException e) {
/* 339 */           il.append(fact.createCast(from, (Type)Type.INT));
/* 340 */           il.append(fact.createCast((Type)Type.INT, to));
/*     */         } 
/*     */       } else {
/* 343 */         Type to = BcelWorld.makeBcelType((UnresolvedType)toType);
/*     */         
/* 345 */         il.append(fact.createCheckCast((ReferenceType)to));
/*     */       }  }
/*     */   
/*     */   }
/*     */   public static InstructionList createConversion(InstructionFactory factory, Type fromType, Type toType) {
/* 350 */     return createConversion(factory, fromType, toType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static InstructionList createConversion(InstructionFactory fact, Type fromType, Type toType, boolean allowAutoboxing) {
/* 356 */     InstructionList il = new InstructionList();
/*     */ 
/*     */     
/* 359 */     if ((fromType.equals(Type.BYTE) || fromType.equals(Type.CHAR) || fromType.equals(Type.SHORT)) && toType.equals(Type.INT)) {
/* 360 */       return il;
/*     */     }
/*     */     
/* 363 */     if (fromType.equals(toType)) {
/* 364 */       return il;
/*     */     }
/* 366 */     if (toType.equals(Type.VOID)) {
/* 367 */       il.append(InstructionFactory.createPop(fromType.getSize()));
/* 368 */       return il;
/*     */     } 
/*     */     
/* 371 */     if (fromType.equals(Type.VOID)) {
/* 372 */       if (toType instanceof org.aspectj.apache.bcel.generic.BasicType) {
/* 373 */         throw new BCException("attempting to cast from void to basic type");
/*     */       }
/* 375 */       il.append(InstructionFactory.createNull((Type)Type.OBJECT));
/* 376 */       return il;
/*     */     } 
/*     */     
/* 379 */     if (fromType.equals(Type.OBJECT) && 
/* 380 */       toType instanceof org.aspectj.apache.bcel.generic.BasicType) {
/* 381 */       String name = toType.toString() + "Value";
/* 382 */       il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, toType, new Type[] { (Type)Type.OBJECT }, (short)184));
/*     */       
/* 384 */       return il;
/*     */     } 
/*     */ 
/*     */     
/* 388 */     if (toType.equals(Type.OBJECT)) {
/* 389 */       if (fromType instanceof org.aspectj.apache.bcel.generic.BasicType) {
/* 390 */         String name = fromType.toString() + "Object";
/* 391 */         il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, (Type)Type.OBJECT, new Type[] { fromType }, (short)184));
/*     */         
/* 393 */         return il;
/* 394 */       }  if (fromType instanceof ReferenceType) {
/* 395 */         return il;
/*     */       }
/* 397 */       throw new RuntimeException();
/*     */     } 
/*     */ 
/*     */     
/* 401 */     if (fromType instanceof ReferenceType && ((ReferenceType)fromType).isAssignmentCompatibleWith(toType)) {
/* 402 */       return il;
/*     */     }
/*     */     
/* 405 */     if (allowAutoboxing) {
/* 406 */       if (toType instanceof org.aspectj.apache.bcel.generic.BasicType && fromType instanceof ReferenceType) {
/*     */         
/* 408 */         String name = toType.toString() + "Value";
/* 409 */         il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, toType, new Type[] { (Type)Type.OBJECT }, (short)184));
/*     */         
/* 411 */         return il;
/*     */       } 
/*     */       
/* 414 */       if (fromType instanceof org.aspectj.apache.bcel.generic.BasicType && toType instanceof ReferenceType) {
/*     */         
/* 416 */         String name = fromType.toString() + "Object";
/* 417 */         il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.Conversions", name, (Type)Type.OBJECT, new Type[] { fromType }, (short)184));
/*     */         
/* 419 */         il.append(fact.createCast((Type)Type.OBJECT, toType));
/* 420 */         return il;
/*     */       } 
/*     */     } 
/*     */     
/* 424 */     il.append(fact.createCast(fromType, toType));
/* 425 */     return il;
/*     */   }
/*     */   public static Instruction createConstant(InstructionFactory fact, int value) {
/*     */     Instruction inst;
/*     */     InstructionCP instructionCP;
/* 430 */     switch (value)
/*     */     { case -1:
/* 432 */         inst = InstructionConstants.ICONST_M1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 463 */         return inst;case 0: inst = InstructionConstants.ICONST_0; return inst;case 1: inst = InstructionConstants.ICONST_1; return inst;case 2: inst = InstructionConstants.ICONST_2; return inst;case 3: inst = InstructionConstants.ICONST_3; return inst;case 4: inst = InstructionConstants.ICONST_4; return inst;case 5: inst = InstructionConstants.ICONST_5; return inst; }  if (value <= 127 && value >= -128) { InstructionByte instructionByte = new InstructionByte((short)16, (byte)value); } else if (value <= 32767 && value >= -32768) { InstructionShort instructionShort = new InstructionShort((short)17, (short)value); } else { int ii = fact.getClassGen().getConstantPool().addInteger(value); instructionCP = new InstructionCP((value <= 255) ? 18 : 19, ii); }  return (Instruction)instructionCP;
/*     */   }
/*     */ 
/*     */   
/* 467 */   public static int testingParseCounter = 0;
/*     */   
/*     */   public static JavaClass makeJavaClass(String filename, byte[] bytes) {
/*     */     try {
/* 471 */       testingParseCounter++;
/* 472 */       ClassParser parser = new ClassParser(new ByteArrayInputStream(bytes), filename);
/* 473 */       return parser.parse();
/* 474 */     } catch (IOException e) {
/* 475 */       throw new BCException("malformed class file");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void replaceInstruction(InstructionHandle ih, InstructionList replacementInstructions, LazyMethodGen enclosingMethod) {
/* 488 */     InstructionList il = enclosingMethod.getBody();
/* 489 */     InstructionHandle fresh = il.append(ih, replacementInstructions);
/* 490 */     deleteInstruction(ih, fresh, enclosingMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deleteInstruction(InstructionHandle ih, LazyMethodGen enclosingMethod) {
/* 501 */     deleteInstruction(ih, ih.getNext(), enclosingMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deleteInstruction(InstructionHandle ih, InstructionHandle retargetTo, LazyMethodGen enclosingMethod) {
/* 512 */     InstructionList il = enclosingMethod.getBody();
/* 513 */     for (InstructionTargeter targeter : ih.getTargetersCopy()) {
/* 514 */       targeter.updateTarget(ih, retargetTo);
/*     */     }
/* 516 */     ih.removeAllTargeters();
/*     */     try {
/* 518 */       il.delete(ih);
/* 519 */     } catch (TargetLostException e) {
/* 520 */       throw new BCException("this really can't happen");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction copyInstruction(Instruction i) {
/* 539 */     if (i instanceof InstructionSelect) {
/* 540 */       InstructionSelect freshSelect = (InstructionSelect)i;
/*     */ 
/*     */       
/* 543 */       InstructionHandle[] targets = new InstructionHandle[(freshSelect.getTargets()).length];
/* 544 */       for (int ii = 0; ii < targets.length; ii++) {
/* 545 */         targets[ii] = freshSelect.getTargets()[ii];
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 550 */       return (Instruction)(new SwitchBuilder(freshSelect.getMatchs(), targets, freshSelect.getTarget())).getInstruction();
/*     */     } 
/* 552 */     return i.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getSourceLine(InstructionHandle ih) {
/* 575 */     int lookahead = 0;
/*     */ 
/*     */     
/* 578 */     while (lookahead++ < 100) {
/* 579 */       if (ih == null) {
/* 580 */         return -1;
/*     */       }
/* 582 */       for (InstructionTargeter t : ih.getTargeters()) {
/* 583 */         if (t instanceof LineNumberTag) {
/* 584 */           return ((LineNumberTag)t).getLineNumber();
/*     */         }
/*     */       } 
/*     */       
/* 588 */       ih = ih.getPrev();
/*     */     } 
/*     */     
/* 591 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setSourceLine(InstructionHandle ih, int lineNumber) {
/* 603 */     ih.addTargeter((InstructionTargeter)new LineNumberTag(lineNumber));
/*     */   }
/*     */   
/*     */   public static int makePublic(int i) {
/* 607 */     return i & 0xFFFFFFF9 | 0x1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static BcelVar[] pushAndReturnArrayOfVars(ResolvedType[] proceedParamTypes, InstructionList il, InstructionFactory fact, LazyMethodGen enclosingMethod) {
/* 612 */     int len = proceedParamTypes.length;
/* 613 */     BcelVar[] ret = new BcelVar[len];
/*     */     
/* 615 */     for (int i = len - 1; i >= 0; i--) {
/* 616 */       ResolvedType typeX = proceedParamTypes[i];
/* 617 */       Type type = BcelWorld.makeBcelType((UnresolvedType)typeX);
/* 618 */       int local = enclosingMethod.allocateLocal(type);
/*     */       
/* 620 */       il.append((Instruction)InstructionFactory.createStore(type, local));
/* 621 */       ret[i] = new BcelVar(typeX, local);
/*     */     } 
/* 623 */     return ret;
/*     */   }
/*     */   
/*     */   public static boolean isConstantPushInstruction(Instruction i) {
/* 627 */     long ii = Constants.instFlags[i.opcode];
/* 628 */     return ((ii & 0x1L) != 0L && (ii & 0x2L) != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSuppressing(Member member, String lintkey) {
/* 635 */     boolean isSuppressing = Utils.isSuppressing(member.getAnnotations(), lintkey);
/* 636 */     if (isSuppressing) {
/* 637 */       return true;
/*     */     }
/* 639 */     UnresolvedType type = member.getDeclaringType();
/* 640 */     if (type instanceof ResolvedType) {
/* 641 */       return Utils.isSuppressing(((ResolvedType)type).getAnnotations(), lintkey);
/*     */     }
/* 643 */     return false;
/*     */   }
/*     */   
/*     */   public static List<Lint.Kind> getSuppressedWarnings(AnnotationAJ[] anns, Lint lint) {
/* 647 */     if (anns == null) {
/* 648 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 651 */     List<Lint.Kind> suppressedWarnings = new ArrayList<>();
/* 652 */     boolean found = false;
/* 653 */     for (int i = 0; !found && i < anns.length; i++) {
/*     */       
/* 655 */       if (UnresolvedType.SUPPRESS_AJ_WARNINGS.getSignature().equals(((BcelAnnotation)anns[i])
/* 656 */           .getBcelAnnotation().getTypeSignature())) {
/* 657 */         found = true;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 662 */         List<NameValuePair> vals = ((BcelAnnotation)anns[i]).getBcelAnnotation().getValues();
/* 663 */         if (vals == null || vals.isEmpty()) {
/* 664 */           suppressedWarnings.addAll(lint.allKinds());
/*     */         } else {
/*     */           
/* 667 */           ArrayElementValue array = (ArrayElementValue)((NameValuePair)vals.get(0)).getValue();
/* 668 */           ElementValue[] values = array.getElementValuesArray();
/* 669 */           for (ElementValue elementValue : values) {
/*     */             
/* 671 */             SimpleElementValue value = (SimpleElementValue)elementValue;
/* 672 */             Lint.Kind lintKind = lint.getLintKind(value.getValueString());
/* 673 */             if (lintKind != null) {
/* 674 */               suppressedWarnings.add(lintKind);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 680 */     return suppressedWarnings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Attribute bcelAttribute(AjAttribute a, ConstantPool pool) {
/* 710 */     int nameIndex = pool.addUtf8(a.getNameString());
/* 711 */     byte[] bytes = a.getBytes(new BcelConstantPoolWriter(pool));
/* 712 */     int length = bytes.length;
/*     */     
/* 714 */     return (Attribute)new Unknown(nameIndex, length, bytes, pool);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\Utility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */