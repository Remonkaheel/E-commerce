/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ import org.aspectj.apache.bcel.generic.ReferenceType;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.MemberImpl;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.ast.And;
/*     */ import org.aspectj.weaver.ast.Call;
/*     */ import org.aspectj.weaver.ast.CallExpr;
/*     */ import org.aspectj.weaver.ast.Expr;
/*     */ import org.aspectj.weaver.ast.FieldGet;
/*     */ import org.aspectj.weaver.ast.FieldGetCall;
/*     */ import org.aspectj.weaver.ast.HasAnnotation;
/*     */ import org.aspectj.weaver.ast.IExprVisitor;
/*     */ import org.aspectj.weaver.ast.ITestVisitor;
/*     */ import org.aspectj.weaver.ast.Instanceof;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Not;
/*     */ import org.aspectj.weaver.ast.Or;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ import org.aspectj.weaver.internal.tools.MatchingContextBasedTest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BcelRenderer
/*     */   implements ITestVisitor, IExprVisitor
/*     */ {
/*     */   private InstructionList instructions;
/*     */   private InstructionFactory fact;
/*     */   private BcelWorld world;
/*     */   InstructionHandle sk;
/*     */   InstructionHandle fk;
/*  50 */   InstructionHandle next = null;
/*     */ 
/*     */   
/*     */   private BcelRenderer(InstructionFactory fact, BcelWorld world) {
/*  54 */     this.fact = fact;
/*  55 */     this.world = world;
/*  56 */     this.instructions = new InstructionList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static InstructionList renderExpr(InstructionFactory fact, BcelWorld world, Expr e) {
/*  62 */     BcelRenderer renderer = new BcelRenderer(fact, world);
/*  63 */     e.accept(renderer);
/*  64 */     return renderer.instructions;
/*     */   }
/*     */   
/*     */   public static InstructionList renderExpr(InstructionFactory fact, BcelWorld world, Expr e, Type desiredType) {
/*  68 */     BcelRenderer renderer = new BcelRenderer(fact, world);
/*  69 */     e.accept(renderer);
/*  70 */     InstructionList il = renderer.instructions;
/*  71 */     il.append(Utility.createConversion(fact, BcelWorld.makeBcelType((UnresolvedType)e.getType()), desiredType));
/*  72 */     return il;
/*     */   }
/*     */   
/*     */   public static InstructionList renderExprs(InstructionFactory fact, BcelWorld world, Expr[] es) {
/*  76 */     BcelRenderer renderer = new BcelRenderer(fact, world);
/*  77 */     for (int i = es.length - 1; i >= 0; i--) {
/*  78 */       es[i].accept(renderer);
/*     */     }
/*  80 */     return renderer.instructions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InstructionList renderTest(InstructionFactory fact, BcelWorld world, Test e, InstructionHandle sk, InstructionHandle fk, InstructionHandle next) {
/*  99 */     BcelRenderer renderer = new BcelRenderer(fact, world);
/* 100 */     renderer.recur(e, sk, fk, next);
/* 101 */     return renderer.instructions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void recur(Test e, InstructionHandle sk, InstructionHandle fk, InstructionHandle next) {
/* 107 */     this.sk = sk;
/* 108 */     this.fk = fk;
/* 109 */     this.next = next;
/* 110 */     e.accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(And e) {
/* 116 */     InstructionHandle savedFk = this.fk;
/* 117 */     recur(e.getRight(), this.sk, this.fk, this.next);
/* 118 */     InstructionHandle ning = this.instructions.getStart();
/* 119 */     recur(e.getLeft(), ning, savedFk, ning);
/*     */   }
/*     */   
/*     */   public void visit(Or e) {
/* 123 */     InstructionHandle savedSk = this.sk;
/* 124 */     recur(e.getRight(), this.sk, this.fk, this.next);
/* 125 */     recur(e.getLeft(), savedSk, this.instructions.getStart(), this.instructions.getStart());
/*     */   }
/*     */   
/*     */   public void visit(Not e) {
/* 129 */     recur(e.getBody(), this.fk, this.sk, this.next);
/*     */   }
/*     */   
/*     */   public void visit(Instanceof i) {
/* 133 */     this.instructions.insert(createJumpBasedOnBooleanOnStack());
/* 134 */     this.instructions.insert(Utility.createInstanceof(this.fact, (ReferenceType)BcelWorld.makeBcelType(i.getType())));
/* 135 */     i.getVar().accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(HasAnnotation hasAnnotation) {
/* 149 */     InstructionList il = new InstructionList();
/*     */ 
/*     */     
/* 152 */     il.append(InstructionFactory.createBranchInstruction((short)198, this.fk));
/*     */ 
/*     */     
/* 155 */     il.append(((BcelVar)hasAnnotation.getVar()).createLoad(this.fact));
/*     */     
/* 157 */     MemberImpl memberImpl1 = MemberImpl.method(UnresolvedType.OBJECT, 0, UnresolvedType.JL_CLASS, "getClass", UnresolvedType.NONE);
/* 158 */     il.append(Utility.createInvoke(this.fact, this.world, (Member)memberImpl1));
/*     */     
/* 160 */     il.append(this.fact.createConstant(new ObjectType(hasAnnotation.getAnnotationType().getName())));
/*     */ 
/*     */     
/* 163 */     MemberImpl memberImpl2 = MemberImpl.method(UnresolvedType.JL_CLASS, 0, UnresolvedType.BOOLEAN, "isAnnotationPresent", new UnresolvedType[] { UnresolvedType.JL_CLASS });
/*     */     
/* 165 */     il.append(Utility.createInvoke(this.fact, this.world, (Member)memberImpl2));
/* 166 */     il.append(createJumpBasedOnBooleanOnStack());
/* 167 */     this.instructions.insert(il);
/* 168 */     hasAnnotation.getVar().accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(MatchingContextBasedTest matchingContextTest) {
/* 177 */     throw new UnsupportedOperationException("matching context extension not supported in bytecode weaving");
/*     */   }
/*     */   
/*     */   private InstructionList createJumpBasedOnBooleanOnStack() {
/* 181 */     InstructionList il = new InstructionList();
/* 182 */     if (this.sk == this.fk) {
/*     */       
/* 184 */       if (this.sk != this.next) {
/* 185 */         il.insert(InstructionFactory.createBranchInstruction((short)167, this.sk));
/*     */       }
/* 187 */       return il;
/*     */     } 
/*     */     
/* 190 */     if (this.fk == this.next) {
/* 191 */       il.insert(InstructionFactory.createBranchInstruction((short)154, this.sk));
/* 192 */     } else if (this.sk == this.next) {
/* 193 */       il.insert(InstructionFactory.createBranchInstruction((short)153, this.fk));
/*     */     } else {
/* 195 */       il.insert(InstructionFactory.createBranchInstruction((short)167, this.sk));
/* 196 */       il.insert(InstructionFactory.createBranchInstruction((short)153, this.fk));
/*     */     } 
/* 198 */     return il;
/*     */   }
/*     */   
/*     */   public void visit(Literal literal) {
/* 202 */     if (literal == Literal.FALSE) {
/* 203 */       throw new BCException("visiting a false expression");
/*     */     }
/*     */   }
/*     */   
/*     */   public void visit(Call call) {
/* 208 */     Member method = call.getMethod();
/*     */     
/* 210 */     Expr[] args = call.getArgs();
/* 211 */     InstructionList callIl = new InstructionList();
/* 212 */     for (int i = 0, len = args.length; i < len; i++) {
/*     */       
/* 214 */       Type desiredType = BcelWorld.makeBcelType(method.getParameterTypes()[i]);
/* 215 */       Expr arg = args[i];
/*     */       
/* 217 */       if (arg == null) {
/* 218 */         InstructionList iList = new InstructionList();
/* 219 */         iList.append(InstructionFactory.createNull(desiredType));
/* 220 */         callIl.append(iList);
/*     */       } else {
/* 222 */         callIl.append(renderExpr(this.fact, this.world, arg, desiredType));
/*     */       } 
/*     */     } 
/*     */     
/* 226 */     callIl.append(Utility.createInvoke(this.fact, this.world, method));
/* 227 */     callIl.append(createJumpBasedOnBooleanOnStack());
/* 228 */     this.instructions.insert(callIl);
/*     */   }
/*     */   
/*     */   public void visit(FieldGetCall fieldGetCall) {
/* 232 */     Member field = fieldGetCall.getField();
/* 233 */     Member method = fieldGetCall.getMethod();
/* 234 */     InstructionList il = new InstructionList();
/* 235 */     il.append(Utility.createGet(this.fact, field));
/*     */     
/* 237 */     Expr[] args = fieldGetCall.getArgs();
/*     */     
/* 239 */     il.append(renderExprs(this.fact, this.world, args));
/*     */     
/* 241 */     il.append(Utility.createInvoke(this.fact, this.world, method));
/* 242 */     il.append(createJumpBasedOnBooleanOnStack());
/* 243 */     this.instructions.insert(il);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Var var) {
/* 249 */     BcelVar bvar = (BcelVar)var;
/* 250 */     bvar.insertLoad(this.instructions, this.fact);
/*     */   }
/*     */   
/*     */   public void visit(FieldGet fieldGet) {
/* 254 */     Member field = fieldGet.getField();
/*     */     
/* 256 */     this.instructions.insert(Utility.createGet(this.fact, field));
/*     */   }
/*     */   
/*     */   public void visit(CallExpr call) {
/* 260 */     Member method = call.getMethod();
/*     */     
/* 262 */     Expr[] args = call.getArgs();
/* 263 */     InstructionList callIl = renderExprs(this.fact, this.world, args);
/* 264 */     callIl.append(Utility.createInvoke(this.fact, this.world, method));
/* 265 */     this.instructions.insert(callIl);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */