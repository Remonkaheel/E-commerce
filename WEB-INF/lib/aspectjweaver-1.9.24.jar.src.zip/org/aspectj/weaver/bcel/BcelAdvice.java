/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.aspectj.apache.bcel.classfile.LocalVariable;
/*     */ import org.aspectj.apache.bcel.classfile.LocalVariableTable;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.InstructionTargeter;
/*     */ import org.aspectj.apache.bcel.generic.LineNumberTag;
/*     */ import org.aspectj.apache.bcel.generic.LocalVariableTag;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.Message;
/*     */ import org.aspectj.weaver.Advice;
/*     */ import org.aspectj.weaver.AdviceKind;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.IEclipseSourceContext;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.Lint;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedMemberImpl;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.ShadowMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.patterns.ExactTypePattern;
/*     */ import org.aspectj.weaver.patterns.ExposedState;
/*     */ import org.aspectj.weaver.patterns.PatternNodeVisitor;
/*     */ import org.aspectj.weaver.patterns.PerClause;
/*     */ import org.aspectj.weaver.patterns.Pointcut;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BcelAdvice
/*     */   extends Advice
/*     */ {
/*     */   private Test runtimeTest;
/*     */   private ExposedState exposedState;
/*  73 */   private int containsInvokedynamic = 0;
/*     */   private Collection<ResolvedType> thrownExceptions;
/*     */   
/*  76 */   public BcelAdvice(AjAttribute.AdviceAttribute attribute, Pointcut pointcut, Member adviceSignature, ResolvedType concreteAspect) { super(attribute, pointcut, simplify(attribute.getKind(), adviceSignature));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 450 */     this.thrownExceptions = null; this.concreteAspect = concreteAspect; }
/*     */   public boolean bindsProceedingJoinPoint() { UnresolvedType[] parameterTypes = this.signature.getParameterTypes(); for (UnresolvedType parameterType : parameterTypes) { if (parameterType.equals(UnresolvedType.PROCEEDING_JOINPOINT)) return true;  }  return false; }
/*     */   private static Member simplify(AdviceKind kind, Member adviceSignature) { if (adviceSignature != null) { UnresolvedType adviceDeclaringType = adviceSignature.getDeclaringType(); if ((kind != AdviceKind.Around || (adviceDeclaringType instanceof ResolvedType && ((ResolvedType)adviceDeclaringType).getWorld().isXnoInline())) && adviceSignature instanceof BcelMethod) { BcelMethod bm = (BcelMethod)adviceSignature; if (bm.getMethod() != null && bm.getMethod().getAnnotations() != null) return adviceSignature;  ResolvedMemberImpl simplermember = new ResolvedMemberImpl(bm.getKind(), bm.getDeclaringType(), bm.getModifiers(), bm.getReturnType(), bm.getName(), bm.getParameterTypes()); simplermember.setParameterNames(bm.getParameterNames()); return (Member)simplermember; }  }  return adviceSignature; }
/*     */   public ShadowMunger concretize(ResolvedType fromType, World world, PerClause clause) { if (!world.areAllLintIgnored()) suppressLintWarnings(world);  ShadowMunger ret = super.concretize(fromType, world, clause); if (!world.areAllLintIgnored()) clearLintSuppressions(world, this.suppressedLintKinds);  IfFinder ifinder = new IfFinder(); ret.getPointcut().accept((PatternNodeVisitor)ifinder, null); boolean hasGuardTest = (ifinder.hasIf && getKind() != AdviceKind.Around); boolean isAround = (getKind() == AdviceKind.Around); if ((getExtraParameterFlags() & 0x2) != 0 && !isAround && !hasGuardTest && (world.getLint()).noGuardForLazyTjp.isEnabled()) (world.getLint()).noGuardForLazyTjp.signal("", getSourceLocation());  return ret; }
/* 454 */   public ShadowMunger parameterizeWith(ResolvedType declaringType, Map<String, UnresolvedType> typeVariableMap) { ResolvedMemberImpl resolvedMemberImpl; Pointcut pc = getPointcut().parameterizeWith(typeVariableMap, declaringType.getWorld()); BcelAdvice ret = null; Member adviceSignature = this.signature; if (this.signature instanceof ResolvedMember && this.signature.getDeclaringType().isGenericType()) resolvedMemberImpl = ((ResolvedMember)this.signature).parameterizedWith(declaringType.getTypeParameters(), declaringType, declaringType.isParameterizedType());  ret = new BcelAdvice(this.attribute, pc, (Member)resolvedMemberImpl, this.concreteAspect); return (ShadowMunger)ret; } public boolean match(Shadow shadow, World world) { if (world.areAllLintIgnored()) return super.match(shadow, world);  suppressLintWarnings(world); boolean ret = super.match(shadow, world); clearLintSuppressions(world, this.suppressedLintKinds); return ret; } public void specializeOn(Shadow shadow) { if (getKind() == AdviceKind.Around) ((BcelShadow)shadow).initializeForAroundClosure();  if (getKind() == null) { this.exposedState = new ExposedState(0); return; }  if (getKind().isPerEntry()) { this.exposedState = new ExposedState(0); } else if (getKind().isCflow()) { this.exposedState = new ExposedState(this.nFreeVars); } else if (getSignature() != null) { this.exposedState = new ExposedState(getSignature()); } else { this.exposedState = new ExposedState(0); return; }  World world = shadow.getIWorld(); if (!world.areAllLintIgnored()) suppressLintWarnings(world);  this.exposedState.setConcreteAspect(this.concreteAspect); this.runtimeTest = getPointcut().findResidue(shadow, this.exposedState); if (!world.areAllLintIgnored()) clearLintSuppressions(world, this.suppressedLintKinds);  if (getKind() == AdviceKind.PerThisEntry) { shadow.getThisVar(); } else if (getKind() == AdviceKind.PerTargetEntry) { shadow.getTargetVar(); }  if ((getExtraParameterFlags() & 0x4) != 0) { ((BcelShadow)shadow).getThisJoinPointStaticPartVar(); ((BcelShadow)shadow).getEnclosingClass().warnOnAddedStaticInitializer(shadow, getSourceLocation()); }  if ((getExtraParameterFlags() & 0x2) != 0) { boolean hasGuardTest = (this.runtimeTest != Literal.TRUE && getKind() != AdviceKind.Around); boolean isAround = (getKind() == AdviceKind.Around); ((BcelShadow)shadow).requireThisJoinPoint(hasGuardTest, isAround); ((BcelShadow)shadow).getEnclosingClass().warnOnAddedStaticInitializer(shadow, getSourceLocation()); if (!hasGuardTest && (world.getLint()).multipleAdviceStoppingLazyTjp.isEnabled()) ((BcelShadow)shadow).addAdvicePreventingLazyTjp(this);  }  if ((getExtraParameterFlags() & 0x8) != 0) { ((BcelShadow)shadow).getThisEnclosingJoinPointStaticPartVar(); ((BcelShadow)shadow).getEnclosingClass().warnOnAddedStaticInitializer(shadow, getSourceLocation()); }  } private boolean canInline(Shadow s) { if (this.attribute.isProceedInInners()) return false;  if (this.concreteAspect == null || this.concreteAspect.isMissing()) return false;  if (this.concreteAspect.getWorld().isXnoInline()) return false;  BcelObjectType boType = BcelWorld.getBcelObjectType(this.concreteAspect); if (boType == null) return false;  if (boType.javaClass.getMajor() >= 52 && this.containsInvokedynamic == 0) { this.containsInvokedynamic = 1; LazyMethodGen lmg = boType.getLazyClassGen().getLazyMethodGen(this.signature.getName(), this.signature.getSignature(), true); ResolvedType searchType = this.concreteAspect; while (lmg == null) { searchType = searchType.getSuperclass(); if (searchType == null) break;  ReferenceTypeDelegate rtd = ((ReferenceType)searchType).getDelegate(); if (rtd instanceof BcelObjectType) { BcelObjectType bot = (BcelObjectType)rtd; if (bot.javaClass.getMajor() < 52) break;  lmg = bot.getLazyClassGen().getLazyMethodGen(this.signature.getName(), this.signature.getSignature(), true); }  }  if (lmg != null) { InstructionList ilist = lmg.getBody(); for (InstructionHandle src = ilist.getStart(); src != null; src = src.getNext()) { if ((src.getInstruction()).opcode == 186) { this.containsInvokedynamic = 2; break; }  }  }  }  if (this.containsInvokedynamic == 2) return false;  return boType.getLazyClassGen().isWoven(); } public Collection<ResolvedType> getThrownExceptions() { if (this.thrownExceptions == null)
/*     */     {
/* 456 */       if (this.concreteAspect != null && this.concreteAspect.getWorld() != null && (
/* 457 */         getKind().isAfter() || getKind() == AdviceKind.Before || getKind() == AdviceKind.Around)) {
/* 458 */         World world = this.concreteAspect.getWorld();
/* 459 */         ResolvedMember m = world.resolve(this.signature);
/* 460 */         if (m == null) {
/* 461 */           this.thrownExceptions = Collections.emptyList();
/*     */         } else {
/* 463 */           this.thrownExceptions = collectCheckedExceptions(m.getExceptions());
/*     */         } 
/*     */       } else {
/* 466 */         this.thrownExceptions = Collections.emptyList();
/*     */       } 
/*     */     }
/* 469 */     return this.thrownExceptions; }
/*     */   
/*     */   private boolean aspectIsBroken() {
/*     */     if (this.concreteAspect instanceof ReferenceType) {
/*     */       ReferenceTypeDelegate rtDelegate = ((ReferenceType)this.concreteAspect).getDelegate();
/*     */       if (!(rtDelegate instanceof BcelObjectType))
/*     */         return true; 
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   public boolean mustCheckExceptions() {
/* 480 */     if (getConcreteAspect() == null) {
/* 481 */       return true;
/*     */     }
/* 483 */     return !getConcreteAspect().isAnnotationStyleAspect(); } public boolean implementOn(Shadow s) { this.hasMatchedAtLeastOnce = true; if (aspectIsBroken())
/*     */       return false;  BcelShadow shadow = (BcelShadow)s; if (!shadow.getWorld().isIgnoringUnusedDeclaredThrownException() && !getThrownExceptions().isEmpty()) { Member member = shadow.getSignature(); if (member instanceof BcelMethod) { removeUnnecessaryProblems((BcelMethod)member, ((BcelMethod)member).getDeclarationLineNumber()); } else { ResolvedMember resolvedMember = shadow.getSignature().resolve(shadow.getWorld()); if (resolvedMember instanceof BcelMethod && shadow.getEnclosingShadow() instanceof BcelShadow) { Member enclosingMember = shadow.getEnclosingShadow().getSignature(); if (enclosingMember instanceof BcelMethod)
/*     */             removeUnnecessaryProblems((BcelMethod)enclosingMember, ((BcelMethod)resolvedMember).getDeclarationLineNumber());  }  }  }  if (shadow.getIWorld().isJoinpointSynchronizationEnabled() && shadow.getKind() == Shadow.MethodExecution && (s.getSignature().getModifiers() & 0x20) != 0)
/*     */       (shadow.getIWorld().getLint()).advisingSynchronizedMethods.signal(new String[] { shadow.toString() }, shadow.getSourceLocation(), new ISourceLocation[] { getSourceLocation() });  if (this.runtimeTest == Literal.FALSE) { Member sig = shadow.getSignature(); if (sig.getArity() == 0 && shadow.getKind() == Shadow.MethodCall && sig.getName().charAt(0) == 'c' && sig.getReturnType().equals(ResolvedType.OBJECT) && sig.getName().equals("clone"))
/*     */         return false;  }  if (getKind() == AdviceKind.Before) { shadow.weaveBefore(this); } else if (getKind() == AdviceKind.AfterReturning) { shadow.weaveAfterReturning(this); } else if (getKind() == AdviceKind.AfterThrowing) { UnresolvedType catchType = hasExtraParameter() ? getExtraParameterType() : UnresolvedType.THROWABLE; shadow.weaveAfterThrowing(this, catchType); } else if (getKind() == AdviceKind.After) { shadow.weaveAfter(this); } else if (getKind() == AdviceKind.Around) { LazyClassGen enclosingClass = shadow.getEnclosingClass(); if (enclosingClass != null && enclosingClass.isInterface() && shadow.getEnclosingMethod().getName().charAt(0) == '<') { (shadow.getWorld().getLint()).cannotAdviseJoinpointInInterfaceWithAroundAdvice.signal(shadow.toString(), shadow.getSourceLocation()); return false; }  if (!canInline(s)) { shadow.weaveAroundClosure(this, hasDynamicTests()); } else { shadow.weaveAroundInline(this, hasDynamicTests()); }  } else if (getKind() == AdviceKind.InterInitializer) { shadow.weaveAfterReturning(this); } else if (getKind().isCflow()) { shadow.weaveCflowEntry(this, getSignature()); } else if (getKind() == AdviceKind.PerThisEntry) { shadow.weavePerObjectEntry(this, (BcelVar)shadow.getThisVar()); } else if (getKind() == AdviceKind.PerTargetEntry) { shadow.weavePerObjectEntry(this, (BcelVar)shadow.getTargetVar()); } else if (getKind() == AdviceKind.Softener) { shadow.weaveSoftener(this, ((ExactTypePattern)this.exceptionType).getType()); } else if (getKind() == AdviceKind.PerTypeWithinEntry) { shadow.weavePerTypeWithinAspectInitialization(this, (UnresolvedType)shadow.getEnclosingType()); } else { throw new BCException("unimplemented kind: " + getKind()); }
/*     */      return true; }
/*     */   private void removeUnnecessaryProblems(BcelMethod method, int problemLineNumber) { ISourceContext sourceContext = method.getSourceContext(); if (sourceContext instanceof IEclipseSourceContext)
/*     */       ((IEclipseSourceContext)sourceContext).removeUnnecessaryProblems((Member)method, problemLineNumber);  }
/*     */   private Collection<ResolvedType> collectCheckedExceptions(UnresolvedType[] excs) { if (excs == null || excs.length == 0)
/*     */       return Collections.emptyList();  Collection<ResolvedType> ret = new ArrayList<>(); World world = this.concreteAspect.getWorld(); ResolvedType runtimeException = world.getCoreType(UnresolvedType.RUNTIME_EXCEPTION); ResolvedType error = world.getCoreType(UnresolvedType.ERROR); for (UnresolvedType exc : excs) { ResolvedType t = world.resolve(exc, true); if (t.isMissing())
/*     */         (world.getLint()).cantFindType.signal(WeaverMessages.format("cftExceptionType", exc.getName()), getSourceLocation());  if (!runtimeException.isAssignableFrom(t) && !error.isAssignableFrom(t))
/*     */         ret.add(t);  }
/*     */      return ret; }
/* 496 */   public boolean hasDynamicTests() { return (this.runtimeTest != null && this.runtimeTest != Literal.TRUE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InstructionList getAdviceInstructions(BcelShadow s, BcelVar extraArgVar, InstructionHandle ifNoAdvice) {
/* 508 */     BcelShadow shadow = s;
/* 509 */     InstructionFactory fact = shadow.getFactory();
/* 510 */     BcelWorld world = shadow.getWorld();
/*     */     
/* 512 */     InstructionList il = new InstructionList();
/*     */ 
/*     */ 
/*     */     
/* 516 */     if (hasExtraParameter() && getKind() == AdviceKind.AfterReturning) {
/* 517 */       UnresolvedType extraParameterType = getExtraParameterType();
/* 518 */       if (!extraParameterType.equals(UnresolvedType.OBJECT) && !extraParameterType.isPrimitiveType()) {
/* 519 */         il.append(BcelRenderer.renderTest(fact, world, 
/* 520 */               Test.makeInstanceof(extraArgVar, getExtraParameterType().resolve(world)), null, ifNoAdvice, null));
/*     */       }
/*     */     } 
/* 523 */     il.append(getAdviceArgSetup(shadow, extraArgVar, (InstructionList)null));
/* 524 */     il.append(getNonTestAdviceInstructions(shadow));
/*     */     
/* 526 */     InstructionHandle ifYesAdvice = il.getStart();
/* 527 */     il.insert(getTestInstructions(shadow, ifYesAdvice, ifNoAdvice, ifYesAdvice));
/*     */ 
/*     */ 
/*     */     
/* 531 */     if (shadow.getKind() == Shadow.MethodExecution && getKind() == AdviceKind.Before) {
/* 532 */       int lineNumber = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 539 */       lineNumber = shadow.getEnclosingMethod().getMemberView().getLineNumberOfFirstInstruction();
/*     */       
/* 541 */       InstructionHandle start = il.getStart();
/* 542 */       if (lineNumber > 0) {
/* 543 */         start.addTargeter((InstructionTargeter)new LineNumberTag(lineNumber));
/*     */       }
/*     */       
/* 546 */       LocalVariableTable lvt = shadow.getEnclosingMethod().getMemberView().getMethod().getLocalVariableTable();
/* 547 */       if (lvt != null) {
/* 548 */         LocalVariable[] lvTable = lvt.getLocalVariableTable();
/* 549 */         for (LocalVariable lv : lvTable) {
/* 550 */           if (lv.getStartPC() == 0) {
/* 551 */             start.addTargeter((InstructionTargeter)new LocalVariableTag(lv.getSignature(), lv.getName(), lv.getIndex(), 0));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 557 */     return il;
/*     */   }
/*     */   
/*     */   public InstructionList getAdviceArgSetup(BcelShadow shadow, BcelVar extraVar, InstructionList closureInstantiation) {
/* 561 */     InstructionFactory fact = shadow.getFactory();
/* 562 */     BcelWorld world = shadow.getWorld();
/* 563 */     InstructionList il = new InstructionList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 575 */     if (this.exposedState.getAspectInstance() != null) {
/* 576 */       il.append(BcelRenderer.renderExpr(fact, world, this.exposedState.getAspectInstance()));
/*     */     }
/*     */     
/* 579 */     boolean x = getDeclaringAspect().resolve(world).isAnnotationStyleAspect();
/* 580 */     boolean isAnnotationStyleAspect = (getConcreteAspect() != null && getConcreteAspect().isAnnotationStyleAspect() && x);
/* 581 */     boolean previousIsClosure = false;
/* 582 */     for (int i = 0, len = this.exposedState.size(); i < len; i++) {
/* 583 */       if (!this.exposedState.isErroneousVar(i)) {
/*     */ 
/*     */         
/* 586 */         BcelVar v = (BcelVar)this.exposedState.get(i);
/*     */         
/* 588 */         if (v == null) {
/*     */           
/* 590 */           if (isAnnotationStyleAspect)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 597 */             if ("Lorg/aspectj/lang/ProceedingJoinPoint;".equals(getSignature().getParameterTypes()[i].getSignature())) {
/*     */               
/* 599 */               if (getKind() != AdviceKind.Around) {
/* 600 */                 previousIsClosure = false;
/* 601 */                 getConcreteAspect()
/* 602 */                   .getWorld()
/* 603 */                   .getMessageHandler()
/* 604 */                   .handleMessage((IMessage)new Message("use of ProceedingJoinPoint is allowed only on around advice (arg " + i + " in " + 
/*     */                       
/* 606 */                       toString() + ")", getSourceLocation(), true));
/*     */                 
/* 608 */                 il.append(InstructionConstants.ACONST_NULL);
/*     */               }
/* 610 */               else if (previousIsClosure) {
/* 611 */                 il.append(InstructionConstants.DUP);
/*     */               } else {
/* 613 */                 previousIsClosure = true;
/* 614 */                 il.append(closureInstantiation.copy());
/* 615 */                 shadow.closureVarInitialized = true;
/*     */               }
/*     */             
/* 618 */             } else if ("Lorg/aspectj/lang/JoinPoint$StaticPart;".equals(getSignature().getParameterTypes()[i]
/* 619 */                 .getSignature())) {
/* 620 */               previousIsClosure = false;
/* 621 */               if ((getExtraParameterFlags() & 0x4) != 0) {
/* 622 */                 shadow.getThisJoinPointStaticPartBcelVar().appendLoad(il, fact);
/*     */               }
/* 624 */             } else if ("Lorg/aspectj/lang/JoinPoint;".equals(getSignature().getParameterTypes()[i].getSignature())) {
/* 625 */               previousIsClosure = false;
/* 626 */               if ((getExtraParameterFlags() & 0x2) != 0) {
/* 627 */                 il.append(shadow.loadThisJoinPoint());
/*     */               }
/* 629 */             } else if ("Lorg/aspectj/lang/JoinPoint$EnclosingStaticPart;".equals(getSignature().getParameterTypes()[i]
/* 630 */                 .getSignature())) {
/* 631 */               previousIsClosure = false;
/* 632 */               if ((getExtraParameterFlags() & 0x8) != 0) {
/* 633 */                 shadow.getThisEnclosingJoinPointStaticPartBcelVar().appendLoad(il, fact);
/*     */               }
/* 635 */             } else if (hasExtraParameter()) {
/* 636 */               previousIsClosure = false;
/* 637 */               extraVar.appendLoadAndConvert(il, fact, getExtraParameterType().resolve(world));
/*     */             } else {
/* 639 */               previousIsClosure = false;
/* 640 */               getConcreteAspect()
/* 641 */                 .getWorld()
/* 642 */                 .getMessageHandler()
/* 643 */                 .handleMessage((IMessage)new Message("use of ProceedingJoinPoint is allowed only on around advice (arg " + i + " in " + 
/*     */                     
/* 645 */                     toString() + ")", getSourceLocation(), true));
/*     */               
/* 647 */               il.append(InstructionConstants.ACONST_NULL);
/*     */             } 
/*     */           }
/*     */         } else {
/* 651 */           UnresolvedType desiredTy = getBindingParameterTypes()[i];
/* 652 */           v.appendLoadAndConvert(il, fact, desiredTy.resolve(world));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 658 */     if (!isAnnotationStyleAspect) {
/* 659 */       if (getKind() == AdviceKind.Around) {
/* 660 */         il.append(closureInstantiation);
/* 661 */       } else if (hasExtraParameter()) {
/* 662 */         extraVar.appendLoadAndConvert(il, fact, getExtraParameterType().resolve(world));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 668 */       if ((getExtraParameterFlags() & 0x4) != 0) {
/* 669 */         shadow.getThisJoinPointStaticPartBcelVar().appendLoad(il, fact);
/*     */       }
/*     */       
/* 672 */       if ((getExtraParameterFlags() & 0x2) != 0) {
/* 673 */         il.append(shadow.loadThisJoinPoint());
/*     */       }
/*     */       
/* 676 */       if ((getExtraParameterFlags() & 0x8) != 0) {
/* 677 */         shadow.getThisEnclosingJoinPointStaticPartBcelVar().appendLoad(il, fact);
/*     */       }
/*     */     } 
/*     */     
/* 681 */     return il;
/*     */   }
/*     */   
/*     */   public InstructionList getNonTestAdviceInstructions(BcelShadow shadow) {
/* 685 */     return new InstructionList(Utility.createInvoke(shadow.getFactory(), shadow.getWorld(), getOriginalSignature()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Member getOriginalSignature() {
/* 690 */     Member sig = getSignature();
/* 691 */     if (sig instanceof ResolvedMember) {
/* 692 */       ResolvedMember rsig = (ResolvedMember)sig;
/* 693 */       if (rsig.hasBackingGenericMember()) {
/* 694 */         return (Member)rsig.getBackingGenericMember();
/*     */       }
/*     */     } 
/* 697 */     return sig;
/*     */   }
/*     */ 
/*     */   
/*     */   public InstructionList getTestInstructions(BcelShadow shadow, InstructionHandle sk, InstructionHandle fk, InstructionHandle next) {
/* 702 */     return BcelRenderer.renderTest(shadow.getFactory(), shadow.getWorld(), this.runtimeTest, sk, fk, next);
/*     */   }
/*     */   
/*     */   public int compareTo(Object other) {
/* 706 */     if (!(other instanceof BcelAdvice)) {
/* 707 */       return 0;
/*     */     }
/* 709 */     BcelAdvice o = (BcelAdvice)other;
/*     */ 
/*     */     
/* 712 */     if (this.kind.getPrecedence() != o.kind.getPrecedence()) {
/* 713 */       if (this.kind.getPrecedence() > o.kind.getPrecedence()) {
/* 714 */         return 1;
/*     */       }
/* 716 */       return -1;
/*     */     } 
/*     */ 
/*     */     
/* 720 */     if (this.kind.isCflow()) {
/*     */ 
/*     */       
/* 723 */       boolean isBelow = (this.kind == AdviceKind.CflowBelowEntry);
/*     */       
/* 725 */       if (this.innerCflowEntries.contains(o))
/* 726 */         return isBelow ? 1 : -1; 
/* 727 */       if (o.innerCflowEntries.contains(this)) {
/* 728 */         return isBelow ? -1 : 1;
/*     */       }
/* 730 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 734 */     if (this.kind.isPerEntry() || this.kind == AdviceKind.Softener) {
/* 735 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 739 */     World world = this.concreteAspect.getWorld();
/*     */     
/* 741 */     int ret = this.concreteAspect.getWorld().compareByPrecedence(this.concreteAspect, o.concreteAspect);
/* 742 */     if (ret != 0) {
/* 743 */       return ret;
/*     */     }
/*     */     
/* 746 */     ResolvedType declaringAspect = getDeclaringAspect().resolve(world);
/* 747 */     ResolvedType o_declaringAspect = o.getDeclaringAspect().resolve(world);
/*     */     
/* 749 */     if (declaringAspect == o_declaringAspect) {
/* 750 */       if (this.kind.isAfter() || o.kind.isAfter()) {
/* 751 */         return (getStart() < o.getStart()) ? -1 : 1;
/*     */       }
/* 753 */       return (getStart() < o.getStart()) ? 1 : -1;
/*     */     } 
/* 755 */     if (declaringAspect.isAssignableFrom(o_declaringAspect))
/* 756 */       return -1; 
/* 757 */     if (o_declaringAspect.isAssignableFrom(declaringAspect)) {
/* 758 */       return 1;
/*     */     }
/* 760 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BcelVar[] getExposedStateAsBcelVars(boolean isAround) {
/* 766 */     if (isAround)
/*     */     {
/* 768 */       if (getConcreteAspect() != null && getConcreteAspect().isAnnotationStyleAspect()) {
/* 769 */         return BcelVar.NONE;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 774 */     if (this.exposedState == null) {
/* 775 */       return BcelVar.NONE;
/*     */     }
/* 777 */     int len = this.exposedState.vars.length;
/* 778 */     BcelVar[] ret = new BcelVar[len];
/* 779 */     for (int i = 0; i < len; i++) {
/* 780 */       ret[i] = (BcelVar)this.exposedState.vars[i];
/*     */     }
/* 782 */     return ret;
/*     */   }
/*     */   
/*     */   protected void suppressLintWarnings(World inWorld) {
/* 786 */     if (this.suppressedLintKinds == null) {
/* 787 */       if (this.signature instanceof BcelMethod) {
/* 788 */         this.suppressedLintKinds = Utility.getSuppressedWarnings(this.signature.getAnnotations(), inWorld.getLint());
/*     */       } else {
/* 790 */         this.suppressedLintKinds = Collections.emptyList();
/*     */         return;
/*     */       } 
/*     */     }
/* 794 */     inWorld.getLint().suppressKinds(this.suppressedLintKinds);
/*     */   }
/*     */   
/*     */   protected void clearLintSuppressions(World inWorld, Collection<Lint.Kind> toClear) {
/* 798 */     inWorld.getLint().clearSuppressions(toClear);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BcelAdvice(AdviceKind kind, Pointcut pointcut, Member signature, int extraArgumentFlags, int start, int end, ISourceContext sourceContext, ResolvedType concreteAspect) {
/* 806 */     this(new AjAttribute.AdviceAttribute(kind, pointcut, extraArgumentFlags, start, end, sourceContext), pointcut, signature, concreteAspect);
/*     */     
/* 808 */     this.thrownExceptions = Collections.emptyList();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */