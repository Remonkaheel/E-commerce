/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BcelVar
/*     */   extends Var
/*     */ {
/*  23 */   private int positionInAroundState = -1;
/*     */   
/*     */   private int slot;
/*     */   
/*     */   public BcelVar(ResolvedType type, int slot) {
/*  28 */     super(type);
/*  29 */     this.slot = slot;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  33 */     return "BcelVar(" + getType() + " " + this.slot + ((this.positionInAroundState != -1) ? (" " + this.positionInAroundState) : "") + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSlot() {
/*  39 */     return this.slot;
/*     */   }
/*     */ 
/*     */   
/*     */   public Instruction createLoad(InstructionFactory fact) {
/*  44 */     return (Instruction)InstructionFactory.createLoad(BcelWorld.makeBcelType((UnresolvedType)getType()), this.slot);
/*     */   }
/*     */   
/*     */   public Instruction createStore(InstructionFactory fact) {
/*  48 */     return (Instruction)InstructionFactory.createStore(BcelWorld.makeBcelType((UnresolvedType)getType()), this.slot);
/*     */   }
/*     */   
/*     */   public void appendStore(InstructionList il, InstructionFactory fact) {
/*  52 */     il.append(createStore(fact));
/*     */   }
/*     */   
/*     */   public void appendLoad(InstructionList il, InstructionFactory fact) {
/*  56 */     il.append(createLoad(fact));
/*     */   }
/*     */   
/*     */   public void appendLoadAndConvert(InstructionList il, InstructionFactory fact, ResolvedType toType) {
/*  60 */     il.append(createLoad(fact));
/*  61 */     Utility.appendConversion(il, fact, getType(), toType);
/*     */   }
/*     */   
/*     */   public void insertLoad(InstructionList il, InstructionFactory fact) {
/*  65 */     il.insert(createLoad(fact));
/*     */   }
/*     */   
/*     */   public InstructionList createCopyFrom(InstructionFactory fact, int oldSlot) {
/*  69 */     InstructionList il = new InstructionList();
/*  70 */     il.append((Instruction)InstructionFactory.createLoad(BcelWorld.makeBcelType((UnresolvedType)getType()), oldSlot));
/*  71 */     il.append(createStore(fact));
/*  72 */     return il;
/*     */   }
/*     */ 
/*     */   
/*     */   void appendConvertableArrayLoad(InstructionList il, InstructionFactory fact, int index, ResolvedType convertTo) {
/*  77 */     ResolvedType convertFromType = getType().getResolvedComponentType();
/*  78 */     appendLoad(il, fact);
/*  79 */     il.append(Utility.createConstant(fact, index));
/*  80 */     il.append(InstructionFactory.createArrayLoad(BcelWorld.makeBcelType((UnresolvedType)convertFromType)));
/*  81 */     Utility.appendConversion(il, fact, convertFromType, convertTo);
/*     */   }
/*     */   
/*     */   void appendConvertableArrayStore(InstructionList il, InstructionFactory fact, int index, BcelVar storee) {
/*  85 */     ResolvedType convertToType = getType().getResolvedComponentType();
/*  86 */     appendLoad(il, fact);
/*  87 */     il.append(Utility.createConstant(fact, index));
/*  88 */     storee.appendLoad(il, fact);
/*  89 */     Utility.appendConversion(il, fact, storee.getType(), convertToType);
/*  90 */     il.append(InstructionFactory.createArrayStore(BcelWorld.makeBcelType((UnresolvedType)convertToType)));
/*     */   }
/*     */   
/*     */   InstructionList createConvertableArrayStore(InstructionFactory fact, int index, BcelVar storee) {
/*  94 */     InstructionList il = new InstructionList();
/*  95 */     appendConvertableArrayStore(il, fact, index, storee);
/*  96 */     return il;
/*     */   }
/*     */   
/*     */   InstructionList createConvertableArrayLoad(InstructionFactory fact, int index, ResolvedType convertTo) {
/* 100 */     InstructionList il = new InstructionList();
/* 101 */     appendConvertableArrayLoad(il, fact, index, convertTo);
/* 102 */     return il;
/*     */   }
/*     */   
/*     */   public int getPositionInAroundState() {
/* 106 */     return this.positionInAroundState;
/*     */   }
/*     */   
/*     */   public void setPositionInAroundState(int positionInAroundState) {
/* 110 */     this.positionInAroundState = positionInAroundState;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final BcelVar[] NONE = new BcelVar[0];
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */