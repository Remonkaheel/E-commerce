/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ import org.aspectj.weaver.ConstantPoolReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelConstantPoolReader
/*    */   implements ConstantPoolReader
/*    */ {
/*    */   private ConstantPool constantPool;
/*    */   
/*    */   public BcelConstantPoolReader(ConstantPool constantPool) {
/* 27 */     this.constantPool = constantPool;
/*    */   }
/*    */   
/*    */   public String readUtf8(int cpIndex) {
/* 31 */     return this.constantPool.getConstantUtf8(cpIndex).getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelConstantPoolReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */