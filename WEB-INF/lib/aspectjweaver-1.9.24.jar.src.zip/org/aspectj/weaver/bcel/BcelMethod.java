/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.aspectj.apache.bcel.classfile.AnnotationDefault;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.ExceptionTable;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ import org.aspectj.apache.bcel.classfile.LineNumber;
/*     */ import org.aspectj.apache.bcel.classfile.LineNumberTable;
/*     */ import org.aspectj.apache.bcel.classfile.LocalVariable;
/*     */ import org.aspectj.apache.bcel.classfile.LocalVariableTable;
/*     */ import org.aspectj.apache.bcel.classfile.Method;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.SourceLocation;
/*     */ import org.aspectj.util.GenericSignature;
/*     */ import org.aspectj.util.GenericSignatureParser;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.AnnotationAJ;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.MemberKind;
/*     */ import org.aspectj.weaver.ResolvedMemberImpl;
/*     */ import org.aspectj.weaver.ResolvedPointcutDefinition;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.ShadowMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BcelMethod
/*     */   extends ResolvedMemberImpl
/*     */ {
/*     */   private static final String ASPECTJ_ANNOTATION_PACKAGE = "org.aspectj.lang.annotation";
/*  55 */   private static final char PACKAGE_INITIAL_CHAR = "org.aspectj.lang.annotation".charAt(0);
/*     */   
/*     */   private Method method;
/*     */   
/*     */   private ShadowMunger associatedShadowMunger;
/*     */   
/*     */   private ResolvedPointcutDefinition preResolvedPointcut;
/*     */   
/*     */   private AjAttribute.EffectiveSignatureAttribute effectiveSignature;
/*     */   
/*     */   private AjAttribute.MethodDeclarationLineNumberAttribute declarationLineNumber;
/*     */   
/*     */   private final BcelObjectType bcelObjectType;
/*     */   
/*     */   private int bitflags;
/*     */   
/*     */   private static final int KNOW_IF_SYNTHETIC = 1;
/*     */   
/*     */   private static final int PARAMETER_NAMES_INITIALIZED = 2;
/*     */   private static final int CAN_BE_PARAMETERIZED = 4;
/*     */   private static final int UNPACKED_GENERIC_SIGNATURE = 8;
/*     */   private static final int IS_AJ_SYNTHETIC = 64;
/*     */   private static final int IS_SYNTHETIC = 128;
/*     */   private static final int IS_SYNTHETIC_INVERSE = 32639;
/*     */   private static final int HAS_ANNOTATIONS = 1024;
/*     */   private static final int HAVE_DETERMINED_ANNOTATIONS = 2048;
/*  81 */   private UnresolvedType genericReturnType = null;
/*  82 */   private UnresolvedType[] genericParameterTypes = null;
/*     */   
/*     */   BcelMethod(BcelObjectType declaringType, Method method) {
/*  85 */     super(method.getName().equals("<init>") ? CONSTRUCTOR : (method.getName().equals("<clinit>") ? STATIC_INITIALIZATION : 
/*  86 */         METHOD), (UnresolvedType)declaringType.getResolvedTypeX(), method.getModifiers(), method.getName(), method.getSignature());
/*  87 */     this.method = method;
/*  88 */     this.sourceContext = declaringType.getResolvedTypeX().getSourceContext();
/*  89 */     this.bcelObjectType = declaringType;
/*  90 */     unpackJavaAttributes();
/*  91 */     unpackAjAttributes(this.bcelObjectType.getWorld());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BcelMethod(BcelObjectType declaringType, Method method, List<AjAttribute> attributes) {
/*  98 */     super(method.getName().equals("<init>") ? CONSTRUCTOR : (method.getName().equals("<clinit>") ? STATIC_INITIALIZATION : 
/*  99 */         METHOD), (UnresolvedType)declaringType.getResolvedTypeX(), method.getModifiers(), method.getName(), method.getSignature());
/* 100 */     this.method = method;
/* 101 */     this.sourceContext = declaringType.getResolvedTypeX().getSourceContext();
/* 102 */     this.bcelObjectType = declaringType;
/* 103 */     unpackJavaAttributes();
/* 104 */     processAttributes(this.bcelObjectType.getWorld(), attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void unpackJavaAttributes() {
/* 110 */     ExceptionTable exnTable = this.method.getExceptionTable();
/* 111 */     this.checkedExceptions = (exnTable == null) ? UnresolvedType.NONE : UnresolvedType.forNames(exnTable.getExceptionNames());
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterNames() {
/* 116 */     determineParameterNames();
/* 117 */     return super.getParameterNames();
/*     */   }
/*     */   
/*     */   public int getLineNumberOfFirstInstruction() {
/* 121 */     LineNumberTable lnt = this.method.getLineNumberTable();
/* 122 */     if (lnt == null) {
/* 123 */       return -1;
/*     */     }
/* 125 */     LineNumber[] lns = lnt.getLineNumberTable();
/* 126 */     if (lns == null || lns.length == 0) {
/* 127 */       return -1;
/*     */     }
/* 129 */     return lns[0].getLineNumber();
/*     */   }
/*     */   
/*     */   public void determineParameterNames() {
/* 133 */     if ((this.bitflags & 0x2) != 0) {
/*     */       return;
/*     */     }
/* 136 */     this.bitflags |= 0x2;
/* 137 */     LocalVariableTable varTable = this.method.getLocalVariableTable();
/* 138 */     int len = getArity();
/* 139 */     if (varTable == null) {
/*     */       
/* 141 */       AnnotationAJ[] annos = getAnnotations();
/* 142 */       if (annos != null && annos.length != 0) {
/* 143 */         AnnotationAJ[] axs = getAnnotations();
/* 144 */         for (AnnotationAJ annotationX : axs) {
/* 145 */           String typename = annotationX.getTypeName();
/* 146 */           if (typename.charAt(0) == PACKAGE_INITIAL_CHAR && (
/* 147 */             typename.equals("org.aspectj.lang.annotation.Pointcut") || typename
/* 148 */             .equals("org.aspectj.lang.annotation.Before") || typename
/* 149 */             .equals("org.aspectj.lang.annotation.Around") || typename
/* 150 */             .startsWith("org.aspectj.lang.annotation.After"))) {
/* 151 */             AnnotationGen a = ((BcelAnnotation)annotationX).getBcelAnnotation();
/* 152 */             if (a != null) {
/* 153 */               List<NameValuePair> values = a.getValues();
/* 154 */               for (NameValuePair nvPair : values) {
/* 155 */                 if (nvPair.getNameString().equals("argNames")) {
/* 156 */                   String argNames = nvPair.getValue().stringifyValue();
/* 157 */                   StringTokenizer argNameTokenizer = new StringTokenizer(argNames, " ,");
/* 158 */                   List<String> argsList = new ArrayList<>();
/* 159 */                   while (argNameTokenizer.hasMoreTokens()) {
/* 160 */                     argsList.add(argNameTokenizer.nextToken());
/*     */                   }
/* 162 */                   int requiredCount = (getParameterTypes()).length;
/* 163 */                   while (argsList.size() < requiredCount) {
/* 164 */                     argsList.add("arg" + argsList.size());
/*     */                   }
/* 166 */                   setParameterNames(argsList.<String>toArray(new String[0]));
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 175 */       setParameterNames(Utility.makeArgNames(len));
/*     */     } else {
/* 177 */       UnresolvedType[] paramTypes = getParameterTypes();
/* 178 */       String[] paramNames = new String[len];
/* 179 */       int index = Modifier.isStatic(this.modifiers) ? 0 : 1;
/* 180 */       for (int i = 0; i < len; i++) {
/* 181 */         LocalVariable lv = varTable.getLocalVariable(index);
/* 182 */         if (lv == null) {
/* 183 */           paramNames[i] = "arg" + i;
/*     */         } else {
/* 185 */           paramNames[i] = lv.getName();
/*     */         } 
/* 187 */         index += paramTypes[i].getSize();
/*     */       } 
/* 189 */       setParameterNames(paramNames);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void unpackAjAttributes(World world) {
/* 194 */     this.associatedShadowMunger = null;
/* 195 */     ResolvedType resolvedDeclaringType = getDeclaringType().resolve(world);
/* 196 */     AjAttribute.WeaverVersionInfo wvinfo = this.bcelObjectType.getWeaverVersionAttribute();
/* 197 */     List<AjAttribute> as = Utility.readAjAttributes(resolvedDeclaringType.getClassName(), this.method.getAttributes(), resolvedDeclaringType
/* 198 */         .getSourceContext(), world, wvinfo, new BcelConstantPoolReader(this.method.getConstantPool()));
/* 199 */     processAttributes(world, as);
/* 200 */     as = AtAjAttributes.readAj5MethodAttributes(this.method, this, resolvedDeclaringType, this.preResolvedPointcut, resolvedDeclaringType
/* 201 */         .getSourceContext(), world.getMessageHandler());
/* 202 */     processAttributes(world, as);
/*     */   }
/*     */   
/*     */   private void processAttributes(World world, List<AjAttribute> as) {
/* 206 */     for (AjAttribute attr : as) {
/* 207 */       if (attr instanceof AjAttribute.MethodDeclarationLineNumberAttribute) {
/* 208 */         this.declarationLineNumber = (AjAttribute.MethodDeclarationLineNumberAttribute)attr; continue;
/* 209 */       }  if (attr instanceof AjAttribute.AdviceAttribute) {
/* 210 */         this.associatedShadowMunger = (ShadowMunger)((AjAttribute.AdviceAttribute)attr).reify((Member)this, world, (ResolvedType)getDeclaringType()); continue;
/* 211 */       }  if (attr instanceof AjAttribute.AjSynthetic) {
/* 212 */         this.bitflags |= 0x40; continue;
/* 213 */       }  if (attr instanceof AjAttribute.EffectiveSignatureAttribute) {
/* 214 */         this.effectiveSignature = (AjAttribute.EffectiveSignatureAttribute)attr; continue;
/* 215 */       }  if (attr instanceof AjAttribute.PointcutDeclarationAttribute) {
/*     */         
/* 217 */         this.preResolvedPointcut = ((AjAttribute.PointcutDeclarationAttribute)attr).reify(); continue;
/*     */       } 
/* 219 */       throw new BCException("weird method attribute " + attr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAnnotationDefaultValue() {
/* 247 */     Attribute[] attrs = this.method.getAttributes();
/* 248 */     for (Attribute attribute : attrs) {
/* 249 */       if (attribute.getName().equals("AnnotationDefault")) {
/* 250 */         AnnotationDefault def = (AnnotationDefault)attribute;
/* 251 */         return def.getElementValue().stringifyValue();
/*     */       } 
/*     */     } 
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAttributeNames(boolean onlyIncludeAjOnes) {
/* 259 */     Attribute[] as = this.method.getAttributes();
/* 260 */     List<String> names = new ArrayList<>();
/*     */     
/* 262 */     for (Attribute a : as) {
/* 263 */       if (!onlyIncludeAjOnes || a.getName().startsWith("org.aspectj.weaver")) {
/* 264 */         names.add(a.getName());
/*     */       }
/*     */     } 
/* 267 */     return names.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAjSynthetic() {
/* 272 */     return ((this.bitflags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ShadowMunger getAssociatedShadowMunger() {
/* 277 */     return this.associatedShadowMunger;
/*     */   }
/*     */ 
/*     */   
/*     */   public AjAttribute.EffectiveSignatureAttribute getEffectiveSignature() {
/* 282 */     return this.effectiveSignature;
/*     */   }
/*     */   
/*     */   public boolean hasDeclarationLineNumberInfo() {
/* 286 */     return (this.declarationLineNumber != null);
/*     */   }
/*     */   
/*     */   public int getDeclarationLineNumber() {
/* 290 */     if (this.declarationLineNumber != null) {
/* 291 */       return this.declarationLineNumber.getLineNumber();
/*     */     }
/* 293 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDeclarationOffset() {
/* 298 */     if (this.declarationLineNumber != null) {
/* 299 */       return this.declarationLineNumber.getOffset();
/*     */     }
/* 301 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceLocation getSourceLocation() {
/*     */     SourceLocation sourceLocation;
/* 307 */     ISourceLocation ret = super.getSourceLocation();
/* 308 */     if ((ret == null || ret.getLine() == 0) && hasDeclarationLineNumberInfo()) {
/*     */       
/* 310 */       ISourceContext isc = getSourceContext();
/* 311 */       if (isc != null) {
/* 312 */         ret = isc.makeSourceLocation(getDeclarationLineNumber(), getDeclarationOffset());
/*     */       } else {
/* 314 */         sourceLocation = new SourceLocation(null, getDeclarationLineNumber());
/*     */       } 
/*     */     } 
/* 317 */     return (ISourceLocation)sourceLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public MemberKind getKind() {
/* 322 */     if (this.associatedShadowMunger != null) {
/* 323 */       return ADVICE;
/*     */     }
/* 325 */     return super.getKind();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAnnotation(UnresolvedType ofType) {
/* 331 */     ensureAnnotationsRetrieved();
/* 332 */     for (ResolvedType aType : this.annotationTypes) {
/* 333 */       if (aType.equals(ofType)) {
/* 334 */         return true;
/*     */       }
/*     */     } 
/* 337 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationAJ[] getAnnotations() {
/* 342 */     ensureAnnotationsRetrieved();
/* 343 */     if ((this.bitflags & 0x400) != 0) {
/* 344 */       return this.annotations;
/*     */     }
/* 346 */     return AnnotationAJ.EMPTY_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType[] getAnnotationTypes() {
/* 352 */     ensureAnnotationsRetrieved();
/* 353 */     return this.annotationTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationAJ getAnnotationOfType(UnresolvedType ofType) {
/* 358 */     ensureAnnotationsRetrieved();
/* 359 */     if ((this.bitflags & 0x400) == 0) {
/* 360 */       return null;
/*     */     }
/* 362 */     for (AnnotationAJ annotation : this.annotations) {
/* 363 */       if (annotation.getTypeName().equals(ofType.getName())) {
/* 364 */         return annotation;
/*     */       }
/*     */     } 
/* 367 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnnotation(AnnotationAJ annotation) {
/* 372 */     ensureAnnotationsRetrieved();
/* 373 */     if ((this.bitflags & 0x400) == 0) {
/* 374 */       this.annotations = new AnnotationAJ[1];
/* 375 */       this.annotations[0] = annotation;
/* 376 */       this.annotationTypes = new ResolvedType[1];
/* 377 */       this.annotationTypes[0] = annotation.getType();
/*     */     } else {
/*     */       
/* 380 */       int len = this.annotations.length;
/* 381 */       AnnotationAJ[] ret = new AnnotationAJ[len + 1];
/* 382 */       System.arraycopy(this.annotations, 0, ret, 0, len);
/* 383 */       ret[len] = annotation;
/* 384 */       this.annotations = ret;
/* 385 */       ResolvedType[] newAnnotationTypes = new ResolvedType[len + 1];
/* 386 */       System.arraycopy(this.annotationTypes, 0, newAnnotationTypes, 0, len);
/* 387 */       newAnnotationTypes[len] = annotation.getType();
/* 388 */       this.annotationTypes = newAnnotationTypes;
/*     */     } 
/* 390 */     this.bitflags |= 0x400;
/*     */   }
/*     */   
/*     */   public void removeAnnotation(ResolvedType annotationType) {
/* 394 */     ensureAnnotationsRetrieved();
/* 395 */     if ((this.bitflags & 0x400) != 0) {
/*     */ 
/*     */       
/* 398 */       int len = this.annotations.length;
/* 399 */       if (len == 1) {
/* 400 */         this.bitflags &= 0xFFFFFBFF;
/* 401 */         this.annotations = null;
/* 402 */         this.annotationTypes = null;
/*     */         return;
/*     */       } 
/* 405 */       AnnotationAJ[] ret = new AnnotationAJ[len - 1];
/* 406 */       int p = 0;
/* 407 */       for (AnnotationAJ annotation : this.annotations) {
/* 408 */         if (!annotation.getType().equals(annotationType)) {
/* 409 */           ret[p++] = annotation;
/*     */         }
/*     */       } 
/* 412 */       this.annotations = ret;
/*     */       
/* 414 */       ResolvedType[] newAnnotationTypes = new ResolvedType[len - 1];
/* 415 */       p = 0;
/* 416 */       for (AnnotationAJ annotation : this.annotations) {
/* 417 */         if (!annotation.getType().equals(annotationType)) {
/* 418 */           newAnnotationTypes[p++] = annotationType;
/*     */         }
/*     */       } 
/* 421 */       this.annotationTypes = newAnnotationTypes;
/*     */     } 
/* 423 */     this.bitflags |= 0x400;
/*     */   }
/*     */   
/*     */   public void addParameterAnnotation(int param, AnnotationAJ anno) {
/* 427 */     ensureParameterAnnotationsRetrieved();
/* 428 */     if (this.parameterAnnotations == NO_PARAMETER_ANNOTATIONXS) {
/*     */       
/* 430 */       this.parameterAnnotations = new AnnotationAJ[getArity()][];
/* 431 */       for (int i = 0; i < getArity(); i++) {
/* 432 */         this.parameterAnnotations[i] = AnnotationAJ.EMPTY_ARRAY;
/*     */       }
/*     */     } 
/* 435 */     int existingCount = (this.parameterAnnotations[param]).length;
/* 436 */     if (existingCount == 0) {
/* 437 */       AnnotationAJ[] annoArray = new AnnotationAJ[1];
/* 438 */       annoArray[0] = anno;
/* 439 */       this.parameterAnnotations[param] = annoArray;
/*     */     } else {
/* 441 */       AnnotationAJ[] newAnnoArray = new AnnotationAJ[existingCount + 1];
/* 442 */       System.arraycopy(this.parameterAnnotations[param], 0, newAnnoArray, 0, existingCount);
/* 443 */       newAnnoArray[existingCount] = anno;
/* 444 */       this.parameterAnnotations[param] = newAnnoArray;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void ensureAnnotationsRetrieved() {
/* 449 */     if (this.method == null) {
/*     */       return;
/*     */     }
/* 452 */     if ((this.bitflags & 0x800) != 0) {
/*     */       return;
/*     */     }
/* 455 */     this.bitflags |= 0x800;
/* 456 */     AnnotationGen[] annos = this.method.getAnnotations();
/* 457 */     if (annos.length == 0) {
/* 458 */       this.annotationTypes = ResolvedType.NONE;
/* 459 */       this.annotations = AnnotationAJ.EMPTY_ARRAY;
/*     */     } else {
/* 461 */       int annoCount = annos.length;
/* 462 */       this.annotationTypes = new ResolvedType[annoCount];
/* 463 */       this.annotations = new AnnotationAJ[annoCount];
/* 464 */       for (int i = 0; i < annoCount; i++) {
/* 465 */         AnnotationGen annotation = annos[i];
/* 466 */         this.annotations[i] = (AnnotationAJ)new BcelAnnotation(annotation, this.bcelObjectType.getWorld());
/* 467 */         this.annotationTypes[i] = this.annotations[i].getType();
/*     */       } 
/* 469 */       this.bitflags |= 0x400;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void ensureParameterAnnotationsRetrieved() {
/* 474 */     if (this.method == null) {
/*     */       return;
/*     */     }
/* 477 */     AnnotationGen[][] pAnns = this.method.getParameterAnnotations();
/* 478 */     if (this.parameterAnnotationTypes == null || pAnns.length != this.parameterAnnotationTypes.length) {
/* 479 */       if (pAnns == Method.NO_PARAMETER_ANNOTATIONS) {
/* 480 */         this.parameterAnnotationTypes = NO_PARAMETER_ANNOTATION_TYPES;
/* 481 */         this.parameterAnnotations = NO_PARAMETER_ANNOTATIONXS;
/*     */       } else {
/* 483 */         AnnotationGen[][] annos = this.method.getParameterAnnotations();
/* 484 */         this.parameterAnnotations = new AnnotationAJ[annos.length][];
/* 485 */         this.parameterAnnotationTypes = new ResolvedType[annos.length][];
/* 486 */         for (int i = 0; i < annos.length; i++) {
/* 487 */           AnnotationGen[] annosOnThisParam = annos[i];
/* 488 */           if ((annos[i]).length == 0) {
/* 489 */             this.parameterAnnotations[i] = AnnotationAJ.EMPTY_ARRAY;
/* 490 */             this.parameterAnnotationTypes[i] = ResolvedType.NONE;
/*     */           } else {
/* 492 */             this.parameterAnnotations[i] = new AnnotationAJ[annosOnThisParam.length];
/* 493 */             this.parameterAnnotationTypes[i] = new ResolvedType[annosOnThisParam.length];
/* 494 */             for (int j = 0; j < annosOnThisParam.length; j++) {
/* 495 */               this.parameterAnnotations[i][j] = (AnnotationAJ)new BcelAnnotation(annosOnThisParam[j], this.bcelObjectType.getWorld());
/* 496 */               this.parameterAnnotationTypes[i][j] = this.bcelObjectType.getWorld().resolve(
/* 497 */                   UnresolvedType.forSignature(annosOnThisParam[j].getTypeSignature()));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationAJ[][] getParameterAnnotations() {
/* 507 */     ensureParameterAnnotationsRetrieved();
/* 508 */     return this.parameterAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolvedType[][] getParameterAnnotationTypes() {
/* 513 */     ensureParameterAnnotationsRetrieved();
/* 514 */     return this.parameterAnnotationTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBeParameterized() {
/* 523 */     unpackGenericSignature();
/* 524 */     return ((this.bitflags & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnresolvedType[] getGenericParameterTypes() {
/* 529 */     unpackGenericSignature();
/* 530 */     return this.genericParameterTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedType getGenericReturnType() {
/* 538 */     unpackGenericSignature();
/* 539 */     return this.genericReturnType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/* 544 */     return this.method;
/*     */   }
/*     */   
/*     */   private void unpackGenericSignature() {
/* 548 */     if ((this.bitflags & 0x8) != 0) {
/*     */       return;
/*     */     }
/* 551 */     this.bitflags |= 0x8;
/* 552 */     if (!this.bcelObjectType.getWorld().isInJava5Mode()) {
/* 553 */       this.genericReturnType = getReturnType();
/* 554 */       this.genericParameterTypes = getParameterTypes();
/*     */       return;
/*     */     } 
/* 557 */     String gSig = this.method.getGenericSignature();
/* 558 */     if (gSig != null) {
/* 559 */       GenericSignature.MethodTypeSignature mSig = (new GenericSignatureParser()).parseAsMethodSignature(gSig);
/*     */ 
/*     */ 
/*     */       
/* 563 */       if (mSig.formalTypeParameters.length > 0)
/*     */       {
/* 565 */         this.bitflags |= 0x4;
/*     */       }
/*     */       
/* 568 */       this.typeVariables = new org.aspectj.weaver.TypeVariable[mSig.formalTypeParameters.length];
/* 569 */       for (int i = 0; i < this.typeVariables.length; i++) {
/* 570 */         GenericSignature.FormalTypeParameter methodFtp = mSig.formalTypeParameters[i];
/*     */         try {
/* 572 */           this.typeVariables[i] = BcelGenericSignatureToTypeXConverter.formalTypeParameter2TypeVariable(methodFtp, mSig.formalTypeParameters, this.bcelObjectType
/* 573 */               .getWorld());
/* 574 */         } catch (GenericSignatureFormatException e) {
/*     */           
/* 576 */           throw new IllegalStateException("While getting the type variables for method " + toString() + " with generic signature " + mSig + " the following error condition was detected: " + e
/* 577 */               .getMessage());
/*     */         } 
/*     */       } 
/*     */       
/* 581 */       GenericSignature.FormalTypeParameter[] parentFormals = this.bcelObjectType.getAllFormals();
/* 582 */       GenericSignature.FormalTypeParameter[] formals = new GenericSignature.FormalTypeParameter[parentFormals.length + mSig.formalTypeParameters.length];
/*     */ 
/*     */ 
/*     */       
/* 586 */       System.arraycopy(mSig.formalTypeParameters, 0, formals, 0, mSig.formalTypeParameters.length);
/* 587 */       System.arraycopy(parentFormals, 0, formals, mSig.formalTypeParameters.length, parentFormals.length);
/* 588 */       GenericSignature.TypeSignature returnTypeSignature = mSig.returnType;
/*     */       try {
/* 590 */         this.genericReturnType = (UnresolvedType)BcelGenericSignatureToTypeXConverter.typeSignature2TypeX(returnTypeSignature, formals, this.bcelObjectType
/* 591 */             .getWorld());
/* 592 */       } catch (GenericSignatureFormatException e) {
/*     */         
/* 594 */         throw new IllegalStateException("While determing the generic return type of " + toString() + " with generic signature " + gSig + " the following error was detected: " + e
/* 595 */             .getMessage());
/*     */       } 
/* 597 */       GenericSignature.TypeSignature[] paramTypeSigs = mSig.parameters;
/* 598 */       if (paramTypeSigs.length == 0) {
/* 599 */         this.genericParameterTypes = UnresolvedType.NONE;
/*     */       } else {
/* 601 */         this.genericParameterTypes = new UnresolvedType[paramTypeSigs.length];
/*     */       } 
/* 603 */       for (int j = 0; j < paramTypeSigs.length; j++) {
/*     */         try {
/* 605 */           this.genericParameterTypes[j] = (UnresolvedType)BcelGenericSignatureToTypeXConverter.typeSignature2TypeX(paramTypeSigs[j], formals, this.bcelObjectType
/* 606 */               .getWorld());
/* 607 */         } catch (GenericSignatureFormatException e) {
/*     */           
/* 609 */           throw new IllegalStateException("While determining the generic parameter types of " + toString() + " with generic signature " + gSig + " the following error was detected: " + e
/* 610 */               .getMessage());
/*     */         } 
/* 612 */         if (paramTypeSigs[j] instanceof GenericSignature.TypeVariableSignature) {
/* 613 */           this.bitflags |= 0x4;
/*     */         }
/*     */       } 
/*     */     } else {
/* 617 */       this.genericReturnType = getReturnType();
/* 618 */       this.genericParameterTypes = getParameterTypes();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void evictWeavingState() {
/* 624 */     if (this.method != null) {
/* 625 */       unpackGenericSignature();
/* 626 */       unpackJavaAttributes();
/* 627 */       ensureAnnotationsRetrieved();
/* 628 */       ensureParameterAnnotationsRetrieved();
/* 629 */       determineParameterNames();
/*     */       
/* 631 */       this.method = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 637 */     if ((this.bitflags & 0x1) == 0) {
/* 638 */       workOutIfSynthetic();
/*     */     }
/* 640 */     return ((this.bitflags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void workOutIfSynthetic() {
/* 646 */     if ((this.bitflags & 0x1) != 0) {
/*     */       return;
/*     */     }
/* 649 */     this.bitflags |= 0x1;
/* 650 */     JavaClass jc = this.bcelObjectType.getJavaClass();
/* 651 */     this.bitflags &= 0x7F7F;
/* 652 */     if (jc == null) {
/*     */       return;
/*     */     }
/* 655 */     if (jc.getMajor() < 49) {
/*     */       
/* 657 */       String[] synthetics = getAttributeNames(false);
/* 658 */       if (synthetics != null) {
/* 659 */         for (String synthetic : synthetics) {
/* 660 */           if (synthetic.equals("Synthetic")) {
/* 661 */             this.bitflags |= 0x80;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 668 */     } else if ((this.modifiers & 0x1000) != 0) {
/* 669 */       this.bitflags |= 0x80;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquivalentTo(Object other) {
/* 685 */     if (!(other instanceof BcelMethod)) {
/* 686 */       return false;
/*     */     }
/* 688 */     BcelMethod o = (BcelMethod)other;
/* 689 */     return getMethod().getCode().getCodeString().equals(o.getMethod().getCode().getCodeString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultConstructor() {
/* 700 */     boolean mightBe = (!hasDeclarationLineNumberInfo() && this.name.equals("<init>") && this.parameterTypes.length == 0);
/* 701 */     if (mightBe)
/*     */     {
/*     */       
/* 704 */       return true;
/*     */     }
/* 706 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */