/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.util.ClassLoaderReference;
/*    */ import org.aspectj.weaver.WeakClassLoaderReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelWeakClassLoaderReference
/*    */   extends WeakClassLoaderReference
/*    */   implements ClassLoaderReference
/*    */ {
/*    */   public BcelWeakClassLoaderReference(ClassLoader loader) {
/* 39 */     super(loader);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 43 */     if (!(obj instanceof BcelWeakClassLoaderReference))
/* 44 */       return false; 
/* 45 */     BcelWeakClassLoaderReference other = (BcelWeakClassLoaderReference)obj;
/* 46 */     return (other.hashcode == this.hashcode);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelWeakClassLoaderReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */