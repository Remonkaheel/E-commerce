package org.aspectj.weaver.bcel;

import org.aspectj.weaver.ReferenceType;
import org.aspectj.weaver.ReferenceTypeDelegate;

public interface TypeDelegateResolver {
  ReferenceTypeDelegate getDelegate(ReferenceType paramReferenceType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\TypeDelegateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */