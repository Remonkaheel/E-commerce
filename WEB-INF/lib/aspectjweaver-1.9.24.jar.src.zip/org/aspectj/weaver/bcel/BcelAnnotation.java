/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ArrayElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.EnumElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*     */ import org.aspectj.weaver.AbstractAnnotationAJ;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BcelAnnotation
/*     */   extends AbstractAnnotationAJ
/*     */ {
/*     */   private final AnnotationGen bcelAnnotation;
/*     */   
/*     */   public BcelAnnotation(AnnotationGen theBcelAnnotation, World world) {
/*  38 */     super(UnresolvedType.forSignature(theBcelAnnotation.getTypeSignature()).resolve(world));
/*  39 */     this.bcelAnnotation = theBcelAnnotation;
/*     */   }
/*     */   
/*     */   public BcelAnnotation(AnnotationGen theBcelAnnotation, ResolvedType resolvedAnnotationType) {
/*  43 */     super(resolvedAnnotationType);
/*  44 */     this.bcelAnnotation = theBcelAnnotation;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  48 */     StringBuilder sb = new StringBuilder();
/*  49 */     List<NameValuePair> nvPairs = this.bcelAnnotation.getValues();
/*  50 */     sb.append("Anno[" + getTypeSignature() + " " + (isRuntimeVisible() ? "rVis" : "rInvis"));
/*  51 */     if (nvPairs.size() > 0) {
/*  52 */       sb.append(" ");
/*  53 */       int i = 0;
/*  54 */       for (NameValuePair element : nvPairs) {
/*  55 */         if (i > 0) {
/*  56 */           sb.append(',');
/*     */         }
/*  58 */         sb.append(element.getNameString()).append("=").append(element.getValue().toString());
/*  59 */         i++;
/*     */       } 
/*     */     } 
/*  62 */     sb.append("]");
/*  63 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getTargets() {
/*  71 */     if (!this.type.equals(UnresolvedType.AT_TARGET)) {
/*  72 */       return Collections.emptySet();
/*     */     }
/*  74 */     List<NameValuePair> values = this.bcelAnnotation.getValues();
/*  75 */     NameValuePair envp = values.get(0);
/*  76 */     ArrayElementValue aev = (ArrayElementValue)envp.getValue();
/*  77 */     ElementValue[] evs = aev.getElementValuesArray();
/*  78 */     Set<String> targets = new HashSet<>();
/*  79 */     for (ElementValue elementValue : evs) {
/*  80 */       EnumElementValue ev = (EnumElementValue)elementValue;
/*  81 */       targets.add(ev.getEnumValueString());
/*     */     } 
/*  83 */     return targets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNameValuePair(String name, String value) {
/*  91 */     return this.bcelAnnotation.hasNameValuePair(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNamedValue(String name) {
/*  99 */     return this.bcelAnnotation.hasNamedValue(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String stringify() {
/* 107 */     StringBuilder sb = new StringBuilder();
/* 108 */     sb.append("@").append(this.type.getClassName());
/* 109 */     List<NameValuePair> values = this.bcelAnnotation.getValues();
/* 110 */     if (values != null && values.size() != 0) {
/* 111 */       sb.append("(");
/* 112 */       for (NameValuePair nvPair : values) {
/* 113 */         sb.append(nvPair.getNameString()).append("=").append(nvPair.getValue().stringifyValue());
/*     */       }
/* 115 */       sb.append(")");
/*     */     } 
/* 117 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRuntimeVisible() {
/* 125 */     return this.bcelAnnotation.isRuntimeVisible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationGen getBcelAnnotation() {
/* 132 */     return this.bcelAnnotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringFormOfValue(String name) {
/* 139 */     List<NameValuePair> annotationValues = this.bcelAnnotation.getValues();
/* 140 */     if (annotationValues == null || annotationValues.size() == 0) {
/* 141 */       return null;
/*     */     }
/* 143 */     for (NameValuePair nvPair : annotationValues) {
/* 144 */       if (nvPair.getNameString().equals(name)) {
/* 145 */         return nvPair.getValue().stringifyValue();
/*     */       }
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */