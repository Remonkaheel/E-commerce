/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.generic.FieldGen;
/*    */ import org.aspectj.apache.bcel.generic.Instruction;
/*    */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*    */ import org.aspectj.apache.bcel.generic.InstructionList;
/*    */ import org.aspectj.apache.bcel.generic.Type;
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedMember;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.ResolvedTypeMunger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelCflowStackFieldAdder
/*    */   extends BcelTypeMunger
/*    */ {
/*    */   private ResolvedMember cflowStackField;
/*    */   
/*    */   public BcelCflowStackFieldAdder(ResolvedMember cflowStackField) {
/* 29 */     super((ResolvedTypeMunger)null, (ResolvedType)cflowStackField.getDeclaringType());
/* 30 */     this.cflowStackField = cflowStackField;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean munge(BcelClassWeaver weaver) {
/* 35 */     LazyClassGen gen = weaver.getLazyClassGen();
/* 36 */     if (!gen.getType().equals(this.cflowStackField.getDeclaringType())) {
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     FieldGen f = new FieldGen(this.cflowStackField.getModifiers(), BcelWorld.makeBcelType(this.cflowStackField.getReturnType()), this.cflowStackField.getName(), gen.getConstantPool());
/* 41 */     gen.addField(f, getSourceLocation());
/*    */     
/* 43 */     LazyMethodGen clinit = gen.getAjcPreClinit();
/* 44 */     InstructionList setup = new InstructionList();
/* 45 */     InstructionFactory fact = gen.getFactory();
/*    */     
/* 47 */     setup.append(fact.createNew("org.aspectj.runtime.internal.CFlowStack"));
/* 48 */     setup.append(InstructionFactory.createDup(1));
/* 49 */     setup.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.CFlowStack", "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/*    */     
/* 51 */     setup.append(Utility.createSet(fact, (Member)this.cflowStackField));
/* 52 */     clinit.getBody().insert(setup);
/*    */     
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResolvedMember getMatchingSyntheticMember(Member member) {
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResolvedMember getSignature() {
/* 64 */     return this.cflowStackField;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(ResolvedType onType) {
/* 69 */     return onType.equals(this.cflowStackField.getDeclaringType());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean existsToSupportShadowMunging() {
/* 74 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelCflowStackFieldAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */