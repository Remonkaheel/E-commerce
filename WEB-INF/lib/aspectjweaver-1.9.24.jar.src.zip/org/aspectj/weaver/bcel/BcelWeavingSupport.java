/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.weaver.Advice;
/*    */ import org.aspectj.weaver.AjAttribute;
/*    */ import org.aspectj.weaver.ConcreteTypeMunger;
/*    */ import org.aspectj.weaver.IWeavingSupport;
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedMember;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.ResolvedTypeMunger;
/*    */ import org.aspectj.weaver.ast.Var;
/*    */ import org.aspectj.weaver.patterns.PerClause;
/*    */ import org.aspectj.weaver.patterns.Pointcut;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelWeavingSupport
/*    */   implements IWeavingSupport
/*    */ {
/*    */   public Advice createAdviceMunger(AjAttribute.AdviceAttribute attribute, Pointcut pointcut, Member signature, ResolvedType concreteAspect) {
/* 37 */     return new BcelAdvice(attribute, pointcut, signature, concreteAspect);
/*    */   }
/*    */   
/*    */   public ConcreteTypeMunger makeCflowStackFieldAdder(ResolvedMember cflowField) {
/* 41 */     return new BcelCflowStackFieldAdder(cflowField);
/*    */   }
/*    */   
/*    */   public ConcreteTypeMunger makeCflowCounterFieldAdder(ResolvedMember cflowField) {
/* 45 */     return new BcelCflowCounterFieldAdder(cflowField);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConcreteTypeMunger makePerClauseAspect(ResolvedType aspect, PerClause.Kind kind) {
/* 56 */     return new BcelPerClauseAspectAdder(aspect, kind);
/*    */   }
/*    */   
/*    */   public Var makeCflowAccessVar(ResolvedType formalType, Member cflowField, int arrayIndex) {
/* 60 */     return new BcelCflowAccessVar(formalType, cflowField, arrayIndex);
/*    */   }
/*    */   
/*    */   public ConcreteTypeMunger concreteTypeMunger(ResolvedTypeMunger munger, ResolvedType aspectType) {
/* 64 */     return new BcelTypeMunger(munger, aspectType);
/*    */   }
/*    */   
/*    */   public ConcreteTypeMunger createAccessForInlineMunger(ResolvedType aspect) {
/* 68 */     return new BcelAccessForInlineMunger(aspect);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelWeavingSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */