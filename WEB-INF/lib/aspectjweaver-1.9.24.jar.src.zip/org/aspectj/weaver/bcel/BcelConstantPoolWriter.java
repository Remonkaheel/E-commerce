/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ import org.aspectj.weaver.ConstantPoolWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BcelConstantPoolWriter
/*    */   implements ConstantPoolWriter
/*    */ {
/*    */   ConstantPool pool;
/*    */   
/*    */   public BcelConstantPoolWriter(ConstantPool pool) {
/* 27 */     this.pool = pool;
/*    */   }
/*    */   
/*    */   public int writeUtf8(String name) {
/* 31 */     return this.pool.addUtf8(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelConstantPoolWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */