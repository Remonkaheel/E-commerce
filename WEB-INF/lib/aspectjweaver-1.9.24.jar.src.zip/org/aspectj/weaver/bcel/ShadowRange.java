/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.generic.BranchHandle;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionBranch;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionLV;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.InstructionSelect;
/*     */ import org.aspectj.apache.bcel.generic.InstructionTargeter;
/*     */ import org.aspectj.apache.bcel.generic.LocalVariableTag;
/*     */ import org.aspectj.apache.bcel.generic.TargetLostException;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ShadowRange
/*     */   extends Range
/*     */ {
/*     */   private BcelShadow shadow;
/*     */   
/*     */   public ShadowRange(InstructionList body) {
/*  41 */     super(body);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void associateWithTargets(InstructionHandle start, InstructionHandle end) {
/*  46 */     this.start = start;
/*  47 */     this.end = end;
/*  48 */     start.addTargeter(this);
/*  49 */     end.addTargeter(this);
/*     */   }
/*     */   
/*     */   public void associateWithShadow(BcelShadow shadow) {
/*  53 */     this.shadow = shadow;
/*  54 */     shadow.setRange(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Shadow.Kind getKind() {
/*  60 */     return this.shadow.getKind();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  65 */     return this.shadow.toString();
/*     */   }
/*     */   
/*     */   void extractInstructionsInto(LazyMethodGen freshMethod, IntMap remap, boolean addReturn) {
/*  69 */     LazyMethodGen.assertGoodBody(getBody(), toString());
/*  70 */     freshMethod.assertGoodBody();
/*  71 */     InstructionList freshBody = freshMethod.getBody();
/*     */     
/*  73 */     for (InstructionHandle oldIh = this.start.getNext(); oldIh != this.end; oldIh = oldIh.getNext()) {
/*     */       InstructionHandle freshIh;
/*  75 */       Instruction oldI = oldIh.getInstruction();
/*  76 */       Instruction freshI = (oldI == RANGEINSTRUCTION) ? oldI : Utility.copyInstruction(oldI);
/*     */ 
/*     */ 
/*     */       
/*  80 */       if (freshI instanceof InstructionBranch) {
/*     */ 
/*     */         
/*  83 */         InstructionBranch oldBranch = (InstructionBranch)oldI;
/*  84 */         InstructionBranch freshBranch = (InstructionBranch)freshI;
/*  85 */         InstructionHandle oldTarget = oldBranch.getTarget();
/*  86 */         oldTarget.removeTargeter((InstructionTargeter)oldBranch);
/*  87 */         oldTarget.addTargeter((InstructionTargeter)freshBranch);
/*  88 */         if (freshBranch instanceof InstructionSelect) {
/*  89 */           InstructionSelect oldSelect = (InstructionSelect)oldI;
/*  90 */           InstructionSelect freshSelect = (InstructionSelect)freshI;
/*  91 */           InstructionHandle[] oldTargets = freshSelect.getTargets();
/*  92 */           for (int k = oldTargets.length - 1; k >= 0; k--) {
/*  93 */             oldTargets[k].removeTargeter((InstructionTargeter)oldSelect);
/*  94 */             oldTargets[k].addTargeter((InstructionTargeter)freshSelect);
/*     */           } 
/*     */         } 
/*  97 */         BranchHandle branchHandle = freshBody.append(freshBranch);
/*     */       } else {
/*  99 */         freshIh = freshBody.append(freshI);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       for (InstructionTargeter source : oldIh.getTargetersCopy()) {
/* 128 */         if (source instanceof LocalVariableTag) {
/* 129 */           Shadow.Kind kind = getKind();
/* 130 */           if (kind == Shadow.AdviceExecution || kind == Shadow.ConstructorExecution || kind == Shadow.MethodExecution || kind == Shadow.PreInitialization || kind == Shadow.Initialization || kind == Shadow.StaticInitialization) {
/*     */ 
/*     */             
/* 133 */             LocalVariableTag sourceLocalVariableTag = (LocalVariableTag)source;
/* 134 */             if (sourceLocalVariableTag.getSlot() == 0)
/*     */             {
/* 136 */               if (sourceLocalVariableTag.getName().equals("this")) {
/* 137 */                 sourceLocalVariableTag.setName("ajc$this");
/*     */               }
/*     */             }
/*     */             
/* 141 */             source.updateTarget(oldIh, freshIh);
/*     */             
/*     */             continue;
/*     */           } 
/* 145 */           source.updateTarget(oldIh, null); continue;
/*     */         } 
/* 147 */         if (source instanceof Range) {
/*     */           
/* 149 */           ((Range)source).updateTarget(oldIh, freshIh, freshBody);
/*     */           
/*     */           continue;
/*     */         } 
/* 153 */         source.updateTarget(oldIh, freshIh);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       if (freshI.isLocalVariableInstruction() || freshI instanceof org.aspectj.apache.bcel.generic.RET) {
/*     */         
/* 167 */         int freshIndex, oldIndex = freshI.getIndex();
/*     */         
/* 169 */         if (!remap.hasKey(oldIndex)) {
/* 170 */           freshIndex = freshMethod.allocateLocal(2);
/* 171 */           remap.put(oldIndex, freshIndex);
/*     */         } else {
/* 173 */           freshIndex = remap.get(oldIndex);
/*     */         } 
/* 175 */         if (freshI instanceof org.aspectj.apache.bcel.generic.RET) {
/* 176 */           freshI.setIndex(freshIndex);
/*     */         } else {
/* 178 */           InstructionLV instructionLV = ((InstructionLV)freshI).setIndexAndCopyIfNecessary(freshIndex);
/* 179 */           freshIh.setInstruction((Instruction)instructionLV);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     for (InstructionHandle newIh = freshBody.getStart(); newIh != freshBody.getEnd(); newIh = newIh.getNext()) {
/* 191 */       for (InstructionTargeter source : newIh.getTargeters()) {
/* 192 */         if (source instanceof LocalVariableTag) {
/* 193 */           LocalVariableTag lvt = (LocalVariableTag)source;
/* 194 */           if (!lvt.isRemapped() && remap.hasKey(lvt.getSlot())) {
/* 195 */             lvt.updateSlot(remap.get(lvt.getSlot()));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 205 */       for (InstructionHandle instructionHandle = this.start.getNext(); instructionHandle != this.end; ) {
/* 206 */         InstructionHandle next = instructionHandle.getNext();
/* 207 */         this.body.delete(instructionHandle);
/* 208 */         instructionHandle = next;
/*     */       } 
/* 210 */     } catch (TargetLostException e) {
/* 211 */       throw new BCException("shouldn't have gotten a target lost");
/*     */     } 
/*     */ 
/*     */     
/* 215 */     InstructionHandle ret = null;
/* 216 */     if (addReturn)
/*     */     {
/* 218 */       ret = freshBody.append(InstructionFactory.createReturn(freshMethod.getReturnType()));
/*     */     }
/*     */     
/* 221 */     for (InstructionTargeter t : this.end.getTargetersCopy()) {
/* 222 */       if (t == this) {
/*     */         continue;
/*     */       }
/* 225 */       if (!addReturn) {
/* 226 */         throw new BCException("range has target, but we aren't adding a return");
/*     */       }
/* 228 */       t.updateTarget(this.end, ret);
/*     */     } 
/*     */ 
/*     */     
/* 232 */     LazyMethodGen.assertGoodBody(getBody(), toString());
/* 233 */     freshMethod.assertGoodBody();
/*     */   }
/*     */   
/*     */   public BcelShadow getShadow() {
/* 237 */     return this.shadow;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\ShadowRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */