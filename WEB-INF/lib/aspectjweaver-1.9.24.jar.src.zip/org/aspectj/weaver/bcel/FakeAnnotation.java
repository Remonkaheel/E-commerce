/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*    */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FakeAnnotation
/*    */   extends AnnotationGen
/*    */ {
/*    */   private String name;
/*    */   private String sig;
/*    */   private boolean isRuntimeVisible;
/*    */   
/*    */   public FakeAnnotation(String name, String sig, boolean isRuntimeVisible) {
/* 36 */     super(null, null, true, null);
/* 37 */     this.name = name;
/* 38 */     this.sig = sig;
/* 39 */     this.isRuntimeVisible = isRuntimeVisible;
/*    */   }
/*    */   
/*    */   public String getTypeName() {
/* 43 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getTypeSignature() {
/* 47 */     return this.sig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addElementNameValuePair(NameValuePair evp) {}
/*    */ 
/*    */   
/*    */   public void dump(DataOutputStream dos) throws IOException {}
/*    */ 
/*    */   
/*    */   public int getTypeIndex() {
/* 59 */     return 0;
/*    */   }
/*    */   
/*    */   public List getValues() {
/* 63 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isRuntimeVisible() {
/* 67 */     return this.isRuntimeVisible;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setIsRuntimeVisible(boolean b) {}
/*    */   
/*    */   public String toShortString() {
/* 74 */     return "@" + this.name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 78 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\FakeAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */