/*      */ package org.aspectj.weaver.bcel;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import org.aspectj.apache.bcel.classfile.Attribute;
/*      */ import org.aspectj.apache.bcel.classfile.AttributeUtils;
/*      */ import org.aspectj.apache.bcel.classfile.ConstantClass;
/*      */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*      */ import org.aspectj.apache.bcel.classfile.EnclosingMethod;
/*      */ import org.aspectj.apache.bcel.classfile.Field;
/*      */ import org.aspectj.apache.bcel.classfile.InnerClass;
/*      */ import org.aspectj.apache.bcel.classfile.InnerClasses;
/*      */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*      */ import org.aspectj.apache.bcel.classfile.Method;
/*      */ import org.aspectj.apache.bcel.classfile.Signature;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.EnumElementValue;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*      */ import org.aspectj.asm.AsmManager;
/*      */ import org.aspectj.bridge.IMessageHandler;
/*      */ import org.aspectj.bridge.MessageUtil;
/*      */ import org.aspectj.util.GenericSignature;
/*      */ import org.aspectj.weaver.AbstractReferenceTypeDelegate;
/*      */ import org.aspectj.weaver.AjAttribute;
/*      */ import org.aspectj.weaver.AjcMemberMaker;
/*      */ import org.aspectj.weaver.AnnotationAJ;
/*      */ import org.aspectj.weaver.AnnotationTargetKind;
/*      */ import org.aspectj.weaver.BCException;
/*      */ import org.aspectj.weaver.BindingScope;
/*      */ import org.aspectj.weaver.ConcreteTypeMunger;
/*      */ import org.aspectj.weaver.ISourceContext;
/*      */ import org.aspectj.weaver.ReferenceType;
/*      */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*      */ import org.aspectj.weaver.ResolvedMember;
/*      */ import org.aspectj.weaver.ResolvedPointcutDefinition;
/*      */ import org.aspectj.weaver.ResolvedType;
/*      */ import org.aspectj.weaver.SourceContextImpl;
/*      */ import org.aspectj.weaver.TypeVariable;
/*      */ import org.aspectj.weaver.UnresolvedType;
/*      */ import org.aspectj.weaver.WeaverStateInfo;
/*      */ import org.aspectj.weaver.World;
/*      */ import org.aspectj.weaver.patterns.Declare;
/*      */ import org.aspectj.weaver.patterns.DeclarePrecedence;
/*      */ import org.aspectj.weaver.patterns.FormalBinding;
/*      */ import org.aspectj.weaver.patterns.IScope;
/*      */ import org.aspectj.weaver.patterns.PerClause;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BcelObjectType
/*      */   extends AbstractReferenceTypeDelegate
/*      */ {
/*      */   public JavaClass javaClass;
/*      */   private boolean artificial;
/*   74 */   private LazyClassGen lazyClassGen = null;
/*      */   
/*      */   private int modifiers;
/*      */   
/*      */   private String className;
/*      */   
/*      */   private String superclassSignature;
/*      */   private String superclassName;
/*      */   private String[] interfaceSignatures;
/*   83 */   private ResolvedMember[] fields = null;
/*   84 */   private ResolvedMember[] methods = null;
/*   85 */   private ResolvedType[] annotationTypes = null;
/*   86 */   private AnnotationAJ[] annotations = null;
/*   87 */   private TypeVariable[] typeVars = null;
/*      */   
/*      */   private String retentionPolicy;
/*      */   
/*      */   private AnnotationTargetKind[] annotationTargetKinds;
/*   92 */   private AjAttribute.WeaverVersionInfo wvInfo = AjAttribute.WeaverVersionInfo.UNKNOWN;
/*   93 */   private ResolvedPointcutDefinition[] pointcuts = null;
/*   94 */   private ResolvedMember[] privilegedAccess = null;
/*   95 */   private WeaverStateInfo weaverState = null;
/*   96 */   private PerClause perClause = null;
/*   97 */   private List<ConcreteTypeMunger> typeMungers = Collections.emptyList();
/*   98 */   private List<Declare> declares = Collections.emptyList();
/*      */   
/*  100 */   private GenericSignature.FormalTypeParameter[] formalsForResolution = null;
/*  101 */   private String declaredSignature = null;
/*      */   
/*      */   private boolean hasBeenWoven = false;
/*      */   
/*      */   private boolean isGenericType = false;
/*      */   
/*      */   private boolean isInterface;
/*      */   private boolean isEnum;
/*      */   private boolean isAnnotation;
/*      */   private boolean isAnonymous;
/*      */   private boolean isNested;
/*      */   private boolean isObject = false;
/*      */   private boolean isAnnotationStyleAspect = false;
/*      */   private boolean isCodeStyleAspect = false;
/*  115 */   private WeakReference<ResolvedType> superTypeReference = new WeakReference<>(null);
/*  116 */   private WeakReference<ResolvedType[]> superInterfaceReferences = (WeakReference)new WeakReference<>(null);
/*      */   
/*  118 */   private int bitflag = 0;
/*      */   
/*      */   private static final int DISCOVERED_ANNOTATION_RETENTION_POLICY = 1;
/*      */   
/*      */   private static final int UNPACKED_GENERIC_SIGNATURE = 2;
/*      */   
/*      */   private static final int UNPACKED_AJATTRIBUTES = 4;
/*      */   
/*      */   private static final int DISCOVERED_ANNOTATION_TARGET_KINDS = 8;
/*      */   
/*      */   private static final int DISCOVERED_DECLARED_SIGNATURE = 16;
/*      */   private static final int DISCOVERED_WHETHER_ANNOTATION_STYLE = 32;
/*      */   private static final int ANNOTATION_UNPACK_IN_PROGRESS = 256;
/*  131 */   private static final String[] NO_INTERFACE_SIGS = new String[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BcelObjectType(ReferenceType resolvedTypeX, JavaClass javaClass, boolean artificial, boolean exposedToWeaver) {
/*  142 */     super(resolvedTypeX, exposedToWeaver);
/*  143 */     this.javaClass = javaClass;
/*  144 */     this.artificial = artificial;
/*  145 */     initializeFromJavaclass();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  150 */     resolvedTypeX.setDelegate((ReferenceTypeDelegate)this);
/*      */     
/*  152 */     ISourceContext sourceContext = resolvedTypeX.getSourceContext();
/*  153 */     if (sourceContext == SourceContextImpl.UNKNOWN_SOURCE_CONTEXT) {
/*  154 */       SourceContextImpl sourceContextImpl = new SourceContextImpl(this);
/*  155 */       setSourceContext((ISourceContext)sourceContextImpl);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  160 */     this.isObject = (javaClass.getSuperclassNameIndex() == 0);
/*  161 */     ensureAspectJAttributesUnpacked();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     setSourcefilename(javaClass.getSourceFileName());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setJavaClass(JavaClass newclass, boolean artificial) {
/*  180 */     this.javaClass = newclass;
/*  181 */     this.artificial = artificial;
/*  182 */     resetState();
/*  183 */     initializeFromJavaclass();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCacheable() {
/*  188 */     return true;
/*      */   }
/*      */   
/*      */   private void initializeFromJavaclass() {
/*  192 */     this.isInterface = this.javaClass.isInterface();
/*  193 */     this.isEnum = this.javaClass.isEnum();
/*  194 */     this.isAnnotation = this.javaClass.isAnnotation();
/*  195 */     this.isAnonymous = this.javaClass.isAnonymous();
/*  196 */     this.isNested = this.javaClass.isNested();
/*  197 */     this.modifiers = this.javaClass.getModifiers();
/*  198 */     this.superclassName = this.javaClass.getSuperclassName();
/*  199 */     this.className = this.javaClass.getClassName();
/*  200 */     this.cachedGenericClassTypeSignature = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInterface() {
/*  207 */     return this.isInterface;
/*      */   }
/*      */   
/*      */   public boolean isEnum() {
/*  211 */     return this.isEnum;
/*      */   }
/*      */   
/*      */   public boolean isAnnotation() {
/*  215 */     return this.isAnnotation;
/*      */   }
/*      */   
/*      */   public boolean isAnonymous() {
/*  219 */     return this.isAnonymous;
/*      */   }
/*      */   
/*      */   public boolean isNested() {
/*  223 */     return this.isNested;
/*      */   }
/*      */   
/*      */   public int getModifiers() {
/*  227 */     return this.modifiers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolvedType getSuperclass() {
/*  234 */     if (this.isObject) {
/*  235 */       return null;
/*      */     }
/*  237 */     ResolvedType supertype = this.superTypeReference.get();
/*  238 */     if (supertype == null) {
/*  239 */       ensureGenericSignatureUnpacked();
/*  240 */       if (this.superclassSignature == null) {
/*  241 */         if (this.superclassName == null) {
/*  242 */           this.superclassName = this.javaClass.getSuperclassName();
/*      */         }
/*  244 */         this.superclassSignature = getResolvedTypeX().getWorld().resolve(UnresolvedType.forName(this.superclassName)).getSignature();
/*      */       } 
/*  246 */       World world = getResolvedTypeX().getWorld();
/*  247 */       supertype = world.resolve(UnresolvedType.forSignature(this.superclassSignature));
/*  248 */       this.superTypeReference = new WeakReference<>(supertype);
/*      */     } 
/*  250 */     return supertype;
/*      */   }
/*      */   
/*      */   public World getWorld() {
/*  254 */     return getResolvedTypeX().getWorld();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolvedType[] getDeclaredInterfaces() {
/*  263 */     ResolvedType[] cachedInterfaceTypes = this.superInterfaceReferences.get();
/*  264 */     if (cachedInterfaceTypes == null) {
/*  265 */       ensureGenericSignatureUnpacked();
/*  266 */       ResolvedType[] interfaceTypes = null;
/*  267 */       if (this.interfaceSignatures == null) {
/*  268 */         String[] names = this.javaClass.getInterfaceNames();
/*  269 */         if (names.length == 0) {
/*  270 */           this.interfaceSignatures = NO_INTERFACE_SIGS;
/*  271 */           interfaceTypes = ResolvedType.NONE;
/*      */         } else {
/*  273 */           this.interfaceSignatures = new String[names.length];
/*  274 */           interfaceTypes = new ResolvedType[names.length];
/*  275 */           for (int i = 0, len = names.length; i < len; i++) {
/*  276 */             interfaceTypes[i] = getResolvedTypeX().getWorld().resolve(UnresolvedType.forName(names[i]));
/*  277 */             this.interfaceSignatures[i] = interfaceTypes[i].getSignature();
/*      */           } 
/*      */         } 
/*      */       } else {
/*  281 */         interfaceTypes = new ResolvedType[this.interfaceSignatures.length];
/*  282 */         for (int i = 0, len = this.interfaceSignatures.length; i < len; i++) {
/*  283 */           interfaceTypes[i] = getResolvedTypeX().getWorld().resolve(UnresolvedType.forSignature(this.interfaceSignatures[i]));
/*      */         }
/*      */       } 
/*  286 */       this.superInterfaceReferences = (WeakReference)new WeakReference<>(interfaceTypes);
/*  287 */       return interfaceTypes;
/*      */     } 
/*  289 */     return cachedInterfaceTypes;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResolvedMember[] getDeclaredMethods() {
/*  294 */     ensureGenericSignatureUnpacked();
/*  295 */     if (this.methods == null) {
/*  296 */       Method[] ms = this.javaClass.getMethods();
/*  297 */       ResolvedMember[] newMethods = new ResolvedMember[ms.length];
/*  298 */       for (int i = ms.length - 1; i >= 0; i--) {
/*  299 */         newMethods[i] = (ResolvedMember)new BcelMethod(this, ms[i]);
/*      */       }
/*  301 */       this.methods = newMethods;
/*      */     } 
/*  303 */     return this.methods;
/*      */   }
/*      */   
/*      */   public ResolvedMember[] getDeclaredFields() {
/*  307 */     ensureGenericSignatureUnpacked();
/*  308 */     if (this.fields == null) {
/*  309 */       Field[] fs = this.javaClass.getFields();
/*  310 */       ResolvedMember[] newfields = new ResolvedMember[fs.length];
/*  311 */       for (int i = 0, len = fs.length; i < len; i++) {
/*  312 */         newfields[i] = (ResolvedMember)new BcelField(this, fs[i]);
/*      */       }
/*  314 */       this.fields = newfields;
/*      */     } 
/*  316 */     return this.fields;
/*      */   }
/*      */   
/*      */   public TypeVariable[] getTypeVariables() {
/*  320 */     if (!isGeneric()) {
/*  321 */       return TypeVariable.NONE;
/*      */     }
/*      */     
/*  324 */     if (this.typeVars == null) {
/*  325 */       GenericSignature.ClassSignature classSig = getGenericClassTypeSignature();
/*  326 */       this.typeVars = new TypeVariable[classSig.formalTypeParameters.length];
/*  327 */       for (int i = 0; i < this.typeVars.length; i++) {
/*  328 */         GenericSignature.FormalTypeParameter ftp = classSig.formalTypeParameters[i];
/*      */         try {
/*  330 */           this.typeVars[i] = BcelGenericSignatureToTypeXConverter.formalTypeParameter2TypeVariable(ftp, classSig.formalTypeParameters, 
/*  331 */               getResolvedTypeX().getWorld());
/*  332 */         } catch (GenericSignatureFormatException e) {
/*      */           
/*  334 */           throw new IllegalStateException("While getting the type variables for type " + toString() + " with generic signature " + classSig + " the following error condition was detected: " + e
/*      */               
/*  336 */               .getMessage());
/*      */         } 
/*      */       } 
/*      */     } 
/*  340 */     return this.typeVars;
/*      */   }
/*      */   
/*      */   public Collection<ConcreteTypeMunger> getTypeMungers() {
/*  344 */     return this.typeMungers;
/*      */   }
/*      */   
/*      */   public Collection<Declare> getDeclares() {
/*  348 */     return this.declares;
/*      */   }
/*      */   
/*      */   public Collection<ResolvedMember> getPrivilegedAccesses() {
/*  352 */     if (this.privilegedAccess == null) {
/*  353 */       return Collections.emptyList();
/*      */     }
/*  355 */     return Arrays.asList(this.privilegedAccess);
/*      */   }
/*      */   
/*      */   public ResolvedMember[] getDeclaredPointcuts() {
/*  359 */     return (ResolvedMember[])this.pointcuts;
/*      */   }
/*      */   
/*      */   public boolean isAspect() {
/*  363 */     return (this.perClause != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAnnotationStyleAspect() {
/*  372 */     if ((this.bitflag & 0x20) == 0) {
/*  373 */       this.bitflag |= 0x20;
/*  374 */       this.isAnnotationStyleAspect = (!this.isCodeStyleAspect && hasAnnotation(AjcMemberMaker.ASPECT_ANNOTATION));
/*      */     } 
/*  376 */     return this.isAnnotationStyleAspect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ensureAspectJAttributesUnpacked() {
/*  383 */     if ((this.bitflag & 0x4) != 0) {
/*      */       return;
/*      */     }
/*  386 */     this.bitflag |= 0x4;
/*  387 */     IMessageHandler msgHandler = getResolvedTypeX().getWorld().getMessageHandler();
/*      */     
/*  389 */     List<AjAttribute> l = null;
/*      */     try {
/*  391 */       l = Utility.readAjAttributes(this.className, this.javaClass.getAttributes(), getResolvedTypeX().getSourceContext(), 
/*  392 */           getResolvedTypeX().getWorld(), AjAttribute.WeaverVersionInfo.UNKNOWN, new BcelConstantPoolReader(this.javaClass
/*  393 */             .getConstantPool()));
/*  394 */     } catch (RuntimeException re) {
/*  395 */       throw new RuntimeException("Problem processing attributes in " + this.javaClass.getFileName(), re);
/*      */     } 
/*  397 */     List<ResolvedPointcutDefinition> pointcuts = new ArrayList<>();
/*  398 */     this.typeMungers = new ArrayList<>();
/*  399 */     this.declares = new ArrayList<>();
/*  400 */     processAttributes(l, pointcuts, false);
/*  401 */     ReferenceType type = getResolvedTypeX();
/*  402 */     AsmManager asmManager = ((BcelWorld)type.getWorld()).getModelAsAsmManager();
/*  403 */     l = AtAjAttributes.readAj5ClassAttributes(asmManager, this.javaClass, type, type.getSourceContext(), msgHandler, this.isCodeStyleAspect);
/*      */     
/*  405 */     AjAttribute.Aspect deferredAspectAttribute = processAttributes(l, pointcuts, true);
/*      */     
/*  407 */     if (pointcuts.size() == 0) {
/*  408 */       this.pointcuts = ResolvedPointcutDefinition.NO_POINTCUTS;
/*      */     } else {
/*  410 */       this.pointcuts = pointcuts.<ResolvedPointcutDefinition>toArray(ResolvedPointcutDefinition.NO_POINTCUTS);
/*      */     } 
/*      */     
/*  413 */     resolveAnnotationDeclares(l);
/*      */     
/*  415 */     if (deferredAspectAttribute != null)
/*      */     {
/*  417 */       this.perClause = deferredAspectAttribute.reifyFromAtAspectJ((ResolvedType)getResolvedTypeX());
/*      */     }
/*  419 */     if (isAspect() && !Modifier.isAbstract(getModifiers()) && isGeneric()) {
/*  420 */       msgHandler.handleMessage(MessageUtil.error("The generic aspect '" + getResolvedTypeX().getName() + "' must be declared abstract", 
/*  421 */             getResolvedTypeX().getSourceLocation()));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private AjAttribute.Aspect processAttributes(List<AjAttribute> attributeList, List<ResolvedPointcutDefinition> pointcuts, boolean fromAnnotations) {
/*  428 */     AjAttribute.Aspect deferredAspectAttribute = null;
/*  429 */     for (AjAttribute a : attributeList) {
/*  430 */       if (a instanceof AjAttribute.Aspect) {
/*  431 */         if (fromAnnotations) {
/*  432 */           deferredAspectAttribute = (AjAttribute.Aspect)a; continue;
/*      */         } 
/*  434 */         this.perClause = ((AjAttribute.Aspect)a).reify((ResolvedType)getResolvedTypeX());
/*  435 */         this.isCodeStyleAspect = true; continue;
/*      */       } 
/*  437 */       if (a instanceof AjAttribute.PointcutDeclarationAttribute) {
/*  438 */         pointcuts.add(((AjAttribute.PointcutDeclarationAttribute)a).reify()); continue;
/*  439 */       }  if (a instanceof AjAttribute.WeaverState) {
/*  440 */         this.weaverState = ((AjAttribute.WeaverState)a).reify(); continue;
/*  441 */       }  if (a instanceof AjAttribute.TypeMunger) {
/*  442 */         this.typeMungers.add(((AjAttribute.TypeMunger)a).reify(getResolvedTypeX().getWorld(), (ResolvedType)getResolvedTypeX())); continue;
/*  443 */       }  if (a instanceof AjAttribute.DeclareAttribute) {
/*  444 */         this.declares.add(((AjAttribute.DeclareAttribute)a).getDeclare()); continue;
/*  445 */       }  if (a instanceof AjAttribute.PrivilegedAttribute) {
/*  446 */         AjAttribute.PrivilegedAttribute privAttribute = (AjAttribute.PrivilegedAttribute)a;
/*  447 */         this.privilegedAccess = privAttribute.getAccessedMembers(); continue;
/*  448 */       }  if (a instanceof AjAttribute.SourceContextAttribute) {
/*  449 */         if (getResolvedTypeX().getSourceContext() instanceof SourceContextImpl) {
/*  450 */           AjAttribute.SourceContextAttribute sca = (AjAttribute.SourceContextAttribute)a;
/*  451 */           ((SourceContextImpl)getResolvedTypeX().getSourceContext()).configureFromAttribute(sca.getSourceFileName(), sca
/*  452 */               .getLineBreaks());
/*      */           
/*  454 */           setSourcefilename(sca.getSourceFileName());
/*      */         }  continue;
/*  456 */       }  if (a instanceof AjAttribute.WeaverVersionInfo) {
/*      */         
/*  458 */         this.wvInfo = (AjAttribute.WeaverVersionInfo)a; continue;
/*      */       } 
/*  460 */       throw new BCException("bad attribute " + a);
/*      */     } 
/*      */     
/*  463 */     return deferredAspectAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveAnnotationDeclares(List<AjAttribute> attributeList) {
/*  471 */     FormalBinding[] bindings = FormalBinding.NONE;
/*  472 */     BindingScope bindingScope = new BindingScope((ResolvedType)getResolvedTypeX(), getResolvedTypeX().getSourceContext(), bindings);
/*  473 */     for (AjAttribute a : attributeList) {
/*  474 */       if (a instanceof AjAttribute.DeclareAttribute) {
/*  475 */         Declare decl = ((AjAttribute.DeclareAttribute)a).getDeclare();
/*  476 */         if (decl instanceof org.aspectj.weaver.patterns.DeclareErrorOrWarning) {
/*  477 */           decl.resolve((IScope)bindingScope); continue;
/*  478 */         }  if (decl instanceof DeclarePrecedence) {
/*  479 */           ((DeclarePrecedence)decl).setScopeForResolution((IScope)bindingScope);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public PerClause getPerClause() {
/*  486 */     ensureAspectJAttributesUnpacked();
/*  487 */     return this.perClause;
/*      */   }
/*      */   
/*      */   public JavaClass getJavaClass() {
/*  491 */     return this.javaClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isArtificial() {
/*  498 */     return this.artificial;
/*      */   }
/*      */   
/*      */   public void resetState() {
/*  502 */     if (this.javaClass == null)
/*      */     {
/*      */ 
/*      */       
/*  506 */       throw new BCException("can't weave evicted type");
/*      */     }
/*      */     
/*  509 */     this.bitflag = 0;
/*      */     
/*  511 */     this.annotationTypes = null;
/*  512 */     this.annotations = null;
/*  513 */     this.interfaceSignatures = null;
/*  514 */     this.superclassSignature = null;
/*  515 */     this.superclassName = null;
/*  516 */     this.fields = null;
/*  517 */     this.methods = null;
/*  518 */     this.pointcuts = null;
/*  519 */     this.perClause = null;
/*  520 */     this.weaverState = null;
/*  521 */     this.lazyClassGen = null;
/*  522 */     this.hasBeenWoven = false;
/*      */     
/*  524 */     this.isObject = (this.javaClass.getSuperclassNameIndex() == 0);
/*  525 */     this.isAnnotationStyleAspect = false;
/*  526 */     ensureAspectJAttributesUnpacked();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finishedWith() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WeaverStateInfo getWeaverState() {
/*  546 */     return this.weaverState;
/*      */   }
/*      */   
/*      */   void setWeaverState(WeaverStateInfo weaverState) {
/*  550 */     this.weaverState = weaverState;
/*      */   }
/*      */   
/*      */   public void printWackyStuff(PrintStream out) {
/*  554 */     if (this.typeMungers.size() > 0) {
/*  555 */       out.println("  TypeMungers: " + this.typeMungers);
/*      */     }
/*  557 */     if (this.declares.size() > 0) {
/*  558 */       out.println("     declares: " + this.declares);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LazyClassGen getLazyClassGen() {
/*  567 */     LazyClassGen ret = this.lazyClassGen;
/*  568 */     if (ret == null) {
/*      */       
/*  570 */       ret = new LazyClassGen(this);
/*      */ 
/*      */ 
/*      */       
/*  574 */       if (isAspect()) {
/*  575 */         this.lazyClassGen = ret;
/*      */       }
/*      */     } 
/*  578 */     return ret;
/*      */   }
/*      */   
/*      */   public boolean isSynthetic() {
/*  582 */     return getResolvedTypeX().isSynthetic();
/*      */   }
/*      */   
/*      */   public AjAttribute.WeaverVersionInfo getWeaverVersionAttribute() {
/*  586 */     return this.wvInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolvedType[] getAnnotationTypes() {
/*  592 */     ensureAnnotationsUnpacked();
/*  593 */     return this.annotationTypes;
/*      */   }
/*      */   
/*      */   public AnnotationAJ[] getAnnotations() {
/*  597 */     ensureAnnotationsUnpacked();
/*  598 */     return this.annotations;
/*      */   }
/*      */   
/*      */   public boolean hasAnnotations() {
/*  602 */     ensureAnnotationsUnpacked();
/*  603 */     return (this.annotations.length != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasAnnotation(UnresolvedType ofType) {
/*  609 */     if (isUnpackingAnnotations()) {
/*  610 */       AnnotationGen[] annos = this.javaClass.getAnnotations();
/*  611 */       if (annos == null || annos.length == 0) {
/*  612 */         return false;
/*      */       }
/*  614 */       String lookingForSignature = ofType.getSignature();
/*  615 */       for (AnnotationGen annotation : annos) {
/*  616 */         if (lookingForSignature.equals(annotation.getTypeSignature())) {
/*  617 */           return true;
/*      */         }
/*      */       } 
/*      */       
/*  621 */       return false;
/*      */     } 
/*  623 */     ensureAnnotationsUnpacked();
/*  624 */     for (int i = 0, max = this.annotationTypes.length; i < max; i++) {
/*  625 */       ResolvedType resolvedType = this.annotationTypes[i];
/*  626 */       if (resolvedType == null) {
/*  627 */         throw new RuntimeException("Annotation entry " + i + " on type " + getResolvedTypeX().getName() + " is null!");
/*      */       }
/*  629 */       if (resolvedType.equals(ofType)) {
/*  630 */         return true;
/*      */       }
/*      */     } 
/*  633 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isAnnotationWithRuntimeRetention() {
/*  637 */     return (getRetentionPolicy() == null) ? false : getRetentionPolicy().equals("RUNTIME");
/*      */   }
/*      */   
/*      */   public String getRetentionPolicy() {
/*  641 */     if ((this.bitflag & 0x1) == 0) {
/*  642 */       this.bitflag |= 0x1;
/*  643 */       this.retentionPolicy = null;
/*  644 */       if (isAnnotation()) {
/*  645 */         ensureAnnotationsUnpacked();
/*  646 */         for (int i = this.annotations.length - 1; i >= 0; i--) {
/*  647 */           AnnotationAJ ax = this.annotations[i];
/*  648 */           if (ax.getTypeName().equals(UnresolvedType.AT_RETENTION.getName())) {
/*  649 */             List<NameValuePair> values = ((BcelAnnotation)ax).getBcelAnnotation().getValues();
/*  650 */             Iterator<NameValuePair> iterator = values.iterator(); if (iterator.hasNext()) { NameValuePair element = iterator.next();
/*  651 */               EnumElementValue v = (EnumElementValue)element.getValue();
/*  652 */               this.retentionPolicy = v.getEnumValueString();
/*  653 */               return this.retentionPolicy; }
/*      */           
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  659 */     return this.retentionPolicy;
/*      */   }
/*      */   
/*      */   public boolean canAnnotationTargetType() {
/*  663 */     AnnotationTargetKind[] targetKinds = getAnnotationTargetKinds();
/*  664 */     if (targetKinds == null) {
/*  665 */       return true;
/*      */     }
/*  667 */     for (AnnotationTargetKind targetKind : targetKinds) {
/*  668 */       if (targetKind.equals(AnnotationTargetKind.TYPE)) {
/*  669 */         return true;
/*      */       }
/*      */     } 
/*  672 */     return false;
/*      */   }
/*      */   
/*      */   public AnnotationTargetKind[] getAnnotationTargetKinds() {
/*  676 */     if ((this.bitflag & 0x8) != 0) {
/*  677 */       return this.annotationTargetKinds;
/*      */     }
/*  679 */     this.bitflag |= 0x8;
/*  680 */     this.annotationTargetKinds = null;
/*      */     
/*  682 */     List<AnnotationTargetKind> targetKinds = new ArrayList<>();
/*  683 */     if (isAnnotation()) {
/*  684 */       AnnotationAJ[] annotationsOnThisType = getAnnotations();
/*  685 */       for (AnnotationAJ a : annotationsOnThisType) {
/*  686 */         if (a.getTypeName().equals(UnresolvedType.AT_TARGET.getName())) {
/*  687 */           Set<String> targets = a.getTargets();
/*  688 */           if (targets != null) {
/*  689 */             for (String targetKind : targets) {
/*  690 */               if (targetKind.equals("ANNOTATION_TYPE")) {
/*  691 */                 targetKinds.add(AnnotationTargetKind.ANNOTATION_TYPE); continue;
/*  692 */               }  if (targetKind.equals("CONSTRUCTOR")) {
/*  693 */                 targetKinds.add(AnnotationTargetKind.CONSTRUCTOR); continue;
/*  694 */               }  if (targetKind.equals("FIELD")) {
/*  695 */                 targetKinds.add(AnnotationTargetKind.FIELD); continue;
/*  696 */               }  if (targetKind.equals("LOCAL_VARIABLE")) {
/*  697 */                 targetKinds.add(AnnotationTargetKind.LOCAL_VARIABLE); continue;
/*  698 */               }  if (targetKind.equals("METHOD")) {
/*  699 */                 targetKinds.add(AnnotationTargetKind.METHOD); continue;
/*  700 */               }  if (targetKind.equals("PACKAGE")) {
/*  701 */                 targetKinds.add(AnnotationTargetKind.PACKAGE); continue;
/*  702 */               }  if (targetKind.equals("PARAMETER")) {
/*  703 */                 targetKinds.add(AnnotationTargetKind.PARAMETER); continue;
/*  704 */               }  if (targetKind.equals("TYPE")) {
/*  705 */                 targetKinds.add(AnnotationTargetKind.TYPE);
/*      */               }
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  711 */       if (!targetKinds.isEmpty()) {
/*  712 */         this.annotationTargetKinds = new AnnotationTargetKind[targetKinds.size()];
/*  713 */         return targetKinds.<AnnotationTargetKind>toArray(this.annotationTargetKinds);
/*      */       } 
/*      */     } 
/*  716 */     return this.annotationTargetKinds;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isUnpackingAnnotations() {
/*  722 */     return ((this.bitflag & 0x100) != 0);
/*      */   }
/*      */   
/*      */   private void ensureAnnotationsUnpacked() {
/*  726 */     if (isUnpackingAnnotations()) {
/*  727 */       throw new BCException("Re-entered weaver instance whilst unpacking annotations on " + this.className);
/*      */     }
/*  729 */     if (this.annotationTypes == null) {
/*      */       try {
/*  731 */         this.bitflag |= 0x100;
/*  732 */         AnnotationGen[] annos = this.javaClass.getAnnotations();
/*  733 */         if (annos == null || annos.length == 0) {
/*  734 */           this.annotationTypes = ResolvedType.NONE;
/*  735 */           this.annotations = AnnotationAJ.EMPTY_ARRAY;
/*      */         } else {
/*  737 */           World w = getResolvedTypeX().getWorld();
/*  738 */           this.annotationTypes = new ResolvedType[annos.length];
/*  739 */           this.annotations = new AnnotationAJ[annos.length];
/*  740 */           for (int i = 0; i < annos.length; i++) {
/*  741 */             AnnotationGen annotation = annos[i];
/*  742 */             String typeSignature = annotation.getTypeSignature();
/*  743 */             ResolvedType rType = w.resolve(UnresolvedType.forSignature(typeSignature));
/*  744 */             if (rType == null) {
/*  745 */               throw new RuntimeException("Whilst unpacking annotations on '" + getResolvedTypeX().getName() + "', failed to resolve type '" + typeSignature + "'");
/*      */             }
/*      */             
/*  748 */             this.annotationTypes[i] = rType;
/*  749 */             this.annotations[i] = (AnnotationAJ)new BcelAnnotation(annotation, rType);
/*      */           } 
/*      */         } 
/*      */       } finally {
/*  753 */         this.bitflag &= 0xFFFFFEFF;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDeclaredGenericSignature() {
/*  761 */     ensureGenericInfoProcessed();
/*  762 */     return this.declaredSignature;
/*      */   }
/*      */   
/*      */   private void ensureGenericSignatureUnpacked() {
/*  766 */     if ((this.bitflag & 0x2) != 0) {
/*      */       return;
/*      */     }
/*  769 */     this.bitflag |= 0x2;
/*  770 */     if (!getResolvedTypeX().getWorld().isInJava5Mode()) {
/*      */       return;
/*      */     }
/*  773 */     GenericSignature.ClassSignature cSig = getGenericClassTypeSignature();
/*  774 */     if (cSig != null) {
/*  775 */       this.formalsForResolution = cSig.formalTypeParameters;
/*  776 */       if (isNested()) {
/*      */ 
/*      */         
/*  779 */         GenericSignature.FormalTypeParameter[] extraFormals = getFormalTypeParametersFromOuterClass();
/*  780 */         if (extraFormals.length > 0) {
/*  781 */           List<GenericSignature.FormalTypeParameter> allFormals = new ArrayList<>();
/*  782 */           Collections.addAll(allFormals, this.formalsForResolution);
/*  783 */           Collections.addAll(allFormals, extraFormals);
/*  784 */           this.formalsForResolution = new GenericSignature.FormalTypeParameter[allFormals.size()];
/*  785 */           allFormals.toArray(this.formalsForResolution);
/*      */         } 
/*      */       } 
/*  788 */       GenericSignature.ClassTypeSignature superSig = cSig.superclassSignature;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  795 */         ResolvedType rt = BcelGenericSignatureToTypeXConverter.classTypeSignature2TypeX(superSig, this.formalsForResolution, 
/*  796 */             getResolvedTypeX().getWorld());
/*  797 */         this.superclassSignature = rt.getSignature();
/*  798 */         this.superclassName = rt.getName();
/*      */       }
/*  800 */       catch (GenericSignatureFormatException e) {
/*      */         
/*  802 */         throw new IllegalStateException("While determining the generic superclass of " + this.className + " with generic signature " + 
/*  803 */             getDeclaredGenericSignature() + " the following error was detected: " + e
/*  804 */             .getMessage());
/*      */       } 
/*      */ 
/*      */       
/*  808 */       if (cSig.superInterfaceSignatures.length == 0) {
/*  809 */         this.interfaceSignatures = NO_INTERFACE_SIGS;
/*      */       } else {
/*  811 */         this.interfaceSignatures = new String[cSig.superInterfaceSignatures.length];
/*  812 */         for (int i = 0; i < cSig.superInterfaceSignatures.length; i++) {
/*      */ 
/*      */           
/*      */           try {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  820 */             this.interfaceSignatures[i] = BcelGenericSignatureToTypeXConverter.classTypeSignature2TypeX(cSig.superInterfaceSignatures[i], this.formalsForResolution, 
/*  821 */                 getResolvedTypeX().getWorld())
/*  822 */               .getSignature();
/*  823 */           } catch (GenericSignatureFormatException e) {
/*      */             
/*  825 */             throw new IllegalStateException("While determing the generic superinterfaces of " + this.className + " with generic signature " + 
/*  826 */                 getDeclaredGenericSignature() + " the following error was detected: " + e
/*  827 */                 .getMessage());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  832 */     if (isGeneric()) {
/*      */       
/*  834 */       ReferenceType genericType = this.resolvedTypeX.getGenericType();
/*      */ 
/*      */ 
/*      */       
/*  838 */       if (genericType != null) {
/*  839 */         genericType.setStartPos(this.resolvedTypeX.getStartPos());
/*  840 */         this.resolvedTypeX = genericType;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public GenericSignature.FormalTypeParameter[] getAllFormals() {
/*  846 */     ensureGenericSignatureUnpacked();
/*  847 */     if (this.formalsForResolution == null) {
/*  848 */       return GenericSignature.FormalTypeParameter.NONE;
/*      */     }
/*  850 */     return this.formalsForResolution;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResolvedType getOuterClass() {
/*  855 */     if (!isNested()) {
/*  856 */       throw new IllegalStateException("Can't get the outer class of non-nested type: " + this.className);
/*      */     }
/*      */ 
/*      */     
/*  860 */     for (Attribute attr : this.javaClass.getAttributes()) {
/*  861 */       if (attr instanceof InnerClasses) {
/*      */         
/*  863 */         InnerClass[] innerClss = ((InnerClasses)attr).getInnerClasses();
/*  864 */         ConstantPool cpool = this.javaClass.getConstantPool();
/*  865 */         for (InnerClass innerCls : innerClss) {
/*      */ 
/*      */           
/*  868 */           if (innerCls.getInnerClassIndex() != 0 && innerCls.getOuterClassIndex() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  873 */             ConstantClass innerClsInfo = (ConstantClass)cpool.getConstant(innerCls.getInnerClassIndex());
/*      */ 
/*      */             
/*  876 */             String innerClsName = cpool.getConstantUtf8(innerClsInfo.getNameIndex()).getValue().replace('/', '.');
/*      */             
/*  878 */             if (innerClsName.compareTo(this.className) == 0) {
/*      */               
/*  880 */               ConstantClass outerClsInfo = (ConstantClass)cpool.getConstant(innerCls.getOuterClassIndex());
/*      */ 
/*      */               
/*  883 */               String outerClsName = cpool.getConstantUtf8(outerClsInfo.getNameIndex()).getValue().replace('/', '.');
/*      */               
/*  885 */               UnresolvedType unresolvedType = UnresolvedType.forName(outerClsName);
/*  886 */               return unresolvedType.resolve(getResolvedTypeX().getWorld());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  892 */     for (Attribute attr : this.javaClass.getAttributes()) {
/*  893 */       ConstantPool cpool = this.javaClass.getConstantPool();
/*  894 */       if (attr instanceof EnclosingMethod) {
/*  895 */         EnclosingMethod enclosingMethodAttribute = (EnclosingMethod)attr;
/*  896 */         if (enclosingMethodAttribute.getEnclosingClassIndex() != 0) {
/*  897 */           ConstantClass outerClassInfo = enclosingMethodAttribute.getEnclosingClass();
/*  898 */           String outerClassName = cpool.getConstantUtf8(outerClassInfo.getNameIndex()).getValue().replace('/', '.');
/*  899 */           UnresolvedType unresolvedType = UnresolvedType.forName(outerClassName);
/*  900 */           return unresolvedType.resolve(getResolvedTypeX().getWorld());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  906 */     int lastDollar = this.className.lastIndexOf('$');
/*  907 */     if (lastDollar == -1)
/*      */     {
/*      */       
/*  910 */       return null;
/*      */     }
/*  912 */     String superClassName = this.className.substring(0, lastDollar);
/*  913 */     UnresolvedType outer = UnresolvedType.forName(superClassName);
/*  914 */     return outer.resolve(getResolvedTypeX().getWorld());
/*      */   }
/*      */   
/*      */   private void ensureGenericInfoProcessed() {
/*  918 */     if ((this.bitflag & 0x10) != 0) {
/*      */       return;
/*      */     }
/*  921 */     this.bitflag |= 0x10;
/*  922 */     Signature sigAttr = AttributeUtils.getSignatureAttribute(this.javaClass.getAttributes());
/*  923 */     this.declaredSignature = (sigAttr == null) ? null : sigAttr.getSignature();
/*  924 */     if (this.declaredSignature != null) {
/*  925 */       this.isGenericType = (this.declaredSignature.charAt(0) == '<');
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isGeneric() {
/*  930 */     ensureGenericInfoProcessed();
/*  931 */     return this.isGenericType;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  936 */     return (this.javaClass == null) ? "BcelObjectType" : ("BcelObjectTypeFor:" + this.className);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void evictWeavingState() {
/*  943 */     if (getResolvedTypeX().getWorld().couldIncrementalCompileFollow()) {
/*      */       return;
/*      */     }
/*      */     
/*  947 */     if (this.javaClass != null) {
/*      */       
/*  949 */       ensureAnnotationsUnpacked();
/*  950 */       ensureGenericInfoProcessed();
/*      */       
/*  952 */       getDeclaredInterfaces();
/*  953 */       getDeclaredFields();
/*  954 */       getDeclaredMethods();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  962 */       if (getResolvedTypeX().getWorld().isXnoInline()) {
/*  963 */         this.lazyClassGen = null;
/*      */       }
/*      */ 
/*      */       
/*  967 */       if (this.weaverState != null) {
/*  968 */         this.weaverState.setReweavable(false);
/*  969 */         this.weaverState.setUnwovenClassFileData(null);
/*      */       }  int i;
/*  971 */       for (i = this.methods.length - 1; i >= 0; i--) {
/*  972 */         this.methods[i].evictWeavingState();
/*      */       }
/*  974 */       for (i = this.fields.length - 1; i >= 0; i--) {
/*  975 */         this.fields[i].evictWeavingState();
/*      */       }
/*  977 */       this.javaClass = null;
/*  978 */       this.artificial = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void weavingCompleted() {
/*  988 */     this.hasBeenWoven = true;
/*  989 */     if (getResolvedTypeX().getWorld().isRunMinimalMemory()) {
/*  990 */       evictWeavingState();
/*      */     }
/*  992 */     if (getSourceContext() != null && !getResolvedTypeX().isAspect()) {
/*  993 */       getSourceContext().tidy();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean hasBeenWoven() {
/*  998 */     return this.hasBeenWoven;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean copySourceContext() {
/* 1003 */     return false;
/*      */   }
/*      */   
/*      */   public void setExposedToWeaver(boolean b) {
/* 1007 */     this.exposedToWeaver = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getCompilerVersion() {
/* 1012 */     return this.wvInfo.getMajorVersion();
/*      */   }
/*      */   
/*      */   public void ensureConsistent() {
/* 1016 */     this.superTypeReference.clear();
/* 1017 */     this.superInterfaceReferences.clear();
/*      */   }
/*      */   
/*      */   public boolean isWeavable() {
/* 1021 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelObjectType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */