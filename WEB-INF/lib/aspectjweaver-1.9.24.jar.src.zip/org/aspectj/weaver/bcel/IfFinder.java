/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.weaver.patterns.AbstractPatternNodeVisitor;
/*    */ import org.aspectj.weaver.patterns.AndPointcut;
/*    */ import org.aspectj.weaver.patterns.IfPointcut;
/*    */ import org.aspectj.weaver.patterns.NotPointcut;
/*    */ import org.aspectj.weaver.patterns.OrPointcut;
/*    */ import org.aspectj.weaver.patterns.PatternNodeVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IfFinder
/*    */   extends AbstractPatternNodeVisitor
/*    */ {
/*    */   boolean hasIf = false;
/*    */   
/*    */   public Object visit(IfPointcut node, Object data) {
/* 27 */     if (!node.alwaysFalse() && !node.alwaysTrue())
/*    */     {
/*    */       
/* 30 */       this.hasIf = true;
/*    */     }
/* 32 */     return node;
/*    */   }
/*    */   
/*    */   public Object visit(AndPointcut node, Object data) {
/* 36 */     if (!this.hasIf)
/* 37 */       node.getLeft().accept((PatternNodeVisitor)this, data); 
/* 38 */     if (!this.hasIf)
/* 39 */       node.getRight().accept((PatternNodeVisitor)this, data); 
/* 40 */     return node;
/*    */   }
/*    */   
/*    */   public Object visit(NotPointcut node, Object data) {
/* 44 */     if (!this.hasIf)
/* 45 */       node.getNegatedPointcut().accept((PatternNodeVisitor)this, data); 
/* 46 */     return node;
/*    */   }
/*    */   
/*    */   public Object visit(OrPointcut node, Object data) {
/* 50 */     if (!this.hasIf)
/* 51 */       node.getLeft().accept((PatternNodeVisitor)this, data); 
/* 52 */     if (!this.hasIf)
/* 53 */       node.getRight().accept((PatternNodeVisitor)this, data); 
/* 54 */     return node;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\IfFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */