/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.GenericSignature;
/*     */ import org.aspectj.weaver.BoundedReferenceType;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.TypeFactory;
/*     */ import org.aspectj.weaver.TypeVariable;
/*     */ import org.aspectj.weaver.TypeVariableReferenceType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.tools.Trace;
/*     */ import org.aspectj.weaver.tools.TraceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BcelGenericSignatureToTypeXConverter
/*     */ {
/*  36 */   private static Trace trace = TraceFactory.getTraceFactory().getTrace(BcelGenericSignatureToTypeXConverter.class);
/*     */ 
/*     */   
/*     */   public static ResolvedType classTypeSignature2TypeX(GenericSignature.ClassTypeSignature aClassTypeSignature, GenericSignature.FormalTypeParameter[] typeParams, World world) throws GenericSignatureFormatException {
/*  40 */     Map<GenericSignature.FormalTypeParameter, ReferenceType> typeMap = new HashMap<>();
/*  41 */     ResolvedType ret = classTypeSignature2TypeX(aClassTypeSignature, typeParams, world, typeMap);
/*  42 */     fixUpCircularDependencies(ret, typeMap);
/*  43 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResolvedType classTypeSignature2TypeX(GenericSignature.ClassTypeSignature aClassTypeSignature, GenericSignature.FormalTypeParameter[] typeParams, World world, Map<GenericSignature.FormalTypeParameter, ReferenceType> inProgressTypeVariableResolutions) throws GenericSignatureFormatException {
/*  55 */     StringBuilder sig = new StringBuilder();
/*  56 */     sig.append(aClassTypeSignature.outerType.identifier.replace(';', ' ').trim());
/*  57 */     for (int i = 0; i < aClassTypeSignature.nestedTypes.length; i++) {
/*  58 */       sig.append("$");
/*  59 */       sig.append((aClassTypeSignature.nestedTypes[i]).identifier.replace(';', ' ').trim());
/*     */     } 
/*  61 */     sig.append(";");
/*     */ 
/*     */ 
/*     */     
/*  65 */     GenericSignature.SimpleClassTypeSignature innerType = aClassTypeSignature.outerType;
/*  66 */     if (aClassTypeSignature.nestedTypes.length > 0) {
/*  67 */       innerType = aClassTypeSignature.nestedTypes[aClassTypeSignature.nestedTypes.length - 1];
/*     */     }
/*  69 */     if (innerType.typeArguments.length > 0) {
/*     */ 
/*     */       
/*  72 */       ResolvedType theBaseType = UnresolvedType.forSignature(sig.toString()).resolve(world);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  78 */       if (!theBaseType.isGenericType() && !theBaseType.isRawType()) {
/*  79 */         if (trace.isTraceEnabled()) {
/*  80 */           trace.event("classTypeSignature2TypeX: this type is not a generic type:", null, new Object[] { theBaseType });
/*     */         }
/*  82 */         return theBaseType;
/*     */       } 
/*     */       
/*  85 */       ResolvedType[] typeArgumentTypes = new ResolvedType[innerType.typeArguments.length];
/*  86 */       for (int j = 0; j < typeArgumentTypes.length; j++) {
/*  87 */         typeArgumentTypes[j] = typeArgument2TypeX(innerType.typeArguments[j], typeParams, world, inProgressTypeVariableResolutions);
/*     */       }
/*     */       
/*  90 */       return (ResolvedType)TypeFactory.createParameterizedType(theBaseType, (UnresolvedType[])typeArgumentTypes, world);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     return world.resolve(UnresolvedType.forSignature(sig.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResolvedType fieldTypeSignature2TypeX(GenericSignature.FieldTypeSignature aFieldTypeSignature, GenericSignature.FormalTypeParameter[] typeParams, World world) throws GenericSignatureFormatException {
/* 103 */     Map<GenericSignature.FormalTypeParameter, ReferenceType> typeMap = new HashMap<>();
/* 104 */     ResolvedType ret = fieldTypeSignature2TypeX(aFieldTypeSignature, typeParams, world, typeMap);
/* 105 */     fixUpCircularDependencies(ret, typeMap);
/* 106 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResolvedType fieldTypeSignature2TypeX(GenericSignature.FieldTypeSignature aFieldTypeSignature, GenericSignature.FormalTypeParameter[] typeParams, World world, Map<GenericSignature.FormalTypeParameter, ReferenceType> inProgressTypeVariableResolutions) throws GenericSignatureFormatException {
/* 113 */     if (aFieldTypeSignature.isClassTypeSignature()) {
/* 114 */       return classTypeSignature2TypeX((GenericSignature.ClassTypeSignature)aFieldTypeSignature, typeParams, world, inProgressTypeVariableResolutions);
/*     */     }
/* 116 */     if (aFieldTypeSignature.isArrayTypeSignature()) {
/* 117 */       GenericSignature.TypeSignature typeSignature; int dims = 0;
/* 118 */       GenericSignature.FieldTypeSignature fieldTypeSignature = aFieldTypeSignature;
/* 119 */       while (fieldTypeSignature instanceof GenericSignature.ArrayTypeSignature) {
/* 120 */         dims++;
/* 121 */         typeSignature = ((GenericSignature.ArrayTypeSignature)fieldTypeSignature).typeSig;
/*     */       } 
/* 123 */       return world.resolve(UnresolvedType.makeArray(
/* 124 */             (UnresolvedType)typeSignature2TypeX(typeSignature, typeParams, world, inProgressTypeVariableResolutions), dims));
/* 125 */     }  if (aFieldTypeSignature.isTypeVariableSignature()) {
/* 126 */       ResolvedType rtx = typeVariableSignature2TypeX((GenericSignature.TypeVariableSignature)aFieldTypeSignature, typeParams, world, inProgressTypeVariableResolutions);
/*     */       
/* 128 */       return rtx;
/*     */     } 
/* 130 */     throw new GenericSignatureFormatException("Cant understand field type signature: " + aFieldTypeSignature);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeVariable formalTypeParameter2TypeVariable(GenericSignature.FormalTypeParameter aFormalTypeParameter, GenericSignature.FormalTypeParameter[] typeParams, World world) throws GenericSignatureFormatException {
/* 136 */     Map<GenericSignature.FormalTypeParameter, ReferenceType> typeMap = new HashMap<>();
/* 137 */     return formalTypeParameter2TypeVariable(aFormalTypeParameter, typeParams, world, typeMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TypeVariable formalTypeParameter2TypeVariable(GenericSignature.FormalTypeParameter aFormalTypeParameter, GenericSignature.FormalTypeParameter[] typeParams, World world, Map<GenericSignature.FormalTypeParameter, ReferenceType> inProgressTypeVariableResolutions) throws GenericSignatureFormatException {
/* 144 */     ResolvedType resolvedType = fieldTypeSignature2TypeX(aFormalTypeParameter.classBound, typeParams, world, inProgressTypeVariableResolutions);
/*     */     
/* 146 */     UnresolvedType[] ifBounds = new UnresolvedType[aFormalTypeParameter.interfaceBounds.length];
/* 147 */     for (int i = 0; i < ifBounds.length; i++) {
/* 148 */       ifBounds[i] = (UnresolvedType)fieldTypeSignature2TypeX(aFormalTypeParameter.interfaceBounds[i], typeParams, world, inProgressTypeVariableResolutions);
/*     */     }
/*     */     
/* 151 */     return new TypeVariable(aFormalTypeParameter.identifier, (UnresolvedType)resolvedType, ifBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResolvedType typeArgument2TypeX(GenericSignature.TypeArgument aTypeArgument, GenericSignature.FormalTypeParameter[] typeParams, World world, Map<GenericSignature.FormalTypeParameter, ReferenceType> inProgressTypeVariableResolutions) throws GenericSignatureFormatException {
/* 158 */     if (aTypeArgument.isWildcard) {
/* 159 */       return UnresolvedType.SOMETHING.resolve(world);
/*     */     }
/* 161 */     if (aTypeArgument.isMinus) {
/* 162 */       ResolvedType resolvedType1 = fieldTypeSignature2TypeX(aTypeArgument.signature, typeParams, world, inProgressTypeVariableResolutions);
/*     */       
/* 164 */       ResolvedType resolvedBound = world.resolve((UnresolvedType)resolvedType1);
/* 165 */       if (resolvedBound.isMissing()) {
/* 166 */         (world.getLint()).cantFindType.signal("Unable to find type (for bound): " + resolvedBound.getName(), null);
/* 167 */         resolvedBound = world.resolve(UnresolvedType.OBJECT);
/*     */       } 
/* 169 */       ReferenceType rBound = (ReferenceType)resolvedBound;
/* 170 */       return (ResolvedType)new BoundedReferenceType(rBound, false, world);
/* 171 */     }  if (aTypeArgument.isPlus) {
/* 172 */       ResolvedType resolvedType1 = fieldTypeSignature2TypeX(aTypeArgument.signature, typeParams, world, inProgressTypeVariableResolutions);
/*     */       
/* 174 */       ResolvedType resolvedBound = world.resolve((UnresolvedType)resolvedType1);
/* 175 */       if (resolvedBound.isMissing()) {
/* 176 */         (world.getLint()).cantFindType.signal("Unable to find type (for bound): " + resolvedBound.getName(), null);
/* 177 */         resolvedBound = world.resolve(UnresolvedType.OBJECT);
/*     */       } 
/* 179 */       ReferenceType rBound = (ReferenceType)resolvedBound;
/* 180 */       return (ResolvedType)new BoundedReferenceType(rBound, true, world);
/*     */     } 
/* 182 */     return fieldTypeSignature2TypeX(aTypeArgument.signature, typeParams, world, inProgressTypeVariableResolutions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResolvedType typeSignature2TypeX(GenericSignature.TypeSignature aTypeSig, GenericSignature.FormalTypeParameter[] typeParams, World world) throws GenericSignatureFormatException {
/* 188 */     Map<GenericSignature.FormalTypeParameter, ReferenceType> typeMap = new HashMap<>();
/* 189 */     ResolvedType ret = typeSignature2TypeX(aTypeSig, typeParams, world, typeMap);
/* 190 */     fixUpCircularDependencies(ret, typeMap);
/* 191 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResolvedType typeSignature2TypeX(GenericSignature.TypeSignature aTypeSig, GenericSignature.FormalTypeParameter[] typeParams, World world, Map<GenericSignature.FormalTypeParameter, ReferenceType> inProgressTypeVariableResolutions) throws GenericSignatureFormatException {
/* 198 */     if (aTypeSig.isBaseType()) {
/* 199 */       return world.resolve(UnresolvedType.forSignature(((GenericSignature.BaseTypeSignature)aTypeSig).toString()));
/*     */     }
/* 201 */     return fieldTypeSignature2TypeX((GenericSignature.FieldTypeSignature)aTypeSig, typeParams, world, inProgressTypeVariableResolutions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResolvedType typeVariableSignature2TypeX(GenericSignature.TypeVariableSignature aTypeVarSig, GenericSignature.FormalTypeParameter[] typeParams, World world, Map<GenericSignature.FormalTypeParameter, ReferenceType> inProgressTypeVariableResolutions) throws GenericSignatureFormatException {
/* 210 */     GenericSignature.FormalTypeParameter typeVarBounds = null;
/* 211 */     for (GenericSignature.FormalTypeParameter typeParam : typeParams) {
/* 212 */       if (typeParam.identifier.equals(aTypeVarSig.typeVariableName)) {
/* 213 */         typeVarBounds = typeParam;
/*     */         break;
/*     */       } 
/*     */     } 
/* 217 */     if (typeVarBounds == null)
/*     */     {
/*     */ 
/*     */       
/* 221 */       return (ResolvedType)new TypeVariableReferenceType(new TypeVariable(aTypeVarSig.typeVariableName), world);
/*     */     }
/*     */     
/* 224 */     if (inProgressTypeVariableResolutions.containsKey(typeVarBounds)) {
/* 225 */       return (ResolvedType)inProgressTypeVariableResolutions.get(typeVarBounds);
/*     */     }
/* 227 */     inProgressTypeVariableResolutions.put(typeVarBounds, new FTPHolder(typeVarBounds, world));
/* 228 */     TypeVariableReferenceType typeVariableReferenceType = new TypeVariableReferenceType(formalTypeParameter2TypeVariable(typeVarBounds, typeParams, world, inProgressTypeVariableResolutions), world);
/*     */     
/* 230 */     inProgressTypeVariableResolutions.put(typeVarBounds, typeVariableReferenceType);
/* 231 */     return (ResolvedType)typeVariableReferenceType;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void fixUpCircularDependencies(ResolvedType aTypeX, Map<GenericSignature.FormalTypeParameter, ReferenceType> typeVariableResolutions) {
/* 236 */     if (!(aTypeX instanceof ReferenceType)) {
/*     */       return;
/*     */     }
/*     */     
/* 240 */     ReferenceType rt = (ReferenceType)aTypeX;
/* 241 */     TypeVariable[] typeVars = rt.getTypeVariables();
/* 242 */     if (typeVars != null)
/* 243 */       for (TypeVariable typeVar : typeVars) {
/* 244 */         if (typeVar.getUpperBound() instanceof FTPHolder) {
/* 245 */           GenericSignature.FormalTypeParameter key = ((FTPHolder)typeVar.getUpperBound()).ftpToBeSubstituted;
/* 246 */           typeVar.setUpperBound((UnresolvedType)typeVariableResolutions.get(key));
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   private static class FTPHolder
/*     */     extends ReferenceType {
/*     */     public GenericSignature.FormalTypeParameter ftpToBeSubstituted;
/*     */     
/*     */     public FTPHolder(GenericSignature.FormalTypeParameter ftp, World world) {
/* 256 */       super("Ljava/lang/Object;", world);
/* 257 */       this.ftpToBeSubstituted = ftp;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 261 */       return "placeholder for TypeVariable of " + this.ftpToBeSubstituted.toString();
/*     */     }
/*     */     
/*     */     public ResolvedType resolve(World world) {
/* 265 */       return (ResolvedType)this;
/*     */     }
/*     */     
/*     */     public boolean isCacheable() {
/* 269 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GenericSignatureFormatException extends Exception {
/*     */     public GenericSignatureFormatException(String explanation) {
/* 275 */       super(explanation);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelGenericSignatureToTypeXConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */