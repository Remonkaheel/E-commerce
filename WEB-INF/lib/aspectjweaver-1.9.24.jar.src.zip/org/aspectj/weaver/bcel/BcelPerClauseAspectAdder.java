/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionBranch;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ import org.aspectj.apache.bcel.generic.ReferenceType;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.AjcMemberMaker;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.NameMangler;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.ResolvedTypeMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.patterns.PerClause;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BcelPerClauseAspectAdder
/*     */   extends BcelTypeMunger
/*     */ {
/*     */   private final PerClause.Kind kind;
/*     */   private boolean hasGeneratedInner = false;
/*     */   
/*     */   public BcelPerClauseAspectAdder(ResolvedType aspect, PerClause.Kind kind) {
/*  47 */     super((ResolvedTypeMunger)null, aspect);
/*  48 */     this.kind = kind;
/*  49 */     if (kind == PerClause.SINGLETON || kind == PerClause.PERTYPEWITHIN || kind == PerClause.PERCFLOW)
/*     */     {
/*  51 */       this.hasGeneratedInner = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean munge(BcelClassWeaver weaver) {
/*  56 */     LazyClassGen gen = weaver.getLazyClassGen();
/*     */     
/*  58 */     doAggressiveInner(gen);
/*     */ 
/*     */     
/*  61 */     if (!gen.getType().equals(this.aspectType)) {
/*  62 */       return false;
/*     */     }
/*     */     
/*  65 */     return doMunge(gen, true);
/*     */   }
/*     */   
/*     */   public boolean forceMunge(LazyClassGen gen, boolean checkAlreadyThere) {
/*  69 */     doAggressiveInner(gen);
/*  70 */     return doMunge(gen, checkAlreadyThere);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doAggressiveInner(LazyClassGen gen) {
/*  78 */     if (!this.hasGeneratedInner) {
/*  79 */       if (this.kind == PerClause.PEROBJECT) {
/*     */         
/*  81 */         UnresolvedType interfaceTypeX = AjcMemberMaker.perObjectInterfaceType((UnresolvedType)this.aspectType);
/*     */         
/*  83 */         LazyClassGen interfaceGen = new LazyClassGen(interfaceTypeX.getName(), "java.lang.Object", null, 1537, new String[0], getWorld());
/*  84 */         interfaceGen.addMethodGen(makeMethodGen(interfaceGen, AjcMemberMaker.perObjectInterfaceGet((UnresolvedType)this.aspectType)));
/*  85 */         interfaceGen.addMethodGen(makeMethodGen(interfaceGen, AjcMemberMaker.perObjectInterfaceSet((UnresolvedType)this.aspectType)));
/*     */         
/*  87 */         gen.addGeneratedInner(interfaceGen);
/*     */       } 
/*  89 */       this.hasGeneratedInner = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean doMunge(LazyClassGen gen, boolean checkAlreadyThere) {
/*  94 */     if (checkAlreadyThere && hasPerClauseMembersAlready(gen)) {
/*  95 */       return false;
/*     */     }
/*     */     
/*  98 */     generatePerClauseMembers(gen);
/*     */     
/* 100 */     if (this.kind == PerClause.SINGLETON) {
/* 101 */       generatePerSingletonAspectOfMethod(gen);
/* 102 */       generatePerSingletonHasAspectMethod(gen);
/* 103 */       generatePerSingletonAjcClinitMethod(gen);
/* 104 */     } else if (this.kind == PerClause.PEROBJECT) {
/* 105 */       generatePerObjectAspectOfMethod(gen);
/* 106 */       generatePerObjectHasAspectMethod(gen);
/* 107 */       generatePerObjectBindMethod(gen);
/*     */     
/*     */     }
/* 110 */     else if (this.kind == PerClause.PERCFLOW) {
/* 111 */       generatePerCflowAspectOfMethod(gen);
/* 112 */       generatePerCflowHasAspectMethod(gen);
/* 113 */       generatePerCflowPushMethod(gen);
/* 114 */       generatePerCflowAjcClinitMethod(gen);
/* 115 */     } else if (this.kind == PerClause.PERTYPEWITHIN) {
/* 116 */       generatePerTWAspectOfMethod(gen);
/* 117 */       generatePerTWHasAspectMethod(gen);
/* 118 */       generatePerTWGetInstanceMethod(gen);
/* 119 */       generatePerTWCreateAspectInstanceMethod(gen);
/* 120 */       generatePerTWGetWithinTypeNameMethod(gen);
/*     */     } else {
/* 122 */       throw new Error("should not happen - not such kind " + this.kind.getName());
/*     */     } 
/* 124 */     return true;
/*     */   }
/*     */   
/*     */   public ResolvedMember getMatchingSyntheticMember(Member member) {
/* 128 */     return null;
/*     */   }
/*     */   
/*     */   public ResolvedMember getSignature() {
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(ResolvedType onType) {
/* 137 */     if (this.hasGeneratedInner) {
/* 138 */       return this.aspectType.equals(onType);
/*     */     }
/* 140 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasPerClauseMembersAlready(LazyClassGen classGen) {
/* 145 */     List<LazyMethodGen> methodGens = classGen.getMethodGens();
/* 146 */     for (LazyMethodGen method : methodGens) {
/* 147 */       if ("aspectOf".equals(method.getName())) {
/* 148 */         if ("()".equals(method.getParameterSignature()) && (this.kind == PerClause.SINGLETON || this.kind == PerClause.PERCFLOW))
/* 149 */           return true; 
/* 150 */         if ("(Ljava/lang/Object;)".equals(method.getParameterSignature()) && this.kind == PerClause.PEROBJECT)
/* 151 */           return true; 
/* 152 */         if ("(Ljava/lang/Class;)".equals(method.getParameterSignature()) && this.kind == PerClause.PERTYPEWITHIN) {
/* 153 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generatePerClauseMembers(LazyClassGen classGen) {
/* 165 */     ResolvedMember failureFieldInfo = AjcMemberMaker.initFailureCauseField((UnresolvedType)this.aspectType);
/* 166 */     if (this.kind == PerClause.SINGLETON) {
/* 167 */       classGen.addField(makeFieldGen(classGen, failureFieldInfo), null);
/*     */     }
/*     */     
/* 170 */     if (this.kind == PerClause.SINGLETON) {
/* 171 */       ResolvedMember perSingletonFieldInfo = AjcMemberMaker.perSingletonField((UnresolvedType)this.aspectType);
/* 172 */       classGen.addField(makeFieldGen(classGen, perSingletonFieldInfo), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 179 */     else if (this.kind == PerClause.PERCFLOW) {
/* 180 */       ResolvedMember perCflowFieldInfo = AjcMemberMaker.perCflowField((UnresolvedType)this.aspectType);
/* 181 */       classGen.addField(makeFieldGen(classGen, perCflowFieldInfo), null);
/* 182 */     } else if (this.kind == PerClause.PERTYPEWITHIN) {
/* 183 */       ResolvedMember perTypeWithinForField = AjcMemberMaker.perTypeWithinWithinTypeField((UnresolvedType)this.aspectType, this.aspectType);
/* 184 */       classGen.addField(makeFieldGen(classGen, perTypeWithinForField), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void generatePerSingletonAspectOfMethod(LazyClassGen classGen) {
/* 189 */     InstructionFactory factory = classGen.getFactory();
/* 190 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perSingletonAspectOfMethod((UnresolvedType)this.aspectType));
/* 191 */     flagAsSynthetic(method, false);
/* 192 */     classGen.addMethodGen(method);
/*     */     
/* 194 */     InstructionList il = method.getBody();
/* 195 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perSingletonField((UnresolvedType)this.aspectType)));
/* 196 */     InstructionBranch ifNotNull = InstructionFactory.createBranchInstruction((short)199, null);
/* 197 */     il.append(ifNotNull);
/* 198 */     il.append(factory.createNew(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName()));
/* 199 */     il.append(InstructionConstants.DUP);
/* 200 */     il.append(InstructionFactory.PUSH(classGen.getConstantPool(), this.aspectType.getName()));
/* 201 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.initFailureCauseField((UnresolvedType)this.aspectType)));
/* 202 */     il.append((Instruction)factory.createInvoke(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName(), "<init>", (Type)Type.VOID, new Type[] { (Type)Type.STRING, (Type)new ObjectType("java.lang.Throwable") }, (short)183));
/*     */     
/* 204 */     il.append(InstructionConstants.ATHROW);
/* 205 */     InstructionHandle ifElse = il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perSingletonField((UnresolvedType)this.aspectType)));
/* 206 */     il.append(InstructionFactory.createReturn((Type)Type.OBJECT));
/* 207 */     ifNotNull.setTarget(ifElse);
/*     */   }
/*     */   
/*     */   private void generatePerSingletonHasAspectMethod(LazyClassGen classGen) {
/* 211 */     InstructionFactory factory = classGen.getFactory();
/* 212 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perSingletonHasAspectMethod((UnresolvedType)this.aspectType));
/* 213 */     flagAsSynthetic(method, false);
/* 214 */     classGen.addMethodGen(method);
/*     */     
/* 216 */     InstructionList il = method.getBody();
/* 217 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perSingletonField((UnresolvedType)this.aspectType)));
/* 218 */     InstructionBranch ifNull = InstructionFactory.createBranchInstruction((short)198, null);
/* 219 */     il.append(ifNull);
/* 220 */     il.append(InstructionFactory.PUSH(classGen.getConstantPool(), true));
/* 221 */     il.append(InstructionFactory.createReturn((Type)Type.INT));
/* 222 */     InstructionHandle ifElse = il.append(InstructionFactory.PUSH(classGen.getConstantPool(), false));
/* 223 */     il.append(InstructionFactory.createReturn((Type)Type.INT));
/* 224 */     ifNull.setTarget(ifElse);
/*     */   }
/*     */   
/*     */   private void generatePerSingletonAjcClinitMethod(LazyClassGen classGen) {
/* 228 */     InstructionFactory factory = classGen.getFactory();
/* 229 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.ajcPostClinitMethod((UnresolvedType)this.aspectType));
/* 230 */     flagAsSynthetic(method, true);
/* 231 */     classGen.addMethodGen(method);
/*     */     
/* 233 */     InstructionList il = method.getBody();
/* 234 */     il.append(factory.createNew(this.aspectType.getName()));
/* 235 */     il.append(InstructionConstants.DUP);
/* 236 */     il.append((Instruction)factory.createInvoke(this.aspectType.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/* 237 */     il.append(Utility.createSet(factory, (Member)AjcMemberMaker.perSingletonField((UnresolvedType)this.aspectType)));
/* 238 */     il.append(InstructionFactory.createReturn((Type)Type.VOID));
/*     */ 
/*     */     
/* 241 */     LazyMethodGen clinit = classGen.getStaticInitializer();
/* 242 */     il = new InstructionList();
/* 243 */     InstructionHandle tryStart = il.append((Instruction)factory.createInvoke(this.aspectType.getName(), "ajc$postClinit", (Type)Type.VOID, Type.NO_ARGS, (short)184));
/*     */     
/* 245 */     InstructionBranch tryEnd = InstructionFactory.createBranchInstruction((short)167, null);
/* 246 */     il.append(tryEnd);
/* 247 */     InstructionHandle handler = il.append((Instruction)InstructionConstants.ASTORE_0);
/* 248 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 249 */     il.append(Utility.createSet(factory, (Member)AjcMemberMaker.initFailureCauseField((UnresolvedType)this.aspectType)));
/* 250 */     il.append(InstructionFactory.createReturn((Type)Type.VOID));
/* 251 */     tryEnd.setTarget(il.getEnd());
/*     */ 
/*     */ 
/*     */     
/* 255 */     if ((clinit.getBody().getEnd().getInstruction()).opcode == 254) {
/* 256 */       clinit.getBody().getEnd().getPrev().setInstruction(InstructionConstants.NOP);
/*     */     }
/* 258 */     clinit.getBody().getEnd().setInstruction(InstructionConstants.NOP);
/* 259 */     clinit.getBody().append(il);
/*     */     
/* 261 */     clinit.addExceptionHandler(tryStart, handler.getPrev(), handler, new ObjectType("java.lang.Throwable"), false);
/*     */   }
/*     */   
/*     */   private void generatePerObjectAspectOfMethod(LazyClassGen classGen) {
/* 265 */     InstructionFactory factory = classGen.getFactory();
/* 266 */     ReferenceType interfaceType = (ReferenceType)BcelWorld.makeBcelType(AjcMemberMaker.perObjectInterfaceType((UnresolvedType)this.aspectType));
/* 267 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perObjectAspectOfMethod((UnresolvedType)this.aspectType));
/* 268 */     flagAsSynthetic(method, false);
/* 269 */     classGen.addMethodGen(method);
/*     */     
/* 271 */     InstructionList il = method.getBody();
/* 272 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 273 */     il.append(factory.createInstanceOf(interfaceType));
/* 274 */     InstructionBranch ifEq = InstructionFactory.createBranchInstruction((short)153, null);
/* 275 */     il.append(ifEq);
/* 276 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 277 */     il.append(factory.createCheckCast(interfaceType));
/* 278 */     il.append(Utility.createInvoke(factory, (short)185, (Member)AjcMemberMaker.perObjectInterfaceGet((UnresolvedType)this.aspectType)));
/* 279 */     il.append(InstructionConstants.DUP);
/* 280 */     InstructionBranch ifNull = InstructionFactory.createBranchInstruction((short)198, null);
/* 281 */     il.append(ifNull);
/* 282 */     il.append(InstructionFactory.createReturn(BcelWorld.makeBcelType((UnresolvedType)this.aspectType)));
/* 283 */     InstructionHandle ifNullElse = il.append(InstructionConstants.POP);
/* 284 */     ifNull.setTarget(ifNullElse);
/* 285 */     InstructionHandle ifEqElse = il.append(factory.createNew(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName()));
/* 286 */     ifEq.setTarget(ifEqElse);
/* 287 */     il.append(InstructionConstants.DUP);
/* 288 */     il.append((Instruction)factory.createInvoke(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/*     */     
/* 290 */     il.append(InstructionConstants.ATHROW);
/*     */   }
/*     */   
/*     */   private void generatePerObjectHasAspectMethod(LazyClassGen classGen) {
/* 294 */     InstructionFactory factory = classGen.getFactory();
/* 295 */     ReferenceType interfaceType = (ReferenceType)BcelWorld.makeBcelType(AjcMemberMaker.perObjectInterfaceType((UnresolvedType)this.aspectType));
/* 296 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perObjectHasAspectMethod((UnresolvedType)this.aspectType));
/* 297 */     flagAsSynthetic(method, false);
/* 298 */     classGen.addMethodGen(method);
/*     */     
/* 300 */     InstructionList il = method.getBody();
/* 301 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 302 */     il.append(factory.createInstanceOf(interfaceType));
/* 303 */     InstructionBranch ifEq = InstructionFactory.createBranchInstruction((short)153, null);
/* 304 */     il.append(ifEq);
/* 305 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 306 */     il.append(factory.createCheckCast(interfaceType));
/* 307 */     il.append(Utility.createInvoke(factory, (short)185, (Member)AjcMemberMaker.perObjectInterfaceGet((UnresolvedType)this.aspectType)));
/* 308 */     InstructionBranch ifNull = InstructionFactory.createBranchInstruction((short)198, null);
/* 309 */     il.append(ifNull);
/* 310 */     il.append(InstructionConstants.ICONST_1);
/* 311 */     il.append(InstructionFactory.createReturn((Type)Type.INT));
/* 312 */     InstructionHandle ifEqElse = il.append(InstructionConstants.ICONST_0);
/* 313 */     ifEq.setTarget(ifEqElse);
/* 314 */     ifNull.setTarget(ifEqElse);
/* 315 */     il.append(InstructionFactory.createReturn((Type)Type.INT));
/*     */   }
/*     */   
/*     */   private void generatePerObjectBindMethod(LazyClassGen classGen) {
/* 319 */     InstructionFactory factory = classGen.getFactory();
/* 320 */     ReferenceType interfaceType = (ReferenceType)BcelWorld.makeBcelType(AjcMemberMaker.perObjectInterfaceType((UnresolvedType)this.aspectType));
/* 321 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perObjectBind((UnresolvedType)this.aspectType));
/* 322 */     flagAsSynthetic(method, true);
/* 323 */     classGen.addMethodGen(method);
/*     */     
/* 325 */     InstructionList il = method.getBody();
/* 326 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 327 */     il.append(factory.createInstanceOf(interfaceType));
/* 328 */     InstructionBranch ifEq = InstructionFactory.createBranchInstruction((short)153, null);
/* 329 */     il.append(ifEq);
/* 330 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 331 */     il.append(factory.createCheckCast(interfaceType));
/* 332 */     il.append(Utility.createInvoke(factory, (short)185, (Member)AjcMemberMaker.perObjectInterfaceGet((UnresolvedType)this.aspectType)));
/* 333 */     InstructionBranch ifNonNull = InstructionFactory.createBranchInstruction((short)199, null);
/* 334 */     il.append(ifNonNull);
/* 335 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 336 */     il.append(factory.createCheckCast(interfaceType));
/* 337 */     il.append(factory.createNew(this.aspectType.getName()));
/* 338 */     il.append(InstructionConstants.DUP);
/* 339 */     il.append((Instruction)factory.createInvoke(this.aspectType.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/* 340 */     il.append(Utility.createInvoke(factory, (short)185, (Member)AjcMemberMaker.perObjectInterfaceSet((UnresolvedType)this.aspectType)));
/* 341 */     InstructionHandle end = il.append(InstructionFactory.createReturn((Type)Type.VOID));
/* 342 */     ifEq.setTarget(end);
/* 343 */     ifNonNull.setTarget(end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generatePerCflowAspectOfMethod(LazyClassGen classGen) {
/* 370 */     InstructionFactory factory = classGen.getFactory();
/* 371 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perCflowAspectOfMethod((UnresolvedType)this.aspectType));
/* 372 */     flagAsSynthetic(method, false);
/* 373 */     classGen.addMethodGen(method);
/*     */     
/* 375 */     InstructionList il = method.getBody();
/* 376 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perCflowField((UnresolvedType)this.aspectType)));
/* 377 */     il.append(Utility.createInvoke(factory, (short)182, AjcMemberMaker.cflowStackPeekInstance()));
/* 378 */     il.append(factory.createCheckCast((ReferenceType)BcelWorld.makeBcelType((UnresolvedType)this.aspectType)));
/* 379 */     il.append(InstructionFactory.createReturn((Type)Type.OBJECT));
/*     */   }
/*     */   
/*     */   private void generatePerCflowHasAspectMethod(LazyClassGen classGen) {
/* 383 */     InstructionFactory factory = classGen.getFactory();
/* 384 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perCflowHasAspectMethod((UnresolvedType)this.aspectType));
/* 385 */     flagAsSynthetic(method, false);
/* 386 */     classGen.addMethodGen(method);
/*     */     
/* 388 */     InstructionList il = method.getBody();
/* 389 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perCflowField((UnresolvedType)this.aspectType)));
/* 390 */     il.append(Utility.createInvoke(factory, (short)182, AjcMemberMaker.cflowStackIsValid()));
/* 391 */     il.append(InstructionFactory.createReturn((Type)Type.INT));
/*     */   }
/*     */   
/*     */   private void generatePerCflowPushMethod(LazyClassGen classGen) {
/* 395 */     InstructionFactory factory = classGen.getFactory();
/* 396 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perCflowPush((UnresolvedType)this.aspectType));
/* 397 */     flagAsSynthetic(method, true);
/* 398 */     classGen.addMethodGen(method);
/*     */     
/* 400 */     InstructionList il = method.getBody();
/* 401 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perCflowField((UnresolvedType)this.aspectType)));
/* 402 */     il.append(factory.createNew(this.aspectType.getName()));
/* 403 */     il.append(InstructionConstants.DUP);
/* 404 */     il.append((Instruction)factory.createInvoke(this.aspectType.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/* 405 */     il.append(Utility.createInvoke(factory, (short)182, AjcMemberMaker.cflowStackPushInstance()));
/* 406 */     il.append(InstructionFactory.createReturn((Type)Type.VOID));
/*     */   }
/*     */   
/*     */   private void generatePerCflowAjcClinitMethod(LazyClassGen classGen) {
/* 410 */     InstructionFactory factory = classGen.getFactory();
/*     */     
/* 412 */     LazyMethodGen method = classGen.getAjcPreClinit();
/*     */     
/* 414 */     InstructionList il = new InstructionList();
/* 415 */     il.append(factory.createNew(AjcMemberMaker.CFLOW_STACK_TYPE.getName()));
/* 416 */     il.append(InstructionConstants.DUP);
/* 417 */     il.append((Instruction)factory.createInvoke(AjcMemberMaker.CFLOW_STACK_TYPE.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/*     */     
/* 419 */     il.append(Utility.createSet(factory, (Member)AjcMemberMaker.perCflowField((UnresolvedType)this.aspectType)));
/* 420 */     method.getBody().insert(il);
/*     */   }
/*     */   
/*     */   private void generatePerTWAspectOfMethod(LazyClassGen classGen) {
/* 424 */     InstructionFactory factory = classGen.getFactory();
/* 425 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perTypeWithinAspectOfMethod((UnresolvedType)this.aspectType, classGen.getWorld()
/* 426 */           .isInJava5Mode()));
/* 427 */     flagAsSynthetic(method, false);
/* 428 */     classGen.addMethodGen(method);
/*     */     
/* 430 */     InstructionList il = method.getBody();
/* 431 */     InstructionHandle tryStart = il.append((Instruction)InstructionConstants.ALOAD_0);
/*     */     
/* 433 */     il.append(Utility.createInvoke(factory, (short)184, (Member)AjcMemberMaker.perTypeWithinGetInstance((UnresolvedType)this.aspectType)));
/* 434 */     il.append((Instruction)InstructionConstants.ASTORE_1);
/* 435 */     il.append((Instruction)InstructionConstants.ALOAD_1);
/* 436 */     InstructionBranch ifNonNull = InstructionFactory.createBranchInstruction((short)199, null);
/* 437 */     il.append(ifNonNull);
/* 438 */     il.append(factory.createNew(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName()));
/* 439 */     il.append(InstructionConstants.DUP);
/* 440 */     il.append(InstructionFactory.PUSH(classGen.getConstantPool(), this.aspectType.getName()));
/* 441 */     il.append(InstructionConstants.ACONST_NULL);
/* 442 */     il.append((Instruction)factory.createInvoke(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName(), "<init>", (Type)Type.VOID, new Type[] { (Type)Type.STRING, (Type)new ObjectType("java.lang.Throwable") }, (short)183));
/*     */     
/* 444 */     il.append(InstructionConstants.ATHROW);
/* 445 */     InstructionHandle ifElse = il.append((Instruction)InstructionConstants.ALOAD_1);
/* 446 */     ifNonNull.setTarget(ifElse);
/* 447 */     il.append(InstructionFactory.createReturn((Type)Type.OBJECT));
/*     */     
/* 449 */     InstructionHandle handler = il.append((Instruction)InstructionConstants.ASTORE_1);
/* 450 */     il.append(factory.createNew(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName()));
/* 451 */     il.append(InstructionConstants.DUP);
/* 452 */     il.append((Instruction)factory.createInvoke(AjcMemberMaker.NO_ASPECT_BOUND_EXCEPTION.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/*     */     
/* 454 */     il.append(InstructionConstants.ATHROW);
/*     */     
/* 456 */     method.addExceptionHandler(tryStart, handler.getPrev(), handler, new ObjectType("java.lang.Exception"), false);
/*     */   }
/*     */ 
/*     */   
/*     */   private void generatePerTWGetWithinTypeNameMethod(LazyClassGen classGen) {
/* 461 */     InstructionFactory factory = classGen.getFactory();
/* 462 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perTypeWithinGetWithinTypeNameMethod((UnresolvedType)this.aspectType, classGen
/* 463 */           .getWorld().isInJava5Mode()));
/* 464 */     flagAsSynthetic(method, false);
/* 465 */     classGen.addMethodGen(method);
/*     */ 
/*     */ 
/*     */     
/* 469 */     InstructionList il = method.getBody();
/* 470 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 471 */     il.append(Utility.createGet(factory, (Member)AjcMemberMaker.perTypeWithinWithinTypeField((UnresolvedType)this.aspectType, this.aspectType)));
/* 472 */     il.append(InstructionConstants.ARETURN);
/*     */   }
/*     */   
/*     */   private void generatePerTWHasAspectMethod(LazyClassGen classGen) {
/* 476 */     InstructionFactory factory = classGen.getFactory();
/* 477 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perTypeWithinHasAspectMethod((UnresolvedType)this.aspectType, classGen.getWorld()
/* 478 */           .isInJava5Mode()));
/* 479 */     flagAsSynthetic(method, false);
/* 480 */     classGen.addMethodGen(method);
/*     */     
/* 482 */     InstructionList il = method.getBody();
/* 483 */     InstructionHandle tryStart = il.append((Instruction)InstructionConstants.ALOAD_0);
/* 484 */     il.append(Utility.createInvoke(factory, (short)184, (Member)AjcMemberMaker.perTypeWithinGetInstance((UnresolvedType)this.aspectType)));
/* 485 */     InstructionBranch ifNull = InstructionFactory.createBranchInstruction((short)198, null);
/* 486 */     il.append(ifNull);
/* 487 */     il.append(InstructionConstants.ICONST_1);
/* 488 */     il.append(InstructionConstants.IRETURN);
/* 489 */     InstructionHandle ifElse = il.append(InstructionConstants.ICONST_0);
/* 490 */     ifNull.setTarget(ifElse);
/* 491 */     il.append(InstructionConstants.IRETURN);
/*     */     
/* 493 */     InstructionHandle handler = il.append((Instruction)InstructionConstants.ASTORE_1);
/* 494 */     il.append(InstructionConstants.ICONST_0);
/* 495 */     il.append(InstructionConstants.IRETURN);
/*     */     
/* 497 */     method.addExceptionHandler(tryStart, handler.getPrev(), handler, new ObjectType("java.lang.Exception"), false);
/*     */   }
/*     */   
/*     */   private void generatePerTWGetInstanceMethod(LazyClassGen classGen) {
/* 501 */     InstructionFactory factory = classGen.getFactory();
/* 502 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perTypeWithinGetInstance((UnresolvedType)this.aspectType));
/* 503 */     flagAsSynthetic(method, true);
/* 504 */     classGen.addMethodGen(method);
/*     */     
/* 506 */     InstructionList il = method.getBody();
/* 507 */     InstructionHandle tryStart = il.append((Instruction)InstructionConstants.ALOAD_0);
/* 508 */     il.append(InstructionFactory.PUSH(factory.getConstantPool(), NameMangler.perTypeWithinLocalAspectOf((UnresolvedType)this.aspectType)));
/* 509 */     il.append(InstructionConstants.ACONST_NULL);
/* 510 */     il.append((Instruction)factory.createInvoke("java/lang/Class", "getDeclaredMethod", Type.getType("Ljava/lang/reflect/Method;"), new Type[] {
/* 511 */             Type.getType("Ljava/lang/String;"), Type.getType("[Ljava/lang/Class;") }, (short)182));
/* 512 */     il.append(InstructionConstants.ACONST_NULL);
/* 513 */     il.append(InstructionConstants.ACONST_NULL);
/* 514 */     il.append((Instruction)factory.createInvoke("java/lang/reflect/Method", "invoke", (Type)Type.OBJECT, new Type[] {
/* 515 */             Type.getType("Ljava/lang/Object;"), Type.getType("[Ljava/lang/Object;") }, (short)182));
/* 516 */     il.append(factory.createCheckCast((ReferenceType)BcelWorld.makeBcelType((UnresolvedType)this.aspectType)));
/* 517 */     il.append(InstructionConstants.ARETURN);
/*     */     
/* 519 */     InstructionHandle handler = il.append((Instruction)InstructionConstants.ASTORE_1);
/* 520 */     il.append(InstructionConstants.ACONST_NULL);
/* 521 */     il.append(InstructionConstants.ARETURN);
/*     */     
/* 523 */     method.addExceptionHandler(tryStart, handler.getPrev(), handler, new ObjectType("java.lang.Exception"), false);
/*     */   }
/*     */   
/*     */   private void generatePerTWCreateAspectInstanceMethod(LazyClassGen classGen) {
/* 527 */     InstructionFactory factory = classGen.getFactory();
/* 528 */     LazyMethodGen method = makeMethodGen(classGen, AjcMemberMaker.perTypeWithinCreateAspectInstance((UnresolvedType)this.aspectType));
/* 529 */     flagAsSynthetic(method, true);
/* 530 */     classGen.addMethodGen(method);
/*     */     
/* 532 */     InstructionList il = method.getBody();
/* 533 */     il.append(factory.createNew(this.aspectType.getName()));
/* 534 */     il.append(InstructionConstants.DUP);
/* 535 */     il.append((Instruction)factory.createInvoke(this.aspectType.getName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/* 536 */     il.append((Instruction)InstructionConstants.ASTORE_1);
/* 537 */     il.append((Instruction)InstructionConstants.ALOAD_1);
/* 538 */     il.append((Instruction)InstructionConstants.ALOAD_0);
/* 539 */     il.append(Utility.createSet(factory, (Member)AjcMemberMaker.perTypeWithinWithinTypeField((UnresolvedType)this.aspectType, this.aspectType)));
/* 540 */     il.append((Instruction)InstructionConstants.ALOAD_1);
/* 541 */     il.append(InstructionConstants.ARETURN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void flagAsSynthetic(LazyMethodGen methodGen, boolean makeJavaSynthetic) {
/* 551 */     if (makeJavaSynthetic) {
/* 552 */       methodGen.makeSynthetic();
/*     */     }
/* 554 */     methodGen.addAttribute(
/* 555 */         Utility.bcelAttribute((AjAttribute)new AjAttribute.AjSynthetic(), methodGen.getEnclosingClass().getConstantPool()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelPerClauseAspectAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */