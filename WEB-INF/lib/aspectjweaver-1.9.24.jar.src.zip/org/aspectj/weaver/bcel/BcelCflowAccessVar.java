/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ import org.aspectj.apache.bcel.generic.Instruction;
/*    */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*    */ import org.aspectj.apache.bcel.generic.InstructionList;
/*    */ import org.aspectj.apache.bcel.generic.Type;
/*    */ import org.aspectj.weaver.Member;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BcelCflowAccessVar
/*    */   extends BcelVar
/*    */ {
/*    */   private Member stackField;
/*    */   private int index;
/*    */   
/*    */   public BcelCflowAccessVar(ResolvedType type, Member stackField, int index) {
/* 40 */     super(type, 0);
/* 41 */     this.stackField = stackField;
/* 42 */     this.index = index;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 46 */     return "BcelCflowAccessVar(" + getType() + " " + this.stackField + "." + this.index + ")";
/*    */   }
/*    */   
/*    */   public Instruction createLoad(InstructionFactory fact) {
/* 50 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */   
/*    */   public Instruction createStore(InstructionFactory fact) {
/* 54 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */   
/*    */   public InstructionList createCopyFrom(InstructionFactory fact, int oldSlot) {
/* 58 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */   
/*    */   public void appendLoad(InstructionList il, InstructionFactory fact) {
/* 62 */     il.append(createLoadInstructions(getType(), fact));
/*    */   }
/*    */   
/*    */   public InstructionList createLoadInstructions(ResolvedType toType, InstructionFactory fact) {
/* 66 */     InstructionList il = new InstructionList();
/*    */     
/* 68 */     il.append(Utility.createGet(fact, this.stackField));
/* 69 */     il.append(Utility.createConstant(fact, this.index));
/* 70 */     il.append((Instruction)fact.createInvoke("org.aspectj.runtime.internal.CFlowStack", "get", (Type)Type.OBJECT, new Type[] { (Type)Type.INT }, (short)182));
/*    */     
/* 72 */     il.append(Utility.createConversion(fact, (Type)Type.OBJECT, BcelWorld.makeBcelType((UnresolvedType)toType)));
/*    */     
/* 74 */     return il;
/*    */   }
/*    */ 
/*    */   
/*    */   public void appendLoadAndConvert(InstructionList il, InstructionFactory fact, ResolvedType toType) {
/* 79 */     il.append(createLoadInstructions(toType, fact));
/*    */   }
/*    */ 
/*    */   
/*    */   public void insertLoad(InstructionList il, InstructionFactory fact) {
/* 84 */     il.insert(createLoadInstructions(getType(), fact));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelCflowAccessVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */