/*    */ package org.aspectj.weaver.bcel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnwovenClassFileWithThirdPartyManagedBytecode
/*    */   extends UnwovenClassFile
/*    */ {
/*    */   IByteCodeProvider provider;
/*    */   
/*    */   public UnwovenClassFileWithThirdPartyManagedBytecode(String filename, String classname, IByteCodeProvider provider) {
/* 29 */     super(filename, classname, null);
/* 30 */     this.provider = provider;
/*    */   }
/*    */   
/*    */   public byte[] getBytes() {
/* 34 */     return this.provider.getBytes();
/*    */   }
/*    */   
/*    */   public static interface IByteCodeProvider {
/*    */     byte[] getBytes();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\UnwovenClassFileWithThirdPartyManagedBytecode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */