/*      */ package org.aspectj.weaver.bcel;
/*      */ 
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.aspectj.apache.bcel.classfile.Attribute;
/*      */ import org.aspectj.apache.bcel.classfile.ClassFormatException;
/*      */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*      */ import org.aspectj.apache.bcel.classfile.Signature;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*      */ import org.aspectj.apache.bcel.generic.BranchHandle;
/*      */ import org.aspectj.apache.bcel.generic.FieldGen;
/*      */ import org.aspectj.apache.bcel.generic.Instruction;
/*      */ import org.aspectj.apache.bcel.generic.InstructionBranch;
/*      */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*      */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*      */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*      */ import org.aspectj.apache.bcel.generic.InstructionList;
/*      */ import org.aspectj.apache.bcel.generic.InvokeInstruction;
/*      */ import org.aspectj.apache.bcel.generic.Type;
/*      */ import org.aspectj.asm.AsmManager;
/*      */ import org.aspectj.asm.IProgramElement;
/*      */ import org.aspectj.bridge.IMessage;
/*      */ import org.aspectj.bridge.ISourceLocation;
/*      */ import org.aspectj.bridge.Message;
/*      */ import org.aspectj.bridge.MessageUtil;
/*      */ import org.aspectj.bridge.WeaveMessage;
/*      */ import org.aspectj.bridge.context.CompilationAndWeavingContext;
/*      */ import org.aspectj.bridge.context.ContextToken;
/*      */ import org.aspectj.weaver.AjcMemberMaker;
/*      */ import org.aspectj.weaver.AnnotationAJ;
/*      */ import org.aspectj.weaver.AnnotationOnTypeMunger;
/*      */ import org.aspectj.weaver.BCException;
/*      */ import org.aspectj.weaver.ConcreteTypeMunger;
/*      */ import org.aspectj.weaver.Member;
/*      */ import org.aspectj.weaver.MemberUtils;
/*      */ import org.aspectj.weaver.MethodDelegateTypeMunger;
/*      */ import org.aspectj.weaver.NameMangler;
/*      */ import org.aspectj.weaver.NewConstructorTypeMunger;
/*      */ import org.aspectj.weaver.NewFieldTypeMunger;
/*      */ import org.aspectj.weaver.NewMemberClassTypeMunger;
/*      */ import org.aspectj.weaver.NewMethodTypeMunger;
/*      */ import org.aspectj.weaver.NewParentTypeMunger;
/*      */ import org.aspectj.weaver.PerObjectInterfaceTypeMunger;
/*      */ import org.aspectj.weaver.PrivilegedAccessMunger;
/*      */ import org.aspectj.weaver.ReferenceType;
/*      */ import org.aspectj.weaver.ResolvedMember;
/*      */ import org.aspectj.weaver.ResolvedMemberImpl;
/*      */ import org.aspectj.weaver.ResolvedType;
/*      */ import org.aspectj.weaver.ResolvedTypeMunger;
/*      */ import org.aspectj.weaver.Shadow;
/*      */ import org.aspectj.weaver.TypeVariableReference;
/*      */ import org.aspectj.weaver.UnresolvedType;
/*      */ import org.aspectj.weaver.WeaverMessages;
/*      */ import org.aspectj.weaver.WeaverStateInfo;
/*      */ import org.aspectj.weaver.World;
/*      */ import org.aspectj.weaver.model.AsmRelationshipProvider;
/*      */ import org.aspectj.weaver.patterns.DeclareAnnotation;
/*      */ import org.aspectj.weaver.patterns.Pointcut;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BcelTypeMunger
/*      */   extends ConcreteTypeMunger
/*      */ {
/*      */   private volatile int hashCode;
/*      */   
/*      */   public BcelTypeMunger(ResolvedTypeMunger munger, ResolvedType aspectType) {
/*   80 */     super(munger, aspectType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2162 */     this.hashCode = 0;
/*      */   }
/*      */   
/*      */   public int hashCode() {
/* 2166 */     if (this.hashCode == 0) {
/* 2167 */       int result = 17;
/* 2168 */       result = 37 * result + ((getMunger() == null) ? 0 : getMunger().hashCode());
/* 2169 */       result = 37 * result + ((getAspectType() == null) ? 0 : getAspectType().hashCode());
/* 2170 */       this.hashCode = result;
/*      */     } 
/* 2172 */     return this.hashCode;
/*      */   }
/*      */   
/*      */   public String toString() {
/*      */     return "(BcelTypeMunger " + getMunger() + ")";
/*      */   }
/*      */   
/*      */   public boolean shouldOverwrite() {
/*      */     return false;
/*      */   }
/*      */   
/*      */   public boolean munge(BcelClassWeaver weaver) {
/*      */     ContextToken tok = CompilationAndWeavingContext.enteringPhase(32, this);
/*      */     boolean changed = false;
/*      */     boolean worthReporting = true;
/*      */     if (weaver.getWorld().isOverWeaving()) {
/*      */       WeaverStateInfo typeWeaverState = weaver.getLazyClassGen().getType().getWeaverState();
/*      */       if (typeWeaverState != null && typeWeaverState.isAspectAlreadyApplied(getAspectType()))
/*      */         return false; 
/*      */     } 
/*      */     if (this.munger.getKind() == ResolvedTypeMunger.Field) {
/*      */       changed = mungeNewField(weaver, (NewFieldTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.Method) {
/*      */       changed = mungeNewMethod(weaver, (NewMethodTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.InnerClass) {
/*      */       changed = mungeNewMemberType(weaver, (NewMemberClassTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.MethodDelegate2) {
/*      */       changed = mungeMethodDelegate(weaver, (MethodDelegateTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.FieldHost) {
/*      */       changed = mungeFieldHost(weaver, (MethodDelegateTypeMunger.FieldHostTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.PerObjectInterface) {
/*      */       changed = mungePerObjectInterface(weaver, (PerObjectInterfaceTypeMunger)this.munger);
/*      */       worthReporting = false;
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.PerTypeWithinInterface) {
/*      */       changed = mungePerTypeWithinTransformer(weaver);
/*      */       worthReporting = false;
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.PrivilegedAccess) {
/*      */       changed = mungePrivilegedAccess(weaver, (PrivilegedAccessMunger)this.munger);
/*      */       worthReporting = false;
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.Constructor) {
/*      */       changed = mungeNewConstructor(weaver, (NewConstructorTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.Parent) {
/*      */       changed = mungeNewParent(weaver, (NewParentTypeMunger)this.munger);
/*      */     } else if (this.munger.getKind() == ResolvedTypeMunger.AnnotationOnType) {
/*      */       changed = mungeNewAnnotationOnType(weaver, (AnnotationOnTypeMunger)this.munger);
/*      */       worthReporting = false;
/*      */     } else {
/*      */       throw new RuntimeException("unimplemented");
/*      */     } 
/*      */     if (changed && this.munger.changesPublicSignature()) {
/*      */       WeaverStateInfo info = weaver.getLazyClassGen().getOrCreateWeaverStateInfo(weaver.getReweavableMode());
/*      */       info.addConcreteMunger(this);
/*      */     } 
/*      */     if (changed && worthReporting) {
/*      */       ResolvedType declaringAspect = null;
/*      */       AsmManager model = ((BcelWorld)getWorld()).getModelAsAsmManager();
/*      */       if (model != null)
/*      */         if (this.munger instanceof NewParentTypeMunger) {
/*      */           NewParentTypeMunger nptMunger = (NewParentTypeMunger)this.munger;
/*      */           declaringAspect = nptMunger.getDeclaringType();
/*      */           if (declaringAspect.isParameterizedOrGenericType())
/*      */             declaringAspect = declaringAspect.getRawType(); 
/*      */           ResolvedType thisAspect = getAspectType();
/*      */           AsmRelationshipProvider.addRelationship(model, weaver.getLazyClassGen().getType(), this.munger, thisAspect);
/*      */           if (!thisAspect.equals(declaringAspect)) {
/*      */             ResolvedType target = weaver.getLazyClassGen().getType();
/*      */             ResolvedType newParent = nptMunger.getNewParent();
/*      */             IProgramElement thisAspectNode = model.getHierarchy().findElementForType(thisAspect.getPackageName(), thisAspect.getClassName());
/*      */             Map<String, List<String>> declareParentsMap = thisAspectNode.getDeclareParentsMap();
/*      */             if (declareParentsMap == null) {
/*      */               declareParentsMap = new HashMap<>();
/*      */               thisAspectNode.setDeclareParentsMap(declareParentsMap);
/*      */             } 
/*      */             String tname = target.getName();
/*      */             String pname = newParent.getName();
/*      */             List<String> newparents = declareParentsMap.computeIfAbsent(tname, k -> new ArrayList());
/*      */             newparents.add(pname);
/*      */             AsmRelationshipProvider.addRelationship(model, weaver.getLazyClassGen().getType(), this.munger, declaringAspect);
/*      */           } 
/*      */         } else {
/*      */           declaringAspect = getAspectType();
/*      */           AsmRelationshipProvider.addRelationship(model, weaver.getLazyClassGen().getType(), this.munger, declaringAspect);
/*      */         }  
/*      */     } 
/*      */     if (changed && worthReporting && this.munger != null && !weaver.getWorld().getMessageHandler().isIgnoring(IMessage.WEAVEINFO)) {
/*      */       String tName = weaver.getLazyClassGen().getType().getSourceLocation().getSourceFile().getName();
/*      */       if (tName.contains("no debug info available")) {
/*      */         tName = "no debug info available";
/*      */       } else {
/*      */         tName = getShortname(weaver.getLazyClassGen().getType().getSourceLocation().getSourceFile().getPath());
/*      */       } 
/*      */       String fName = getShortname(getAspectType().getSourceLocation().getSourceFile().getPath());
/*      */       if (this.munger.getKind().equals(ResolvedTypeMunger.Parent)) {
/*      */         NewParentTypeMunger parentTM = (NewParentTypeMunger)this.munger;
/*      */         if (parentTM.isMixin()) {
/*      */           weaver.getWorld().getMessageHandler().handleMessage((IMessage)WeaveMessage.constructWeavingMessage(WeaveMessage.WEAVEMESSAGE_MIXIN, new String[] { parentTM.getNewParent().getName(), fName, weaver.getLazyClassGen().getType().getName(), tName }, weaver.getLazyClassGen().getClassName(), getAspectType().getName(), parentTM.getNewParent().getSourceLocation(), weaver.getLazyClassGen().getType().getSourceLocation()));
/*      */         } else if (parentTM.getNewParent().isInterface()) {
/*      */           weaver.getWorld().getMessageHandler().handleMessage((IMessage)WeaveMessage.constructWeavingMessage(WeaveMessage.WEAVEMESSAGE_DECLAREPARENTSIMPLEMENTS, new String[] { weaver.getLazyClassGen().getType().getName(), tName, parentTM.getNewParent().getName(), fName }, weaver.getLazyClassGen().getClassName(), getAspectType().getName(), parentTM.getNewParent().getSourceLocation(), weaver.getLazyClassGen().getType().getSourceLocation()));
/*      */         } else {
/*      */           weaver.getWorld().getMessageHandler().handleMessage((IMessage)WeaveMessage.constructWeavingMessage(WeaveMessage.WEAVEMESSAGE_DECLAREPARENTSEXTENDS, new String[] { weaver.getLazyClassGen().getType().getName(), tName, parentTM.getNewParent().getName(), fName }));
/*      */         } 
/*      */       } else if (!this.munger.getKind().equals(ResolvedTypeMunger.FieldHost)) {
/*      */         ResolvedMember declaredSig = this.munger.getSignature();
/*      */         String fromString = fName + ":'" + declaredSig + "'";
/*      */         String kindString = this.munger.getKind().toString().toLowerCase();
/*      */         if (kindString.equals("innerclass")) {
/*      */           kindString = "member class";
/*      */           fromString = fName;
/*      */         } 
/*      */         weaver.getWorld().getMessageHandler().handleMessage((IMessage)WeaveMessage.constructWeavingMessage(WeaveMessage.WEAVEMESSAGE_ITD, new String[] { weaver.getLazyClassGen().getType().getName(), tName, kindString, getAspectType().getName(), fromString }, weaver.getLazyClassGen().getClassName(), getAspectType().getName(), weaver.getLazyClassGen().getType().getSourceLocation(), getAspectType().getSourceLocation()));
/*      */       } 
/*      */     } 
/*      */     CompilationAndWeavingContext.leavingPhase(tok);
/*      */     return changed;
/*      */   }
/*      */   
/*      */   private String getShortname(String path) {
/*      */     int takefrom = path.lastIndexOf('/');
/*      */     if (takefrom == -1)
/*      */       takefrom = path.lastIndexOf('\\'); 
/*      */     return path.substring(takefrom + 1);
/*      */   }
/*      */   
/*      */   private boolean mungeNewAnnotationOnType(BcelClassWeaver weaver, AnnotationOnTypeMunger munger) {
/*      */     try {
/*      */       BcelAnnotation anno = (BcelAnnotation)munger.getNewAnnotation();
/*      */       weaver.getLazyClassGen().addAnnotation(anno.getBcelAnnotation());
/*      */     } catch (ClassCastException cce) {
/*      */       throw new IllegalStateException("DiagnosticsFor318237: The typemunger " + munger + " contains an annotation of type " + munger.getNewAnnotation().getClass().getName() + " when it should be a BcelAnnotation", cce);
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private boolean mungeNewParent(BcelClassWeaver weaver, NewParentTypeMunger typeTransformer) {
/*      */     LazyClassGen newParentTarget = weaver.getLazyClassGen();
/*      */     ResolvedType newParent = typeTransformer.getNewParent();
/*      */     boolean performChange = true;
/*      */     performChange = enforceDecpRule1_abstractMethodsImplemented(weaver, typeTransformer.getSourceLocation(), newParentTarget, newParent);
/*      */     performChange = (enforceDecpRule2_cantExtendFinalClass(weaver, typeTransformer.getSourceLocation(), newParentTarget, newParent) && performChange);
/*      */     List<ResolvedMember> methods = newParent.getMethodsWithoutIterator(false, true, false);
/*      */     for (ResolvedMember method : methods) {
/*      */       if (!method.getName().equals("<init>")) {
/*      */         LazyMethodGen subMethod = findMatchingMethod(newParentTarget, method);
/*      */         if (subMethod != null && !subMethod.isBridgeMethod() && (!subMethod.isSynthetic() || !method.isSynthetic()) && (!subMethod.isStatic() || !subMethod.getName().startsWith("access$"))) {
/*      */           performChange = (enforceDecpRule3_visibilityChanges(weaver, newParent, method, subMethod) && performChange);
/*      */           performChange = (enforceDecpRule4_compatibleReturnTypes(weaver, method, subMethod) && performChange);
/*      */           performChange = (enforceDecpRule5_cantChangeFromStaticToNonstatic(weaver, typeTransformer.getSourceLocation(), method, subMethod) && performChange);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     if (!performChange)
/*      */       return false; 
/*      */     if (newParent.isClass()) {
/*      */       if (!attemptToModifySuperCalls(weaver, newParentTarget, newParent))
/*      */         return false; 
/*      */       newParentTarget.setSuperClass(newParent);
/*      */     } else {
/*      */       newParentTarget.addInterface(newParent, getSourceLocation());
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private boolean enforceDecpRule1_abstractMethodsImplemented(BcelClassWeaver weaver, ISourceLocation mungerLoc, LazyClassGen newParentTarget, ResolvedType newParent) {
/*      */     if (newParentTarget.isAbstract() || newParentTarget.isInterface())
/*      */       return true; 
/*      */     boolean ruleCheckingSucceeded = true;
/*      */     List<ResolvedMember> newParentMethods = newParent.getMethodsWithoutIterator(false, true, false);
/*      */     for (ResolvedMember newParentMethod : newParentMethods) {
/*      */       String newParentMethodName = newParentMethod.getName();
/*      */       if (newParentMethod.isAbstract() && !newParentMethodName.startsWith("ajc$interField")) {
/*      */         ResolvedMember discoveredImpl = null;
/*      */         List<ResolvedMember> targetMethods = newParentTarget.getType().getMethodsWithoutIterator(false, true, false);
/*      */         for (ResolvedMember targetMethod : targetMethods) {
/*      */           if (!targetMethod.isAbstract() && targetMethod.getName().equals(newParentMethodName)) {
/*      */             String newParentMethodSig = newParentMethod.getParameterSignature();
/*      */             String targetMethodSignature = targetMethod.getParameterSignature();
/*      */             if (targetMethodSignature.equals(newParentMethodSig)) {
/*      */               discoveredImpl = targetMethod;
/*      */             } else if (targetMethod.hasBackingGenericMember() && targetMethod.getBackingGenericMember().getParameterSignature().equals(newParentMethodSig)) {
/*      */               discoveredImpl = targetMethod;
/*      */             } else if (newParentMethod.hasBackingGenericMember()) {
/*      */               if (newParentMethod.getBackingGenericMember().getParameterSignature().equals(targetMethodSignature)) {
/*      */                 discoveredImpl = targetMethod;
/*      */               } else if (targetMethod instanceof BcelMethod) {
/*      */                 UnresolvedType[] targetMethodGenericParameterTypes = targetMethod.getGenericParameterTypes();
/*      */                 if (targetMethodGenericParameterTypes != null) {
/*      */                   StringBuilder b = new StringBuilder("(");
/*      */                   for (UnresolvedType p : targetMethodGenericParameterTypes)
/*      */                     b.append(p.getSignature()); 
/*      */                   b.append(')');
/*      */                   if (b.toString().equals(newParentMethodSig))
/*      */                     discoveredImpl = targetMethod; 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             if (discoveredImpl != null)
/*      */               break; 
/*      */           } 
/*      */         } 
/*      */         if (discoveredImpl == null) {
/*      */           boolean satisfiedByITD = false;
/*      */           for (ConcreteTypeMunger m : newParentTarget.getType().getInterTypeMungersIncludingSupers()) {
/*      */             if (m.getMunger() != null && m.getMunger().getKind() == ResolvedTypeMunger.Method) {
/*      */               ResolvedMember sig = m.getSignature();
/*      */               if (!Modifier.isAbstract(sig.getModifiers())) {
/*      */                 if (m.isTargetTypeParameterized()) {
/*      */                   ReferenceType referenceType = getWorld().resolve(sig.getDeclaringType()).getGenericType();
/*      */                   ResolvedType actualOccurrence = newParent.discoverActualOccurrenceOfTypeInHierarchy((ResolvedType)referenceType);
/*      */                   if (actualOccurrence == null)
/*      */                     actualOccurrence = newParentTarget.getType().discoverActualOccurrenceOfTypeInHierarchy((ResolvedType)referenceType); 
/*      */                   m = m.parameterizedFor(actualOccurrence);
/*      */                   sig = m.getSignature();
/*      */                 } 
/*      */                 if (ResolvedType.matches((Member)AjcMemberMaker.interMethod(sig, (UnresolvedType)m.getAspectType(), sig.getDeclaringType().resolve(weaver.getWorld()).isInterface()), (Member)newParentMethod))
/*      */                   satisfiedByITD = true; 
/*      */               } 
/*      */               continue;
/*      */             } 
/*      */             if (m.getMunger() != null && m.getMunger().getKind() == ResolvedTypeMunger.MethodDelegate2)
/*      */               satisfiedByITD = true; 
/*      */           } 
/*      */           if (!satisfiedByITD) {
/*      */             error(weaver, "The type " + newParentTarget.getName() + " must implement the inherited abstract method " + newParentMethod.getDeclaringType() + "." + newParentMethodName + newParentMethod.getParameterSignature(), newParentTarget.getType().getSourceLocation(), new ISourceLocation[] { newParentMethod.getSourceLocation(), mungerLoc });
/*      */             ruleCheckingSucceeded = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     return ruleCheckingSucceeded;
/*      */   }
/*      */   
/*      */   private boolean enforceDecpRule2_cantExtendFinalClass(BcelClassWeaver weaver, ISourceLocation transformerLoc, LazyClassGen targetType, ResolvedType newParent) {
/*      */     if (newParent.isFinal()) {
/*      */       error(weaver, "Cannot make type " + targetType.getName() + " extend final class " + newParent.getName(), targetType.getType().getSourceLocation(), new ISourceLocation[] { transformerLoc });
/*      */       return false;
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private boolean enforceDecpRule3_visibilityChanges(BcelClassWeaver weaver, ResolvedType newParent, ResolvedMember superMethod, LazyMethodGen subMethod) {
/*      */     boolean cont = true;
/*      */     if (Modifier.isPublic(superMethod.getModifiers())) {
/*      */       if (subMethod.isProtected() || subMethod.isDefault() || subMethod.isPrivate()) {
/*      */         weaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("Cannot reduce the visibility of the inherited method '" + superMethod + "' from " + newParent.getName(), superMethod.getSourceLocation()));
/*      */         cont = false;
/*      */       } 
/*      */     } else if (Modifier.isProtected(superMethod.getModifiers())) {
/*      */       if (subMethod.isDefault() || subMethod.isPrivate()) {
/*      */         weaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("Cannot reduce the visibility of the inherited method '" + superMethod + "' from " + newParent.getName(), superMethod.getSourceLocation()));
/*      */         cont = false;
/*      */       } 
/*      */     } else if (superMethod.isDefault() && subMethod.isPrivate()) {
/*      */       weaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("Cannot reduce the visibility of the inherited method '" + superMethod + "' from " + newParent.getName(), superMethod.getSourceLocation()));
/*      */       cont = false;
/*      */     } 
/*      */     return cont;
/*      */   }
/*      */   
/*      */   private boolean enforceDecpRule4_compatibleReturnTypes(BcelClassWeaver weaver, ResolvedMember superMethod, LazyMethodGen subMethod) {
/*      */     boolean cont = true;
/*      */     String superReturnTypeSig = superMethod.getGenericReturnType().getSignature();
/*      */     String subReturnTypeSig = subMethod.getGenericReturnTypeSignature();
/*      */     superReturnTypeSig = superReturnTypeSig.replace('.', '/');
/*      */     subReturnTypeSig = subReturnTypeSig.replace('.', '/');
/*      */     if (!superReturnTypeSig.equals(subReturnTypeSig)) {
/*      */       ResolvedType subType = weaver.getWorld().resolve(subMethod.getReturnType());
/*      */       ResolvedType superType = weaver.getWorld().resolve(superMethod.getReturnType());
/*      */       boolean isError = false;
/*      */       if (weaver.getWorld().isInJava5Mode())
/*      */         if (superType.isPrimitiveType() && !subType.isPrimitiveType()) {
/*      */           isError = true;
/*      */         } else if (subType.isPrimitiveType() && !superType.isPrimitiveType()) {
/*      */           isError = true;
/*      */         }  
/*      */       if (!isError && !superType.isAssignableFrom(subType))
/*      */         isError = true; 
/*      */       if (isError) {
/*      */         weaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("The return type is incompatible with " + superMethod.getDeclaringType() + "." + superMethod.getName() + superMethod.getParameterSignature(), subMethod.getSourceLocation()));
/*      */         cont = false;
/*      */       } 
/*      */     } 
/*      */     return cont;
/*      */   }
/*      */   
/*      */   private boolean enforceDecpRule5_cantChangeFromStaticToNonstatic(BcelClassWeaver weaver, ISourceLocation mungerLoc, ResolvedMember superMethod, LazyMethodGen subMethod) {
/*      */     boolean superMethodStatic = Modifier.isStatic(superMethod.getModifiers());
/*      */     if (superMethodStatic && !subMethod.isStatic()) {
/*      */       error(weaver, "This instance method " + subMethod.getName() + subMethod.getParameterSignature() + " cannot override the static method from " + superMethod.getDeclaringType().getName(), subMethod.getSourceLocation(), new ISourceLocation[] { mungerLoc });
/*      */       return false;
/*      */     } 
/*      */     if (!superMethodStatic && subMethod.isStatic()) {
/*      */       error(weaver, "The static method " + subMethod.getName() + subMethod.getParameterSignature() + " cannot hide the instance method from " + superMethod.getDeclaringType().getName(), subMethod.getSourceLocation(), new ISourceLocation[] { mungerLoc });
/*      */       return false;
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   public void error(BcelClassWeaver weaver, String text, ISourceLocation primaryLoc, ISourceLocation[] extraLocs) {
/*      */     Message message = new Message(text, primaryLoc, true, extraLocs);
/*      */     weaver.getWorld().getMessageHandler().handleMessage((IMessage)message);
/*      */   }
/*      */   
/*      */   private LazyMethodGen findMatchingMethod(LazyClassGen type, ResolvedMember searchMethod) {
/*      */     String searchName = searchMethod.getName();
/*      */     String searchSig = searchMethod.getParameterSignature();
/*      */     for (LazyMethodGen method : type.getMethodGens()) {
/*      */       if (method.getName().equals(searchName) && method.getParameterSignature().equals(searchSig))
/*      */         return method; 
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   public boolean attemptToModifySuperCalls(BcelClassWeaver weaver, LazyClassGen newParentTarget, ResolvedType newParent) {
/*      */     ReferenceType referenceType1, referenceType2;
/*      */     ResolvedType currentParentType = newParentTarget.getSuperClass();
/*      */     if (currentParentType.getGenericType() != null)
/*      */       referenceType2 = currentParentType.getGenericType(); 
/*      */     String currentParent = referenceType2.getName();
/*      */     if (newParent.getGenericType() != null)
/*      */       referenceType1 = newParent.getGenericType(); 
/*      */     List<LazyMethodGen> mgs = newParentTarget.getMethodGens();
/*      */     for (LazyMethodGen aMethod : mgs) {
/*      */       if (LazyMethodGen.isConstructor(aMethod)) {
/*      */         InstructionList insList = aMethod.getBody();
/*      */         InstructionHandle handle = insList.getStart();
/*      */         while (handle != null) {
/*      */           if ((handle.getInstruction()).opcode == 183) {
/*      */             ConstantPool cpg = newParentTarget.getConstantPool();
/*      */             InvokeInstruction invokeSpecial = (InvokeInstruction)handle.getInstruction();
/*      */             if (invokeSpecial.getClassName(cpg).equals(currentParent) && invokeSpecial.getMethodName(cpg).equals("<init>")) {
/*      */               ResolvedMember newCtor = getConstructorWithSignature((ResolvedType)referenceType1, invokeSpecial.getSignature(cpg));
/*      */               if (newCtor == null) {
/*      */                 boolean satisfiedByITDC = false;
/*      */                 for (Iterator<ConcreteTypeMunger> ii = newParentTarget.getType().getInterTypeMungersIncludingSupers().iterator(); ii.hasNext() && !satisfiedByITDC; ) {
/*      */                   ConcreteTypeMunger m = ii.next();
/*      */                   if (m.getMunger() instanceof NewConstructorTypeMunger && m.getSignature().getSignature().equals(invokeSpecial.getSignature(cpg)))
/*      */                     satisfiedByITDC = true; 
/*      */                 } 
/*      */                 if (!satisfiedByITDC) {
/*      */                   String csig = createReadableCtorSig((ResolvedType)referenceType1, cpg, invokeSpecial);
/*      */                   weaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("Unable to modify hierarchy for " + newParentTarget.getClassName() + " - the constructor " + csig + " is missing", getSourceLocation()));
/*      */                   return false;
/*      */                 } 
/*      */               } 
/*      */               int idx = cpg.addMethodref(referenceType1.getName(), invokeSpecial.getMethodName(cpg), invokeSpecial.getSignature(cpg));
/*      */               invokeSpecial.setIndex(idx);
/*      */             } 
/*      */           } 
/*      */           handle = handle.getNext();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private String createReadableCtorSig(ResolvedType newParent, ConstantPool cpg, InvokeInstruction invokeSpecial) {
/*      */     StringBuilder sb = new StringBuilder();
/*      */     Type[] ctorArgs = invokeSpecial.getArgumentTypes(cpg);
/*      */     sb.append(newParent.getClassName());
/*      */     sb.append("(");
/*      */     for (int i = 0; i < ctorArgs.length; i++) {
/*      */       String argtype = ctorArgs[i].toString();
/*      */       if (argtype.lastIndexOf(".") != -1) {
/*      */         sb.append(argtype.substring(argtype.lastIndexOf(".") + 1));
/*      */       } else {
/*      */         sb.append(argtype);
/*      */       } 
/*      */       if (i + 1 < ctorArgs.length)
/*      */         sb.append(","); 
/*      */     } 
/*      */     sb.append(")");
/*      */     return sb.toString();
/*      */   }
/*      */   
/*      */   private ResolvedMember getConstructorWithSignature(ResolvedType type, String searchSig) {
/*      */     for (ResolvedMember method : type.getDeclaredJavaMethods()) {
/*      */       if (MemberUtils.isConstructor(method) && method.getSignature().equals(searchSig))
/*      */         return method; 
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   private boolean mungePrivilegedAccess(BcelClassWeaver weaver, PrivilegedAccessMunger munger) {
/*      */     ReferenceType referenceType;
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     ResolvedMember member = munger.getMember();
/*      */     ResolvedType onType = weaver.getWorld().resolve(member.getDeclaringType(), munger.getSourceLocation());
/*      */     if (onType.isRawType())
/*      */       referenceType = onType.getGenericType(); 
/*      */     if (referenceType.equals(gen.getType())) {
/*      */       if (member.getKind() == Member.FIELD) {
/*      */         addFieldGetter(gen, member, AjcMemberMaker.privilegedAccessMethodForFieldGet((UnresolvedType)this.aspectType, (Member)member, munger.shortSyntax));
/*      */         addFieldSetter(gen, member, AjcMemberMaker.privilegedAccessMethodForFieldSet((UnresolvedType)this.aspectType, (Member)member, munger.shortSyntax));
/*      */         return true;
/*      */       } 
/*      */       if (member.getKind() == Member.METHOD) {
/*      */         addMethodDispatch(gen, member, AjcMemberMaker.privilegedAccessMethodForMethod((UnresolvedType)this.aspectType, member));
/*      */         return true;
/*      */       } 
/*      */       if (member.getKind() == Member.CONSTRUCTOR) {
/*      */         for (LazyMethodGen m : gen.getMethodGens()) {
/*      */           if (m.getMemberView() != null && m.getMemberView().getKind() == Member.CONSTRUCTOR)
/*      */             m.forcePublic(); 
/*      */         } 
/*      */         return true;
/*      */       } 
/*      */       if (member.getKind() == Member.STATIC_INITIALIZATION) {
/*      */         gen.forcePublic();
/*      */         return true;
/*      */       } 
/*      */       throw new RuntimeException("unimplemented");
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private void addFieldGetter(LazyClassGen gen, ResolvedMember field, ResolvedMember accessMethod) {
/*      */     LazyMethodGen mg = makeMethodGen(gen, accessMethod);
/*      */     InstructionList il = new InstructionList();
/*      */     InstructionFactory fact = gen.getFactory();
/*      */     if (Modifier.isStatic(field.getModifiers())) {
/*      */       il.append((Instruction)fact.createFieldAccess(gen.getClassName(), field.getName(), BcelWorld.makeBcelType(field.getType()), (short)178));
/*      */     } else {
/*      */       il.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       il.append((Instruction)fact.createFieldAccess(gen.getClassName(), field.getName(), BcelWorld.makeBcelType(field.getType()), (short)180));
/*      */     } 
/*      */     il.append(InstructionFactory.createReturn(BcelWorld.makeBcelType(field.getType())));
/*      */     mg.getBody().insert(il);
/*      */     gen.addMethodGen(mg, getSignature().getSourceLocation());
/*      */   }
/*      */   
/*      */   private void addFieldSetter(LazyClassGen gen, ResolvedMember field, ResolvedMember accessMethod) {
/*      */     LazyMethodGen mg = makeMethodGen(gen, accessMethod);
/*      */     InstructionList il = new InstructionList();
/*      */     InstructionFactory fact = gen.getFactory();
/*      */     Type fieldType = BcelWorld.makeBcelType(field.getType());
/*      */     if (Modifier.isStatic(field.getModifiers())) {
/*      */       il.append((Instruction)InstructionFactory.createLoad(fieldType, 0));
/*      */       il.append((Instruction)fact.createFieldAccess(gen.getClassName(), field.getName(), fieldType, (short)179));
/*      */     } else {
/*      */       il.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       il.append((Instruction)InstructionFactory.createLoad(fieldType, 1));
/*      */       il.append((Instruction)fact.createFieldAccess(gen.getClassName(), field.getName(), fieldType, (short)181));
/*      */     } 
/*      */     il.append(InstructionFactory.createReturn((Type)Type.VOID));
/*      */     mg.getBody().insert(il);
/*      */     gen.addMethodGen(mg, getSignature().getSourceLocation());
/*      */   }
/*      */   
/*      */   private void addMethodDispatch(LazyClassGen gen, ResolvedMember method, ResolvedMember accessMethod) {
/*      */     LazyMethodGen mg = makeMethodGen(gen, accessMethod);
/*      */     InstructionList il = new InstructionList();
/*      */     InstructionFactory fact = gen.getFactory();
/*      */     Type[] paramTypes = BcelWorld.makeBcelTypes(method.getParameterTypes());
/*      */     int pos = 0;
/*      */     if (!Modifier.isStatic(method.getModifiers())) {
/*      */       il.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       pos++;
/*      */     } 
/*      */     for (Type paramType : paramTypes) {
/*      */       il.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */       pos += paramType.getSize();
/*      */     } 
/*      */     il.append(Utility.createInvoke(fact, (BcelWorld)this.aspectType.getWorld(), (Member)method));
/*      */     il.append(InstructionFactory.createReturn(BcelWorld.makeBcelType(method.getReturnType())));
/*      */     mg.getBody().insert(il);
/*      */     gen.addMethodGen(mg);
/*      */   }
/*      */   
/*      */   protected LazyMethodGen makeMethodGen(LazyClassGen gen, ResolvedMember member) {
/*      */     try {
/*      */       Type returnType = BcelWorld.makeBcelType(member.getReturnType());
/*      */       Type[] parameterTypes = BcelWorld.makeBcelTypes(member.getParameterTypes());
/*      */       LazyMethodGen ret = new LazyMethodGen(member.getModifiers(), returnType, member.getName(), parameterTypes, UnresolvedType.getNames(member.getExceptions()), gen);
/*      */       return ret;
/*      */     } catch (ClassFormatException cfe) {
/*      */       throw new RuntimeException("Problem with makeMethodGen for method " + member.getName() + " in type " + gen.getName() + "  ret=" + member.getReturnType(), cfe);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected FieldGen makeFieldGen(LazyClassGen gen, ResolvedMember member) {
/*      */     return new FieldGen(member.getModifiers(), BcelWorld.makeBcelType(member.getReturnType()), member.getName(), gen.getConstantPool());
/*      */   }
/*      */   
/*      */   private boolean mungePerObjectInterface(BcelClassWeaver weaver, PerObjectInterfaceTypeMunger munger) {
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     if (couldMatch(gen.getBcelObjectType(), munger.getTestPointcut())) {
/*      */       FieldGen fg = makeFieldGen(gen, AjcMemberMaker.perObjectField((UnresolvedType)gen.getType(), this.aspectType));
/*      */       gen.addField(fg, getSourceLocation());
/*      */       Type fieldType = BcelWorld.makeBcelType((UnresolvedType)this.aspectType);
/*      */       LazyMethodGen mg = new LazyMethodGen(1, fieldType, NameMangler.perObjectInterfaceGet((UnresolvedType)this.aspectType), Type.NO_ARGS, new String[0], gen);
/*      */       InstructionList il = new InstructionList();
/*      */       InstructionFactory fact = gen.getFactory();
/*      */       il.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       il.append((Instruction)fact.createFieldAccess(gen.getClassName(), fg.getName(), fieldType, (short)180));
/*      */       il.append(InstructionFactory.createReturn(fieldType));
/*      */       mg.getBody().insert(il);
/*      */       gen.addMethodGen(mg);
/*      */       LazyMethodGen mg1 = new LazyMethodGen(1, (Type)Type.VOID, NameMangler.perObjectInterfaceSet((UnresolvedType)this.aspectType), new Type[] { fieldType }, new String[0], gen);
/*      */       InstructionList il1 = new InstructionList();
/*      */       il1.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       il1.append((Instruction)InstructionFactory.createLoad(fieldType, 1));
/*      */       il1.append((Instruction)fact.createFieldAccess(gen.getClassName(), fg.getName(), fieldType, (short)181));
/*      */       il1.append(InstructionFactory.createReturn((Type)Type.VOID));
/*      */       mg1.getBody().insert(il1);
/*      */       gen.addMethodGen(mg1);
/*      */       gen.addInterface(munger.getInterfaceType().resolve(weaver.getWorld()), getSourceLocation());
/*      */       return true;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private boolean mungePerTypeWithinTransformer(BcelClassWeaver weaver) {
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     FieldGen fg = makeFieldGen(gen, AjcMemberMaker.perTypeWithinField((UnresolvedType)gen.getType(), this.aspectType));
/*      */     gen.addField(fg, getSourceLocation());
/*      */     if (!gen.getType().canBeSeenBy(this.aspectType) && this.aspectType.isPrivilegedAspect())
/*      */       gen.forcePublic(); 
/*      */     Type fieldType = BcelWorld.makeBcelType((UnresolvedType)this.aspectType);
/*      */     LazyMethodGen mg = new LazyMethodGen(9, fieldType, NameMangler.perTypeWithinLocalAspectOf((UnresolvedType)this.aspectType), Type.NO_ARGS, new String[0], gen);
/*      */     InstructionList il = new InstructionList();
/*      */     InstructionFactory fact = gen.getFactory();
/*      */     il.append((Instruction)fact.createFieldAccess(gen.getClassName(), fg.getName(), fieldType, (short)178));
/*      */     il.append(InstructionFactory.createReturn(fieldType));
/*      */     mg.getBody().insert(il);
/*      */     gen.addMethodGen(mg);
/*      */     return true;
/*      */   }
/*      */   
/*      */   private boolean couldMatch(BcelObjectType bcelObjectType, Pointcut pointcut) {
/*      */     return !bcelObjectType.isInterface();
/*      */   }
/*      */   
/*      */   private boolean mungeNewMemberType(BcelClassWeaver classWeaver, NewMemberClassTypeMunger munger) {
/*      */     ReferenceType referenceType;
/*      */     World world = classWeaver.getWorld();
/*      */     ResolvedType onType = world.resolve(munger.getTargetType());
/*      */     if (onType.isRawType())
/*      */       referenceType = onType.getGenericType(); 
/*      */     return referenceType.equals(classWeaver.getLazyClassGen().getType());
/*      */   }
/*      */   
/*      */   private boolean mungeNewMethod(BcelClassWeaver classWeaver, NewMethodTypeMunger munger) {
/*      */     ReferenceType referenceType;
/*      */     World world = classWeaver.getWorld();
/*      */     ResolvedMember unMangledInterMethod = munger.getSignature().resolve(world);
/*      */     ResolvedMember interMethodBody = munger.getDeclaredInterMethodBody((UnresolvedType)this.aspectType, world);
/*      */     ResolvedMember interMethodDispatcher = munger.getDeclaredInterMethodDispatcher((UnresolvedType)this.aspectType, world);
/*      */     ResolvedMember memberHoldingAnyAnnotations = interMethodDispatcher;
/*      */     LazyClassGen classGen = classWeaver.getLazyClassGen();
/*      */     ResolvedType onType = world.resolve(unMangledInterMethod.getDeclaringType(), munger.getSourceLocation());
/*      */     if (onType.isRawType())
/*      */       referenceType = onType.getGenericType(); 
/*      */     if (referenceType.isAnnotation()) {
/*      */       signalError("itdmOnAnnotationNotAllowed", classWeaver, (UnresolvedType)referenceType);
/*      */       return false;
/*      */     } 
/*      */     if (referenceType.isEnum()) {
/*      */       signalError("itdmOnEnumNotAllowed", classWeaver, (UnresolvedType)referenceType);
/*      */       return false;
/*      */     } 
/*      */     boolean mungingInterface = classGen.isInterface();
/*      */     boolean onInterface = referenceType.isInterface();
/*      */     if (onInterface && classGen.getLazyMethodGen(unMangledInterMethod.getName(), unMangledInterMethod.getSignature(), true) != null)
/*      */       return false; 
/*      */     if (referenceType.equals(classGen.getType())) {
/*      */       ResolvedMember mangledInterMethod = AjcMemberMaker.interMethod(unMangledInterMethod, (UnresolvedType)this.aspectType, onInterface);
/*      */       LazyMethodGen newMethod = makeMethodGen(classGen, mangledInterMethod);
/*      */       if (mungingInterface)
/*      */         newMethod.setAccessFlags(1025); 
/*      */       if (classWeaver.getWorld().isInJava5Mode()) {
/*      */         ReferenceType referenceType1;
/*      */         AnnotationAJ[] annotationsOnRealMember = null;
/*      */         ResolvedType toLookOn = this.aspectType;
/*      */         if (this.aspectType.isRawType())
/*      */           referenceType1 = this.aspectType.getGenericType(); 
/*      */         ResolvedMember realMember = getRealMemberForITDFromAspect((ResolvedType)referenceType1, memberHoldingAnyAnnotations, false);
/*      */         if (realMember != null)
/*      */           annotationsOnRealMember = realMember.getAnnotations(); 
/*      */         Set<ResolvedType> addedAnnotations = new HashSet<>();
/*      */         if (annotationsOnRealMember != null)
/*      */           for (AnnotationAJ anno : annotationsOnRealMember) {
/*      */             AnnotationGen a = ((BcelAnnotation)anno).getBcelAnnotation();
/*      */             AnnotationGen ag = new AnnotationGen(a, classGen.getConstantPool(), true);
/*      */             newMethod.addAnnotation((AnnotationAJ)new BcelAnnotation(ag, classWeaver.getWorld()));
/*      */             addedAnnotations.add(anno.getType());
/*      */           }  
/*      */         if (realMember != null)
/*      */           copyOverParameterAnnotations(newMethod, realMember); 
/*      */         List<DeclareAnnotation> allDecams = world.getDeclareAnnotationOnMethods();
/*      */         for (DeclareAnnotation declareAnnotationMC : allDecams) {
/*      */           if (declareAnnotationMC.matches(unMangledInterMethod, world)) {
/*      */             AnnotationAJ annotation = declareAnnotationMC.getAnnotation();
/*      */             if (!addedAnnotations.contains(annotation.getType()))
/*      */               newMethod.addAnnotation(annotation); 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       if (!onInterface && !Modifier.isAbstract(mangledInterMethod.getModifiers())) {
/*      */         InstructionList body = newMethod.getBody();
/*      */         InstructionFactory fact = classGen.getFactory();
/*      */         int pos = 0;
/*      */         if (!Modifier.isStatic(unMangledInterMethod.getModifiers())) {
/*      */           body.append(InstructionFactory.createThis());
/*      */           pos++;
/*      */         } 
/*      */         Type[] paramTypes = BcelWorld.makeBcelTypes(mangledInterMethod.getParameterTypes());
/*      */         for (Type paramType : paramTypes) {
/*      */           body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */           pos += paramType.getSize();
/*      */         } 
/*      */         body.append(Utility.createInvoke(fact, classWeaver.getWorld(), (Member)interMethodBody));
/*      */         body.append(InstructionFactory.createReturn(BcelWorld.makeBcelType(mangledInterMethod.getReturnType())));
/*      */         if (classWeaver.getWorld().isInJava5Mode())
/*      */           createAnyBridgeMethodsForCovariance(classWeaver, munger, unMangledInterMethod, (ResolvedType)referenceType, classGen, paramTypes); 
/*      */       } 
/*      */       if (world.isInJava5Mode()) {
/*      */         String basicSignature = mangledInterMethod.getSignature();
/*      */         String genericSignature = ((ResolvedMemberImpl)mangledInterMethod).getSignatureForAttribute();
/*      */         if (!basicSignature.equals(genericSignature))
/*      */           newMethod.addAttribute((Attribute)createSignatureAttribute(classGen.getConstantPool(), genericSignature)); 
/*      */       } 
/*      */       classWeaver.addLazyMethodGen(newMethod);
/*      */       classWeaver.getLazyClassGen().warnOnAddedMethod(newMethod.getMethod(), getSignature().getSourceLocation());
/*      */       addNeededSuperCallMethods(classWeaver, (ResolvedType)referenceType, munger.getSuperMethodsCalled());
/*      */       return true;
/*      */     } 
/*      */     if (onInterface && !Modifier.isAbstract(unMangledInterMethod.getModifiers())) {
/*      */       if (!classGen.getType().isTopmostImplementor((ResolvedType)referenceType)) {
/*      */         ResolvedType rtx = classGen.getType().getTopmostImplementor((ResolvedType)referenceType);
/*      */         if (rtx == null) {
/*      */           ResolvedType rt = classGen.getType();
/*      */           if (rt.isInterface()) {
/*      */             ISourceLocation sloc = munger.getSourceLocation();
/*      */             classWeaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("ITD target " + rt.getName() + " is an interface but has been incorrectly determined to be the topmost implementor of " + referenceType.getName() + ". ITD is " + getSignature(), sloc));
/*      */           } 
/*      */           if (!referenceType.isAssignableFrom(rt)) {
/*      */             ISourceLocation sloc = munger.getSourceLocation();
/*      */             classWeaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error("ITD target " + rt.getName() + " doesn't appear to implement " + referenceType.getName() + " why did we consider it the top most implementor? ITD is " + getSignature(), sloc));
/*      */           } 
/*      */         } else if (!rtx.isExposedToWeaver()) {
/*      */           ISourceLocation sLoc = munger.getSourceLocation();
/*      */           classWeaver.getWorld().getMessageHandler().handleMessage(MessageUtil.error(WeaverMessages.format("itdNonExposedImplementor", rtx, getAspectType().getName()), (sLoc == null) ? getAspectType().getSourceLocation() : sLoc));
/*      */         } 
/*      */         return false;
/*      */       } 
/*      */       ResolvedMember mangledInterMethod = AjcMemberMaker.interMethod(unMangledInterMethod, (UnresolvedType)this.aspectType, false);
/*      */       LazyMethodGen mg = makeMethodGen(classGen, mangledInterMethod);
/*      */       if (classWeaver.getWorld().isInJava5Mode()) {
/*      */         ReferenceType referenceType1;
/*      */         AnnotationAJ[] annotationsOnRealMember = null;
/*      */         ResolvedType toLookOn = this.aspectType;
/*      */         if (this.aspectType.isRawType())
/*      */           referenceType1 = this.aspectType.getGenericType(); 
/*      */         ResolvedMember realMember = getRealMemberForITDFromAspect((ResolvedType)referenceType1, memberHoldingAnyAnnotations, false);
/*      */         if (realMember == null)
/*      */           throw new BCException("Couldn't find ITD holder member '" + memberHoldingAnyAnnotations + "' on aspect " + this.aspectType); 
/*      */         annotationsOnRealMember = realMember.getAnnotations();
/*      */         if (annotationsOnRealMember != null)
/*      */           for (AnnotationAJ annotationX : annotationsOnRealMember) {
/*      */             AnnotationGen a = ((BcelAnnotation)annotationX).getBcelAnnotation();
/*      */             AnnotationGen ag = new AnnotationGen(a, classWeaver.getLazyClassGen().getConstantPool(), true);
/*      */             mg.addAnnotation((AnnotationAJ)new BcelAnnotation(ag, classWeaver.getWorld()));
/*      */           }  
/*      */         copyOverParameterAnnotations(mg, realMember);
/*      */       } 
/*      */       if (mungingInterface)
/*      */         mg.setAccessFlags(1025); 
/*      */       Type[] paramTypes = BcelWorld.makeBcelTypes(mangledInterMethod.getParameterTypes());
/*      */       Type returnType = BcelWorld.makeBcelType(mangledInterMethod.getReturnType());
/*      */       InstructionList body = mg.getBody();
/*      */       InstructionFactory fact = classGen.getFactory();
/*      */       int pos = 0;
/*      */       if (!Modifier.isStatic(mangledInterMethod.getModifiers())) {
/*      */         body.append(InstructionFactory.createThis());
/*      */         pos++;
/*      */       } 
/*      */       for (Type paramType : paramTypes) {
/*      */         body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */         pos += paramType.getSize();
/*      */       } 
/*      */       body.append(Utility.createInvoke(fact, classWeaver.getWorld(), (Member)interMethodBody));
/*      */       Type t = BcelWorld.makeBcelType(interMethodBody.getReturnType());
/*      */       if (!t.equals(returnType))
/*      */         body.append(fact.createCast(t, returnType)); 
/*      */       body.append(InstructionFactory.createReturn(returnType));
/*      */       mg.definingType = (ResolvedType)referenceType;
/*      */       if (world.isInJava5Mode()) {
/*      */         String basicSignature = mangledInterMethod.getSignature();
/*      */         String genericSignature = ((ResolvedMemberImpl)mangledInterMethod).getSignatureForAttribute();
/*      */         if (!basicSignature.equals(genericSignature))
/*      */           mg.addAttribute((Attribute)createSignatureAttribute(classGen.getConstantPool(), genericSignature)); 
/*      */       } 
/*      */       classWeaver.addOrReplaceLazyMethodGen(mg);
/*      */       addNeededSuperCallMethods(classWeaver, (ResolvedType)referenceType, munger.getSuperMethodsCalled());
/*      */       createBridgeIfNecessary(classWeaver, munger, unMangledInterMethod, classGen);
/*      */       return true;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private void createBridgeIfNecessary(BcelClassWeaver classWeaver, NewMethodTypeMunger munger, ResolvedMember unMangledInterMethod, LazyClassGen classGen) {
/*      */     if (munger.getDeclaredSignature() != null) {
/*      */       boolean needsbridging = false;
/*      */       ResolvedMember mungerSignature = munger.getSignature();
/*      */       ResolvedMemberImpl resolvedMemberImpl = munger.getDeclaredSignature().parameterizedWith(null, mungerSignature.getDeclaringType().resolve(getWorld()), false, munger.getTypeVariableAliases());
/*      */       if (!resolvedMemberImpl.getReturnType().getErasureSignature().equals(mungerSignature.getReturnType().getErasureSignature()))
/*      */         needsbridging = true; 
/*      */       UnresolvedType[] originalParams = resolvedMemberImpl.getParameterTypes();
/*      */       UnresolvedType[] newParams = mungerSignature.getParameterTypes();
/*      */       for (int ii = 0; ii < originalParams.length; ii++) {
/*      */         if (!originalParams[ii].getErasureSignature().equals(newParams[ii].getErasureSignature()))
/*      */           needsbridging = true; 
/*      */       } 
/*      */       if (needsbridging)
/*      */         createBridge(classWeaver, unMangledInterMethod, classGen, (ResolvedMember)resolvedMemberImpl); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void copyOverParameterAnnotations(LazyMethodGen receiverMethod, ResolvedMember donorMethod) {
/*      */     AnnotationAJ[][] pAnnos = donorMethod.getParameterAnnotations();
/*      */     if (pAnnos != null) {
/*      */       int offset = receiverMethod.isStatic() ? 0 : 1;
/*      */       int param = 0;
/*      */       for (int i = offset; i < pAnnos.length; i++) {
/*      */         AnnotationAJ[] annosOnParam = pAnnos[i];
/*      */         if (annosOnParam != null)
/*      */           for (AnnotationAJ anno : annosOnParam)
/*      */             receiverMethod.addParameterAnnotation(param, anno);  
/*      */         param++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void createBridge(BcelClassWeaver weaver, ResolvedMember unMangledInterMethod, LazyClassGen classGen, ResolvedMember toBridgeTo) {
/*      */     ResolvedMember bridgerMethod = AjcMemberMaker.bridgerToInterMethod(unMangledInterMethod, (UnresolvedType)classGen.getType());
/*      */     ResolvedMember bridgingSetter = AjcMemberMaker.interMethodBridger(toBridgeTo, (UnresolvedType)this.aspectType, false);
/*      */     LazyMethodGen bridgeMethod = makeMethodGen(classGen, bridgingSetter);
/*      */     Type[] paramTypes = BcelWorld.makeBcelTypes(bridgingSetter.getParameterTypes());
/*      */     Type[] bridgingToParms = BcelWorld.makeBcelTypes(unMangledInterMethod.getParameterTypes());
/*      */     Type returnType = BcelWorld.makeBcelType(bridgingSetter.getReturnType());
/*      */     InstructionList body = bridgeMethod.getBody();
/*      */     InstructionFactory fact = classGen.getFactory();
/*      */     int pos = 0;
/*      */     if (!Modifier.isStatic(bridgingSetter.getModifiers())) {
/*      */       body.append(InstructionFactory.createThis());
/*      */       pos++;
/*      */     } 
/*      */     for (int i = 0, len = paramTypes.length; i < len; i++) {
/*      */       Type paramType = paramTypes[i];
/*      */       body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */       if (!bridgingSetter.getParameterTypes()[i].getErasureSignature().equals(unMangledInterMethod.getParameterTypes()[i].getErasureSignature()))
/*      */         body.append(fact.createCast(paramType, bridgingToParms[i])); 
/*      */       pos += paramType.getSize();
/*      */     } 
/*      */     body.append(Utility.createInvoke(fact, weaver.getWorld(), (Member)bridgerMethod));
/*      */     body.append(InstructionFactory.createReturn(returnType));
/*      */     classGen.addMethodGen(bridgeMethod);
/*      */   }
/*      */   
/*      */   private Signature createSignatureAttribute(ConstantPool cp, String signature) {
/*      */     int nameIndex = cp.addUtf8("Signature");
/*      */     int sigIndex = cp.addUtf8(signature);
/*      */     return new Signature(nameIndex, 2, sigIndex, cp);
/*      */   }
/*      */   
/*      */   private void createAnyBridgeMethodsForCovariance(BcelClassWeaver weaver, NewMethodTypeMunger munger, ResolvedMember unMangledInterMethod, ResolvedType onType, LazyClassGen gen, Type[] paramTypes) {
/*      */     boolean quitRightNow = false;
/*      */     String localMethodName = unMangledInterMethod.getName();
/*      */     String erasedSig = unMangledInterMethod.getSignatureErased();
/*      */     String localParameterSig = erasedSig.substring(0, erasedSig.lastIndexOf(')') + 1);
/*      */     String localReturnTypeESig = unMangledInterMethod.getReturnType().getErasureSignature();
/*      */     boolean alreadyDone = false;
/*      */     ResolvedMember[] localMethods = onType.getDeclaredMethods();
/*      */     for (ResolvedMember member : localMethods) {
/*      */       if (member.getName().equals(localMethodName))
/*      */         if (member.getParameterSignature().equals(localParameterSig))
/*      */           alreadyDone = true;  
/*      */     } 
/*      */     if (!alreadyDone) {
/*      */       ResolvedType supertype = onType.getSuperclass();
/*      */       if (supertype != null)
/*      */         for (Iterator<ResolvedMember> iter = supertype.getMethods(true, true); iter.hasNext() && !quitRightNow; ) {
/*      */           ResolvedMember aMethod = iter.next();
/*      */           if (aMethod.getName().equals(localMethodName) && aMethod.getParameterSignature().equals(localParameterSig))
/*      */             if (!aMethod.getReturnType().getErasureSignature().equals(localReturnTypeESig) && !Modifier.isPrivate(aMethod.getModifiers())) {
/*      */               createBridgeMethod(weaver.getWorld(), munger, unMangledInterMethod, gen, paramTypes, aMethod);
/*      */               quitRightNow = true;
/*      */             }  
/*      */         }  
/*      */     } 
/*      */   }
/*      */   
/*      */   private void createBridgeMethod(BcelWorld world, NewMethodTypeMunger munger, ResolvedMember unMangledInterMethod, LazyClassGen clazz, Type[] paramTypes, ResolvedMember theBridgeMethod) {
/*      */     int pos = 0;
/*      */     LazyMethodGen bridgeMethod = makeMethodGen(clazz, theBridgeMethod);
/*      */     bridgeMethod.setAccessFlags(bridgeMethod.getAccessFlags() | 0x40);
/*      */     Type returnType = BcelWorld.makeBcelType(theBridgeMethod.getReturnType());
/*      */     InstructionList body = bridgeMethod.getBody();
/*      */     InstructionFactory fact = clazz.getFactory();
/*      */     if (!Modifier.isStatic(unMangledInterMethod.getModifiers())) {
/*      */       body.append(InstructionFactory.createThis());
/*      */       pos++;
/*      */     } 
/*      */     for (Type paramType : paramTypes) {
/*      */       body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */       pos += paramType.getSize();
/*      */     } 
/*      */     body.append(Utility.createInvoke(fact, world, (Member)unMangledInterMethod));
/*      */     body.append(InstructionFactory.createReturn(returnType));
/*      */     clazz.addMethodGen(bridgeMethod);
/*      */   }
/*      */   
/*      */   private String stringifyMember(ResolvedMember member) {
/*      */     StringBuilder buf = new StringBuilder();
/*      */     buf.append(member.getReturnType().getName());
/*      */     buf.append(' ');
/*      */     buf.append(member.getName());
/*      */     if (member.getKind() != Member.FIELD) {
/*      */       buf.append("(");
/*      */       UnresolvedType[] params = member.getParameterTypes();
/*      */       if (params.length != 0) {
/*      */         buf.append(params[0]);
/*      */         for (int i = 1, len = params.length; i < len; i++) {
/*      */           buf.append(", ");
/*      */           buf.append(params[i].getName());
/*      */         } 
/*      */       } 
/*      */       buf.append(")");
/*      */     } 
/*      */     return buf.toString();
/*      */   }
/*      */   
/*      */   private boolean mungeMethodDelegate(BcelClassWeaver weaver, MethodDelegateTypeMunger munger) {
/*      */     ReferenceType referenceType;
/*      */     World world = weaver.getWorld();
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     if (gen.getType().isAnnotation() || gen.getType().isEnum())
/*      */       return false; 
/*      */     ResolvedMember introduced = munger.getSignature();
/*      */     ResolvedType fromType = world.resolve(introduced.getDeclaringType(), munger.getSourceLocation());
/*      */     if (fromType.isRawType())
/*      */       referenceType = fromType.getGenericType(); 
/*      */     boolean shouldApply = munger.matches(weaver.getLazyClassGen().getType(), this.aspectType);
/*      */     if (shouldApply) {
/*      */       Type bcelReturnType = BcelWorld.makeBcelType(introduced.getReturnType());
/*      */       if (munger.getImplClassName() == null && !munger.specifiesDelegateFactoryMethod()) {
/*      */         boolean isOK = false;
/*      */         List<LazyMethodGen> existingMethods = gen.getMethodGens();
/*      */         for (LazyMethodGen m : existingMethods) {
/*      */           if (m.getName().equals(introduced.getName()) && m.getParameterSignature().equals(introduced.getParameterSignature()) && m.getReturnType().equals(bcelReturnType))
/*      */             isOK = true; 
/*      */         } 
/*      */         if (!isOK) {
/*      */           Message message = new Message("@DeclareParents: No defaultImpl was specified but the type '" + gen.getName() + "' does not implement the method '" + stringifyMember(introduced) + "' defined on the interface '" + introduced.getDeclaringType() + "'", weaver.getLazyClassGen().getType().getSourceLocation(), true, new ISourceLocation[] { munger.getSourceLocation() });
/*      */           weaver.getWorld().getMessageHandler().handleMessage((IMessage)message);
/*      */           return false;
/*      */         } 
/*      */         return true;
/*      */       } 
/*      */       LazyMethodGen mg = new LazyMethodGen(introduced.getModifiers() - 1024, bcelReturnType, introduced.getName(), BcelWorld.makeBcelTypes(introduced.getParameterTypes()), BcelWorld.makeBcelTypesAsClassNames(introduced.getExceptions()), gen);
/*      */       if (weaver.getWorld().isInJava5Mode()) {
/*      */         AnnotationAJ[] annotationsOnRealMember = null;
/*      */         ReferenceType referenceType1 = weaver.getWorld().lookupOrCreateName(introduced.getDeclaringType());
/*      */         if (referenceType.isRawType())
/*      */           referenceType1 = referenceType.getGenericType(); 
/*      */         ResolvedMember[] ms = referenceType1.getDeclaredJavaMethods();
/*      */         for (ResolvedMember m : ms) {
/*      */           if (introduced.getName().equals(m.getName()) && introduced.getSignature().equals(m.getSignature())) {
/*      */             annotationsOnRealMember = m.getAnnotations();
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         if (annotationsOnRealMember != null)
/*      */           for (AnnotationAJ anno : annotationsOnRealMember) {
/*      */             AnnotationGen a = ((BcelAnnotation)anno).getBcelAnnotation();
/*      */             AnnotationGen ag = new AnnotationGen(a, weaver.getLazyClassGen().getConstantPool(), true);
/*      */             mg.addAnnotation((AnnotationAJ)new BcelAnnotation(ag, weaver.getWorld()));
/*      */           }  
/*      */       } 
/*      */       InstructionList body = new InstructionList();
/*      */       InstructionFactory fact = gen.getFactory();
/*      */       body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       body.append(Utility.createGet(fact, (Member)munger.getDelegate(weaver.getLazyClassGen().getType())));
/*      */       InstructionBranch outerIfNonNull = InstructionFactory.createBranchInstruction((short)199, null);
/*      */       body.append(outerIfNonNull);
/*      */       body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       body.append(InstructionConstants.MONITORENTER);
/*      */       InstructionHandle tryStart = body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       body.append(Utility.createGet(fact, (Member)munger.getDelegate(weaver.getLazyClassGen().getType())));
/*      */       InstructionBranch innerIfNonNull = InstructionFactory.createBranchInstruction((short)199, null);
/*      */       body.append(innerIfNonNull);
/*      */       body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       if (munger.specifiesDelegateFactoryMethod()) {
/*      */         ResolvedMember rm = munger.getDelegateFactoryMethod(weaver.getWorld());
/*      */         if (rm.getArity() != 0) {
/*      */           ResolvedType parameterType = rm.getParameterTypes()[0].resolve(weaver.getWorld());
/*      */           if (!parameterType.isAssignableFrom(weaver.getLazyClassGen().getType())) {
/*      */             signalError("For mixin factory method '" + rm + "': Instance type '" + weaver.getLazyClassGen().getType() + "' is not compatible with factory parameter type '" + parameterType + "'", weaver);
/*      */             return false;
/*      */           } 
/*      */         } 
/*      */         if (Modifier.isStatic(rm.getModifiers())) {
/*      */           if (rm.getArity() != 0)
/*      */             body.append((Instruction)InstructionConstants.ALOAD_0); 
/*      */           body.append((Instruction)fact.createInvoke(rm.getDeclaringType().getName(), rm.getName(), rm.getSignature(), (short)184));
/*      */           body.append(Utility.createSet(fact, (Member)munger.getDelegate(weaver.getLazyClassGen().getType())));
/*      */         } else {
/*      */           UnresolvedType theAspect = munger.getAspect();
/*      */           body.append((Instruction)fact.createInvoke(theAspect.getName(), "aspectOf", "()" + theAspect.getSignature(), (short)184));
/*      */           if (rm.getArity() != 0)
/*      */             body.append((Instruction)InstructionConstants.ALOAD_0); 
/*      */           body.append((Instruction)fact.createInvoke(rm.getDeclaringType().getName(), rm.getName(), rm.getSignature(), (short)182));
/*      */           body.append(Utility.createSet(fact, (Member)munger.getDelegate(weaver.getLazyClassGen().getType())));
/*      */         } 
/*      */       } else {
/*      */         body.append(fact.createNew(munger.getImplClassName()));
/*      */         body.append(InstructionConstants.DUP);
/*      */         body.append((Instruction)fact.createInvoke(munger.getImplClassName(), "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/*      */         body.append(Utility.createSet(fact, (Member)munger.getDelegate(weaver.getLazyClassGen().getType())));
/*      */       } 
/*      */       InstructionHandle ifNonNullElse = body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       innerIfNonNull.setTarget(ifNonNullElse);
/*      */       body.append(InstructionConstants.MONITOREXIT);
/*      */       InstructionBranch gotoAfterTryCatch = new InstructionBranch((short)167, null);
/*      */       BranchHandle branchHandle = body.append(gotoAfterTryCatch);
/*      */       InstructionHandle catchStart = body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       body.append(InstructionConstants.MONITOREXIT);
/*      */       InstructionHandle catchEnd = body.append(InstructionConstants.ATHROW);
/*      */       mg.addExceptionHandler(tryStart, branchHandle.getPrev(), catchStart, null, false);
/*      */       mg.addExceptionHandler(catchStart, catchEnd.getPrev(), catchStart, null, false);
/*      */       InstructionHandle afterTryCatch = body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */       gotoAfterTryCatch.setTarget(afterTryCatch);
/*      */       outerIfNonNull.setTarget(afterTryCatch);
/*      */       body.append(Utility.createGet(fact, (Member)munger.getDelegate(weaver.getLazyClassGen().getType())));
/*      */       int pos = 0;
/*      */       if (!Modifier.isStatic(introduced.getModifiers()))
/*      */         pos++; 
/*      */       Type[] paramTypes = BcelWorld.makeBcelTypes(introduced.getParameterTypes());
/*      */       for (Type paramType : paramTypes) {
/*      */         body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */         pos += paramType.getSize();
/*      */       } 
/*      */       body.append(Utility.createInvoke(fact, (short)185, (Member)introduced));
/*      */       body.append(InstructionFactory.createReturn(bcelReturnType));
/*      */       mg.getBody().append(body);
/*      */       weaver.addLazyMethodGen(mg);
/*      */       weaver.getLazyClassGen().warnOnAddedMethod(mg.getMethod(), getSignature().getSourceLocation());
/*      */       return true;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private boolean mungeFieldHost(BcelClassWeaver weaver, MethodDelegateTypeMunger.FieldHostTypeMunger munger) {
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     if (gen.getType().isAnnotation() || gen.getType().isEnum())
/*      */       return false; 
/*      */     munger.matches(weaver.getLazyClassGen().getType(), this.aspectType);
/*      */     ResolvedMember host = AjcMemberMaker.itdAtDeclareParentsField(weaver.getLazyClassGen().getType(), munger.getSignature().getType(), (UnresolvedType)this.aspectType);
/*      */     FieldGen field = makeFieldGen(weaver.getLazyClassGen(), host);
/*      */     field.setModifiers(field.getModifiers() | BcelField.AccSynthetic);
/*      */     weaver.getLazyClassGen().addField(field, null);
/*      */     return true;
/*      */   }
/*      */   
/*      */   private ResolvedMember getRealMemberForITDFromAspect(ResolvedType aspectType, ResolvedMember lookingFor, boolean isCtorRelated) {
/*      */     World world = aspectType.getWorld();
/*      */     boolean debug = false;
/*      */     if (debug) {
/*      */       System.err.println("Searching for a member on type: " + aspectType);
/*      */       System.err.println("Member we are looking for: " + lookingFor);
/*      */     } 
/*      */     ResolvedMember[] aspectMethods = aspectType.getDeclaredMethods();
/*      */     UnresolvedType[] lookingForParams = lookingFor.getParameterTypes();
/*      */     ResolvedMember realMember = null;
/*      */     for (int i = 0; realMember == null && i < aspectMethods.length; i++) {
/*      */       ResolvedMember member = aspectMethods[i];
/*      */       if (member.getName().equals(lookingFor.getName())) {
/*      */         UnresolvedType[] memberParams = member.getGenericParameterTypes();
/*      */         if (memberParams.length == lookingForParams.length) {
/*      */           if (debug)
/*      */             System.err.println("Reviewing potential candidates: " + member); 
/*      */           boolean matchOK = true;
/*      */           for (int j = 0; j < memberParams.length && matchOK; j++) {
/*      */             ResolvedType pMember = memberParams[j].resolve(world);
/*      */             ResolvedType pLookingFor = lookingForParams[j].resolve(world);
/*      */             if (pMember.isTypeVariableReference())
/*      */               pMember = ((TypeVariableReference)pMember).getTypeVariable().getFirstBound().resolve(world); 
/*      */             if (pMember.isParameterizedType() || pMember.isGenericType())
/*      */               pMember = pMember.getRawType().resolve(aspectType.getWorld()); 
/*      */             if (pLookingFor.isTypeVariableReference())
/*      */               pLookingFor = ((TypeVariableReference)pLookingFor).getTypeVariable().getFirstBound().resolve(world); 
/*      */             if (pLookingFor.isParameterizedType() || pLookingFor.isGenericType())
/*      */               pLookingFor = pLookingFor.getRawType().resolve(world); 
/*      */             if (debug)
/*      */               System.err.println("Comparing parameter " + j + "   member=" + pMember + "   lookingFor=" + pLookingFor); 
/*      */             if (!pMember.equals(pLookingFor))
/*      */               matchOK = false; 
/*      */           } 
/*      */           if (matchOK)
/*      */             realMember = member; 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     if (debug && realMember == null)
/*      */       System.err.println("Didn't find a match"); 
/*      */     return realMember;
/*      */   }
/*      */   
/*      */   private void addNeededSuperCallMethods(BcelClassWeaver weaver, ResolvedType onType, Set<ResolvedMember> neededSuperCalls) {
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     for (ResolvedMember superMethod : neededSuperCalls) {
/*      */       if (weaver.addDispatchTarget(superMethod)) {
/*      */         String dispatchName;
/*      */         boolean isSuper = !superMethod.getDeclaringType().equals(gen.getType());
/*      */         if (isSuper) {
/*      */           dispatchName = NameMangler.superDispatchMethod((UnresolvedType)onType, superMethod.getName());
/*      */         } else {
/*      */           dispatchName = NameMangler.protectedDispatchMethod((UnresolvedType)onType, superMethod.getName());
/*      */         } 
/*      */         superMethod = superMethod.resolve(weaver.getWorld());
/*      */         LazyMethodGen dispatcher = makeDispatcher(gen, dispatchName, superMethod, weaver.getWorld(), isSuper);
/*      */         weaver.addLazyMethodGen(dispatcher);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void signalError(String msgid, BcelClassWeaver weaver, UnresolvedType onType) {
/*      */     IMessage msg = MessageUtil.error(WeaverMessages.format(msgid, onType.getName()), getSourceLocation());
/*      */     weaver.getWorld().getMessageHandler().handleMessage(msg);
/*      */   }
/*      */   
/*      */   private void signalError(String msgString, BcelClassWeaver weaver) {
/*      */     IMessage msg = MessageUtil.error(msgString, getSourceLocation());
/*      */     weaver.getWorld().getMessageHandler().handleMessage(msg);
/*      */   }
/*      */   
/*      */   private boolean mungeNewConstructor(BcelClassWeaver weaver, NewConstructorTypeMunger newConstructorTypeMunger) {
/*      */     ReferenceType referenceType;
/*      */     LazyClassGen currentClass = weaver.getLazyClassGen();
/*      */     InstructionFactory fact = currentClass.getFactory();
/*      */     ResolvedMember newConstructorMember = newConstructorTypeMunger.getSyntheticConstructor();
/*      */     ResolvedType onType = newConstructorMember.getDeclaringType().resolve(weaver.getWorld());
/*      */     if (onType.isRawType())
/*      */       referenceType = onType.getGenericType(); 
/*      */     if (referenceType.isAnnotation()) {
/*      */       signalError("itdcOnAnnotationNotAllowed", weaver, (UnresolvedType)referenceType);
/*      */       return false;
/*      */     } 
/*      */     if (referenceType.isEnum()) {
/*      */       signalError("itdcOnEnumNotAllowed", weaver, (UnresolvedType)referenceType);
/*      */       return false;
/*      */     } 
/*      */     if (!referenceType.equals(currentClass.getType()))
/*      */       return false; 
/*      */     ResolvedMember explicitConstructor = newConstructorTypeMunger.getExplicitConstructor();
/*      */     LazyMethodGen mg = makeMethodGen(currentClass, newConstructorMember);
/*      */     mg.setEffectiveSignature(newConstructorTypeMunger.getSignature(), Shadow.ConstructorExecution, true);
/*      */     if (weaver.getWorld().isInJava5Mode()) {
/*      */       ResolvedMember interMethodDispatcher = AjcMemberMaker.postIntroducedConstructor((UnresolvedType)this.aspectType, (UnresolvedType)referenceType, newConstructorTypeMunger.getSignature().getParameterTypes());
/*      */       AnnotationAJ[] annotationsOnRealMember = null;
/*      */       ResolvedMember realMember = getRealMemberForITDFromAspect(this.aspectType, interMethodDispatcher, true);
/*      */       if (realMember != null)
/*      */         annotationsOnRealMember = realMember.getAnnotations(); 
/*      */       if (annotationsOnRealMember != null)
/*      */         for (AnnotationAJ annotationX : annotationsOnRealMember) {
/*      */           AnnotationGen a = ((BcelAnnotation)annotationX).getBcelAnnotation();
/*      */           AnnotationGen ag = new AnnotationGen(a, weaver.getLazyClassGen().getConstantPool(), true);
/*      */           mg.addAnnotation((AnnotationAJ)new BcelAnnotation(ag, weaver.getWorld()));
/*      */         }  
/*      */       List<DeclareAnnotation> allDecams = weaver.getWorld().getDeclareAnnotationOnMethods();
/*      */       for (DeclareAnnotation decaMC : allDecams) {
/*      */         if (decaMC.matches(explicitConstructor, weaver.getWorld()) && mg.getEnclosingClass().getType() == this.aspectType)
/*      */           mg.addAnnotation(decaMC.getAnnotation()); 
/*      */       } 
/*      */     } 
/*      */     if ((mg.getArgumentTypes()).length == 0) {
/*      */       LazyMethodGen toRemove = null;
/*      */       for (LazyMethodGen object : currentClass.getMethodGens()) {
/*      */         if (object.getName().equals("<init>") && (object.getArgumentTypes()).length == 0)
/*      */           toRemove = object; 
/*      */       } 
/*      */       if (toRemove != null)
/*      */         currentClass.removeMethodGen(toRemove); 
/*      */     } 
/*      */     currentClass.addMethodGen(mg);
/*      */     InstructionList body = mg.getBody();
/*      */     UnresolvedType[] declaredParams = newConstructorTypeMunger.getSignature().getParameterTypes();
/*      */     Type[] paramTypes = mg.getArgumentTypes();
/*      */     int frameIndex = 1;
/*      */     for (int i = 0, len = declaredParams.length; i < len; i++) {
/*      */       body.append((Instruction)InstructionFactory.createLoad(paramTypes[i], frameIndex));
/*      */       frameIndex += paramTypes[i].getSize();
/*      */     } 
/*      */     ResolvedMember resolvedMember1 = AjcMemberMaker.preIntroducedConstructor((UnresolvedType)this.aspectType, (UnresolvedType)referenceType, declaredParams);
/*      */     body.append(Utility.createInvoke(fact, (BcelWorld)null, (Member)resolvedMember1));
/*      */     int arraySlot = mg.allocateLocal(1);
/*      */     body.append((Instruction)InstructionFactory.createStore((Type)Type.OBJECT, arraySlot));
/*      */     body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */     UnresolvedType[] superParamTypes = explicitConstructor.getParameterTypes();
/*      */     for (int j = 0, k = superParamTypes.length; j < k; j++) {
/*      */       body.append((Instruction)InstructionFactory.createLoad((Type)Type.OBJECT, arraySlot));
/*      */       body.append(Utility.createConstant(fact, j));
/*      */       body.append(InstructionFactory.createArrayLoad((Type)Type.OBJECT));
/*      */       body.append(Utility.createConversion(fact, (Type)Type.OBJECT, BcelWorld.makeBcelType(superParamTypes[j])));
/*      */     } 
/*      */     body.append(Utility.createInvoke(fact, (BcelWorld)null, (Member)explicitConstructor));
/*      */     body.append((Instruction)InstructionConstants.ALOAD_0);
/*      */     ResolvedMember resolvedMember2 = AjcMemberMaker.postIntroducedConstructor((UnresolvedType)this.aspectType, (UnresolvedType)referenceType, declaredParams);
/*      */     UnresolvedType[] postParamTypes = resolvedMember2.getParameterTypes();
/*      */     for (int m = 1, n = postParamTypes.length; m < n; m++) {
/*      */       body.append((Instruction)InstructionFactory.createLoad((Type)Type.OBJECT, arraySlot));
/*      */       body.append(Utility.createConstant(fact, superParamTypes.length + m - 1));
/*      */       body.append(InstructionFactory.createArrayLoad((Type)Type.OBJECT));
/*      */       body.append(Utility.createConversion(fact, (Type)Type.OBJECT, BcelWorld.makeBcelType(postParamTypes[m])));
/*      */     } 
/*      */     body.append(Utility.createInvoke(fact, (BcelWorld)null, (Member)resolvedMember2));
/*      */     body.append(InstructionConstants.RETURN);
/*      */     addNeededSuperCallMethods(weaver, (ResolvedType)referenceType, this.munger.getSuperMethodsCalled());
/*      */     return true;
/*      */   }
/*      */   
/*      */   private static LazyMethodGen makeDispatcher(LazyClassGen onGen, String dispatchName, ResolvedMember superMethod, BcelWorld world, boolean isSuper) {
/*      */     Type[] paramTypes = BcelWorld.makeBcelTypes(superMethod.getParameterTypes());
/*      */     Type returnType = BcelWorld.makeBcelType(superMethod.getReturnType());
/*      */     int modifiers = 1;
/*      */     if (onGen.isInterface())
/*      */       modifiers |= 0x400; 
/*      */     LazyMethodGen mg = new LazyMethodGen(modifiers, returnType, dispatchName, paramTypes, UnresolvedType.getNames(superMethod.getExceptions()), onGen);
/*      */     InstructionList body = mg.getBody();
/*      */     if (onGen.isInterface())
/*      */       return mg; 
/*      */     InstructionFactory fact = onGen.getFactory();
/*      */     int pos = 0;
/*      */     body.append(InstructionFactory.createThis());
/*      */     pos++;
/*      */     for (Type paramType : paramTypes) {
/*      */       body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */       pos += paramType.getSize();
/*      */     } 
/*      */     if (isSuper) {
/*      */       body.append(Utility.createSuperInvoke(fact, world, (Member)superMethod));
/*      */     } else {
/*      */       body.append(Utility.createInvoke(fact, world, (Member)superMethod));
/*      */     } 
/*      */     body.append(InstructionFactory.createReturn(returnType));
/*      */     return mg;
/*      */   }
/*      */   
/*      */   private boolean mungeNewField(BcelClassWeaver weaver, NewFieldTypeMunger munger) {
/*      */     ReferenceType referenceType;
/*      */     munger.getInitMethod((UnresolvedType)this.aspectType);
/*      */     LazyClassGen gen = weaver.getLazyClassGen();
/*      */     ResolvedMember field = munger.getSignature();
/*      */     ResolvedType onType = weaver.getWorld().resolve(field.getDeclaringType(), munger.getSourceLocation());
/*      */     if (onType.isRawType())
/*      */       referenceType = onType.getGenericType(); 
/*      */     boolean onInterface = referenceType.isInterface();
/*      */     if (referenceType.isAnnotation()) {
/*      */       signalError("itdfOnAnnotationNotAllowed", weaver, (UnresolvedType)referenceType);
/*      */       return false;
/*      */     } 
/*      */     if (referenceType.isEnum()) {
/*      */       signalError("itdfOnEnumNotAllowed", weaver, (UnresolvedType)referenceType);
/*      */       return false;
/*      */     } 
/*      */     ResolvedMember interMethodBody = munger.getInitMethod((UnresolvedType)this.aspectType);
/*      */     AnnotationAJ[] annotationsOnRealMember = null;
/*      */     if (weaver.getWorld().isInJava5Mode()) {
/*      */       ReferenceType referenceType1;
/*      */       ResolvedType toLookOn = this.aspectType;
/*      */       if (this.aspectType.isRawType())
/*      */         referenceType1 = this.aspectType.getGenericType(); 
/*      */       ResolvedMember realMember = getRealMemberForITDFromAspect((ResolvedType)referenceType1, interMethodBody, false);
/*      */       if (realMember != null)
/*      */         annotationsOnRealMember = realMember.getAnnotations(); 
/*      */     } 
/*      */     if (referenceType.equals(gen.getType())) {
/*      */       if (onInterface) {
/*      */         ResolvedMember itdfieldGetter = AjcMemberMaker.interFieldInterfaceGetter(field, (ResolvedType)referenceType, (UnresolvedType)this.aspectType);
/*      */         LazyMethodGen mg = makeMethodGen(gen, itdfieldGetter);
/*      */         gen.addMethodGen(mg);
/*      */         LazyMethodGen mg1 = makeMethodGen(gen, AjcMemberMaker.interFieldInterfaceSetter(field, (ResolvedType)referenceType, (UnresolvedType)this.aspectType));
/*      */         gen.addMethodGen(mg1);
/*      */       } else {
/*      */         weaver.addInitializer(this);
/*      */         ResolvedMember newField = AjcMemberMaker.interFieldClassField(field, (UnresolvedType)this.aspectType, (munger.version == 2));
/*      */         FieldGen fg = makeFieldGen(gen, newField);
/*      */         if (annotationsOnRealMember != null)
/*      */           for (AnnotationAJ annotationX : annotationsOnRealMember) {
/*      */             AnnotationGen a = ((BcelAnnotation)annotationX).getBcelAnnotation();
/*      */             AnnotationGen ag = new AnnotationGen(a, weaver.getLazyClassGen().getConstantPool(), true);
/*      */             fg.addAnnotation(ag);
/*      */           }  
/*      */         if (weaver.getWorld().isInJava5Mode()) {
/*      */           String basicSignature = field.getSignature();
/*      */           String genericSignature = field.getReturnType().resolve(weaver.getWorld()).getSignatureForAttribute();
/*      */           if (!basicSignature.equals(genericSignature))
/*      */             fg.addAttribute((Attribute)createSignatureAttribute(gen.getConstantPool(), genericSignature)); 
/*      */         } 
/*      */         gen.addField(fg, getSourceLocation());
/*      */       } 
/*      */       return true;
/*      */     } 
/*      */     if (onInterface && gen.getType().isTopmostImplementor((ResolvedType)referenceType)) {
/*      */       if (Modifier.isStatic(field.getModifiers()))
/*      */         throw new RuntimeException("unimplemented"); 
/*      */       boolean alreadyExists = false;
/*      */       if (munger.version == 2)
/*      */         for (BcelField fieldgen : gen.getFieldGens()) {
/*      */           if (fieldgen.getName().equals(field.getName())) {
/*      */             alreadyExists = true;
/*      */             break;
/*      */           } 
/*      */         }  
/*      */       ResolvedMember newField = AjcMemberMaker.interFieldInterfaceField(field, (UnresolvedType)referenceType, (UnresolvedType)this.aspectType, (munger.version == 2));
/*      */       String fieldName = newField.getName();
/*      */       Type fieldType = BcelWorld.makeBcelType(field.getType());
/*      */       if (!alreadyExists) {
/*      */         weaver.addInitializer(this);
/*      */         FieldGen fg = makeFieldGen(gen, newField);
/*      */         if (annotationsOnRealMember != null)
/*      */           for (AnnotationAJ annotationX : annotationsOnRealMember) {
/*      */             AnnotationGen a = ((BcelAnnotation)annotationX).getBcelAnnotation();
/*      */             AnnotationGen ag = new AnnotationGen(a, weaver.getLazyClassGen().getConstantPool(), true);
/*      */             fg.addAnnotation(ag);
/*      */           }  
/*      */         if (weaver.getWorld().isInJava5Mode()) {
/*      */           String basicSignature = field.getSignature();
/*      */           String genericSignature = field.getReturnType().resolve(weaver.getWorld()).getSignatureForAttribute();
/*      */           if (!basicSignature.equals(genericSignature))
/*      */             fg.addAttribute((Attribute)createSignatureAttribute(gen.getConstantPool(), genericSignature)); 
/*      */         } 
/*      */         gen.addField(fg, getSourceLocation());
/*      */       } 
/*      */       ResolvedMember itdfieldGetter = AjcMemberMaker.interFieldInterfaceGetter(field, gen.getType(), (UnresolvedType)this.aspectType);
/*      */       LazyMethodGen mg = makeMethodGen(gen, itdfieldGetter);
/*      */       InstructionList il = new InstructionList();
/*      */       InstructionFactory fact = gen.getFactory();
/*      */       if (Modifier.isStatic(field.getModifiers())) {
/*      */         il.append((Instruction)fact.createFieldAccess(gen.getClassName(), fieldName, fieldType, (short)178));
/*      */       } else {
/*      */         il.append((Instruction)InstructionConstants.ALOAD_0);
/*      */         il.append((Instruction)fact.createFieldAccess(gen.getClassName(), fieldName, fieldType, (short)180));
/*      */       } 
/*      */       il.append(InstructionFactory.createReturn(fieldType));
/*      */       mg.getBody().insert(il);
/*      */       gen.addMethodGen(mg);
/*      */       if (munger.getDeclaredSignature() != null) {
/*      */         ResolvedMemberImpl resolvedMemberImpl = munger.getDeclaredSignature().parameterizedWith(null, munger.getSignature().getDeclaringType().resolve(getWorld()), false, munger.getTypeVariableAliases());
/*      */         boolean needsbridging = false;
/*      */         if (!resolvedMemberImpl.getReturnType().getErasureSignature().equals(munger.getSignature().getReturnType().getErasureSignature()))
/*      */           needsbridging = true; 
/*      */         if (needsbridging) {
/*      */           ResolvedMember bridgingGetter = AjcMemberMaker.interFieldInterfaceGetter((ResolvedMember)resolvedMemberImpl, gen.getType(), (UnresolvedType)this.aspectType);
/*      */           createBridgeMethodForITDF(weaver, gen, itdfieldGetter, bridgingGetter);
/*      */         } 
/*      */       } 
/*      */       ResolvedMember itdfieldSetter = AjcMemberMaker.interFieldInterfaceSetter(field, gen.getType(), (UnresolvedType)this.aspectType);
/*      */       LazyMethodGen mg1 = makeMethodGen(gen, itdfieldSetter);
/*      */       InstructionList il1 = new InstructionList();
/*      */       if (Modifier.isStatic(field.getModifiers())) {
/*      */         il1.append((Instruction)InstructionFactory.createLoad(fieldType, 0));
/*      */         il1.append((Instruction)fact.createFieldAccess(gen.getClassName(), fieldName, fieldType, (short)179));
/*      */       } else {
/*      */         il1.append((Instruction)InstructionConstants.ALOAD_0);
/*      */         il1.append((Instruction)InstructionFactory.createLoad(fieldType, 1));
/*      */         il1.append((Instruction)fact.createFieldAccess(gen.getClassName(), fieldName, fieldType, (short)181));
/*      */       } 
/*      */       il1.append(InstructionFactory.createReturn((Type)Type.VOID));
/*      */       mg1.getBody().insert(il1);
/*      */       gen.addMethodGen(mg1);
/*      */       if (munger.getDeclaredSignature() != null) {
/*      */         ResolvedMemberImpl resolvedMemberImpl = munger.getDeclaredSignature().parameterizedWith(null, munger.getSignature().getDeclaringType().resolve(getWorld()), false, munger.getTypeVariableAliases());
/*      */         boolean needsbridging = false;
/*      */         if (!resolvedMemberImpl.getReturnType().getErasureSignature().equals(munger.getSignature().getReturnType().getErasureSignature()))
/*      */           needsbridging = true; 
/*      */         if (needsbridging) {
/*      */           ResolvedMember bridgingSetter = AjcMemberMaker.interFieldInterfaceSetter((ResolvedMember)resolvedMemberImpl, gen.getType(), (UnresolvedType)this.aspectType);
/*      */           createBridgeMethodForITDF(weaver, gen, itdfieldSetter, bridgingSetter);
/*      */         } 
/*      */       } 
/*      */       return true;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private void createBridgeMethodForITDF(BcelClassWeaver weaver, LazyClassGen gen, ResolvedMember itdfieldSetter, ResolvedMember bridgingSetter) {
/*      */     LazyMethodGen bridgeMethod = makeMethodGen(gen, bridgingSetter);
/*      */     bridgeMethod.setAccessFlags(bridgeMethod.getAccessFlags() | 0x40);
/*      */     Type[] paramTypes = BcelWorld.makeBcelTypes(bridgingSetter.getParameterTypes());
/*      */     Type[] bridgingToParms = BcelWorld.makeBcelTypes(itdfieldSetter.getParameterTypes());
/*      */     Type returnType = BcelWorld.makeBcelType(bridgingSetter.getReturnType());
/*      */     InstructionList body = bridgeMethod.getBody();
/*      */     InstructionFactory fact = gen.getFactory();
/*      */     int pos = 0;
/*      */     if (!Modifier.isStatic(bridgingSetter.getModifiers())) {
/*      */       body.append(InstructionFactory.createThis());
/*      */       pos++;
/*      */     } 
/*      */     for (int i = 0, len = paramTypes.length; i < len; i++) {
/*      */       Type paramType = paramTypes[i];
/*      */       body.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/*      */       if (!bridgingSetter.getParameterTypes()[i].getErasureSignature().equals(itdfieldSetter.getParameterTypes()[i].getErasureSignature()))
/*      */         body.append(fact.createCast(paramType, bridgingToParms[i])); 
/*      */       pos += paramType.getSize();
/*      */     } 
/*      */     body.append(Utility.createInvoke(fact, weaver.getWorld(), (Member)itdfieldSetter));
/*      */     body.append(InstructionFactory.createReturn(returnType));
/*      */     gen.addMethodGen(bridgeMethod);
/*      */   }
/*      */   
/*      */   public ConcreteTypeMunger parameterizedFor(ResolvedType target) {
/*      */     return new BcelTypeMunger(this.munger.parameterizedFor(target), this.aspectType);
/*      */   }
/*      */   
/*      */   public ConcreteTypeMunger parameterizeWith(Map<String, UnresolvedType> m, World w) {
/*      */     return new BcelTypeMunger(this.munger.parameterizeWith(m, w), this.aspectType);
/*      */   }
/*      */   
/*      */   public List<String> getTypeVariableAliases() {
/*      */     return this.munger.getTypeVariableAliases();
/*      */   }
/*      */   
/*      */   public boolean equals(Object other) {
/*      */     if (!(other instanceof BcelTypeMunger))
/*      */       return false; 
/*      */     BcelTypeMunger o = (BcelTypeMunger)other;
/*      */     return (((o.getMunger() == null) ? (getMunger() == null) : o.getMunger().equals(getMunger())) && ((o.getAspectType() == null) ? (getAspectType() == null) : o.getAspectType().equals(getAspectType())));
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelTypeMunger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */