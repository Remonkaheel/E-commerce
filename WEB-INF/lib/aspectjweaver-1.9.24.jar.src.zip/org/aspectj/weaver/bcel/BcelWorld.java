/*      */ package org.aspectj.weaver.bcel;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.net.MalformedURLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import org.aspectj.apache.bcel.classfile.ClassParser;
/*      */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*      */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*      */ import org.aspectj.apache.bcel.generic.FieldInstruction;
/*      */ import org.aspectj.apache.bcel.generic.Instruction;
/*      */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*      */ import org.aspectj.apache.bcel.generic.InvokeInstruction;
/*      */ import org.aspectj.apache.bcel.generic.MULTIANEWARRAY;
/*      */ import org.aspectj.apache.bcel.generic.ObjectType;
/*      */ import org.aspectj.apache.bcel.generic.Type;
/*      */ import org.aspectj.apache.bcel.util.ClassLoaderReference;
/*      */ import org.aspectj.apache.bcel.util.ClassLoaderRepository;
/*      */ import org.aspectj.apache.bcel.util.ClassPath;
/*      */ import org.aspectj.apache.bcel.util.NonCachingClassLoaderRepository;
/*      */ import org.aspectj.apache.bcel.util.Repository;
/*      */ import org.aspectj.asm.AsmManager;
/*      */ import org.aspectj.asm.IRelationship;
/*      */ import org.aspectj.asm.internal.CharOperation;
/*      */ import org.aspectj.bridge.IMessage;
/*      */ import org.aspectj.bridge.IMessageHandler;
/*      */ import org.aspectj.bridge.ISourceLocation;
/*      */ import org.aspectj.bridge.Message;
/*      */ import org.aspectj.bridge.MessageUtil;
/*      */ import org.aspectj.bridge.WeaveMessage;
/*      */ import org.aspectj.weaver.Advice;
/*      */ import org.aspectj.weaver.AdviceKind;
/*      */ import org.aspectj.weaver.AnnotationAJ;
/*      */ import org.aspectj.weaver.AnnotationOnTypeMunger;
/*      */ import org.aspectj.weaver.BCException;
/*      */ import org.aspectj.weaver.Checker;
/*      */ import org.aspectj.weaver.ICrossReferenceHandler;
/*      */ import org.aspectj.weaver.IWeavingSupport;
/*      */ import org.aspectj.weaver.Member;
/*      */ import org.aspectj.weaver.MemberImpl;
/*      */ import org.aspectj.weaver.MemberKind;
/*      */ import org.aspectj.weaver.NewParentTypeMunger;
/*      */ import org.aspectj.weaver.ReferenceType;
/*      */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*      */ import org.aspectj.weaver.ResolvedMember;
/*      */ import org.aspectj.weaver.ResolvedMemberImpl;
/*      */ import org.aspectj.weaver.ResolvedType;
/*      */ import org.aspectj.weaver.ResolvedTypeMunger;
/*      */ import org.aspectj.weaver.Shadow;
/*      */ import org.aspectj.weaver.ShadowMunger;
/*      */ import org.aspectj.weaver.UnresolvedType;
/*      */ import org.aspectj.weaver.World;
/*      */ import org.aspectj.weaver.loadtime.definition.Definition;
/*      */ import org.aspectj.weaver.loadtime.definition.DocumentParser;
/*      */ import org.aspectj.weaver.model.AsmRelationshipProvider;
/*      */ import org.aspectj.weaver.patterns.DeclareAnnotation;
/*      */ import org.aspectj.weaver.patterns.DeclareParents;
/*      */ import org.aspectj.weaver.patterns.ParserException;
/*      */ import org.aspectj.weaver.patterns.PatternParser;
/*      */ import org.aspectj.weaver.patterns.TypePattern;
/*      */ import org.aspectj.weaver.tools.Trace;
/*      */ import org.aspectj.weaver.tools.TraceFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BcelWorld
/*      */   extends World
/*      */   implements Repository
/*      */ {
/*      */   private final ClassPathManager classPath;
/*      */   protected Repository delegate;
/*      */   private BcelWeakClassLoaderReference loaderRef;
/*   92 */   private final BcelWeavingSupport bcelWeavingSupport = new BcelWeavingSupport();
/*      */   
/*      */   private boolean isXmlConfiguredWorld = false;
/*      */   private WeavingXmlConfig xmlConfiguration;
/*      */   private List<TypeDelegateResolver> typeDelegateResolvers;
/*   97 */   private static Trace trace = TraceFactory.getTraceFactory().getTrace(BcelWorld.class); private List<String> aspectRequiredTypesProcessed; private Map<String, String> aspectRequiredTypes;
/*      */   
/*      */   public BcelWorld() {
/*  100 */     this("");
/*      */   }
/*      */   
/*      */   public BcelWorld(String cp) {
/*  104 */     this(makeDefaultClasspath(cp), IMessageHandler.THROW, (ICrossReferenceHandler)null);
/*      */   }
/*      */   
/*      */   public IRelationship.Kind determineRelKind(ShadowMunger munger) {
/*  108 */     AdviceKind ak = ((Advice)munger).getKind();
/*  109 */     if (ak.getKey() == AdviceKind.Before.getKey())
/*  110 */       return IRelationship.Kind.ADVICE_BEFORE; 
/*  111 */     if (ak.getKey() == AdviceKind.After.getKey())
/*  112 */       return IRelationship.Kind.ADVICE_AFTER; 
/*  113 */     if (ak.getKey() == AdviceKind.AfterThrowing.getKey())
/*  114 */       return IRelationship.Kind.ADVICE_AFTERTHROWING; 
/*  115 */     if (ak.getKey() == AdviceKind.AfterReturning.getKey())
/*  116 */       return IRelationship.Kind.ADVICE_AFTERRETURNING; 
/*  117 */     if (ak.getKey() == AdviceKind.Around.getKey())
/*  118 */       return IRelationship.Kind.ADVICE_AROUND; 
/*  119 */     if (ak.getKey() == AdviceKind.CflowEntry.getKey() || ak.getKey() == AdviceKind.CflowBelowEntry.getKey() || ak
/*  120 */       .getKey() == AdviceKind.InterInitializer.getKey() || ak.getKey() == AdviceKind.PerCflowEntry.getKey() || ak
/*  121 */       .getKey() == AdviceKind.PerCflowBelowEntry.getKey() || ak.getKey() == AdviceKind.PerThisEntry.getKey() || ak
/*  122 */       .getKey() == AdviceKind.PerTargetEntry.getKey() || ak.getKey() == AdviceKind.Softener.getKey() || ak
/*  123 */       .getKey() == AdviceKind.PerTypeWithinEntry.getKey())
/*      */     {
/*  125 */       return null;
/*      */     }
/*  127 */     throw new RuntimeException("Shadow.determineRelKind: What the hell is it? " + ak);
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportMatch(ShadowMunger munger, Shadow shadow) {
/*  132 */     if (getCrossReferenceHandler() != null) {
/*  133 */       IRelationship.Kind kind = determineRelKind(munger);
/*  134 */       getCrossReferenceHandler().addCrossReference(munger
/*  135 */           .getSourceLocation(), shadow
/*  136 */           .getSourceLocation(), 
/*  137 */           (kind == null) ? null : kind.getName(), ((Advice)munger)
/*  138 */           .hasDynamicTests());
/*      */     } 
/*      */ 
/*      */     
/*  142 */     if (!getMessageHandler().isIgnoring(IMessage.WEAVEINFO)) {
/*  143 */       reportWeavingMessage(munger, shadow);
/*      */     }
/*      */     
/*  146 */     if (getModel() != null) {
/*  147 */       AsmRelationshipProvider.addAdvisedRelationship(getModelAsAsmManager(), shadow, munger);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void reportWeavingMessage(ShadowMunger munger, Shadow shadow) {
/*      */     WeaveMessage weaveMessage;
/*  156 */     Advice advice = (Advice)munger;
/*  157 */     AdviceKind aKind = advice.getKind();
/*      */     
/*  159 */     if (aKind == null || advice.getConcreteAspect() == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  164 */     if (!aKind.equals(AdviceKind.Before) && !aKind.equals(AdviceKind.After) && !aKind.equals(AdviceKind.AfterReturning) && 
/*  165 */       !aKind.equals(AdviceKind.AfterThrowing) && !aKind.equals(AdviceKind.Around) && !aKind.equals(AdviceKind.Softener)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  173 */     if (shadow.getKind() == Shadow.SynchronizationUnlock) {
/*  174 */       if (advice.lastReportedMonitorExitJoinpointLocation == null) {
/*      */         
/*  176 */         advice.lastReportedMonitorExitJoinpointLocation = shadow.getSourceLocation();
/*      */       } else {
/*  178 */         if (areTheSame(shadow.getSourceLocation(), advice.lastReportedMonitorExitJoinpointLocation)) {
/*      */           
/*  180 */           advice.lastReportedMonitorExitJoinpointLocation = null;
/*      */           
/*      */           return;
/*      */         } 
/*  184 */         advice.lastReportedMonitorExitJoinpointLocation = shadow.getSourceLocation();
/*      */       } 
/*      */     }
/*      */     
/*  188 */     String description = advice.getKind().toString();
/*  189 */     String advisedType = shadow.getEnclosingType().getName();
/*  190 */     String advisingType = advice.getConcreteAspect().getName();
/*  191 */     Message msg = null;
/*  192 */     if (advice.getKind().equals(AdviceKind.Softener)) {
/*  193 */       weaveMessage = WeaveMessage.constructWeavingMessage(WeaveMessage.WEAVEMESSAGE_SOFTENS, new String[] { advisedType, 
/*      */ 
/*      */             
/*  196 */             beautifyLocation(shadow.getSourceLocation()), advisingType, 
/*  197 */             beautifyLocation(munger.getSourceLocation()) }, advisedType, advisingType, shadow
/*      */ 
/*      */           
/*  200 */           .getSourceLocation(), munger.getSourceLocation());
/*      */     }
/*      */     else {
/*      */       
/*  204 */       boolean runtimeTest = advice.hasDynamicTests();
/*  205 */       String joinPointDescription = shadow.toString();
/*  206 */       weaveMessage = WeaveMessage.constructWeavingMessage(WeaveMessage.WEAVEMESSAGE_ADVISES, new String[] { joinPointDescription, advisedType, 
/*      */ 
/*      */ 
/*      */             
/*  210 */             beautifyLocation(shadow.getSourceLocation()), description, advisingType, 
/*      */             
/*  212 */             beautifyLocation(munger.getSourceLocation()), 
/*  213 */             runtimeTest ? " [with runtime test]" : "" }, advisedType, advisingType, shadow
/*      */ 
/*      */           
/*  216 */           .getSourceLocation(), munger.getSourceLocation());
/*      */     } 
/*      */ 
/*      */     
/*  220 */     getMessageHandler().handleMessage((IMessage)weaveMessage);
/*      */   }
/*      */   
/*      */   private boolean areTheSame(ISourceLocation locA, ISourceLocation locB) {
/*  224 */     if (locA == null) {
/*  225 */       return (locB == null);
/*      */     }
/*  227 */     if (locB == null) {
/*  228 */       return false;
/*      */     }
/*  230 */     if (locA.getLine() != locB.getLine()) {
/*  231 */       return false;
/*      */     }
/*  233 */     File fA = locA.getSourceFile();
/*  234 */     File fB = locA.getSourceFile();
/*  235 */     if (fA == null) {
/*  236 */       return (fB == null);
/*      */     }
/*  238 */     if (fB == null) {
/*  239 */       return false;
/*      */     }
/*  241 */     return fA.getName().equals(fB.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String beautifyLocation(ISourceLocation isl) {
/*  248 */     StringBuilder nice = new StringBuilder();
/*  249 */     if (isl == null || isl.getSourceFile() == null || isl.getSourceFile().getName().contains("no debug info available")) {
/*  250 */       nice.append("no debug info available");
/*      */     } else {
/*      */       
/*  253 */       int takeFrom = isl.getSourceFile().getPath().lastIndexOf('/');
/*  254 */       if (takeFrom == -1) {
/*  255 */         takeFrom = isl.getSourceFile().getPath().lastIndexOf('\\');
/*      */       }
/*  257 */       int binary = isl.getSourceFile().getPath().lastIndexOf('!');
/*  258 */       if (binary != -1 && binary < takeFrom) {
/*      */         
/*  260 */         String pathToBinaryLoc = isl.getSourceFile().getPath().substring(0, binary + 1);
/*  261 */         if (pathToBinaryLoc.contains(".jar")) {
/*      */           
/*  263 */           int lastSlash = pathToBinaryLoc.lastIndexOf('/');
/*  264 */           if (lastSlash == -1) {
/*  265 */             lastSlash = pathToBinaryLoc.lastIndexOf('\\');
/*      */           }
/*  267 */           nice.append(pathToBinaryLoc.substring(lastSlash + 1));
/*      */         } 
/*      */       } 
/*  270 */       nice.append(isl.getSourceFile().getPath().substring(takeFrom + 1));
/*  271 */       if (isl.getLine() != 0) {
/*  272 */         nice.append(":").append(isl.getLine());
/*      */       }
/*      */       
/*  275 */       if (isl.getSourceFileName() != null) {
/*  276 */         nice.append("(from ").append(isl.getSourceFileName()).append(")");
/*      */       }
/*      */     } 
/*  279 */     return nice.toString();
/*      */   }
/*      */   
/*      */   private static List<String> makeDefaultClasspath(String cp) {
/*  283 */     List<String> classPath = new ArrayList<>();
/*  284 */     classPath.addAll(getPathEntries(cp));
/*  285 */     classPath.addAll(getPathEntries(ClassPath.getClassPath()));
/*  286 */     return classPath;
/*      */   }
/*      */ 
/*      */   
/*      */   private static List<String> getPathEntries(String s) {
/*  291 */     List<String> ret = new ArrayList<>();
/*  292 */     StringTokenizer tok = new StringTokenizer(s, File.pathSeparator);
/*  293 */     while (tok.hasMoreTokens()) {
/*  294 */       ret.add(tok.nextToken());
/*      */     }
/*  296 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ensureRepositorySetup() {
/*  333 */     if (this.delegate == null) {
/*  334 */       this.delegate = getClassLoaderRepositoryFor(this.loaderRef);
/*      */     }
/*      */   }
/*      */   
/*      */   public Repository getClassLoaderRepositoryFor(ClassLoaderReference loader) {
/*  339 */     if (this.bcelRepositoryCaching) {
/*  340 */       return (Repository)new ClassLoaderRepository(loader);
/*      */     }
/*  342 */     return (Repository)new NonCachingClassLoaderRepository(loader);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPath(String name) {
/*  347 */     this.classPath.addPath(name, getMessageHandler());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Type makeBcelType(UnresolvedType type) {
/*  353 */     return Type.getType(type.getErasureSignature());
/*      */   }
/*      */   
/*      */   static Type[] makeBcelTypes(UnresolvedType[] types) {
/*  357 */     Type[] ret = new Type[types.length];
/*  358 */     for (int i = 0, len = types.length; i < len; i++) {
/*  359 */       ret[i] = makeBcelType(types[i]);
/*      */     }
/*  361 */     return ret;
/*      */   }
/*      */   
/*      */   public static Type[] makeBcelTypes(String[] types) {
/*  365 */     if (types == null || types.length == 0) {
/*  366 */       return null;
/*      */     }
/*  368 */     Type[] ret = new Type[types.length];
/*  369 */     for (int i = 0, len = types.length; i < len; i++) {
/*  370 */       ret[i] = makeBcelType(types[i]);
/*      */     }
/*  372 */     return ret;
/*      */   }
/*      */   
/*      */   public static Type makeBcelType(String type) {
/*  376 */     return Type.getType(type);
/*      */   }
/*      */ 
/*      */   
/*      */   static String[] makeBcelTypesAsClassNames(UnresolvedType[] types) {
/*  381 */     String[] ret = new String[types.length];
/*  382 */     for (int i = 0, len = types.length; i < len; i++) {
/*  383 */       ret[i] = types[i].getName();
/*      */     }
/*  385 */     return ret;
/*      */   }
/*      */   
/*      */   public static UnresolvedType fromBcel(Type t) {
/*  389 */     return UnresolvedType.forSignature(t.getSignature());
/*      */   }
/*      */   
/*      */   static UnresolvedType[] fromBcel(Type[] ts) {
/*  393 */     UnresolvedType[] ret = new UnresolvedType[ts.length];
/*  394 */     for (int i = 0, len = ts.length; i < len; i++) {
/*  395 */       ret[i] = fromBcel(ts[i]);
/*      */     }
/*  397 */     return ret;
/*      */   }
/*      */   
/*      */   public ResolvedType resolve(Type t) {
/*  401 */     return resolve(fromBcel(t));
/*      */   }
/*      */ 
/*      */   
/*      */   protected ReferenceTypeDelegate resolveDelegate(ReferenceType ty) {
/*  406 */     String name = ty.getName();
/*  407 */     ensureAdvancedConfigurationProcessed();
/*  408 */     JavaClass jc = lookupJavaClass(this.classPath, name);
/*  409 */     if (jc == null) {
/*      */       
/*  411 */       if (this.typeDelegateResolvers != null) {
/*  412 */         for (TypeDelegateResolver tdr : this.typeDelegateResolvers) {
/*  413 */           ReferenceTypeDelegate delegate = tdr.getDelegate(ty);
/*  414 */           if (delegate != null) {
/*  415 */             return delegate;
/*      */           }
/*      */         } 
/*      */       }
/*  419 */       return null;
/*      */     } 
/*  421 */     return (ReferenceTypeDelegate)buildBcelDelegate(ty, jc, false, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public BcelObjectType buildBcelDelegate(ReferenceType type, JavaClass jc, boolean artificial, boolean exposedToWeaver) {
/*  426 */     BcelObjectType ret = new BcelObjectType(type, jc, artificial, exposedToWeaver);
/*  427 */     return ret;
/*      */   }
/*      */   
/*      */   private JavaClass lookupJavaClass(ClassPathManager classPath, String name) {
/*  431 */     if (classPath == null) {
/*      */       try {
/*  433 */         ensureRepositorySetup();
/*  434 */         JavaClass jc = this.delegate.loadClass(name);
/*  435 */         if (trace.isTraceEnabled()) {
/*  436 */           trace.event("lookupJavaClass", this, new Object[] { name, jc });
/*      */         }
/*  438 */         return jc;
/*  439 */       } catch (ClassNotFoundException e) {
/*  440 */         if (trace.isTraceEnabled()) {
/*  441 */           trace.error("Unable to find class '" + name + "' in repository", e);
/*      */         }
/*  443 */         return null;
/*      */       } 
/*      */     }
/*      */     
/*  447 */     ClassPathManager.ClassFile file = null;
/*      */     try {
/*  449 */       file = classPath.find(UnresolvedType.forName(name));
/*  450 */       if (file == null) {
/*  451 */         return null;
/*      */       }
/*  453 */       ClassParser parser = new ClassParser(file.getInputStream(), file.getPath());
/*  454 */       JavaClass jc = parser.parse();
/*  455 */       return jc;
/*  456 */     } catch (IOException ioe) {
/*  457 */       if (trace.isTraceEnabled()) {
/*  458 */         trace.error("IOException whilst processing class", ioe);
/*      */       }
/*  460 */       return null;
/*      */     } finally {
/*  462 */       if (file != null) {
/*  463 */         file.close();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public BcelObjectType addSourceObjectType(JavaClass jc, boolean artificial) {
/*  469 */     return addSourceObjectType(jc.getClassName(), jc, artificial);
/*      */   }
/*      */   
/*      */   public BcelObjectType addSourceObjectType(String classname, JavaClass jc, boolean artificial) {
/*  473 */     BcelObjectType ret = null;
/*  474 */     if (!jc.getClassName().equals(classname)) {
/*  475 */       throw new RuntimeException(jc.getClassName() + "!=" + classname);
/*      */     }
/*  477 */     String signature = UnresolvedType.forName(jc.getClassName()).getSignature();
/*      */     
/*  479 */     ResolvedType resolvedTypeFromTypeMap = this.typeMap.get(signature);
/*      */     
/*  481 */     if (resolvedTypeFromTypeMap != null && !(resolvedTypeFromTypeMap instanceof ReferenceType)) {
/*      */       
/*  483 */       StringBuilder exceptionText = new StringBuilder();
/*  484 */       exceptionText.append("Found invalid (not a ReferenceType) entry in the type map. ");
/*  485 */       exceptionText.append("Signature=[" + signature + "] Found=[" + resolvedTypeFromTypeMap + "] Class=[" + resolvedTypeFromTypeMap.getClass() + "]");
/*  486 */       throw new BCException(exceptionText.toString());
/*      */     } 
/*      */     
/*  489 */     ReferenceType referenceTypeFromTypeMap = (ReferenceType)resolvedTypeFromTypeMap;
/*      */     
/*  491 */     if (referenceTypeFromTypeMap == null) {
/*  492 */       if (jc.isGeneric() && isInJava5Mode()) {
/*  493 */         ReferenceType rawType = ReferenceType.fromTypeX(UnresolvedType.forRawTypeName(jc.getClassName()), this);
/*  494 */         ret = buildBcelDelegate(rawType, jc, artificial, true);
/*  495 */         ReferenceType genericRefType = new ReferenceType(UnresolvedType.forGenericTypeSignature(signature, ret
/*  496 */               .getDeclaredGenericSignature()), this);
/*  497 */         rawType.setDelegate((ReferenceTypeDelegate)ret);
/*  498 */         genericRefType.setDelegate((ReferenceTypeDelegate)ret);
/*  499 */         rawType.setGenericType(genericRefType);
/*  500 */         this.typeMap.put(signature, (ResolvedType)rawType);
/*      */       } else {
/*  502 */         referenceTypeFromTypeMap = new ReferenceType(signature, this);
/*  503 */         ret = buildBcelDelegate(referenceTypeFromTypeMap, jc, artificial, true);
/*  504 */         this.typeMap.put(signature, (ResolvedType)referenceTypeFromTypeMap);
/*      */       } 
/*      */     } else {
/*  507 */       ret = buildBcelDelegate(referenceTypeFromTypeMap, jc, artificial, true);
/*      */     } 
/*  509 */     return ret;
/*      */   }
/*      */   
/*      */   public BcelObjectType addSourceObjectType(String classname, byte[] bytes, boolean artificial) {
/*  513 */     BcelObjectType retval = null;
/*  514 */     String signature = UnresolvedType.forName(classname).getSignature();
/*  515 */     ResolvedType resolvedTypeFromTypeMap = this.typeMap.get(signature);
/*      */     
/*  517 */     if (resolvedTypeFromTypeMap != null && !(resolvedTypeFromTypeMap instanceof ReferenceType)) {
/*      */       
/*  519 */       StringBuilder exceptionText = new StringBuilder();
/*  520 */       exceptionText.append("Found invalid (not a ReferenceType) entry in the type map. ");
/*  521 */       exceptionText.append("Signature=[" + signature + "] Found=[" + resolvedTypeFromTypeMap + "] Class=[" + resolvedTypeFromTypeMap.getClass() + "]");
/*  522 */       throw new BCException(exceptionText.toString());
/*      */     } 
/*      */     
/*  525 */     ReferenceType referenceTypeFromTypeMap = (ReferenceType)resolvedTypeFromTypeMap;
/*      */     
/*  527 */     if (referenceTypeFromTypeMap == null) {
/*  528 */       JavaClass jc = Utility.makeJavaClass(classname, bytes);
/*  529 */       if (jc.isGeneric() && isInJava5Mode()) {
/*  530 */         referenceTypeFromTypeMap = ReferenceType.fromTypeX(UnresolvedType.forRawTypeName(jc.getClassName()), this);
/*  531 */         retval = buildBcelDelegate(referenceTypeFromTypeMap, jc, artificial, true);
/*  532 */         ReferenceType genericRefType = new ReferenceType(UnresolvedType.forGenericTypeSignature(signature, retval
/*  533 */               .getDeclaredGenericSignature()), this);
/*  534 */         referenceTypeFromTypeMap.setDelegate((ReferenceTypeDelegate)retval);
/*  535 */         genericRefType.setDelegate((ReferenceTypeDelegate)retval);
/*  536 */         referenceTypeFromTypeMap.setGenericType(genericRefType);
/*  537 */         this.typeMap.put(signature, (ResolvedType)referenceTypeFromTypeMap);
/*      */       } else {
/*  539 */         referenceTypeFromTypeMap = new ReferenceType(signature, this);
/*  540 */         retval = buildBcelDelegate(referenceTypeFromTypeMap, jc, artificial, true);
/*  541 */         this.typeMap.put(signature, (ResolvedType)referenceTypeFromTypeMap);
/*      */       } 
/*      */     } else {
/*  544 */       ReferenceTypeDelegate existingDelegate = referenceTypeFromTypeMap.getDelegate();
/*  545 */       if (!(existingDelegate instanceof BcelObjectType)) {
/*  546 */         throw new IllegalStateException("For " + classname + " should be BcelObjectType, but is " + existingDelegate.getClass());
/*      */       }
/*  548 */       retval = (BcelObjectType)existingDelegate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  556 */       retval = buildBcelDelegate(referenceTypeFromTypeMap, Utility.makeJavaClass(classname, bytes), artificial, true);
/*      */     } 
/*      */     
/*  559 */     return retval;
/*      */   }
/*      */   
/*      */   void deleteSourceObjectType(UnresolvedType ty) {
/*  563 */     this.typeMap.remove(ty.getSignature());
/*      */   }
/*      */   
/*      */   public static Member makeFieldJoinPointSignature(LazyClassGen cg, FieldInstruction fi) {
/*  567 */     ConstantPool cpg = cg.getConstantPool();
/*  568 */     return (Member)MemberImpl.field(fi.getClassName(cpg), (
/*  569 */         fi.opcode == 178 || fi.opcode == 179) ? 8 : 0, fi.getName(cpg), fi
/*  570 */         .getSignature(cpg));
/*      */   }
/*      */   
/*      */   public Member makeJoinPointSignatureFromMethod(LazyMethodGen mg, MemberKind kind) {
/*  574 */     BcelMethod bcelMethod = mg.getMemberView();
/*  575 */     if (bcelMethod == null) {
/*  576 */       int mods = mg.getAccessFlags();
/*  577 */       if (mg.getEnclosingClass().isInterface()) {
/*  578 */         mods |= 0x200;
/*      */       }
/*  580 */       return (Member)new ResolvedMemberImpl(kind, UnresolvedType.forName(mg.getClassName()), mods, fromBcel(mg.getReturnType()), mg
/*  581 */           .getName(), fromBcel(mg.getArgumentTypes()));
/*      */     } 
/*  583 */     return (Member)bcelMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Member makeJoinPointSignatureForMonitorEnter(LazyClassGen cg, InstructionHandle h) {
/*  589 */     return (Member)MemberImpl.monitorEnter();
/*      */   }
/*      */   
/*      */   public Member makeJoinPointSignatureForMonitorExit(LazyClassGen cg, InstructionHandle h) {
/*  593 */     return (Member)MemberImpl.monitorExit();
/*      */   }
/*      */   public Member makeJoinPointSignatureForArrayConstruction(LazyClassGen cg, InstructionHandle handle) {
/*      */     MemberImpl memberImpl;
/*  597 */     Instruction i = handle.getInstruction();
/*  598 */     ConstantPool cpg = cg.getConstantPool();
/*  599 */     Member retval = null;
/*      */     
/*  601 */     if (i.opcode == 189) {
/*      */       
/*  603 */       Type ot = i.getType(cpg);
/*  604 */       UnresolvedType ut = fromBcel(ot);
/*  605 */       ut = UnresolvedType.makeArray(ut, 1);
/*  606 */       memberImpl = MemberImpl.method(ut, 1, UnresolvedType.VOID, "<init>", (UnresolvedType[])new ResolvedType[] { (ResolvedType)this.INT });
/*  607 */     } else if (i instanceof MULTIANEWARRAY) {
/*  608 */       MULTIANEWARRAY arrayInstruction = (MULTIANEWARRAY)i;
/*  609 */       UnresolvedType ut = null;
/*  610 */       short dimensions = arrayInstruction.getDimensions();
/*  611 */       ObjectType ot = arrayInstruction.getLoadClassType(cpg);
/*  612 */       if (ot != null) {
/*  613 */         ut = fromBcel((Type)ot);
/*  614 */         ut = UnresolvedType.makeArray(ut, dimensions);
/*      */       } else {
/*  616 */         Type t = arrayInstruction.getType(cpg);
/*  617 */         ut = fromBcel(t);
/*      */       } 
/*  619 */       ResolvedType[] parms = new ResolvedType[dimensions];
/*  620 */       for (int ii = 0; ii < dimensions; ii++) {
/*  621 */         parms[ii] = (ResolvedType)this.INT;
/*      */       }
/*  623 */       memberImpl = MemberImpl.method(ut, 1, UnresolvedType.VOID, "<init>", (UnresolvedType[])parms);
/*      */     }
/*  625 */     else if (i.opcode == 188) {
/*      */       
/*  627 */       Type ot = i.getType();
/*  628 */       UnresolvedType ut = fromBcel(ot);
/*  629 */       memberImpl = MemberImpl.method(ut, 1, UnresolvedType.VOID, "<init>", (UnresolvedType[])new ResolvedType[] { (ResolvedType)this.INT });
/*      */     } else {
/*  631 */       throw new BCException("Cannot create array construction signature for this non-array instruction:" + i);
/*      */     } 
/*  633 */     return (Member)memberImpl;
/*      */   }
/*      */   
/*      */   public Member makeJoinPointSignatureForMethodInvocation(LazyClassGen cg, InvokeInstruction ii) {
/*  637 */     ConstantPool cpg = cg.getConstantPool();
/*  638 */     String name = ii.getName(cpg);
/*  639 */     String declaring = ii.getClassName(cpg);
/*  640 */     UnresolvedType declaringType = null;
/*      */     
/*  642 */     String signature = ii.getSignature(cpg);
/*      */ 
/*      */     
/*  645 */     if (name.startsWith("ajc$privMethod$")) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/*  650 */         declaringType = UnresolvedType.forName(declaring);
/*  651 */         String typeNameAsFoundInAccessorName = declaringType.getName().replace('.', '_');
/*  652 */         int indexInAccessorName = name.lastIndexOf(typeNameAsFoundInAccessorName);
/*  653 */         if (indexInAccessorName != -1) {
/*  654 */           String methodName = name.substring(indexInAccessorName + typeNameAsFoundInAccessorName.length() + 1);
/*  655 */           ResolvedType resolvedDeclaringType = declaringType.resolve(this);
/*  656 */           ResolvedMember[] methods = resolvedDeclaringType.getDeclaredMethods();
/*  657 */           for (ResolvedMember method : methods) {
/*  658 */             if (method.getName().equals(methodName) && method.getSignature().equals(signature) && Modifier.isPrivate(method.getModifiers())) {
/*  659 */               return (Member)method;
/*      */             }
/*      */           } 
/*      */         } 
/*  663 */       } catch (Exception e) {
/*      */ 
/*      */         
/*  666 */         e.printStackTrace();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  672 */     int modifier = (ii instanceof org.aspectj.apache.bcel.generic.INVOKEINTERFACE) ? 512 : ((ii.opcode == 184) ? 8 : ((ii.opcode == 183 && !name.equals("<init>")) ? 2 : 0));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  678 */     if (ii.opcode == 184) {
/*  679 */       ResolvedType appearsDeclaredBy = resolve(declaring);
/*      */       
/*  681 */       for (Iterator<ResolvedMember> iterator = appearsDeclaredBy.getMethods(true, true); iterator.hasNext(); ) {
/*  682 */         ResolvedMember method = iterator.next();
/*  683 */         if (Modifier.isStatic(method.getModifiers()) && 
/*  684 */           name.equals(method.getName()) && signature.equals(method.getSignature())) {
/*      */           
/*  686 */           declaringType = method.getDeclaringType();
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  693 */     if (declaringType == null) {
/*  694 */       if (declaring.charAt(0) == '[') {
/*  695 */         declaringType = UnresolvedType.forSignature(declaring);
/*      */       } else {
/*  697 */         declaringType = UnresolvedType.forName(declaring);
/*      */       } 
/*      */     }
/*  700 */     return (Member)MemberImpl.method(declaringType, modifier, name, signature);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  705 */     StringBuilder buf = new StringBuilder();
/*  706 */     buf.append("BcelWorld(");
/*      */     
/*  708 */     buf.append(")");
/*  709 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BcelObjectType getBcelObjectType(ResolvedType concreteAspect) {
/*  717 */     if (concreteAspect == null) {
/*  718 */       return null;
/*      */     }
/*  720 */     if (!(concreteAspect instanceof ReferenceType)) {
/*  721 */       return null;
/*      */     }
/*  723 */     ReferenceTypeDelegate rtDelegate = ((ReferenceType)concreteAspect).getDelegate();
/*  724 */     if (rtDelegate instanceof BcelObjectType) {
/*  725 */       return (BcelObjectType)rtDelegate;
/*      */     }
/*  727 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tidyUp() {
/*  734 */     this.classPath.closeArchives();
/*  735 */     this.typeMap.report();
/*  736 */     this.typeMap.demote(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaClass findClass(String className) {
/*  744 */     return lookupJavaClass(this.classPath, className);
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaClass loadClass(String className) throws ClassNotFoundException {
/*  749 */     return lookupJavaClass(this.classPath, className);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void storeClass(JavaClass clazz) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeClass(JavaClass clazz) {
/*  759 */     throw new RuntimeException("Not implemented");
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaClass loadClass(Class clazz) throws ClassNotFoundException {
/*  764 */     throw new RuntimeException("Not implemented");
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  769 */     this.delegate.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void validateType(UnresolvedType type) {
/*  779 */     ResolvedType result = this.typeMap.get(type.getSignature());
/*  780 */     if (result == null) {
/*      */       return;
/*      */     }
/*  783 */     if (!result.isExposedToWeaver()) {
/*      */       return;
/*      */     }
/*  786 */     result.ensureConsistent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean applyDeclareParents(DeclareParents p, ResolvedType onType) {
/*  803 */     boolean didSomething = false;
/*  804 */     List<ResolvedType> newParents = p.findMatchingNewParents(onType, true);
/*  805 */     if (!newParents.isEmpty()) {
/*  806 */       didSomething = true;
/*  807 */       BcelObjectType classType = getBcelObjectType(onType);
/*      */       
/*  809 */       for (ResolvedType newParent : newParents) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  815 */         onType.addParent(newParent);
/*  816 */         NewParentTypeMunger newParentTypeMunger = new NewParentTypeMunger(newParent, p.getDeclaringType());
/*  817 */         newParentTypeMunger.setSourceLocation(p.getSourceLocation());
/*  818 */         onType.addInterTypeMunger(new BcelTypeMunger((ResolvedTypeMunger)newParentTypeMunger, getCrosscuttingMembersSet()
/*  819 */               .findAspectDeclaringParents(p)), false);
/*      */       } 
/*      */     } 
/*  822 */     return didSomething;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean applyDeclareAtType(DeclareAnnotation decA, ResolvedType onType, boolean reportProblems) {
/*  829 */     boolean didSomething = false;
/*  830 */     if (decA.matches(onType)) {
/*      */       
/*  832 */       if (onType.hasAnnotation((UnresolvedType)decA.getAnnotation().getType()))
/*      */       {
/*  834 */         return false;
/*      */       }
/*      */       
/*  837 */       AnnotationAJ annoX = decA.getAnnotation();
/*      */ 
/*      */       
/*  840 */       boolean isOK = checkTargetOK(decA, onType, annoX);
/*      */       
/*  842 */       if (isOK) {
/*  843 */         didSomething = true;
/*  844 */         AnnotationOnTypeMunger annotationOnTypeMunger = new AnnotationOnTypeMunger(annoX);
/*  845 */         annotationOnTypeMunger.setSourceLocation(decA.getSourceLocation());
/*  846 */         onType.addInterTypeMunger(new BcelTypeMunger((ResolvedTypeMunger)annotationOnTypeMunger, decA.getAspect().resolve(this)), false);
/*  847 */         decA.copyAnnotationTo(onType);
/*      */       } 
/*      */     } 
/*  850 */     return didSomething;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean applyDeclareAtField(DeclareAnnotation deca, ResolvedType type) {
/*  860 */     boolean changedType = false;
/*  861 */     ResolvedMember[] fields = type.getDeclaredFields();
/*  862 */     for (ResolvedMember field : fields) {
/*  863 */       if (deca.matches(field, this)) {
/*  864 */         AnnotationAJ anno = deca.getAnnotation();
/*  865 */         if (!field.hasAnnotation((UnresolvedType)anno.getType())) {
/*  866 */           field.addAnnotation(anno);
/*  867 */           changedType = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*  871 */     return changedType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkTargetOK(DeclareAnnotation decA, ResolvedType onType, AnnotationAJ annoX) {
/*  879 */     if (annoX.specifiesTarget() && ((
/*  880 */       onType.isAnnotation() && !annoX.allowedOnAnnotationType()) || !annoX.allowedOnRegularType())) {
/*  881 */       return false;
/*      */     }
/*      */     
/*  884 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void weaveInterTypeDeclarations(ResolvedType onType) {
/*      */     ReferenceType referenceType;
/*  893 */     List<DeclareParents> declareParentsList = getCrosscuttingMembersSet().getDeclareParents();
/*  894 */     if (onType.isRawType()) {
/*  895 */       referenceType = onType.getGenericType();
/*      */     }
/*  897 */     referenceType.clearInterTypeMungers();
/*      */     
/*  899 */     List<DeclareParents> decpToRepeat = new ArrayList<>();
/*      */     
/*  901 */     boolean aParentChangeOccurred = false;
/*  902 */     boolean anAnnotationChangeOccurred = false;
/*      */     
/*  904 */     for (DeclareParents decp : declareParentsList) {
/*  905 */       boolean typeChanged = applyDeclareParents(decp, (ResolvedType)referenceType);
/*  906 */       if (typeChanged) {
/*  907 */         aParentChangeOccurred = true;
/*      */         continue;
/*      */       } 
/*  910 */       if (!decp.getChild().isStarAnnotation()) {
/*  911 */         decpToRepeat.add(decp);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  917 */     for (DeclareAnnotation decA : getCrosscuttingMembersSet().getDeclareAnnotationOnTypes()) {
/*  918 */       boolean typeChanged = applyDeclareAtType(decA, (ResolvedType)referenceType, true);
/*  919 */       if (typeChanged) {
/*  920 */         anAnnotationChangeOccurred = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  925 */     for (DeclareAnnotation deca : getCrosscuttingMembersSet().getDeclareAnnotationOnFields()) {
/*  926 */       if (applyDeclareAtField(deca, (ResolvedType)referenceType)) {
/*  927 */         anAnnotationChangeOccurred = true;
/*      */       }
/*      */     } 
/*      */     
/*  931 */     while ((aParentChangeOccurred || anAnnotationChangeOccurred) && !decpToRepeat.isEmpty()) {
/*  932 */       anAnnotationChangeOccurred = aParentChangeOccurred = false;
/*  933 */       List<DeclareParents> decpToRepeatNextTime = new ArrayList<>();
/*  934 */       for (DeclareParents decp : decpToRepeat) {
/*  935 */         if (applyDeclareParents(decp, (ResolvedType)referenceType)) {
/*  936 */           aParentChangeOccurred = true; continue;
/*      */         } 
/*  938 */         decpToRepeatNextTime.add(decp);
/*      */       } 
/*      */ 
/*      */       
/*  942 */       for (DeclareAnnotation deca : getCrosscuttingMembersSet().getDeclareAnnotationOnTypes()) {
/*  943 */         if (applyDeclareAtType(deca, (ResolvedType)referenceType, false)) {
/*  944 */           anAnnotationChangeOccurred = true;
/*      */         }
/*      */       } 
/*      */       
/*  948 */       for (DeclareAnnotation deca : getCrosscuttingMembersSet().getDeclareAnnotationOnFields()) {
/*  949 */         if (applyDeclareAtField(deca, (ResolvedType)referenceType)) {
/*  950 */           anAnnotationChangeOccurred = true;
/*      */         }
/*      */       } 
/*  953 */       decpToRepeat = decpToRepeatNextTime;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IWeavingSupport getWeavingSupport() {
/*  960 */     return this.bcelWeavingSupport;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportCheckerMatch(Checker checker, Shadow shadow) {
/*  966 */     Message message = new Message(checker.getMessage(shadow), shadow.toString(), checker.isError() ? IMessage.ERROR : IMessage.WARNING, shadow.getSourceLocation(), null, new ISourceLocation[] { checker.getSourceLocation() }, true, 0, -1, -1);
/*      */ 
/*      */     
/*  969 */     getMessageHandler().handleMessage((IMessage)message);
/*      */     
/*  971 */     if (getCrossReferenceHandler() != null) {
/*  972 */       getCrossReferenceHandler()
/*  973 */         .addCrossReference(checker
/*  974 */           .getSourceLocation(), shadow
/*  975 */           .getSourceLocation(), 
/*  976 */           checker.isError() ? IRelationship.Kind.DECLARE_ERROR.getName() : 
/*  977 */           IRelationship.Kind.DECLARE_WARNING.getName(), false);
/*      */     }
/*      */ 
/*      */     
/*  981 */     if (getModel() != null) {
/*  982 */       AsmRelationshipProvider.addDeclareErrorOrWarningRelationship(getModelAsAsmManager(), shadow, checker);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public AsmManager getModelAsAsmManager() {
/*  988 */     return (AsmManager)getModel();
/*      */   }
/*      */   
/*      */   void raiseError(String message) {
/*  992 */     getMessageHandler().handleMessage(MessageUtil.error(message));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXmlFiles(List<File> xmlFiles) {
/* 1002 */     if (!this.isXmlConfiguredWorld && !xmlFiles.isEmpty()) {
/* 1003 */       raiseError("xml configuration files only supported by the compiler when -xmlConfigured option specified");
/*      */       return;
/*      */     } 
/* 1006 */     if (!xmlFiles.isEmpty()) {
/* 1007 */       this.xmlConfiguration = new WeavingXmlConfig(this, 1);
/*      */     }
/* 1009 */     for (File xmlfile : xmlFiles) {
/*      */       try {
/* 1011 */         Definition d = DocumentParser.parse(xmlfile.toURI().toURL());
/* 1012 */         this.xmlConfiguration.add(d);
/* 1013 */       } catch (MalformedURLException e) {
/* 1014 */         raiseError("Unexpected problem processing XML config file '" + xmlfile.getName() + "' :" + e.getMessage());
/* 1015 */       } catch (Exception e) {
/* 1016 */         raiseError("Unexpected problem processing XML config file '" + xmlfile.getName() + "' :" + e.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addScopedAspect(String name, String scope) {
/* 1025 */     this.isXmlConfiguredWorld = true;
/* 1026 */     if (this.xmlConfiguration == null) {
/* 1027 */       this.xmlConfiguration = new WeavingXmlConfig(this, 2);
/*      */     }
/* 1029 */     this.xmlConfiguration.addScopedAspect(name, scope);
/*      */   }
/*      */   
/*      */   public void setXmlConfigured(boolean b) {
/* 1033 */     this.isXmlConfiguredWorld = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isXmlConfigured() {
/* 1038 */     return (this.isXmlConfiguredWorld && this.xmlConfiguration != null);
/*      */   }
/*      */   
/*      */   public WeavingXmlConfig getXmlConfiguration() {
/* 1042 */     return this.xmlConfiguration;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAspectIncluded(ResolvedType aspectType) {
/* 1047 */     if (!isXmlConfigured()) {
/* 1048 */       return true;
/*      */     }
/* 1050 */     return this.xmlConfiguration.specifiesInclusionOfAspect(aspectType.getName());
/*      */   }
/*      */ 
/*      */   
/*      */   public TypePattern getAspectScope(ResolvedType declaringType) {
/* 1055 */     return this.xmlConfiguration.getScopeFor(declaringType.getName());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasUnsatisfiedDependency(ResolvedType aspectType) {
/* 1060 */     String aspectName = aspectType.getName();
/*      */     
/* 1062 */     if (aspectType.hasAnnotations()) {
/* 1063 */       AnnotationAJ[] annos = aspectType.getAnnotations();
/* 1064 */       for (AnnotationAJ anno : annos) {
/* 1065 */         if (anno.getTypeName().equals("org.aspectj.lang.annotation.RequiredTypes")) {
/* 1066 */           String values = anno.getStringFormOfValue("value");
/* 1067 */           if (values != null && values.length() > 2) {
/* 1068 */             values = values.substring(1, values.length() - 1);
/* 1069 */             StringTokenizer tokenizer = new StringTokenizer(values, ",");
/* 1070 */             boolean anythingMissing = false;
/* 1071 */             while (tokenizer.hasMoreElements()) {
/* 1072 */               String requiredTypeName = tokenizer.nextToken();
/* 1073 */               ResolvedType rt = resolve(UnresolvedType.forName(requiredTypeName));
/* 1074 */               if (rt.isMissing()) {
/* 1075 */                 if (!getMessageHandler().isIgnoring(IMessage.INFO)) {
/* 1076 */                   getMessageHandler().handleMessage(
/* 1077 */                       MessageUtil.info("deactivating aspect '" + aspectName + "' as it requires type '" + requiredTypeName + "' which cannot be found on the classpath"));
/*      */                 }
/*      */                 
/* 1080 */                 anythingMissing = true;
/* 1081 */                 if (this.aspectRequiredTypes == null) {
/* 1082 */                   this.aspectRequiredTypes = new HashMap<>();
/*      */                 }
/*      */                 
/* 1085 */                 this.aspectRequiredTypes.put(aspectName, requiredTypeName);
/*      */               } 
/*      */             } 
/* 1088 */             if (anythingMissing) {
/* 1089 */               return true;
/*      */             }
/*      */             
/* 1092 */             return false;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1097 */           return false;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1102 */     if (this.aspectRequiredTypes == null)
/*      */     {
/* 1104 */       return false;
/*      */     }
/* 1106 */     if (!this.aspectRequiredTypesProcessed.contains(aspectName)) {
/* 1107 */       String requiredTypeName = this.aspectRequiredTypes.get(aspectName);
/* 1108 */       if (requiredTypeName == null) {
/* 1109 */         this.aspectRequiredTypesProcessed.add(aspectName);
/* 1110 */         return false;
/*      */       } 
/* 1112 */       ResolvedType rt = resolve(UnresolvedType.forName(requiredTypeName));
/* 1113 */       if (!rt.isMissing()) {
/* 1114 */         this.aspectRequiredTypesProcessed.add(aspectName);
/* 1115 */         this.aspectRequiredTypes.remove(aspectName);
/* 1116 */         return false;
/*      */       } 
/* 1118 */       if (!getMessageHandler().isIgnoring(IMessage.INFO)) {
/* 1119 */         getMessageHandler().handleMessage(
/* 1120 */             MessageUtil.info("deactivating aspect '" + aspectName + "' as it requires type '" + requiredTypeName + "' which cannot be found on the classpath"));
/*      */       }
/*      */       
/* 1123 */       this.aspectRequiredTypesProcessed.add(aspectName);
/* 1124 */       return true;
/*      */     } 
/*      */ 
/*      */     
/* 1128 */     return this.aspectRequiredTypes.containsKey(aspectName);
/*      */   }
/*      */   
/* 1131 */   public BcelWorld(List<String> classPath, IMessageHandler handler, ICrossReferenceHandler xrefHandler) { this.aspectRequiredTypesProcessed = new ArrayList<>();
/* 1132 */     this.aspectRequiredTypes = null; this.classPath = new ClassPathManager(classPath, handler); setMessageHandler(handler); setCrossReferenceHandler(xrefHandler); this.delegate = this; } public BcelWorld(ClassPathManager cpm, IMessageHandler handler, ICrossReferenceHandler xrefHandler) { this.aspectRequiredTypesProcessed = new ArrayList<>(); this.aspectRequiredTypes = null; this.classPath = cpm; setMessageHandler(handler); setCrossReferenceHandler(xrefHandler); this.delegate = this; } public BcelWorld(ClassLoader loader, IMessageHandler handler, ICrossReferenceHandler xrefHandler) { this.aspectRequiredTypesProcessed = new ArrayList<>(); this.aspectRequiredTypes = null; this.classPath = null;
/*      */     this.loaderRef = new BcelWeakClassLoaderReference(loader);
/*      */     setMessageHandler(handler);
/* 1135 */     setCrossReferenceHandler(xrefHandler); } public void addAspectRequires(String aspectClassName, String requiredType) { if (this.aspectRequiredTypes == null) {
/* 1136 */       this.aspectRequiredTypes = new HashMap<>();
/*      */     }
/* 1138 */     this.aspectRequiredTypes.put(aspectClassName, requiredType); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class WeavingXmlConfig
/*      */   {
/*      */     static final int MODE_COMPILE = 1;
/*      */ 
/*      */     
/*      */     static final int MODE_LTW = 2;
/*      */ 
/*      */     
/*      */     private int mode;
/*      */ 
/*      */     
/*      */     private boolean initialized = false;
/*      */     
/* 1156 */     private List<Definition> definitions = new ArrayList<>();
/*      */     
/* 1158 */     private List<String> resolvedIncludedAspects = new ArrayList<>();
/* 1159 */     private Map<String, TypePattern> scopes = new HashMap<>();
/*      */ 
/*      */     
/* 1162 */     private List<String> includedFastMatchPatterns = Collections.emptyList();
/* 1163 */     private List<TypePattern> includedPatterns = Collections.emptyList();
/* 1164 */     private List<String> excludedFastMatchPatterns = Collections.emptyList();
/* 1165 */     private List<TypePattern> excludedPatterns = Collections.emptyList();
/*      */     
/*      */     private BcelWorld world;
/*      */     
/*      */     public WeavingXmlConfig(BcelWorld bcelWorld, int mode) {
/* 1170 */       this.world = bcelWorld;
/* 1171 */       this.mode = mode;
/*      */     }
/*      */     
/*      */     public void add(Definition d) {
/* 1175 */       this.definitions.add(d);
/*      */     }
/*      */     
/*      */     public void addScopedAspect(String aspectName, String scope) {
/* 1179 */       ensureInitialized();
/* 1180 */       this.resolvedIncludedAspects.add(aspectName);
/*      */       try {
/* 1182 */         TypePattern scopePattern = (new PatternParser(scope)).parseTypePattern();
/* 1183 */         scopePattern.resolve(this.world);
/* 1184 */         this.scopes.put(aspectName, scopePattern);
/* 1185 */         if (!this.world.getMessageHandler().isIgnoring(IMessage.INFO)) {
/* 1186 */           this.world.getMessageHandler().handleMessage(
/* 1187 */               MessageUtil.info("Aspect '" + aspectName + "' is scoped to apply against types matching pattern '" + scopePattern + "'"));
/*      */         }
/*      */       }
/* 1190 */       catch (Exception e) {
/* 1191 */         this.world.getMessageHandler().handleMessage(
/* 1192 */             MessageUtil.error("Unable to parse scope as type pattern.  Scope was '" + scope + "': " + e.getMessage()));
/*      */       } 
/*      */     }
/*      */     
/*      */     public void ensureInitialized() {
/* 1197 */       if (!this.initialized) {
/*      */         try {
/* 1199 */           this.resolvedIncludedAspects = new ArrayList<>();
/*      */           
/* 1201 */           for (Definition definition : this.definitions) {
/* 1202 */             List<String> aspectNames = definition.getAspectClassNames();
/* 1203 */             for (String name : aspectNames) {
/* 1204 */               this.resolvedIncludedAspects.add(name);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1212 */               String scope = definition.getScopeForAspect(name);
/* 1213 */               if (scope != null) {
/*      */                 
/*      */                 try {
/* 1216 */                   TypePattern scopePattern = (new PatternParser(scope)).parseTypePattern();
/* 1217 */                   scopePattern.resolve(this.world);
/* 1218 */                   this.scopes.put(name, scopePattern);
/* 1219 */                   if (!this.world.getMessageHandler().isIgnoring(IMessage.INFO)) {
/* 1220 */                     this.world.getMessageHandler().handleMessage(
/* 1221 */                         MessageUtil.info("Aspect '" + name + "' is scoped to apply against types matching pattern '" + scopePattern
/*      */                           
/* 1223 */                           .toString() + "'"));
/*      */                   }
/* 1225 */                 } catch (Exception e) {
/*      */                   
/* 1227 */                   this.world.getMessageHandler().handleMessage(
/* 1228 */                       MessageUtil.error("Unable to parse scope as type pattern.  Scope was '" + scope + "': " + e
/* 1229 */                         .getMessage()));
/*      */                 } 
/*      */               }
/*      */             } 
/*      */             try {
/* 1234 */               List<String> includePatterns = definition.getIncludePatterns();
/* 1235 */               if (includePatterns.size() > 0) {
/* 1236 */                 this.includedPatterns = new ArrayList<>();
/* 1237 */                 this.includedFastMatchPatterns = new ArrayList<>();
/*      */               } 
/* 1239 */               for (String includePattern : includePatterns) {
/* 1240 */                 if (includePattern.endsWith("..*")) {
/*      */                   
/* 1242 */                   this.includedFastMatchPatterns.add(includePattern.substring(0, includePattern.length() - 2)); continue;
/*      */                 } 
/* 1244 */                 TypePattern includedPattern = (new PatternParser(includePattern)).parseTypePattern();
/* 1245 */                 this.includedPatterns.add(includedPattern);
/*      */               } 
/*      */               
/* 1248 */               List<String> excludePatterns = definition.getExcludePatterns();
/* 1249 */               if (excludePatterns.size() > 0) {
/* 1250 */                 this.excludedPatterns = new ArrayList<>();
/* 1251 */                 this.excludedFastMatchPatterns = new ArrayList<>();
/*      */               } 
/* 1253 */               for (String excludePattern : excludePatterns) {
/* 1254 */                 if (excludePattern.endsWith("..*")) {
/*      */                   
/* 1256 */                   this.excludedFastMatchPatterns.add(excludePattern.substring(0, excludePattern.length() - 2)); continue;
/*      */                 } 
/* 1258 */                 TypePattern excludedPattern = (new PatternParser(excludePattern)).parseTypePattern();
/* 1259 */                 this.excludedPatterns.add(excludedPattern);
/*      */               }
/*      */             
/* 1262 */             } catch (ParserException pe) {
/*      */               
/* 1264 */               this.world.getMessageHandler().handleMessage(
/* 1265 */                   MessageUtil.error("Unable to parse type pattern: " + pe.getMessage()));
/*      */             } 
/*      */           } 
/*      */         } finally {
/*      */           
/* 1270 */           this.initialized = true;
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean specifiesInclusionOfAspect(String name) {
/* 1276 */       ensureInitialized();
/* 1277 */       return this.resolvedIncludedAspects.contains(name);
/*      */     }
/*      */     
/*      */     public TypePattern getScopeFor(String name) {
/* 1281 */       return this.scopes.get(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean excludesType(ResolvedType type) {
/* 1301 */       if (this.mode == 2) {
/* 1302 */         return false;
/*      */       }
/* 1304 */       String typename = type.getName();
/* 1305 */       boolean excluded = false;
/* 1306 */       for (String excludedPattern : this.excludedFastMatchPatterns) {
/* 1307 */         if (typename.startsWith(excludedPattern)) {
/* 1308 */           excluded = true;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1312 */       if (!excluded) {
/* 1313 */         for (TypePattern excludedPattern : this.excludedPatterns) {
/* 1314 */           if (excludedPattern.matchesStatically(type)) {
/* 1315 */             excluded = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/* 1320 */       return excluded;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public World.TypeMap getTypeMap() {
/* 1327 */     return this.typeMap;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLoadtimeWeaving() {
/* 1332 */     return false;
/*      */   }
/*      */   
/*      */   public void addTypeDelegateResolver(TypeDelegateResolver typeDelegateResolver) {
/* 1336 */     if (this.typeDelegateResolvers == null) {
/* 1337 */       this.typeDelegateResolvers = new ArrayList<>();
/*      */     }
/* 1339 */     this.typeDelegateResolvers.add(typeDelegateResolver);
/*      */   }
/*      */ 
/*      */   
/*      */   public void classWriteEvent(char[][] compoundName) {
/* 1344 */     this.typeMap.classWriteEvent(new String(CharOperation.concatWith(compoundName, '.')));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void demote(ResolvedType type) {
/* 1351 */     this.typeMap.demote(type);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\BcelWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */