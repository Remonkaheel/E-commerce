/*     */ package org.aspectj.weaver.bcel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.CodeSource;
/*     */ import org.aspectj.util.FileUtil;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExtensibleURLClassLoader
/*     */   extends URLClassLoader
/*     */ {
/*     */   private ClassPathManager classPath;
/*     */   
/*     */   public ExtensibleURLClassLoader(URL[] urls, ClassLoader parent) {
/*  32 */     super(urls, parent);
/*     */ 
/*     */     
/*     */     try {
/*  36 */       this.classPath = new ClassPathManager(FileUtil.makeClasspath(urls), null);
/*  37 */     } catch (ExceptionInInitializerError ex) {
/*  38 */       ex.printStackTrace(System.out);
/*  39 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addURL(URL url) {
/*  44 */     super.addURL(url);
/*     */     
/*  46 */     this.classPath.addPath(url.getPath(), null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class findClass(String name) throws ClassNotFoundException {
/*     */     try {
/*  52 */       byte[] bytes = getBytes(name);
/*  53 */       if (bytes != null) {
/*  54 */         return defineClass(name, bytes);
/*     */       }
/*  56 */       throw new ClassNotFoundException(name);
/*     */     }
/*  58 */     catch (IOException ex) {
/*  59 */       throw new ClassNotFoundException(name, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class defineClass(String name, byte[] b, CodeSource cs) throws IOException {
/*  65 */     return defineClass(name, b, 0, b.length, cs);
/*     */   }
/*     */   
/*     */   protected byte[] getBytes(String name) throws IOException {
/*  69 */     byte[] b = null;
/*  70 */     UnresolvedType unresolvedType = null;
/*     */     try {
/*  72 */       unresolvedType = UnresolvedType.forName(name);
/*  73 */     } catch (BCException bce) {
/*  74 */       if (!bce.getMessage().contains("nameToSignature")) {
/*  75 */         bce.printStackTrace(System.err);
/*     */       }
/*  77 */       return null;
/*     */     } 
/*  79 */     ClassPathManager.ClassFile classFile = this.classPath.find(unresolvedType);
/*  80 */     if (classFile != null) {
/*     */       try {
/*  82 */         b = FileUtil.readAsByteArray(classFile.getInputStream());
/*     */       } finally {
/*  84 */         classFile.close();
/*     */       } 
/*     */     }
/*  87 */     return b;
/*     */   }
/*     */   
/*     */   private Class<?> defineClass(String name, byte[] bytes) throws IOException {
/*  91 */     String packageName = getPackageName(name);
/*  92 */     if (packageName != null) {
/*  93 */       Package pakkage = getPackage(packageName);
/*  94 */       if (pakkage == null) {
/*  95 */         definePackage(packageName, null, null, null, null, null, null, null);
/*     */       }
/*     */     } 
/*     */     
/*  99 */     return defineClass(name, bytes, (CodeSource)null);
/*     */   }
/*     */   
/*     */   private String getPackageName(String className) {
/* 103 */     int offset = className.lastIndexOf('.');
/* 104 */     return (offset == -1) ? null : className.substring(0, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 109 */     super.close();
/* 110 */     this.classPath.closeArchives();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\bcel\ExtensibleURLClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */