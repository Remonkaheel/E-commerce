/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.World;
/*    */ import org.aspectj.weaver.ast.Test;
/*    */ import org.aspectj.weaver.ast.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NameBindingPointcut
/*    */   extends Pointcut
/*    */ {
/*    */   protected Test exposeStateForVar(Var var, TypePattern type, ExposedState state, World world) {
/* 36 */     if (type instanceof BindingTypePattern) {
/* 37 */       BindingTypePattern b = (BindingTypePattern)type;
/* 38 */       state.set(b.getFormalIndex(), var);
/*    */     } 
/* 40 */     ResolvedType myType = type.getExactType().resolve(world);
/* 41 */     if (myType.isParameterizedType())
/*    */     {
/* 43 */       myType = myType.getRawType();
/*    */     }
/* 45 */     return Test.makeInstanceof(var, myType.resolve(world));
/*    */   }
/*    */   
/*    */   public abstract List<BindingTypePattern> getBindingTypePatterns();
/*    */   
/*    */   public abstract List<BindingPattern> getBindingAnnotationTypePatterns();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\NameBindingPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */