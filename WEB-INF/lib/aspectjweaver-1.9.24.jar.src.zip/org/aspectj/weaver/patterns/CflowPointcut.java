/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.util.FileUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.Advice;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.CrosscuttingMembers;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.NameMangler;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedMemberImpl;
/*     */ import org.aspectj.weaver.ResolvedPointcutDefinition;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.ShadowMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CflowPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   private final Pointcut entry;
/*     */   boolean isBelow;
/*     */   private int[] freeVars;
/*  56 */   public static final ResolvedPointcutDefinition CFLOW_MARKER = new ResolvedPointcutDefinition(null, 0, null, UnresolvedType.NONE, 
/*  57 */       Pointcut.makeMatchesNothing(Pointcut.RESOLVED));
/*     */ 
/*     */   
/*     */   public CflowPointcut(Pointcut entry, boolean isBelow, int[] freeVars) {
/*  61 */     this.entry = entry;
/*  62 */     this.isBelow = isBelow;
/*  63 */     this.freeVars = freeVars;
/*  64 */     this.pointcutKind = 10;
/*     */   }
/*     */   
/*     */   public boolean isCflowBelow() {
/*  68 */     return this.isBelow;
/*     */   }
/*     */   
/*     */   public int couldMatchKinds() {
/*  72 */     return Shadow.ALL_SHADOW_KINDS_BITS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut getEntry() {
/*  77 */     return this.entry;
/*     */   }
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo type) {
/*  81 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*  86 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  90 */     s.writeByte(10);
/*  91 */     this.entry.write(s);
/*  92 */     s.writeBoolean(this.isBelow);
/*  93 */     FileUtil.writeIntArray(this.freeVars, (DataOutputStream)s);
/*  94 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  99 */     CflowPointcut ret = new CflowPointcut(Pointcut.read(s, context), s.readBoolean(), FileUtil.readIntArray((DataInputStream)s));
/* 100 */     ret.readLocation(context, (DataInputStream)s);
/* 101 */     return ret;
/*     */   }
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 105 */     CflowPointcut ret = new CflowPointcut(this.entry.parameterizeWith(typeVariableMap, w), this.isBelow, this.freeVars);
/* 106 */     ret.copyLocationFrom(this);
/* 107 */     return ret;
/*     */   }
/*     */   
/*     */   public void resolveBindings(IScope scope, Bindings bindings) {
/* 111 */     if (bindings == null) {
/* 112 */       this.entry.resolveBindings(scope, (Bindings)null);
/* 113 */       this.entry.state = RESOLVED;
/* 114 */       this.freeVars = new int[0];
/*     */     } else {
/*     */       
/* 117 */       Bindings entryBindings = new Bindings(bindings.size());
/*     */       
/* 119 */       this.entry.resolveBindings(scope, entryBindings);
/* 120 */       this.entry.state = RESOLVED;
/*     */       
/* 122 */       this.freeVars = entryBindings.getUsedFormals();
/*     */       
/* 124 */       bindings.mergeIn(entryBindings, scope);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 129 */     if (!(other instanceof CflowPointcut)) {
/* 130 */       return false;
/*     */     }
/* 132 */     CflowPointcut o = (CflowPointcut)other;
/* 133 */     return (o.entry.equals(this.entry) && o.isBelow == this.isBelow);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 137 */     int result = 17;
/* 138 */     result = 37 * result + this.entry.hashCode();
/* 139 */     result = 37 * result + (this.isBelow ? 0 : 1);
/* 140 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 144 */     return "cflow" + (this.isBelow ? "below" : "") + "(" + this.entry + ")";
/*     */   }
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 148 */     throw new RuntimeException("unimplemented - did concretization fail?");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/*     */     Pointcut concreteEntry;
/*     */     Object object1;
/* 161 */     if (isDeclare(bindings.getEnclosingAdvice())) {
/* 162 */       inAspect.getWorld().showMessage(IMessage.ERROR, 
/* 163 */           WeaverMessages.format("cflowInDeclare", this.isBelow ? "below" : ""), bindings
/* 164 */           .getEnclosingAdvice().getSourceLocation(), null);
/* 165 */       return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */     } 
/*     */ 
/*     */     
/* 169 */     IntMap entryBindings = new IntMap();
/* 170 */     if (this.freeVars != null) {
/* 171 */       for (int j = 0, k = this.freeVars.length; j < k; j++) {
/* 172 */         int freeVar = this.freeVars[j];
/*     */         
/* 174 */         entryBindings.put(freeVar, j);
/*     */       } 
/*     */     }
/* 177 */     entryBindings.copyContext(bindings);
/*     */ 
/*     */     
/* 180 */     World world = inAspect.getWorld();
/*     */ 
/*     */ 
/*     */     
/* 184 */     ResolvedType concreteAspect = bindings.getConcreteAspect();
/*     */     
/* 186 */     CrosscuttingMembers xcut = concreteAspect.crosscuttingMembers;
/* 187 */     Collection<ShadowMunger> previousCflowEntries = xcut.getCflowEntries();
/*     */     
/* 189 */     entryBindings.pushEnclosingDefinition(CFLOW_MARKER);
/*     */     
/*     */     try {
/* 192 */       concreteEntry = this.entry.concretize(inAspect, declaringType, entryBindings);
/*     */     } finally {
/* 194 */       entryBindings.popEnclosingDefinitition();
/*     */     } 
/*     */     
/* 197 */     List<ShadowMunger> innerCflowEntries = new ArrayList<>(xcut.getCflowEntries());
/* 198 */     innerCflowEntries.removeAll(previousCflowEntries);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (this.freeVars == null || this.freeVars.length == 0) {
/*     */       ResolvedMemberImpl resolvedMemberImpl;
/*     */       
/* 218 */       ResolvedMember resolvedMember = null;
/*     */       
/* 220 */       object1 = getCflowfield(xcut, concreteEntry, concreteAspect, "counter");
/*     */ 
/*     */       
/* 223 */       if (object1 != null) {
/* 224 */         resolvedMember = (ResolvedMember)object1;
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 232 */         resolvedMemberImpl = new ResolvedMemberImpl(Member.FIELD, (UnresolvedType)concreteAspect, 9, NameMangler.cflowCounter(xcut), UnresolvedType.forName("org.aspectj.runtime.internal.CFlowCounter").getSignature());
/*     */ 
/*     */         
/* 235 */         concreteAspect.crosscuttingMembers.addTypeMunger(world.getWeavingSupport().makeCflowCounterFieldAdder((ResolvedMember)resolvedMemberImpl));
/*     */ 
/*     */ 
/*     */         
/* 239 */         concreteAspect.crosscuttingMembers.addConcreteShadowMunger((ShadowMunger)Advice.makeCflowEntry(world, concreteEntry, this.isBelow, (Member)resolvedMemberImpl, 
/* 240 */               (this.freeVars == null) ? 0 : this.freeVars.length, innerCflowEntries, inAspect));
/*     */         
/* 242 */         putCflowfield(xcut, concreteEntry, concreteAspect, resolvedMemberImpl, "counter");
/*     */       } 
/*     */ 
/*     */       
/* 246 */       Pointcut pointcut = new ConcreteCflowPointcut(concreteAspect, (Member)resolvedMemberImpl, null, true);
/* 247 */       pointcut.copyLocationFrom(this);
/* 248 */       return pointcut;
/*     */     } 
/*     */     
/* 251 */     List<ConcreteCflowPointcut.Slot> slots = new ArrayList<>();
/*     */     
/* 253 */     for (int i = 0, len = this.freeVars.length; i < len; i++) {
/* 254 */       int freeVar = this.freeVars[i];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 260 */       if (bindings.hasKey(freeVar)) {
/*     */ 
/*     */ 
/*     */         
/* 264 */         int formalIndex = bindings.get(freeVar);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 275 */         ResolvedPointcutDefinition enclosingDef = bindings.peekEnclosingDefinition();
/* 276 */         ResolvedType formalType = null;
/*     */ 
/*     */         
/* 279 */         if (enclosingDef != null && (enclosingDef.getParameterTypes()).length > 0) {
/* 280 */           formalType = enclosingDef.getParameterTypes()[freeVar].resolve(world);
/*     */         } else {
/* 282 */           formalType = bindings.getAdviceSignature().getParameterTypes()[formalIndex].resolve(world);
/*     */         } 
/*     */         
/* 285 */         ConcreteCflowPointcut.Slot slot = new ConcreteCflowPointcut.Slot(formalIndex, formalType, i);
/* 286 */         slots.add(slot);
/*     */       } 
/* 288 */     }  ResolvedMember localCflowField = null;
/* 289 */     Object field = getCflowfield(xcut, concreteEntry, concreteAspect, "stack");
/* 290 */     if (field != null) {
/* 291 */       localCflowField = (ResolvedMember)field;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 296 */       object1 = new ResolvedMemberImpl(Member.FIELD, (UnresolvedType)concreteAspect, 9, NameMangler.cflowStack(xcut), UnresolvedType.forName("org.aspectj.runtime.internal.CFlowStack").getSignature());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 304 */       concreteAspect.crosscuttingMembers.addConcreteShadowMunger((ShadowMunger)Advice.makeCflowEntry(world, concreteEntry, this.isBelow, (Member)object1, this.freeVars.length, innerCflowEntries, inAspect));
/*     */ 
/*     */       
/* 307 */       concreteAspect.crosscuttingMembers.addTypeMunger(world.getWeavingSupport()
/* 308 */           .makeCflowStackFieldAdder((ResolvedMember)object1));
/* 309 */       putCflowfield(xcut, concreteEntry, concreteAspect, object1, "stack");
/*     */     } 
/* 311 */     Pointcut ret = new ConcreteCflowPointcut(concreteAspect, (Member)object1, slots, false);
/* 312 */     ret.copyLocationFrom(this);
/* 313 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getKey(Pointcut p, ResolvedType a, String stackOrCounter) {
/* 319 */     StringBuilder sb = new StringBuilder();
/* 320 */     sb.append(a.getName());
/* 321 */     sb.append("::");
/* 322 */     sb.append(p.toString());
/* 323 */     sb.append("::");
/* 324 */     sb.append(stackOrCounter);
/* 325 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private Object getCflowfield(CrosscuttingMembers xcut, Pointcut pcutkey, ResolvedType concreteAspect, String stackOrCounter) {
/* 329 */     String key = getKey(pcutkey, concreteAspect, stackOrCounter);
/* 330 */     Object o = null;
/* 331 */     if (this.isBelow) {
/* 332 */       o = xcut.getCflowBelowFields().get(key);
/*     */     } else {
/* 334 */       o = xcut.getCflowFields().get(key);
/*     */     } 
/*     */     
/* 337 */     return o;
/*     */   }
/*     */ 
/*     */   
/*     */   private void putCflowfield(CrosscuttingMembers xcut, Pointcut pcutkey, ResolvedType concreteAspect, Object o, String stackOrCounter) {
/* 342 */     String key = getKey(pcutkey, concreteAspect, stackOrCounter);
/*     */     
/* 344 */     if (this.isBelow) {
/* 345 */       xcut.getCflowBelowFields().put(key, o);
/*     */     } else {
/* 347 */       xcut.getCflowFields().put(key, o);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 352 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 357 */     Object ret = accept(visitor, data);
/* 358 */     if (this.entry != null)
/* 359 */       this.entry.traverse(visitor, ret); 
/* 360 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\CflowPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */