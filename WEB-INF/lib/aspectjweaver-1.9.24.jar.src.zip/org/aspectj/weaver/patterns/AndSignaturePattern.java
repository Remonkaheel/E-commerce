/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndSignaturePattern
/*     */   extends AbstractSignaturePattern
/*     */ {
/*     */   private ISignaturePattern leftSp;
/*     */   private ISignaturePattern rightSp;
/*     */   private List<ExactTypePattern> exactDeclaringTypes;
/*     */   
/*     */   public AndSignaturePattern(ISignaturePattern leftSp, ISignaturePattern rightSp) {
/*  39 */     this.leftSp = leftSp;
/*  40 */     this.rightSp = rightSp;
/*     */   }
/*     */   
/*     */   public boolean couldEverMatch(ResolvedType type) {
/*  44 */     return (this.leftSp.couldEverMatch(type) || this.rightSp.couldEverMatch(type));
/*     */   }
/*     */   
/*     */   public List<ExactTypePattern> getExactDeclaringTypes() {
/*  48 */     if (this.exactDeclaringTypes == null) {
/*  49 */       this.exactDeclaringTypes = new ArrayList<>();
/*  50 */       this.exactDeclaringTypes.addAll(this.leftSp.getExactDeclaringTypes());
/*  51 */       this.exactDeclaringTypes.addAll(this.rightSp.getExactDeclaringTypes());
/*     */     } 
/*  53 */     return this.exactDeclaringTypes;
/*     */   }
/*     */   
/*     */   public boolean isMatchOnAnyName() {
/*  57 */     return (this.leftSp.isMatchOnAnyName() || this.rightSp.isMatchOnAnyName());
/*     */   }
/*     */   
/*     */   public boolean isStarAnnotation() {
/*  61 */     return (this.leftSp.isStarAnnotation() || this.rightSp.isStarAnnotation());
/*     */   }
/*     */   
/*     */   public boolean matches(Member member, World world, boolean b) {
/*  65 */     return (this.leftSp.matches(member, world, b) && this.rightSp.matches(member, world, b));
/*     */   }
/*     */   
/*     */   public ISignaturePattern parameterizeWith(Map<String, UnresolvedType> typeVariableBindingMap, World world) {
/*  69 */     return new AndSignaturePattern(this.leftSp.parameterizeWith(typeVariableBindingMap, world), this.rightSp.parameterizeWith(typeVariableBindingMap, world));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISignaturePattern resolveBindings(IScope scope, Bindings bindings) {
/*  76 */     this.leftSp.resolveBindings(scope, bindings);
/*  77 */     this.rightSp.resolveBindings(scope, bindings);
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   public static ISignaturePattern readAndSignaturePattern(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  82 */     AndSignaturePattern ret = new AndSignaturePattern(readCompoundSignaturePattern(s, context), readCompoundSignaturePattern(s, context));
/*     */     
/*  84 */     s.readInt();
/*  85 */     s.readInt();
/*     */     
/*  87 */     return ret;
/*     */   }
/*     */   
/*     */   public ISignaturePattern getLeft() {
/*  91 */     return this.leftSp;
/*     */   }
/*     */   
/*     */   public ISignaturePattern getRight() {
/*  95 */     return this.rightSp;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  99 */     StringBuilder sb = new StringBuilder();
/* 100 */     sb.append(this.leftSp.toString()).append(" && ").append(this.rightSp.toString());
/* 101 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AndSignaturePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */