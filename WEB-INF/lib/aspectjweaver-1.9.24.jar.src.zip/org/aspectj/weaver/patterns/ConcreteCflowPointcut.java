/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.Message;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.MemberImpl;
/*     */ import org.aspectj.weaver.NameMangler;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Expr;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcreteCflowPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   private final Member cflowField;
/*     */   List<Slot> slots;
/*     */   boolean usesCounter;
/*     */   ResolvedType aspect;
/*     */   
/*     */   public ConcreteCflowPointcut(ResolvedType aspect, Member cflowField, List<Slot> slots, boolean usesCounter) {
/*  43 */     this.aspect = aspect;
/*  44 */     this.cflowField = cflowField;
/*  45 */     this.slots = slots;
/*  46 */     this.usesCounter = usesCounter;
/*  47 */     this.pointcutKind = 10;
/*     */   }
/*     */   
/*     */   public int couldMatchKinds() {
/*  51 */     return Shadow.ALL_SHADOW_KINDS_BITS;
/*     */   }
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo type) {
/*  55 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*  64 */     if (this.slots != null) {
/*  65 */       for (Slot slot : this.slots) {
/*  66 */         ResolvedType rt = slot.formalType;
/*  67 */         if (rt.isMissing()) {
/*  68 */           ISourceLocation[] locs = { getSourceLocation() };
/*     */           
/*  70 */           Message m = new Message(WeaverMessages.format("missingTypePreventsMatch", rt.getName()), "", Message.WARNING, shadow.getSourceLocation(), null, locs);
/*  71 */           rt.getWorld().getMessageHandler().handleMessage((IMessage)m);
/*  72 */           return FuzzyBoolean.NO;
/*     */         } 
/*     */       } 
/*     */     }
/*  76 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getUsedFormalSlots() {
/*  81 */     if (this.slots == null) {
/*  82 */       return new int[0];
/*     */     }
/*  84 */     int[] indices = new int[this.slots.size()];
/*  85 */     for (int i = 0; i < indices.length; i++) {
/*  86 */       indices[i] = ((Slot)this.slots.get(i)).formalIndex;
/*     */     }
/*  88 */     return indices;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  92 */     throw new RuntimeException("unimplemented");
/*     */   }
/*     */   
/*     */   public void resolveBindings(IScope scope, Bindings bindings) {
/*  96 */     throw new RuntimeException("unimplemented");
/*     */   }
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 100 */     throw new RuntimeException("unimplemented");
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 104 */     if (!(other instanceof ConcreteCflowPointcut)) {
/* 105 */       return false;
/*     */     }
/* 107 */     ConcreteCflowPointcut o = (ConcreteCflowPointcut)other;
/* 108 */     return o.cflowField.equals(this.cflowField);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 112 */     int result = 17;
/* 113 */     result = 37 * result + this.cflowField.hashCode();
/* 114 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 118 */     return "concretecflow(" + this.cflowField + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 123 */     if (this.usesCounter) {
/* 124 */       return Test.makeFieldGetCall(this.cflowField, cflowCounterIsValidMethod, Expr.NONE);
/*     */     }
/* 126 */     if (this.slots != null) {
/* 127 */       for (Slot slot : this.slots)
/*     */       {
/* 129 */         state.set(slot.formalIndex, this.aspect
/* 130 */             .getWorld().getWeavingSupport().makeCflowAccessVar(slot.formalType, this.cflowField, slot.arrayIndex));
/*     */       }
/*     */     }
/* 133 */     return Test.makeFieldGetCall(this.cflowField, cflowStackIsValidMethod, Expr.NONE);
/*     */   }
/*     */ 
/*     */   
/* 137 */   private static final Member cflowStackIsValidMethod = (Member)MemberImpl.method(NameMangler.CFLOW_STACK_UNRESOLVEDTYPE, 0, UnresolvedType.BOOLEAN, "isValid", UnresolvedType.NONE);
/*     */ 
/*     */   
/* 140 */   private static final Member cflowCounterIsValidMethod = (Member)MemberImpl.method(NameMangler.CFLOW_COUNTER_UNRESOLVEDTYPE, 0, UnresolvedType.BOOLEAN, "isValid", UnresolvedType.NONE);
/*     */ 
/*     */   
/*     */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 144 */     throw new RuntimeException("unimplemented");
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 148 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public static class Slot {
/*     */     int formalIndex;
/*     */     ResolvedType formalType;
/*     */     int arrayIndex;
/*     */     
/*     */     public Slot(int formalIndex, ResolvedType formalType, int arrayIndex) {
/* 157 */       this.formalIndex = formalIndex;
/* 158 */       this.formalType = formalType;
/* 159 */       this.arrayIndex = arrayIndex;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other) {
/* 163 */       if (!(other instanceof Slot)) {
/* 164 */         return false;
/*     */       }
/*     */       
/* 167 */       Slot o = (Slot)other;
/* 168 */       return (o.formalIndex == this.formalIndex && o.arrayIndex == this.arrayIndex && o.formalType.equals(this.formalType));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 172 */       int result = 19;
/* 173 */       result = 37 * result + this.formalIndex;
/* 174 */       result = 37 * result + this.arrayIndex;
/* 175 */       result = 37 * result + this.formalType.hashCode();
/* 176 */       return result;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 180 */       return "Slot(" + this.formalIndex + ", " + this.formalType + ", " + this.arrayIndex + ")";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ConcreteCflowPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */