/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicTokenSource
/*     */   implements ITokenSource
/*     */ {
/*  24 */   private int index = 0;
/*     */   private IToken[] tokens;
/*     */   private ISourceContext sourceContext;
/*     */   
/*     */   public BasicTokenSource(IToken[] tokens, ISourceContext sourceContext) {
/*  29 */     this.tokens = tokens;
/*  30 */     this.sourceContext = sourceContext;
/*     */   }
/*     */   
/*     */   public int getIndex() {
/*  34 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setIndex(int newIndex) {
/*  38 */     this.index = newIndex;
/*     */   }
/*     */   
/*     */   public IToken next() {
/*     */     try {
/*  43 */       return this.tokens[this.index++];
/*  44 */     } catch (ArrayIndexOutOfBoundsException e) {
/*  45 */       return IToken.EOF;
/*     */     } 
/*     */   }
/*     */   
/*     */   public IToken peek() {
/*     */     try {
/*  51 */       return this.tokens[this.index];
/*  52 */     } catch (ArrayIndexOutOfBoundsException e) {
/*  53 */       return IToken.EOF;
/*     */     } 
/*     */   }
/*     */   
/*     */   public IToken peek(int offset) {
/*     */     try {
/*  59 */       return this.tokens[this.index + offset];
/*  60 */     } catch (ArrayIndexOutOfBoundsException e) {
/*  61 */       return IToken.EOF;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/*  66 */     StringBuilder buf = new StringBuilder();
/*  67 */     buf.append("[");
/*  68 */     for (int i = 0; i < this.tokens.length; i++) {
/*  69 */       IToken t = this.tokens[i];
/*  70 */       if (t == null)
/*     */         break; 
/*  72 */       if (i > 0)
/*  73 */         buf.append(", "); 
/*  74 */       buf.append(t.toString());
/*     */     } 
/*  76 */     buf.append("]");
/*  77 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ITokenSource makeTokenSource(String input, ISourceContext context) {
/*  84 */     char[] chars = input.toCharArray();
/*     */     
/*  86 */     int i = 0;
/*  87 */     List<BasicToken> tokens = new ArrayList<>();
/*     */     
/*  89 */     while (i < chars.length) {
/*  90 */       char nextChar; int start0; char ch = chars[i++];
/*  91 */       switch (ch) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\r':
/*     */         case ' ':
/*     */           continue;
/*     */         case '!':
/*     */         case '(':
/*     */         case ')':
/*     */         case '*':
/*     */         case '+':
/*     */         case ',':
/*     */         case ':':
/*     */         case '<':
/*     */         case '=':
/*     */         case '>':
/*     */         case '?':
/*     */         case '@':
/*     */         case '[':
/*     */         case ']':
/* 111 */           tokens.add(BasicToken.makeOperator(makeString(ch), i - 1, i - 1));
/*     */           continue;
/*     */         case '.':
/* 114 */           if (i + 2 <= chars.length) {
/*     */             
/* 116 */             char nextChar1 = chars[i];
/* 117 */             char nextChar2 = chars[i + 1];
/* 118 */             if (ch == nextChar1 && ch == nextChar2) {
/*     */               
/* 120 */               tokens.add(BasicToken.makeIdentifier("...", i - 1, i + 1));
/* 121 */               i += 2; continue;
/*     */             } 
/* 123 */             tokens.add(BasicToken.makeOperator(makeString(ch), i - 1, i - 1));
/*     */             continue;
/*     */           } 
/* 126 */           tokens.add(BasicToken.makeOperator(makeString(ch), i - 1, i - 1));
/*     */           continue;
/*     */         
/*     */         case '&':
/* 130 */           if (i + 1 <= chars.length && chars[i] != '&') {
/* 131 */             tokens.add(BasicToken.makeOperator(makeString(ch), i - 1, i - 1));
/*     */             continue;
/*     */           } 
/*     */         
/*     */         case '|':
/* 136 */           if (i == chars.length) {
/* 137 */             throw new BCException("bad " + ch);
/*     */           }
/* 139 */           nextChar = chars[i++];
/* 140 */           if (nextChar == ch) {
/* 141 */             tokens.add(BasicToken.makeOperator(makeString(ch, 2), i - 2, i - 1)); continue;
/*     */           } 
/* 143 */           throw new RuntimeException("bad " + ch);
/*     */ 
/*     */ 
/*     */         
/*     */         case '"':
/* 148 */           start0 = i - 1;
/* 149 */           for (; i < chars.length && chars[i] != '"'; i++);
/* 150 */           i++;
/* 151 */           tokens.add(BasicToken.makeLiteral(new String(chars, start0 + 1, i - start0 - 2), "string", start0, i - 1));
/*     */           continue;
/*     */       } 
/* 154 */       int start = i - 1;
/* 155 */       for (; i < chars.length && Character.isJavaIdentifierPart(chars[i]); i++);
/* 156 */       tokens.add(BasicToken.makeIdentifier(new String(chars, start, i - start), start, i - 1));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     return new BasicTokenSource(tokens.<IToken>toArray(new IToken[0]), context);
/*     */   }
/*     */   
/*     */   private static String makeString(char ch) {
/* 167 */     return Character.toString(ch);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String makeString(char ch, int count) {
/* 172 */     char[] chars = new char[count];
/* 173 */     for (int i = 0; i < count; ) { chars[i] = ch; i++; }
/* 174 */      return new String(chars);
/*     */   }
/*     */   public ISourceContext getSourceContext() {
/* 177 */     return this.sourceContext;
/*     */   }
/*     */   public void setSourceContext(ISourceContext context) {
/* 180 */     this.sourceContext = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMoreTokens() {
/* 185 */     return (this.index < this.tokens.length);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\BasicTokenSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */