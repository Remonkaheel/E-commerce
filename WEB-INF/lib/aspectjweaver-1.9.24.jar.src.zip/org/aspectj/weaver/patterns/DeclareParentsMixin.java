/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.aspectj.weaver.CompressingDataOutputStream;
/*    */ import org.aspectj.weaver.ISourceContext;
/*    */ import org.aspectj.weaver.VersionedDataInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclareParentsMixin
/*    */   extends DeclareParents
/*    */ {
/* 27 */   private int bitflags = 0;
/*    */   
/*    */   public DeclareParentsMixin(TypePattern child, List<TypePattern> parents) {
/* 30 */     super(child, parents, true);
/*    */   }
/*    */   
/*    */   public DeclareParentsMixin(TypePattern child, TypePatternList parents) {
/* 34 */     super(child, parents, true);
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 38 */     if (!(other instanceof DeclareParentsMixin)) {
/* 39 */       return false;
/*    */     }
/* 41 */     DeclareParentsMixin o = (DeclareParentsMixin)other;
/* 42 */     return (o.child.equals(this.child) && o.parents.equals(this.parents) && o.bitflags == this.bitflags);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 46 */     int result = 23;
/* 47 */     result = 37 * result + this.child.hashCode();
/* 48 */     result = 37 * result + this.parents.hashCode();
/* 49 */     result = 37 * result + this.bitflags;
/* 50 */     return result;
/*    */   }
/*    */   
/*    */   public void write(CompressingDataOutputStream s) throws IOException {
/* 54 */     s.writeByte(6);
/* 55 */     this.child.write(s);
/* 56 */     this.parents.write(s);
/* 57 */     writeLocation((DataOutputStream)s);
/* 58 */     s.writeInt(this.bitflags);
/*    */   }
/*    */   
/*    */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 62 */     DeclareParentsMixin ret = new DeclareParentsMixin(TypePattern.read(s, context), TypePatternList.read(s, context));
/* 63 */     ret.readLocation(context, (DataInputStream)s);
/* 64 */     ret.bitflags = s.readInt();
/* 65 */     return ret;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 69 */     StringBuilder buf = new StringBuilder();
/* 70 */     buf.append("declare parents mixin: ");
/* 71 */     buf.append(this.child);
/* 72 */     buf.append(" implements ");
/* 73 */     buf.append(this.parents);
/* 74 */     buf.append(";");
/* 75 */     buf.append("bits=0x").append(Integer.toHexString(this.bitflags));
/* 76 */     return buf.toString();
/*    */   }
/*    */   
/*    */   public boolean isMixin() {
/* 80 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\DeclareParentsMixin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */