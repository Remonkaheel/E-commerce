/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeclareErrorOrWarning
/*     */   extends Declare
/*     */ {
/*     */   private boolean isError;
/*     */   private Pointcut pointcut;
/*     */   private String message;
/*     */   
/*     */   public DeclareErrorOrWarning(boolean isError, Pointcut pointcut, String message) {
/*  30 */     this.isError = isError;
/*  31 */     this.pointcut = pointcut;
/*  32 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  39 */     StringBuilder buf = new StringBuilder();
/*  40 */     buf.append("declare ");
/*  41 */     if (this.isError) {
/*  42 */       buf.append("error: ");
/*     */     } else {
/*  44 */       buf.append("warning: ");
/*     */     } 
/*  46 */     buf.append(this.pointcut);
/*  47 */     buf.append(": ");
/*  48 */     buf.append("\"");
/*  49 */     buf.append(this.message);
/*  50 */     buf.append("\";");
/*  51 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  55 */     if (!(other instanceof DeclareErrorOrWarning)) {
/*  56 */       return false;
/*     */     }
/*  58 */     DeclareErrorOrWarning o = (DeclareErrorOrWarning)other;
/*  59 */     return (o.isError == this.isError && o.pointcut.equals(this.pointcut) && o.message.equals(this.message));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  63 */     int result = this.isError ? 19 : 23;
/*  64 */     result = 37 * result + this.pointcut.hashCode();
/*  65 */     result = 37 * result + this.message.hashCode();
/*  66 */     return result;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/*  70 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/*  74 */     Object ret = accept(visitor, data);
/*  75 */     if (this.pointcut != null)
/*  76 */       this.pointcut.traverse(visitor, ret); 
/*  77 */     return ret;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  81 */     s.writeByte(1);
/*  82 */     s.writeBoolean(this.isError);
/*  83 */     this.pointcut.write(s);
/*  84 */     s.writeUTF(this.message);
/*  85 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  89 */     Declare ret = new DeclareErrorOrWarning(s.readBoolean(), Pointcut.read(s, context), s.readUTF());
/*  90 */     ret.readLocation(context, (DataInputStream)s);
/*  91 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isError() {
/*  95 */     return this.isError;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/*  99 */     return this.message;
/*     */   }
/*     */   
/*     */   public Pointcut getPointcut() {
/* 103 */     return this.pointcut;
/*     */   }
/*     */   
/*     */   public void resolve(IScope scope) {
/* 107 */     this.pointcut = this.pointcut.resolve(scope);
/*     */   }
/*     */   
/*     */   public Declare parameterizeWith(Map<String, UnresolvedType> typeVariableBindingMap, World w) {
/* 111 */     Declare ret = new DeclareErrorOrWarning(this.isError, this.pointcut.parameterizeWith(typeVariableBindingMap, w), this.message);
/* 112 */     ret.copyLocationFrom(this);
/* 113 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isAdviceLike() {
/* 117 */     return true;
/*     */   }
/*     */   
/*     */   public String getNameSuffix() {
/* 121 */     return "eow";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 128 */     StringBuilder buf = new StringBuilder();
/* 129 */     buf.append("declare ");
/* 130 */     if (this.isError) {
/* 131 */       buf.append("error");
/*     */     } else {
/* 133 */       buf.append("warning");
/*     */     } 
/* 135 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\DeclareErrorOrWarning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */