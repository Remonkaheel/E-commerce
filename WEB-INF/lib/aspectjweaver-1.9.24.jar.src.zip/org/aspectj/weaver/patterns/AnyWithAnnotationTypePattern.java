/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnyWithAnnotationTypePattern
/*     */   extends TypePattern
/*     */ {
/*     */   public AnyWithAnnotationTypePattern(AnnotationTypePattern atp) {
/*  35 */     super(false, false);
/*  36 */     this.annotationPattern = atp;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/*  41 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean couldEverMatchSameTypesAs(TypePattern other) {
/*  46 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type) {
/*  51 */     this.annotationPattern.resolve(type.getWorld());
/*  52 */     boolean b = false;
/*  53 */     if (type.temporaryAnnotationTypes != null) {
/*  54 */       b = this.annotationPattern.matches((AnnotatedElement)type, type.temporaryAnnotationTypes).alwaysTrue();
/*     */     } else {
/*  56 */       b = this.annotationPattern.matches((AnnotatedElement)type).alwaysTrue();
/*     */     } 
/*  58 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding, boolean requireExactType) {
/*  63 */     if (requireExactType) {
/*  64 */       scope.getWorld().getMessageHandler().handleMessage(
/*  65 */           MessageUtil.error(WeaverMessages.format("wildcardTypePatternNotAllowed"), getSourceLocation()));
/*  66 */       return NO;
/*     */     } 
/*  68 */     return super.resolveBindings(scope, bindings, allowBinding, requireExactType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type, ResolvedType annotatedType) {
/*  73 */     this.annotationPattern.resolve(type.getWorld());
/*  74 */     return this.annotationPattern.matches((AnnotatedElement)annotatedType).alwaysTrue();
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesInstanceof(ResolvedType type) {
/*  79 */     if (Modifier.isFinal(type.getModifiers())) {
/*  80 */       return FuzzyBoolean.fromBoolean(matchesExactly(type));
/*     */     }
/*  82 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesArray(UnresolvedType type) {
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  92 */     AnyWithAnnotationTypePattern ret = new AnyWithAnnotationTypePattern(this.annotationPattern.parameterizeWith(typeVariableMap, w));
/*     */     
/*  94 */     ret.copyLocationFrom(this);
/*  95 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 100 */     s.writeByte(10);
/* 101 */     this.annotationPattern.write(s);
/* 102 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static TypePattern read(VersionedDataInputStream s, ISourceContext c) throws IOException {
/* 106 */     AnnotationTypePattern annPatt = AnnotationTypePattern.read(s, c);
/* 107 */     AnyWithAnnotationTypePattern ret = new AnyWithAnnotationTypePattern(annPatt);
/* 108 */     ret.readLocation(c, (DataInputStream)s);
/* 109 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesSubtypes(ResolvedType type) {
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStar() {
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     return "(" + this.annotationPattern + " *)";
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern getAnnotationTypePattern() {
/* 132 */     return this.annotationPattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 137 */     if (!(obj instanceof AnyWithAnnotationTypePattern)) {
/* 138 */       return false;
/*     */     }
/* 140 */     AnyWithAnnotationTypePattern awatp = (AnyWithAnnotationTypePattern)obj;
/* 141 */     return this.annotationPattern.equals(awatp.annotationPattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     return this.annotationPattern.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AnyWithAnnotationTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */