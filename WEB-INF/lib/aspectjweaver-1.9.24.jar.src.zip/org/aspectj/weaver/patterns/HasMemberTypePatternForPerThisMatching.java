/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.aspectj.weaver.CompressingDataOutputStream;
/*    */ import org.aspectj.weaver.ConcreteTypeMunger;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HasMemberTypePatternForPerThisMatching
/*    */   extends HasMemberTypePattern
/*    */ {
/*    */   public HasMemberTypePatternForPerThisMatching(SignaturePattern aSignaturePattern) {
/* 46 */     super(aSignaturePattern);
/*    */   }
/*    */   
/*    */   protected boolean hasMethod(ResolvedType type) {
/* 50 */     boolean b = super.hasMethod(type);
/* 51 */     if (b) {
/* 52 */       return true;
/*    */     }
/*    */     
/* 55 */     List<ConcreteTypeMunger> mungers = type.getInterTypeMungersIncludingSupers();
/* 56 */     if (mungers.size() != 0) {
/* 57 */       return true;
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(CompressingDataOutputStream s) throws IOException {
/* 64 */     throw new IllegalAccessError("Should never be called, these are transient and don't get serialized");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\HasMemberTypePatternForPerThisMatching.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */