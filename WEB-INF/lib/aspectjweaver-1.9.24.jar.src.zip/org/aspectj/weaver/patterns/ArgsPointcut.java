/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.IHasPosition;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgsPointcut
/*     */   extends NameBindingPointcut
/*     */ {
/*     */   private static final String ASPECTJ_JP_SIGNATURE_PREFIX = "Lorg/aspectj/lang/JoinPoint";
/*     */   private static final String ASPECTJ_SYNTHETIC_SIGNATURE_PREFIX = "Lorg/aspectj/runtime/internal/";
/*     */   private TypePatternList arguments;
/*     */   private String stringRepresentation;
/*     */   
/*     */   public ArgsPointcut(TypePatternList arguments) {
/*  51 */     this.arguments = arguments;
/*  52 */     this.pointcutKind = 4;
/*  53 */     this.stringRepresentation = "args" + arguments.toString() + "";
/*     */   }
/*     */   
/*     */   public TypePatternList getArguments() {
/*  57 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  61 */     ArgsPointcut ret = new ArgsPointcut(this.arguments.parameterizeWith(typeVariableMap, w));
/*  62 */     ret.copyLocationFrom(this);
/*  63 */     return ret;
/*     */   }
/*     */   
/*     */   public int couldMatchKinds() {
/*  67 */     return Shadow.ALL_SHADOW_KINDS_BITS;
/*     */   }
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo type) {
/*  71 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*  75 */     ResolvedType[] argumentsToMatchAgainst = getArgumentsToMatchAgainst(shadow);
/*  76 */     FuzzyBoolean ret = this.arguments.matches(argumentsToMatchAgainst, TypePattern.DYNAMIC);
/*  77 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private ResolvedType[] getArgumentsToMatchAgainst(Shadow shadow) {
/*  82 */     if (shadow.isShadowForArrayConstructionJoinpoint()) {
/*  83 */       return shadow.getArgumentTypesForArrayConstructionShadow();
/*     */     }
/*     */     
/*  86 */     ResolvedType[] argumentsToMatchAgainst = shadow.getIWorld().resolve(shadow.getGenericArgTypes());
/*     */ 
/*     */ 
/*     */     
/*  90 */     if (shadow.getKind() == Shadow.AdviceExecution) {
/*  91 */       int numExtraArgs = 0;
/*  92 */       for (ResolvedType resolvedType : argumentsToMatchAgainst) {
/*  93 */         String argumentSignature = resolvedType.getSignature();
/*  94 */         if (argumentSignature.startsWith("Lorg/aspectj/lang/JoinPoint") || argumentSignature
/*  95 */           .startsWith("Lorg/aspectj/runtime/internal/")) {
/*  96 */           numExtraArgs++;
/*     */         } else {
/*     */           
/*  99 */           numExtraArgs = 0;
/*     */         } 
/*     */       } 
/* 102 */       if (numExtraArgs > 0) {
/* 103 */         int newArgLength = argumentsToMatchAgainst.length - numExtraArgs;
/* 104 */         ResolvedType[] argsSubset = new ResolvedType[newArgLength];
/* 105 */         System.arraycopy(argumentsToMatchAgainst, 0, argsSubset, 0, newArgLength);
/* 106 */         argumentsToMatchAgainst = argsSubset;
/*     */       } 
/* 108 */     } else if (shadow.getKind() == Shadow.ConstructorExecution && (
/* 109 */       shadow.getMatchingSignature().getParameterTypes()).length < argumentsToMatchAgainst.length) {
/*     */       
/* 111 */       int newArgLength = (shadow.getMatchingSignature().getParameterTypes()).length;
/* 112 */       ResolvedType[] argsSubset = new ResolvedType[newArgLength];
/* 113 */       System.arraycopy(argumentsToMatchAgainst, 0, argsSubset, 0, newArgLength);
/* 114 */       argumentsToMatchAgainst = argsSubset;
/*     */     } 
/*     */     
/* 117 */     return argumentsToMatchAgainst;
/*     */   }
/*     */   
/*     */   public List<BindingPattern> getBindingAnnotationTypePatterns() {
/* 121 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public List<BindingTypePattern> getBindingTypePatterns() {
/* 125 */     List<BindingTypePattern> l = new ArrayList<>();
/* 126 */     TypePattern[] pats = this.arguments.getTypePatterns();
/* 127 */     for (TypePattern pat : pats) {
/* 128 */       if (pat instanceof BindingTypePattern) {
/* 129 */         l.add((BindingTypePattern)pat);
/*     */       }
/*     */     } 
/* 132 */     return l;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 136 */     s.writeByte(4);
/* 137 */     this.arguments.write(s);
/* 138 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 142 */     ArgsPointcut ret = new ArgsPointcut(TypePatternList.read(s, context));
/* 143 */     ret.readLocation(context, (DataInputStream)s);
/* 144 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 148 */     if (!(other instanceof ArgsPointcut)) {
/* 149 */       return false;
/*     */     }
/* 151 */     ArgsPointcut o = (ArgsPointcut)other;
/* 152 */     return o.arguments.equals(this.arguments);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 156 */     return this.arguments.hashCode();
/*     */   }
/*     */   
/*     */   public void resolveBindings(IScope scope, Bindings bindings) {
/* 160 */     this.arguments.resolveBindings(scope, bindings, true, true);
/* 161 */     if (this.arguments.ellipsisCount > 1) {
/* 162 */       scope.message(IMessage.ERROR, (IHasPosition)this, "uses more than one .. in args (compiler limitation)");
/*     */     }
/*     */   }
/*     */   
/*     */   public void postRead(ResolvedType enclosingType) {
/* 167 */     this.arguments.postRead(enclosingType);
/*     */   }
/*     */   
/*     */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 171 */     if (isDeclare(bindings.getEnclosingAdvice())) {
/*     */       
/* 173 */       inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("argsInDeclare"), bindings
/* 174 */           .getEnclosingAdvice().getSourceLocation(), null);
/* 175 */       return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */     } 
/* 177 */     TypePatternList args = this.arguments.resolveReferences(bindings);
/* 178 */     if (inAspect.crosscuttingMembers != null) {
/* 179 */       inAspect.crosscuttingMembers.exposeTypes(args.getExactTypes());
/*     */     }
/* 181 */     Pointcut ret = new ArgsPointcut(args);
/* 182 */     ret.copyLocationFrom(this);
/* 183 */     return ret;
/*     */   }
/*     */   private Test findResidueNoEllipsis(Shadow shadow, ExposedState state, TypePattern[] patterns) {
/*     */     Test test;
/* 187 */     ResolvedType[] argumentsToMatchAgainst = getArgumentsToMatchAgainst(shadow);
/* 188 */     int len = argumentsToMatchAgainst.length;
/*     */     
/* 190 */     if (patterns.length != len) {
/* 191 */       return (Test)Literal.FALSE;
/*     */     }
/*     */     
/* 194 */     Literal literal = Literal.TRUE;
/*     */     
/* 196 */     for (int i = 0; i < len; i++) {
/* 197 */       UnresolvedType argType = shadow.getGenericArgTypes()[i];
/* 198 */       TypePattern type = patterns[i];
/* 199 */       ResolvedType argRTX = shadow.getIWorld().resolve(argType, true);
/* 200 */       if (!(type instanceof BindingTypePattern)) {
/* 201 */         if (argRTX.isMissing()) {
/* 202 */           (shadow.getIWorld().getLint()).cantFindType.signal(new String[] { WeaverMessages.format("cftArgType", argType
/* 203 */                   .getName()) }shadow.getSourceLocation(), new ISourceLocation[] {
/* 204 */                 getSourceLocation()
/*     */               });
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 210 */         if (type.matchesInstanceof(argRTX).alwaysTrue()) {
/*     */           continue;
/*     */         }
/*     */       } 
/*     */       
/* 215 */       World world = shadow.getIWorld();
/* 216 */       ResolvedType typeToExpose = type.getExactType().resolve(world);
/* 217 */       if (typeToExpose.isParameterizedType()) {
/* 218 */         boolean inDoubt = (type.matchesInstanceof(argRTX) == FuzzyBoolean.MAYBE);
/* 219 */         if (inDoubt && (world.getLint()).uncheckedArgument.isEnabled()) {
/* 220 */           String uncheckedMatchWith = typeToExpose.getSimpleBaseName();
/* 221 */           if (argRTX.isParameterizedType() && argRTX.getRawType() == typeToExpose.getRawType()) {
/* 222 */             uncheckedMatchWith = argRTX.getSimpleName();
/*     */           }
/* 224 */           if (!isUncheckedArgumentWarningSuppressed()) {
/* 225 */             (world.getLint()).uncheckedArgument.signal(new String[] { typeToExpose.getSimpleName(), uncheckedMatchWith, typeToExpose
/* 226 */                   .getSimpleBaseName(), shadow.toResolvedString(world) }, getSourceLocation(), new ISourceLocation[] { shadow
/* 227 */                   .getSourceLocation() });
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 232 */       test = Test.makeAnd((Test)literal, exposeStateForVar(shadow.getArgVar(i), type, state, shadow.getIWorld()));
/*     */       continue;
/*     */     } 
/* 235 */     return test;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUncheckedArgumentWarningSuppressed() {
/* 245 */     return false;
/*     */   }
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 249 */     ResolvedType[] argsToMatch = getArgumentsToMatchAgainst(shadow);
/* 250 */     if (this.arguments.matches(argsToMatch, TypePattern.DYNAMIC).alwaysFalse()) {
/* 251 */       return (Test)Literal.FALSE;
/*     */     }
/* 253 */     int ellipsisCount = this.arguments.ellipsisCount;
/* 254 */     if (ellipsisCount == 0)
/* 255 */       return findResidueNoEllipsis(shadow, state, this.arguments.getTypePatterns()); 
/* 256 */     if (ellipsisCount == 1) {
/* 257 */       TypePattern[] patternsWithEllipsis = this.arguments.getTypePatterns();
/* 258 */       TypePattern[] patternsWithoutEllipsis = new TypePattern[argsToMatch.length];
/* 259 */       int lenWithEllipsis = patternsWithEllipsis.length;
/* 260 */       int lenWithoutEllipsis = patternsWithoutEllipsis.length;
/*     */       
/* 262 */       int indexWithEllipsis = 0;
/* 263 */       int indexWithoutEllipsis = 0;
/* 264 */       while (indexWithoutEllipsis < lenWithoutEllipsis) {
/* 265 */         TypePattern p = patternsWithEllipsis[indexWithEllipsis++];
/* 266 */         if (p == TypePattern.ELLIPSIS) {
/* 267 */           int newLenWithoutEllipsis = lenWithoutEllipsis - lenWithEllipsis - indexWithEllipsis;
/* 268 */           while (indexWithoutEllipsis < newLenWithoutEllipsis)
/* 269 */             patternsWithoutEllipsis[indexWithoutEllipsis++] = TypePattern.ANY; 
/*     */           continue;
/*     */         } 
/* 272 */         patternsWithoutEllipsis[indexWithoutEllipsis++] = p;
/*     */       } 
/*     */       
/* 275 */       return findResidueNoEllipsis(shadow, state, patternsWithoutEllipsis);
/*     */     } 
/* 277 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 282 */     return this.stringRepresentation;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 286 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 291 */     Object ret = accept(visitor, data);
/* 292 */     if (this.arguments != null)
/* 293 */       this.arguments.traverse(visitor, ret); 
/* 294 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ArgsPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */