/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import org.aspectj.weaver.IHasPosition;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormalBinding
/*    */   implements IHasPosition
/*    */ {
/*    */   private final UnresolvedType type;
/*    */   private final String name;
/*    */   private final int index;
/*    */   private final int start;
/*    */   private final int end;
/*    */   
/*    */   public FormalBinding(UnresolvedType type, String name, int index, int start, int end) {
/* 25 */     this.type = type;
/* 26 */     this.name = name;
/* 27 */     this.index = index;
/* 28 */     this.start = start;
/* 29 */     this.end = end;
/*    */   }
/*    */   
/*    */   public FormalBinding(UnresolvedType type, int index) {
/* 33 */     this(type, "unknown", index, 0, 0);
/*    */   }
/*    */   
/*    */   public FormalBinding(UnresolvedType type, String name, int index) {
/* 37 */     this(type, name, index, 0, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return this.type.toString() + ":" + this.index;
/*    */   }
/*    */   
/*    */   public int getEnd() {
/* 47 */     return this.end;
/*    */   }
/*    */   
/*    */   public int getStart() {
/* 51 */     return this.start;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 55 */     return this.index;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 59 */     return this.name;
/*    */   }
/*    */   
/*    */   public UnresolvedType getType() {
/* 63 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 68 */   public static final FormalBinding[] NONE = new FormalBinding[0];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class ImplicitFormalBinding
/*    */     extends FormalBinding
/*    */   {
/*    */     public ImplicitFormalBinding(UnresolvedType type, String name, int index) {
/* 78 */       super(type, name, index);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\FormalBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */