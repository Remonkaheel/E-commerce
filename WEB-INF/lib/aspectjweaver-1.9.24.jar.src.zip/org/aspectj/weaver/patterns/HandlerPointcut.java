/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   TypePattern exceptionType;
/*  39 */   private static final int MATCH_KINDS = Shadow.ExceptionHandler.bit;
/*     */   
/*     */   public HandlerPointcut(TypePattern exceptionType) {
/*  42 */     this.exceptionType = exceptionType;
/*  43 */     this.pointcutKind = 13;
/*     */   }
/*     */   
/*     */   public int couldMatchKinds() {
/*  47 */     return MATCH_KINDS;
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo type) {
/*  52 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*  56 */     if (shadow.getKind() != Shadow.ExceptionHandler) {
/*  57 */       return FuzzyBoolean.NO;
/*     */     }
/*     */     
/*  60 */     this.exceptionType.resolve(shadow.getIWorld());
/*     */ 
/*     */     
/*  63 */     return this.exceptionType.matches(shadow.getSignature().getParameterTypes()[0].resolve(shadow.getIWorld()), TypePattern.STATIC);
/*     */   }
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  67 */     HandlerPointcut ret = new HandlerPointcut(this.exceptionType.parameterizeWith(typeVariableMap, w));
/*  68 */     ret.copyLocationFrom(this);
/*  69 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  73 */     if (!(other instanceof HandlerPointcut)) {
/*  74 */       return false;
/*     */     }
/*  76 */     HandlerPointcut o = (HandlerPointcut)other;
/*  77 */     return o.exceptionType.equals(this.exceptionType);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  81 */     int result = 17;
/*  82 */     result = 37 * result + this.exceptionType.hashCode();
/*  83 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  87 */     StringBuilder buf = new StringBuilder();
/*  88 */     buf.append("handler(");
/*  89 */     buf.append(this.exceptionType.toString());
/*  90 */     buf.append(")");
/*  91 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  95 */     s.writeByte(13);
/*  96 */     this.exceptionType.write(s);
/*  97 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 101 */     HandlerPointcut ret = new HandlerPointcut(TypePattern.read(s, context));
/* 102 */     ret.readLocation(context, (DataInputStream)s);
/* 103 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveBindings(IScope scope, Bindings bindings) {
/* 111 */     this.exceptionType = this.exceptionType.resolveBindings(scope, bindings, false, false);
/* 112 */     boolean invalidParameterization = false;
/* 113 */     if (this.exceptionType.getTypeParameters().size() > 0) {
/* 114 */       invalidParameterization = true;
/*     */     }
/* 116 */     UnresolvedType exactType = this.exceptionType.getExactType();
/* 117 */     if (exactType != null && exactType.isParameterizedType()) {
/* 118 */       invalidParameterization = true;
/*     */     }
/* 120 */     if (invalidParameterization)
/*     */     {
/* 122 */       scope.message(MessageUtil.error(WeaverMessages.format("noParameterizedTypePatternInHandler"), 
/* 123 */             getSourceLocation()));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 129 */     return match(shadow).alwaysTrue() ? (Test)Literal.TRUE : (Test)Literal.FALSE;
/*     */   }
/*     */   
/*     */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 133 */     Pointcut ret = new HandlerPointcut(this.exceptionType);
/* 134 */     ret.copyLocationFrom(this);
/* 135 */     return ret;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 139 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 144 */     Object ret = accept(visitor, data);
/* 145 */     if (this.exceptionType != null)
/* 146 */       this.exceptionType.traverse(visitor, ret); 
/* 147 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\HandlerPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */