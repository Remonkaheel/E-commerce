/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPatternNodeVisitor
/*     */   implements PatternNodeVisitor
/*     */ {
/*     */   public Object visit(AnyTypePattern node, Object data) {
/*  23 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(NoTypePattern node, Object data) {
/*  27 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(EllipsisTypePattern node, Object data) {
/*  31 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AnyWithAnnotationTypePattern node, Object data) {
/*  35 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AnyAnnotationTypePattern node, Object data) {
/*  39 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(EllipsisAnnotationTypePattern node, Object data) {
/*  43 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AndAnnotationTypePattern node, Object data) {
/*  47 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AndPointcut node, Object data) {
/*  51 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AndTypePattern node, Object data) {
/*  55 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AnnotationPatternList node, Object data) {
/*  59 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(AnnotationPointcut node, Object data) {
/*  63 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ArgsAnnotationPointcut node, Object data) {
/*  67 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ArgsPointcut node, Object data) {
/*  71 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(BindingAnnotationTypePattern node, Object data) {
/*  75 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(BindingTypePattern node, Object data) {
/*  79 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(CflowPointcut node, Object data) {
/*  83 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ConcreteCflowPointcut node, Object data) {
/*  87 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(DeclareAnnotation node, Object data) {
/*  91 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(DeclareErrorOrWarning node, Object data) {
/*  95 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(DeclareParents node, Object data) {
/*  99 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(DeclarePrecedence node, Object data) {
/* 103 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(DeclareSoft node, Object data) {
/* 107 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ExactAnnotationTypePattern node, Object data) {
/* 111 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ExactTypePattern node, Object data) {
/* 115 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(HandlerPointcut node, Object data) {
/* 119 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(IfPointcut node, Object data) {
/* 123 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(KindedPointcut node, Object data) {
/* 127 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ModifiersPattern node, Object data) {
/* 131 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(NamePattern node, Object data) {
/* 135 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(NotAnnotationTypePattern node, Object data) {
/* 139 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(NotPointcut node, Object data) {
/* 143 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(NotTypePattern node, Object data) {
/* 147 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(OrAnnotationTypePattern node, Object data) {
/* 151 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(OrPointcut node, Object data) {
/* 155 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(OrTypePattern node, Object data) {
/* 159 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(PerCflow node, Object data) {
/* 163 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(PerFromSuper node, Object data) {
/* 167 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(PerObject node, Object data) {
/* 171 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(PerSingleton node, Object data) {
/* 175 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(PerTypeWithin node, Object data) {
/* 179 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(PatternNode node, Object data) {
/* 183 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ReferencePointcut node, Object data) {
/* 187 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(SignaturePattern node, Object data) {
/* 191 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ThisOrTargetAnnotationPointcut node, Object data) {
/* 195 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ThisOrTargetPointcut node, Object data) {
/* 199 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(ThrowsPattern node, Object data) {
/* 203 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(TypePatternList node, Object data) {
/* 207 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(WildAnnotationTypePattern node, Object data) {
/* 211 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(WildTypePattern node, Object data) {
/* 215 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(WithinAnnotationPointcut node, Object data) {
/* 219 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(WithinCodeAnnotationPointcut node, Object data) {
/* 223 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(WithinPointcut node, Object data) {
/* 227 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(WithincodePointcut node, Object data) {
/* 231 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(Pointcut.MatchesNothingPointcut node, Object data) {
/* 235 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(TypeVariablePattern node, Object data) {
/* 239 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(TypeVariablePatternList node, Object data) {
/* 243 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(HasMemberTypePattern node, Object data) {
/* 247 */     return node;
/*     */   }
/*     */   
/*     */   public Object visit(TypeCategoryTypePattern node, Object data) {
/* 251 */     return node;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AbstractPatternNodeVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */