/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnyTypePattern
/*     */   extends TypePattern
/*     */ {
/*     */   public AnyTypePattern() {
/*  29 */     super(false, false, new TypePatternList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean couldEverMatchSameTypesAs(TypePattern other) {
/*  39 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type) {
/*  47 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type, ResolvedType annotatedType) {
/*  52 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesInstanceof(ResolvedType type) {
/*  60 */     return FuzzyBoolean.YES;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesArray(UnresolvedType type) {
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  70 */     s.writeByte(5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesSubtypes(ResolvedType type) {
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStar() {
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  94 */     return "*";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  99 */     return obj instanceof AnyTypePattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     return 37;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 109 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map<String, UnresolvedType> arg0, World w) {
/* 114 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AnyTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */