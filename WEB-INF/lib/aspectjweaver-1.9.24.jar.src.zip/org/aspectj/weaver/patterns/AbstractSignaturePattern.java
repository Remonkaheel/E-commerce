/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.aspectj.weaver.BCException;
/*    */ import org.aspectj.weaver.CompressingDataOutputStream;
/*    */ import org.aspectj.weaver.ISourceContext;
/*    */ import org.aspectj.weaver.VersionedDataInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSignaturePattern
/*    */   implements ISignaturePattern
/*    */ {
/*    */   protected void writePlaceholderLocation(CompressingDataOutputStream s) throws IOException {
/* 30 */     s.writeInt(0);
/* 31 */     s.writeInt(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public static ISignaturePattern readCompoundSignaturePattern(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 36 */     byte key = s.readByte();
/* 37 */     switch (key) {
/*    */       case 1:
/* 39 */         return SignaturePattern.read(s, context);
/*    */       case 4:
/* 41 */         return AndSignaturePattern.readAndSignaturePattern(s, context);
/*    */       case 3:
/* 43 */         return OrSignaturePattern.readOrSignaturePattern(s, context);
/*    */       case 2:
/* 45 */         return NotSignaturePattern.readNotSignaturePattern(s, context);
/*    */     } 
/* 47 */     throw new BCException("unknown SignatureTypePattern kind: " + key);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void writeCompoundSignaturePattern(CompressingDataOutputStream s, ISignaturePattern sigPattern) throws IOException {
/* 53 */     if (sigPattern instanceof SignaturePattern) {
/* 54 */       s.writeByte(1);
/* 55 */       ((SignaturePattern)sigPattern).write(s);
/* 56 */     } else if (sigPattern instanceof AndSignaturePattern) {
/* 57 */       AndSignaturePattern andSignaturePattern = (AndSignaturePattern)sigPattern;
/* 58 */       s.writeByte(4);
/* 59 */       writeCompoundSignaturePattern(s, andSignaturePattern.getLeft());
/* 60 */       writeCompoundSignaturePattern(s, andSignaturePattern.getRight());
/* 61 */       s.writeInt(0);
/* 62 */       s.writeInt(0);
/* 63 */     } else if (sigPattern instanceof OrSignaturePattern) {
/* 64 */       OrSignaturePattern orSignaturePattern = (OrSignaturePattern)sigPattern;
/* 65 */       s.writeByte(3);
/* 66 */       writeCompoundSignaturePattern(s, orSignaturePattern.getLeft());
/* 67 */       writeCompoundSignaturePattern(s, orSignaturePattern.getRight());
/* 68 */       s.writeInt(0);
/* 69 */       s.writeInt(0);
/*    */     } else {
/*    */       
/* 72 */       NotSignaturePattern notSignaturePattern = (NotSignaturePattern)sigPattern;
/* 73 */       s.writeByte(2);
/* 74 */       writeCompoundSignaturePattern(s, notSignaturePattern.getNegated());
/* 75 */       s.writeInt(0);
/* 76 */       s.writeInt(0);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AbstractSignaturePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */