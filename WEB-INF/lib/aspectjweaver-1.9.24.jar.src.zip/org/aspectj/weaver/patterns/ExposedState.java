/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.ast.Expr;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExposedState
/*     */ {
/*  24 */   public static final boolean[] NO_ERRONEOUS_VARS = new boolean[0];
/*     */   
/*     */   public Var[] vars;
/*     */   private boolean[] erroneousVars;
/*     */   private Expr aspectInstance;
/*     */   private UnresolvedType[] expectedVarTypes;
/*     */   private ResolvedType concreteAspect;
/*     */   
/*     */   public ExposedState(int size) {
/*  33 */     if (size == 0) {
/*  34 */       this.vars = Var.NONE;
/*  35 */       this.erroneousVars = NO_ERRONEOUS_VARS;
/*     */     } else {
/*  37 */       this.vars = new Var[size];
/*  38 */       this.erroneousVars = new boolean[size];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExposedState(Member signature) {
/*  45 */     this((signature.getParameterTypes()).length);
/*  46 */     this.expectedVarTypes = new UnresolvedType[(signature.getParameterTypes()).length];
/*  47 */     if (this.expectedVarTypes.length > 0) {
/*  48 */       for (int i = 0; i < (signature.getParameterTypes()).length; i++) {
/*  49 */         this.expectedVarTypes[i] = signature.getParameterTypes()[i];
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFullySetUp() {
/*  56 */     for (Var var : this.vars) {
/*  57 */       if (var == null)
/*  58 */         return false; 
/*     */     } 
/*  60 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(int i, Var var) {
/*  65 */     if (this.expectedVarTypes != null) {
/*  66 */       ResolvedType expected = this.expectedVarTypes[i].resolve(var.getType().getWorld());
/*  67 */       if (!expected.equals(ResolvedType.OBJECT) && 
/*  68 */         !expected.isAssignableFrom(var.getType()) && 
/*  69 */         !var.getType().isCoerceableFrom(expected)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.vars[i] = var;
/*     */   }
/*     */   
/*     */   public Var get(int i) {
/*  81 */     return this.vars[i];
/*     */   }
/*     */   
/*     */   public int size() {
/*  85 */     return this.vars.length;
/*     */   }
/*     */   
/*     */   public Expr getAspectInstance() {
/*  89 */     return this.aspectInstance;
/*     */   }
/*     */   
/*     */   public void setAspectInstance(Expr aspectInstance) {
/*  93 */     this.aspectInstance = aspectInstance;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  97 */     return "ExposedState(#Vars=" + this.vars.length + ",Vars=" + Arrays.<Var>asList(this.vars) + ",AspectInstance=" + this.aspectInstance + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErroneousVar(int formalIndex) {
/* 103 */     this.erroneousVars[formalIndex] = true;
/*     */   }
/*     */   
/*     */   public boolean isErroneousVar(int formalIndex) {
/* 107 */     return this.erroneousVars[formalIndex];
/*     */   }
/*     */   
/*     */   public void setConcreteAspect(ResolvedType concreteAspect) {
/* 111 */     this.concreteAspect = concreteAspect;
/*     */   }
/*     */   
/*     */   public ResolvedType getConcreteAspect() {
/* 115 */     return this.concreteAspect;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ExposedState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */