/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EllipsisTypePattern
/*     */   extends TypePattern
/*     */ {
/*     */   public EllipsisTypePattern() {
/*  29 */     super(false, false, new TypePatternList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean couldEverMatchSameTypesAs(TypePattern other) {
/*  39 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type) {
/*  47 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type, ResolvedType annotatedType) {
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesInstanceof(ResolvedType type) {
/*  60 */     return FuzzyBoolean.NO;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesArray(UnresolvedType type) {
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  70 */     s.writeByte(4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEllipsis() {
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  80 */     return "..";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  90 */     return obj instanceof EllipsisTypePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 100 */     return 629;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 105 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map typeVariableMap, World w) {
/* 110 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\EllipsisTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */