/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingTypePattern
/*     */   extends ExactTypePattern
/*     */   implements BindingPattern
/*     */ {
/*     */   private int formalIndex;
/*     */   private String bindingName;
/*     */   
/*     */   public BindingTypePattern(UnresolvedType type, int index, boolean isVarArgs) {
/*  32 */     super(type, false, isVarArgs, (TypePatternList)null);
/*  33 */     this.formalIndex = index;
/*     */   }
/*     */   
/*     */   public BindingTypePattern(FormalBinding binding, boolean isVarArgs) {
/*  37 */     this(binding.getType(), binding.getIndex(), isVarArgs);
/*  38 */     this.bindingName = binding.getName();
/*     */   }
/*     */   
/*     */   public int getFormalIndex() {
/*  42 */     return this.formalIndex;
/*     */   }
/*     */   
/*     */   public String getBindingName() {
/*  46 */     return this.bindingName;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  50 */     if (!(other instanceof BindingTypePattern)) {
/*  51 */       return false;
/*     */     }
/*  53 */     BindingTypePattern o = (BindingTypePattern)other;
/*  54 */     if (this.includeSubtypes != o.includeSubtypes) {
/*  55 */       return false;
/*     */     }
/*  57 */     if (this.isVarArgs != o.isVarArgs) {
/*  58 */       return false;
/*     */     }
/*  60 */     return (o.type.equals(this.type) && o.formalIndex == this.formalIndex);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  64 */     int result = 17;
/*  65 */     result = 37 * result + super.hashCode();
/*  66 */     result = 37 * result + this.formalIndex;
/*  67 */     return result;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream out) throws IOException {
/*  71 */     out.writeByte(3);
/*  72 */     this.type.write(out);
/*  73 */     out.writeShort((short)this.formalIndex);
/*  74 */     out.writeBoolean(this.isVarArgs);
/*  75 */     writeLocation((DataOutputStream)out);
/*     */   }
/*     */   
/*     */   public static TypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  79 */     UnresolvedType type = UnresolvedType.read((DataInputStream)s);
/*  80 */     int index = s.readShort();
/*  81 */     boolean isVarargs = false;
/*  82 */     if (s.getMajorVersion() >= 2) {
/*  83 */       isVarargs = s.readBoolean();
/*     */     }
/*  85 */     TypePattern ret = new BindingTypePattern(type, index, isVarargs);
/*  86 */     ret.readLocation(context, (DataInputStream)s);
/*  87 */     return ret;
/*     */   }
/*     */   
/*     */   public TypePattern remapAdviceFormals(IntMap bindings) {
/*  91 */     if (!bindings.hasKey(this.formalIndex)) {
/*  92 */       return new ExactTypePattern(this.type, false, this.isVarArgs, null);
/*     */     }
/*  94 */     int newFormalIndex = bindings.get(this.formalIndex);
/*  95 */     return new BindingTypePattern(this.type, newFormalIndex, this.isVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 100 */     ExactTypePattern superParameterized = (ExactTypePattern)super.parameterizeWith(typeVariableMap, w);
/* 101 */     BindingTypePattern ret = new BindingTypePattern(superParameterized.getExactType(), this.formalIndex, this.isVarArgs);
/* 102 */     ret.copyLocationFrom(this);
/* 103 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return "BindingTypePattern(" + super.toString() + ", " + this.formalIndex + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\BindingTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */