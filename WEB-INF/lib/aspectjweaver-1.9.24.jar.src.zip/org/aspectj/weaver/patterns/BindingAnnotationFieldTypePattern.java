/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingAnnotationFieldTypePattern
/*     */   extends ExactAnnotationTypePattern
/*     */   implements BindingPattern
/*     */ {
/*     */   protected int formalIndex;
/*     */   UnresolvedType formalType;
/*     */   
/*     */   public BindingAnnotationFieldTypePattern(UnresolvedType formalType, int formalIndex, UnresolvedType theAnnotationType) {
/*  46 */     super(theAnnotationType, (Map<String, String>)null);
/*  47 */     this.formalIndex = formalIndex;
/*  48 */     this.formalType = formalType;
/*     */   }
/*     */   
/*     */   public void resolveBinding(World world) {
/*  52 */     if (this.resolved) {
/*     */       return;
/*     */     }
/*  55 */     this.resolved = true;
/*  56 */     this.formalType = (UnresolvedType)world.resolve(this.formalType);
/*  57 */     this.annotationType = (UnresolvedType)world.resolve(this.annotationType);
/*  58 */     ResolvedType annoType = (ResolvedType)this.annotationType;
/*  59 */     if (!annoType.isAnnotation()) {
/*     */       
/*  61 */       IMessage m = MessageUtil.error(WeaverMessages.format("referenceToNonAnnotationType", annoType.getName()), 
/*  62 */           getSourceLocation());
/*  63 */       world.getMessageHandler().handleMessage(m);
/*  64 */       this.resolved = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern parameterizeWith(Map typeVariableMap, World w) {
/*  70 */     throw new BCException("Parameterization not implemented for annotation field binding construct (compiler limitation)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFormalIndex() {
/*  92 */     return this.formalIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  97 */     if (!(obj instanceof BindingAnnotationFieldTypePattern)) {
/*  98 */       return false;
/*     */     }
/* 100 */     BindingAnnotationFieldTypePattern btp = (BindingAnnotationFieldTypePattern)obj;
/* 101 */     return (btp.formalIndex == this.formalIndex && this.annotationType.equals(btp.annotationType) && this.formalType
/* 102 */       .equals(btp.formalType));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 107 */     return this.annotationType.hashCode() * 37 + this.formalIndex * 37 + this.formalType.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern remapAdviceFormals(IntMap bindings) {
/* 112 */     if (!bindings.hasKey(this.formalIndex)) {
/* 113 */       throw new BCException("Annotation field binding reference must be bound (compiler limitation)");
/*     */     }
/*     */ 
/*     */     
/* 117 */     int newFormalIndex = bindings.get(this.formalIndex);
/* 118 */     BindingAnnotationFieldTypePattern baftp = new BindingAnnotationFieldTypePattern(this.formalType, newFormalIndex, this.annotationType);
/*     */     
/* 120 */     baftp.formalName = this.formalName;
/* 121 */     return baftp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 127 */     s.writeByte(11);
/* 128 */     this.formalType.write(s);
/* 129 */     s.writeShort((short)this.formalIndex);
/* 130 */     this.annotationType.write(s);
/* 131 */     s.writeUTF(this.formalName);
/* 132 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */ 
/*     */   
/*     */   public static AnnotationTypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 137 */     AnnotationTypePattern ret = new BindingAnnotationFieldTypePattern(UnresolvedType.read((DataInputStream)s), s.readShort(), UnresolvedType.read((DataInputStream)s));
/* 138 */     ret.readLocation(context, (DataInputStream)s);
/* 139 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public static AnnotationTypePattern read2(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 144 */     BindingAnnotationFieldTypePattern ret = new BindingAnnotationFieldTypePattern(UnresolvedType.read((DataInputStream)s), s.readShort(), UnresolvedType.read((DataInputStream)s));
/* 145 */     ret.formalName = s.readUTF();
/* 146 */     ret.readLocation(context, (DataInputStream)s);
/* 147 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated, ResolvedType[] parameterAnnotations) {
/* 160 */     if (annotated.hasAnnotation(this.annotationType) && 
/* 161 */       this.annotationType instanceof ReferenceType) {
/* 162 */       ReferenceType rt = (ReferenceType)this.annotationType;
/* 163 */       if (rt.getRetentionPolicy() != null && rt.getRetentionPolicy().equals("SOURCE")) {
/* 164 */         rt.getWorld()
/* 165 */           .getMessageHandler()
/* 166 */           .handleMessage(
/* 167 */             MessageUtil.warn(WeaverMessages.format("noMatchBecauseSourceRetention", this.annotationType, annotated), 
/* 168 */               getSourceLocation()));
/* 169 */         return FuzzyBoolean.NO;
/*     */       } 
/* 171 */       ResolvedMember[] methods = rt.getDeclaredMethods();
/* 172 */       boolean found = false;
/* 173 */       for (int i = 0; i < methods.length && !found; i++) {
/* 174 */         if (methods[i].getReturnType().equals(this.formalType)) {
/* 175 */           found = true;
/*     */         }
/*     */       } 
/* 178 */       return found ? FuzzyBoolean.YES : FuzzyBoolean.NO;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     return FuzzyBoolean.NO;
/*     */   }
/*     */   
/*     */   public UnresolvedType getFormalType() {
/* 195 */     return this.formalType;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\BindingAnnotationFieldTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */