/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.TypeVariableReference;
/*     */ import org.aspectj.weaver.TypeVariableReferenceType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExactTypePattern
/*     */   extends TypePattern
/*     */ {
/*     */   protected UnresolvedType type;
/*     */   protected transient ResolvedType resolvedType;
/*     */   public boolean checked = false;
/*     */   public boolean isVoid = false;
/*  43 */   public static final Map<String, Class<?>> primitiveTypesMap = new HashMap<>(); static {
/*  44 */     primitiveTypesMap.put("int", int.class);
/*  45 */     primitiveTypesMap.put("short", short.class);
/*  46 */     primitiveTypesMap.put("long", long.class);
/*  47 */     primitiveTypesMap.put("byte", byte.class);
/*  48 */     primitiveTypesMap.put("char", char.class);
/*  49 */     primitiveTypesMap.put("float", float.class);
/*  50 */     primitiveTypesMap.put("double", double.class);
/*     */   }
/*  52 */   public static final Map<String, Class<?>> boxedPrimitivesMap = new HashMap<>(); static {
/*  53 */     boxedPrimitivesMap.put("java.lang.Integer", Integer.class);
/*  54 */     boxedPrimitivesMap.put("java.lang.Short", Short.class);
/*  55 */     boxedPrimitivesMap.put("java.lang.Long", Long.class);
/*  56 */     boxedPrimitivesMap.put("java.lang.Byte", Byte.class);
/*  57 */     boxedPrimitivesMap.put("java.lang.Character", Character.class);
/*  58 */     boxedPrimitivesMap.put("java.lang.Float", Float.class);
/*  59 */     boxedPrimitivesMap.put("java.lang.Double", Double.class);
/*     */   }
/*  61 */   private static final Map<String, Class<?>> boxedTypesMap = new HashMap<>(); static {
/*  62 */     boxedTypesMap.put("int", Integer.class);
/*  63 */     boxedTypesMap.put("short", Short.class);
/*  64 */     boxedTypesMap.put("long", Long.class);
/*  65 */     boxedTypesMap.put("byte", Byte.class);
/*  66 */     boxedTypesMap.put("char", Character.class);
/*  67 */     boxedTypesMap.put("float", Float.class);
/*  68 */     boxedTypesMap.put("double", Double.class);
/*     */   }
/*     */   
/*     */   private static final byte EXACT_VERSION = 1;
/*     */   
/*     */   protected boolean matchesSubtypes(ResolvedType type) {
/*  74 */     boolean match = super.matchesSubtypes(type);
/*  75 */     if (match) {
/*  76 */       return match;
/*     */     }
/*     */     
/*  79 */     if (type.isArray() && this.type.isArray()) {
/*  80 */       ResolvedType componentType = type.getComponentType().resolve(type.getWorld());
/*  81 */       UnresolvedType newPatternType = this.type.getComponentType();
/*  82 */       ExactTypePattern etp = new ExactTypePattern(newPatternType, this.includeSubtypes, false, this.typeParameters);
/*  83 */       return etp.matchesSubtypes(componentType, type);
/*     */     } 
/*  85 */     return match;
/*     */   }
/*     */   
/*     */   public ExactTypePattern(UnresolvedType type, boolean includeSubtypes, boolean isVarArgs, TypePatternList typeParams) {
/*  89 */     super(includeSubtypes, isVarArgs, typeParams);
/*  90 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArray() {
/*  95 */     return this.type.isArray();
/*     */   }
/*     */   
/*     */   public int getDimensions() {
/*  99 */     return this.type.getDimensions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean couldEverMatchSameTypesAs(TypePattern other) {
/* 109 */     if (super.couldEverMatchSameTypesAs(other)) {
/* 110 */       return true;
/*     */     }
/*     */     
/* 113 */     UnresolvedType otherType = other.getExactType();
/* 114 */     if (!ResolvedType.isMissing(otherType)) {
/* 115 */       return this.type.equals(otherType);
/*     */     }
/* 117 */     if (other instanceof WildTypePattern) {
/* 118 */       WildTypePattern owtp = (WildTypePattern)other;
/* 119 */       String yourSimpleNamePrefix = owtp.getNamePatterns()[0].maybeGetSimpleName();
/* 120 */       if (yourSimpleNamePrefix != null) {
/* 121 */         return this.type.getName().startsWith(yourSimpleNamePrefix);
/*     */       }
/*     */     } 
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType matchType) {
/* 129 */     if (!matchesArray((UnresolvedType)matchType)) {
/* 130 */       return false;
/*     */     }
/* 132 */     boolean typeMatch = this.type.equals(matchType);
/* 133 */     if (!typeMatch && (matchType.isParameterizedType() || matchType.isGenericType())) {
/* 134 */       typeMatch = this.type.equals(matchType.getRawType());
/*     */     }
/* 136 */     if (!typeMatch && matchType.isTypeVariableReference()) {
/* 137 */       typeMatch = matchesTypeVariable((TypeVariableReferenceType)matchType);
/*     */     }
/* 139 */     if (!typeMatch) {
/* 140 */       return false;
/*     */     }
/* 142 */     this.annotationPattern.resolve(matchType.getWorld());
/* 143 */     boolean annMatch = false;
/* 144 */     if (matchType.temporaryAnnotationTypes != null) {
/* 145 */       annMatch = this.annotationPattern.matches((AnnotatedElement)matchType, matchType.temporaryAnnotationTypes).alwaysTrue();
/*     */     } else {
/* 147 */       annMatch = this.annotationPattern.matches((AnnotatedElement)matchType).alwaysTrue();
/*     */     } 
/* 149 */     return (typeMatch && annMatch);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean matchesTypeVariable(TypeVariableReferenceType matchType) {
/* 154 */     return this.type.equals(matchType.getTypeVariable().getFirstBound());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType matchType, ResolvedType annotatedType) {
/* 160 */     if (!matchesArray((UnresolvedType)matchType)) {
/* 161 */       return false;
/*     */     }
/* 163 */     boolean typeMatch = this.type.equals(matchType);
/* 164 */     if (!typeMatch && (matchType.isParameterizedType() || matchType.isGenericType())) {
/* 165 */       typeMatch = this.type.equals(matchType.getRawType());
/*     */     }
/* 167 */     if (!typeMatch && matchType.isTypeVariableReference()) {
/* 168 */       typeMatch = matchesTypeVariable((TypeVariableReferenceType)matchType);
/*     */     }
/* 170 */     this.annotationPattern.resolve(matchType.getWorld());
/* 171 */     boolean annMatch = false;
/* 172 */     if (annotatedType.temporaryAnnotationTypes != null) {
/* 173 */       annMatch = this.annotationPattern.matches((AnnotatedElement)annotatedType, annotatedType.temporaryAnnotationTypes).alwaysTrue();
/*     */     } else {
/* 175 */       annMatch = this.annotationPattern.matches((AnnotatedElement)annotatedType).alwaysTrue();
/*     */     } 
/* 177 */     return (typeMatch && annMatch);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesArray(UnresolvedType type) {
/* 182 */     return (type.getDimensions() == getDimensions());
/*     */   }
/*     */   
/*     */   public UnresolvedType getType() {
/* 186 */     return this.type;
/*     */   }
/*     */   
/*     */   public ResolvedType getResolvedExactType(World world) {
/* 190 */     if (this.resolvedType == null) {
/* 191 */       this.resolvedType = world.resolve(this.type);
/*     */     }
/* 193 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVoid() {
/* 198 */     if (!this.checked) {
/* 199 */       this.isVoid = this.type.getSignature().equals("V");
/* 200 */       this.checked = true;
/*     */     } 
/* 202 */     return this.isVoid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesInstanceof(ResolvedType matchType) {
/* 209 */     this.annotationPattern.resolve(matchType.getWorld());
/* 210 */     if (this.type.equals(ResolvedType.OBJECT)) {
/* 211 */       return FuzzyBoolean.YES.and(this.annotationPattern.matches((AnnotatedElement)matchType));
/*     */     }
/*     */     
/* 214 */     ResolvedType resolvedType = this.type.resolve(matchType.getWorld());
/* 215 */     if (resolvedType.isAssignableFrom(matchType)) {
/* 216 */       return FuzzyBoolean.YES.and(this.annotationPattern.matches((AnnotatedElement)matchType));
/*     */     }
/*     */ 
/*     */     
/* 220 */     if (this.type.isPrimitiveType()) {
/* 221 */       return FuzzyBoolean.NO;
/*     */     }
/* 223 */     return matchType.isCoerceableFrom(this.type.resolve(matchType.getWorld())) ? FuzzyBoolean.MAYBE : FuzzyBoolean.NO;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 229 */     if (!(other instanceof ExactTypePattern)) {
/* 230 */       return false;
/*     */     }
/* 232 */     if (other instanceof BindingTypePattern) {
/* 233 */       return false;
/*     */     }
/* 235 */     ExactTypePattern o = (ExactTypePattern)other;
/* 236 */     if (this.includeSubtypes != o.includeSubtypes) {
/* 237 */       return false;
/*     */     }
/* 239 */     if (this.isVarArgs != o.isVarArgs) {
/* 240 */       return false;
/*     */     }
/* 242 */     if (!this.typeParameters.equals(o.typeParameters)) {
/* 243 */       return false;
/*     */     }
/* 245 */     return (o.type.equals(this.type) && o.annotationPattern.equals(this.annotationPattern));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 250 */     int result = 17;
/* 251 */     result = 37 * result + this.type.hashCode();
/* 252 */     result = 37 * result + Boolean.valueOf(this.includeSubtypes).hashCode();
/* 253 */     result = 37 * result + Boolean.valueOf(this.isVarArgs).hashCode();
/* 254 */     result = 37 * result + this.typeParameters.hashCode();
/* 255 */     result = 37 * result + this.annotationPattern.hashCode();
/* 256 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream out) throws IOException {
/* 263 */     out.writeByte(2);
/* 264 */     out.writeByte(1);
/* 265 */     out.writeCompressedSignature(this.type.getSignature());
/* 266 */     out.writeBoolean(this.includeSubtypes);
/* 267 */     out.writeBoolean(this.isVarArgs);
/* 268 */     this.annotationPattern.write(out);
/* 269 */     this.typeParameters.write(out);
/* 270 */     writeLocation((DataOutputStream)out);
/*     */   }
/*     */   
/*     */   public static TypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 274 */     if (s.getMajorVersion() >= 2) {
/* 275 */       return readTypePattern150(s, context);
/*     */     }
/* 277 */     return readTypePatternOldStyle((DataInputStream)s, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public static TypePattern readTypePattern150(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 282 */     byte version = s.readByte();
/* 283 */     if (version > 1) {
/* 284 */       throw new BCException("ExactTypePattern was written by a more recent version of AspectJ");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 289 */     TypePattern ret = new ExactTypePattern(s.isAtLeast169() ? s.readSignatureAsUnresolvedType() : UnresolvedType.read((DataInputStream)s), s.readBoolean(), s.readBoolean(), null);
/*     */ 
/*     */     
/* 292 */     ret.setAnnotationTypePattern(AnnotationTypePattern.read(s, context));
/* 293 */     ret.setTypeParameters(TypePatternList.read(s, context));
/* 294 */     ret.readLocation(context, (DataInputStream)s);
/* 295 */     return ret;
/*     */   }
/*     */   
/*     */   public static TypePattern readTypePatternOldStyle(DataInputStream s, ISourceContext context) throws IOException {
/* 299 */     TypePattern ret = new ExactTypePattern(UnresolvedType.read(s), s.readBoolean(), false, null);
/* 300 */     ret.readLocation(context, s);
/* 301 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 306 */     StringBuilder buff = new StringBuilder();
/* 307 */     if (this.annotationPattern != AnnotationTypePattern.ANY) {
/* 308 */       buff.append('(');
/* 309 */       buff.append(this.annotationPattern.toString());
/* 310 */       buff.append(' ');
/*     */     } 
/* 312 */     String typeString = this.type.toString();
/* 313 */     if (this.isVarArgs) {
/* 314 */       typeString = typeString.substring(0, typeString.lastIndexOf('['));
/*     */     }
/* 316 */     buff.append(typeString);
/* 317 */     if (this.includeSubtypes) {
/* 318 */       buff.append('+');
/*     */     }
/* 320 */     if (this.isVarArgs) {
/* 321 */       buff.append("...");
/*     */     }
/* 323 */     if (this.annotationPattern != AnnotationTypePattern.ANY) {
/* 324 */       buff.append(')');
/*     */     }
/* 326 */     return buff.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding, boolean requireExactType) {
/* 331 */     throw new BCException("trying to re-resolve");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 339 */     UnresolvedType newType = this.type;
/* 340 */     if (this.type.isTypeVariableReference()) {
/* 341 */       TypeVariableReference t = (TypeVariableReference)this.type;
/* 342 */       String key = t.getTypeVariable().getName();
/* 343 */       if (typeVariableMap.containsKey(key)) {
/* 344 */         newType = typeVariableMap.get(key);
/*     */       }
/* 346 */     } else if (this.type.isParameterizedType()) {
/* 347 */       newType = w.resolve(this.type).parameterize(typeVariableMap);
/*     */     } 
/* 349 */     ExactTypePattern ret = new ExactTypePattern(newType, this.includeSubtypes, this.isVarArgs, this.typeParameters);
/* 350 */     ret.annotationPattern = this.annotationPattern.parameterizeWith(typeVariableMap, w);
/* 351 */     ret.copyLocationFrom(this);
/* 352 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 357 */     return visitor.visit(this, data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ExactTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */