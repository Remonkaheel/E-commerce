package org.aspectj.weaver.patterns;

import java.util.List;
import java.util.Map;
import org.aspectj.weaver.Member;
import org.aspectj.weaver.ResolvedType;
import org.aspectj.weaver.UnresolvedType;
import org.aspectj.weaver.World;

public interface ISignaturePattern {
  public static final byte PATTERN = 1;
  
  public static final byte NOT = 2;
  
  public static final byte OR = 3;
  
  public static final byte AND = 4;
  
  boolean matches(Member paramMember, World paramWorld, boolean paramBoolean);
  
  ISignaturePattern parameterizeWith(Map<String, UnresolvedType> paramMap, World paramWorld);
  
  ISignaturePattern resolveBindings(IScope paramIScope, Bindings paramBindings);
  
  List<ExactTypePattern> getExactDeclaringTypes();
  
  boolean isMatchOnAnyName();
  
  boolean couldEverMatch(ResolvedType paramResolvedType);
  
  boolean isStarAnnotation();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ISignaturePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */