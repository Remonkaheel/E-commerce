/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndTypePattern
/*     */   extends TypePattern
/*     */ {
/*     */   private TypePattern left;
/*     */   private TypePattern right;
/*     */   
/*     */   public AndTypePattern(TypePattern left, TypePattern right) {
/*  39 */     super(false, false);
/*  40 */     this.left = left;
/*  41 */     this.right = right;
/*  42 */     setLocation(left.getSourceContext(), left.getStart(), right.getEnd());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean couldEverMatchSameTypesAs(TypePattern other) {
/*  47 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesInstanceof(ResolvedType type) {
/*  52 */     return this.left.matchesInstanceof(type).and(this.right.matchesInstanceof(type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type) {
/*  58 */     return (this.left.matchesExactly(type) && this.right.matchesExactly(type));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type, ResolvedType annotatedType) {
/*  63 */     return (this.left.matchesExactly(type, annotatedType) && this.right.matchesExactly(type, annotatedType));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matchesStatically(ResolvedType type) {
/*  68 */     return (this.left.matchesStatically(type) && this.right.matchesStatically(type));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesArray(UnresolvedType type) {
/*  73 */     return (this.left.matchesArray(type) && this.right.matchesArray(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIsVarArgs(boolean isVarArgs) {
/*  78 */     this.isVarArgs = isVarArgs;
/*  79 */     this.left.setIsVarArgs(isVarArgs);
/*  80 */     this.right.setIsVarArgs(isVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnnotationTypePattern(AnnotationTypePattern annPatt) {
/*  85 */     if (annPatt == AnnotationTypePattern.ANY) {
/*     */       return;
/*     */     }
/*  88 */     if (this.left.annotationPattern == AnnotationTypePattern.ANY) {
/*  89 */       this.left.setAnnotationTypePattern(annPatt);
/*     */     } else {
/*  91 */       this.left.setAnnotationTypePattern(new AndAnnotationTypePattern(this.left.annotationPattern, annPatt));
/*     */     } 
/*  93 */     if (this.right.annotationPattern == AnnotationTypePattern.ANY) {
/*  94 */       this.right.setAnnotationTypePattern(annPatt);
/*     */     } else {
/*  96 */       this.right.setAnnotationTypePattern(new AndAnnotationTypePattern(this.right.annotationPattern, annPatt));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 102 */     s.writeByte(8);
/* 103 */     this.left.write(s);
/* 104 */     this.right.write(s);
/* 105 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static TypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 109 */     AndTypePattern ret = new AndTypePattern(TypePattern.read(s, context), TypePattern.read(s, context));
/* 110 */     ret.readLocation(context, (DataInputStream)s);
/* 111 */     if (ret.left.isVarArgs && ret.right.isVarArgs) {
/* 112 */       ret.isVarArgs = true;
/*     */     }
/* 114 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding, boolean requireExactType) {
/* 119 */     if (requireExactType) {
/* 120 */       return notExactType(scope);
/*     */     }
/* 122 */     this.left = this.left.resolveBindings(scope, bindings, false, false);
/* 123 */     this.right = this.right.resolveBindings(scope, bindings, false, false);
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 129 */     TypePattern newLeft = this.left.parameterizeWith(typeVariableMap, w);
/* 130 */     TypePattern newRight = this.right.parameterizeWith(typeVariableMap, w);
/* 131 */     AndTypePattern ret = new AndTypePattern(newLeft, newRight);
/* 132 */     ret.copyLocationFrom(this);
/* 133 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     StringBuilder buff = new StringBuilder();
/* 139 */     if (this.annotationPattern != AnnotationTypePattern.ANY) {
/* 140 */       buff.append('(');
/* 141 */       buff.append(this.annotationPattern.toString());
/* 142 */       buff.append(' ');
/*     */     } 
/* 144 */     buff.append('(');
/* 145 */     buff.append(this.left.toString());
/* 146 */     buff.append(" && ");
/* 147 */     buff.append(this.right.toString());
/* 148 */     buff.append(')');
/* 149 */     if (this.annotationPattern != AnnotationTypePattern.ANY) {
/* 150 */       buff.append(')');
/*     */     }
/* 152 */     return buff.toString();
/*     */   }
/*     */   
/*     */   public TypePattern getLeft() {
/* 156 */     return this.left;
/*     */   }
/*     */   
/*     */   public TypePattern getRight() {
/* 160 */     return this.right;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 165 */     if (!(obj instanceof AndTypePattern)) {
/* 166 */       return false;
/*     */     }
/* 168 */     AndTypePattern atp = (AndTypePattern)obj;
/* 169 */     return (this.left.equals(atp.left) && this.right.equals(atp.right));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStarAnnotation() {
/* 174 */     return (this.left.isStarAnnotation() && this.right.isStarAnnotation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 184 */     int ret = 17;
/* 185 */     ret += 37 * this.left.hashCode();
/* 186 */     ret += 37 * this.right.hashCode();
/* 187 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 192 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 197 */     Object ret = accept(visitor, data);
/* 198 */     if (this.left != null)
/* 199 */       this.left.traverse(visitor, ret); 
/* 200 */     if (this.right != null)
/* 201 */       this.right.traverse(visitor, ret); 
/* 202 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AndTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */