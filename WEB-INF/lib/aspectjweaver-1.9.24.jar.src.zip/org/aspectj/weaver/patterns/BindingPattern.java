package org.aspectj.weaver.patterns;

import org.aspectj.weaver.IHasPosition;

public interface BindingPattern extends IHasPosition {
  int getFormalIndex();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\BindingPattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */