/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   Pointcut left;
/*     */   Pointcut right;
/*     */   private int couldMatchKinds;
/*     */   
/*     */   public AndPointcut(Pointcut left, Pointcut right) {
/*  36 */     this.left = left;
/*  37 */     this.right = right;
/*  38 */     this.pointcutKind = 5;
/*  39 */     setLocation(left.getSourceContext(), left.getStart(), right.getEnd());
/*  40 */     this.couldMatchKinds = left.couldMatchKinds() & right.couldMatchKinds();
/*     */   }
/*     */   
/*     */   public int couldMatchKinds() {
/*  44 */     return this.couldMatchKinds;
/*     */   }
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo type) {
/*  48 */     FuzzyBoolean leftMatch = this.left.fastMatch(type);
/*  49 */     if (leftMatch.alwaysFalse()) {
/*  50 */       return leftMatch;
/*     */     }
/*  52 */     return leftMatch.and(this.right.fastMatch(type));
/*     */   }
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*  56 */     FuzzyBoolean leftMatch = this.left.match(shadow);
/*  57 */     if (leftMatch.alwaysFalse()) {
/*  58 */       return leftMatch;
/*     */     }
/*  60 */     return leftMatch.and(this.right.match(shadow));
/*     */   }
/*     */   
/*     */   public String toString() {
/*  64 */     return "(" + this.left.toString() + " && " + this.right.toString() + ")";
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  68 */     if (!(other instanceof AndPointcut)) {
/*  69 */       return false;
/*     */     }
/*  71 */     AndPointcut o = (AndPointcut)other;
/*  72 */     return (o.left.equals(this.left) && o.right.equals(this.right));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  76 */     int result = 19;
/*  77 */     result = 37 * result + this.left.hashCode();
/*  78 */     result = 37 * result + this.right.hashCode();
/*  79 */     return result;
/*     */   }
/*     */   
/*     */   public void resolveBindings(IScope scope, Bindings bindings) {
/*  83 */     this.left.resolveBindings(scope, bindings);
/*  84 */     this.right.resolveBindings(scope, bindings);
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  88 */     s.writeByte(5);
/*  89 */     this.left.write(s);
/*  90 */     this.right.write(s);
/*  91 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  95 */     AndPointcut ret = new AndPointcut(Pointcut.read(s, context), Pointcut.read(s, context));
/*  96 */     ret.readLocation(context, (DataInputStream)s);
/*  97 */     return ret;
/*     */   }
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 101 */     return Test.makeAnd(this.left.findResidue(shadow, state), this.right.findResidue(shadow, state));
/*     */   }
/*     */   
/*     */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 105 */     AndPointcut ret = new AndPointcut(this.left.concretize(inAspect, declaringType, bindings), this.right.concretize(inAspect, declaringType, bindings));
/*     */     
/* 107 */     ret.copyLocationFrom(this);
/* 108 */     ret.m_ignoreUnboundBindingForNames = this.m_ignoreUnboundBindingForNames;
/* 109 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 114 */     AndPointcut ret = new AndPointcut(this.left.parameterizeWith(typeVariableMap, w), this.right.parameterizeWith(typeVariableMap, w));
/* 115 */     ret.copyLocationFrom(this);
/* 116 */     ret.m_ignoreUnboundBindingForNames = this.m_ignoreUnboundBindingForNames;
/* 117 */     return ret;
/*     */   }
/*     */   
/*     */   public Pointcut getLeft() {
/* 121 */     return this.left;
/*     */   }
/*     */   
/*     */   public Pointcut getRight() {
/* 125 */     return this.right;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 129 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 133 */     Object ret = accept(visitor, data);
/* 134 */     if (this.left != null)
/* 135 */       this.left.traverse(visitor, ret); 
/* 136 */     if (this.right != null)
/* 137 */       this.right.traverse(visitor, ret); 
/* 138 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AndPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */