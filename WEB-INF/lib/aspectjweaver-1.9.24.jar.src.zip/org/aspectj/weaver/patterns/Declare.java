/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.aspectj.weaver.ISourceContext;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ import org.aspectj.weaver.VersionedDataInputStream;
/*    */ import org.aspectj.weaver.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Declare
/*    */   extends PatternNode
/*    */ {
/*    */   public static final byte ERROR_OR_WARNING = 1;
/*    */   public static final byte PARENTS = 2;
/*    */   public static final byte SOFT = 3;
/*    */   public static final byte DOMINATES = 4;
/*    */   public static final byte ANNOTATION = 5;
/*    */   public static final byte PARENTSMIXIN = 6;
/*    */   public static final byte TYPE_ERROR_OR_WARNING = 7;
/*    */   private ResolvedType declaringType;
/*    */   
/*    */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 37 */     byte kind = s.readByte();
/* 38 */     switch (kind) {
/*    */       case 1:
/* 40 */         return DeclareErrorOrWarning.read(s, context);
/*    */       case 4:
/* 42 */         return DeclarePrecedence.read(s, context);
/*    */       case 2:
/* 44 */         return DeclareParents.read(s, context);
/*    */       case 3:
/* 46 */         return DeclareSoft.read(s, context);
/*    */       case 5:
/* 48 */         return DeclareAnnotation.read(s, context);
/*    */       case 6:
/* 50 */         return DeclareParentsMixin.read(s, context);
/*    */       case 7:
/* 52 */         return DeclareTypeErrorOrWarning.read(s, context);
/*    */     } 
/* 54 */     throw new RuntimeException("unimplemented");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void resolve(IScope paramIScope);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract Declare parameterizeWith(Map<String, UnresolvedType> paramMap, World paramWorld);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean isAdviceLike();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract String getNameSuffix();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDeclaringType(ResolvedType aType) {
/* 83 */     this.declaringType = aType;
/*    */   }
/*    */   
/*    */   public ResolvedType getDeclaringType() {
/* 87 */     return this.declaringType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\Declare.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */