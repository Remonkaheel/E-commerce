/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.AnnotationAJ;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.IHasPosition;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.TypeVariableReference;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExactAnnotationTypePattern
/*     */   extends AnnotationTypePattern
/*     */ {
/*     */   protected UnresolvedType annotationType;
/*     */   protected String formalName;
/*     */   protected boolean resolved = false;
/*     */   protected boolean bindingPattern = false;
/*     */   private Map<String, String> annotationValues;
/*     */   
/*     */   public ExactAnnotationTypePattern(UnresolvedType annotationType, Map<String, String> annotationValues) {
/*  49 */     this.annotationType = annotationType;
/*  50 */     this.annotationValues = annotationValues;
/*  51 */     this.resolved = annotationType instanceof ResolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   private ExactAnnotationTypePattern(UnresolvedType annotationType) {
/*  56 */     this.annotationType = annotationType;
/*  57 */     this.resolved = annotationType instanceof ResolvedType;
/*     */   }
/*     */   
/*     */   protected ExactAnnotationTypePattern(String formalName) {
/*  61 */     this.formalName = formalName;
/*  62 */     this.resolved = false;
/*  63 */     this.bindingPattern = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolvedType getResolvedAnnotationType() {
/*  68 */     if (!this.resolved) {
/*  69 */       throw new IllegalStateException("I need to be resolved first!");
/*     */     }
/*  71 */     return (ResolvedType)this.annotationType;
/*     */   }
/*     */   
/*     */   public UnresolvedType getAnnotationType() {
/*  75 */     return this.annotationType;
/*     */   }
/*     */   
/*     */   public Map<String, String> getAnnotationValues() {
/*  79 */     return this.annotationValues;
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatches(AnnotatedElement annotated) {
/*  84 */     if (annotated.hasAnnotation(this.annotationType) && this.annotationValues == null) {
/*  85 */       return FuzzyBoolean.YES;
/*     */     }
/*     */ 
/*     */     
/*  89 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated) {
/*  95 */     return matches(annotated, (ResolvedType[])null);
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated, ResolvedType[] parameterAnnotations) {
/* 100 */     if (!isForParameterAnnotationMatch()) {
/* 101 */       boolean checkSupers = false;
/* 102 */       if (getResolvedAnnotationType().isInheritedAnnotation() && 
/* 103 */         annotated instanceof ResolvedType) {
/* 104 */         checkSupers = true;
/*     */       }
/*     */ 
/*     */       
/* 108 */       if (annotated.hasAnnotation(this.annotationType)) {
/* 109 */         if (this.annotationType instanceof ReferenceType) {
/* 110 */           ReferenceType rt = (ReferenceType)this.annotationType;
/* 111 */           if (rt.getRetentionPolicy() != null && rt.getRetentionPolicy().equals("SOURCE")) {
/* 112 */             rt.getWorld()
/* 113 */               .getMessageHandler()
/* 114 */               .handleMessage(
/* 115 */                 MessageUtil.warn(WeaverMessages.format("noMatchBecauseSourceRetention", this.annotationType, annotated), 
/* 116 */                   getSourceLocation()));
/* 117 */             return FuzzyBoolean.NO;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 122 */         if (this.annotationValues != null) {
/* 123 */           AnnotationAJ theAnnotation = annotated.getAnnotationOfType(this.annotationType);
/*     */ 
/*     */           
/* 126 */           Set<String> keys = this.annotationValues.keySet();
/* 127 */           for (String k : keys) {
/* 128 */             boolean notEqual = false;
/* 129 */             String v = this.annotationValues.get(k);
/*     */ 
/*     */             
/* 132 */             if (k.endsWith("!")) {
/* 133 */               notEqual = true;
/* 134 */               k = k.substring(0, k.length() - 1);
/*     */             } 
/* 136 */             if (theAnnotation.hasNamedValue(k)) {
/*     */ 
/*     */               
/* 139 */               if (notEqual) {
/* 140 */                 if (theAnnotation.hasNameValuePair(k, v))
/* 141 */                   return FuzzyBoolean.NO; 
/*     */                 continue;
/*     */               } 
/* 144 */               if (!theAnnotation.hasNameValuePair(k, v)) {
/* 145 */                 return FuzzyBoolean.NO;
/*     */               }
/*     */               
/*     */               continue;
/*     */             } 
/* 150 */             ResolvedMember[] ms = ((ResolvedType)this.annotationType).getDeclaredMethods();
/* 151 */             boolean foundMatch = false;
/* 152 */             for (int i = 0; i < ms.length && !foundMatch; i++) {
/* 153 */               if (ms[i].isAbstract() && (ms[i].getParameterTypes()).length == 0 && ms[i].getName().equals(k)) {
/*     */                 
/* 155 */                 String s = ms[i].getAnnotationDefaultValue();
/* 156 */                 if (s != null && s.equals(v)) {
/* 157 */                   foundMatch = true;
/*     */                 }
/*     */               } 
/*     */             } 
/* 161 */             if (notEqual) {
/* 162 */               if (foundMatch)
/* 163 */                 return FuzzyBoolean.NO; 
/*     */               continue;
/*     */             } 
/* 166 */             if (!foundMatch) {
/* 167 */               return FuzzyBoolean.NO;
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 173 */         return FuzzyBoolean.YES;
/* 174 */       }  if (checkSupers) {
/* 175 */         ResolvedType toMatchAgainst = ((ResolvedType)annotated).getSuperclass();
/* 176 */         while (toMatchAgainst != null) {
/* 177 */           if (toMatchAgainst.hasAnnotation(this.annotationType)) {
/*     */             
/* 179 */             if (this.annotationValues != null) {
/* 180 */               AnnotationAJ theAnnotation = toMatchAgainst.getAnnotationOfType(this.annotationType);
/*     */ 
/*     */               
/* 183 */               Set<String> keys = this.annotationValues.keySet();
/* 184 */               for (String k : keys) {
/* 185 */                 String v = this.annotationValues.get(k);
/* 186 */                 if (theAnnotation.hasNamedValue(k)) {
/*     */ 
/*     */                   
/* 189 */                   if (!theAnnotation.hasNameValuePair(k, v)) {
/* 190 */                     return FuzzyBoolean.NO;
/*     */                   }
/*     */                   continue;
/*     */                 } 
/* 194 */                 ResolvedMember[] ms = ((ResolvedType)this.annotationType).getDeclaredMethods();
/* 195 */                 boolean foundMatch = false;
/* 196 */                 for (int i = 0; i < ms.length && !foundMatch; i++) {
/* 197 */                   if (ms[i].isAbstract() && (ms[i].getParameterTypes()).length == 0 && ms[i]
/* 198 */                     .getName().equals(k)) {
/*     */                     
/* 200 */                     String s = ms[i].getAnnotationDefaultValue();
/* 201 */                     if (s != null && s.equals(v)) {
/* 202 */                       foundMatch = true;
/*     */                     }
/*     */                   } 
/*     */                 } 
/* 206 */                 if (!foundMatch) {
/* 207 */                   return FuzzyBoolean.NO;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */             
/* 212 */             return FuzzyBoolean.YES;
/*     */           } 
/* 214 */           toMatchAgainst = toMatchAgainst.getSuperclass();
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 219 */       if (parameterAnnotations == null) {
/* 220 */         return FuzzyBoolean.NO;
/*     */       }
/* 222 */       for (ResolvedType parameterAnnotation : parameterAnnotations) {
/* 223 */         if (this.annotationType.equals(parameterAnnotation)) {
/*     */           
/* 225 */           if (this.annotationValues != null) {
/* 226 */             parameterAnnotation
/* 227 */               .getWorld()
/* 228 */               .getMessageHandler()
/* 229 */               .handleMessage(
/*     */                 
/* 231 */                 MessageUtil.error("Compiler limitation: annotation value matching for parameter annotations not yet supported"));
/* 232 */             return FuzzyBoolean.NO;
/*     */           } 
/* 234 */           return FuzzyBoolean.YES;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 239 */     return FuzzyBoolean.NO;
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesRuntimeType(AnnotatedElement annotated) {
/* 244 */     if (getResolvedAnnotationType().isInheritedAnnotation())
/*     */     {
/* 246 */       if (matches(annotated).alwaysTrue()) {
/* 247 */         return FuzzyBoolean.YES;
/*     */       }
/*     */     }
/*     */     
/* 251 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(World world) {
/* 256 */     if (!this.resolved) {
/* 257 */       this.annotationType = (UnresolvedType)this.annotationType.resolve(world);
/* 258 */       this.resolved = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding) {
/* 270 */     if (this.resolved) {
/* 271 */       return this;
/*     */     }
/* 273 */     this.resolved = true;
/* 274 */     String simpleName = maybeGetSimpleName();
/* 275 */     if (simpleName != null) {
/* 276 */       FormalBinding formalBinding = scope.lookupFormal(simpleName);
/* 277 */       if (formalBinding != null) {
/* 278 */         if (bindings == null) {
/* 279 */           scope.message(IMessage.ERROR, (IHasPosition)this, "negation doesn't allow binding");
/* 280 */           return this;
/*     */         } 
/* 282 */         if (!allowBinding) {
/* 283 */           scope.message(IMessage.ERROR, (IHasPosition)this, "name binding only allowed in @pcds, args, this, and target");
/* 284 */           return this;
/*     */         } 
/* 286 */         this.formalName = simpleName;
/* 287 */         this.bindingPattern = true;
/* 288 */         verifyIsAnnotationType(formalBinding.getType().resolve(scope.getWorld()), scope);
/* 289 */         BindingAnnotationTypePattern binding = new BindingAnnotationTypePattern(formalBinding);
/* 290 */         binding.copyLocationFrom(this);
/* 291 */         bindings.register(binding, scope);
/* 292 */         binding.resolveBinding(scope.getWorld());
/* 293 */         if (isForParameterAnnotationMatch()) {
/* 294 */           binding.setForParameterAnnotationMatch();
/*     */         }
/*     */         
/* 297 */         return binding;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 302 */     String cleanname = this.annotationType.getName();
/* 303 */     this.annotationType = (UnresolvedType)scope.getWorld().resolve(this.annotationType, true);
/*     */ 
/*     */     
/* 306 */     if (ResolvedType.isMissing(this.annotationType)) {
/* 307 */       UnresolvedType type = null;
/* 308 */       while (ResolvedType.isMissing(type = scope.lookupType(cleanname, (IHasPosition)this))) {
/* 309 */         int lastDot = cleanname.lastIndexOf('.');
/* 310 */         if (lastDot == -1) {
/*     */           break;
/*     */         }
/* 313 */         cleanname = cleanname.substring(0, lastDot) + "$" + cleanname.substring(lastDot + 1);
/*     */       } 
/* 315 */       this.annotationType = (UnresolvedType)scope.getWorld().resolve(type, true);
/*     */     } 
/*     */     
/* 318 */     verifyIsAnnotationType((ResolvedType)this.annotationType, scope);
/* 319 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 324 */     UnresolvedType newAnnotationType = this.annotationType;
/* 325 */     if (this.annotationType.isTypeVariableReference()) {
/* 326 */       TypeVariableReference t = (TypeVariableReference)this.annotationType;
/* 327 */       String key = t.getTypeVariable().getName();
/* 328 */       if (typeVariableMap.containsKey(key)) {
/* 329 */         newAnnotationType = typeVariableMap.get(key);
/*     */       }
/* 331 */     } else if (this.annotationType.isParameterizedType()) {
/* 332 */       newAnnotationType = this.annotationType.parameterize(typeVariableMap);
/*     */     } 
/* 334 */     ExactAnnotationTypePattern ret = new ExactAnnotationTypePattern(newAnnotationType, this.annotationValues);
/* 335 */     ret.formalName = this.formalName;
/* 336 */     ret.bindingPattern = this.bindingPattern;
/* 337 */     ret.copyLocationFrom(this);
/* 338 */     if (isForParameterAnnotationMatch()) {
/* 339 */       ret.setForParameterAnnotationMatch();
/*     */     }
/* 341 */     return ret;
/*     */   }
/*     */   
/*     */   protected String maybeGetSimpleName() {
/* 345 */     if (this.formalName != null) {
/* 346 */       return this.formalName;
/*     */     }
/* 348 */     String ret = this.annotationType.getName();
/* 349 */     return (ret.indexOf('.') == -1) ? ret : null;
/*     */   }
/*     */   
/*     */   protected void verifyIsAnnotationType(ResolvedType type, IScope scope) {
/* 353 */     if (!type.isAnnotation()) {
/* 354 */       IMessage m = MessageUtil.error(WeaverMessages.format("referenceToNonAnnotationType", type.getName()), 
/* 355 */           getSourceLocation());
/* 356 */       scope.getWorld().getMessageHandler().handleMessage(m);
/* 357 */       this.resolved = false;
/*     */     } 
/*     */   }
/*     */   
/* 361 */   private static byte VERSION = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 370 */     s.writeByte(1);
/* 371 */     s.writeByte(VERSION);
/* 372 */     s.writeBoolean(this.bindingPattern);
/* 373 */     if (this.bindingPattern) {
/* 374 */       s.writeUTF(this.formalName);
/*     */     } else {
/* 376 */       this.annotationType.write(s);
/*     */     } 
/* 378 */     writeLocation((DataOutputStream)s);
/* 379 */     s.writeBoolean(isForParameterAnnotationMatch());
/* 380 */     if (this.annotationValues == null) {
/* 381 */       s.writeInt(0);
/*     */     } else {
/* 383 */       s.writeInt(this.annotationValues.size());
/* 384 */       Set<String> key = this.annotationValues.keySet();
/* 385 */       for (String k : key) {
/* 386 */         s.writeUTF(k);
/* 387 */         s.writeUTF(this.annotationValues.get(k));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static AnnotationTypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*     */     ExactAnnotationTypePattern ret;
/* 394 */     byte version = s.readByte();
/* 395 */     if (version > VERSION) {
/* 396 */       throw new BCException("ExactAnnotationTypePattern was written by a newer version of AspectJ");
/*     */     }
/* 398 */     boolean isBindingPattern = s.readBoolean();
/* 399 */     if (isBindingPattern) {
/* 400 */       ret = new ExactAnnotationTypePattern(s.readUTF());
/*     */     } else {
/* 402 */       ret = new ExactAnnotationTypePattern(UnresolvedType.read((DataInputStream)s));
/*     */     } 
/* 404 */     ret.readLocation(context, (DataInputStream)s);
/* 405 */     if (s.getMajorVersion() >= 4 && 
/* 406 */       s.readBoolean()) {
/* 407 */       ret.setForParameterAnnotationMatch();
/*     */     }
/*     */     
/* 410 */     if (s.getMajorVersion() >= 5) {
/* 411 */       int annotationValueCount = s.readInt();
/* 412 */       if (annotationValueCount > 0) {
/* 413 */         Map<String, String> aValues = new HashMap<>();
/* 414 */         for (int i = 0; i < annotationValueCount; i++) {
/* 415 */           String key = s.readUTF();
/* 416 */           String val = s.readUTF();
/* 417 */           aValues.put(key, val);
/*     */         } 
/* 419 */         ret.annotationValues = aValues;
/*     */       } 
/*     */     } 
/* 422 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 432 */     if (!(obj instanceof ExactAnnotationTypePattern)) {
/* 433 */       return false;
/*     */     }
/* 435 */     ExactAnnotationTypePattern other = (ExactAnnotationTypePattern)obj;
/* 436 */     return (other.annotationType.equals(this.annotationType) && 
/* 437 */       isForParameterAnnotationMatch() == other.isForParameterAnnotationMatch() && ((this.annotationValues == null) ? (other.annotationValues == null) : this.annotationValues
/* 438 */       .equals(other.annotationValues)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 448 */     return (this.annotationType.hashCode() * 37 + (isForParameterAnnotationMatch() ? 0 : 1)) * 37 + (
/* 449 */       (this.annotationValues == null) ? 0 : this.annotationValues.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 454 */     if (!this.resolved && this.formalName != null) {
/* 455 */       return this.formalName;
/*     */     }
/* 457 */     String ret = "@" + this.annotationType.toString();
/* 458 */     if (this.formalName != null) {
/* 459 */       ret = ret + " " + this.formalName;
/*     */     }
/* 461 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 466 */     return visitor.visit(this, data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ExactAnnotationTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */