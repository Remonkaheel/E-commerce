/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.TypeVariableReferenceType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeclareSoft
/*     */   extends Declare
/*     */ {
/*     */   private TypePattern exception;
/*     */   private Pointcut pointcut;
/*     */   
/*     */   public DeclareSoft(TypePattern exception, Pointcut pointcut) {
/*  33 */     this.exception = exception;
/*  34 */     this.pointcut = pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/*  39 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/*  43 */     Object ret = accept(visitor, data);
/*  44 */     if (this.exception != null)
/*  45 */       this.exception.traverse(visitor, ret); 
/*  46 */     if (this.pointcut != null)
/*  47 */       this.pointcut.traverse(visitor, ret); 
/*  48 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Declare parameterizeWith(Map<String, UnresolvedType> typeVariableBindingMap, World w) {
/*  53 */     DeclareSoft ret = new DeclareSoft(this.exception.parameterizeWith(typeVariableBindingMap, w), this.pointcut.parameterizeWith(typeVariableBindingMap, w));
/*     */     
/*  55 */     ret.copyLocationFrom(this);
/*  56 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  61 */     StringBuilder buf = new StringBuilder();
/*  62 */     buf.append("declare soft: ");
/*  63 */     buf.append(this.exception);
/*  64 */     buf.append(": ");
/*  65 */     buf.append(this.pointcut);
/*  66 */     buf.append(";");
/*  67 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/*  72 */     if (!(other instanceof DeclareSoft)) {
/*  73 */       return false;
/*     */     }
/*  75 */     DeclareSoft o = (DeclareSoft)other;
/*  76 */     return (o.pointcut.equals(this.pointcut) && o.exception.equals(this.exception));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  81 */     int result = 19;
/*  82 */     result = 37 * result + this.pointcut.hashCode();
/*  83 */     result = 37 * result + this.exception.hashCode();
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  89 */     s.writeByte(3);
/*  90 */     this.exception.write(s);
/*  91 */     this.pointcut.write(s);
/*  92 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  96 */     Declare ret = new DeclareSoft(TypePattern.read(s, context), Pointcut.read(s, context));
/*  97 */     ret.readLocation(context, (DataInputStream)s);
/*  98 */     return ret;
/*     */   }
/*     */   
/*     */   public Pointcut getPointcut() {
/* 102 */     return this.pointcut;
/*     */   }
/*     */   
/*     */   public TypePattern getException() {
/* 106 */     return this.exception;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(IScope scope) {
/* 111 */     this.exception = this.exception.resolveBindings(scope, (Bindings)null, false, true);
/* 112 */     ResolvedType excType = this.exception.getExactType().resolve(scope.getWorld());
/* 113 */     if (!excType.isMissing()) {
/* 114 */       if (excType.isTypeVariableReference()) {
/* 115 */         TypeVariableReferenceType typeVariableRT = (TypeVariableReferenceType)excType;
/*     */ 
/*     */         
/* 118 */         excType = typeVariableRT.getTypeVariable().getFirstBound().resolve(scope.getWorld());
/*     */       } 
/* 120 */       if (!scope.getWorld().getCoreType(UnresolvedType.THROWABLE).isAssignableFrom(excType)) {
/* 121 */         scope.getWorld()
/* 122 */           .showMessage(IMessage.ERROR, WeaverMessages.format("notThrowable", excType.getName()), this.exception
/* 123 */             .getSourceLocation(), null);
/* 124 */         this.pointcut = Pointcut.makeMatchesNothing(Pointcut.RESOLVED);
/*     */         
/*     */         return;
/*     */       } 
/* 128 */       if (scope.getWorld().getCoreType(UnresolvedType.RUNTIME_EXCEPTION).isAssignableFrom(excType)) {
/* 129 */         (scope.getWorld().getLint()).runtimeExceptionNotSoftened.signal(new String[] { excType.getName() }, this.exception
/* 130 */             .getSourceLocation(), null);
/* 131 */         this.pointcut = Pointcut.makeMatchesNothing(Pointcut.RESOLVED);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 136 */     this.pointcut = this.pointcut.resolve(scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAdviceLike() {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNameSuffix() {
/* 146 */     return "soft";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\DeclareSoft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */