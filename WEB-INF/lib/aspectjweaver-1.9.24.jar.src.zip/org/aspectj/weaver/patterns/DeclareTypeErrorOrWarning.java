/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeclareTypeErrorOrWarning
/*     */   extends Declare
/*     */ {
/*     */   private boolean isError;
/*     */   private TypePattern typePattern;
/*     */   private String message;
/*     */   
/*     */   public DeclareTypeErrorOrWarning(boolean isError, TypePattern typePattern, String message) {
/*  35 */     this.isError = isError;
/*  36 */     this.typePattern = typePattern;
/*  37 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  44 */     StringBuilder buf = new StringBuilder();
/*  45 */     buf.append("declare ");
/*  46 */     if (this.isError) {
/*  47 */       buf.append("error: ");
/*     */     } else {
/*  49 */       buf.append("warning: ");
/*     */     } 
/*  51 */     buf.append(this.typePattern);
/*  52 */     buf.append(": ");
/*  53 */     buf.append("\"");
/*  54 */     buf.append(this.message);
/*  55 */     buf.append("\";");
/*  56 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  60 */     if (!(other instanceof DeclareTypeErrorOrWarning)) {
/*  61 */       return false;
/*     */     }
/*  63 */     DeclareTypeErrorOrWarning o = (DeclareTypeErrorOrWarning)other;
/*  64 */     return (o.isError == this.isError && o.typePattern.equals(this.typePattern) && o.message.equals(this.message));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  68 */     int result = this.isError ? 19 : 23;
/*  69 */     result = 37 * result + this.typePattern.hashCode();
/*  70 */     result = 37 * result + this.message.hashCode();
/*  71 */     return result;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/*  75 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/*  79 */     Object ret = accept(visitor, data);
/*  80 */     if (this.typePattern != null)
/*  81 */       this.typePattern.traverse(visitor, ret); 
/*  82 */     return ret;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  86 */     s.writeByte(7);
/*  87 */     s.writeBoolean(this.isError);
/*  88 */     this.typePattern.write(s);
/*  89 */     s.writeUTF(this.message);
/*  90 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  94 */     Declare ret = new DeclareTypeErrorOrWarning(s.readBoolean(), TypePattern.read(s, context), s.readUTF());
/*  95 */     ret.readLocation(context, (DataInputStream)s);
/*  96 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isError() {
/* 100 */     return this.isError;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 104 */     return this.message;
/*     */   }
/*     */   
/*     */   public TypePattern getTypePattern() {
/* 108 */     return this.typePattern;
/*     */   }
/*     */   
/*     */   public void resolve(IScope scope) {
/* 112 */     this.typePattern.resolve(scope.getWorld());
/*     */   }
/*     */   
/*     */   public Declare parameterizeWith(Map<String, UnresolvedType> typeVariableBindingMap, World w) {
/* 116 */     Declare ret = new DeclareTypeErrorOrWarning(this.isError, this.typePattern.parameterizeWith(typeVariableBindingMap, w), this.message);
/* 117 */     ret.copyLocationFrom(this);
/* 118 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isAdviceLike() {
/* 122 */     return false;
/*     */   }
/*     */   
/*     */   public String getNameSuffix() {
/* 126 */     return "teow";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 133 */     StringBuilder buf = new StringBuilder();
/* 134 */     buf.append("declare type ");
/* 135 */     if (this.isError) {
/* 136 */       buf.append("error");
/*     */     } else {
/* 138 */       buf.append("warning");
/*     */     } 
/* 140 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\DeclareTypeErrorOrWarning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */