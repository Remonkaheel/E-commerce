/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotationTypePattern
/*     */   extends PatternNode
/*     */ {
/*  28 */   public static final AnnotationTypePattern ANY = new AnyAnnotationTypePattern();
/*  29 */   public static final AnnotationTypePattern ELLIPSIS = new EllipsisAnnotationTypePattern();
/*  30 */   public static final AnnotationTypePattern[] NONE = new AnnotationTypePattern[0];
/*     */   
/*     */   private boolean isForParameterAnnotationMatch;
/*     */   
/*     */   public static final byte EXACT = 1;
/*     */   
/*     */   public static final byte BINDING = 2;
/*     */   
/*     */   public static final byte NOT = 3;
/*     */   
/*     */   public static final byte OR = 4;
/*     */   public static final byte AND = 5;
/*     */   public static final byte ELLIPSIS_KEY = 6;
/*     */   
/*     */   public FuzzyBoolean fastMatches(AnnotatedElement annotated) {
/*  45 */     return FuzzyBoolean.MAYBE;
/*     */   } public static final byte ANY_KEY = 7; public static final byte WILD = 8; public static final byte EXACTFIELD = 9; public static final byte BINDINGFIELD = 10; public static final byte BINDINGFIELD2 = 11; public abstract FuzzyBoolean matches(AnnotatedElement paramAnnotatedElement);
/*     */   public abstract FuzzyBoolean matches(AnnotatedElement paramAnnotatedElement, ResolvedType[] paramArrayOfResolvedType);
/*     */   public AnnotationTypePattern remapAdviceFormals(IntMap bindings) {
/*  49 */     return this;
/*     */   }
/*     */   
/*     */   public abstract void resolve(World paramWorld);
/*     */   
/*     */   public abstract AnnotationTypePattern parameterizeWith(Map<String, UnresolvedType> paramMap, World paramWorld);
/*     */   
/*     */   public boolean isAny() {
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding) {
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationTypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  80 */     byte key = s.readByte();
/*  81 */     switch (key) {
/*     */       case 1:
/*  83 */         return ExactAnnotationTypePattern.read(s, context);
/*     */       case 2:
/*  85 */         return BindingAnnotationTypePattern.read(s, context);
/*     */       case 3:
/*  87 */         return NotAnnotationTypePattern.read(s, context);
/*     */       case 4:
/*  89 */         return OrAnnotationTypePattern.read(s, context);
/*     */       case 5:
/*  91 */         return AndAnnotationTypePattern.read(s, context);
/*     */       case 8:
/*  93 */         return WildAnnotationTypePattern.read(s, context);
/*     */       case 9:
/*  95 */         return ExactAnnotationFieldTypePattern.read(s, context);
/*     */       case 10:
/*  97 */         return BindingAnnotationFieldTypePattern.read(s, context);
/*     */       case 11:
/*  99 */         return BindingAnnotationFieldTypePattern.read2(s, context);
/*     */       case 6:
/* 101 */         return ELLIPSIS;
/*     */       case 7:
/* 103 */         return ANY;
/*     */     } 
/* 105 */     throw new BCException("unknown TypePattern kind: " + key);
/*     */   }
/*     */   
/*     */   public void setForParameterAnnotationMatch() {
/* 109 */     this.isForParameterAnnotationMatch = true;
/*     */   }
/*     */   
/*     */   public boolean isForParameterAnnotationMatch() {
/* 113 */     return this.isForParameterAnnotationMatch;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AnnotationTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */