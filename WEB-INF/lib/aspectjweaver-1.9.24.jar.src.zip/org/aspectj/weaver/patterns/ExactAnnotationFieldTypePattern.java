/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.IHasPosition;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExactAnnotationFieldTypePattern
/*     */   extends ExactAnnotationTypePattern
/*     */ {
/*     */   UnresolvedType annotationType;
/*     */   private ResolvedMember field;
/*     */   
/*     */   public ExactAnnotationFieldTypePattern(ExactAnnotationTypePattern p, String formalName) {
/*  43 */     super(formalName);
/*  44 */     this.annotationType = p.annotationType;
/*  45 */     copyLocationFrom(p);
/*     */   }
/*     */   
/*     */   public ExactAnnotationFieldTypePattern(UnresolvedType annotationType, String formalName) {
/*  49 */     super(formalName);
/*  50 */     this.annotationType = annotationType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding) {
/*  60 */     if (this.resolved) {
/*  61 */       return this;
/*     */     }
/*  63 */     this.resolved = true;
/*  64 */     FormalBinding formalBinding = scope.lookupFormal(this.formalName);
/*  65 */     if (formalBinding == null) {
/*  66 */       scope.message(IMessage.ERROR, (IHasPosition)this, "When using @annotation(<annotationType>(<annotationField>)), <annotationField> must be bound");
/*     */       
/*  68 */       return this;
/*     */     } 
/*     */     
/*  71 */     this.annotationType = (UnresolvedType)scope.getWorld().resolve(this.annotationType, true);
/*     */ 
/*     */     
/*  74 */     if (ResolvedType.isMissing(this.annotationType)) {
/*  75 */       String cleanname = this.annotationType.getName();
/*  76 */       UnresolvedType type = null;
/*  77 */       while (ResolvedType.isMissing(type = scope.lookupType(cleanname, (IHasPosition)this))) {
/*  78 */         int lastDot = cleanname.lastIndexOf('.');
/*  79 */         if (lastDot == -1) {
/*     */           break;
/*     */         }
/*  82 */         cleanname = cleanname.substring(0, lastDot) + "$" + cleanname.substring(lastDot + 1);
/*     */       } 
/*  84 */       this.annotationType = (UnresolvedType)scope.getWorld().resolve(type, true);
/*  85 */       if (ResolvedType.isMissing(this.annotationType))
/*     */       {
/*     */         
/*  88 */         return this;
/*     */       }
/*     */     } 
/*     */     
/*  92 */     verifyIsAnnotationType((ResolvedType)this.annotationType, scope);
/*     */     
/*  94 */     ResolvedType formalBindingType = formalBinding.getType().resolve(scope.getWorld());
/*     */     
/*  96 */     String bindingTypeSignature = formalBindingType.getSignature();
/*  97 */     if (!formalBindingType.isEnum() && !bindingTypeSignature.equals("Ljava/lang/String;") && !bindingTypeSignature.equals("I")) {
/*  98 */       scope.message(IMessage.ERROR, (IHasPosition)this, "The field within the annotation must be an enum, string or int. '" + formalBinding
/*  99 */           .getType() + "' is not (compiler limitation)");
/*     */     }
/*     */     
/* 102 */     this.bindingPattern = true;
/*     */ 
/*     */     
/* 105 */     ReferenceType theAnnotationType = (ReferenceType)this.annotationType;
/* 106 */     ResolvedMember[] annotationFields = theAnnotationType.getDeclaredMethods();
/* 107 */     this.field = null;
/* 108 */     boolean looksAmbiguous = false;
/* 109 */     for (ResolvedMember resolvedMember : annotationFields) {
/* 110 */       if (resolvedMember.getReturnType().equals(formalBinding.getType())) {
/* 111 */         if (this.field != null) {
/* 112 */           boolean haveProblem = true;
/*     */           
/* 114 */           if (this.field.getName().equals(this.formalName)) {
/*     */             
/* 116 */             haveProblem = false;
/* 117 */           } else if (resolvedMember.getName().equals(this.formalName)) {
/*     */             
/* 119 */             this.field = resolvedMember;
/* 120 */             haveProblem = false;
/*     */           } 
/* 122 */           if (haveProblem) {
/* 123 */             looksAmbiguous = true;
/*     */           }
/*     */         } else {
/* 126 */           this.field = resolvedMember;
/*     */         } 
/*     */       }
/*     */     } 
/* 130 */     if (looksAmbiguous)
/*     */     {
/* 132 */       if (this.field == null || !this.field.getName().equals(this.formalName)) {
/* 133 */         scope.message(IMessage.ERROR, (IHasPosition)this, "The field type '" + formalBinding.getType() + "' is ambiguous for annotation type '" + theAnnotationType
/* 134 */             .getName() + "'");
/*     */       }
/*     */     }
/* 137 */     if (this.field == null) {
/* 138 */       scope.message(IMessage.ERROR, (IHasPosition)this, "No field of type '" + formalBinding.getType() + "' exists on annotation type '" + theAnnotationType
/* 139 */           .getName() + "'");
/*     */     }
/*     */ 
/*     */     
/* 143 */     BindingAnnotationFieldTypePattern binding = new BindingAnnotationFieldTypePattern(formalBinding.getType(), formalBinding.getIndex(), (UnresolvedType)theAnnotationType);
/* 144 */     binding.copyLocationFrom(this);
/* 145 */     binding.formalName = this.formalName;
/* 146 */     bindings.register(binding, scope);
/* 147 */     binding.resolveBinding(scope.getWorld());
/* 148 */     return binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 153 */     s.writeByte(9);
/* 154 */     s.writeUTF(this.formalName);
/* 155 */     this.annotationType.write(s);
/* 156 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */ 
/*     */   
/*     */   public static AnnotationTypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 161 */     String formalName = s.readUTF();
/* 162 */     UnresolvedType annotationType = UnresolvedType.read((DataInputStream)s);
/* 163 */     ExactAnnotationFieldTypePattern ret = new ExactAnnotationFieldTypePattern(annotationType, formalName);
/* 164 */     ret.readLocation(context, (DataInputStream)s);
/* 165 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 172 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 177 */     if (!(obj instanceof ExactAnnotationFieldTypePattern)) {
/* 178 */       return false;
/*     */     }
/* 180 */     ExactAnnotationFieldTypePattern other = (ExactAnnotationFieldTypePattern)obj;
/* 181 */     return (other.annotationType.equals(this.annotationType) && other.field.equals(this.field) && other.formalName
/* 182 */       .equals(this.formalName));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 187 */     int hashcode = this.annotationType.hashCode();
/* 188 */     hashcode = hashcode * 37 + this.field.hashCode();
/* 189 */     hashcode = hashcode * 37 + this.formalName.hashCode();
/* 190 */     return hashcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatches(AnnotatedElement annotated) {
/* 198 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public UnresolvedType getAnnotationType() {
/* 203 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public Map getAnnotationValues() {
/* 208 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolvedType getResolvedAnnotationType() {
/* 213 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated, ResolvedType[] parameterAnnotations) {
/* 218 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated) {
/* 223 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesRuntimeType(AnnotatedElement annotated) {
/* 228 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern parameterizeWith(Map typeVariableMap, World w) {
/* 233 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(World world) {
/* 238 */     throw new BCException("unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 243 */     if (!this.resolved && this.formalName != null) {
/* 244 */       return this.formalName;
/*     */     }
/* 246 */     StringBuilder ret = new StringBuilder();
/* 247 */     ret.append("@").append(this.annotationType.toString());
/* 248 */     ret.append("(").append(this.formalName).append(")");
/* 249 */     return ret.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ExactAnnotationFieldTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */