/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bindings
/*     */ {
/*  20 */   public static final Bindings NONE = new Bindings(0);
/*     */   
/*     */   private BindingPattern[] bindings;
/*     */   
/*     */   public Bindings(BindingPattern[] bindings) {
/*  25 */     this.bindings = bindings;
/*     */   }
/*     */   
/*     */   public Bindings(int count) {
/*  29 */     this(new BindingPattern[count]);
/*     */   }
/*     */   
/*     */   public void register(BindingPattern binding, IScope scope) {
/*  33 */     int index = binding.getFormalIndex();
/*  34 */     BindingPattern existingBinding = this.bindings[index];
/*  35 */     if (existingBinding != null) {
/*  36 */       scope.message(IMessage.ERROR, existingBinding, binding, "multiple bindings" + index + ", " + binding);
/*     */     }
/*  38 */     this.bindings[index] = binding;
/*     */   }
/*     */   
/*     */   public void mergeIn(Bindings other, IScope scope) {
/*  42 */     for (int i = 0, len = other.bindings.length; i < len; i++) {
/*  43 */       if (other.bindings[i] != null) {
/*  44 */         register(other.bindings[i], scope);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkEquals(Bindings other, IScope scope) {
/*  53 */     BindingPattern[] b1 = this.bindings;
/*  54 */     BindingPattern[] b2 = other.bindings;
/*  55 */     int len = b1.length;
/*  56 */     if (len != b2.length) {
/*  57 */       throw new BCException("INSANE");
/*     */     }
/*     */     
/*  60 */     for (int i = 0; i < len; i++) {
/*  61 */       if (b1[i] == null && b2[i] != null) {
/*  62 */         scope.message(IMessage.ERROR, b2[i], "inconsistent binding");
/*  63 */         b1[i] = b2[i];
/*  64 */       } else if (b2[i] == null && b1[i] != null) {
/*  65 */         scope.message(IMessage.ERROR, b1[i], "inconsistent binding");
/*  66 */         b2[i] = b1[i];
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/*  72 */     StringBuilder buf = new StringBuilder("Bindings(");
/*  73 */     for (int i = 0, len = this.bindings.length; i < len; i++) {
/*  74 */       if (i > 0)
/*  75 */         buf.append(", "); 
/*  76 */       buf.append(this.bindings[i]);
/*     */     } 
/*  78 */     buf.append(")");
/*  79 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getUsedFormals() {
/*  84 */     int[] ret = new int[this.bindings.length];
/*  85 */     int index = 0;
/*  86 */     for (int i = 0, len = this.bindings.length; i < len; i++) {
/*  87 */       if (this.bindings[i] != null) {
/*  88 */         ret[index++] = i;
/*     */       }
/*     */     } 
/*  91 */     int[] newRet = new int[index];
/*  92 */     System.arraycopy(ret, 0, newRet, 0, index);
/*     */     
/*  94 */     return newRet;
/*     */   }
/*     */   
/*     */   public UnresolvedType[] getUsedFormalTypes() {
/*  98 */     UnresolvedType[] ret = new UnresolvedType[this.bindings.length];
/*  99 */     int index = 0;
/* 100 */     for (BindingPattern binding : this.bindings) {
/* 101 */       if (binding != null) {
/* 102 */         ret[index++] = ((BindingTypePattern)binding).getExactType();
/*     */       }
/*     */     } 
/* 105 */     UnresolvedType[] newRet = new UnresolvedType[index];
/* 106 */     System.arraycopy(ret, 0, newRet, 0, index);
/*     */     
/* 108 */     return newRet;
/*     */   }
/*     */   
/*     */   public Bindings copy() {
/* 112 */     return new Bindings((BindingPattern[])this.bindings.clone());
/*     */   }
/*     */   
/*     */   public void checkAllBound(IScope scope) {
/* 116 */     for (int i = 0, len = this.bindings.length; i < len; i++) {
/* 117 */       if (this.bindings[i] == null)
/*     */       {
/* 119 */         if (scope.getFormal(i) instanceof FormalBinding.ImplicitFormalBinding) {
/* 120 */           this.bindings[i] = new BindingTypePattern(scope.getFormal(i), false);
/*     */         } else {
/* 122 */           scope.message(IMessage.ERROR, scope.getFormal(i), "formal unbound in pointcut ");
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 130 */     return this.bindings.length;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\Bindings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */