package org.aspectj.weaver.patterns;

import org.aspectj.weaver.ISourceContext;

public interface ITokenSource {
  IToken next();
  
  IToken peek();
  
  IToken peek(int paramInt);
  
  int getIndex();
  
  void setIndex(int paramInt);
  
  ISourceContext getSourceContext();
  
  boolean hasMoreTokens();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ITokenSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */