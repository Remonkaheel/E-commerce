/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationPatternList
/*     */   extends PatternNode
/*     */ {
/*     */   private AnnotationTypePattern[] typePatterns;
/*  31 */   int ellipsisCount = 0;
/*     */   
/*  33 */   public static final AnnotationPatternList EMPTY = new AnnotationPatternList(AnnotationTypePattern.NONE);
/*     */   
/*  35 */   public static final AnnotationPatternList ANY = new AnnotationPatternList(new AnnotationTypePattern[] { AnnotationTypePattern.ELLIPSIS });
/*     */ 
/*     */   
/*     */   public AnnotationPatternList() {
/*  39 */     this.typePatterns = AnnotationTypePattern.NONE;
/*  40 */     this.ellipsisCount = 0;
/*     */   }
/*     */   
/*     */   public AnnotationPatternList(AnnotationTypePattern[] arguments) {
/*  44 */     this.typePatterns = arguments;
/*  45 */     for (AnnotationTypePattern argument : arguments) {
/*  46 */       if (argument == AnnotationTypePattern.ELLIPSIS) {
/*  47 */         this.ellipsisCount++;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public AnnotationPatternList(List<AnnotationTypePattern> l) {
/*  53 */     this(l.<AnnotationTypePattern>toArray(AnnotationTypePattern.NONE));
/*     */   }
/*     */   
/*     */   protected AnnotationTypePattern[] getAnnotationPatterns() {
/*  57 */     return this.typePatterns;
/*     */   }
/*     */   
/*     */   public AnnotationPatternList parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  61 */     AnnotationTypePattern[] parameterizedPatterns = new AnnotationTypePattern[this.typePatterns.length];
/*  62 */     for (int i = 0; i < parameterizedPatterns.length; i++) {
/*  63 */       parameterizedPatterns[i] = this.typePatterns[i].parameterizeWith(typeVariableMap, w);
/*     */     }
/*  65 */     AnnotationPatternList ret = new AnnotationPatternList(parameterizedPatterns);
/*  66 */     ret.copyLocationFrom(this);
/*  67 */     return ret;
/*     */   }
/*     */   
/*     */   public void resolve(World inWorld) {
/*  71 */     for (AnnotationTypePattern typePattern : this.typePatterns) {
/*  72 */       typePattern.resolve(inWorld);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matches(ResolvedType[] someArgs) {
/*  78 */     int numArgsMatchedByEllipsis = someArgs.length + this.ellipsisCount - this.typePatterns.length;
/*  79 */     if (numArgsMatchedByEllipsis < 0) {
/*  80 */       return FuzzyBoolean.NO;
/*     */     }
/*  82 */     if (numArgsMatchedByEllipsis > 0 && this.ellipsisCount == 0) {
/*  83 */       return FuzzyBoolean.NO;
/*     */     }
/*     */     
/*  86 */     FuzzyBoolean ret = FuzzyBoolean.YES;
/*  87 */     int argsIndex = 0;
/*  88 */     for (AnnotationTypePattern typePattern : this.typePatterns) {
/*  89 */       if (typePattern == AnnotationTypePattern.ELLIPSIS) {
/*     */         
/*  91 */         argsIndex += numArgsMatchedByEllipsis;
/*  92 */       } else if (typePattern == AnnotationTypePattern.ANY) {
/*  93 */         argsIndex++;
/*     */       }
/*     */       else {
/*     */         
/*  97 */         if (someArgs[argsIndex].isPrimitiveType()) {
/*  98 */           return FuzzyBoolean.NO;
/*     */         }
/* 100 */         ExactAnnotationTypePattern ap = (ExactAnnotationTypePattern)typePattern;
/* 101 */         FuzzyBoolean matches = ap.matchesRuntimeType((AnnotatedElement)someArgs[argsIndex]);
/* 102 */         if (matches == FuzzyBoolean.NO) {
/* 103 */           return FuzzyBoolean.MAYBE;
/*     */         }
/* 105 */         argsIndex++;
/* 106 */         ret = ret.and(matches);
/*     */       } 
/*     */     } 
/*     */     
/* 110 */     return ret;
/*     */   }
/*     */   
/*     */   public int size() {
/* 114 */     return this.typePatterns.length;
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern get(int index) {
/* 118 */     return this.typePatterns[index];
/*     */   }
/*     */   
/*     */   public AnnotationPatternList resolveBindings(IScope scope, Bindings bindings, boolean allowBinding) {
/* 122 */     for (int i = 0; i < this.typePatterns.length; i++) {
/* 123 */       AnnotationTypePattern p = this.typePatterns[i];
/* 124 */       if (p != null) {
/* 125 */         this.typePatterns[i] = this.typePatterns[i].resolveBindings(scope, bindings, allowBinding);
/*     */       }
/*     */     } 
/* 128 */     return this;
/*     */   }
/*     */   
/*     */   public AnnotationPatternList resolveReferences(IntMap bindings) {
/* 132 */     int len = this.typePatterns.length;
/* 133 */     AnnotationTypePattern[] ret = new AnnotationTypePattern[len];
/* 134 */     for (int i = 0; i < len; i++) {
/* 135 */       ret[i] = this.typePatterns[i].remapAdviceFormals(bindings);
/*     */     }
/* 137 */     return new AnnotationPatternList(ret);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 141 */     StringBuilder buf = new StringBuilder();
/* 142 */     buf.append("(");
/* 143 */     for (int i = 0, len = this.typePatterns.length; i < len; i++) {
/* 144 */       AnnotationTypePattern type = this.typePatterns[i];
/* 145 */       if (i > 0) {
/* 146 */         buf.append(", ");
/*     */       }
/* 148 */       if (type == AnnotationTypePattern.ELLIPSIS) {
/* 149 */         buf.append("..");
/*     */       } else {
/* 151 */         String annPatt = type.toString();
/* 152 */         buf.append(annPatt.startsWith("@") ? annPatt.substring(1) : annPatt);
/*     */       } 
/*     */     } 
/* 155 */     buf.append(")");
/* 156 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 160 */     if (!(other instanceof AnnotationPatternList)) {
/* 161 */       return false;
/*     */     }
/* 163 */     AnnotationPatternList o = (AnnotationPatternList)other;
/* 164 */     int len = o.typePatterns.length;
/* 165 */     if (len != this.typePatterns.length) {
/* 166 */       return false;
/*     */     }
/* 168 */     for (int i = 0; i < len; i++) {
/* 169 */       if (!this.typePatterns[i].equals(o.typePatterns[i])) {
/* 170 */         return false;
/*     */       }
/*     */     } 
/* 173 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 177 */     int result = 41;
/* 178 */     for (AnnotationTypePattern typePattern : this.typePatterns) {
/* 179 */       result = 37 * result + typePattern.hashCode();
/*     */     }
/* 181 */     return result;
/*     */   }
/*     */   
/*     */   public static AnnotationPatternList read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 185 */     short len = s.readShort();
/* 186 */     AnnotationTypePattern[] arguments = new AnnotationTypePattern[len];
/* 187 */     for (int i = 0; i < len; i++) {
/* 188 */       arguments[i] = AnnotationTypePattern.read(s, context);
/*     */     }
/* 190 */     AnnotationPatternList ret = new AnnotationPatternList(arguments);
/* 191 */     ret.readLocation(context, (DataInputStream)s);
/* 192 */     return ret;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 196 */     s.writeShort(this.typePatterns.length);
/* 197 */     for (AnnotationTypePattern typePattern : this.typePatterns) {
/* 198 */       typePattern.write(s);
/*     */     }
/* 200 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 204 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 208 */     Object ret = accept(visitor, data);
/* 209 */     for (AnnotationTypePattern typePattern : this.typePatterns) {
/* 210 */       typePattern.traverse(visitor, ret);
/*     */     }
/* 212 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AnnotationPatternList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */