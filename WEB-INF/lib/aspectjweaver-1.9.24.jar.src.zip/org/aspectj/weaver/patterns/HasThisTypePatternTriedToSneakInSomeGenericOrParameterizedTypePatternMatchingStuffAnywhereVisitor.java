/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor
/*    */   extends AbstractPatternNodeVisitor
/*    */ {
/*    */   boolean ohYesItHas = false;
/*    */   
/*    */   public Object visit(ExactTypePattern node, Object data) {
/* 30 */     UnresolvedType theExactType = node.getExactType();
/* 31 */     if (theExactType.isParameterizedType()) this.ohYesItHas = true;
/*    */     
/* 33 */     return data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object visit(WildTypePattern node, Object data) {
/* 41 */     if (node.getUpperBound() != null) this.ohYesItHas = true; 
/* 42 */     if (node.getLowerBound() != null) this.ohYesItHas = true; 
/* 43 */     if (node.getTypeParameters().size() != 0) this.ohYesItHas = true; 
/* 44 */     return data;
/*    */   }
/*    */   
/*    */   public boolean wellHasItThen() {
/* 48 */     return this.ohYesItHas;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */