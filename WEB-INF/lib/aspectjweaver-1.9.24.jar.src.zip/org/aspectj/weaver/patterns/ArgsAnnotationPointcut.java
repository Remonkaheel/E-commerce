/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.IHasPosition;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgsAnnotationPointcut
/*     */   extends NameBindingPointcut
/*     */ {
/*     */   private AnnotationPatternList arguments;
/*     */   private String declarationText;
/*     */   
/*     */   public ArgsAnnotationPointcut(AnnotationPatternList arguments) {
/*  51 */     this.arguments = arguments;
/*  52 */     this.pointcutKind = 21;
/*  53 */     buildDeclarationText();
/*     */   }
/*     */   
/*     */   public AnnotationPatternList getArguments() {
/*  57 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public int couldMatchKinds() {
/*  61 */     return Shadow.ALL_SHADOW_KINDS_BITS;
/*     */   }
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  65 */     ArgsAnnotationPointcut ret = new ArgsAnnotationPointcut(this.arguments.parameterizeWith(typeVariableMap, w));
/*  66 */     ret.copyLocationFrom(this);
/*  67 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo info) {
/*  76 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*  85 */     this.arguments.resolve(shadow.getIWorld());
/*  86 */     FuzzyBoolean ret = this.arguments.matches(shadow.getIWorld().resolve(shadow.getArgTypes()));
/*  87 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resolveBindings(IScope scope, Bindings bindings) {
/*  97 */     if (!scope.getWorld().isInJava5Mode()) {
/*  98 */       scope.message(MessageUtil.error(WeaverMessages.format("atargsNeedsJava5"), 
/*  99 */             getSourceLocation()));
/*     */       return;
/*     */     } 
/* 102 */     this.arguments.resolveBindings(scope, bindings, true);
/* 103 */     if (this.arguments.ellipsisCount > 1) {
/* 104 */       scope.message(IMessage.ERROR, (IHasPosition)this, "uses more than one .. in args (compiler limitation)");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 114 */     if (isDeclare(bindings.getEnclosingAdvice())) {
/*     */       
/* 116 */       inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("argsInDeclare"), bindings
/* 117 */           .getEnclosingAdvice().getSourceLocation(), null);
/* 118 */       return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */     } 
/* 120 */     AnnotationPatternList list = this.arguments.resolveReferences(bindings);
/* 121 */     Pointcut ret = new ArgsAnnotationPointcut(list);
/* 122 */     ret.copyLocationFrom(this);
/* 123 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/*     */     Test test;
/* 132 */     int len = shadow.getArgCount();
/*     */ 
/*     */     
/* 135 */     int numArgsMatchedByEllipsis = len + this.arguments.ellipsisCount - this.arguments.size();
/* 136 */     if (numArgsMatchedByEllipsis < 0) {
/* 137 */       return (Test)Literal.FALSE;
/*     */     }
/* 139 */     if (numArgsMatchedByEllipsis > 0 && this.arguments.ellipsisCount == 0) {
/* 140 */       return (Test)Literal.FALSE;
/*     */     }
/*     */     
/* 143 */     Literal literal = Literal.TRUE;
/* 144 */     int argsIndex = 0;
/* 145 */     for (int i = 0; i < this.arguments.size(); i++) {
/* 146 */       if (this.arguments.get(i) == AnnotationTypePattern.ELLIPSIS) {
/*     */         
/* 148 */         argsIndex += numArgsMatchedByEllipsis;
/* 149 */       } else if (this.arguments.get(i) == AnnotationTypePattern.ANY) {
/* 150 */         argsIndex++;
/*     */       }
/*     */       else {
/*     */         
/* 154 */         ExactAnnotationTypePattern ap = (ExactAnnotationTypePattern)this.arguments.get(i);
/* 155 */         UnresolvedType argType = shadow.getArgType(argsIndex);
/* 156 */         ResolvedType rArgType = argType.resolve(shadow.getIWorld());
/* 157 */         if (rArgType.isMissing()) {
/* 158 */           (shadow.getIWorld().getLint()).cantFindType.signal(new String[] { WeaverMessages.format("cftArgType", argType
/* 159 */                   .getName()) }shadow.getSourceLocation(), new ISourceLocation[] {
/* 160 */                 getSourceLocation()
/*     */               });
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 166 */         ResolvedType rAnnType = ap.getAnnotationType().resolve(shadow.getIWorld());
/* 167 */         if (ap instanceof BindingAnnotationTypePattern) {
/* 168 */           BindingAnnotationTypePattern btp = (BindingAnnotationTypePattern)ap;
/* 169 */           Var annvar = shadow.getArgAnnotationVar(argsIndex, (UnresolvedType)rAnnType);
/* 170 */           state.set(btp.getFormalIndex(), annvar);
/*     */         } 
/* 172 */         if (!ap.matches((AnnotatedElement)rArgType).alwaysTrue())
/*     */         {
/* 174 */           test = Test.makeAnd((Test)literal, Test.makeHasAnnotation(shadow.getArgVar(argsIndex), rAnnType));
/*     */         }
/* 176 */         argsIndex++;
/*     */       } 
/*     */     } 
/* 179 */     return test;
/*     */   }
/*     */   
/*     */   public List<BindingPattern> getBindingAnnotationTypePatterns() {
/* 183 */     List<BindingPattern> l = new ArrayList<>();
/* 184 */     AnnotationTypePattern[] pats = this.arguments.getAnnotationPatterns();
/* 185 */     for (AnnotationTypePattern pat : pats) {
/* 186 */       if (pat instanceof BindingAnnotationTypePattern) {
/* 187 */         l.add((BindingPattern)pat);
/*     */       }
/*     */     } 
/* 190 */     return l;
/*     */   }
/*     */   
/*     */   public List<BindingTypePattern> getBindingTypePatterns() {
/* 194 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 198 */     s.writeByte(21);
/* 199 */     this.arguments.write(s);
/* 200 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 204 */     AnnotationPatternList annotationPatternList = AnnotationPatternList.read(s, context);
/* 205 */     ArgsAnnotationPointcut ret = new ArgsAnnotationPointcut(annotationPatternList);
/* 206 */     ret.readLocation(context, (DataInputStream)s);
/* 207 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 216 */     if (!(obj instanceof ArgsAnnotationPointcut)) {
/* 217 */       return false;
/*     */     }
/* 219 */     ArgsAnnotationPointcut other = (ArgsAnnotationPointcut)obj;
/* 220 */     return other.arguments.equals(this.arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 229 */     return 17 + 37 * this.arguments.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildDeclarationText() {
/* 238 */     StringBuilder buf = new StringBuilder("@args");
/* 239 */     buf.append(this.arguments.toString());
/* 240 */     this.declarationText = buf.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 244 */     return this.declarationText;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 248 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 253 */     Object ret = accept(visitor, data);
/* 254 */     if (this.arguments != null)
/* 255 */       this.arguments.traverse(visitor, ret); 
/* 256 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ArgsAnnotationPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */