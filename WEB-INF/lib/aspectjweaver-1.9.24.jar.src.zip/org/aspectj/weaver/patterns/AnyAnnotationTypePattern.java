/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.aspectj.util.FuzzyBoolean;
/*    */ import org.aspectj.weaver.AnnotatedElement;
/*    */ import org.aspectj.weaver.CompressingDataOutputStream;
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.UnresolvedType;
/*    */ import org.aspectj.weaver.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnyAnnotationTypePattern
/*    */   extends AnnotationTypePattern
/*    */ {
/*    */   public FuzzyBoolean fastMatches(AnnotatedElement annotated) {
/* 28 */     return FuzzyBoolean.YES;
/*    */   }
/*    */ 
/*    */   
/*    */   public FuzzyBoolean matches(AnnotatedElement annotated) {
/* 33 */     return FuzzyBoolean.YES;
/*    */   }
/*    */ 
/*    */   
/*    */   public FuzzyBoolean matches(AnnotatedElement annotated, ResolvedType[] parameterAnnotations) {
/* 38 */     return FuzzyBoolean.YES;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(CompressingDataOutputStream s) throws IOException {
/* 43 */     s.writeByte(7);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void resolve(World world) {}
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return "@ANY";
/*    */   }
/*    */ 
/*    */   
/*    */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 57 */     return visitor.visit(this, data);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAny() {
/* 62 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationTypePattern parameterizeWith(Map<String, UnresolvedType> arg0, World w) {
/* 67 */     return this;
/*    */   }
/*    */   
/*    */   public void setForParameterAnnotationMatch() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AnyAnnotationTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */