/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndAnnotationTypePattern
/*     */   extends AnnotationTypePattern
/*     */ {
/*     */   private AnnotationTypePattern left;
/*     */   private AnnotationTypePattern right;
/*     */   
/*     */   public AndAnnotationTypePattern(AnnotationTypePattern left, AnnotationTypePattern right) {
/*  37 */     this.left = left;
/*  38 */     this.right = right;
/*  39 */     setLocation(left.getSourceContext(), left.getStart(), right.getEnd());
/*     */   }
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated) {
/*  43 */     return this.left.matches(annotated).and(this.right.matches(annotated));
/*     */   }
/*     */   
/*     */   public FuzzyBoolean matches(AnnotatedElement annotated, ResolvedType[] parameterAnnotations) {
/*  47 */     return this.left.matches(annotated, parameterAnnotations).and(this.right.matches(annotated, parameterAnnotations));
/*     */   }
/*     */   
/*     */   public void resolve(World world) {
/*  51 */     this.left.resolve(world);
/*  52 */     this.right.resolve(world);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding) {
/*  62 */     this.left = this.left.resolveBindings(scope, bindings, allowBinding);
/*  63 */     this.right = this.right.resolveBindings(scope, bindings, allowBinding);
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  68 */     AnnotationTypePattern newLeft = this.left.parameterizeWith(typeVariableMap, w);
/*  69 */     AnnotationTypePattern newRight = this.right.parameterizeWith(typeVariableMap, w);
/*  70 */     AndAnnotationTypePattern ret = new AndAnnotationTypePattern(newLeft, newRight);
/*  71 */     ret.copyLocationFrom(this);
/*  72 */     if (isForParameterAnnotationMatch()) {
/*  73 */       ret.setForParameterAnnotationMatch();
/*     */     }
/*  75 */     return ret;
/*     */   }
/*     */   
/*     */   public static AnnotationTypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  79 */     AnnotationTypePattern p = new AndAnnotationTypePattern(AnnotationTypePattern.read(s, context), AnnotationTypePattern.read(s, context));
/*     */     
/*  81 */     p.readLocation(context, (DataInputStream)s);
/*  82 */     if (s.getMajorVersion() >= 4 && 
/*  83 */       s.readBoolean()) {
/*  84 */       p.setForParameterAnnotationMatch();
/*     */     }
/*     */     
/*  87 */     return p;
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  91 */     s.writeByte(5);
/*  92 */     this.left.write(s);
/*  93 */     this.right.write(s);
/*  94 */     writeLocation((DataOutputStream)s);
/*  95 */     s.writeBoolean(isForParameterAnnotationMatch());
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  99 */     if (!(obj instanceof AndAnnotationTypePattern)) {
/* 100 */       return false;
/*     */     }
/* 102 */     AndAnnotationTypePattern other = (AndAnnotationTypePattern)obj;
/* 103 */     return (this.left.equals(other.left) && this.right.equals(other.right) && this.left.isForParameterAnnotationMatch() == this.right
/* 104 */       .isForParameterAnnotationMatch());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 108 */     int result = 17;
/* 109 */     result = result * 37 + this.left.hashCode();
/* 110 */     result = result * 37 + this.right.hashCode();
/* 111 */     result = result * 37 + (isForParameterAnnotationMatch() ? 0 : 1);
/* 112 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 116 */     return this.left.toString() + " " + this.right.toString();
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern getLeft() {
/* 120 */     return this.left;
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern getRight() {
/* 124 */     return this.right;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 128 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 132 */     Object ret = accept(visitor, data);
/* 133 */     if (this.left != null)
/* 134 */       this.left.traverse(visitor, ret); 
/* 135 */     if (this.right != null)
/* 136 */       this.right.traverse(visitor, ret); 
/* 137 */     return ret;
/*     */   }
/*     */   
/*     */   public void setForParameterAnnotationMatch() {
/* 141 */     this.left.setForParameterAnnotationMatch();
/* 142 */     this.right.setForParameterAnnotationMatch();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AndAnnotationTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */