/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.ShadowMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KindedPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   Shadow.Kind kind;
/*     */   private SignaturePattern signature;
/*     */   private int matchKinds;
/*  45 */   private ShadowMunger munger = null;
/*     */   
/*     */   public KindedPointcut(Shadow.Kind kind, SignaturePattern signature) {
/*  48 */     this.kind = kind;
/*  49 */     this.signature = signature;
/*  50 */     this.pointcutKind = 1;
/*  51 */     this.matchKinds = kind.bit;
/*     */   }
/*     */   
/*     */   public KindedPointcut(Shadow.Kind kind, SignaturePattern signature, ShadowMunger munger) {
/*  55 */     this(kind, signature);
/*  56 */     this.munger = munger;
/*     */   }
/*     */   
/*     */   public SignaturePattern getSignature() {
/*  60 */     return this.signature;
/*     */   }
/*     */ 
/*     */   
/*     */   public int couldMatchKinds() {
/*  65 */     return this.matchKinds;
/*     */   }
/*     */   
/*     */   public boolean couldEverMatchSameJoinPointsAs(KindedPointcut other) {
/*  69 */     if (this.kind != other.kind) {
/*  70 */       return false;
/*     */     }
/*  72 */     String myName = this.signature.getName().maybeGetSimpleName();
/*  73 */     String yourName = other.signature.getName().maybeGetSimpleName();
/*  74 */     if (myName != null && yourName != null && 
/*  75 */       !myName.equals(yourName)) {
/*  76 */       return false;
/*     */     }
/*     */     
/*  79 */     if ((this.signature.getParameterTypes()).ellipsisCount == 0 && 
/*  80 */       (other.signature.getParameterTypes()).ellipsisCount == 0 && (
/*  81 */       this.signature.getParameterTypes().getTypePatterns()).length != (other.signature.getParameterTypes().getTypePatterns()).length) {
/*  82 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo info) {
/*  92 */     if (info.getKind() != null && 
/*  93 */       info.getKind() != this.kind) {
/*  94 */       return FuzzyBoolean.NO;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (info.world.optimizedMatching)
/*     */     {
/*     */       
/* 106 */       if ((this.kind == Shadow.MethodExecution || this.kind == Shadow.Initialization) && info.getKind() == null) {
/* 107 */         boolean fastMatchingOnAspect = info.getType().isAspect();
/*     */ 
/*     */ 
/*     */         
/* 111 */         if (fastMatchingOnAspect) {
/* 112 */           return FuzzyBoolean.MAYBE;
/*     */         }
/*     */         
/* 115 */         if (getSignature().isExactDeclaringTypePattern()) {
/* 116 */           ExactTypePattern typePattern = (ExactTypePattern)getSignature().getDeclaringType();
/*     */           
/* 118 */           ResolvedType patternExactType = typePattern.getResolvedExactType(info.world);
/* 119 */           if (patternExactType.isInterface()) {
/* 120 */             ResolvedType curr = info.getType();
/* 121 */             Iterator<ResolvedType> hierarchyWalker = curr.getHierarchy(true, true);
/* 122 */             boolean found = false;
/* 123 */             while (hierarchyWalker.hasNext()) {
/* 124 */               curr = hierarchyWalker.next();
/* 125 */               if (typePattern.matchesStatically(curr)) {
/* 126 */                 found = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 130 */             if (!found) {
/* 131 */               return FuzzyBoolean.NO;
/*     */             }
/* 133 */           } else if (patternExactType.isClass()) {
/* 134 */             ResolvedType curr = info.getType();
/*     */             
/* 136 */             while (!typePattern.matchesStatically(curr))
/*     */             
/*     */             { 
/* 139 */               curr = curr.getSuperclass();
/* 140 */               if (curr == null)
/* 141 */                 break;  }  if (curr == null) {
/* 142 */               return FuzzyBoolean.NO;
/*     */             }
/*     */           } 
/* 145 */         } else if (getSignature().getDeclaringType() instanceof AnyWithAnnotationTypePattern) {
/*     */           
/* 147 */           ResolvedType type = info.getType();
/*     */           
/* 149 */           AnnotationTypePattern annotationTypePattern = ((AnyWithAnnotationTypePattern)getSignature().getDeclaringType()).getAnnotationPattern();
/* 150 */           if (annotationTypePattern instanceof ExactAnnotationTypePattern) {
/* 151 */             ExactAnnotationTypePattern exactAnnotationTypePattern = (ExactAnnotationTypePattern)annotationTypePattern;
/* 152 */             if (exactAnnotationTypePattern.getAnnotationValues() == null || exactAnnotationTypePattern
/* 153 */               .getAnnotationValues().size() == 0) {
/* 154 */               ResolvedType annotationType = exactAnnotationTypePattern.getAnnotationType().resolve(info.world);
/* 155 */               if (type.hasAnnotation((UnresolvedType)annotationType)) {
/* 156 */                 return FuzzyBoolean.MAYBE;
/*     */               }
/* 158 */               if (annotationType.isInheritedAnnotation()) {
/*     */                 
/* 160 */                 ResolvedType toMatchAgainst = type.getSuperclass();
/* 161 */                 boolean found = false;
/* 162 */                 while (toMatchAgainst != null) {
/* 163 */                   if (toMatchAgainst.hasAnnotation((UnresolvedType)annotationType)) {
/* 164 */                     found = true;
/*     */                     break;
/*     */                   } 
/* 167 */                   toMatchAgainst = toMatchAgainst.getSuperclass();
/*     */                 } 
/* 169 */                 if (!found) {
/* 170 */                   return FuzzyBoolean.NO;
/*     */                 }
/*     */               } else {
/* 173 */                 return FuzzyBoolean.NO;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/* 191 */     if (shadow.getKind() != this.kind) {
/* 192 */       return FuzzyBoolean.NO;
/*     */     }
/*     */     
/* 195 */     if (shadow.getKind() == Shadow.SynchronizationLock && this.kind == Shadow.SynchronizationLock) {
/* 196 */       return FuzzyBoolean.YES;
/*     */     }
/* 198 */     if (shadow.getKind() == Shadow.SynchronizationUnlock && this.kind == Shadow.SynchronizationUnlock) {
/* 199 */       return FuzzyBoolean.YES;
/*     */     }
/*     */     
/* 202 */     if (!this.signature.matches(shadow.getMatchingSignature(), shadow.getIWorld(), (this.kind == Shadow.MethodCall))) {
/*     */       
/* 204 */       if (this.kind == Shadow.MethodCall) {
/* 205 */         warnOnConfusingSig(shadow);
/*     */       }
/*     */       
/* 208 */       return FuzzyBoolean.NO;
/*     */     } 
/*     */     
/* 211 */     return FuzzyBoolean.YES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void warnOnConfusingSig(Shadow shadow) {
/* 229 */     if (!(shadow.getIWorld().getLint()).unmatchedSuperTypeInCall.isEnabled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 234 */     if (this.munger instanceof org.aspectj.weaver.Checker) {
/*     */       return;
/*     */     }
/*     */     
/* 238 */     World world = shadow.getIWorld();
/*     */ 
/*     */     
/* 241 */     UnresolvedType exactDeclaringType = this.signature.getDeclaringType().getExactType();
/*     */     
/* 243 */     ResolvedType shadowDeclaringType = shadow.getSignature().getDeclaringType().resolve(world);
/*     */     
/* 245 */     if (this.signature.getDeclaringType().isStar() || ResolvedType.isMissing(exactDeclaringType) || exactDeclaringType
/* 246 */       .resolve(world).isMissing()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 251 */     if (!shadowDeclaringType.isAssignableFrom(exactDeclaringType.resolve(world))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 257 */     ResolvedMember rm = shadow.getSignature().resolve(world);
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (rm == null) {
/*     */       return;
/*     */     }
/*     */     
/* 265 */     int shadowModifiers = rm.getModifiers();
/* 266 */     if (!ResolvedType.isVisible(shadowModifiers, shadowDeclaringType, exactDeclaringType.resolve(world))) {
/*     */       return;
/*     */     }
/*     */     
/* 270 */     if (!this.signature.getReturnType().matchesStatically(shadow.getSignature().getReturnType().resolve(world))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     if (exactDeclaringType.resolve(world).isInterface() && shadowDeclaringType.equals(world.resolve("java.lang.Object"))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 284 */     SignaturePattern nonConfusingPattern = new SignaturePattern(this.signature.getKind(), this.signature.getModifiers(), this.signature.getReturnType(), TypePattern.ANY, this.signature.getName(), this.signature.getParameterTypes(), this.signature.getThrowsPattern(), this.signature.getAnnotationPattern());
/*     */     
/* 286 */     if (nonConfusingPattern.matches(shadow.getSignature(), shadow.getIWorld(), true)) {
/* 287 */       (shadow.getIWorld().getLint()).unmatchedSuperTypeInCall.signal(new String[] { shadow
/* 288 */             .getSignature().getDeclaringType().toString(), this.signature.getDeclaringType().toString()
/* 289 */           }, getSourceLocation(), new ISourceLocation[] { shadow.getSourceLocation() });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 295 */     if (!(other instanceof KindedPointcut)) {
/* 296 */       return false;
/*     */     }
/* 298 */     KindedPointcut o = (KindedPointcut)other;
/* 299 */     return (o.kind == this.kind && o.signature.equals(this.signature));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 304 */     int result = 17;
/* 305 */     result = 37 * result + this.kind.hashCode();
/* 306 */     result = 37 * result + this.signature.hashCode();
/* 307 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 312 */     StringBuilder buf = new StringBuilder();
/* 313 */     buf.append(this.kind.getSimpleName());
/* 314 */     buf.append("(");
/* 315 */     buf.append(this.signature.toString());
/* 316 */     buf.append(")");
/* 317 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void postRead(ResolvedType enclosingType) {
/* 322 */     this.signature.postRead(enclosingType);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 327 */     s.writeByte(1);
/* 328 */     this.kind.write((DataOutputStream)s);
/* 329 */     this.signature.write(s);
/* 330 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 334 */     Shadow.Kind kind = Shadow.Kind.read((DataInputStream)s);
/* 335 */     SignaturePattern sig = SignaturePattern.read(s, context);
/* 336 */     KindedPointcut ret = new KindedPointcut(kind, sig);
/* 337 */     ret.readLocation(context, (DataInputStream)s);
/* 338 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveBindings(IScope scope, Bindings bindings) {
/* 347 */     if (this.kind == Shadow.Initialization);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     this.signature = this.signature.resolveBindings(scope, bindings);
/*     */     
/* 355 */     if (this.kind == Shadow.ConstructorExecution && 
/* 356 */       this.signature.getDeclaringType() != null) {
/* 357 */       World world = scope.getWorld();
/* 358 */       UnresolvedType exactType = this.signature.getDeclaringType().getExactType();
/* 359 */       if (this.signature.getKind() == Member.CONSTRUCTOR && !ResolvedType.isMissing(exactType) && exactType
/* 360 */         .resolve(world).isInterface() && !this.signature.getDeclaringType().isIncludeSubtypes()) {
/* 361 */         (world.getLint()).noInterfaceCtorJoinpoint.signal(exactType.toString(), getSourceLocation());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 367 */     if (this.kind == Shadow.StaticInitialization) {
/* 368 */       HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 369 */       this.signature.getDeclaringType().traverse(visitor, null);
/* 370 */       if (visitor.wellHasItThen()) {
/* 371 */         scope.message(MessageUtil.error(WeaverMessages.format("noStaticInitJPsForParameterizedTypes"), 
/* 372 */               getSourceLocation()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 377 */     if (this.kind == Shadow.FieldGet || this.kind == Shadow.FieldSet) {
/* 378 */       HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 379 */       this.signature.getDeclaringType().traverse(visitor, null);
/* 380 */       if (visitor.wellHasItThen()) {
/* 381 */         scope.message(MessageUtil.error(WeaverMessages.format("noParameterizedTypesInGetAndSet"), 
/* 382 */               getSourceLocation()));
/*     */       }
/*     */ 
/*     */       
/* 386 */       UnresolvedType returnType = this.signature.getReturnType().getExactType();
/* 387 */       if (returnType.equals(UnresolvedType.VOID)) {
/* 388 */         scope.message(MessageUtil.error(WeaverMessages.format("fieldCantBeVoid"), 
/* 389 */               getSourceLocation()));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 395 */     if (this.kind == Shadow.Initialization || this.kind == Shadow.PreInitialization) {
/* 396 */       HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 397 */       this.signature.getDeclaringType().traverse(visitor, null);
/* 398 */       if (visitor.wellHasItThen()) {
/* 399 */         scope.message(MessageUtil.error(WeaverMessages.format("noInitJPsForParameterizedTypes"), 
/* 400 */               getSourceLocation()));
/*     */       }
/*     */       
/* 403 */       visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 404 */       this.signature.getThrowsPattern().traverse(visitor, null);
/* 405 */       if (visitor.wellHasItThen()) {
/* 406 */         scope.message(MessageUtil.error(WeaverMessages.format("noGenericThrowables"), getSourceLocation()));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 412 */     if (this.kind == Shadow.MethodExecution || this.kind == Shadow.ConstructorExecution) {
/* 413 */       HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 414 */       this.signature.getDeclaringType().traverse(visitor, null);
/* 415 */       if (visitor.wellHasItThen()) {
/* 416 */         scope.message(MessageUtil.error(
/* 417 */               WeaverMessages.format("noParameterizedDeclaringTypesInExecution"), 
/* 418 */               getSourceLocation()));
/*     */       }
/*     */       
/* 421 */       visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 422 */       this.signature.getThrowsPattern().traverse(visitor, null);
/* 423 */       if (visitor.wellHasItThen()) {
/* 424 */         scope.message(MessageUtil.error(WeaverMessages.format("noGenericThrowables"), getSourceLocation()));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 430 */     if (this.kind == Shadow.MethodCall || this.kind == Shadow.ConstructorCall) {
/* 431 */       HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 432 */       this.signature.getDeclaringType().traverse(visitor, null);
/* 433 */       if (visitor.wellHasItThen()) {
/* 434 */         scope.message(MessageUtil.error(
/* 435 */               WeaverMessages.format("noParameterizedDeclaringTypesInCall"), 
/* 436 */               getSourceLocation()));
/*     */       }
/*     */       
/* 439 */       visitor = new HasThisTypePatternTriedToSneakInSomeGenericOrParameterizedTypePatternMatchingStuffAnywhereVisitor();
/* 440 */       this.signature.getThrowsPattern().traverse(visitor, null);
/* 441 */       if (visitor.wellHasItThen()) {
/* 442 */         scope.message(MessageUtil.error(WeaverMessages.format("noGenericThrowables"), getSourceLocation()));
/*     */       }
/* 444 */       if (!scope.getWorld().isJoinpointArrayConstructionEnabled() && this.kind == Shadow.ConstructorCall && this.signature
/* 445 */         .getDeclaringType().isArray()) {
/* 446 */         scope.message(MessageUtil.warn(WeaverMessages.format("noNewArrayJoinpointsByDefault"), 
/* 447 */               getSourceLocation()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 454 */     return match(shadow).alwaysTrue() ? (Test)Literal.TRUE : (Test)Literal.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 459 */     Pointcut ret = new KindedPointcut(this.kind, this.signature, bindings.getEnclosingAdvice());
/* 460 */     ret.copyLocationFrom(this);
/* 461 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 466 */     Pointcut ret = new KindedPointcut(this.kind, this.signature.parameterizeWith(typeVariableMap, w), this.munger);
/* 467 */     ret.copyLocationFrom(this);
/* 468 */     return ret;
/*     */   }
/*     */   
/*     */   public Shadow.Kind getKind() {
/* 472 */     return this.kind;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 477 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 482 */     Object ret = accept(visitor, data);
/* 483 */     if (this.signature != null)
/* 484 */       this.signature.traverse(visitor, ret); 
/* 485 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\KindedPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */