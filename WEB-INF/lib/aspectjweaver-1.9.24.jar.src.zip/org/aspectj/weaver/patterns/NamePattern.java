/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamePattern
/*     */   extends PatternNode
/*     */ {
/*     */   char[] pattern;
/*  22 */   int starCount = 0;
/*  23 */   private int hashcode = -1;
/*     */   
/*  25 */   public static final NamePattern ELLIPSIS = new NamePattern("");
/*  26 */   public static final NamePattern ANY = new NamePattern("*");
/*     */   
/*     */   public NamePattern(String name) {
/*  29 */     this(name.toCharArray());
/*     */   }
/*     */   
/*     */   public NamePattern(char[] pattern) {
/*  33 */     this.pattern = pattern;
/*     */     
/*  35 */     for (char c : pattern) {
/*  36 */       if (c == '*') {
/*  37 */         this.starCount++;
/*     */       }
/*     */     } 
/*  40 */     this.hashcode = (new String(pattern)).hashCode();
/*     */   }
/*     */   
/*     */   public boolean matches(char[] a2) {
/*  44 */     char[] a1 = this.pattern;
/*  45 */     int len1 = a1.length;
/*  46 */     int len2 = a2.length;
/*  47 */     if (this.starCount == 0) {
/*  48 */       if (len1 != len2) {
/*  49 */         return false;
/*     */       }
/*  51 */       for (int i = 0; i < len1; i++) {
/*  52 */         if (a1[i] != a2[i]) {
/*  53 */           return false;
/*     */         }
/*     */       } 
/*  56 */       return true;
/*  57 */     }  if (this.starCount == 1) {
/*     */       
/*  59 */       if (len1 == 1) {
/*  60 */         return true;
/*     */       }
/*  62 */       if (len1 > len2 + 1) {
/*  63 */         return false;
/*     */       }
/*  65 */       int i2 = 0;
/*  66 */       for (int i1 = 0; i1 < len1; i1++) {
/*  67 */         char c1 = a1[i1];
/*  68 */         if (c1 == '*') {
/*  69 */           i2 = len2 - len1 - i1 + 1;
/*  70 */         } else if (c1 != a2[i2++]) {
/*  71 */           return false;
/*     */         } 
/*     */       } 
/*  74 */       return true;
/*     */     } 
/*     */     
/*  77 */     boolean b = outOfStar(a1, a2, 0, 0, len1 - this.starCount, len2, this.starCount);
/*     */     
/*  79 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean outOfStar(char[] pattern, char[] target, int pi, int ti, int pLeft, int tLeft, int starsLeft) {
/*  85 */     if (pLeft > tLeft) {
/*  86 */       return false;
/*     */     }
/*     */     
/*     */     while (true) {
/*  90 */       if (tLeft == 0) {
/*  91 */         return true;
/*     */       }
/*  93 */       if (pLeft == 0) {
/*  94 */         return (starsLeft > 0);
/*     */       }
/*  96 */       if (pattern[pi] == '*') {
/*  97 */         return inStar(pattern, target, pi + 1, ti, pLeft, tLeft, starsLeft - 1);
/*     */       }
/*  99 */       if (target[ti] != pattern[pi]) {
/* 100 */         return false;
/*     */       }
/* 102 */       pi++;
/* 103 */       ti++;
/* 104 */       pLeft--;
/* 105 */       tLeft--;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean inStar(char[] pattern, char[] target, int pi, int ti, int pLeft, int tLeft, int starsLeft) {
/* 112 */     char patternChar = pattern[pi];
/* 113 */     while (patternChar == '*') {
/* 114 */       starsLeft--;
/* 115 */       patternChar = pattern[++pi];
/*     */     } 
/*     */     
/*     */     while (true) {
/* 119 */       if (pLeft > tLeft) {
/* 120 */         return false;
/*     */       }
/* 122 */       if (target[ti] == patternChar && 
/* 123 */         outOfStar(pattern, target, pi + 1, ti + 1, pLeft - 1, tLeft - 1, starsLeft)) {
/* 124 */         return true;
/*     */       }
/*     */       
/* 127 */       ti++;
/* 128 */       tLeft--;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean matches(String other) {
/* 133 */     if (this.starCount == 1 && this.pattern.length == 1)
/*     */     {
/* 135 */       return true;
/*     */     }
/* 137 */     return matches(other.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 142 */     return new String(this.pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 147 */     if (other instanceof NamePattern) {
/* 148 */       NamePattern otherPat = (NamePattern)other;
/* 149 */       if (otherPat.starCount != this.starCount) {
/* 150 */         return false;
/*     */       }
/* 152 */       if (otherPat.pattern.length != this.pattern.length) {
/* 153 */         return false;
/*     */       }
/* 155 */       for (int i = 0; i < this.pattern.length; i++) {
/* 156 */         if (this.pattern[i] != otherPat.pattern[i]) {
/* 157 */           return false;
/*     */         }
/*     */       } 
/* 160 */       return true;
/*     */     } 
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 167 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream out) throws IOException {
/* 172 */     out.writeUTF(new String(this.pattern));
/*     */   }
/*     */   
/*     */   public static NamePattern read(VersionedDataInputStream in) throws IOException {
/* 176 */     String s = in.readUTF();
/* 177 */     if (s.length() == 0) {
/* 178 */       return ELLIPSIS;
/*     */     }
/* 180 */     return new NamePattern(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String maybeGetSimpleName() {
/* 189 */     if (this.starCount == 0 && this.pattern.length > 0) {
/* 190 */       return new String(this.pattern);
/*     */     }
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAny() {
/* 201 */     return (this.starCount == 1 && this.pattern.length == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 206 */     return visitor.visit(this, data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\NamePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */