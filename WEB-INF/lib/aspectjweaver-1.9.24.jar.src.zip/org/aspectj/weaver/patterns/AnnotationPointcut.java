/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.AjcMemberMaker;
/*     */ import org.aspectj.weaver.AnnotatedElement;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ConcreteTypeMunger;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.ShadowMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationPointcut
/*     */   extends NameBindingPointcut
/*     */ {
/*     */   private ExactAnnotationTypePattern annotationTypePattern;
/*     */   private String declarationText;
/*     */   
/*     */   public AnnotationPointcut(ExactAnnotationTypePattern type) {
/*  70 */     this.annotationTypePattern = type;
/*  71 */     this.pointcutKind = 16;
/*  72 */     buildDeclarationText();
/*     */   }
/*     */   
/*     */   public AnnotationPointcut(ExactAnnotationTypePattern type, ShadowMunger munger) {
/*  76 */     this(type);
/*  77 */     buildDeclarationText();
/*     */   }
/*     */   
/*     */   public ExactAnnotationTypePattern getAnnotationTypePattern() {
/*  81 */     return this.annotationTypePattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public int couldMatchKinds() {
/*  86 */     return Shadow.ALL_SHADOW_KINDS_BITS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/*  91 */     AnnotationPointcut ret = new AnnotationPointcut((ExactAnnotationTypePattern)this.annotationTypePattern.parameterizeWith(typeVariableMap, w));
/*     */     
/*  93 */     ret.copyLocationFrom(this);
/*  94 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo info) {
/* 104 */     if (info.getKind() == Shadow.StaticInitialization) {
/* 105 */       return this.annotationTypePattern.fastMatches((AnnotatedElement)info.getType());
/*     */     }
/* 107 */     return FuzzyBoolean.MAYBE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/*     */     ResolvedMember resolvedMember1;
/* 118 */     AnnotatedElement toMatchAgainst = null;
/* 119 */     Member member = shadow.getSignature();
/* 120 */     ResolvedMember rMember = member.resolve(shadow.getIWorld());
/*     */     
/* 122 */     if (rMember == null) {
/* 123 */       if (member.getName().startsWith("ajc$")) {
/* 124 */         return FuzzyBoolean.NO;
/*     */       }
/* 126 */       (shadow.getIWorld().getLint()).unresolvableMember.signal(member.toString(), getSourceLocation());
/* 127 */       return FuzzyBoolean.NO;
/*     */     } 
/*     */     
/* 130 */     Shadow.Kind kind = shadow.getKind();
/* 131 */     if (kind == Shadow.StaticInitialization) {
/* 132 */       ResolvedType resolvedType = rMember.getDeclaringType().resolve(shadow.getIWorld());
/* 133 */     } else if (kind == Shadow.ExceptionHandler) {
/* 134 */       ResolvedType resolvedType = rMember.getParameterTypes()[0].resolve(shadow.getIWorld());
/*     */     } else {
/* 136 */       resolvedMember1 = rMember;
/*     */ 
/*     */       
/* 139 */       if (rMember.isAnnotatedElsewhere() && (
/* 140 */         kind == Shadow.FieldGet || kind == Shadow.FieldSet)) {
/*     */         
/* 142 */         List<ConcreteTypeMunger> mungers = rMember.getDeclaringType().resolve(shadow.getIWorld()).getInterTypeMungers();
/* 143 */         for (ConcreteTypeMunger typeMunger : mungers) {
/* 144 */           if (typeMunger.getMunger() instanceof org.aspectj.weaver.NewFieldTypeMunger) {
/* 145 */             ResolvedMember fakerm = typeMunger.getSignature();
/* 146 */             if (fakerm.equals(member)) {
/* 147 */               ResolvedMember ajcMethod = AjcMemberMaker.interFieldInitializer(fakerm, (UnresolvedType)typeMunger.getAspectType());
/* 148 */               ResolvedMember rmm = findMethod(typeMunger.getAspectType(), ajcMethod);
/* 149 */               resolvedMember1 = rmm;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 157 */     this.annotationTypePattern.resolve(shadow.getIWorld());
/* 158 */     return this.annotationTypePattern.matches((AnnotatedElement)resolvedMember1);
/*     */   }
/*     */   
/*     */   private ResolvedMember findMethod(ResolvedType aspectType, ResolvedMember ajcMethod) {
/* 162 */     ResolvedMember[] decMethods = aspectType.getDeclaredMethods();
/* 163 */     for (ResolvedMember member : decMethods) {
/* 164 */       if (member.equals(ajcMethod)) {
/* 165 */         return member;
/*     */       }
/*     */     } 
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resolveBindings(IScope scope, Bindings bindings) {
/* 179 */     if (!scope.getWorld().isInJava5Mode()) {
/* 180 */       scope.message(MessageUtil.error(WeaverMessages.format("atannotationNeedsJava5"), 
/* 181 */             getSourceLocation()));
/*     */       return;
/*     */     } 
/* 184 */     this.annotationTypePattern = (ExactAnnotationTypePattern)this.annotationTypePattern.resolveBindings(scope, bindings, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 195 */     ExactAnnotationTypePattern newType = (ExactAnnotationTypePattern)this.annotationTypePattern.remapAdviceFormals(bindings);
/* 196 */     Pointcut ret = new AnnotationPointcut(newType, bindings.getEnclosingAdvice());
/* 197 */     ret.copyLocationFrom(this);
/* 198 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 203 */     if (this.annotationTypePattern instanceof BindingAnnotationFieldTypePattern) {
/* 204 */       if (shadow.getKind() != Shadow.MethodExecution) {
/* 205 */         shadow.getIWorld()
/* 206 */           .getMessageHandler()
/* 207 */           .handleMessage(
/*     */             
/* 209 */             MessageUtil.error("Annotation field binding is only supported at method-execution join points (compiler limitation)", 
/* 210 */               getSourceLocation()));
/* 211 */         return (Test)Literal.TRUE;
/*     */       } 
/* 213 */       BindingAnnotationFieldTypePattern btp = (BindingAnnotationFieldTypePattern)this.annotationTypePattern;
/* 214 */       ResolvedType formalType = btp.getFormalType().resolve(shadow.getIWorld());
/* 215 */       UnresolvedType annoType = btp.getAnnotationType();
/*     */ 
/*     */       
/* 218 */       Var var = shadow.getKindedAnnotationVar(annoType);
/* 219 */       if (var == null) {
/* 220 */         throw new BCException("Unexpected problem locating annotation at join point '" + shadow + "'");
/*     */       }
/* 222 */       state.set(btp.getFormalIndex(), var.getAccessorForValue(formalType, btp.formalName));
/* 223 */     } else if (this.annotationTypePattern instanceof BindingAnnotationTypePattern) {
/* 224 */       BindingAnnotationTypePattern btp = (BindingAnnotationTypePattern)this.annotationTypePattern;
/* 225 */       UnresolvedType annotationType = btp.getAnnotationType();
/* 226 */       Var var = shadow.getKindedAnnotationVar(annotationType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (var == null) {
/* 240 */         if (matchInternal(shadow).alwaysTrue()) {
/* 241 */           return (Test)Literal.TRUE;
/*     */         }
/* 243 */         return (Test)Literal.FALSE;
/*     */       } 
/*     */       
/* 246 */       state.set(btp.getFormalIndex(), var);
/*     */     } 
/*     */     
/* 249 */     if (matchInternal(shadow).alwaysTrue()) {
/* 250 */       return (Test)Literal.TRUE;
/*     */     }
/* 252 */     return (Test)Literal.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BindingPattern> getBindingAnnotationTypePatterns() {
/* 263 */     if (this.annotationTypePattern instanceof BindingPattern) {
/* 264 */       List<BindingPattern> l = new ArrayList<>();
/* 265 */       l.add((BindingPattern)this.annotationTypePattern);
/* 266 */       return l;
/*     */     } 
/* 268 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BindingTypePattern> getBindingTypePatterns() {
/* 279 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 289 */     s.writeByte(16);
/* 290 */     this.annotationTypePattern.write(s);
/* 291 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 295 */     AnnotationTypePattern type = AnnotationTypePattern.read(s, context);
/* 296 */     AnnotationPointcut ret = new AnnotationPointcut((ExactAnnotationTypePattern)type);
/* 297 */     ret.readLocation(context, (DataInputStream)s);
/* 298 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 303 */     if (!(other instanceof AnnotationPointcut)) {
/* 304 */       return false;
/*     */     }
/* 306 */     AnnotationPointcut o = (AnnotationPointcut)other;
/* 307 */     return o.annotationTypePattern.equals(this.annotationTypePattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 312 */     int result = 17;
/* 313 */     result = 37 * result + this.annotationTypePattern.hashCode();
/* 314 */     return result;
/*     */   }
/*     */   
/*     */   public void buildDeclarationText() {
/* 318 */     StringBuilder buf = new StringBuilder();
/* 319 */     buf.append("@annotation(");
/* 320 */     String annPatt = this.annotationTypePattern.toString();
/* 321 */     buf.append(annPatt.startsWith("@") ? annPatt.substring(1) : annPatt);
/* 322 */     buf.append(")");
/* 323 */     this.declarationText = buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 328 */     return this.declarationText;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 333 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 338 */     Object ret = accept(visitor, data);
/* 339 */     if (this.annotationTypePattern != null)
/* 340 */       this.annotationTypePattern.traverse(visitor, ret); 
/* 341 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\AnnotationPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */