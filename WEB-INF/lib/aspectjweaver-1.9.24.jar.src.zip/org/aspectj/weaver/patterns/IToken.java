/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import org.aspectj.weaver.IHasPosition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IToken
/*    */   extends IHasPosition
/*    */ {
/* 19 */   public static final IToken EOF = BasicToken.makeOperator("<eof>", 0, 0);
/*    */   
/*    */   String getString();
/*    */   
/*    */   boolean isIdentifier();
/*    */   
/*    */   String getLiteralKind();
/*    */   
/*    */   Pointcut maybeGetParsedPointcut();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\IToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */