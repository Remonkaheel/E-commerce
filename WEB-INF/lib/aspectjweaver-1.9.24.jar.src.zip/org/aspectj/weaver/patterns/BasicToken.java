/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BasicToken
/*    */   implements IToken
/*    */ {
/*    */   private String value;
/*    */   private boolean isIdentifier;
/*    */   private String literalKind;
/*    */   private int start;
/*    */   private int end;
/*    */   
/*    */   public static BasicToken makeOperator(String value, int start, int end) {
/* 26 */     return new BasicToken(value.intern(), false, null, start, end);
/*    */   }
/*    */   
/*    */   public static BasicToken makeIdentifier(String value, int start, int end) {
/* 30 */     return new BasicToken(value, true, null, start, end);
/*    */   }
/*    */   
/*    */   public static BasicToken makeLiteral(String value, String kind, int start, int end) {
/* 34 */     return new BasicToken(value, false, kind.intern(), start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   private BasicToken(String value, boolean isIdentifier, String literalKind, int start, int end) {
/* 39 */     this.value = value;
/* 40 */     this.isIdentifier = isIdentifier;
/* 41 */     this.literalKind = literalKind;
/* 42 */     this.start = start;
/* 43 */     this.end = end;
/*    */   }
/*    */   
/* 46 */   public int getStart() { return this.start; }
/* 47 */   public int getEnd() { return this.end; } public String getFileName() {
/* 48 */     return "unknown";
/*    */   }
/*    */   public String getString() {
/* 51 */     return this.value;
/*    */   }
/*    */   
/*    */   public boolean isIdentifier() {
/* 55 */     return this.isIdentifier;
/*    */   }
/*    */   
/*    */   public Pointcut maybeGetParsedPointcut() {
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/*    */     String s;
/* 66 */     if (this.isIdentifier) { s = this.value; }
/* 67 */     else { s = "'" + this.value + "'"; }
/*    */     
/* 69 */     return s + "@" + this.start + ":" + this.end;
/*    */   }
/*    */   public String getLiteralKind() {
/* 72 */     return this.literalKind;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\BasicToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */