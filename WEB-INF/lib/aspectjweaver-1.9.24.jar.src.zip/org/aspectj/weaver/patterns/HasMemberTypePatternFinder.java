/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HasMemberTypePatternFinder
/*    */   extends AbstractPatternNodeVisitor
/*    */ {
/*    */   private boolean hasMemberTypePattern = false;
/*    */   
/*    */   public HasMemberTypePatternFinder(TypePattern aPattern) {
/* 23 */     aPattern.traverse(this, null);
/*    */   }
/*    */   
/*    */   public Object visit(HasMemberTypePattern node, Object data) {
/* 27 */     this.hasMemberTypePattern = true;
/* 28 */     return null;
/*    */   }
/*    */   public boolean hasMemberTypePattern() {
/* 31 */     return this.hasMemberTypePattern;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\HasMemberTypePatternFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */