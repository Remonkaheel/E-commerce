/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.Advice;
/*     */ import org.aspectj.weaver.AjcMemberMaker;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedMemberImpl;
/*     */ import org.aspectj.weaver.ResolvedPointcutDefinition;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.ShadowMunger;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Expr;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.ast.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IfPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   public ResolvedMember testMethod;
/*     */   public int extraParameterFlags;
/*     */   private final String enclosingPointcutHint;
/*     */   public Pointcut residueSource;
/*     */   int baseArgsCount;
/*     */   private boolean findingResidue;
/*     */   private int ifLastMatchedShadowId;
/*     */   private Test ifLastMatchedShadowResidue;
/*     */   private IfPointcut partiallyConcretized;
/*     */   
/*     */   public IfPointcut(ResolvedMember testMethod, int extraParameterFlags) {
/* 173 */     this.findingResidue = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     this.partiallyConcretized = null; this.testMethod = testMethod; this.extraParameterFlags = extraParameterFlags; this.pointcutKind = 9; this.enclosingPointcutHint = null; } public IfPointcut(String enclosingPointcutHint) { this.findingResidue = false; this.partiallyConcretized = null; this.pointcutKind = 9; this.enclosingPointcutHint = enclosingPointcutHint; this.testMethod = null; this.extraParameterFlags = -1; } public int couldMatchKinds() { return Shadow.ALL_SHADOW_KINDS_BITS; } public FuzzyBoolean fastMatch(FastMatchInfo type) { return FuzzyBoolean.MAYBE; }
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) { if (this.extraParameterFlags != -1 && (this.extraParameterFlags & 0x10) != 0) { if ((this.extraParameterFlags & 0x20) != 0) return FuzzyBoolean.YES;  return FuzzyBoolean.NO; }  return FuzzyBoolean.MAYBE; }
/*     */   public boolean alwaysFalse() { return false; }
/*     */   public boolean alwaysTrue() { return false; }
/*     */   public Pointcut getResidueSource() { return this.residueSource; }
/*     */   public void write(CompressingDataOutputStream s) throws IOException { s.writeByte(9); s.writeBoolean((this.testMethod != null)); if (this.testMethod != null) this.testMethod.write(s);  s.writeByte(this.extraParameterFlags); writeLocation((DataOutputStream)s); }
/* 366 */   public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) { IfPointcut ret; if (isDeclare(bindings.getEnclosingAdvice())) {
/*     */       
/* 368 */       inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("ifInDeclare"), bindings
/* 369 */           .getEnclosingAdvice().getSourceLocation(), null);
/* 370 */       return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */     } 
/*     */     
/* 373 */     if (this.partiallyConcretized != null) {
/* 374 */       return this.partiallyConcretized;
/*     */     }
/*     */ 
/*     */     
/* 378 */     if (this.extraParameterFlags < 0 && this.testMethod == null) {
/*     */       
/* 380 */       ResolvedPointcutDefinition def = bindings.peekEnclosingDefinition();
/* 381 */       if (def != null) {
/* 382 */         ResolvedType aspect = inAspect.getWorld().resolve(def.getDeclaringType());
/* 383 */         for (Iterator<ResolvedMember> memberIter = aspect.getMethods(true, true); memberIter.hasNext(); ) {
/* 384 */           ResolvedMember method = memberIter.next();
/* 385 */           if (def.getName().equals(method.getName()) && (def
/* 386 */             .getParameterTypes()).length == (method.getParameterTypes()).length) {
/* 387 */             boolean sameSig = true;
/* 388 */             for (int j = 0; j < (method.getParameterTypes()).length; j++) {
/* 389 */               UnresolvedType argJ = method.getParameterTypes()[j];
/* 390 */               if (!argJ.equals(def.getParameterTypes()[j])) {
/* 391 */                 sameSig = false;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 395 */             if (sameSig) {
/* 396 */               this.testMethod = method;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/* 401 */         if (this.testMethod == null) {
/* 402 */           inAspect.getWorld().showMessage(IMessage.ERROR, "Cannot find if() body from '" + def
/* 403 */               .toString() + "' for '" + this.enclosingPointcutHint + "'", 
/* 404 */               getSourceLocation(), null);
/* 405 */           return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */         } 
/*     */       } else {
/* 408 */         this.testMethod = inAspect.getWorld().resolve(bindings.getAdviceSignature());
/*     */       } 
/* 410 */       ret = new IfPointcut(this.enclosingPointcutHint);
/* 411 */       ret.testMethod = this.testMethod;
/*     */     } else {
/* 413 */       ret = new IfPointcut(this.testMethod, this.extraParameterFlags);
/*     */     } 
/* 415 */     ret.copyLocationFrom(this);
/* 416 */     this.partiallyConcretized = ret;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     if (bindings.directlyInAdvice() && bindings.getEnclosingAdvice() == null) {
/*     */ 
/*     */       
/* 426 */       inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("ifInPerClause"), 
/* 427 */           getSourceLocation(), null);
/* 428 */       return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */     } 
/*     */     
/* 431 */     if (bindings.directlyInAdvice()) {
/* 432 */       ShadowMunger advice = bindings.getEnclosingAdvice();
/* 433 */       if (advice instanceof Advice) {
/* 434 */         ret.baseArgsCount = ((Advice)advice).getBaseParameterCount();
/*     */       } else {
/* 436 */         ret.baseArgsCount = 0;
/*     */       } 
/* 438 */       ret.residueSource = advice.getPointcut().concretize(inAspect, inAspect, ret.baseArgsCount, advice);
/*     */     } else {
/* 440 */       ResolvedPointcutDefinition def = bindings.peekEnclosingDefinition();
/* 441 */       if (def == CflowPointcut.CFLOW_MARKER) {
/* 442 */         inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("ifLexicallyInCflow"), 
/* 443 */             getSourceLocation(), null);
/* 444 */         return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */       } 
/* 446 */       ret.baseArgsCount = (def.getParameterTypes()).length;
/*     */ 
/*     */ 
/*     */       
/* 450 */       if (ret.extraParameterFlags < 0) {
/* 451 */         ret.baseArgsCount = 0;
/* 452 */         for (int i = 0; i < (this.testMethod.getParameterTypes()).length; i++) {
/* 453 */           String argSignature = this.testMethod.getParameterTypes()[i].getSignature();
/* 454 */           if (!AjcMemberMaker.TYPEX_JOINPOINT.getSignature().equals(argSignature) && 
/* 455 */             !AjcMemberMaker.TYPEX_PROCEEDINGJOINPOINT.getSignature().equals(argSignature) && 
/* 456 */             !AjcMemberMaker.TYPEX_STATICJOINPOINT.getSignature().equals(argSignature) && 
/* 457 */             !AjcMemberMaker.TYPEX_ENCLOSINGSTATICJOINPOINT.getSignature().equals(argSignature))
/*     */           {
/*     */             
/* 460 */             ret.baseArgsCount++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 465 */       IntMap newBindings = IntMap.idMap(ret.baseArgsCount);
/* 466 */       newBindings.copyContext(bindings);
/* 467 */       ret.residueSource = def.getPointcut().concretize(inAspect, declaringType, newBindings);
/*     */     } 
/*     */     
/* 470 */     return ret; } public static Pointcut read(VersionedDataInputStream s, ISourceContext context) throws IOException { ResolvedMemberImpl resolvedMemberImpl; boolean hasTestMethod = s.readBoolean(); ResolvedMember resolvedTestMethod = null; if (hasTestMethod)
/*     */       resolvedMemberImpl = ResolvedMemberImpl.readResolvedMember(s, context);  IfPointcut ret = new IfPointcut((ResolvedMember)resolvedMemberImpl, s.readByte()); ret.readLocation(context, (DataInputStream)s); return ret; } public void resolveBindings(IScope scope, Bindings bindings) {}
/*     */   public boolean equals(Object other) { if (!(other instanceof IfPointcut))
/*     */       return false;  IfPointcut o = (IfPointcut)other; if (o.testMethod == null)
/*     */       return (this.testMethod == null); 
/*     */     return o.testMethod.equals(this.testMethod); }
/* 476 */   public Pointcut parameterizeWith(Map typeVariableMap, World w) { return this; } public int hashCode() { int result = 17;
/*     */     result = 37 * result + this.testMethod.hashCode();
/*     */     return result; }
/*     */   public String toString() { if (this.extraParameterFlags < 0)
/*     */       return "if()"; 
/*     */     return "if(" + this.testMethod + ")"; }
/* 482 */   public static IfPointcut makeIfFalsePointcut(Pointcut.State state) { IfPointcut ret = new IfFalsePointcut();
/* 483 */     ret.state = state;
/* 484 */     return ret; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 489 */     return visitor.visit(this, data); }
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) { if (this.findingResidue) return (Test)Literal.TRUE;  this.findingResidue = true; try { if (shadow.shadowId == this.ifLastMatchedShadowId) { test = this.ifLastMatchedShadowResidue; return test; }  Literal literal = Literal.TRUE; List<Var> args = new ArrayList<>(); if (this.extraParameterFlags >= 0) { if ((this.extraParameterFlags & 0x10) != 0) { if ((this.extraParameterFlags & 0x20) != 0) { literal = Literal.TRUE; this.ifLastMatchedShadowId = shadow.shadowId; this.ifLastMatchedShadowResidue = (Test)literal; return (Test)literal; }  literal = Literal.FALSE; this.ifLastMatchedShadowId = shadow.shadowId; this.ifLastMatchedShadowResidue = (Test)literal; return (Test)literal; }  if (this.baseArgsCount > 0) { ExposedState myState = new ExposedState(this.baseArgsCount); myState.setConcreteAspect(state.getConcreteAspect()); this.residueSource.findResidue(shadow, myState); UnresolvedType[] pTypes = (this.testMethod == null) ? null : this.testMethod.getParameterTypes(); if (pTypes != null && this.baseArgsCount > pTypes.length) throw new BCException("Unexpected problem with testMethod " + this.testMethod + ": expecting " + this.baseArgsCount + " arguments");  for (int i = 0; i < this.baseArgsCount; i++) { Var v = myState.get(i); if (v != null) { args.add(v); test = Test.makeAnd((Test)literal, Test.makeInstanceof(v, pTypes[i].resolve(shadow.getIWorld()))); }  }  }  if ((this.extraParameterFlags & 0x2) != 0) args.add(shadow.getThisJoinPointVar());  if ((this.extraParameterFlags & 0x4) != 0) args.add(shadow.getThisJoinPointStaticPartVar());  if ((this.extraParameterFlags & 0x8) != 0)
/*     */           args.add(shadow.getThisEnclosingJoinPointStaticPartVar());  if ((this.extraParameterFlags & 0x40) != 0)
/*     */           args.add(shadow.getThisAspectInstanceVar(state.getConcreteAspect()));  } else { int currentStateIndex = 0; for (int i = 0; i < (this.testMethod.getParameterTypes()).length; i++) { String argSignature = this.testMethod.getParameterTypes()[i].getSignature(); if (AjcMemberMaker.TYPEX_JOINPOINT.getSignature().equals(argSignature)) { args.add(shadow.getThisJoinPointVar()); continue; }  if (AjcMemberMaker.TYPEX_PROCEEDINGJOINPOINT.getSignature().equals(argSignature)) { args.add(shadow.getThisJoinPointVar()); continue; }  if (AjcMemberMaker.TYPEX_STATICJOINPOINT.getSignature().equals(argSignature)) { args.add(shadow.getThisJoinPointStaticPartVar()); continue; }  if (AjcMemberMaker.TYPEX_ENCLOSINGSTATICJOINPOINT.getSignature().equals(argSignature)) { args.add(shadow.getThisEnclosingJoinPointStaticPartVar()); continue; }  if (state.size() == 0 || currentStateIndex > state.size()) { String[] paramNames = this.testMethod.getParameterNames(); StringBuilder errorParameter = new StringBuilder(); if (i + 1 == (this.testMethod.getParameterTypes()).length) { ExposedState myState = new ExposedState(this.baseArgsCount); myState.setConcreteAspect(state.getConcreteAspect()); this.residueSource.findResidue(shadow, myState); if (myState.size() == 1) { Var var = myState.get(0); args.add(var); test = Test.makeAnd(test, Test.makeInstanceof(var, this.testMethod.getParameterTypes()[i].resolve(shadow.getIWorld()))); continue; }  }  if (paramNames != null) { errorParameter.append(this.testMethod.getParameterTypes()[i].getName()).append(" "); errorParameter.append(paramNames[i]); shadow.getIWorld().getMessageHandler().handleMessage(MessageUtil.error("Missing binding for if() pointcut method.  Parameter " + (i + 1) + "(" + errorParameter.toString() + ") must be bound - even in reference pointcuts  (compiler limitation)", this.testMethod.getSourceLocation())); } else { shadow.getIWorld().getMessageHandler().handleMessage(MessageUtil.error("Missing binding for if() pointcut method.  Parameter " + (i + 1) + " must be bound - even in reference pointcuts (compiler limitation)", this.testMethod.getSourceLocation())); }  return (Test)Literal.TRUE; }  Var v = state.get(currentStateIndex++); while (v == null && currentStateIndex < state.size())
/*     */             v = state.get(currentStateIndex++);  args.add(v); test = Test.makeAnd(test, Test.makeInstanceof(v, this.testMethod.getParameterTypes()[i].resolve(shadow.getIWorld()))); continue; }  }  Test test = Test.makeAnd(test, Test.makeCall((Member)this.testMethod, args.<Expr>toArray(Expr.NONE))); this.ifLastMatchedShadowId = shadow.shadowId; this.ifLastMatchedShadowResidue = test; return test; } finally { this.findingResidue = false; }  }
/* 494 */   protected boolean shouldCopyLocationForConcretize() { return false; } public Object traverse(PatternNodeVisitor visitor, Object data) { Object ret = accept(visitor, data);
/* 495 */     if (this.partiallyConcretized != null)
/* 496 */       this.partiallyConcretized.traverse(visitor, ret); 
/* 497 */     if (this.residueSource != null)
/* 498 */       this.residueSource.traverse(visitor, ret); 
/* 499 */     return ret; }
/*     */ 
/*     */   
/*     */   public static class IfFalsePointcut
/*     */     extends IfPointcut {
/*     */     public IfFalsePointcut() {
/* 505 */       super((ResolvedMember)null, 0);
/* 506 */       this.pointcutKind = 15;
/*     */     }
/*     */ 
/*     */     
/*     */     public int couldMatchKinds() {
/* 511 */       return Shadow.NO_SHADOW_KINDS_BITS;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean alwaysFalse() {
/* 516 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 521 */       return (Test)Literal.FALSE;
/*     */     }
/*     */ 
/*     */     
/*     */     public FuzzyBoolean fastMatch(FastMatchInfo type) {
/* 526 */       return FuzzyBoolean.NO;
/*     */     }
/*     */ 
/*     */     
/*     */     protected FuzzyBoolean matchInternal(Shadow shadow) {
/* 531 */       return FuzzyBoolean.NO;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void resolveBindings(IScope scope, Bindings bindings) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void postRead(ResolvedType enclosingType) {}
/*     */ 
/*     */     
/*     */     public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 544 */       if (isDeclare(bindings.getEnclosingAdvice())) {
/*     */         
/* 546 */         inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("ifInDeclare"), bindings
/* 547 */             .getEnclosingAdvice().getSourceLocation(), null);
/* 548 */         return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */       } 
/* 550 */       return makeIfFalsePointcut(this.state);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(CompressingDataOutputStream s) throws IOException {
/* 555 */       s.writeByte(15);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 560 */       int result = 17;
/* 561 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 566 */       return "if(false)";
/*     */     }
/*     */   }
/*     */   
/*     */   public static IfPointcut makeIfTruePointcut(Pointcut.State state) {
/* 571 */     IfPointcut ret = new IfTruePointcut();
/* 572 */     ret.state = state;
/* 573 */     return ret;
/*     */   }
/*     */   
/*     */   public static class IfTruePointcut
/*     */     extends IfPointcut {
/*     */     public IfTruePointcut() {
/* 579 */       super((ResolvedMember)null, 0);
/* 580 */       this.pointcutKind = 14;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean alwaysTrue() {
/* 585 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 590 */       return (Test)Literal.TRUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public FuzzyBoolean fastMatch(FastMatchInfo type) {
/* 595 */       return FuzzyBoolean.YES;
/*     */     }
/*     */ 
/*     */     
/*     */     protected FuzzyBoolean matchInternal(Shadow shadow) {
/* 600 */       return FuzzyBoolean.YES;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void resolveBindings(IScope scope, Bindings bindings) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void postRead(ResolvedType enclosingType) {}
/*     */ 
/*     */     
/*     */     public Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 613 */       if (isDeclare(bindings.getEnclosingAdvice())) {
/*     */         
/* 615 */         inAspect.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("ifInDeclare"), bindings
/* 616 */             .getEnclosingAdvice().getSourceLocation(), null);
/* 617 */         return Pointcut.makeMatchesNothing(Pointcut.CONCRETE);
/*     */       } 
/* 619 */       return makeIfTruePointcut(this.state);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(CompressingDataOutputStream s) throws IOException {
/* 624 */       s.writeByte(14);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 629 */       int result = 37;
/* 630 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 635 */       return "if(true)";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlways(boolean matches) {
/* 644 */     this.extraParameterFlags |= 0x10;
/* 645 */     if (matches)
/* 646 */       this.extraParameterFlags |= 0x20; 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\IfPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */