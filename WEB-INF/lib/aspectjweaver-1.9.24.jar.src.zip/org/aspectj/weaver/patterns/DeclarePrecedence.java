/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeclarePrecedence
/*     */   extends Declare
/*     */ {
/*     */   private TypePatternList patterns;
/*  29 */   private IScope scope = null;
/*     */   
/*     */   public DeclarePrecedence(List<TypePattern> patterns) {
/*  32 */     this(new TypePatternList(patterns));
/*     */   }
/*     */   
/*     */   private DeclarePrecedence(TypePatternList patterns) {
/*  36 */     this.patterns = patterns;
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/*  40 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/*  44 */     Object ret = accept(visitor, data);
/*  45 */     if (this.patterns != null)
/*  46 */       this.patterns.traverse(visitor, ret); 
/*  47 */     return ret;
/*     */   }
/*     */   
/*     */   public Declare parameterizeWith(Map<String, UnresolvedType> typeVariableBindingMap, World w) {
/*  51 */     DeclarePrecedence ret = new DeclarePrecedence(this.patterns.parameterizeWith(typeVariableBindingMap, w));
/*  52 */     ret.copyLocationFrom(this);
/*  53 */     return ret;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  57 */     StringBuilder buf = new StringBuilder();
/*  58 */     buf.append("declare precedence: ");
/*  59 */     buf.append(this.patterns);
/*  60 */     buf.append(";");
/*  61 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  65 */     if (!(other instanceof DeclarePrecedence)) {
/*  66 */       return false;
/*     */     }
/*  68 */     DeclarePrecedence o = (DeclarePrecedence)other;
/*  69 */     return o.patterns.equals(this.patterns);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  73 */     return this.patterns.hashCode();
/*     */   }
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  77 */     s.writeByte(4);
/*  78 */     this.patterns.write(s);
/*  79 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/*  83 */     Declare ret = new DeclarePrecedence(TypePatternList.read(s, context));
/*  84 */     ret.readLocation(context, (DataInputStream)s);
/*  85 */     return ret;
/*     */   }
/*     */   
/*     */   public void setScopeForResolution(IScope scope) {
/*  89 */     this.scope = scope;
/*     */   }
/*     */   
/*     */   public void ensureResolved() {
/*  93 */     if (this.scope != null) {
/*     */       try {
/*  95 */         resolve(this.scope);
/*     */       } finally {
/*  97 */         this.scope = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void resolve(IScope scope) {
/* 103 */     this.patterns = this.patterns.resolveBindings(scope, Bindings.NONE, false, false);
/* 104 */     boolean seenStar = false;
/*     */     
/* 106 */     for (int i = 0; i < this.patterns.size(); i++) {
/* 107 */       TypePattern pi = this.patterns.get(i);
/* 108 */       if (pi.isStar()) {
/* 109 */         if (seenStar) {
/* 110 */           scope.getWorld().showMessage(IMessage.ERROR, WeaverMessages.format("circularityInPrecedenceStar"), pi
/* 111 */               .getSourceLocation(), null);
/*     */         }
/* 113 */         seenStar = true;
/*     */       } else {
/*     */         
/* 116 */         ResolvedType exactType = pi.getExactType().resolve(scope.getWorld());
/* 117 */         if (!exactType.isMissing()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 122 */           if (!exactType.isAspect() && !exactType.isAnnotationStyleAspect() && !pi.isIncludeSubtypes() && 
/* 123 */             !exactType.isTypeVariableReference()) {
/* 124 */             scope.getWorld().showMessage(IMessage.ERROR, 
/* 125 */                 WeaverMessages.format("nonAspectTypesInPrecedence", exactType.getName()), pi.getSourceLocation(), null);
/*     */           }
/*     */ 
/*     */           
/* 129 */           for (int j = 0; j < this.patterns.size(); j++) {
/* 130 */             if (j != i) {
/*     */ 
/*     */               
/* 133 */               TypePattern pj = this.patterns.get(j);
/* 134 */               if (!pj.isStar())
/*     */               {
/*     */                 
/* 137 */                 if (pj.matchesStatically(exactType))
/* 138 */                   scope.getWorld().showMessage(IMessage.ERROR, 
/* 139 */                       WeaverMessages.format("circularityInPrecedenceTwo", exactType.getName()), pi
/* 140 */                       .getSourceLocation(), pj.getSourceLocation());  } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   } public TypePatternList getPatterns() {
/* 147 */     ensureResolved();
/* 148 */     return this.patterns;
/*     */   }
/*     */   
/*     */   private int matchingIndex(ResolvedType a) {
/* 152 */     ensureResolved();
/* 153 */     int knownMatch = -1;
/* 154 */     int starMatch = -1;
/* 155 */     for (int i = 0, len = this.patterns.size(); i < len; i++) {
/* 156 */       TypePattern p = this.patterns.get(i);
/* 157 */       if (p.isStar()) {
/* 158 */         starMatch = i;
/* 159 */       } else if (p.matchesStatically(a)) {
/* 160 */         if (knownMatch != -1) {
/* 161 */           a.getWorld().showMessage(IMessage.ERROR, 
/* 162 */               WeaverMessages.format("multipleMatchesInPrecedence", a, this.patterns.get(knownMatch), p), this.patterns
/* 163 */               .get(knownMatch).getSourceLocation(), p.getSourceLocation());
/* 164 */           return -1;
/*     */         } 
/* 166 */         knownMatch = i;
/*     */       } 
/*     */     } 
/*     */     
/* 170 */     if (knownMatch == -1) {
/* 171 */       return starMatch;
/*     */     }
/* 173 */     return knownMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compare(ResolvedType aspect1, ResolvedType aspect2) {
/* 178 */     ensureResolved();
/* 179 */     int index1 = matchingIndex(aspect1);
/* 180 */     int index2 = matchingIndex(aspect2);
/*     */ 
/*     */ 
/*     */     
/* 184 */     if (index1 == -1 || index2 == -1) {
/* 185 */       return 0;
/*     */     }
/*     */     
/* 188 */     if (index1 == index2)
/* 189 */       return 0; 
/* 190 */     if (index1 > index2) {
/* 191 */       return -1;
/*     */     }
/* 193 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAdviceLike() {
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   public String getNameSuffix() {
/* 202 */     return "precedence";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\DeclarePrecedence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */