/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.Message;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeclareParents
/*     */   extends Declare
/*     */ {
/*     */   protected TypePattern child;
/*     */   protected TypePatternList parents;
/*     */   private boolean isWildChild = false;
/*     */   protected boolean isExtends = true;
/*     */   
/*     */   public DeclareParents(TypePattern child, List<TypePattern> parents, boolean isExtends) {
/*  41 */     this(child, new TypePatternList(parents), isExtends);
/*     */   }
/*     */   
/*     */   protected DeclareParents(TypePattern child, TypePatternList parents, boolean isExtends) {
/*  45 */     this.child = child;
/*  46 */     this.parents = parents;
/*  47 */     this.isExtends = isExtends;
/*  48 */     WildChildFinder wildChildFinder = new WildChildFinder();
/*  49 */     child.accept(wildChildFinder, null);
/*  50 */     this.isWildChild = wildChildFinder.containedWildChild();
/*     */   }
/*     */   
/*     */   public boolean match(ResolvedType typeX) {
/*  54 */     if (!this.child.matchesStatically(typeX)) {
/*  55 */       return false;
/*     */     }
/*  57 */     if ((typeX.getWorld().getLint()).typeNotExposedToWeaver.isEnabled() && !typeX.isExposedToWeaver()) {
/*  58 */       (typeX.getWorld().getLint()).typeNotExposedToWeaver.signal(typeX.getName(), getSourceLocation());
/*     */     }
/*     */     
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/*  66 */     return visitor.visit(this, data);
/*     */   }
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/*  70 */     Object ret = accept(visitor, data);
/*  71 */     if (this.child != null)
/*  72 */       this.child.traverse(visitor, ret); 
/*  73 */     if (this.parents != null)
/*  74 */       this.parents.traverse(visitor, ret); 
/*  75 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Declare parameterizeWith(Map<String, UnresolvedType> typeVariableBindingMap, World w) {
/*  80 */     DeclareParents ret = new DeclareParents(this.child.parameterizeWith(typeVariableBindingMap, w), this.parents.parameterizeWith(typeVariableBindingMap, w), this.isExtends);
/*     */     
/*  82 */     ret.copyLocationFrom(this);
/*  83 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     StringBuilder buf = new StringBuilder();
/*  89 */     buf.append("declare parents: ");
/*  90 */     buf.append(this.child);
/*  91 */     buf.append(this.isExtends ? " extends " : " implements ");
/*  92 */     buf.append(this.parents);
/*  93 */     buf.append(";");
/*  94 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/*  99 */     if (!(other instanceof DeclareParents)) {
/* 100 */       return false;
/*     */     }
/* 102 */     DeclareParents o = (DeclareParents)other;
/* 103 */     return (o.child.equals(this.child) && o.parents.equals(this.parents));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 109 */     int result = 23;
/* 110 */     result = 37 * result + this.child.hashCode();
/* 111 */     result = 37 * result + this.parents.hashCode();
/* 112 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 117 */     s.writeByte(2);
/* 118 */     this.child.write(s);
/* 119 */     this.parents.write(s);
/* 120 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static Declare read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 124 */     DeclareParents ret = new DeclareParents(TypePattern.read(s, context), TypePatternList.read(s, context), true);
/* 125 */     ret.readLocation(context, (DataInputStream)s);
/* 126 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean parentsIncludeInterface(World w) {
/* 130 */     for (int i = 0; i < this.parents.size(); i++) {
/* 131 */       if (this.parents.get(i).getExactType().resolve(w).isInterface()) {
/* 132 */         return true;
/*     */       }
/*     */     } 
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   public boolean parentsIncludeClass(World w) {
/* 139 */     for (int i = 0; i < this.parents.size(); i++) {
/* 140 */       if (this.parents.get(i).getExactType().resolve(w).isClass()) {
/* 141 */         return true;
/*     */       }
/*     */     } 
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(IScope scope) {
/* 149 */     TypePattern resolvedChild = this.child.resolveBindings(scope, Bindings.NONE, false, false);
/* 150 */     if (!resolvedChild.equals(this.child)) {
/* 151 */       WildChildFinder wildChildFinder = new WildChildFinder();
/* 152 */       resolvedChild.accept(wildChildFinder, null);
/* 153 */       this.isWildChild = wildChildFinder.containedWildChild();
/* 154 */       this.child = resolvedChild;
/*     */     } 
/* 156 */     this.parents = this.parents.resolveBindings(scope, Bindings.NONE, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePatternList getParents() {
/* 164 */     return this.parents;
/*     */   }
/*     */   
/*     */   public TypePattern getChild() {
/* 168 */     return this.child;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExtends() {
/* 173 */     return this.isExtends;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAdviceLike() {
/* 178 */     return false;
/*     */   }
/*     */   
/*     */   private ResolvedType maybeGetNewParent(ResolvedType targetType, TypePattern typePattern, World world, boolean reportErrors) {
/* 182 */     if (typePattern == TypePattern.NO) {
/* 183 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 187 */     UnresolvedType iType = typePattern.getExactType();
/* 188 */     ResolvedType parentType = iType.resolve(world);
/*     */     
/* 190 */     if (targetType.equals(world.getCoreType(UnresolvedType.OBJECT))) {
/* 191 */       world.showMessage(IMessage.ERROR, WeaverMessages.format("decpObject"), getSourceLocation(), null);
/* 192 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 197 */     if (parentType.isParameterizedType() || parentType.isRawType()) {
/*     */       
/* 199 */       boolean isOK = verifyNoInheritedAlternateParameterization(targetType, parentType, world);
/* 200 */       if (!isOK) {
/* 201 */         return null;
/*     */       }
/*     */     } 
/*     */     
/* 205 */     if (parentType.isAssignableFrom(targetType)) {
/* 206 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 210 */     if (reportErrors && this.isWildChild && targetType.isEnum()) {
/* 211 */       (world.getLint()).enumAsTargetForDecpIgnored.signal(targetType.toString(), getSourceLocation());
/*     */     }
/*     */ 
/*     */     
/* 215 */     if (reportErrors && this.isWildChild && targetType.isAnnotation()) {
/* 216 */       (world.getLint()).annotationAsTargetForDecpIgnored.signal(targetType.toString(), getSourceLocation());
/*     */     }
/*     */ 
/*     */     
/* 220 */     if (targetType.isEnum() && parentType.isInterface()) {
/* 221 */       if (reportErrors && !this.isWildChild) {
/* 222 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("cantDecpOnEnumToImplInterface", targetType), 
/* 223 */             getSourceLocation(), null);
/*     */       }
/* 225 */       return null;
/*     */     } 
/* 227 */     if (targetType.isAnnotation() && parentType.isInterface()) {
/* 228 */       if (reportErrors && !this.isWildChild) {
/* 229 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("cantDecpOnAnnotationToImplInterface", targetType), 
/* 230 */             getSourceLocation(), null);
/*     */       }
/* 232 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 236 */     if (targetType.isEnum() && parentType.isClass()) {
/* 237 */       if (reportErrors && !this.isWildChild) {
/* 238 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("cantDecpOnEnumToExtendClass", targetType), 
/* 239 */             getSourceLocation(), null);
/*     */       }
/* 241 */       return null;
/*     */     } 
/* 243 */     if (targetType.isAnnotation() && parentType.isClass()) {
/* 244 */       if (reportErrors && !this.isWildChild) {
/* 245 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("cantDecpOnAnnotationToExtendClass", targetType), 
/* 246 */             getSourceLocation(), null);
/*     */       }
/* 248 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 252 */     if (parentType.getSignature().equals(UnresolvedType.ENUM.getSignature())) {
/* 253 */       if (reportErrors && !this.isWildChild) {
/* 254 */         world.showMessage(IMessage.ERROR, 
/* 255 */             WeaverMessages.format("cantDecpToMakeEnumSupertype", targetType), getSourceLocation(), null);
/*     */       }
/* 257 */       return null;
/*     */     } 
/* 259 */     if (parentType.getSignature().equals(UnresolvedType.ANNOTATION.getSignature())) {
/* 260 */       if (reportErrors && !this.isWildChild) {
/* 261 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("cantDecpToMakeAnnotationSupertype", targetType), 
/* 262 */             getSourceLocation(), null);
/*     */       }
/* 264 */       return null;
/*     */     } 
/*     */     
/* 267 */     if (parentType.isAssignableFrom(targetType)) {
/* 268 */       return null;
/*     */     }
/*     */     
/* 271 */     if (targetType.isAssignableFrom(parentType)) {
/* 272 */       world.showMessage(IMessage.ERROR, WeaverMessages.format("cantExtendSelf", targetType.getName()), 
/* 273 */           getSourceLocation(), null);
/* 274 */       return null;
/*     */     } 
/*     */     
/* 277 */     if (parentType.isClass()) {
/* 278 */       if (targetType.isInterface()) {
/* 279 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("interfaceExtendClass"), 
/* 280 */             getSourceLocation(), null);
/* 281 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 285 */       if (!targetType.getSuperclass().isAssignableFrom(parentType)) {
/* 286 */         world.showMessage(IMessage.ERROR, WeaverMessages.format("decpHierarchy", iType.getName(), targetType
/* 287 */               .getSuperclass().getName()), getSourceLocation(), null);
/* 288 */         return null;
/*     */       } 
/* 290 */       return parentType;
/*     */     } 
/*     */     
/* 293 */     return parentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean verifyNoInheritedAlternateParameterization(ResolvedType typeToVerify, ResolvedType newParent, World world) {
/* 309 */     if (typeToVerify.equals(ResolvedType.OBJECT)) {
/* 310 */       return true;
/*     */     }
/*     */     
/* 313 */     ReferenceType referenceType = newParent.getGenericType();
/* 314 */     Iterator<ResolvedType> iter = typeToVerify.getDirectSupertypes();
/* 315 */     while (iter.hasNext()) {
/* 316 */       ResolvedType supertype = iter.next();
/* 317 */       if (((supertype.isRawType() && newParent.isParameterizedType()) || (supertype.isParameterizedType() && newParent
/* 318 */         .isRawType())) && referenceType
/* 319 */         .equals(supertype.getGenericType())) {
/*     */         
/* 321 */         world.getMessageHandler().handleMessage((IMessage)new Message(
/* 322 */               WeaverMessages.format("cantDecpMultipleParameterizations", newParent.getName(), typeToVerify
/* 323 */                 .getName(), supertype.getName()), getSourceLocation(), true, new ISourceLocation[] { typeToVerify
/* 324 */                 .getSourceLocation() }));
/* 325 */         return false;
/*     */       } 
/* 327 */       if (supertype.isParameterizedType()) {
/* 328 */         ReferenceType referenceType1 = supertype.getGenericType();
/*     */ 
/*     */         
/* 331 */         if (referenceType1.isAssignableFrom((ResolvedType)referenceType) && !supertype.isAssignableFrom(newParent)) {
/* 332 */           world.getMessageHandler().handleMessage((IMessage)new Message(
/* 333 */                 WeaverMessages.format("cantDecpMultipleParameterizations", newParent
/* 334 */                   .getName(), typeToVerify.getName(), supertype.getName()), getSourceLocation(), true, new ISourceLocation[] { typeToVerify
/* 335 */                   .getSourceLocation() }));
/* 336 */           return false;
/*     */         } 
/*     */       } 
/* 339 */       if (!verifyNoInheritedAlternateParameterization(supertype, newParent, world)) {
/* 340 */         return false;
/*     */       }
/*     */     } 
/* 343 */     return true;
/*     */   }
/*     */   public List<ResolvedType> findMatchingNewParents(ResolvedType onType, boolean reportErrors) {
/*     */     ReferenceType referenceType;
/* 347 */     if (onType.isRawType()) {
/* 348 */       referenceType = onType.getGenericType();
/*     */     }
/* 350 */     if (!match((ResolvedType)referenceType)) {
/* 351 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 354 */     List<ResolvedType> ret = new ArrayList<>();
/* 355 */     for (int i = 0; i < this.parents.size(); i++) {
/* 356 */       ResolvedType t = maybeGetNewParent((ResolvedType)referenceType, this.parents.get(i), referenceType.getWorld(), reportErrors);
/* 357 */       if (t != null) {
/* 358 */         ret.add(t);
/*     */       }
/*     */     } 
/*     */     
/* 362 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNameSuffix() {
/* 367 */     return "parents";
/*     */   }
/*     */   
/*     */   public boolean isMixin() {
/* 371 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\DeclareParents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */