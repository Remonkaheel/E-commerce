package org.aspectj.weaver.patterns;

public interface IVerificationRequired {
  void verify();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\IVerificationRequired.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */