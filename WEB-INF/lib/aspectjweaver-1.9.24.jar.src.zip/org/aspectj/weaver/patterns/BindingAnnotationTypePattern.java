/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.MessageUtil;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.TypeVariableReference;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingAnnotationTypePattern
/*     */   extends ExactAnnotationTypePattern
/*     */   implements BindingPattern
/*     */ {
/*     */   protected int formalIndex;
/*     */   private static final byte VERSION = 1;
/*     */   
/*     */   public BindingAnnotationTypePattern(UnresolvedType annotationType, int index) {
/*  36 */     super(annotationType, (Map<String, String>)null);
/*  37 */     this.formalIndex = index;
/*     */   }
/*     */   
/*     */   public BindingAnnotationTypePattern(FormalBinding binding) {
/*  41 */     this(binding.getType(), binding.getIndex());
/*     */   }
/*     */   
/*     */   public void resolveBinding(World world) {
/*  45 */     if (this.resolved) {
/*     */       return;
/*     */     }
/*  48 */     this.resolved = true;
/*  49 */     this.annotationType = (UnresolvedType)this.annotationType.resolve(world);
/*  50 */     ResolvedType resolvedAnnotationType = (ResolvedType)this.annotationType;
/*  51 */     if (!resolvedAnnotationType.isAnnotation()) {
/*  52 */       IMessage m = MessageUtil.error(WeaverMessages.format("referenceToNonAnnotationType", this.annotationType
/*  53 */             .getName()), getSourceLocation());
/*  54 */       world.getMessageHandler().handleMessage(m);
/*  55 */       this.resolved = false;
/*     */     } 
/*  57 */     if (this.annotationType.isTypeVariableReference()) {
/*     */       return;
/*     */     }
/*  60 */     verifyRuntimeRetention(world, resolvedAnnotationType);
/*     */   }
/*     */   
/*     */   private void verifyRuntimeRetention(World world, ResolvedType resolvedAnnotationType) {
/*  64 */     if (!resolvedAnnotationType.isAnnotationWithRuntimeRetention()) {
/*     */       
/*  66 */       IMessage m = MessageUtil.error(WeaverMessages.format("bindingNonRuntimeRetentionAnnotation", this.annotationType
/*  67 */             .getName()), getSourceLocation());
/*  68 */       world.getMessageHandler().handleMessage(m);
/*  69 */       this.resolved = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern parameterizeWith(Map typeVariableMap, World w) {
/*  74 */     UnresolvedType newAnnotationType = this.annotationType;
/*  75 */     if (this.annotationType.isTypeVariableReference()) {
/*  76 */       TypeVariableReference t = (TypeVariableReference)this.annotationType;
/*  77 */       String key = t.getTypeVariable().getName();
/*  78 */       if (typeVariableMap.containsKey(key)) {
/*  79 */         newAnnotationType = (UnresolvedType)typeVariableMap.get(key);
/*     */       }
/*  81 */     } else if (this.annotationType.isParameterizedType()) {
/*  82 */       newAnnotationType = this.annotationType.parameterize(typeVariableMap);
/*     */     } 
/*  84 */     BindingAnnotationTypePattern ret = new BindingAnnotationTypePattern(newAnnotationType, this.formalIndex);
/*  85 */     if (newAnnotationType instanceof ResolvedType) {
/*  86 */       ResolvedType rat = (ResolvedType)newAnnotationType;
/*  87 */       verifyRuntimeRetention(rat.getWorld(), rat);
/*     */     } 
/*  89 */     ret.copyLocationFrom(this);
/*  90 */     return ret;
/*     */   }
/*     */   
/*     */   public int getFormalIndex() {
/*  94 */     return this.formalIndex;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  98 */     if (!(obj instanceof BindingAnnotationTypePattern)) {
/*  99 */       return false;
/*     */     }
/* 101 */     BindingAnnotationTypePattern btp = (BindingAnnotationTypePattern)obj;
/* 102 */     return (super.equals(btp) && btp.formalIndex == this.formalIndex);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 106 */     return super.hashCode() * 37 + this.formalIndex;
/*     */   }
/*     */   
/*     */   public AnnotationTypePattern remapAdviceFormals(IntMap bindings) {
/* 110 */     if (!bindings.hasKey(this.formalIndex)) {
/* 111 */       return new ExactAnnotationTypePattern(this.annotationType, null);
/*     */     }
/* 113 */     int newFormalIndex = bindings.get(this.formalIndex);
/* 114 */     return new BindingAnnotationTypePattern(this.annotationType, newFormalIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 122 */     s.writeByte(2);
/* 123 */     s.writeByte(1);
/* 124 */     this.annotationType.write(s);
/* 125 */     s.writeShort((short)this.formalIndex);
/* 126 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static AnnotationTypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 130 */     byte version = s.readByte();
/* 131 */     if (version > 1) {
/* 132 */       throw new BCException("BindingAnnotationTypePattern was written by a more recent version of AspectJ");
/*     */     }
/* 134 */     AnnotationTypePattern ret = new BindingAnnotationTypePattern(UnresolvedType.read((DataInputStream)s), s.readShort());
/* 135 */     ret.readLocation(context, (DataInputStream)s);
/* 136 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\BindingAnnotationTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */