/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifiersPattern
/*     */   extends PatternNode
/*     */ {
/*     */   private int requiredModifiers;
/*     */   private int forbiddenModifiers;
/*  27 */   public static final ModifiersPattern ANY = new ModifiersPattern(0, 0);
/*     */   
/*  29 */   private static Map<String, Integer> modifierFlags = null;
/*     */   
/*     */   static {
/*  32 */     modifierFlags = new HashMap<>();
/*  33 */     int flag = 1;
/*  34 */     while (flag <= 2048) {
/*  35 */       String flagName = Modifier.toString(flag);
/*  36 */       modifierFlags.put(flagName, Integer.valueOf(flag));
/*  37 */       flag <<= 1;
/*     */     } 
/*     */     
/*  40 */     modifierFlags.put("synthetic", Integer.valueOf(4096));
/*     */   }
/*     */   
/*     */   public ModifiersPattern(int requiredModifiers, int forbiddenModifiers) {
/*  44 */     this.requiredModifiers = requiredModifiers;
/*  45 */     this.forbiddenModifiers = forbiddenModifiers;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  49 */     if (this == ANY) {
/*  50 */       return "";
/*     */     }
/*     */     
/*  53 */     String ret = Modifier.toString(this.requiredModifiers);
/*  54 */     if (this.forbiddenModifiers == 0) {
/*  55 */       return ret;
/*     */     }
/*  57 */     return ret + " !" + Modifier.toString(this.forbiddenModifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/*  62 */     if (!(other instanceof ModifiersPattern)) {
/*  63 */       return false;
/*     */     }
/*  65 */     ModifiersPattern o = (ModifiersPattern)other;
/*  66 */     return (o.requiredModifiers == this.requiredModifiers && o.forbiddenModifiers == this.forbiddenModifiers);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  70 */     int result = 17;
/*  71 */     result = 37 * result + this.requiredModifiers;
/*  72 */     result = 37 * result + this.forbiddenModifiers;
/*  73 */     return result;
/*     */   }
/*     */   
/*     */   public boolean matches(int modifiers) {
/*  77 */     return ((modifiers & this.requiredModifiers) == this.requiredModifiers && (modifiers & this.forbiddenModifiers) == 0);
/*     */   }
/*     */   
/*     */   public static ModifiersPattern read(VersionedDataInputStream s) throws IOException {
/*  81 */     int requiredModifiers = s.readShort();
/*  82 */     int forbiddenModifiers = s.readShort();
/*  83 */     if (requiredModifiers == 0 && forbiddenModifiers == 0) {
/*  84 */       return ANY;
/*     */     }
/*  86 */     return new ModifiersPattern(requiredModifiers, forbiddenModifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/*  91 */     s.writeShort(this.requiredModifiers);
/*  92 */     s.writeShort(this.forbiddenModifiers);
/*     */   }
/*     */   
/*     */   public static int getModifierFlag(String name) {
/*  96 */     Integer flag = modifierFlags.get(name);
/*  97 */     if (flag == null) {
/*  98 */       return -1;
/*     */     }
/* 100 */     return flag.intValue();
/*     */   }
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 104 */     return visitor.visit(this, data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\ModifiersPattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */