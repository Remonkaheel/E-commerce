/*    */ package org.aspectj.weaver.patterns;
/*    */ 
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.Shadow;
/*    */ import org.aspectj.weaver.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastMatchInfo
/*    */ {
/*    */   private Shadow.Kind kind;
/*    */   private ResolvedType type;
/*    */   public World world;
/*    */   
/*    */   public FastMatchInfo(ResolvedType type, Shadow.Kind kind, World world) {
/* 29 */     this.type = type;
/* 30 */     this.kind = kind;
/* 31 */     this.world = world;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Shadow.Kind getKind() {
/* 40 */     return this.kind;
/*    */   }
/*    */   
/*    */   public ResolvedType getType() {
/* 44 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return "FastMatchInfo [type=" + this.type.getName() + "] [" + ((this.kind == null) ? "AllKinds" : ("Kind=" + this.kind)) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\FastMatchInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */