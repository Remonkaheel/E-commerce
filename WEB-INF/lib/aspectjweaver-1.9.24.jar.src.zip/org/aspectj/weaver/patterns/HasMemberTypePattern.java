/*     */ package org.aspectj.weaver.patterns;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.ConcreteTypeMunger;
/*     */ import org.aspectj.weaver.IHasPosition;
/*     */ import org.aspectj.weaver.ISourceContext;
/*     */ import org.aspectj.weaver.Member;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.VersionedDataInputStream;
/*     */ import org.aspectj.weaver.WeaverMessages;
/*     */ import org.aspectj.weaver.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HasMemberTypePattern
/*     */   extends TypePattern
/*     */ {
/*     */   private SignaturePattern signaturePattern;
/*     */   private static final String declareAtPrefix = "ajc$declare_at";
/*     */   
/*     */   public HasMemberTypePattern(SignaturePattern aSignaturePattern) {
/*  43 */     super(false, false);
/*  44 */     this.signaturePattern = aSignaturePattern;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type) {
/*  49 */     if (this.signaturePattern.getKind() == Member.FIELD) {
/*  50 */       return hasField(type);
/*     */     }
/*  52 */     return hasMethod(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ISignaturePattern getSignaturePattern() {
/*  57 */     return this.signaturePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasField(ResolvedType type) {
/*  64 */     World world = type.getWorld();
/*  65 */     for (Iterator<ResolvedMember> iter = type.getFields(); iter.hasNext(); ) {
/*  66 */       Member field = (Member)iter.next();
/*  67 */       if (field.getName().startsWith("ajc$declare_at")) {
/*     */         continue;
/*     */       }
/*  70 */       if (!this.signaturePattern.matches(field, type.getWorld(), false) || (
/*  71 */         field.getDeclaringType().resolve(world) != type && 
/*  72 */         Modifier.isPrivate(field.getModifiers()))) {
/*     */         continue;
/*     */       }
/*     */       
/*  76 */       return true;
/*     */     } 
/*     */     
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasMethod(ResolvedType type) {
/*  84 */     World world = type.getWorld();
/*  85 */     for (Iterator<ResolvedMember> iter = type.getMethods(true, true); iter.hasNext(); ) {
/*  86 */       Member method = (Member)iter.next();
/*  87 */       if (method.getName().startsWith("ajc$declare_at")) {
/*     */         continue;
/*     */       }
/*  90 */       if (this.signaturePattern.matches(method, type.getWorld(), false)) {
/*  91 */         ResolvedType declaringType = method.getDeclaringType().resolve(world);
/*  92 */         if (declaringType != type && 
/*  93 */           Modifier.isPrivate(method.getModifiers())) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/*  98 */         if (method.getName().equals("finalize") && declaringType.equals(ResolvedType.OBJECT) && this.signaturePattern
/*  99 */           .getAnnotationPattern() instanceof ExactAnnotationTypePattern && ((ExactAnnotationTypePattern)this.signaturePattern
/* 100 */           .getAnnotationPattern()).getAnnotationType().getSignature().equals("Ljava/lang/Deprecated;")) {
/*     */           continue;
/*     */         }
/* 103 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     List<ConcreteTypeMunger> mungers = type.getInterTypeMungersIncludingSupers();
/* 108 */     for (ConcreteTypeMunger munger : mungers) {
/* 109 */       ResolvedMember resolvedMember = munger.getSignature();
/* 110 */       if (!this.signaturePattern.matches((Member)resolvedMember, type.getWorld(), false) || 
/* 111 */         !Modifier.isPublic(resolvedMember.getModifiers())) {
/*     */         continue;
/*     */       }
/* 114 */       return true;
/*     */     } 
/*     */     
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesExactly(ResolvedType type, ResolvedType annotatedType) {
/* 122 */     return matchesExactly(type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean matchesArray(UnresolvedType type) {
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public FuzzyBoolean matchesInstanceof(ResolvedType type) {
/* 132 */     throw new UnsupportedOperationException("hasmethod/field do not support instanceof matching");
/*     */   }
/*     */ 
/*     */   
/*     */   public TypePattern parameterizeWith(Map<String, UnresolvedType> typeVariableMap, World w) {
/* 137 */     HasMemberTypePattern ret = new HasMemberTypePattern(this.signaturePattern.parameterizeWith(typeVariableMap, w));
/* 138 */     ret.copyLocationFrom(this);
/* 139 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePattern resolveBindings(IScope scope, Bindings bindings, boolean allowBinding, boolean requireExactType) {
/* 145 */     if (!scope.getWorld().isHasMemberSupportEnabled()) {
/* 146 */       String msg = WeaverMessages.format("hasMemberNotEnabled", toString());
/* 147 */       scope.message(IMessage.ERROR, (IHasPosition)this, msg);
/*     */     } 
/* 149 */     this.signaturePattern.resolveBindings(scope, bindings);
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 155 */     if (!(obj instanceof HasMemberTypePattern)) {
/* 156 */       return false;
/*     */     }
/* 158 */     if (this == obj) {
/* 159 */       return true;
/*     */     }
/* 161 */     return this.signaturePattern.equals(((HasMemberTypePattern)obj).signaturePattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     return this.signaturePattern.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     StringBuilder buff = new StringBuilder();
/* 172 */     if (this.signaturePattern.getKind() == Member.FIELD) {
/* 173 */       buff.append("hasfield(");
/*     */     } else {
/* 175 */       buff.append("hasmethod(");
/*     */     } 
/* 177 */     buff.append(this.signaturePattern.toString());
/* 178 */     buff.append(")");
/* 179 */     return buff.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 184 */     s.writeByte(11);
/* 185 */     this.signaturePattern.write(s);
/* 186 */     writeLocation((DataOutputStream)s);
/*     */   }
/*     */   
/*     */   public static TypePattern read(VersionedDataInputStream s, ISourceContext context) throws IOException {
/* 190 */     SignaturePattern sp = SignaturePattern.read(s, context);
/* 191 */     HasMemberTypePattern ret = new HasMemberTypePattern(sp);
/* 192 */     ret.readLocation(context, (DataInputStream)s);
/* 193 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 198 */     return visitor.visit(this, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object traverse(PatternNodeVisitor visitor, Object data) {
/* 203 */     Object ret = accept(visitor, data);
/* 204 */     super.traverse(visitor, ret);
/* 205 */     if (this.signaturePattern != null)
/* 206 */       this.signaturePattern.traverse(visitor, ret); 
/* 207 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\HasMemberTypePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */