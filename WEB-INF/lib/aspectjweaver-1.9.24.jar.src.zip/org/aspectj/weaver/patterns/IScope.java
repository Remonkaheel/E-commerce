package org.aspectj.weaver.patterns;

import org.aspectj.bridge.IMessage;
import org.aspectj.bridge.IMessageHandler;
import org.aspectj.weaver.IHasPosition;
import org.aspectj.weaver.ResolvedType;
import org.aspectj.weaver.UnresolvedType;
import org.aspectj.weaver.World;

public interface IScope {
  UnresolvedType lookupType(String paramString, IHasPosition paramIHasPosition);
  
  World getWorld();
  
  ResolvedType getEnclosingType();
  
  IMessageHandler getMessageHandler();
  
  FormalBinding lookupFormal(String paramString);
  
  FormalBinding getFormal(int paramInt);
  
  int getFormalCount();
  
  String[] getImportedPrefixes();
  
  String[] getImportedNames();
  
  void message(IMessage.Kind paramKind, IHasPosition paramIHasPosition, String paramString);
  
  void message(IMessage.Kind paramKind, IHasPosition paramIHasPosition1, IHasPosition paramIHasPosition2, String paramString);
  
  void message(IMessage paramIMessage);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\patterns\IScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */