/*     */ package org.aspectj.weaver.ltw;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ import org.aspectj.bridge.IMessageHandler;
/*     */ import org.aspectj.weaver.Dump;
/*     */ import org.aspectj.weaver.ICrossReferenceHandler;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.bcel.BcelWorld;
/*     */ import org.aspectj.weaver.loadtime.IWeavingContext;
/*     */ import org.aspectj.weaver.reflect.AnnotationFinder;
/*     */ import org.aspectj.weaver.reflect.IReflectionWorld;
/*     */ import org.aspectj.weaver.reflect.ReflectionBasedReferenceTypeDelegateFactory;
/*     */ import org.aspectj.weaver.reflect.ReflectionWorld;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LTWWorld
/*     */   extends BcelWorld
/*     */   implements IReflectionWorld
/*     */ {
/*     */   private AnnotationFinder annotationFinder;
/*     */   private IWeavingContext weavingContext;
/*     */   private String classLoaderString;
/*     */   private String classLoaderParentString;
/*  66 */   protected static final Class concurrentMapClass = null;
/*     */   private static final boolean ShareBootstrapTypes = false;
/*     */   protected static Map bootstrapTypes;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private boolean typeCompletionInProgress;
/*     */   private List<ResolvedType> typesForCompletion;
/*     */   
/*     */   public LTWWorld(ClassLoader loader, IWeavingContext weavingContext, IMessageHandler handler, ICrossReferenceHandler xrefHandler) {
/*  74 */     super(loader, handler, xrefHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     this.typeCompletionInProgress = false;
/* 218 */     this.typesForCompletion = new ArrayList<>(); this.weavingContext = weavingContext; try { this.classLoaderString = loader.toString(); } catch (Throwable t) { this.classLoaderString = loader.getClass().getName() + ":" + Integer.toString(System.identityHashCode(loader)); }  this.classLoaderParentString = (loader.getParent() == null) ? "<NullParent>" : loader.getParent().toString(); setBehaveInJava5Way(true); this.annotationFinder = ReflectionWorld.makeAnnotationFinderIfAny(loader, (World)this);
/*     */   } public ClassLoader getClassLoader() { return this.weavingContext.getClassLoader(); } protected ReferenceTypeDelegate resolveDelegate(ReferenceType ty) { ReferenceTypeDelegate bootstrapLoaderDelegate = resolveIfBootstrapDelegate(ty); if (bootstrapLoaderDelegate != null) return bootstrapLoaderDelegate;  return super.resolveDelegate(ty); } protected ReferenceTypeDelegate resolveIfBootstrapDelegate(ReferenceType ty) { return null; }
/*     */   private ReferenceTypeDelegate resolveReflectionTypeDelegate(ReferenceType ty, ClassLoader resolutionLoader) { return (ReferenceTypeDelegate)ReflectionBasedReferenceTypeDelegateFactory.createDelegate(ty, (World)this, resolutionLoader); }
/*     */   public void loadedClass(Class clazz) {}
/* 222 */   protected void completeBinaryType(ResolvedType ret) { if (isLocallyDefined(ret.getName())) {
/* 223 */       if (this.typeCompletionInProgress) {
/* 224 */         this.typesForCompletion.add(ret);
/*     */       } else {
/*     */         try {
/* 227 */           this.typeCompletionInProgress = true;
/* 228 */           completeHierarchyForType(ret);
/*     */         } finally {
/* 230 */           this.typeCompletionInProgress = false;
/*     */         } 
/* 232 */         while (this.typesForCompletion.size() != 0) {
/* 233 */           ResolvedType rt = this.typesForCompletion.get(0);
/* 234 */           completeHierarchyForType(rt);
/* 235 */           this.typesForCompletion.remove(0);
/*     */         }
/*     */       
/*     */       } 
/* 239 */     } else if (!ret.needsModifiableDelegate()) {
/* 240 */       ret = completeNonLocalType(ret);
/*     */     }  }
/*     */   public AnnotationFinder getAnnotationFinder() {
/*     */     return this.annotationFinder;
/*     */   } public ResolvedType resolve(Class aClass) {
/*     */     return ReflectionWorld.resolve((World)this, aClass);
/* 246 */   } private void completeHierarchyForType(ResolvedType ret) { (getLint()).typeNotExposedToWeaver.setSuppressed(true);
/* 247 */     weaveInterTypeDeclarations(ret);
/* 248 */     (getLint()).typeNotExposedToWeaver.setSuppressed(false); }
/*     */   private static Map<?, ?> makeConcurrentMap() { if (concurrentMapClass != null) try { return concurrentMapClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]); } catch (InstantiationException|IllegalAccessException|NoSuchMethodException|java.lang.reflect.InvocationTargetException instantiationException) {}  return Collections.synchronizedMap(new HashMap<>()); }
/*     */   private static Class<?> makeConcurrentMapClass() { String[] betterChoices = { "java.util.concurrent.ConcurrentHashMap", "edu.emory.mathcs.backport.java.util.concurrent.ConcurrentHashMap", "EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap" }; for (String betterChoice : betterChoices) { try { return Class.forName(betterChoice); } catch (ClassNotFoundException classNotFoundException) {  } catch (SecurityException securityException) {} }  return null; }
/*     */   public boolean isRunMinimalMemory() { if (isRunMinimalMemorySet())
/* 252 */       return super.isRunMinimalMemory();  return false; } protected boolean needsCompletion() { return true; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocallyDefined(String classname) {
/* 257 */     return this.weavingContext.isLocallyDefined(classname);
/*     */   }
/*     */   protected ResolvedType completeNonLocalType(ResolvedType ret) {
/*     */     ReferenceType referenceType;
/* 261 */     if (ret.isMissing()) {
/* 262 */       return ret;
/*     */     }
/* 264 */     ResolvedType toResolve = ret;
/* 265 */     if (ret.isParameterizedType() || ret.isGenericType()) {
/* 266 */       referenceType = toResolve.getGenericType();
/*     */     }
/* 268 */     ReferenceTypeDelegate rtd = resolveReflectionTypeDelegate(referenceType, getClassLoader());
/* 269 */     ((ReferenceType)ret).setDelegate(rtd);
/* 270 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void storeClass(JavaClass clazz) {
/* 275 */     ensureRepositorySetup();
/* 276 */     this.delegate.storeClass(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(Dump.IVisitor visitor) {
/* 281 */     visitor.visitObject("Class loader:");
/* 282 */     visitor.visitObject(this.classLoaderString);
/* 283 */     visitor.visitObject("Class loader parent:");
/* 284 */     visitor.visitObject(this.classLoaderParentString);
/* 285 */     super.accept(visitor);
/*     */   }
/*     */   
/*     */   public boolean isLoadtimeWeaving() {
/* 289 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\ltw\LTWWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */