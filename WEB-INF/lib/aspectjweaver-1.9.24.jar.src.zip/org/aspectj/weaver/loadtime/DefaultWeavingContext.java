/*     */ package org.aspectj.weaver.loadtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.aspectj.weaver.bcel.BcelWeakClassLoaderReference;
/*     */ import org.aspectj.weaver.loadtime.definition.Definition;
/*     */ import org.aspectj.weaver.tools.Trace;
/*     */ import org.aspectj.weaver.tools.TraceFactory;
/*     */ import org.aspectj.weaver.tools.WeavingAdaptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultWeavingContext
/*     */   implements IWeavingContext
/*     */ {
/*     */   protected BcelWeakClassLoaderReference loaderRef;
/*     */   private String shortName;
/*  35 */   private static Trace trace = TraceFactory.getTraceFactory().getTrace(DefaultWeavingContext.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultWeavingContext(ClassLoader loader) {
/*  44 */     this.loaderRef = new BcelWeakClassLoaderReference(loader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String name) throws IOException {
/*  51 */     return getClassLoader().getResources(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBundleIdFromURL(URL url) {
/*  58 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassLoaderName() {
/*  65 */     ClassLoader loader = getClassLoader();
/*  66 */     return (loader != null) ? (loader.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(loader))) : 
/*  67 */       "null";
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/*  71 */     return this.loaderRef.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFile(URL url) {
/*  78 */     return url.getFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  85 */     if (this.shortName == null) {
/*  86 */       this.shortName = getClassLoaderName().replace('$', '.');
/*  87 */       int index = this.shortName.lastIndexOf(".");
/*  88 */       if (index != -1) {
/*  89 */         this.shortName = this.shortName.substring(index + 1);
/*     */       }
/*     */     } 
/*  92 */     return this.shortName;
/*     */   }
/*     */   
/*     */   public String getSuffix() {
/*  96 */     return getClassLoaderName();
/*     */   }
/*     */   
/*     */   public boolean isLocallyDefined(String classname) {
/* 100 */     String asResource = classname.replace('.', '/').concat(".class");
/* 101 */     ClassLoader loader = getClassLoader();
/* 102 */     URL localURL = loader.getResource(asResource);
/* 103 */     if (localURL == null) {
/* 104 */       return false;
/*     */     }
/*     */     
/* 107 */     boolean isLocallyDefined = true;
/*     */     
/* 109 */     ClassLoader parent = loader.getParent();
/* 110 */     if (parent != null) {
/* 111 */       URL parentURL = parent.getResource(asResource);
/* 112 */       if (localURL.equals(parentURL)) {
/* 113 */         isLocallyDefined = false;
/*     */       }
/*     */     } 
/* 116 */     return isLocallyDefined;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Definition> getDefinitions(ClassLoader loader, WeavingAdaptor adaptor) {
/* 126 */     if (trace.isTraceEnabled()) {
/* 127 */       trace.enter("getDefinitions", this, new Object[] { "goo", adaptor });
/*     */     }
/*     */     
/* 130 */     List<Definition> definitions = ((ClassLoaderWeavingAdaptor)adaptor).parseDefinitions(loader);
/*     */     
/* 132 */     if (trace.isTraceEnabled()) {
/* 133 */       trace.exit("getDefinitions", definitions);
/*     */     }
/* 135 */     return definitions;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\DefaultWeavingContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */