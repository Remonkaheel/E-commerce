/*     */ package org.aspectj.weaver.loadtime;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.IMessageHandler;
/*     */ import org.aspectj.bridge.Message;
/*     */ import org.aspectj.util.LangUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Options
/*     */ {
/*     */   private static final String OPTION_15 = "-1.5";
/*     */   private static final String OPTION_lazyTjp = "-XlazyTjp";
/*     */   private static final String OPTION_noWarn = "-nowarn";
/*     */   private static final String OPTION_noWarnNone = "-warn:none";
/*     */   private static final String OPTION_proceedOnError = "-proceedOnError";
/*     */   private static final String OPTION_verbose = "-verbose";
/*     */   private static final String OPTION_debug = "-debug";
/*     */   private static final String OPTION_reweavable = "-Xreweavable";
/*     */   private static final String OPTION_noinline = "-Xnoinline";
/*     */   private static final String OPTION_addSerialVersionUID = "-XaddSerialVersionUID";
/*     */   private static final String OPTION_hasMember = "-XhasMember";
/*     */   private static final String OPTION_pinpoint = "-Xdev:pinpoint";
/*     */   private static final String OPTION_showWeaveInfo = "-showWeaveInfo";
/*     */   private static final String OPTIONVALUED_messageHandler = "-XmessageHandlerClass:";
/*     */   private static final String OPTIONVALUED_Xlintfile = "-Xlintfile:";
/*     */   private static final String OPTIONVALUED_Xlint = "-Xlint:";
/*     */   private static final String OPTIONVALUED_joinpoints = "-Xjoinpoints:";
/*     */   private static final String OPTIONVALUED_Xset = "-Xset:";
/*     */   private static final String OPTION_timers = "-timers";
/*     */   private static final String OPTIONVALUED_loadersToSkip = "-loadersToSkip:";
/*     */   
/*     */   public static WeaverOption parse(String options, ClassLoader laoder, IMessageHandler imh) {
/*  52 */     WeaverOption weaverOption = new WeaverOption(imh);
/*     */     
/*  54 */     if (LangUtil.isEmpty(options)) {
/*  55 */       return weaverOption;
/*     */     }
/*     */     
/*  58 */     List<String> flags = LangUtil.anySplit(options, " ");
/*  59 */     Collections.reverse(flags);
/*     */ 
/*     */     
/*  62 */     for (String arg : flags) {
/*  63 */       if (arg.startsWith("-XmessageHandlerClass:") && 
/*  64 */         arg.length() > "-XmessageHandlerClass:".length()) {
/*  65 */         String handlerClass = arg.substring("-XmessageHandlerClass:".length()).trim();
/*     */         try {
/*  67 */           Class<?> handler = Class.forName(handlerClass, false, laoder);
/*  68 */           weaverOption.messageHandler = handler.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*  69 */         } catch (Throwable t) {
/*  70 */           weaverOption.messageHandler.handleMessage((IMessage)new Message("Cannot instantiate message handler " + handlerClass, IMessage.ERROR, t, null));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     for (String arg : flags) {
/*  79 */       if (arg.equals("-1.5")) {
/*  80 */         weaverOption.java5 = true; continue;
/*  81 */       }  if (arg.equalsIgnoreCase("-XlazyTjp")) {
/*  82 */         weaverOption.lazyTjp = true; continue;
/*  83 */       }  if (arg.equalsIgnoreCase("-Xnoinline")) {
/*  84 */         weaverOption.noInline = true; continue;
/*  85 */       }  if (arg.equalsIgnoreCase("-XaddSerialVersionUID")) {
/*  86 */         weaverOption.addSerialVersionUID = true; continue;
/*  87 */       }  if (arg.equalsIgnoreCase("-nowarn") || arg.equalsIgnoreCase("-warn:none")) {
/*  88 */         weaverOption.noWarn = true; continue;
/*  89 */       }  if (arg.equalsIgnoreCase("-proceedOnError")) {
/*  90 */         weaverOption.proceedOnError = true; continue;
/*  91 */       }  if (arg.equalsIgnoreCase("-Xreweavable")) {
/*  92 */         weaverOption.notReWeavable = false; continue;
/*  93 */       }  if (arg.equalsIgnoreCase("-showWeaveInfo")) {
/*  94 */         weaverOption.showWeaveInfo = true; continue;
/*  95 */       }  if (arg.equalsIgnoreCase("-XhasMember")) {
/*  96 */         weaverOption.hasMember = true; continue;
/*  97 */       }  if (arg.startsWith("-Xjoinpoints:")) {
/*  98 */         if (arg.length() > "-Xjoinpoints:".length())
/*  99 */           weaverOption.optionalJoinpoints = arg.substring("-Xjoinpoints:".length()).trim();  continue;
/*     */       } 
/* 101 */       if (arg.equalsIgnoreCase("-verbose")) {
/* 102 */         weaverOption.verbose = true; continue;
/* 103 */       }  if (arg.equalsIgnoreCase("-debug")) {
/* 104 */         weaverOption.debug = true; continue;
/* 105 */       }  if (arg.equalsIgnoreCase("-Xdev:pinpoint")) {
/* 106 */         weaverOption.pinpoint = true; continue;
/* 107 */       }  if (arg.startsWith("-XmessageHandlerClass:"))
/*     */         continue; 
/* 109 */       if (arg.startsWith("-Xlintfile:")) {
/* 110 */         if (arg.length() > "-Xlintfile:".length())
/* 111 */           weaverOption.lintFile = arg.substring("-Xlintfile:".length()).trim();  continue;
/*     */       } 
/* 113 */       if (arg.startsWith("-Xlint:")) {
/* 114 */         if (arg.length() > "-Xlint:".length())
/* 115 */           weaverOption.lint = arg.substring("-Xlint:".length()).trim();  continue;
/*     */       } 
/* 117 */       if (arg.startsWith("-Xset:")) {
/* 118 */         if (arg.length() > "-Xlint:".length())
/* 119 */           weaverOption.xSet = arg.substring("-Xset:".length()).trim();  continue;
/*     */       } 
/* 121 */       if (arg.equalsIgnoreCase("-timers")) {
/* 122 */         weaverOption.timers = true; continue;
/* 123 */       }  if (arg.startsWith("-loadersToSkip:")) {
/* 124 */         if (arg.length() > "-loadersToSkip:".length()) {
/* 125 */           String value = arg.substring("-loadersToSkip:".length()).trim();
/* 126 */           weaverOption.loadersToSkip = value;
/*     */         }  continue;
/*     */       } 
/* 129 */       weaverOption.messageHandler.handleMessage((IMessage)new Message("Cannot configure weaver with option '" + arg + "': unknown option", IMessage.WARNING, null, null));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     if (weaverOption.noWarn) {
/* 136 */       weaverOption.messageHandler.ignore(IMessage.WARNING);
/*     */     }
/* 138 */     if (weaverOption.verbose) {
/* 139 */       weaverOption.messageHandler.dontIgnore(IMessage.INFO);
/*     */     }
/* 141 */     if (weaverOption.debug) {
/* 142 */       weaverOption.messageHandler.dontIgnore(IMessage.DEBUG);
/*     */     }
/* 144 */     if (weaverOption.showWeaveInfo) {
/* 145 */       weaverOption.messageHandler.dontIgnore(IMessage.WEAVEINFO);
/*     */     }
/*     */     
/* 148 */     return weaverOption;
/*     */   }
/*     */   
/*     */   public static class WeaverOption
/*     */   {
/*     */     boolean java5;
/*     */     boolean lazyTjp;
/*     */     boolean hasMember;
/*     */     boolean timers = false;
/*     */     String optionalJoinpoints;
/*     */     boolean noWarn;
/*     */     boolean proceedOnError;
/*     */     boolean verbose;
/*     */     boolean debug;
/*     */     boolean notReWeavable = true;
/*     */     boolean noInline;
/*     */     boolean addSerialVersionUID;
/*     */     boolean showWeaveInfo;
/*     */     boolean pinpoint;
/*     */     IMessageHandler messageHandler;
/*     */     String lint;
/*     */     String lintFile;
/*     */     String xSet;
/*     */     String loadersToSkip;
/*     */     
/*     */     public WeaverOption(IMessageHandler imh) {
/* 174 */       this.messageHandler = imh;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\Options.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */