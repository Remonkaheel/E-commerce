package org.aspectj.weaver.loadtime;

import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.List;
import org.aspectj.weaver.loadtime.definition.Definition;
import org.aspectj.weaver.tools.WeavingAdaptor;

public interface IWeavingContext {
  Enumeration<URL> getResources(String paramString) throws IOException;
  
  String getBundleIdFromURL(URL paramURL);
  
  String getClassLoaderName();
  
  ClassLoader getClassLoader();
  
  String getFile(URL paramURL);
  
  String getId();
  
  boolean isLocallyDefined(String paramString);
  
  List<Definition> getDefinitions(ClassLoader paramClassLoader, WeavingAdaptor paramWeavingAdaptor);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\IWeavingContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */