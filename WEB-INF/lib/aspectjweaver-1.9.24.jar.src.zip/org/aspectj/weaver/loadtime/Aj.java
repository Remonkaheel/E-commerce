/*     */ package org.aspectj.weaver.loadtime;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.aspectj.bridge.context.CompilationAndWeavingContext;
/*     */ import org.aspectj.weaver.Dump;
/*     */ import org.aspectj.weaver.tools.Trace;
/*     */ import org.aspectj.weaver.tools.TraceFactory;
/*     */ import org.aspectj.weaver.tools.WeavingAdaptor;
/*     */ import org.aspectj.weaver.tools.cache.SimpleCache;
/*     */ import org.aspectj.weaver.tools.cache.SimpleCacheFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Aj
/*     */   implements ClassPreProcessor
/*     */ {
/*     */   private IWeavingContext weavingContext;
/*  44 */   public static SimpleCache laCache = SimpleCacheFactory.createSimpleCache();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static ReferenceQueue<ClassLoader> adaptorQueue = new ReferenceQueue<>();
/*     */   
/*  53 */   private static Trace trace = TraceFactory.getTraceFactory().getTrace(Aj.class); private static final String deleLoader = "sun.reflect.DelegatingClassLoader";
/*     */   
/*     */   public Aj() {
/*  56 */     this(null);
/*     */   }
/*     */   private static final String deleLoader2 = "jdk.internal.reflect.DelegatingClassLoader";
/*     */   public Aj(IWeavingContext context) {
/*  60 */     if (trace.isTraceEnabled())
/*  61 */       trace.enter("<init>", this, new Object[] { context, getClass().getClassLoader() }); 
/*  62 */     this.weavingContext = context;
/*  63 */     if (trace.isTraceEnabled()) {
/*  64 */       trace.exit("<init>");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] preProcess(String className, byte[] bytes, ClassLoader classLoader, ProtectionDomain protectionDomain) {
/*  85 */     if (classLoader == null || className == null || classLoader
/*  86 */       .getClass().getName().equals("sun.reflect.DelegatingClassLoader") || classLoader.getClass().getName().equals("jdk.internal.reflect.DelegatingClassLoader"))
/*     */     {
/*  88 */       return null;
/*     */     }
/*     */     
/*  91 */     if (loadersToSkip != null)
/*     */     {
/*  93 */       if (loadersToSkip.contains(classLoader.getClass().getName()))
/*     */       {
/*  95 */         return null;
/*     */       }
/*     */     }
/*     */     
/*  99 */     if (trace.isTraceEnabled())
/* 100 */       trace.enter("preProcess", this, new Object[] { className, bytes, classLoader }); 
/* 101 */     if (trace.isTraceEnabled()) {
/* 102 */       trace.event("preProcess", this, new Object[] { classLoader.getParent(), Thread.currentThread().getContextClassLoader() });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/* 136 */     } catch (Throwable th) {
/* 137 */       trace.error(className, th);
/* 138 */       Dump.dumpWithException(th);
/*     */ 
/*     */       
/* 141 */       if (trace.isTraceEnabled())
/* 142 */         trace.exit("preProcess", th); 
/* 143 */       return null;
/*     */     } finally {
/* 145 */       CompilationAndWeavingContext.resetForThread();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AdaptorKey
/*     */     extends WeakReference
/*     */   {
/*     */     private final int loaderHashCode;
/*     */     
/*     */     private final int sysHashCode;
/*     */     
/*     */     private final int hashValue;
/*     */     
/*     */     private final String loaderClass;
/*     */     
/*     */     public AdaptorKey(ClassLoader loader) {
/* 162 */       super((T)loader, (ReferenceQueue)Aj.adaptorQueue);
/* 163 */       this.loaderHashCode = loader.hashCode();
/* 164 */       this.sysHashCode = System.identityHashCode(loader);
/* 165 */       this.loaderClass = loader.getClass().getName();
/* 166 */       this.hashValue = this.loaderHashCode + this.sysHashCode + this.loaderClass.hashCode();
/*     */     }
/*     */     
/*     */     public ClassLoader getClassLoader() {
/* 170 */       ClassLoader instance = (ClassLoader)get();
/*     */       
/* 172 */       return instance;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 177 */       if (!(obj instanceof AdaptorKey)) {
/* 178 */         return false;
/*     */       }
/* 180 */       AdaptorKey other = (AdaptorKey)obj;
/* 181 */       return (other.loaderHashCode == this.loaderHashCode && other.sysHashCode == this.sysHashCode && this.loaderClass
/*     */         
/* 183 */         .equals(other.loaderClass));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 188 */       return this.hashValue;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int removeStaleAdaptors(boolean displayProgress) {
/* 202 */     int removed = 0;
/* 203 */     synchronized (WeaverContainer.weavingAdaptors) {
/* 204 */       if (displayProgress) {
/* 205 */         System.err.println("Weaver adaptors before queue processing:");
/* 206 */         Map<AdaptorKey, ExplicitlyInitializedClassLoaderWeavingAdaptor> m = WeaverContainer.weavingAdaptors;
/* 207 */         Set<AdaptorKey> keys = m.keySet();
/* 208 */         for (AdaptorKey object : keys) {
/* 209 */           System.err.println(object + " = " + WeaverContainer.weavingAdaptors.get(object));
/*     */         }
/*     */       } 
/* 212 */       Reference<?> o = adaptorQueue.poll();
/* 213 */       while (o != null) {
/* 214 */         if (displayProgress)
/* 215 */           System.err.println("Processing referencequeue entry " + o); 
/* 216 */         AdaptorKey wo = (AdaptorKey)o;
/* 217 */         boolean didit = (WeaverContainer.weavingAdaptors.remove(wo) != null);
/* 218 */         if (didit) {
/* 219 */           removed++;
/*     */         } else {
/* 221 */           throw new RuntimeException("Eh?? key=" + wo);
/*     */         } 
/* 223 */         if (displayProgress)
/* 224 */           System.err.println("Removed? " + didit); 
/* 225 */         o = adaptorQueue.poll();
/*     */       } 
/* 227 */       if (displayProgress) {
/* 228 */         System.err.println("Weaver adaptors after queue processing:");
/* 229 */         Map<AdaptorKey, ExplicitlyInitializedClassLoaderWeavingAdaptor> m = WeaverContainer.weavingAdaptors;
/* 230 */         Set<AdaptorKey> keys = m.keySet();
/* 231 */         for (AdaptorKey object : keys) {
/* 232 */           System.err.println(object + " = " + WeaverContainer.weavingAdaptors.get(object));
/*     */         }
/*     */       } 
/*     */     } 
/* 236 */     return removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getActiveAdaptorCount() {
/* 243 */     return WeaverContainer.weavingAdaptors.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkQ() {
/* 251 */     synchronized (adaptorQueue) {
/* 252 */       Reference<?> o = adaptorQueue.poll();
/* 253 */       while (o != null) {
/* 254 */         AdaptorKey wo = (AdaptorKey)o;
/*     */         
/* 256 */         WeaverContainer.weavingAdaptors.remove(wo);
/*     */         
/* 258 */         o = adaptorQueue.poll();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 263 */   public static List<String> loadersToSkip = null;
/*     */ 
/*     */   
/*     */   static {
/* 267 */     new ExplicitlyInitializedClassLoaderWeavingAdaptor(new ClassLoaderWeavingAdaptor());
/*     */     try {
/* 269 */       String loadersToSkipProperty = System.getProperty("aj.weaving.loadersToSkip", "");
/* 270 */       StringTokenizer st = new StringTokenizer(loadersToSkipProperty, ",");
/* 271 */       if (loadersToSkipProperty != null && loadersToSkip == null) {
/* 272 */         if (st.hasMoreTokens())
/*     */         {
/* 274 */           loadersToSkip = new ArrayList<>();
/*     */         }
/* 276 */         while (st.hasMoreTokens()) {
/* 277 */           String nextLoader = st.nextToken();
/* 278 */           loadersToSkip.add(nextLoader);
/*     */         } 
/*     */       } 
/* 281 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class WeaverContainer
/*     */   {
/* 292 */     static final Map<Aj.AdaptorKey, Aj.ExplicitlyInitializedClassLoaderWeavingAdaptor> weavingAdaptors = Collections.synchronizedMap(new HashMap<>());
/*     */     
/*     */     static WeavingAdaptor getWeaver(ClassLoader loader, IWeavingContext weavingContext) {
/* 295 */       Aj.ExplicitlyInitializedClassLoaderWeavingAdaptor adaptor = null;
/* 296 */       Aj.AdaptorKey adaptorKey = new Aj.AdaptorKey(loader);
/*     */       
/* 298 */       String loaderClassName = loader.getClass().getName();
/*     */       
/* 300 */       synchronized (weavingAdaptors) {
/* 301 */         Aj.checkQ();
/* 302 */         if (loader.equals(myClassLoader)) {
/* 303 */           adaptor = myClassLoaderAdaptor;
/*     */         } else {
/* 305 */           adaptor = weavingAdaptors.get(adaptorKey);
/*     */         } 
/* 307 */         if (adaptor == null) {
/*     */ 
/*     */           
/* 310 */           ClassLoaderWeavingAdaptor weavingAdaptor = new ClassLoaderWeavingAdaptor();
/* 311 */           adaptor = new Aj.ExplicitlyInitializedClassLoaderWeavingAdaptor(weavingAdaptor);
/* 312 */           if (myClassLoaderAdaptor == null && loader.equals(myClassLoader)) {
/* 313 */             myClassLoaderAdaptor = adaptor;
/*     */           } else {
/* 315 */             weavingAdaptors.put(adaptorKey, adaptor);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 320 */       return adaptor.getWeavingAdaptor(loader, weavingContext);
/*     */     }
/*     */ 
/*     */     
/* 324 */     private static final ClassLoader myClassLoader = WeavingAdaptor.class.getClassLoader();
/*     */     private static Aj.ExplicitlyInitializedClassLoaderWeavingAdaptor myClassLoaderAdaptor;
/*     */   }
/*     */   
/*     */   static class ExplicitlyInitializedClassLoaderWeavingAdaptor
/*     */   {
/*     */     private final ClassLoaderWeavingAdaptor weavingAdaptor;
/*     */     private boolean isInitialized;
/*     */     
/*     */     public ExplicitlyInitializedClassLoaderWeavingAdaptor(ClassLoaderWeavingAdaptor weavingAdaptor) {
/* 334 */       this.weavingAdaptor = weavingAdaptor;
/* 335 */       this.isInitialized = false;
/*     */     }
/*     */     
/*     */     private void initialize(ClassLoader loader, IWeavingContext weavingContext) {
/* 339 */       if (!this.isInitialized) {
/* 340 */         this.isInitialized = true;
/* 341 */         this.weavingAdaptor.initialize(loader, weavingContext);
/*     */       } 
/*     */     }
/*     */     
/*     */     public ClassLoaderWeavingAdaptor getWeavingAdaptor(ClassLoader loader, IWeavingContext weavingContext) {
/* 346 */       initialize(loader, weavingContext);
/* 347 */       return this.weavingAdaptor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace(ClassLoader loader) {
/* 355 */     ClassLoaderWeavingAdaptor weavingAdaptor = (ClassLoaderWeavingAdaptor)WeaverContainer.getWeaver(loader, this.weavingContext);
/* 356 */     return weavingAdaptor.getNamespace();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean generatedClassesExist(ClassLoader loader) {
/* 367 */     return ((ClassLoaderWeavingAdaptor)WeaverContainer.getWeaver(loader, this.weavingContext)).generatedClassesExistFor(null);
/*     */   }
/*     */   
/*     */   public void flushGeneratedClasses(ClassLoader loader) {
/* 371 */     ((ClassLoaderWeavingAdaptor)WeaverContainer.getWeaver(loader, this.weavingContext)).flushGeneratedClasses();
/*     */   }
/*     */ 
/*     */   
/*     */   public void prepareForRedefinition(ClassLoader loader, String className) {
/* 376 */     ((ClassLoaderWeavingAdaptor)WeaverContainer.getWeaver(loader, this.weavingContext)).flushGeneratedClassesFor(className);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\Aj.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */