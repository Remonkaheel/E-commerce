/*     */ package org.aspectj.weaver.loadtime.definition;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightXMLParser
/*     */ {
/*  28 */   private static Map<String, char[]> entities = (Map)new HashMap<>();
/*     */   
/*     */   static {
/*  31 */     entities.put("amp", new char[] { '&' });
/*  32 */     entities.put("quot", new char[] { '"' });
/*  33 */     entities.put("apos", new char[] { '\'' });
/*  34 */     entities.put("lt", new char[] { '<' });
/*  35 */     entities.put("gt", new char[] { '>' });
/*     */   }
/*     */ 
/*     */   
/*  39 */   private String name = null;
/*  40 */   private Map<String, Object> attributes = new HashMap<>();
/*  41 */   private ArrayList<LightXMLParser> children = new ArrayList<>(); private static final char NULL_CHAR = '\000'; private char pushedBackChar;
/*     */   private Reader reader;
/*     */   
/*     */   public ArrayList getChildrens() {
/*  45 */     return this.children;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  49 */     return this.name;
/*     */   }
/*     */   public void parseFromReader(Reader reader) throws Exception {
/*     */     char c;
/*  53 */     this.pushedBackChar = Character.MIN_VALUE;
/*  54 */     this.attributes = new HashMap<>();
/*  55 */     this.name = null;
/*  56 */     this.children = new ArrayList<>();
/*  57 */     this.reader = reader;
/*     */ 
/*     */     
/*     */     while (true) {
/*  61 */       c = skipBlanks();
/*     */ 
/*     */ 
/*     */       
/*  65 */       if (c != '<') {
/*  66 */         throw new Exception("LightParser Exception: Expected < but got: " + c);
/*     */       }
/*     */ 
/*     */       
/*  70 */       c = getNextChar();
/*     */ 
/*     */       
/*  73 */       if (c == '!' || c == '?') {
/*  74 */         skipCommentOrXmlTag(0); continue;
/*     */       }  break;
/*     */     } 
/*  77 */     pushBackChar(c);
/*     */     
/*  79 */     parseNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char skipBlanks() throws Exception {
/*     */     char c;
/*     */     while (true) {
/*  88 */       c = getNextChar();
/*  89 */       switch (c) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\r':
/*     */         case ' ':
/*     */           continue;
/*     */       }  break;
/*  96 */     }  return c;
/*     */   }
/*     */ 
/*     */   
/*     */   private char getWhitespaces(StringBuffer result) throws Exception {
/*     */     char c;
/*     */     while (true) {
/* 103 */       c = getNextChar();
/* 104 */       switch (c) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case ' ':
/* 108 */           result.append(c); continue;
/*     */         case '\r':
/*     */           continue;
/*     */       }  break;
/* 112 */     }  return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getNodeName(StringBuffer result) throws Exception {
/*     */     while (true) {
/* 122 */       char c = getNextChar();
/* 123 */       if ((c < 'a' || c > 'z') && (c > 'Z' || c < 'A') && (c > '9' || c < '0') && c != '_' && c != '-' && c != '.' && c != ':') {
/*     */         
/* 125 */         pushBackChar(c);
/*     */         return;
/*     */       } 
/* 128 */       result.append(c);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void getString(StringBuffer string) throws Exception {
/* 133 */     char delimiter = getNextChar();
/* 134 */     if (delimiter != '\'' && delimiter != '"') {
/* 135 */       throw new Exception("Parsing error. Expected ' or \"  but got: " + delimiter);
/*     */     }
/*     */ 
/*     */     
/*     */     while (true) {
/* 140 */       char c = getNextChar();
/* 141 */       if (c == delimiter)
/*     */         return; 
/* 143 */       if (c == '&') {
/* 144 */         mapEntity(string); continue;
/*     */       } 
/* 146 */       string.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void getPCData(StringBuffer data) throws Exception {
/*     */     while (true) {
/* 153 */       char c = getNextChar();
/* 154 */       if (c == '<') {
/* 155 */         c = getNextChar();
/* 156 */         if (c == '!') {
/* 157 */           checkCDATA(data); continue;
/*     */         } 
/* 159 */         pushBackChar(c);
/*     */         
/*     */         return;
/*     */       } 
/* 163 */       data.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkCDATA(StringBuffer buf) throws Exception {
/* 169 */     char c = getNextChar();
/* 170 */     if (c != '[') {
/* 171 */       pushBackChar(c);
/* 172 */       skipCommentOrXmlTag(0);
/* 173 */       return false;
/* 174 */     }  if (!checkLiteral("CDATA[")) {
/* 175 */       skipCommentOrXmlTag(1);
/* 176 */       return false;
/*     */     } 
/* 178 */     int delimiterCharsSkipped = 0;
/* 179 */     while (delimiterCharsSkipped < 3) {
/* 180 */       c = getNextChar();
/* 181 */       switch (c) {
/*     */         case ']':
/* 183 */           if (delimiterCharsSkipped < 2) {
/* 184 */             delimiterCharsSkipped++; continue;
/*     */           } 
/* 186 */           buf.append(']');
/* 187 */           buf.append(']');
/* 188 */           delimiterCharsSkipped = 0;
/*     */           continue;
/*     */         
/*     */         case '>':
/* 192 */           if (delimiterCharsSkipped < 2) {
/* 193 */             for (int j = 0; j < delimiterCharsSkipped; j++) {
/* 194 */               buf.append(']');
/*     */             }
/* 196 */             delimiterCharsSkipped = 0;
/* 197 */             buf.append('>'); continue;
/*     */           } 
/* 199 */           delimiterCharsSkipped = 3;
/*     */           continue;
/*     */       } 
/*     */       
/* 203 */       for (int i = 0; i < delimiterCharsSkipped; i++) {
/* 204 */         buf.append(']');
/*     */       }
/* 206 */       buf.append(c);
/* 207 */       delimiterCharsSkipped = 0;
/*     */     } 
/*     */     
/* 210 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void skipCommentOrXmlTag(int bracketLevel) throws Exception {
/* 215 */     char delim = Character.MIN_VALUE;
/* 216 */     int level = 1;
/*     */     
/* 218 */     if (bracketLevel == 0) {
/* 219 */       char c = getNextChar();
/* 220 */       if (c == '-') {
/* 221 */         c = getNextChar();
/* 222 */         if (c == ']') {
/* 223 */           bracketLevel--;
/* 224 */         } else if (c == '[') {
/* 225 */           bracketLevel++;
/* 226 */         } else if (c == '-') {
/* 227 */           skipComment();
/*     */           return;
/*     */         } 
/* 230 */       } else if (c == '[') {
/* 231 */         bracketLevel++;
/*     */       } 
/*     */     } 
/* 234 */     while (level > 0) {
/* 235 */       char c = getNextChar();
/* 236 */       if (delim == '\000') {
/* 237 */         if (c == '"' || c == '\'') {
/* 238 */           delim = c;
/* 239 */         } else if (bracketLevel <= 0) {
/* 240 */           if (c == '<') {
/* 241 */             level++;
/* 242 */           } else if (c == '>') {
/* 243 */             level--;
/*     */           } 
/*     */         } 
/* 246 */         if (c == '[') {
/* 247 */           bracketLevel++; continue;
/* 248 */         }  if (c == ']')
/* 249 */           bracketLevel--; 
/*     */         continue;
/*     */       } 
/* 252 */       if (c == delim) {
/* 253 */         delim = Character.MIN_VALUE;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseNode(LightXMLParser elt) throws Exception {
/* 261 */     StringBuffer buf = new StringBuffer();
/* 262 */     getNodeName(buf);
/* 263 */     String name = buf.toString();
/* 264 */     elt.setName(name);
/*     */     
/* 266 */     char c = skipBlanks();
/* 267 */     while (c != '>' && c != '/') {
/*     */       
/* 269 */       emptyBuf(buf);
/* 270 */       pushBackChar(c);
/* 271 */       getNodeName(buf);
/* 272 */       String key = buf.toString();
/* 273 */       c = skipBlanks();
/* 274 */       if (c != '=') {
/* 275 */         throw new Exception("Parsing error. Expected = but got: " + c);
/*     */       }
/*     */       
/* 278 */       pushBackChar(skipBlanks());
/*     */       
/* 280 */       emptyBuf(buf);
/* 281 */       getString(buf);
/*     */       
/* 283 */       elt.setAttribute(key, buf);
/*     */ 
/*     */       
/* 286 */       c = skipBlanks();
/*     */     } 
/* 288 */     if (c == '/') {
/* 289 */       c = getNextChar();
/* 290 */       if (c != '>') {
/* 291 */         throw new Exception("Parsing error. Expected > but got: " + c);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 297 */     emptyBuf(buf);
/* 298 */     c = getWhitespaces(buf);
/* 299 */     if (c != '<') {
/*     */       
/* 301 */       pushBackChar(c);
/* 302 */       getPCData(buf);
/*     */     } else {
/*     */       
/*     */       while (true) {
/* 306 */         c = getNextChar();
/* 307 */         if (c == '!') {
/* 308 */           if (checkCDATA(buf)) {
/* 309 */             getPCData(buf);
/*     */             break;
/*     */           } 
/* 312 */           c = getWhitespaces(buf);
/* 313 */           if (c != '<') {
/* 314 */             pushBackChar(c);
/* 315 */             getPCData(buf);
/*     */             break;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 320 */         if (c != '/') {
/* 321 */           emptyBuf(buf);
/*     */         }
/* 323 */         if (c == '/') {
/* 324 */           pushBackChar(c);
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 330 */     if (buf.length() == 0) {
/*     */       
/* 332 */       while (c != '/') {
/* 333 */         if (c == '!') {
/* 334 */           for (int i = 0; i < 2; i++) {
/* 335 */             c = getNextChar();
/* 336 */             if (c != '-') {
/* 337 */               throw new Exception("Parsing error. Expected element or comment");
/*     */             }
/*     */           } 
/* 340 */           skipComment();
/*     */         } else {
/*     */           
/* 343 */           pushBackChar(c);
/* 344 */           LightXMLParser child = createAnotherElement();
/* 345 */           parseNode(child);
/* 346 */           elt.addChild(child);
/*     */         } 
/* 348 */         c = skipBlanks();
/* 349 */         if (c != '<') {
/* 350 */           throw new Exception("Parsing error. Expected <, but got: " + c);
/*     */         }
/* 352 */         c = getNextChar();
/*     */       } 
/* 354 */       pushBackChar(c);
/*     */     } 
/*     */     
/* 357 */     c = getNextChar();
/* 358 */     if (c != '/') {
/* 359 */       throw new Exception("Parsing error. Expected /, but got: " + c);
/*     */     }
/* 361 */     pushBackChar(skipBlanks());
/* 362 */     if (!checkLiteral(name)) {
/* 363 */       throw new Exception("Parsing error. Expected " + name);
/*     */     }
/* 365 */     if (skipBlanks() != '>') {
/* 366 */       throw new Exception("Parsing error. Expected >, but got: " + c);
/*     */     }
/*     */   }
/*     */   
/*     */   private void skipComment() throws Exception {
/* 371 */     int dashes = 2;
/* 372 */     while (dashes > 0) {
/* 373 */       char ch = getNextChar();
/* 374 */       if (ch == '-') {
/* 375 */         dashes--; continue;
/*     */       } 
/* 377 */       dashes = 2;
/*     */     } 
/*     */ 
/*     */     
/* 381 */     char nextChar = getNextChar();
/* 382 */     if (nextChar != '>') {
/* 383 */       throw new Exception("Parsing error. Expected > but got: " + nextChar);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkLiteral(String literal) throws Exception {
/* 388 */     int length = literal.length();
/* 389 */     for (int i = 0; i < length; i++) {
/* 390 */       if (getNextChar() != literal.charAt(i)) {
/* 391 */         return false;
/*     */       }
/*     */     } 
/* 394 */     return true;
/*     */   }
/*     */   
/*     */   private char getNextChar() throws Exception {
/* 398 */     if (this.pushedBackChar != '\000') {
/* 399 */       char c = this.pushedBackChar;
/* 400 */       this.pushedBackChar = Character.MIN_VALUE;
/* 401 */       return c;
/*     */     } 
/* 403 */     int i = this.reader.read();
/* 404 */     if (i < 0) {
/* 405 */       throw new Exception("Parsing error. Unexpected end of data");
/*     */     }
/* 407 */     return (char)i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void mapEntity(StringBuffer buf) throws Exception {
/* 413 */     this; char c = Character.MIN_VALUE;
/* 414 */     StringBuilder keyBuf = new StringBuilder();
/*     */     while (true) {
/* 416 */       c = getNextChar();
/* 417 */       if (c == ';') {
/*     */         break;
/*     */       }
/* 420 */       keyBuf.append(c);
/*     */     } 
/* 422 */     String key = keyBuf.toString();
/* 423 */     if (key.charAt(0) == '#') {
/*     */       try {
/* 425 */         if (key.charAt(1) == 'x') {
/* 426 */           c = (char)Integer.parseInt(key.substring(2), 16);
/*     */         } else {
/* 428 */           c = (char)Integer.parseInt(key.substring(1), 10);
/*     */         } 
/* 430 */       } catch (NumberFormatException e) {
/* 431 */         throw new Exception("Unknown entity: " + key);
/*     */       } 
/* 433 */       buf.append(c);
/*     */     } else {
/* 435 */       char[] value = entities.get(key);
/* 436 */       if (value == null) {
/* 437 */         throw new Exception("Unknown entity: " + key);
/*     */       }
/* 439 */       buf.append(value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void pushBackChar(char c) {
/* 444 */     this.pushedBackChar = c;
/*     */   }
/*     */   
/*     */   private void addChild(LightXMLParser child) {
/* 448 */     this.children.add(child);
/*     */   }
/*     */   
/*     */   private void setAttribute(String name, Object value) {
/* 452 */     this.attributes.put(name, value.toString());
/*     */   }
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 456 */     return this.attributes;
/*     */   }
/*     */   
/*     */   private LightXMLParser createAnotherElement() {
/* 460 */     return new LightXMLParser();
/*     */   }
/*     */   
/*     */   private void setName(String name) {
/* 464 */     this.name = name;
/*     */   }
/*     */   
/*     */   private void emptyBuf(StringBuffer buf) {
/* 468 */     buf.setLength(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\definition\LightXMLParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */