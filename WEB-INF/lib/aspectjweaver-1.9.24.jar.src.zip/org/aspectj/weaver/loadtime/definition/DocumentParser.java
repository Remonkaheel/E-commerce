/*     */ package org.aspectj.weaver.loadtime.definition;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Hashtable;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.aspectj.util.LangUtil;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentParser
/*     */   extends DefaultHandler
/*     */ {
/*     */   private static final boolean LIGHTPARSER;
/*     */   private static boolean CACHE;
/*  86 */   private static Hashtable<String, Definition> parsedFiles = new Hashtable<>(); private Definition.ConcreteAspect activeConcreteAspectDefinition; private boolean inAspects;
/*     */   private boolean inWeaver;
/*     */   private boolean inAspectJ;
/*     */   
/*     */   static {
/*  91 */     boolean value = false;
/*     */     try {
/*  93 */       value = System.getProperty("org.aspectj.weaver.loadtime.configuration.cache", "true").equalsIgnoreCase("true");
/*  94 */     } catch (Throwable t) {
/*  95 */       t.printStackTrace();
/*     */     } 
/*  97 */     CACHE = value;
/*     */     
/*  99 */     value = false;
/*     */     
/*     */     try {
/* 102 */       value = System.getProperty("org.aspectj.weaver.loadtime.configuration.lightxmlparser", "false").equalsIgnoreCase("true");
/* 103 */     } catch (Throwable t) {
/* 104 */       t.printStackTrace();
/*     */     } 
/* 106 */     LIGHTPARSER = value;
/*     */   }
/*     */ 
/*     */   
/* 110 */   private final Definition definition = new Definition(); private static final String DECLARE_ANNOTATION_ELEMENT = "declare-annotation"; private static final String EXPRESSION_ATTRIBUTE = "expression"; private static final String WITHIN_ATTRIBUTE = "within"; private static final String AROUND_ELEMENT = "around"; private static final String AFTER_THROWING_ELEMENT = "after-throwing"; private static final String AFTER_RETURNING_ELEMENT = "after-returning"; private static final String AFTER_ELEMENT = "after"; private static final String BEFORE_ELEMENT = "before"; private static final String POINTCUT_ELEMENT = "pointcut"; private static final String PERCLAUSE_ATTRIBUTE = "perclause"; private static final String PRECEDENCE_ATTRIBUTE = "precedence"; private static final String EXTEND_ATTRIBUTE = "extends"; private static final String REQUIRES_ATTRIBUTE = "requires";
/*     */   private static final String SCOPE_ATTRIBUTE = "scope";
/*     */   
/*     */   public static Definition parse(URL url) throws Exception {
/* 114 */     if (CACHE && parsedFiles.containsKey(url.toString())) {
/* 115 */       return parsedFiles.get(url.toString());
/*     */     }
/* 117 */     Definition def = null;
/*     */     
/* 119 */     if (LIGHTPARSER) {
/* 120 */       def = SimpleAOPParser.parse(url);
/*     */     } else {
/* 122 */       def = saxParsing(url);
/*     */     } 
/*     */     
/* 125 */     if (CACHE && def.getAspectClassNames().size() > 0) {
/* 126 */       parsedFiles.put(url.toString(), def);
/*     */     }
/*     */     
/* 129 */     return def;
/*     */   }
/*     */   private static final String NAME_ATTRIBUTE = "name"; private static final String CONCRETE_ASPECT_ELEMENT = "concrete-aspect"; private static final String ASPECT_ELEMENT = "aspect"; private static final String ASPECTS_ELEMENT = "aspects"; private static final String OPTIONS_ATTRIBUTE = "options"; private static final String EXCLUDE_ELEMENT = "exclude"; private static final String INCLUDE_ELEMENT = "include"; private static final String DUMP_PERCLASSLOADERDIR_ATTRIBUTE = "perclassloaderdumpdir"; private static final String DUMP_BEFOREANDAFTER_ATTRIBUTE = "beforeandafter"; private static final String DUMP_ELEMENT = "dump"; private static final String WEAVER_ELEMENT = "weaver"; private static final String ASPECTJ_ELEMENT = "aspectj"; private static final String DTD_PUBLIC_ID_ALIAS = "-//AspectJ//DTD//EN"; private static final String DTD_PUBLIC_ID = "-//AspectJ//DTD 1.5.0//EN";
/*     */   private static Definition saxParsing(URL url) throws SAXException, ParserConfigurationException, IOException {
/* 133 */     DocumentParser parser = new DocumentParser();
/*     */     
/* 135 */     XMLReader xmlReader = getXMLReader();
/* 136 */     xmlReader.setContentHandler(parser);
/* 137 */     xmlReader.setErrorHandler(parser);
/*     */     
/*     */     try {
/* 140 */       xmlReader.setFeature("https://xml.org/sax/features/validation", false);
/* 141 */     } catch (SAXException sAXException) {}
/*     */ 
/*     */     
/*     */     try {
/* 145 */       xmlReader.setFeature("https://xml.org/sax/features/external-general-entities", false);
/* 146 */     } catch (SAXException sAXException) {}
/*     */ 
/*     */     
/*     */     try {
/* 150 */       xmlReader.setFeature("https://xml.org/sax/features/external-parameter-entities", false);
/* 151 */     } catch (SAXException sAXException) {}
/*     */ 
/*     */ 
/*     */     
/* 155 */     xmlReader.setEntityResolver(parser);
/* 156 */     InputStream in = url.openStream();
/* 157 */     xmlReader.parse(new InputSource(in));
/* 158 */     return parser.definition;
/*     */   }
/*     */   
/*     */   private static XMLReader getXMLReader() throws SAXException, ParserConfigurationException {
/* 162 */     XMLReader xmlReader = null;
/*     */     
/*     */     try {
/* 165 */       xmlReader = XMLReaderFactory.createXMLReader();
/*     */ 
/*     */     
/*     */     }
/* 169 */     catch (SAXException ex) {
/* 170 */       xmlReader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
/*     */     } 
/* 172 */     return xmlReader;
/*     */   }
/*     */   
/*     */   public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
/* 176 */     if (publicId.equals("-//AspectJ//DTD 1.5.0//EN") || publicId.equals("-//AspectJ//DTD//EN")) {
/* 177 */       InputStream in = DocumentParser.class.getResourceAsStream("/aspectj_1_5_0.dtd");
/* 178 */       if (in == null) {
/* 179 */         System.err.println("AspectJ - WARN - could not read DTD " + publicId);
/* 180 */         return null;
/*     */       } 
/* 182 */       return new InputSource(in);
/*     */     } 
/*     */     
/* 185 */     System.err.println("AspectJ - WARN - unknown DTD " + publicId + " - consider using " + "-//AspectJ//DTD 1.5.0//EN");
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/* 191 */     if ("aspect".equals(qName)) {
/* 192 */       String name = attributes.getValue("name");
/* 193 */       String scopePattern = replaceXmlAnd(attributes.getValue("scope"));
/* 194 */       String requiredType = attributes.getValue("requires");
/* 195 */       if (!isNull(name)) {
/* 196 */         this.definition.getAspectClassNames().add(name);
/* 197 */         if (scopePattern != null) {
/* 198 */           this.definition.addScopedAspect(name, scopePattern);
/*     */         }
/* 200 */         if (requiredType != null) {
/* 201 */           this.definition.setAspectRequires(name, requiredType);
/*     */         }
/*     */       } 
/* 204 */     } else if ("weaver".equals(qName)) {
/* 205 */       String options = attributes.getValue("options");
/* 206 */       if (!isNull(options)) {
/* 207 */         this.definition.appendWeaverOptions(options);
/*     */       }
/* 209 */       this.inWeaver = true;
/* 210 */     } else if ("concrete-aspect".equals(qName)) {
/* 211 */       String name = attributes.getValue("name");
/* 212 */       String extend = attributes.getValue("extends");
/* 213 */       String precedence = attributes.getValue("precedence");
/* 214 */       String perclause = attributes.getValue("perclause");
/* 215 */       if (!isNull(name)) {
/* 216 */         this.activeConcreteAspectDefinition = new Definition.ConcreteAspect(name, extend, precedence, perclause);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 223 */         this.definition.getConcreteAspects().add(this.activeConcreteAspectDefinition);
/*     */       } 
/* 225 */     } else if ("pointcut".equals(qName) && this.activeConcreteAspectDefinition != null) {
/* 226 */       String name = attributes.getValue("name");
/* 227 */       String expression = attributes.getValue("expression");
/* 228 */       if (!isNull(name) && !isNull(expression)) {
/* 229 */         this.activeConcreteAspectDefinition.pointcuts.add(new Definition.Pointcut(name, replaceXmlAnd(expression)));
/*     */       }
/* 231 */     } else if ("declare-annotation".equals(qName) && this.activeConcreteAspectDefinition != null) {
/* 232 */       String methodSig = attributes.getValue("method");
/* 233 */       String fieldSig = attributes.getValue("field");
/* 234 */       String typePat = attributes.getValue("type");
/* 235 */       String anno = attributes.getValue("annotation");
/* 236 */       if (isNull(anno)) {
/* 237 */         throw new SAXException("Badly formed <declare-annotation> element, 'annotation' value is missing");
/*     */       }
/* 239 */       if (isNull(methodSig) && isNull(fieldSig) && isNull(typePat)) {
/* 240 */         throw new SAXException("Badly formed <declare-annotation> element, need one of 'method'/'field'/'type' specified");
/*     */       }
/* 242 */       if (!isNull(methodSig))
/*     */       {
/* 244 */         this.activeConcreteAspectDefinition.declareAnnotations.add(new Definition.DeclareAnnotation(Definition.DeclareAnnotationKind.Method, methodSig, anno));
/*     */       }
/* 246 */       else if (!isNull(fieldSig))
/*     */       {
/* 248 */         this.activeConcreteAspectDefinition.declareAnnotations.add(new Definition.DeclareAnnotation(Definition.DeclareAnnotationKind.Field, fieldSig, anno));
/*     */       }
/* 250 */       else if (!isNull(typePat))
/*     */       {
/* 252 */         this.activeConcreteAspectDefinition.declareAnnotations.add(new Definition.DeclareAnnotation(Definition.DeclareAnnotationKind.Type, typePat, anno));
/*     */       }
/*     */     
/* 255 */     } else if ("before".equals(qName) && this.activeConcreteAspectDefinition != null) {
/* 256 */       String pointcut = attributes.getValue("pointcut");
/* 257 */       String adviceClass = attributes.getValue("invokeClass");
/* 258 */       String adviceMethod = attributes.getValue("invokeMethod");
/* 259 */       if (!isNull(pointcut) && !isNull(adviceClass) && !isNull(adviceMethod)) {
/* 260 */         this.activeConcreteAspectDefinition.pointcutsAndAdvice.add(new Definition.PointcutAndAdvice(Definition.AdviceKind.Before, 
/* 261 */               replaceXmlAnd(pointcut), adviceClass, adviceMethod));
/*     */       } else {
/* 263 */         throw new SAXException("Badly formed <before> element");
/*     */       } 
/* 265 */     } else if ("after".equals(qName) && this.activeConcreteAspectDefinition != null) {
/* 266 */       String pointcut = attributes.getValue("pointcut");
/* 267 */       String adviceClass = attributes.getValue("invokeClass");
/* 268 */       String adviceMethod = attributes.getValue("invokeMethod");
/* 269 */       if (!isNull(pointcut) && !isNull(adviceClass) && !isNull(adviceMethod)) {
/* 270 */         this.activeConcreteAspectDefinition.pointcutsAndAdvice.add(new Definition.PointcutAndAdvice(Definition.AdviceKind.After, 
/* 271 */               replaceXmlAnd(pointcut), adviceClass, adviceMethod));
/*     */       } else {
/* 273 */         throw new SAXException("Badly formed <after> element");
/*     */       } 
/* 275 */     } else if ("around".equals(qName) && this.activeConcreteAspectDefinition != null) {
/* 276 */       String pointcut = attributes.getValue("pointcut");
/* 277 */       String adviceClass = attributes.getValue("invokeClass");
/* 278 */       String adviceMethod = attributes.getValue("invokeMethod");
/* 279 */       if (!isNull(pointcut) && !isNull(adviceClass) && !isNull(adviceMethod)) {
/* 280 */         this.activeConcreteAspectDefinition.pointcutsAndAdvice.add(new Definition.PointcutAndAdvice(Definition.AdviceKind.Around, 
/* 281 */               replaceXmlAnd(pointcut), adviceClass, adviceMethod));
/*     */       } else {
/* 283 */         throw new SAXException("Badly formed <before> element");
/*     */       } 
/* 285 */     } else if ("aspectj".equals(qName)) {
/* 286 */       if (this.inAspectJ) {
/* 287 */         throw new SAXException("Found nested <aspectj> element");
/*     */       }
/* 289 */       this.inAspectJ = true;
/* 290 */     } else if ("aspects".equals(qName)) {
/* 291 */       this.inAspects = true;
/* 292 */     } else if ("include".equals(qName) && this.inWeaver) {
/* 293 */       String typePattern = getWithinAttribute(attributes);
/* 294 */       if (!isNull(typePattern)) {
/* 295 */         this.definition.getIncludePatterns().add(typePattern);
/*     */       }
/* 297 */     } else if ("exclude".equals(qName) && this.inWeaver) {
/* 298 */       String typePattern = getWithinAttribute(attributes);
/* 299 */       if (!isNull(typePattern)) {
/* 300 */         this.definition.getExcludePatterns().add(typePattern);
/*     */       }
/* 302 */     } else if ("dump".equals(qName) && this.inWeaver) {
/* 303 */       String typePattern = getWithinAttribute(attributes);
/* 304 */       if (!isNull(typePattern)) {
/* 305 */         this.definition.getDumpPatterns().add(typePattern);
/*     */       }
/* 307 */       String beforeAndAfter = attributes.getValue("beforeandafter");
/* 308 */       if (isTrue(beforeAndAfter)) {
/* 309 */         this.definition.setDumpBefore(true);
/*     */       }
/* 311 */       String perWeaverDumpDir = attributes.getValue("perclassloaderdumpdir");
/* 312 */       if (isTrue(perWeaverDumpDir)) {
/* 313 */         this.definition.setCreateDumpDirPerClassloader(true);
/*     */       }
/* 315 */     } else if ("exclude".equals(qName) && this.inAspects) {
/* 316 */       String typePattern = getWithinAttribute(attributes);
/* 317 */       if (!isNull(typePattern)) {
/* 318 */         this.definition.getAspectExcludePatterns().add(typePattern);
/*     */       }
/* 320 */     } else if ("include".equals(qName) && this.inAspects) {
/* 321 */       String typePattern = getWithinAttribute(attributes);
/* 322 */       if (!isNull(typePattern)) {
/* 323 */         this.definition.getAspectIncludePatterns().add(typePattern);
/*     */       }
/*     */     } else {
/* 326 */       throw new SAXException("Unknown element while parsing <aspectj> element: " + qName);
/*     */     } 
/* 328 */     super.startElement(uri, localName, qName, attributes);
/*     */   }
/*     */   
/*     */   private String getWithinAttribute(Attributes attributes) {
/* 332 */     return replaceXmlAnd(attributes.getValue("within"));
/*     */   }
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 336 */     if ("concrete-aspect".equals(qName)) {
/* 337 */       this.activeConcreteAspectDefinition = null;
/* 338 */     } else if ("aspectj".equals(qName)) {
/* 339 */       this.inAspectJ = false;
/* 340 */     } else if ("weaver".equals(qName)) {
/* 341 */       this.inWeaver = false;
/* 342 */     } else if ("aspects".equals(qName)) {
/* 343 */       this.inAspects = false;
/*     */     } 
/* 345 */     super.endElement(uri, localName, qName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warning(SAXParseException e) throws SAXException {
/* 350 */     super.warning(e);
/*     */   }
/*     */   
/*     */   public void error(SAXParseException e) throws SAXException {
/* 354 */     super.error(e);
/*     */   }
/*     */   
/*     */   public void fatalError(SAXParseException e) throws SAXException {
/* 358 */     super.fatalError(e);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String replaceXmlAnd(String expression) {
/* 363 */     return LangUtil.replace(expression, " AND ", " && ");
/*     */   }
/*     */   
/*     */   private boolean isNull(String s) {
/* 367 */     return (s == null || s.length() <= 0);
/*     */   }
/*     */   
/*     */   private boolean isTrue(String s) {
/* 371 */     return (s != null && s.equals("true"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deactivateCaching() {
/* 378 */     CACHE = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\definition\DocumentParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */