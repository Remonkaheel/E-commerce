/*     */ package org.aspectj.weaver.loadtime.definition;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.LangUtil;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleAOPParser
/*     */ {
/*     */   private static final String ASPECTJ_ELEMENT = "aspectj";
/*     */   private static final String WEAVER_ELEMENT = "weaver";
/*     */   private static final String DUMP_ELEMENT = "dump";
/*     */   private static final String DUMP_BEFOREANDAFTER_ATTRIBUTE = "beforeandafter";
/*     */   private static final String DUMP_PERCLASSLOADERDIR_ATTRIBUTE = "perclassloaderdumpdir";
/*     */   private static final String INCLUDE_ELEMENT = "include";
/*     */   private static final String EXCLUDE_ELEMENT = "exclude";
/*     */   private static final String OPTIONS_ATTRIBUTE = "options";
/*     */   private static final String ASPECTS_ELEMENT = "aspects";
/*     */   private static final String ASPECT_ELEMENT = "aspect";
/*     */   private static final String CONCRETE_ASPECT_ELEMENT = "concrete-aspect";
/*     */   private static final String NAME_ATTRIBUTE = "name";
/*     */   private static final String SCOPE_ATTRIBUTE = "scope";
/*     */   private static final String REQUIRES_ATTRIBUTE = "requires";
/*     */   private static final String EXTEND_ATTRIBUTE = "extends";
/*     */   private static final String PRECEDENCE_ATTRIBUTE = "precedence";
/*     */   private static final String PERCLAUSE_ATTRIBUTE = "perclause";
/*     */   private static final String POINTCUT_ELEMENT = "pointcut";
/*     */   private static final String WITHIN_ATTRIBUTE = "within";
/*     */   private static final String EXPRESSION_ATTRIBUTE = "expression";
/*     */   private static final String DECLARE_ANNOTATION = "declare-annotation";
/*     */   private static final String ANNONATION_TAG = "annotation";
/*     */   private static final String ANNO_KIND_TYPE = "type";
/*     */   private static final String ANNO_KIND_METHOD = "method";
/*     */   private static final String ANNO_KIND_FIELD = "field";
/*     */   private static final String BEFORE_ELEMENT = "before";
/*     */   private static final String AFTER_ELEMENT = "after";
/*     */   private static final String AROUND_ELEMENT = "around";
/*  70 */   private final Definition m_definition = new Definition();
/*     */   private boolean m_inAspectJ;
/*     */   private boolean m_inWeaver;
/*     */   
/*     */   public static Definition parse(URL url) throws Exception {
/*  75 */     InputStream in = url.openStream();
/*  76 */     LightXMLParser xml = new LightXMLParser();
/*  77 */     xml.parseFromReader(new InputStreamReader(in));
/*  78 */     SimpleAOPParser sap = new SimpleAOPParser();
/*  79 */     traverse(sap, xml);
/*  80 */     return sap.m_definition;
/*     */   }
/*     */   private boolean m_inAspects; private Definition.ConcreteAspect m_lastConcreteAspect;
/*     */   private void startElement(String qName, Map<String, Object> attrMap) throws Exception {
/*  84 */     if ("aspect".equals(qName)) {
/*  85 */       String name = (String)attrMap.get("name");
/*  86 */       String scopePattern = replaceXmlAnd((String)attrMap
/*  87 */           .get("scope"));
/*  88 */       String requiredType = (String)attrMap.get("requires");
/*  89 */       if (!isNull(name)) {
/*  90 */         this.m_definition.getAspectClassNames().add(name);
/*  91 */         if (scopePattern != null) {
/*  92 */           this.m_definition.addScopedAspect(name, scopePattern);
/*     */         }
/*  94 */         if (requiredType != null) {
/*  95 */           this.m_definition.setAspectRequires(name, requiredType);
/*     */         }
/*     */       } 
/*  98 */     } else if ("weaver".equals(qName)) {
/*  99 */       String options = (String)attrMap.get("options");
/* 100 */       if (!isNull(options)) {
/* 101 */         this.m_definition.appendWeaverOptions(options);
/*     */       }
/* 103 */       this.m_inWeaver = true;
/* 104 */     } else if ("concrete-aspect".equals(qName)) {
/* 105 */       String name = (String)attrMap.get("name");
/* 106 */       String extend = (String)attrMap.get("extends");
/* 107 */       String precedence = (String)attrMap.get("precedence");
/* 108 */       String perclause = (String)attrMap.get("perclause");
/* 109 */       if (!isNull(name)) {
/* 110 */         this.m_lastConcreteAspect = new Definition.ConcreteAspect(name, extend, precedence, perclause);
/*     */         
/* 112 */         this.m_definition.getConcreteAspects().add(this.m_lastConcreteAspect);
/*     */       } 
/* 114 */     } else if ("pointcut".equals(qName) && this.m_lastConcreteAspect != null) {
/*     */       
/* 116 */       String name = (String)attrMap.get("name");
/* 117 */       String expression = (String)attrMap.get("expression");
/* 118 */       if (!isNull(name) && !isNull(expression)) {
/* 119 */         this.m_lastConcreteAspect.pointcuts.add(new Definition.Pointcut(name, 
/* 120 */               replaceXmlAnd(expression)));
/*     */       }
/* 122 */     } else if ("aspectj".equals(qName)) {
/* 123 */       if (this.m_inAspectJ) {
/* 124 */         throw new Exception("Found nested <aspectj> element");
/*     */       }
/* 126 */       this.m_inAspectJ = true;
/* 127 */     } else if ("aspects".equals(qName)) {
/* 128 */       this.m_inAspects = true;
/* 129 */     } else if ("include".equals(qName) && this.m_inWeaver) {
/* 130 */       String typePattern = getWithinAttribute(attrMap);
/* 131 */       if (!isNull(typePattern)) {
/* 132 */         this.m_definition.getIncludePatterns().add(typePattern);
/*     */       }
/* 134 */     } else if ("exclude".equals(qName) && this.m_inWeaver) {
/* 135 */       String typePattern = getWithinAttribute(attrMap);
/* 136 */       if (!isNull(typePattern)) {
/* 137 */         this.m_definition.getExcludePatterns().add(typePattern);
/*     */       }
/* 139 */     } else if ("dump".equals(qName) && this.m_inWeaver) {
/* 140 */       String typePattern = getWithinAttribute(attrMap);
/* 141 */       if (!isNull(typePattern)) {
/* 142 */         this.m_definition.getDumpPatterns().add(typePattern);
/*     */       }
/*     */       
/* 145 */       String beforeAndAfter = (String)attrMap.get("beforeandafter");
/* 146 */       if (isTrue(beforeAndAfter)) {
/* 147 */         this.m_definition.setDumpBefore(true);
/*     */       }
/*     */       
/* 150 */       String perWeaverDumpDir = (String)attrMap.get("perclassloaderdumpdir");
/* 151 */       if (isTrue(perWeaverDumpDir)) {
/* 152 */         this.m_definition.setCreateDumpDirPerClassloader(true);
/*     */       }
/* 154 */     } else if ("exclude".equals(qName) && this.m_inAspects) {
/* 155 */       String typePattern = getWithinAttribute(attrMap);
/* 156 */       if (!isNull(typePattern)) {
/* 157 */         this.m_definition.getAspectExcludePatterns().add(typePattern);
/*     */       }
/* 159 */     } else if ("include".equals(qName) && this.m_inAspects) {
/* 160 */       String typePattern = getWithinAttribute(attrMap);
/* 161 */       if (!isNull(typePattern)) {
/* 162 */         this.m_definition.getAspectIncludePatterns().add(typePattern);
/*     */       }
/* 164 */     } else if ("declare-annotation".equals(qName) && this.m_inAspects) {
/* 165 */       String anno = (String)attrMap.get("annotation");
/* 166 */       if (!isNull(anno)) {
/* 167 */         String pattern = (String)attrMap.get("field");
/* 168 */         if (pattern != null) {
/* 169 */           this.m_lastConcreteAspect.declareAnnotations.add(new Definition.DeclareAnnotation(Definition.DeclareAnnotationKind.Field, pattern, anno));
/*     */         }
/*     */         else {
/*     */           
/* 173 */           pattern = (String)attrMap.get("method");
/* 174 */           if (pattern != null) {
/* 175 */             this.m_lastConcreteAspect.declareAnnotations.add(new Definition.DeclareAnnotation(Definition.DeclareAnnotationKind.Method, pattern, anno));
/*     */           }
/*     */           else {
/*     */             
/* 179 */             pattern = (String)attrMap.get("type");
/* 180 */             if (pattern != null) {
/* 181 */               this.m_lastConcreteAspect.declareAnnotations.add(new Definition.DeclareAnnotation(Definition.DeclareAnnotationKind.Type, pattern, anno));
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 189 */     } else if ("before".equals(qName) && this.m_inAspects) {
/* 190 */       String pointcut = (String)attrMap.get("pointcut");
/* 191 */       String adviceClass = (String)attrMap.get("invokeClass");
/* 192 */       String adviceMethod = (String)attrMap.get("invokeMethod");
/* 193 */       if (!isNull(pointcut) && !isNull(adviceClass) && !isNull(adviceMethod)) {
/* 194 */         this.m_lastConcreteAspect.pointcutsAndAdvice.add(new Definition.PointcutAndAdvice(Definition.AdviceKind.Before, 
/* 195 */               replaceXmlAnd(pointcut), adviceClass, adviceMethod));
/*     */       } else {
/* 197 */         throw new SAXException("Badly formed <before> element");
/*     */       } 
/* 199 */     } else if ("after".equals(qName) && this.m_inAspects) {
/* 200 */       String pointcut = (String)attrMap.get("pointcut");
/* 201 */       String adviceClass = (String)attrMap.get("invokeClass");
/* 202 */       String adviceMethod = (String)attrMap.get("invokeMethod");
/* 203 */       if (!isNull(pointcut) && !isNull(adviceClass) && !isNull(adviceMethod)) {
/* 204 */         this.m_lastConcreteAspect.pointcutsAndAdvice.add(new Definition.PointcutAndAdvice(Definition.AdviceKind.After, 
/* 205 */               replaceXmlAnd(pointcut), adviceClass, adviceMethod));
/*     */       } else {
/* 207 */         throw new SAXException("Badly formed <after> element");
/*     */       } 
/* 209 */     } else if ("around".equals(qName) && this.m_inAspects) {
/* 210 */       String pointcut = (String)attrMap.get("pointcut");
/* 211 */       String adviceClass = (String)attrMap.get("invokeClass");
/* 212 */       String adviceMethod = (String)attrMap.get("invokeMethod");
/* 213 */       if (!isNull(pointcut) && !isNull(adviceClass) && !isNull(adviceMethod)) {
/* 214 */         this.m_lastConcreteAspect.pointcutsAndAdvice.add(new Definition.PointcutAndAdvice(Definition.AdviceKind.Around, 
/* 215 */               replaceXmlAnd(pointcut), adviceClass, adviceMethod));
/*     */       }
/*     */     } else {
/*     */       
/* 219 */       throw new Exception("Unknown element while parsing <aspectj> element: " + qName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void endElement(String qName) throws Exception {
/* 225 */     if ("concrete-aspect".equals(qName)) {
/* 226 */       this.m_lastConcreteAspect = null;
/* 227 */     } else if ("aspectj".equals(qName)) {
/* 228 */       this.m_inAspectJ = false;
/* 229 */     } else if ("weaver".equals(qName)) {
/* 230 */       this.m_inWeaver = false;
/* 231 */     } else if ("aspects".equals(qName)) {
/* 232 */       this.m_inAspects = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getWithinAttribute(Map<String, Object> attributes) {
/* 237 */     return replaceXmlAnd((String)attributes.get("within"));
/*     */   }
/*     */ 
/*     */   
/*     */   private static String replaceXmlAnd(String expression) {
/* 242 */     return LangUtil.replace(expression, " AND ", " && ");
/*     */   }
/*     */   
/*     */   private boolean isNull(String s) {
/* 246 */     return (s == null || s.length() <= 0);
/*     */   }
/*     */   
/*     */   private boolean isTrue(String s) {
/* 250 */     return (s != null && s.equals("true"));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void traverse(SimpleAOPParser sap, LightXMLParser xml) throws Exception {
/* 255 */     sap.startElement(xml.getName(), xml.getAttributes());
/* 256 */     Iterable<LightXMLParser> childrens = xml.getChildrens();
/* 257 */     for (LightXMLParser child : childrens) {
/* 258 */       traverse(sap, child);
/*     */     }
/* 260 */     sap.endElement(xml.getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\definition\SimpleAOPParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */