/*    */ package org.aspectj.weaver.loadtime;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.instrument.Instrumentation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Agent
/*    */ {
/*    */   private static Instrumentation s_instrumentation;
/* 34 */   private static ClassFileTransformer s_transformer = new ClassPreProcessorAgentAdapter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void premain(String options, Instrumentation instrumentation) {
/* 44 */     if (s_instrumentation != null) {
/*    */       return;
/*    */     }
/* 47 */     s_instrumentation = instrumentation;
/* 48 */     s_instrumentation.addTransformer(s_transformer);
/*    */   }
/*    */   
/*    */   public static void agentmain(String options, Instrumentation instrumentation) {
/* 52 */     premain(options, instrumentation);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Instrumentation getInstrumentation() {
/* 59 */     if (s_instrumentation == null) {
/* 60 */       throw new UnsupportedOperationException("AspectJ weaving agent was neither started via '-javaagent' (preMain) nor attached via 'VirtualMachine.loadAgent' (agentMain)");
/*    */     }
/*    */ 
/*    */     
/* 64 */     return s_instrumentation;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\Agent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */