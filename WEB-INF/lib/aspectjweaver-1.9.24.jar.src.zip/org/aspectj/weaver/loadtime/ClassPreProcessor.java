package org.aspectj.weaver.loadtime;

import java.security.ProtectionDomain;

public interface ClassPreProcessor {
  void initialize();
  
  byte[] preProcess(String paramString, byte[] paramArrayOfbyte, ClassLoader paramClassLoader, ProtectionDomain paramProtectionDomain);
  
  void prepareForRedefinition(ClassLoader paramClassLoader, String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\ClassPreProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */