/*    */ package org.aspectj.weaver.loadtime;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.instrument.IllegalClassFormatException;
/*    */ import java.security.ProtectionDomain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassPreProcessorAgentAdapter
/*    */   implements ClassFileTransformer
/*    */ {
/*    */   private static ClassPreProcessor classPreProcessor;
/*    */   
/*    */   static {
/*    */     try {
/* 27 */       classPreProcessor = new Aj();
/* 28 */       classPreProcessor.initialize();
/* 29 */     } catch (Exception e) {
/* 30 */       throw new ExceptionInInitializerError("could not initialize JSR163 preprocessor due to: " + e.toString());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] bytes) throws IllegalClassFormatException {
/* 47 */     if (classBeingRedefined != null) {
/* 48 */       System.err.println("INFO: (Enh120375):  AspectJ attempting reweave of '" + className + "'");
/* 49 */       classPreProcessor.prepareForRedefinition(loader, className);
/*    */     } 
/* 51 */     return classPreProcessor.preProcess(className, bytes, loader, protectionDomain);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\ClassPreProcessorAgentAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */