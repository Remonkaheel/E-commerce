/*    */ package org.aspectj.weaver.loadtime;
/*    */ 
/*    */ import org.aspectj.bridge.AbortException;
/*    */ import org.aspectj.bridge.IMessage;
/*    */ import org.aspectj.bridge.IMessageHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultMessageHandler
/*    */   implements IMessageHandler
/*    */ {
/*    */   boolean isVerbose = false;
/*    */   boolean isDebug = false;
/*    */   boolean showWeaveInfo = false;
/*    */   boolean showWarn = true;
/*    */   
/*    */   public boolean handleMessage(IMessage message) throws AbortException {
/* 29 */     if (isIgnoring(message.getKind())) {
/* 30 */       return false;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     return SYSTEM_ERR.handleMessage(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isIgnoring(IMessage.Kind kind) {
/* 49 */     if (kind.equals(IMessage.WEAVEINFO)) {
/* 50 */       return !this.showWeaveInfo;
/*    */     }
/* 52 */     if (kind.isSameOrLessThan(IMessage.INFO)) {
/* 53 */       return !this.isVerbose;
/*    */     }
/* 55 */     if (kind.isSameOrLessThan(IMessage.DEBUG)) {
/* 56 */       return !this.isDebug;
/*    */     }
/* 58 */     return !this.showWarn;
/*    */   }
/*    */   
/*    */   public void dontIgnore(IMessage.Kind kind) {
/* 62 */     if (kind.equals(IMessage.WEAVEINFO)) {
/* 63 */       this.showWeaveInfo = true;
/* 64 */     } else if (kind.equals(IMessage.DEBUG)) {
/* 65 */       this.isVerbose = true;
/* 66 */     } else if (kind.equals(IMessage.WARNING)) {
/* 67 */       this.showWarn = false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void ignore(IMessage.Kind kind) {
/* 72 */     if (kind.equals(IMessage.WEAVEINFO)) {
/* 73 */       this.showWeaveInfo = false;
/* 74 */     } else if (kind.equals(IMessage.DEBUG)) {
/* 75 */       this.isVerbose = false;
/* 76 */     } else if (kind.equals(IMessage.WARNING)) {
/* 77 */       this.showWarn = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\DefaultMessageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */