/*     */ package org.aspectj.weaver.loadtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ClassElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.ElementValue;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.NameValuePair;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.SimpleElementValue;
/*     */ import org.aspectj.apache.bcel.generic.BasicType;
/*     */ import org.aspectj.apache.bcel.generic.FieldGen;
/*     */ import org.aspectj.apache.bcel.generic.Instruction;
/*     */ import org.aspectj.apache.bcel.generic.InstructionConstants;
/*     */ import org.aspectj.apache.bcel.generic.InstructionFactory;
/*     */ import org.aspectj.apache.bcel.generic.InstructionHandle;
/*     */ import org.aspectj.apache.bcel.generic.InstructionList;
/*     */ import org.aspectj.apache.bcel.generic.InstructionTargeter;
/*     */ import org.aspectj.apache.bcel.generic.LocalVariableTag;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.Message;
/*     */ import org.aspectj.weaver.AjAttribute;
/*     */ import org.aspectj.weaver.AnnotationAJ;
/*     */ import org.aspectj.weaver.GeneratedReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.UnresolvedType;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.bcel.BcelAnnotation;
/*     */ import org.aspectj.weaver.bcel.BcelPerClauseAspectAdder;
/*     */ import org.aspectj.weaver.bcel.BcelWorld;
/*     */ import org.aspectj.weaver.bcel.LazyClassGen;
/*     */ import org.aspectj.weaver.bcel.LazyMethodGen;
/*     */ import org.aspectj.weaver.loadtime.definition.Definition;
/*     */ import org.aspectj.weaver.patterns.BasicTokenSource;
/*     */ import org.aspectj.weaver.patterns.Declare;
/*     */ import org.aspectj.weaver.patterns.DeclareAnnotation;
/*     */ import org.aspectj.weaver.patterns.ISignaturePattern;
/*     */ import org.aspectj.weaver.patterns.ITokenSource;
/*     */ import org.aspectj.weaver.patterns.PatternParser;
/*     */ import org.aspectj.weaver.patterns.PerClause;
/*     */ import org.aspectj.weaver.patterns.TypePattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcreteAspectCodeGen
/*     */ {
/*  79 */   private static final String[] EMPTY_STRINGS = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Definition.ConcreteAspect concreteAspect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final World world;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValid = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType parent;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PerClause perclause;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] bytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConcreteAspectCodeGen(Definition.ConcreteAspect concreteAspect, World world) {
/* 118 */     this.concreteAspect = concreteAspect;
/* 119 */     this.world = world;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validate() {
/* 128 */     if (!(this.world instanceof BcelWorld)) {
/* 129 */       reportError("Internal error: world must be of type BcelWorld");
/* 130 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 135 */     ReferenceType referenceType = this.world.lookupBySignature(UnresolvedType.forName(this.concreteAspect.name).getSignature());
/*     */     
/* 137 */     if (referenceType != null && !referenceType.isMissing()) {
/* 138 */       reportError("Attempt to concretize but chosen aspect name already defined: " + stringify());
/* 139 */       return false;
/*     */     } 
/*     */     
/* 142 */     if (this.concreteAspect.pointcutsAndAdvice.size() != 0) {
/* 143 */       this.isValid = true;
/* 144 */       return true;
/*     */     } 
/*     */     
/* 147 */     if (this.concreteAspect.declareAnnotations.size() != 0) {
/* 148 */       this.isValid = true;
/* 149 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     if (this.concreteAspect.extend == null && this.concreteAspect.precedence != null) {
/* 154 */       if (this.concreteAspect.pointcuts.isEmpty()) {
/* 155 */         this.isValid = true;
/*     */         
/* 157 */         this.parent = null;
/* 158 */         return true;
/*     */       } 
/* 160 */       reportError("Attempt to use nested pointcuts without extends clause: " + stringify());
/* 161 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 165 */     String parentAspectName = this.concreteAspect.extend;
/*     */     
/* 167 */     if (parentAspectName.contains("<")) {
/*     */       
/* 169 */       this.parent = this.world.resolve(UnresolvedType.forName(parentAspectName), true);
/* 170 */       if (this.parent.isMissing()) {
/* 171 */         reportError("Unable to resolve type reference: " + stringify());
/* 172 */         return false;
/*     */       } 
/* 174 */       if (this.parent.isParameterizedType()) {
/* 175 */         UnresolvedType[] typeParameters = this.parent.getTypeParameters();
/* 176 */         for (UnresolvedType typeParameter : typeParameters) {
/* 177 */           if (typeParameter instanceof ResolvedType && ((ResolvedType)typeParameter).isMissing()) {
/* 178 */             reportError("Unablet to resolve type parameter '" + typeParameter.getName() + "' from " + stringify());
/* 179 */             return false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 184 */       this.parent = this.world.resolve(this.concreteAspect.extend, true);
/*     */     } 
/*     */     
/* 187 */     if (this.parent.isMissing()) {
/*     */       
/* 189 */       String fixedName = this.concreteAspect.extend;
/* 190 */       int hasDot = fixedName.lastIndexOf('.');
/* 191 */       while (hasDot > 0) {
/* 192 */         char[] fixedNameChars = fixedName.toCharArray();
/* 193 */         fixedNameChars[hasDot] = '$';
/* 194 */         fixedName = new String(fixedNameChars);
/* 195 */         hasDot = fixedName.lastIndexOf('.');
/* 196 */         this.parent = this.world.resolve(UnresolvedType.forName(fixedName), true);
/* 197 */         if (!this.parent.isMissing()) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 203 */     if (this.parent.isMissing()) {
/* 204 */       reportError("Cannot find parent aspect for: " + stringify());
/* 205 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 209 */     if (!this.parent.isAbstract() && !this.parent.equals(ResolvedType.OBJECT)) {
/* 210 */       reportError("Attempt to concretize a non-abstract aspect: " + stringify());
/* 211 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 215 */     if (!this.parent.isAspect() && !this.parent.equals(ResolvedType.OBJECT)) {
/* 216 */       reportError("Attempt to concretize a non aspect: " + stringify());
/* 217 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 221 */     List<String> elligibleAbstractions = new ArrayList<>();
/*     */     
/* 223 */     Collection<ResolvedMember> abstractMethods = getOutstandingAbstractMethods(this.parent);
/* 224 */     for (ResolvedMember method : abstractMethods) {
/* 225 */       if ("()V".equals(method.getSignature())) {
/* 226 */         String n = method.getName();
/*     */ 
/*     */         
/* 229 */         if (n.startsWith("ajc$pointcut")) {
/* 230 */           n = n.substring(14);
/* 231 */           n = n.substring(0, n.indexOf("$"));
/* 232 */           elligibleAbstractions.add(n); continue;
/* 233 */         }  if (hasPointcutAnnotation(method)) {
/* 234 */           elligibleAbstractions.add(method.getName());
/*     */           
/*     */           continue;
/*     */         } 
/* 238 */         reportError("Abstract method '" + method.toString() + "' cannot be concretized in XML: " + stringify());
/* 239 */         return false;
/*     */       } 
/*     */       
/* 242 */       if (method.getName().startsWith("ajc$pointcut") || hasPointcutAnnotation(method)) {
/*     */         
/* 244 */         reportError("Abstract method '" + method
/* 245 */             .toString() + "' cannot be concretized as a pointcut (illegal signature, must have no arguments, must return void): " + 
/*     */             
/* 247 */             stringify());
/* 248 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 252 */       reportError("Abstract method '" + method.toString() + "' cannot be concretized in XML: " + stringify());
/* 253 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 257 */     List<String> pointcutNames = new ArrayList<>();
/* 258 */     for (Definition.Pointcut abstractPc : this.concreteAspect.pointcuts) {
/* 259 */       pointcutNames.add(abstractPc.name);
/*     */     }
/* 261 */     for (String elligiblePc : elligibleAbstractions) {
/* 262 */       if (!pointcutNames.contains(elligiblePc)) {
/* 263 */         reportError("Abstract pointcut '" + elligiblePc + "' not configured: " + stringify());
/* 264 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 268 */     if (this.concreteAspect.perclause != null) {
/* 269 */       String perclauseString = this.concreteAspect.perclause;
/* 270 */       if (!perclauseString.startsWith("persingleton") && 
/* 271 */         !perclauseString.startsWith("percflow") && 
/* 272 */         !perclauseString.startsWith("pertypewithin") && 
/* 273 */         !perclauseString.startsWith("perthis") && 
/* 274 */         !perclauseString.startsWith("pertarget") && 
/* 275 */         !perclauseString.startsWith("percflowbelow")) {
/*     */         
/* 277 */         reportError("Unrecognized per clause specified " + stringify());
/* 278 */         return false;
/*     */       } 
/*     */     } 
/* 281 */     this.isValid = true;
/* 282 */     return this.isValid;
/*     */   }
/*     */   
/*     */   private Collection<ResolvedMember> getOutstandingAbstractMethods(ResolvedType type) {
/* 286 */     Map<String, ResolvedMember> collector = new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/* 290 */     getOutstandingAbstractMethodsHelper(type, collector);
/* 291 */     return collector.values();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void getOutstandingAbstractMethodsHelper(ResolvedType type, Map<String, ResolvedMember> collector) {
/* 297 */     if (type == null) {
/*     */       return;
/*     */     }
/*     */     
/* 301 */     if (!type.equals(ResolvedType.OBJECT) && 
/* 302 */       type.getSuperclass() != null) {
/* 303 */       getOutstandingAbstractMethodsHelper(type.getSuperclass(), collector);
/*     */     }
/*     */     
/* 306 */     ResolvedMember[] rms = type.getDeclaredMethods();
/* 307 */     if (rms != null) {
/* 308 */       for (ResolvedMember member : rms) {
/* 309 */         String key = member.getName() + member.getSignature();
/* 310 */         if (member.isAbstract()) {
/* 311 */           collector.put(key, member);
/*     */         } else {
/* 313 */           collector.remove(key);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String stringify() {
/* 325 */     StringBuilder sb = new StringBuilder("<concrete-aspect name='");
/* 326 */     sb.append(this.concreteAspect.name);
/* 327 */     sb.append("' extends='");
/* 328 */     sb.append(this.concreteAspect.extend);
/* 329 */     sb.append("' perclause='");
/* 330 */     sb.append(this.concreteAspect.perclause);
/* 331 */     sb.append("'/> in aop.xml");
/*     */     
/* 333 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private boolean hasPointcutAnnotation(ResolvedMember member) {
/* 337 */     AnnotationAJ[] as = member.getAnnotations();
/* 338 */     if (as == null || as.length == 0) {
/* 339 */       return false;
/*     */     }
/* 341 */     for (AnnotationAJ a : as) {
/* 342 */       if (a.getTypeSignature().equals("Lorg/aspectj/lang/annotation/Pointcut;")) {
/* 343 */         return true;
/*     */       }
/*     */     } 
/* 346 */     return false;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 350 */     return this.concreteAspect.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 357 */     if (!this.isValid) {
/* 358 */       throw new RuntimeException("Must validate first");
/*     */     }
/* 360 */     if (this.bytes != null) {
/* 361 */       return this.bytes;
/*     */     }
/* 363 */     PerClause.Kind perclauseKind = PerClause.SINGLETON;
/* 364 */     PerClause parentPerClause = (this.parent != null) ? this.parent.getPerClause() : null;
/* 365 */     if (parentPerClause != null) {
/* 366 */       perclauseKind = parentPerClause.getKind();
/*     */     }
/* 368 */     String perclauseString = null;
/*     */     
/* 370 */     if (this.concreteAspect.perclause != null) {
/* 371 */       perclauseString = this.concreteAspect.perclause;
/* 372 */       if (perclauseString.startsWith("persingleton")) {
/* 373 */         perclauseKind = PerClause.SINGLETON;
/* 374 */       } else if (perclauseString.startsWith("percflow")) {
/* 375 */         perclauseKind = PerClause.PERCFLOW;
/* 376 */       } else if (perclauseString.startsWith("pertypewithin")) {
/* 377 */         perclauseKind = PerClause.PERTYPEWITHIN;
/* 378 */       } else if (perclauseString.startsWith("perthis")) {
/* 379 */         perclauseKind = PerClause.PEROBJECT;
/* 380 */       } else if (perclauseString.startsWith("pertarget")) {
/* 381 */         perclauseKind = PerClause.PEROBJECT;
/* 382 */       } else if (perclauseString.startsWith("percflowbelow")) {
/* 383 */         perclauseKind = PerClause.PERCFLOW;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     String parentName = "java/lang/Object";
/* 394 */     if (this.parent != null) {
/* 395 */       if (this.parent.isParameterizedType()) {
/* 396 */         parentName = this.parent.getGenericType().getName().replace('.', '/');
/*     */       } else {
/* 398 */         parentName = this.parent.getName().replace('.', '/');
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 403 */     LazyClassGen cg = new LazyClassGen(this.concreteAspect.name.replace('.', '/'), parentName, null, 33, EMPTY_STRINGS, this.world);
/*     */     
/* 405 */     if (this.parent != null && this.parent.isParameterizedType()) {
/* 406 */       cg.setSuperClass(this.parent);
/*     */     }
/* 408 */     if (perclauseString == null) {
/*     */       
/* 410 */       AnnotationGen ag = new AnnotationGen(new ObjectType("org/aspectj/lang/annotation/Aspect"), Collections.emptyList(), true, cg.getConstantPool());
/* 411 */       cg.addAnnotation(ag);
/*     */     } else {
/*     */       
/* 414 */       List<NameValuePair> elems = new ArrayList<>();
/* 415 */       elems.add(new NameValuePair("value", (ElementValue)new SimpleElementValue(115, cg
/* 416 */               .getConstantPool(), perclauseString), cg.getConstantPool()));
/*     */       
/* 418 */       AnnotationGen ag = new AnnotationGen(new ObjectType("org/aspectj/lang/annotation/Aspect"), elems, true, cg.getConstantPool());
/* 419 */       cg.addAnnotation(ag);
/*     */     } 
/* 421 */     if (this.concreteAspect.precedence != null) {
/* 422 */       SimpleElementValue svg = new SimpleElementValue(115, cg.getConstantPool(), this.concreteAspect.precedence);
/* 423 */       List<NameValuePair> elems = new ArrayList<>();
/* 424 */       elems.add(new NameValuePair("value", (ElementValue)svg, cg.getConstantPool()));
/*     */       
/* 426 */       AnnotationGen agprec = new AnnotationGen(new ObjectType("org/aspectj/lang/annotation/DeclarePrecedence"), elems, true, cg.getConstantPool());
/* 427 */       cg.addAnnotation(agprec);
/*     */     } 
/*     */ 
/*     */     
/* 431 */     LazyMethodGen init = new LazyMethodGen(1, (Type)Type.VOID, "<init>", Type.NO_ARGS, EMPTY_STRINGS, cg);
/* 432 */     InstructionList cbody = init.getBody();
/* 433 */     cbody.append((Instruction)InstructionConstants.ALOAD_0);
/*     */     
/* 435 */     cbody.append((Instruction)cg.getFactory().createInvoke(parentName, "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183));
/* 436 */     cbody.append(InstructionConstants.RETURN);
/* 437 */     cg.addMethodGen(init);
/*     */     
/* 439 */     for (Definition.Pointcut abstractPc : this.concreteAspect.pointcuts) {
/*     */       
/* 441 */       LazyMethodGen mg = new LazyMethodGen(1, (Type)Type.VOID, abstractPc.name, Type.NO_ARGS, EMPTY_STRINGS, cg);
/* 442 */       SimpleElementValue svg = new SimpleElementValue(115, cg.getConstantPool(), abstractPc.expression);
/* 443 */       List<NameValuePair> elems = new ArrayList<>();
/* 444 */       elems.add(new NameValuePair("value", (ElementValue)svg, cg.getConstantPool()));
/*     */       
/* 446 */       AnnotationGen mag = new AnnotationGen(new ObjectType("org/aspectj/lang/annotation/Pointcut"), elems, true, cg.getConstantPool());
/* 447 */       BcelAnnotation bcelAnnotation = new BcelAnnotation(mag, this.world);
/* 448 */       mg.addAnnotation((AnnotationAJ)bcelAnnotation);
/*     */       
/* 450 */       InstructionList body = mg.getBody();
/* 451 */       body.append(InstructionConstants.RETURN);
/* 452 */       cg.addMethodGen(mg);
/*     */     } 
/*     */ 
/*     */     
/* 456 */     if (this.concreteAspect.deows.size() > 0) {
/* 457 */       int counter = 1;
/* 458 */       for (Definition.DeclareErrorOrWarning deow : this.concreteAspect.deows) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 463 */         FieldGen field = new FieldGen(16, (Type)ObjectType.STRING, "rule" + counter++, cg.getConstantPool());
/* 464 */         SimpleElementValue svg = new SimpleElementValue(115, cg.getConstantPool(), deow.pointcut);
/* 465 */         List<NameValuePair> elems = new ArrayList<>();
/* 466 */         elems.add(new NameValuePair("value", (ElementValue)svg, cg.getConstantPool()));
/*     */         
/* 468 */         AnnotationGen mag = new AnnotationGen(new ObjectType("org/aspectj/lang/annotation/Declare" + (deow.isError ? "Error" : "Warning")), elems, true, cg.getConstantPool());
/* 469 */         field.addAnnotation(mag);
/*     */         
/* 471 */         field.setValue(deow.message);
/* 472 */         cg.addField(field, null);
/*     */       } 
/*     */     } 
/*     */     
/* 476 */     if (this.concreteAspect.pointcutsAndAdvice.size() > 0) {
/* 477 */       int adviceCounter = 1;
/* 478 */       for (Definition.PointcutAndAdvice paa : this.concreteAspect.pointcutsAndAdvice) {
/* 479 */         generateAdviceMethod(paa, adviceCounter, cg);
/* 480 */         adviceCounter++;
/*     */       } 
/*     */     } 
/*     */     
/* 484 */     if (this.concreteAspect.declareAnnotations.size() > 0) {
/* 485 */       int decCounter = 1;
/* 486 */       for (Definition.DeclareAnnotation da : this.concreteAspect.declareAnnotations) {
/* 487 */         generateDeclareAnnotation(da, decCounter++, cg);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 492 */     ReferenceType rt = new ReferenceType(ResolvedType.forName(this.concreteAspect.name).getSignature(), this.world);
/* 493 */     GeneratedReferenceTypeDelegate grtd = new GeneratedReferenceTypeDelegate(rt);
/* 494 */     grtd.setSuperclass(this.parent);
/* 495 */     rt.setDelegate((ReferenceTypeDelegate)grtd);
/*     */     
/* 497 */     BcelPerClauseAspectAdder perClauseMunger = new BcelPerClauseAspectAdder((ResolvedType)rt, perclauseKind);
/* 498 */     perClauseMunger.forceMunge(cg, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 503 */     JavaClass jc = cg.getJavaClass((BcelWorld)this.world);
/* 504 */     ((BcelWorld)this.world).addSourceObjectType(jc, true);
/*     */     
/* 506 */     this.bytes = jc.getBytes();
/* 507 */     return this.bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateDeclareAnnotation(Definition.DeclareAnnotation da, int decCounter, LazyClassGen cg) {
/* 544 */     AnnotationAJ constructedAnnotation = buildDeclareAnnotation_actualAnnotation(cg, da);
/* 545 */     if (constructedAnnotation == null) {
/*     */       return;
/*     */     }
/*     */     
/* 549 */     String nameComponent = da.declareAnnotationKind.name().toLowerCase();
/* 550 */     String declareName = "ajc$declare_at_" + nameComponent + "_" + decCounter;
/* 551 */     LazyMethodGen declareMethod = new LazyMethodGen(1, (Type)Type.VOID, declareName, Type.NO_ARGS, EMPTY_STRINGS, cg);
/* 552 */     InstructionList declareMethodBody = declareMethod.getBody();
/* 553 */     declareMethodBody.append(InstructionFactory.RETURN);
/* 554 */     declareMethod.addAnnotation(constructedAnnotation);
/*     */     
/* 556 */     DeclareAnnotation deca = null;
/* 557 */     ITokenSource tokenSource = BasicTokenSource.makeTokenSource(da.pattern, null);
/* 558 */     PatternParser pp = new PatternParser(tokenSource);
/*     */     
/* 560 */     if (da.declareAnnotationKind == Definition.DeclareAnnotationKind.Method || da.declareAnnotationKind == Definition.DeclareAnnotationKind.Field) {
/* 561 */       ISignaturePattern isp = (da.declareAnnotationKind == Definition.DeclareAnnotationKind.Method) ? pp.parseCompoundMethodOrConstructorSignaturePattern(true) : pp.parseCompoundFieldSignaturePattern();
/* 562 */       deca = new DeclareAnnotation((da.declareAnnotationKind == Definition.DeclareAnnotationKind.Method) ? DeclareAnnotation.AT_METHOD : DeclareAnnotation.AT_FIELD, isp);
/* 563 */     } else if (da.declareAnnotationKind == Definition.DeclareAnnotationKind.Type) {
/* 564 */       TypePattern tp = pp.parseTypePattern();
/* 565 */       deca = new DeclareAnnotation(DeclareAnnotation.AT_TYPE, tp);
/*     */     } 
/*     */     
/* 568 */     deca.setAnnotationMethod(declareName);
/* 569 */     deca.setAnnotationString(da.annotation);
/* 570 */     AjAttribute.DeclareAttribute declareAttribute = new AjAttribute.DeclareAttribute((Declare)deca);
/* 571 */     cg.addAttribute((AjAttribute)declareAttribute);
/* 572 */     cg.addMethodGen(declareMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationAJ buildDeclareAnnotation_actualAnnotation(LazyClassGen cg, Definition.DeclareAnnotation da) {
/* 579 */     AnnotationGen anno = buildAnnotationFromString(cg.getConstantPool(), cg.getWorld(), da.annotation);
/* 580 */     if (anno == null) {
/* 581 */       return null;
/*     */     }
/* 583 */     return (AnnotationAJ)new BcelAnnotation(anno, this.world);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationGen buildAnnotationFromString(ConstantPool cp, World w, String annotationString) {
/* 595 */     int paren = annotationString.indexOf('(');
/* 596 */     if (paren == -1) {
/*     */       
/* 598 */       AnnotationGen annotationGen = buildBaseAnnotationType(cp, this.world, annotationString);
/* 599 */       return annotationGen;
/*     */     } 
/*     */     
/* 602 */     String name = annotationString.substring(0, paren);
/*     */     
/* 604 */     List<String> values = new ArrayList<>();
/* 605 */     int pos = paren + 1;
/* 606 */     int depth = 0;
/* 607 */     int len = annotationString.length();
/* 608 */     int start = pos;
/* 609 */     while (pos < len) {
/* 610 */       char ch = annotationString.charAt(pos);
/* 611 */       if (ch == ')' && depth == 0) {
/*     */         break;
/*     */       }
/* 614 */       if (ch == '(' || ch == '[') {
/* 615 */         depth++;
/* 616 */       } else if (ch == ')' || ch == ']') {
/* 617 */         depth--;
/*     */       } 
/* 619 */       if (ch == ',' && depth == 0) {
/*     */         
/* 621 */         values.add(annotationString.substring(start, pos).trim());
/* 622 */         start = pos + 1;
/*     */       } 
/* 624 */       pos++;
/*     */     } 
/* 626 */     if (start != pos)
/*     */     {
/* 628 */       values.add(annotationString.substring(start, pos).trim());
/*     */     }
/* 630 */     AnnotationGen aaj = buildBaseAnnotationType(cp, this.world, name);
/* 631 */     if (aaj == null) {
/* 632 */       return null;
/*     */     }
/* 634 */     String typename = aaj.getTypeName();
/* 635 */     ResolvedType type = UnresolvedType.forName(typename).resolve(this.world);
/* 636 */     ResolvedMember[] rms = type.getDeclaredMethods();
/*     */     
/* 638 */     for (String value : values) {
/* 639 */       int equalsIndex = value.indexOf("=");
/* 640 */       String key = "value";
/* 641 */       if (value.charAt(0) != '"' && equalsIndex != -1) {
/* 642 */         key = value.substring(0, equalsIndex).trim();
/* 643 */         value = value.substring(equalsIndex + 1).trim();
/*     */       } 
/* 645 */       boolean keyIsOk = false;
/* 646 */       for (ResolvedMember rm : rms) {
/* 647 */         NameValuePair nvp = null;
/* 648 */         if (rm.getName().equals(key)) {
/*     */           
/* 650 */           keyIsOk = true;
/* 651 */           UnresolvedType rt = rm.getReturnType();
/* 652 */           if (rt.isPrimitiveType()) {
/* 653 */             switch (rt.getSignature().charAt(0)) {
/*     */               case 'J':
/*     */                 try {
/* 656 */                   long longValue = Long.parseLong(value);
/* 657 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(74, cp, longValue), cp);
/* 658 */                 } catch (NumberFormatException nfe) {
/* 659 */                   reportError("unable to interpret annotation value '" + value + "' as a long");
/* 660 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               case 'S':
/*     */                 try {
/* 665 */                   short shortValue = Short.parseShort(value);
/* 666 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(83, cp, shortValue), cp);
/* 667 */                 } catch (NumberFormatException nfe) {
/* 668 */                   reportError("unable to interpret annotation value '" + value + "' as a short");
/* 669 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               case 'F':
/*     */                 try {
/* 674 */                   float floatValue = Float.parseFloat(value);
/* 675 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(70, cp, floatValue), cp);
/* 676 */                 } catch (NumberFormatException nfe) {
/* 677 */                   reportError("unable to interpret annotation value '" + value + "' as a float");
/* 678 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               case 'D':
/*     */                 try {
/* 683 */                   double doubleValue = Double.parseDouble(value);
/* 684 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(68, cp, doubleValue), cp);
/* 685 */                 } catch (NumberFormatException nfe) {
/* 686 */                   reportError("unable to interpret annotation value '" + value + "' as a double");
/* 687 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               case 'I':
/*     */                 try {
/* 692 */                   int intValue = Integer.parseInt(value);
/* 693 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(73, cp, intValue), cp);
/* 694 */                 } catch (NumberFormatException nfe) {
/* 695 */                   reportError("unable to interpret annotation value '" + value + "' as an integer");
/* 696 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               case 'B':
/*     */                 try {
/* 701 */                   byte byteValue = Byte.parseByte(value);
/* 702 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(66, cp, byteValue), cp);
/* 703 */                 } catch (NumberFormatException nfe) {
/* 704 */                   reportError("unable to interpret annotation value '" + value + "' as a byte");
/* 705 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               case 'C':
/* 709 */                 if (value.length() < 2) {
/* 710 */                   reportError("unable to interpret annotation value '" + value + "' as a char");
/* 711 */                   return null;
/*     */                 } 
/* 713 */                 nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(67, cp, value.charAt(1)), cp);
/*     */                 break;
/*     */               case 'Z':
/*     */                 try {
/* 717 */                   boolean booleanValue = Boolean.parseBoolean(value);
/* 718 */                   nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(90, cp, booleanValue), cp);
/* 719 */                 } catch (NumberFormatException nfe) {
/* 720 */                   reportError("unable to interpret annotation value '" + value + "' as a boolean");
/* 721 */                   return null;
/*     */                 } 
/*     */                 break;
/*     */               default:
/* 725 */                 reportError("not yet supporting XML setting of annotation values of type " + rt.getName());
/* 726 */                 return null;
/*     */             } 
/* 728 */           } else if (UnresolvedType.JL_STRING.equals(rt)) {
/* 729 */             if (value.length() < 2) {
/* 730 */               reportError("Invalid string value specified in annotation string: " + annotationString);
/* 731 */               return null;
/*     */             } 
/* 733 */             value = value.substring(1, value.length() - 1);
/* 734 */             nvp = new NameValuePair(key, (ElementValue)new SimpleElementValue(115, cp, value), cp);
/* 735 */           } else if (UnresolvedType.JL_CLASS.equals(rt)) {
/*     */ 
/*     */ 
/*     */             
/* 739 */             if (value.length() < 6) {
/* 740 */               reportError("Not a well formed class value for an annotation '" + value + "'");
/* 741 */               return null;
/*     */             } 
/* 743 */             String clazz = value.substring(0, value.length() - 6);
/* 744 */             boolean qualified = clazz.contains(".");
/* 745 */             if (!qualified)
/*     */             {
/* 747 */               clazz = "java.lang." + clazz;
/*     */             }
/* 749 */             nvp = new NameValuePair(key, (ElementValue)new ClassElementValue(new ObjectType(clazz), cp), cp);
/*     */           } 
/*     */         } 
/* 752 */         if (nvp != null) {
/* 753 */           aaj.addElementNameValuePair(nvp);
/*     */         }
/*     */       } 
/* 756 */       if (!keyIsOk) {
/* 757 */         reportError("annotation @" + typename + " does not have a value named " + key);
/* 758 */         return null;
/*     */       } 
/*     */     } 
/* 761 */     return aaj;
/*     */   }
/*     */ 
/*     */   
/*     */   private AnnotationGen buildBaseAnnotationType(ConstantPool cp, World world, String typename) {
/* 766 */     String annoname = typename;
/* 767 */     if (annoname.startsWith("@")) {
/* 768 */       annoname = annoname.substring(1);
/*     */     }
/* 770 */     ResolvedType annotationType = UnresolvedType.forName(annoname).resolve(world);
/* 771 */     if (!annotationType.isAnnotation()) {
/* 772 */       reportError("declare is not specifying an annotation type :" + typename);
/* 773 */       return null;
/*     */     } 
/* 775 */     if (!annotationType.isAnnotationWithRuntimeRetention()) {
/* 776 */       reportError("declare is using an annotation type that does not have runtime retention: " + typename);
/* 777 */       return null;
/*     */     } 
/* 779 */     List<NameValuePair> elems = new ArrayList<>();
/* 780 */     return new AnnotationGen(new ObjectType(annoname), elems, true, cp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateAdviceMethod(Definition.PointcutAndAdvice paa, int adviceCounter, LazyClassGen cg) {
/*     */     Type type;
/* 794 */     ResolvedType delegateClass = this.world.resolve(UnresolvedType.forName(paa.adviceClass));
/* 795 */     if (delegateClass.isMissing()) {
/* 796 */       reportError("Class to invoke cannot be found: '" + paa.adviceClass + "'");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 802 */     String adviceName = "generated$" + paa.adviceKind.toString().toLowerCase() + "$advice$" + adviceCounter;
/*     */ 
/*     */     
/* 805 */     AnnotationAJ aaj = buildAdviceAnnotation(cg, paa);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 810 */     String method = paa.adviceMethod;
/*     */     
/* 812 */     int paren = method.indexOf("(");
/* 813 */     String methodName = method.substring(0, paren);
/* 814 */     String signature = method.substring(paren);
/*     */ 
/*     */     
/* 817 */     if (signature.charAt(0) != '(' || !signature.endsWith(")")) {
/* 818 */       reportError("Badly formatted parameter signature: '" + method + "'");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 823 */     List<Type> paramTypes = new ArrayList<>();
/* 824 */     List<String> paramNames = new ArrayList<>();
/* 825 */     if (signature.charAt(1) != ')') {
/*     */       
/* 827 */       StringBuilder convertedSignature = new StringBuilder("(");
/* 828 */       boolean paramsBroken = false;
/* 829 */       int i = 1;
/* 830 */       while (i < signature.length() && signature.charAt(i) != ')' && !paramsBroken) {
/* 831 */         int nextChunkEndPos = signature.indexOf(',', i);
/* 832 */         if (nextChunkEndPos == -1) {
/* 833 */           nextChunkEndPos = signature.indexOf(')', i);
/*     */         }
/*     */         
/* 836 */         String nextChunk = signature.substring(i, nextChunkEndPos).trim();
/* 837 */         int space = nextChunk.indexOf(" ");
/* 838 */         ResolvedType resolvedParamType = null;
/* 839 */         if (space == -1) {
/*     */           
/* 841 */           if (nextChunk.equals("JoinPoint")) {
/* 842 */             nextChunk = "org.aspectj.lang.JoinPoint";
/* 843 */           } else if (nextChunk.equals("JoinPoint.StaticPart")) {
/* 844 */             nextChunk = "org.aspectj.lang.JoinPoint$StaticPart";
/* 845 */           } else if (nextChunk.equals("ProceedingJoinPoint")) {
/* 846 */             nextChunk = "org.aspectj.lang.ProceedingJoinPoint";
/*     */           } 
/* 848 */           UnresolvedType unresolvedParamType = UnresolvedType.forName(nextChunk);
/* 849 */           resolvedParamType = this.world.resolve(unresolvedParamType);
/*     */         } else {
/* 851 */           String typename = nextChunk.substring(0, space);
/* 852 */           if (typename.equals("JoinPoint")) {
/* 853 */             typename = "org.aspectj.lang.JoinPoint";
/* 854 */           } else if (typename.equals("JoinPoint.StaticPart")) {
/* 855 */             typename = "org.aspectj.lang.JoinPoint$StaticPart";
/* 856 */           } else if (typename.equals("ProceedingJoinPoint")) {
/* 857 */             typename = "org.aspectj.lang.ProceedingJoinPoint";
/*     */           } 
/* 859 */           UnresolvedType unresolvedParamType = UnresolvedType.forName(typename);
/* 860 */           resolvedParamType = this.world.resolve(unresolvedParamType);
/* 861 */           String paramname = nextChunk.substring(space).trim();
/* 862 */           paramNames.add(paramname);
/*     */         } 
/* 864 */         if (resolvedParamType.isMissing()) {
/* 865 */           reportError("Cannot find type specified as parameter: '" + nextChunk + "' from signature '" + signature + "'");
/* 866 */           paramsBroken = true;
/*     */         } 
/* 868 */         paramTypes.add(Type.getType(resolvedParamType.getSignature()));
/* 869 */         convertedSignature.append(resolvedParamType.getSignature());
/* 870 */         i = nextChunkEndPos + 1;
/*     */       } 
/* 872 */       convertedSignature.append(")");
/* 873 */       signature = convertedSignature.toString();
/* 874 */       if (paramsBroken) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 879 */     BasicType basicType = Type.VOID;
/*     */ 
/*     */     
/* 882 */     if (paa.adviceKind == Definition.AdviceKind.Around) {
/* 883 */       ResolvedMember[] methods = delegateClass.getDeclaredMethods();
/* 884 */       ResolvedMember found = null;
/* 885 */       for (ResolvedMember candidate : methods) {
/* 886 */         if (candidate.getName().equals(methodName)) {
/* 887 */           UnresolvedType[] cparms = candidate.getParameterTypes();
/* 888 */           if (cparms.length == paramTypes.size()) {
/* 889 */             boolean paramsMatch = true;
/* 890 */             for (int i = 0; i < cparms.length; i++) {
/* 891 */               if (!cparms[i].getSignature().equals(((Type)paramTypes.get(i)).getSignature())) {
/* 892 */                 paramsMatch = false;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 896 */             if (paramsMatch) {
/* 897 */               found = candidate;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 903 */       if (found != null) {
/* 904 */         type = Type.getType(found.getReturnType().getSignature());
/*     */       } else {
/* 906 */         reportError("Unable to find method to invoke.  In class: " + delegateClass.getName() + " cant find " + paa.adviceMethod);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 913 */     LazyMethodGen advice = new LazyMethodGen(1, type, adviceName, paramTypes.<Type>toArray(Type.NO_ARGS), EMPTY_STRINGS, cg);
/*     */     
/* 915 */     InstructionList adviceBody = advice.getBody();
/*     */ 
/*     */     
/* 918 */     int pos = 1;
/* 919 */     for (Type paramType : paramTypes) {
/* 920 */       adviceBody.append((Instruction)InstructionFactory.createLoad(paramType, pos));
/* 921 */       pos += paramType.getSize();
/*     */     } 
/*     */ 
/*     */     
/* 925 */     adviceBody.append((Instruction)cg.getFactory().createInvoke(paa.adviceClass, methodName, signature + type.getSignature(), (short)184));
/*     */ 
/*     */ 
/*     */     
/* 929 */     if (type == Type.VOID) {
/* 930 */       adviceBody.append(InstructionConstants.RETURN);
/*     */     }
/* 932 */     else if (type.getSignature().length() < 2) {
/* 933 */       String str = type.getSignature();
/* 934 */       if (str.equals("F")) {
/* 935 */         adviceBody.append(InstructionConstants.FRETURN);
/* 936 */       } else if (str.equals("D")) {
/* 937 */         adviceBody.append(InstructionConstants.DRETURN);
/* 938 */       } else if (str.equals("J")) {
/* 939 */         adviceBody.append(InstructionConstants.LRETURN);
/*     */       } else {
/* 941 */         adviceBody.append(InstructionConstants.IRETURN);
/*     */       } 
/*     */     } else {
/* 944 */       adviceBody.append(InstructionConstants.ARETURN);
/*     */     } 
/*     */ 
/*     */     
/* 948 */     advice.addAnnotation(aaj);
/* 949 */     InstructionHandle start = adviceBody.getStart();
/*     */ 
/*     */     
/* 952 */     String sig = this.concreteAspect.name.replace('.', '/');
/* 953 */     start.addTargeter((InstructionTargeter)new LocalVariableTag("L" + sig + ";", "this", 0, start.getPosition()));
/* 954 */     if (paramNames.size() > 0) {
/* 955 */       for (int i = 0; i < paramNames.size(); i++) {
/* 956 */         start.addTargeter((InstructionTargeter)new LocalVariableTag(((Type)paramTypes.get(i)).getSignature(), paramNames.get(i), i + 1, start
/* 957 */               .getPosition()));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 962 */     cg.addMethodGen(advice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationAJ buildAdviceAnnotation(LazyClassGen cg, Definition.PointcutAndAdvice paa) {
/* 969 */     SimpleElementValue svg = new SimpleElementValue(115, cg.getConstantPool(), paa.pointcut);
/* 970 */     List<NameValuePair> elems = new ArrayList<>();
/* 971 */     elems.add(new NameValuePair("value", (ElementValue)svg, cg.getConstantPool()));
/*     */     
/* 973 */     AnnotationGen mag = new AnnotationGen(new ObjectType("org/aspectj/lang/annotation/" + paa.adviceKind.toString()), elems, true, cg.getConstantPool());
/* 974 */     return (AnnotationAJ)new BcelAnnotation(mag, this.world);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reportError(String message) {
/* 984 */     this.world.getMessageHandler().handleMessage((IMessage)new Message(message, IMessage.ERROR, null, null));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\loadtime\ConcreteAspectCodeGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */