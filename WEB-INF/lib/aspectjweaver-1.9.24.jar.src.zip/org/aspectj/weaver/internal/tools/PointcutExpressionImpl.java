/*     */ package org.aspectj.weaver.internal.tools;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.patterns.AbstractPatternNodeVisitor;
/*     */ import org.aspectj.weaver.patterns.AnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.ArgsAnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.ArgsPointcut;
/*     */ import org.aspectj.weaver.patterns.CflowPointcut;
/*     */ import org.aspectj.weaver.patterns.ExposedState;
/*     */ import org.aspectj.weaver.patterns.FastMatchInfo;
/*     */ import org.aspectj.weaver.patterns.IfPointcut;
/*     */ import org.aspectj.weaver.patterns.NotAnnotationTypePattern;
/*     */ import org.aspectj.weaver.patterns.NotPointcut;
/*     */ import org.aspectj.weaver.patterns.PatternNodeVisitor;
/*     */ import org.aspectj.weaver.patterns.Pointcut;
/*     */ import org.aspectj.weaver.patterns.ThisOrTargetAnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.ThisOrTargetPointcut;
/*     */ import org.aspectj.weaver.patterns.WithinAnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.WithinCodeAnnotationPointcut;
/*     */ import org.aspectj.weaver.reflect.ReflectionFastMatchInfo;
/*     */ import org.aspectj.weaver.reflect.ReflectionShadow;
/*     */ import org.aspectj.weaver.reflect.ReflectionWorld;
/*     */ import org.aspectj.weaver.reflect.ShadowMatchImpl;
/*     */ import org.aspectj.weaver.tools.DefaultMatchingContext;
/*     */ import org.aspectj.weaver.tools.MatchingContext;
/*     */ import org.aspectj.weaver.tools.PointcutExpression;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.aspectj.weaver.tools.ShadowMatch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointcutExpressionImpl
/*     */   implements PointcutExpression
/*     */ {
/*     */   private static final boolean MATCH_INFO = false;
/*     */   private World world;
/*     */   private Pointcut pointcut;
/*     */   private String expression;
/*     */   private PointcutParameter[] parameters;
/*  57 */   private MatchingContext matchContext = (MatchingContext)new DefaultMatchingContext();
/*     */   
/*     */   public PointcutExpressionImpl(Pointcut pointcut, String expression, PointcutParameter[] params, World inWorld) {
/*  60 */     this.pointcut = pointcut;
/*  61 */     this.expression = expression;
/*  62 */     this.world = inWorld;
/*  63 */     this.parameters = params;
/*  64 */     if (this.parameters == null) {
/*  65 */       this.parameters = new PointcutParameter[0];
/*     */     }
/*     */   }
/*     */   
/*     */   public Pointcut getUnderlyingPointcut() {
/*  70 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchingContext(MatchingContext aMatchContext) {
/*  79 */     this.matchContext = aMatchContext;
/*     */   }
/*     */   
/*     */   public boolean couldMatchJoinPointsInType(Class aClass) {
/*  83 */     ResolvedType matchType = this.world.resolve(aClass.getName());
/*  84 */     if (matchType.isMissing() && this.world instanceof ReflectionWorld)
/*     */     {
/*     */ 
/*     */       
/*  88 */       matchType = ((ReflectionWorld)this.world).resolveUsingClass(aClass);
/*     */     }
/*  90 */     ReflectionFastMatchInfo info = new ReflectionFastMatchInfo(matchType, null, this.matchContext, this.world);
/*  91 */     boolean couldMatch = this.pointcut.fastMatch((FastMatchInfo)info).maybeTrue();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     return couldMatch;
/*     */   }
/*     */   
/*     */   public boolean mayNeedDynamicTest() {
/* 100 */     HasPossibleDynamicContentVisitor visitor = new HasPossibleDynamicContentVisitor();
/* 101 */     this.pointcut.traverse((PatternNodeVisitor)visitor, null);
/* 102 */     return visitor.hasDynamicContent();
/*     */   }
/*     */   
/*     */   private ExposedState getExposedState() {
/* 106 */     return new ExposedState(this.parameters.length);
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesMethodExecution(Method aMethod) {
/* 110 */     ShadowMatch match = matchesExecution(aMethod);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     return match;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesConstructorExecution(Constructor aConstructor) {
/* 119 */     ShadowMatch match = matchesExecution(aConstructor);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     return match;
/*     */   }
/*     */   
/*     */   private ShadowMatch matchesExecution(Member aMember) {
/* 128 */     Shadow s = ReflectionShadow.makeExecutionShadow(this.world, aMember, this.matchContext);
/* 129 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 130 */     sm.setSubject(aMember);
/* 131 */     sm.setWithinCode(null);
/* 132 */     sm.setWithinType(aMember.getDeclaringClass());
/* 133 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesStaticInitialization(Class aClass) {
/* 137 */     Shadow s = ReflectionShadow.makeStaticInitializationShadow(this.world, aClass, this.matchContext);
/* 138 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 139 */     sm.setSubject(null);
/* 140 */     sm.setWithinCode(null);
/* 141 */     sm.setWithinType(aClass);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesAdviceExecution(Method aMethod) {
/* 150 */     Shadow s = ReflectionShadow.makeAdviceExecutionShadow(this.world, aMethod, this.matchContext);
/* 151 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 152 */     sm.setSubject(aMethod);
/* 153 */     sm.setWithinCode(null);
/* 154 */     sm.setWithinType(aMethod.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesInitialization(Constructor aConstructor) {
/* 163 */     Shadow s = ReflectionShadow.makeInitializationShadow(this.world, aConstructor, this.matchContext);
/* 164 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 165 */     sm.setSubject(aConstructor);
/* 166 */     sm.setWithinCode(null);
/* 167 */     sm.setWithinType(aConstructor.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesPreInitialization(Constructor aConstructor) {
/* 176 */     Shadow s = ReflectionShadow.makePreInitializationShadow(this.world, aConstructor, this.matchContext);
/* 177 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 178 */     sm.setSubject(aConstructor);
/* 179 */     sm.setWithinCode(null);
/* 180 */     sm.setWithinType(aConstructor.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesMethodCall(Method aMethod, Member withinCode) {
/* 189 */     Shadow s = ReflectionShadow.makeCallShadow(this.world, aMethod, withinCode, this.matchContext);
/* 190 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 191 */     sm.setSubject(aMethod);
/* 192 */     sm.setWithinCode(withinCode);
/* 193 */     sm.setWithinType(withinCode.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesMethodCall(Method aMethod, Class callerType) {
/* 202 */     Shadow s = ReflectionShadow.makeCallShadow(this.world, aMethod, callerType, this.matchContext);
/* 203 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 204 */     sm.setSubject(aMethod);
/* 205 */     sm.setWithinCode(null);
/* 206 */     sm.setWithinType(callerType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesConstructorCall(Constructor aConstructor, Class callerType) {
/* 215 */     Shadow s = ReflectionShadow.makeCallShadow(this.world, aConstructor, callerType, this.matchContext);
/* 216 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 217 */     sm.setSubject(aConstructor);
/* 218 */     sm.setWithinCode(null);
/* 219 */     sm.setWithinType(callerType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesConstructorCall(Constructor aConstructor, Member withinCode) {
/* 228 */     Shadow s = ReflectionShadow.makeCallShadow(this.world, aConstructor, withinCode, this.matchContext);
/* 229 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 230 */     sm.setSubject(aConstructor);
/* 231 */     sm.setWithinCode(withinCode);
/* 232 */     sm.setWithinType(withinCode.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesHandler(Class exceptionType, Class handlingType) {
/* 241 */     Shadow s = ReflectionShadow.makeHandlerShadow(this.world, exceptionType, handlingType, this.matchContext);
/* 242 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 243 */     sm.setSubject(null);
/* 244 */     sm.setWithinCode(null);
/* 245 */     sm.setWithinType(handlingType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesHandler(Class exceptionType, Member withinCode) {
/* 254 */     Shadow s = ReflectionShadow.makeHandlerShadow(this.world, exceptionType, withinCode, this.matchContext);
/* 255 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 256 */     sm.setSubject(null);
/* 257 */     sm.setWithinCode(withinCode);
/* 258 */     sm.setWithinType(withinCode.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesFieldGet(Field aField, Class withinType) {
/* 267 */     Shadow s = ReflectionShadow.makeFieldGetShadow(this.world, aField, withinType, this.matchContext);
/* 268 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 269 */     sm.setSubject(aField);
/* 270 */     sm.setWithinCode(null);
/* 271 */     sm.setWithinType(withinType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesFieldGet(Field aField, Member withinCode) {
/* 280 */     Shadow s = ReflectionShadow.makeFieldGetShadow(this.world, aField, withinCode, this.matchContext);
/* 281 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 282 */     sm.setSubject(aField);
/* 283 */     sm.setWithinCode(withinCode);
/* 284 */     sm.setWithinType(withinCode.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesFieldSet(Field aField, Class withinType) {
/* 293 */     Shadow s = ReflectionShadow.makeFieldSetShadow(this.world, aField, withinType, this.matchContext);
/* 294 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 295 */     sm.setSubject(aField);
/* 296 */     sm.setWithinCode(null);
/* 297 */     sm.setWithinType(withinType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 302 */     return (ShadowMatch)sm;
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesFieldSet(Field aField, Member withinCode) {
/* 306 */     Shadow s = ReflectionShadow.makeFieldSetShadow(this.world, aField, withinCode, this.matchContext);
/* 307 */     ShadowMatchImpl sm = getShadowMatch(s);
/* 308 */     sm.setSubject(aField);
/* 309 */     sm.setWithinCode(withinCode);
/* 310 */     sm.setWithinType(withinCode.getDeclaringClass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     return (ShadowMatch)sm;
/*     */   }
/*     */   private ShadowMatchImpl getShadowMatch(Shadow forShadow) {
/*     */     Test test;
/* 319 */     FuzzyBoolean match = this.pointcut.match(forShadow);
/* 320 */     Literal literal = Literal.TRUE;
/* 321 */     ExposedState state = getExposedState();
/* 322 */     if (match.maybeTrue()) {
/* 323 */       test = this.pointcut.findResidue(forShadow, state);
/*     */     }
/* 325 */     ShadowMatchImpl sm = new ShadowMatchImpl(match, test, state, this.parameters);
/* 326 */     sm.setMatchingContext(this.matchContext);
/* 327 */     return sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPointcutExpression() {
/* 336 */     return this.expression;
/*     */   }
/*     */   
/*     */   private static class HasPossibleDynamicContentVisitor extends AbstractPatternNodeVisitor {
/*     */     private boolean hasDynamicContent = false;
/*     */     
/*     */     public boolean hasDynamicContent() {
/* 343 */       return this.hasDynamicContent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(WithinAnnotationPointcut node, Object data) {
/* 348 */       this.hasDynamicContent = true;
/* 349 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(WithinCodeAnnotationPointcut node, Object data) {
/* 354 */       this.hasDynamicContent = true;
/* 355 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(AnnotationPointcut node, Object data) {
/* 360 */       this.hasDynamicContent = true;
/* 361 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ArgsAnnotationPointcut node, Object data) {
/* 366 */       this.hasDynamicContent = true;
/* 367 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ArgsPointcut node, Object data) {
/* 372 */       this.hasDynamicContent = true;
/* 373 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(CflowPointcut node, Object data) {
/* 378 */       this.hasDynamicContent = true;
/* 379 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(IfPointcut node, Object data) {
/* 384 */       this.hasDynamicContent = true;
/* 385 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(NotAnnotationTypePattern node, Object data) {
/* 390 */       return node.getNegatedPattern().accept((PatternNodeVisitor)this, data);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(NotPointcut node, Object data) {
/* 395 */       return node.getNegatedPointcut().accept((PatternNodeVisitor)this, data);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ThisOrTargetAnnotationPointcut node, Object data) {
/* 400 */       this.hasDynamicContent = true;
/* 401 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ThisOrTargetPointcut node, Object data) {
/* 406 */       this.hasDynamicContent = true;
/* 407 */       return null;
/*     */     }
/*     */     
/*     */     private HasPossibleDynamicContentVisitor() {}
/*     */   }
/*     */   
/*     */   public static class Handler implements Member {
/*     */     private Class<?> decClass;
/*     */     private Class<?> exType;
/*     */     
/*     */     public Handler(Class<?> decClass, Class<?> exType) {
/* 418 */       this.decClass = decClass;
/* 419 */       this.exType = exType;
/*     */     }
/*     */     
/*     */     public int getModifiers() {
/* 423 */       return 0;
/*     */     }
/*     */     
/*     */     public Class getDeclaringClass() {
/* 427 */       return this.decClass;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 431 */       return null;
/*     */     }
/*     */     
/*     */     public Class getHandledExceptionType() {
/* 435 */       return this.exType;
/*     */     }
/*     */     
/*     */     public boolean isSynthetic() {
/* 439 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\internal\tools\PointcutExpressionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */