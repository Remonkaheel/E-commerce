/*     */ package org.aspectj.weaver.internal.tools;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.CompressingDataOutputStream;
/*     */ import org.aspectj.weaver.IntMap;
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.patterns.Bindings;
/*     */ import org.aspectj.weaver.patterns.ExposedState;
/*     */ import org.aspectj.weaver.patterns.FastMatchInfo;
/*     */ import org.aspectj.weaver.patterns.IScope;
/*     */ import org.aspectj.weaver.patterns.PatternNodeVisitor;
/*     */ import org.aspectj.weaver.patterns.Pointcut;
/*     */ import org.aspectj.weaver.reflect.ReflectionBasedReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.reflect.ReflectionFastMatchInfo;
/*     */ import org.aspectj.weaver.reflect.ReflectionShadow;
/*     */ import org.aspectj.weaver.reflect.ReflectionWorld;
/*     */ import org.aspectj.weaver.tools.ContextBasedMatcher;
/*     */ import org.aspectj.weaver.tools.FuzzyBoolean;
/*     */ import org.aspectj.weaver.tools.MatchingContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointcutDesignatorHandlerBasedPointcut
/*     */   extends Pointcut
/*     */ {
/*     */   private final ContextBasedMatcher matcher;
/*     */   private final World world;
/*     */   
/*     */   public PointcutDesignatorHandlerBasedPointcut(ContextBasedMatcher expr, World world) {
/*  50 */     this.matcher = expr;
/*  51 */     this.world = world;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getPointcutKind() {
/*  60 */     return 22;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FuzzyBoolean fastMatch(FastMatchInfo info) {
/*  69 */     if (info instanceof ReflectionFastMatchInfo) {
/*     */       
/*  71 */       if (!(this.world instanceof ReflectionWorld)) {
/*  72 */         throw new IllegalStateException("Can only match user-extension pcds with a ReflectionWorld");
/*     */       }
/*  74 */       Class<?> clazz = null;
/*     */       try {
/*  76 */         clazz = Class.forName(info.getType().getName(), false, ((ReflectionWorld)this.world).getClassLoader());
/*  77 */       } catch (ClassNotFoundException cnfe) {
/*  78 */         if (info.getType() instanceof ReferenceType) {
/*  79 */           ReferenceTypeDelegate rtd = ((ReferenceType)info.getType()).getDelegate();
/*  80 */           if (rtd instanceof ReflectionBasedReferenceTypeDelegate) {
/*  81 */             clazz = ((ReflectionBasedReferenceTypeDelegate)rtd).getClazz();
/*     */           }
/*     */         } 
/*     */       } 
/*  85 */       if (clazz == null) {
/*  86 */         return FuzzyBoolean.MAYBE;
/*     */       }
/*  88 */       return FuzzyBoolean.fromBoolean(this.matcher.couldMatchJoinPointsInType(clazz, ((ReflectionFastMatchInfo)info).getMatchingContext()));
/*     */     } 
/*  90 */     throw new IllegalStateException("Can only match user-extension pcds against Reflection FastMatchInfo objects");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int couldMatchKinds() {
/*  99 */     return Shadow.ALL_SHADOW_KINDS_BITS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FuzzyBoolean matchInternal(Shadow shadow) {
/* 108 */     if (shadow instanceof ReflectionShadow) {
/* 109 */       MatchingContext context = ((ReflectionShadow)shadow).getMatchingContext();
/* 110 */       FuzzyBoolean match = this.matcher.matchesStatically(context);
/* 111 */       if (match == FuzzyBoolean.MAYBE)
/* 112 */         return FuzzyBoolean.MAYBE; 
/* 113 */       if (match == FuzzyBoolean.YES)
/* 114 */         return FuzzyBoolean.YES; 
/* 115 */       if (match == FuzzyBoolean.NO) {
/* 116 */         return FuzzyBoolean.NO;
/*     */       }
/*     */     } 
/* 119 */     throw new IllegalStateException("Can only match user-extension pcds against Reflection shadows (not BCEL)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resolveBindings(IScope scope, Bindings bindings) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pointcut concretize1(ResolvedType inAspect, ResolvedType declaringType, IntMap bindings) {
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Test findResidueInternal(Shadow shadow, ExposedState state) {
/* 149 */     if (!this.matcher.mayNeedDynamicTest()) {
/* 150 */       return (Test)Literal.TRUE;
/*     */     }
/*     */     
/* 153 */     matchInternal(shadow);
/* 154 */     return new MatchingContextBasedTest(this.matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut parameterizeWith(Map typeVariableMap, World w) {
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompressingDataOutputStream s) throws IOException {
/* 173 */     throw new UnsupportedOperationException("can't write custom pointcut designator expressions to stream");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object accept(PatternNodeVisitor visitor, Object data) {
/* 184 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\internal\tools\PointcutDesignatorHandlerBasedPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */