/*     */ package org.aspectj.weaver.internal.tools;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.ResolvedMember;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.Shadow;
/*     */ import org.aspectj.weaver.World;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.patterns.AbstractPatternNodeVisitor;
/*     */ import org.aspectj.weaver.patterns.AnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.ArgsAnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.ArgsPointcut;
/*     */ import org.aspectj.weaver.patterns.CflowPointcut;
/*     */ import org.aspectj.weaver.patterns.ExposedState;
/*     */ import org.aspectj.weaver.patterns.FastMatchInfo;
/*     */ import org.aspectj.weaver.patterns.IfPointcut;
/*     */ import org.aspectj.weaver.patterns.NotAnnotationTypePattern;
/*     */ import org.aspectj.weaver.patterns.NotPointcut;
/*     */ import org.aspectj.weaver.patterns.PatternNodeVisitor;
/*     */ import org.aspectj.weaver.patterns.Pointcut;
/*     */ import org.aspectj.weaver.patterns.ThisOrTargetAnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.ThisOrTargetPointcut;
/*     */ import org.aspectj.weaver.patterns.WithinAnnotationPointcut;
/*     */ import org.aspectj.weaver.patterns.WithinCodeAnnotationPointcut;
/*     */ import org.aspectj.weaver.reflect.ReflectionFastMatchInfo;
/*     */ import org.aspectj.weaver.reflect.StandardShadow;
/*     */ import org.aspectj.weaver.reflect.StandardShadowMatchImpl;
/*     */ import org.aspectj.weaver.tools.DefaultMatchingContext;
/*     */ import org.aspectj.weaver.tools.MatchingContext;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.aspectj.weaver.tools.ShadowMatch;
/*     */ import org.aspectj.weaver.tools.StandardPointcutExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardPointcutExpressionImpl
/*     */   implements StandardPointcutExpression
/*     */ {
/*     */   private World world;
/*     */   private Pointcut pointcut;
/*     */   private String expression;
/*     */   private PointcutParameter[] parameters;
/*  53 */   private MatchingContext matchContext = (MatchingContext)new DefaultMatchingContext();
/*     */   
/*     */   public StandardPointcutExpressionImpl(Pointcut pointcut, String expression, PointcutParameter[] params, World inWorld) {
/*  56 */     this.pointcut = pointcut;
/*  57 */     this.expression = expression;
/*  58 */     this.world = inWorld;
/*  59 */     this.parameters = params;
/*  60 */     if (this.parameters == null) {
/*  61 */       this.parameters = new PointcutParameter[0];
/*     */     }
/*     */   }
/*     */   
/*     */   public Pointcut getUnderlyingPointcut() {
/*  66 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchingContext(MatchingContext aMatchContext) {
/*  75 */     this.matchContext = aMatchContext;
/*     */   }
/*     */   
/*     */   public boolean couldMatchJoinPointsInType(Class aClass) {
/*  79 */     ResolvedType matchType = this.world.resolve(aClass.getName());
/*  80 */     ReflectionFastMatchInfo info = new ReflectionFastMatchInfo(matchType, null, this.matchContext, this.world);
/*  81 */     return this.pointcut.fastMatch((FastMatchInfo)info).maybeTrue();
/*     */   }
/*     */   
/*     */   public boolean mayNeedDynamicTest() {
/*  85 */     HasPossibleDynamicContentVisitor visitor = new HasPossibleDynamicContentVisitor();
/*  86 */     this.pointcut.traverse((PatternNodeVisitor)visitor, null);
/*  87 */     return visitor.hasDynamicContent();
/*     */   }
/*     */   
/*     */   private ExposedState getExposedState() {
/*  91 */     return new ExposedState(this.parameters.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShadowMatch matchesMethodExecution(ResolvedMember aMethod) {
/*  99 */     return matchesExecution(aMethod);
/*     */   }
/*     */   
/*     */   public ShadowMatch matchesConstructorExecution(Constructor aConstructor) {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ShadowMatch matchesExecution(ResolvedMember aMember) {
/* 117 */     Shadow s = StandardShadow.makeExecutionShadow(this.world, aMember, this.matchContext);
/* 118 */     StandardShadowMatchImpl sm = getShadowMatch(s);
/* 119 */     sm.setSubject(aMember);
/* 120 */     sm.setWithinCode(null);
/* 121 */     sm.setWithinType((ResolvedType)aMember.getDeclaringType());
/* 122 */     return (ShadowMatch)sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShadowMatch matchesStaticInitialization(ResolvedType aType) {
/* 135 */     Shadow s = StandardShadow.makeStaticInitializationShadow(this.world, aType, this.matchContext);
/* 136 */     StandardShadowMatchImpl sm = getShadowMatch(s);
/* 137 */     sm.setSubject(null);
/* 138 */     sm.setWithinCode(null);
/* 139 */     sm.setWithinType(aType);
/* 140 */     return (ShadowMatch)sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShadowMatch matchesMethodCall(ResolvedMember aMethod, ResolvedMember withinCode) {
/* 171 */     Shadow s = StandardShadow.makeCallShadow(this.world, aMethod, withinCode, this.matchContext);
/* 172 */     StandardShadowMatchImpl sm = getShadowMatch(s);
/* 173 */     sm.setSubject(aMethod);
/* 174 */     sm.setWithinCode(withinCode);
/* 175 */     sm.setWithinType((ResolvedType)withinCode.getDeclaringType());
/* 176 */     return (ShadowMatch)sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StandardShadowMatchImpl getShadowMatch(Shadow forShadow) {
/*     */     Test test;
/* 262 */     FuzzyBoolean match = this.pointcut.match(forShadow);
/* 263 */     Literal literal = Literal.TRUE;
/* 264 */     ExposedState state = getExposedState();
/* 265 */     if (match.maybeTrue()) {
/* 266 */       test = this.pointcut.findResidue(forShadow, state);
/*     */     }
/* 268 */     StandardShadowMatchImpl sm = new StandardShadowMatchImpl(match, test, state, this.parameters);
/* 269 */     sm.setMatchingContext(this.matchContext);
/* 270 */     return sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPointcutExpression() {
/* 279 */     return this.expression;
/*     */   }
/*     */   
/*     */   private static class HasPossibleDynamicContentVisitor extends AbstractPatternNodeVisitor {
/*     */     private boolean hasDynamicContent = false;
/*     */     
/*     */     public boolean hasDynamicContent() {
/* 286 */       return this.hasDynamicContent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(WithinAnnotationPointcut node, Object data) {
/* 291 */       this.hasDynamicContent = true;
/* 292 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(WithinCodeAnnotationPointcut node, Object data) {
/* 297 */       this.hasDynamicContent = true;
/* 298 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(AnnotationPointcut node, Object data) {
/* 303 */       this.hasDynamicContent = true;
/* 304 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ArgsAnnotationPointcut node, Object data) {
/* 309 */       this.hasDynamicContent = true;
/* 310 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ArgsPointcut node, Object data) {
/* 315 */       this.hasDynamicContent = true;
/* 316 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(CflowPointcut node, Object data) {
/* 321 */       this.hasDynamicContent = true;
/* 322 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(IfPointcut node, Object data) {
/* 327 */       this.hasDynamicContent = true;
/* 328 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(NotAnnotationTypePattern node, Object data) {
/* 333 */       return node.getNegatedPattern().accept((PatternNodeVisitor)this, data);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(NotPointcut node, Object data) {
/* 338 */       return node.getNegatedPointcut().accept((PatternNodeVisitor)this, data);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ThisOrTargetAnnotationPointcut node, Object data) {
/* 343 */       this.hasDynamicContent = true;
/* 344 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object visit(ThisOrTargetPointcut node, Object data) {
/* 349 */       this.hasDynamicContent = true;
/* 350 */       return null;
/*     */     }
/*     */     
/*     */     private HasPossibleDynamicContentVisitor() {}
/*     */   }
/*     */   
/*     */   public static class Handler implements Member {
/*     */     private Class<?> decClass;
/*     */     private Class<?> exType;
/*     */     
/*     */     public Handler(Class<?> decClass, Class<?> exType) {
/* 361 */       this.decClass = decClass;
/* 362 */       this.exType = exType;
/*     */     }
/*     */     
/*     */     public int getModifiers() {
/* 366 */       return 0;
/*     */     }
/*     */     
/*     */     public Class getDeclaringClass() {
/* 370 */       return this.decClass;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 374 */       return null;
/*     */     }
/*     */     
/*     */     public Class getHandledExceptionType() {
/* 378 */       return this.exType;
/*     */     }
/*     */     
/*     */     public boolean isSynthetic() {
/* 382 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\internal\tools\StandardPointcutExpressionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */