/*    */ package org.aspectj.weaver.internal.tools;
/*    */ 
/*    */ import org.aspectj.weaver.ast.ITestVisitor;
/*    */ import org.aspectj.weaver.ast.Test;
/*    */ import org.aspectj.weaver.tools.ContextBasedMatcher;
/*    */ import org.aspectj.weaver.tools.MatchingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatchingContextBasedTest
/*    */   extends Test
/*    */ {
/*    */   private final ContextBasedMatcher matcher;
/*    */   
/*    */   public MatchingContextBasedTest(ContextBasedMatcher pc) {
/* 28 */     this.matcher = pc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(ITestVisitor v) {
/* 36 */     v.visit(this);
/*    */   }
/*    */   
/*    */   public boolean matches(MatchingContext context) {
/* 40 */     return this.matcher.matchesDynamically(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\internal\tools\MatchingContextBasedTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */