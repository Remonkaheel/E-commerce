/*    */ package org.aspectj.weaver.internal.tools;
/*    */ 
/*    */ import org.aspectj.weaver.ResolvedType;
/*    */ import org.aspectj.weaver.World;
/*    */ import org.aspectj.weaver.patterns.TypePattern;
/*    */ import org.aspectj.weaver.reflect.ReflectionBasedReferenceTypeDelegateFactory;
/*    */ import org.aspectj.weaver.tools.TypePatternMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypePatternMatcherImpl
/*    */   implements TypePatternMatcher
/*    */ {
/*    */   private final TypePattern pattern;
/*    */   private final World world;
/*    */   
/*    */   public TypePatternMatcherImpl(TypePattern pattern, World world) {
/* 24 */     this.pattern = pattern;
/* 25 */     this.world = world;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(Class aClass) {
/* 30 */     ResolvedType rt = ReflectionBasedReferenceTypeDelegateFactory.resolveTypeInWorld(aClass, this.world);
/* 31 */     return this.pattern.matchesStatically(rt);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\internal\tools\TypePatternMatcherImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */