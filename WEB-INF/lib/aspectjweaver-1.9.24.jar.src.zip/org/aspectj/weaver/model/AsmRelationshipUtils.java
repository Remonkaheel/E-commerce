/*    */ package org.aspectj.weaver.model;
/*    */ 
/*    */ import org.aspectj.weaver.patterns.AndPointcut;
/*    */ import org.aspectj.weaver.patterns.OrPointcut;
/*    */ import org.aspectj.weaver.patterns.Pointcut;
/*    */ import org.aspectj.weaver.patterns.ReferencePointcut;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsmRelationshipUtils
/*    */ {
/*    */   public static final String DECLARE_PRECEDENCE = "precedence";
/*    */   public static final String DECLARE_SOFT = "soft";
/*    */   public static final String DECLARE_PARENTS = "parents";
/*    */   public static final String DECLARE_WARNING = "warning";
/*    */   public static final String DECLARE_ERROR = "error";
/*    */   public static final String DECLARE_UNKNONWN = "<unknown declare>";
/*    */   public static final String POINTCUT_ABSTRACT = "<abstract pointcut>";
/*    */   public static final String POINTCUT_ANONYMOUS = "<anonymous pointcut>";
/*    */   public static final String DOUBLE_DOTS = "..";
/*    */   public static final int MAX_MESSAGE_LENGTH = 18;
/*    */   public static final String DEC_LABEL = "declare";
/*    */   
/*    */   public static String genDeclareMessage(String message) {
/* 42 */     int length = message.length();
/* 43 */     if (length < 18) {
/* 44 */       return message;
/*    */     }
/* 46 */     return message.substring(0, 17) + "..";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String genPointcutDetails(Pointcut pcd) {
/* 55 */     StringBuilder details = new StringBuilder();
/* 56 */     if (pcd instanceof ReferencePointcut) {
/* 57 */       ReferencePointcut rp = (ReferencePointcut)pcd;
/* 58 */       details.append(rp.name).append("..");
/* 59 */     } else if (pcd instanceof AndPointcut) {
/* 60 */       AndPointcut ap = (AndPointcut)pcd;
/* 61 */       if (ap.getLeft() instanceof ReferencePointcut) {
/* 62 */         details.append(ap.getLeft().toString()).append("..");
/*    */       } else {
/* 64 */         details.append("<anonymous pointcut>").append("..");
/*    */       } 
/* 66 */     } else if (pcd instanceof OrPointcut) {
/* 67 */       OrPointcut op = (OrPointcut)pcd;
/* 68 */       if (op.getLeft() instanceof ReferencePointcut) {
/* 69 */         details.append(op.getLeft().toString()).append("..");
/*    */       } else {
/* 71 */         details.append("<anonymous pointcut>").append("..");
/*    */       } 
/*    */     } else {
/* 74 */       details.append("<anonymous pointcut>");
/*    */     } 
/* 76 */     return details.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\model\AsmRelationshipUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */