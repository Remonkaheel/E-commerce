/*      */ package org.aspectj.weaver.model;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import org.aspectj.asm.AsmManager;
/*      */ import org.aspectj.asm.IHierarchy;
/*      */ import org.aspectj.asm.IProgramElement;
/*      */ import org.aspectj.asm.IRelationship;
/*      */ import org.aspectj.asm.IRelationshipMap;
/*      */ import org.aspectj.asm.internal.HandleProviderDelimiter;
/*      */ import org.aspectj.asm.internal.ProgramElement;
/*      */ import org.aspectj.bridge.ISourceLocation;
/*      */ import org.aspectj.bridge.SourceLocation;
/*      */ import org.aspectj.weaver.Advice;
/*      */ import org.aspectj.weaver.AdviceKind;
/*      */ import org.aspectj.weaver.Checker;
/*      */ import org.aspectj.weaver.Lint;
/*      */ import org.aspectj.weaver.Member;
/*      */ import org.aspectj.weaver.NewParentTypeMunger;
/*      */ import org.aspectj.weaver.ReferenceType;
/*      */ import org.aspectj.weaver.ResolvedMember;
/*      */ import org.aspectj.weaver.ResolvedPointcutDefinition;
/*      */ import org.aspectj.weaver.ResolvedType;
/*      */ import org.aspectj.weaver.ResolvedTypeMunger;
/*      */ import org.aspectj.weaver.Shadow;
/*      */ import org.aspectj.weaver.ShadowMunger;
/*      */ import org.aspectj.weaver.UnresolvedType;
/*      */ import org.aspectj.weaver.World;
/*      */ import org.aspectj.weaver.bcel.BcelShadow;
/*      */ import org.aspectj.weaver.bcel.BcelTypeMunger;
/*      */ import org.aspectj.weaver.patterns.DeclareErrorOrWarning;
/*      */ import org.aspectj.weaver.patterns.DeclareParents;
/*      */ import org.aspectj.weaver.patterns.Pointcut;
/*      */ import org.aspectj.weaver.patterns.TypePatternList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AsmRelationshipProvider
/*      */ {
/*      */   public static final String ADVISES = "advises";
/*      */   public static final String ADVISED_BY = "advised by";
/*      */   public static final String DECLARES_ON = "declares on";
/*      */   public static final String DECLAREDY_BY = "declared by";
/*      */   public static final String SOFTENS = "softens";
/*      */   public static final String SOFTENED_BY = "softened by";
/*      */   public static final String MATCHED_BY = "matched by";
/*      */   public static final String MATCHES_DECLARE = "matches declare";
/*      */   public static final String INTER_TYPE_DECLARES = "declared on";
/*      */   public static final String INTER_TYPE_DECLARED_BY = "aspect declarations";
/*      */   public static final String ANNOTATES = "annotates";
/*      */   public static final String ANNOTATED_BY = "annotated by";
/*      */   
/*      */   public static void addDeclareErrorOrWarningRelationship(AsmManager model, Shadow affectedShadow, Checker deow) {
/*   77 */     if (model == null) {
/*      */       return;
/*      */     }
/*   80 */     if (affectedShadow.getSourceLocation() == null || deow.getSourceLocation() == null) {
/*      */       return;
/*      */     }
/*      */     
/*   84 */     if (World.createInjarHierarchy) {
/*   85 */       createHierarchyForBinaryAspect(model, (ShadowMunger)deow);
/*      */     }
/*      */     
/*   88 */     IProgramElement targetNode = getNode(model, affectedShadow);
/*   89 */     if (targetNode == null) {
/*      */       return;
/*      */     }
/*   92 */     String targetHandle = targetNode.getHandleIdentifier();
/*   93 */     if (targetHandle == null) {
/*      */       return;
/*      */     }
/*      */     
/*   97 */     IProgramElement sourceNode = model.getHierarchy().findElementForSourceLine(deow.getSourceLocation());
/*   98 */     String sourceHandle = sourceNode.getHandleIdentifier();
/*   99 */     if (sourceHandle == null) {
/*      */       return;
/*      */     }
/*      */     
/*  103 */     IRelationshipMap relmap = model.getRelationshipMap();
/*  104 */     IRelationship foreward = relmap.get(sourceHandle, IRelationship.Kind.DECLARE, "matched by", false, true);
/*  105 */     foreward.addTarget(targetHandle);
/*      */     
/*  107 */     IRelationship back = relmap.get(targetHandle, IRelationship.Kind.DECLARE, "matches declare", false, true);
/*  108 */     if (back != null && back.getTargets() != null) {
/*  109 */       back.addTarget(sourceHandle);
/*      */     }
/*  111 */     if (sourceNode.getSourceLocation() != null) {
/*  112 */       model.addAspectInEffectThisBuild(sourceNode.getSourceLocation().getSourceFile());
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean isMixinRelated(ResolvedTypeMunger typeTransformer) {
/*  117 */     ResolvedTypeMunger.Kind kind = typeTransformer.getKind();
/*  118 */     return (kind == ResolvedTypeMunger.MethodDelegate2 || kind == ResolvedTypeMunger.FieldHost || (kind == ResolvedTypeMunger.Parent && ((NewParentTypeMunger)typeTransformer)
/*  119 */       .isMixin()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addRelationship(AsmManager model, ResolvedType onType, ResolvedTypeMunger typeTransformer, ResolvedType originatingAspect) {
/*  127 */     if (model == null) {
/*      */       return;
/*      */     }
/*      */     
/*  131 */     if (World.createInjarHierarchy && isBinaryAspect(originatingAspect)) {
/*  132 */       createHierarchy(model, typeTransformer, originatingAspect);
/*      */     }
/*      */     
/*  135 */     if (originatingAspect.getSourceLocation() != null) {
/*  136 */       String sourceHandle = "";
/*  137 */       IProgramElement sourceNode = null;
/*  138 */       if (typeTransformer.getSourceLocation() != null && typeTransformer.getSourceLocation().getOffset() != -1 && 
/*  139 */         !isMixinRelated(typeTransformer)) {
/*  140 */         sourceNode = model.getHierarchy().findElementForType(originatingAspect.getPackageName(), originatingAspect
/*  141 */             .getClassName());
/*  142 */         IProgramElement closer = model.getHierarchy().findCloserMatchForLineNumber(sourceNode, typeTransformer
/*  143 */             .getSourceLocation().getLine());
/*  144 */         if (closer != null) {
/*  145 */           sourceNode = closer;
/*      */         }
/*  147 */         if (sourceNode == null)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  152 */           if (World.createInjarHierarchy) {
/*  153 */             createHierarchy(model, typeTransformer, originatingAspect);
/*  154 */             if (typeTransformer.getSourceLocation() != null && typeTransformer.getSourceLocation().getOffset() != -1 && 
/*  155 */               !isMixinRelated(typeTransformer)) {
/*  156 */               sourceNode = model.getHierarchy().findElementForType(originatingAspect.getPackageName(), originatingAspect
/*  157 */                   .getClassName());
/*  158 */               IProgramElement closer2 = model.getHierarchy().findCloserMatchForLineNumber(sourceNode, typeTransformer
/*  159 */                   .getSourceLocation().getLine());
/*  160 */               if (closer2 != null) {
/*  161 */                 sourceNode = closer2;
/*      */               }
/*      */             } else {
/*  164 */               sourceNode = model.getHierarchy().findElementForType(originatingAspect.getPackageName(), originatingAspect
/*  165 */                   .getClassName());
/*      */             } 
/*      */           } 
/*      */         }
/*  169 */         sourceHandle = sourceNode.getHandleIdentifier();
/*      */       } else {
/*  171 */         sourceNode = model.getHierarchy().findElementForType(originatingAspect.getPackageName(), originatingAspect
/*  172 */             .getClassName());
/*      */ 
/*      */ 
/*      */         
/*  176 */         sourceHandle = sourceNode.getHandleIdentifier();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  187 */       if (sourceHandle == null) {
/*      */         return;
/*      */       }
/*  190 */       String targetHandle = findOrFakeUpNode(model, onType);
/*  191 */       if (targetHandle == null) {
/*      */         return;
/*      */       }
/*  194 */       IRelationshipMap mapper = model.getRelationshipMap();
/*  195 */       IRelationship foreward = mapper.get(sourceHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "declared on", false, true);
/*      */       
/*  197 */       foreward.addTarget(targetHandle);
/*      */       
/*  199 */       IRelationship back = mapper.get(targetHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "aspect declarations", false, true);
/*      */       
/*  201 */       back.addTarget(sourceHandle);
/*  202 */       if (sourceNode != null && sourceNode.getSourceLocation() != null)
/*      */       {
/*  204 */         model.addAspectInEffectThisBuild(sourceNode.getSourceLocation().getSourceFile());
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String findOrFakeUpNode(AsmManager model, ResolvedType onType) {
/*  210 */     IHierarchy hierarchy = model.getHierarchy();
/*  211 */     ISourceLocation sourceLocation = onType.getSourceLocation();
/*  212 */     String canonicalFilePath = model.getCanonicalFilePath(sourceLocation.getSourceFile());
/*  213 */     int lineNumber = sourceLocation.getLine();
/*      */     
/*  215 */     IProgramElement node = hierarchy.findNodeForSourceFile(hierarchy.getRoot(), canonicalFilePath);
/*  216 */     if (node == null) {
/*      */       
/*  218 */       String bpath = onType.getBinaryPath();
/*  219 */       if (bpath == null) {
/*  220 */         return model.getHandleProvider().createHandleIdentifier(createFileStructureNode(model, canonicalFilePath));
/*      */       }
/*  222 */       IProgramElement programElement = model.getHierarchy().getRoot();
/*      */       
/*  224 */       StringBuilder phantomHandle = new StringBuilder();
/*      */ 
/*      */       
/*  227 */       phantomHandle.append(programElement.getHandleIdentifier());
/*      */ 
/*      */       
/*  230 */       phantomHandle.append(HandleProviderDelimiter.PACKAGEFRAGMENTROOT.getDelimiter()).append(HandleProviderDelimiter.PHANTOM
/*  231 */           .getDelimiter());
/*      */       
/*  233 */       int pos = bpath.indexOf('!');
/*  234 */       if (pos != -1) {
/*      */         
/*  236 */         String jarPath = bpath.substring(0, pos);
/*  237 */         String element = model.getHandleElementForInpath(jarPath);
/*  238 */         if (element != null) {
/*  239 */           phantomHandle.append(element);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  244 */       String packageName = onType.getPackageName();
/*  245 */       phantomHandle.append(HandleProviderDelimiter.PACKAGEFRAGMENT.getDelimiter()).append(packageName);
/*      */ 
/*      */ 
/*      */       
/*  249 */       int dotClassPosition = bpath.lastIndexOf(".class");
/*  250 */       if (dotClassPosition == -1) {
/*  251 */         phantomHandle.append(HandleProviderDelimiter.CLASSFILE.getDelimiter()).append("UNKNOWN.class");
/*      */       } else {
/*  253 */         int startPosition = dotClassPosition;
/*      */         char ch;
/*  255 */         while (startPosition > 0 && (ch = bpath.charAt(startPosition)) != '/' && ch != '\\' && ch != '!') {
/*  256 */           startPosition--;
/*      */         }
/*  258 */         String classFile = bpath.substring(startPosition + 1, dotClassPosition + 6);
/*  259 */         phantomHandle.append(HandleProviderDelimiter.CLASSFILE.getDelimiter()).append(classFile);
/*      */       } 
/*      */ 
/*      */       
/*  263 */       phantomHandle.append(HandleProviderDelimiter.TYPE.getDelimiter()).append(onType.getClassName());
/*      */       
/*  265 */       return phantomHandle.toString();
/*      */     } 
/*      */ 
/*      */     
/*  269 */     IProgramElement closernode = hierarchy.findCloserMatchForLineNumber(node, lineNumber);
/*  270 */     if (closernode == null) {
/*  271 */       return node.getHandleIdentifier();
/*      */     }
/*  273 */     return closernode.getHandleIdentifier();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IProgramElement createFileStructureNode(AsmManager asm, String sourceFilePath) {
/*  281 */     int lastSlash = sourceFilePath.lastIndexOf('\\');
/*  282 */     if (lastSlash == -1) {
/*  283 */       lastSlash = sourceFilePath.lastIndexOf('/');
/*      */     }
/*      */     
/*  286 */     int i = sourceFilePath.lastIndexOf('!');
/*  287 */     int j = sourceFilePath.indexOf(".class");
/*  288 */     if (i > lastSlash && i != -1 && j != -1)
/*      */     {
/*  290 */       lastSlash = i;
/*      */     }
/*  292 */     String fileName = sourceFilePath.substring(lastSlash + 1);
/*  293 */     ProgramElement programElement = new ProgramElement(asm, fileName, IProgramElement.Kind.FILE_JAVA, (ISourceLocation)new SourceLocation(new File(sourceFilePath), 1, 1), 0, null, null);
/*      */ 
/*      */     
/*  296 */     programElement.addChild(IHierarchy.NO_STRUCTURE);
/*  297 */     return (IProgramElement)programElement;
/*      */   }
/*      */   
/*      */   private static boolean isBinaryAspect(ResolvedType aspect) {
/*  301 */     return (aspect.getBinaryPath() != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ISourceLocation getBinarySourceLocation(ResolvedType aspect, ISourceLocation sl) {
/*  310 */     if (sl == null) {
/*  311 */       return null;
/*      */     }
/*  313 */     String sourceFileName = null;
/*  314 */     if (aspect instanceof ReferenceType) {
/*  315 */       String s = ((ReferenceType)aspect).getDelegate().getSourcefilename();
/*  316 */       int i = s.lastIndexOf('/');
/*  317 */       if (i != -1) {
/*  318 */         sourceFileName = s.substring(i + 1);
/*      */       } else {
/*  320 */         sourceFileName = s;
/*      */       } 
/*      */     } 
/*  323 */     return (ISourceLocation)new SourceLocation(getBinaryFile(aspect), sl.getLine(), sl.getEndLine(), 
/*  324 */         (sl.getColumn() == 0) ? -2147483647 : sl.getColumn(), sl.getContext(), sourceFileName);
/*      */   }
/*      */ 
/*      */   
/*      */   private static ISourceLocation createSourceLocation(String sourcefilename, ResolvedType aspect, ISourceLocation sl) {
/*  329 */     return (ISourceLocation)new SourceLocation(getBinaryFile(aspect), sl.getLine(), sl.getEndLine(), 
/*  330 */         (sl.getColumn() == 0) ? -2147483647 : sl.getColumn(), sl.getContext(), sourcefilename);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getSourceFileName(ResolvedType aspect) {
/*  335 */     String sourceFileName = null;
/*  336 */     if (aspect instanceof ReferenceType) {
/*  337 */       String s = ((ReferenceType)aspect).getDelegate().getSourcefilename();
/*  338 */       int i = s.lastIndexOf('/');
/*  339 */       if (i != -1) {
/*  340 */         sourceFileName = s.substring(i + 1);
/*      */       } else {
/*  342 */         sourceFileName = s;
/*      */       } 
/*      */     } 
/*  345 */     return sourceFileName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static File getBinaryFile(ResolvedType aspect) {
/*  354 */     String s = aspect.getBinaryPath();
/*  355 */     File f = aspect.getSourceLocation().getSourceFile();
/*      */     
/*  357 */     int i = f.getPath().lastIndexOf('.');
/*  358 */     String path = null;
/*  359 */     if (i != -1) {
/*  360 */       path = f.getPath().substring(0, i) + ".class";
/*      */     } else {
/*  362 */       path = f.getPath() + ".class";
/*      */     } 
/*  364 */     return new File(s + "!" + path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void createHierarchy(AsmManager model, ResolvedTypeMunger typeTransformer, ResolvedType aspect) {
/*      */     ProgramElement programElement2, programElement3;
/*  378 */     IProgramElement filenode = model.getHierarchy().findElementForSourceLine(typeTransformer.getSourceLocation());
/*  379 */     if (filenode == null && (
/*  380 */       typeTransformer.getKind() == ResolvedTypeMunger.MethodDelegate2 || typeTransformer
/*  381 */       .getKind() == ResolvedTypeMunger.FieldHost)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  393 */     if (!filenode.getKind().equals(IProgramElement.Kind.FILE_JAVA)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  398 */     ISourceLocation binLocation = getBinarySourceLocation(aspect, aspect.getSourceLocation());
/*  399 */     String f = getBinaryFile(aspect).getName();
/*  400 */     ProgramElement programElement1 = new ProgramElement(model, f, IProgramElement.Kind.FILE, binLocation, 0, null, null);
/*      */ 
/*      */     
/*  403 */     IProgramElement root = model.getHierarchy().getRoot();
/*  404 */     IProgramElement binaries = model.getHierarchy().findElementForLabel(root, IProgramElement.Kind.SOURCE_FOLDER, "binaries");
/*  405 */     if (binaries == null) {
/*  406 */       programElement2 = new ProgramElement(model, "binaries", IProgramElement.Kind.SOURCE_FOLDER, new ArrayList());
/*  407 */       root.addChild((IProgramElement)programElement2);
/*      */     } 
/*      */     
/*  410 */     String packagename = (aspect.getPackageName() == null) ? "" : aspect.getPackageName();
/*      */     
/*  412 */     IProgramElement pkgNode = model.getHierarchy().findElementForLabel((IProgramElement)programElement2, IProgramElement.Kind.PACKAGE, packagename);
/*      */     
/*  414 */     if (pkgNode == null) {
/*  415 */       programElement3 = new ProgramElement(model, packagename, IProgramElement.Kind.PACKAGE, new ArrayList());
/*  416 */       programElement2.addChild((IProgramElement)programElement3);
/*  417 */       programElement3.addChild((IProgramElement)programElement1);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  422 */       programElement3.addChild((IProgramElement)programElement1);
/*  423 */       for (IProgramElement element : programElement3.getChildren()) {
/*  424 */         if (!element.equals(programElement1) && element.getHandleIdentifier().equals(programElement1.getHandleIdentifier())) {
/*      */ 
/*      */           
/*  427 */           programElement3.removeChild((IProgramElement)programElement1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  458 */     ProgramElement programElement4 = new ProgramElement(model, aspect.getSimpleName(), IProgramElement.Kind.ASPECT, getBinarySourceLocation(aspect, aspect.getSourceLocation()), aspect.getModifiers(), null, null);
/*  459 */     programElement1.addChild((IProgramElement)programElement4);
/*      */     
/*  461 */     addChildNodes(model, aspect, (IProgramElement)programElement4, aspect.getDeclaredPointcuts());
/*      */     
/*  463 */     addChildNodes(model, aspect, (IProgramElement)programElement4, aspect.getDeclaredAdvice());
/*  464 */     addChildNodes(model, aspect, (IProgramElement)programElement4, aspect.getDeclares());
/*  465 */     addChildNodes(model, aspect, (IProgramElement)programElement4, aspect.getTypeMungers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addDeclareAnnotationRelationship(AsmManager model, ISourceLocation declareAnnotationLocation, ISourceLocation annotatedLocation, boolean isRemove) {
/*  474 */     if (model == null) {
/*      */       return;
/*      */     }
/*      */     
/*  478 */     IProgramElement sourceNode = model.getHierarchy().findElementForSourceLine(declareAnnotationLocation);
/*  479 */     String sourceHandle = sourceNode.getHandleIdentifier();
/*  480 */     if (sourceHandle == null) {
/*      */       return;
/*      */     }
/*      */     
/*  484 */     IProgramElement targetNode = model.getHierarchy().findElementForSourceLine(annotatedLocation);
/*  485 */     String targetHandle = targetNode.getHandleIdentifier();
/*  486 */     if (targetHandle == null) {
/*      */       return;
/*      */     }
/*      */     
/*  490 */     IRelationshipMap mapper = model.getRelationshipMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  503 */     IRelationship foreward = mapper.get(sourceHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "annotates", false, true);
/*  504 */     foreward.addTarget(targetHandle);
/*      */     
/*  506 */     IRelationship back = mapper.get(targetHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "annotated by", false, true);
/*  507 */     back.addTarget(sourceHandle);
/*  508 */     if (sourceNode.getSourceLocation() != null) {
/*  509 */       model.addAspectInEffectThisBuild(sourceNode.getSourceLocation().getSourceFile());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void createHierarchyForBinaryAspect(AsmManager asm, ShadowMunger munger) {
/*      */     ProgramElement programElement2, programElement3;
/*  518 */     if (!munger.isBinary()) {
/*      */       return;
/*      */     }
/*      */     
/*  522 */     IProgramElement sourceFileNode = asm.getHierarchy().findElementForSourceLine(munger.getSourceLocation());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  527 */     if (!sourceFileNode.getKind().equals(IProgramElement.Kind.FILE_JAVA)) {
/*      */       return;
/*      */     }
/*      */     
/*  531 */     ResolvedType aspect = munger.getDeclaringType();
/*      */ 
/*      */ 
/*      */     
/*  535 */     ProgramElement programElement1 = new ProgramElement(asm, sourceFileNode.getName(), IProgramElement.Kind.FILE, munger.getBinarySourceLocation(aspect.getSourceLocation()), 0, null, null);
/*      */ 
/*      */     
/*  538 */     IProgramElement root = asm.getHierarchy().getRoot();
/*  539 */     IProgramElement binaries = asm.getHierarchy().findElementForLabel(root, IProgramElement.Kind.SOURCE_FOLDER, "binaries");
/*  540 */     if (binaries == null) {
/*  541 */       programElement2 = new ProgramElement(asm, "binaries", IProgramElement.Kind.SOURCE_FOLDER, new ArrayList());
/*  542 */       root.addChild((IProgramElement)programElement2);
/*      */     } 
/*      */     
/*  545 */     String packagename = (aspect.getPackageName() == null) ? "" : aspect.getPackageName();
/*      */     
/*  547 */     IProgramElement pkgNode = asm.getHierarchy().findElementForLabel((IProgramElement)programElement2, IProgramElement.Kind.PACKAGE, packagename);
/*      */     
/*  549 */     if (pkgNode == null) {
/*  550 */       programElement3 = new ProgramElement(asm, packagename, IProgramElement.Kind.PACKAGE, new ArrayList());
/*  551 */       programElement2.addChild((IProgramElement)programElement3);
/*  552 */       programElement3.addChild((IProgramElement)programElement1);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  557 */       programElement3.addChild((IProgramElement)programElement1);
/*  558 */       for (IProgramElement element : programElement3.getChildren()) {
/*  559 */         if (!element.equals(programElement1) && element.getHandleIdentifier().equals(programElement1.getHandleIdentifier())) {
/*      */ 
/*      */           
/*  562 */           programElement3.removeChild((IProgramElement)programElement1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  593 */     ProgramElement programElement4 = new ProgramElement(asm, aspect.getSimpleName(), IProgramElement.Kind.ASPECT, munger.getBinarySourceLocation(aspect.getSourceLocation()), aspect.getModifiers(), null, null);
/*  594 */     programElement1.addChild((IProgramElement)programElement4);
/*      */     
/*  596 */     String sourcefilename = getSourceFileName(aspect);
/*  597 */     addPointcuts(asm, sourcefilename, aspect, (IProgramElement)programElement4, aspect.getDeclaredPointcuts());
/*  598 */     addChildNodes(asm, aspect, (IProgramElement)programElement4, aspect.getDeclaredAdvice());
/*  599 */     addChildNodes(asm, aspect, (IProgramElement)programElement4, aspect.getDeclares());
/*  600 */     addChildNodes(asm, aspect, (IProgramElement)programElement4, aspect.getTypeMungers());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addPointcuts(AsmManager model, String sourcefilename, ResolvedType aspect, IProgramElement containingAspect, ResolvedMember[] pointcuts) {
/*  606 */     for (ResolvedMember pointcut : pointcuts) {
/*  607 */       if (pointcut instanceof ResolvedPointcutDefinition) {
/*  608 */         ResolvedPointcutDefinition rpcd = (ResolvedPointcutDefinition)pointcut;
/*  609 */         Pointcut p = rpcd.getPointcut();
/*  610 */         ISourceLocation sLoc = (p == null) ? null : p.getSourceLocation();
/*  611 */         if (sLoc == null) {
/*  612 */           sLoc = rpcd.getSourceLocation();
/*      */         }
/*  614 */         ISourceLocation pointcutLocation = (sLoc == null) ? null : createSourceLocation(sourcefilename, aspect, sLoc);
/*      */         
/*  616 */         ProgramElement pointcutElement = new ProgramElement(model, pointcut.getName(), IProgramElement.Kind.POINTCUT, pointcutLocation, pointcut.getModifiers(), NO_COMMENT, Collections.emptyList());
/*  617 */         containingAspect.addChild((IProgramElement)pointcutElement);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*  622 */   private static final String NO_COMMENT = null;
/*      */   
/*      */   private static void addChildNodes(AsmManager asm, ResolvedType aspect, IProgramElement parent, ResolvedMember[] children) {
/*  625 */     for (ResolvedMember pcd : children) {
/*  626 */       if (pcd instanceof ResolvedPointcutDefinition) {
/*  627 */         ResolvedPointcutDefinition rpcd = (ResolvedPointcutDefinition)pcd;
/*  628 */         Pointcut p = rpcd.getPointcut();
/*  629 */         ISourceLocation sLoc = (p == null) ? null : p.getSourceLocation();
/*  630 */         if (sLoc == null) {
/*  631 */           sLoc = rpcd.getSourceLocation();
/*      */         }
/*  633 */         parent.addChild((IProgramElement)new ProgramElement(asm, pcd.getName(), IProgramElement.Kind.POINTCUT, getBinarySourceLocation(aspect, sLoc), pcd
/*  634 */               .getModifiers(), null, Collections.emptyList()));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void addChildNodes(AsmManager asm, ResolvedType aspect, IProgramElement parent, Collection<?> children) {
/*  640 */     int deCtr = 1;
/*  641 */     int dwCtr = 1;
/*  642 */     for (Object element : children) {
/*  643 */       if (element instanceof DeclareErrorOrWarning) {
/*  644 */         DeclareErrorOrWarning decl = (DeclareErrorOrWarning)element;
/*  645 */         int counter = 0;
/*  646 */         if (decl.isError()) {
/*  647 */           counter = deCtr++;
/*      */         } else {
/*  649 */           counter = dwCtr++;
/*      */         } 
/*  651 */         parent.addChild(createDeclareErrorOrWarningChild(asm, aspect, decl, counter)); continue;
/*  652 */       }  if (element instanceof Advice) {
/*  653 */         Advice advice = (Advice)element;
/*  654 */         parent.addChild(createAdviceChild(asm, advice)); continue;
/*  655 */       }  if (element instanceof DeclareParents) {
/*  656 */         parent.addChild(createDeclareParentsChild(asm, (DeclareParents)element)); continue;
/*  657 */       }  if (element instanceof BcelTypeMunger) {
/*  658 */         IProgramElement newChild = createIntertypeDeclaredChild(asm, aspect, (BcelTypeMunger)element);
/*      */         
/*  660 */         if (newChild != null) {
/*  661 */           parent.addChild(newChild);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IProgramElement createDeclareErrorOrWarningChild(AsmManager model, ResolvedType aspect, DeclareErrorOrWarning decl, int count) {
/*  687 */     ProgramElement programElement = new ProgramElement(model, decl.getName(), decl.isError() ? IProgramElement.Kind.DECLARE_ERROR : IProgramElement.Kind.DECLARE_WARNING, getBinarySourceLocation(aspect, decl.getSourceLocation()), decl.getDeclaringType().getModifiers(), null, null);
/*  688 */     programElement.setDetails("\"" + AsmRelationshipUtils.genDeclareMessage(decl.getMessage()) + "\"");
/*  689 */     if (count != -1) {
/*  690 */       programElement.setBytecodeName(decl.getName() + "_" + count);
/*      */     }
/*  692 */     return (IProgramElement)programElement;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static IProgramElement createAdviceChild(AsmManager model, Advice advice) {
/*  698 */     ProgramElement programElement = new ProgramElement(model, advice.getKind().getName(), IProgramElement.Kind.ADVICE, advice.getBinarySourceLocation(advice.getSourceLocation()), advice.getSignature().getModifiers(), null, Collections.emptyList());
/*  699 */     programElement.setDetails(AsmRelationshipUtils.genPointcutDetails(advice.getPointcut()));
/*  700 */     programElement.setBytecodeName(advice.getSignature().getName());
/*  701 */     return (IProgramElement)programElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IProgramElement createIntertypeDeclaredChild(AsmManager model, ResolvedType aspect, BcelTypeMunger itd) {
/*  710 */     ResolvedTypeMunger rtMunger = itd.getMunger();
/*      */     
/*  712 */     ResolvedMember sig = rtMunger.getSignature();
/*  713 */     ResolvedTypeMunger.Kind kind = rtMunger.getKind();
/*  714 */     if (kind == ResolvedTypeMunger.Field) {
/*      */       
/*  716 */       String name = sig.getDeclaringType().getClassName() + "." + sig.getName();
/*  717 */       if (name.contains("$")) {
/*  718 */         name = name.substring(name.indexOf("$") + 1);
/*      */       }
/*      */       
/*  721 */       ProgramElement programElement = new ProgramElement(model, name, IProgramElement.Kind.INTER_TYPE_FIELD, getBinarySourceLocation(aspect, itd.getSourceLocation()), rtMunger.getSignature().getModifiers(), null, Collections.emptyList());
/*  722 */       programElement.setCorrespondingType(sig.getReturnType().getName());
/*  723 */       return (IProgramElement)programElement;
/*  724 */     }  if (kind == ResolvedTypeMunger.Method) {
/*      */       
/*  726 */       String name = sig.getDeclaringType().getClassName() + "." + sig.getName();
/*  727 */       if (name.contains("$")) {
/*  728 */         name = name.substring(name.indexOf("$") + 1);
/*      */       }
/*      */       
/*  731 */       ProgramElement programElement = new ProgramElement(model, name, IProgramElement.Kind.INTER_TYPE_METHOD, getBinarySourceLocation(aspect, itd.getSourceLocation()), rtMunger.getSignature().getModifiers(), null, Collections.emptyList());
/*  732 */       setParams((IProgramElement)programElement, sig);
/*  733 */       return (IProgramElement)programElement;
/*  734 */     }  if (kind == ResolvedTypeMunger.Constructor) {
/*  735 */       String name = sig.getDeclaringType().getClassName() + "." + sig.getDeclaringType().getClassName();
/*  736 */       if (name.contains("$")) {
/*  737 */         name = name.substring(name.indexOf("$") + 1);
/*      */       }
/*      */ 
/*      */       
/*  741 */       ProgramElement programElement = new ProgramElement(model, name, IProgramElement.Kind.INTER_TYPE_CONSTRUCTOR, getBinarySourceLocation(aspect, itd.getSourceLocation()), rtMunger.getSignature().getModifiers(), null, Collections.emptyList());
/*  742 */       setParams((IProgramElement)programElement, sig);
/*  743 */       return (IProgramElement)programElement;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  755 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void setParams(IProgramElement pe, ResolvedMember sig) {
/*  760 */     UnresolvedType[] ts = sig.getParameterTypes();
/*  761 */     pe.setParameterNames(Collections.emptyList());
/*      */     
/*  763 */     if (ts == null) {
/*  764 */       pe.setParameterSignatures(Collections.emptyList(), Collections.emptyList());
/*      */     } else {
/*  766 */       List<char[]> paramSigs = (List)new ArrayList<>();
/*  767 */       for (UnresolvedType t : ts) {
/*  768 */         paramSigs.add(t.getSignature().toCharArray());
/*      */       }
/*  770 */       pe.setParameterSignatures(paramSigs, Collections.emptyList());
/*      */     } 
/*  772 */     pe.setCorrespondingType(sig.getReturnType().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static IProgramElement createDeclareParentsChild(AsmManager model, DeclareParents decp) {
/*  778 */     ProgramElement programElement = new ProgramElement(model, "declare parents", IProgramElement.Kind.DECLARE_PARENTS, getBinarySourceLocation(decp.getDeclaringType(), decp.getSourceLocation()), 1, null, Collections.emptyList());
/*  779 */     setParentTypesOnDeclareParentsNode(decp, (IProgramElement)programElement);
/*  780 */     return (IProgramElement)programElement;
/*      */   }
/*      */   
/*      */   private static void setParentTypesOnDeclareParentsNode(DeclareParents decp, IProgramElement decpElement) {
/*  784 */     TypePatternList tpl = decp.getParents();
/*  785 */     List<String> parents = new ArrayList<>();
/*  786 */     for (int i = 0; i < tpl.size(); i++) {
/*  787 */       parents.add(tpl.get(i).getExactType().getName().replaceAll("\\$", "."));
/*      */     }
/*  789 */     decpElement.setParentTypes(parents);
/*      */   }
/*      */   
/*      */   public static String getHandle(AsmManager asm, Advice advice) {
/*  793 */     if (null == advice.handle) {
/*  794 */       ISourceLocation sl = advice.getSourceLocation();
/*  795 */       if (sl != null) {
/*  796 */         IProgramElement ipe = asm.getHierarchy().findElementForSourceLine(sl);
/*  797 */         advice.handle = ipe.getHandleIdentifier();
/*      */       } 
/*      */     } 
/*  800 */     return advice.handle;
/*      */   }
/*      */   
/*      */   public static void addAdvisedRelationship(AsmManager model, Shadow matchedShadow, ShadowMunger munger) {
/*  804 */     if (model == null) {
/*      */       return;
/*      */     }
/*      */     
/*  808 */     if (munger instanceof Advice) {
/*  809 */       Advice advice = (Advice)munger;
/*      */       
/*  811 */       if (advice.getKind().isPerEntry() || advice.getKind().isCflow()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  816 */       if (World.createInjarHierarchy) {
/*  817 */         createHierarchyForBinaryAspect(model, (ShadowMunger)advice);
/*      */       }
/*      */       
/*  820 */       IRelationshipMap mapper = model.getRelationshipMap();
/*  821 */       IProgramElement targetNode = getNode(model, matchedShadow);
/*  822 */       if (targetNode == null) {
/*      */         return;
/*      */       }
/*  825 */       boolean runtimeTest = advice.hasDynamicTests();
/*      */       
/*  827 */       IProgramElement.ExtraInformation extra = new IProgramElement.ExtraInformation();
/*      */       
/*  829 */       String adviceHandle = getHandle(model, advice);
/*  830 */       if (adviceHandle == null) {
/*      */         return;
/*      */       }
/*      */       
/*  834 */       extra.setExtraAdviceInformation(advice.getKind().getName());
/*  835 */       IProgramElement adviceElement = model.getHierarchy().findElementForHandle(adviceHandle);
/*  836 */       if (adviceElement != null) {
/*  837 */         adviceElement.setExtraInfo(extra);
/*      */       }
/*  839 */       String targetHandle = targetNode.getHandleIdentifier();
/*  840 */       if (advice.getKind().equals(AdviceKind.Softener)) {
/*  841 */         IRelationship foreward = mapper.get(adviceHandle, IRelationship.Kind.DECLARE_SOFT, "softens", runtimeTest, true);
/*  842 */         if (foreward != null) {
/*  843 */           foreward.addTarget(targetHandle);
/*      */         }
/*      */         
/*  846 */         IRelationship back = mapper.get(targetHandle, IRelationship.Kind.DECLARE, "softened by", runtimeTest, true);
/*  847 */         if (back != null) {
/*  848 */           back.addTarget(adviceHandle);
/*      */         }
/*      */       } else {
/*  851 */         IRelationship foreward = mapper.get(adviceHandle, IRelationship.Kind.ADVICE, "advises", runtimeTest, true);
/*  852 */         if (foreward != null) {
/*  853 */           foreward.addTarget(targetHandle);
/*      */         }
/*      */         
/*  856 */         IRelationship back = mapper.get(targetHandle, IRelationship.Kind.ADVICE, "advised by", runtimeTest, true);
/*  857 */         if (back != null) {
/*  858 */           back.addTarget(adviceHandle);
/*      */         }
/*      */       } 
/*  861 */       if (adviceElement.getSourceLocation() != null) {
/*  862 */         model.addAspectInEffectThisBuild(adviceElement.getSourceLocation().getSourceFile());
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected static IProgramElement getNode(AsmManager model, Shadow shadow) {
/*  868 */     Member enclosingMember = shadow.getEnclosingCodeSignature();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  885 */     IProgramElement enclosingNode = null;
/*  886 */     if (shadow instanceof BcelShadow) {
/*  887 */       Member actualEnclosingMember = ((BcelShadow)shadow).getRealEnclosingCodeSignature();
/*      */       
/*  889 */       if (actualEnclosingMember == null) {
/*  890 */         enclosingNode = lookupMember(model.getHierarchy(), shadow.getEnclosingType(), enclosingMember);
/*      */       } else {
/*  892 */         UnresolvedType type = enclosingMember.getDeclaringType();
/*  893 */         UnresolvedType actualType = actualEnclosingMember.getDeclaringType();
/*      */ 
/*      */ 
/*      */         
/*  897 */         if (type.equals(actualType)) {
/*  898 */           enclosingNode = lookupMember(model.getHierarchy(), shadow.getEnclosingType(), enclosingMember);
/*      */         } else {
/*  900 */           enclosingNode = lookupMember(model.getHierarchy(), shadow.getEnclosingType(), actualEnclosingMember);
/*      */         } 
/*      */       } 
/*      */     } else {
/*  904 */       enclosingNode = lookupMember(model.getHierarchy(), shadow.getEnclosingType(), enclosingMember);
/*      */     } 
/*      */     
/*  907 */     if (enclosingNode == null) {
/*  908 */       Lint.Kind err = (shadow.getIWorld().getLint()).shadowNotInStructure;
/*  909 */       if (err.isEnabled()) {
/*  910 */         err.signal(shadow.toString(), shadow.getSourceLocation());
/*      */       }
/*  912 */       return null;
/*      */     } 
/*      */     
/*  915 */     Member shadowSig = shadow.getSignature();
/*      */     
/*  917 */     if (shadow.getKind() == Shadow.MethodCall || shadow.getKind() == Shadow.ConstructorCall || 
/*  918 */       !shadowSig.equals(enclosingMember)) {
/*  919 */       IProgramElement bodyNode = findOrCreateCodeNode(model, enclosingNode, shadowSig, shadow);
/*  920 */       return bodyNode;
/*      */     } 
/*  922 */     return enclosingNode;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean sourceLinesMatch(ISourceLocation location1, ISourceLocation location2) {
/*  927 */     return (location1.getLine() == location2.getLine());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IProgramElement findOrCreateCodeNode(AsmManager asm, IProgramElement enclosingNode, Member shadowSig, Shadow shadow) {
/*  944 */     for (IProgramElement node : enclosingNode.getChildren()) {
/*  945 */       int excl = node.getBytecodeName().lastIndexOf('!');
/*  946 */       if (((excl != -1 && shadowSig.getName().equals(node.getBytecodeName().substring(0, excl))) || shadowSig.getName()
/*  947 */         .equals(node.getBytecodeName())) && shadowSig
/*  948 */         .getSignature().equals(node.getBytecodeSignature()) && 
/*  949 */         sourceLinesMatch(node.getSourceLocation(), shadow.getSourceLocation())) {
/*  950 */         return node;
/*      */       }
/*      */     } 
/*      */     
/*  954 */     ISourceLocation sl = shadow.getSourceLocation();
/*      */ 
/*      */ 
/*      */     
/*  958 */     SourceLocation peLoc = new SourceLocation(enclosingNode.getSourceLocation().getSourceFile(), sl.getLine());
/*  959 */     peLoc.setOffset(sl.getOffset());
/*  960 */     ProgramElement programElement = new ProgramElement(asm, shadow.toString(), IProgramElement.Kind.CODE, (ISourceLocation)peLoc, 0, null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  966 */     int numberOfChildrenWithThisName = 0;
/*  967 */     for (IProgramElement child : enclosingNode.getChildren()) {
/*  968 */       if (child.getName().equals(shadow.toString())) {
/*  969 */         numberOfChildrenWithThisName++;
/*      */       }
/*      */     } 
/*  972 */     programElement.setBytecodeName(shadowSig.getName() + "!" + String.valueOf(numberOfChildrenWithThisName + 1));
/*  973 */     programElement.setBytecodeSignature(shadowSig.getSignature());
/*  974 */     enclosingNode.addChild((IProgramElement)programElement);
/*  975 */     return (IProgramElement)programElement;
/*      */   }
/*      */   
/*      */   private static IProgramElement lookupMember(IHierarchy model, UnresolvedType declaringType, Member member) {
/*  979 */     IProgramElement typeElement = model.findElementForType(declaringType.getPackageName(), declaringType.getClassName());
/*  980 */     if (typeElement == null) {
/*  981 */       return null;
/*      */     }
/*  983 */     for (IProgramElement element : typeElement.getChildren()) {
/*  984 */       if (member.getName().equals(element.getBytecodeName()) && member.getSignature().equals(element.getBytecodeSignature())) {
/*  985 */         return element;
/*      */       }
/*      */     } 
/*      */     
/*  989 */     return typeElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addDeclareAnnotationMethodRelationship(ISourceLocation sourceLocation, String affectedTypeName, ResolvedMember affectedMethod, AsmManager model) {
/*  998 */     if (model == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1002 */     String pkg = null;
/* 1003 */     String type = affectedTypeName;
/* 1004 */     int packageSeparator = affectedTypeName.lastIndexOf(".");
/* 1005 */     if (packageSeparator != -1) {
/* 1006 */       pkg = affectedTypeName.substring(0, packageSeparator);
/* 1007 */       type = affectedTypeName.substring(packageSeparator + 1);
/*      */     } 
/*      */     
/* 1010 */     IHierarchy hierarchy = model.getHierarchy();
/*      */     
/* 1012 */     IProgramElement typeElem = hierarchy.findElementForType(pkg, type);
/* 1013 */     if (typeElem == null) {
/*      */       return;
/*      */     }
/* 1016 */     if (!typeElem.getKind().isType()) {
/* 1017 */       throw new IllegalStateException("Did not find a type element, found a " + typeElem.getKind() + " element");
/*      */     }
/*      */     
/* 1020 */     StringBuilder parmString = new StringBuilder("(");
/* 1021 */     UnresolvedType[] args = affectedMethod.getParameterTypes();
/* 1022 */     for (int i = 0; i < args.length; i++) {
/* 1023 */       parmString.append(args[i].getName());
/* 1024 */       if (i + 1 < args.length) {
/* 1025 */         parmString.append(",");
/*      */       }
/*      */     } 
/* 1028 */     parmString.append(")");
/* 1029 */     IProgramElement methodElem = null;
/*      */     
/* 1031 */     if (affectedMethod.getName().startsWith("<init>")) {
/*      */       
/* 1033 */       methodElem = hierarchy.findElementForSignature(typeElem, IProgramElement.Kind.CONSTRUCTOR, type + parmString);
/* 1034 */       if (methodElem == null && args.length == 0) {
/* 1035 */         methodElem = typeElem;
/*      */       }
/*      */     } else {
/*      */       
/* 1039 */       methodElem = hierarchy.findElementForSignature(typeElem, IProgramElement.Kind.METHOD, affectedMethod.getName() + parmString);
/*      */     } 
/*      */ 
/*      */     
/* 1043 */     if (methodElem == null) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/* 1048 */       String targetHandle = methodElem.getHandleIdentifier();
/* 1049 */       if (targetHandle == null) {
/*      */         return;
/*      */       }
/*      */       
/* 1053 */       IProgramElement sourceNode = hierarchy.findElementForSourceLine(sourceLocation);
/* 1054 */       String sourceHandle = sourceNode.getHandleIdentifier();
/* 1055 */       if (sourceHandle == null) {
/*      */         return;
/*      */       }
/*      */       
/* 1059 */       IRelationshipMap mapper = model.getRelationshipMap();
/* 1060 */       IRelationship foreward = mapper.get(sourceHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "annotates", false, true);
/* 1061 */       foreward.addTarget(targetHandle);
/*      */       
/* 1063 */       IRelationship back = mapper.get(targetHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "annotated by", false, true);
/* 1064 */       back.addTarget(sourceHandle);
/* 1065 */     } catch (Throwable t) {
/*      */       
/* 1067 */       t.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addDeclareAnnotationFieldRelationship(AsmManager model, ISourceLocation declareLocation, String affectedTypeName, ResolvedMember affectedFieldName, boolean isRemove) {
/* 1078 */     if (model == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1082 */     String pkg = null;
/* 1083 */     String type = affectedTypeName;
/* 1084 */     int packageSeparator = affectedTypeName.lastIndexOf(".");
/* 1085 */     if (packageSeparator != -1) {
/* 1086 */       pkg = affectedTypeName.substring(0, packageSeparator);
/* 1087 */       type = affectedTypeName.substring(packageSeparator + 1);
/*      */     } 
/* 1089 */     IHierarchy hierarchy = model.getHierarchy();
/* 1090 */     IProgramElement typeElem = hierarchy.findElementForType(pkg, type);
/* 1091 */     if (typeElem == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1095 */     IProgramElement fieldElem = hierarchy.findElementForSignature(typeElem, IProgramElement.Kind.FIELD, affectedFieldName
/* 1096 */         .getName());
/* 1097 */     if (fieldElem == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1101 */     String targetHandle = fieldElem.getHandleIdentifier();
/* 1102 */     if (targetHandle == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1106 */     IProgramElement sourceNode = hierarchy.findElementForSourceLine(declareLocation);
/* 1107 */     String sourceHandle = sourceNode.getHandleIdentifier();
/* 1108 */     if (sourceHandle == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1112 */     IRelationshipMap relmap = model.getRelationshipMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1121 */     IRelationship foreward = relmap.get(sourceHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "annotates", false, true);
/* 1122 */     foreward.addTarget(targetHandle);
/* 1123 */     IRelationship back = relmap.get(targetHandle, IRelationship.Kind.DECLARE_INTER_TYPE, "annotated by", false, true);
/* 1124 */     back.addTarget(sourceHandle);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\weaver\model\AsmRelationshipProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */