/*     */ package org.aspectj.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericSignature
/*     */ {
/*     */   public static class ClassSignature
/*     */   {
/*  25 */     public GenericSignature.FormalTypeParameter[] formalTypeParameters = GenericSignature.FormalTypeParameter.NONE;
/*     */     public GenericSignature.ClassTypeSignature superclassSignature;
/*  27 */     public GenericSignature.ClassTypeSignature[] superInterfaceSignatures = GenericSignature.ClassTypeSignature.NONE;
/*     */     
/*     */     public String toString() {
/*  30 */       StringBuilder ret = new StringBuilder();
/*  31 */       ret.append(this.formalTypeParameters.toString());
/*  32 */       ret.append(this.superclassSignature.toString());
/*  33 */       for (GenericSignature.ClassTypeSignature superInterfaceSignature : this.superInterfaceSignatures) {
/*  34 */         ret.append(superInterfaceSignature.toString());
/*     */       }
/*  36 */       return ret.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MethodTypeSignature {
/*  41 */     public GenericSignature.FormalTypeParameter[] formalTypeParameters = GenericSignature.FormalTypeParameter.NONE;
/*  42 */     public GenericSignature.TypeSignature[] parameters = new GenericSignature.TypeSignature[0];
/*     */     public GenericSignature.TypeSignature returnType;
/*  44 */     public GenericSignature.FieldTypeSignature[] throwsSignatures = new GenericSignature.FieldTypeSignature[0];
/*     */ 
/*     */     
/*     */     public MethodTypeSignature(GenericSignature.FormalTypeParameter[] aFormalParameterList, GenericSignature.TypeSignature[] aParameterList, GenericSignature.TypeSignature aReturnType, GenericSignature.FieldTypeSignature[] aThrowsSignatureList) {
/*  48 */       this.formalTypeParameters = aFormalParameterList;
/*  49 */       this.parameters = aParameterList;
/*  50 */       this.returnType = aReturnType;
/*  51 */       this.throwsSignatures = aThrowsSignatureList;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  55 */       StringBuilder sb = new StringBuilder();
/*  56 */       if (this.formalTypeParameters.length > 0) {
/*  57 */         sb.append("<");
/*  58 */         for (GenericSignature.FormalTypeParameter formalTypeParameter : this.formalTypeParameters) {
/*  59 */           sb.append(formalTypeParameter.toString());
/*     */         }
/*  61 */         sb.append(">");
/*     */       } 
/*  63 */       sb.append("(");
/*  64 */       for (GenericSignature.TypeSignature parameter : this.parameters) {
/*  65 */         sb.append(parameter.toString());
/*     */       }
/*  67 */       sb.append(")");
/*  68 */       sb.append(this.returnType.toString());
/*  69 */       for (GenericSignature.FieldTypeSignature throwsSignature : this.throwsSignatures) {
/*  70 */         sb.append("^");
/*  71 */         sb.append(throwsSignature.toString());
/*     */       } 
/*  73 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FormalTypeParameter
/*     */   {
/*  81 */     public static final FormalTypeParameter[] NONE = new FormalTypeParameter[0];
/*     */     public String identifier;
/*     */     public GenericSignature.FieldTypeSignature classBound;
/*     */     public GenericSignature.FieldTypeSignature[] interfaceBounds;
/*     */     
/*     */     public String toString() {
/*  87 */       StringBuilder ret = new StringBuilder();
/*  88 */       ret.append("T");
/*  89 */       ret.append(this.identifier);
/*  90 */       ret.append(":");
/*  91 */       ret.append(this.classBound.toString());
/*  92 */       for (GenericSignature.FieldTypeSignature interfaceBound : this.interfaceBounds) {
/*  93 */         ret.append(":");
/*  94 */         ret.append(interfaceBound.toString());
/*     */       } 
/*  96 */       return ret.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class TypeSignature {
/*     */     public boolean isBaseType() {
/* 102 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BaseTypeSignature extends TypeSignature {
/*     */     private final String sig;
/*     */     
/*     */     public BaseTypeSignature(String aPrimitiveType) {
/* 110 */       this.sig = aPrimitiveType;
/*     */     }
/*     */     
/*     */     public boolean isBaseType() {
/* 114 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 118 */       return this.sig;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class FieldTypeSignature extends TypeSignature {
/*     */     public boolean isClassTypeSignature() {
/* 124 */       return false;
/*     */     }
/*     */     
/*     */     public boolean isTypeVariableSignature() {
/* 128 */       return false;
/*     */     }
/*     */     
/*     */     public boolean isArrayTypeSignature() {
/* 132 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ClassTypeSignature
/*     */     extends FieldTypeSignature {
/* 138 */     public static final ClassTypeSignature[] NONE = new ClassTypeSignature[0];
/*     */     public String classSignature;
/*     */     public GenericSignature.SimpleClassTypeSignature outerType;
/*     */     public GenericSignature.SimpleClassTypeSignature[] nestedTypes;
/*     */     
/*     */     public ClassTypeSignature(String sig, String identifier) {
/* 144 */       this.classSignature = sig;
/* 145 */       this.outerType = new GenericSignature.SimpleClassTypeSignature(identifier);
/* 146 */       this.nestedTypes = new GenericSignature.SimpleClassTypeSignature[0];
/*     */     }
/*     */     
/*     */     public ClassTypeSignature(String sig, GenericSignature.SimpleClassTypeSignature outer, GenericSignature.SimpleClassTypeSignature[] inners) {
/* 150 */       this.classSignature = sig;
/* 151 */       this.outerType = outer;
/* 152 */       this.nestedTypes = inners;
/*     */     }
/*     */     
/*     */     public boolean isClassTypeSignature() {
/* 156 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 160 */       return this.classSignature;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TypeVariableSignature extends FieldTypeSignature {
/*     */     public String typeVariableName;
/*     */     
/*     */     public TypeVariableSignature(String typeVarToken) {
/* 168 */       this.typeVariableName = typeVarToken.substring(1);
/*     */     }
/*     */     
/*     */     public boolean isTypeVariableSignature() {
/* 172 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 176 */       return "T" + this.typeVariableName + ";";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayTypeSignature extends FieldTypeSignature {
/*     */     public GenericSignature.TypeSignature typeSig;
/*     */     
/*     */     public ArrayTypeSignature(GenericSignature.TypeSignature aTypeSig) {
/* 184 */       this.typeSig = aTypeSig;
/*     */     }
/*     */     
/*     */     public boolean isArrayTypeSignature() {
/* 188 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 192 */       return "[" + this.typeSig.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SimpleClassTypeSignature {
/*     */     public String identifier;
/*     */     public GenericSignature.TypeArgument[] typeArguments;
/*     */     
/*     */     public SimpleClassTypeSignature(String identifier) {
/* 201 */       this.identifier = identifier;
/* 202 */       this.typeArguments = new GenericSignature.TypeArgument[0];
/*     */     }
/*     */     
/*     */     public SimpleClassTypeSignature(String identifier, GenericSignature.TypeArgument[] args) {
/* 206 */       this.identifier = identifier;
/* 207 */       this.typeArguments = args;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 211 */       StringBuilder sb = new StringBuilder();
/* 212 */       sb.append(this.identifier);
/* 213 */       if (this.typeArguments.length > 0) {
/* 214 */         sb.append("<");
/* 215 */         for (GenericSignature.TypeArgument typeArgument : this.typeArguments) {
/* 216 */           sb.append(typeArgument.toString());
/*     */         }
/* 218 */         sb.append(">");
/*     */       } 
/* 220 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TypeArgument {
/*     */     public boolean isWildcard = false;
/*     */     public boolean isPlus = false;
/*     */     public boolean isMinus = false;
/*     */     public GenericSignature.FieldTypeSignature signature;
/*     */     
/*     */     public TypeArgument() {
/* 231 */       this.isWildcard = true;
/*     */     }
/*     */     
/*     */     public TypeArgument(boolean plus, boolean minus, GenericSignature.FieldTypeSignature aSig) {
/* 235 */       this.isPlus = plus;
/* 236 */       this.isMinus = minus;
/* 237 */       this.signature = aSig;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 241 */       if (this.isWildcard)
/* 242 */         return "*"; 
/* 243 */       StringBuilder sb = new StringBuilder();
/* 244 */       if (this.isPlus)
/* 245 */         sb.append("+"); 
/* 246 */       if (this.isMinus)
/* 247 */         sb.append("-"); 
/* 248 */       sb.append(this.signature.toString());
/* 249 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\GenericSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */