/*     */ package org.aspectj.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FuzzyBoolean
/*     */ {
/*     */   private static class YesFuzzyBoolean
/*     */     extends FuzzyBoolean
/*     */   {
/*     */     private YesFuzzyBoolean() {}
/*     */     
/*     */     public boolean alwaysFalse() {
/*  30 */       return false;
/*     */     }
/*     */     
/*     */     public boolean alwaysTrue() {
/*  34 */       return true;
/*     */     }
/*     */     
/*     */     public boolean maybeFalse() {
/*  38 */       return false;
/*     */     }
/*     */     
/*     */     public boolean maybeTrue() {
/*  42 */       return true;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean and(FuzzyBoolean other) {
/*  46 */       return other;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean not() {
/*  50 */       return FuzzyBoolean.NO;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean or(FuzzyBoolean other) {
/*  54 */       return this;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  58 */       return "YES";
/*     */     } }
/*     */   
/*     */   private static class NoFuzzyBoolean extends FuzzyBoolean {
/*     */     public boolean alwaysFalse() {
/*  63 */       return true;
/*     */     }
/*     */     private NoFuzzyBoolean() {}
/*     */     public boolean alwaysTrue() {
/*  67 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean maybeFalse() {
/*  72 */       return true;
/*     */     }
/*     */     
/*     */     public boolean maybeTrue() {
/*  76 */       return false;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean and(FuzzyBoolean other) {
/*  80 */       return this;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean not() {
/*  84 */       return FuzzyBoolean.YES;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean or(FuzzyBoolean other) {
/*  88 */       return other;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  92 */       return "NO";
/*     */     } }
/*     */   private static class NeverFuzzyBoolean extends FuzzyBoolean { private NeverFuzzyBoolean() {}
/*     */     
/*     */     public boolean alwaysFalse() {
/*  97 */       return true;
/*     */     }
/*     */     
/*     */     public boolean alwaysTrue() {
/* 101 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean maybeFalse() {
/* 106 */       return true;
/*     */     }
/*     */     
/*     */     public boolean maybeTrue() {
/* 110 */       return false;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean and(FuzzyBoolean other) {
/* 114 */       return this;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean not() {
/* 118 */       return this;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean or(FuzzyBoolean other) {
/* 122 */       return this;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 126 */       return "NEVER";
/*     */     } }
/*     */   
/*     */   private static class MaybeFuzzyBoolean extends FuzzyBoolean { private MaybeFuzzyBoolean() {}
/*     */     
/*     */     public boolean alwaysFalse() {
/* 132 */       return false;
/*     */     }
/*     */     
/*     */     public boolean alwaysTrue() {
/* 136 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean maybeFalse() {
/* 141 */       return true;
/*     */     }
/*     */     
/*     */     public boolean maybeTrue() {
/* 145 */       return true;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean and(FuzzyBoolean other) {
/* 149 */       return other.alwaysFalse() ? other : this;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean not() {
/* 153 */       return this;
/*     */     }
/*     */     
/*     */     public FuzzyBoolean or(FuzzyBoolean other) {
/* 157 */       return other.alwaysTrue() ? other : this;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 161 */       return "MAYBE";
/*     */     } }
/*     */ 
/*     */   
/* 165 */   public static final FuzzyBoolean YES = new YesFuzzyBoolean();
/* 166 */   public static final FuzzyBoolean NO = new NoFuzzyBoolean();
/* 167 */   public static final FuzzyBoolean MAYBE = new MaybeFuzzyBoolean();
/* 168 */   public static final FuzzyBoolean NEVER = new NeverFuzzyBoolean();
/*     */   public abstract boolean alwaysTrue();
/*     */   public static final FuzzyBoolean fromBoolean(boolean b) {
/* 171 */     return b ? YES : NO;
/*     */   }
/*     */   
/*     */   public abstract boolean alwaysFalse();
/*     */   
/*     */   public abstract boolean maybeTrue();
/*     */   
/*     */   public abstract boolean maybeFalse();
/*     */   
/*     */   public abstract FuzzyBoolean and(FuzzyBoolean paramFuzzyBoolean);
/*     */   
/*     */   public abstract FuzzyBoolean or(FuzzyBoolean paramFuzzyBoolean);
/*     */   
/*     */   public abstract FuzzyBoolean not();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\FuzzyBoolean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */