/*     */ package org.aspectj.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartialOrder
/*     */ {
/*     */   private static class SortObject<T extends PartialComparable>
/*     */   {
/*     */     T object;
/*  54 */     List<SortObject<T>> smallerObjects = new LinkedList<>();
/*  55 */     List<SortObject<T>> biggerObjects = new LinkedList<>();
/*     */     
/*     */     public SortObject(T o) {
/*  58 */       this.object = o;
/*     */     }
/*     */     
/*     */     boolean hasNoSmallerObjects() {
/*  62 */       return (this.smallerObjects.size() == 0);
/*     */     }
/*     */     
/*     */     boolean removeSmallerObject(SortObject<T> o) {
/*  66 */       this.smallerObjects.remove(o);
/*  67 */       return hasNoSmallerObjects();
/*     */     }
/*     */     
/*     */     void addDirectedLinks(SortObject<T> other) {
/*  71 */       int cmp = this.object.compareTo(other.object);
/*  72 */       if (cmp == 0) {
/*     */         return;
/*     */       }
/*  75 */       if (cmp > 0) {
/*  76 */         this.smallerObjects.add(other);
/*  77 */         other.biggerObjects.add(this);
/*     */       } else {
/*  79 */         this.biggerObjects.add(other);
/*  80 */         other.smallerObjects.add(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public String toString() {
/*  85 */       return this.object.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T extends PartialComparable> void addNewPartialComparable(List<SortObject<T>> graph, T o) {
/*  90 */     SortObject<T> so = new SortObject<>(o);
/*  91 */     for (SortObject<T> other : graph) {
/*  92 */       so.addDirectedLinks(other);
/*     */     }
/*  94 */     graph.add(so);
/*     */   }
/*     */   
/*     */   private static <T extends PartialComparable> void removeFromGraph(List<SortObject<T>> graph, SortObject<T> o) {
/*  98 */     for (Iterator<SortObject<T>> i = graph.iterator(); i.hasNext(); ) {
/*  99 */       SortObject<T> other = i.next();
/*     */       
/* 101 */       if (o == other) {
/* 102 */         i.remove();
/*     */       }
/*     */ 
/*     */       
/* 106 */       other.removeSmallerObject(o);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends PartialComparable> List<T> sort(List<T> objects) {
/* 118 */     if (objects.size() < 2) {
/* 119 */       return objects;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     List<SortObject<T>> sortList = new LinkedList<>();
/* 127 */     for (PartialComparable partialComparable : objects) {
/* 128 */       addNewPartialComparable(sortList, (T)partialComparable);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     int N = objects.size();
/* 138 */     for (int index = 0; index < N; index++) {
/*     */ 
/*     */ 
/*     */       
/* 142 */       SortObject<T> leastWithNoSmallers = null;
/*     */       
/* 144 */       for (SortObject<T> so : sortList) {
/* 145 */         if (so.hasNoSmallerObjects() && (
/* 146 */           leastWithNoSmallers == null || so.object.fallbackCompareTo(leastWithNoSmallers.object) < 0)) {
/* 147 */           leastWithNoSmallers = so;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 152 */       if (leastWithNoSmallers == null) {
/* 153 */         return null;
/*     */       }
/*     */       
/* 156 */       removeFromGraph(sortList, leastWithNoSmallers);
/* 157 */       objects.set(index, leastWithNoSmallers.object);
/*     */     } 
/*     */     
/* 160 */     return objects;
/*     */   }
/*     */   
/*     */   public static interface PartialComparable {
/*     */     int compareTo(Object param1Object);
/*     */     
/*     */     int fallbackCompareTo(Object param1Object); }
/*     */   
/*     */   static class Token implements PartialComparable {
/*     */     Token(String s) {
/* 170 */       this.s = s;
/*     */     }
/*     */     private String s;
/*     */     public int compareTo(Object other) {
/* 174 */       Token t = (Token)other;
/*     */       
/* 176 */       int cmp = this.s.charAt(0) - t.s.charAt(0);
/* 177 */       if (cmp == 1) {
/* 178 */         return 1;
/*     */       }
/* 180 */       if (cmp == -1) {
/* 181 */         return -1;
/*     */       }
/* 183 */       return 0;
/*     */     }
/*     */     
/*     */     public int fallbackCompareTo(Object other) {
/* 187 */       return -this.s.compareTo(((Token)other).s);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 191 */       return this.s;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 196 */     List<Token> l = new ArrayList<>();
/* 197 */     l.add(new Token("a1"));
/* 198 */     l.add(new Token("c2"));
/* 199 */     l.add(new Token("b3"));
/* 200 */     l.add(new Token("f4"));
/* 201 */     l.add(new Token("e5"));
/* 202 */     l.add(new Token("d6"));
/* 203 */     l.add(new Token("c7"));
/* 204 */     l.add(new Token("b8"));
/*     */     
/* 206 */     l.add(new Token("z"));
/* 207 */     l.add(new Token("x"));
/*     */     
/* 209 */     l.add(new Token("f9"));
/* 210 */     l.add(new Token("e10"));
/* 211 */     l.add(new Token("a11"));
/* 212 */     l.add(new Token("d12"));
/* 213 */     l.add(new Token("b13"));
/* 214 */     l.add(new Token("c14"));
/*     */     
/* 216 */     System.out.println(l);
/*     */     
/* 218 */     sort(l);
/*     */     
/* 220 */     System.out.println(l);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\PartialOrder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */