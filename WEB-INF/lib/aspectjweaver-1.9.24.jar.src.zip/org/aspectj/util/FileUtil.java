/*      */ package org.aspectj.util;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileReader;
/*      */ import java.io.FileWriter;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.Writer;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.NoSuchFileException;
/*      */ import java.nio.file.Paths;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FileUtil
/*      */ {
/*   56 */   public static final File DEFAULT_PARENT = new File(".");
/*      */ 
/*      */   
/*   59 */   public static final List<String> SOURCE_SUFFIXES = Collections.unmodifiableList(Arrays.asList(new String[] { ".java", ".aj" }));
/*      */   
/*   61 */   public static final FileFilter ZIP_FILTER = new FileFilter() {
/*      */       public boolean accept(File file) {
/*   63 */         return FileUtil.isZipFile(file);
/*      */       }
/*      */       
/*      */       public String toString() {
/*   67 */         return "ZIP_FILTER";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   static final int[] INT_RA = new int[0];
/*      */ 
/*      */   
/*   84 */   public static final FileFilter ALL = new FileFilter() {
/*      */       public boolean accept(File f) {
/*   86 */         return true;
/*      */       }
/*      */     };
/*   89 */   public static final FileFilter DIRS_AND_WRITABLE_CLASSES = new FileFilter() {
/*      */       public boolean accept(File file) {
/*   91 */         return (null != file && (file.isDirectory() || (file.canWrite() && file.getName().toLowerCase().endsWith(".class"))));
/*      */       }
/*      */     };
/*      */   private static final boolean PERMIT_CVS;
/*      */   static {
/*   96 */     String name = FileUtil.class.getName() + ".PERMIT_CVS";
/*   97 */     PERMIT_CVS = LangUtil.getBoolean(name, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isZipFile(File file) {
/*  102 */     if (file == null)
/*  103 */       return false;  
/*  104 */     try { ZipFile zipFile = new ZipFile(file); 
/*  105 */       try { boolean bool = true;
/*  106 */         zipFile.close(); return bool; } catch (Throwable throwable) { try { zipFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/*  107 */     { return false; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int zipSuffixLength(File file) {
/*  117 */     return (null == file) ? 0 : zipSuffixLength(file.getPath());
/*      */   }
/*      */ 
/*      */   
/*      */   public static int zipSuffixLength(String path) {
/*  122 */     if (null != path && 4 < path.length()) {
/*  123 */       String test = path.substring(path.length() - 4).toLowerCase();
/*  124 */       if (".zip".equals(test) || ".jar".equals(test)) {
/*  125 */         return 4;
/*      */       }
/*      */     } 
/*  128 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean hasSourceSuffix(File file) {
/*  133 */     return (null != file && hasSourceSuffix(file.getPath()));
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean hasSourceSuffix(String path) {
/*  138 */     return (null != path && 0 != sourceSuffixLength(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int sourceSuffixLength(File file) {
/*  145 */     return (null == file) ? 0 : sourceSuffixLength(file.getPath());
/*      */   }
/*      */ 
/*      */   
/*      */   public static int sourceSuffixLength(String path) {
/*  150 */     if (LangUtil.isEmpty(path)) {
/*  151 */       return 0;
/*      */     }
/*      */     
/*  154 */     for (String suffix : SOURCE_SUFFIXES) {
/*  155 */       if (path.endsWith(suffix) || path.toLowerCase().endsWith(suffix)) {
/*  156 */         return suffix.length();
/*      */       }
/*      */     } 
/*  159 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean canReadDir(File dir) {
/*  164 */     return (null != dir && dir.canRead() && dir.isDirectory());
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean canReadFile(File file) {
/*  169 */     return (null != file && file.canRead() && file.isFile());
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean canWriteDir(File dir) {
/*  174 */     return (null != dir && dir.canWrite() && dir.isDirectory());
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean canWriteFile(File file) {
/*  179 */     return (null != file && file.canWrite() && file.isFile());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwIaxUnlessCanReadDir(File dir, String label) {
/*  197 */     if (!canReadDir(dir)) {
/*  198 */       throw new IllegalArgumentException(label + " not readable dir: " + dir);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwIaxUnlessCanWriteFile(File file, String label) {
/*  206 */     if (!canWriteFile(file)) {
/*  207 */       throw new IllegalArgumentException(label + " not writable file: " + file);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void throwIaxUnlessCanWriteDir(File dir, String label) {
/*  213 */     if (!canWriteDir(dir)) {
/*  214 */       throw new IllegalArgumentException(label + " not writable dir: " + dir);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static String[] getPaths(File[] files) {
/*  220 */     if (null == files || 0 == files.length) {
/*  221 */       return new String[0];
/*      */     }
/*  223 */     String[] result = new String[files.length];
/*  224 */     for (int i = 0; i < result.length; i++) {
/*  225 */       if (null != files[i]) {
/*  226 */         result[i] = files[i].getPath();
/*      */       }
/*      */     } 
/*  229 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String[] getPaths(List<File> files) {
/*  234 */     int size = (null == files) ? 0 : files.size();
/*  235 */     if (0 == size) {
/*  236 */       return new String[0];
/*      */     }
/*  238 */     String[] result = new String[size];
/*  239 */     for (int i = 0; i < size; i++) {
/*  240 */       File file = files.get(i);
/*  241 */       if (null != file) {
/*  242 */         result[i] = file.getPath();
/*      */       }
/*      */     } 
/*  245 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String fileToClassName(File basedir, File classFile) {
/*  258 */     LangUtil.throwIaxIfNull(classFile, "classFile");
/*  259 */     String classFilePath = normalizedPath(classFile);
/*  260 */     if (!classFilePath.endsWith(".class")) {
/*  261 */       String m = classFile + " does not end with .class";
/*  262 */       throw new IllegalArgumentException(m);
/*      */     } 
/*  264 */     classFilePath = classFilePath.substring(0, classFilePath.length() - 6);
/*  265 */     if (null != basedir) {
/*  266 */       String basePath = normalizedPath(basedir);
/*  267 */       if (!classFilePath.startsWith(basePath)) {
/*  268 */         String m = classFile + " does not start with " + basedir;
/*  269 */         throw new IllegalArgumentException(m);
/*      */       } 
/*  271 */       classFilePath = classFilePath.substring(basePath.length() + 1);
/*      */     } else {
/*  273 */       String[] suffixes = { "com", "org", "java", "javax" };
/*  274 */       boolean found = false;
/*  275 */       for (int i = 0; !found && i < suffixes.length; i++) {
/*  276 */         int loc = classFilePath.indexOf(suffixes[i] + "/");
/*  277 */         if (0 == loc || (-1 != loc && '/' == classFilePath.charAt(loc - 1))) {
/*  278 */           classFilePath = classFilePath.substring(loc);
/*  279 */           found = true;
/*      */         } 
/*      */       } 
/*  282 */       if (!found) {
/*  283 */         int loc = classFilePath.lastIndexOf("/");
/*  284 */         if (-1 != loc) {
/*  285 */           classFilePath = classFilePath.substring(loc + 1);
/*      */         }
/*      */       } 
/*      */     } 
/*  289 */     return classFilePath.replace('/', '.');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String normalizedPath(File file, File basedir) {
/*  301 */     String filePath = normalizedPath(file);
/*  302 */     if (null != basedir) {
/*  303 */       String basePath = normalizedPath(basedir);
/*  304 */       if (filePath.startsWith(basePath)) {
/*  305 */         filePath = filePath.substring(basePath.length());
/*  306 */         if (filePath.startsWith("/")) {
/*  307 */           filePath = filePath.substring(1);
/*      */         }
/*      */       } 
/*      */     } 
/*  311 */     return filePath;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String flatten(File[] files, String infix) {
/*  323 */     if (LangUtil.isEmpty((Object[])files)) {
/*  324 */       return "";
/*      */     }
/*  326 */     return flatten(getPaths(files), infix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String flatten(String[] paths, String infix) {
/*  336 */     if (null == infix) {
/*  337 */       infix = File.pathSeparator;
/*      */     }
/*  339 */     StringBuilder result = new StringBuilder();
/*  340 */     boolean first = true;
/*  341 */     for (String path : paths) {
/*  342 */       if (null != path) {
/*      */ 
/*      */         
/*  345 */         if (first) {
/*  346 */           first = false;
/*      */         } else {
/*      */           
/*  349 */           result.append(infix);
/*      */         } 
/*  351 */         result.append(path);
/*      */       } 
/*  353 */     }  return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String normalizedPath(File file) {
/*  362 */     return (null == file) ? "" : weakNormalize(file.getAbsolutePath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String weakNormalize(String path) {
/*  369 */     if (null != path) {
/*  370 */       path = path.replace('\\', '/').trim();
/*      */     }
/*  372 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getBestFile(String[] paths) {
/*  383 */     if (null == paths) {
/*  384 */       return null;
/*      */     }
/*  386 */     File result = null;
/*  387 */     for (int i = 0; null == result && i < paths.length; i++) {
/*  388 */       String path = paths[i];
/*  389 */       if (null == path) {
/*      */         continue;
/*      */       }
/*  392 */       if (path.startsWith("sp:")) {
/*      */         try {
/*  394 */           path = System.getProperty(path.substring(3));
/*  395 */         } catch (Throwable t) {
/*  396 */           path = null;
/*      */         } 
/*  398 */         if (null == path) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */       try {
/*  403 */         File f = new File(path);
/*  404 */         if (f.exists() && f.canRead()) {
/*  405 */           result = getBestFile(f);
/*      */         }
/*  407 */       } catch (Throwable throwable) {}
/*      */       
/*      */       continue;
/*      */     } 
/*  411 */     return result;
/*      */   }
/*      */   
/*      */   public static File getBestFile(String[] paths, boolean mustBeJar) {
/*  415 */     if (null == paths) {
/*  416 */       return null;
/*      */     }
/*  418 */     File result = null;
/*  419 */     for (int i = 0; null == result && i < paths.length; i++) {
/*  420 */       String path = paths[i];
/*  421 */       if (null == path) {
/*      */         continue;
/*      */       }
/*  424 */       if (path.startsWith("sp:")) {
/*      */         try {
/*  426 */           path = System.getProperty(path.substring(3));
/*  427 */         } catch (Throwable t) {
/*  428 */           path = null;
/*      */         } 
/*  430 */         if (null == path) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */       try {
/*  435 */         File f = new File(path);
/*      */         
/*  437 */         if (f.exists() && f.canRead() && 
/*  438 */           mustBeJar && !f.isDirectory()) {
/*  439 */           result = getBestFile(f);
/*      */         }
/*      */       }
/*  442 */       catch (Throwable throwable) {}
/*      */       
/*      */       continue;
/*      */     } 
/*  446 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getBestFile(File file) {
/*  457 */     LangUtil.throwIaxIfNull(file, "file");
/*  458 */     if (file.exists()) {
/*      */       try {
/*  460 */         return file.getCanonicalFile();
/*  461 */       } catch (IOException e) {
/*  462 */         return file.getAbsoluteFile();
/*      */       } 
/*      */     }
/*  465 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getBestPath(File file) {
/*  477 */     LangUtil.throwIaxIfNull(file, "file");
/*  478 */     if (file.exists()) {
/*      */       try {
/*  480 */         return file.getCanonicalPath();
/*  481 */       } catch (IOException e) {
/*  482 */         return file.getAbsolutePath();
/*      */       } 
/*      */     }
/*  485 */     return file.getPath();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getAbsolutePaths(File[] files) {
/*  491 */     if (null == files || 0 == files.length) {
/*  492 */       return new String[0];
/*      */     }
/*  494 */     String[] result = new String[files.length];
/*  495 */     for (int i = 0; i < result.length; i++) {
/*  496 */       if (null != files[i]) {
/*  497 */         result[i] = files[i].getAbsolutePath();
/*      */       }
/*      */     } 
/*  500 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int deleteContents(File dir) {
/*  509 */     return deleteContents(dir, ALL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int deleteContents(File dir, FileFilter filter) {
/*  519 */     return deleteContents(dir, filter, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int deleteContents(File dir, FileFilter filter, boolean deleteEmptyDirs) {
/*  531 */     if (null == dir) {
/*  532 */       throw new IllegalArgumentException("null dir");
/*      */     }
/*  534 */     if (!dir.exists() || !dir.canWrite()) {
/*  535 */       return 0;
/*      */     }
/*  537 */     if (!dir.isDirectory()) {
/*  538 */       dir.delete();
/*  539 */       return 1;
/*      */     } 
/*  541 */     String[] fromFiles = dir.list();
/*  542 */     if (fromFiles == null) {
/*  543 */       return 0;
/*      */     }
/*  545 */     int result = 0;
/*  546 */     for (String string : fromFiles) {
/*  547 */       File file = new File(dir, string);
/*  548 */       if (null == filter || filter.accept(file)) {
/*  549 */         if (file.isDirectory()) {
/*  550 */           result += deleteContents(file, filter, deleteEmptyDirs);
/*  551 */           String[] fileContent = file.list();
/*  552 */           if (deleteEmptyDirs && fileContent != null && 0 == fileContent.length)
/*      */           {
/*  554 */             file.delete();
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  559 */           file.delete();
/*  560 */           result++;
/*      */         } 
/*      */       }
/*      */     } 
/*  564 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int copyDir(File fromDir, File toDir) throws IOException {
/*  575 */     return copyDir(fromDir, toDir, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int copyDir(File fromDir, File toDir, String fromSuffix, String toSuffix) throws IOException {
/*  589 */     return copyDir(fromDir, toDir, fromSuffix, toSuffix, (FileFilter)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int copyDir(File fromDir, File toDir, final String fromSuffix, String toSuffix, FileFilter delegate) throws IOException {
/*      */     String[] fromFiles;
/*  641 */     if (null == fromDir || !fromDir.canRead()) {
/*  642 */       return 0;
/*      */     }
/*  644 */     boolean haveSuffix = (null != fromSuffix && 0 < fromSuffix.length());
/*  645 */     int slen = !haveSuffix ? 0 : fromSuffix.length();
/*      */     
/*  647 */     if (!toDir.exists()) {
/*  648 */       toDir.mkdirs();
/*      */     }
/*      */     
/*  651 */     if (!haveSuffix) {
/*  652 */       fromFiles = fromDir.list();
/*      */     } else {
/*  654 */       FilenameFilter filter = new FilenameFilter() {
/*      */           public boolean accept(File dir, String name) {
/*  656 */             return ((new File(dir, name)).isDirectory() || name.endsWith(fromSuffix));
/*      */           }
/*      */         };
/*  659 */       fromFiles = fromDir.list(filter);
/*      */     } 
/*  661 */     int result = 0;
/*  662 */     int MAX = (null == fromFiles) ? 0 : fromFiles.length;
/*  663 */     for (int i = 0; i < MAX; i++) {
/*  664 */       String filename = fromFiles[i];
/*  665 */       File fromFile = new File(fromDir, filename);
/*  666 */       if (fromFile.canRead()) {
/*  667 */         if (fromFile.isDirectory()) {
/*  668 */           result += copyDir(fromFile, new File(toDir, filename), fromSuffix, toSuffix, delegate);
/*  669 */         } else if (fromFile.isFile()) {
/*  670 */           if (haveSuffix) {
/*  671 */             filename = filename.substring(0, filename.length() - slen);
/*      */           }
/*  673 */           if (null != toSuffix) {
/*  674 */             filename = filename + toSuffix;
/*      */           }
/*  676 */           File targetFile = new File(toDir, filename);
/*  677 */           if (null == delegate || delegate.accept(targetFile)) {
/*  678 */             copyFile(fromFile, targetFile);
/*      */           }
/*  680 */           result++;
/*      */         } 
/*      */       }
/*      */     } 
/*  684 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] listFiles(File srcDir) {
/*  693 */     ArrayList<String> result = new ArrayList<>();
/*  694 */     if (null != srcDir && srcDir.canRead()) {
/*  695 */       listFiles(srcDir, (String)null, result);
/*      */     }
/*  697 */     return result.<String>toArray(new String[0]);
/*      */   }
/*      */   
/*  700 */   public static final FileFilter aspectjSourceFileFilter = new FileFilter() {
/*      */       public boolean accept(File pathname) {
/*  702 */         String name = pathname.getName().toLowerCase();
/*  703 */         return (name.endsWith(".java") || name.endsWith(".aj"));
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   static final String FILECHARS = "abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
/*      */ 
/*      */   
/*      */   public static File[] listFiles(File srcDir, FileFilter fileFilter) {
/*  713 */     ArrayList<File> result = new ArrayList<>();
/*  714 */     if (null != srcDir && srcDir.canRead()) {
/*  715 */       listFiles(srcDir, result, fileFilter);
/*      */     }
/*  717 */     return result.<File>toArray(new File[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<File> listClassFiles(File dir) {
/*  726 */     ArrayList<File> result = new ArrayList<>();
/*  727 */     if (null != dir && dir.canRead()) {
/*  728 */       listClassFiles(dir, result);
/*      */     }
/*  730 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File[] getBaseDirFiles(File basedir, String[] paths) {
/*  741 */     return getBaseDirFiles(basedir, paths, (String[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File[] getBaseDirFiles(File basedir, String[] paths, String[] suffixes) {
/*  753 */     LangUtil.throwIaxIfNull(basedir, "basedir");
/*  754 */     LangUtil.throwIaxIfNull(paths, "paths");
/*  755 */     File[] result = null;
/*  756 */     if (!LangUtil.isEmpty((Object[])suffixes)) {
/*  757 */       ArrayList<File> list = new ArrayList<>();
/*  758 */       for (String path : paths) {
/*  759 */         for (String suffix : suffixes) {
/*  760 */           if (path.endsWith(suffix)) {
/*  761 */             list.add(new File(basedir, path));
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*  766 */       result = list.<File>toArray(new File[0]);
/*      */     } else {
/*  768 */       result = new File[paths.length];
/*  769 */       for (int i = 0; i < result.length; i++) {
/*  770 */         result[i] = newFile(basedir, paths[i]);
/*      */       }
/*      */     } 
/*  773 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static File newFile(File dir, String path) {
/*  784 */     if (".".equals(path))
/*  785 */       return dir; 
/*  786 */     if ("..".equals(path)) {
/*  787 */       File parentDir = dir.getParentFile();
/*  788 */       if (null != parentDir) {
/*  789 */         return parentDir;
/*      */       }
/*  791 */       return new File(dir, "..");
/*      */     } 
/*      */     
/*  794 */     return new File(dir, path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File[] copyFiles(File srcDir, String[] relativePaths, File destDir) throws IllegalArgumentException, IOException {
/*  809 */     String[] paths = relativePaths;
/*  810 */     throwIaxUnlessCanReadDir(srcDir, "srcDir");
/*  811 */     throwIaxUnlessCanWriteDir(destDir, "destDir");
/*  812 */     LangUtil.throwIaxIfNull(paths, "relativePaths");
/*  813 */     File[] result = new File[paths.length];
/*  814 */     for (int i = 0; i < paths.length; i++) {
/*  815 */       String path = paths[i];
/*  816 */       LangUtil.throwIaxIfNull(path, "relativePaths-entry");
/*  817 */       File src = newFile(srcDir, paths[i]);
/*  818 */       File dest = newFile(destDir, path);
/*  819 */       File destParent = dest.getParentFile();
/*  820 */       if (!destParent.exists()) {
/*  821 */         destParent.mkdirs();
/*      */       }
/*  823 */       LangUtil.throwIaxIfFalse(canWriteDir(destParent), "dest-entry-parent");
/*  824 */       copyFile(src, dest);
/*  825 */       result[i] = dest;
/*      */     } 
/*  827 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyFile(File fromFile, File toFile) throws IOException {
/*  837 */     LangUtil.throwIaxIfNull(fromFile, "fromFile");
/*  838 */     LangUtil.throwIaxIfNull(toFile, "toFile");
/*  839 */     LangUtil.throwIaxIfFalse(!toFile.equals(fromFile), "same file");
/*  840 */     if (toFile.isDirectory()) {
/*  841 */       throwIaxUnlessCanWriteDir(toFile, "toFile");
/*  842 */       if (fromFile.isFile()) {
/*  843 */         File targFile = new File(toFile, fromFile.getName());
/*  844 */         copyValidFiles(fromFile, targFile);
/*  845 */       } else if (fromFile.isDirectory()) {
/*  846 */         copyDir(fromFile, toFile);
/*      */       } else {
/*  848 */         LangUtil.throwIaxIfFalse(false, "not dir or file: " + fromFile);
/*      */       } 
/*  850 */     } else if (toFile.isFile()) {
/*  851 */       if (fromFile.isDirectory()) {
/*  852 */         LangUtil.throwIaxIfFalse(false, "can't copy to file dir: " + fromFile);
/*      */       }
/*  854 */       copyValidFiles(fromFile, toFile);
/*      */     } else {
/*  856 */       ensureParentWritable(toFile);
/*  857 */       if (fromFile.isFile()) {
/*  858 */         copyValidFiles(fromFile, toFile);
/*  859 */       } else if (fromFile.isDirectory()) {
/*  860 */         toFile.mkdirs();
/*  861 */         throwIaxUnlessCanWriteDir(toFile, "toFile");
/*  862 */         copyDir(fromFile, toFile);
/*      */       } else {
/*  864 */         LangUtil.throwIaxIfFalse(false, "not dir or file: " + fromFile);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File ensureParentWritable(File path) {
/*  878 */     LangUtil.throwIaxIfNull(path, "path");
/*  879 */     File pathParent = path.getParentFile();
/*  880 */     if (null == pathParent) {
/*  881 */       pathParent = DEFAULT_PARENT;
/*      */     }
/*  883 */     if (!pathParent.canWrite()) {
/*  884 */       pathParent.mkdirs();
/*      */     }
/*  886 */     throwIaxUnlessCanWriteDir(pathParent, "pathParent");
/*  887 */     return pathParent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyValidFiles(File fromFile, File toFile) throws IOException {
/*  898 */     FileInputStream in = new FileInputStream(fromFile); try { FileOutputStream out = new FileOutputStream(toFile); 
/*  899 */       try { copyStream(in, out);
/*  900 */         out.close(); } catch (Throwable throwable) { try { out.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  in.close(); }
/*      */     catch (Throwable throwable) { try {
/*      */         in.close();
/*      */       } catch (Throwable throwable1) {
/*      */         throwable.addSuppressed(throwable1);
/*      */       }  throw throwable; }
/*  906 */      } public static void copyStream(DataInputStream in, PrintStream out) throws IOException { LangUtil.throwIaxIfNull(in, "in");
/*  907 */     LangUtil.throwIaxIfNull(in, "out");
/*      */     String s;
/*  909 */     while (null != (s = in.readLine())) {
/*  910 */       out.println(s);
/*      */     } }
/*      */ 
/*      */   
/*      */   public static void copyStream(InputStream in, OutputStream out) throws IOException {
/*  915 */     int MAX = 4096;
/*  916 */     byte[] buf = new byte[4096]; int bytesRead;
/*  917 */     for (bytesRead = in.read(buf, 0, 4096); bytesRead != -1; bytesRead = in.read(buf, 0, 4096)) {
/*  918 */       out.write(buf, 0, bytesRead);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void copyStream(Reader in, Writer out) throws IOException {
/*  923 */     int MAX = 4096;
/*  924 */     char[] buf = new char[4096]; int bytesRead;
/*  925 */     for (bytesRead = in.read(buf, 0, 4096); bytesRead != -1; bytesRead = in.read(buf, 0, 4096)) {
/*  926 */       out.write(buf, 0, bytesRead);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File makeNewChildDir(File parent, String child) {
/*  938 */     if (null == parent || !parent.canWrite() || !parent.isDirectory())
/*  939 */       throw new IllegalArgumentException("bad parent: " + parent); 
/*  940 */     if (null == child) {
/*  941 */       child = "makeNewChildDir";
/*  942 */     } else if (!isValidFileName(child)) {
/*  943 */       throw new IllegalArgumentException("bad child: " + child);
/*      */     } 
/*  945 */     File result = new File(parent, child);
/*  946 */     int safety = 1000;
/*  947 */     for (String suffix = randomFileString(); 0 < --safety && result.exists(); suffix = randomFileString()) {
/*  948 */       result = new File(parent, child + suffix);
/*      */     }
/*  950 */     if (result.exists()) {
/*  951 */       System.err.println("exhausted files for child dir in " + parent);
/*  952 */       return null;
/*      */     } 
/*  954 */     return (result.mkdirs() && result.exists()) ? result : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getTempDir(String name) {
/*  965 */     if (null == name) {
/*  966 */       name = "FileUtil_getTempDir";
/*  967 */     } else if (!isValidFileName(name)) {
/*  968 */       throw new IllegalArgumentException(" invalid: " + name);
/*      */     } 
/*  970 */     File result = null;
/*  971 */     File tempFile = null;
/*      */     try {
/*  973 */       tempFile = File.createTempFile("ignoreMe", ".txt");
/*  974 */       File tempParent = tempFile.getParentFile();
/*  975 */       result = makeNewChildDir(tempParent, name);
/*  976 */     } catch (IOException t) {
/*  977 */       result = makeNewChildDir(new File("."), name);
/*      */     } finally {
/*  979 */       if (null != tempFile) {
/*  980 */         tempFile.delete();
/*      */       }
/*      */     } 
/*  983 */     return result;
/*      */   }
/*      */   
/*      */   public static URL[] getFileURLs(File[] files) {
/*  987 */     if (null == files || 0 == files.length) {
/*  988 */       return new URL[0];
/*      */     }
/*  990 */     URL[] result = new URL[files.length];
/*  991 */     for (int i = 0; i < result.length; i++) {
/*  992 */       result[i] = getFileURL(files[i]);
/*      */     }
/*  994 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static URL getFileURL(File file) {
/* 1004 */     LangUtil.throwIaxIfNull(file, "file");
/* 1005 */     URL result = null;
/*      */     try {
/* 1007 */       result = file.toURL();
/*      */       
/* 1009 */       if (null != result) {
/* 1010 */         return result;
/*      */       }
/* 1012 */       String url = "file:" + file.getAbsolutePath().replace('\\', '/');
/* 1013 */       result = new URL(url + (file.isDirectory() ? "/" : ""));
/* 1014 */     } catch (MalformedURLException e) {
/* 1015 */       String m = "Util.makeURL(\"" + file.getPath() + "\" MUE " + e.getMessage();
/* 1016 */       System.err.println(m);
/*      */     } 
/* 1018 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String writeAsString(File file, String contents) {
/* 1030 */     LangUtil.throwIaxIfNull(file, "file");
/* 1031 */     if (null == contents) {
/* 1032 */       contents = "";
/*      */     }
/* 1034 */     Writer out = null;
/*      */     try {
/* 1036 */       File parentDir = file.getParentFile();
/* 1037 */       if (!parentDir.exists() && !parentDir.mkdirs()) {
/* 1038 */         return "unable to make parent dir for " + file;
/*      */       }
/* 1040 */       Reader in = new StringReader(contents);
/* 1041 */       out = new FileWriter(file);
/* 1042 */       copyStream(in, out);
/* 1043 */       return null;
/* 1044 */     } catch (IOException e) {
/* 1045 */       return LangUtil.unqualifiedClassName(e) + " writing " + file + ": " + e.getMessage();
/*      */     } finally {
/* 1047 */       if (null != out) {
/*      */         try {
/* 1049 */           out.close();
/* 1050 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] readBooleanArray(DataInputStream s) throws IOException {
/* 1060 */     int len = s.readInt();
/* 1061 */     boolean[] ret = new boolean[len];
/* 1062 */     for (int i = 0; i < len; i++) {
/* 1063 */       ret[i] = s.readBoolean();
/*      */     }
/* 1065 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeBooleanArray(boolean[] a, DataOutputStream s) throws IOException {
/* 1072 */     int len = a.length;
/* 1073 */     s.writeInt(len);
/* 1074 */     for (boolean b : a) {
/* 1075 */       s.writeBoolean(b);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] readIntArray(DataInputStream s) throws IOException {
/* 1083 */     int len = s.readInt();
/* 1084 */     int[] ret = new int[len];
/* 1085 */     for (int i = 0; i < len; i++) {
/* 1086 */       ret[i] = s.readInt();
/*      */     }
/* 1088 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeIntArray(int[] a, DataOutputStream s) throws IOException {
/* 1095 */     int len = a.length;
/* 1096 */     s.writeInt(len);
/* 1097 */     for (int j : a) {
/* 1098 */       s.writeInt(j);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] readStringArray(DataInputStream s) throws IOException {
/* 1106 */     int len = s.readInt();
/* 1107 */     String[] ret = new String[len];
/* 1108 */     for (int i = 0; i < len; i++) {
/* 1109 */       ret[i] = s.readUTF();
/*      */     }
/* 1111 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeStringArray(String[] a, DataOutputStream s) throws IOException {
/* 1118 */     if (a == null) {
/* 1119 */       s.writeInt(0);
/*      */       return;
/*      */     } 
/* 1122 */     int len = a.length;
/* 1123 */     s.writeInt(len);
/* 1124 */     for (String value : a) {
/* 1125 */       s.writeUTF(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readAsString(File file) throws IOException {
/* 1133 */     BufferedReader r = new BufferedReader(new FileReader(file));
/* 1134 */     StringBuilder b = new StringBuilder();
/*      */     while (true) {
/* 1136 */       int ch = r.read();
/* 1137 */       if (ch == -1) {
/*      */         break;
/*      */       }
/* 1140 */       b.append((char)ch);
/*      */     } 
/* 1142 */     r.close();
/* 1143 */     return b.toString();
/*      */   }
/*      */   
/*      */   public static List<String> readAsLines(File file) {
/*      */     try {
/* 1148 */       return Files.readAllLines(Paths.get(file.toURI()));
/* 1149 */     } catch (NoSuchFileException nsfe) {
/* 1150 */       return Collections.emptyList();
/* 1151 */     } catch (IOException e) {
/* 1152 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readAsByteArray(File file) throws IOException {
/* 1177 */     FileInputStream in = new FileInputStream(file);
/* 1178 */     byte[] ret = readAsByteArray(in);
/* 1179 */     in.close();
/* 1180 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readAsByteArray(InputStream inStream) throws IOException {
/* 1187 */     int size = 1024;
/* 1188 */     byte[] ba = new byte[size];
/* 1189 */     int readSoFar = 0;
/*      */     
/*      */     while (true) {
/* 1192 */       int nRead = inStream.read(ba, readSoFar, size - readSoFar);
/* 1193 */       if (nRead == -1) {
/*      */         break;
/*      */       }
/* 1196 */       readSoFar += nRead;
/* 1197 */       if (readSoFar == size) {
/* 1198 */         int newSize = size * 2;
/* 1199 */         byte[] arrayOfByte = new byte[newSize];
/* 1200 */         System.arraycopy(ba, 0, arrayOfByte, 0, size);
/* 1201 */         ba = arrayOfByte;
/* 1202 */         size = newSize;
/*      */       } 
/*      */     } 
/*      */     
/* 1206 */     byte[] newBa = new byte[readSoFar];
/* 1207 */     System.arraycopy(ba, 0, newBa, 0, readSoFar);
/* 1208 */     return newBa;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String randomFileString() {
/* 1215 */     double FILECHARS_length = "abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".length();
/* 1216 */     int LEN = 6;
/* 1217 */     char[] result = new char[6];
/* 1218 */     int index = (int)(Math.random() * 6.0D);
/* 1219 */     for (int i = 0; i < 6; i++) {
/* 1220 */       if (index >= 6) {
/* 1221 */         index = 0;
/*      */       }
/* 1223 */       result[index++] = "abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt((int)(Math.random() * FILECHARS_length));
/*      */     } 
/* 1225 */     return new String(result);
/*      */   }
/*      */   
/*      */   public static InputStream getStreamFromZip(String zipFile, String name) {
/*      */     try {
/* 1230 */       ZipFile zf = new ZipFile(zipFile);
/*      */       
/* 1232 */       ZipEntry entry = zf.getEntry(name);
/* 1233 */       return zf.getInputStream(entry);
/*      */ 
/*      */     
/*      */     }
/* 1237 */     catch (IOException ioe) {
/* 1238 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> lineSeek(String sought, List<String> sources, boolean listAll, PrintStream errorSink) {
/* 1276 */     if (LangUtil.isEmpty(sought) || LangUtil.isEmpty(sources)) {
/* 1277 */       return Collections.emptyList();
/*      */     }
/* 1279 */     ArrayList<String> result = new ArrayList<>();
/* 1280 */     for (String path : sources) {
/* 1281 */       String error = lineSeek(sought, path, listAll, result);
/* 1282 */       if (null != error && null != errorSink) {
/* 1283 */         errorSink.println(error);
/*      */       }
/*      */     } 
/* 1286 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String lineSeek(String sought, String sourcePath, boolean listAll, List<String> sink) {
/* 1301 */     if (LangUtil.isEmpty(sought) || LangUtil.isEmpty(sourcePath)) {
/* 1302 */       return "nothing sought";
/*      */     }
/* 1304 */     if (LangUtil.isEmpty(sourcePath)) {
/* 1305 */       return "no sourcePath";
/*      */     }
/* 1307 */     File file = new File(sourcePath);
/* 1308 */     if (!file.canRead() || !file.isFile()) {
/* 1309 */       return "sourcePath not a readable file";
/*      */     }
/* 1311 */     int lineNum = 0;
/* 1312 */     FileReader fin = null;
/*      */     try {
/* 1314 */       fin = new FileReader(file);
/* 1315 */       BufferedReader reader = new BufferedReader(fin);
/*      */       String line;
/* 1317 */       while (null != (line = reader.readLine())) {
/* 1318 */         lineNum++;
/* 1319 */         int loc = line.indexOf(sought);
/* 1320 */         if (-1 != loc) {
/* 1321 */           sink.add(sourcePath + ":" + lineNum + ":" + loc);
/* 1322 */           if (!listAll) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       } 
/* 1327 */     } catch (IOException e) {
/* 1328 */       return LangUtil.unqualifiedClassName(e) + " reading " + sourcePath + ":" + lineNum;
/*      */     } finally {
/*      */       try {
/* 1331 */         if (null != fin) {
/* 1332 */           fin.close();
/*      */         }
/* 1334 */       } catch (IOException iOException) {}
/*      */     } 
/*      */     
/* 1337 */     return null;
/*      */   }
/*      */   
/*      */   public static BufferedOutputStream makeOutputStream(File file) throws FileNotFoundException {
/* 1341 */     File parent = file.getParentFile();
/* 1342 */     if (parent != null) {
/* 1343 */       parent.mkdirs();
/*      */     }
/* 1345 */     return new BufferedOutputStream(new FileOutputStream(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean sleepPastFinalModifiedTime(File[] files) {
/* 1356 */     if (null == files || 0 == files.length) {
/* 1357 */       return true;
/*      */     }
/* 1359 */     long delayUntil = System.currentTimeMillis();
/* 1360 */     for (File file : files) {
/* 1361 */       if (null != file && file.exists()) {
/*      */ 
/*      */         
/* 1364 */         long nextModTime = file.lastModified();
/* 1365 */         if (nextModTime > delayUntil)
/* 1366 */           delayUntil = nextModTime; 
/*      */       } 
/*      */     } 
/* 1369 */     return LangUtil.sleepUntil(++delayUntil);
/*      */   }
/*      */   
/*      */   private static void listClassFiles(File baseDir, ArrayList<File> result) {
/* 1373 */     File[] files = baseDir.listFiles();
/* 1374 */     for (File f : files) {
/* 1375 */       if (f.isDirectory()) {
/* 1376 */         listClassFiles(f, result);
/*      */       
/*      */       }
/* 1379 */       else if (f.getName().endsWith(".class")) {
/* 1380 */         result.add(f);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void listFiles(File baseDir, ArrayList<File> result, FileFilter filter) {
/* 1387 */     File[] files = baseDir.listFiles();
/*      */     
/* 1389 */     boolean skipCVS = (!PERMIT_CVS && filter == aspectjSourceFileFilter);
/* 1390 */     for (File f : files) {
/* 1391 */       if (f.isDirectory()) {
/* 1392 */         if (skipCVS) {
/* 1393 */           String name = f.getName().toLowerCase();
/* 1394 */           if ("cvs".equals(name) || "sccs".equals(name)) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 1398 */         listFiles(f, result, filter);
/*      */         continue;
/*      */       } 
/* 1401 */       if (filter.accept(f)) {
/* 1402 */         result.add(f);
/*      */       }
/*      */       continue;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isValidFileName(String input) {
/* 1410 */     return (null != input && !input.contains(File.pathSeparator));
/*      */   }
/*      */   
/*      */   private static void listFiles(File baseDir, String dir, ArrayList<String> result) {
/* 1414 */     String dirPrefix = (null == dir) ? "" : (dir + "/");
/* 1415 */     File dirFile = (null == dir) ? baseDir : new File(baseDir.getPath() + "/" + dir);
/* 1416 */     String[] files = dirFile.list();
/* 1417 */     for (String file : files) {
/* 1418 */       File f = new File(dirFile, file);
/* 1419 */       String path = dirPrefix + file;
/* 1420 */       if (f.isDirectory()) {
/* 1421 */         listFiles(baseDir, path, result);
/*      */       } else {
/*      */         
/* 1424 */         result.add(path);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> makeClasspath(URL[] urls) {
/* 1433 */     List<String> ret = new LinkedList<>();
/* 1434 */     if (urls != null) {
/* 1435 */       for (URL url : urls) {
/* 1436 */         ret.add(toPathString(url));
/*      */       }
/*      */     }
/* 1439 */     return ret;
/*      */   }
/*      */   
/*      */   private static String toPathString(URL url) {
/*      */     try {
/* 1444 */       return url.toURI().getPath();
/* 1445 */     } catch (URISyntaxException e) {
/* 1446 */       System.err.println("Warning!! Malformed URL may cause problems: " + url);
/*      */ 
/*      */ 
/*      */       
/* 1450 */       return url.getPath();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Pipe
/*      */     implements Runnable
/*      */   {
/*      */     private final InputStream in;
/*      */ 
/*      */     
/*      */     private final OutputStream out;
/*      */ 
/*      */     
/*      */     private final long sleep;
/*      */ 
/*      */     
/*      */     private ByteArrayOutputStream snoop;
/*      */ 
/*      */     
/*      */     private long totalWritten;
/*      */     
/*      */     private Throwable thrown;
/*      */     
/*      */     private boolean halt;
/*      */     
/*      */     private final boolean closeInput;
/*      */     
/*      */     private final boolean closeOutput;
/*      */     
/*      */     private boolean finishStream;
/*      */     
/*      */     private boolean done;
/*      */ 
/*      */     
/*      */     Pipe(InputStream in, OutputStream out) {
/* 1487 */       this(in, out, 100L, false, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Pipe(InputStream in, OutputStream out, long sleep, boolean closeInput, boolean closeOutput) {
/* 1497 */       LangUtil.throwIaxIfNull(in, "in");
/* 1498 */       LangUtil.throwIaxIfNull(out, "out");
/* 1499 */       this.in = in;
/* 1500 */       this.out = out;
/* 1501 */       this.closeInput = closeInput;
/* 1502 */       this.closeOutput = closeOutput;
/* 1503 */       this.sleep = Math.min(0L, Math.max(60000L, sleep));
/*      */     }
/*      */     
/*      */     public void setSnoop(ByteArrayOutputStream snoop) {
/* 1507 */       this.snoop = snoop;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/* 1514 */       this.totalWritten = 0L;
/* 1515 */       if (this.halt) {
/*      */         return;
/*      */       }
/*      */       try {
/* 1519 */         int MAX = 4096;
/* 1520 */         byte[] buf = new byte[4096];
/*      */         
/* 1522 */         int count = this.in.read(buf, 0, 4096);
/*      */         
/* 1524 */         while ((this.halt && this.finishStream && 0 < count) || (!this.halt && -1 != count)) {
/* 1525 */           this.out.write(buf, 0, count);
/* 1526 */           ByteArrayOutputStream mySnoop = this.snoop;
/* 1527 */           if (null != mySnoop) {
/* 1528 */             mySnoop.write(buf, 0, count);
/*      */           }
/* 1530 */           this.totalWritten += count;
/* 1531 */           if (this.halt && !this.finishStream) {
/*      */             break;
/*      */           }
/* 1534 */           if (!this.halt && 0L < this.sleep) {
/* 1535 */             Thread.sleep(this.sleep);
/*      */           }
/* 1537 */           if (this.halt && !this.finishStream) {
/*      */             break;
/*      */           }
/* 1540 */           count = this.in.read(buf, 0, 4096);
/*      */         } 
/* 1542 */       } catch (Throwable e) {
/* 1543 */         this.thrown = e;
/*      */       } finally {
/* 1545 */         this.halt = true;
/* 1546 */         if (this.closeInput) {
/*      */           try {
/* 1548 */             this.in.close();
/* 1549 */           } catch (IOException iOException) {}
/*      */         }
/*      */ 
/*      */         
/* 1553 */         if (this.closeOutput) {
/*      */           try {
/* 1555 */             this.out.close();
/* 1556 */           } catch (IOException iOException) {}
/*      */         }
/*      */ 
/*      */         
/* 1560 */         this.done = true;
/* 1561 */         completing(this.totalWritten, this.thrown);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean halt(boolean wait, boolean finishStream) {
/* 1574 */       if (!this.halt) {
/* 1575 */         this.halt = true;
/*      */       }
/* 1577 */       if (wait) {
/* 1578 */         while (!this.done) {
/* 1579 */           synchronized (this) {
/* 1580 */             notifyAll();
/*      */           } 
/* 1582 */           if (!this.done) {
/*      */             try {
/* 1584 */               Thread.sleep(5L);
/* 1585 */             } catch (InterruptedException e) {
/*      */               break;
/*      */             } 
/*      */           }
/*      */         } 
/*      */       }
/* 1591 */       return this.halt;
/*      */     }
/*      */ 
/*      */     
/*      */     public long totalWritten() {
/* 1596 */       return this.totalWritten;
/*      */     }
/*      */ 
/*      */     
/*      */     public Throwable getThrown() {
/* 1601 */       return this.thrown;
/*      */     }
/*      */     
/*      */     protected void completing(long totalWritten, Throwable thrown) {}
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\FileUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */