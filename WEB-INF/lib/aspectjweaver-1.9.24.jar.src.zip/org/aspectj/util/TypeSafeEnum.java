/*    */ package org.aspectj.util;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeSafeEnum
/*    */ {
/*    */   private final byte key;
/*    */   private final String name;
/*    */   
/*    */   public TypeSafeEnum(String name, int key) {
/* 23 */     this.name = name;
/* 24 */     if (key > 127 || key < -128) {
/* 25 */       throw new IllegalArgumentException("key doesn't fit into a byte: " + key);
/*    */     }
/* 27 */     this.key = (byte)key;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 31 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */   
/*    */   public byte getKey() {
/* 39 */     return this.key;
/*    */   }
/*    */   
/*    */   public void write(DataOutputStream s) throws IOException {
/* 43 */     s.writeByte(this.key);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 47 */     return this.name.hashCode() * 37 + this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 52 */     return (o instanceof TypeSafeEnum && ((TypeSafeEnum)o).key == this.key && ((TypeSafeEnum)o).name
/*    */       
/* 54 */       .equals(this.name));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\TypeSafeEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */