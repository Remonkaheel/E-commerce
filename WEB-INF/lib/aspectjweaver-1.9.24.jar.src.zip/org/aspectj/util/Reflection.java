/*     */ package org.aspectj.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reflection
/*     */ {
/*  24 */   public static final Class<?>[] MAIN_PARM_TYPES = new Class[] { String[].class };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object invokestaticN(Class<?> class_, String name, Object[] args) {
/*  30 */     return invokeN(class_, name, null, args);
/*     */   }
/*     */   
/*     */   public static Object invoke(Class<?> class_, Object target, String name, Object arg1, Object arg2) {
/*  34 */     return invokeN(class_, name, target, new Object[] { arg1, arg2 });
/*     */   }
/*     */   
/*     */   public static Object invoke(Class<?> class_, Object target, String name, Object arg1, Object arg2, Object arg3) {
/*  38 */     return invokeN(class_, name, target, new Object[] { arg1, arg2, arg3 });
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object invokeN(Class<?> class_, String name, Object target, Object[] args) {
/*  43 */     Method meth = getMatchingMethod(class_, name, args);
/*     */     try {
/*  45 */       return meth.invoke(target, args);
/*  46 */     } catch (IllegalAccessException e) {
/*  47 */       throw new RuntimeException(e.toString());
/*  48 */     } catch (InvocationTargetException e) {
/*  49 */       Throwable t = e.getTargetException();
/*  50 */       if (t instanceof Error) throw (Error)t; 
/*  51 */       if (t instanceof RuntimeException) throw (RuntimeException)t; 
/*  52 */       t.printStackTrace();
/*  53 */       throw new RuntimeException(t.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method getMatchingMethod(Class<?> class_, String name, Object[] args) {
/*  59 */     Method[] meths = class_.getMethods();
/*  60 */     for (Method meth : meths) {
/*  61 */       if (meth.getName().equals(name) && isCompatible(meth, args)) {
/*  62 */         return meth;
/*     */       }
/*     */     } 
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isCompatible(Method meth, Object[] args) {
/*  70 */     return ((meth.getParameterTypes()).length == args.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getStaticField(Class<?> class_, String name) {
/*     */     try {
/*  78 */       return class_.getField(name).get(null);
/*  79 */     } catch (IllegalAccessException e) {
/*  80 */       throw new RuntimeException("unimplemented");
/*  81 */     } catch (NoSuchFieldException e) {
/*  82 */       throw new RuntimeException("unimplemented");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runMainInSameVM(String classpath, String className, String[] args) throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {
/*  93 */     LangUtil.throwIaxIfNull(className, "class name");
/*  94 */     if (LangUtil.isEmpty(classpath)) {
/*  95 */       Class<?> mainClass = Class.forName(className);
/*  96 */       runMainInSameVM(mainClass, args);
/*     */       return;
/*     */     } 
/*  99 */     ArrayList<File> dirs = new ArrayList<>();
/* 100 */     ArrayList<File> libs = new ArrayList<>();
/* 101 */     ArrayList<URL> urls = new ArrayList<>();
/* 102 */     String[] entries = LangUtil.splitClasspath(classpath);
/* 103 */     for (String entry : entries) {
/* 104 */       URL url = makeURL(entry);
/* 105 */       if (null != url) {
/* 106 */         urls.add(url);
/*     */       }
/* 108 */       File file = new File(entry);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       if (FileUtil.isZipFile(file)) {
/* 114 */         libs.add(file);
/* 115 */       } else if (file.isDirectory()) {
/* 116 */         dirs.add(file);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 121 */     File[] dirRa = dirs.<File>toArray(new File[0]);
/* 122 */     File[] libRa = libs.<File>toArray(new File[0]);
/* 123 */     URL[] urlRa = urls.<URL>toArray(new URL[0]);
/* 124 */     runMainInSameVM(urlRa, libRa, dirRa, className, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runMainInSameVM(URL[] urls, File[] libs, File[] dirs, String className, String[] args) throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {
/* 136 */     LangUtil.throwIaxIfNull(className, "class name");
/* 137 */     LangUtil.throwIaxIfNotAssignable((Object[])libs, File.class, "jars");
/* 138 */     LangUtil.throwIaxIfNotAssignable((Object[])dirs, File.class, "dirs");
/* 139 */     URL[] libUrls = FileUtil.getFileURLs(libs);
/* 140 */     if (!LangUtil.isEmpty((Object[])libUrls)) {
/* 141 */       if (!LangUtil.isEmpty((Object[])urls)) {
/* 142 */         URL[] temp = new URL[libUrls.length + urls.length];
/* 143 */         System.arraycopy(urls, 0, temp, 0, urls.length);
/* 144 */         System.arraycopy(urls, 0, temp, libUrls.length, urls.length);
/* 145 */         urls = temp;
/*     */       } else {
/* 147 */         urls = libUrls;
/*     */       } 
/*     */     }
/* 150 */     UtilClassLoader loader = new UtilClassLoader(urls, dirs);
/* 151 */     Class<?> targetClass = null;
/*     */     try {
/* 153 */       targetClass = loader.loadClass(className);
/* 154 */     } catch (ClassNotFoundException e) {
/* 155 */       String s = "unable to load class " + className + " using class loader " + loader;
/*     */       
/* 157 */       throw new ClassNotFoundException(s);
/*     */     } 
/* 159 */     Method main = targetClass.getMethod("main", MAIN_PARM_TYPES);
/* 160 */     main.invoke(null, new Object[] { args });
/*     */   }
/*     */   
/*     */   public static void runMainInSameVM(Class<?> mainClass, String[] args) throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
/* 164 */     LangUtil.throwIaxIfNull(mainClass, "main class");
/* 165 */     Method main = mainClass.getMethod("main", MAIN_PARM_TYPES);
/* 166 */     main.invoke(null, new Object[] { args });
/*     */   }
/*     */ 
/*     */   
/*     */   private static URL makeURL(String s) {
/*     */     try {
/* 172 */       return new URL(s);
/* 173 */     } catch (Throwable t) {
/* 174 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\Reflection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */