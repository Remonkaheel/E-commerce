/*     */ package org.aspectj.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericSignatureParser
/*     */ {
/*     */   private String inputString;
/*     */   private String[] tokenStream;
/*  36 */   private int tokenIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericSignature.ClassSignature parseAsClassSignature(String sig) {
/*  43 */     this.inputString = sig;
/*  44 */     this.tokenStream = tokenize(sig);
/*  45 */     this.tokenIndex = 0;
/*  46 */     GenericSignature.ClassSignature classSig = new GenericSignature.ClassSignature();
/*     */     
/*  48 */     if (maybeEat("<")) {
/*  49 */       List<GenericSignature.FormalTypeParameter> formalTypeParametersList = new ArrayList<>();
/*     */       while (true) {
/*  51 */         formalTypeParametersList.add(parseFormalTypeParameter());
/*  52 */         if (maybeEat(">"))
/*  53 */         { classSig.formalTypeParameters = new GenericSignature.FormalTypeParameter[formalTypeParametersList.size()];
/*  54 */           formalTypeParametersList.toArray(classSig.formalTypeParameters); break; } 
/*     */       } 
/*  56 */     }  classSig.superclassSignature = parseClassTypeSignature();
/*  57 */     List<GenericSignature.ClassTypeSignature> superIntSigs = new ArrayList<>();
/*  58 */     while (this.tokenIndex < this.tokenStream.length) {
/*  59 */       superIntSigs.add(parseClassTypeSignature());
/*     */     }
/*  61 */     classSig.superInterfaceSignatures = new GenericSignature.ClassTypeSignature[superIntSigs.size()];
/*  62 */     superIntSigs.toArray(classSig.superInterfaceSignatures);
/*  63 */     return classSig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericSignature.MethodTypeSignature parseAsMethodSignature(String sig) {
/*  71 */     this.inputString = sig;
/*  72 */     this.tokenStream = tokenize(sig);
/*  73 */     this.tokenIndex = 0;
/*  74 */     GenericSignature.FormalTypeParameter[] formals = GenericSignature.FormalTypeParameter.NONE;
/*  75 */     GenericSignature.TypeSignature returnType = null;
/*     */     
/*  77 */     if (maybeEat("<")) {
/*  78 */       List<GenericSignature.FormalTypeParameter> formalTypeParametersList = new ArrayList<>();
/*     */       while (true) {
/*  80 */         formalTypeParametersList.add(parseFormalTypeParameter());
/*  81 */         if (maybeEat(">")) {
/*  82 */           formals = new GenericSignature.FormalTypeParameter[formalTypeParametersList.size()];
/*  83 */           formalTypeParametersList.toArray(formals); break;
/*     */         } 
/*     */       } 
/*  86 */     }  eat("(");
/*  87 */     List<GenericSignature.TypeSignature> paramList = new ArrayList<>();
/*  88 */     while (!maybeEat(")")) {
/*  89 */       GenericSignature.FieldTypeSignature fsig = parseFieldTypeSignature(true);
/*  90 */       if (fsig != null) {
/*  91 */         paramList.add(fsig); continue;
/*     */       } 
/*  93 */       paramList.add(new GenericSignature.BaseTypeSignature(eatIdentifier()));
/*     */     } 
/*     */     
/*  96 */     GenericSignature.TypeSignature[] params = new GenericSignature.TypeSignature[paramList.size()];
/*  97 */     paramList.toArray(params);
/*     */     
/*  99 */     returnType = parseFieldTypeSignature(true);
/* 100 */     if (returnType == null) {
/* 101 */       returnType = new GenericSignature.BaseTypeSignature(eatIdentifier());
/*     */     }
/* 103 */     List<GenericSignature.FieldTypeSignature> throwsList = new ArrayList<>();
/* 104 */     while (maybeEat("^")) {
/* 105 */       GenericSignature.FieldTypeSignature fsig = parseFieldTypeSignature(false);
/* 106 */       throwsList.add(fsig);
/*     */     } 
/* 108 */     GenericSignature.FieldTypeSignature[] throwsSigs = new GenericSignature.FieldTypeSignature[throwsList.size()];
/* 109 */     throwsList.toArray(throwsSigs);
/* 110 */     return new GenericSignature.MethodTypeSignature(formals, params, returnType, throwsSigs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericSignature.FieldTypeSignature parseAsFieldSignature(String sig) {
/* 118 */     this.inputString = sig;
/* 119 */     this.tokenStream = tokenize(sig);
/* 120 */     this.tokenIndex = 0;
/* 121 */     return parseFieldTypeSignature(false);
/*     */   }
/*     */   
/*     */   private GenericSignature.FormalTypeParameter parseFormalTypeParameter() {
/* 125 */     GenericSignature.FormalTypeParameter ftp = new GenericSignature.FormalTypeParameter();
/*     */     
/* 127 */     ftp.identifier = eatIdentifier();
/*     */     
/* 129 */     eat(":");
/* 130 */     ftp.classBound = parseFieldTypeSignature(true);
/* 131 */     if (ftp.classBound == null) {
/* 132 */       ftp.classBound = new GenericSignature.ClassTypeSignature("Ljava/lang/Object;", "Ljava/lang/Object");
/*     */     }
/*     */     
/* 135 */     List<GenericSignature.FieldTypeSignature> optionalBounds = new ArrayList<>();
/* 136 */     while (maybeEat(":")) {
/* 137 */       optionalBounds.add(parseFieldTypeSignature(false));
/*     */     }
/* 139 */     ftp.interfaceBounds = new GenericSignature.FieldTypeSignature[optionalBounds.size()];
/* 140 */     optionalBounds.toArray(ftp.interfaceBounds);
/* 141 */     return ftp;
/*     */   }
/*     */   
/*     */   private GenericSignature.FieldTypeSignature parseFieldTypeSignature(boolean isOptional) {
/* 145 */     if (isOptional)
/*     */     {
/* 147 */       if (!this.tokenStream[this.tokenIndex].startsWith("L") && !this.tokenStream[this.tokenIndex].startsWith("T") && 
/* 148 */         !this.tokenStream[this.tokenIndex].startsWith("[")) {
/* 149 */         return null;
/*     */       }
/*     */     }
/* 152 */     if (maybeEat("["))
/* 153 */       return parseArrayTypeSignature(); 
/* 154 */     if (this.tokenStream[this.tokenIndex].startsWith("L"))
/* 155 */       return parseClassTypeSignature(); 
/* 156 */     if (this.tokenStream[this.tokenIndex].startsWith("T")) {
/* 157 */       return parseTypeVariableSignature();
/*     */     }
/* 159 */     throw new IllegalStateException("Expecting [,L, or T, but found " + this.tokenStream[this.tokenIndex] + " while unpacking " + this.inputString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericSignature.ArrayTypeSignature parseArrayTypeSignature() {
/* 166 */     GenericSignature.FieldTypeSignature fieldType = parseFieldTypeSignature(true);
/* 167 */     if (fieldType != null) {
/* 168 */       return new GenericSignature.ArrayTypeSignature(fieldType);
/*     */     }
/*     */     
/* 171 */     return new GenericSignature.ArrayTypeSignature(new GenericSignature.BaseTypeSignature(eatIdentifier()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericSignature.ClassTypeSignature parseClassTypeSignature() {
/* 177 */     GenericSignature.SimpleClassTypeSignature outerType = null;
/* 178 */     GenericSignature.SimpleClassTypeSignature[] nestedTypes = new GenericSignature.SimpleClassTypeSignature[0];
/* 179 */     StringBuilder ret = new StringBuilder();
/* 180 */     String identifier = eatIdentifier();
/* 181 */     ret.append(identifier);
/* 182 */     while (maybeEat("/")) {
/* 183 */       ret.append("/");
/* 184 */       ret.append(eatIdentifier());
/*     */     } 
/* 186 */     identifier = ret.toString();
/*     */ 
/*     */     
/* 189 */     while (!maybeEat(";")) {
/* 190 */       if (this.tokenStream[this.tokenIndex].equals(".")) {
/*     */         
/* 192 */         outerType = new GenericSignature.SimpleClassTypeSignature(identifier);
/* 193 */         nestedTypes = parseNestedTypesHelper(ret); continue;
/* 194 */       }  if (this.tokenStream[this.tokenIndex].equals("<")) {
/* 195 */         ret.append("<");
/* 196 */         GenericSignature.TypeArgument[] tArgs = maybeParseTypeArguments();
/* 197 */         for (GenericSignature.TypeArgument tArg : tArgs) {
/* 198 */           ret.append(tArg.toString());
/*     */         }
/* 200 */         ret.append(">");
/* 201 */         outerType = new GenericSignature.SimpleClassTypeSignature(identifier, tArgs);
/* 202 */         nestedTypes = parseNestedTypesHelper(ret); continue;
/*     */       } 
/* 204 */       throw new IllegalStateException("Expecting .,<, or ;, but found " + this.tokenStream[this.tokenIndex] + " while unpacking " + this.inputString);
/*     */     } 
/*     */ 
/*     */     
/* 208 */     ret.append(";");
/* 209 */     if (outerType == null)
/* 210 */       outerType = new GenericSignature.SimpleClassTypeSignature(ret.toString()); 
/* 211 */     return new GenericSignature.ClassTypeSignature(ret.toString(), outerType, nestedTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericSignature.SimpleClassTypeSignature[] parseNestedTypesHelper(StringBuilder ret) {
/* 219 */     boolean brokenSignature = false;
/*     */     
/* 221 */     List<GenericSignature.SimpleClassTypeSignature> nestedTypeList = new ArrayList<>();
/* 222 */     while (maybeEat(".")) {
/* 223 */       ret.append(".");
/* 224 */       GenericSignature.SimpleClassTypeSignature sig = parseSimpleClassTypeSignature();
/* 225 */       if (this.tokenStream[this.tokenIndex].equals("/")) {
/* 226 */         if (!brokenSignature) {
/* 227 */           System.err.println("[See bug 406167] Bad class file signature encountered, nested types appear package qualified, ignoring those incorrect pieces. Signature: " + this.inputString);
/*     */         }
/* 229 */         brokenSignature = true;
/*     */ 
/*     */         
/* 232 */         this.tokenIndex++;
/* 233 */         while (this.tokenStream[this.tokenIndex + 1].equals("/")) {
/* 234 */           this.tokenIndex += 2;
/*     */         }
/*     */         
/* 237 */         sig = parseSimpleClassTypeSignature();
/*     */       } 
/* 239 */       ret.append(sig.toString());
/* 240 */       nestedTypeList.add(sig);
/*     */     } 
/* 242 */     GenericSignature.SimpleClassTypeSignature[] nestedTypes = new GenericSignature.SimpleClassTypeSignature[nestedTypeList.size()];
/* 243 */     nestedTypeList.toArray(nestedTypes);
/* 244 */     return nestedTypes;
/*     */   }
/*     */   
/*     */   private GenericSignature.SimpleClassTypeSignature parseSimpleClassTypeSignature() {
/* 248 */     String identifier = eatIdentifier();
/* 249 */     GenericSignature.TypeArgument[] tArgs = maybeParseTypeArguments();
/* 250 */     if (tArgs != null) {
/* 251 */       return new GenericSignature.SimpleClassTypeSignature(identifier, tArgs);
/*     */     }
/* 253 */     return new GenericSignature.SimpleClassTypeSignature(identifier);
/*     */   }
/*     */ 
/*     */   
/*     */   private GenericSignature.TypeArgument parseTypeArgument() {
/* 258 */     boolean isPlus = false;
/* 259 */     boolean isMinus = false;
/* 260 */     if (maybeEat("*"))
/* 261 */       return new GenericSignature.TypeArgument(); 
/* 262 */     if (maybeEat("+")) {
/* 263 */       isPlus = true;
/* 264 */     } else if (maybeEat("-")) {
/* 265 */       isMinus = true;
/*     */     } 
/* 267 */     GenericSignature.FieldTypeSignature sig = parseFieldTypeSignature(false);
/* 268 */     return new GenericSignature.TypeArgument(isPlus, isMinus, sig);
/*     */   }
/*     */   
/*     */   private GenericSignature.TypeArgument[] maybeParseTypeArguments() {
/* 272 */     if (maybeEat("<")) {
/* 273 */       List<GenericSignature.TypeArgument> typeArgs = new ArrayList<>();
/*     */       while (true) {
/* 275 */         GenericSignature.TypeArgument arg = parseTypeArgument();
/* 276 */         typeArgs.add(arg);
/* 277 */         if (maybeEat(">"))
/* 278 */         { GenericSignature.TypeArgument[] tArgs = new GenericSignature.TypeArgument[typeArgs.size()];
/* 279 */           typeArgs.toArray(tArgs);
/* 280 */           return tArgs; } 
/*     */       } 
/* 282 */     }  return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private GenericSignature.TypeVariableSignature parseTypeVariableSignature() {
/* 287 */     GenericSignature.TypeVariableSignature tv = new GenericSignature.TypeVariableSignature(eatIdentifier());
/* 288 */     eat(";");
/* 289 */     return tv;
/*     */   }
/*     */   
/*     */   private boolean maybeEat(String token) {
/* 293 */     if (this.tokenStream.length <= this.tokenIndex)
/* 294 */       return false; 
/* 295 */     if (this.tokenStream[this.tokenIndex].equals(token)) {
/* 296 */       this.tokenIndex++;
/* 297 */       return true;
/*     */     } 
/* 299 */     return false;
/*     */   }
/*     */   
/*     */   private void eat(String token) {
/* 303 */     if (!this.tokenStream[this.tokenIndex].equals(token)) {
/* 304 */       throw new IllegalStateException("Expecting " + token + " but found " + this.tokenStream[this.tokenIndex] + " while unpacking " + this.inputString);
/*     */     }
/*     */     
/* 307 */     this.tokenIndex++;
/*     */   }
/*     */   
/*     */   private String eatIdentifier() {
/* 311 */     return this.tokenStream[this.tokenIndex++];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] tokenize(String signatureString) {
/* 318 */     char[] chars = signatureString.toCharArray();
/* 319 */     int index = 0;
/* 320 */     List<String> tokens = new ArrayList<>();
/* 321 */     StringBuilder identifier = new StringBuilder();
/* 322 */     boolean inParens = false;
/* 323 */     boolean inArray = false;
/* 324 */     boolean couldSeePrimitive = false;
/*     */     while (true) {
/* 326 */       switch (chars[index]) {
/*     */         case '<':
/* 328 */           if (identifier.length() > 0)
/* 329 */             tokens.add(identifier.toString()); 
/* 330 */           identifier = new StringBuilder();
/* 331 */           tokens.add("<");
/*     */           break;
/*     */         case '>':
/* 334 */           if (identifier.length() > 0)
/* 335 */             tokens.add(identifier.toString()); 
/* 336 */           identifier = new StringBuilder();
/* 337 */           tokens.add(">");
/*     */           break;
/*     */         case ':':
/* 340 */           if (identifier.length() > 0)
/* 341 */             tokens.add(identifier.toString()); 
/* 342 */           identifier = new StringBuilder();
/* 343 */           tokens.add(":");
/*     */           break;
/*     */         case '/':
/* 346 */           if (identifier.length() > 0)
/* 347 */             tokens.add(identifier.toString()); 
/* 348 */           identifier = new StringBuilder();
/* 349 */           tokens.add("/");
/* 350 */           couldSeePrimitive = false;
/*     */           break;
/*     */         case ';':
/* 353 */           if (identifier.length() > 0)
/* 354 */             tokens.add(identifier.toString()); 
/* 355 */           identifier = new StringBuilder();
/* 356 */           tokens.add(";");
/* 357 */           couldSeePrimitive = true;
/* 358 */           inArray = false;
/*     */           break;
/*     */         case '^':
/* 361 */           if (identifier.length() > 0)
/* 362 */             tokens.add(identifier.toString()); 
/* 363 */           identifier = new StringBuilder();
/* 364 */           tokens.add("^");
/*     */           break;
/*     */         case '+':
/* 367 */           tokens.add("+");
/*     */           break;
/*     */         case '-':
/* 370 */           tokens.add("-");
/*     */           break;
/*     */         case '*':
/* 373 */           tokens.add("*");
/*     */           break;
/*     */         case '.':
/* 376 */           if (identifier.length() > 0)
/* 377 */             tokens.add(identifier.toString()); 
/* 378 */           identifier = new StringBuilder();
/* 379 */           couldSeePrimitive = false;
/* 380 */           tokens.add(".");
/*     */           break;
/*     */         case '(':
/* 383 */           tokens.add("(");
/* 384 */           inParens = true;
/* 385 */           couldSeePrimitive = true;
/*     */           break;
/*     */         case ')':
/* 388 */           tokens.add(")");
/* 389 */           inParens = false;
/*     */           break;
/*     */         case '[':
/* 392 */           tokens.add("[");
/* 393 */           couldSeePrimitive = true;
/* 394 */           inArray = true;
/*     */           break;
/*     */         case 'B':
/*     */         case 'C':
/*     */         case 'D':
/*     */         case 'F':
/*     */         case 'I':
/*     */         case 'J':
/*     */         case 'S':
/*     */         case 'V':
/*     */         case 'Z':
/* 405 */           if ((inParens || inArray) && couldSeePrimitive && identifier.length() == 0) {
/* 406 */             tokens.add(new String("" + chars[index]));
/*     */           } else {
/* 408 */             identifier.append(chars[index]);
/*     */           } 
/* 410 */           inArray = false;
/*     */           break;
/*     */         case 'L':
/* 413 */           couldSeePrimitive = false;
/*     */         
/*     */         default:
/* 416 */           identifier.append(chars[index]); break;
/*     */       } 
/* 418 */       if (++index >= chars.length) {
/* 419 */         if (identifier.length() > 0)
/* 420 */           tokens.add(identifier.toString()); 
/* 421 */         String[] tokenArray = new String[tokens.size()];
/* 422 */         tokens.toArray(tokenArray);
/* 423 */         return tokenArray;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\GenericSignatureParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */