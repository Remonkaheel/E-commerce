/*     */ package org.aspectj.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilClassLoader
/*     */   extends URLClassLoader
/*     */ {
/*     */   List<File> dirs;
/*     */   private URL[] urlsForDebugString;
/*     */   
/*     */   public UtilClassLoader(URL[] urls, File[] dirs) {
/*  39 */     super(urls);
/*  40 */     LangUtil.throwIaxIfNotAssignable((Object[])dirs, File.class, "dirs");
/*  41 */     this.urlsForDebugString = urls;
/*  42 */     List<File> dcopy = new ArrayList<>();
/*     */     
/*  44 */     if (!LangUtil.isEmpty((Object[])dirs)) {
/*  45 */       dcopy.addAll(Arrays.asList(dirs));
/*     */     }
/*  47 */     this.dirs = Collections.unmodifiableList(dcopy);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/*  52 */     return ClassLoader.getSystemResource(name);
/*     */   }
/*     */   
/*     */   public InputStream getResourceAsStream(String name) {
/*  56 */     return ClassLoader.getSystemResourceAsStream(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/*  64 */     ClassNotFoundException thrown = null;
/*  65 */     Class<?> result = findLoadedClass(name);
/*  66 */     if (null != result) {
/*  67 */       resolve = false;
/*     */     } else {
/*     */       try {
/*  70 */         result = findSystemClass(name);
/*  71 */       } catch (ClassNotFoundException e) {
/*  72 */         thrown = e;
/*     */       } 
/*     */     } 
/*  75 */     if (null == result) {
/*     */       try {
/*  77 */         result = super.loadClass(name, resolve);
/*  78 */       } catch (ClassNotFoundException e) {
/*  79 */         thrown = e;
/*     */       } 
/*  81 */       if (null != result) {
/*  82 */         return result;
/*     */       }
/*     */     } 
/*  85 */     if (null == result) {
/*  86 */       byte[] data = readClass(name);
/*  87 */       if (data != null) {
/*  88 */         result = defineClass(name, data, 0, data.length);
/*     */       }
/*     */     } 
/*     */     
/*  92 */     if (null == result) {
/*  93 */       throw (null != thrown) ? thrown : new ClassNotFoundException(name);
/*     */     }
/*  95 */     if (resolve) {
/*  96 */       resolveClass(result);
/*     */     }
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] readClass(String className) throws ClassNotFoundException {
/* 103 */     String fileName = className.replace('.', '/') + ".class";
/* 104 */     for (File dir : this.dirs) {
/* 105 */       File file = new File(dir, fileName);
/* 106 */       if (file.canRead()) {
/* 107 */         return getClassData(file);
/*     */       }
/*     */     } 
/* 110 */     return null;
/*     */   }
/*     */   
/*     */   private byte[] getClassData(File f) {
/*     */     try {
/* 115 */       FileInputStream stream = new FileInputStream(f);
/* 116 */       ByteArrayOutputStream out = new ByteArrayOutputStream(1000);
/* 117 */       byte[] b = new byte[4096];
/*     */       int n;
/* 119 */       while ((n = stream.read(b)) != -1) {
/* 120 */         out.write(b, 0, n);
/*     */       }
/* 122 */       stream.close();
/* 123 */       out.close();
/* 124 */       return out.toByteArray();
/* 125 */     } catch (IOException iOException) {
/*     */       
/* 127 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 132 */     return "UtilClassLoader(urls=" + 
/* 133 */       Arrays.<URL>asList(this.urlsForDebugString) + ", dirs=" + this.dirs + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspect\\util\UtilClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */