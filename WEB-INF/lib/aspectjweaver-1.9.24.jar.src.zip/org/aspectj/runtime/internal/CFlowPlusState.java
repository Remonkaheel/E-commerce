/*    */ package org.aspectj.runtime.internal;
/*    */ 
/*    */ import org.aspectj.runtime.CFlow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CFlowPlusState
/*    */   extends CFlow
/*    */ {
/*    */   private Object[] state;
/*    */   
/*    */   public CFlowPlusState(Object[] state) {
/* 21 */     this.state = state;
/*    */   }
/*    */   
/*    */   public CFlowPlusState(Object[] state, Object _aspect) {
/* 25 */     super(_aspect);
/* 26 */     this.state = state;
/*    */   }
/*    */   
/*    */   public Object get(int index) {
/* 30 */     return this.state[index];
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\CFlowPlusState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */