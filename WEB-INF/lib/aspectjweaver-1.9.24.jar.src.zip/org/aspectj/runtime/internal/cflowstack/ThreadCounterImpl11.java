/*    */ package org.aspectj.runtime.internal.cflowstack;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadCounterImpl11
/*    */   implements ThreadCounter
/*    */ {
/* 22 */   private Hashtable<Thread, Counter> counters = new Hashtable<>();
/*    */   
/*    */   private Thread cached_thread;
/*    */   private Counter cached_counter;
/* 26 */   private int change_count = 0;
/*    */   private static final int COLLECT_AT = 20000;
/*    */   private static final int MIN_COLLECT_AT = 100;
/*    */   
/*    */   static class Counter {
/* 31 */     protected int value = 0;
/*    */   }
/*    */   
/*    */   private synchronized Counter getThreadCounter() {
/* 35 */     if (Thread.currentThread() != this.cached_thread) {
/* 36 */       this.cached_thread = Thread.currentThread();
/* 37 */       this.cached_counter = this.counters.get(this.cached_thread);
/* 38 */       if (this.cached_counter == null) {
/* 39 */         this.cached_counter = new Counter();
/* 40 */         this.counters.put(this.cached_thread, this.cached_counter);
/*    */       } 
/* 42 */       this.change_count++;
/*    */       
/* 44 */       int size = Math.max(1, this.counters.size());
/* 45 */       if (this.change_count > Math.max(100, 20000 / size)) {
/* 46 */         List<Thread> dead_stacks = new ArrayList<>();
/* 47 */         for (Enumeration<Thread> e = this.counters.keys(); e.hasMoreElements(); ) {
/* 48 */           Thread t = e.nextElement();
/* 49 */           if (!t.isAlive()) dead_stacks.add(t); 
/*    */         } 
/* 51 */         for (Thread t : dead_stacks) {
/* 52 */           this.counters.remove(t);
/*    */         }
/* 54 */         this.change_count = 0;
/*    */       } 
/*    */     } 
/* 57 */     return this.cached_counter;
/*    */   }
/*    */   
/*    */   public void inc() {
/* 61 */     (getThreadCounter()).value++;
/*    */   }
/*    */   
/*    */   public void dec() {
/* 65 */     (getThreadCounter()).value--;
/*    */   }
/*    */   
/*    */   public boolean isNotZero() {
/* 69 */     return ((getThreadCounter()).value != 0);
/*    */   }
/*    */   
/*    */   public void removeThreadCounter() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\cflowstack\ThreadCounterImpl11.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */