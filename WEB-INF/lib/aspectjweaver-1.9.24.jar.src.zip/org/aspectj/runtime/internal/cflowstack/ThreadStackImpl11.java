/*    */ package org.aspectj.runtime.internal.cflowstack;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadStackImpl11
/*    */   implements ThreadStack
/*    */ {
/* 21 */   private Hashtable<Thread, Stack> stacks = new Hashtable<>();
/*    */   private Thread cached_thread;
/*    */   private Stack cached_stack;
/* 24 */   private int change_count = 0;
/*    */   private static final int COLLECT_AT = 20000;
/*    */   private static final int MIN_COLLECT_AT = 100;
/*    */   
/*    */   public synchronized Stack getThreadStack() {
/* 29 */     if (Thread.currentThread() != this.cached_thread) {
/* 30 */       this.cached_thread = Thread.currentThread();
/* 31 */       this.cached_stack = this.stacks.get(this.cached_thread);
/* 32 */       if (this.cached_stack == null) {
/* 33 */         this.cached_stack = new Stack();
/* 34 */         this.stacks.put(this.cached_thread, this.cached_stack);
/*    */       } 
/* 36 */       this.change_count++;
/*    */       
/* 38 */       int size = Math.max(1, this.stacks.size());
/* 39 */       if (this.change_count > Math.max(100, 20000 / size)) {
/* 40 */         Stack<Thread> dead_stacks = new Stack<>(); Enumeration<Thread> e;
/* 41 */         for (e = this.stacks.keys(); e.hasMoreElements(); ) {
/* 42 */           Thread t = e.nextElement();
/* 43 */           if (!t.isAlive()) dead_stacks.push(t); 
/*    */         } 
/* 45 */         for (e = dead_stacks.elements(); e.hasMoreElements(); ) {
/* 46 */           Thread t = e.nextElement();
/* 47 */           this.stacks.remove(t);
/*    */         } 
/* 49 */         this.change_count = 0;
/*    */       } 
/*    */     } 
/* 52 */     return this.cached_stack;
/*    */   }
/*    */   
/*    */   public void removeThreadStack() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\cflowstack\ThreadStackImpl11.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */