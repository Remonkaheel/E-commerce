package org.aspectj.runtime.internal.cflowstack;

import java.util.Stack;

public interface ThreadStack {
  Stack getThreadStack();
  
  void removeThreadStack();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\cflowstack\ThreadStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */