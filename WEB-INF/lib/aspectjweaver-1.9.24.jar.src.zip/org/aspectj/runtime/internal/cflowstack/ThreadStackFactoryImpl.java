/*    */ package org.aspectj.runtime.internal.cflowstack;
/*    */ 
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadStackFactoryImpl
/*    */   implements ThreadStackFactory
/*    */ {
/*    */   private static class ThreadStackImpl
/*    */     extends ThreadLocal<Stack>
/*    */     implements ThreadStack
/*    */   {
/*    */     private ThreadStackImpl() {}
/*    */     
/*    */     public Stack initialValue() {
/* 21 */       return new Stack();
/*    */     }
/*    */     public Stack getThreadStack() {
/* 24 */       return get();
/*    */     }
/*    */     public void removeThreadStack() {
/* 27 */       remove();
/*    */     }
/*    */   }
/*    */   
/*    */   public ThreadStack getNewThreadStack() {
/* 32 */     return new ThreadStackImpl();
/*    */   }
/*    */   
/*    */   private static class ThreadCounterImpl extends ThreadLocal<ThreadCounterImpl.Counter> implements ThreadCounter { private ThreadCounterImpl() {}
/*    */     
/*    */     public Counter initialValue() {
/* 38 */       return new Counter();
/*    */     }
/*    */     public Counter getThreadCounter() {
/* 41 */       return get();
/*    */     }
/*    */     
/*    */     public void removeThreadCounter() {
/* 45 */       remove();
/*    */     }
/*    */     
/* 48 */     public void inc() { (getThreadCounter()).value++; }
/* 49 */     public void dec() { (getThreadCounter()).value--; } public boolean isNotZero() {
/* 50 */       return ((getThreadCounter()).value != 0);
/*    */     }
/*    */     static class Counter { Counter() {
/* 53 */         this.value = 0;
/*    */       }
/*    */       protected int value; } }
/*    */   
/*    */   public ThreadCounter getNewThreadCounter() {
/* 58 */     return new ThreadCounterImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\cflowstack\ThreadStackFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */