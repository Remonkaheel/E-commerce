/*    */ package org.aspectj.runtime.internal.cflowstack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadStackFactoryImpl11
/*    */   implements ThreadStackFactory
/*    */ {
/*    */   public ThreadStack getNewThreadStack() {
/* 19 */     return new ThreadStackImpl11();
/*    */   }
/*    */   
/*    */   public ThreadCounter getNewThreadCounter() {
/* 23 */     return new ThreadCounterImpl11();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\cflowstack\ThreadStackFactoryImpl11.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */