package org.aspectj.runtime.internal.cflowstack;

public interface ThreadCounter {
  void inc();
  
  void dec();
  
  boolean isNotZero();
  
  void removeThreadCounter();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\cflowstack\ThreadCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */