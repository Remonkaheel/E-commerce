/*     */ package org.aspectj.runtime.internal;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import org.aspectj.lang.NoAspectBoundException;
/*     */ import org.aspectj.runtime.CFlow;
/*     */ import org.aspectj.runtime.internal.cflowstack.ThreadStack;
/*     */ import org.aspectj.runtime.internal.cflowstack.ThreadStackFactory;
/*     */ import org.aspectj.runtime.internal.cflowstack.ThreadStackFactoryImpl;
/*     */ import org.aspectj.runtime.internal.cflowstack.ThreadStackFactoryImpl11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CFlowStack
/*     */ {
/*     */   private static ThreadStackFactory tsFactory;
/*     */   
/*     */   static {
/*  59 */     selectFactoryForVMVersion();
/*     */   }
/*     */ 
/*     */   
/*  63 */   private ThreadStack stackProxy = tsFactory.getNewThreadStack();
/*     */ 
/*     */   
/*     */   private Stack getThreadStack() {
/*  67 */     return this.stackProxy.getThreadStack();
/*     */   }
/*     */ 
/*     */   
/*     */   public void push(Object obj) {
/*  72 */     getThreadStack().push(obj);
/*     */   }
/*     */   
/*     */   public void pushInstance(Object obj) {
/*  76 */     getThreadStack().push(new CFlow(obj));
/*     */   }
/*     */   
/*     */   public void push(Object[] obj) {
/*  80 */     getThreadStack().push(new CFlowPlusState(obj));
/*     */   }
/*     */   
/*     */   public void pop() {
/*  84 */     Stack<?> s = getThreadStack();
/*  85 */     s.pop();
/*  86 */     if (s.isEmpty()) {
/*  87 */       this.stackProxy.removeThreadStack();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object peek() {
/*  92 */     Stack<?> stack = getThreadStack();
/*  93 */     if (stack.isEmpty()) throw new NoAspectBoundException(); 
/*  94 */     return stack.peek();
/*     */   }
/*     */   
/*     */   public Object get(int index) {
/*  98 */     CFlow cf = peekCFlow();
/*  99 */     return (null == cf) ? null : cf.get(index);
/*     */   }
/*     */   
/*     */   public Object peekInstance() {
/* 103 */     CFlow cf = peekCFlow();
/* 104 */     if (cf != null) return cf.getAspect(); 
/* 105 */     throw new NoAspectBoundException();
/*     */   }
/*     */   
/*     */   public CFlow peekCFlow() {
/* 109 */     Stack<?> stack = getThreadStack();
/* 110 */     if (stack.isEmpty()) return null; 
/* 111 */     return (CFlow)stack.peek();
/*     */   }
/*     */   
/*     */   public CFlow peekTopCFlow() {
/* 115 */     Stack<?> stack = getThreadStack();
/* 116 */     if (stack.isEmpty()) return null; 
/* 117 */     return (CFlow)stack.elementAt(0);
/*     */   }
/*     */   
/*     */   public boolean isValid() {
/* 121 */     return !getThreadStack().isEmpty();
/*     */   }
/*     */   
/* 124 */   private static ThreadStackFactory getThreadLocalStackFactory() { return (ThreadStackFactory)new ThreadStackFactoryImpl(); } private static ThreadStackFactory getThreadLocalStackFactoryFor11() {
/* 125 */     return (ThreadStackFactory)new ThreadStackFactoryImpl11();
/*     */   }
/*     */   private static void selectFactoryForVMVersion() {
/* 128 */     String override = getSystemPropertyWithoutSecurityException("aspectj.runtime.cflowstack.usethreadlocal", "unspecified");
/* 129 */     boolean useThreadLocalImplementation = false;
/* 130 */     if (override.equals("unspecified")) {
/* 131 */       String v = System.getProperty("java.class.version", "0.0");
/*     */       
/* 133 */       useThreadLocalImplementation = (v.compareTo("46.0") >= 0);
/*     */     } else {
/* 135 */       useThreadLocalImplementation = (override.equals("yes") || override.equals("true"));
/*     */     } 
/*     */     
/* 138 */     if (useThreadLocalImplementation) {
/* 139 */       tsFactory = getThreadLocalStackFactory();
/*     */     } else {
/* 141 */       tsFactory = getThreadLocalStackFactoryFor11();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getSystemPropertyWithoutSecurityException(String aPropertyName, String aDefaultValue) {
/*     */     try {
/* 147 */       return System.getProperty(aPropertyName, aDefaultValue);
/*     */     }
/* 149 */     catch (SecurityException ex) {
/* 150 */       return aDefaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getThreadStackFactoryClassName() {
/* 157 */     return tsFactory.getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\CFlowStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */