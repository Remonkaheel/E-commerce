/*     */ package org.aspectj.runtime.internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Conversions
/*     */ {
/*     */   public static Object intObject(int i) {
/*  23 */     return Integer.valueOf(i);
/*     */   }
/*     */   public static Object shortObject(short i) {
/*  26 */     return Short.valueOf(i);
/*     */   }
/*     */   public static Object byteObject(byte i) {
/*  29 */     return Byte.valueOf(i);
/*     */   }
/*     */   public static Object charObject(char i) {
/*  32 */     return Character.valueOf(i);
/*     */   }
/*     */   public static Object longObject(long i) {
/*  35 */     return Long.valueOf(i);
/*     */   }
/*     */   public static Object floatObject(float i) {
/*  38 */     return Float.valueOf(i);
/*     */   }
/*     */   public static Object doubleObject(double i) {
/*  41 */     return Double.valueOf(i);
/*     */   }
/*     */   public static Object booleanObject(boolean i) {
/*  44 */     return Boolean.valueOf(i);
/*     */   }
/*     */   public static Object voidObject() {
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int intValue(Object o) {
/*  52 */     if (o == null)
/*  53 */       return 0; 
/*  54 */     if (o instanceof Number) {
/*  55 */       return ((Number)o).intValue();
/*     */     }
/*  57 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to int");
/*     */   }
/*     */ 
/*     */   
/*     */   public static long longValue(Object o) {
/*  62 */     if (o == null)
/*  63 */       return 0L; 
/*  64 */     if (o instanceof Number) {
/*  65 */       return ((Number)o).longValue();
/*     */     }
/*  67 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to long");
/*     */   }
/*     */ 
/*     */   
/*     */   public static float floatValue(Object o) {
/*  72 */     if (o == null)
/*  73 */       return 0.0F; 
/*  74 */     if (o instanceof Number) {
/*  75 */       return ((Number)o).floatValue();
/*     */     }
/*  77 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to float");
/*     */   }
/*     */ 
/*     */   
/*     */   public static double doubleValue(Object o) {
/*  82 */     if (o == null)
/*  83 */       return 0.0D; 
/*  84 */     if (o instanceof Number) {
/*  85 */       return ((Number)o).doubleValue();
/*     */     }
/*  87 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to double");
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte byteValue(Object o) {
/*  92 */     if (o == null)
/*  93 */       return 0; 
/*  94 */     if (o instanceof Number) {
/*  95 */       return ((Number)o).byteValue();
/*     */     }
/*  97 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to byte");
/*     */   }
/*     */ 
/*     */   
/*     */   public static short shortValue(Object o) {
/* 102 */     if (o == null)
/* 103 */       return 0; 
/* 104 */     if (o instanceof Number) {
/* 105 */       return ((Number)o).shortValue();
/*     */     }
/* 107 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to short");
/*     */   }
/*     */ 
/*     */   
/*     */   public static char charValue(Object o) {
/* 112 */     if (o == null)
/* 113 */       return Character.MIN_VALUE; 
/* 114 */     if (o instanceof Character) {
/* 115 */       return ((Character)o).charValue();
/*     */     }
/* 117 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to char");
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean booleanValue(Object o) {
/* 122 */     if (o == null)
/* 123 */       return false; 
/* 124 */     if (o instanceof Boolean) {
/* 125 */       return ((Boolean)o).booleanValue();
/*     */     }
/* 127 */     throw new ClassCastException(o.getClass().getName() + " can not be converted to boolean");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object voidValue(Object o) {
/* 136 */     if (o == null) {
/* 137 */       return o;
/*     */     }
/*     */     
/* 140 */     return o;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\Conversions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */