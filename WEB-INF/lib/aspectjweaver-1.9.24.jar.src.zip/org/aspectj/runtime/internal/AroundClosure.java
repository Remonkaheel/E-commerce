/*     */ package org.aspectj.runtime.internal;
/*     */ 
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AroundClosure
/*     */ {
/*     */   protected Object[] state;
/*  28 */   protected int bitflags = 1048576;
/*     */   
/*     */   protected Object[] preInitializationState;
/*     */   
/*     */   public AroundClosure() {}
/*     */   
/*     */   public AroundClosure(Object[] state) {
/*  35 */     this.state = state;
/*     */   }
/*     */   public int getFlags() {
/*  38 */     return this.bitflags;
/*     */   }
/*     */   public Object[] getState() {
/*  41 */     return this.state;
/*     */   }
/*     */   
/*     */   public Object[] getPreInitializationState() {
/*  45 */     return this.preInitializationState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object run(Object[] paramArrayOfObject) throws Throwable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProceedingJoinPoint linkClosureAndJoinPoint() {
/*  63 */     ProceedingJoinPoint jp = (ProceedingJoinPoint)this.state[this.state.length - 1];
/*  64 */     jp.set$AroundClosure(this);
/*  65 */     return jp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProceedingJoinPoint linkStackClosureAndJoinPoint(int flags) {
/*  77 */     ProceedingJoinPoint jp = (ProceedingJoinPoint)this.state[this.state.length - 1];
/*  78 */     jp.stack$AroundClosure(this);
/*  79 */     this.bitflags = flags;
/*  80 */     return jp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProceedingJoinPoint linkClosureAndJoinPoint(int flags) {
/*  92 */     ProceedingJoinPoint jp = (ProceedingJoinPoint)this.state[this.state.length - 1];
/*  93 */     jp.set$AroundClosure(this);
/*  94 */     this.bitflags = flags;
/*  95 */     return jp;
/*     */   }
/*     */   
/*     */   public void unlink() {
/*  99 */     ProceedingJoinPoint jp = (ProceedingJoinPoint)this.state[this.state.length - 1];
/* 100 */     jp.stack$AroundClosure(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\AroundClosure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */