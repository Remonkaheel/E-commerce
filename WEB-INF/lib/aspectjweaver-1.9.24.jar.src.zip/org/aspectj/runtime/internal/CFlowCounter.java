/*    */ package org.aspectj.runtime.internal;
/*    */ 
/*    */ import org.aspectj.runtime.internal.cflowstack.ThreadCounter;
/*    */ import org.aspectj.runtime.internal.cflowstack.ThreadStackFactory;
/*    */ import org.aspectj.runtime.internal.cflowstack.ThreadStackFactoryImpl;
/*    */ import org.aspectj.runtime.internal.cflowstack.ThreadStackFactoryImpl11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CFlowCounter
/*    */ {
/*    */   private static ThreadStackFactory tsFactory;
/*    */   
/*    */   static {
/* 29 */     selectFactoryForVMVersion();
/*    */   }
/*    */ 
/*    */   
/* 33 */   private ThreadCounter flowHeightHandler = tsFactory.getNewThreadCounter();
/*    */ 
/*    */   
/*    */   public void inc() {
/* 37 */     this.flowHeightHandler.inc();
/*    */   }
/*    */   
/*    */   public void dec() {
/* 41 */     this.flowHeightHandler.dec();
/* 42 */     if (!this.flowHeightHandler.isNotZero()) {
/* 43 */       this.flowHeightHandler.removeThreadCounter();
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isValid() {
/* 48 */     return this.flowHeightHandler.isNotZero();
/*    */   }
/*    */   
/*    */   private static ThreadStackFactory getThreadLocalStackFactory() {
/* 52 */     return (ThreadStackFactory)new ThreadStackFactoryImpl(); } private static ThreadStackFactory getThreadLocalStackFactoryFor11() {
/* 53 */     return (ThreadStackFactory)new ThreadStackFactoryImpl11();
/*    */   }
/*    */   private static void selectFactoryForVMVersion() {
/* 56 */     String override = getSystemPropertyWithoutSecurityException("aspectj.runtime.cflowstack.usethreadlocal", "unspecified");
/* 57 */     boolean useThreadLocalImplementation = false;
/* 58 */     if (override.equals("unspecified")) {
/* 59 */       String v = System.getProperty("java.class.version", "0.0");
/*    */       
/* 61 */       useThreadLocalImplementation = (v.compareTo("46.0") >= 0);
/*    */     } else {
/* 63 */       useThreadLocalImplementation = (override.equals("yes") || override.equals("true"));
/*    */     } 
/*    */     
/* 66 */     if (useThreadLocalImplementation) {
/* 67 */       tsFactory = getThreadLocalStackFactory();
/*    */     } else {
/* 69 */       tsFactory = getThreadLocalStackFactoryFor11();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private static String getSystemPropertyWithoutSecurityException(String aPropertyName, String aDefaultValue) {
/*    */     try {
/* 76 */       return System.getProperty(aPropertyName, aDefaultValue);
/*    */     }
/* 78 */     catch (SecurityException ex) {
/* 79 */       return aDefaultValue;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getThreadStackFactoryClassName() {
/* 85 */     return tsFactory.getClass().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\internal\CFlowCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */