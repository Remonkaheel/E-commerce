/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Modifier;
/*    */ import org.aspectj.lang.reflect.InitializerSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InitializerSignatureImpl
/*    */   extends CodeSignatureImpl
/*    */   implements InitializerSignature
/*    */ {
/*    */   private Constructor<?> constructor;
/*    */   
/*    */   InitializerSignatureImpl(int modifiers, Class<?> declaringType) {
/* 26 */     super(modifiers, Modifier.isStatic(modifiers) ? "<clinit>" : "<init>", declaringType, EMPTY_CLASS_ARRAY, EMPTY_STRING_ARRAY, EMPTY_CLASS_ARRAY);
/*    */   }
/*    */ 
/*    */   
/*    */   InitializerSignatureImpl(String stringRep) {
/* 31 */     super(stringRep);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 35 */     return Modifier.isStatic(getModifiers()) ? "<clinit>" : "<init>";
/*    */   }
/*    */   
/*    */   protected String createToString(StringMaker sm) {
/* 39 */     StringBuilder buf = new StringBuilder();
/* 40 */     buf.append(sm.makeModifiersString(getModifiers()));
/* 41 */     buf.append(sm.makePrimaryTypeName(getDeclaringType(), getDeclaringTypeName()));
/* 42 */     buf.append(".");
/* 43 */     buf.append(getName());
/* 44 */     return buf.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Constructor getInitializer() {
/* 51 */     if (this.constructor == null) {
/*    */       try {
/* 53 */         this.constructor = getDeclaringType().getDeclaredConstructor(getParameterTypes());
/* 54 */       } catch (Exception exception) {}
/*    */     }
/*    */ 
/*    */     
/* 58 */     return this.constructor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\InitializerSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */