/*     */ package org.aspectj.runtime.reflect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.Signature;
/*     */ import org.aspectj.lang.reflect.AdviceSignature;
/*     */ import org.aspectj.lang.reflect.CatchClauseSignature;
/*     */ import org.aspectj.lang.reflect.ConstructorSignature;
/*     */ import org.aspectj.lang.reflect.FieldSignature;
/*     */ import org.aspectj.lang.reflect.InitializerSignature;
/*     */ import org.aspectj.lang.reflect.LockSignature;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ import org.aspectj.lang.reflect.SourceLocation;
/*     */ import org.aspectj.lang.reflect.UnlockSignature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Factory
/*     */ {
/*     */   Class<?> lexicalClass;
/*     */   ClassLoader lookupClassLoader;
/*     */   String filename;
/*     */   int count;
/*  43 */   private static final Class[] NO_TYPES = new Class[0];
/*  44 */   private static final String[] NO_STRINGS = new String[0];
/*     */   
/*  46 */   static Hashtable<String, Class<?>> prims = new Hashtable<>();
/*     */   static {
/*  48 */     prims.put("void", void.class);
/*  49 */     prims.put("boolean", boolean.class);
/*  50 */     prims.put("byte", byte.class);
/*  51 */     prims.put("char", char.class);
/*  52 */     prims.put("short", short.class);
/*  53 */     prims.put("int", int.class);
/*  54 */     prims.put("long", long.class);
/*  55 */     prims.put("float", float.class);
/*  56 */     prims.put("double", double.class);
/*     */   }
/*     */   
/*     */   static Class<?> makeClass(String s, ClassLoader loader) {
/*  60 */     if (s.equals("*"))
/*  61 */       return null; 
/*  62 */     Class<?> ret = prims.get(s);
/*  63 */     if (ret != null) {
/*  64 */       return ret;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  69 */       if (loader == null) {
/*  70 */         return Class.forName(s);
/*     */       }
/*     */ 
/*     */       
/*  74 */       return Class.forName(s, false, loader);
/*     */     }
/*  76 */     catch (ClassNotFoundException e) {
/*     */ 
/*     */       
/*  79 */       return ClassNotFoundException.class;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Factory(String filename, Class<?> lexicalClass) {
/*  85 */     this.filename = filename;
/*  86 */     this.lexicalClass = lexicalClass;
/*  87 */     this.count = 0;
/*  88 */     this.lookupClassLoader = lexicalClass.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart makeSJP(String kind, String modifiers, String methodName, String declaringType, String paramTypes, String paramNames, String exceptionTypes, String returnType, int l) {
/*  99 */     MethodSignature methodSignature = makeMethodSig(modifiers, methodName, declaringType, paramTypes, paramNames, exceptionTypes, returnType);
/* 100 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, (Signature)methodSignature, makeSourceLoc(l, -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart makeSJP(String kind, String modifiers, String methodName, String declaringType, String paramTypes, String paramNames, String returnType, int l) {
/* 112 */     MethodSignature methodSignature = makeMethodSig(modifiers, methodName, declaringType, paramTypes, paramNames, "", returnType);
/* 113 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, (Signature)methodSignature, makeSourceLoc(l, -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart makeMethodSJP(String kind, int modifiers, String methodName, Class declaringType, Class[] paramTypes, String[] paramNames, Class[] exceptionTypes, Class returnType, int line) {
/* 120 */     MethodSignature methodSignature = makeMethodSig(modifiers, methodName, declaringType, (paramTypes == null) ? NO_TYPES : paramTypes, 
/* 121 */         (paramNames == null) ? NO_STRINGS : paramNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes, (returnType == null) ? void.class : returnType);
/* 122 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, (Signature)methodSignature, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeMethodESJP(String kind, int modifiers, String methodName, Class declaringType, Class[] paramTypes, String[] paramNames, Class[] exceptionTypes, Class returnType, int line) {
/* 126 */     MethodSignature methodSignature = makeMethodSig(modifiers, methodName, declaringType, (paramTypes == null) ? NO_TYPES : paramTypes, 
/* 127 */         (paramNames == null) ? NO_STRINGS : paramNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes, (returnType == null) ? void.class : returnType);
/* 128 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, (Signature)methodSignature, makeSourceLoc(line, -1));
/*     */   }
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart makeConstructorSJP(String kind, int modifiers, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, int line) {
/* 133 */     ConstructorSignatureImpl sig = new ConstructorSignatureImpl(modifiers, declaringType, (parameterTypes == null) ? NO_TYPES : parameterTypes, (parameterNames == null) ? NO_STRINGS : parameterNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes);
/* 134 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */ 
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeConstructorESJP(String kind, int modifiers, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, int line) {
/* 139 */     ConstructorSignatureImpl sig = new ConstructorSignatureImpl(modifiers, declaringType, (parameterTypes == null) ? NO_TYPES : parameterTypes, (parameterNames == null) ? NO_STRINGS : parameterNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes);
/* 140 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeCatchClauseSJP(String kind, Class<?> declaringType, Class<?> parameterType, String parameterName, int line) {
/* 144 */     CatchClauseSignatureImpl sig = new CatchClauseSignatureImpl(declaringType, parameterType, (parameterName == null) ? "" : parameterName);
/* 145 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeCatchClauseESJP(String kind, Class<?> declaringType, Class<?> parameterType, String parameterName, int line) {
/* 149 */     CatchClauseSignatureImpl sig = new CatchClauseSignatureImpl(declaringType, parameterType, (parameterName == null) ? "" : parameterName);
/* 150 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeFieldSJP(String kind, int modifiers, String name, Class<?> declaringType, Class<?> fieldType, int line) {
/* 154 */     FieldSignatureImpl sig = new FieldSignatureImpl(modifiers, name, declaringType, fieldType);
/* 155 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeFieldESJP(String kind, int modifiers, String name, Class<?> declaringType, Class<?> fieldType, int line) {
/* 159 */     FieldSignatureImpl sig = new FieldSignatureImpl(modifiers, name, declaringType, fieldType);
/* 160 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeInitializerSJP(String kind, int modifiers, Class<?> declaringType, int line) {
/* 164 */     InitializerSignatureImpl sig = new InitializerSignatureImpl(modifiers, declaringType);
/* 165 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeInitializerESJP(String kind, int modifiers, Class<?> declaringType, int line) {
/* 169 */     InitializerSignatureImpl sig = new InitializerSignatureImpl(modifiers, declaringType);
/* 170 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeLockSJP(String kind, Class<?> declaringType, int line) {
/* 174 */     LockSignatureImpl sig = new LockSignatureImpl(declaringType);
/* 175 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeLockESJP(String kind, Class<?> declaringType, int line) {
/* 179 */     LockSignatureImpl sig = new LockSignatureImpl(declaringType);
/* 180 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeUnlockSJP(String kind, Class<?> declaringType, int line) {
/* 184 */     UnlockSignatureImpl sig = new UnlockSignatureImpl(declaringType);
/* 185 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeUnlockESJP(String kind, Class<?> declaringType, int line) {
/* 189 */     UnlockSignatureImpl sig = new UnlockSignatureImpl(declaringType);
/* 190 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart makeAdviceSJP(String kind, int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, Class<?> returnType, int line) {
/* 199 */     AdviceSignatureImpl sig = new AdviceSignatureImpl(modifiers, name, declaringType, (parameterTypes == null) ? NO_TYPES : parameterTypes, (parameterNames == null) ? NO_STRINGS : parameterNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes, (returnType == null) ? void.class : returnType);
/* 200 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeAdviceESJP(String kind, int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, Class<?> returnType, int line) {
/* 209 */     AdviceSignatureImpl sig = new AdviceSignatureImpl(modifiers, name, declaringType, (parameterTypes == null) ? NO_TYPES : parameterTypes, (parameterNames == null) ? NO_STRINGS : parameterNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes, (returnType == null) ? void.class : returnType);
/* 210 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(line, -1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart makeSJP(String kind, Signature sig, SourceLocation loc) {
/* 216 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, loc);
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeSJP(String kind, Signature sig, int l, int c) {
/* 220 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(l, c));
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart makeSJP(String kind, Signature sig, int l) {
/* 224 */     return new JoinPointImpl.StaticPartImpl(this.count++, kind, sig, makeSourceLoc(l, -1));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeESJP(String kind, Signature sig, SourceLocation loc) {
/* 228 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, loc);
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeESJP(String kind, Signature sig, int l, int c) {
/* 232 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(l, c));
/*     */   }
/*     */   
/*     */   public JoinPoint.EnclosingStaticPart makeESJP(String kind, Signature sig, int l) {
/* 236 */     return new JoinPointImpl.EnclosingStaticPartImpl(this.count++, kind, sig, makeSourceLoc(l, -1));
/*     */   }
/*     */   
/*     */   public static JoinPoint.StaticPart makeEncSJP(Member member) {
/* 240 */     Signature sig = null;
/* 241 */     String kind = null;
/* 242 */     if (member instanceof Method) {
/* 243 */       Method method = (Method)member;
/*     */ 
/*     */       
/* 246 */       sig = new MethodSignatureImpl(method.getModifiers(), method.getName(), method.getDeclaringClass(), method.getParameterTypes(), new String[(method.getParameterTypes()).length], method.getExceptionTypes(), method.getReturnType());
/* 247 */       kind = "method-execution";
/* 248 */     } else if (member instanceof Constructor) {
/* 249 */       Constructor<?> cons = (Constructor)member;
/*     */       
/* 251 */       sig = new ConstructorSignatureImpl(cons.getModifiers(), cons.getDeclaringClass(), cons.getParameterTypes(), new String[(cons.getParameterTypes()).length], cons.getExceptionTypes());
/* 252 */       kind = "constructor-execution";
/*     */     } else {
/* 254 */       throw new IllegalArgumentException("member must be either a method or constructor");
/*     */     } 
/* 256 */     return new JoinPointImpl.EnclosingStaticPartImpl(-1, kind, sig, null);
/*     */   }
/*     */   
/* 259 */   private static Object[] NO_ARGS = new Object[0];
/*     */   
/*     */   public static JoinPoint makeJP(JoinPoint.StaticPart staticPart, Object _this, Object target) {
/* 262 */     return (JoinPoint)new JoinPointImpl(staticPart, _this, target, NO_ARGS);
/*     */   }
/*     */   
/*     */   public static JoinPoint makeJP(JoinPoint.StaticPart staticPart, Object _this, Object target, Object arg0) {
/* 266 */     return (JoinPoint)new JoinPointImpl(staticPart, _this, target, new Object[] { arg0 });
/*     */   }
/*     */   
/*     */   public static JoinPoint makeJP(JoinPoint.StaticPart staticPart, Object _this, Object target, Object arg0, Object arg1) {
/* 270 */     return (JoinPoint)new JoinPointImpl(staticPart, _this, target, new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */   public static JoinPoint makeJP(JoinPoint.StaticPart staticPart, Object _this, Object target, Object[] args) {
/* 274 */     return (JoinPoint)new JoinPointImpl(staticPart, _this, target, args);
/*     */   }
/*     */   
/*     */   public MethodSignature makeMethodSig(String stringRep) {
/* 278 */     MethodSignatureImpl ret = new MethodSignatureImpl(stringRep);
/* 279 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 280 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodSignature makeMethodSig(String modifiers, String methodName, String declaringType, String paramTypes, String paramNames, String exceptionTypes, String returnType) {
/* 285 */     Class<?> declaringTypeClass = makeClass(declaringType, this.lookupClassLoader);
/* 286 */     return makeMethodSig(modifiers, methodName, declaringTypeClass, paramTypes, paramNames, exceptionTypes, returnType);
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodSignature makeMethodSig(String modifiers, String methodName, Class<?> declaringTypeClass, String paramTypes, String paramNames, String exceptionTypes, String returnType) {
/* 291 */     int modifiersAsInt = Integer.parseInt(modifiers, 16);
/*     */     
/* 293 */     StringTokenizer st = new StringTokenizer(paramTypes, ":");
/* 294 */     int numParams = st.countTokens();
/* 295 */     Class[] paramTypeClasses = new Class[numParams];
/* 296 */     for (int i = 0; i < numParams; i++) {
/* 297 */       paramTypeClasses[i] = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     }
/* 299 */     st = new StringTokenizer(paramNames, ":");
/* 300 */     numParams = st.countTokens();
/* 301 */     String[] paramNamesArray = new String[numParams];
/* 302 */     for (int j = 0; j < numParams; j++) {
/* 303 */       paramNamesArray[j] = st.nextToken();
/*     */     }
/* 305 */     st = new StringTokenizer(exceptionTypes, ":");
/* 306 */     numParams = st.countTokens();
/* 307 */     Class[] exceptionTypeClasses = new Class[numParams];
/* 308 */     for (int k = 0; k < numParams; k++) {
/* 309 */       exceptionTypeClasses[k] = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     }
/* 311 */     Class<?> returnTypeClass = makeClass(returnType, this.lookupClassLoader);
/*     */     
/* 313 */     MethodSignatureImpl ret = new MethodSignatureImpl(modifiersAsInt, methodName, declaringTypeClass, paramTypeClasses, paramNamesArray, exceptionTypeClasses, returnTypeClass);
/*     */ 
/*     */     
/* 316 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodSignature makeMethodSig(int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, Class<?> returnType) {
/* 322 */     MethodSignatureImpl ret = new MethodSignatureImpl(modifiers, name, declaringType, (parameterTypes == null) ? NO_TYPES : parameterTypes, parameterNames, (exceptionTypes == null) ? NO_TYPES : exceptionTypes, returnType);
/* 323 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 324 */     return ret;
/*     */   }
/*     */   
/*     */   public ConstructorSignature makeConstructorSig(String stringRep) {
/* 328 */     ConstructorSignatureImpl ret = new ConstructorSignatureImpl(stringRep);
/* 329 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 330 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConstructorSignature makeConstructorSig(String modifiers, String declaringType, String paramTypes, String paramNames, String exceptionTypes) {
/* 335 */     int modifiersAsInt = Integer.parseInt(modifiers, 16);
/*     */     
/* 337 */     Class<?> declaringTypeClass = makeClass(declaringType, this.lookupClassLoader);
/*     */     
/* 339 */     StringTokenizer st = new StringTokenizer(paramTypes, ":");
/* 340 */     int numParams = st.countTokens();
/* 341 */     Class[] paramTypeClasses = new Class[numParams];
/* 342 */     for (int i = 0; i < numParams; i++) {
/* 343 */       paramTypeClasses[i] = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     }
/* 345 */     st = new StringTokenizer(paramNames, ":");
/* 346 */     numParams = st.countTokens();
/* 347 */     String[] paramNamesArray = new String[numParams];
/* 348 */     for (int j = 0; j < numParams; j++) {
/* 349 */       paramNamesArray[j] = st.nextToken();
/*     */     }
/* 351 */     st = new StringTokenizer(exceptionTypes, ":");
/* 352 */     numParams = st.countTokens();
/* 353 */     Class[] exceptionTypeClasses = new Class[numParams];
/* 354 */     for (int k = 0; k < numParams; k++) {
/* 355 */       exceptionTypeClasses[k] = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     }
/* 357 */     ConstructorSignatureImpl ret = new ConstructorSignatureImpl(modifiersAsInt, declaringTypeClass, paramTypeClasses, paramNamesArray, exceptionTypeClasses);
/*     */     
/* 359 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 360 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConstructorSignature makeConstructorSig(int modifiers, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes) {
/* 365 */     ConstructorSignatureImpl ret = new ConstructorSignatureImpl(modifiers, declaringType, parameterTypes, parameterNames, exceptionTypes);
/*     */     
/* 367 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 368 */     return ret;
/*     */   }
/*     */   
/*     */   public FieldSignature makeFieldSig(String stringRep) {
/* 372 */     FieldSignatureImpl ret = new FieldSignatureImpl(stringRep);
/* 373 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 374 */     return ret;
/*     */   }
/*     */   
/*     */   public FieldSignature makeFieldSig(String modifiers, String name, String declaringType, String fieldType) {
/* 378 */     int modifiersAsInt = Integer.parseInt(modifiers, 16);
/* 379 */     Class<?> declaringTypeClass = makeClass(declaringType, this.lookupClassLoader);
/* 380 */     Class<?> fieldTypeClass = makeClass(fieldType, this.lookupClassLoader);
/*     */     
/* 382 */     FieldSignatureImpl ret = new FieldSignatureImpl(modifiersAsInt, name, declaringTypeClass, fieldTypeClass);
/* 383 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 384 */     return ret;
/*     */   }
/*     */   
/*     */   public FieldSignature makeFieldSig(int modifiers, String name, Class<?> declaringType, Class<?> fieldType) {
/* 388 */     FieldSignatureImpl ret = new FieldSignatureImpl(modifiers, name, declaringType, fieldType);
/* 389 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 390 */     return ret;
/*     */   }
/*     */   
/*     */   public AdviceSignature makeAdviceSig(String stringRep) {
/* 394 */     AdviceSignatureImpl ret = new AdviceSignatureImpl(stringRep);
/* 395 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 396 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public AdviceSignature makeAdviceSig(String modifiers, String name, String declaringType, String paramTypes, String paramNames, String exceptionTypes, String returnType) {
/* 401 */     int modifiersAsInt = Integer.parseInt(modifiers, 16);
/*     */     
/* 403 */     Class<?> declaringTypeClass = makeClass(declaringType, this.lookupClassLoader);
/*     */     
/* 405 */     StringTokenizer st = new StringTokenizer(paramTypes, ":");
/* 406 */     int numParams = st.countTokens();
/* 407 */     Class[] paramTypeClasses = new Class[numParams];
/* 408 */     for (int i = 0; i < numParams; i++) {
/* 409 */       paramTypeClasses[i] = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     }
/* 411 */     st = new StringTokenizer(paramNames, ":");
/* 412 */     numParams = st.countTokens();
/* 413 */     String[] paramNamesArray = new String[numParams];
/* 414 */     for (int j = 0; j < numParams; j++) {
/* 415 */       paramNamesArray[j] = st.nextToken();
/*     */     }
/* 417 */     st = new StringTokenizer(exceptionTypes, ":");
/* 418 */     numParams = st.countTokens();
/* 419 */     Class[] exceptionTypeClasses = new Class[numParams];
/* 420 */     for (int k = 0; k < numParams; k++) {
/* 421 */       exceptionTypeClasses[k] = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     }
/*     */     
/* 424 */     Class<?> returnTypeClass = makeClass(returnType, this.lookupClassLoader);
/*     */     
/* 426 */     AdviceSignatureImpl ret = new AdviceSignatureImpl(modifiersAsInt, name, declaringTypeClass, paramTypeClasses, paramNamesArray, exceptionTypeClasses, returnTypeClass);
/*     */     
/* 428 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 429 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public AdviceSignature makeAdviceSig(int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, Class<?> returnType) {
/* 434 */     AdviceSignatureImpl ret = new AdviceSignatureImpl(modifiers, name, declaringType, parameterTypes, parameterNames, exceptionTypes, returnType);
/*     */     
/* 436 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 437 */     return ret;
/*     */   }
/*     */   
/*     */   public InitializerSignature makeInitializerSig(String stringRep) {
/* 441 */     InitializerSignatureImpl ret = new InitializerSignatureImpl(stringRep);
/* 442 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 443 */     return ret;
/*     */   }
/*     */   
/*     */   public InitializerSignature makeInitializerSig(String modifiers, String declaringType) {
/* 447 */     int modifiersAsInt = Integer.parseInt(modifiers, 16);
/* 448 */     Class<?> declaringTypeClass = makeClass(declaringType, this.lookupClassLoader);
/*     */     
/* 450 */     InitializerSignatureImpl ret = new InitializerSignatureImpl(modifiersAsInt, declaringTypeClass);
/* 451 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 452 */     return ret;
/*     */   }
/*     */   
/*     */   public InitializerSignature makeInitializerSig(int modifiers, Class<?> declaringType) {
/* 456 */     InitializerSignatureImpl ret = new InitializerSignatureImpl(modifiers, declaringType);
/* 457 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 458 */     return ret;
/*     */   }
/*     */   
/*     */   public CatchClauseSignature makeCatchClauseSig(String stringRep) {
/* 462 */     CatchClauseSignatureImpl ret = new CatchClauseSignatureImpl(stringRep);
/* 463 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 464 */     return ret;
/*     */   }
/*     */   
/*     */   public CatchClauseSignature makeCatchClauseSig(String declaringType, String parameterType, String parameterName) {
/* 468 */     Class<?> declaringTypeClass = makeClass(declaringType, this.lookupClassLoader);
/*     */     
/* 470 */     StringTokenizer st = new StringTokenizer(parameterType, ":");
/* 471 */     Class<?> parameterTypeClass = makeClass(st.nextToken(), this.lookupClassLoader);
/*     */     
/* 473 */     st = new StringTokenizer(parameterName, ":");
/* 474 */     String parameterNameForReturn = st.nextToken();
/*     */     
/* 476 */     CatchClauseSignatureImpl ret = new CatchClauseSignatureImpl(declaringTypeClass, parameterTypeClass, parameterNameForReturn);
/* 477 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 478 */     return ret;
/*     */   }
/*     */   
/*     */   public CatchClauseSignature makeCatchClauseSig(Class<?> declaringType, Class<?> parameterType, String parameterName) {
/* 482 */     CatchClauseSignatureImpl ret = new CatchClauseSignatureImpl(declaringType, parameterType, parameterName);
/* 483 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 484 */     return ret;
/*     */   }
/*     */   
/*     */   public LockSignature makeLockSig(String stringRep) {
/* 488 */     LockSignatureImpl ret = new LockSignatureImpl(stringRep);
/* 489 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 490 */     return ret;
/*     */   }
/*     */   
/*     */   public LockSignature makeLockSig() {
/* 494 */     Class<?> declaringTypeClass = makeClass("Ljava/lang/Object;", this.lookupClassLoader);
/* 495 */     LockSignatureImpl ret = new LockSignatureImpl(declaringTypeClass);
/* 496 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 497 */     return ret;
/*     */   }
/*     */   
/*     */   public LockSignature makeLockSig(Class<?> declaringType) {
/* 501 */     LockSignatureImpl ret = new LockSignatureImpl(declaringType);
/* 502 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 503 */     return ret;
/*     */   }
/*     */   
/*     */   public UnlockSignature makeUnlockSig(String stringRep) {
/* 507 */     UnlockSignatureImpl ret = new UnlockSignatureImpl(stringRep);
/* 508 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 509 */     return ret;
/*     */   }
/*     */   
/*     */   public UnlockSignature makeUnlockSig() {
/* 513 */     Class<?> declaringTypeClass = makeClass("Ljava/lang/Object;", this.lookupClassLoader);
/* 514 */     UnlockSignatureImpl ret = new UnlockSignatureImpl(declaringTypeClass);
/* 515 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 516 */     return ret;
/*     */   }
/*     */   
/*     */   public UnlockSignature makeUnlockSig(Class<?> declaringType) {
/* 520 */     UnlockSignatureImpl ret = new UnlockSignatureImpl(declaringType);
/* 521 */     ret.setLookupClassLoader(this.lookupClassLoader);
/* 522 */     return ret;
/*     */   }
/*     */   
/*     */   public SourceLocation makeSourceLoc(int line, int col) {
/* 526 */     return new SourceLocationImpl(this.lexicalClass, this.filename, line);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\Factory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */