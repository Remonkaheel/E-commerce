/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.UnlockSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UnlockSignatureImpl
/*    */   extends SignatureImpl
/*    */   implements UnlockSignature
/*    */ {
/*    */   private Class<?> parameterType;
/*    */   
/*    */   UnlockSignatureImpl(Class<?> c) {
/* 23 */     super(8, "unlock", c);
/* 24 */     this.parameterType = c;
/*    */   }
/*    */   
/*    */   UnlockSignatureImpl(String stringRep) {
/* 28 */     super(stringRep);
/*    */   }
/*    */   
/*    */   protected String createToString(StringMaker sm) {
/* 32 */     if (this.parameterType == null) this.parameterType = extractType(3); 
/* 33 */     return "unlock(" + sm.makeTypeName(this.parameterType) + ")";
/*    */   }
/*    */   
/*    */   public Class getParameterType() {
/* 37 */     if (this.parameterType == null) this.parameterType = extractType(3); 
/* 38 */     return this.parameterType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\UnlockSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */