/*     */ package org.aspectj.runtime.reflect;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.lang.Signature;
/*     */ import org.aspectj.lang.reflect.SourceLocation;
/*     */ import org.aspectj.runtime.internal.AroundClosure;
/*     */ 
/*     */ 
/*     */ class JoinPointImpl
/*     */   implements ProceedingJoinPoint
/*     */ {
/*     */   Object _this;
/*     */   Object target;
/*     */   Object[] args;
/*     */   JoinPoint.StaticPart staticPart;
/*     */   private AroundClosure arc;
/*     */   private List<AroundClosure> arcs;
/*     */   private final ThreadLocal<Integer> arcIndex;
/*     */   
/*     */   static class StaticPartImpl
/*     */     implements JoinPoint.StaticPart
/*     */   {
/*     */     String kind;
/*     */     Signature signature;
/*     */     SourceLocation sourceLocation;
/*     */     private final int id;
/*     */     
/*     */     public StaticPartImpl(int id, String kind, Signature signature, SourceLocation sourceLocation) {
/*  32 */       this.kind = kind;
/*  33 */       this.signature = signature;
/*  34 */       this.sourceLocation = sourceLocation;
/*  35 */       this.id = id;
/*     */     }
/*     */     
/*     */     public int getId() {
/*  39 */       return this.id;
/*     */     }
/*     */     
/*     */     public String getKind() {
/*  43 */       return this.kind;
/*     */     }
/*     */     
/*     */     public Signature getSignature() {
/*  47 */       return this.signature;
/*     */     }
/*     */     
/*     */     public SourceLocation getSourceLocation() {
/*  51 */       return this.sourceLocation;
/*     */     }
/*     */     
/*     */     String toString(StringMaker sm) {
/*  55 */       return sm.makeKindName(getKind()) + "(" + ((SignatureImpl)getSignature()).toString(sm) + ")";
/*     */     }
/*     */     
/*     */     public final String toString() {
/*  59 */       return toString(StringMaker.middleStringMaker);
/*     */     }
/*     */     
/*     */     public final String toShortString() {
/*  63 */       return toString(StringMaker.shortStringMaker);
/*     */     }
/*     */     
/*     */     public final String toLongString() {
/*  67 */       return toString(StringMaker.longStringMaker);
/*     */     }
/*     */   }
/*     */   
/*     */   static class EnclosingStaticPartImpl extends StaticPartImpl implements JoinPoint.EnclosingStaticPart {
/*     */     public EnclosingStaticPartImpl(int count, String kind, Signature signature, SourceLocation sourceLocation) {
/*  73 */       super(count, kind, signature, sourceLocation);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getThis() {
/*     */     return this._this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTarget() {
/*     */     return this.target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getArgs() {
/*     */     if (this.args == null) {
/*     */       this.args = new Object[0];
/*     */     }
/*     */     Object[] argsCopy = new Object[this.args.length];
/*     */     System.arraycopy(this.args, 0, argsCopy, 0, this.args.length);
/*     */     return argsCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPoint.StaticPart getStaticPart() {
/*     */     return this.staticPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKind() {
/*     */     return this.staticPart.getKind();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JoinPointImpl(JoinPoint.StaticPart staticPart, Object _this, Object target, Object[] args)
/*     */   {
/* 136 */     this.arc = null;
/* 137 */     this.arcs = null;
/* 138 */     this.arcIndex = ThreadLocal.withInitial(() -> Integer.valueOf((this.arcs == null) ? -1 : (this.arcs.size() - 1))); this.staticPart = staticPart;
/*     */     this._this = _this;
/*     */     this.target = target;
/* 141 */     this.args = args; } public void set$AroundClosure(AroundClosure arc) { this.arc = arc; }
/*     */   
/*     */   public Signature getSignature() {
/*     */     return this.staticPart.getSignature();
/*     */   }
/* 146 */   public void stack$AroundClosure(AroundClosure arc) { if (this.arcs == null)
/* 147 */       this.arcs = new ArrayList<>(); 
/* 148 */     if (arc == null) {
/* 149 */       int newIndex = ((Integer)this.arcIndex.get()).intValue() - 1;
/* 150 */       if (newIndex > -1) {
/* 151 */         this.arcIndex.set(Integer.valueOf(newIndex));
/*     */       } else {
/* 153 */         this.arcIndex.remove();
/*     */       } 
/*     */     } else {
/* 156 */       this.arcs.add(arc);
/* 157 */       this.arcIndex.set(Integer.valueOf(this.arcs.size() - 1));
/*     */     }  } public SourceLocation getSourceLocation() {
/*     */     return this.staticPart.getSourceLocation();
/*     */   } public final String toString() {
/*     */     return this.staticPart.toString();
/*     */   } public Object proceed() throws Throwable {
/* 163 */     if (this.arcs == null) {
/* 164 */       return (this.arc == null) ? null : this.arc.run(this.arc.getState());
/*     */     }
/* 166 */     AroundClosure ac = this.arcs.get(((Integer)this.arcIndex.get()).intValue());
/* 167 */     return ac.run(ac.getState());
/*     */   } public final String toShortString() {
/*     */     return this.staticPart.toShortString();
/*     */   } public final String toLongString() {
/*     */     return this.staticPart.toLongString();
/*     */   } public Object proceed(Object[] adviceBindings) throws Throwable {
/* 173 */     AroundClosure ac = (this.arcs == null) ? this.arc : this.arcs.get(((Integer)this.arcIndex.get()).intValue());
/*     */     
/* 175 */     if (ac == null) {
/* 176 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 181 */     int flags = ac.getFlags();
/* 182 */     boolean unset = ((flags & 0x100000) != 0);
/* 183 */     boolean thisTargetTheSame = ((flags & 0x10000) != 0);
/* 184 */     boolean hasThis = ((flags & 0x1000) != 0);
/* 185 */     boolean bindsThis = ((flags & 0x100) != 0);
/* 186 */     boolean hasTarget = ((flags & 0x10) != 0);
/* 187 */     boolean bindsTarget = ((flags & 0x1) != 0);
/*     */ 
/*     */     
/* 190 */     Object[] state = ac.getState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     int firstArgumentIndexIntoAdviceBindings = 0;
/* 199 */     int firstArgumentIndexIntoState = 0;
/* 200 */     firstArgumentIndexIntoState += hasThis ? 1 : 0;
/* 201 */     firstArgumentIndexIntoState += (hasTarget && !thisTargetTheSame) ? 1 : 0;
/* 202 */     if (hasThis && 
/* 203 */       bindsThis) {
/*     */       
/* 205 */       firstArgumentIndexIntoAdviceBindings = 1;
/* 206 */       state[0] = adviceBindings[0];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (hasTarget && 
/* 212 */       bindsTarget) {
/* 213 */       if (thisTargetTheSame) {
/*     */         
/* 215 */         firstArgumentIndexIntoAdviceBindings = 1 + (bindsThis ? 1 : 0);
/* 216 */         state[0] = adviceBindings[bindsThis ? 1 : 0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         int targetPositionInAdviceBindings = (hasThis && bindsThis) ? 1 : 0;
/* 230 */         firstArgumentIndexIntoAdviceBindings = ((hasThis && bindsThis) ? 1 : 0) + ((hasTarget && bindsTarget && !thisTargetTheSame) ? 1 : 0);
/* 231 */         state[hasThis ? 1 : 0] = adviceBindings[targetPositionInAdviceBindings];
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     for (int i = firstArgumentIndexIntoAdviceBindings; i < adviceBindings.length; i++) {
/* 240 */       state[firstArgumentIndexIntoState + i - firstArgumentIndexIntoAdviceBindings] = adviceBindings[i];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     return ac.run(state);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\JoinPointImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */