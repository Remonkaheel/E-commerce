/*     */ package org.aspectj.runtime.reflect;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.StringTokenizer;
/*     */ import org.aspectj.lang.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SignatureImpl
/*     */   implements Signature
/*     */ {
/*     */   private static boolean useCache = true;
/*  25 */   int modifiers = -1;
/*     */   
/*     */   String name;
/*     */   
/*     */   String declaringTypeName;
/*     */   
/*     */   Class<?> declaringType;
/*     */   
/*     */   Cache stringCache;
/*     */   
/*     */   private String stringRep;
/*     */   
/*     */   ClassLoader lookupClassLoader;
/*     */   static final char SEP = '-';
/*     */   
/*     */   String toString(StringMaker sm) {
/*  41 */     String result = null;
/*  42 */     if (useCache) {
/*  43 */       if (this.stringCache == null) {
/*     */         try {
/*  45 */           this.stringCache = new CacheImpl();
/*  46 */         } catch (Throwable t) {
/*  47 */           useCache = false;
/*     */         } 
/*     */       } else {
/*  50 */         result = this.stringCache.get(sm.cacheOffset);
/*     */       } 
/*     */     }
/*  53 */     if (result == null) {
/*  54 */       result = createToString(sm);
/*     */     }
/*  56 */     if (useCache) {
/*  57 */       this.stringCache.set(sm.cacheOffset, result);
/*     */     }
/*  59 */     return result;
/*     */   }
/*     */   
/*  62 */   public final String toString() { return toString(StringMaker.middleStringMaker); }
/*  63 */   public final String toShortString() { return toString(StringMaker.shortStringMaker); } public final String toLongString() {
/*  64 */     return toString(StringMaker.longStringMaker);
/*     */   }
/*     */   public int getModifiers() {
/*  67 */     if (this.modifiers == -1) this.modifiers = extractInt(0); 
/*  68 */     return this.modifiers;
/*     */   }
/*     */   public String getName() {
/*  71 */     if (this.name == null) this.name = extractString(1); 
/*  72 */     return this.name;
/*     */   }
/*     */   public Class getDeclaringType() {
/*  75 */     if (this.declaringType == null) this.declaringType = extractType(2); 
/*  76 */     return this.declaringType;
/*     */   }
/*     */   public String getDeclaringTypeName() {
/*  79 */     if (this.declaringTypeName == null) {
/*  80 */       this.declaringTypeName = getDeclaringType().getName();
/*     */     }
/*  82 */     return this.declaringTypeName;
/*     */   }
/*     */   
/*     */   String fullTypeName(Class<?> type) {
/*  86 */     if (type == null) return "ANONYMOUS"; 
/*  87 */     if (type.isArray()) return fullTypeName(type.getComponentType()) + "[]"; 
/*  88 */     return type.getName().replace('$', '.');
/*     */   }
/*     */   
/*     */   String stripPackageName(String name) {
/*  92 */     int dot = name.lastIndexOf('.');
/*  93 */     if (dot == -1) return name; 
/*  94 */     return name.substring(dot + 1);
/*     */   }
/*     */   
/*     */   String shortTypeName(Class<?> type) {
/*  98 */     if (type == null) return "ANONYMOUS"; 
/*  99 */     if (type.isArray()) return shortTypeName(type.getComponentType()) + "[]"; 
/* 100 */     return stripPackageName(type.getName()).replace('$', '.');
/*     */   }
/*     */   
/*     */   void addFullTypeNames(StringBuffer buf, Class[] types) {
/* 104 */     for (int i = 0; i < types.length; i++) {
/* 105 */       if (i > 0) buf.append(", "); 
/* 106 */       buf.append(fullTypeName(types[i]));
/*     */     } 
/*     */   }
/*     */   void addShortTypeNames(StringBuffer buf, Class[] types) {
/* 110 */     for (int i = 0; i < types.length; i++) {
/* 111 */       if (i > 0) buf.append(", "); 
/* 112 */       buf.append(shortTypeName(types[i]));
/*     */     } 
/*     */   }
/*     */   
/*     */   void addTypeArray(StringBuffer buf, Class[] types) {
/* 117 */     addFullTypeNames(buf, types);
/*     */   }
/*     */ 
/*     */   
/*     */   SignatureImpl(int modifiers, String name, Class<?> declaringType) {
/* 122 */     this.lookupClassLoader = null; this.modifiers = modifiers; this.name = name; this.declaringType = declaringType; } public SignatureImpl(String stringRep) { this.lookupClassLoader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.stringRep = stringRep; }
/*     */    public void setLookupClassLoader(ClassLoader loader) {
/*     */     this.lookupClassLoader = loader;
/*     */   } private ClassLoader getLookupClassLoader() {
/*     */     if (this.lookupClassLoader == null)
/*     */       this.lookupClassLoader = getClass().getClassLoader(); 
/*     */     return this.lookupClassLoader;
/*     */   } String extractString(int n) {
/* 142 */     int startIndex = 0;
/* 143 */     int endIndex = this.stringRep.indexOf('-');
/* 144 */     while (n-- > 0) {
/* 145 */       startIndex = endIndex + 1;
/* 146 */       endIndex = this.stringRep.indexOf('-', startIndex);
/*     */     } 
/* 148 */     if (endIndex == -1) endIndex = this.stringRep.length();
/*     */ 
/*     */ 
/*     */     
/* 152 */     return this.stringRep.substring(startIndex, endIndex);
/*     */   }
/*     */   
/*     */   int extractInt(int n) {
/* 156 */     String s = extractString(n);
/* 157 */     return Integer.parseInt(s, 16);
/*     */   }
/*     */   
/*     */   Class<?> extractType(int n) {
/* 161 */     String s = extractString(n);
/* 162 */     return Factory.makeClass(s, getLookupClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 167 */   static String[] EMPTY_STRING_ARRAY = new String[0];
/* 168 */   static Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */   
/*     */   static final String INNER_SEP = ":";
/*     */   
/*     */   String[] extractStrings(int n) {
/* 173 */     String s = extractString(n);
/* 174 */     StringTokenizer st = new StringTokenizer(s, ":");
/* 175 */     int N = st.countTokens();
/* 176 */     String[] ret = new String[N];
/* 177 */     for (int i = 0; i < N; ) { ret[i] = st.nextToken(); i++; }
/* 178 */      return ret;
/*     */   }
/*     */   Class[] extractTypes(int n) {
/* 181 */     String s = extractString(n);
/* 182 */     StringTokenizer st = new StringTokenizer(s, ":");
/* 183 */     int N = st.countTokens();
/* 184 */     Class[] ret = new Class[N];
/* 185 */     for (int i = 0; i < N; ) { ret[i] = Factory.makeClass(st.nextToken(), getLookupClassLoader()); i++; }
/* 186 */      return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setUseCache(boolean b) {
/* 193 */     useCache = b;
/*     */   }
/*     */   
/*     */   static boolean getUseCache() {
/* 197 */     return useCache;
/*     */   }
/*     */   
/*     */   protected abstract String createToString(StringMaker paramStringMaker);
/*     */   
/*     */   private static interface Cache {
/*     */     String get(int param1Int);
/*     */     
/*     */     void set(int param1Int, String param1String);
/*     */   }
/*     */   
/*     */   private static final class CacheImpl
/*     */     implements Cache {
/*     */     private SoftReference<String[]> toStringCacheRef;
/*     */     
/*     */     public CacheImpl() {
/* 213 */       makeCache();
/*     */     }
/*     */     
/*     */     public String get(int cacheOffset) {
/* 217 */       String[] cachedArray = array();
/* 218 */       if (cachedArray == null) {
/* 219 */         return null;
/*     */       }
/* 221 */       return cachedArray[cacheOffset];
/*     */     }
/*     */     
/*     */     public void set(int cacheOffset, String result) {
/* 225 */       String[] cachedArray = array();
/* 226 */       if (cachedArray == null) {
/* 227 */         cachedArray = makeCache();
/*     */       }
/* 229 */       cachedArray[cacheOffset] = result;
/*     */     }
/*     */     
/*     */     private String[] array() {
/* 233 */       return this.toStringCacheRef.get();
/*     */     }
/*     */     
/*     */     private String[] makeCache() {
/* 237 */       String[] array = new String[3];
/* 238 */       this.toStringCacheRef = (SoftReference)new SoftReference<>(array);
/* 239 */       return array;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\SignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */