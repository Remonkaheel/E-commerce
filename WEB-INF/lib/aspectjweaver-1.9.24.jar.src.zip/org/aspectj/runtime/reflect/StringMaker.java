/*     */ package org.aspectj.runtime.reflect;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringMaker
/*     */ {
/*     */   boolean shortTypeNames = true;
/*     */   boolean includeArgs = true;
/*     */   boolean includeThrows = false;
/*     */   boolean includeModifiers = false;
/*     */   boolean shortPrimaryTypeNames = false;
/*     */   boolean includeJoinPointTypeName = true;
/*     */   boolean includeEnclosingPoint = true;
/*     */   boolean shortKindName = true;
/*     */   int cacheOffset;
/*  33 */   static StringMaker shortStringMaker = new StringMaker(); static StringMaker middleStringMaker; static {
/*  34 */     shortStringMaker.shortTypeNames = true;
/*  35 */     shortStringMaker.includeArgs = false;
/*  36 */     shortStringMaker.includeThrows = false;
/*  37 */     shortStringMaker.includeModifiers = false;
/*  38 */     shortStringMaker.shortPrimaryTypeNames = true;
/*     */     
/*  40 */     shortStringMaker.includeJoinPointTypeName = false;
/*  41 */     shortStringMaker.includeEnclosingPoint = false;
/*     */     
/*  43 */     shortStringMaker.cacheOffset = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     middleStringMaker = new StringMaker();
/*  49 */     middleStringMaker.shortTypeNames = true;
/*  50 */     middleStringMaker.includeArgs = true;
/*  51 */     middleStringMaker.includeThrows = false;
/*  52 */     middleStringMaker.includeModifiers = false;
/*  53 */     middleStringMaker.shortPrimaryTypeNames = false;
/*     */     
/*  55 */     shortStringMaker.cacheOffset = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     longStringMaker = new StringMaker();
/*  61 */     longStringMaker.shortTypeNames = false;
/*  62 */     longStringMaker.includeArgs = true;
/*  63 */     longStringMaker.includeThrows = false;
/*  64 */     longStringMaker.includeModifiers = true;
/*  65 */     longStringMaker.shortPrimaryTypeNames = false;
/*  66 */     longStringMaker.shortKindName = false;
/*     */     
/*  68 */     longStringMaker.cacheOffset = 2;
/*     */   }
/*     */   static StringMaker longStringMaker;
/*     */   String makeKindName(String name) {
/*  72 */     int dash = name.lastIndexOf('-');
/*  73 */     if (dash == -1) return name; 
/*  74 */     return name.substring(dash + 1);
/*     */   }
/*     */   
/*     */   String makeModifiersString(int modifiers) {
/*  78 */     if (!this.includeModifiers) return ""; 
/*  79 */     String str = Modifier.toString(modifiers);
/*  80 */     if (str.length() == 0) return ""; 
/*  81 */     return str + " ";
/*     */   }
/*     */   
/*     */   String stripPackageName(String name) {
/*  85 */     int dot = name.lastIndexOf('.');
/*  86 */     if (dot == -1) return name; 
/*  87 */     return name.substring(dot + 1);
/*     */   }
/*     */   
/*     */   String makeTypeName(Class<?> type, String typeName, boolean shortName) {
/*  91 */     if (type == null) return "ANONYMOUS"; 
/*  92 */     if (type.isArray()) {
/*  93 */       Class<?> componentType = type.getComponentType();
/*  94 */       return makeTypeName(componentType, componentType.getName(), shortName) + "[]";
/*     */     } 
/*  96 */     if (shortName) {
/*  97 */       return stripPackageName(typeName).replace('$', '.');
/*     */     }
/*  99 */     return typeName.replace('$', '.');
/*     */   }
/*     */ 
/*     */   
/*     */   public String makeTypeName(Class<?> type) {
/* 104 */     return makeTypeName(type, type.getName(), this.shortTypeNames);
/*     */   }
/*     */   
/*     */   public String makePrimaryTypeName(Class<?> type, String typeName) {
/* 108 */     return makeTypeName(type, typeName, this.shortPrimaryTypeNames);
/*     */   }
/*     */   
/*     */   public void addTypeNames(StringBuffer buf, Class[] types) {
/* 112 */     for (int i = 0; i < types.length; i++) {
/* 113 */       if (i > 0) buf.append(", "); 
/* 114 */       buf.append(makeTypeName(types[i]));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addSignature(StringBuffer buf, Class[] types) {
/* 119 */     if (types == null)
/* 120 */       return;  if (!this.includeArgs) {
/* 121 */       if (types.length == 0) {
/* 122 */         buf.append("()");
/*     */         return;
/*     */       } 
/* 125 */       buf.append("(..)");
/*     */       
/*     */       return;
/*     */     } 
/* 129 */     buf.append("(");
/* 130 */     addTypeNames(buf, types);
/* 131 */     buf.append(")");
/*     */   }
/*     */   
/*     */   public void addThrows(StringBuffer buf, Class[] types) {
/* 135 */     if (!this.includeThrows || types == null || types.length == 0)
/*     */       return; 
/* 137 */     buf.append(" throws ");
/* 138 */     addTypeNames(buf, types);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\StringMaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */