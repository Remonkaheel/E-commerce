/*     */ package org.aspectj.runtime.reflect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodSignatureImpl
/*     */   extends CodeSignatureImpl
/*     */   implements MethodSignature
/*     */ {
/*     */   private Method method;
/*     */   Class<?> returnType;
/*     */   
/*     */   MethodSignatureImpl(int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, Class<?> returnType) {
/*  28 */     super(modifiers, name, declaringType, parameterTypes, parameterNames, exceptionTypes);
/*  29 */     this.returnType = returnType;
/*     */   }
/*     */   
/*     */   MethodSignatureImpl(String stringRep) {
/*  33 */     super(stringRep);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getReturnType() {
/*  38 */     if (this.returnType == null)
/*  39 */       this.returnType = extractType(6); 
/*  40 */     return this.returnType;
/*     */   }
/*     */   
/*     */   protected String createToString(StringMaker sm) {
/*  44 */     StringBuffer buf = new StringBuffer();
/*  45 */     buf.append(sm.makeModifiersString(getModifiers()));
/*  46 */     if (sm.includeArgs)
/*  47 */       buf.append(sm.makeTypeName(getReturnType())); 
/*  48 */     if (sm.includeArgs)
/*  49 */       buf.append(" "); 
/*  50 */     buf.append(sm.makePrimaryTypeName(getDeclaringType(), getDeclaringTypeName()));
/*  51 */     buf.append(".");
/*  52 */     buf.append(getName());
/*  53 */     sm.addSignature(buf, getParameterTypes());
/*  54 */     sm.addThrows(buf, getExceptionTypes());
/*  55 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/*  64 */     if (this.method == null) {
/*  65 */       Class<?> dtype = getDeclaringType();
/*     */       try {
/*  67 */         this.method = dtype.getDeclaredMethod(getName(), getParameterTypes());
/*  68 */       } catch (NoSuchMethodException nsmEx) {
/*     */         
/*  70 */         Set<Class<?>> searched = new HashSet<>();
/*  71 */         searched.add(dtype);
/*  72 */         this.method = search(dtype, getName(), getParameterTypes(), searched);
/*     */       } 
/*     */     } 
/*  75 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method search(Class<?> type, String name, Class[] params, Set<Class<?>> searched) {
/*  88 */     if (type == null) {
/*  89 */       return null;
/*     */     }
/*  91 */     if (!searched.contains(type)) {
/*  92 */       searched.add(type);
/*     */       try {
/*  94 */         return type.getDeclaredMethod(name, params);
/*  95 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*     */     } 
/*     */ 
/*     */     
/*  99 */     Method m = search(type.getSuperclass(), name, params, searched);
/* 100 */     if (m != null) {
/* 101 */       return m;
/*     */     }
/* 103 */     Class[] superinterfaces = type.getInterfaces();
/* 104 */     if (superinterfaces != null) {
/* 105 */       for (Class<?> superinterface : superinterfaces) {
/* 106 */         m = search(superinterface, name, params, searched);
/* 107 */         if (m != null) {
/* 108 */           return m;
/*     */         }
/*     */       } 
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\MethodSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */