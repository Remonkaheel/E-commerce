/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.MemberSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MemberSignatureImpl
/*    */   extends SignatureImpl
/*    */   implements MemberSignature
/*    */ {
/*    */   MemberSignatureImpl(int modifiers, String name, Class<?> declaringType) {
/* 22 */     super(modifiers, name, declaringType);
/*    */   }
/*    */   
/*    */   public MemberSignatureImpl(String stringRep) {
/* 26 */     super(stringRep);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\MemberSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */