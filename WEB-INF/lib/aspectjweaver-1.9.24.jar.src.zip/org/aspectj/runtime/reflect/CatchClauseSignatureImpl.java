/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.CatchClauseSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CatchClauseSignatureImpl
/*    */   extends SignatureImpl
/*    */   implements CatchClauseSignature
/*    */ {
/*    */   Class<?> parameterType;
/*    */   String parameterName;
/*    */   
/*    */   CatchClauseSignatureImpl(Class<?> declaringType, Class<?> parameterType, String parameterName) {
/* 26 */     super(0, "catch", declaringType);
/* 27 */     this.parameterType = parameterType;
/* 28 */     this.parameterName = parameterName;
/*    */   }
/*    */   
/*    */   CatchClauseSignatureImpl(String stringRep) {
/* 32 */     super(stringRep);
/*    */   }
/*    */   
/*    */   public Class getParameterType() {
/* 36 */     if (this.parameterType == null) this.parameterType = extractType(3); 
/* 37 */     return this.parameterType;
/*    */   }
/*    */   public String getParameterName() {
/* 40 */     if (this.parameterName == null) this.parameterName = extractString(4); 
/* 41 */     return this.parameterName;
/*    */   }
/*    */   
/*    */   protected String createToString(StringMaker sm) {
/* 45 */     return "catch(" + sm.makeTypeName(getParameterType()) + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\CatchClauseSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */