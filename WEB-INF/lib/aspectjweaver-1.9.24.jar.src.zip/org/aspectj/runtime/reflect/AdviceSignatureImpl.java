/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.StringTokenizer;
/*    */ import org.aspectj.lang.reflect.AdviceSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AdviceSignatureImpl
/*    */   extends CodeSignatureImpl
/*    */   implements AdviceSignature
/*    */ {
/*    */   Class<?> returnType;
/* 24 */   private Method adviceMethod = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   AdviceSignatureImpl(int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes, Class<?> returnType) {
/* 30 */     super(modifiers, name, declaringType, parameterTypes, parameterNames, exceptionTypes);
/*    */     
/* 32 */     this.returnType = returnType;
/*    */   }
/*    */   
/*    */   AdviceSignatureImpl(String stringRep) {
/* 36 */     super(stringRep);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class getReturnType() {
/* 42 */     if (this.returnType == null) this.returnType = extractType(6); 
/* 43 */     return this.returnType;
/*    */   }
/*    */   
/*    */   protected String createToString(StringMaker sm) {
/* 47 */     StringBuffer buf = new StringBuffer();
/*    */     
/* 49 */     if (sm.includeArgs) buf.append(sm.makeTypeName(getReturnType())); 
/* 50 */     if (sm.includeArgs) buf.append(" "); 
/* 51 */     buf.append(sm.makePrimaryTypeName(getDeclaringType(), getDeclaringTypeName()));
/* 52 */     buf.append(".");
/* 53 */     buf.append(toAdviceName(getName()));
/* 54 */     sm.addSignature(buf, getParameterTypes());
/* 55 */     sm.addThrows(buf, getExceptionTypes());
/* 56 */     return buf.toString();
/*    */   }
/*    */   
/*    */   private String toAdviceName(String methodName) {
/* 60 */     if (methodName.indexOf('$') == -1) return methodName; 
/* 61 */     StringTokenizer strTok = new StringTokenizer(methodName, "$");
/* 62 */     while (strTok.hasMoreTokens()) {
/* 63 */       String token = strTok.nextToken();
/* 64 */       if (token.startsWith("before") || token
/* 65 */         .startsWith("after") || token
/* 66 */         .startsWith("around")) return token; 
/*    */     } 
/* 68 */     return methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Method getAdvice() {
/* 75 */     if (this.adviceMethod == null) {
/*    */       try {
/* 77 */         this.adviceMethod = getDeclaringType().getDeclaredMethod(getName(), getParameterTypes());
/* 78 */       } catch (Exception exception) {}
/*    */     }
/*    */ 
/*    */     
/* 82 */     return this.adviceMethod;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\AdviceSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */