/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.SourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SourceLocationImpl
/*    */   implements SourceLocation
/*    */ {
/*    */   Class<?> withinType;
/*    */   String fileName;
/*    */   int line;
/*    */   
/*    */   SourceLocationImpl(Class<?> withinType, String fileName, int line) {
/* 25 */     this.withinType = withinType;
/* 26 */     this.fileName = fileName;
/* 27 */     this.line = line;
/*    */   }
/*    */   
/* 30 */   public Class getWithinType() { return this.withinType; }
/* 31 */   public String getFileName() { return this.fileName; }
/* 32 */   public int getLine() { return this.line; } public int getColumn() {
/* 33 */     return -1;
/*    */   }
/*    */   public String toString() {
/* 36 */     return getFileName() + ":" + getLine();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\SourceLocationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */