/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.CodeSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class CodeSignatureImpl
/*    */   extends MemberSignatureImpl
/*    */   implements CodeSignature
/*    */ {
/*    */   Class[] parameterTypes;
/*    */   String[] parameterNames;
/*    */   Class[] exceptionTypes;
/*    */   
/*    */   CodeSignatureImpl(int modifiers, String name, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes) {
/* 27 */     super(modifiers, name, declaringType);
/* 28 */     this.parameterTypes = parameterTypes;
/* 29 */     this.parameterNames = parameterNames;
/* 30 */     this.exceptionTypes = exceptionTypes;
/*    */   }
/*    */   CodeSignatureImpl(String stringRep) {
/* 33 */     super(stringRep);
/*    */   }
/*    */   
/*    */   public Class[] getParameterTypes() {
/* 37 */     if (this.parameterTypes == null) this.parameterTypes = extractTypes(3); 
/* 38 */     return this.parameterTypes;
/*    */   }
/*    */   public String[] getParameterNames() {
/* 41 */     if (this.parameterNames == null) this.parameterNames = extractStrings(4); 
/* 42 */     return this.parameterNames;
/*    */   }
/*    */   public Class[] getExceptionTypes() {
/* 45 */     if (this.exceptionTypes == null) this.exceptionTypes = extractTypes(5); 
/* 46 */     return this.exceptionTypes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\CodeSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */