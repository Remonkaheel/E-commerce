/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.aspectj.lang.reflect.ConstructorSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConstructorSignatureImpl
/*    */   extends CodeSignatureImpl
/*    */   implements ConstructorSignature
/*    */ {
/*    */   private Constructor<?> constructor;
/*    */   
/*    */   ConstructorSignatureImpl(int modifiers, Class<?> declaringType, Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes) {
/* 27 */     super(modifiers, "<init>", declaringType, parameterTypes, parameterNames, exceptionTypes);
/*    */   }
/*    */   
/*    */   ConstructorSignatureImpl(String stringRep) {
/* 31 */     super(stringRep);
/*    */   }
/*    */   public String getName() {
/* 34 */     return "<init>";
/*    */   }
/*    */   protected String createToString(StringMaker sm) {
/* 37 */     StringBuffer buf = new StringBuffer();
/* 38 */     buf.append(sm.makeModifiersString(getModifiers()));
/* 39 */     buf.append(sm.makePrimaryTypeName(getDeclaringType(), getDeclaringTypeName()));
/* 40 */     sm.addSignature(buf, getParameterTypes());
/* 41 */     sm.addThrows(buf, getExceptionTypes());
/* 42 */     return buf.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Constructor getConstructor() {
/* 49 */     if (this.constructor == null) {
/*    */       try {
/* 51 */         this.constructor = getDeclaringType().getDeclaredConstructor(getParameterTypes());
/* 52 */       } catch (Exception exception) {}
/*    */     }
/*    */ 
/*    */     
/* 56 */     return this.constructor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\ConstructorSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */