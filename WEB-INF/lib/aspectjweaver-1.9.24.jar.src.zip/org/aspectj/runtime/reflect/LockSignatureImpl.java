/*    */ package org.aspectj.runtime.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.LockSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LockSignatureImpl
/*    */   extends SignatureImpl
/*    */   implements LockSignature
/*    */ {
/*    */   private Class<?> parameterType;
/*    */   
/*    */   LockSignatureImpl(Class<?> c) {
/* 23 */     super(8, "lock", c);
/* 24 */     this.parameterType = c;
/*    */   }
/*    */   
/*    */   LockSignatureImpl(String stringRep) {
/* 28 */     super(stringRep);
/*    */   }
/*    */   
/*    */   protected String createToString(StringMaker sm) {
/* 32 */     if (this.parameterType == null) this.parameterType = extractType(3); 
/* 33 */     return "lock(" + sm.makeTypeName(this.parameterType) + ")";
/*    */   }
/*    */   
/*    */   public Class<?> getParameterType() {
/* 37 */     if (this.parameterType == null) this.parameterType = extractType(3); 
/* 38 */     return this.parameterType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\reflect\LockSignatureImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */