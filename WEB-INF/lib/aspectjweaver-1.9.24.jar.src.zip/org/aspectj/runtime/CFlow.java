/*    */ package org.aspectj.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CFlow
/*    */ {
/*    */   private Object _aspect;
/*    */   
/*    */   public CFlow() {
/* 21 */     this(null);
/*    */   }
/*    */   
/*    */   public CFlow(Object _aspect) {
/* 25 */     this._aspect = _aspect;
/*    */   }
/*    */   
/*    */   public Object getAspect() {
/* 29 */     return this._aspect;
/*    */   }
/*    */   
/*    */   public void setAspect(Object _aspect) {
/* 33 */     this._aspect = _aspect;
/*    */   }
/*    */   
/*    */   public Object get(int index) {
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\runtime\CFlow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */