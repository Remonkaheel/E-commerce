/*      */ package org.aspectj.asm;
/*      */ 
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.aspectj.asm.internal.AspectJElementHierarchy;
/*      */ import org.aspectj.asm.internal.HandleProviderDelimiter;
/*      */ import org.aspectj.asm.internal.JDTLikeHandleProvider;
/*      */ import org.aspectj.asm.internal.RelationshipMap;
/*      */ import org.aspectj.bridge.ISourceLocation;
/*      */ import org.aspectj.util.IStructureModel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AsmManager
/*      */   implements IStructureModel
/*      */ {
/*      */   public static boolean recordingLastActiveStructureModel = true;
/*      */   public static AsmManager lastActiveStructureModel;
/*      */   public static boolean forceSingletonBehaviour = false;
/*      */   public static boolean attemptIncrementalModelRepairs = false;
/*      */   public static boolean dumpModelPostBuild = false;
/*      */   private static boolean dumpModel = false;
/*      */   private static boolean dumpRelationships = false;
/*      */   private static boolean dumpDeltaProcessing = false;
/*   69 */   private static IModelFilter modelFilter = null;
/*   70 */   private static String dumpFilename = "";
/*      */   
/*      */   private static boolean reporting = false;
/*      */   
/*      */   private static boolean completingTypeBindings = false;
/*   75 */   private final List<IHierarchyListener> structureListeners = new ArrayList<>();
/*      */ 
/*      */ 
/*      */   
/*      */   protected IHierarchy hierarchy;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<File, String> inpathMap;
/*      */ 
/*      */ 
/*      */   
/*      */   private IRelationshipMap mapper;
/*      */ 
/*      */ 
/*      */   
/*      */   private IElementHandleProvider handleProvider;
/*      */ 
/*      */   
/*   94 */   private final CanonicalFilePathMap canonicalFilePathMap = new CanonicalFilePathMap();
/*      */ 
/*      */   
/*   97 */   private final Set<File> lastBuildChanges = new HashSet<>();
/*      */ 
/*      */   
/*  100 */   final Set<File> aspectsWeavingInLastBuild = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AsmManager createNewStructureModel(Map<File, String> inpathMap) {
/*  110 */     if (forceSingletonBehaviour && lastActiveStructureModel != null) {
/*  111 */       return lastActiveStructureModel;
/*      */     }
/*  113 */     AsmManager asm = new AsmManager();
/*  114 */     asm.inpathMap = inpathMap;
/*  115 */     asm.hierarchy = (IHierarchy)new AspectJElementHierarchy(asm);
/*  116 */     asm.mapper = (IRelationshipMap)new RelationshipMap();
/*  117 */     asm.handleProvider = (IElementHandleProvider)new JDTLikeHandleProvider(asm);
/*      */ 
/*      */     
/*  120 */     asm.handleProvider.initialize();
/*  121 */     asm.resetDeltaProcessing();
/*  122 */     setLastActiveStructureModel(asm);
/*  123 */     return asm;
/*      */   }
/*      */   
/*      */   public IHierarchy getHierarchy() {
/*  127 */     return this.hierarchy;
/*      */   }
/*      */   
/*      */   public IRelationshipMap getRelationshipMap() {
/*  131 */     return this.mapper;
/*      */   }
/*      */   
/*      */   public void fireModelUpdated() {
/*  135 */     notifyListeners();
/*  136 */     if (dumpModelPostBuild && this.hierarchy.getConfigFile() != null) {
/*  137 */       writeStructureModel(this.hierarchy.getConfigFile());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap<Integer, List<IProgramElement>> getInlineAnnotations(String sourceFile, boolean showSubMember, boolean showMemberAndType) {
/*  147 */     if (!this.hierarchy.isValid()) {
/*  148 */       return null;
/*      */     }
/*      */     
/*  151 */     HashMap<Integer, List<IProgramElement>> annotations = new HashMap<>();
/*  152 */     IProgramElement node = this.hierarchy.findElementForSourceFile(sourceFile);
/*  153 */     if (node == IHierarchy.NO_STRUCTURE) {
/*  154 */       return null;
/*      */     }
/*  156 */     IProgramElement fileNode = node;
/*  157 */     List<IProgramElement> peNodes = new ArrayList<>();
/*  158 */     getAllStructureChildren(fileNode, peNodes, showSubMember, showMemberAndType);
/*  159 */     for (IProgramElement peNode : peNodes) {
/*  160 */       List<IProgramElement> entries = new ArrayList<>();
/*  161 */       entries.add(peNode);
/*  162 */       ISourceLocation sourceLoc = peNode.getSourceLocation();
/*  163 */       if (null != sourceLoc) {
/*  164 */         Integer hash = Integer.valueOf(sourceLoc.getLine());
/*  165 */         List<IProgramElement> existingEntry = annotations.get(hash);
/*  166 */         if (existingEntry != null) {
/*  167 */           entries.addAll(existingEntry);
/*      */         }
/*  169 */         annotations.put(hash, entries);
/*      */       } 
/*      */     } 
/*  172 */     return annotations;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void getAllStructureChildren(IProgramElement node, List<IProgramElement> result, boolean showSubMember, boolean showMemberAndType) {
/*  178 */     List<IProgramElement> children = node.getChildren();
/*  179 */     if (node.getChildren() == null) {
/*      */       return;
/*      */     }
/*  182 */     for (IProgramElement next : children) {
/*  183 */       List<IRelationship> rels = this.mapper.get(next);
/*  184 */       if (next != null && ((next
/*  185 */         .getKind() == IProgramElement.Kind.CODE && showSubMember) || (next.getKind() != IProgramElement.Kind.CODE && showMemberAndType)) && rels != null && rels
/*  186 */         .size() > 0) {
/*  187 */         result.add(next);
/*      */       }
/*  189 */       getAllStructureChildren(next, result, showSubMember, showMemberAndType);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void addListener(IHierarchyListener listener) {
/*  194 */     this.structureListeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removeStructureListener(IHierarchyListener listener) {
/*  198 */     this.structureListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllListeners() {
/*  206 */     this.structureListeners.clear();
/*      */   }
/*      */   
/*      */   private void notifyListeners() {
/*  210 */     for (IHierarchyListener listener : this.structureListeners) {
/*  211 */       listener.elementsUpdated(this.hierarchy);
/*      */     }
/*      */   }
/*      */   
/*      */   public IElementHandleProvider getHandleProvider() {
/*  216 */     return this.handleProvider;
/*      */   }
/*      */   
/*      */   public void setHandleProvider(IElementHandleProvider handleProvider) {
/*  220 */     this.handleProvider = handleProvider;
/*      */   }
/*      */   
/*      */   public void writeStructureModel(String configFilePath) {
/*      */     try {
/*  225 */       String filePath = genExternFilePath(configFilePath);
/*  226 */       FileOutputStream fos = new FileOutputStream(filePath);
/*  227 */       ObjectOutputStream s = new ObjectOutputStream(fos);
/*  228 */       s.writeObject(this.hierarchy);
/*  229 */       s.writeObject(this.mapper);
/*  230 */       s.flush();
/*  231 */       fos.flush();
/*  232 */       fos.close();
/*  233 */       s.close();
/*  234 */     } catch (IOException iOException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readStructureModel(String configFilePath) {
/*  245 */     boolean hierarchyReadOK = false;
/*      */     try {
/*  247 */       if (configFilePath == null) {
/*  248 */         this.hierarchy.setRoot(IHierarchy.NO_STRUCTURE);
/*      */       } else {
/*  250 */         String filePath = genExternFilePath(configFilePath);
/*  251 */         FileInputStream in = new FileInputStream(filePath);
/*  252 */         ObjectInputStream s = new ObjectInputStream(in);
/*  253 */         this.hierarchy = (IHierarchy)s.readObject();
/*  254 */         ((AspectJElementHierarchy)this.hierarchy).setAsmManager(this);
/*  255 */         hierarchyReadOK = true;
/*  256 */         this.mapper = (IRelationshipMap)s.readObject();
/*  257 */         s.close();
/*      */       } 
/*  259 */     } catch (FileNotFoundException fnfe) {
/*      */       
/*  261 */       this.hierarchy.setRoot(IHierarchy.NO_STRUCTURE);
/*  262 */     } catch (EOFException eofe) {
/*      */       
/*  264 */       if (!hierarchyReadOK) {
/*  265 */         System.err.println("AsmManager: Unable to read structure model: " + configFilePath + " because of:");
/*  266 */         eofe.printStackTrace();
/*  267 */         this.hierarchy.setRoot(IHierarchy.NO_STRUCTURE);
/*      */       } 
/*  269 */     } catch (Exception e) {
/*      */ 
/*      */ 
/*      */       
/*  273 */       this.hierarchy.setRoot(IHierarchy.NO_STRUCTURE);
/*      */     } finally {
/*  275 */       notifyListeners();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private String genExternFilePath(String configFilePath) {
/*  281 */     if (configFilePath.lastIndexOf(".lst") != -1) {
/*  282 */       configFilePath = configFilePath.substring(0, configFilePath.lastIndexOf(".lst"));
/*      */     }
/*  284 */     return configFilePath + ".ajsym";
/*      */   }
/*      */   
/*      */   public String getCanonicalFilePath(File f) {
/*  288 */     return this.canonicalFilePathMap.get(f);
/*      */   }
/*      */   
/*      */   public CanonicalFilePathMap getCanonicalFilePathMap() {
/*  292 */     return this.canonicalFilePathMap;
/*      */   }
/*      */   
/*      */   private static class CanonicalFilePathMap
/*      */   {
/*      */     private static final int MAX_SIZE = 4000;
/*  298 */     private final Map<String, String> pathMap = new HashMap<>(20);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String get(File f) {
/*  384 */       String ret = this.pathMap.get(f.getPath());
/*  385 */       if (ret == null) {
/*      */         try {
/*  387 */           ret = f.getCanonicalPath();
/*  388 */         } catch (IOException ioEx) {
/*  389 */           ret = f.getPath();
/*      */         } 
/*  391 */         this.pathMap.put(f.getPath(), ret);
/*  392 */         if (this.pathMap.size() > 4000) {
/*  393 */           this.pathMap.clear();
/*      */         }
/*      */       } 
/*  396 */       return ret;
/*      */     }
/*      */     
/*      */     private CanonicalFilePathMap() {} }
/*      */   
/*      */   public static void setReporting(String filename, boolean dModel, boolean dRels, boolean dDeltaProcessing, boolean deletefile) {
/*  402 */     reporting = true;
/*  403 */     dumpModel = dModel;
/*  404 */     dumpRelationships = dRels;
/*  405 */     dumpDeltaProcessing = dDeltaProcessing;
/*  406 */     if (deletefile) {
/*  407 */       (new File(filename)).delete();
/*      */     }
/*  409 */     dumpFilename = filename;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setReporting(String filename, boolean dModel, boolean dRels, boolean dDeltaProcessing, boolean deletefile, IModelFilter aFilter) {
/*  414 */     setReporting(filename, dModel, dRels, dDeltaProcessing, deletefile);
/*  415 */     modelFilter = aFilter;
/*      */   }
/*      */   
/*      */   public static boolean isReporting() {
/*  419 */     return reporting;
/*      */   }
/*      */   
/*      */   public static void setDontReport() {
/*  423 */     reporting = false;
/*  424 */     dumpDeltaProcessing = false;
/*  425 */     dumpModel = false;
/*  426 */     dumpRelationships = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportModelInfo(String reasonForReport) {
/*  435 */     if (!dumpModel && !dumpRelationships) {
/*      */       return;
/*      */     }
/*      */     try {
/*  439 */       FileWriter fw = new FileWriter(dumpFilename, true);
/*  440 */       BufferedWriter bw = new BufferedWriter(fw);
/*  441 */       if (dumpModel) {
/*  442 */         bw.write("=== MODEL STATUS REPORT ========= " + reasonForReport + "\n");
/*  443 */         dumptree(bw, this.hierarchy.getRoot(), 0);
/*      */         
/*  445 */         bw.write("=== END OF MODEL REPORT =========\n");
/*      */       } 
/*  447 */       if (dumpRelationships) {
/*  448 */         bw.write("=== RELATIONSHIPS REPORT ========= " + reasonForReport + "\n");
/*  449 */         dumprels(bw);
/*  450 */         bw.write("=== END OF RELATIONSHIPS REPORT ==\n");
/*      */       } 
/*  452 */       Properties p = summarizeModel().getProperties();
/*  453 */       Enumeration<Object> pkeyenum = p.keys();
/*  454 */       bw.write("=== Properties of the model and relationships map =====\n");
/*  455 */       while (pkeyenum.hasMoreElements()) {
/*  456 */         String pkey = (String)pkeyenum.nextElement();
/*  457 */         bw.write(pkey + "=" + p.getProperty(pkey) + "\n");
/*      */       } 
/*  459 */       bw.flush();
/*  460 */       fw.close();
/*  461 */     } catch (IOException e) {
/*  462 */       System.err.println("InternalError: Unable to report model information:");
/*  463 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void dumptree(Writer w, IProgramElement node, int indent) throws IOException {
/*  468 */     for (int i = 0; i < indent; i++) {
/*  469 */       w.write(" ");
/*      */     }
/*  471 */     String loc = "";
/*  472 */     if (node != null && 
/*  473 */       node.getSourceLocation() != null) {
/*  474 */       loc = node.getSourceLocation().toString();
/*  475 */       if (modelFilter != null) {
/*  476 */         loc = modelFilter.processFilelocation(loc);
/*      */       }
/*      */     } 
/*      */     
/*  480 */     w.write(node + "  [" + ((node == null) ? "null" : node.getKind().toString()) + "] " + loc + "\n");
/*  481 */     if (node != null) {
/*  482 */       for (IProgramElement child : node.getChildren()) {
/*  483 */         dumptree(w, child, indent + 2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static void dumptree(IProgramElement node, int indent) throws IOException {
/*  489 */     for (int i = 0; i < indent; i++) {
/*  490 */       System.out.print(" ");
/*      */     }
/*  492 */     String loc = "";
/*  493 */     if (node != null && 
/*  494 */       node.getSourceLocation() != null) {
/*  495 */       loc = node.getSourceLocation().toString();
/*      */     }
/*      */     
/*  498 */     System.out.println(node + "  [" + ((node == null) ? "null" : node.getKind().toString()) + "] " + loc);
/*  499 */     if (node != null) {
/*  500 */       for (IProgramElement child : node.getChildren()) {
/*  501 */         dumptree(child, indent + 2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dumprels(Writer w) throws IOException {
/*  507 */     int ctr = 1;
/*  508 */     Set<String> entries = this.mapper.getEntries();
/*  509 */     for (String hid : entries) {
/*  510 */       List<IRelationship> rels = this.mapper.get(hid);
/*  511 */       for (IRelationship ir : rels) {
/*  512 */         List<String> targets = ir.getTargets();
/*  513 */         for (String thid : targets) {
/*  514 */           StringBuilder sb = new StringBuilder();
/*  515 */           if (modelFilter == null || modelFilter.wantsHandleIds()) {
/*  516 */             sb.append("Hid:" + ctr++ + ":");
/*      */           }
/*  518 */           sb.append("(targets=" + targets.size() + ") " + hid + " (" + ir.getName() + ") " + thid + "\n");
/*  519 */           w.write(sb.toString());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void dumprelsStderr(String key) {
/*  526 */     System.err.println("Relationships dump follows: " + key);
/*  527 */     int ctr = 1;
/*  528 */     Set<String> entries = this.mapper.getEntries();
/*  529 */     for (String hid : entries) {
/*  530 */       for (IRelationship ir : this.mapper.get(hid)) {
/*  531 */         List<String> targets = ir.getTargets();
/*  532 */         for (String thid : targets) {
/*  533 */           System.err.println("Hid:" + ctr++ + ":(targets=" + targets.size() + ") " + hid + " (" + ir.getName() + ") " + thid);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  538 */     System.err.println("End of relationships dump for: " + key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean removeStructureModelForFiles(Writer fw, Collection<File> files) throws IOException {
/*  549 */     boolean modelModified = false;
/*      */     
/*  551 */     Set<String> deletedNodes = new HashSet<>();
/*  552 */     for (File fileForCompilation : files) {
/*  553 */       String correctedPath = getCanonicalFilePath(fileForCompilation);
/*  554 */       IProgramElement progElem = this.hierarchy.findInFileMap(correctedPath);
/*  555 */       if (progElem != null) {
/*      */         
/*  557 */         if (dumpDeltaProcessing) {
/*  558 */           fw.write("Deleting " + progElem + " node for file " + fileForCompilation + "\n");
/*      */         }
/*  560 */         removeNode(progElem);
/*  561 */         this.lastBuildChanges.add(fileForCompilation);
/*  562 */         deletedNodes.add(getCanonicalFilePath(progElem.getSourceLocation().getSourceFile()));
/*  563 */         if (!this.hierarchy.removeFromFileMap(correctedPath)) {
/*  564 */           throw new RuntimeException("Whilst repairing model, couldn't remove entry for file: " + correctedPath + " from the filemap");
/*      */         }
/*      */         
/*  567 */         modelModified = true;
/*      */       } 
/*      */     } 
/*  570 */     if (modelModified) {
/*  571 */       this.hierarchy.updateHandleMap(deletedNodes);
/*      */     }
/*  573 */     return modelModified;
/*      */   }
/*      */ 
/*      */   
/*      */   public void processDelta(Collection<File> files_tobecompiled, Set<File> files_added, Set<File> files_deleted) {
/*      */     try {
/*  579 */       Writer fw = null;
/*      */ 
/*      */       
/*  582 */       if (dumpDeltaProcessing) {
/*  583 */         FileWriter filew = new FileWriter(dumpFilename, true);
/*  584 */         fw = new BufferedWriter(filew);
/*  585 */         fw.write("=== Processing delta changes for the model ===\n");
/*  586 */         fw.write("Files for compilation:#" + files_tobecompiled.size() + ":" + files_tobecompiled + "\n");
/*  587 */         fw.write("Files added          :#" + files_added.size() + ":" + files_added + "\n");
/*  588 */         fw.write("Files deleted        :#" + files_deleted.size() + ":" + files_deleted + "\n");
/*      */       } 
/*      */       
/*  591 */       long stime = System.currentTimeMillis();
/*      */ 
/*      */       
/*  594 */       removeStructureModelForFiles(fw, files_deleted);
/*  595 */       long etime1 = System.currentTimeMillis();
/*      */ 
/*      */       
/*  598 */       repairRelationships(fw);
/*  599 */       long etime2 = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */       
/*  603 */       removeStructureModelForFiles(fw, files_tobecompiled);
/*      */       
/*  605 */       if (dumpDeltaProcessing) {
/*  606 */         fw.write("===== Delta Processing timing ==========\n");
/*  607 */         fw.write("Hierarchy=" + (etime1 - stime) + "ms   Relationshipmap=" + (etime2 - etime1) + "ms\n");
/*  608 */         fw.write("===== Traversal ========================\n");
/*      */ 
/*      */         
/*  611 */         fw.write("========================================\n");
/*  612 */         fw.flush();
/*  613 */         fw.close();
/*      */       } 
/*      */       
/*  616 */       reportModelInfo("After delta processing");
/*  617 */     } catch (IOException e) {
/*  618 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private String getTypeNameFromHandle(String handle, Map<String, String> cache) {
/*      */     try {
/*  625 */       String typename = cache.get(handle);
/*  626 */       if (typename != null) {
/*  627 */         return typename;
/*      */       }
/*      */ 
/*      */       
/*  631 */       int hasPackage = handle.indexOf(HandleProviderDelimiter.PACKAGEFRAGMENT.getDelimiter());
/*  632 */       int typeLocation = handle.indexOf(HandleProviderDelimiter.TYPE.getDelimiter());
/*  633 */       if (typeLocation == -1) {
/*  634 */         typeLocation = handle.indexOf(HandleProviderDelimiter.ASPECT_TYPE.getDelimiter());
/*      */       }
/*  636 */       if (typeLocation == -1)
/*      */       {
/*  638 */         return "";
/*      */       }
/*  640 */       StringBuilder qualifiedTypeNameFromHandle = new StringBuilder();
/*  641 */       if (hasPackage != -1) {
/*  642 */         int classfileLoc = handle.indexOf(HandleProviderDelimiter.CLASSFILE.getDelimiter(), hasPackage);
/*  643 */         qualifiedTypeNameFromHandle.append(handle.substring(hasPackage + 1, classfileLoc));
/*  644 */         qualifiedTypeNameFromHandle.append('.');
/*      */       } 
/*  646 */       qualifiedTypeNameFromHandle.append(handle.substring(typeLocation + 1));
/*  647 */       typename = qualifiedTypeNameFromHandle.toString();
/*  648 */       cache.put(handle, typename);
/*  649 */       return typename;
/*  650 */     } catch (StringIndexOutOfBoundsException sioobe) {
/*      */       
/*  652 */       System.err.println("Handle processing problem, the handle is: " + handle);
/*  653 */       sioobe.printStackTrace(System.err);
/*  654 */       return "";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeRelationshipsTargettingThisType(String typename) {
/*  671 */     boolean debug = false;
/*  672 */     if (debug) {
/*  673 */       System.err.println(">>removeRelationshipsTargettingThisType " + typename);
/*      */     }
/*  675 */     String pkg = null;
/*  676 */     String type = typename;
/*  677 */     int lastSep = typename.lastIndexOf('.');
/*  678 */     if (lastSep != -1) {
/*  679 */       pkg = typename.substring(0, lastSep);
/*  680 */       type = typename.substring(lastSep + 1);
/*      */     } 
/*  682 */     boolean didsomething = false;
/*  683 */     IProgramElement typeNode = this.hierarchy.findElementForType(pkg, type);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  688 */     if (typeNode == null) {
/*      */       return;
/*      */     }
/*      */     
/*  692 */     Set<String> sourcesToRemove = new HashSet<>();
/*  693 */     Map<String, String> handleToTypenameCache = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  699 */     Set<String> sourcehandlesSet = this.mapper.getEntries();
/*  700 */     List<IRelationship> relationshipsToRemove = new ArrayList<>();
/*  701 */     for (String hid : sourcehandlesSet) {
/*  702 */       if (isPhantomHandle(hid))
/*      */       {
/*      */         
/*  705 */         if (!getTypeNameFromHandle(hid, handleToTypenameCache).equals(typename)) {
/*      */           continue;
/*      */         }
/*      */       }
/*  709 */       IProgramElement sourceElement = this.hierarchy.getElement(hid);
/*  710 */       if (sourceElement == null || sameType(hid, sourceElement, typeNode)) {
/*      */         
/*  712 */         relationshipsToRemove.clear();
/*  713 */         List<IRelationship> relationships = this.mapper.get(hid);
/*  714 */         for (IRelationship relationship : relationships) {
/*  715 */           if (relationship.getKind() == IRelationship.Kind.USES_POINTCUT) {
/*      */             continue;
/*      */           }
/*      */           
/*  719 */           if (relationship.isAffects()) {
/*      */             continue;
/*      */           }
/*      */           
/*  723 */           relationshipsToRemove.add(relationship);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  729 */         if (relationshipsToRemove.size() > 0) {
/*  730 */           didsomething = true;
/*  731 */           if (relationshipsToRemove.size() == relationships.size()) {
/*  732 */             sourcesToRemove.add(hid); continue;
/*      */           } 
/*  734 */           for (IRelationship iRelationship : relationshipsToRemove) {
/*  735 */             relationships.remove(iRelationship);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  742 */     for (String hid : sourcesToRemove) {
/*      */ 
/*      */       
/*  745 */       this.mapper.removeAll(hid);
/*  746 */       IProgramElement ipe = this.hierarchy.getElement(hid);
/*  747 */       if (ipe != null)
/*      */       {
/*  749 */         if (ipe.getKind().equals(IProgramElement.Kind.CODE)) {
/*  750 */           if (debug) {
/*  751 */             System.err.println("  source handle: it was code node, removing that as well... code=" + ipe + " parent=" + ipe
/*  752 */                 .getParent());
/*      */           }
/*  754 */           removeSingleNode(ipe);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  759 */     if (debug) {
/*  760 */       dumprelsStderr("after processing 'affectedby'");
/*      */     }
/*  762 */     if (didsomething) {
/*  763 */       sourcesToRemove.clear();
/*      */       
/*  765 */       if (debug) {
/*  766 */         dumprelsStderr("before processing 'affects'");
/*      */       }
/*      */       
/*  769 */       sourcehandlesSet = this.mapper.getEntries();
/*  770 */       for (String hid : sourcehandlesSet) {
/*  771 */         relationshipsToRemove.clear();
/*  772 */         List<IRelationship> relationships = this.mapper.get(hid);
/*  773 */         for (IRelationship rel : relationships) {
/*  774 */           if (rel.getKind() == IRelationship.Kind.USES_POINTCUT) {
/*      */             continue;
/*      */           }
/*      */           
/*  778 */           if (!rel.isAffects()) {
/*      */             continue;
/*      */           }
/*  781 */           List<String> targets = rel.getTargets();
/*  782 */           List<String> targetsToRemove = new ArrayList<>();
/*      */ 
/*      */ 
/*      */           
/*  786 */           for (String targethid : targets) {
/*  787 */             if (isPhantomHandle(hid) && !getTypeNameFromHandle(hid, handleToTypenameCache).equals(typename)) {
/*      */               continue;
/*      */             }
/*      */             
/*  791 */             IProgramElement existingTarget = this.hierarchy.getElement(targethid);
/*  792 */             if (existingTarget == null || sameType(targethid, existingTarget, typeNode)) {
/*  793 */               targetsToRemove.add(targethid);
/*      */             }
/*      */           } 
/*      */           
/*  797 */           if (targetsToRemove.size() != 0) {
/*  798 */             if (targetsToRemove.size() == targets.size()) {
/*  799 */               relationshipsToRemove.add(rel);
/*      */               continue;
/*      */             } 
/*  802 */             for (String togo : targetsToRemove) {
/*  803 */               targets.remove(togo);
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  810 */         if (relationshipsToRemove.size() > 0) {
/*      */ 
/*      */           
/*  813 */           if (relationshipsToRemove.size() == relationships.size()) {
/*  814 */             sourcesToRemove.add(hid); continue;
/*      */           } 
/*  816 */           for (IRelationship iRelationship : relationshipsToRemove) {
/*  817 */             relationships.remove(iRelationship);
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  823 */       for (String hid : sourcesToRemove) {
/*      */ 
/*      */         
/*  826 */         this.mapper.removeAll(hid);
/*  827 */         IProgramElement ipe = this.hierarchy.getElement(hid);
/*  828 */         if (ipe != null)
/*      */         {
/*      */           
/*  831 */           if (ipe.getKind().equals(IProgramElement.Kind.CODE)) {
/*  832 */             if (debug) {
/*  833 */               System.err.println("  source handle: it was code node, removing that as well... code=" + ipe + " parent=" + ipe
/*  834 */                   .getParent());
/*      */             }
/*  836 */             removeSingleNode(ipe);
/*      */           } 
/*      */         }
/*      */       } 
/*  840 */       if (debug) {
/*  841 */         dumprelsStderr("after processing 'affects'");
/*      */       }
/*      */     } 
/*      */     
/*  845 */     if (debug) {
/*  846 */       System.err.println("<<removeRelationshipsTargettingThisFile");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean sameType(String hid, IProgramElement target, IProgramElement type) {
/*  854 */     IProgramElement containingType = target;
/*  855 */     if (target == null) {
/*  856 */       throw new RuntimeException("target can't be null!");
/*      */     }
/*  858 */     if (type == null) {
/*  859 */       throw new RuntimeException("type can't be null!");
/*      */     }
/*  861 */     if (target.getKind().isSourceFile() || target.getKind().isFile()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  873 */       if (target.getSourceLocation() == null) {
/*  874 */         return false;
/*      */       }
/*      */       
/*  877 */       if (type.getSourceLocation() == null) {
/*  878 */         return false;
/*      */       }
/*  880 */       if (target.getSourceLocation().getSourceFile() == null) {
/*  881 */         return false;
/*      */       }
/*  883 */       if (type.getSourceLocation().getSourceFile() == null) {
/*  884 */         return false;
/*      */       }
/*  886 */       return target.getSourceLocation().getSourceFile().equals(type.getSourceLocation().getSourceFile());
/*      */     } 
/*      */     try {
/*  889 */       while (!containingType.getKind().isType()) {
/*  890 */         containingType = containingType.getParent();
/*      */       }
/*  892 */     } catch (Throwable t) {
/*      */ 
/*      */ 
/*      */       
/*  896 */       throw new RuntimeException("Exception whilst walking up from target " + target.toLabelString() + " kind=(" + target
/*  897 */           .getKind() + ") hid=(" + target.getHandleIdentifier() + ")", t);
/*      */     } 
/*  899 */     return type.equals(containingType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isPhantomHandle(String handle) {
/*  907 */     int phantomMarker = handle.indexOf(HandleProviderDelimiter.PHANTOM.getDelimiter());
/*  908 */     return (phantomMarker != -1 && handle
/*  909 */       .charAt(phantomMarker - 1) == HandleProviderDelimiter.PACKAGEFRAGMENTROOT.getDelimiter());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void repairRelationships(Writer fw) {
/*      */     try {
/*  924 */       if (dumpDeltaProcessing) {
/*  925 */         fw.write("Repairing relationships map:\n");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  930 */       Set<String> sourcesToRemove = new HashSet<>();
/*  931 */       Set<String> nonExistingHandles = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  937 */       Set<String> keyset = this.mapper.getEntries();
/*  938 */       for (String hid : keyset) {
/*      */ 
/*      */ 
/*      */         
/*  942 */         if (nonExistingHandles.contains(hid)) {
/*  943 */           sourcesToRemove.add(hid); continue;
/*  944 */         }  if (!isPhantomHandle(hid)) {
/*      */           
/*  946 */           IProgramElement existingElement = this.hierarchy.getElement(hid);
/*  947 */           if (dumpDeltaProcessing) {
/*  948 */             fw.write("Looking for handle [" + hid + "] in model, found: " + existingElement + "\n");
/*      */           }
/*      */           
/*  951 */           if (existingElement == null) {
/*      */             
/*  953 */             sourcesToRemove.add(hid);
/*  954 */             nonExistingHandles.add(hid);
/*      */             continue;
/*      */           } 
/*  957 */           List<IRelationship> relationships = this.mapper.get(hid);
/*  958 */           List<IRelationship> relationshipsToRemove = new ArrayList<>();
/*      */ 
/*      */           
/*  961 */           for (IRelationship rel : relationships) {
/*  962 */             List<String> targets = rel.getTargets();
/*  963 */             List<String> targetsToRemove = new ArrayList<>();
/*      */ 
/*      */             
/*  966 */             for (String targethid : targets) {
/*      */ 
/*      */               
/*  969 */               if (nonExistingHandles.contains(targethid)) {
/*  970 */                 if (dumpDeltaProcessing) {
/*  971 */                   fw.write("Target handle [" + targethid + "] for srchid[" + hid + "]rel[" + rel.getName() + "] does not exist\n");
/*      */                 }
/*      */                 
/*  974 */                 targetsToRemove.add(targethid); continue;
/*  975 */               }  if (!isPhantomHandle(targethid)) {
/*      */                 
/*  977 */                 IProgramElement existingTarget = this.hierarchy.getElement(targethid);
/*  978 */                 if (existingTarget == null) {
/*  979 */                   if (dumpDeltaProcessing) {
/*  980 */                     fw.write("Target handle [" + targethid + "] for srchid[" + hid + "]rel[" + rel
/*  981 */                         .getName() + "] does not exist\n");
/*      */                   }
/*  983 */                   targetsToRemove.add(targethid);
/*  984 */                   nonExistingHandles.add(targethid);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/*  990 */             if (targetsToRemove.size() != 0) {
/*      */ 
/*      */               
/*  993 */               if (targetsToRemove.size() == targets.size()) {
/*  994 */                 if (dumpDeltaProcessing) {
/*  995 */                   fw.write("No targets remain for srchid[" + hid + "] rel[" + rel.getName() + "]: removing it\n");
/*      */                 }
/*      */                 
/*  998 */                 relationshipsToRemove.add(rel);
/*      */                 
/*      */                 continue;
/*      */               } 
/* 1002 */               for (String togo : targetsToRemove) {
/* 1003 */                 targets.remove(togo);
/*      */               }
/*      */ 
/*      */               
/* 1007 */               if (targets.size() == 0) {
/* 1008 */                 if (dumpDeltaProcessing) {
/* 1009 */                   fw.write("No targets remain for srchid[" + hid + "] rel[" + rel.getName() + "]: removing it\n");
/*      */                 }
/*      */                 
/* 1012 */                 relationshipsToRemove.add(rel);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1029 */           if (relationshipsToRemove.size() > 0) {
/*      */ 
/*      */             
/* 1032 */             if (relationshipsToRemove.size() == relationships.size()) {
/*      */ 
/*      */               
/* 1035 */               sourcesToRemove.add(hid);
/*      */               
/*      */               continue;
/*      */             } 
/* 1039 */             for (IRelationship irel : relationshipsToRemove) {
/* 1040 */               verifyAssumption(this.mapper.remove(hid, irel), "Failed to remove relationship " + irel.getName() + " for shid " + hid);
/*      */             }
/*      */             
/* 1043 */             List<IRelationship> rels = this.mapper.get(hid);
/* 1044 */             if (rels == null || rels.size() == 0) {
/* 1045 */               sourcesToRemove.add(hid);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1053 */       for (String hid : sourcesToRemove) {
/* 1054 */         this.mapper.removeAll(hid);
/* 1055 */         IProgramElement ipe = this.hierarchy.getElement(hid);
/* 1056 */         if (ipe != null)
/*      */         {
/*      */           
/* 1059 */           if (ipe.getKind().equals(IProgramElement.Kind.CODE))
/*      */           {
/* 1061 */             removeSingleNode(ipe);
/*      */           }
/*      */         }
/*      */       } 
/* 1065 */     } catch (IOException ioe) {
/* 1066 */       System.err.println("Failed to repair relationships:");
/* 1067 */       ioe.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeSingleNode(IProgramElement progElem) {
/* 1076 */     if (progElem == null) {
/* 1077 */       throw new IllegalStateException("AsmManager.removeNode(): programElement unexpectedly null");
/*      */     }
/* 1079 */     boolean deleteOK = false;
/* 1080 */     IProgramElement parent = progElem.getParent();
/* 1081 */     List<IProgramElement> kids = parent.getChildren();
/* 1082 */     for (int i = 0, max = kids.size(); i < max; i++) {
/* 1083 */       if (((IProgramElement)kids.get(i)).equals(progElem)) {
/* 1084 */         kids.remove(i);
/* 1085 */         deleteOK = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1089 */     if (!deleteOK) {
/* 1090 */       System.err.println("unexpectedly failed to delete node from model.  hid=" + progElem.getHandleIdentifier());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeNode(IProgramElement progElem) {
/*      */     try {
/* 1109 */       if (progElem == null) {
/* 1110 */         throw new IllegalStateException("AsmManager.removeNode(): programElement unexpectedly null");
/*      */       }
/*      */       
/* 1113 */       IProgramElement parent = progElem.getParent();
/*      */       
/* 1115 */       List<IProgramElement> kids = parent.getChildren();
/*      */       
/* 1117 */       for (int i = 0; i < kids.size(); i++) {
/*      */         
/* 1119 */         if (((IProgramElement)kids.get(i)).equals(progElem)) {
/* 1120 */           kids.remove(i);
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1128 */       if (parent.getChildren().size() == 0 && parent
/* 1129 */         .getParent() != null && (parent
/* 1130 */         .getKind().equals(IProgramElement.Kind.CODE) || parent.getKind().equals(IProgramElement.Kind.PACKAGE)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1136 */         removeNode(parent);
/*      */       }
/* 1138 */     } catch (NullPointerException npe) {
/*      */ 
/*      */ 
/*      */       
/* 1142 */       npe.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void verifyAssumption(boolean b, String info) {
/* 1147 */     if (!b) {
/* 1148 */       System.err.println("=========== ASSERTION IS NOT TRUE =========v");
/* 1149 */       System.err.println(info);
/* 1150 */       Thread.dumpStack();
/* 1151 */       System.err.println("=========== ASSERTION IS NOT TRUE =========^");
/* 1152 */       throw new RuntimeException("Assertion is false");
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void verifyAssumption(boolean b) {
/* 1157 */     if (!b) {
/* 1158 */       Thread.dumpStack();
/* 1159 */       throw new RuntimeException("Assertion is false");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ModelInfo
/*      */   {
/* 1170 */     private final Hashtable<String, Integer> nodeTypeCount = new Hashtable<>();
/* 1171 */     private final Properties extraProperties = new Properties();
/*      */     
/*      */     private ModelInfo(IHierarchy hierarchy, IRelationshipMap relationshipMap) {
/* 1174 */       IProgramElement ipe = hierarchy.getRoot();
/* 1175 */       walkModel(ipe);
/* 1176 */       recordStat("FileMapSize", Integer.toString(hierarchy.getFileMapEntrySet().size()));
/* 1177 */       recordStat("RelationshipMapSize", Integer.toString(relationshipMap.getEntries().size()));
/*      */     }
/*      */     
/*      */     private void walkModel(IProgramElement ipe) {
/* 1181 */       countNode(ipe);
/* 1182 */       for (IProgramElement child : ipe.getChildren()) {
/* 1183 */         walkModel(child);
/*      */       }
/*      */     }
/*      */     
/*      */     private void countNode(IProgramElement ipe) {
/* 1188 */       String node = ipe.getKind().toString();
/* 1189 */       Integer ctr = this.nodeTypeCount.get(node);
/* 1190 */       if (ctr == null) {
/* 1191 */         this.nodeTypeCount.put(node, Integer.valueOf(1));
/*      */       } else {
/* 1193 */         ctr = Integer.valueOf(ctr.intValue() + 1);
/* 1194 */         this.nodeTypeCount.put(node, ctr);
/*      */       } 
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1199 */       StringBuilder sb = new StringBuilder();
/* 1200 */       sb.append("Model node summary:\n");
/* 1201 */       Enumeration<String> nodeKeys = this.nodeTypeCount.keys();
/* 1202 */       while (nodeKeys.hasMoreElements()) {
/* 1203 */         String key = nodeKeys.nextElement();
/* 1204 */         Integer ct = this.nodeTypeCount.get(key);
/* 1205 */         sb.append(key + "=" + ct + "\n");
/*      */       } 
/* 1207 */       sb.append("Model stats:\n");
/* 1208 */       Enumeration<Object> ks = this.extraProperties.keys();
/* 1209 */       while (ks.hasMoreElements()) {
/* 1210 */         String k = (String)ks.nextElement();
/* 1211 */         String v = this.extraProperties.getProperty(k);
/* 1212 */         sb.append(k + "=" + v + "\n");
/*      */       } 
/* 1214 */       return sb.toString();
/*      */     }
/*      */     
/*      */     public Properties getProperties() {
/* 1218 */       Properties p = new Properties();
/* 1219 */       for (Map.Entry<String, Integer> entry : this.nodeTypeCount.entrySet()) {
/* 1220 */         p.setProperty(entry.getKey(), ((Integer)entry.getValue()).toString());
/*      */       }
/* 1222 */       p.putAll(this.extraProperties);
/* 1223 */       return p;
/*      */     }
/*      */     
/*      */     public void recordStat(String string, String string2) {
/* 1227 */       this.extraProperties.setProperty(string, string2);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public ModelInfo summarizeModel() {
/* 1233 */     return new ModelInfo(getHierarchy(), getRelationshipMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCompletingTypeBindings(boolean b) {
/* 1251 */     completingTypeBindings = b;
/*      */   }
/*      */   
/*      */   public static boolean isCompletingTypeBindings() {
/* 1255 */     return completingTypeBindings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetDeltaProcessing() {
/* 1267 */     this.lastBuildChanges.clear();
/* 1268 */     this.aspectsWeavingInLastBuild.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<File> getModelChangesOnLastBuild() {
/* 1276 */     return this.lastBuildChanges;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<File> getAspectsWeavingFilesOnLastBuild() {
/* 1283 */     return this.aspectsWeavingInLastBuild;
/*      */   }
/*      */   
/*      */   public void addAspectInEffectThisBuild(File f) {
/* 1287 */     this.aspectsWeavingInLastBuild.add(f);
/*      */   }
/*      */   
/*      */   public static void setLastActiveStructureModel(AsmManager structureModel) {
/* 1291 */     if (recordingLastActiveStructureModel) {
/* 1292 */       lastActiveStructureModel = structureModel;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getHandleElementForInpath(String binaryPath) {
/* 1297 */     return this.inpathMap.get(new File(binaryPath));
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\AsmManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */