/*    */ package org.aspectj.asm;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.aspectj.asm.internal.ProgramElement;
/*    */ import org.aspectj.bridge.ISourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IHierarchy
/*    */   extends Serializable
/*    */ {
/* 29 */   public static final IProgramElement NO_STRUCTURE = (IProgramElement)new ProgramElement(null, "<build to view structure>", IProgramElement.Kind.ERROR, null);
/*    */ 
/*    */   
/*    */   IProgramElement getElement(String paramString);
/*    */   
/*    */   IProgramElement getRoot();
/*    */   
/*    */   void setRoot(IProgramElement paramIProgramElement);
/*    */   
/*    */   void addToFileMap(String paramString, IProgramElement paramIProgramElement);
/*    */   
/*    */   boolean removeFromFileMap(String paramString);
/*    */   
/*    */   void setFileMap(Map<String, IProgramElement> paramMap);
/*    */   
/*    */   default void setFileMap(HashMap<String, IProgramElement> fileMap) {
/* 45 */     setFileMap(fileMap);
/*    */   }
/*    */   
/*    */   IProgramElement findInFileMap(String paramString);
/*    */   
/*    */   Set<Map.Entry<String, IProgramElement>> getFileMapEntrySet();
/*    */   
/*    */   boolean isValid();
/*    */   
/*    */   IProgramElement findElementForHandle(String paramString);
/*    */   
/*    */   IProgramElement findElementForHandleOrCreate(String paramString, boolean paramBoolean);
/*    */   
/*    */   IProgramElement findElementForSignature(IProgramElement paramIProgramElement, IProgramElement.Kind paramKind, String paramString);
/*    */   
/*    */   IProgramElement findElementForLabel(IProgramElement paramIProgramElement, IProgramElement.Kind paramKind, String paramString);
/*    */   
/*    */   IProgramElement findElementForType(String paramString1, String paramString2);
/*    */   
/*    */   IProgramElement findElementForSourceFile(String paramString);
/*    */   
/*    */   IProgramElement findElementForSourceLine(ISourceLocation paramISourceLocation);
/*    */   
/*    */   IProgramElement findElementForSourceLine(String paramString, int paramInt);
/*    */   
/*    */   IProgramElement findElementForOffSet(String paramString, int paramInt1, int paramInt2);
/*    */   
/*    */   String getConfigFile();
/*    */   
/*    */   void setConfigFile(String paramString);
/*    */   
/*    */   void flushTypeMap();
/*    */   
/*    */   void flushHandleMap();
/*    */   
/*    */   void updateHandleMap(Set<String> paramSet);
/*    */   
/*    */   IProgramElement findCloserMatchForLineNumber(IProgramElement paramIProgramElement, int paramInt);
/*    */   
/*    */   IProgramElement findNodeForSourceFile(IProgramElement paramIProgramElement, String paramString);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IHierarchy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */