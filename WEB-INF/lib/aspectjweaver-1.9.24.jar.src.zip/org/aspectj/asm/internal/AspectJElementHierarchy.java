/*     */ package org.aspectj.asm.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.aspectj.asm.AsmManager;
/*     */ import org.aspectj.asm.IHierarchy;
/*     */ import org.aspectj.asm.IProgramElement;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ import org.aspectj.bridge.SourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJElementHierarchy
/*     */   implements IHierarchy
/*     */ {
/*     */   private static final long serialVersionUID = 6462734311117048620L;
/*     */   private transient AsmManager asm;
/*  40 */   protected IProgramElement root = null;
/*  41 */   protected String configFile = null;
/*     */ 
/*     */ 
/*     */   
/*  45 */   private Map<String, IProgramElement> fileMap = null;
/*  46 */   private Map<String, IProgramElement> handleMap = new HashMap<>();
/*  47 */   private Map<String, IProgramElement> typeMap = null;
/*     */   
/*     */   public AspectJElementHierarchy(AsmManager asm) {
/*  50 */     this.asm = asm;
/*     */   }
/*     */   
/*     */   public IProgramElement getElement(String handle) {
/*  54 */     return findElementForHandleOrCreate(handle, false);
/*     */   }
/*     */   
/*     */   public void setAsmManager(AsmManager asm) {
/*  58 */     this.asm = asm;
/*     */   }
/*     */   
/*     */   public IProgramElement getRoot() {
/*  62 */     return this.root;
/*     */   }
/*     */   
/*     */   public String toSummaryString() {
/*  66 */     StringBuilder s = new StringBuilder();
/*  67 */     s.append("FileMap has " + this.fileMap.size() + " entries\n");
/*  68 */     s.append("HandleMap has " + this.handleMap.size() + " entries\n");
/*  69 */     s.append("TypeMap has " + this.handleMap.size() + " entries\n");
/*  70 */     s.append("FileMap:\n");
/*  71 */     for (Map.Entry<String, IProgramElement> fileMapEntry : this.fileMap.entrySet()) {
/*  72 */       s.append(fileMapEntry).append("\n");
/*     */     }
/*  74 */     s.append("TypeMap:\n");
/*  75 */     for (Map.Entry<String, IProgramElement> typeMapEntry : this.typeMap.entrySet()) {
/*  76 */       s.append(typeMapEntry).append("\n");
/*     */     }
/*  78 */     s.append("HandleMap:\n");
/*  79 */     for (Map.Entry<String, IProgramElement> handleMapEntry : this.handleMap.entrySet()) {
/*  80 */       s.append(handleMapEntry).append("\n");
/*     */     }
/*  82 */     return s.toString();
/*     */   }
/*     */   
/*     */   public void setRoot(IProgramElement root) {
/*  86 */     this.root = root;
/*  87 */     this.handleMap = new HashMap<>();
/*  88 */     this.typeMap = new HashMap<>();
/*     */   }
/*     */   
/*     */   public void addToFileMap(String key, IProgramElement value) {
/*  92 */     this.fileMap.put(key, value);
/*     */   }
/*     */   
/*     */   public boolean removeFromFileMap(String canonicalFilePath) {
/*  96 */     return (this.fileMap.remove(canonicalFilePath) != null);
/*     */   }
/*     */   
/*     */   public void setFileMap(Map<String, IProgramElement> fileMap) {
/* 100 */     this.fileMap = fileMap;
/*     */   }
/*     */   
/*     */   public IProgramElement findInFileMap(String key) {
/* 104 */     return this.fileMap.get(key);
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, IProgramElement>> getFileMapEntrySet() {
/* 108 */     return this.fileMap.entrySet();
/*     */   }
/*     */   
/*     */   public boolean isValid() {
/* 112 */     return (this.root != null && this.fileMap != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForSignature(IProgramElement parent, IProgramElement.Kind kind, String signature) {
/* 123 */     for (IProgramElement node : parent.getChildren()) {
/* 124 */       if (node.getKind() == kind && signature.equals(node.toSignatureString())) {
/* 125 */         return node;
/*     */       }
/* 127 */       IProgramElement childSearch = findElementForSignature(node, kind, signature);
/* 128 */       if (childSearch != null) {
/* 129 */         return childSearch;
/*     */       }
/*     */     } 
/*     */     
/* 133 */     return null;
/*     */   }
/*     */   
/*     */   public IProgramElement findElementForLabel(IProgramElement parent, IProgramElement.Kind kind, String label) {
/* 137 */     for (IProgramElement node : parent.getChildren()) {
/* 138 */       if (node.getKind() == kind && label.equals(node.toLabelString())) {
/* 139 */         return node;
/*     */       }
/* 141 */       IProgramElement childSearch = findElementForLabel(node, kind, label);
/* 142 */       if (childSearch != null) {
/* 143 */         return childSearch;
/*     */       }
/*     */     } 
/*     */     
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForType(String packageName, String typeName) {
/* 159 */     synchronized (this) {
/*     */       
/* 161 */       StringBuilder keyb = (packageName == null) ? new StringBuilder() : new StringBuilder(packageName);
/* 162 */       keyb.append(".").append(typeName);
/* 163 */       String key = keyb.toString();
/* 164 */       IProgramElement cachedValue = this.typeMap.get(key);
/* 165 */       if (cachedValue != null) {
/* 166 */         return cachedValue;
/*     */       }
/*     */       
/* 169 */       List<IProgramElement> packageNodes = findMatchingPackages(packageName);
/*     */       
/* 171 */       for (IProgramElement pkg : packageNodes) {
/*     */         
/* 173 */         for (IProgramElement fileNode : pkg.getChildren()) {
/* 174 */           IProgramElement cNode = findClassInNodes(fileNode.getChildren(), typeName, typeName);
/* 175 */           if (cNode != null) {
/* 176 */             this.typeMap.put(key, cNode);
/* 177 */             return cNode;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IProgramElement> findMatchingPackages(String packagename) {
/* 225 */     List<IProgramElement> children = this.root.getChildren();
/*     */     
/* 227 */     if (children.size() == 0) {
/* 228 */       return Collections.emptyList();
/*     */     }
/* 230 */     if (((IProgramElement)children.get(0)).getKind() == IProgramElement.Kind.SOURCE_FOLDER) {
/* 231 */       String searchPackageName = (packagename == null) ? "" : packagename;
/*     */       
/* 233 */       List<IProgramElement> matchingPackageNodes = new ArrayList<>();
/* 234 */       for (IProgramElement sourceFolder : children) {
/* 235 */         List<IProgramElement> possiblePackageNodes = sourceFolder.getChildren();
/* 236 */         for (IProgramElement possiblePackageNode : possiblePackageNodes) {
/* 237 */           if (possiblePackageNode.getKind() == IProgramElement.Kind.PACKAGE && 
/* 238 */             possiblePackageNode.getName().equals(searchPackageName)) {
/* 239 */             matchingPackageNodes.add(possiblePackageNode);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 245 */       return matchingPackageNodes;
/*     */     } 
/*     */ 
/*     */     
/* 249 */     if (packagename == null) {
/*     */       
/* 251 */       List<IProgramElement> list = new ArrayList<>();
/* 252 */       list.add(this.root);
/* 253 */       return list;
/*     */     } 
/* 255 */     List<IProgramElement> result = new ArrayList<>();
/* 256 */     for (IProgramElement possiblePackage : children) {
/* 257 */       if (possiblePackage.getKind() == IProgramElement.Kind.PACKAGE && possiblePackage.getName().equals(packagename)) {
/* 258 */         result.add(possiblePackage);
/*     */       }
/* 260 */       if (possiblePackage.getKind() == IProgramElement.Kind.SOURCE_FOLDER && 
/* 261 */         possiblePackage.getName().equals("binaries")) {
/* 262 */         for (IProgramElement possiblePackage2 : possiblePackage.getChildren()) {
/* 263 */           if (possiblePackage2.getKind() == IProgramElement.Kind.PACKAGE && possiblePackage2
/* 264 */             .getName().equals(packagename)) {
/* 265 */             result.add(possiblePackage2);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 272 */     if (result.isEmpty()) {
/* 273 */       return Collections.emptyList();
/*     */     }
/* 275 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IProgramElement findClassInNodes(Collection<IProgramElement> nodes, String name, String typeName) {
/*     */     String baseName, innerName;
/* 283 */     int dollar = name.indexOf('$');
/* 284 */     if (dollar == -1) {
/* 285 */       baseName = name;
/* 286 */       innerName = null;
/*     */     } else {
/* 288 */       baseName = name.substring(0, dollar);
/* 289 */       innerName = name.substring(dollar + 1);
/*     */     } 
/*     */     
/* 292 */     for (IProgramElement classNode : nodes) {
/* 293 */       if (!classNode.getKind().isType()) {
/* 294 */         List<IProgramElement> kids = classNode.getChildren();
/* 295 */         if (kids != null && !kids.isEmpty()) {
/* 296 */           IProgramElement node = findClassInNodes(kids, name, typeName);
/* 297 */           if (node != null)
/* 298 */             return node; 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 302 */       if (baseName.equals(classNode.getName())) {
/* 303 */         if (innerName == null) {
/* 304 */           return classNode;
/*     */         }
/* 306 */         return findClassInNodes(classNode.getChildren(), innerName, typeName);
/*     */       } 
/* 308 */       if (name.equals(classNode.getName()))
/* 309 */         return classNode; 
/* 310 */       if (typeName.equals(classNode.getBytecodeSignature()))
/* 311 */         return classNode; 
/* 312 */       if (classNode.getChildren() != null && !classNode.getChildren().isEmpty()) {
/* 313 */         IProgramElement node = findClassInNodes(classNode.getChildren(), name, typeName);
/* 314 */         if (node != null) {
/* 315 */           return node;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 320 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForSourceFile(String sourceFile) {
/*     */     try {
/* 329 */       if (!isValid() || sourceFile == null) {
/* 330 */         return IHierarchy.NO_STRUCTURE;
/*     */       }
/* 332 */       String correctedPath = this.asm.getCanonicalFilePath(new File(sourceFile));
/*     */       
/* 334 */       IProgramElement node = findInFileMap(correctedPath);
/* 335 */       if (node != null) {
/* 336 */         return node;
/*     */       }
/* 338 */       return createFileStructureNode(correctedPath);
/*     */     
/*     */     }
/* 341 */     catch (Exception e) {
/* 342 */       return IHierarchy.NO_STRUCTURE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForSourceLine(ISourceLocation location) {
/*     */     try {
/* 351 */       return findElementForSourceLine(this.asm.getCanonicalFilePath(location.getSourceFile()), location.getLine());
/* 352 */     } catch (Exception e) {
/* 353 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForSourceLine(String sourceFilePath, int lineNumber) {
/* 365 */     String canonicalSFP = this.asm.getCanonicalFilePath(new File(sourceFilePath));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 370 */     IProgramElement node = findNodeForSourceFile(this.root, canonicalSFP);
/* 371 */     if (node == null) {
/* 372 */       return createFileStructureNode(sourceFilePath);
/*     */     }
/*     */ 
/*     */     
/* 376 */     IProgramElement closernode = findCloserMatchForLineNumber(node, lineNumber);
/* 377 */     if (closernode == null) {
/* 378 */       return node;
/*     */     }
/* 380 */     return closernode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findNodeForSourceFile(IProgramElement node, String sourcefilePath) {
/* 394 */     if ((node.getKind().isSourceFile() && !node.getName().equals("<root>")) || node.getKind().isFile()) {
/* 395 */       ISourceLocation nodeLoc = node.getSourceLocation();
/* 396 */       if (nodeLoc != null && this.asm.getCanonicalFilePath(nodeLoc.getSourceFile()).equals(sourcefilePath)) {
/* 397 */         return node;
/*     */       }
/* 399 */       return null;
/*     */     } 
/*     */     
/* 402 */     for (IProgramElement child : node.getChildren()) {
/* 403 */       IProgramElement foundit = findNodeForSourceFile(child, sourcefilePath);
/* 404 */       if (foundit != null) {
/* 405 */         return foundit;
/*     */       }
/*     */     } 
/* 408 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForOffSet(String sourceFilePath, int lineNumber, int offSet) {
/* 413 */     String canonicalSFP = this.asm.getCanonicalFilePath(new File(sourceFilePath));
/* 414 */     IProgramElement node = findNodeForSourceLineHelper(this.root, canonicalSFP, lineNumber, offSet);
/* 415 */     if (node != null) {
/* 416 */       return node;
/*     */     }
/* 418 */     return createFileStructureNode(sourceFilePath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private IProgramElement createFileStructureNode(String sourceFilePath) {
/* 424 */     int lastSlash = sourceFilePath.lastIndexOf('\\');
/* 425 */     if (lastSlash == -1) {
/* 426 */       lastSlash = sourceFilePath.lastIndexOf('/');
/*     */     }
/*     */     
/* 429 */     int i = sourceFilePath.lastIndexOf('!');
/* 430 */     int j = sourceFilePath.indexOf(".class");
/* 431 */     if (i > lastSlash && i != -1 && j != -1)
/*     */     {
/* 433 */       lastSlash = i;
/*     */     }
/* 435 */     String fileName = sourceFilePath.substring(lastSlash + 1);
/* 436 */     IProgramElement fileNode = new ProgramElement(this.asm, fileName, IProgramElement.Kind.FILE_JAVA, (ISourceLocation)new SourceLocation(new File(sourceFilePath), 1, 1), 0, null, null);
/*     */ 
/*     */     
/* 439 */     fileNode.addChild(NO_STRUCTURE);
/* 440 */     return fileNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findCloserMatchForLineNumber(IProgramElement node, int lineno) {
/* 451 */     if (node == null || node.getChildren() == null) {
/* 452 */       return null;
/*     */     }
/* 454 */     for (IProgramElement child : node.getChildren()) {
/* 455 */       ISourceLocation childLoc = child.getSourceLocation();
/* 456 */       if (childLoc != null) {
/* 457 */         if (childLoc.getLine() <= lineno && childLoc.getEndLine() >= lineno) {
/*     */           
/* 459 */           IProgramElement evenCloserMatch = findCloserMatchForLineNumber(child, lineno);
/* 460 */           if (evenCloserMatch == null) {
/* 461 */             return child;
/*     */           }
/* 463 */           return evenCloserMatch;
/*     */         } 
/* 465 */         if (child.getKind().isType()) {
/*     */           
/* 467 */           IProgramElement evenCloserMatch = findCloserMatchForLineNumber(child, lineno);
/* 468 */           if (evenCloserMatch != null) {
/* 469 */             return evenCloserMatch;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 474 */     return null;
/*     */   }
/*     */   
/*     */   private IProgramElement findNodeForSourceLineHelper(IProgramElement node, String sourceFilePath, int lineno, int offset) {
/* 478 */     if (matches(node, sourceFilePath, lineno, offset) && !hasMoreSpecificChild(node, sourceFilePath, lineno, offset)) {
/* 479 */       return node;
/*     */     }
/*     */     
/* 482 */     if (node != null) {
/* 483 */       for (IProgramElement child : node.getChildren()) {
/* 484 */         IProgramElement foundNode = findNodeForSourceLineHelper(child, sourceFilePath, lineno, offset);
/* 485 */         if (foundNode != null) {
/* 486 */           return foundNode;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 491 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(IProgramElement node, String sourceFilePath, int lineNumber, int offSet) {
/* 501 */     ISourceLocation nodeSourceLocation = (node != null) ? node.getSourceLocation() : null;
/* 502 */     return (node != null && nodeSourceLocation != null && nodeSourceLocation
/*     */       
/* 504 */       .getSourceFile().getAbsolutePath().equals(sourceFilePath) && ((offSet != -1 && nodeSourceLocation
/* 505 */       .getOffset() == offSet) || offSet == -1) && ((nodeSourceLocation
/* 506 */       .getLine() <= lineNumber && nodeSourceLocation.getEndLine() >= lineNumber) || (lineNumber <= 1 && node
/* 507 */       .getKind().isSourceFile())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMoreSpecificChild(IProgramElement node, String sourceFilePath, int lineNumber, int offSet) {
/* 514 */     for (IProgramElement child : node.getChildren()) {
/* 515 */       if (matches(child, sourceFilePath, lineNumber, offSet)) {
/* 516 */         return true;
/*     */       }
/*     */     } 
/* 519 */     return false;
/*     */   }
/*     */   
/*     */   public String getConfigFile() {
/* 523 */     return this.configFile;
/*     */   }
/*     */   
/*     */   public void setConfigFile(String configFile) {
/* 527 */     this.configFile = configFile;
/*     */   }
/*     */   
/*     */   public IProgramElement findElementForHandle(String handle) {
/* 531 */     return findElementForHandleOrCreate(handle, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProgramElement findElementForHandleOrCreate(String handle, boolean create) {
/* 539 */     IProgramElement ipe = null;
/* 540 */     synchronized (this) {
/* 541 */       ipe = this.handleMap.get(handle);
/* 542 */       if (ipe != null) {
/* 543 */         return ipe;
/*     */       }
/* 545 */       ipe = findElementForHandle(this.root, handle);
/* 546 */       if (ipe == null && create) {
/* 547 */         ipe = createFileStructureNode(getFilename(handle));
/*     */       }
/* 549 */       if (ipe != null) {
/* 550 */         cache(handle, ipe);
/*     */       }
/*     */     } 
/* 553 */     return ipe;
/*     */   }
/*     */   
/*     */   private IProgramElement findElementForHandle(IProgramElement parent, String handle) {
/* 557 */     for (IProgramElement node : parent.getChildren()) {
/* 558 */       String nodeHid = node.getHandleIdentifier();
/* 559 */       if (handle.equals(nodeHid)) {
/* 560 */         return node;
/*     */       }
/* 562 */       if (handle.startsWith(nodeHid)) {
/*     */         
/* 564 */         IProgramElement childSearch = findElementForHandle(node, handle);
/* 565 */         if (childSearch != null) {
/* 566 */           return childSearch;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 571 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cache(String handle, IProgramElement pe) {
/* 595 */     if (!AsmManager.isCompletingTypeBindings()) {
/* 596 */       this.handleMap.put(handle, pe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void flushTypeMap() {
/* 601 */     this.typeMap.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void flushHandleMap() {
/* 606 */     this.handleMap.clear();
/*     */   }
/*     */   
/*     */   public void flushFileMap() {
/* 610 */     this.fileMap.clear();
/*     */   }
/*     */   
/*     */   public void forget(IProgramElement compilationUnitNode, IProgramElement typeNode) {
/* 614 */     String k = null;
/* 615 */     synchronized (this) {
/*     */ 
/*     */       
/* 618 */       for (Map.Entry<String, IProgramElement> typeMapEntry : this.typeMap.entrySet()) {
/* 619 */         if (typeMapEntry.getValue() == typeNode) {
/* 620 */           k = typeMapEntry.getKey();
/*     */           break;
/*     */         } 
/*     */       } 
/* 624 */       if (k != null) {
/* 625 */         this.typeMap.remove(k);
/*     */       }
/*     */     } 
/*     */     
/* 629 */     if (compilationUnitNode != null) {
/* 630 */       k = null;
/* 631 */       for (Map.Entry<String, IProgramElement> entry : this.fileMap.entrySet()) {
/* 632 */         if (entry.getValue() == compilationUnitNode) {
/* 633 */           k = entry.getKey();
/*     */           break;
/*     */         } 
/*     */       } 
/* 637 */       if (k != null) {
/* 638 */         this.fileMap.remove(k);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateHandleMap(Set<String> deletedFiles) {
/* 646 */     List<String> forRemoval = new ArrayList<>();
/* 647 */     Set<String> k = null;
/* 648 */     synchronized (this) {
/* 649 */       k = this.handleMap.keySet();
/* 650 */       for (String handle : k) {
/* 651 */         IProgramElement ipe = this.handleMap.get(handle);
/* 652 */         if (ipe == null) {
/* 653 */           System.err.println("handleMap expectation not met, where is the IPE for " + handle);
/*     */         }
/* 655 */         if (ipe == null || deletedFiles.contains(getCanonicalFilePath(ipe))) {
/* 656 */           forRemoval.add(handle);
/*     */         }
/*     */       } 
/* 659 */       for (String handle : forRemoval) {
/* 660 */         this.handleMap.remove(handle);
/*     */       }
/* 662 */       forRemoval.clear();
/* 663 */       k = this.typeMap.keySet();
/* 664 */       for (String typeName : k) {
/* 665 */         IProgramElement ipe = this.typeMap.get(typeName);
/* 666 */         if (deletedFiles.contains(getCanonicalFilePath(ipe))) {
/* 667 */           forRemoval.add(typeName);
/*     */         }
/*     */       } 
/* 670 */       for (String typeName : forRemoval) {
/* 671 */         this.typeMap.remove(typeName);
/*     */       }
/* 673 */       forRemoval.clear();
/*     */     } 
/* 675 */     for (Map.Entry<String, IProgramElement> entry : this.fileMap.entrySet()) {
/* 676 */       String filePath = entry.getKey();
/* 677 */       if (deletedFiles.contains(getCanonicalFilePath(entry.getValue()))) {
/* 678 */         forRemoval.add(filePath);
/*     */       }
/*     */     } 
/* 681 */     for (String filePath : forRemoval) {
/* 682 */       this.fileMap.remove(filePath);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getFilename(String hid) {
/* 687 */     return this.asm.getHandleProvider().getFileForHandle(hid);
/*     */   }
/*     */   
/*     */   private String getCanonicalFilePath(IProgramElement ipe) {
/* 691 */     if (ipe.getSourceLocation() != null) {
/* 692 */       return this.asm.getCanonicalFilePath(ipe.getSourceLocation().getSourceFile());
/*     */     }
/* 694 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\AspectJElementHierarchy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */