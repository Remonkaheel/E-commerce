/*     */ package org.aspectj.asm.internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharOperation
/*     */ {
/*  19 */   public static final char[][] NO_CHAR_CHAR = new char[0][];
/*     */   
/*  21 */   public static final char[] NO_CHAR = new char[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char[] subarray(char[] array, int start, int end) {
/*  27 */     if (end == -1)
/*  28 */       end = array.length; 
/*  29 */     if (start > end)
/*  30 */       return null; 
/*  31 */     if (start < 0)
/*  32 */       return null; 
/*  33 */     if (end > array.length) {
/*  34 */       return null;
/*     */     }
/*  36 */     char[] result = new char[end - start];
/*  37 */     System.arraycopy(array, start, result, 0, end - start);
/*  38 */     return result;
/*     */   }
/*     */   
/*     */   public static final char[][] subarray(char[][] array, int start, int end) {
/*  42 */     if (end == -1)
/*  43 */       end = array.length; 
/*  44 */     if (start > end)
/*  45 */       return null; 
/*  46 */     if (start < 0)
/*  47 */       return null; 
/*  48 */     if (end > array.length) {
/*  49 */       return null;
/*     */     }
/*  51 */     char[][] result = new char[end - start][];
/*  52 */     System.arraycopy(array, start, result, 0, end - start);
/*  53 */     return result;
/*     */   }
/*     */   
/*     */   public static final char[][] splitOn(char divider, char[] array) {
/*  57 */     int length = (array == null) ? 0 : array.length;
/*  58 */     if (length == 0) {
/*  59 */       return NO_CHAR_CHAR;
/*     */     }
/*  61 */     int wordCount = 1;
/*  62 */     for (int i = 0; i < length; i++) {
/*  63 */       if (array[i] == divider)
/*  64 */         wordCount++; 
/*  65 */     }  char[][] split = new char[wordCount][];
/*  66 */     int last = 0, currentWord = 0;
/*  67 */     for (int j = 0; j < length; j++) {
/*  68 */       if (array[j] == divider) {
/*  69 */         split[currentWord] = new char[j - last];
/*  70 */         System.arraycopy(array, last, split[currentWord++], 0, j - last);
/*  71 */         last = j + 1;
/*     */       } 
/*     */     } 
/*  74 */     split[currentWord] = new char[length - last];
/*  75 */     System.arraycopy(array, last, split[currentWord], 0, length - last);
/*  76 */     return split;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int lastIndexOf(char toBeFound, char[] array) {
/*  83 */     for (int i = array.length; --i >= 0;) {
/*  84 */       if (toBeFound == array[i])
/*  85 */         return i; 
/*  86 */     }  return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int indexOf(char toBeFound, char[] array) {
/*  93 */     for (int i = 0; i < array.length; i++) {
/*  94 */       if (toBeFound == array[i])
/*  95 */         return i; 
/*  96 */     }  return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char[] concat(char[] first, char[] second) {
/* 103 */     if (first == null)
/* 104 */       return second; 
/* 105 */     if (second == null) {
/* 106 */       return first;
/*     */     }
/* 108 */     int length1 = first.length;
/* 109 */     int length2 = second.length;
/* 110 */     char[] result = new char[length1 + length2];
/* 111 */     System.arraycopy(first, 0, result, 0, length1);
/* 112 */     System.arraycopy(second, 0, result, length1, length2);
/* 113 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean equals(char[] first, char[] second) {
/* 120 */     if (first == second)
/* 121 */       return true; 
/* 122 */     if (first == null || second == null)
/* 123 */       return false; 
/* 124 */     if (first.length != second.length) {
/* 125 */       return false;
/*     */     }
/* 127 */     for (int i = first.length; --i >= 0;) {
/* 128 */       if (first[i] != second[i])
/* 129 */         return false; 
/* 130 */     }  return true;
/*     */   }
/*     */   
/*     */   public static final String toString(char[][] array) {
/* 134 */     char[] result = concatWith(array, '.');
/* 135 */     return new String(result);
/*     */   }
/*     */   
/*     */   public static final char[] concatWith(char[][] array, char separator) {
/* 139 */     int length = (array == null) ? 0 : array.length;
/* 140 */     if (length == 0) {
/* 141 */       return NO_CHAR;
/*     */     }
/* 143 */     int size = length - 1;
/* 144 */     int index = length;
/* 145 */     while (--index >= 0) {
/* 146 */       if ((array[index]).length == 0) {
/* 147 */         size--; continue;
/*     */       } 
/* 149 */       size += (array[index]).length;
/*     */     } 
/* 151 */     if (size <= 0)
/* 152 */       return NO_CHAR; 
/* 153 */     char[] result = new char[size];
/* 154 */     index = length;
/* 155 */     while (--index >= 0) {
/* 156 */       length = (array[index]).length;
/* 157 */       if (length > 0) {
/* 158 */         System.arraycopy(array[index], 0, result, size -= length, length);
/* 159 */         if (--size >= 0)
/* 160 */           result[size] = separator; 
/*     */       } 
/*     */     } 
/* 163 */     return result;
/*     */   }
/*     */   
/*     */   public static final int hashCode(char[] array) {
/* 167 */     int length = array.length;
/* 168 */     int hash = (length == 0) ? 31 : array[0];
/* 169 */     if (length < 8) {
/* 170 */       for (int i = length; --i > 0;) {
/* 171 */         hash = hash * 31 + array[i];
/*     */       }
/*     */     } else {
/* 174 */       for (int i = length - 1, last = (i > 16) ? (i - 16) : 0; i > last; i -= 2)
/* 175 */         hash = hash * 31 + array[i]; 
/*     */     } 
/* 177 */     return hash & Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public static final boolean equals(char[][] first, char[][] second) {
/* 181 */     if (first == second)
/* 182 */       return true; 
/* 183 */     if (first == null || second == null)
/* 184 */       return false; 
/* 185 */     if (first.length != second.length) {
/* 186 */       return false;
/*     */     }
/* 188 */     for (int i = first.length; --i >= 0;) {
/* 189 */       if (!equals(first[i], second[i]))
/* 190 */         return false; 
/* 191 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void replace(char[] array, char toBeReplaced, char replacementChar) {
/* 198 */     if (toBeReplaced != replacementChar)
/* 199 */       for (int i = 0, max = array.length; i < max; i++) {
/* 200 */         if (array[i] == toBeReplaced)
/* 201 */           array[i] = replacementChar; 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\CharOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */