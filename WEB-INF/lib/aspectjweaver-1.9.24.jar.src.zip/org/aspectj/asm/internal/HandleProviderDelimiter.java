/*     */ package org.aspectj.asm.internal;
/*     */ 
/*     */ import org.aspectj.asm.IProgramElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandleProviderDelimiter
/*     */ {
/*  30 */   public static final HandleProviderDelimiter ESCAPE = new HandleProviderDelimiter('\\');
/*  31 */   public static final HandleProviderDelimiter JAVAPROJECT = new HandleProviderDelimiter('=');
/*  32 */   public static final HandleProviderDelimiter PACKAGEFRAGMENTROOT = new HandleProviderDelimiter('/');
/*  33 */   public static final HandleProviderDelimiter PACKAGEFRAGMENT = new HandleProviderDelimiter('<');
/*  34 */   public static final HandleProviderDelimiter FIELD = new HandleProviderDelimiter('^');
/*  35 */   public static final HandleProviderDelimiter METHOD = new HandleProviderDelimiter('~');
/*  36 */   public static final HandleProviderDelimiter INITIALIZER = new HandleProviderDelimiter('|');
/*  37 */   public static final HandleProviderDelimiter COMPILATIONUNIT = new HandleProviderDelimiter('{');
/*  38 */   public static final HandleProviderDelimiter CLASSFILE = new HandleProviderDelimiter('(');
/*  39 */   public static final HandleProviderDelimiter MODULAR_CLASSFILE = new HandleProviderDelimiter('\'');
/*  40 */   public static final HandleProviderDelimiter TYPE = new HandleProviderDelimiter('[');
/*  41 */   public static final HandleProviderDelimiter PACKAGEDECLARATION = new HandleProviderDelimiter('%');
/*  42 */   public static final HandleProviderDelimiter IMPORTDECLARATION = new HandleProviderDelimiter('#');
/*  43 */   public static final HandleProviderDelimiter COUNT = new HandleProviderDelimiter('!');
/*     */ 
/*     */   
/*  46 */   public static final HandleProviderDelimiter LOCALVARIABLE = new HandleProviderDelimiter('@');
/*  47 */   public static final HandleProviderDelimiter TYPE_PARAMETER = new HandleProviderDelimiter(']');
/*  48 */   public static final HandleProviderDelimiter ANNOTATION = new HandleProviderDelimiter('}');
/*  49 */   public static final HandleProviderDelimiter LAMBDA_EXPRESSION = new HandleProviderDelimiter(')');
/*  50 */   public static final HandleProviderDelimiter LAMBDA_METHOD = new HandleProviderDelimiter('&');
/*  51 */   public static final HandleProviderDelimiter STRING = new HandleProviderDelimiter('"');
/*  52 */   public static final HandleProviderDelimiter MODULE = new HandleProviderDelimiter('`');
/*  53 */   public static final HandleProviderDelimiter DELIMITER_ESCAPE = new HandleProviderDelimiter('=');
/*     */ 
/*     */   
/*  56 */   public static final HandleProviderDelimiter ASPECT_CU = new HandleProviderDelimiter('*');
/*  57 */   public static final HandleProviderDelimiter ADVICE = new HandleProviderDelimiter('§');
/*  58 */   public static final HandleProviderDelimiter ASPECT_TYPE = new HandleProviderDelimiter('>');
/*  59 */   public static final HandleProviderDelimiter CODEELEMENT = new HandleProviderDelimiter('?');
/*  60 */   public static final HandleProviderDelimiter ITD_FIELD = new HandleProviderDelimiter(',');
/*  61 */   public static final HandleProviderDelimiter ITD_METHOD = new HandleProviderDelimiter('°');
/*  62 */   public static final HandleProviderDelimiter DECLARE = new HandleProviderDelimiter('´');
/*  63 */   public static final HandleProviderDelimiter POINTCUT = new HandleProviderDelimiter('©');
/*     */ 
/*     */   
/*  66 */   public static final HandleProviderDelimiter PHANTOM = new HandleProviderDelimiter(';');
/*     */   
/*  68 */   private static char empty = ' ';
/*     */   private final char delim;
/*     */   
/*     */   private HandleProviderDelimiter(char delim) {
/*  72 */     this.delim = delim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getDelimiter() {
/*  79 */     return this.delim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char getDelimiter(IProgramElement ipe) {
/*  87 */     IProgramElement.Kind kind = ipe.getKind();
/*  88 */     if (kind.equals(IProgramElement.Kind.PROJECT))
/*  89 */       return JAVAPROJECT.getDelimiter(); 
/*  90 */     if (kind.equals(IProgramElement.Kind.PACKAGE))
/*  91 */       return PACKAGEFRAGMENT.getDelimiter(); 
/*  92 */     if (kind.equals(IProgramElement.Kind.FILE_JAVA)) {
/*  93 */       if (ipe.getName().endsWith(".aj")) {
/*  94 */         return ASPECT_CU.getDelimiter();
/*     */       }
/*  96 */       return COMPILATIONUNIT.getDelimiter();
/*     */     } 
/*  98 */     if (kind.equals(IProgramElement.Kind.FILE_ASPECTJ))
/*  99 */       return ASPECT_CU.getDelimiter(); 
/* 100 */     if (kind.equals(IProgramElement.Kind.IMPORT_REFERENCE))
/* 101 */       return IMPORTDECLARATION.getDelimiter(); 
/* 102 */     if (kind.equals(IProgramElement.Kind.PACKAGE_DECLARATION))
/* 103 */       return PACKAGEDECLARATION.getDelimiter(); 
/* 104 */     if (kind.equals(IProgramElement.Kind.CLASS) || kind.equals(IProgramElement.Kind.INTERFACE) || kind
/* 105 */       .equals(IProgramElement.Kind.ENUM) || kind.equals(IProgramElement.Kind.ANNOTATION))
/* 106 */       return TYPE.getDelimiter(); 
/* 107 */     if (kind.equals(IProgramElement.Kind.ASPECT)) {
/* 108 */       if (ipe.isAnnotationStyleDeclaration()) {
/* 109 */         return TYPE.getDelimiter();
/*     */       }
/* 111 */       return ASPECT_TYPE.getDelimiter();
/*     */     } 
/* 113 */     if (kind.equals(IProgramElement.Kind.INITIALIZER))
/* 114 */       return INITIALIZER.getDelimiter(); 
/* 115 */     if (kind.equals(IProgramElement.Kind.INTER_TYPE_FIELD))
/* 116 */       return ITD_FIELD.getDelimiter(); 
/* 117 */     if (kind.equals(IProgramElement.Kind.INTER_TYPE_METHOD) || kind.equals(IProgramElement.Kind.INTER_TYPE_CONSTRUCTOR) || kind
/* 118 */       .equals(IProgramElement.Kind.INTER_TYPE_PARENT))
/* 119 */       return ITD_METHOD.getDelimiter(); 
/* 120 */     if (kind.equals(IProgramElement.Kind.CONSTRUCTOR) || kind.equals(IProgramElement.Kind.METHOD))
/* 121 */       return METHOD.getDelimiter(); 
/* 122 */     if (kind.equals(IProgramElement.Kind.FIELD) || kind.equals(IProgramElement.Kind.ENUM_VALUE))
/* 123 */       return FIELD.getDelimiter(); 
/* 124 */     if (kind.equals(IProgramElement.Kind.POINTCUT)) {
/* 125 */       if (ipe.isAnnotationStyleDeclaration()) {
/* 126 */         return METHOD.getDelimiter();
/*     */       }
/* 128 */       return POINTCUT.getDelimiter();
/*     */     } 
/* 130 */     if (kind.equals(IProgramElement.Kind.ADVICE)) {
/* 131 */       if (ipe.isAnnotationStyleDeclaration()) {
/* 132 */         return METHOD.getDelimiter();
/*     */       }
/* 134 */       return ADVICE.getDelimiter();
/*     */     } 
/* 136 */     if (kind.equals(IProgramElement.Kind.DECLARE_PARENTS) || kind.equals(IProgramElement.Kind.DECLARE_WARNING) || kind
/* 137 */       .equals(IProgramElement.Kind.DECLARE_ERROR) || kind.equals(IProgramElement.Kind.DECLARE_SOFT) || kind
/* 138 */       .equals(IProgramElement.Kind.DECLARE_PRECEDENCE) || kind
/* 139 */       .equals(IProgramElement.Kind.DECLARE_ANNOTATION_AT_CONSTRUCTOR) || kind
/* 140 */       .equals(IProgramElement.Kind.DECLARE_ANNOTATION_AT_FIELD) || kind
/* 141 */       .equals(IProgramElement.Kind.DECLARE_ANNOTATION_AT_METHOD) || kind
/* 142 */       .equals(IProgramElement.Kind.DECLARE_ANNOTATION_AT_TYPE))
/* 143 */       return DECLARE.getDelimiter(); 
/* 144 */     if (kind.equals(IProgramElement.Kind.CODE))
/* 145 */       return CODEELEMENT.getDelimiter(); 
/* 146 */     if (kind == IProgramElement.Kind.FILE) {
/* 147 */       if (ipe.getName().endsWith(".class"))
/* 148 */         return CLASSFILE.getDelimiter(); 
/* 149 */       if (ipe.getName().endsWith(".aj"))
/* 150 */         return ASPECT_CU.getDelimiter(); 
/* 151 */       if (ipe.getName().endsWith(".java")) {
/* 152 */         return COMPILATIONUNIT.getDelimiter();
/*     */       }
/* 154 */       return empty;
/*     */     } 
/*     */     
/* 157 */     return empty;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\HandleProviderDelimiter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */