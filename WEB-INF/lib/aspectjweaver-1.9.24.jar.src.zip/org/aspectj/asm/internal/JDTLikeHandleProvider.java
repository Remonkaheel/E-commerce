/*     */ package org.aspectj.asm.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import org.aspectj.asm.AsmManager;
/*     */ import org.aspectj.asm.IElementHandleProvider;
/*     */ import org.aspectj.asm.IProgramElement;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDTLikeHandleProvider
/*     */   implements IElementHandleProvider
/*     */ {
/*     */   private final AsmManager asm;
/*  35 */   private static final char[] empty = new char[0];
/*  36 */   private static final char[] countDelim = new char[] { HandleProviderDelimiter.COUNT.getDelimiter() };
/*     */   
/*     */   private static final String backslash = "\\";
/*     */   private static final String emptyString = "";
/*     */   
/*     */   public JDTLikeHandleProvider(AsmManager asm) {
/*  42 */     this.asm = asm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String createHandleIdentifier(IProgramElement ipe) {
/*  52 */     if (ipe == null || (ipe.getKind().equals(IProgramElement.Kind.FILE_JAVA) && ipe.getName().equals("<root>")))
/*  53 */       return ""; 
/*  54 */     if (ipe.getHandleIdentifier(false) != null)
/*     */     {
/*     */       
/*  57 */       return ipe.getHandleIdentifier(); } 
/*  58 */     if (ipe.getKind().equals(IProgramElement.Kind.FILE_LST)) {
/*  59 */       String configFile = this.asm.getHierarchy().getConfigFile();
/*  60 */       int start = configFile.lastIndexOf(File.separator);
/*  61 */       int end = configFile.lastIndexOf(".lst");
/*  62 */       if (end != -1) {
/*  63 */         configFile = configFile.substring(start + 1, end);
/*     */       } else {
/*  65 */         configFile = "=" + configFile.substring(start + 1);
/*     */       } 
/*  67 */       ipe.setHandleIdentifier(configFile);
/*  68 */       return configFile;
/*  69 */     }  if (ipe.getKind() == IProgramElement.Kind.SOURCE_FOLDER) {
/*  70 */       StringBuilder sb = new StringBuilder();
/*  71 */       sb.append(createHandleIdentifier(ipe.getParent())).append("/");
/*     */       
/*  73 */       String folder = ipe.getName();
/*  74 */       if (folder.endsWith("/")) {
/*  75 */         folder = folder.substring(0, folder.length() - 1);
/*     */       }
/*  77 */       if (folder.contains("/")) {
/*  78 */         folder = folder.replace("/", "\\/");
/*     */       }
/*  80 */       sb.append(folder);
/*  81 */       String str1 = sb.toString();
/*  82 */       ipe.setHandleIdentifier(str1);
/*  83 */       return str1;
/*     */     } 
/*  85 */     IProgramElement parent = ipe.getParent();
/*  86 */     if (parent != null && parent.getKind().equals(IProgramElement.Kind.IMPORT_REFERENCE))
/*     */     {
/*  88 */       parent = ipe.getParent().getParent();
/*     */     }
/*     */     
/*  91 */     StringBuilder handle = new StringBuilder();
/*     */     
/*  93 */     handle.append(createHandleIdentifier(parent));
/*     */     
/*  95 */     handle.append(HandleProviderDelimiter.getDelimiter(ipe));
/*     */ 
/*     */     
/*  98 */     if (!ipe.getKind().equals(IProgramElement.Kind.INITIALIZER) && (
/*  99 */       ipe.getKind() != IProgramElement.Kind.CLASS || !ipe.getName().endsWith("{..}")))
/*     */     {
/*     */ 
/*     */       
/* 103 */       if (ipe.getKind() == IProgramElement.Kind.INTER_TYPE_CONSTRUCTOR) {
/* 104 */         handle.append(ipe.getName()).append("_new").append(getParameters(ipe));
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 109 */       else if (ipe.getKind().isDeclareAnnotation()) {
/*     */         
/* 111 */         handle.append("declare \\@").append(ipe.getName().substring(9)).append(getParameters(ipe));
/*     */       } else {
/* 113 */         if (ipe.getFullyQualifiedName() != null) {
/* 114 */           handle.append(ipe.getFullyQualifiedName());
/*     */         } else {
/* 116 */           handle.append(ipe.getName());
/*     */         } 
/* 118 */         handle.append(getParameters(ipe));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     handle.append(getCount(ipe));
/*     */     
/* 128 */     ipe.setHandleIdentifier(handle.toString());
/* 129 */     return handle.toString();
/*     */   }
/*     */   
/*     */   private String getParameters(IProgramElement ipe) {
/* 133 */     if (ipe.getParameterSignatures() == null || ipe.getParameterSignatures().isEmpty()) {
/* 134 */       return "";
/*     */     }
/* 136 */     List<String> sourceRefs = ipe.getParameterSignaturesSourceRefs();
/* 137 */     List<char[]> parameterTypes = ipe.getParameterSignatures();
/* 138 */     StringBuilder sb = new StringBuilder();
/* 139 */     if (sourceRefs != null) {
/* 140 */       for (String sourceRef : sourceRefs) {
/* 141 */         sb.append(HandleProviderDelimiter.getDelimiter(ipe));
/* 142 */         sb.append(sourceRef);
/*     */       } 
/*     */     } else {
/* 145 */       for (char[] element : parameterTypes) {
/* 146 */         sb.append(HandleProviderDelimiter.getDelimiter(ipe));
/* 147 */         sb.append(NameConvertor.createShortName(element, false, false));
/*     */       } 
/*     */     } 
/* 150 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] getCount(IProgramElement ipe) {
/* 162 */     char[] byteCodeName = ipe.getBytecodeName().toCharArray();
/*     */     
/* 164 */     if (ipe.getKind().isInterTypeMember()) {
/* 165 */       int count = 1;
/* 166 */       List<IProgramElement> kids = ipe.getParent().getChildren();
/* 167 */       for (IProgramElement object : kids) {
/* 168 */         if (object.equals(ipe)) {
/*     */           break;
/*     */         }
/* 171 */         if (object.getKind().isInterTypeMember() && 
/* 172 */           object.getName().equals(ipe.getName()) && getParameters(object).equals(getParameters(ipe))) {
/* 173 */           String existingHandle = object.getHandleIdentifier();
/* 174 */           int suffixPosition = existingHandle.indexOf('!');
/* 175 */           if (suffixPosition != -1) {
/* 176 */             count = Integer.parseInt(existingHandle.substring(suffixPosition + 1)) + 1; continue;
/*     */           } 
/* 178 */           if (count == 1) {
/* 179 */             count = 2;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 185 */       if (count > 1) {
/* 186 */         return CharOperation.concat(countDelim, Integer.toString(count).toCharArray());
/*     */       }
/* 188 */     } else if (ipe.getKind().isDeclare()) {
/*     */       
/* 190 */       int count = computeCountBasedOnPeers(ipe);
/* 191 */       if (count > 1) {
/* 192 */         return CharOperation.concat(countDelim, Integer.toString(count).toCharArray());
/*     */       }
/* 194 */     } else if (ipe.getKind().equals(IProgramElement.Kind.ADVICE)) {
/*     */       
/* 196 */       int count = 1;
/* 197 */       List<IProgramElement> kids = ipe.getParent().getChildren();
/* 198 */       String ipeSig = ipe.getBytecodeSignature();
/*     */       
/* 200 */       int idx = 0;
/* 201 */       ipeSig = shortenIpeSig(ipeSig);
/* 202 */       for (IProgramElement object : kids) {
/* 203 */         if (object.equals(ipe)) {
/*     */           break;
/*     */         }
/* 206 */         if (object.getKind() == ipe.getKind() && 
/* 207 */           object.getName().equals(ipe.getName())) {
/* 208 */           String sig1 = object.getBytecodeSignature();
/* 209 */           if (sig1 != null && (idx = sig1.indexOf(")")) != -1) {
/* 210 */             sig1 = sig1.substring(0, idx);
/*     */           }
/*     */ 
/*     */           
/* 214 */           if (sig1 != null && 
/* 215 */             sig1.contains("Lorg/aspectj/lang")) {
/* 216 */             if (sig1.endsWith("Lorg/aspectj/lang/JoinPoint$StaticPart;")) {
/* 217 */               sig1 = sig1.substring(0, sig1.lastIndexOf("Lorg/aspectj/lang/JoinPoint$StaticPart;"));
/*     */             }
/* 219 */             if (sig1.endsWith("Lorg/aspectj/lang/JoinPoint;")) {
/* 220 */               sig1 = sig1.substring(0, sig1.lastIndexOf("Lorg/aspectj/lang/JoinPoint;"));
/*     */             }
/* 222 */             if (sig1.endsWith("Lorg/aspectj/lang/JoinPoint$StaticPart;")) {
/* 223 */               sig1 = sig1.substring(0, sig1.lastIndexOf("Lorg/aspectj/lang/JoinPoint$StaticPart;"));
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 228 */           if ((sig1 == null && ipeSig == null) || (sig1 != null && sig1.equals(ipeSig))) {
/* 229 */             String existingHandle = object.getHandleIdentifier();
/* 230 */             int suffixPosition = existingHandle.indexOf('!');
/* 231 */             if (suffixPosition != -1) {
/* 232 */               count = Integer.parseInt(existingHandle.substring(suffixPosition + 1)) + 1; continue;
/*     */             } 
/* 234 */             if (count == 1) {
/* 235 */               count = 2;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 242 */       if (count > 1)
/* 243 */         return CharOperation.concat(countDelim, Integer.toString(count).toCharArray()); 
/*     */     } else {
/* 245 */       if (ipe.getKind().equals(IProgramElement.Kind.INITIALIZER)) {
/*     */ 
/*     */         
/* 248 */         int count = 1;
/* 249 */         List<IProgramElement> kids = ipe.getParent().getChildren();
/* 250 */         String ipeSig = ipe.getBytecodeSignature();
/*     */         
/* 252 */         int idx = 0;
/* 253 */         ipeSig = shortenIpeSig(ipeSig);
/* 254 */         for (IProgramElement object : kids) {
/* 255 */           if (object.equals(ipe)) {
/*     */             break;
/*     */           }
/* 258 */           if (object.getKind() == ipe.getKind() && 
/* 259 */             object.getName().equals(ipe.getName())) {
/* 260 */             String sig1 = object.getBytecodeSignature();
/* 261 */             if (sig1 != null && (idx = sig1.indexOf(")")) != -1) {
/* 262 */               sig1 = sig1.substring(0, idx);
/*     */             }
/*     */ 
/*     */             
/* 266 */             if (sig1 != null && 
/* 267 */               sig1.contains("Lorg/aspectj/lang")) {
/* 268 */               if (sig1.endsWith("Lorg/aspectj/lang/JoinPoint$StaticPart;")) {
/* 269 */                 sig1 = sig1.substring(0, sig1.lastIndexOf("Lorg/aspectj/lang/JoinPoint$StaticPart;"));
/*     */               }
/* 271 */               if (sig1.endsWith("Lorg/aspectj/lang/JoinPoint;")) {
/* 272 */                 sig1 = sig1.substring(0, sig1.lastIndexOf("Lorg/aspectj/lang/JoinPoint;"));
/*     */               }
/* 274 */               if (sig1.endsWith("Lorg/aspectj/lang/JoinPoint$StaticPart;")) {
/* 275 */                 sig1 = sig1.substring(0, sig1.lastIndexOf("Lorg/aspectj/lang/JoinPoint$StaticPart;"));
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 280 */             if ((sig1 == null && ipeSig == null) || (sig1 != null && sig1.equals(ipeSig))) {
/* 281 */               String existingHandle = object.getHandleIdentifier();
/* 282 */               int suffixPosition = existingHandle.indexOf('!');
/* 283 */               if (suffixPosition != -1) {
/* 284 */                 count = Integer.parseInt(existingHandle.substring(suffixPosition + 1)) + 1; continue;
/*     */               } 
/* 286 */               if (count == 1) {
/* 287 */                 count = 2;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 295 */         return Integer.toString(count).toCharArray();
/*     */       } 
/*     */       
/* 298 */       if (ipe.getKind().equals(IProgramElement.Kind.CODE)) {
/* 299 */         int index = CharOperation.lastIndexOf('!', byteCodeName);
/* 300 */         if (index != -1) {
/* 301 */           return convertCount(CharOperation.subarray(byteCodeName, index + 1, byteCodeName.length));
/*     */         }
/* 303 */       } else if (ipe.getKind() == IProgramElement.Kind.CLASS) {
/*     */         
/* 305 */         int count = 1;
/* 306 */         List<IProgramElement> kids = ipe.getParent().getChildren();
/* 307 */         if (ipe.getName().endsWith("{..}")) {
/*     */           
/* 309 */           for (IProgramElement object : kids) {
/* 310 */             if (object.equals(ipe)) {
/*     */               break;
/*     */             }
/* 313 */             if (object.getKind() == ipe.getKind() && 
/* 314 */               object.getName().endsWith("{..}")) {
/* 315 */               String existingHandle = object.getHandleIdentifier();
/* 316 */               int suffixPosition = existingHandle.lastIndexOf('!');
/* 317 */               int lastSquareBracket = existingHandle.lastIndexOf('[');
/* 318 */               if (suffixPosition != -1 && lastSquareBracket < suffixPosition) {
/* 319 */                 count = Integer.parseInt(existingHandle.substring(suffixPosition + 1)) + 1; continue;
/*     */               } 
/* 321 */               if (count == 1) {
/* 322 */                 count = 2;
/*     */               }
/*     */             }
/*     */           
/*     */           } 
/*     */         } else {
/*     */           
/* 329 */           for (IProgramElement object : kids) {
/* 330 */             if (object.equals(ipe)) {
/*     */               break;
/*     */             }
/* 333 */             if (object.getKind() == ipe.getKind() && 
/* 334 */               object.getName().equals(ipe.getName())) {
/* 335 */               String existingHandle = object.getHandleIdentifier();
/* 336 */               int suffixPosition = existingHandle.lastIndexOf('!');
/* 337 */               int lastSquareBracket = existingHandle.lastIndexOf('[');
/* 338 */               if (suffixPosition != -1 && lastSquareBracket < suffixPosition) {
/* 339 */                 count = Integer.parseInt(existingHandle.substring(suffixPosition + 1)) + 1; continue;
/*     */               } 
/* 341 */               if (count == 1) {
/* 342 */                 count = 2;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 349 */         if (count > 1)
/* 350 */           return CharOperation.concat(countDelim, Integer.toString(count).toCharArray()); 
/*     */       } 
/*     */     } 
/* 353 */     return empty;
/*     */   }
/*     */   
/*     */   private String shortenIpeSig(String ipeSig) {
/*     */     int idx;
/* 358 */     if (ipeSig != null && (idx = ipeSig.indexOf(")")) != -1) {
/* 359 */       ipeSig = ipeSig.substring(0, idx);
/*     */     }
/* 361 */     if (ipeSig != null && 
/* 362 */       ipeSig.contains("Lorg/aspectj/lang")) {
/* 363 */       if (ipeSig.endsWith("Lorg/aspectj/lang/JoinPoint$StaticPart;")) {
/* 364 */         ipeSig = ipeSig.substring(0, ipeSig.lastIndexOf("Lorg/aspectj/lang/JoinPoint$StaticPart;"));
/*     */       }
/* 366 */       if (ipeSig.endsWith("Lorg/aspectj/lang/JoinPoint;")) {
/* 367 */         ipeSig = ipeSig.substring(0, ipeSig.lastIndexOf("Lorg/aspectj/lang/JoinPoint;"));
/*     */       }
/* 369 */       if (ipeSig.endsWith("Lorg/aspectj/lang/JoinPoint$StaticPart;")) {
/* 370 */         ipeSig = ipeSig.substring(0, ipeSig.lastIndexOf("Lorg/aspectj/lang/JoinPoint$StaticPart;"));
/*     */       }
/*     */     } 
/*     */     
/* 374 */     return ipeSig;
/*     */   }
/*     */   
/*     */   private int computeCountBasedOnPeers(IProgramElement ipe) {
/* 378 */     int count = 1;
/* 379 */     for (IProgramElement object : ipe.getParent().getChildren()) {
/* 380 */       if (object.equals(ipe)) {
/*     */         break;
/*     */       }
/* 383 */       if (object.getKind() == ipe.getKind() && 
/* 384 */         object.getKind().toString().equals(ipe.getKind().toString())) {
/* 385 */         String existingHandle = object.getHandleIdentifier();
/* 386 */         int suffixPosition = existingHandle.indexOf('!');
/* 387 */         if (suffixPosition != -1) {
/* 388 */           count = Integer.parseInt(existingHandle.substring(suffixPosition + 1)) + 1; continue;
/*     */         } 
/* 390 */         if (count == 1) {
/* 391 */           count = 2;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 397 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] convertCount(char[] c) {
/* 404 */     if ((c.length == 1 && c[0] != ' ' && c[0] != '1') || c.length > 1) {
/* 405 */       return CharOperation.concat(countDelim, c);
/*     */     }
/* 407 */     return empty;
/*     */   }
/*     */   
/*     */   public String getFileForHandle(String handle) {
/* 411 */     IProgramElement node = this.asm.getHierarchy().getElement(handle);
/* 412 */     if (node != null)
/* 413 */       return this.asm.getCanonicalFilePath(node.getSourceLocation().getSourceFile()); 
/* 414 */     if (handle.charAt(0) == HandleProviderDelimiter.ASPECT_CU.getDelimiter() || handle
/* 415 */       .charAt(0) == HandleProviderDelimiter.COMPILATIONUNIT.getDelimiter())
/*     */     {
/*     */ 
/*     */       
/* 419 */       return "\\" + handle.substring(1);
/*     */     }
/* 421 */     return "";
/*     */   }
/*     */   
/*     */   public int getLineNumberForHandle(String handle) {
/* 425 */     IProgramElement node = this.asm.getHierarchy().getElement(handle);
/* 426 */     if (node != null)
/* 427 */       return node.getSourceLocation().getLine(); 
/* 428 */     if (handle.charAt(0) == HandleProviderDelimiter.ASPECT_CU.getDelimiter() || handle
/* 429 */       .charAt(0) == HandleProviderDelimiter.COMPILATIONUNIT.getDelimiter())
/*     */     {
/*     */ 
/*     */       
/* 433 */       return 1;
/*     */     }
/* 435 */     return -1;
/*     */   }
/*     */   
/*     */   public int getOffSetForHandle(String handle) {
/* 439 */     IProgramElement node = this.asm.getHierarchy().getElement(handle);
/* 440 */     if (node != null)
/* 441 */       return node.getSourceLocation().getOffset(); 
/* 442 */     if (handle.charAt(0) == HandleProviderDelimiter.ASPECT_CU.getDelimiter() || handle
/* 443 */       .charAt(0) == HandleProviderDelimiter.COMPILATIONUNIT.getDelimiter())
/*     */     {
/*     */ 
/*     */       
/* 447 */       return 0;
/*     */     }
/* 449 */     return -1;
/*     */   }
/*     */   
/*     */   public String createHandleIdentifier(ISourceLocation location) {
/* 453 */     IProgramElement node = this.asm.getHierarchy().findElementForSourceLine(location);
/* 454 */     if (node != null) {
/* 455 */       return createHandleIdentifier(node);
/*     */     }
/* 457 */     return null;
/*     */   }
/*     */   
/*     */   public String createHandleIdentifier(File sourceFile, int line, int column, int offset) {
/* 461 */     IProgramElement node = this.asm.getHierarchy().findElementForOffSet(sourceFile.getAbsolutePath(), line, offset);
/* 462 */     if (node != null) {
/* 463 */       return createHandleIdentifier(node);
/*     */     }
/* 465 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dependsOnLocation() {
/* 470 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\JDTLikeHandleProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */