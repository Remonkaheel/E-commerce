/*     */ package org.aspectj.asm.internal;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.aspectj.asm.IProgramElement;
/*     */ import org.aspectj.asm.IRelationship;
/*     */ import org.aspectj.asm.IRelationshipMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelationshipMap
/*     */   extends HashMap<String, List<IRelationship>>
/*     */   implements IRelationshipMap
/*     */ {
/*     */   private static final long serialVersionUID = 496638323566589643L;
/*     */   
/*     */   public List<IRelationship> get(String handle) {
/*  38 */     List<IRelationship> relationships = (List<IRelationship>)get(handle);
/*  39 */     if (relationships == null) {
/*  40 */       return null;
/*     */     }
/*  42 */     return relationships;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<IRelationship> get(IProgramElement source) {
/*  47 */     return get(source.getHandleIdentifier());
/*     */   }
/*     */ 
/*     */   
/*     */   public IRelationship get(String source, IRelationship.Kind kind, String relationshipName, boolean runtimeTest, boolean createIfMissing) {
/*  52 */     List<IRelationship> relationships = get(source);
/*  53 */     if (relationships == null) {
/*  54 */       if (!createIfMissing) {
/*  55 */         return null;
/*     */       }
/*  57 */       relationships = new ArrayList<>();
/*  58 */       IRelationship rel = new Relationship(relationshipName, kind, source, new ArrayList<>(), runtimeTest);
/*  59 */       relationships.add(rel);
/*     */       
/*  61 */       put((K)source, (V)relationships);
/*  62 */       return rel;
/*     */     } 
/*  64 */     for (IRelationship curr : relationships) {
/*  65 */       if (curr.getKind() == kind && curr.getName().equals(relationshipName) && curr.hasRuntimeTest() == runtimeTest) {
/*  66 */         return curr;
/*     */       }
/*     */     } 
/*  69 */     if (createIfMissing) {
/*     */ 
/*     */       
/*  72 */       IRelationship rel = new Relationship(relationshipName, kind, source, new ArrayList<>(), runtimeTest);
/*  73 */       relationships.add(rel);
/*  74 */       return rel;
/*     */     } 
/*     */     
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IRelationship get(IProgramElement source, IRelationship.Kind kind, String relationshipName, boolean runtimeTest, boolean createIfMissing) {
/*  82 */     return get(source.getHandleIdentifier(), kind, relationshipName, runtimeTest, createIfMissing);
/*     */   }
/*     */   
/*     */   public IRelationship get(IProgramElement source, IRelationship.Kind kind, String relationshipName) {
/*  86 */     return get(source, kind, relationshipName, false, true);
/*     */   }
/*     */   
/*     */   public boolean remove(String source, IRelationship relationship) {
/*  90 */     List<IRelationship> list = (List<IRelationship>)get(source);
/*  91 */     if (list != null) {
/*  92 */       return list.remove(relationship);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   public void removeAll(String source) {
/* 107 */     remove(source);
/*     */   }
/*     */   
/*     */   public void put(String source, IRelationship relationship) {
/* 111 */     List<IRelationship> existingRelationships = (List<IRelationship>)get(source);
/* 112 */     if (existingRelationships == null) {
/*     */       
/* 114 */       existingRelationships = new ArrayList<>();
/* 115 */       existingRelationships.add(relationship);
/* 116 */       put((K)source, (V)existingRelationships);
/*     */     } else {
/* 118 */       boolean matched = false;
/* 119 */       for (IRelationship existingRelationship : existingRelationships) {
/* 120 */         if (existingRelationship.getName().equals(relationship.getName()) && existingRelationship
/* 121 */           .getKind() == relationship.getKind()) {
/* 122 */           existingRelationship.getTargets().addAll(relationship.getTargets());
/* 123 */           matched = true;
/*     */         } 
/*     */       } 
/* 126 */       if (matched)
/*     */       {
/* 128 */         System.err.println("matched = true");
/*     */       }
/* 130 */       if (matched) {
/* 131 */         existingRelationships.add(relationship);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void put(IProgramElement source, IRelationship relationship) {
/* 137 */     put(source.getHandleIdentifier(), relationship);
/*     */   }
/*     */   
/*     */   public void clear() {
/* 141 */     super.clear();
/*     */   }
/*     */   
/*     */   public Set<String> getEntries() {
/* 145 */     return keySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\RelationshipMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */