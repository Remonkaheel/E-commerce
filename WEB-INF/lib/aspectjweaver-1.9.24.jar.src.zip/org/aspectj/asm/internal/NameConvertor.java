/*     */ package org.aspectj.asm.internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameConvertor
/*     */ {
/*     */   private static final char BOOLEAN = 'Z';
/*     */   private static final char BYTE = 'B';
/*     */   private static final char CHAR = 'C';
/*     */   private static final char DOUBLE = 'D';
/*     */   private static final char FLOAT = 'F';
/*     */   private static final char INT = 'I';
/*     */   private static final char LONG = 'J';
/*     */   private static final char SHORT = 'S';
/*     */   private static final char ARRAY = '[';
/*     */   private static final char RESOLVED = 'L';
/*     */   private static final char UNRESOLVED = 'Q';
/*     */   public static final char PARAMETERIZED = 'P';
/*  29 */   private static final char[] BOOLEAN_NAME = new char[] { 'b', 'o', 'o', 'l', 'e', 'a', 'n' };
/*  30 */   private static final char[] BYTE_NAME = new char[] { 'b', 'y', 't', 'e' };
/*  31 */   private static final char[] CHAR_NAME = new char[] { 'c', 'h', 'a', 'r' };
/*  32 */   private static final char[] DOUBLE_NAME = new char[] { 'd', 'o', 'u', 'b', 'l', 'e' };
/*  33 */   private static final char[] FLOAT_NAME = new char[] { 'f', 'l', 'o', 'a', 't' };
/*  34 */   private static final char[] INT_NAME = new char[] { 'i', 'n', 't' };
/*  35 */   private static final char[] LONG_NAME = new char[] { 'l', 'o', 'n', 'g' };
/*  36 */   private static final char[] SHORT_NAME = new char[] { 's', 'h', 'o', 'r', 't' };
/*     */   
/*  38 */   private static final char[] SQUARE_BRACKETS = new char[] { '[', ']' };
/*  39 */   private static final char[] GREATER_THAN = new char[] { '>' };
/*  40 */   private static final char[] LESS_THAN = new char[] { '<' };
/*  41 */   private static final char[] COMMA = new char[] { ',' };
/*  42 */   private static final char[] BACKSLASH_LESSTHAN = new char[] { '\\', '<' };
/*  43 */   private static final char[] SEMICOLON = new char[] { ';' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] convertFromSignature(char[] c) {
/*  50 */     int lt = CharOperation.indexOf('<', c);
/*  51 */     int sc = CharOperation.indexOf(';', c);
/*  52 */     int gt = CharOperation.indexOf('>', c);
/*     */     
/*  54 */     int smallest = 0;
/*  55 */     if (lt == -1 && sc == -1 && gt == -1)
/*     */     {
/*  57 */       return getFullyQualifiedTypeName(c); } 
/*  58 */     if (lt != -1 && (sc == -1 || lt <= sc) && (gt == -1 || lt <= gt)) {
/*     */       
/*  60 */       smallest = lt;
/*  61 */     } else if (sc != -1 && (lt == -1 || sc <= lt) && (gt == -1 || sc <= gt)) {
/*     */       
/*  63 */       smallest = sc;
/*     */     } else {
/*     */       
/*  66 */       smallest = gt;
/*     */     } 
/*  68 */     char[] first = CharOperation.subarray(c, 0, smallest);
/*  69 */     char[] second = CharOperation.subarray(c, smallest + 1, c.length);
/*  70 */     if (smallest == 0 && first.length == 0 && c[0] == '>')
/*     */     {
/*     */       
/*  73 */       return GREATER_THAN; } 
/*  74 */     if (first.length == 1 && second.length == 0)
/*  75 */       return first; 
/*  76 */     if (second.length == 0 || (second.length == 1 && second[0] == ';'))
/*     */     {
/*     */       
/*  79 */       return convertFromSignature(first); } 
/*  80 */     if (smallest == lt) {
/*     */ 
/*     */ 
/*     */       
/*  84 */       char[] inclLT = CharOperation.concat(convertFromSignature(first), LESS_THAN);
/*  85 */       return CharOperation.concat(inclLT, convertFromSignature(second));
/*  86 */     }  if (smallest == gt) {
/*  87 */       char[] inclLT = CharOperation.concat(convertFromSignature(first), GREATER_THAN);
/*  88 */       return CharOperation.concat(inclLT, convertFromSignature(second));
/*  89 */     }  if (second.length != 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       char[] inclComma = CharOperation.concat(convertFromSignature(first), COMMA);
/*  95 */       return CharOperation.concat(inclComma, convertFromSignature(second));
/*     */     } 
/*  97 */     return CharOperation.concat(convertFromSignature(first), convertFromSignature(second));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] getFullyQualifiedTypeName(char[] c) {
/* 108 */     if (c.length == 0) {
/* 109 */       return c;
/*     */     }
/* 111 */     if (c[0] == 'Z')
/* 112 */       return BOOLEAN_NAME; 
/* 113 */     if (c[0] == 'B')
/* 114 */       return BYTE_NAME; 
/* 115 */     if (c[0] == 'C')
/* 116 */       return CHAR_NAME; 
/* 117 */     if (c[0] == 'D')
/* 118 */       return DOUBLE_NAME; 
/* 119 */     if (c[0] == 'F')
/* 120 */       return FLOAT_NAME; 
/* 121 */     if (c[0] == 'I')
/* 122 */       return INT_NAME; 
/* 123 */     if (c[0] == 'J')
/* 124 */       return LONG_NAME; 
/* 125 */     if (c[0] == 'S')
/* 126 */       return SHORT_NAME; 
/* 127 */     if (c[0] == '[') {
/* 128 */       return CharOperation.concat(getFullyQualifiedTypeName(CharOperation.subarray(c, 1, c.length)), SQUARE_BRACKETS);
/*     */     }
/* 130 */     char[] type = CharOperation.subarray(c, 1, c.length);
/* 131 */     CharOperation.replace(type, '/', '.');
/* 132 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] createShortName(char[] c, boolean haveFullyQualifiedAtLeastOneThing, boolean needsFullyQualifiedFirstEntry) {
/* 144 */     if (c[0] == '[') {
/* 145 */       char[] ret = CharOperation.concat(new char[] { '\\', '['
/*     */           },
/* 147 */           createShortName(CharOperation.subarray(c, 1, c.length), haveFullyQualifiedAtLeastOneThing, needsFullyQualifiedFirstEntry));
/*     */       
/* 149 */       return ret;
/* 150 */     }  if (c[0] == '+') {
/* 151 */       char[] ret = CharOperation.concat(new char[] { '+'
/*     */           },
/* 153 */           createShortName(CharOperation.subarray(c, 1, c.length), haveFullyQualifiedAtLeastOneThing, needsFullyQualifiedFirstEntry));
/*     */       
/* 155 */       return ret;
/* 156 */     }  if (c[0] == '*') {
/* 157 */       return c;
/*     */     }
/* 159 */     int lt = CharOperation.indexOf('<', c);
/* 160 */     int sc = CharOperation.indexOf(';', c);
/* 161 */     int gt = CharOperation.indexOf('>', c);
/*     */     
/* 163 */     int smallest = 0;
/* 164 */     if (lt == -1 && sc == -1 && gt == -1) {
/*     */       
/* 166 */       if (!needsFullyQualifiedFirstEntry) {
/* 167 */         return getTypeName(c, true);
/*     */       }
/* 169 */       return getTypeName(c, haveFullyQualifiedAtLeastOneThing);
/*     */     } 
/* 171 */     if (lt != -1 && (sc == -1 || lt <= sc) && (gt == -1 || lt <= gt)) {
/*     */       
/* 173 */       smallest = lt;
/* 174 */     } else if (sc != -1 && (lt == -1 || sc <= lt) && (gt == -1 || sc <= gt)) {
/*     */       
/* 176 */       smallest = sc;
/*     */     } else {
/*     */       
/* 179 */       smallest = gt;
/*     */     } 
/* 181 */     char[] first = CharOperation.subarray(c, 0, smallest);
/* 182 */     char[] second = CharOperation.subarray(c, smallest + 1, c.length);
/* 183 */     if (smallest == 0 && first.length == 0 && c[0] == '>')
/*     */     {
/*     */       
/* 186 */       return c; } 
/* 187 */     if (first.length == 1 && second.length == 0)
/* 188 */       return first; 
/* 189 */     if (second.length == 0 || (second.length == 1 && second[0] == ';'))
/*     */     {
/*     */       
/* 192 */       return CharOperation.concat(createShortName(first, haveFullyQualifiedAtLeastOneThing, needsFullyQualifiedFirstEntry), new char[] { ';' });
/*     */     }
/* 194 */     if (smallest == lt) {
/*     */ 
/*     */ 
/*     */       
/* 198 */       char[] inclLT = CharOperation.concat(createShortName(first, haveFullyQualifiedAtLeastOneThing, true), BACKSLASH_LESSTHAN);
/*     */       
/* 200 */       return CharOperation.concat(inclLT, createShortName(second, true, false));
/* 201 */     }  if (smallest == gt) {
/* 202 */       char[] inclLT = CharOperation.concat(
/* 203 */           createShortName(first, haveFullyQualifiedAtLeastOneThing, needsFullyQualifiedFirstEntry), GREATER_THAN);
/* 204 */       return CharOperation.concat(inclLT, createShortName(second, true, false));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 209 */     char[] firstTypeParam = CharOperation.concat(createShortName(first, haveFullyQualifiedAtLeastOneThing, false), SEMICOLON);
/*     */     
/* 211 */     return CharOperation.concat(firstTypeParam, createShortName(second, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] getTypeName(char[] name, boolean haveFullyQualifiedAtLeastOneThing) {
/* 230 */     if (!haveFullyQualifiedAtLeastOneThing) {
/* 231 */       if (name[0] == 'L' || name[0] == 'P') {
/* 232 */         char[] arrayOfChar = CharOperation.subarray(name, 1, name.length);
/* 233 */         CharOperation.replace(arrayOfChar, '/', '.');
/* 234 */         return CharOperation.concat(new char[] { 'Q' }, arrayOfChar);
/*     */       } 
/* 236 */       char[] sub = CharOperation.subarray(name, 1, name.length);
/* 237 */       CharOperation.replace(sub, '/', '.');
/* 238 */       return CharOperation.concat(new char[] { name[0] }, sub);
/*     */     } 
/*     */     
/* 241 */     int i = CharOperation.lastIndexOf('/', name);
/* 242 */     if (i != -1) {
/* 243 */       if (name[0] == 'L' || name[0] == 'P') {
/* 244 */         return CharOperation.concat(new char[] { 'Q' }, CharOperation.subarray(name, i + 1, name.length));
/*     */       }
/* 246 */       return CharOperation.concat(new char[] { name[0] }, CharOperation.subarray(name, i + 1, name.length));
/*     */     } 
/*     */ 
/*     */     
/* 250 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\NameConvertor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */