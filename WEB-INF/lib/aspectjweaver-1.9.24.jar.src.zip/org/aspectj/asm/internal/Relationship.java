/*    */ package org.aspectj.asm.internal;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.aspectj.asm.IRelationship;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Relationship
/*    */   implements IRelationship
/*    */ {
/*    */   private static final long serialVersionUID = 3855166397957609120L;
/*    */   private String name;
/*    */   private IRelationship.Kind kind;
/*    */   private boolean isAffects;
/*    */   private String sourceHandle;
/*    */   private List<String> targets;
/*    */   private boolean hasRuntimeTest;
/*    */   
/*    */   public Relationship(String name, IRelationship.Kind kind, String sourceHandle, List<String> targets, boolean runtimeTest) {
/* 35 */     this.name = name;
/* 36 */     this
/* 37 */       .isAffects = (name.equals("advises") || name.equals("declares on") || name.equals("softens") || name.equals("matched by") || name.equals("declared on") || name.equals("annotates"));
/* 38 */     this.kind = kind;
/* 39 */     this.sourceHandle = sourceHandle;
/* 40 */     this.targets = targets;
/* 41 */     this.hasRuntimeTest = runtimeTest;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */   
/*    */   public IRelationship.Kind getKind() {
/* 49 */     return this.kind;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 53 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getSourceHandle() {
/* 57 */     return this.sourceHandle;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getTargets() {
/* 62 */     return this.targets;
/*    */   }
/*    */   
/*    */   public void addTarget(String handle) {
/* 66 */     if (this.targets.contains(handle)) {
/*    */       return;
/*    */     }
/* 69 */     this.targets.add(handle);
/*    */   }
/*    */   
/*    */   public boolean hasRuntimeTest() {
/* 73 */     return this.hasRuntimeTest;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isAffects() {
/* 83 */     return this.isAffects;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\internal\Relationship.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */