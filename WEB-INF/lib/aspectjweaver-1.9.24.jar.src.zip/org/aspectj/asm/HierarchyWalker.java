/*    */ package org.aspectj.asm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HierarchyWalker
/*    */ {
/*    */   protected void preProcess(IProgramElement node) {}
/*    */   
/*    */   protected void postProcess(IProgramElement node) {}
/*    */   
/*    */   public IProgramElement process(IProgramElement node) {
/* 32 */     preProcess(node);
/* 33 */     node.walk(this);
/* 34 */     postProcess(node);
/* 35 */     return node;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\HierarchyWalker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */