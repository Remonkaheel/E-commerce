package org.aspectj.asm;

public interface IModelFilter {
  String processFilelocation(String paramString);
  
  boolean wantsHandleIds();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IModelFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */