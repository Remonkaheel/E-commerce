package org.aspectj.asm;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public interface IRelationshipMap extends Serializable {
  List<IRelationship> get(IProgramElement paramIProgramElement);
  
  List<IRelationship> get(String paramString);
  
  IRelationship get(IProgramElement paramIProgramElement, IRelationship.Kind paramKind, String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  IRelationship get(IProgramElement paramIProgramElement, IRelationship.Kind paramKind, String paramString);
  
  IRelationship get(String paramString1, IRelationship.Kind paramKind, String paramString2, boolean paramBoolean1, boolean paramBoolean2);
  
  void put(IProgramElement paramIProgramElement, IRelationship paramIRelationship);
  
  void put(String paramString, IRelationship paramIRelationship);
  
  boolean remove(String paramString, IRelationship paramIRelationship);
  
  void removeAll(String paramString);
  
  void clear();
  
  Set<String> getEntries();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IRelationshipMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */