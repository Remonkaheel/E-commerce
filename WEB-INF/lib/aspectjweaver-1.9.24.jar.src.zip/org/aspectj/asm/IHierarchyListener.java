package org.aspectj.asm;

import java.util.EventListener;

public interface IHierarchyListener extends EventListener {
  void elementsUpdated(IHierarchy paramIHierarchy);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IHierarchyListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */