/*    */ package org.aspectj.asm;
/*    */ 
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IRelationship
/*    */   extends Serializable
/*    */ {
/*    */   String getName();
/*    */   
/*    */   Kind getKind();
/*    */   
/*    */   void addTarget(String paramString);
/*    */   
/*    */   List<String> getTargets();
/*    */   
/*    */   String getSourceHandle();
/*    */   
/*    */   boolean hasRuntimeTest();
/*    */   
/*    */   boolean isAffects();
/*    */   
/*    */   public static class Kind
/*    */     implements Serializable
/*    */   {
/*    */     private static final long serialVersionUID = -2691351740214705220L;
/* 44 */     public static final Kind DECLARE_WARNING = new Kind("declare warning");
/* 45 */     public static final Kind DECLARE_ERROR = new Kind("declare error");
/* 46 */     public static final Kind ADVICE_AROUND = new Kind("around advice");
/* 47 */     public static final Kind ADVICE_AFTERRETURNING = new Kind("after returning advice");
/* 48 */     public static final Kind ADVICE_AFTERTHROWING = new Kind("after throwing advice");
/* 49 */     public static final Kind ADVICE_AFTER = new Kind("after advice");
/* 50 */     public static final Kind ADVICE_BEFORE = new Kind("before advice");
/* 51 */     public static final Kind ADVICE = new Kind("advice");
/* 52 */     public static final Kind DECLARE = new Kind("declare");
/* 53 */     public static final Kind DECLARE_INTER_TYPE = new Kind("inter-type declaration");
/* 54 */     public static final Kind USES_POINTCUT = new Kind("uses pointcut");
/* 55 */     public static final Kind DECLARE_SOFT = new Kind("declare soft");
/*    */     
/* 57 */     public static final Kind[] ALL = new Kind[] { DECLARE_WARNING, DECLARE_ERROR, ADVICE_AROUND, ADVICE_AFTERRETURNING, ADVICE_AFTERTHROWING, ADVICE_AFTER, ADVICE_BEFORE, ADVICE, DECLARE, DECLARE_INTER_TYPE, USES_POINTCUT, DECLARE_SOFT };
/*    */     
/*    */     private final String name;
/*    */ 
/*    */     
/*    */     public boolean isDeclareKind() {
/* 63 */       return (this == DECLARE_WARNING || this == DECLARE_ERROR || this == DECLARE || this == DECLARE_INTER_TYPE || this == DECLARE_SOFT);
/*    */     }
/*    */ 
/*    */     
/*    */     public String getName() {
/* 68 */       return this.name;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static Kind getKindFor(String stringFormOfRelationshipKind) {
/* 78 */       for (Kind kind : ALL) {
/* 79 */         if (kind.name.equals(stringFormOfRelationshipKind)) {
/* 80 */           return kind;
/*    */         }
/*    */       } 
/* 83 */       return null;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     private Kind(String name) {
/* 96 */       this.ordinal = nextOrdinal++;
/*    */       this.name = name;
/*    */     } private Object readResolve() throws ObjectStreamException {
/* 99 */       return ALL[this.ordinal];
/*    */     }
/*    */     
/*    */     public String toString() {
/*    */       return this.name;
/*    */     }
/*    */     
/*    */     private static int nextOrdinal = 0;
/*    */     private final int ordinal;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IRelationship.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */