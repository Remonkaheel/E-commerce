package org.aspectj.asm;

import java.io.File;
import org.aspectj.bridge.ISourceLocation;

public interface IElementHandleProvider {
  String createHandleIdentifier(ISourceLocation paramISourceLocation);
  
  String createHandleIdentifier(File paramFile, int paramInt1, int paramInt2, int paramInt3);
  
  String createHandleIdentifier(IProgramElement paramIProgramElement);
  
  String getFileForHandle(String paramString);
  
  int getLineNumberForHandle(String paramString);
  
  int getOffSetForHandle(String paramString);
  
  void initialize();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IElementHandleProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */