/*     */ package org.aspectj.asm;public interface IProgramElement extends Serializable { List<IProgramElement> getChildren(); void setChildren(List<IProgramElement> paramList); void addChild(IProgramElement paramIProgramElement); boolean removeChild(IProgramElement paramIProgramElement); void setExtraInfo(ExtraInformation paramExtraInformation); ExtraInformation getExtraInfo(); IProgramElement getParent(); void setParent(IProgramElement paramIProgramElement); void setParentTypes(List<String> paramList); List<String> getParentTypes(); String getName(); void setName(String paramString); String getDetails(); void setDetails(String paramString); Kind getKind(); void setKind(Kind paramKind); List<Modifiers> getModifiers(); void setModifiers(int paramInt); Accessibility getAccessibility(); String getDeclaringType(); String getPackageName(); void setCorrespondingType(String paramString); String getCorrespondingType(); String getCorrespondingType(boolean paramBoolean); String toSignatureString(); String toSignatureString(boolean paramBoolean); void setRunnable(boolean paramBoolean); boolean isRunnable(); boolean isImplementor();
/*     */   void setImplementor(boolean paramBoolean);
/*     */   boolean isOverrider();
/*     */   void setOverrider(boolean paramBoolean);
/*     */   IMessage getMessage();
/*     */   void setMessage(IMessage paramIMessage);
/*     */   ISourceLocation getSourceLocation();
/*     */   void setSourceLocation(ISourceLocation paramISourceLocation);
/*     */   String toString();
/*     */   String getFormalComment();
/*     */   void setFormalComment(String paramString);
/*     */   String toLinkLabelString();
/*     */   String toLinkLabelString(boolean paramBoolean);
/*     */   String toLabelString();
/*     */   String toLabelString(boolean paramBoolean);
/*     */   List<String> getParameterNames();
/*     */   void setParameterNames(List<String> paramList);
/*     */   List<char[]> getParameterSignatures();
/*     */   List<String> getParameterSignaturesSourceRefs();
/*     */   void setParameterSignatures(List<char[]> paramList, List<String> paramList1);
/*     */   List<char[]> getParameterTypes();
/*     */   String getHandleIdentifier();
/*     */   String getHandleIdentifier(boolean paramBoolean);
/*     */   void setHandleIdentifier(String paramString);
/*     */   String toLongString();
/*     */   String getBytecodeName();
/*     */   String getBytecodeSignature();
/*     */   void setBytecodeName(String paramString);
/*     */   void setBytecodeSignature(String paramString);
/*     */   String getSourceSignature();
/*     */   void setSourceSignature(String paramString);
/*     */   IProgramElement walk(HierarchyWalker paramHierarchyWalker);
/*     */   AsmManager getModel();
/*     */   int getRawModifiers();
/*     */   void setAnnotationStyleDeclaration(boolean paramBoolean);
/*     */   boolean isAnnotationStyleDeclaration();
/*     */   void setAnnotationType(String paramString);
/*     */   String getAnnotationType();
/*     */   String[] getRemovedAnnotationTypes();
/*     */   Map<String, List<String>> getDeclareParentsMap();
/*     */   void setDeclareParentsMap(Map<String, List<String>> paramMap);
/*     */   void addFullyQualifiedName(String paramString);
/*     */   String getFullyQualifiedName();
/*     */   void setAnnotationRemover(boolean paramBoolean);
/*     */   boolean isAnnotationRemover();
/*     */   String getCorrespondingTypeSignature();
/*  47 */   public static class ExtraInformation implements Serializable { private String extraInfo = "";
/*     */     private static final long serialVersionUID = -3880735494840820638L;
/*     */     
/*     */     public void setExtraAdviceInformation(String string) {
/*  51 */       this.extraInfo = string;
/*     */     }
/*     */     
/*     */     public String getExtraAdviceInformation() {
/*  55 */       return this.extraInfo;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  59 */       return "ExtraInformation: [" + this.extraInfo + "]";
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Modifiers
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = -8279300899976607927L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     public static final Modifiers STATIC = new Modifiers("static", 8);
/* 214 */     public static final Modifiers FINAL = new Modifiers("final", 16);
/* 215 */     public static final Modifiers ABSTRACT = new Modifiers("abstract", 1024);
/* 216 */     public static final Modifiers SYNCHRONIZED = new Modifiers("synchronized", 32);
/* 217 */     public static final Modifiers VOLATILE = new Modifiers("volatile", 64);
/* 218 */     public static final Modifiers STRICTFP = new Modifiers("strictfp", 2048);
/* 219 */     public static final Modifiers TRANSIENT = new Modifiers("transient", 128);
/* 220 */     public static final Modifiers NATIVE = new Modifiers("native", 256);
/* 221 */     public static final Modifiers[] ALL = new Modifiers[] { STATIC, FINAL, ABSTRACT, SYNCHRONIZED, VOLATILE, STRICTFP, TRANSIENT, NATIVE };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int bit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Modifiers(String name, int bit) {
/* 240 */       this.ordinal = nextOrdinal++; this.name = name;
/*     */       this.bit = bit;
/*     */     } public String toString() { return this.name; } public int getBit() { return this.bit; } private static int nextOrdinal = 0; private final int ordinal;
/* 243 */     private Object readResolve() throws ObjectStreamException { return ALL[this.ordinal]; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Accessibility
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 5371838588180918519L;
/*     */     
/* 254 */     public static final Accessibility PUBLIC = new Accessibility("public");
/* 255 */     public static final Accessibility PACKAGE = new Accessibility("package");
/* 256 */     public static final Accessibility PROTECTED = new Accessibility("protected");
/* 257 */     public static final Accessibility PRIVATE = new Accessibility("private");
/* 258 */     public static final Accessibility PRIVILEGED = new Accessibility("privileged");
/* 259 */     public static final Accessibility[] ALL = new Accessibility[] { PUBLIC, PACKAGE, PROTECTED, PRIVATE, PRIVILEGED };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Accessibility(String name) {
/* 272 */       this.ordinal = nextOrdinal++;
/*     */       this.name = name;
/*     */     } public String toString() { return this.name; } private static int nextOrdinal = 0; private final int ordinal; private Object readResolve() throws ObjectStreamException {
/* 275 */       return ALL[this.ordinal];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Kind
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = -1963553877479266124L;
/*     */     
/* 286 */     public static final Kind PROJECT = new Kind("project");
/* 287 */     public static final Kind PACKAGE = new Kind("package");
/* 288 */     public static final Kind FILE = new Kind("file");
/* 289 */     public static final Kind FILE_JAVA = new Kind("java source file");
/* 290 */     public static final Kind FILE_ASPECTJ = new Kind("aspect source file");
/* 291 */     public static final Kind FILE_LST = new Kind("build configuration file");
/* 292 */     public static final Kind IMPORT_REFERENCE = new Kind("import reference");
/* 293 */     public static final Kind CLASS = new Kind("class");
/* 294 */     public static final Kind INTERFACE = new Kind("interface");
/* 295 */     public static final Kind ASPECT = new Kind("aspect");
/* 296 */     public static final Kind ENUM = new Kind("enum");
/* 297 */     public static final Kind ENUM_VALUE = new Kind("enumvalue");
/* 298 */     public static final Kind ANNOTATION = new Kind("annotation");
/* 299 */     public static final Kind INITIALIZER = new Kind("initializer");
/* 300 */     public static final Kind INTER_TYPE_FIELD = new Kind("inter-type field");
/* 301 */     public static final Kind INTER_TYPE_METHOD = new Kind("inter-type method");
/* 302 */     public static final Kind INTER_TYPE_CONSTRUCTOR = new Kind("inter-type constructor");
/* 303 */     public static final Kind INTER_TYPE_PARENT = new Kind("inter-type parent");
/* 304 */     public static final Kind CONSTRUCTOR = new Kind("constructor");
/* 305 */     public static final Kind METHOD = new Kind("method");
/* 306 */     public static final Kind FIELD = new Kind("field");
/* 307 */     public static final Kind POINTCUT = new Kind("pointcut");
/* 308 */     public static final Kind ADVICE = new Kind("advice");
/* 309 */     public static final Kind DECLARE_PARENTS = new Kind("declare parents");
/* 310 */     public static final Kind DECLARE_WARNING = new Kind("declare warning");
/* 311 */     public static final Kind DECLARE_ERROR = new Kind("declare error");
/* 312 */     public static final Kind DECLARE_SOFT = new Kind("declare soft");
/* 313 */     public static final Kind DECLARE_PRECEDENCE = new Kind("declare precedence");
/* 314 */     public static final Kind CODE = new Kind("code");
/* 315 */     public static final Kind ERROR = new Kind("error");
/* 316 */     public static final Kind DECLARE_ANNOTATION_AT_CONSTRUCTOR = new Kind("declare @constructor");
/* 317 */     public static final Kind DECLARE_ANNOTATION_AT_FIELD = new Kind("declare @field");
/* 318 */     public static final Kind DECLARE_ANNOTATION_AT_METHOD = new Kind("declare @method");
/* 319 */     public static final Kind DECLARE_ANNOTATION_AT_TYPE = new Kind("declare @type");
/* 320 */     public static final Kind SOURCE_FOLDER = new Kind("source folder");
/* 321 */     public static final Kind PACKAGE_DECLARATION = new Kind("package declaration");
/*     */     
/* 323 */     public static final Kind[] ALL = new Kind[] { PROJECT, PACKAGE, FILE, FILE_JAVA, FILE_ASPECTJ, FILE_LST, IMPORT_REFERENCE, CLASS, INTERFACE, ASPECT, ENUM, ENUM_VALUE, ANNOTATION, INITIALIZER, INTER_TYPE_FIELD, INTER_TYPE_METHOD, INTER_TYPE_CONSTRUCTOR, INTER_TYPE_PARENT, CONSTRUCTOR, METHOD, FIELD, POINTCUT, ADVICE, DECLARE_PARENTS, DECLARE_WARNING, DECLARE_ERROR, DECLARE_SOFT, DECLARE_PRECEDENCE, CODE, ERROR, DECLARE_ANNOTATION_AT_CONSTRUCTOR, DECLARE_ANNOTATION_AT_FIELD, DECLARE_ANNOTATION_AT_METHOD, DECLARE_ANNOTATION_AT_TYPE, SOURCE_FOLDER, PACKAGE_DECLARATION };
/*     */ 
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Kind getKindForString(String kindString) {
/* 333 */       for (Kind kind : ALL) {
/* 334 */         if (kind.toString().equals(kindString)) {
/* 335 */           return kind;
/*     */         }
/*     */       } 
/* 338 */       return ERROR;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Kind(String name) {
/* 411 */       this.ordinal = nextOrdinal++; this.name = name;
/*     */     } public String toString() { return this.name; } public static List<Kind> getNonAJMemberKinds() { List<Kind> list = new ArrayList<>(); list.add(METHOD); list.add(ENUM_VALUE); list.add(FIELD); list.add(CONSTRUCTOR); return list; } public boolean isMember() { return (this == FIELD || this == METHOD || this == CONSTRUCTOR || this == POINTCUT || this == ADVICE || this == ENUM_VALUE); } public boolean isInterTypeMember() { return (this == INTER_TYPE_CONSTRUCTOR || this == INTER_TYPE_FIELD || this == INTER_TYPE_METHOD); } public boolean isType() { return (this == CLASS || this == INTERFACE || this == ASPECT || this == ANNOTATION || this == ENUM); } public boolean isSourceFile() { return (this == FILE_ASPECTJ || this == FILE_JAVA); } public boolean isFile() { return (this == FILE); } public boolean isDeclare() { return this.name.startsWith("declare"); } public boolean isDeclareAnnotation() { return this.name.startsWith("declare @"); } public boolean isDeclareParents() { return this.name.startsWith("declare parents"); } public boolean isDeclareSoft() { return this.name.startsWith("declare soft"); } public boolean isDeclareWarning() { return this.name.startsWith("declare warning"); } public boolean isDeclareError() { return this.name.startsWith("declare error"); } public boolean isDeclarePrecedence() { return this.name.startsWith("declare precedence"); }
/*     */     private static int nextOrdinal = 0; private final int ordinal;
/* 414 */     private Object readResolve() throws ObjectStreamException { return ALL[this.ordinal]; }
/*     */ 
/*     */     
/*     */     public boolean isPackageDeclaration() {
/* 418 */       return (this == PACKAGE_DECLARATION);
/*     */     }
/*     */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\asm\IProgramElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */