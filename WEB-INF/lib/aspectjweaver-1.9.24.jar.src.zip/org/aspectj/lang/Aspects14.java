/*     */ package org.aspectj.lang;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Aspects14
/*     */ {
/*  28 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*  29 */   private static final Class[] PEROBJECT_CLASS_ARRAY = new Class[] { Object.class };
/*  30 */   private static final Class[] PERTYPEWITHIN_CLASS_ARRAY = new Class[] { Class.class };
/*  31 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ASPECTOF = "aspectOf";
/*     */ 
/*     */   
/*     */   private static final String HASASPECT = "hasAspect";
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object aspectOf(Class<?> aspectClass) throws NoAspectBoundException {
/*     */     try {
/*  44 */       return getSingletonOrThreadAspectOf(aspectClass).invoke((Object)null, EMPTY_OBJECT_ARRAY);
/*  45 */     } catch (InvocationTargetException e) {
/*     */       
/*  47 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*  48 */     } catch (Exception e) {
/*  49 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object aspectOf(Class<?> aspectClass, Object perObject) throws NoAspectBoundException {
/*     */     try {
/*  62 */       return getPerObjectAspectOf(aspectClass).invoke((Object)null, new Object[] { perObject });
/*  63 */     } catch (InvocationTargetException e) {
/*     */       
/*  65 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*  66 */     } catch (Exception e) {
/*  67 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object aspectOf(Class<?> aspectClass, Class perTypeWithin) throws NoAspectBoundException {
/*     */     try {
/*  80 */       return getPerTypeWithinAspectOf(aspectClass).invoke((Object)null, new Object[] { perTypeWithin });
/*  81 */     } catch (InvocationTargetException e) {
/*     */       
/*  83 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*  84 */     } catch (Exception e) {
/*  85 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAspect(Class<?> aspectClass) throws NoAspectBoundException {
/*     */     try {
/*  98 */       return ((Boolean)getSingletonOrThreadHasAspect(aspectClass).invoke((Object)null, EMPTY_OBJECT_ARRAY)).booleanValue();
/*  99 */     } catch (Exception e) {
/* 100 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAspect(Class<?> aspectClass, Object perObject) throws NoAspectBoundException {
/*     */     try {
/* 113 */       return ((Boolean)getPerObjectHasAspect(aspectClass).invoke((Object)null, new Object[] { perObject })).booleanValue();
/* 114 */     } catch (Exception e) {
/* 115 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAspect(Class<?> aspectClass, Class perTypeWithin) throws NoAspectBoundException {
/*     */     try {
/* 128 */       return ((Boolean)getPerTypeWithinHasAspect(aspectClass).invoke((Object)null, new Object[] { perTypeWithin })).booleanValue();
/* 129 */     } catch (Exception e) {
/* 130 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getSingletonOrThreadAspectOf(Class<?> aspectClass) throws NoSuchMethodException {
/* 137 */     Method method = aspectClass.getDeclaredMethod("aspectOf", EMPTY_CLASS_ARRAY);
/* 138 */     return checkAspectOf(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerObjectAspectOf(Class<?> aspectClass) throws NoSuchMethodException {
/* 142 */     Method method = aspectClass.getDeclaredMethod("aspectOf", PEROBJECT_CLASS_ARRAY);
/* 143 */     return checkAspectOf(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerTypeWithinAspectOf(Class<?> aspectClass) throws NoSuchMethodException {
/* 147 */     Method method = aspectClass.getDeclaredMethod("aspectOf", PERTYPEWITHIN_CLASS_ARRAY);
/* 148 */     return checkAspectOf(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method checkAspectOf(Method method, Class<?> aspectClass) throws NoSuchMethodException {
/* 152 */     method.setAccessible(true);
/* 153 */     if (!method.isAccessible() || 
/* 154 */       !Modifier.isPublic(method.getModifiers()) || 
/* 155 */       !Modifier.isStatic(method.getModifiers())) {
/* 156 */       throw new NoSuchMethodException(aspectClass.getName() + ".aspectOf(..) is not accessible public static");
/*     */     }
/* 158 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getSingletonOrThreadHasAspect(Class<?> aspectClass) throws NoSuchMethodException {
/* 164 */     Method method = aspectClass.getDeclaredMethod("hasAspect", EMPTY_CLASS_ARRAY);
/* 165 */     return checkHasAspect(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerObjectHasAspect(Class<?> aspectClass) throws NoSuchMethodException {
/* 169 */     Method method = aspectClass.getDeclaredMethod("hasAspect", PEROBJECT_CLASS_ARRAY);
/* 170 */     return checkHasAspect(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerTypeWithinHasAspect(Class<?> aspectClass) throws NoSuchMethodException {
/* 174 */     Method method = aspectClass.getDeclaredMethod("hasAspect", PERTYPEWITHIN_CLASS_ARRAY);
/* 175 */     return checkHasAspect(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method checkHasAspect(Method method, Class<?> aspectClass) throws NoSuchMethodException {
/* 179 */     method.setAccessible(true);
/* 180 */     if (!method.isAccessible() || 
/* 181 */       !Modifier.isPublic(method.getModifiers()) || 
/* 182 */       !Modifier.isStatic(method.getModifiers())) {
/* 183 */       throw new NoSuchMethodException(aspectClass.getName() + ".hasAspect(..) is not accessible public static");
/*     */     }
/* 185 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\Aspects14.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */