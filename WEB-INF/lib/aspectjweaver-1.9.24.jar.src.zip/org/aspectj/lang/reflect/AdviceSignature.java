package org.aspectj.lang.reflect;

import java.lang.reflect.Method;

public interface AdviceSignature extends CodeSignature {
  Class getReturnType();
  
  Method getAdvice();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\AdviceSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */