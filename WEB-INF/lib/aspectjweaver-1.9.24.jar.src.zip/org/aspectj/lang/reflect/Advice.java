package org.aspectj.lang.reflect;

import java.lang.reflect.Type;

public interface Advice {
  AjType getDeclaringType();
  
  AdviceKind getKind();
  
  String getName();
  
  AjType<?>[] getParameterTypes();
  
  Type[] getGenericParameterTypes();
  
  AjType<?>[] getExceptionTypes();
  
  PointcutExpression getPointcutExpression();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\Advice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */