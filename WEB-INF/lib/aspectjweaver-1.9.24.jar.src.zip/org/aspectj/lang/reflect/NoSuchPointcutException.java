/*    */ package org.aspectj.lang.reflect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoSuchPointcutException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3256444698657634352L;
/*    */   private String name;
/*    */   
/*    */   public NoSuchPointcutException(String name) {
/* 24 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 31 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\NoSuchPointcutException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */