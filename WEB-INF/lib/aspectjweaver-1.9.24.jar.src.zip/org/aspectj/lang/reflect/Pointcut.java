package org.aspectj.lang.reflect;

public interface Pointcut {
  String getName();
  
  int getModifiers();
  
  AjType<?>[] getParameterTypes();
  
  String[] getParameterNames();
  
  AjType getDeclaringType();
  
  PointcutExpression getPointcutExpression();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\Pointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */