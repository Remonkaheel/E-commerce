package org.aspectj.lang.reflect;

public interface SourceLocation {
  Class getWithinType();
  
  String getFileName();
  
  int getLine();
  
  int getColumn();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\SourceLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */