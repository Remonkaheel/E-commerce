/*    */ package org.aspectj.lang.reflect;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.WeakHashMap;
/*    */ import org.aspectj.internal.lang.reflect.AjTypeImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AjTypeSystem
/*    */ {
/* 29 */   private static Map<Class, WeakReference<AjType>> ajTypes = Collections.synchronizedMap(new WeakHashMap<>());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> AjType<T> getAjType(Class<T> fromClass) {
/* 42 */     WeakReference<AjType> weakRefToAjType = ajTypes.get(fromClass);
/* 43 */     if (weakRefToAjType != null) {
/* 44 */       AjType<T> theAjType = weakRefToAjType.get();
/* 45 */       if (theAjType != null) {
/* 46 */         return theAjType;
/*    */       }
/* 48 */       AjTypeImpl ajTypeImpl1 = new AjTypeImpl(fromClass);
/* 49 */       ajTypes.put(fromClass, new WeakReference(ajTypeImpl1));
/* 50 */       return (AjType<T>)ajTypeImpl1;
/*    */     } 
/*    */ 
/*    */     
/* 54 */     AjTypeImpl ajTypeImpl = new AjTypeImpl(fromClass);
/* 55 */     ajTypes.put(fromClass, new WeakReference(ajTypeImpl));
/* 56 */     return (AjType<T>)ajTypeImpl;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\AjTypeSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */