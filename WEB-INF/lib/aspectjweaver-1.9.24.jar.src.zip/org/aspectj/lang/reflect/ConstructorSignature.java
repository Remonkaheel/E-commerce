package org.aspectj.lang.reflect;

import java.lang.reflect.Constructor;

public interface ConstructorSignature extends CodeSignature {
  Constructor getConstructor();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\ConstructorSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */