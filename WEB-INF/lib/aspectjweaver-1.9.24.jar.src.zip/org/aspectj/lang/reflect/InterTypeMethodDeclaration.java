package org.aspectj.lang.reflect;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

public interface InterTypeMethodDeclaration extends InterTypeDeclaration {
  String getName();
  
  AjType<?> getReturnType();
  
  Type getGenericReturnType();
  
  AjType<?>[] getParameterTypes();
  
  Type[] getGenericParameterTypes();
  
  TypeVariable<Method>[] getTypeParameters();
  
  AjType<?>[] getExceptionTypes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\InterTypeMethodDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */