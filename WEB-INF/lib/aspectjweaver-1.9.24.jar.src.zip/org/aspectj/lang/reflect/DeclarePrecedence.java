package org.aspectj.lang.reflect;

public interface DeclarePrecedence {
  AjType getDeclaringType();
  
  TypePattern[] getPrecedenceOrder();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\DeclarePrecedence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */