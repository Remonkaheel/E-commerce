package org.aspectj.lang.reflect;

import java.lang.reflect.Method;

public interface MethodSignature extends CodeSignature {
  Class getReturnType();
  
  Method getMethod();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\MethodSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */