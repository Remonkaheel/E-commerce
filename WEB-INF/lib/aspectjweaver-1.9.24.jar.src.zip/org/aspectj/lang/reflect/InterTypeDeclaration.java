package org.aspectj.lang.reflect;

public interface InterTypeDeclaration {
  AjType<?> getDeclaringType();
  
  AjType<?> getTargetType() throws ClassNotFoundException;
  
  int getModifiers();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\InterTypeDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */