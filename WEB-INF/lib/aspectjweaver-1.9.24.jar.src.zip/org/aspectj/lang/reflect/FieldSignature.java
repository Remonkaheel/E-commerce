package org.aspectj.lang.reflect;

import java.lang.reflect.Field;

public interface FieldSignature extends MemberSignature {
  Class getFieldType();
  
  Field getField();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\FieldSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */