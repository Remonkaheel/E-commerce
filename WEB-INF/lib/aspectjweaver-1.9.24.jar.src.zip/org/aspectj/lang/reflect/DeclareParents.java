package org.aspectj.lang.reflect;

import java.lang.reflect.Type;

public interface DeclareParents {
  AjType getDeclaringType();
  
  TypePattern getTargetTypesPattern();
  
  boolean isExtends();
  
  boolean isImplements();
  
  Type[] getParentTypes() throws ClassNotFoundException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\DeclareParents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */