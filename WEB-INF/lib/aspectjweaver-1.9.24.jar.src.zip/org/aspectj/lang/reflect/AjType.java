package org.aspectj.lang.reflect;

import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

public interface AjType<T> extends Type, AnnotatedElement {
  String getName();
  
  Package getPackage();
  
  AjType<?>[] getInterfaces();
  
  int getModifiers();
  
  Class<T> getJavaClass();
  
  AjType<?> getSupertype();
  
  Type getGenericSupertype();
  
  Method getEnclosingMethod();
  
  Constructor getEnclosingConstructor();
  
  AjType<?> getEnclosingType();
  
  AjType<?> getDeclaringType();
  
  PerClause getPerClause();
  
  AjType<?>[] getAjTypes();
  
  AjType<?>[] getDeclaredAjTypes();
  
  Constructor getConstructor(AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  Constructor[] getConstructors();
  
  Constructor getDeclaredConstructor(AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  Constructor[] getDeclaredConstructors();
  
  Field getDeclaredField(String paramString) throws NoSuchFieldException;
  
  Field[] getDeclaredFields();
  
  Field getField(String paramString) throws NoSuchFieldException;
  
  Field[] getFields();
  
  Method getDeclaredMethod(String paramString, AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  Method getMethod(String paramString, AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  Method[] getDeclaredMethods();
  
  Method[] getMethods();
  
  Pointcut getDeclaredPointcut(String paramString) throws NoSuchPointcutException;
  
  Pointcut getPointcut(String paramString) throws NoSuchPointcutException;
  
  Pointcut[] getDeclaredPointcuts();
  
  Pointcut[] getPointcuts();
  
  Advice[] getDeclaredAdvice(AdviceKind... paramVarArgs);
  
  Advice[] getAdvice(AdviceKind... paramVarArgs);
  
  Advice getAdvice(String paramString) throws NoSuchAdviceException;
  
  Advice getDeclaredAdvice(String paramString) throws NoSuchAdviceException;
  
  InterTypeMethodDeclaration getDeclaredITDMethod(String paramString, AjType<?> paramAjType, AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  InterTypeMethodDeclaration[] getDeclaredITDMethods();
  
  InterTypeMethodDeclaration getITDMethod(String paramString, AjType<?> paramAjType, AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  InterTypeMethodDeclaration[] getITDMethods();
  
  InterTypeConstructorDeclaration getDeclaredITDConstructor(AjType<?> paramAjType, AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  InterTypeConstructorDeclaration[] getDeclaredITDConstructors();
  
  InterTypeConstructorDeclaration getITDConstructor(AjType<?> paramAjType, AjType<?>... paramVarArgs) throws NoSuchMethodException;
  
  InterTypeConstructorDeclaration[] getITDConstructors();
  
  InterTypeFieldDeclaration getDeclaredITDField(String paramString, AjType<?> paramAjType) throws NoSuchFieldException;
  
  InterTypeFieldDeclaration[] getDeclaredITDFields();
  
  InterTypeFieldDeclaration getITDField(String paramString, AjType<?> paramAjType) throws NoSuchFieldException;
  
  InterTypeFieldDeclaration[] getITDFields();
  
  DeclareErrorOrWarning[] getDeclareErrorOrWarnings();
  
  DeclareParents[] getDeclareParents();
  
  DeclareSoft[] getDeclareSofts();
  
  DeclareAnnotation[] getDeclareAnnotations();
  
  DeclarePrecedence[] getDeclarePrecedence();
  
  T[] getEnumConstants();
  
  TypeVariable<Class<T>>[] getTypeParameters();
  
  boolean isEnum();
  
  boolean isInstance(Object paramObject);
  
  boolean isInterface();
  
  boolean isLocalClass();
  
  boolean isMemberClass();
  
  boolean isArray();
  
  boolean isPrimitive();
  
  boolean isAspect();
  
  boolean isMemberAspect();
  
  boolean isPrivileged();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\reflect\AjType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */