/*    */ package org.aspectj.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoAspectBoundException
/*    */   extends RuntimeException
/*    */ {
/*    */   Throwable cause;
/*    */   
/*    */   public NoAspectBoundException(String aspectName, Throwable inner) {
/* 24 */     super((inner == null) ? aspectName : (
/* 25 */         "Exception while initializing " + aspectName + ": " + inner));
/* 26 */     this.cause = inner;
/*    */   }
/*    */   
/*    */   public NoAspectBoundException() {}
/*    */   
/*    */   public Throwable getCause() {
/* 32 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\NoAspectBoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */