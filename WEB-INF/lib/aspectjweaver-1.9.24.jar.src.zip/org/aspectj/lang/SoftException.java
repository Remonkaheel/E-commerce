/*    */ package org.aspectj.lang;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SoftException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final boolean HAVE_JAVA_14;
/*    */   Throwable inner;
/*    */   
/*    */   static {
/* 36 */     boolean java14 = false;
/*    */     try {
/* 38 */       Class.forName("java.nio.Buffer");
/* 39 */       java14 = true;
/* 40 */     } catch (Throwable throwable) {}
/*    */ 
/*    */     
/* 43 */     HAVE_JAVA_14 = java14;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SoftException(Throwable inner) {
/* 53 */     this.inner = inner;
/*    */   }
/*    */   
/* 56 */   public Throwable getWrappedThrowable() { return this.inner; } public Throwable getCause() {
/* 57 */     return this.inner;
/*    */   }
/*    */   public void printStackTrace() {
/* 60 */     printStackTrace(System.err);
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintStream stream) {
/* 64 */     super.printStackTrace(stream);
/* 65 */     Throwable _inner = this.inner;
/* 66 */     if (!HAVE_JAVA_14 && null != _inner) {
/* 67 */       stream.print("Caused by: ");
/* 68 */       _inner.printStackTrace(stream);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintWriter stream) {
/* 73 */     super.printStackTrace(stream);
/* 74 */     Throwable _inner = this.inner;
/* 75 */     if (!HAVE_JAVA_14 && null != _inner) {
/* 76 */       stream.print("Caused by: ");
/* 77 */       _inner.printStackTrace(stream);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\SoftException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */