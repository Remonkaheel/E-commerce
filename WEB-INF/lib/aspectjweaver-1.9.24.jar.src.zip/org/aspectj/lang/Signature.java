package org.aspectj.lang;

public interface Signature {
  String toString();
  
  String toShortString();
  
  String toLongString();
  
  String getName();
  
  int getModifiers();
  
  Class getDeclaringType();
  
  String getDeclaringTypeName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\Signature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */