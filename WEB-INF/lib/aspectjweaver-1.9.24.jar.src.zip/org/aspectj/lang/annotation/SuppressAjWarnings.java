package org.aspectj.lang.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface SuppressAjWarnings {
  String[] value() default {""};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\annotation\SuppressAjWarnings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */