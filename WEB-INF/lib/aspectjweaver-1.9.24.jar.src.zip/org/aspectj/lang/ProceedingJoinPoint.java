/*    */ package org.aspectj.lang;
/*    */ 
/*    */ import org.aspectj.runtime.internal.AroundClosure;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ProceedingJoinPoint
/*    */   extends JoinPoint
/*    */ {
/*    */   void set$AroundClosure(AroundClosure paramAroundClosure);
/*    */   
/*    */   default void stack$AroundClosure(AroundClosure arc) {
/* 42 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   Object proceed() throws Throwable;
/*    */   
/*    */   Object proceed(Object[] paramArrayOfObject) throws Throwable;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\ProceedingJoinPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */