/*     */ package org.aspectj.lang;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Aspects
/*     */ {
/*  30 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*  31 */   private static final Class[] PEROBJECT_CLASS_ARRAY = new Class[] { Object.class };
/*  32 */   private static final Class[] PERTYPEWITHIN_CLASS_ARRAY = new Class[] { Class.class };
/*  33 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */ 
/*     */   
/*     */   private static final String ASPECTOF = "aspectOf";
/*     */ 
/*     */   
/*     */   private static final String HASASPECT = "hasAspect";
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T aspectOf(Class<T> aspectClass) throws NoAspectBoundException {
/*     */     try {
/*  45 */       return (T)getSingletonOrThreadAspectOf(aspectClass).invoke((Object)null, EMPTY_OBJECT_ARRAY);
/*  46 */     } catch (InvocationTargetException e) {
/*     */       
/*  48 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*  49 */     } catch (Exception e) {
/*  50 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T aspectOf(Class<T> aspectClass, Object perObject) throws NoAspectBoundException {
/*     */     try {
/*  63 */       return (T)getPerObjectAspectOf(aspectClass).invoke((Object)null, new Object[] { perObject });
/*  64 */     } catch (InvocationTargetException e) {
/*     */       
/*  66 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*  67 */     } catch (Exception e) {
/*  68 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T aspectOf(Class<T> aspectClass, Class<?> perTypeWithin) throws NoAspectBoundException {
/*     */     try {
/*  81 */       return (T)getPerTypeWithinAspectOf(aspectClass).invoke((Object)null, new Object[] { perTypeWithin });
/*  82 */     } catch (InvocationTargetException e) {
/*     */       
/*  84 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*  85 */     } catch (Exception e) {
/*  86 */       throw new NoAspectBoundException(aspectClass.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAspect(Class<?> aspectClass) throws NoAspectBoundException {
/*     */     try {
/*  97 */       return ((Boolean)getSingletonOrThreadHasAspect(aspectClass).invoke((Object)null, EMPTY_OBJECT_ARRAY)).booleanValue();
/*  98 */     } catch (Exception e) {
/*  99 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAspect(Class<?> aspectClass, Object perObject) throws NoAspectBoundException {
/*     */     try {
/* 111 */       return ((Boolean)getPerObjectHasAspect(aspectClass).invoke((Object)null, new Object[] { perObject })).booleanValue();
/* 112 */     } catch (Exception e) {
/* 113 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAspect(Class<?> aspectClass, Class<?> perTypeWithin) throws NoAspectBoundException {
/*     */     try {
/* 125 */       return ((Boolean)getPerTypeWithinHasAspect(aspectClass).invoke((Object)null, new Object[] { perTypeWithin })).booleanValue();
/* 126 */     } catch (Exception e) {
/* 127 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getSingletonOrThreadAspectOf(Class<?> aspectClass) throws NoSuchMethodException {
/* 134 */     Method method = aspectClass.getDeclaredMethod("aspectOf", EMPTY_CLASS_ARRAY);
/* 135 */     return checkAspectOf(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerObjectAspectOf(Class<?> aspectClass) throws NoSuchMethodException {
/* 139 */     Method method = aspectClass.getDeclaredMethod("aspectOf", PEROBJECT_CLASS_ARRAY);
/* 140 */     return checkAspectOf(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerTypeWithinAspectOf(Class<?> aspectClass) throws NoSuchMethodException {
/* 144 */     Method method = aspectClass.getDeclaredMethod("aspectOf", PERTYPEWITHIN_CLASS_ARRAY);
/* 145 */     return checkAspectOf(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method checkAspectOf(Method method, Class<?> aspectClass) throws NoSuchMethodException {
/* 149 */     method.setAccessible(true);
/* 150 */     if (!method.isAccessible() || 
/* 151 */       !Modifier.isPublic(method.getModifiers()) || 
/* 152 */       !Modifier.isStatic(method.getModifiers())) {
/* 153 */       throw new NoSuchMethodException(aspectClass.getName() + ".aspectOf(..) is not accessible public static");
/*     */     }
/* 155 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getSingletonOrThreadHasAspect(Class<?> aspectClass) throws NoSuchMethodException {
/* 161 */     Method method = aspectClass.getDeclaredMethod("hasAspect", EMPTY_CLASS_ARRAY);
/* 162 */     return checkHasAspect(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerObjectHasAspect(Class<?> aspectClass) throws NoSuchMethodException {
/* 166 */     Method method = aspectClass.getDeclaredMethod("hasAspect", PEROBJECT_CLASS_ARRAY);
/* 167 */     return checkHasAspect(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method getPerTypeWithinHasAspect(Class<?> aspectClass) throws NoSuchMethodException {
/* 171 */     Method method = aspectClass.getDeclaredMethod("hasAspect", PERTYPEWITHIN_CLASS_ARRAY);
/* 172 */     return checkHasAspect(method, aspectClass);
/*     */   }
/*     */   
/*     */   private static Method checkHasAspect(Method method, Class<?> aspectClass) throws NoSuchMethodException {
/* 176 */     method.setAccessible(true);
/* 177 */     if (!method.isAccessible() || 
/* 178 */       !Modifier.isPublic(method.getModifiers()) || 
/* 179 */       !Modifier.isStatic(method.getModifiers())) {
/* 180 */       throw new NoSuchMethodException(aspectClass.getName() + ".hasAspect(..) is not accessible public static");
/*     */     }
/* 182 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\Aspects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */