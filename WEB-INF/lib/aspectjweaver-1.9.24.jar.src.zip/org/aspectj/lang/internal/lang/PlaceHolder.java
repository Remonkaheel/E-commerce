package org.aspectj.lang.internal.lang;

class PlaceHolder {
  private static final long L = 1L;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\lang\internal\lang\PlaceHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */