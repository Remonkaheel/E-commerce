/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.InterTypeDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterTypeDeclarationImpl
/*    */   implements InterTypeDeclaration
/*    */ {
/*    */   private AjType<?> declaringType;
/*    */   protected String targetTypeName;
/*    */   private AjType<?> targetType;
/*    */   private int modifiers;
/*    */   
/*    */   public InterTypeDeclarationImpl(AjType<?> decType, String target, int mods) {
/* 29 */     this.declaringType = decType;
/* 30 */     this.targetTypeName = target;
/* 31 */     this.modifiers = mods;
/*    */     try {
/* 33 */       this.targetType = (AjType)StringToType.stringToType(target, decType.getJavaClass());
/* 34 */     } catch (ClassNotFoundException classNotFoundException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public InterTypeDeclarationImpl(AjType<?> decType, AjType<?> targetType, int mods) {
/* 40 */     this.declaringType = decType;
/* 41 */     this.targetType = targetType;
/* 42 */     this.targetTypeName = targetType.getName();
/* 43 */     this.modifiers = mods;
/*    */   }
/*    */   
/*    */   public AjType<?> getDeclaringType() {
/* 47 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public AjType<?> getTargetType() throws ClassNotFoundException {
/* 51 */     if (this.targetType == null) throw new ClassNotFoundException(this.targetTypeName); 
/* 52 */     return this.targetType;
/*    */   }
/*    */   
/*    */   public int getModifiers() {
/* 56 */     return this.modifiers;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\InterTypeDeclarationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */