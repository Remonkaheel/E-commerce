/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.lang.reflect.Type;
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.AjTypeSystem;
/*    */ import org.aspectj.lang.reflect.InterTypeConstructorDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterTypeConstructorDeclarationImpl
/*    */   extends InterTypeDeclarationImpl
/*    */   implements InterTypeConstructorDeclaration
/*    */ {
/*    */   private Method baseMethod;
/*    */   
/*    */   public InterTypeConstructorDeclarationImpl(AjType<?> decType, String target, int mods, Method baseMethod) {
/* 32 */     super(decType, target, mods);
/* 33 */     this.baseMethod = baseMethod;
/*    */   }
/*    */   
/*    */   public AjType<?>[] getParameterTypes() {
/* 37 */     Class<?>[] baseTypes = this.baseMethod.getParameterTypes();
/* 38 */     AjType[] arrayOfAjType = new AjType[baseTypes.length - 1];
/* 39 */     for (int i = 1; i < baseTypes.length; i++) {
/* 40 */       arrayOfAjType[i - 1] = AjTypeSystem.getAjType(baseTypes[i]);
/*    */     }
/* 42 */     return (AjType<?>[])arrayOfAjType;
/*    */   }
/*    */   
/*    */   public Type[] getGenericParameterTypes() {
/* 46 */     Type[] baseTypes = this.baseMethod.getGenericParameterTypes();
/* 47 */     AjType[] arrayOfAjType = new AjType[baseTypes.length - 1];
/* 48 */     for (int i = 1; i < baseTypes.length; i++) {
/* 49 */       if (baseTypes[i] instanceof Class) {
/* 50 */         arrayOfAjType[i - 1] = AjTypeSystem.getAjType((Class)baseTypes[i]);
/*    */       } else {
/* 52 */         arrayOfAjType[i - 1] = (AjType)baseTypes[i];
/*    */       } 
/*    */     } 
/* 55 */     return (Type[])arrayOfAjType;
/*    */   }
/*    */   
/*    */   public AjType<?>[] getExceptionTypes() {
/* 59 */     Class<?>[] baseTypes = this.baseMethod.getExceptionTypes();
/* 60 */     AjType[] arrayOfAjType = new AjType[baseTypes.length];
/* 61 */     for (int i = 0; i < baseTypes.length; i++) {
/* 62 */       arrayOfAjType[i] = AjTypeSystem.getAjType(baseTypes[i]);
/*    */     }
/* 64 */     return (AjType<?>[])arrayOfAjType;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 68 */     StringBuilder sb = new StringBuilder();
/* 69 */     sb.append(Modifier.toString(getModifiers()));
/* 70 */     sb.append(" ");
/* 71 */     sb.append(this.targetTypeName);
/* 72 */     sb.append(".new");
/* 73 */     sb.append("(");
/* 74 */     AjType[] arrayOfAjType = (AjType[])getParameterTypes();
/* 75 */     for (int i = 0; i < arrayOfAjType.length - 1; i++) {
/* 76 */       sb.append(arrayOfAjType[i].toString());
/* 77 */       sb.append(", ");
/*    */     } 
/* 79 */     if (arrayOfAjType.length > 0) {
/* 80 */       sb.append(arrayOfAjType[arrayOfAjType.length - 1].toString());
/*    */     }
/* 82 */     sb.append(")");
/* 83 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\InterTypeConstructorDeclarationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */