/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.DeclareAnnotation;
/*    */ import org.aspectj.lang.reflect.SignaturePattern;
/*    */ import org.aspectj.lang.reflect.TypePattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclareAnnotationImpl
/*    */   implements DeclareAnnotation
/*    */ {
/*    */   private Annotation theAnnotation;
/*    */   private String annText;
/*    */   private AjType<?> declaringType;
/*    */   private DeclareAnnotation.Kind kind;
/*    */   private TypePattern typePattern;
/*    */   private SignaturePattern signaturePattern;
/*    */   
/*    */   public DeclareAnnotationImpl(AjType<?> declaring, String kindString, String pattern, Annotation ann, String annText) {
/* 35 */     this.declaringType = declaring;
/* 36 */     if (kindString.equals("at_type")) { this.kind = DeclareAnnotation.Kind.Type; }
/* 37 */     else if (kindString.equals("at_field")) { this.kind = DeclareAnnotation.Kind.Field; }
/* 38 */     else if (kindString.equals("at_method")) { this.kind = DeclareAnnotation.Kind.Method; }
/* 39 */     else if (kindString.equals("at_constructor")) { this.kind = DeclareAnnotation.Kind.Constructor; }
/* 40 */     else { throw new IllegalStateException("Unknown declare annotation kind: " + kindString); }
/* 41 */      if (this.kind == DeclareAnnotation.Kind.Type) {
/* 42 */       this.typePattern = new TypePatternImpl(pattern);
/*    */     } else {
/* 44 */       this.signaturePattern = new SignaturePatternImpl(pattern);
/*    */     } 
/* 46 */     this.theAnnotation = ann;
/* 47 */     this.annText = annText;
/*    */   }
/*    */   
/*    */   public AjType<?> getDeclaringType() {
/* 51 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public DeclareAnnotation.Kind getKind() {
/* 55 */     return this.kind;
/*    */   }
/*    */   
/*    */   public SignaturePattern getSignaturePattern() {
/* 59 */     return this.signaturePattern;
/*    */   }
/*    */   
/*    */   public TypePattern getTypePattern() {
/* 63 */     return this.typePattern;
/*    */   }
/*    */   
/*    */   public Annotation getAnnotation() {
/* 67 */     return this.theAnnotation;
/*    */   }
/*    */   
/*    */   public String getAnnotationAsText() {
/* 71 */     return this.annText;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 75 */     StringBuilder sb = new StringBuilder();
/* 76 */     sb.append("declare @");
/* 77 */     switch (getKind()) {
/*    */       case Type:
/* 79 */         sb.append("type : ");
/* 80 */         sb.append(getTypePattern().asString());
/*    */         break;
/*    */       case Method:
/* 83 */         sb.append("method : ");
/* 84 */         sb.append(getSignaturePattern().asString());
/*    */         break;
/*    */       case Field:
/* 87 */         sb.append("field : ");
/* 88 */         sb.append(getSignaturePattern().asString());
/*    */         break;
/*    */       case Constructor:
/* 91 */         sb.append("constructor : ");
/* 92 */         sb.append(getSignaturePattern().asString());
/*    */         break;
/*    */     } 
/* 95 */     sb.append(" : ");
/* 96 */     sb.append(getAnnotationAsText());
/* 97 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\DeclareAnnotationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */