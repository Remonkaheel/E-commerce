/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.lang.reflect.Type;
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.AjTypeSystem;
/*    */ import org.aspectj.lang.reflect.InterTypeFieldDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterTypeFieldDeclarationImpl
/*    */   extends InterTypeDeclarationImpl
/*    */   implements InterTypeFieldDeclaration
/*    */ {
/*    */   private String name;
/*    */   private AjType<?> type;
/*    */   private Type genericType;
/*    */   
/*    */   public InterTypeFieldDeclarationImpl(AjType<?> decType, String target, int mods, String name, AjType<?> type, Type genericType) {
/* 34 */     super(decType, target, mods);
/* 35 */     this.name = name;
/* 36 */     this.type = type;
/* 37 */     this.genericType = genericType;
/*    */   }
/*    */   
/*    */   public InterTypeFieldDeclarationImpl(AjType<?> decType, AjType<?> targetType, Field base) {
/* 41 */     super(decType, targetType, base.getModifiers());
/* 42 */     this.name = base.getName();
/* 43 */     this.type = AjTypeSystem.getAjType(base.getType());
/* 44 */     Type gt = base.getGenericType();
/* 45 */     if (gt instanceof Class) {
/* 46 */       this.genericType = (Type)AjTypeSystem.getAjType((Class)gt);
/*    */     } else {
/* 48 */       this.genericType = gt;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getName() {
/* 53 */     return this.name;
/*    */   }
/*    */   
/*    */   public AjType<?> getType() {
/* 57 */     return this.type;
/*    */   }
/*    */   
/*    */   public Type getGenericType() {
/* 61 */     return this.genericType;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 65 */     StringBuilder sb = new StringBuilder();
/* 66 */     sb.append(Modifier.toString(getModifiers()));
/* 67 */     sb.append(" ");
/* 68 */     sb.append(getType().toString());
/* 69 */     sb.append(" ");
/* 70 */     sb.append(this.targetTypeName);
/* 71 */     sb.append(".");
/* 72 */     sb.append(getName());
/* 73 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\InterTypeFieldDeclarationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */