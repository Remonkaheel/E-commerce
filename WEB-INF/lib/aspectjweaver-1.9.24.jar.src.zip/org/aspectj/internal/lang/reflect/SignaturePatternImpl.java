/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.SignaturePattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignaturePatternImpl
/*    */   implements SignaturePattern
/*    */ {
/*    */   private String sigPattern;
/*    */   
/*    */   public SignaturePatternImpl(String pattern) {
/* 25 */     this.sigPattern = pattern;
/*    */   }
/*    */   
/*    */   public String asString() {
/* 29 */     return this.sigPattern;
/*    */   }
/*    */   public String toString() {
/* 32 */     return asString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\SignaturePatternImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */