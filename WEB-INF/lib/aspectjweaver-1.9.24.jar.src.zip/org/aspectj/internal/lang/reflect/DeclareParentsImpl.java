/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.DeclareParents;
/*    */ import org.aspectj.lang.reflect.TypePattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclareParentsImpl
/*    */   implements DeclareParents
/*    */ {
/*    */   private AjType<?> declaringType;
/*    */   private TypePattern targetTypesPattern;
/*    */   private Type[] parents;
/*    */   private String parentsString;
/*    */   private String firstMissingTypeName;
/*    */   private boolean isExtends;
/*    */   private boolean parentsError = false;
/*    */   
/*    */   public DeclareParentsImpl(String targets, String parentsAsString, boolean isExtends, AjType<?> declaring) {
/* 39 */     this.targetTypesPattern = new TypePatternImpl(targets);
/* 40 */     this.isExtends = isExtends;
/* 41 */     this.declaringType = declaring;
/* 42 */     this.parentsString = parentsAsString;
/*    */     try {
/* 44 */       this.parents = StringToType.commaSeparatedListToTypeArray(parentsAsString, declaring.getJavaClass());
/* 45 */     } catch (ClassNotFoundException cnfEx) {
/* 46 */       this.parentsError = true;
/* 47 */       this.firstMissingTypeName = cnfEx.getMessage();
/*    */     } 
/*    */   }
/*    */   
/*    */   public AjType getDeclaringType() {
/* 52 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public TypePattern getTargetTypesPattern() {
/* 56 */     return this.targetTypesPattern;
/*    */   }
/*    */   
/*    */   public boolean isExtends() {
/* 60 */     return this.isExtends;
/*    */   }
/*    */   
/*    */   public boolean isImplements() {
/* 64 */     return !this.isExtends;
/*    */   }
/*    */   
/*    */   public Type[] getParentTypes() throws ClassNotFoundException {
/* 68 */     if (this.parentsError) {
/* 69 */       throw new ClassNotFoundException(this.firstMissingTypeName);
/*    */     }
/* 71 */     return this.parents;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 75 */     StringBuilder sb = new StringBuilder();
/* 76 */     sb.append("declare parents : ");
/* 77 */     sb.append(getTargetTypesPattern().asString());
/* 78 */     sb.append(isExtends() ? " extends " : " implements ");
/* 79 */     sb.append(this.parentsString);
/* 80 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\DeclareParentsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */