/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.PerClause;
/*    */ import org.aspectj.lang.reflect.PerClauseKind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerClauseImpl
/*    */   implements PerClause
/*    */ {
/*    */   private final PerClauseKind kind;
/*    */   
/*    */   protected PerClauseImpl(PerClauseKind kind) {
/* 26 */     this.kind = kind;
/*    */   }
/*    */   
/*    */   public PerClauseKind getKind() {
/* 30 */     return this.kind;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 34 */     return "issingleton()";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\PerClauseImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */