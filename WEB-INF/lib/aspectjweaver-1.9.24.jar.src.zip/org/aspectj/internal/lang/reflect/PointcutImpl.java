/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.StringTokenizer;
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.AjTypeSystem;
/*    */ import org.aspectj.lang.reflect.Pointcut;
/*    */ import org.aspectj.lang.reflect.PointcutExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointcutImpl
/*    */   implements Pointcut
/*    */ {
/*    */   private final String name;
/*    */   private final PointcutExpression pc;
/*    */   private final Method baseMethod;
/*    */   private final AjType<?> declaringType;
/* 32 */   private String[] parameterNames = new String[0];
/*    */   
/*    */   protected PointcutImpl(String name, String pc, Method method, AjType<?> declaringType, String pNames) {
/* 35 */     this.name = name;
/* 36 */     this.pc = new PointcutExpressionImpl(pc);
/* 37 */     this.baseMethod = method;
/* 38 */     this.declaringType = declaringType;
/* 39 */     this.parameterNames = splitOnComma(pNames);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PointcutExpression getPointcutExpression() {
/* 46 */     return this.pc;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getModifiers() {
/* 54 */     return this.baseMethod.getModifiers();
/*    */   }
/*    */   
/*    */   public AjType<?>[] getParameterTypes() {
/* 58 */     Class<?>[] baseParamTypes = this.baseMethod.getParameterTypes();
/* 59 */     AjType[] arrayOfAjType = new AjType[baseParamTypes.length];
/* 60 */     for (int i = 0; i < arrayOfAjType.length; i++) {
/* 61 */       arrayOfAjType[i] = AjTypeSystem.getAjType(baseParamTypes[i]);
/*    */     }
/* 63 */     return (AjType<?>[])arrayOfAjType;
/*    */   }
/*    */   
/*    */   public AjType getDeclaringType() {
/* 67 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public String[] getParameterNames() {
/* 71 */     return this.parameterNames;
/*    */   }
/*    */   
/*    */   private String[] splitOnComma(String s) {
/* 75 */     StringTokenizer strTok = new StringTokenizer(s, ",");
/* 76 */     String[] ret = new String[strTok.countTokens()];
/* 77 */     for (int i = 0; i < ret.length; i++) {
/* 78 */       ret[i] = strTok.nextToken().trim();
/*    */     }
/* 80 */     return ret;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 84 */     StringBuilder sb = new StringBuilder();
/* 85 */     sb.append(getName());
/* 86 */     sb.append("(");
/* 87 */     AjType[] arrayOfAjType = (AjType[])getParameterTypes();
/* 88 */     for (int i = 0; i < arrayOfAjType.length; i++) {
/* 89 */       sb.append(arrayOfAjType[i].getName());
/* 90 */       if (this.parameterNames != null && this.parameterNames[i] != null) {
/* 91 */         sb.append(" ");
/* 92 */         sb.append(this.parameterNames[i]);
/*    */       } 
/* 94 */       if (i + 1 < arrayOfAjType.length) sb.append(","); 
/*    */     } 
/* 96 */     sb.append(") : ");
/* 97 */     sb.append(getPointcutExpression().asString());
/* 98 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\PointcutImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */