/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.DeclarePrecedence;
/*    */ import org.aspectj.lang.reflect.TypePattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclarePrecedenceImpl
/*    */   implements DeclarePrecedence
/*    */ {
/*    */   private AjType<?> declaringType;
/*    */   private TypePattern[] precedenceList;
/*    */   private String precedenceString;
/*    */   
/*    */   public DeclarePrecedenceImpl(String precedenceList, AjType<?> declaring) {
/* 31 */     this.declaringType = declaring;
/* 32 */     this.precedenceString = precedenceList;
/* 33 */     String toTokenize = precedenceList;
/* 34 */     if (toTokenize.startsWith("(")) {
/* 35 */       toTokenize = toTokenize.substring(1, toTokenize.length() - 1);
/*    */     }
/* 37 */     StringTokenizer strTok = new StringTokenizer(toTokenize, ",");
/* 38 */     this.precedenceList = new TypePattern[strTok.countTokens()];
/* 39 */     for (int i = 0; i < this.precedenceList.length; i++) {
/* 40 */       this.precedenceList[i] = new TypePatternImpl(strTok.nextToken().trim());
/*    */     }
/*    */   }
/*    */   
/*    */   public AjType getDeclaringType() {
/* 45 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public TypePattern[] getPrecedenceOrder() {
/* 49 */     return this.precedenceList;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 53 */     return "declare precedence : " + this.precedenceString;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\DeclarePrecedenceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */