/*     */ package org.aspectj.internal.lang.reflect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.InterTypeMethodDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterTypeMethodDeclarationImpl
/*     */   extends InterTypeDeclarationImpl
/*     */   implements InterTypeMethodDeclaration
/*     */ {
/*     */   private String name;
/*     */   private Method baseMethod;
/*  31 */   private int parameterAdjustmentFactor = 1;
/*     */   
/*     */   private AjType<?>[] parameterTypes;
/*     */   private Type[] genericParameterTypes;
/*     */   private AjType<?> returnType;
/*     */   private Type genericReturnType;
/*     */   private AjType<?>[] exceptionTypes;
/*     */   
/*     */   public InterTypeMethodDeclarationImpl(AjType<?> decType, String target, int mods, String name, Method itdInterMethod) {
/*  40 */     super(decType, target, mods);
/*  41 */     this.name = name;
/*  42 */     this.baseMethod = itdInterMethod;
/*     */   }
/*     */   
/*     */   public InterTypeMethodDeclarationImpl(AjType<?> decType, AjType<?> targetType, Method base, int modifiers) {
/*  46 */     super(decType, targetType, modifiers);
/*  47 */     this.parameterAdjustmentFactor = 0;
/*  48 */     this.name = base.getName();
/*  49 */     this.baseMethod = base;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  53 */     return this.name;
/*     */   }
/*     */   
/*     */   public AjType<?> getReturnType() {
/*  57 */     return AjTypeSystem.getAjType(this.baseMethod.getReturnType());
/*     */   }
/*     */   
/*     */   public Type getGenericReturnType() {
/*  61 */     Type gRet = this.baseMethod.getGenericReturnType();
/*  62 */     if (gRet instanceof Class) {
/*  63 */       return (Type)AjTypeSystem.getAjType((Class)gRet);
/*     */     }
/*  65 */     return gRet;
/*     */   }
/*     */   
/*     */   public AjType<?>[] getParameterTypes() {
/*  69 */     Class<?>[] baseTypes = this.baseMethod.getParameterTypes();
/*  70 */     AjType[] arrayOfAjType = new AjType[baseTypes.length - this.parameterAdjustmentFactor];
/*  71 */     for (int i = this.parameterAdjustmentFactor; i < baseTypes.length; i++) {
/*  72 */       arrayOfAjType[i - this.parameterAdjustmentFactor] = AjTypeSystem.getAjType(baseTypes[i]);
/*     */     }
/*  74 */     return (AjType<?>[])arrayOfAjType;
/*     */   }
/*     */   
/*     */   public Type[] getGenericParameterTypes() {
/*  78 */     Type[] baseTypes = this.baseMethod.getGenericParameterTypes();
/*  79 */     AjType[] arrayOfAjType = new AjType[baseTypes.length - this.parameterAdjustmentFactor];
/*  80 */     for (int i = this.parameterAdjustmentFactor; i < baseTypes.length; i++) {
/*  81 */       if (baseTypes[i] instanceof Class) {
/*  82 */         arrayOfAjType[i - this.parameterAdjustmentFactor] = AjTypeSystem.getAjType((Class)baseTypes[i]);
/*     */       } else {
/*  84 */         arrayOfAjType[i - this.parameterAdjustmentFactor] = (AjType)baseTypes[i];
/*     */       } 
/*     */     } 
/*  87 */     return (Type[])arrayOfAjType;
/*     */   }
/*     */   
/*     */   public TypeVariable<Method>[] getTypeParameters() {
/*  91 */     return this.baseMethod.getTypeParameters();
/*     */   }
/*     */   
/*     */   public AjType<?>[] getExceptionTypes() {
/*  95 */     Class<?>[] baseTypes = this.baseMethod.getExceptionTypes();
/*  96 */     AjType[] arrayOfAjType = new AjType[baseTypes.length];
/*  97 */     for (int i = 0; i < baseTypes.length; i++) {
/*  98 */       arrayOfAjType[i] = AjTypeSystem.getAjType(baseTypes[i]);
/*     */     }
/* 100 */     return (AjType<?>[])arrayOfAjType;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 104 */     StringBuilder sb = new StringBuilder();
/* 105 */     sb.append(Modifier.toString(getModifiers()));
/* 106 */     sb.append(" ");
/* 107 */     sb.append(getReturnType().toString());
/* 108 */     sb.append(" ");
/* 109 */     sb.append(this.targetTypeName);
/* 110 */     sb.append(".");
/* 111 */     sb.append(getName());
/* 112 */     sb.append("(");
/* 113 */     AjType[] arrayOfAjType = (AjType[])getParameterTypes();
/* 114 */     for (int i = 0; i < arrayOfAjType.length - 1; i++) {
/* 115 */       sb.append(arrayOfAjType[i].toString());
/* 116 */       sb.append(", ");
/*     */     } 
/* 118 */     if (arrayOfAjType.length > 0) {
/* 119 */       sb.append(arrayOfAjType[arrayOfAjType.length - 1].toString());
/*     */     }
/* 121 */     sb.append(")");
/* 122 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\InterTypeMethodDeclarationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */