/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.lang.reflect.TypeVariable;
/*    */ import java.util.StringTokenizer;
/*    */ import org.aspectj.lang.reflect.AjTypeSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringToType
/*    */ {
/*    */   public static Type[] commaSeparatedListToTypeArray(String typeNames, Class classScope) throws ClassNotFoundException {
/* 29 */     StringTokenizer strTok = new StringTokenizer(typeNames, ",");
/* 30 */     Type[] ret = new Type[strTok.countTokens()];
/* 31 */     int index = 0;
/*    */     
/* 33 */     while (strTok.hasMoreTokens()) {
/* 34 */       String typeName = strTok.nextToken().trim();
/* 35 */       ret[index++] = stringToType(typeName, classScope);
/*    */     } 
/* 37 */     return ret;
/*    */   }
/*    */ 
/*    */   
/*    */   public static Type stringToType(String typeName, Class<?> classScope) throws ClassNotFoundException {
/*    */     try {
/* 43 */       if (!typeName.contains("<")) {
/* 44 */         return (Type)AjTypeSystem.getAjType(Class.forName(typeName, false, classScope.getClassLoader()));
/*    */       }
/* 46 */       return makeParameterizedType(typeName, classScope);
/*    */     }
/* 48 */     catch (ClassNotFoundException e) {
/*    */       
/* 50 */       TypeVariable[] tVars = (TypeVariable[])classScope.getTypeParameters();
/* 51 */       for (TypeVariable<?> tVar : tVars) {
/* 52 */         if (tVar.getName().equals(typeName)) {
/* 53 */           return tVar;
/*    */         }
/*    */       } 
/* 56 */       throw new ClassNotFoundException(typeName);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private static Type makeParameterizedType(String typeName, Class<?> classScope) throws ClassNotFoundException {
/* 62 */     int paramStart = typeName.indexOf('<');
/* 63 */     String baseName = typeName.substring(0, paramStart);
/* 64 */     final Class<?> baseClass = Class.forName(baseName, false, classScope.getClassLoader());
/* 65 */     int paramEnd = typeName.lastIndexOf('>');
/* 66 */     String params = typeName.substring(paramStart + 1, paramEnd);
/* 67 */     final Type[] typeParams = commaSeparatedListToTypeArray(params, classScope);
/* 68 */     return new ParameterizedType()
/*    */       {
/*    */         public Type[] getActualTypeArguments() {
/* 71 */           return typeParams;
/*    */         }
/*    */         
/*    */         public Type getRawType() {
/* 75 */           return baseClass;
/*    */         }
/*    */         
/*    */         public Type getOwnerType() {
/* 79 */           return baseClass.getEnclosingClass();
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\StringToType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */