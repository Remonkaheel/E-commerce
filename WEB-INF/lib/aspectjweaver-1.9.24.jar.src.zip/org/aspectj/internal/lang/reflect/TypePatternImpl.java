/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.TypePattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypePatternImpl
/*    */   implements TypePattern
/*    */ {
/*    */   private String typePattern;
/*    */   
/*    */   public TypePatternImpl(String pattern) {
/* 25 */     this.typePattern = pattern;
/*    */   }
/*    */   
/*    */   public String asString() {
/* 29 */     return this.typePattern;
/*    */   }
/*    */   public String toString() {
/* 32 */     return asString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\TypePatternImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */