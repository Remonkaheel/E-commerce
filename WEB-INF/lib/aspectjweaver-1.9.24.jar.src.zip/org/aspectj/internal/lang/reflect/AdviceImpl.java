/*     */ package org.aspectj.internal.lang.reflect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import org.aspectj.lang.annotation.AdviceName;
/*     */ import org.aspectj.lang.reflect.Advice;
/*     */ import org.aspectj.lang.reflect.AdviceKind;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PointcutExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdviceImpl
/*     */   implements Advice
/*     */ {
/*     */   private static final String AJC_INTERNAL = "org.aspectj.runtime.internal";
/*     */   private final AdviceKind kind;
/*     */   private final Method adviceMethod;
/*     */   private PointcutExpression pointcutExpression;
/*     */   private boolean hasExtraParam = false;
/*     */   private Type[] genericParameterTypes;
/*     */   private AjType[] parameterTypes;
/*     */   private AjType[] exceptionTypes;
/*     */   
/*     */   protected AdviceImpl(Method method, String pointcut, AdviceKind type) {
/*  41 */     this.kind = type;
/*  42 */     this.adviceMethod = method;
/*  43 */     this.pointcutExpression = new PointcutExpressionImpl(pointcut);
/*     */   }
/*     */   
/*     */   protected AdviceImpl(Method method, String pointcut, AdviceKind type, String extraParamName) {
/*  47 */     this(method, pointcut, type);
/*  48 */     this.hasExtraParam = true;
/*     */   }
/*     */   
/*     */   public AjType getDeclaringType() {
/*  52 */     return AjTypeSystem.getAjType(this.adviceMethod.getDeclaringClass());
/*     */   }
/*     */   
/*     */   public Type[] getGenericParameterTypes() {
/*  56 */     if (this.genericParameterTypes == null) {
/*  57 */       Type[] genTypes = this.adviceMethod.getGenericParameterTypes();
/*  58 */       int syntheticCount = 0;
/*  59 */       for (Type t : genTypes) {
/*  60 */         if (t instanceof Class && (
/*  61 */           (Class)t).getPackage().getName().equals("org.aspectj.runtime.internal")) syntheticCount++;
/*     */       
/*     */       } 
/*  64 */       this.genericParameterTypes = new Type[genTypes.length - syntheticCount];
/*  65 */       for (int i = 0; i < this.genericParameterTypes.length; i++) {
/*  66 */         if (genTypes[i] instanceof Class) {
/*  67 */           this.genericParameterTypes[i] = (Type)AjTypeSystem.getAjType((Class)genTypes[i]);
/*     */         } else {
/*  69 */           this.genericParameterTypes[i] = genTypes[i];
/*     */         } 
/*     */       } 
/*     */     } 
/*  73 */     return this.genericParameterTypes;
/*     */   }
/*     */   
/*     */   public AjType<?>[] getParameterTypes() {
/*  77 */     if (this.parameterTypes == null) {
/*  78 */       Class<?>[] ptypes = this.adviceMethod.getParameterTypes();
/*  79 */       int syntheticCount = 0;
/*  80 */       for (Class<?> c : ptypes) {
/*  81 */         if (c.getPackage().getName().equals("org.aspectj.runtime.internal")) syntheticCount++; 
/*     */       } 
/*  83 */       this.parameterTypes = new AjType[ptypes.length - syntheticCount];
/*  84 */       for (int i = 0; i < this.parameterTypes.length; i++) {
/*  85 */         this.parameterTypes[i] = AjTypeSystem.getAjType(ptypes[i]);
/*     */       }
/*     */     } 
/*  88 */     return (AjType<?>[])this.parameterTypes;
/*     */   }
/*     */   
/*     */   public AjType<?>[] getExceptionTypes() {
/*  92 */     if (this.exceptionTypes == null) {
/*  93 */       Class<?>[] exTypes = this.adviceMethod.getExceptionTypes();
/*  94 */       this.exceptionTypes = new AjType[exTypes.length];
/*  95 */       for (int i = 0; i < exTypes.length; i++) {
/*  96 */         this.exceptionTypes[i] = AjTypeSystem.getAjType(exTypes[i]);
/*     */       }
/*     */     } 
/*  99 */     return (AjType<?>[])this.exceptionTypes;
/*     */   }
/*     */   
/*     */   public AdviceKind getKind() {
/* 103 */     return this.kind;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 107 */     String adviceName = this.adviceMethod.getName();
/* 108 */     if (adviceName.startsWith("ajc$")) {
/* 109 */       adviceName = "";
/* 110 */       AdviceName name = this.adviceMethod.<AdviceName>getAnnotation(AdviceName.class);
/* 111 */       if (name != null) adviceName = name.value(); 
/*     */     } 
/* 113 */     return adviceName;
/*     */   }
/*     */   
/*     */   public PointcutExpression getPointcutExpression() {
/* 117 */     return this.pointcutExpression;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 121 */     StringBuilder sb = new StringBuilder();
/* 122 */     if (getName().length() > 0) {
/* 123 */       sb.append("@AdviceName(\"");
/* 124 */       sb.append(getName());
/* 125 */       sb.append("\") ");
/*     */     } 
/* 127 */     if (getKind() == AdviceKind.AROUND) {
/* 128 */       sb.append(this.adviceMethod.getGenericReturnType().toString());
/* 129 */       sb.append(" ");
/*     */     } 
/* 131 */     switch (getKind()) {
/*     */       case AFTER:
/* 133 */         sb.append("after(");
/*     */         break;
/*     */       case AFTER_RETURNING:
/* 136 */         sb.append("after(");
/*     */         break;
/*     */       case AFTER_THROWING:
/* 139 */         sb.append("after(");
/*     */         break;
/*     */       case AROUND:
/* 142 */         sb.append("around(");
/*     */         break;
/*     */       case BEFORE:
/* 145 */         sb.append("before(");
/*     */         break;
/*     */     } 
/* 148 */     AjType[] arrayOfAjType1 = (AjType[])getParameterTypes();
/* 149 */     int len = arrayOfAjType1.length;
/* 150 */     if (this.hasExtraParam) len--; 
/* 151 */     for (int i = 0; i < len; i++) {
/* 152 */       sb.append(arrayOfAjType1[i].getName());
/* 153 */       if (i + 1 < len) sb.append(","); 
/*     */     } 
/* 155 */     sb.append(") ");
/* 156 */     switch (getKind()) {
/*     */       case AFTER_RETURNING:
/* 158 */         sb.append("returning");
/* 159 */         if (this.hasExtraParam) {
/* 160 */           sb.append("(");
/* 161 */           sb.append(arrayOfAjType1[len - 1].getName());
/* 162 */           sb.append(") ");
/*     */         } 
/*     */       case AFTER_THROWING:
/* 165 */         sb.append("throwing");
/* 166 */         if (this.hasExtraParam) {
/* 167 */           sb.append("(");
/* 168 */           sb.append(arrayOfAjType1[len - 1].getName());
/* 169 */           sb.append(") ");
/*     */         } 
/*     */         break;
/*     */     } 
/* 173 */     AjType[] arrayOfAjType2 = (AjType[])getExceptionTypes();
/* 174 */     if (arrayOfAjType2.length > 0) {
/* 175 */       sb.append("throws ");
/* 176 */       for (int j = 0; j < arrayOfAjType2.length; j++) {
/* 177 */         sb.append(arrayOfAjType2[j].getName());
/* 178 */         if (j + 1 < arrayOfAjType2.length) sb.append(","); 
/*     */       } 
/* 180 */       sb.append(" ");
/*     */     } 
/* 182 */     sb.append(": ");
/* 183 */     sb.append(getPointcutExpression().asString());
/* 184 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\AdviceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */