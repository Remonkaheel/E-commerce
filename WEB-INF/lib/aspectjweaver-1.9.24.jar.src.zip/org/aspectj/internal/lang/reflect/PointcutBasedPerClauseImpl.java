/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.PerClauseKind;
/*    */ import org.aspectj.lang.reflect.PointcutBasedPerClause;
/*    */ import org.aspectj.lang.reflect.PointcutExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointcutBasedPerClauseImpl
/*    */   extends PerClauseImpl
/*    */   implements PointcutBasedPerClause
/*    */ {
/*    */   private final PointcutExpression pointcutExpression;
/*    */   
/*    */   public PointcutBasedPerClauseImpl(PerClauseKind kind, String pointcutExpression) {
/* 29 */     super(kind);
/* 30 */     this.pointcutExpression = new PointcutExpressionImpl(pointcutExpression);
/*    */   }
/*    */   
/*    */   public PointcutExpression getPointcutExpression() {
/* 34 */     return this.pointcutExpression;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 38 */     StringBuilder sb = new StringBuilder();
/* 39 */     switch (getKind()) { case PERCFLOW:
/* 40 */         sb.append("percflow("); break;
/* 41 */       case PERCFLOWBELOW: sb.append("percflowbelow("); break;
/* 42 */       case PERTARGET: sb.append("pertarget("); break;
/* 43 */       case PERTHIS: sb.append("perthis("); break; }
/*    */     
/* 45 */     sb.append(this.pointcutExpression.asString());
/* 46 */     sb.append(")");
/* 47 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\PointcutBasedPerClauseImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */