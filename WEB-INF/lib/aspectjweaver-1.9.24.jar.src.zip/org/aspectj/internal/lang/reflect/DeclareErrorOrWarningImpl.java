/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.DeclareErrorOrWarning;
/*    */ import org.aspectj.lang.reflect.PointcutExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclareErrorOrWarningImpl
/*    */   implements DeclareErrorOrWarning
/*    */ {
/*    */   private PointcutExpression pc;
/*    */   private String msg;
/*    */   private boolean isError;
/*    */   private AjType<?> declaringType;
/*    */   
/*    */   public DeclareErrorOrWarningImpl(String pointcut, String message, boolean isError, AjType<?> decType) {
/* 30 */     this.pc = new PointcutExpressionImpl(pointcut);
/* 31 */     this.msg = message;
/* 32 */     this.isError = isError;
/* 33 */     this.declaringType = decType;
/*    */   }
/*    */   public AjType getDeclaringType() {
/* 36 */     return this.declaringType;
/*    */   }
/*    */   public PointcutExpression getPointcutExpression() {
/* 39 */     return this.pc;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 43 */     return this.msg;
/*    */   }
/*    */   
/*    */   public boolean isError() {
/* 47 */     return this.isError;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     sb.append("declare ");
/* 53 */     sb.append(isError() ? "error : " : "warning : ");
/* 54 */     sb.append(getPointcutExpression().asString());
/* 55 */     sb.append(" : ");
/* 56 */     sb.append("\"");
/* 57 */     sb.append(getMessage());
/* 58 */     sb.append("\"");
/* 59 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\DeclareErrorOrWarningImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */