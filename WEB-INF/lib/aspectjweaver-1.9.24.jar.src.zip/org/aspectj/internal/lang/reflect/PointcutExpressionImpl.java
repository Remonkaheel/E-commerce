/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.PointcutExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointcutExpressionImpl
/*    */   implements PointcutExpression
/*    */ {
/*    */   private String expression;
/*    */   
/*    */   public PointcutExpressionImpl(String aPointcutExpression) {
/* 24 */     this.expression = aPointcutExpression;
/*    */   }
/*    */   
/*    */   public String asString() {
/* 28 */     return this.expression;
/*    */   }
/*    */   public String toString() {
/* 31 */     return asString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\PointcutExpressionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */