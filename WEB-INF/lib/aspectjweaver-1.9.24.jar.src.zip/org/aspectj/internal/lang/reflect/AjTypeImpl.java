/*      */ package org.aspectj.internal.lang.reflect;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import org.aspectj.internal.lang.annotation.ajcDeclareAnnotation;
/*      */ import org.aspectj.internal.lang.annotation.ajcDeclareEoW;
/*      */ import org.aspectj.internal.lang.annotation.ajcDeclareParents;
/*      */ import org.aspectj.internal.lang.annotation.ajcDeclarePrecedence;
/*      */ import org.aspectj.internal.lang.annotation.ajcDeclareSoft;
/*      */ import org.aspectj.internal.lang.annotation.ajcITD;
/*      */ import org.aspectj.internal.lang.annotation.ajcPrivileged;
/*      */ import org.aspectj.lang.annotation.After;
/*      */ import org.aspectj.lang.annotation.AfterReturning;
/*      */ import org.aspectj.lang.annotation.AfterThrowing;
/*      */ import org.aspectj.lang.annotation.Around;
/*      */ import org.aspectj.lang.annotation.Aspect;
/*      */ import org.aspectj.lang.annotation.Before;
/*      */ import org.aspectj.lang.annotation.DeclareError;
/*      */ import org.aspectj.lang.annotation.DeclareParents;
/*      */ import org.aspectj.lang.annotation.DeclarePrecedence;
/*      */ import org.aspectj.lang.annotation.DeclareWarning;
/*      */ import org.aspectj.lang.annotation.Pointcut;
/*      */ import org.aspectj.lang.reflect.Advice;
/*      */ import org.aspectj.lang.reflect.AdviceKind;
/*      */ import org.aspectj.lang.reflect.AjType;
/*      */ import org.aspectj.lang.reflect.AjTypeSystem;
/*      */ import org.aspectj.lang.reflect.DeclareAnnotation;
/*      */ import org.aspectj.lang.reflect.DeclareErrorOrWarning;
/*      */ import org.aspectj.lang.reflect.DeclareParents;
/*      */ import org.aspectj.lang.reflect.DeclarePrecedence;
/*      */ import org.aspectj.lang.reflect.DeclareSoft;
/*      */ import org.aspectj.lang.reflect.InterTypeConstructorDeclaration;
/*      */ import org.aspectj.lang.reflect.InterTypeFieldDeclaration;
/*      */ import org.aspectj.lang.reflect.InterTypeMethodDeclaration;
/*      */ import org.aspectj.lang.reflect.NoSuchAdviceException;
/*      */ import org.aspectj.lang.reflect.NoSuchPointcutException;
/*      */ import org.aspectj.lang.reflect.PerClause;
/*      */ import org.aspectj.lang.reflect.PerClauseKind;
/*      */ import org.aspectj.lang.reflect.Pointcut;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AjTypeImpl<T>
/*      */   implements AjType<T>
/*      */ {
/*      */   private static final String ajcMagic = "ajc$";
/*      */   private Class<T> clazz;
/*   70 */   private Pointcut[] declaredPointcuts = null;
/*   71 */   private Pointcut[] pointcuts = null;
/*   72 */   private Advice[] declaredAdvice = null;
/*   73 */   private Advice[] advice = null;
/*   74 */   private InterTypeMethodDeclaration[] declaredITDMethods = null;
/*   75 */   private InterTypeMethodDeclaration[] itdMethods = null;
/*   76 */   private InterTypeFieldDeclaration[] declaredITDFields = null;
/*   77 */   private InterTypeFieldDeclaration[] itdFields = null;
/*   78 */   private InterTypeConstructorDeclaration[] itdCons = null;
/*   79 */   private InterTypeConstructorDeclaration[] declaredITDCons = null;
/*      */   
/*      */   public AjTypeImpl(Class<T> fromClass) {
/*   82 */     this.clazz = fromClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*   89 */     return this.clazz.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Package getPackage() {
/*   96 */     return this.clazz.getPackage();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AjType<?>[] getInterfaces() {
/*  103 */     Class<?>[] baseInterfaces = this.clazz.getInterfaces();
/*  104 */     return toAjTypeArray(baseInterfaces);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getModifiers() {
/*  111 */     return this.clazz.getModifiers();
/*      */   }
/*      */   
/*      */   public Class<T> getJavaClass() {
/*  115 */     return this.clazz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AjType<? super T> getSupertype() {
/*  122 */     Class<? super T> superclass = this.clazz.getSuperclass();
/*  123 */     return (superclass == null) ? null : new AjTypeImpl((Class)superclass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getGenericSupertype() {
/*  130 */     return this.clazz.getGenericSuperclass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method getEnclosingMethod() {
/*  137 */     return this.clazz.getEnclosingMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Constructor getEnclosingConstructor() {
/*  144 */     return this.clazz.getEnclosingConstructor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AjType<?> getEnclosingType() {
/*  151 */     Class<?> enc = this.clazz.getEnclosingClass();
/*  152 */     return (enc != null) ? new AjTypeImpl((Class)enc) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AjType<?> getDeclaringType() {
/*  159 */     Class<?> dec = this.clazz.getDeclaringClass();
/*  160 */     return (dec != null) ? new AjTypeImpl((Class)dec) : null;
/*      */   }
/*      */   
/*      */   public PerClause getPerClause() {
/*  164 */     if (isAspect()) {
/*  165 */       Aspect aspectAnn = this.clazz.<Aspect>getAnnotation(Aspect.class);
/*  166 */       String perClause = aspectAnn.value();
/*  167 */       if (perClause.equals("")) {
/*  168 */         if (getSupertype().isAspect()) {
/*  169 */           return getSupertype().getPerClause();
/*      */         }
/*  171 */         return new PerClauseImpl(PerClauseKind.SINGLETON);
/*  172 */       }  if (perClause.startsWith("perthis("))
/*  173 */         return new PointcutBasedPerClauseImpl(PerClauseKind.PERTHIS, perClause.substring("perthis(".length(), perClause.length() - 1)); 
/*  174 */       if (perClause.startsWith("pertarget("))
/*  175 */         return new PointcutBasedPerClauseImpl(PerClauseKind.PERTARGET, perClause.substring("pertarget(".length(), perClause.length() - 1)); 
/*  176 */       if (perClause.startsWith("percflow("))
/*  177 */         return new PointcutBasedPerClauseImpl(PerClauseKind.PERCFLOW, perClause.substring("percflow(".length(), perClause.length() - 1)); 
/*  178 */       if (perClause.startsWith("percflowbelow("))
/*  179 */         return new PointcutBasedPerClauseImpl(PerClauseKind.PERCFLOWBELOW, perClause.substring("percflowbelow(".length(), perClause.length() - 1)); 
/*  180 */       if (perClause.startsWith("pertypewithin")) {
/*  181 */         return new TypePatternBasedPerClauseImpl(PerClauseKind.PERTYPEWITHIN, perClause.substring("pertypewithin(".length(), perClause.length() - 1));
/*      */       }
/*  183 */       throw new IllegalStateException("Per-clause not recognized: " + perClause);
/*      */     } 
/*      */     
/*  186 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/*  194 */     return this.clazz.isAnnotationPresent(annotationType);
/*      */   }
/*      */   
/*      */   public <A extends Annotation> A getAnnotation(Class<A> annotationType) {
/*  198 */     return this.clazz.getAnnotation(annotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Annotation[] getAnnotations() {
/*  205 */     return this.clazz.getAnnotations();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Annotation[] getDeclaredAnnotations() {
/*  212 */     return this.clazz.getDeclaredAnnotations();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AjType<?>[] getAjTypes() {
/*  219 */     Class[] classes = this.clazz.getClasses();
/*  220 */     return toAjTypeArray(classes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AjType<?>[] getDeclaredAjTypes() {
/*  227 */     Class[] classes = this.clazz.getDeclaredClasses();
/*  228 */     return toAjTypeArray(classes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Constructor getConstructor(AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  235 */     return this.clazz.getConstructor(toClassArray(parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Constructor[] getConstructors() {
/*  242 */     return (Constructor[])this.clazz.getConstructors();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Constructor getDeclaredConstructor(AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  249 */     return this.clazz.getDeclaredConstructor(toClassArray(parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Constructor[] getDeclaredConstructors() {
/*  256 */     return (Constructor[])this.clazz.getDeclaredConstructors();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Field getDeclaredField(String name) throws NoSuchFieldException {
/*  263 */     Field f = this.clazz.getDeclaredField(name);
/*  264 */     if (f.getName().startsWith("ajc$")) throw new NoSuchFieldException(name); 
/*  265 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Field[] getDeclaredFields() {
/*  272 */     Field[] fields = this.clazz.getDeclaredFields();
/*  273 */     List<Field> filteredFields = new ArrayList<>();
/*  274 */     for (Field field : fields) {
/*  275 */       if (!field.getName().startsWith("ajc$") && 
/*  276 */         !field.isAnnotationPresent((Class)DeclareWarning.class) && 
/*  277 */         !field.isAnnotationPresent((Class)DeclareError.class))
/*  278 */         filteredFields.add(field); 
/*      */     } 
/*  280 */     Field[] ret = new Field[filteredFields.size()];
/*  281 */     filteredFields.toArray(ret);
/*  282 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Field getField(String name) throws NoSuchFieldException {
/*  289 */     Field f = this.clazz.getField(name);
/*  290 */     if (f.getName().startsWith("ajc$")) throw new NoSuchFieldException(name); 
/*  291 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Field[] getFields() {
/*  298 */     Field[] fields = this.clazz.getFields();
/*  299 */     List<Field> filteredFields = new ArrayList<>();
/*  300 */     for (Field field : fields) {
/*  301 */       if (!field.getName().startsWith("ajc$") && 
/*  302 */         !field.isAnnotationPresent((Class)DeclareWarning.class) && 
/*  303 */         !field.isAnnotationPresent((Class)DeclareError.class))
/*  304 */         filteredFields.add(field); 
/*      */     } 
/*  306 */     Field[] ret = new Field[filteredFields.size()];
/*  307 */     filteredFields.toArray(ret);
/*  308 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method getDeclaredMethod(String name, AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  315 */     Method m = this.clazz.getDeclaredMethod(name, toClassArray(parameterTypes));
/*  316 */     if (!isReallyAMethod(m)) throw new NoSuchMethodException(name); 
/*  317 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method getMethod(String name, AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  324 */     Method m = this.clazz.getMethod(name, toClassArray(parameterTypes));
/*  325 */     if (!isReallyAMethod(m)) throw new NoSuchMethodException(name); 
/*  326 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method[] getDeclaredMethods() {
/*  333 */     Method[] methods = this.clazz.getDeclaredMethods();
/*  334 */     List<Method> filteredMethods = new ArrayList<>();
/*  335 */     for (Method method : methods) {
/*  336 */       if (isReallyAMethod(method)) filteredMethods.add(method); 
/*      */     } 
/*  338 */     Method[] ret = new Method[filteredMethods.size()];
/*  339 */     filteredMethods.toArray(ret);
/*  340 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method[] getMethods() {
/*  347 */     Method[] methods = this.clazz.getMethods();
/*  348 */     List<Method> filteredMethods = new ArrayList<>();
/*  349 */     for (Method method : methods) {
/*  350 */       if (isReallyAMethod(method)) filteredMethods.add(method); 
/*      */     } 
/*  352 */     Method[] ret = new Method[filteredMethods.size()];
/*  353 */     filteredMethods.toArray(ret);
/*  354 */     return ret;
/*      */   }
/*      */   
/*      */   private boolean isReallyAMethod(Method method) {
/*  358 */     if (method.getName().startsWith("ajc$")) return false; 
/*  359 */     if ((method.getAnnotations()).length == 0) return true; 
/*  360 */     if (method.isAnnotationPresent((Class)Pointcut.class)) return false; 
/*  361 */     if (method.isAnnotationPresent((Class)Before.class)) return false; 
/*  362 */     if (method.isAnnotationPresent((Class)After.class)) return false; 
/*  363 */     if (method.isAnnotationPresent((Class)AfterReturning.class)) return false; 
/*  364 */     if (method.isAnnotationPresent((Class)AfterThrowing.class)) return false; 
/*  365 */     if (method.isAnnotationPresent((Class)Around.class)) return false; 
/*  366 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointcut getDeclaredPointcut(String name) throws NoSuchPointcutException {
/*  373 */     Pointcut[] pcs = getDeclaredPointcuts();
/*  374 */     for (Pointcut pc : pcs) {
/*  375 */       if (pc.getName().equals(name)) return pc; 
/*  376 */     }  throw new NoSuchPointcutException(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointcut getPointcut(String name) throws NoSuchPointcutException {
/*  383 */     Pointcut[] pcs = getPointcuts();
/*  384 */     for (Pointcut pc : pcs) {
/*  385 */       if (pc.getName().equals(name)) return pc; 
/*  386 */     }  throw new NoSuchPointcutException(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointcut[] getDeclaredPointcuts() {
/*  393 */     if (this.declaredPointcuts != null) return this.declaredPointcuts; 
/*  394 */     List<Pointcut> pointcuts = new ArrayList<>();
/*  395 */     Method[] methods = this.clazz.getDeclaredMethods();
/*  396 */     for (Method method : methods) {
/*  397 */       Pointcut pc = asPointcut(method);
/*  398 */       if (pc != null) pointcuts.add(pc); 
/*      */     } 
/*  400 */     Pointcut[] ret = new Pointcut[pointcuts.size()];
/*  401 */     pointcuts.toArray(ret);
/*  402 */     this.declaredPointcuts = ret;
/*  403 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointcut[] getPointcuts() {
/*  410 */     if (this.pointcuts != null) return this.pointcuts; 
/*  411 */     List<Pointcut> pcuts = new ArrayList<>();
/*  412 */     Method[] methods = this.clazz.getMethods();
/*  413 */     for (Method method : methods) {
/*  414 */       Pointcut pc = asPointcut(method);
/*  415 */       if (pc != null) pcuts.add(pc); 
/*      */     } 
/*  417 */     Pointcut[] ret = new Pointcut[pcuts.size()];
/*  418 */     pcuts.toArray(ret);
/*  419 */     this.pointcuts = ret;
/*  420 */     return ret;
/*      */   }
/*      */   
/*      */   private Pointcut asPointcut(Method method) {
/*  424 */     Pointcut pcAnn = method.<Pointcut>getAnnotation(Pointcut.class);
/*  425 */     if (pcAnn != null) {
/*  426 */       String name = method.getName();
/*  427 */       if (name.startsWith("ajc$")) {
/*      */         
/*  429 */         int nameStart = name.indexOf("$$");
/*  430 */         name = name.substring(nameStart + 2, name.length());
/*  431 */         int nextDollar = name.indexOf("$");
/*  432 */         if (nextDollar != -1) name = name.substring(0, nextDollar); 
/*      */       } 
/*  434 */       return new PointcutImpl(name, pcAnn.value(), method, AjTypeSystem.getAjType(method.getDeclaringClass()), pcAnn.argNames());
/*      */     } 
/*  436 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Advice[] getDeclaredAdvice(AdviceKind... ofType) {
/*      */     Set<AdviceKind> types;
/*  443 */     if (ofType.length == 0) {
/*  444 */       types = EnumSet.allOf(AdviceKind.class);
/*      */     } else {
/*  446 */       types = EnumSet.noneOf(AdviceKind.class);
/*  447 */       types.addAll(Arrays.asList(ofType));
/*      */     } 
/*  449 */     return getDeclaredAdvice(types);
/*      */   }
/*      */   
/*      */   public Advice[] getAdvice(AdviceKind... ofType) {
/*      */     Set<AdviceKind> types;
/*  454 */     if (ofType.length == 0) {
/*  455 */       types = EnumSet.allOf(AdviceKind.class);
/*      */     } else {
/*  457 */       types = EnumSet.noneOf(AdviceKind.class);
/*  458 */       types.addAll(Arrays.asList(ofType));
/*      */     } 
/*  460 */     return getAdvice(types);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Advice[] getDeclaredAdvice(Set<AdviceKind> ofAdviceTypes) {
/*  467 */     if (this.declaredAdvice == null) initDeclaredAdvice(); 
/*  468 */     List<Advice> adviceList = new ArrayList<>();
/*  469 */     for (Advice a : this.declaredAdvice) {
/*  470 */       if (ofAdviceTypes.contains(a.getKind())) adviceList.add(a); 
/*      */     } 
/*  472 */     Advice[] ret = new Advice[adviceList.size()];
/*  473 */     adviceList.toArray(ret);
/*  474 */     return ret;
/*      */   }
/*      */   
/*      */   private void initDeclaredAdvice() {
/*  478 */     Method[] methods = this.clazz.getDeclaredMethods();
/*  479 */     List<Advice> adviceList = new ArrayList<>();
/*  480 */     for (Method method : methods) {
/*  481 */       Advice advice = asAdvice(method);
/*  482 */       if (advice != null) adviceList.add(advice); 
/*      */     } 
/*  484 */     this.declaredAdvice = new Advice[adviceList.size()];
/*  485 */     adviceList.toArray(this.declaredAdvice);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Advice[] getAdvice(Set<AdviceKind> ofAdviceTypes) {
/*  492 */     if (this.advice == null) initAdvice(); 
/*  493 */     List<Advice> adviceList = new ArrayList<>();
/*  494 */     for (Advice a : this.advice) {
/*  495 */       if (ofAdviceTypes.contains(a.getKind())) adviceList.add(a); 
/*      */     } 
/*  497 */     Advice[] ret = new Advice[adviceList.size()];
/*  498 */     adviceList.toArray(ret);
/*  499 */     return ret;
/*      */   }
/*      */   
/*      */   private void initAdvice() {
/*  503 */     Method[] methods = this.clazz.getMethods();
/*  504 */     List<Advice> adviceList = new ArrayList<>();
/*  505 */     for (Method method : methods) {
/*  506 */       Advice advice = asAdvice(method);
/*  507 */       if (advice != null) adviceList.add(advice); 
/*      */     } 
/*  509 */     this.advice = new Advice[adviceList.size()];
/*  510 */     adviceList.toArray(this.advice);
/*      */   }
/*      */ 
/*      */   
/*      */   public Advice getAdvice(String name) throws NoSuchAdviceException {
/*  515 */     if (name.equals("")) throw new IllegalArgumentException("use getAdvice(AdviceType...) instead for un-named advice"); 
/*  516 */     if (this.advice == null) initAdvice(); 
/*  517 */     for (Advice a : this.advice) {
/*  518 */       if (a.getName().equals(name)) return a; 
/*      */     } 
/*  520 */     throw new NoSuchAdviceException(name);
/*      */   }
/*      */   
/*      */   public Advice getDeclaredAdvice(String name) throws NoSuchAdviceException {
/*  524 */     if (name.equals("")) throw new IllegalArgumentException("use getAdvice(AdviceType...) instead for un-named advice"); 
/*  525 */     if (this.declaredAdvice == null) initDeclaredAdvice(); 
/*  526 */     for (Advice a : this.declaredAdvice) {
/*  527 */       if (a.getName().equals(name)) return a; 
/*      */     } 
/*  529 */     throw new NoSuchAdviceException(name);
/*      */   }
/*      */   
/*      */   private Advice asAdvice(Method method) {
/*  533 */     if ((method.getAnnotations()).length == 0) return null; 
/*  534 */     Before beforeAnn = method.<Before>getAnnotation(Before.class);
/*  535 */     if (beforeAnn != null) return new AdviceImpl(method, beforeAnn.value(), AdviceKind.BEFORE); 
/*  536 */     After afterAnn = method.<After>getAnnotation(After.class);
/*  537 */     if (afterAnn != null) return new AdviceImpl(method, afterAnn.value(), AdviceKind.AFTER); 
/*  538 */     AfterReturning afterReturningAnn = method.<AfterReturning>getAnnotation(AfterReturning.class);
/*  539 */     if (afterReturningAnn != null) {
/*  540 */       String pcExpr = afterReturningAnn.pointcut();
/*  541 */       if (pcExpr.equals("")) pcExpr = afterReturningAnn.value(); 
/*  542 */       return new AdviceImpl(method, pcExpr, AdviceKind.AFTER_RETURNING, afterReturningAnn.returning());
/*      */     } 
/*  544 */     AfterThrowing afterThrowingAnn = method.<AfterThrowing>getAnnotation(AfterThrowing.class);
/*  545 */     if (afterThrowingAnn != null) {
/*  546 */       String pcExpr = afterThrowingAnn.pointcut();
/*  547 */       if (pcExpr == null) pcExpr = afterThrowingAnn.value(); 
/*  548 */       return new AdviceImpl(method, pcExpr, AdviceKind.AFTER_THROWING, afterThrowingAnn.throwing());
/*      */     } 
/*  550 */     Around aroundAnn = method.<Around>getAnnotation(Around.class);
/*  551 */     if (aroundAnn != null) return new AdviceImpl(method, aroundAnn.value(), AdviceKind.AROUND); 
/*  552 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InterTypeMethodDeclaration getDeclaredITDMethod(String name, AjType<?> target, AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  560 */     InterTypeMethodDeclaration[] itdms = getDeclaredITDMethods();
/*  561 */     for (InterTypeMethodDeclaration itdm : itdms) {
/*      */       try {
/*  563 */         if (itdm.getName().equals(name)) {
/*  564 */           AjType<?> itdTarget = itdm.getTargetType();
/*  565 */           if (itdTarget.equals(target)) {
/*  566 */             AjType[] arrayOfAjType = itdm.getParameterTypes();
/*  567 */             if (arrayOfAjType.length == parameterTypes.length)
/*  568 */             { int i = 0; while (true) { if (i < arrayOfAjType.length) {
/*  569 */                   if (!arrayOfAjType[i].equals(parameterTypes[i]))
/*      */                     break;  i++; continue;
/*      */                 } 
/*  572 */                 return itdm; }  } 
/*      */           } 
/*      */         } 
/*  575 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */ 
/*      */     
/*  579 */     throw new NoSuchMethodException(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InterTypeMethodDeclaration[] getDeclaredITDMethods() {
/*  586 */     if (this.declaredITDMethods == null) {
/*  587 */       List<InterTypeMethodDeclaration> itdms = new ArrayList<>();
/*  588 */       Method[] baseMethods = this.clazz.getDeclaredMethods();
/*  589 */       for (Method m : baseMethods) {
/*  590 */         if (m.getName().contains("ajc$interMethodDispatch1$") && 
/*  591 */           m.isAnnotationPresent((Class)ajcITD.class)) {
/*  592 */           ajcITD ann = m.<ajcITD>getAnnotation(ajcITD.class);
/*      */ 
/*      */ 
/*      */           
/*  596 */           InterTypeMethodDeclaration itdm = new InterTypeMethodDeclarationImpl(this, ann.targetType(), ann.modifiers(), ann.name(), m);
/*  597 */           itdms.add(itdm);
/*      */         } 
/*      */       } 
/*  600 */       addAnnotationStyleITDMethods(itdms, false);
/*  601 */       this.declaredITDMethods = new InterTypeMethodDeclaration[itdms.size()];
/*  602 */       itdms.toArray(this.declaredITDMethods);
/*      */     } 
/*  604 */     return this.declaredITDMethods;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InterTypeMethodDeclaration getITDMethod(String name, AjType<?> target, AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  610 */     InterTypeMethodDeclaration[] itdms = getITDMethods();
/*  611 */     for (InterTypeMethodDeclaration itdm : itdms) {
/*      */       try {
/*  613 */         if (itdm.getName().equals(name)) {
/*  614 */           AjType<?> itdTarget = itdm.getTargetType();
/*  615 */           if (itdTarget.equals(target)) {
/*  616 */             AjType[] arrayOfAjType = itdm.getParameterTypes();
/*  617 */             if (arrayOfAjType.length == parameterTypes.length)
/*  618 */             { int i = 0; while (true) { if (i < arrayOfAjType.length) {
/*  619 */                   if (!arrayOfAjType[i].equals(parameterTypes[i]))
/*      */                     break;  i++; continue;
/*      */                 } 
/*  622 */                 return itdm; }  } 
/*      */           } 
/*      */         } 
/*  625 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */ 
/*      */     
/*  629 */     throw new NoSuchMethodException(name);
/*      */   }
/*      */   
/*      */   public InterTypeMethodDeclaration[] getITDMethods() {
/*  633 */     if (this.itdMethods == null) {
/*  634 */       List<InterTypeMethodDeclaration> itdms = new ArrayList<>();
/*  635 */       Method[] baseMethods = this.clazz.getDeclaredMethods();
/*  636 */       for (Method m : baseMethods) {
/*  637 */         if (m.getName().contains("ajc$interMethod$") && 
/*  638 */           m.isAnnotationPresent((Class)ajcITD.class)) {
/*  639 */           ajcITD ann = m.<ajcITD>getAnnotation(ajcITD.class);
/*  640 */           if (Modifier.isPublic(ann.modifiers())) {
/*      */ 
/*      */ 
/*      */             
/*  644 */             InterTypeMethodDeclaration itdm = new InterTypeMethodDeclarationImpl(this, ann.targetType(), ann.modifiers(), ann.name(), m);
/*  645 */             itdms.add(itdm);
/*      */           } 
/*      */         } 
/*  648 */       }  addAnnotationStyleITDMethods(itdms, true);
/*  649 */       this.itdMethods = new InterTypeMethodDeclaration[itdms.size()];
/*  650 */       itdms.toArray(this.itdMethods);
/*      */     } 
/*  652 */     return this.itdMethods;
/*      */   }
/*      */   
/*      */   private void addAnnotationStyleITDMethods(List<InterTypeMethodDeclaration> toList, boolean publicOnly) {
/*  656 */     if (isAspect()) {
/*  657 */       for (Field f : this.clazz.getDeclaredFields()) {
/*  658 */         if (f.getType().isInterface() && 
/*  659 */           f.isAnnotationPresent((Class)DeclareParents.class)) {
/*  660 */           Class<DeclareParents> decPAnnClass = DeclareParents.class;
/*  661 */           DeclareParents decPAnn = f.<DeclareParents>getAnnotation(decPAnnClass);
/*  662 */           if (decPAnn.defaultImpl() != decPAnnClass) {
/*  663 */             for (Method itdM : f.getType().getDeclaredMethods()) {
/*  664 */               if (Modifier.isPublic(itdM.getModifiers()) || !publicOnly) {
/*      */                 
/*  666 */                 InterTypeMethodDeclaration itdm = new InterTypeMethodDeclarationImpl(this, AjTypeSystem.getAjType(f.getType()), itdM, 1);
/*      */ 
/*      */                 
/*  669 */                 toList.add(itdm);
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addAnnotationStyleITDFields(List<InterTypeFieldDeclaration> toList, boolean publicOnly) {}
/*      */ 
/*      */   
/*      */   public InterTypeConstructorDeclaration getDeclaredITDConstructor(AjType<?> target, AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  684 */     InterTypeConstructorDeclaration[] itdcs = getDeclaredITDConstructors();
/*  685 */     for (InterTypeConstructorDeclaration itdc : itdcs) {
/*      */       try {
/*  687 */         AjType<?> itdTarget = itdc.getTargetType();
/*  688 */         if (itdTarget.equals(target)) {
/*  689 */           AjType[] arrayOfAjType = itdc.getParameterTypes();
/*  690 */           if (arrayOfAjType.length == parameterTypes.length) {
/*  691 */             int i = 0; while (true) { if (i < arrayOfAjType.length) {
/*  692 */                 if (!arrayOfAjType[i].equals(parameterTypes[i]))
/*      */                   break;  i++; continue;
/*      */               } 
/*  695 */               return itdc; } 
/*      */           } 
/*      */         } 
/*  698 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */ 
/*      */     
/*  702 */     throw new NoSuchMethodException();
/*      */   }
/*      */   
/*      */   public InterTypeConstructorDeclaration[] getDeclaredITDConstructors() {
/*  706 */     if (this.declaredITDCons == null) {
/*  707 */       List<InterTypeConstructorDeclaration> itdcs = new ArrayList<>();
/*  708 */       Method[] baseMethods = this.clazz.getDeclaredMethods();
/*  709 */       for (Method m : baseMethods) {
/*  710 */         if (m.getName().contains("ajc$postInterConstructor") && 
/*  711 */           m.isAnnotationPresent((Class)ajcITD.class)) {
/*  712 */           ajcITD ann = m.<ajcITD>getAnnotation(ajcITD.class);
/*      */           
/*  714 */           InterTypeConstructorDeclaration itdc = new InterTypeConstructorDeclarationImpl(this, ann.targetType(), ann.modifiers(), m);
/*  715 */           itdcs.add(itdc);
/*      */         } 
/*      */       } 
/*  718 */       this.declaredITDCons = new InterTypeConstructorDeclaration[itdcs.size()];
/*  719 */       itdcs.toArray(this.declaredITDCons);
/*      */     } 
/*  721 */     return this.declaredITDCons;
/*      */   }
/*      */ 
/*      */   
/*      */   public InterTypeConstructorDeclaration getITDConstructor(AjType<?> target, AjType<?>... parameterTypes) throws NoSuchMethodException {
/*  726 */     InterTypeConstructorDeclaration[] itdcs = getITDConstructors();
/*  727 */     for (InterTypeConstructorDeclaration itdc : itdcs) {
/*      */       try {
/*  729 */         AjType<?> itdTarget = itdc.getTargetType();
/*  730 */         if (itdTarget.equals(target)) {
/*  731 */           AjType[] arrayOfAjType = itdc.getParameterTypes();
/*  732 */           if (arrayOfAjType.length == parameterTypes.length) {
/*  733 */             int i = 0; while (true) { if (i < arrayOfAjType.length) {
/*  734 */                 if (!arrayOfAjType[i].equals(parameterTypes[i]))
/*      */                   break;  i++; continue;
/*      */               } 
/*  737 */               return itdc; } 
/*      */           } 
/*      */         } 
/*  740 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */ 
/*      */     
/*  744 */     throw new NoSuchMethodException();
/*      */   }
/*      */   
/*      */   public InterTypeConstructorDeclaration[] getITDConstructors() {
/*  748 */     if (this.itdCons == null) {
/*  749 */       List<InterTypeConstructorDeclaration> itdcs = new ArrayList<>();
/*  750 */       Method[] baseMethods = this.clazz.getMethods();
/*  751 */       for (Method m : baseMethods) {
/*  752 */         if (m.getName().contains("ajc$postInterConstructor") && 
/*  753 */           m.isAnnotationPresent((Class)ajcITD.class)) {
/*  754 */           ajcITD ann = m.<ajcITD>getAnnotation(ajcITD.class);
/*  755 */           if (Modifier.isPublic(ann.modifiers())) {
/*      */             
/*  757 */             InterTypeConstructorDeclaration itdc = new InterTypeConstructorDeclarationImpl(this, ann.targetType(), ann.modifiers(), m);
/*  758 */             itdcs.add(itdc);
/*      */           } 
/*      */         } 
/*  761 */       }  this.itdCons = new InterTypeConstructorDeclaration[itdcs.size()];
/*  762 */       itdcs.toArray(this.itdCons);
/*      */     } 
/*  764 */     return this.itdCons;
/*      */   }
/*      */   
/*      */   public InterTypeFieldDeclaration getDeclaredITDField(String name, AjType<?> target) throws NoSuchFieldException {
/*  768 */     InterTypeFieldDeclaration[] itdfs = getDeclaredITDFields();
/*  769 */     for (InterTypeFieldDeclaration itdf : itdfs) {
/*  770 */       if (itdf.getName().equals(name)) {
/*      */         try {
/*  772 */           AjType<?> itdTarget = itdf.getTargetType();
/*  773 */           if (itdTarget.equals(target)) return itdf; 
/*  774 */         } catch (ClassNotFoundException classNotFoundException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  779 */     throw new NoSuchFieldException(name);
/*      */   }
/*      */   
/*      */   public InterTypeFieldDeclaration[] getDeclaredITDFields() {
/*  783 */     List<InterTypeFieldDeclaration> itdfs = new ArrayList<>();
/*  784 */     if (this.declaredITDFields == null) {
/*  785 */       Method[] baseMethods = this.clazz.getDeclaredMethods();
/*  786 */       for (Method m : baseMethods) {
/*  787 */         if (m.isAnnotationPresent((Class)ajcITD.class) && 
/*  788 */           m.getName().contains("ajc$interFieldInit")) {
/*  789 */           ajcITD ann = m.<ajcITD>getAnnotation(ajcITD.class);
/*  790 */           String interFieldInitMethodName = m.getName();
/*      */           
/*  792 */           String interFieldGetDispatchMethodName = interFieldInitMethodName.replace("FieldInit", "FieldGetDispatch");
/*      */           try {
/*  794 */             Method dispatch = this.clazz.getDeclaredMethod(interFieldGetDispatchMethodName, m.getParameterTypes());
/*      */ 
/*      */ 
/*      */             
/*  798 */             InterTypeFieldDeclaration itdf = new InterTypeFieldDeclarationImpl(this, ann.targetType(), ann.modifiers(), ann.name(), AjTypeSystem.getAjType(dispatch.getReturnType()), dispatch.getGenericReturnType());
/*  799 */             itdfs.add(itdf);
/*  800 */           } catch (NoSuchMethodException nsmEx) {
/*  801 */             throw new IllegalStateException("Can't find field get dispatch method for " + m.getName());
/*      */           } 
/*      */         } 
/*      */       } 
/*  805 */       addAnnotationStyleITDFields(itdfs, false);
/*  806 */       this.declaredITDFields = new InterTypeFieldDeclaration[itdfs.size()];
/*  807 */       itdfs.toArray(this.declaredITDFields);
/*      */     } 
/*  809 */     return this.declaredITDFields;
/*      */   }
/*      */ 
/*      */   
/*      */   public InterTypeFieldDeclaration getITDField(String name, AjType<?> target) throws NoSuchFieldException {
/*  814 */     InterTypeFieldDeclaration[] itdfs = getITDFields();
/*  815 */     for (InterTypeFieldDeclaration itdf : itdfs) {
/*  816 */       if (itdf.getName().equals(name)) {
/*      */         try {
/*  818 */           AjType<?> itdTarget = itdf.getTargetType();
/*  819 */           if (itdTarget.equals(target)) return itdf; 
/*  820 */         } catch (ClassNotFoundException classNotFoundException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  825 */     throw new NoSuchFieldException(name);
/*      */   }
/*      */   
/*      */   public InterTypeFieldDeclaration[] getITDFields() {
/*  829 */     List<InterTypeFieldDeclaration> itdfs = new ArrayList<>();
/*  830 */     if (this.itdFields == null) {
/*  831 */       Method[] baseMethods = this.clazz.getMethods();
/*  832 */       for (Method m : baseMethods) {
/*  833 */         if (m.isAnnotationPresent((Class)ajcITD.class)) {
/*  834 */           ajcITD ann = m.<ajcITD>getAnnotation(ajcITD.class);
/*  835 */           if (m.getName().contains("ajc$interFieldInit") && 
/*  836 */             Modifier.isPublic(ann.modifiers())) {
/*  837 */             String interFieldInitMethodName = m.getName();
/*      */             
/*  839 */             String interFieldGetDispatchMethodName = interFieldInitMethodName.replace("FieldInit", "FieldGetDispatch");
/*      */             try {
/*  841 */               Method dispatch = m.getDeclaringClass().getDeclaredMethod(interFieldGetDispatchMethodName, m.getParameterTypes());
/*      */ 
/*      */ 
/*      */               
/*  845 */               InterTypeFieldDeclaration itdf = new InterTypeFieldDeclarationImpl(this, ann.targetType(), ann.modifiers(), ann.name(), AjTypeSystem.getAjType(dispatch.getReturnType()), dispatch.getGenericReturnType());
/*  846 */               itdfs.add(itdf);
/*  847 */             } catch (NoSuchMethodException nsmEx) {
/*  848 */               throw new IllegalStateException("Can't find field get dispatch method for " + m.getName());
/*      */             } 
/*      */           } 
/*      */         } 
/*  852 */       }  addAnnotationStyleITDFields(itdfs, true);
/*  853 */       this.itdFields = new InterTypeFieldDeclaration[itdfs.size()];
/*  854 */       itdfs.toArray(this.itdFields);
/*      */     } 
/*  856 */     return this.itdFields;
/*      */   }
/*      */   
/*      */   public DeclareErrorOrWarning[] getDeclareErrorOrWarnings() {
/*  860 */     List<DeclareErrorOrWarning> deows = new ArrayList<>();
/*  861 */     for (Field field : this.clazz.getDeclaredFields()) {
/*      */       try {
/*  863 */         if (field.isAnnotationPresent((Class)DeclareWarning.class)) {
/*  864 */           DeclareWarning dw = field.<DeclareWarning>getAnnotation(DeclareWarning.class);
/*  865 */           if (Modifier.isPublic(field.getModifiers()) && Modifier.isStatic(field.getModifiers())) {
/*  866 */             String message = (String)field.get((Object)null);
/*  867 */             DeclareErrorOrWarningImpl deow = new DeclareErrorOrWarningImpl(dw.value(), message, false, this);
/*  868 */             deows.add(deow);
/*      */           } 
/*  870 */         } else if (field.isAnnotationPresent((Class)DeclareError.class)) {
/*  871 */           DeclareError de = field.<DeclareError>getAnnotation(DeclareError.class);
/*  872 */           if (Modifier.isPublic(field.getModifiers()) && Modifier.isStatic(field.getModifiers())) {
/*  873 */             String message = (String)field.get((Object)null);
/*  874 */             DeclareErrorOrWarningImpl deow = new DeclareErrorOrWarningImpl(de.value(), message, true, this);
/*  875 */             deows.add(deow);
/*      */           } 
/*      */         } 
/*  878 */       } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  880 */       } catch (IllegalAccessException illegalAccessException) {}
/*      */     } 
/*      */ 
/*      */     
/*  884 */     for (Method method : this.clazz.getDeclaredMethods()) {
/*  885 */       if (method.isAnnotationPresent((Class)ajcDeclareEoW.class)) {
/*  886 */         ajcDeclareEoW deowAnn = method.<ajcDeclareEoW>getAnnotation(ajcDeclareEoW.class);
/*  887 */         DeclareErrorOrWarning deow = new DeclareErrorOrWarningImpl(deowAnn.pointcut(), deowAnn.message(), deowAnn.isError(), this);
/*  888 */         deows.add(deow);
/*      */       } 
/*      */     } 
/*  891 */     DeclareErrorOrWarning[] ret = new DeclareErrorOrWarning[deows.size()];
/*  892 */     deows.toArray(ret);
/*  893 */     return ret;
/*      */   }
/*      */   
/*      */   public DeclareParents[] getDeclareParents() {
/*  897 */     List<DeclareParents> decps = new ArrayList<>();
/*  898 */     for (Method method : this.clazz.getDeclaredMethods()) {
/*  899 */       if (method.isAnnotationPresent((Class)ajcDeclareParents.class)) {
/*  900 */         ajcDeclareParents decPAnn = method.<ajcDeclareParents>getAnnotation(ajcDeclareParents.class);
/*      */ 
/*      */ 
/*      */         
/*  904 */         DeclareParentsImpl decp = new DeclareParentsImpl(decPAnn.targetTypePattern(), decPAnn.parentTypes(), decPAnn.isExtends(), this);
/*      */ 
/*      */         
/*  907 */         decps.add(decp);
/*      */       } 
/*      */     } 
/*  910 */     addAnnotationStyleDeclareParents(decps);
/*  911 */     if (getSupertype().isAspect()) {
/*  912 */       decps.addAll(Arrays.asList(getSupertype().getDeclareParents()));
/*      */     }
/*  914 */     DeclareParents[] ret = new DeclareParents[decps.size()];
/*  915 */     decps.toArray(ret);
/*  916 */     return ret;
/*      */   }
/*      */   
/*      */   private void addAnnotationStyleDeclareParents(List<DeclareParents> toList) {
/*  920 */     for (Field f : this.clazz.getDeclaredFields()) {
/*  921 */       if (f.isAnnotationPresent((Class)DeclareParents.class) && 
/*  922 */         f.getType().isInterface()) {
/*  923 */         DeclareParents ann = f.<DeclareParents>getAnnotation(DeclareParents.class);
/*  924 */         String parentType = f.getType().getName();
/*      */         
/*  926 */         DeclareParentsImpl decp = new DeclareParentsImpl(ann.value(), parentType, false, this);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  931 */         toList.add(decp);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public DeclareSoft[] getDeclareSofts() {
/*  937 */     List<DeclareSoft> decs = new ArrayList<>();
/*  938 */     for (Method method : this.clazz.getDeclaredMethods()) {
/*  939 */       if (method.isAnnotationPresent((Class)ajcDeclareSoft.class)) {
/*  940 */         ajcDeclareSoft decSAnn = method.<ajcDeclareSoft>getAnnotation(ajcDeclareSoft.class);
/*      */ 
/*      */ 
/*      */         
/*  944 */         DeclareSoftImpl ds = new DeclareSoftImpl(this, decSAnn.pointcut(), decSAnn.exceptionType());
/*      */         
/*  946 */         decs.add(ds);
/*      */       } 
/*      */     } 
/*  949 */     if (getSupertype().isAspect()) {
/*  950 */       decs.addAll(Arrays.asList(getSupertype().getDeclareSofts()));
/*      */     }
/*  952 */     DeclareSoft[] ret = new DeclareSoft[decs.size()];
/*  953 */     decs.toArray(ret);
/*  954 */     return ret;
/*      */   }
/*      */   
/*      */   public DeclareAnnotation[] getDeclareAnnotations() {
/*  958 */     List<DeclareAnnotation> decAs = new ArrayList<>();
/*  959 */     for (Method method : this.clazz.getDeclaredMethods()) {
/*  960 */       if (method.isAnnotationPresent((Class)ajcDeclareAnnotation.class)) {
/*  961 */         ajcDeclareAnnotation decAnn = method.<ajcDeclareAnnotation>getAnnotation(ajcDeclareAnnotation.class);
/*      */         
/*  963 */         Annotation targetAnnotation = null;
/*  964 */         Annotation[] anns = method.getAnnotations();
/*  965 */         for (Annotation ann : anns) {
/*  966 */           if (ann.annotationType() != ajcDeclareAnnotation.class) {
/*      */             
/*  968 */             targetAnnotation = ann;
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  977 */         DeclareAnnotationImpl da = new DeclareAnnotationImpl(this, decAnn.kind(), decAnn.pattern(), targetAnnotation, decAnn.annotation());
/*      */         
/*  979 */         decAs.add(da);
/*      */       } 
/*      */     } 
/*  982 */     if (getSupertype().isAspect()) {
/*  983 */       decAs.addAll(Arrays.asList(getSupertype().getDeclareAnnotations()));
/*      */     }
/*  985 */     DeclareAnnotation[] ret = new DeclareAnnotation[decAs.size()];
/*  986 */     decAs.toArray(ret);
/*  987 */     return ret;
/*      */   }
/*      */   
/*      */   public DeclarePrecedence[] getDeclarePrecedence() {
/*  991 */     List<DeclarePrecedence> decps = new ArrayList<>();
/*      */ 
/*      */     
/*  994 */     if (this.clazz.isAnnotationPresent((Class)DeclarePrecedence.class)) {
/*      */       
/*  996 */       DeclarePrecedence ann = this.clazz.<DeclarePrecedence>getAnnotation(DeclarePrecedence.class);
/*      */       
/*  998 */       DeclarePrecedenceImpl decp = new DeclarePrecedenceImpl(ann.value(), this);
/*      */ 
/*      */       
/* 1001 */       decps.add(decp);
/*      */     } 
/*      */ 
/*      */     
/* 1005 */     for (Method method : this.clazz.getDeclaredMethods()) {
/* 1006 */       if (method.isAnnotationPresent((Class)ajcDeclarePrecedence.class)) {
/* 1007 */         ajcDeclarePrecedence decPAnn = method.<ajcDeclarePrecedence>getAnnotation(ajcDeclarePrecedence.class);
/*      */         
/* 1009 */         DeclarePrecedenceImpl decp = new DeclarePrecedenceImpl(decPAnn.value(), this);
/*      */ 
/*      */         
/* 1012 */         decps.add(decp);
/*      */       } 
/*      */     } 
/* 1015 */     if (getSupertype().isAspect()) {
/* 1016 */       decps.addAll(Arrays.asList(getSupertype().getDeclarePrecedence()));
/*      */     }
/* 1018 */     DeclarePrecedence[] ret = new DeclarePrecedence[decps.size()];
/* 1019 */     decps.toArray(ret);
/* 1020 */     return ret;
/*      */   }
/*      */   
/*      */   public T[] getEnumConstants() {
/* 1024 */     return this.clazz.getEnumConstants();
/*      */   }
/*      */   
/*      */   public TypeVariable<Class<T>>[] getTypeParameters() {
/* 1028 */     return this.clazz.getTypeParameters();
/*      */   }
/*      */   
/*      */   public boolean isEnum() {
/* 1032 */     return this.clazz.isEnum();
/*      */   }
/*      */   
/*      */   public boolean isInstance(Object o) {
/* 1036 */     return this.clazz.isInstance(o);
/*      */   }
/*      */   
/*      */   public boolean isInterface() {
/* 1040 */     return this.clazz.isInterface();
/*      */   }
/*      */   
/*      */   public boolean isLocalClass() {
/* 1044 */     return (this.clazz.isLocalClass() && !isAspect());
/*      */   }
/*      */   
/*      */   public boolean isMemberClass() {
/* 1048 */     return (this.clazz.isMemberClass() && !isAspect());
/*      */   }
/*      */   
/*      */   public boolean isArray() {
/* 1052 */     return this.clazz.isArray();
/*      */   }
/*      */   
/*      */   public boolean isPrimitive() {
/* 1056 */     return this.clazz.isPrimitive();
/*      */   }
/*      */   
/*      */   public boolean isAspect() {
/* 1060 */     return (this.clazz.getAnnotation(Aspect.class) != null);
/*      */   }
/*      */   
/*      */   public boolean isMemberAspect() {
/* 1064 */     return (this.clazz.isMemberClass() && isAspect());
/*      */   }
/*      */   
/*      */   public boolean isPrivileged() {
/* 1068 */     return (isAspect() && this.clazz.isAnnotationPresent((Class)ajcPrivileged.class));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1073 */     if (!(obj instanceof AjTypeImpl)) return false; 
/* 1074 */     AjTypeImpl<?> other = (AjTypeImpl)obj;
/* 1075 */     return other.clazz.equals(this.clazz);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1080 */     return this.clazz.hashCode();
/*      */   }
/*      */   
/*      */   private AjType<?>[] toAjTypeArray(Class<?>[] classes) {
/* 1084 */     AjType[] arrayOfAjType = new AjType[classes.length];
/* 1085 */     for (int i = 0; i < arrayOfAjType.length; i++) {
/* 1086 */       arrayOfAjType[i] = AjTypeSystem.getAjType(classes[i]);
/*      */     }
/* 1088 */     return (AjType<?>[])arrayOfAjType;
/*      */   }
/*      */   
/*      */   private Class<?>[] toClassArray(AjType<?>[] ajTypes) {
/* 1092 */     Class<?>[] classes = new Class[ajTypes.length];
/* 1093 */     for (int i = 0; i < classes.length; i++) {
/* 1094 */       classes[i] = ajTypes[i].getJavaClass();
/*      */     }
/* 1096 */     return classes;
/*      */   }
/*      */   public String toString() {
/* 1099 */     return getName();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\AjTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */