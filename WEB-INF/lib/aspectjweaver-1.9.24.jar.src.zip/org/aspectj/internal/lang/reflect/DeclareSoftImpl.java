/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.AjType;
/*    */ import org.aspectj.lang.reflect.AjTypeSystem;
/*    */ import org.aspectj.lang.reflect.DeclareSoft;
/*    */ import org.aspectj.lang.reflect.PointcutExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclareSoftImpl
/*    */   implements DeclareSoft
/*    */ {
/*    */   private AjType<?> declaringType;
/*    */   private PointcutExpression pointcut;
/*    */   private AjType<?> exceptionType;
/*    */   private String missingTypeName;
/*    */   
/*    */   public DeclareSoftImpl(AjType<?> declaringType, String pcut, String exceptionTypeName) {
/* 32 */     this.declaringType = declaringType;
/* 33 */     this.pointcut = new PointcutExpressionImpl(pcut);
/*    */     try {
/* 35 */       ClassLoader cl = declaringType.getJavaClass().getClassLoader();
/* 36 */       this.exceptionType = AjTypeSystem.getAjType(Class.forName(exceptionTypeName, false, cl));
/* 37 */     } catch (ClassNotFoundException ex) {
/* 38 */       this.missingTypeName = exceptionTypeName;
/*    */     } 
/*    */   }
/*    */   
/*    */   public AjType getDeclaringType() {
/* 43 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public AjType getSoftenedExceptionType() throws ClassNotFoundException {
/* 47 */     if (this.missingTypeName != null) throw new ClassNotFoundException(this.missingTypeName); 
/* 48 */     return this.exceptionType;
/*    */   }
/*    */   
/*    */   public PointcutExpression getPointcutExpression() {
/* 52 */     return this.pointcut;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 56 */     StringBuilder sb = new StringBuilder();
/* 57 */     sb.append("declare soft : ");
/* 58 */     if (this.missingTypeName != null) {
/* 59 */       sb.append(this.exceptionType.getName());
/*    */     } else {
/* 61 */       sb.append(this.missingTypeName);
/*    */     } 
/* 63 */     sb.append(" : ");
/* 64 */     sb.append(getPointcutExpression().asString());
/* 65 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\DeclareSoftImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */