/*    */ package org.aspectj.internal.lang.reflect;
/*    */ 
/*    */ import org.aspectj.lang.reflect.PerClauseKind;
/*    */ import org.aspectj.lang.reflect.TypePattern;
/*    */ import org.aspectj.lang.reflect.TypePatternBasedPerClause;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypePatternBasedPerClauseImpl
/*    */   extends PerClauseImpl
/*    */   implements TypePatternBasedPerClause
/*    */ {
/*    */   private TypePattern typePattern;
/*    */   
/*    */   public TypePatternBasedPerClauseImpl(PerClauseKind kind, String pattern) {
/* 28 */     super(kind);
/* 29 */     this.typePattern = new TypePatternImpl(pattern);
/*    */   }
/*    */   
/*    */   public TypePattern getTypePattern() {
/* 33 */     return this.typePattern;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 37 */     return "pertypewithin(" + this.typePattern.asString() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\reflect\TypePatternBasedPerClauseImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */