package org.aspectj.internal.lang.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface ajcDeclareParents {
  String targetTypePattern();
  
  String parentTypes();
  
  boolean isExtends();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\internal\lang\annotation\ajcDeclareParents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */