/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.aspectj.util.LangUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceLocation
/*     */   implements ISourceLocation
/*     */ {
/*     */   private static final long serialVersionUID = -5434765814401009794L;
/*  30 */   private transient int cachedHashcode = -1;
/*     */ 
/*     */   
/*  33 */   public static final ISourceLocation UNKNOWN = new SourceLocation(ISourceLocation.NO_FILE, 0, 0, 0);
/*     */   
/*     */   private final File sourceFile;
/*     */   
/*     */   private final int startLine;
/*     */   private final int column;
/*     */   private final int endLine;
/*     */   private int offset;
/*     */   private final String context;
/*     */   private boolean noColumn;
/*     */   private String sourceFileName;
/*     */   
/*     */   public static final void validLine(int line) {
/*  46 */     if (line < 0)
/*  47 */       throw new IllegalArgumentException("negative line: " + line); 
/*  48 */     if (line > 1073741823) {
/*  49 */       throw new IllegalArgumentException("line too large: " + line);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void validColumn(int column) {
/*  55 */     if (column < 0)
/*  56 */       throw new IllegalArgumentException("negative column: " + column); 
/*  57 */     if (column > 1073741823) {
/*  58 */       throw new IllegalArgumentException("column too large: " + column);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceLocation(File file, int line) {
/*  66 */     this(file, line, line, -2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public SourceLocation(File file, int line, int endLine) {
/*  71 */     this(file, line, endLine, -2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceLocation(File file, int line, int endLine, int column) {
/*  81 */     this(file, line, endLine, column, (String)null);
/*     */   }
/*     */   
/*     */   public SourceLocation(File file, int line, int endLine, int column, String context) {
/*  85 */     if (column == -2147483647) {
/*  86 */       column = 0;
/*  87 */       this.noColumn = true;
/*     */     } 
/*  89 */     if (null == file) {
/*  90 */       file = ISourceLocation.NO_FILE;
/*     */     }
/*  92 */     validLine(line);
/*  93 */     validLine(endLine);
/*  94 */     LangUtil.throwIaxIfFalse((line <= endLine), line + " > " + endLine);
/*  95 */     LangUtil.throwIaxIfFalse((column >= 0), "negative column: " + column);
/*  96 */     this.sourceFile = file;
/*  97 */     this.startLine = line;
/*  98 */     this.column = column;
/*  99 */     this.endLine = endLine;
/* 100 */     this.context = context;
/*     */   }
/*     */   
/*     */   public SourceLocation(File file, int line, int endLine, int column, String context, String sourceFileName) {
/* 104 */     this(file, line, endLine, column, context);
/* 105 */     this.sourceFileName = sourceFileName;
/*     */   }
/*     */   
/*     */   public File getSourceFile() {
/* 109 */     return this.sourceFile;
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 113 */     return this.startLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 120 */     return this.column;
/*     */   }
/*     */   
/*     */   public int getEndLine() {
/* 124 */     return this.endLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContext() {
/* 129 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     StringBuilder sb = new StringBuilder();
/* 135 */     if (null != this.context) {
/* 136 */       sb.append(this.context);
/* 137 */       sb.append(LangUtil.EOL);
/*     */     } 
/* 139 */     if (this.sourceFile != ISourceLocation.NO_FILE) {
/* 140 */       sb.append(this.sourceFile.getPath());
/*     */     }
/* 142 */     if (this.startLine > 0) {
/* 143 */       sb.append(":");
/* 144 */       sb.append(this.startLine);
/*     */     } 
/* 146 */     if (!this.noColumn) {
/* 147 */       sb.append(":" + this.column);
/*     */     }
/* 149 */     if (this.offset >= 0) {
/* 150 */       sb.append("::" + this.offset);
/*     */     }
/* 152 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 159 */     return this.offset;
/*     */   }
/*     */   
/*     */   public void setOffset(int i) {
/* 163 */     this.cachedHashcode = -1;
/* 164 */     this.offset = i;
/*     */   }
/*     */   
/*     */   public String getSourceFileName() {
/* 168 */     return this.sourceFileName;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 172 */     if (!(obj instanceof SourceLocation)) {
/* 173 */       return false;
/*     */     }
/* 175 */     SourceLocation o = (SourceLocation)obj;
/* 176 */     return (this.startLine == o.startLine && this.column == o.column && this.endLine == o.endLine && this.offset == o.offset && ((this.sourceFile == null) ? (o.sourceFile == null) : this.sourceFile
/* 177 */       .equals(o.sourceFile)) && ((this.context == null) ? (o.context == null) : this.context
/* 178 */       .equals(o.context)) && this.noColumn == o.noColumn && ((this.sourceFileName == null) ? (o.sourceFileName == null) : this.sourceFileName
/* 179 */       .equals(o.sourceFileName)));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 183 */     if (this.cachedHashcode == -1) {
/* 184 */       this.cachedHashcode = (this.sourceFile == null) ? 0 : this.sourceFile.hashCode();
/* 185 */       this.cachedHashcode = this.cachedHashcode * 37 + this.startLine;
/* 186 */       this.cachedHashcode = this.cachedHashcode * 37 + this.column;
/* 187 */       this.cachedHashcode = this.cachedHashcode * 37 + this.endLine;
/* 188 */       this.cachedHashcode = this.cachedHashcode * 37 + this.offset;
/* 189 */       this.cachedHashcode = this.cachedHashcode * 37 + ((this.context == null) ? 0 : this.context.hashCode());
/* 190 */       this.cachedHashcode = this.cachedHashcode * 37 + (this.noColumn ? 0 : 1);
/* 191 */       this.cachedHashcode = this.cachedHashcode * 37 + ((this.sourceFileName == null) ? 0 : this.sourceFileName.hashCode());
/*     */     } 
/* 193 */     return this.cachedHashcode;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\SourceLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */