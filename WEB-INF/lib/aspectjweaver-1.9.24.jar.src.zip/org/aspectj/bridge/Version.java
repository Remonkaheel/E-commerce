/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Version
/*     */ {
/*     */   public static final String DEVELOPMENT = "DEVELOPMENT";
/*     */   public static final long NOTIME = 0L;
/*     */   public static final String UNREPLACED_TEXT = "${project.version}";
/*     */   public static final String UNREPLACED_TIME_TEXT = "${version.time_text}";
/*     */   private static String text;
/*     */   private static String time_text;
/*  50 */   private static long time = -1L;
/*     */   
/*     */   public static final String SIMPLE_DATE_FORMAT = "EEEE MMM d, yyyy 'at' HH:mm:ss z";
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  57 */       URL resource = Version.class.getResource("version.properties");
/*  58 */       Properties p = new Properties();
/*  59 */       p.load(resource.openStream());
/*  60 */       text = p.getProperty("version.text", "");
/*  61 */       if (text.equals("${project.version}")) {
/*  62 */         text = "DEVELOPMENT";
/*     */       }
/*  64 */       time_text = p.getProperty("version.time_text", "");
/*  65 */       if (time_text.equals("${version.time_text}")) {
/*  66 */         time_text = "";
/*     */       }
/*  68 */     } catch (IOException e) {
/*  69 */       text = "DEVELOPMENT";
/*  70 */       time_text = "";
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long getTime() {
/*  75 */     if (time == -1L) {
/*  76 */       long foundTime = 0L;
/*     */       
/*     */       try {
/*  79 */         SimpleDateFormat format = new SimpleDateFormat("EEEE MMM d, yyyy 'at' HH:mm:ss z");
/*  80 */         ParsePosition pos = new ParsePosition(0);
/*  81 */         Date date = format.parse(time_text, pos);
/*  82 */         if (date != null) foundTime = date.getTime(); 
/*  83 */       } catch (Throwable throwable) {}
/*     */       
/*  85 */       time = foundTime;
/*     */     } 
/*  87 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  97 */     if (null != args && 0 < args.length && 
/*  98 */       !text.equals(args[0])) {
/*  99 */       System.err.println("version expected: \"" + args[0] + "\" actual=\"" + text + "\"");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTimeText() {
/* 109 */     return time_text;
/*     */   }
/*     */   
/*     */   public static String getText() {
/* 113 */     return text;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\Version.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */