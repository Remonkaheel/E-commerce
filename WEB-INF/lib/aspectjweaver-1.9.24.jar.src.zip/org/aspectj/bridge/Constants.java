package org.aspectj.bridge;

public class Constants {
  public static final String AOP_USER_XML = "META-INF/aop.xml";
  
  public static final String AOP_AJC_XML = "META-INF/aop-ajc.xml";
  
  public static final String AOP_OSGI_XML = "org/aspectj/aop.xml";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */