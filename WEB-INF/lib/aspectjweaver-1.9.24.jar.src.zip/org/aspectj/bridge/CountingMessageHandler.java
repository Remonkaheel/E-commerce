/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import org.aspectj.util.LangUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CountingMessageHandler
/*     */   implements IMessageHandler
/*     */ {
/*     */   public final IMessageHandler delegate;
/*     */   public final CountingMessageHandler proxy;
/*     */   private final Hashtable<IMessage.Kind, IntHolder> counters;
/*     */   
/*     */   public static CountingMessageHandler makeCountingMessageHandler(IMessageHandler handler) {
/*  31 */     if (handler instanceof CountingMessageHandler) {
/*  32 */       return (CountingMessageHandler)handler;
/*     */     }
/*  34 */     return new CountingMessageHandler(handler);
/*     */   }
/*     */ 
/*     */   
/*     */   public CountingMessageHandler(IMessageHandler delegate) {
/*  39 */     LangUtil.throwIaxIfNull(delegate, "delegate");
/*  40 */     this.delegate = delegate;
/*  41 */     this.counters = new Hashtable<>();
/*  42 */     this.proxy = (delegate instanceof CountingMessageHandler) ? (CountingMessageHandler)delegate : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleMessage(IMessage message) throws AbortException {
/*  47 */     if (null != this.proxy) {
/*  48 */       return this.proxy.handleMessage(message);
/*     */     }
/*  50 */     if (null != message) {
/*  51 */       IMessage.Kind kind = message.getKind();
/*  52 */       if (!isIgnoring(kind)) {
/*  53 */         increment(kind);
/*     */       }
/*     */     } 
/*  56 */     return this.delegate.handleMessage(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIgnoring(IMessage.Kind kind) {
/*  61 */     return this.delegate.isIgnoring(kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dontIgnore(IMessage.Kind kind) {
/*  71 */     this.delegate.dontIgnore(kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignore(IMessage.Kind kind) {
/*  81 */     this.delegate.ignore(kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  86 */     return this.delegate.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numMessages(IMessage.Kind kind, boolean orGreater) {
/*  98 */     if (null != this.proxy) {
/*  99 */       return this.proxy.numMessages(kind, orGreater);
/*     */     }
/* 101 */     int result = 0;
/* 102 */     if (null == kind) {
/* 103 */       for (Enumeration<IntHolder> enu = this.counters.elements(); enu.hasMoreElements();) {
/* 104 */         result += ((IntHolder)enu.nextElement()).count;
/*     */       }
/* 106 */     } else if (!orGreater) {
/* 107 */       result = numMessages(kind);
/*     */     } else {
/* 109 */       for (IMessage.Kind k : IMessage.KINDS) {
/* 110 */         if (kind.isSameOrLessThan(k)) {
/* 111 */           result += numMessages(k);
/*     */         }
/*     */       } 
/*     */     } 
/* 115 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasErrors() {
/* 122 */     return (0 < numMessages(IMessage.ERROR, true));
/*     */   }
/*     */   
/*     */   private int numMessages(IMessage.Kind kind) {
/* 126 */     if (null != this.proxy) {
/* 127 */       return this.proxy.numMessages(kind);
/*     */     }
/* 129 */     IntHolder counter = this.counters.get(kind);
/* 130 */     return (null == counter) ? 0 : counter.count;
/*     */   }
/*     */   
/*     */   private void increment(IMessage.Kind kind) {
/* 134 */     if (null != this.proxy) {
/* 135 */       throw new IllegalStateException("not called when proxying");
/*     */     }
/*     */     
/* 138 */     IntHolder counter = this.counters.get(kind);
/* 139 */     if (null == counter) {
/* 140 */       counter = new IntHolder();
/* 141 */       this.counters.put(kind, counter);
/*     */     } 
/* 143 */     counter.count++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 151 */     if (this.proxy != null) {
/* 152 */       this.proxy.reset();
/*     */     }
/* 154 */     this.counters.clear();
/*     */   }
/*     */   
/*     */   private static class IntHolder {
/*     */     int count;
/*     */     
/*     */     private IntHolder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\CountingMessageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */