/*    */ package org.aspectj.bridge;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageWriter
/*    */   implements IMessageHandler
/*    */ {
/*    */   protected PrintWriter writer;
/*    */   protected boolean abortOnFailure;
/*    */   
/*    */   public MessageWriter(PrintWriter writer, boolean abortOnFailure) {
/* 29 */     this.writer = (null != writer) ? writer : new PrintWriter(System.out);
/* 30 */     this.abortOnFailure = abortOnFailure;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleMessage(IMessage message) throws AbortException {
/* 40 */     if (null != message && !isIgnoring(message.getKind())) {
/* 41 */       String result = render(message);
/* 42 */       if (null != result) {
/* 43 */         this.writer.println(result);
/* 44 */         this.writer.flush();
/* 45 */         if (this.abortOnFailure && (message
/* 46 */           .isFailed() || message.isAbort())) {
/* 47 */           throw new AbortException(message);
/*    */         }
/*    */       } 
/*    */     } 
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isIgnoring(IMessage.Kind kind) {
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dontIgnore(IMessage.Kind kind) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void ignore(IMessage.Kind kind) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String render(IMessage message) {
/* 81 */     return message.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\MessageWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */