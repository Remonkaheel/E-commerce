package org.aspectj.bridge;

import java.util.List;

public interface IMessageHolder extends IMessageHandler {
  public static final boolean ORGREATER = true;
  
  public static final boolean EQUAL = false;
  
  boolean hasAnyMessage(IMessage.Kind paramKind, boolean paramBoolean);
  
  int numMessages(IMessage.Kind paramKind, boolean paramBoolean);
  
  IMessage[] getMessages(IMessage.Kind paramKind, boolean paramBoolean);
  
  List<IMessage> getUnmodifiableListView();
  
  void clearMessages() throws UnsupportedOperationException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\IMessageHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */