/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageHandler
/*     */   implements IMessageHolder
/*     */ {
/*     */   protected final ArrayList<IMessage> messages;
/*     */   protected final List<IMessage.Kind> ignoring;
/*     */   protected boolean handleMessageResult;
/*     */   protected IMessageHandler interceptor;
/*     */   
/*     */   public MessageHandler() {
/*  44 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageHandler(boolean accumulateOnly) {
/*  51 */     this.messages = new ArrayList<>();
/*  52 */     this.ignoring = new ArrayList<>();
/*  53 */     init(accumulateOnly);
/*  54 */     ignore(IMessage.WEAVEINFO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  62 */     init(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(boolean accumulateOnly) {
/*  71 */     this.handleMessageResult = accumulateOnly;
/*  72 */     if (0 < this.messages.size()) {
/*  73 */       this.messages.clear();
/*     */     }
/*  75 */     if (0 < this.ignoring.size()) {
/*  76 */       boolean ignoringWeaveMessages = isIgnoring(IMessage.WEAVEINFO);
/*  77 */       this.ignoring.clear();
/*  78 */       if (ignoringWeaveMessages) {
/*  79 */         ignore(IMessage.WEAVEINFO);
/*     */       }
/*     */     } 
/*  82 */     if (null != this.interceptor) {
/*  83 */       this.interceptor = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearMessages() {
/*  91 */     if (0 < this.messages.size()) {
/*  92 */       this.messages.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleMessage(IMessage message) {
/* 105 */     if (null != this.interceptor && this.interceptor.handleMessage(message)) {
/* 106 */       return true;
/*     */     }
/* 108 */     if (null == message) {
/* 109 */       throw new IllegalArgumentException("null message");
/*     */     }
/* 111 */     if (!this.ignoring.contains(message.getKind())) {
/* 112 */       this.messages.add(message);
/*     */     }
/* 114 */     return this.handleMessageResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoring(IMessage.Kind kind) {
/* 123 */     return (null != kind && this.ignoring.contains(kind));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignore(IMessage.Kind kind) {
/* 132 */     if (null != kind && !this.ignoring.contains(kind)) {
/* 133 */       this.ignoring.add(kind);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dontIgnore(IMessage.Kind kind) {
/* 141 */     if (null != kind) {
/* 142 */       this.ignoring.remove(kind);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAnyMessage(IMessage.Kind kind, boolean orGreater) {
/* 150 */     if (null == kind) {
/* 151 */       return (0 < this.messages.size());
/*     */     }
/* 153 */     if (!orGreater) {
/* 154 */       for (IMessage m : this.messages) {
/* 155 */         if (kind == m.getKind()) {
/* 156 */           return true;
/*     */         }
/*     */       } 
/*     */     } else {
/* 160 */       for (IMessage m : this.messages) {
/* 161 */         if (kind.isSameOrLessThan(m.getKind())) {
/* 162 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 166 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numMessages(IMessage.Kind kind, boolean orGreater) {
/* 173 */     if (null == kind) {
/* 174 */       return this.messages.size();
/*     */     }
/* 176 */     int result = 0;
/* 177 */     if (!orGreater) {
/* 178 */       for (IMessage m : this.messages) {
/* 179 */         if (kind == m.getKind()) {
/* 180 */           result++;
/*     */         }
/*     */       } 
/*     */     } else {
/* 184 */       for (IMessage m : this.messages) {
/* 185 */         if (kind.isSameOrLessThan(m.getKind())) {
/* 186 */           result++;
/*     */         }
/*     */       } 
/*     */     } 
/* 190 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IMessage> getUnmodifiableListView() {
/* 197 */     return Collections.unmodifiableList(this.messages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMessage[] getMessages(IMessage.Kind kind, boolean orGreater) {
/* 207 */     if (null == kind) {
/* 208 */       return this.messages.<IMessage>toArray(IMessage.RA_IMessage);
/*     */     }
/* 210 */     ArrayList<IMessage> result = new ArrayList<>();
/* 211 */     if (!orGreater) {
/* 212 */       for (IMessage m : this.messages) {
/* 213 */         if (kind == m.getKind()) {
/* 214 */           result.add(m);
/*     */         }
/*     */       } 
/*     */     } else {
/* 218 */       for (IMessage m : this.messages) {
/* 219 */         if (kind.isSameOrLessThan(m.getKind())) {
/* 220 */           result.add(m);
/*     */         }
/*     */       } 
/*     */     } 
/* 224 */     if (0 == result.size()) {
/* 225 */       return IMessage.RA_IMessage;
/*     */     }
/* 227 */     return result.<IMessage>toArray(IMessage.RA_IMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMessage[] getErrors() {
/* 234 */     return getMessages(IMessage.ERROR, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMessage[] getWarnings() {
/* 241 */     return getMessages(IMessage.WARNING, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterceptor(IMessageHandler interceptor) {
/* 250 */     this.interceptor = interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 257 */     if (0 == this.messages.size()) {
/* 258 */       return "MessageHandler: no messages";
/*     */     }
/* 260 */     return "MessageHandler: " + this.messages;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\MessageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */