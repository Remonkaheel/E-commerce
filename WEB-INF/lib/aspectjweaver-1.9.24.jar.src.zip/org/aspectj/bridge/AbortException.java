/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbortException
/*     */   extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = -7211791639898586417L;
/*     */   private boolean isSilent = false;
/*     */   public static final String NO_MESSAGE_TEXT = "AbortException (no message)";
/*  48 */   private static final ArrayList<AbortException> porters = new ArrayList<>();
/*     */   
/*     */   protected IMessage message;
/*     */   
/*     */   protected boolean isPorter;
/*     */   
/*     */   public static AbortException borrowPorter(IMessage message) {
/*     */     AbortException result;
/*  56 */     synchronized (porters) {
/*  57 */       if (porters.size() > 0) {
/*  58 */         result = porters.get(0);
/*     */       } else {
/*  60 */         result = new AbortException();
/*  61 */         result.setIsSilent(false);
/*     */       } 
/*     */     } 
/*  64 */     result.setIMessage(message);
/*  65 */     result.isPorter = true;
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void returnPorter(AbortException porter) {
/*  73 */     synchronized (porters) {
/*  74 */       if (porters.contains(porter)) {
/*  75 */         throw new IllegalStateException("already have " + porter);
/*     */       }
/*  77 */       porters.add(porter);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String extractMessage(IMessage message) {
/*  84 */     if (null == message) {
/*  85 */       return "AbortException (no message)";
/*     */     }
/*  87 */     String m = message.getMessage();
/*  88 */     if (null == m) {
/*  89 */       return "AbortException (no message)";
/*     */     }
/*  91 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbortException() {
/* 104 */     this("ABORT");
/* 105 */     this.isSilent = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public AbortException(String s) {
/* 110 */     super((null != s) ? s : "AbortException (no message)");
/* 111 */     this.message = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public AbortException(IMessage message) {
/* 116 */     super(extractMessage(message));
/* 117 */     this.message = message;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMessage getIMessage() {
/* 122 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPorter() {
/* 131 */     return this.isPorter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getThrown() {
/* 136 */     Throwable result = null;
/* 137 */     IMessage m = getIMessage();
/* 138 */     if (null != m) {
/* 139 */       result = m.getThrown();
/* 140 */       if (result instanceof AbortException) {
/* 141 */         return ((AbortException)result).getThrown();
/*     */       }
/*     */     } 
/* 144 */     return result;
/*     */   }
/*     */   
/*     */   private void setIMessage(IMessage message) {
/* 148 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 159 */     String message = super.getMessage();
/* 160 */     if (null == message || "AbortException (no message)" == message) {
/* 161 */       IMessage m = getIMessage();
/* 162 */       if (null != m) {
/* 163 */         message = m.getMessage();
/* 164 */         if (null == message) {
/* 165 */           Throwable thrown = m.getThrown();
/* 166 */           if (null != thrown) {
/* 167 */             message = thrown.getMessage();
/*     */           }
/*     */         } 
/*     */       } 
/* 171 */       if (null == message) {
/* 172 */         message = "AbortException (no message)";
/*     */       }
/*     */     } 
/* 175 */     return message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace() {
/* 182 */     printStackTrace(System.out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream s) {
/* 191 */     IMessage m = getIMessage();
/* 192 */     Throwable thrown = (null == m) ? null : m.getThrown();
/* 193 */     if (!isPorter() || null == thrown) {
/* 194 */       s.println("Message: " + m);
/* 195 */       super.printStackTrace(s);
/*     */     } else {
/* 197 */       thrown.printStackTrace(s);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter s) {
/* 207 */     IMessage m = getIMessage();
/* 208 */     Throwable thrown = (null == m) ? null : m.getThrown();
/* 209 */     if (null == thrown) {
/* 210 */       if (isPorter()) {
/* 211 */         s.println("(Warning porter AbortException without thrown)");
/*     */       }
/* 213 */       s.println("Message: " + m);
/* 214 */       super.printStackTrace(s);
/*     */     } else {
/* 216 */       thrown.printStackTrace(s);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isSilent() {
/* 221 */     return this.isSilent;
/*     */   }
/*     */   
/*     */   public void setIsSilent(boolean isSilent) {
/* 225 */     this.isSilent = isSilent;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\AbortException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */