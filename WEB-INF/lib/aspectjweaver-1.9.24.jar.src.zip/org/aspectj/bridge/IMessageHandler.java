/*    */ package org.aspectj.bridge;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IMessageHandler
/*    */ {
/* 32 */   public static final IMessageHandler SYSTEM_ERR = new MessageWriter(new PrintWriter(System.err, true), true);
/*    */ 
/*    */ 
/*    */   
/* 36 */   public static final IMessageHandler SYSTEM_OUT = new MessageWriter(new PrintWriter(System.out, true), false);
/*    */ 
/*    */ 
/*    */   
/* 40 */   public static final IMessageHandler THROW = new IMessageHandler()
/*    */     {
/*    */       public boolean handleMessage(IMessage message) {
/* 43 */         if (message.getKind().compareTo(IMessage.ERROR) >= 0) {
/* 44 */           throw new AbortException(message);
/*    */         }
/* 46 */         return SYSTEM_OUT.handleMessage(message);
/*    */       }
/*    */       
/*    */       public boolean isIgnoring(IMessage.Kind kind) {
/* 50 */         return false;
/*    */       }
/*    */       
/*    */       public void dontIgnore(IMessage.Kind kind) {}
/*    */       
/*    */       public void ignore(IMessage.Kind kind) {}
/*    */     };
/*    */   
/*    */   boolean handleMessage(IMessage paramIMessage) throws AbortException;
/*    */   
/*    */   boolean isIgnoring(IMessage.Kind paramKind);
/*    */   
/*    */   void dontIgnore(IMessage.Kind paramKind);
/*    */   
/*    */   void ignore(IMessage.Kind paramKind);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\IMessageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */