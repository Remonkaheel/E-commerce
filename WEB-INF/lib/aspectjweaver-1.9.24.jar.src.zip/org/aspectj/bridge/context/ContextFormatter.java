package org.aspectj.bridge.context;

public interface ContextFormatter {
  String formatEntry(int paramInt, Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\context\ContextFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */