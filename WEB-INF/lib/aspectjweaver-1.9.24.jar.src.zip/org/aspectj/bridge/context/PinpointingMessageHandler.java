/*     */ package org.aspectj.bridge.context;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.List;
/*     */ import org.aspectj.bridge.AbortException;
/*     */ import org.aspectj.bridge.IMessage;
/*     */ import org.aspectj.bridge.IMessageHandler;
/*     */ import org.aspectj.bridge.ISourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PinpointingMessageHandler
/*     */   implements IMessageHandler
/*     */ {
/*     */   private IMessageHandler delegate;
/*     */   
/*     */   public PinpointingMessageHandler(IMessageHandler delegate) {
/*  35 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleMessage(IMessage message) throws AbortException {
/*  42 */     if (!isIgnoring(message.getKind())) {
/*  43 */       MessageIssued ex = new MessageIssued();
/*  44 */       ex.fillInStackTrace();
/*  45 */       StringWriter sw = new StringWriter();
/*  46 */       ex.printStackTrace(new PrintWriter(sw));
/*  47 */       StringBuilder sb = new StringBuilder();
/*  48 */       sb.append(CompilationAndWeavingContext.getCurrentContext());
/*  49 */       sb.append(sw.toString());
/*  50 */       IMessage pinpointedMessage = new PinpointedMessage(message, sb.toString());
/*  51 */       return this.delegate.handleMessage(pinpointedMessage);
/*     */     } 
/*  53 */     return this.delegate.handleMessage(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoring(IMessage.Kind kind) {
/*  61 */     return this.delegate.isIgnoring(kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dontIgnore(IMessage.Kind kind) {
/*  68 */     this.delegate.dontIgnore(kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignore(IMessage.Kind kind) {
/*  76 */     this.delegate.ignore(kind);
/*     */   }
/*     */   
/*     */   private static class PinpointedMessage
/*     */     implements IMessage {
/*     */     private IMessage delegate;
/*     */     private String message;
/*     */     
/*     */     public PinpointedMessage(IMessage delegate, String pinpoint) {
/*  85 */       this.delegate = delegate;
/*  86 */       this.message = delegate.getMessage() + "\n" + pinpoint;
/*     */     }
/*     */     
/*  89 */     public String getMessage() { return this.message; }
/*  90 */     public IMessage.Kind getKind() { return this.delegate.getKind(); }
/*  91 */     public boolean isError() { return this.delegate.isError(); }
/*  92 */     public boolean isWarning() { return this.delegate.isWarning(); }
/*  93 */     public boolean isDebug() { return this.delegate.isDebug(); }
/*  94 */     public boolean isUsage() { return this.delegate.isUsage(); }
/*  95 */     public boolean isInfo() { return this.delegate.isInfo(); }
/*  96 */     public boolean isAbort() { return this.delegate.isAbort(); }
/*  97 */     public boolean isTaskTag() { return this.delegate.isTaskTag(); }
/*  98 */     public boolean isFailed() { return this.delegate.isFailed(); }
/*  99 */     public boolean getDeclared() { return this.delegate.getDeclared(); }
/* 100 */     public int getID() { return this.delegate.getID(); }
/* 101 */     public int getSourceStart() { return this.delegate.getSourceStart(); }
/* 102 */     public int getSourceEnd() { return this.delegate.getSourceEnd(); }
/* 103 */     public Throwable getThrown() { return this.delegate.getThrown(); }
/* 104 */     public ISourceLocation getSourceLocation() { return this.delegate.getSourceLocation(); }
/* 105 */     public String getDetails() { return this.delegate.getDetails(); } public List<ISourceLocation> getExtraSourceLocations() {
/* 106 */       return this.delegate.getExtraSourceLocations();
/*     */     } }
/*     */   private static class MessageIssued extends RuntimeException { private static final long serialVersionUID = 1L;
/*     */     
/*     */     private MessageIssued() {}
/*     */     
/*     */     public String getMessage() {
/* 113 */       return "message issued...";
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\context\PinpointingMessageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */