/*     */ package org.aspectj.bridge.context;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompilationAndWeavingContext
/*     */ {
/*  30 */   private static int nextTokenId = 1;
/*     */   
/*     */   public static final int BATCH_BUILD = 0;
/*     */   
/*     */   public static final int INCREMENTAL_BUILD = 1;
/*     */   
/*     */   public static final int PROCESSING_COMPILATION_UNIT = 2;
/*     */   
/*     */   public static final int RESOLVING_COMPILATION_UNIT = 3;
/*     */   
/*     */   public static final int ANALYSING_COMPILATION_UNIT = 4;
/*     */   
/*     */   public static final int GENERATING_UNWOVEN_CODE_FOR_COMPILATION_UNIT = 5;
/*     */   
/*     */   public static final int COMPLETING_TYPE_BINDINGS = 6;
/*     */   
/*     */   public static final int PROCESSING_DECLARE_PARENTS = 7;
/*     */   
/*     */   public static final int CHECK_AND_SET_IMPORTS = 8;
/*     */   public static final int CONNECTING_TYPE_HIERARCHY1 = 9;
/*     */   public static final int BUILDING_FIELDS_AND_METHODS = 10;
/*     */   public static final int COLLECTING_ITDS_AND_DECLARES = 11;
/*     */   public static final int PROCESSING_DECLARE_ANNOTATIONS = 12;
/*     */   public static final int WEAVING_INTERTYPE_DECLARATIONS = 13;
/*     */   public static final int RESOLVING_POINTCUT_DECLARATIONS = 14;
/*     */   public static final int ADDING_DECLARE_WARNINGS_AND_ERRORS = 15;
/*     */   public static final int VALIDATING_AT_ASPECTJ_ANNOTATIONS = 16;
/*     */   public static final int ACCESS_FOR_INLINE = 17;
/*     */   public static final int ADDING_AT_ASPECTJ_ANNOTATIONS = 18;
/*     */   public static final int FIXING_SUPER_CALLS_IN_ITDS = 19;
/*     */   public static final int FIXING_SUPER_CALLS = 20;
/*     */   public static final int OPTIMIZING_THIS_JOIN_POINT_CALLS = 21;
/*     */   public static final int CONNECTING_TYPE_HIERARCHY2 = 22;
/*     */   public static final int WEAVING = 23;
/*     */   public static final int PROCESSING_REWEAVABLE_STATE = 24;
/*     */   public static final int PROCESSING_TYPE_MUNGERS = 25;
/*     */   public static final int WEAVING_ASPECTS = 26;
/*     */   public static final int WEAVING_CLASSES = 27;
/*     */   public static final int WEAVING_TYPE = 28;
/*     */   public static final int MATCHING_SHADOW = 29;
/*     */   public static final int IMPLEMENTING_ON_SHADOW = 30;
/*     */   public static final int MATCHING_POINTCUT = 31;
/*     */   public static final int MUNGING_WITH = 32;
/*     */   public static final int PROCESSING_ATASPECTJTYPE_MUNGERS_ONLY = 33;
/*  74 */   public static final String[] PHASE_NAMES = new String[] { "batch building", "incrementally building", "processing compilation unit", "resolving types defined in compilation unit", "analysing types defined in compilation unit", "generating unwoven code for type defined in compilation unit", "completing type bindings", "processing declare parents", "checking and setting imports", "connecting type hierarchy 1", "building fields and methods", "collecting itds and declares", "processing declare annotations", "weaving intertype declarations", "resolving pointcut declarations", "adding declare warning and errors", "validating @AspectJ annotations", "creating accessors for inlining", "adding @AspectJ annotations", "fixing super calls in ITDs in interface context", "fixing super calls in ITDs", "optimizing thisJoinPoint calls", "connecting type hierarchy 2", "weaving", "processing reweavable state", "processing type mungers", "weaving aspects", "weaving classes", "weaving type", "matching shadow", "implementing on shadow", "matching pointcut", "type munging with", "type munging for @AspectJ aspectOf" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static ThreadLocal<Stack<ContextStackEntry>> contextMap = new ThreadLocal<>();
/*     */ 
/*     */   
/*  94 */   private static Stack<ContextStackEntry> contextStack = new Stack<>();
/*     */ 
/*     */   
/*  97 */   private static Map<Integer, ContextFormatter> formatterMap = new HashMap<>();
/*     */   
/*  99 */   private static ContextFormatter defaultFormatter = new DefaultFormatter();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean multiThreaded = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void reset() {
/* 110 */     if (!multiThreaded) {
/* 111 */       contextMap.remove();
/* 112 */       contextStack.clear();
/* 113 */       formatterMap.clear();
/* 114 */       nextTokenId = 1;
/*     */     } else {
/* 116 */       contextMap.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setMultiThreaded(boolean mt) {
/* 123 */     multiThreaded = mt;
/*     */   }
/*     */   
/*     */   public static void registerFormatter(int phaseId, ContextFormatter aFormatter) {
/* 127 */     formatterMap.put(Integer.valueOf(phaseId), aFormatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCurrentContext() {
/* 134 */     Iterable<ContextStackEntry> contextStack = getContextStack();
/* 135 */     Stack<String> explanationStack = new Stack<>();
/* 136 */     for (ContextStackEntry entry : contextStack) {
/* 137 */       Object data = entry.getData();
/* 138 */       if (data != null) {
/* 139 */         explanationStack.push(getFormatter(entry).formatEntry(entry.phaseId, data));
/*     */       }
/*     */     } 
/* 142 */     StringBuilder sb = new StringBuilder();
/* 143 */     while (!explanationStack.isEmpty()) {
/* 144 */       sb.append("when ");
/* 145 */       sb.append(((String)explanationStack.pop()).toString());
/* 146 */       sb.append("\n");
/*     */     } 
/* 148 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCurrentContext(boolean prependNLIfNotEmpty) {
/* 157 */     String context = getCurrentContext();
/* 158 */     return context.isEmpty() ? context : ((prependNLIfNotEmpty ? "\n" : "") + context);
/*     */   }
/*     */   
/*     */   public static ContextToken enteringPhase(int phaseId, Object data) {
/* 162 */     Stack<ContextStackEntry> contextStack = getContextStack();
/* 163 */     ContextTokenImpl nextToken = nextToken();
/* 164 */     contextStack.push(new ContextStackEntry(nextToken, phaseId, new WeakReference(data)));
/* 165 */     return nextToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void leavingPhase(ContextToken aToken) {
/* 172 */     Stack<ContextStackEntry> contextStack = getContextStack();
/* 173 */     while (!contextStack.isEmpty()) {
/* 174 */       ContextStackEntry entry = contextStack.pop();
/* 175 */       if (entry.contextToken == aToken) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetForThread() {
/* 185 */     if (!multiThreaded) {
/*     */       return;
/*     */     }
/* 188 */     contextMap.remove();
/*     */   }
/*     */   
/*     */   private static Stack<ContextStackEntry> getContextStack() {
/* 192 */     if (!multiThreaded) {
/* 193 */       return CompilationAndWeavingContext.contextStack;
/*     */     }
/* 195 */     Stack<ContextStackEntry> contextStack = contextMap.get();
/* 196 */     if (contextStack == null) {
/* 197 */       contextStack = new Stack<>();
/* 198 */       contextMap.set(contextStack);
/*     */     } 
/* 200 */     return contextStack;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ContextTokenImpl nextToken() {
/* 205 */     return new ContextTokenImpl(nextTokenId++);
/*     */   }
/*     */   
/*     */   private static ContextFormatter getFormatter(ContextStackEntry entry) {
/* 209 */     Integer key = Integer.valueOf(entry.phaseId);
/* 210 */     if (formatterMap.containsKey(key)) {
/* 211 */       return formatterMap.get(key);
/*     */     }
/* 213 */     return defaultFormatter;
/*     */   }
/*     */   
/*     */   private static class ContextTokenImpl
/*     */     implements ContextToken {
/*     */     public int tokenId;
/*     */     
/*     */     public ContextTokenImpl(int id) {
/* 221 */       this.tokenId = id;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ContextStackEntry
/*     */   {
/*     */     public CompilationAndWeavingContext.ContextTokenImpl contextToken;
/*     */     public int phaseId;
/*     */     private WeakReference<Object> dataRef;
/*     */     
/*     */     public ContextStackEntry(CompilationAndWeavingContext.ContextTokenImpl ct, int phase, WeakReference<Object> data) {
/* 232 */       this.contextToken = ct;
/* 233 */       this.phaseId = phase;
/* 234 */       this.dataRef = data;
/*     */     }
/*     */     
/*     */     public Object getData() {
/* 238 */       return this.dataRef.get();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 242 */       Object data = getData();
/* 243 */       if (data == null) {
/* 244 */         return "referenced context entry has gone out of scope";
/*     */       }
/* 246 */       return CompilationAndWeavingContext.getFormatter(this).formatEntry(this.phaseId, data);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DefaultFormatter implements ContextFormatter {
/*     */     private DefaultFormatter() {}
/*     */     
/*     */     public String formatEntry(int phaseId, Object data) {
/* 254 */       StringBuilder sb = new StringBuilder();
/* 255 */       sb.append(CompilationAndWeavingContext.PHASE_NAMES[phaseId]);
/* 256 */       sb.append(" ");
/* 257 */       if (data instanceof char[]) {
/* 258 */         sb.append(new String((char[])data));
/*     */       } else {
/*     */         try {
/* 261 */           sb.append(data.toString());
/* 262 */         } catch (RuntimeException ex) {
/*     */           
/* 264 */           sb.append("** broken toString in data object **");
/*     */         } 
/*     */       } 
/* 267 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\context\CompilationAndWeavingContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */