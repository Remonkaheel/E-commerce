package org.aspectj.bridge;

public interface ILifecycleAware {
  void buildStarting(boolean paramBoolean);
  
  void buildFinished(boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\ILifecycleAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */