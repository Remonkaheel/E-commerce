/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeaveMessage
/*     */   extends Message
/*     */ {
/*  19 */   public static WeaveMessageKind WEAVEMESSAGE_DECLAREPARENTSIMPLEMENTS = new WeaveMessageKind(1, "Extending interface set for type '%1' (%2) to include '%3' (%4)");
/*     */ 
/*     */   
/*  22 */   public static WeaveMessageKind WEAVEMESSAGE_ITD = new WeaveMessageKind(2, "Type '%1' (%2) has intertyped %3 from '%4' (%5)");
/*     */ 
/*     */   
/*  25 */   public static WeaveMessageKind WEAVEMESSAGE_ADVISES = new WeaveMessageKind(3, "Join point '%1' in Type '%2' (%3) advised by %4 advice from '%5' (%6)%7");
/*     */ 
/*     */   
/*  28 */   public static WeaveMessageKind WEAVEMESSAGE_DECLAREPARENTSEXTENDS = new WeaveMessageKind(4, "Setting superclass of type '%1' (%2) to '%3' (%4)");
/*     */ 
/*     */   
/*  31 */   public static WeaveMessageKind WEAVEMESSAGE_SOFTENS = new WeaveMessageKind(5, "Softening exceptions in type '%1' (%2) as defined by aspect '%3' (%4)");
/*     */ 
/*     */   
/*  34 */   public static WeaveMessageKind WEAVEMESSAGE_ANNOTATES = new WeaveMessageKind(6, "'%1' (%2) is annotated with %3 %4 annotation from '%5' (%6)");
/*     */ 
/*     */   
/*  37 */   public static WeaveMessageKind WEAVEMESSAGE_MIXIN = new WeaveMessageKind(7, "Mixing interface '%1' (%2) into type '%3' (%4)");
/*     */   
/*  39 */   public static WeaveMessageKind WEAVEMESSAGE_REMOVES_ANNOTATION = new WeaveMessageKind(6, "'%1' (%2) has had %3 %4 annotation removed by '%5' (%6)");
/*     */ 
/*     */ 
/*     */   
/*     */   private String affectedTypeName;
/*     */ 
/*     */   
/*     */   private String aspectName;
/*     */ 
/*     */ 
/*     */   
/*     */   private WeaveMessage(String message, String affectedTypeName, String aspectName, ISourceLocation affectedTypeLocation, ISourceLocation aspectLocation) {
/*  51 */     super(message, null, IMessage.WEAVEINFO, affectedTypeLocation, null, new ISourceLocation[] { aspectLocation });
/*  52 */     this.affectedTypeName = affectedTypeName;
/*  53 */     this.aspectName = aspectName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WeaveMessage constructWeavingMessage(WeaveMessageKind kind, String[] inserts) {
/*  64 */     StringBuilder str = new StringBuilder(kind.getMessage());
/*  65 */     int pos = -1;
/*  66 */     while ((pos = (new String(str)).indexOf("%")) != -1) {
/*  67 */       int n = Character.getNumericValue(str.charAt(pos + 1));
/*  68 */       str.replace(pos, pos + 2, inserts[n - 1]);
/*     */     } 
/*  70 */     return new WeaveMessage(str.toString(), null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WeaveMessage constructWeavingMessage(WeaveMessageKind kind, String[] inserts, String affectedTypeName, String aspectName, ISourceLocation affectedTypeLocation, ISourceLocation aspectLocation) {
/*  89 */     StringBuilder str = new StringBuilder(kind.getMessage());
/*  90 */     int pos = -1;
/*  91 */     while ((pos = (new String(str)).indexOf("%")) != -1) {
/*  92 */       int n = Character.getNumericValue(str.charAt(pos + 1));
/*  93 */       str.replace(pos, pos + 2, inserts[n - 1]);
/*     */     } 
/*  95 */     return new WeaveMessage(str.toString(), affectedTypeName, aspectName, affectedTypeLocation, aspectLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAspectName() {
/* 102 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAffectedTypeName() {
/* 109 */     return this.affectedTypeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class WeaveMessageKind
/*     */   {
/*     */     private String message;
/*     */ 
/*     */     
/*     */     public WeaveMessageKind(int id, String message) {
/* 119 */       this.message = message;
/*     */     }
/*     */     
/*     */     public String getMessage() {
/* 123 */       return this.message;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\WeaveMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */