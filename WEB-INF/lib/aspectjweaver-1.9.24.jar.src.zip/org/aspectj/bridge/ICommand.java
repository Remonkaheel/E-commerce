package org.aspectj.bridge;

public interface ICommand {
  boolean runCommand(String[] paramArrayOfString, IMessageHandler paramIMessageHandler);
  
  boolean repeatCommand(IMessageHandler paramIMessageHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\ICommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */