package org.aspectj.bridge;

public interface IProgressListener {
  void setText(String paramString);
  
  void setProgress(double paramDouble);
  
  void setCancelledRequested(boolean paramBoolean);
  
  boolean isCancelledRequested();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\IProgressListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */