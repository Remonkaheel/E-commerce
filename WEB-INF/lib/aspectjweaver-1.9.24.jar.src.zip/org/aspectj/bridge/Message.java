/*     */ package org.aspectj.bridge;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Message
/*     */   implements IMessage
/*     */ {
/*     */   private final String message;
/*     */   private final IMessage.Kind kind;
/*     */   private final Throwable thrown;
/*     */   private final ISourceLocation sourceLocation;
/*     */   private final String details;
/*     */   private final List<ISourceLocation> extraSourceLocations;
/*     */   private final boolean declared;
/*     */   private final int id;
/*     */   private final int sourceStart;
/*     */   private final int sourceEnd;
/*     */   
/*     */   public Message(String message, ISourceLocation location, boolean isError) {
/*  42 */     this(message, isError ? IMessage.ERROR : IMessage.WARNING, (Throwable)null, location);
/*     */   }
/*     */   
/*     */   public Message(String message, ISourceLocation location, boolean isError, ISourceLocation[] extraSourceLocations) {
/*  46 */     this(message, "", isError ? IMessage.ERROR : IMessage.WARNING, location, null, 
/*  47 */         (extraSourceLocations.length > 0) ? extraSourceLocations : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message(String message, String details, IMessage.Kind kind, ISourceLocation sourceLocation, Throwable thrown, ISourceLocation[] extraSourceLocations) {
/*  63 */     this(message, details, kind, sourceLocation, thrown, extraSourceLocations, false, 0, -1, -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Message(String message, String details, IMessage.Kind kind, ISourceLocation sLoc, Throwable thrown, ISourceLocation[] otherLocs, boolean declared, int id, int sourcestart, int sourceend) {
/*  68 */     this.details = details;
/*  69 */     this.id = id;
/*  70 */     this.sourceStart = sourcestart;
/*  71 */     this.sourceEnd = sourceend;
/*  72 */     this.message = (message != null) ? message : ((thrown == null) ? null : thrown.getMessage());
/*  73 */     this.kind = kind;
/*  74 */     this.sourceLocation = sLoc;
/*  75 */     this.thrown = thrown;
/*  76 */     if (otherLocs != null) {
/*  77 */       this.extraSourceLocations = Collections.unmodifiableList(Arrays.asList(otherLocs));
/*     */     } else {
/*  79 */       this.extraSourceLocations = Collections.emptyList();
/*     */     } 
/*  81 */     if (null == this.kind) {
/*  82 */       throw new IllegalArgumentException("null kind");
/*     */     }
/*  84 */     if (null == this.message) {
/*  85 */       throw new IllegalArgumentException("null message");
/*     */     }
/*  87 */     this.declared = declared;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message(String message, IMessage.Kind kind, Throwable thrown, ISourceLocation sourceLocation) {
/* 101 */     this(message, "", kind, sourceLocation, thrown, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IMessage.Kind getKind() {
/* 106 */     return this.kind;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isError() {
/* 111 */     return (this.kind == IMessage.ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarning() {
/* 116 */     return (this.kind == IMessage.WARNING);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebug() {
/* 121 */     return (this.kind == IMessage.DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUsage() {
/* 128 */     return (this.kind == IMessage.USAGE);
/*     */   }
/*     */   
/*     */   public boolean isTaskTag() {
/* 132 */     return (this.kind == IMessage.TASKTAG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfo() {
/* 139 */     return (this.kind == IMessage.INFO);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAbort() {
/* 144 */     return (this.kind == IMessage.ABORT);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDeclared() {
/* 149 */     return this.declared;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFailed() {
/* 156 */     return (this.kind == IMessage.FAIL);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getMessage() {
/* 161 */     return this.message;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Throwable getThrown() {
/* 166 */     return this.thrown;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ISourceLocation getSourceLocation() {
/* 171 */     return this.sourceLocation;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 175 */     return MessageUtil.renderMessage(this, false);
/*     */   }
/*     */   
/*     */   public String getDetails() {
/* 179 */     return this.details;
/*     */   }
/*     */   
/*     */   public List<ISourceLocation> getExtraSourceLocations() {
/* 183 */     return this.extraSourceLocations;
/*     */   }
/*     */   
/*     */   public int getID() {
/* 187 */     return this.id;
/*     */   }
/*     */   
/*     */   public int getSourceStart() {
/* 191 */     return this.sourceStart;
/*     */   }
/*     */   
/*     */   public int getSourceEnd() {
/* 195 */     return this.sourceEnd;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\Message.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */