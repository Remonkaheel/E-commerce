/*    */ package org.aspectj.bridge;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReflectionFactory
/*    */ {
/*    */   public static final String OLD_AJC = "bridge.tools.impl.OldAjc";
/*    */   public static final String ECLIPSE = "org.aspectj.ajdt.ajc.AjdtCommand";
/* 26 */   private static final Object[] NONE = new Object[0];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ICommand makeCommand(String cname, IMessageHandler errorSink) {
/* 36 */     return (ICommand)make(ICommand.class, cname, NONE, errorSink);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Object make(Class<?> c, String cname, Object[] args, IMessageHandler errorSink) {
/* 44 */     boolean makeErrors = (null != errorSink);
/* 45 */     Object result = null;
/*    */     try {
/* 47 */       Class<?> cfn = Class.forName(cname);
/* 48 */       String error = null;
/* 49 */       if (args == NONE) {
/* 50 */         result = cfn.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*    */       } else {
/* 52 */         Class<?>[] types = getTypes(args);
/* 53 */         Constructor<?> constructor = cfn.getConstructor(types);
/* 54 */         if (null != constructor) {
/* 55 */           result = constructor.newInstance(args);
/*    */         }
/* 57 */         else if (makeErrors) {
/* 58 */           error = "no constructor for " + c + " using " + Arrays.<Class<?>>asList(types);
/*    */         } 
/*    */       } 
/*    */       
/* 62 */       if (null != result && 
/* 63 */         !c.isAssignableFrom(result.getClass())) {
/* 64 */         if (makeErrors) {
/* 65 */           error = "expecting type " + c + " got " + result.getClass();
/*    */         }
/* 67 */         result = null;
/*    */       } 
/*    */       
/* 70 */       if (null != error) {
/* 71 */         IMessage mssg = new Message(error, IMessage.FAIL, null, null);
/* 72 */         errorSink.handleMessage(mssg);
/*    */       } 
/* 74 */     } catch (Throwable t) {
/* 75 */       if (makeErrors) {
/* 76 */         String mssg = "ReflectionFactory unable to load " + cname + " as " + c.getName();
/* 77 */         IMessage m = new Message(mssg, IMessage.FAIL, t, null);
/* 78 */         errorSink.handleMessage(m);
/*    */       } 
/*    */     } 
/* 81 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Class<?>[] getTypes(Object[] args) {
/* 88 */     if (null == args || 0 < args.length) {
/* 89 */       return new Class[0];
/*    */     }
/* 91 */     Class<?>[] result = new Class[args.length];
/* 92 */     for (int i = 0; i < result.length; i++) {
/* 93 */       if (null != args[i]) {
/* 94 */         result[i] = args[i].getClass();
/*    */       }
/*    */     } 
/* 97 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\bridge\ReflectionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */