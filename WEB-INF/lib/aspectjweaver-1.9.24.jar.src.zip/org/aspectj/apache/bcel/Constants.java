/*     */ package org.aspectj.apache.bcel;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Constants
/*     */ {
/*     */   public static final int MAJOR_1_1 = 45;
/*     */   public static final int MINOR_1_1 = 3;
/*     */   public static final int MAJOR_1_5 = 49;
/*     */   public static final int MAJOR_1_6 = 50;
/*     */   public static final int MAJOR_1_8 = 52;
/*     */   public static final int MAX_SHORT = 65535;
/*     */   public static final int MAX_BYTE = 255;
/*     */   public static final short ACC_PUBLIC = 1;
/*     */   public static final short ACC_PRIVATE = 2;
/*     */   public static final short ACC_PROTECTED = 4;
/*     */   public static final short ACC_STATIC = 8;
/*     */   public static final short ACC_FINAL = 16;
/*     */   public static final short ACC_SYNCHRONIZED = 32;
/*     */   public static final short ACC_VOLATILE = 64;
/*     */   public static final short ACC_TRANSIENT = 128;
/*     */   public static final short ACC_NATIVE = 256;
/*     */   public static final short ACC_INTERFACE = 512;
/*     */   public static final short ACC_ABSTRACT = 1024;
/*     */   public static final short ACC_STRICT = 2048;
/*     */   public static final short ACC_SYNTHETIC = 4096;
/*     */   public static final short ACC_ANNOTATION = 8192;
/*     */   public static final short ACC_ENUM = 16384;
/*     */   public static final int ACC_MODULE = 32768;
/*     */   public static final short ACC_BRIDGE = 64;
/*     */   public static final short ACC_VARARGS = 128;
/*     */   public static final int MODULE_ACC_TRANSITIVE = 32;
/*     */   public static final int MODULE_ACC_STATIC_PHASE = 64;
/*     */   public static final int MODULE_ACC_SYNTHETIC = 4096;
/*     */   public static final int MODULE_ACC_MANDATED = 32768;
/*     */   public static final short ACC_SUPER = 32;
/*     */   public static final short MAX_ACC_FLAG = 2048;
/*     */   
/*     */   public static class ClassFileVersion
/*     */   {
/*  85 */     private static final Map<Integer, ClassFileVersion> cache = new ConcurrentHashMap<>();
/*     */     
/*     */     public final int MAJOR;
/*     */     public final int MINOR;
/*  89 */     public final int PREVIEW_MINOR = 65535;
/*     */     
/*     */     private ClassFileVersion(int major, int minor) {
/*  92 */       this.MAJOR = major;
/*  93 */       this.MINOR = minor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ClassFileVersion of(int javaMajor) {
/* 104 */       return of(javaMajor, 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ClassFileVersion of(int javaMajor, int javaMinor) {
/* 116 */       if (javaMajor < 1)
/* 117 */         throw new IllegalArgumentException("Java major version must be >= 1"); 
/* 118 */       if (javaMajor == 1) {
/* 119 */         if (javaMinor < 1 || javaMinor > 9) {
/* 120 */           throw new IllegalArgumentException("Java 1.x versions must be 1.1 to 1.9");
/*     */         }
/* 122 */         javaMajor = javaMinor;
/*     */       } 
/* 124 */       ClassFileVersion classFileVersion = cache.get(Integer.valueOf(javaMajor));
/* 125 */       if (classFileVersion == null) {
/* 126 */         classFileVersion = new ClassFileVersion(javaMajor + 44, (javaMajor == 1) ? 3 : 0);
/* 127 */         cache.put(Integer.valueOf(javaMajor), classFileVersion);
/*     */       } 
/* 129 */       return classFileVersion;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 134 */       if (this == o) return true; 
/* 135 */       if (!(o instanceof ClassFileVersion)) return false; 
/* 136 */       ClassFileVersion that = (ClassFileVersion)o;
/*     */       
/* 138 */       return (this.MAJOR == that.MAJOR && this.MINOR == that.MINOR);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 144 */       return Objects.hash(new Object[] { Integer.valueOf(this.MAJOR), Integer.valueOf(this.MINOR) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public static final String[] ACCESS_NAMES = new String[] { "public", "private", "protected", "static", "final", "synchronized", "volatile", "transient", "native", "interface", "abstract", "strictfp" };
/*     */   
/*     */   public static final byte CONSTANT_Utf8 = 1;
/*     */   
/*     */   public static final byte CONSTANT_Integer = 3;
/*     */   
/*     */   public static final byte CONSTANT_Float = 4;
/*     */   
/*     */   public static final byte CONSTANT_Long = 5;
/*     */   
/*     */   public static final byte CONSTANT_Double = 6;
/*     */   
/*     */   public static final byte CONSTANT_Class = 7;
/*     */   
/*     */   public static final byte CONSTANT_Fieldref = 9;
/*     */   public static final byte CONSTANT_String = 8;
/*     */   public static final byte CONSTANT_Methodref = 10;
/*     */   public static final byte CONSTANT_InterfaceMethodref = 11;
/*     */   public static final byte CONSTANT_NameAndType = 12;
/*     */   public static final byte CONSTANT_MethodHandle = 15;
/*     */   public static final byte CONSTANT_MethodType = 16;
/*     */   public static final byte CONSTANT_Dynamic = 17;
/*     */   public static final byte CONSTANT_InvokeDynamic = 18;
/*     */   public static final byte CONSTANT_Module = 19;
/*     */   public static final byte CONSTANT_Package = 20;
/* 222 */   public static final String[] CONSTANT_NAMES = new String[] { "", "CONSTANT_Utf8", "", "CONSTANT_Integer", "CONSTANT_Float", "CONSTANT_Long", "CONSTANT_Double", "CONSTANT_Class", "CONSTANT_String", "CONSTANT_Fieldref", "CONSTANT_Methodref", "CONSTANT_InterfaceMethodref", "CONSTANT_NameAndType", "", "", "CONSTANT_MethodHandle", "CONSTANT_MethodType", "CONSTANT_Dynamic", "CONSTANT_InvokeDynamic", "CONSTANT_Module", "CONSTANT_Package" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String STATIC_INITIALIZER_NAME = "<clinit>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONSTRUCTOR_NAME = "<init>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public static final String[] INTERFACES_IMPLEMENTED_BY_ARRAYS = new String[] { "java.lang.Cloneable", "java.io.Serializable" };
/*     */   
/*     */   public static final int MAX_CP_ENTRIES = 65535;
/*     */   
/*     */   public static final int MAX_CODE_SIZE = 65536;
/*     */   
/*     */   public static final short NOP = 0;
/*     */   
/*     */   public static final short ACONST_NULL = 1;
/*     */   
/*     */   public static final short ICONST_M1 = 2;
/*     */   
/*     */   public static final short ICONST_0 = 3;
/*     */   
/*     */   public static final short ICONST_1 = 4;
/*     */   
/*     */   public static final short ICONST_2 = 5;
/*     */   
/*     */   public static final short ICONST_3 = 6;
/*     */   
/*     */   public static final short ICONST_4 = 7;
/*     */   
/*     */   public static final short ICONST_5 = 8;
/*     */   
/*     */   public static final short LCONST_0 = 9;
/*     */   
/*     */   public static final short LCONST_1 = 10;
/*     */   
/*     */   public static final short FCONST_0 = 11;
/*     */   
/*     */   public static final short FCONST_1 = 12;
/*     */   
/*     */   public static final short FCONST_2 = 13;
/*     */   
/*     */   public static final short DCONST_0 = 14;
/*     */   
/*     */   public static final short DCONST_1 = 15;
/*     */   
/*     */   public static final short BIPUSH = 16;
/*     */   
/*     */   public static final short SIPUSH = 17;
/*     */   
/*     */   public static final short LDC = 18;
/*     */   
/*     */   public static final short LDC_W = 19;
/*     */   
/*     */   public static final short LDC2_W = 20;
/*     */   
/*     */   public static final short ILOAD = 21;
/*     */   
/*     */   public static final short LLOAD = 22;
/*     */   
/*     */   public static final short FLOAD = 23;
/*     */   public static final short DLOAD = 24;
/*     */   public static final short ALOAD = 25;
/*     */   public static final short ILOAD_0 = 26;
/*     */   public static final short ILOAD_1 = 27;
/*     */   public static final short ILOAD_2 = 28;
/*     */   public static final short ILOAD_3 = 29;
/*     */   public static final short LLOAD_0 = 30;
/*     */   public static final short LLOAD_1 = 31;
/*     */   public static final short LLOAD_2 = 32;
/*     */   public static final short LLOAD_3 = 33;
/*     */   public static final short FLOAD_0 = 34;
/*     */   public static final short FLOAD_1 = 35;
/*     */   public static final short FLOAD_2 = 36;
/*     */   public static final short FLOAD_3 = 37;
/*     */   public static final short DLOAD_0 = 38;
/*     */   public static final short DLOAD_1 = 39;
/*     */   public static final short DLOAD_2 = 40;
/*     */   public static final short DLOAD_3 = 41;
/*     */   public static final short ALOAD_0 = 42;
/*     */   public static final short ALOAD_1 = 43;
/*     */   public static final short ALOAD_2 = 44;
/*     */   public static final short ALOAD_3 = 45;
/*     */   public static final short IALOAD = 46;
/*     */   public static final short LALOAD = 47;
/*     */   public static final short FALOAD = 48;
/*     */   public static final short DALOAD = 49;
/*     */   public static final short AALOAD = 50;
/*     */   public static final short BALOAD = 51;
/*     */   public static final short CALOAD = 52;
/*     */   public static final short SALOAD = 53;
/*     */   public static final short ISTORE = 54;
/*     */   public static final short LSTORE = 55;
/*     */   public static final short FSTORE = 56;
/*     */   public static final short DSTORE = 57;
/*     */   public static final short ASTORE = 58;
/*     */   public static final short ISTORE_0 = 59;
/*     */   public static final short ISTORE_1 = 60;
/*     */   public static final short ISTORE_2 = 61;
/*     */   public static final short ISTORE_3 = 62;
/*     */   public static final short LSTORE_0 = 63;
/*     */   public static final short LSTORE_1 = 64;
/*     */   public static final short LSTORE_2 = 65;
/*     */   public static final short LSTORE_3 = 66;
/*     */   public static final short FSTORE_0 = 67;
/*     */   public static final short FSTORE_1 = 68;
/*     */   public static final short FSTORE_2 = 69;
/*     */   public static final short FSTORE_3 = 70;
/*     */   public static final short DSTORE_0 = 71;
/*     */   public static final short DSTORE_1 = 72;
/*     */   public static final short DSTORE_2 = 73;
/*     */   public static final short DSTORE_3 = 74;
/*     */   public static final short ASTORE_0 = 75;
/*     */   public static final short ASTORE_1 = 76;
/*     */   public static final short ASTORE_2 = 77;
/*     */   public static final short ASTORE_3 = 78;
/*     */   public static final short IASTORE = 79;
/*     */   public static final short LASTORE = 80;
/*     */   public static final short FASTORE = 81;
/*     */   public static final short DASTORE = 82;
/*     */   public static final short AASTORE = 83;
/*     */   public static final short BASTORE = 84;
/*     */   public static final short CASTORE = 85;
/*     */   public static final short SASTORE = 86;
/*     */   public static final short POP = 87;
/*     */   public static final short POP2 = 88;
/*     */   public static final short DUP = 89;
/*     */   public static final short DUP_X1 = 90;
/*     */   public static final short DUP_X2 = 91;
/*     */   public static final short DUP2 = 92;
/*     */   public static final short DUP2_X1 = 93;
/*     */   public static final short DUP2_X2 = 94;
/*     */   public static final short SWAP = 95;
/*     */   public static final short IADD = 96;
/*     */   public static final short LADD = 97;
/*     */   public static final short FADD = 98;
/*     */   public static final short DADD = 99;
/*     */   public static final short ISUB = 100;
/*     */   public static final short LSUB = 101;
/*     */   public static final short FSUB = 102;
/*     */   public static final short DSUB = 103;
/*     */   public static final short IMUL = 104;
/*     */   public static final short LMUL = 105;
/*     */   public static final short FMUL = 106;
/*     */   public static final short DMUL = 107;
/*     */   public static final short IDIV = 108;
/*     */   public static final short LDIV = 109;
/*     */   public static final short FDIV = 110;
/*     */   public static final short DDIV = 111;
/*     */   public static final short IREM = 112;
/*     */   public static final short LREM = 113;
/*     */   public static final short FREM = 114;
/*     */   public static final short DREM = 115;
/*     */   public static final short INEG = 116;
/*     */   public static final short LNEG = 117;
/*     */   public static final short FNEG = 118;
/*     */   public static final short DNEG = 119;
/*     */   public static final short ISHL = 120;
/*     */   public static final short LSHL = 121;
/*     */   public static final short ISHR = 122;
/*     */   public static final short LSHR = 123;
/*     */   public static final short IUSHR = 124;
/*     */   public static final short LUSHR = 125;
/*     */   public static final short IAND = 126;
/*     */   public static final short LAND = 127;
/*     */   public static final short IOR = 128;
/*     */   public static final short LOR = 129;
/*     */   public static final short IXOR = 130;
/*     */   public static final short LXOR = 131;
/*     */   public static final short IINC = 132;
/*     */   public static final short I2L = 133;
/*     */   public static final short I2F = 134;
/*     */   public static final short I2D = 135;
/*     */   public static final short L2I = 136;
/*     */   public static final short L2F = 137;
/*     */   public static final short L2D = 138;
/*     */   public static final short F2I = 139;
/*     */   public static final short F2L = 140;
/*     */   public static final short F2D = 141;
/*     */   public static final short D2I = 142;
/*     */   public static final short D2L = 143;
/*     */   public static final short D2F = 144;
/*     */   public static final short I2B = 145;
/*     */   public static final short INT2BYTE = 145;
/*     */   public static final short I2C = 146;
/*     */   public static final short INT2CHAR = 146;
/*     */   public static final short I2S = 147;
/*     */   public static final short INT2SHORT = 147;
/*     */   public static final short LCMP = 148;
/*     */   public static final short FCMPL = 149;
/*     */   public static final short FCMPG = 150;
/*     */   public static final short DCMPL = 151;
/*     */   public static final short DCMPG = 152;
/*     */   public static final short IFEQ = 153;
/*     */   public static final short IFNE = 154;
/*     */   public static final short IFLT = 155;
/*     */   public static final short IFGE = 156;
/*     */   public static final short IFGT = 157;
/*     */   public static final short IFLE = 158;
/*     */   public static final short IF_ICMPEQ = 159;
/*     */   public static final short IF_ICMPNE = 160;
/*     */   public static final short IF_ICMPLT = 161;
/*     */   public static final short IF_ICMPGE = 162;
/*     */   public static final short IF_ICMPGT = 163;
/*     */   public static final short IF_ICMPLE = 164;
/*     */   public static final short IF_ACMPEQ = 165;
/*     */   public static final short IF_ACMPNE = 166;
/*     */   public static final short GOTO = 167;
/*     */   public static final short JSR = 168;
/*     */   public static final short RET = 169;
/*     */   public static final short TABLESWITCH = 170;
/*     */   public static final short LOOKUPSWITCH = 171;
/*     */   public static final short IRETURN = 172;
/*     */   public static final short LRETURN = 173;
/*     */   public static final short FRETURN = 174;
/*     */   public static final short DRETURN = 175;
/*     */   public static final short ARETURN = 176;
/*     */   public static final short RETURN = 177;
/*     */   public static final short GETSTATIC = 178;
/*     */   public static final short PUTSTATIC = 179;
/*     */   public static final short GETFIELD = 180;
/*     */   public static final short PUTFIELD = 181;
/*     */   public static final short INVOKEVIRTUAL = 182;
/*     */   public static final short INVOKESPECIAL = 183;
/*     */   public static final short INVOKENONVIRTUAL = 183;
/*     */   public static final short INVOKESTATIC = 184;
/*     */   public static final short INVOKEINTERFACE = 185;
/*     */   public static final short INVOKEDYNAMIC = 186;
/*     */   public static final short NEW = 187;
/*     */   public static final short NEWARRAY = 188;
/*     */   public static final short ANEWARRAY = 189;
/*     */   public static final short ARRAYLENGTH = 190;
/*     */   public static final short ATHROW = 191;
/*     */   public static final short CHECKCAST = 192;
/*     */   public static final short INSTANCEOF = 193;
/*     */   public static final short MONITORENTER = 194;
/*     */   public static final short MONITOREXIT = 195;
/*     */   public static final short WIDE = 196;
/*     */   public static final short MULTIANEWARRAY = 197;
/*     */   public static final short IFNULL = 198;
/*     */   public static final short IFNONNULL = 199;
/*     */   public static final short GOTO_W = 200;
/*     */   public static final short JSR_W = 201;
/*     */   public static final short BREAKPOINT = 202;
/*     */   public static final short LDC_QUICK = 203;
/*     */   public static final short LDC_W_QUICK = 204;
/*     */   public static final short LDC2_W_QUICK = 205;
/*     */   public static final short GETFIELD_QUICK = 206;
/*     */   public static final short PUTFIELD_QUICK = 207;
/*     */   public static final short GETFIELD2_QUICK = 208;
/*     */   public static final short PUTFIELD2_QUICK = 209;
/*     */   public static final short GETSTATIC_QUICK = 210;
/*     */   public static final short PUTSTATIC_QUICK = 211;
/*     */   public static final short GETSTATIC2_QUICK = 212;
/*     */   public static final short PUTSTATIC2_QUICK = 213;
/*     */   public static final short INVOKEVIRTUAL_QUICK = 214;
/*     */   public static final short INVOKENONVIRTUAL_QUICK = 215;
/*     */   public static final short INVOKESUPER_QUICK = 216;
/*     */   public static final short INVOKESTATIC_QUICK = 217;
/*     */   public static final short INVOKEINTERFACE_QUICK = 218;
/*     */   public static final short INVOKEVIRTUALOBJECT_QUICK = 219;
/*     */   public static final short NEW_QUICK = 221;
/*     */   public static final short ANEWARRAY_QUICK = 222;
/*     */   public static final short MULTIANEWARRAY_QUICK = 223;
/*     */   public static final short CHECKCAST_QUICK = 224;
/*     */   public static final short INSTANCEOF_QUICK = 225;
/*     */   public static final short INVOKEVIRTUAL_QUICK_W = 226;
/*     */   public static final short GETFIELD_QUICK_W = 227;
/*     */   public static final short PUTFIELD_QUICK_W = 228;
/*     */   public static final short IMPDEP1 = 254;
/*     */   public static final short IMPDEP2 = 255;
/*     */   public static final short PUSH = 4711;
/*     */   public static final short SWITCH = 4712;
/*     */   public static final short UNDEFINED = -1;
/*     */   public static final short UNPREDICTABLE = -2;
/*     */   public static final short RESERVED = -3;
/*     */   public static final String ILLEGAL_OPCODE = "<illegal opcode>";
/*     */   public static final String ILLEGAL_TYPE = "<illegal type>";
/*     */   public static final byte T_BOOLEAN = 4;
/*     */   public static final byte T_CHAR = 5;
/*     */   public static final byte T_FLOAT = 6;
/*     */   public static final byte T_DOUBLE = 7;
/*     */   public static final byte T_BYTE = 8;
/*     */   public static final byte T_SHORT = 9;
/*     */   public static final byte T_INT = 10;
/*     */   public static final byte T_LONG = 11;
/*     */   public static final byte T_VOID = 12;
/*     */   public static final byte T_ARRAY = 13;
/*     */   public static final byte T_OBJECT = 14;
/*     */   public static final byte T_REFERENCE = 14;
/*     */   public static final byte T_UNKNOWN = 15;
/*     */   public static final byte T_ADDRESS = 16;
/* 525 */   public static final String[] TYPE_NAMES = new String[] { "<illegal type>", "<illegal type>", "<illegal type>", "<illegal type>", "boolean", "char", "float", "double", "byte", "short", "int", "long", "void", "array", "object", "unknown" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 532 */   public static final String[] CLASS_TYPE_NAMES = new String[] { "<illegal type>", "<illegal type>", "<illegal type>", "<illegal type>", "java.lang.Boolean", "java.lang.Character", "java.lang.Float", "java.lang.Double", "java.lang.Byte", "java.lang.Short", "java.lang.Integer", "java.lang.Long", "java.lang.Void", "<illegal type>", "<illegal type>", "<illegal type>" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 539 */   public static final String[] SHORT_TYPE_NAMES = new String[] { "<illegal type>", "<illegal type>", "<illegal type>", "<illegal type>", "Z", "C", "F", "D", "B", "S", "I", "J", "V", "<illegal type>", "<illegal type>", "<illegal type>" };
/*     */   
/*     */   public static final int PUSH_INST = 1;
/*     */   
/*     */   public static final int CONSTANT_INST = 2;
/*     */   
/*     */   public static final long LOADCLASS_INST = 4L;
/*     */   public static final int CP_INST = 8;
/*     */   public static final int INDEXED = 16;
/*     */   public static final int LOAD_INST = 32;
/*     */   public static final int LV_INST = 64;
/*     */   public static final int POP_INST = 128;
/*     */   public static final int STORE_INST = 256;
/*     */   public static final long STACK_INST = 512L;
/*     */   public static final long BRANCH_INSTRUCTION = 1024L;
/*     */   public static final long TARGETER_INSTRUCTION = 2048L;
/*     */   public static final long NEGATABLE = 4096L;
/*     */   public static final long IF_INST = 8192L;
/*     */   public static final long JSR_INSTRUCTION = 16384L;
/*     */   public static final long RET_INST = 32768L;
/*     */   public static final long EXCEPTION_THROWER = 65536L;
/* 560 */   public static final byte[] iLen = new byte[256];
/*     */   public static final byte UNDEFINED_LENGTH = 40;
/*     */   public static final byte VARIABLE_LENGTH = 38;
/* 563 */   public static final byte[] stackEntriesProduced = new byte[256];
/* 564 */   public static final Type[] types = new Type[256];
/* 565 */   public static final long[] instFlags = new long[256];
/*     */   
/* 567 */   public static final Class<Throwable>[][] instExcs = (Class<Throwable>[][])new Class[256][];
/*     */   
/* 569 */   public static final Object _unused = ConstantsInitializer.initialize();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 574 */   public static final short[][] TYPE_OF_OPERANDS = new short[][] { {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, { 8 }, { 9 }, { 8 }, { 9 }, { 9 }, { 8 }, { 8 }, { 8 }, { 8 }, { 8 }, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, { 8 }, { 8 }, { 8 }, { 8 }, { 8 }, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, { 8, 8 }, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 8 }, {}, {}, {}, {}, {}, {}, {}, {}, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9 }, { 9, 8, 8 }, {}, { 9 }, { 8 }, { 9 }, {}, {}, { 9 }, { 9 }, {}, {}, { 8 }, { 9, 8 }, { 9 }, { 9 }, { 10 }, { 10 }, {}, {}, {}, {}, {}, {}, {}, {}, 
/*     */       {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, 
/*     */       {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, 
/*     */       {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, 
/*     */       {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, 
/*     */       {}, {}, {}, {}, {}, {} };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 614 */   public static final String[] OPCODE_NAMES = new String[] { "nop", "aconst_null", "iconst_m1", "iconst_0", "iconst_1", "iconst_2", "iconst_3", "iconst_4", "iconst_5", "lconst_0", "lconst_1", "fconst_0", "fconst_1", "fconst_2", "dconst_0", "dconst_1", "bipush", "sipush", "ldc", "ldc_w", "ldc2_w", "iload", "lload", "fload", "dload", "aload", "iload_0", "iload_1", "iload_2", "iload_3", "lload_0", "lload_1", "lload_2", "lload_3", "fload_0", "fload_1", "fload_2", "fload_3", "dload_0", "dload_1", "dload_2", "dload_3", "aload_0", "aload_1", "aload_2", "aload_3", "iaload", "laload", "faload", "daload", "aaload", "baload", "caload", "saload", "istore", "lstore", "fstore", "dstore", "astore", "istore_0", "istore_1", "istore_2", "istore_3", "lstore_0", "lstore_1", "lstore_2", "lstore_3", "fstore_0", "fstore_1", "fstore_2", "fstore_3", "dstore_0", "dstore_1", "dstore_2", "dstore_3", "astore_0", "astore_1", "astore_2", "astore_3", "iastore", "lastore", "fastore", "dastore", "aastore", "bastore", "castore", "sastore", "pop", "pop2", "dup", "dup_x1", "dup_x2", "dup2", "dup2_x1", "dup2_x2", "swap", "iadd", "ladd", "fadd", "dadd", "isub", "lsub", "fsub", "dsub", "imul", "lmul", "fmul", "dmul", "idiv", "ldiv", "fdiv", "ddiv", "irem", "lrem", "frem", "drem", "ineg", "lneg", "fneg", "dneg", "ishl", "lshl", "ishr", "lshr", "iushr", "lushr", "iand", "land", "ior", "lor", "ixor", "lxor", "iinc", "i2l", "i2f", "i2d", "l2i", "l2f", "l2d", "f2i", "f2l", "f2d", "d2i", "d2l", "d2f", "i2b", "i2c", "i2s", "lcmp", "fcmpl", "fcmpg", "dcmpl", "dcmpg", "ifeq", "ifne", "iflt", "ifge", "ifgt", "ifle", "if_icmpeq", "if_icmpne", "if_icmplt", "if_icmpge", "if_icmpgt", "if_icmple", "if_acmpeq", "if_acmpne", "goto", "jsr", "ret", "tableswitch", "lookupswitch", "ireturn", "lreturn", "freturn", "dreturn", "areturn", "return", "getstatic", "putstatic", "getfield", "putfield", "invokevirtual", "invokespecial", "invokestatic", "invokeinterface", "invokedynamic", "new", "newarray", "anewarray", "arraylength", "athrow", "checkcast", "instanceof", "monitorenter", "monitorexit", "wide", "multianewarray", "ifnull", "ifnonnull", "goto_w", "jsr_w", "breakpoint", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "<illegal opcode>", "impdep1", "impdep2" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 644 */   public static final int[] CONSUME_STACK = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 3, 4, 3, 4, 3, 3, 3, 3, 1, 2, 1, 2, 3, 2, 3, 4, 2, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 1, 2, 1, 2, 2, 3, 2, 3, 2, 3, 2, 4, 2, 4, 2, 4, 0, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 4, 2, 2, 4, 4, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 1, 1, 1, 2, 1, 2, 1, 0, 0, -2, 1, -2, -2, -2, -2, -2, -1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, -2, 1, 1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -2, -2 };
/*     */ 
/*     */   
/*     */   public static final byte ATTR_UNKNOWN = -1;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_SOURCE_FILE = 0;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_CONSTANT_VALUE = 1;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_CODE = 2;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_EXCEPTIONS = 3;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_LINE_NUMBER_TABLE = 4;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_LOCAL_VARIABLE_TABLE = 5;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_INNER_CLASSES = 6;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_SYNTHETIC = 7;
/*     */ 
/*     */   
/*     */   public static final byte ATTR_DEPRECATED = 8;
/*     */   
/*     */   public static final byte ATTR_PMG = 9;
/*     */   
/*     */   public static final byte ATTR_SIGNATURE = 10;
/*     */   
/*     */   public static final byte ATTR_STACK_MAP = 11;
/*     */   
/*     */   public static final byte ATTR_RUNTIME_VISIBLE_ANNOTATIONS = 12;
/*     */   
/*     */   public static final byte ATTR_RUNTIME_INVISIBLE_ANNOTATIONS = 13;
/*     */   
/*     */   public static final byte ATTR_RUNTIME_VISIBLE_PARAMETER_ANNOTATIONS = 14;
/*     */   
/*     */   public static final byte ATTR_RUNTIME_INVISIBLE_PARAMETER_ANNOTATIONS = 15;
/*     */   
/*     */   public static final byte ATTR_LOCAL_VARIABLE_TYPE_TABLE = 16;
/*     */   
/*     */   public static final byte ATTR_ENCLOSING_METHOD = 17;
/*     */   
/*     */   public static final byte ATTR_ANNOTATION_DEFAULT = 18;
/*     */   
/*     */   public static final byte ATTR_BOOTSTRAPMETHODS = 19;
/*     */   
/*     */   public static final byte ATTR_RUNTIME_VISIBLE_TYPE_ANNOTATIONS = 20;
/*     */   
/*     */   public static final byte ATTR_RUNTIME_INVISIBLE_TYPE_ANNOTATIONS = 21;
/*     */   
/*     */   public static final byte ATTR_METHOD_PARAMETERS = 22;
/*     */   
/*     */   public static final byte ATTR_MODULE = 23;
/*     */   
/*     */   public static final byte ATTR_MODULE_PACKAGES = 24;
/*     */   
/*     */   public static final byte ATTR_MODULE_MAIN_CLASS = 25;
/*     */   
/*     */   public static final byte ATTR_NEST_HOST = 26;
/*     */   
/*     */   public static final byte ATTR_NEST_MEMBERS = 27;
/*     */   
/*     */   public static final short KNOWN_ATTRIBUTES = 28;
/*     */   
/* 716 */   public static final String[] ATTRIBUTE_NAMES = new String[] { "SourceFile", "ConstantValue", "Code", "Exceptions", "LineNumberTable", "LocalVariableTable", "InnerClasses", "Synthetic", "Deprecated", "PMGClass", "Signature", "StackMap", "RuntimeVisibleAnnotations", "RuntimeInvisibleAnnotations", "RuntimeVisibleParameterAnnotations", "RuntimeInvisibleParameterAnnotations", "LocalVariableTypeTable", "EnclosingMethod", "AnnotationDefault", "BootstrapMethods", "RuntimeVisibleTypeAnnotations", "RuntimeInvisibleTypeAnnotations", "MethodParameters", "Module", "ModulePackages", "ModuleMainClass", "NestHost", "NestMembers" };
/*     */ 
/*     */   
/*     */   public static final byte ITEM_Bogus = 0;
/*     */ 
/*     */   
/*     */   public static final byte ITEM_Integer = 1;
/*     */   
/*     */   public static final byte ITEM_Float = 2;
/*     */   
/*     */   public static final byte ITEM_Double = 3;
/*     */   
/*     */   public static final byte ITEM_Long = 4;
/*     */   
/*     */   public static final byte ITEM_Null = 5;
/*     */   
/*     */   public static final byte ITEM_InitObject = 6;
/*     */   
/*     */   public static final byte ITEM_Object = 7;
/*     */   
/*     */   public static final byte ITEM_NewObject = 8;
/*     */   
/* 738 */   public static final String[] ITEM_NAMES = new String[] { "Bogus", "Integer", "Float", "Double", "Long", "Null", "InitObject", "Object", "NewObject" };
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */