/*    */ package org.aspectj.apache.bcel.util;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.DataInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ByteSequence
/*    */   extends DataInputStream
/*    */ {
/*    */   private ByteArrayStream byte_stream;
/*    */   
/*    */   public ByteSequence(byte[] bytes) {
/* 71 */     super(new ByteArrayStream(bytes));
/* 72 */     this.byte_stream = (ByteArrayStream)this.in;
/*    */   }
/*    */   
/* 75 */   public final int getIndex() { return this.byte_stream.getPosition(); } final void unreadByte() {
/* 76 */     this.byte_stream.unreadByte();
/*    */   }
/*    */   private static final class ByteArrayStream extends ByteArrayInputStream {
/* 79 */     ByteArrayStream(byte[] bytes) { super(bytes); }
/* 80 */     final int getPosition() { return this.pos; } final void unreadByte() {
/* 81 */       if (this.pos > 0) this.pos--; 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bce\\util\ByteSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */