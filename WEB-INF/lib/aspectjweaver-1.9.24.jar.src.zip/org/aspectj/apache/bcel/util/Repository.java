package org.aspectj.apache.bcel.util;

import org.aspectj.apache.bcel.classfile.JavaClass;

public interface Repository {
  void storeClass(JavaClass paramJavaClass);
  
  void removeClass(JavaClass paramJavaClass);
  
  JavaClass findClass(String paramString);
  
  JavaClass loadClass(String paramString) throws ClassNotFoundException;
  
  JavaClass loadClass(Class paramClass) throws ClassNotFoundException;
  
  void clear();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bce\\util\Repository.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */