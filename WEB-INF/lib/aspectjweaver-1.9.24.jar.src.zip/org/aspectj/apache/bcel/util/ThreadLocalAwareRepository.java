/*     */ package org.aspectj.apache.bcel.util;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadLocalAwareRepository
/*     */   implements Repository
/*     */ {
/*  63 */   private static ThreadLocal<WeakReference<Repository>> threadLocal = new ThreadLocal<>();
/*     */   
/*     */   public static void setCurrentRepository(Repository repository) {
/*  66 */     threadLocal.set(new WeakReference<>(repository));
/*     */   }
/*     */   
/*     */   private static Repository currentRepository() {
/*  70 */     WeakReference<Repository> ref = threadLocal.get();
/*  71 */     Repository repo = null;
/*  72 */     if (ref != null) {
/*  73 */       repo = ref.get();
/*     */     }
/*  75 */     if (repo == null) {
/*  76 */       repo = SyntheticRepository.getInstance();
/*     */     }
/*  78 */     return repo;
/*     */   }
/*     */ 
/*     */   
/*     */   public void storeClass(JavaClass clazz) {
/*  83 */     currentRepository().storeClass(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeClass(JavaClass clazz) {
/*  88 */     currentRepository().removeClass(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaClass findClass(String className) {
/*  93 */     return currentRepository().findClass(className);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(String className) throws ClassNotFoundException {
/*  98 */     return currentRepository().loadClass(className);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(Class clazz) throws ClassNotFoundException {
/* 103 */     return currentRepository().loadClass(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 108 */     currentRepository().clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bce\\util\ThreadLocalAwareRepository.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */