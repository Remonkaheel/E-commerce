/*     */ package org.aspectj.apache.bcel.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.WeakHashMap;
/*     */ import org.aspectj.apache.bcel.classfile.ClassParser;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyntheticRepository
/*     */   implements Repository
/*     */ {
/*  81 */   private static final String DEFAULT_PATH = ClassPath.getClassPath();
/*     */   
/*  83 */   private static HashMap<ClassPath, SyntheticRepository> _instances = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  87 */   private ClassPath _path = null;
/*  88 */   private WeakHashMap<String, JavaClass> _loadedClasses = new WeakHashMap<>();
/*     */   
/*     */   private SyntheticRepository(ClassPath path) {
/*  91 */     this._path = path;
/*     */   }
/*     */   
/*     */   public static SyntheticRepository getInstance() {
/*  95 */     return getInstance(ClassPath.getSystemClassPath());
/*     */   }
/*     */   
/*     */   public static SyntheticRepository getInstance(ClassPath classPath) {
/*  99 */     SyntheticRepository rep = _instances.get(classPath);
/*     */     
/* 101 */     if (rep == null) {
/* 102 */       rep = new SyntheticRepository(classPath);
/* 103 */       _instances.put(classPath, rep);
/*     */     } 
/*     */     
/* 106 */     return rep;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeClass(JavaClass clazz) {
/* 113 */     this._loadedClasses.put(clazz.getClassName(), clazz);
/* 114 */     clazz.setRepository(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeClass(JavaClass clazz) {
/* 121 */     this._loadedClasses.remove(clazz.getClassName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass findClass(String className) {
/* 128 */     return this._loadedClasses.get(className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(String className) throws ClassNotFoundException {
/* 135 */     if (className == null || className.equals("")) {
/* 136 */       throw new IllegalArgumentException("Invalid class name " + className);
/*     */     }
/*     */     
/* 139 */     className = className.replace('/', '.');
/*     */     
/*     */     try {
/* 142 */       return loadClass(this._path.getInputStream(className), className);
/* 143 */     } catch (IOException e) {
/* 144 */       throw new ClassNotFoundException("Exception while looking for class " + className + ": " + e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(Class clazz) throws ClassNotFoundException {
/* 155 */     String className = clazz.getName();
/* 156 */     String name = className;
/* 157 */     int i = name.lastIndexOf('.');
/*     */     
/* 159 */     if (i > 0) {
/* 160 */       name = name.substring(i + 1);
/*     */     }
/*     */     
/* 163 */     return loadClass(clazz.getResourceAsStream(name + ".class"), className);
/*     */   }
/*     */   
/*     */   private JavaClass loadClass(InputStream is, String className) throws ClassNotFoundException {
/* 167 */     JavaClass clazz = findClass(className);
/*     */     
/* 169 */     if (clazz != null) {
/* 170 */       return clazz;
/*     */     }
/*     */     
/*     */     try {
/* 174 */       if (is != null) {
/* 175 */         ClassParser parser = new ClassParser(is, className);
/* 176 */         clazz = parser.parse();
/*     */         
/* 178 */         storeClass(clazz);
/*     */         
/* 180 */         return clazz;
/*     */       } 
/* 182 */     } catch (IOException e) {
/* 183 */       throw new ClassNotFoundException("Exception while looking for class " + className + ": " + e.toString());
/*     */     } 
/*     */     
/* 186 */     throw new ClassNotFoundException("SyntheticRepository could not load " + className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 193 */     this._loadedClasses.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bce\\util\SyntheticRepository.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */