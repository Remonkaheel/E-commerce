/*    */ package org.aspectj.apache.bcel.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultClassLoaderReference
/*    */   implements ClassLoaderReference
/*    */ {
/*    */   private ClassLoader loader;
/*    */   
/*    */   public DefaultClassLoaderReference(ClassLoader classLoader) {
/* 68 */     this.loader = classLoader;
/*    */   }
/*    */   
/*    */   public ClassLoader getClassLoader() {
/* 72 */     return this.loader;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bce\\util\DefaultClassLoaderReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */