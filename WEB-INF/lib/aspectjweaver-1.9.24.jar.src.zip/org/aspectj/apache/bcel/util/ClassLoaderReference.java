package org.aspectj.apache.bcel.util;

public interface ClassLoaderReference {
  ClassLoader getClassLoader();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bce\\util\ClassLoaderReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */