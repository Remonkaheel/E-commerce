package org.aspectj.apache.bcel.generic;

public interface InstVisitor {
  void visitStackInstruction(Instruction paramInstruction);
  
  void visitLocalVariableInstruction(InstructionLV paramInstructionLV);
  
  void visitBranchInstruction(InstructionBranch paramInstructionBranch);
  
  void visitLoadClass(Instruction paramInstruction);
  
  void visitFieldInstruction(Instruction paramInstruction);
  
  void visitIfInstruction(Instruction paramInstruction);
  
  void visitConversionInstruction(Instruction paramInstruction);
  
  void visitPopInstruction(Instruction paramInstruction);
  
  void visitStoreInstruction(Instruction paramInstruction);
  
  void visitTypedInstruction(Instruction paramInstruction);
  
  void visitSelect(InstructionSelect paramInstructionSelect);
  
  void visitJsrInstruction(InstructionBranch paramInstructionBranch);
  
  void visitGotoInstruction(Instruction paramInstruction);
  
  void visitUnconditionalBranch(Instruction paramInstruction);
  
  void visitPushInstruction(Instruction paramInstruction);
  
  void visitArithmeticInstruction(Instruction paramInstruction);
  
  void visitCPInstruction(Instruction paramInstruction);
  
  void visitInvokeInstruction(InvokeInstruction paramInvokeInstruction);
  
  void visitArrayInstruction(Instruction paramInstruction);
  
  void visitAllocationInstruction(Instruction paramInstruction);
  
  void visitReturnInstruction(Instruction paramInstruction);
  
  void visitFieldOrMethod(Instruction paramInstruction);
  
  void visitConstantPushInstruction(Instruction paramInstruction);
  
  void visitExceptionThrower(Instruction paramInstruction);
  
  void visitLoadInstruction(Instruction paramInstruction);
  
  void visitVariableLengthInstruction(Instruction paramInstruction);
  
  void visitStackProducer(Instruction paramInstruction);
  
  void visitStackConsumer(Instruction paramInstruction);
  
  void visitACONST_NULL(Instruction paramInstruction);
  
  void visitGETSTATIC(FieldInstruction paramFieldInstruction);
  
  void visitIF_ICMPLT(Instruction paramInstruction);
  
  void visitMONITOREXIT(Instruction paramInstruction);
  
  void visitIFLT(Instruction paramInstruction);
  
  void visitLSTORE(Instruction paramInstruction);
  
  void visitPOP2(Instruction paramInstruction);
  
  void visitBASTORE(Instruction paramInstruction);
  
  void visitISTORE(Instruction paramInstruction);
  
  void visitCHECKCAST(Instruction paramInstruction);
  
  void visitFCMPG(Instruction paramInstruction);
  
  void visitI2F(Instruction paramInstruction);
  
  void visitATHROW(Instruction paramInstruction);
  
  void visitDCMPL(Instruction paramInstruction);
  
  void visitARRAYLENGTH(Instruction paramInstruction);
  
  void visitDUP(Instruction paramInstruction);
  
  void visitINVOKESTATIC(InvokeInstruction paramInvokeInstruction);
  
  void visitLCONST(Instruction paramInstruction);
  
  void visitDREM(Instruction paramInstruction);
  
  void visitIFGE(Instruction paramInstruction);
  
  void visitCALOAD(Instruction paramInstruction);
  
  void visitLASTORE(Instruction paramInstruction);
  
  void visitI2D(Instruction paramInstruction);
  
  void visitDADD(Instruction paramInstruction);
  
  void visitINVOKESPECIAL(InvokeInstruction paramInvokeInstruction);
  
  void visitIAND(Instruction paramInstruction);
  
  void visitPUTFIELD(FieldInstruction paramFieldInstruction);
  
  void visitILOAD(Instruction paramInstruction);
  
  void visitDLOAD(Instruction paramInstruction);
  
  void visitDCONST(Instruction paramInstruction);
  
  void visitNEW(Instruction paramInstruction);
  
  void visitIFNULL(Instruction paramInstruction);
  
  void visitLSUB(Instruction paramInstruction);
  
  void visitL2I(Instruction paramInstruction);
  
  void visitISHR(Instruction paramInstruction);
  
  void visitTABLESWITCH(TABLESWITCH paramTABLESWITCH);
  
  void visitIINC(IINC paramIINC);
  
  void visitDRETURN(Instruction paramInstruction);
  
  void visitFSTORE(Instruction paramInstruction);
  
  void visitDASTORE(Instruction paramInstruction);
  
  void visitIALOAD(Instruction paramInstruction);
  
  void visitDDIV(Instruction paramInstruction);
  
  void visitIF_ICMPGE(Instruction paramInstruction);
  
  void visitLAND(Instruction paramInstruction);
  
  void visitIDIV(Instruction paramInstruction);
  
  void visitLOR(Instruction paramInstruction);
  
  void visitCASTORE(Instruction paramInstruction);
  
  void visitFREM(Instruction paramInstruction);
  
  void visitLDC(Instruction paramInstruction);
  
  void visitBIPUSH(Instruction paramInstruction);
  
  void visitDSTORE(Instruction paramInstruction);
  
  void visitF2L(Instruction paramInstruction);
  
  void visitFMUL(Instruction paramInstruction);
  
  void visitLLOAD(Instruction paramInstruction);
  
  void visitJSR(InstructionBranch paramInstructionBranch);
  
  void visitFSUB(Instruction paramInstruction);
  
  void visitSASTORE(Instruction paramInstruction);
  
  void visitALOAD(Instruction paramInstruction);
  
  void visitDUP2_X2(Instruction paramInstruction);
  
  void visitRETURN(Instruction paramInstruction);
  
  void visitDALOAD(Instruction paramInstruction);
  
  void visitSIPUSH(Instruction paramInstruction);
  
  void visitDSUB(Instruction paramInstruction);
  
  void visitL2F(Instruction paramInstruction);
  
  void visitIF_ICMPGT(Instruction paramInstruction);
  
  void visitF2D(Instruction paramInstruction);
  
  void visitI2L(Instruction paramInstruction);
  
  void visitIF_ACMPNE(Instruction paramInstruction);
  
  void visitPOP(Instruction paramInstruction);
  
  void visitI2S(Instruction paramInstruction);
  
  void visitIFEQ(Instruction paramInstruction);
  
  void visitSWAP(Instruction paramInstruction);
  
  void visitIOR(Instruction paramInstruction);
  
  void visitIREM(Instruction paramInstruction);
  
  void visitIASTORE(Instruction paramInstruction);
  
  void visitNEWARRAY(Instruction paramInstruction);
  
  void visitINVOKEINTERFACE(INVOKEINTERFACE paramINVOKEINTERFACE);
  
  void visitINEG(Instruction paramInstruction);
  
  void visitLCMP(Instruction paramInstruction);
  
  void visitJSR_W(InstructionBranch paramInstructionBranch);
  
  void visitMULTIANEWARRAY(MULTIANEWARRAY paramMULTIANEWARRAY);
  
  void visitDUP_X2(Instruction paramInstruction);
  
  void visitSALOAD(Instruction paramInstruction);
  
  void visitIFNONNULL(Instruction paramInstruction);
  
  void visitDMUL(Instruction paramInstruction);
  
  void visitIFNE(Instruction paramInstruction);
  
  void visitIF_ICMPLE(Instruction paramInstruction);
  
  void visitLDC2_W(Instruction paramInstruction);
  
  void visitGETFIELD(FieldInstruction paramFieldInstruction);
  
  void visitLADD(Instruction paramInstruction);
  
  void visitNOP(Instruction paramInstruction);
  
  void visitFALOAD(Instruction paramInstruction);
  
  void visitINSTANCEOF(Instruction paramInstruction);
  
  void visitIFLE(Instruction paramInstruction);
  
  void visitLXOR(Instruction paramInstruction);
  
  void visitLRETURN(Instruction paramInstruction);
  
  void visitFCONST(Instruction paramInstruction);
  
  void visitIUSHR(Instruction paramInstruction);
  
  void visitBALOAD(Instruction paramInstruction);
  
  void visitDUP2(Instruction paramInstruction);
  
  void visitIF_ACMPEQ(Instruction paramInstruction);
  
  void visitIMPDEP1(Instruction paramInstruction);
  
  void visitMONITORENTER(Instruction paramInstruction);
  
  void visitLSHL(Instruction paramInstruction);
  
  void visitDCMPG(Instruction paramInstruction);
  
  void visitD2L(Instruction paramInstruction);
  
  void visitIMPDEP2(Instruction paramInstruction);
  
  void visitL2D(Instruction paramInstruction);
  
  void visitRET(RET paramRET);
  
  void visitIFGT(Instruction paramInstruction);
  
  void visitIXOR(Instruction paramInstruction);
  
  void visitINVOKEVIRTUAL(InvokeInstruction paramInvokeInstruction);
  
  void visitFASTORE(Instruction paramInstruction);
  
  void visitIRETURN(Instruction paramInstruction);
  
  void visitIF_ICMPNE(Instruction paramInstruction);
  
  void visitFLOAD(Instruction paramInstruction);
  
  void visitLDIV(Instruction paramInstruction);
  
  void visitPUTSTATIC(FieldInstruction paramFieldInstruction);
  
  void visitAALOAD(Instruction paramInstruction);
  
  void visitD2I(Instruction paramInstruction);
  
  void visitIF_ICMPEQ(Instruction paramInstruction);
  
  void visitAASTORE(Instruction paramInstruction);
  
  void visitARETURN(Instruction paramInstruction);
  
  void visitDUP2_X1(Instruction paramInstruction);
  
  void visitFNEG(Instruction paramInstruction);
  
  void visitGOTO_W(Instruction paramInstruction);
  
  void visitD2F(Instruction paramInstruction);
  
  void visitGOTO(Instruction paramInstruction);
  
  void visitISUB(Instruction paramInstruction);
  
  void visitF2I(Instruction paramInstruction);
  
  void visitDNEG(Instruction paramInstruction);
  
  void visitICONST(Instruction paramInstruction);
  
  void visitFDIV(Instruction paramInstruction);
  
  void visitI2B(Instruction paramInstruction);
  
  void visitLNEG(Instruction paramInstruction);
  
  void visitLREM(Instruction paramInstruction);
  
  void visitIMUL(Instruction paramInstruction);
  
  void visitIADD(Instruction paramInstruction);
  
  void visitLSHR(Instruction paramInstruction);
  
  void visitLOOKUPSWITCH(LOOKUPSWITCH paramLOOKUPSWITCH);
  
  void visitDUP_X1(Instruction paramInstruction);
  
  void visitFCMPL(Instruction paramInstruction);
  
  void visitI2C(Instruction paramInstruction);
  
  void visitLMUL(Instruction paramInstruction);
  
  void visitLUSHR(Instruction paramInstruction);
  
  void visitISHL(Instruction paramInstruction);
  
  void visitLALOAD(Instruction paramInstruction);
  
  void visitASTORE(Instruction paramInstruction);
  
  void visitANEWARRAY(Instruction paramInstruction);
  
  void visitFRETURN(Instruction paramInstruction);
  
  void visitFADD(Instruction paramInstruction);
  
  void visitBREAKPOINT(Instruction paramInstruction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */