/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.Constant;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantDouble;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantFloat;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantInteger;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantLong;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantString;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionCP
/*     */   extends Instruction
/*     */ {
/*     */   protected int index;
/*     */   
/*     */   public InstructionCP(short opcode, int index) {
/*  81 */     super(opcode);
/*  82 */     this.index = index;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  87 */     if (this.opcode == 19 && this.index < 256) {
/*  88 */       out.writeByte(18);
/*  89 */       out.writeByte(this.index);
/*     */     } else {
/*  91 */       out.writeByte(this.opcode);
/*  92 */       if (Constants.iLen[this.opcode] == 2) {
/*  93 */         if (this.index > 255) {
/*  94 */           throw new IllegalStateException();
/*     */         }
/*  96 */         out.writeByte(this.index);
/*     */       } else {
/*  98 */         out.writeShort(this.index);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 105 */     if (this.opcode == 19 && this.index < 256) {
/* 106 */       return 2;
/*     */     }
/* 108 */     return super.getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 123 */     return super.toString(verbose) + " " + this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(ConstantPool cp) {
/* 130 */     Constant c = cp.getConstant(this.index);
/* 131 */     String str = cp.constantToString(c);
/*     */     
/* 133 */     if (c instanceof org.aspectj.apache.bcel.classfile.ConstantClass) {
/* 134 */       str = str.replace('.', '/');
/*     */     }
/*     */     
/* 137 */     return Constants.OPCODE_NAMES[this.opcode] + " " + str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getIndex() {
/* 145 */     return this.index;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIndex(int index) {
/* 150 */     this.index = index;
/* 151 */     if (this.index > 255 && this.opcode == 18)
/*     */     {
/* 153 */       this.opcode = 19;
/*     */     }
/*     */   }
/*     */   
/*     */   public Type getType(ConstantPool cpg) {
/*     */     String name;
/* 159 */     switch (cpg.getConstant(this.index).getTag()) {
/*     */       case 8:
/* 161 */         return Type.STRING;
/*     */       case 4:
/* 163 */         return Type.FLOAT;
/*     */       case 3:
/* 165 */         return Type.INT;
/*     */       case 5:
/* 167 */         return Type.LONG;
/*     */       case 6:
/* 169 */         return Type.DOUBLE;
/*     */       case 7:
/* 171 */         name = cpg.getConstantString_CONSTANTClass(this.index);
/*     */ 
/*     */         
/* 174 */         if (!name.startsWith("[")) {
/* 175 */           StringBuilder sb = new StringBuilder();
/* 176 */           sb.append("L").append(name).append(";");
/* 177 */           return Type.getType(sb.toString());
/*     */         } 
/* 179 */         return Type.getType(name);
/*     */     } 
/*     */     
/* 182 */     throw new RuntimeException("Unknown or invalid constant type at " + this.index);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(ConstantPool constantPool) {
/*     */     int i;
/* 188 */     Constant constant = constantPool.getConstant(this.index);
/*     */     
/* 190 */     switch (constant.getTag()) {
/*     */       case 8:
/* 192 */         i = ((ConstantString)constant).getStringIndex();
/* 193 */         constant = constantPool.getConstant(i);
/* 194 */         return ((ConstantUtf8)constant).getValue();
/*     */       
/*     */       case 4:
/* 197 */         return ((ConstantFloat)constant).getValue();
/*     */       
/*     */       case 3:
/* 200 */         return ((ConstantInteger)constant).getValue();
/*     */       
/*     */       case 5:
/* 203 */         return ((ConstantLong)constant).getValue();
/*     */       
/*     */       case 6:
/* 206 */         return ((ConstantDouble)constant).getValue();
/*     */     } 
/* 208 */     throw new RuntimeException("Unknown or invalid constant type at " + this.index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 213 */     if (!(other instanceof InstructionCP)) {
/* 214 */       return false;
/*     */     }
/* 216 */     InstructionCP o = (InstructionCP)other;
/* 217 */     return (o.opcode == this.opcode && o.index == this.index);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 221 */     return this.opcode * 37 + this.index;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionCP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */