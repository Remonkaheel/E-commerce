/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.aspectj.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionHandle
/*     */   implements Serializable
/*     */ {
/*     */   InstructionHandle next;
/*     */   InstructionHandle prev;
/*     */   Instruction instruction;
/*  80 */   protected int pos = -1;
/*  81 */   private Set<InstructionTargeter> targeters = Collections.emptySet();
/*     */   
/*     */   protected InstructionHandle(Instruction i) {
/*  84 */     setInstruction(i);
/*     */   }
/*     */   
/*     */   static final InstructionHandle getInstructionHandle(Instruction i) {
/*  88 */     return new InstructionHandle(i);
/*     */   }
/*     */   
/*     */   public final InstructionHandle getNext() {
/*  92 */     return this.next;
/*     */   }
/*     */   
/*     */   public final InstructionHandle getPrev() {
/*  96 */     return this.prev;
/*     */   }
/*     */   
/*     */   public final Instruction getInstruction() {
/* 100 */     return this.instruction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstruction(Instruction i) {
/* 107 */     if (this.instruction != null) {
/* 108 */       this.instruction.dispose();
/*     */     }
/* 110 */     this.instruction = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 118 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPosition(int pos) {
/* 125 */     this.pos = pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 133 */     this.next = this.prev = null;
/* 134 */     this.instruction.dispose();
/* 135 */     this.instruction = null;
/* 136 */     this.pos = -1;
/* 137 */     removeAllTargeters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllTargeters() {
/* 144 */     this.targeters.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTargeter(InstructionTargeter t) {
/* 151 */     this.targeters.remove(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTargeter(InstructionTargeter t) {
/* 158 */     if (this.targeters == Collections.EMPTY_SET) {
/* 159 */       this.targeters = new HashSet<>();
/*     */     }
/* 161 */     this.targeters.add(t);
/*     */   }
/*     */   
/*     */   public boolean hasTargeters() {
/* 165 */     return !this.targeters.isEmpty();
/*     */   }
/*     */   
/*     */   public Set<InstructionTargeter> getTargeters() {
/* 169 */     return this.targeters;
/*     */   }
/*     */   
/*     */   public Set<InstructionTargeter> getTargetersCopy() {
/* 173 */     Set<InstructionTargeter> copy = new HashSet<>(this.targeters);
/* 174 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 181 */     return Utility.format(this.pos, 4, false, ' ') + ": " + this.instruction.toString(verbose);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 185 */     return toString(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */