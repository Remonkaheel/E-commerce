/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.Repository;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceType
/*     */   extends Type
/*     */ {
/*     */   protected ReferenceType(byte t, String s) {
/*  70 */     super(t, s);
/*     */   }
/*     */   
/*     */   ReferenceType() {
/*  74 */     super((byte)14, "<null object>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCastableTo(Type t) {
/*  83 */     if (equals(Type.NULL)) {
/*  84 */       return true;
/*     */     }
/*     */     
/*  87 */     return isAssignmentCompatibleWith(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAssignmentCompatibleWith(Type t) {
/*  98 */     if (!(t instanceof ReferenceType)) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     ReferenceType T = (ReferenceType)t;
/*     */     
/* 104 */     if (equals(Type.NULL)) {
/* 105 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (this instanceof ObjectType && ((ObjectType)this).referencesClass()) {
/*     */ 
/*     */ 
/*     */       
/* 115 */       if (T instanceof ObjectType && ((ObjectType)T).referencesClass()) {
/* 116 */         if (equals(T)) {
/* 117 */           return true;
/*     */         }
/*     */         
/* 120 */         if (Repository.instanceOf(((ObjectType)this).getClassName(), ((ObjectType)T).getClassName())) {
/* 121 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       if (T instanceof ObjectType && ((ObjectType)T).referencesInterface() && 
/* 129 */         Repository.implementationOf(((ObjectType)this).getClassName(), ((ObjectType)T).getClassName())) {
/* 130 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     if (this instanceof ObjectType && ((ObjectType)this).referencesInterface()) {
/*     */ 
/*     */ 
/*     */       
/* 142 */       if (T instanceof ObjectType && ((ObjectType)T).referencesClass() && 
/* 143 */         T.equals(Type.OBJECT)) {
/* 144 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 151 */       if (T instanceof ObjectType && ((ObjectType)T).referencesInterface()) {
/* 152 */         if (equals(T)) {
/* 153 */           return true;
/*     */         }
/* 155 */         if (Repository.implementationOf(((ObjectType)this).getClassName(), ((ObjectType)T).getClassName())) {
/* 156 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     if (this instanceof ArrayType) {
/*     */ 
/*     */ 
/*     */       
/* 168 */       if (T instanceof ObjectType && ((ObjectType)T).referencesClass() && 
/* 169 */         T.equals(Type.OBJECT)) {
/* 170 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       if (T instanceof ArrayType) {
/*     */ 
/*     */ 
/*     */         
/* 181 */         Type sc = ((ArrayType)this).getElementType();
/* 182 */         Type tc = ((ArrayType)this).getElementType();
/*     */         
/* 184 */         if (sc instanceof BasicType && tc instanceof BasicType && sc.equals(tc)) {
/* 185 */           return true;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         if (tc instanceof ReferenceType && sc instanceof ReferenceType && ((ReferenceType)sc)
/* 192 */           .isAssignmentCompatibleWith(tc)) {
/* 193 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       if (T instanceof ObjectType && ((ObjectType)T).referencesInterface()) {
/* 204 */         for (int ii = 0; ii < Constants.INTERFACES_IMPLEMENTED_BY_ARRAYS.length; ii++) {
/* 205 */           if (T.equals(new ObjectType(Constants.INTERFACES_IMPLEMENTED_BY_ARRAYS[ii]))) {
/* 206 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType getFirstCommonSuperclass(ReferenceType t) {
/* 224 */     if (equals(Type.NULL)) {
/* 225 */       return t;
/*     */     }
/* 227 */     if (t.equals(Type.NULL)) {
/* 228 */       return this;
/*     */     }
/* 230 */     if (equals(t)) {
/* 231 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     if (this instanceof ArrayType && t instanceof ArrayType) {
/* 242 */       ArrayType arrType1 = (ArrayType)this;
/* 243 */       ArrayType arrType2 = (ArrayType)t;
/* 244 */       if (arrType1.getDimensions() == arrType2.getDimensions() && arrType1.getBasicType() instanceof ObjectType && arrType2
/* 245 */         .getBasicType() instanceof ObjectType) {
/* 246 */         return new ArrayType(((ObjectType)arrType1.getBasicType()).getFirstCommonSuperclass((ObjectType)arrType2
/* 247 */               .getBasicType()), arrType1.getDimensions());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 252 */     if (this instanceof ArrayType || t instanceof ArrayType) {
/* 253 */       return Type.OBJECT;
/*     */     }
/*     */ 
/*     */     
/* 257 */     if ((this instanceof ObjectType && ((ObjectType)this).referencesInterface()) || (t instanceof ObjectType && ((ObjectType)t)
/* 258 */       .referencesInterface())) {
/* 259 */       return Type.OBJECT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 266 */     ObjectType thiz = (ObjectType)this;
/* 267 */     ObjectType other = (ObjectType)t;
/* 268 */     JavaClass[] thiz_sups = Repository.lookupClass(thiz.getClassName()).getSuperClasses();
/* 269 */     JavaClass[] other_sups = Repository.lookupClass(other.getClassName()).getSuperClasses();
/*     */     
/* 271 */     if (thiz_sups == null || other_sups == null) {
/* 272 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 276 */     JavaClass[] this_sups = new JavaClass[thiz_sups.length + 1];
/* 277 */     JavaClass[] t_sups = new JavaClass[other_sups.length + 1];
/* 278 */     System.arraycopy(thiz_sups, 0, this_sups, 1, thiz_sups.length);
/* 279 */     System.arraycopy(other_sups, 0, t_sups, 1, other_sups.length);
/* 280 */     this_sups[0] = Repository.lookupClass(thiz.getClassName());
/* 281 */     t_sups[0] = Repository.lookupClass(other.getClassName());
/*     */     
/* 283 */     for (JavaClass t_sup : t_sups) {
/* 284 */       for (JavaClass this_sup : this_sups) {
/* 285 */         if (this_sup.equals(t_sup)) {
/* 286 */           return new ObjectType(this_sup.getClassName());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 292 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\ReferenceType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */