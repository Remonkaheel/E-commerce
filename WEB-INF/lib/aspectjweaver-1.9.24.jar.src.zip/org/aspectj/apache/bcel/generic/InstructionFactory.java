/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionFactory
/*     */   implements InstructionConstants
/*     */ {
/*     */   protected ClassGen cg;
/*     */   protected ConstantPool cp;
/*     */   
/*     */   public InstructionFactory(ClassGen cg, ConstantPool cp) {
/*  73 */     this.cg = cg;
/*  74 */     this.cp = cp;
/*     */   }
/*     */   
/*     */   public InstructionFactory(ClassGen cg) {
/*  78 */     this(cg, cg.getConstantPool());
/*     */   }
/*     */   
/*     */   public InstructionFactory(ConstantPool cp) {
/*  82 */     this((ClassGen)null, cp);
/*     */   }
/*     */   
/*     */   public InvokeInstruction createInvoke(String class_name, String name, Type ret_type, Type[] arg_types, short kind) {
/*  86 */     return createInvoke(class_name, name, ret_type, arg_types, kind, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvokeInstruction createInvoke(String class_name, String name, Type ret_type, Type[] arg_types, short kind, boolean isInterface) {
/*     */     int index, nargs;
/* 102 */     String signature = Utility.toMethodSignature(ret_type, arg_types);
/*     */ 
/*     */     
/* 105 */     if (kind == 185 || isInterface)
/* 106 */     { index = this.cp.addInterfaceMethodref(class_name, name, signature); }
/* 107 */     else { if (kind == 186) {
/* 108 */         throw new IllegalStateException("NYI");
/*     */       }
/* 110 */       index = this.cp.addMethodref(class_name, name, signature); }
/*     */ 
/*     */     
/* 113 */     switch (kind) {
/*     */       case 183:
/* 115 */         return new InvokeInstruction((short)183, index);
/*     */       case 182:
/* 117 */         return new InvokeInstruction((short)182, index);
/*     */       case 184:
/* 119 */         return new InvokeInstruction((short)184, index);
/*     */       case 185:
/* 121 */         nargs = 0;
/* 122 */         for (Type arg_type : arg_types) {
/* 123 */           nargs += arg_type.getSize();
/*     */         }
/* 125 */         return new INVOKEINTERFACE(index, nargs + 1, 0);
/*     */     } 
/* 127 */     throw new RuntimeException("Oops: Unknown invoke kind:" + kind);
/*     */   }
/*     */   public InvokeInstruction createInvoke(String class_name, String name, String signature, short kind) {
/*     */     int index;
/*     */     Type[] argumentTypes;
/*     */     int nargs;
/* 133 */     if (kind == 185)
/* 134 */     { index = this.cp.addInterfaceMethodref(class_name, name, signature); }
/* 135 */     else { if (kind == 186) {
/* 136 */         throw new IllegalStateException("NYI");
/*     */       }
/* 138 */       index = this.cp.addMethodref(class_name, name, signature); }
/*     */ 
/*     */     
/* 141 */     switch (kind) {
/*     */       case 183:
/* 143 */         return new InvokeInstruction((short)183, index);
/*     */       case 182:
/* 145 */         return new InvokeInstruction((short)182, index);
/*     */       case 184:
/* 147 */         return new InvokeInstruction((short)184, index);
/*     */       case 185:
/* 149 */         argumentTypes = Type.getArgumentTypes(signature);
/* 150 */         nargs = 0;
/* 151 */         for (Type argumentType : argumentTypes) {
/* 152 */           nargs += argumentType.getSize();
/*     */         }
/* 154 */         return new INVOKEINTERFACE(index, nargs + 1, 0);
/*     */     } 
/* 156 */     throw new RuntimeException("Oops: Unknown invoke kind:" + kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Instruction createALOAD(int n) {
/* 161 */     if (n < 4) {
/* 162 */       return new InstructionLV((short)(42 + n));
/*     */     }
/* 164 */     return new InstructionLV((short)25, n);
/*     */   }
/*     */   
/*     */   public static Instruction createASTORE(int n) {
/* 168 */     if (n < 4) {
/* 169 */       return new InstructionLV((short)(75 + n));
/*     */     }
/* 171 */     return new InstructionLV((short)58, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createConstant(Object value) {
/*     */     Instruction instruction;
/* 183 */     if (value instanceof Number) {
/* 184 */       instruction = PUSH(this.cp, (Number)value);
/* 185 */     } else if (value instanceof String) {
/* 186 */       instruction = PUSH(this.cp, (String)value);
/* 187 */     } else if (value instanceof Boolean) {
/* 188 */       instruction = PUSH(this.cp, (Boolean)value);
/* 189 */     } else if (value instanceof Character) {
/* 190 */       instruction = PUSH(this.cp, (Character)value);
/* 191 */     } else if (value instanceof ObjectType) {
/* 192 */       instruction = PUSH(this.cp, (ObjectType)value);
/*     */     } else {
/* 194 */       throw new ClassGenException("Illegal type: " + value.getClass());
/*     */     } 
/*     */     
/* 197 */     return instruction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInstruction createFieldAccess(String class_name, String name, Type type, short kind) {
/* 211 */     String signature = type.getSignature();
/*     */     
/* 213 */     int index = this.cp.addFieldref(class_name, name, signature);
/*     */     
/* 215 */     switch (kind) {
/*     */       case 180:
/* 217 */         return new FieldInstruction((short)180, index);
/*     */       case 181:
/* 219 */         return new FieldInstruction((short)181, index);
/*     */       case 178:
/* 221 */         return new FieldInstruction((short)178, index);
/*     */       case 179:
/* 223 */         return new FieldInstruction((short)179, index);
/*     */     } 
/*     */     
/* 226 */     throw new RuntimeException("Oops: Unknown getfield kind:" + kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createThis() {
/* 234 */     return new InstructionLV((short)25, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createReturn(Type type) {
/* 241 */     switch (type.getType()) {
/*     */       case 13:
/*     */       case 14:
/* 244 */         return ARETURN;
/*     */       case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 250 */         return IRETURN;
/*     */       case 6:
/* 252 */         return FRETURN;
/*     */       case 7:
/* 254 */         return DRETURN;
/*     */       case 11:
/* 256 */         return LRETURN;
/*     */       case 12:
/* 258 */         return RETURN;
/*     */     } 
/*     */     
/* 261 */     throw new RuntimeException("Invalid type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createPop(int size) {
/* 269 */     return (size == 2) ? POP2 : POP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createDup(int size) {
/* 276 */     return (size == 2) ? DUP2 : DUP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createDup_2(int size) {
/* 283 */     return (size == 2) ? DUP2_X2 : DUP_X2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createDup_1(int size) {
/* 290 */     return (size == 2) ? DUP2_X1 : DUP_X1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InstructionLV createStore(Type type, int index) {
/* 297 */     switch (type.getType()) {
/*     */       case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 303 */         return new InstructionLV((short)54, index);
/*     */       case 6:
/* 305 */         return new InstructionLV((short)56, index);
/*     */       case 7:
/* 307 */         return new InstructionLV((short)57, index);
/*     */       case 11:
/* 309 */         return new InstructionLV((short)55, index);
/*     */       case 13:
/*     */       case 14:
/* 312 */         return new InstructionLV((short)58, index);
/*     */     } 
/* 314 */     throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InstructionLV createLoad(Type type, int index) {
/* 322 */     switch (type.getType()) {
/*     */       case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 328 */         return new InstructionLV((short)21, index);
/*     */       case 6:
/* 330 */         return new InstructionLV((short)23, index);
/*     */       case 7:
/* 332 */         return new InstructionLV((short)24, index);
/*     */       case 11:
/* 334 */         return new InstructionLV((short)22, index);
/*     */       case 13:
/*     */       case 14:
/* 337 */         return new InstructionLV((short)25, index);
/*     */     } 
/* 339 */     throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createArrayLoad(Type type) {
/* 347 */     switch (type.getType()) {
/*     */       case 4:
/*     */       case 8:
/* 350 */         return BALOAD;
/*     */       case 5:
/* 352 */         return CALOAD;
/*     */       case 9:
/* 354 */         return SALOAD;
/*     */       case 10:
/* 356 */         return IALOAD;
/*     */       case 6:
/* 358 */         return FALOAD;
/*     */       case 7:
/* 360 */         return DALOAD;
/*     */       case 11:
/* 362 */         return LALOAD;
/*     */       case 13:
/*     */       case 14:
/* 365 */         return AALOAD;
/*     */     } 
/* 367 */     throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createArrayStore(Type type) {
/* 375 */     switch (type.getType()) {
/*     */       case 4:
/*     */       case 8:
/* 378 */         return BASTORE;
/*     */       case 5:
/* 380 */         return CASTORE;
/*     */       case 9:
/* 382 */         return SASTORE;
/*     */       case 10:
/* 384 */         return IASTORE;
/*     */       case 6:
/* 386 */         return FASTORE;
/*     */       case 7:
/* 388 */         return DASTORE;
/*     */       case 11:
/* 390 */         return LASTORE;
/*     */       case 13:
/*     */       case 14:
/* 393 */         return AASTORE;
/*     */     } 
/* 395 */     throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */   
/* 399 */   private static final char[] shortNames = new char[] { 'C', 'F', 'D', 'B', 'S', 'I', 'L' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createCast(Type src_type, Type dest_type) {
/* 406 */     if (src_type instanceof BasicType && dest_type instanceof BasicType) {
/* 407 */       byte dest = dest_type.getType();
/* 408 */       byte src = src_type.getType();
/*     */       
/* 410 */       if (dest == 11 && (src == 5 || src == 8 || src == 9)) {
/* 411 */         src = 10;
/*     */       }
/*     */       
/* 414 */       if (src == 7) {
/* 415 */         switch (dest) {
/*     */           case 6:
/* 417 */             return InstructionConstants.D2F;
/*     */           case 10:
/* 419 */             return InstructionConstants.D2I;
/*     */           case 11:
/* 421 */             return InstructionConstants.D2L;
/*     */         } 
/* 423 */       } else if (src == 6) {
/* 424 */         switch (dest) {
/*     */           case 7:
/* 426 */             return InstructionConstants.F2D;
/*     */           case 10:
/* 428 */             return InstructionConstants.F2I;
/*     */           case 11:
/* 430 */             return InstructionConstants.F2L;
/*     */         } 
/* 432 */       } else if (src == 10) {
/* 433 */         switch (dest) {
/*     */           case 8:
/* 435 */             return InstructionConstants.I2B;
/*     */           case 5:
/* 437 */             return InstructionConstants.I2C;
/*     */           case 7:
/* 439 */             return InstructionConstants.I2D;
/*     */           case 6:
/* 441 */             return InstructionConstants.I2F;
/*     */           case 11:
/* 443 */             return InstructionConstants.I2L;
/*     */           case 9:
/* 445 */             return InstructionConstants.I2S;
/*     */         } 
/* 447 */       } else if (src == 11) {
/* 448 */         switch (dest) {
/*     */           case 7:
/* 450 */             return InstructionConstants.L2D;
/*     */           case 6:
/* 452 */             return InstructionConstants.L2F;
/*     */           case 10:
/* 454 */             return InstructionConstants.L2I;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 468 */       return null;
/*     */     } 
/* 470 */     if (src_type instanceof ReferenceType && dest_type instanceof ReferenceType) {
/* 471 */       if (dest_type instanceof ArrayType) {
/* 472 */         return new InstructionCP((short)192, this.cp.addArrayClass((ArrayType)dest_type));
/*     */       }
/* 474 */       return new InstructionCP((short)192, this.cp.addClass(((ObjectType)dest_type).getClassName()));
/*     */     } 
/*     */     
/* 477 */     throw new RuntimeException("Can not cast " + src_type + " to " + dest_type);
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldInstruction createGetField(String class_name, String name, Type t) {
/* 482 */     return new FieldInstruction((short)180, this.cp.addFieldref(class_name, name, t.getSignature()));
/*     */   }
/*     */   
/*     */   public FieldInstruction createGetStatic(String class_name, String name, Type t) {
/* 486 */     return new FieldInstruction((short)178, this.cp.addFieldref(class_name, name, t.getSignature()));
/*     */   }
/*     */   
/*     */   public FieldInstruction createPutField(String class_name, String name, Type t) {
/* 490 */     return new FieldInstruction((short)181, this.cp.addFieldref(class_name, name, t.getSignature()));
/*     */   }
/*     */   
/*     */   public FieldInstruction createPutStatic(String class_name, String name, Type t) {
/* 494 */     return new FieldInstruction((short)179, this.cp.addFieldref(class_name, name, t.getSignature()));
/*     */   }
/*     */   
/*     */   public Instruction createCheckCast(ReferenceType t) {
/* 498 */     if (t instanceof ArrayType) {
/* 499 */       return new InstructionCP((short)192, this.cp.addArrayClass((ArrayType)t));
/*     */     }
/* 501 */     return new InstructionCP((short)192, this.cp.addClass((ObjectType)t));
/*     */   }
/*     */ 
/*     */   
/*     */   public Instruction createInstanceOf(ReferenceType t) {
/* 506 */     if (t instanceof ArrayType) {
/* 507 */       return new InstructionCP((short)193, this.cp.addArrayClass((ArrayType)t));
/*     */     }
/* 509 */     return new InstructionCP((short)193, this.cp.addClass((ObjectType)t));
/*     */   }
/*     */ 
/*     */   
/*     */   public Instruction createNew(ObjectType t) {
/* 514 */     return new InstructionCP((short)187, this.cp.addClass(t));
/*     */   }
/*     */   
/*     */   public Instruction createNew(String s) {
/* 518 */     return createNew(new ObjectType(s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createNewArray(Type t, short dim) {
/*     */     ArrayType at;
/* 527 */     if (dim == 1) {
/* 528 */       if (t instanceof ObjectType)
/* 529 */         return new InstructionCP((short)189, this.cp.addClass((ObjectType)t)); 
/* 530 */       if (t instanceof ArrayType) {
/* 531 */         return new InstructionCP((short)189, this.cp.addArrayClass((ArrayType)t));
/*     */       }
/* 533 */       return new InstructionByte((short)188, ((BasicType)t).getType());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 538 */     if (t instanceof ArrayType) {
/* 539 */       at = (ArrayType)t;
/*     */     } else {
/* 541 */       at = new ArrayType(t, dim);
/*     */     } 
/*     */     
/* 544 */     return new MULTIANEWARRAY(this.cp.addArrayClass(at), dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createNull(Type type) {
/* 552 */     switch (type.getType()) {
/*     */       case 13:
/*     */       case 14:
/* 555 */         return ACONST_NULL;
/*     */       case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 561 */         return ICONST_0;
/*     */       case 6:
/* 563 */         return FCONST_0;
/*     */       case 7:
/* 565 */         return DCONST_0;
/*     */       case 11:
/* 567 */         return LCONST_0;
/*     */       case 12:
/* 569 */         return NOP;
/*     */     } 
/*     */     
/* 572 */     throw new RuntimeException("Invalid type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InstructionBranch createBranchInstruction(short opcode, InstructionHandle target) {
/* 581 */     switch (opcode) {
/*     */       case 153:
/* 583 */         return new InstructionBranch((short)153, target);
/*     */       case 154:
/* 585 */         return new InstructionBranch((short)154, target);
/*     */       case 155:
/* 587 */         return new InstructionBranch((short)155, target);
/*     */       case 156:
/* 589 */         return new InstructionBranch((short)156, target);
/*     */       case 157:
/* 591 */         return new InstructionBranch((short)157, target);
/*     */       case 158:
/* 593 */         return new InstructionBranch((short)158, target);
/*     */       case 159:
/* 595 */         return new InstructionBranch((short)159, target);
/*     */       case 160:
/* 597 */         return new InstructionBranch((short)160, target);
/*     */       case 161:
/* 599 */         return new InstructionBranch((short)161, target);
/*     */       case 162:
/* 601 */         return new InstructionBranch((short)162, target);
/*     */       case 163:
/* 603 */         return new InstructionBranch((short)163, target);
/*     */       case 164:
/* 605 */         return new InstructionBranch((short)164, target);
/*     */       case 165:
/* 607 */         return new InstructionBranch((short)165, target);
/*     */       case 166:
/* 609 */         return new InstructionBranch((short)166, target);
/*     */       case 167:
/* 611 */         return new InstructionBranch((short)167, target);
/*     */       case 168:
/* 613 */         return new InstructionBranch((short)168, target);
/*     */       case 198:
/* 615 */         return new InstructionBranch((short)198, target);
/*     */       case 199:
/* 617 */         return new InstructionBranch((short)199, target);
/*     */       case 200:
/* 619 */         return new InstructionBranch((short)200, target);
/*     */       case 201:
/* 621 */         return new InstructionBranch((short)201, target);
/*     */     } 
/* 623 */     throw new RuntimeException("Invalid opcode: " + opcode);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClassGen(ClassGen c) {
/* 628 */     this.cg = c;
/*     */   }
/*     */   
/*     */   public ClassGen getClassGen() {
/* 632 */     return this.cg;
/*     */   }
/*     */   
/*     */   public void setConstantPool(ConstantPool c) {
/* 636 */     this.cp = c;
/*     */   }
/*     */   
/*     */   public ConstantPool getConstantPool() {
/* 640 */     return this.cp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, int value) {
/* 647 */     Instruction instruction = null;
/* 648 */     if (value >= -1 && value <= 5)
/* 649 */       return INSTRUCTIONS[3 + value]; 
/* 650 */     if (value >= -128 && value <= 127) {
/* 651 */       instruction = new InstructionByte((short)16, (byte)value);
/* 652 */     } else if (value >= -32768 && value <= 32767) {
/* 653 */       instruction = new InstructionShort((short)17, (short)value);
/*     */     } else {
/*     */       
/* 656 */       int pos = cp.addInteger(value);
/* 657 */       if (pos <= 255) {
/* 658 */         instruction = new InstructionCP((short)18, pos);
/*     */       } else {
/* 660 */         instruction = new InstructionCP((short)19, pos);
/*     */       } 
/*     */     } 
/* 663 */     return instruction;
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, ObjectType t) {
/* 667 */     return new InstructionCP((short)19, cp.addClass(t));
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, boolean value) {
/* 671 */     return INSTRUCTIONS[3 + (value ? 1 : 0)];
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, float value) {
/* 675 */     Instruction instruction = null;
/* 676 */     if (value == 0.0D) {
/* 677 */       instruction = FCONST_0;
/* 678 */     } else if (value == 1.0D) {
/* 679 */       instruction = FCONST_1;
/* 680 */     } else if (value == 2.0D) {
/* 681 */       instruction = FCONST_2;
/*     */     } else {
/*     */       
/* 684 */       int i = cp.addFloat(value);
/* 685 */       instruction = new InstructionCP((i <= 255) ? 18 : 19, i);
/*     */     } 
/* 687 */     return instruction;
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, long value) {
/* 691 */     Instruction instruction = null;
/* 692 */     if (value == 0L) {
/* 693 */       instruction = LCONST_0;
/* 694 */     } else if (value == 1L) {
/* 695 */       instruction = LCONST_1;
/*     */     } else {
/* 697 */       instruction = new InstructionCP((short)20, cp.addLong(value));
/*     */     } 
/* 699 */     return instruction;
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, double value) {
/* 703 */     Instruction instruction = null;
/* 704 */     if (value == 0.0D) {
/* 705 */       instruction = DCONST_0;
/* 706 */     } else if (value == 1.0D) {
/* 707 */       instruction = DCONST_1;
/*     */     } else {
/*     */       
/* 710 */       instruction = new InstructionCP((short)20, cp.addDouble(value));
/*     */     } 
/* 712 */     return instruction;
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, String value) {
/* 716 */     Instruction instruction = null;
/* 717 */     if (value == null) {
/* 718 */       instruction = ACONST_NULL;
/*     */     } else {
/* 720 */       int i = cp.addString(value);
/* 721 */       instruction = new InstructionCP((i <= 255) ? 18 : 19, i);
/*     */     } 
/* 723 */     return instruction;
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, Number value) {
/* 727 */     Instruction instruction = null;
/* 728 */     if (value instanceof Integer || value instanceof Short || value instanceof Byte) {
/* 729 */       instruction = PUSH(cp, value.intValue());
/* 730 */     } else if (value instanceof Double) {
/* 731 */       instruction = PUSH(cp, value.doubleValue());
/* 732 */     } else if (value instanceof Float) {
/* 733 */       instruction = PUSH(cp, value.floatValue());
/* 734 */     } else if (value instanceof Long) {
/* 735 */       instruction = PUSH(cp, value.longValue());
/*     */     } else {
/* 737 */       throw new ClassGenException("What's this: " + value);
/*     */     } 
/* 739 */     return instruction;
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, Character value) {
/* 743 */     return PUSH(cp, value.charValue());
/*     */   }
/*     */   
/*     */   public static Instruction PUSH(ConstantPool cp, Boolean value) {
/* 747 */     return PUSH(cp, value.booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionList PUSHCLASS(ConstantPool cp, String className) {
/* 755 */     InstructionList iList = new InstructionList();
/* 756 */     int classIndex = cp.addClass(className);
/* 757 */     if (this.cg != null && this.cg.getMajor() >= 49) {
/* 758 */       if (classIndex <= 255) {
/* 759 */         iList.append(new InstructionCP((short)18, classIndex));
/*     */       } else {
/* 761 */         iList.append(new InstructionCP((short)19, classIndex));
/*     */       } 
/*     */     } else {
/* 764 */       className = className.replace('/', '.');
/* 765 */       iList.append(PUSH(cp, className));
/* 766 */       iList.append(createInvoke("java.lang.Class", "forName", ObjectType.CLASS, Type.STRINGARRAY1, (short)184));
/*     */     } 
/*     */     
/* 769 */     return iList;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */