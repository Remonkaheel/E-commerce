/*      */ package org.aspectj.apache.bcel.generic;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Stack;
/*      */ import org.aspectj.apache.bcel.classfile.Attribute;
/*      */ import org.aspectj.apache.bcel.classfile.Code;
/*      */ import org.aspectj.apache.bcel.classfile.CodeException;
/*      */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*      */ import org.aspectj.apache.bcel.classfile.ExceptionTable;
/*      */ import org.aspectj.apache.bcel.classfile.LineNumber;
/*      */ import org.aspectj.apache.bcel.classfile.LineNumberTable;
/*      */ import org.aspectj.apache.bcel.classfile.LocalVariable;
/*      */ import org.aspectj.apache.bcel.classfile.LocalVariableTable;
/*      */ import org.aspectj.apache.bcel.classfile.Method;
/*      */ import org.aspectj.apache.bcel.classfile.Utility;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeAnnos;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeParamAnnos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MethodGen
/*      */   extends FieldGenOrMethodGen
/*      */ {
/*      */   private String classname;
/*      */   private Type[] parameterTypes;
/*      */   private String[] parameterNames;
/*      */   private int maxLocals;
/*      */   private int maxStack;
/*      */   private InstructionList il;
/*      */   private boolean stripAttributes;
/*  103 */   private int highestLineNumber = 0;
/*      */   
/*  105 */   private List<LocalVariableGen> localVariablesList = new ArrayList<>();
/*  106 */   private List<LineNumberGen> lineNumbersList = new ArrayList<>();
/*  107 */   private ArrayList<CodeExceptionGen> exceptionsList = new ArrayList<>();
/*  108 */   private ArrayList<String> exceptionsThrown = new ArrayList<>();
/*  109 */   private List<Attribute> codeAttributesList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<AnnotationGen>[] param_annotations;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasParameterAnnotations = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean haveUnpackedParameterAnnotations = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodGen(int access_flags, Type return_type, Type[] arg_types, String[] arg_names, String method_name, String class_name, InstructionList il, ConstantPool cp) {
/*  134 */     this.modifiers = access_flags;
/*  135 */     this.type = return_type;
/*  136 */     this.parameterTypes = arg_types;
/*  137 */     this.parameterNames = arg_names;
/*  138 */     this.name = method_name;
/*  139 */     this.classname = class_name;
/*  140 */     this.il = il;
/*  141 */     this.cp = cp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHighestlinenumber() {
/*  190 */     return this.highestLineNumber;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodGen(Method m, String class_name, ConstantPool cp) {
/*  202 */     this(m, class_name, cp, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public MethodGen(Method m, String class_name, ConstantPool cp, boolean useTags) {
/*  207 */     this(m.getModifiers(), m
/*      */         
/*  209 */         .getReturnType(), m.getArgumentTypes(), (String[])null, m.getName(), class_name, 
/*  210 */         ((m.getModifiers() & 0x500) == 0) ? new InstructionList(m.getCode()
/*  211 */           .getCode()) : null, cp);
/*      */     
/*  213 */     Attribute[] attributes = m.getAttributes();
/*  214 */     for (Attribute attribute : attributes) {
/*  215 */       Attribute a = attribute;
/*      */       
/*  217 */       if (a instanceof Code) {
/*  218 */         Code code = (Code)a;
/*  219 */         setMaxStack(code.getMaxStack());
/*  220 */         setMaxLocals(code.getMaxLocals());
/*      */         
/*  222 */         CodeException[] ces = code.getExceptionTable();
/*      */         
/*  224 */         InstructionHandle[] arrayOfInstructions = this.il.getInstructionsAsArray();
/*      */ 
/*      */ 
/*      */         
/*  228 */         if (ces != null) {
/*  229 */           for (CodeException ce : ces) {
/*  230 */             InstructionHandle end; int type = ce.getCatchType();
/*  231 */             ObjectType catchType = null;
/*      */             
/*  233 */             if (type > 0) {
/*  234 */               String cen = m.getConstantPool().getConstantString_CONSTANTClass(type);
/*  235 */               catchType = new ObjectType(cen);
/*      */             } 
/*      */             
/*  238 */             int end_pc = ce.getEndPC();
/*  239 */             int length = (m.getCode().getCode()).length;
/*      */ 
/*      */ 
/*      */             
/*  243 */             if (length == end_pc) {
/*  244 */               end = this.il.getEnd();
/*      */             } else {
/*  246 */               end = this.il.findHandle(end_pc, arrayOfInstructions);
/*  247 */               end = end.getPrev();
/*      */             } 
/*      */             
/*  250 */             addExceptionHandler(this.il.findHandle(ce.getStartPC(), arrayOfInstructions), end, this.il.findHandle(ce
/*  251 */                   .getHandlerPC(), arrayOfInstructions), catchType);
/*      */           } 
/*      */         }
/*      */         
/*  255 */         Attribute[] codeAttrs = code.getAttributes();
/*  256 */         for (Attribute codeAttr : codeAttrs) {
/*  257 */           a = codeAttr;
/*      */           
/*  259 */           if (a instanceof LineNumberTable) {
/*  260 */             LineNumber[] ln = ((LineNumberTable)a).getLineNumberTable();
/*  261 */             if (useTags) {
/*      */               
/*  263 */               for (LineNumber l : ln) {
/*  264 */                 int lnum = l.getLineNumber();
/*  265 */                 if (lnum > this.highestLineNumber) {
/*  266 */                   this.highestLineNumber = lnum;
/*      */                 }
/*  268 */                 LineNumberTag lt = new LineNumberTag(lnum);
/*  269 */                 this.il.findHandle(l.getStartPC(), arrayOfInstructions, true).addTargeter(lt);
/*      */               } 
/*      */             } else {
/*  272 */               for (LineNumber l : ln) {
/*  273 */                 addLineNumber(this.il.findHandle(l.getStartPC(), arrayOfInstructions, true), l.getLineNumber());
/*      */               }
/*      */             } 
/*  276 */           } else if (a instanceof LocalVariableTable) {
/*      */ 
/*      */             
/*  279 */             if (useTags) {
/*  280 */               LocalVariable[] lv = ((LocalVariableTable)a).getLocalVariableTable();
/*      */               
/*  282 */               for (LocalVariable l : lv) {
/*  283 */                 Type t = Type.getType(l.getSignature());
/*      */                 
/*  285 */                 LocalVariableTag lvt = new LocalVariableTag(t, l.getSignature(), l.getName(), l.getIndex(), l.getStartPC());
/*  286 */                 InstructionHandle start = this.il.findHandle(l.getStartPC(), arrayOfInstructions, true);
/*  287 */                 byte b = t.getType();
/*  288 */                 if (b != 16) {
/*  289 */                   int increment = t.getSize();
/*  290 */                   if (l.getIndex() + increment > this.maxLocals) {
/*  291 */                     this.maxLocals = l.getIndex() + increment;
/*      */                   }
/*      */                 } 
/*  294 */                 int end = l.getStartPC() + l.getLength();
/*      */                 do {
/*  296 */                   start.addTargeter(lvt);
/*  297 */                   start = start.getNext();
/*  298 */                 } while (start != null && start.getPosition() < end);
/*      */               } 
/*      */             } else {
/*      */               
/*  302 */               LocalVariable[] lv = ((LocalVariableTable)a).getLocalVariableTable();
/*      */               
/*  304 */               removeLocalVariables();
/*      */               
/*  306 */               for (LocalVariable l : lv) {
/*  307 */                 InstructionHandle start = this.il.findHandle(l.getStartPC(), arrayOfInstructions);
/*  308 */                 InstructionHandle end = this.il.findHandle(l.getStartPC() + l.getLength(), arrayOfInstructions);
/*      */ 
/*      */                 
/*  311 */                 if (end != null) {
/*  312 */                   end = end.getPrev();
/*      */                 }
/*      */                 
/*  315 */                 if (null == start) {
/*  316 */                   start = this.il.getStart();
/*      */                 }
/*  318 */                 if (null == end) {
/*  319 */                   end = this.il.getEnd();
/*      */                 }
/*      */                 
/*  322 */                 addLocalVariable(l.getName(), Type.getType(l.getSignature()), l.getIndex(), start, end);
/*      */               } 
/*      */             } 
/*      */           } else {
/*  326 */             addCodeAttribute(a);
/*      */           } 
/*      */         } 
/*  329 */       } else if (a instanceof ExceptionTable) {
/*  330 */         String[] names = ((ExceptionTable)a).getExceptionNames();
/*  331 */         for (String s : names) {
/*  332 */           addException(s);
/*      */         }
/*  334 */       } else if (a instanceof RuntimeAnnos) {
/*  335 */         RuntimeAnnos runtimeAnnotations = (RuntimeAnnos)a;
/*  336 */         List<AnnotationGen> l = runtimeAnnotations.getAnnotations();
/*  337 */         this.annotationList.addAll(l);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  343 */         addAttribute(a);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public LocalVariableGen addLocalVariable(String name, Type type, int slot, InstructionHandle start, InstructionHandle end) {
/*  349 */     int size = type.getSize();
/*  350 */     if (slot + size > this.maxLocals) {
/*  351 */       this.maxLocals = slot + size;
/*      */     }
/*  353 */     LocalVariableGen l = new LocalVariableGen(slot, name, type, start, end);
/*  354 */     int i = this.localVariablesList.indexOf(l);
/*  355 */     if (i >= 0) {
/*  356 */       this.localVariablesList.set(i, l);
/*      */     } else {
/*  358 */       this.localVariablesList.add(l);
/*      */     } 
/*  360 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalVariableGen addLocalVariable(String name, Type type, InstructionHandle start, InstructionHandle end) {
/*  374 */     return addLocalVariable(name, type, this.maxLocals, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLocalVariable(LocalVariableGen l) {
/*  381 */     this.localVariablesList.remove(l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLocalVariables() {
/*  388 */     this.localVariablesList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void sort(LocalVariableGen[] vars, int l, int r) {
/*  395 */     int i = l, j = r;
/*  396 */     int m = vars[(l + r) / 2].getIndex();
/*      */ 
/*      */     
/*      */     do {
/*  400 */       while (vars[i].getIndex() < m) {
/*  401 */         i++;
/*      */       }
/*  403 */       while (m < vars[j].getIndex()) {
/*  404 */         j--;
/*      */       }
/*      */       
/*  407 */       if (i > j)
/*  408 */         continue;  LocalVariableGen h = vars[i];
/*  409 */       vars[i] = vars[j];
/*  410 */       vars[j] = h;
/*  411 */       i++;
/*  412 */       j--;
/*      */     }
/*  414 */     while (i <= j);
/*      */     
/*  416 */     if (l < j) {
/*  417 */       sort(vars, l, j);
/*      */     }
/*  419 */     if (i < r) {
/*  420 */       sort(vars, i, r);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalVariableGen[] getLocalVariables() {
/*  431 */     int size = this.localVariablesList.size();
/*  432 */     LocalVariableGen[] lg = new LocalVariableGen[size];
/*  433 */     this.localVariablesList.toArray(lg);
/*      */     
/*  435 */     for (int i = 0; i < size; i++) {
/*  436 */       if (lg[i].getStart() == null) {
/*  437 */         lg[i].setStart(this.il.getStart());
/*      */       }
/*      */       
/*  440 */       if (lg[i].getEnd() == null) {
/*  441 */         lg[i].setEnd(this.il.getEnd());
/*      */       }
/*      */     } 
/*      */     
/*  445 */     if (size > 1) {
/*  446 */       sort(lg, 0, size - 1);
/*      */     }
/*      */     
/*  449 */     return lg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalVariableTable getLocalVariableTable(ConstantPool cp) {
/*  456 */     LocalVariableGen[] lg = getLocalVariables();
/*  457 */     int size = lg.length;
/*  458 */     LocalVariable[] lv = new LocalVariable[size];
/*      */     
/*  460 */     for (int i = 0; i < size; i++) {
/*  461 */       lv[i] = lg[i].getLocalVariable(cp);
/*      */     }
/*      */     
/*  464 */     return new LocalVariableTable(cp.addUtf8("LocalVariableTable"), 2 + lv.length * 10, lv, cp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LineNumberGen addLineNumber(InstructionHandle ih, int src_line) {
/*  475 */     LineNumberGen l = new LineNumberGen(ih, src_line);
/*  476 */     this.lineNumbersList.add(l);
/*  477 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLineNumber(LineNumberGen l) {
/*  484 */     this.lineNumbersList.remove(l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLineNumbers() {
/*  491 */     this.lineNumbersList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LineNumberGen[] getLineNumbers() {
/*  498 */     LineNumberGen[] lg = new LineNumberGen[this.lineNumbersList.size()];
/*  499 */     this.lineNumbersList.toArray(lg);
/*  500 */     return lg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LineNumberTable getLineNumberTable(ConstantPool cp) {
/*  507 */     int size = this.lineNumbersList.size();
/*  508 */     LineNumber[] ln = new LineNumber[size];
/*      */     
/*  510 */     for (int i = 0; i < size; i++) {
/*  511 */       ln[i] = ((LineNumberGen)this.lineNumbersList.get(i)).getLineNumber();
/*      */     }
/*      */     
/*  514 */     return new LineNumberTable(cp.addUtf8("LineNumberTable"), 2 + ln.length * 4, ln, cp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CodeExceptionGen addExceptionHandler(InstructionHandle start_pc, InstructionHandle end_pc, InstructionHandle handler_pc, ObjectType catch_type) {
/*  529 */     if (start_pc == null || end_pc == null || handler_pc == null) {
/*  530 */       throw new ClassGenException("Exception handler target is null instruction");
/*      */     }
/*      */     
/*  533 */     CodeExceptionGen c = new CodeExceptionGen(start_pc, end_pc, handler_pc, catch_type);
/*  534 */     this.exceptionsList.add(c);
/*  535 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeExceptionHandler(CodeExceptionGen c) {
/*  542 */     this.exceptionsList.remove(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeExceptionHandlers() {
/*  549 */     this.exceptionsList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CodeExceptionGen[] getExceptionHandlers() {
/*  556 */     CodeExceptionGen[] cg = new CodeExceptionGen[this.exceptionsList.size()];
/*  557 */     this.exceptionsList.toArray(cg);
/*  558 */     return cg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CodeException[] getCodeExceptions() {
/*  565 */     int size = this.exceptionsList.size();
/*  566 */     CodeException[] c_exc = new CodeException[size];
/*      */     
/*      */     try {
/*  569 */       for (int i = 0; i < size; i++) {
/*  570 */         CodeExceptionGen c = this.exceptionsList.get(i);
/*  571 */         c_exc[i] = c.getCodeException(this.cp);
/*      */       } 
/*  573 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*      */ 
/*      */     
/*  576 */     return c_exc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addException(String class_name) {
/*  585 */     this.exceptionsThrown.add(class_name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeException(String c) {
/*  592 */     this.exceptionsThrown.remove(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeExceptions() {
/*  599 */     this.exceptionsThrown.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getExceptions() {
/*  606 */     String[] e = new String[this.exceptionsThrown.size()];
/*  607 */     this.exceptionsThrown.toArray(e);
/*  608 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExceptionTable getExceptionTable(ConstantPool cp) {
/*  615 */     int size = this.exceptionsThrown.size();
/*  616 */     int[] ex = new int[size];
/*      */     
/*      */     try {
/*  619 */       for (int i = 0; i < size; i++) {
/*  620 */         ex[i] = cp.addClass((String)this.exceptionsThrown.get(i));
/*      */       }
/*  622 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*      */ 
/*      */     
/*  625 */     return new ExceptionTable(cp.addUtf8("Exceptions"), 2 + 2 * size, ex, cp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCodeAttribute(Attribute a) {
/*  636 */     this.codeAttributesList.add(a);
/*      */   }
/*      */   
/*      */   public void addParameterAnnotationsAsAttribute(ConstantPool cp) {
/*  640 */     if (!this.hasParameterAnnotations) {
/*      */       return;
/*      */     }
/*  643 */     Attribute[] attrs = Utility.getParameterAnnotationAttributes(cp, (List[])this.param_annotations);
/*  644 */     if (attrs != null) {
/*  645 */       for (Attribute attr : attrs) {
/*  646 */         addAttribute(attr);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeCodeAttribute(Attribute a) {
/*  655 */     this.codeAttributesList.remove(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeCodeAttributes() {
/*  662 */     this.codeAttributesList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attribute[] getCodeAttributes() {
/*  669 */     Attribute[] attributes = new Attribute[this.codeAttributesList.size()];
/*  670 */     this.codeAttributesList.toArray(attributes);
/*  671 */     return attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method getMethod() {
/*  681 */     String signature = getSignature();
/*  682 */     int name_index = this.cp.addUtf8(this.name);
/*  683 */     int signature_index = this.cp.addUtf8(signature);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  688 */     byte[] byte_code = null;
/*      */     
/*  690 */     if (this.il != null) {
/*      */       try {
/*  692 */         byte_code = this.il.getByteCode();
/*  693 */       } catch (Exception e) {
/*  694 */         throw new IllegalStateException("Unexpected problem whilst preparing bytecode for " + getClassName() + "." + 
/*  695 */             getName() + getSignature(), e);
/*      */       } 
/*      */     }
/*      */     
/*  699 */     LineNumberTable lnt = null;
/*  700 */     LocalVariableTable lvt = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  706 */     if (this.localVariablesList.size() > 0 && !this.stripAttributes) {
/*  707 */       addCodeAttribute((Attribute)(lvt = getLocalVariableTable(this.cp)));
/*      */     }
/*      */     
/*  710 */     if (this.lineNumbersList.size() > 0 && !this.stripAttributes) {
/*  711 */       addCodeAttribute((Attribute)(lnt = getLineNumberTable(this.cp)));
/*      */     }
/*      */     
/*  714 */     Attribute[] code_attrs = getCodeAttributes();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  719 */     int attrs_len = 0;
/*  720 */     for (Attribute code_attr : code_attrs) {
/*  721 */       attrs_len += code_attr.getLength() + 6;
/*      */     }
/*      */     
/*  724 */     CodeException[] c_exc = getCodeExceptions();
/*  725 */     int exc_len = c_exc.length * 8;
/*      */     
/*  727 */     Code code = null;
/*      */     
/*  729 */     if (this.il != null && !isAbstract()) {
/*      */       
/*  731 */       List<Attribute> attributes = getAttributes();
/*  732 */       for (Attribute a : attributes) {
/*  733 */         if (a instanceof Code) {
/*  734 */           removeAttribute(a);
/*      */         }
/*      */       } 
/*      */       
/*  738 */       code = new Code(this.cp.addUtf8("Code"), 8 + byte_code.length + 2 + exc_len + 2 + attrs_len, this.maxStack, this.maxLocals, byte_code, c_exc, code_attrs, this.cp);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  743 */       addAttribute((Attribute)code);
/*      */     } 
/*      */     
/*  746 */     addAnnotationsAsAttribute(this.cp);
/*  747 */     addParameterAnnotationsAsAttribute(this.cp);
/*      */     
/*  749 */     ExceptionTable et = null;
/*      */     
/*  751 */     if (this.exceptionsThrown.size() > 0) {
/*  752 */       addAttribute((Attribute)(et = getExceptionTable(this.cp)));
/*      */     }
/*      */     
/*  755 */     Method m = new Method(this.modifiers, name_index, signature_index, getAttributesImmutable(), this.cp);
/*      */ 
/*      */ 
/*      */     
/*  759 */     if (lvt != null) {
/*  760 */       removeCodeAttribute((Attribute)lvt);
/*      */     }
/*  762 */     if (lnt != null) {
/*  763 */       removeCodeAttribute((Attribute)lnt);
/*      */     }
/*  765 */     if (code != null) {
/*  766 */       removeAttribute((Attribute)code);
/*      */     }
/*  768 */     if (et != null) {
/*  769 */       removeAttribute((Attribute)et);
/*      */     }
/*      */     
/*  772 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxLocals(int m) {
/*  779 */     this.maxLocals = m;
/*      */   }
/*      */   
/*      */   public int getMaxLocals() {
/*  783 */     return this.maxLocals;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxStack(int m) {
/*  790 */     this.maxStack = m;
/*      */   }
/*      */   
/*      */   public int getMaxStack() {
/*  794 */     return this.maxStack;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/*  801 */     return this.classname;
/*      */   }
/*      */   
/*      */   public void setClassName(String class_name) {
/*  805 */     this.classname = class_name;
/*      */   }
/*      */   
/*      */   public void setReturnType(Type return_type) {
/*  809 */     setType(return_type);
/*      */   }
/*      */   
/*      */   public Type getReturnType() {
/*  813 */     return getType();
/*      */   }
/*      */   
/*      */   public void setArgumentTypes(Type[] arg_types) {
/*  817 */     this.parameterTypes = arg_types;
/*      */   }
/*      */   
/*      */   public Type[] getArgumentTypes() {
/*  821 */     return this.parameterTypes;
/*      */   }
/*      */   
/*      */   public void setArgumentType(int i, Type type) {
/*  825 */     this.parameterTypes[i] = type;
/*      */   }
/*      */   
/*      */   public Type getArgumentType(int i) {
/*  829 */     return this.parameterTypes[i];
/*      */   }
/*      */   
/*      */   public void setArgumentNames(String[] arg_names) {
/*  833 */     this.parameterNames = arg_names;
/*      */   }
/*      */   
/*      */   public String[] getArgumentNames() {
/*  837 */     if (this.parameterNames != null) {
/*  838 */       return (String[])this.parameterNames.clone();
/*      */     }
/*  840 */     return new String[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public void setArgumentName(int i, String name) {
/*  845 */     this.parameterNames[i] = name;
/*      */   }
/*      */   
/*      */   public String getArgumentName(int i) {
/*  849 */     return this.parameterNames[i];
/*      */   }
/*      */   
/*      */   public InstructionList getInstructionList() {
/*  853 */     return this.il;
/*      */   }
/*      */   
/*      */   public void setInstructionList(InstructionList il) {
/*  857 */     this.il = il;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSignature() {
/*  862 */     return Utility.toMethodSignature(this.type, this.parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxStack() {
/*  869 */     if (this.il != null) {
/*  870 */       this.maxStack = getMaxStack(this.cp, this.il, getExceptionHandlers());
/*      */     } else {
/*  872 */       this.maxStack = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxLocals() {
/*  880 */     setMaxLocals(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxLocals(boolean respectLocalVariableTable) {
/*  890 */     if (this.il != null) {
/*  891 */       int max = isStatic() ? 0 : 1;
/*      */       
/*  893 */       if (this.parameterTypes != null) {
/*  894 */         for (Type parameterType : this.parameterTypes) {
/*  895 */           max += parameterType.getSize();
/*      */         }
/*      */       }
/*      */       
/*  899 */       for (InstructionHandle ih = this.il.getStart(); ih != null; ih = ih.getNext()) {
/*  900 */         Instruction ins = ih.getInstruction();
/*      */         
/*  902 */         if (ins instanceof InstructionLV || ins instanceof RET) {
/*  903 */           int index = ins.getIndex() + ins.getType(this.cp).getSize();
/*      */           
/*  905 */           if (index > max) {
/*  906 */             max = index;
/*      */           }
/*      */         } 
/*      */       } 
/*  910 */       if (!respectLocalVariableTable || max > this.maxLocals) {
/*  911 */         this.maxLocals = max;
/*      */       }
/*      */     }
/*  914 */     else if (!respectLocalVariableTable) {
/*  915 */       this.maxLocals = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void stripAttributes(boolean flag) {
/*  921 */     this.stripAttributes = flag;
/*      */   }
/*      */   
/*      */   static final class BranchTarget {
/*      */     InstructionHandle target;
/*      */     int stackDepth;
/*      */     
/*      */     BranchTarget(InstructionHandle target, int stackDepth) {
/*  929 */       this.target = target;
/*  930 */       this.stackDepth = stackDepth;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BranchStack {
/*  935 */     Stack<MethodGen.BranchTarget> branchTargets = new Stack<>();
/*  936 */     Map<InstructionHandle, MethodGen.BranchTarget> visitedTargets = new Hashtable<>();
/*      */     
/*      */     public void push(InstructionHandle target, int stackDepth) {
/*  939 */       if (visited(target)) {
/*      */         return;
/*      */       }
/*      */       
/*  943 */       this.branchTargets.push(visit(target, stackDepth));
/*      */     }
/*      */     
/*      */     public MethodGen.BranchTarget pop() {
/*  947 */       if (!this.branchTargets.empty()) {
/*  948 */         MethodGen.BranchTarget bt = this.branchTargets.pop();
/*  949 */         return bt;
/*      */       } 
/*      */       
/*  952 */       return null;
/*      */     }
/*      */     
/*      */     private final MethodGen.BranchTarget visit(InstructionHandle target, int stackDepth) {
/*  956 */       MethodGen.BranchTarget bt = new MethodGen.BranchTarget(target, stackDepth);
/*  957 */       this.visitedTargets.put(target, bt);
/*      */       
/*  959 */       return bt;
/*      */     }
/*      */     
/*      */     private final boolean visited(InstructionHandle target) {
/*  963 */       return (this.visitedTargets.get(target) != null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getMaxStack(ConstantPool cp, InstructionList il, CodeExceptionGen[] et) {
/*  973 */     BranchStack branchTargets = new BranchStack();
/*      */     
/*  975 */     int stackDepth = 0;
/*  976 */     int maxStackDepth = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  982 */     for (CodeExceptionGen codeExceptionGen : et) {
/*  983 */       InstructionHandle handlerPos = codeExceptionGen.getHandlerPC();
/*  984 */       if (handlerPos != null) {
/*      */         
/*  986 */         maxStackDepth = 1;
/*  987 */         branchTargets.push(handlerPos, 1);
/*      */       } 
/*      */     } 
/*      */     
/*  991 */     InstructionHandle ih = il.getStart();
/*  992 */     while (ih != null) {
/*  993 */       Instruction instruction = ih.getInstruction();
/*  994 */       short opcode = instruction.opcode;
/*  995 */       int prod = instruction.produceStack(cp);
/*  996 */       int con = instruction.consumeStack(cp);
/*  997 */       int delta = prod - con;
/*      */       
/*  999 */       stackDepth += delta;
/* 1000 */       if (stackDepth > maxStackDepth) {
/* 1001 */         maxStackDepth = stackDepth;
/*      */       }
/*      */ 
/*      */       
/* 1005 */       if (instruction instanceof InstructionBranch) {
/* 1006 */         InstructionBranch branch = (InstructionBranch)instruction;
/* 1007 */         if (instruction instanceof InstructionSelect) {
/*      */           
/* 1009 */           InstructionSelect select = (InstructionSelect)branch;
/* 1010 */           InstructionHandle[] targets = select.getTargets();
/* 1011 */           for (InstructionHandle target : targets) {
/* 1012 */             branchTargets.push(target, stackDepth);
/*      */           }
/*      */           
/* 1015 */           ih = null;
/* 1016 */         } else if (!branch.isIfInstruction()) {
/*      */ 
/*      */           
/* 1019 */           if (opcode == 168 || opcode == 201) {
/* 1020 */             branchTargets.push(ih.getNext(), stackDepth - 1);
/*      */           }
/* 1022 */           ih = null;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1027 */         branchTargets.push(branch.getTarget(), stackDepth);
/*      */       
/*      */       }
/* 1030 */       else if (opcode == 191 || opcode == 169 || (opcode >= 172 && opcode <= 177)) {
/*      */         
/* 1032 */         ih = null;
/*      */       } 
/*      */ 
/*      */       
/* 1036 */       if (ih != null) {
/* 1037 */         ih = ih.getNext();
/*      */       }
/*      */       
/* 1040 */       if (ih == null) {
/* 1041 */         BranchTarget bt = branchTargets.pop();
/* 1042 */         if (bt != null) {
/* 1043 */           ih = bt.target;
/* 1044 */           stackDepth = bt.stackDepth;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1048 */     return maxStackDepth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String toString() {
/* 1058 */     String access = Utility.accessToString(this.modifiers);
/* 1059 */     String signature = Utility.toMethodSignature(this.type, this.parameterTypes);
/*      */     
/* 1061 */     signature = Utility.methodSignatureToString(signature, this.name, access, true, getLocalVariableTable(this.cp));
/*      */     
/* 1063 */     StringBuilder buf = new StringBuilder(signature);
/*      */     
/* 1065 */     if (this.exceptionsThrown.size() > 0) {
/* 1066 */       for (String s : this.exceptionsThrown) {
/* 1067 */         buf.append("\n\t\tthrows " + s);
/*      */       }
/*      */     }
/*      */     
/* 1071 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<AnnotationGen> getAnnotationsOnParameter(int i) {
/* 1080 */     ensureExistingParameterAnnotationsUnpacked();
/* 1081 */     if (!this.hasParameterAnnotations || i > this.parameterTypes.length) {
/* 1082 */       return null;
/*      */     }
/* 1084 */     return this.param_annotations[i];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ensureExistingParameterAnnotationsUnpacked() {
/* 1094 */     if (this.haveUnpackedParameterAnnotations) {
/*      */       return;
/*      */     }
/*      */     
/* 1098 */     List<Attribute> attrs = getAttributes();
/* 1099 */     RuntimeParamAnnos paramAnnVisAttr = null;
/* 1100 */     RuntimeParamAnnos paramAnnInvisAttr = null;
/*      */     
/* 1102 */     for (Attribute attribute : attrs) {
/* 1103 */       if (attribute instanceof RuntimeParamAnnos) {
/*      */         
/* 1105 */         if (!this.hasParameterAnnotations) {
/* 1106 */           this.param_annotations = (List<AnnotationGen>[])new List[this.parameterTypes.length];
/* 1107 */           for (int i = 0; i < this.parameterTypes.length; i++) {
/* 1108 */             this.param_annotations[i] = new ArrayList<>();
/*      */           }
/*      */         } 
/*      */         
/* 1112 */         this.hasParameterAnnotations = true;
/* 1113 */         RuntimeParamAnnos rpa = (RuntimeParamAnnos)attribute;
/* 1114 */         if (rpa.areVisible()) {
/* 1115 */           paramAnnVisAttr = rpa;
/*      */         } else {
/* 1117 */           paramAnnInvisAttr = rpa;
/*      */         } 
/* 1119 */         for (int j = 0; j < this.parameterTypes.length; j++) {
/*      */           
/* 1121 */           AnnotationGen[] annos = rpa.getAnnotationsOnParameter(j);
/*      */ 
/*      */ 
/*      */           
/* 1125 */           for (AnnotationGen anAnnotation : annos) {
/* 1126 */             this.param_annotations[j].add(anAnnotation);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1131 */     if (paramAnnVisAttr != null) {
/* 1132 */       removeAttribute((Attribute)paramAnnVisAttr);
/*      */     }
/* 1134 */     if (paramAnnInvisAttr != null) {
/* 1135 */       removeAttribute((Attribute)paramAnnInvisAttr);
/*      */     }
/* 1137 */     this.haveUnpackedParameterAnnotations = true;
/*      */   }
/*      */   
/*      */   private List<AnnotationGen> makeMutableVersion(AnnotationGen[] mutableArray) {
/* 1141 */     List<AnnotationGen> result = new ArrayList<>();
/* 1142 */     for (AnnotationGen annotationGen : mutableArray) {
/* 1143 */       result.add(new AnnotationGen(annotationGen, getConstantPool(), false));
/*      */     }
/* 1145 */     return result;
/*      */   }
/*      */   
/*      */   public void addParameterAnnotation(int parameterIndex, AnnotationGen annotation) {
/* 1149 */     ensureExistingParameterAnnotationsUnpacked();
/* 1150 */     if (!this.hasParameterAnnotations) {
/* 1151 */       this.param_annotations = (List<AnnotationGen>[])new List[this.parameterTypes.length];
/* 1152 */       this.hasParameterAnnotations = true;
/*      */     } 
/* 1154 */     List<AnnotationGen> existingAnnotations = this.param_annotations[parameterIndex];
/* 1155 */     if (existingAnnotations != null) {
/* 1156 */       existingAnnotations.add(annotation);
/*      */     } else {
/* 1158 */       List<AnnotationGen> l = new ArrayList<>();
/* 1159 */       l.add(annotation);
/* 1160 */       this.param_annotations[parameterIndex] = l;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\MethodGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */