/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.apache.bcel.ConstantsInitializer;
/*     */ import org.aspectj.apache.bcel.classfile.ClassFormatException;
/*     */ import org.aspectj.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Type
/*     */ {
/*     */   protected byte type;
/*     */   protected String signature;
/*  81 */   public static final BasicType VOID = new BasicType((byte)12);
/*  82 */   public static final BasicType BOOLEAN = new BasicType((byte)4);
/*  83 */   public static final BasicType INT = new BasicType((byte)10);
/*  84 */   public static final BasicType SHORT = new BasicType((byte)9);
/*  85 */   public static final BasicType BYTE = new BasicType((byte)8);
/*  86 */   public static final BasicType LONG = new BasicType((byte)11);
/*  87 */   public static final BasicType DOUBLE = new BasicType((byte)7);
/*  88 */   public static final BasicType FLOAT = new BasicType((byte)6);
/*  89 */   public static final BasicType CHAR = new BasicType((byte)5);
/*  90 */   public static final ObjectType OBJECT = new ObjectType("java.lang.Object");
/*  91 */   public static final ObjectType STRING = new ObjectType("java.lang.String");
/*  92 */   public static final ArrayType OBJECT_ARRAY = new ArrayType("java.lang.Object", 1);
/*  93 */   public static final ArrayType STRING_ARRAY = new ArrayType("java.lang.String", 1);
/*  94 */   public static final ArrayType CLASS_ARRAY = new ArrayType("java.lang.Class", 1);
/*  95 */   public static final ObjectType STRINGBUFFER = new ObjectType("java.lang.StringBuffer");
/*  96 */   public static final ObjectType STRINGBUILDER = new ObjectType("java.lang.StringBuilder");
/*  97 */   public static final ObjectType THROWABLE = new ObjectType("java.lang.Throwable");
/*  98 */   public static final ObjectType CLASS = new ObjectType("java.lang.Class");
/*  99 */   public static final ObjectType INTEGER = new ObjectType("java.lang.Integer");
/* 100 */   public static final ObjectType EXCEPTION = new ObjectType("java.lang.Exception");
/* 101 */   public static final ObjectType LIST = new ObjectType("java.util.List");
/* 102 */   public static final ObjectType ITERATOR = new ObjectType("java.util.Iterator");
/* 103 */   public static final Type[] NO_ARGS = new Type[0];
/* 104 */   public static final ReferenceType NULL = new ReferenceType() {  }
/*     */   ;
/* 106 */   public static final Type UNKNOWN = new Type((byte)15, "<unknown object>") {  }
/*     */   ;
/* 108 */   public static final Type[] STRINGARRAY1 = new Type[] { STRING };
/* 109 */   public static final Type[] STRINGARRAY2 = new Type[] { STRING, STRING };
/* 110 */   public static final Type[] STRINGARRAY3 = new Type[] { STRING, STRING, STRING };
/* 111 */   public static final Type[] STRINGARRAY4 = new Type[] { STRING, STRING, STRING, STRING };
/* 112 */   public static final Type[] STRINGARRAY5 = new Type[] { STRING, STRING, STRING, STRING, STRING };
/* 113 */   public static final Type[] STRINGARRAY6 = new Type[] { STRING, STRING, STRING, STRING, STRING, STRING };
/* 114 */   public static final Type[] STRINGARRAY7 = new Type[] { STRING, STRING, STRING, STRING, STRING, STRING, STRING };
/*     */   
/* 116 */   private static Map<String, Type> commonTypes = new HashMap<>();
/*     */   
/*     */   static {
/* 119 */     commonTypes.put(STRING.getSignature(), STRING);
/* 120 */     commonTypes.put(THROWABLE.getSignature(), THROWABLE);
/* 121 */     commonTypes.put(VOID.getSignature(), VOID);
/* 122 */     commonTypes.put(BOOLEAN.getSignature(), BOOLEAN);
/* 123 */     commonTypes.put(BYTE.getSignature(), BYTE);
/* 124 */     commonTypes.put(SHORT.getSignature(), SHORT);
/* 125 */     commonTypes.put(CHAR.getSignature(), CHAR);
/* 126 */     commonTypes.put(INT.getSignature(), INT);
/* 127 */     commonTypes.put(LONG.getSignature(), LONG);
/* 128 */     commonTypes.put(DOUBLE.getSignature(), DOUBLE);
/* 129 */     commonTypes.put(FLOAT.getSignature(), FLOAT);
/* 130 */     commonTypes.put(CLASS.getSignature(), CLASS);
/* 131 */     commonTypes.put(OBJECT.getSignature(), OBJECT);
/* 132 */     commonTypes.put(STRING_ARRAY.getSignature(), STRING_ARRAY);
/* 133 */     commonTypes.put(CLASS_ARRAY.getSignature(), CLASS_ARRAY);
/* 134 */     commonTypes.put(OBJECT_ARRAY.getSignature(), OBJECT_ARRAY);
/* 135 */     commonTypes.put(INTEGER.getSignature(), INTEGER);
/* 136 */     commonTypes.put(EXCEPTION.getSignature(), EXCEPTION);
/* 137 */     commonTypes.put(STRINGBUFFER.getSignature(), STRINGBUFFER);
/* 138 */     commonTypes.put(STRINGBUILDER.getSignature(), STRINGBUILDER);
/* 139 */     commonTypes.put(LIST.getSignature(), LIST);
/* 140 */     commonTypes.put(ITERATOR.getSignature(), ITERATOR);
/* 141 */     ConstantsInitializer.initialize();
/*     */   }
/*     */   
/*     */   protected Type(byte t, String s) {
/* 145 */     this.type = t;
/* 146 */     this.signature = s;
/*     */   }
/*     */   
/*     */   public String getSignature() {
/* 150 */     return this.signature;
/*     */   }
/*     */   
/*     */   public byte getType() {
/* 154 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 161 */     switch (this.type) {
/*     */       case 7:
/*     */       case 11:
/* 164 */         return 2;
/*     */       case 12:
/* 166 */         return 0;
/*     */     } 
/* 168 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 177 */     return (equals(NULL) || this.type >= 15) ? this.signature : 
/* 178 */       Utility.signatureToString(this.signature, false);
/*     */   }
/*     */   
/*     */   public static final Type getType(String signature) {
/* 182 */     Type t = commonTypes.get(signature);
/* 183 */     if (t != null) {
/* 184 */       return t;
/*     */     }
/* 186 */     byte type = Utility.typeOfSignature(signature);
/* 187 */     if (type <= 12)
/* 188 */       return BasicType.getType(type); 
/* 189 */     if (type == 13) {
/* 190 */       int dim = 0;
/*     */       do {
/* 192 */         dim++;
/* 193 */       } while (signature.charAt(dim) == '[');
/*     */       
/* 195 */       Type componentType = getType(signature.substring(dim));
/* 196 */       return new ArrayType(componentType, dim);
/*     */     } 
/*     */     
/* 199 */     int nextAngly = signature.indexOf('<');
/*     */     
/* 201 */     int index = signature.indexOf(';');
/*     */     
/* 203 */     String typeString = null;
/* 204 */     if (nextAngly == -1 || nextAngly > index) {
/* 205 */       typeString = signature.substring(1, index).replace('/', '.');
/*     */     } else {
/* 207 */       boolean endOfSigReached = false;
/* 208 */       int posn = nextAngly;
/* 209 */       int genericDepth = 0;
/* 210 */       while (!endOfSigReached) {
/* 211 */         switch (signature.charAt(posn++)) {
/*     */           case '<':
/* 213 */             genericDepth++;
/*     */           
/*     */           case '>':
/* 216 */             genericDepth--;
/*     */           
/*     */           case ';':
/* 219 */             if (genericDepth == 0) {
/* 220 */               endOfSigReached = true;
/*     */             }
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 226 */       index = posn - 1;
/* 227 */       typeString = signature.substring(1, nextAngly).replace('/', '.');
/*     */     } 
/*     */     
/* 230 */     return new ObjectType(typeString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final TypeHolder getTypeInternal(String signature) throws StringIndexOutOfBoundsException {
/* 241 */     byte type = Utility.typeOfSignature(signature);
/*     */     
/* 243 */     if (type <= 12)
/* 244 */       return new TypeHolder(BasicType.getType(type), 1); 
/* 245 */     if (type == 13) {
/* 246 */       int dim = 0;
/*     */       do {
/* 248 */         dim++;
/* 249 */       } while (signature.charAt(dim) == '[');
/*     */       
/* 251 */       TypeHolder th = getTypeInternal(signature.substring(dim));
/* 252 */       return new TypeHolder(new ArrayType(th.getType(), dim), dim + th.getConsumed());
/*     */     } 
/*     */     
/* 255 */     int index = signature.indexOf(';');
/* 256 */     if (index < 0) {
/* 257 */       throw new ClassFormatException("Invalid signature: " + signature);
/*     */     }
/*     */ 
/*     */     
/* 261 */     int nextAngly = signature.indexOf('<');
/* 262 */     String typeString = null;
/* 263 */     if (nextAngly == -1 || nextAngly > index) {
/* 264 */       typeString = signature.substring(1, index).replace('/', '.');
/*     */     } else {
/* 266 */       boolean endOfSigReached = false;
/* 267 */       int posn = nextAngly;
/* 268 */       int genericDepth = 0;
/* 269 */       while (!endOfSigReached) {
/* 270 */         switch (signature.charAt(posn++)) {
/*     */           case '<':
/* 272 */             genericDepth++;
/*     */           
/*     */           case '>':
/* 275 */             genericDepth--;
/*     */           
/*     */           case ';':
/* 278 */             if (genericDepth == 0) {
/* 279 */               endOfSigReached = true;
/*     */             }
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 285 */       index = posn - 1;
/* 286 */       typeString = signature.substring(1, nextAngly).replace('/', '.');
/*     */     } 
/*     */     
/* 289 */     return new TypeHolder(new ObjectType(typeString), index + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getReturnType(String signature) {
/*     */     try {
/* 302 */       int index = signature.lastIndexOf(')') + 1;
/* 303 */       return getType(signature.substring(index));
/* 304 */     } catch (StringIndexOutOfBoundsException e) {
/* 305 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type[] getArgumentTypes(String signature) {
/* 317 */     List<Type> argumentTypes = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 322 */       if (signature.charAt(0) != '(') {
/* 323 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*     */       }
/*     */       
/* 326 */       int index = 1;
/*     */       
/* 328 */       while (signature.charAt(index) != ')') {
/* 329 */         TypeHolder th = getTypeInternal(signature.substring(index));
/* 330 */         argumentTypes.add(th.getType());
/* 331 */         index += th.getConsumed();
/*     */       } 
/* 333 */     } catch (StringIndexOutOfBoundsException e) {
/* 334 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*     */     } 
/*     */     
/* 337 */     Type[] types = new Type[argumentTypes.size()];
/* 338 */     argumentTypes.toArray(types);
/* 339 */     return types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getArgumentSizes(String signature) {
/* 347 */     int size = 0;
/* 348 */     if (signature.charAt(0) != '(') {
/* 349 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*     */     }
/*     */     
/* 352 */     int index = 1;
/*     */     try {
/* 354 */       while (signature.charAt(index) != ')') {
/* 355 */         byte type = Utility.typeOfSignature(signature.charAt(index));
/* 356 */         if (type <= 12) {
/* 357 */           size += BasicType.getType(type).getSize();
/* 358 */           index++; continue;
/* 359 */         }  if (type == 13) {
/* 360 */           int dim = 0;
/*     */           while (true) {
/* 362 */             dim++;
/* 363 */             if (signature.charAt(dim + index) != '[') {
/* 364 */               TypeHolder th = getTypeInternal(signature.substring(dim + index));
/* 365 */               size++;
/* 366 */               index += dim + th.getConsumed();
/*     */             } 
/*     */           } 
/* 369 */         }  int index2 = signature.indexOf(';', index);
/*     */ 
/*     */         
/* 372 */         int nextAngly = signature.indexOf('<', index);
/* 373 */         if (nextAngly != -1 && nextAngly <= index2) {
/*     */           
/* 375 */           boolean endOfSigReached = false;
/* 376 */           int posn = nextAngly;
/* 377 */           int genericDepth = 0;
/* 378 */           while (!endOfSigReached) {
/* 379 */             switch (signature.charAt(posn++)) {
/*     */               case '<':
/* 381 */                 genericDepth++;
/*     */               
/*     */               case '>':
/* 384 */                 genericDepth--;
/*     */               
/*     */               case ';':
/* 387 */                 if (genericDepth == 0) {
/* 388 */                   endOfSigReached = true;
/*     */                 }
/*     */             } 
/*     */ 
/*     */           
/*     */           } 
/* 394 */           index2 = posn - 1;
/*     */         } 
/* 396 */         size++;
/* 397 */         index = index2 + 1;
/*     */       }
/*     */     
/* 400 */     } catch (StringIndexOutOfBoundsException e) {
/* 401 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*     */     } 
/* 403 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTypeSize(String signature) {
/* 410 */     byte type = Utility.typeOfSignature(signature.charAt(0));
/* 411 */     if (type <= 12)
/* 412 */       return BasicType.getType(type).getSize(); 
/* 413 */     if (type == 13) {
/* 414 */       return 1;
/*     */     }
/* 416 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getType(Class<int> cl) {
/* 427 */     if (cl == null) {
/* 428 */       throw new IllegalArgumentException("Class must not be null");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     if (cl.isArray())
/* 435 */       return getType(cl.getName()); 
/* 436 */     if (cl.isPrimitive()) {
/* 437 */       if (cl == int.class)
/* 438 */         return INT; 
/* 439 */       if (cl == void.class)
/* 440 */         return VOID; 
/* 441 */       if (cl == double.class)
/* 442 */         return DOUBLE; 
/* 443 */       if (cl == float.class)
/* 444 */         return FLOAT; 
/* 445 */       if (cl == boolean.class)
/* 446 */         return BOOLEAN; 
/* 447 */       if (cl == byte.class)
/* 448 */         return BYTE; 
/* 449 */       if (cl == short.class)
/* 450 */         return SHORT; 
/* 451 */       if (cl == byte.class)
/* 452 */         return BYTE; 
/* 453 */       if (cl == long.class)
/* 454 */         return LONG; 
/* 455 */       if (cl == char.class) {
/* 456 */         return CHAR;
/*     */       }
/* 458 */       throw new IllegalStateException("Ooops, what primitive type is " + cl);
/*     */     } 
/*     */     
/* 461 */     return new ObjectType(cl.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getSignature(Method meth) {
/* 466 */     StringBuilder sb = new StringBuilder("(");
/* 467 */     Class[] params = meth.getParameterTypes();
/*     */     
/* 469 */     for (Class param : params) {
/* 470 */       sb.append(getType(param).getSignature());
/*     */     }
/*     */     
/* 473 */     sb.append(")");
/* 474 */     sb.append(getType(meth.getReturnType()).getSignature());
/* 475 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getSignature(Constructor<?> cons) {
/* 479 */     StringBuilder sb = new StringBuilder("(");
/* 480 */     Class<?>[] params = cons.getParameterTypes();
/*     */     
/* 482 */     for (Class<?> param : params) {
/* 483 */       sb.append(getType(param).getSignature());
/*     */     }
/*     */     
/* 486 */     sb.append(")V");
/* 487 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static class TypeHolder {
/*     */     private Type t;
/*     */     private int consumed;
/*     */     
/*     */     public Type getType() {
/* 495 */       return this.t;
/*     */     }
/*     */     
/*     */     public int getConsumed() {
/* 499 */       return this.consumed;
/*     */     }
/*     */     
/*     */     public TypeHolder(Type t, int i) {
/* 503 */       this.t = t;
/* 504 */       this.consumed = i;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\Type.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */