/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Instruction
/*     */   implements Cloneable, Serializable, Constants
/*     */ {
/*  72 */   public short opcode = -1;
/*     */   
/*     */   public Instruction(short opcode) {
/*  75 */     this.opcode = opcode;
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  79 */     out.writeByte(this.opcode);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  83 */     return Constants.OPCODE_NAMES[this.opcode];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Instruction copy() {
/*  95 */     if (InstructionConstants.INSTRUCTIONS[this.opcode] != null) {
/*  96 */       return this;
/*     */     }
/*  98 */     Instruction i = null;
/*     */     try {
/* 100 */       i = (Instruction)clone();
/* 101 */     } catch (CloneNotSupportedException e) {
/* 102 */       System.err.println(e);
/*     */     } 
/* 104 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Instruction readInstruction(ByteSequence bytes) throws IOException {
/* 115 */     boolean wide = false;
/* 116 */     short opcode = (short)bytes.readUnsignedByte();
/*     */     
/* 118 */     if (opcode == 196) {
/* 119 */       wide = true;
/* 120 */       opcode = (short)bytes.readUnsignedByte();
/*     */     } 
/*     */     
/* 123 */     Instruction constantInstruction = InstructionConstants.INSTRUCTIONS[opcode];
/*     */     
/* 125 */     if (constantInstruction != null) {
/* 126 */       return constantInstruction;
/*     */     }
/*     */     
/* 129 */     Instruction obj = null;
/*     */     try {
/* 131 */       switch (opcode) {
/*     */         case 16:
/* 133 */           obj = new InstructionByte((short)16, bytes.readByte());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 236 */           return obj;case 17: obj = new InstructionShort((short)17, bytes.readShort()); return obj;case 18: obj = new InstructionCP((short)18, bytes.readUnsignedByte()); return obj;case 19: case 20: obj = new InstructionCP(opcode, bytes.readUnsignedShort()); return obj;case 21: case 22: case 23: case 24: case 25: case 54: case 55: case 56: case 57: case 58: obj = new InstructionLV(opcode, wide ? bytes.readUnsignedShort() : bytes.readUnsignedByte()); return obj;case 132: obj = new IINC(wide ? bytes.readUnsignedShort() : bytes.readUnsignedByte(), wide ? bytes.readShort() : bytes.readByte(), wide); return obj;case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161: case 162: case 163: case 164: case 165: case 166: case 167: case 168: case 198: case 199: obj = new InstructionBranch(opcode, bytes.readShort()); return obj;case 200: case 201: obj = new InstructionBranch(opcode, bytes.readInt()); return obj;case 170: obj = new TABLESWITCH(bytes); return obj;case 171: obj = new LOOKUPSWITCH(bytes); return obj;case 169: obj = new RET(wide ? bytes.readUnsignedShort() : bytes.readUnsignedByte(), wide); return obj;case 187: obj = new InstructionCP((short)187, bytes.readUnsignedShort()); return obj;case 178: case 179: case 180: case 181: obj = new FieldInstruction(opcode, bytes.readUnsignedShort()); return obj;case 182: case 183: case 184: obj = new InvokeInstruction(opcode, bytes.readUnsignedShort()); return obj;case 185: obj = new INVOKEINTERFACE(bytes.readUnsignedShort(), bytes.readUnsignedByte(), bytes.readByte()); return obj;case 186: obj = new InvokeDynamic(bytes.readUnsignedShort(), bytes.readUnsignedShort()); return obj;case 188: obj = new InstructionByte((short)188, bytes.readByte()); return obj;case 189: case 192: obj = new InstructionCP(opcode, bytes.readUnsignedShort()); return obj;case 193: obj = new InstructionCP((short)193, bytes.readUnsignedShort()); return obj;case 197: obj = new MULTIANEWARRAY(bytes.readUnsignedShort(), (short)bytes.readByte()); return obj;
/*     */       } 
/*     */       throw new ClassGenException("Illegal opcode detected");
/*     */     } catch (ClassGenException e) {
/*     */       throw e;
/*     */     } catch (Exception e) {
/*     */       throw new ClassGenException(e.toString());
/*     */     }  } public int consumeStack(ConstantPool cpg) {
/* 244 */     return Constants.CONSUME_STACK[this.opcode];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int produceStack(ConstantPool cpg) {
/* 252 */     return Constants.stackEntriesProduced[this.opcode];
/*     */   }
/*     */   
/*     */   public short getOpcode() {
/* 256 */     return this.opcode;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 261 */     int len = Constants.iLen[this.opcode];
/* 262 */     assert len != 0;
/*     */ 
/*     */ 
/*     */     
/* 266 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {}
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 275 */     if (getClass() != Instruction.class) {
/* 276 */       throw new RuntimeException("NO WAY " + getClass());
/*     */     }
/* 278 */     if (!(other instanceof Instruction)) {
/* 279 */       return false;
/*     */     }
/* 281 */     return (((Instruction)other).opcode == this.opcode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 304 */     if (getClass() != Instruction.class) {
/* 305 */       throw new RuntimeException("NO WAY " + getClass());
/*     */     }
/* 307 */     return this.opcode * 37;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 320 */     return getType(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType(ConstantPool cp) {
/* 325 */     Type t = Constants.types[this.opcode];
/* 326 */     if (t != null) {
/* 327 */       return t;
/*     */     }
/* 329 */     throw new RuntimeException("Do not know type for instruction " + getName() + "(" + this.opcode + ")");
/*     */   }
/*     */   
/*     */   public Number getValue() {
/* 333 */     assert (instFlags[this.opcode] & 0x2L) == 0L;
/*     */ 
/*     */ 
/*     */     
/* 337 */     switch (this.opcode) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/* 345 */         return Integer.valueOf(this.opcode - 3);
/*     */     } 
/* 347 */     throw new IllegalStateException("Not implemented yet for " + getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIndex() {
/* 352 */     return -1;
/*     */   }
/*     */   
/*     */   public void setIndex(int i) {
/* 356 */     throw new IllegalStateException("Shouldnt be asking " + getName().toUpperCase());
/*     */   }
/*     */   
/*     */   public Object getValue(ConstantPool cpg) {
/* 360 */     throw new IllegalStateException("Shouldnt be asking " + getName().toUpperCase());
/*     */   }
/*     */   
/*     */   public boolean isLoadInstruction() {
/* 364 */     return ((Constants.instFlags[this.opcode] & 0x20L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isASTORE() {
/* 369 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isALOAD() {
/* 373 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isStoreInstruction() {
/* 377 */     return ((Constants.instFlags[this.opcode] & 0x100L) != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isJsrInstruction() {
/* 385 */     return ((Constants.instFlags[this.opcode] & 0x4000L) != 0L);
/*     */   }
/*     */   
/*     */   public boolean isConstantInstruction() {
/* 389 */     return ((Constants.instFlags[this.opcode] & 0x2L) != 0L);
/*     */   }
/*     */   
/*     */   public boolean isConstantPoolInstruction() {
/* 393 */     return ((Constants.instFlags[this.opcode] & 0x8L) != 0L);
/*     */   }
/*     */   
/*     */   public boolean isStackProducer() {
/* 397 */     return (Constants.stackEntriesProduced[this.opcode] != 0);
/*     */   }
/*     */   
/*     */   public boolean isStackConsumer() {
/* 401 */     return (Constants.CONSUME_STACK[this.opcode] != 0);
/*     */   }
/*     */   
/*     */   public boolean isIndexedInstruction() {
/* 405 */     return ((Constants.instFlags[this.opcode] & 0x10L) != 0L);
/*     */   }
/*     */   
/*     */   public boolean isArrayCreationInstruction() {
/* 409 */     return (this.opcode == 188 || this.opcode == 189 || this.opcode == 197);
/*     */   }
/*     */   
/*     */   public ObjectType getLoadClassType(ConstantPool cpg) {
/* 413 */     assert (Constants.instFlags[this.opcode] & 0x4L) == 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 418 */     Type t = getType(cpg);
/* 419 */     if (t instanceof ArrayType) {
/* 420 */       t = ((ArrayType)t).getBasicType();
/*     */     }
/* 422 */     return (t instanceof ObjectType) ? (ObjectType)t : null;
/*     */   }
/*     */   
/*     */   public boolean isReturnInstruction() {
/* 426 */     return ((Constants.instFlags[this.opcode] & 0x8000L) != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocalVariableInstruction() {
/* 434 */     return ((Constants.instFlags[this.opcode] & 0x40L) != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 441 */     if (verbose) {
/* 442 */       StringBuilder sb = new StringBuilder();
/* 443 */       sb.append(getName()).append("[").append(this.opcode).append("](size").append(Constants.iLen[this.opcode]).append(")");
/* 444 */       return sb.toString();
/*     */     } 
/* 446 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 452 */     return toString(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\Instruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */