/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RET
/*     */   extends Instruction
/*     */ {
/*     */   private boolean wide;
/*     */   private int index;
/*     */   
/*     */   public RET(int index, boolean wide) {
/*  77 */     super((short)169);
/*  78 */     this.index = index;
/*  79 */     this.wide = wide;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  84 */     if (this.wide) {
/*  85 */       out.writeByte(196);
/*     */     }
/*  87 */     out.writeByte(this.opcode);
/*  88 */     if (this.wide) {
/*  89 */       out.writeShort(this.index);
/*     */     } else {
/*  91 */       out.writeByte(this.index);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLength() {
/*  96 */     if (this.wide) {
/*  97 */       return 4;
/*     */     }
/*  99 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getIndex() {
/* 104 */     return this.index;
/*     */   }
/*     */   
/*     */   public final void setIndex(int index) {
/* 108 */     this.index = index;
/* 109 */     this.wide = (index > 255);
/*     */   }
/*     */   
/*     */   public String toString(boolean verbose) {
/* 113 */     return super.toString(verbose) + " " + this.index;
/*     */   }
/*     */   
/*     */   public Type getType(ConstantPool cp) {
/* 117 */     return ReturnaddressType.NO_TARGET;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 121 */     if (!(other instanceof RET)) {
/* 122 */       return false;
/*     */     }
/* 124 */     RET o = (RET)other;
/* 125 */     return (o.opcode == this.opcode && o.index == this.index);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 129 */     return this.opcode * 37 + this.index;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\RET.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */