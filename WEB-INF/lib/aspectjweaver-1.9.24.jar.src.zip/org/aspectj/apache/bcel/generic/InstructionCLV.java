/*    */ package org.aspectj.apache.bcel.generic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstructionCLV
/*    */   extends InstructionLV
/*    */ {
/*    */   public InstructionCLV(short opcode) {
/* 10 */     super(opcode);
/*    */   }
/*    */   
/*    */   public InstructionCLV(short opcode, int localVariableIndex) {
/* 14 */     super(opcode, localVariableIndex);
/*    */   }
/*    */   
/*    */   public void setIndex(int localVariableIndex) {
/* 18 */     if (localVariableIndex != getIndex()) {
/* 19 */       throw new ClassGenException("Do not attempt to modify the index to '" + localVariableIndex + "' for this constant instruction: " + this);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canSetIndex() {
/* 24 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionCLV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */