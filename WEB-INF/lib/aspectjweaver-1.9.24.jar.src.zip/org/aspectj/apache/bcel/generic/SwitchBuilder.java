/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SwitchBuilder
/*     */ {
/*     */   private int[] match;
/*     */   private InstructionHandle[] targets;
/*     */   private InstructionSelect instruction;
/*     */   private int match_length;
/*     */   
/*     */   public SwitchBuilder(int[] match, InstructionHandle[] targets, InstructionHandle target, int max_gap) {
/*  87 */     this.match = (int[])match.clone();
/*  88 */     this.targets = (InstructionHandle[])targets.clone();
/*     */     
/*  90 */     if ((this.match_length = match.length) < 2) {
/*  91 */       if (match.length == 0) {
/*  92 */         this.instruction = new LOOKUPSWITCH(match, targets, target);
/*     */       } else {
/*  94 */         this.instruction = new TABLESWITCH(match, targets, target);
/*     */       } 
/*     */     } else {
/*  97 */       sort(0, this.match_length - 1);
/*     */       
/*  99 */       if (matchIsOrdered(max_gap)) {
/* 100 */         fillup(max_gap, target);
/*     */         
/* 102 */         this.instruction = new TABLESWITCH(this.match, this.targets, target);
/*     */       } else {
/*     */         
/* 105 */         this.instruction = new LOOKUPSWITCH(this.match, this.targets, target);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public SwitchBuilder(int[] match, InstructionHandle[] targets, InstructionHandle target) {
/* 110 */     this(match, targets, target, 1);
/*     */   }
/*     */   
/*     */   private final void fillup(int max_gap, InstructionHandle target) {
/* 114 */     int max_size = this.match_length + this.match_length * max_gap;
/* 115 */     int[] m_vec = new int[max_size];
/* 116 */     InstructionHandle[] t_vec = new InstructionHandle[max_size];
/* 117 */     int count = 1;
/*     */     
/* 119 */     m_vec[0] = this.match[0];
/* 120 */     t_vec[0] = this.targets[0];
/*     */     
/* 122 */     for (int i = 1; i < this.match_length; i++) {
/* 123 */       int prev = this.match[i - 1];
/* 124 */       int gap = this.match[i] - prev;
/*     */       
/* 126 */       for (int j = 1; j < gap; j++) {
/* 127 */         m_vec[count] = prev + j;
/* 128 */         t_vec[count] = target;
/* 129 */         count++;
/*     */       } 
/*     */       
/* 132 */       m_vec[count] = this.match[i];
/* 133 */       t_vec[count] = this.targets[i];
/* 134 */       count++;
/*     */     } 
/*     */     
/* 137 */     this.match = new int[count];
/* 138 */     this.targets = new InstructionHandle[count];
/*     */     
/* 140 */     System.arraycopy(m_vec, 0, this.match, 0, count);
/* 141 */     System.arraycopy(t_vec, 0, this.targets, 0, count);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void sort(int l, int r) {
/* 148 */     int i = l, j = r;
/* 149 */     int m = this.match[(l + r) / 2];
/*     */ 
/*     */     
/*     */     do {
/* 153 */       for (; this.match[i] < m; i++);
/* 154 */       for (; m < this.match[j]; j--);
/*     */       
/* 156 */       if (i > j)
/* 157 */         continue;  int h = this.match[i]; this.match[i] = this.match[j]; this.match[j] = h;
/* 158 */       InstructionHandle h2 = this.targets[i]; this.targets[i] = this.targets[j]; this.targets[j] = h2;
/* 159 */       i++; j--;
/*     */     }
/* 161 */     while (i <= j);
/*     */     
/* 163 */     if (l < j) sort(l, j); 
/* 164 */     if (i < r) sort(i, r);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean matchIsOrdered(int max_gap) {
/* 171 */     for (int i = 1; i < this.match_length; i++) {
/* 172 */       int diff = this.match[i] - this.match[i - 1];
/* 173 */       if (diff > max_gap || diff < 0) return false; 
/*     */     } 
/* 175 */     return true;
/*     */   }
/*     */   
/*     */   public final InstructionSelect getInstruction() {
/* 179 */     return this.instruction;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\SwitchBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */