/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantInvokeDynamic;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InvokeDynamic
/*     */   extends InvokeInstruction
/*     */ {
/*     */   public InvokeDynamic(int index, int zeroes) {
/*  73 */     super((short)186, index);
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  77 */     out.writeByte(this.opcode);
/*  78 */     out.writeShort(this.index);
/*  79 */     out.writeShort(0);
/*     */   }
/*     */   
/*     */   public String toString(ConstantPool cp) {
/*  83 */     return super.toString(cp) + " " + this.index;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  87 */     if (!(other instanceof InvokeDynamic)) {
/*  88 */       return false;
/*     */     }
/*  90 */     InvokeDynamic o = (InvokeDynamic)other;
/*  91 */     return (o.opcode == this.opcode && o.index == this.index);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  95 */     return this.opcode * 37 + this.index;
/*     */   }
/*     */   
/*     */   public Type getReturnType(ConstantPool cp) {
/*  99 */     return Type.getReturnType(getSignature(cp));
/*     */   }
/*     */   
/*     */   public Type[] getArgumentTypes(ConstantPool cp) {
/* 103 */     return Type.getArgumentTypes(getSignature(cp));
/*     */   }
/*     */   
/*     */   public String getSignature(ConstantPool cp) {
/* 107 */     if (this.signature == null) {
/* 108 */       ConstantInvokeDynamic cid = (ConstantInvokeDynamic)cp.getConstant(this.index);
/* 109 */       ConstantNameAndType cnat = (ConstantNameAndType)cp.getConstant(cid.getNameAndTypeIndex());
/* 110 */       this.signature = cp.getConstantUtf8(cnat.getSignatureIndex()).getValue();
/*     */     } 
/* 112 */     return this.signature;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName(ConstantPool cp) {
/* 117 */     if (this.name == null) {
/* 118 */       ConstantInvokeDynamic cid = (ConstantInvokeDynamic)cp.getConstant(this.index);
/* 119 */       ConstantNameAndType cnat = (ConstantNameAndType)cp.getConstant(cid.getNameAndTypeIndex());
/* 120 */       this.name = cp.getConstantUtf8(cnat.getNameIndex()).getValue();
/*     */     } 
/* 122 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getClassName(ConstantPool cp) {
/* 126 */     throw new IllegalStateException("there is no classname for invokedynamic");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InvokeDynamic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */