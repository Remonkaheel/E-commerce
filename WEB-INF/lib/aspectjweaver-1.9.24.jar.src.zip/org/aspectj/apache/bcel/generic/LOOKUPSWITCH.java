/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LOOKUPSWITCH
/*     */   extends InstructionSelect
/*     */ {
/*     */   public LOOKUPSWITCH(int[] match, InstructionHandle[] targets, InstructionHandle target) {
/*  71 */     super((short)171, match, targets, target);
/*     */     
/*  73 */     this.length = (short)(9 + this.matchLength * 8);
/*  74 */     this.fixedLength = this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  83 */     super.dump(out);
/*  84 */     out.writeInt(this.matchLength);
/*     */     
/*  86 */     for (int i = 0; i < this.matchLength; i++) {
/*  87 */       out.writeInt(this.match[i]);
/*  88 */       out.writeInt(this.indices[i] = getTargetOffset(this.targets[i]));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LOOKUPSWITCH(ByteSequence bytes) throws IOException {
/*  96 */     super((short)171, bytes);
/*     */     
/*  98 */     this.matchLength = bytes.readInt();
/*  99 */     this.fixedLength = (short)(9 + this.matchLength * 8);
/* 100 */     this.length = (short)(this.fixedLength + this.padding);
/*     */     
/* 102 */     this.match = new int[this.matchLength];
/* 103 */     this.indices = new int[this.matchLength];
/* 104 */     this.targets = new InstructionHandle[this.matchLength];
/*     */     
/* 106 */     for (int i = 0; i < this.matchLength; i++) {
/* 107 */       this.match[i] = bytes.readInt();
/* 108 */       this.indices[i] = bytes.readInt();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\LOOKUPSWITCH.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */