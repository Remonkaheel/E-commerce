/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionBranch
/*     */   extends Instruction
/*     */   implements InstructionTargeter
/*     */ {
/*     */   private static final int UNSET = -1;
/*  74 */   protected int targetIndex = -1;
/*     */ 
/*     */   
/*     */   protected InstructionHandle targetInstruction;
/*     */   
/*     */   protected int positionOfThisInstruction;
/*     */ 
/*     */   
/*     */   public InstructionBranch(short opcode, InstructionHandle target) {
/*  83 */     super(opcode);
/*  84 */     setTarget(target);
/*     */   }
/*     */   
/*     */   public InstructionBranch(short opcode, int index) {
/*  88 */     super(opcode);
/*  89 */     this.targetIndex = index;
/*     */   }
/*     */   
/*     */   public InstructionBranch(short opcode) {
/*  93 */     super(opcode);
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  97 */     int target = getTargetOffset();
/*     */     
/*  99 */     if (Math.abs(target) >= 32767 && this.opcode != 200 && this.opcode != 201) {
/* 100 */       throw new ClassGenException("Branch target offset too large for short.  Instruction: " + getName().toUpperCase() + "(" + this.opcode + ")");
/*     */     }
/*     */ 
/*     */     
/* 104 */     out.writeByte(this.opcode);
/*     */     
/* 106 */     switch (this.opcode) {
/*     */       
/*     */       case 200:
/*     */       case 201:
/* 110 */         out.writeInt(target);
/*     */         return;
/*     */       
/*     */       case 153:
/*     */       case 154:
/*     */       case 155:
/*     */       case 156:
/*     */       case 157:
/*     */       case 158:
/*     */       case 159:
/*     */       case 160:
/*     */       case 161:
/*     */       case 162:
/*     */       case 163:
/*     */       case 164:
/*     */       case 165:
/*     */       case 166:
/*     */       case 167:
/*     */       case 168:
/*     */       case 198:
/*     */       case 199:
/* 131 */         out.writeShort(target);
/*     */         return;
/*     */     } 
/*     */     
/* 135 */     throw new IllegalStateException("Don't know how to write out " + getName().toUpperCase());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getTargetOffset() {
/* 141 */     if (this.targetInstruction == null && this.targetIndex == -1) {
/* 142 */       throw new ClassGenException("Target of " + super.toString(true) + " is unknown");
/*     */     }
/*     */     
/* 145 */     if (this.targetInstruction == null) {
/* 146 */       return this.targetIndex;
/*     */     }
/* 148 */     return this.targetInstruction.getPosition() - this.positionOfThisInstruction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 162 */     int i = getTargetOffset();
/*     */     
/* 164 */     this.positionOfThisInstruction += offset;
/*     */     
/* 166 */     if (Math.abs(i) >= 32767 - max_offset && this.opcode != 201 && this.opcode != 200) {
/*     */       
/* 168 */       if (this.opcode == 168 || this.opcode == 167) {
/* 169 */         if (this.opcode == 168) {
/* 170 */           this.opcode = 201;
/*     */         } else {
/* 172 */           this.opcode = 200;
/*     */         } 
/* 174 */         return 2;
/*     */       } 
/* 176 */       throw new IllegalStateException("Unable to pack method, jump (with opcode=" + this.opcode + ") is too far: " + 
/* 177 */           Math.abs(i));
/*     */     } 
/*     */ 
/*     */     
/* 181 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 191 */     String s = super.toString(verbose);
/* 192 */     String t = "null";
/*     */     
/* 194 */     if (verbose) {
/* 195 */       if (this.targetInstruction != null) {
/* 196 */         if (this.targetInstruction.getInstruction() == this) {
/* 197 */           t = "<points to itself>";
/* 198 */         } else if (this.targetInstruction.getInstruction() == null) {
/* 199 */           t = "<null destination>";
/*     */         } else {
/* 201 */           t = this.targetInstruction.getInstruction().toString(false);
/*     */         }
/*     */       
/*     */       }
/* 205 */     } else if (this.targetInstruction != null) {
/* 206 */       this.targetIndex = getTargetOffset();
/* 207 */       t = "" + (this.targetIndex + this.positionOfThisInstruction);
/*     */     } 
/*     */ 
/*     */     
/* 211 */     return s + " -> " + t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getIndex() {
/* 218 */     return this.targetIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionHandle getTarget() {
/* 225 */     return this.targetInstruction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(InstructionHandle target) {
/* 234 */     notifyTarget(this.targetInstruction, target, this);
/* 235 */     this.targetInstruction = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final void notifyTarget(InstructionHandle oldHandle, InstructionHandle newHandle, InstructionTargeter t) {
/* 242 */     if (oldHandle != null) {
/* 243 */       oldHandle.removeTargeter(t);
/*     */     }
/* 245 */     if (newHandle != null) {
/* 246 */       newHandle.addTargeter(t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle oldHandle, InstructionHandle newHandle) {
/* 258 */     if (this.targetInstruction == oldHandle) {
/* 259 */       setTarget(newHandle);
/*     */     } else {
/* 261 */       throw new ClassGenException("Not targeting " + oldHandle + ", but " + this.targetInstruction);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTarget(InstructionHandle ih) {
/* 269 */     return (this.targetInstruction == ih);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 276 */     setTarget((InstructionHandle)null);
/* 277 */     this.targetIndex = -1;
/* 278 */     this.positionOfThisInstruction = -1;
/*     */   }
/*     */   
/*     */   public Type getType(ConstantPool cp) {
/* 282 */     if ((Constants.instFlags[this.opcode] & 0x4000L) != 0L) {
/* 283 */       return new ReturnaddressType(physicalSuccessor());
/*     */     }
/* 285 */     return super.getType(cp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionHandle physicalSuccessor() {
/* 296 */     InstructionHandle ih = this.targetInstruction;
/*     */ 
/*     */     
/* 299 */     while (ih.getPrev() != null) {
/* 300 */       ih = ih.getPrev();
/*     */     }
/*     */ 
/*     */     
/* 304 */     while (ih.getInstruction() != this) {
/* 305 */       ih = ih.getNext();
/*     */     }
/*     */     
/* 308 */     InstructionHandle toThis = ih;
/*     */     
/* 310 */     while (ih != null) {
/* 311 */       ih = ih.getNext();
/* 312 */       if (ih != null && ih.getInstruction() == this) {
/* 313 */         throw new RuntimeException("physicalSuccessor() called on a shared JsrInstruction.");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 318 */     return toThis.getNext();
/*     */   }
/*     */   
/*     */   public boolean isIfInstruction() {
/* 322 */     return ((Constants.instFlags[this.opcode] & 0x2000L) != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 330 */     return (this == other);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 334 */     int result = 17;
/* 335 */     result = this.opcode * 37 + result;
/* 336 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionBranch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */