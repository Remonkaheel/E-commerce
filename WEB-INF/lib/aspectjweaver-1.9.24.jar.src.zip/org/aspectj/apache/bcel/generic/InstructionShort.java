/*    */ package org.aspectj.apache.bcel.generic;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstructionShort
/*    */   extends Instruction
/*    */ {
/*    */   private final short value;
/*    */   
/*    */   public InstructionShort(short opcode, short value) {
/* 67 */     super(opcode);
/* 68 */     this.value = value;
/*    */   }
/*    */   
/*    */   public void dump(DataOutputStream out) throws IOException {
/* 72 */     out.writeByte(this.opcode);
/* 73 */     out.writeShort(this.value);
/*    */   }
/*    */   
/*    */   public String toString(boolean verbose) {
/* 77 */     return super.toString(verbose) + " " + this.value;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 81 */     if (!(other instanceof InstructionShort)) {
/* 82 */       return false;
/*    */     }
/* 84 */     InstructionShort o = (InstructionShort)other;
/* 85 */     return (o.opcode == this.opcode && o.value == this.value);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 89 */     return this.opcode * 37 + this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionShort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */