/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import org.aspectj.apache.bcel.Repository;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectType
/*     */   extends ReferenceType
/*     */ {
/*     */   private String classname;
/*     */   
/*     */   public ObjectType(String class_name) {
/*  73 */     super((byte)14, toSignature(class_name));
/*  74 */     this.classname = class_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectType(String classname, String signature) {
/*  82 */     super((byte)14, signature);
/*  83 */     this.classname = classname;
/*     */   }
/*     */   
/*     */   private static String toSignature(String classname) {
/*  87 */     StringBuilder sig = new StringBuilder();
/*  88 */     sig.append("L").append(classname.replace('.', '/'));
/*  89 */     sig.append(";");
/*  90 */     return sig.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  97 */     return this.classname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 105 */     return this.classname.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object type) {
/* 113 */     return (type instanceof ObjectType) ? ((ObjectType)type).classname.equals(this.classname) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean referencesClass() {
/* 120 */     JavaClass jc = Repository.lookupClass(this.classname);
/* 121 */     if (jc == null) {
/* 122 */       return false;
/*     */     }
/* 124 */     return jc.isClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean referencesInterface() {
/* 132 */     JavaClass jc = Repository.lookupClass(this.classname);
/* 133 */     if (jc == null) {
/* 134 */       return false;
/*     */     }
/* 136 */     return !jc.isClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean subclassOf(ObjectType superclass) {
/* 141 */     if (referencesInterface() || superclass.referencesInterface()) {
/* 142 */       return false;
/*     */     }
/*     */     
/* 145 */     return Repository.instanceOf(this.classname, superclass.classname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean accessibleTo(ObjectType accessor) {
/* 152 */     JavaClass jc = Repository.lookupClass(this.classname);
/*     */     
/* 154 */     if (jc.isPublic()) {
/* 155 */       return true;
/*     */     }
/* 157 */     JavaClass acc = Repository.lookupClass(accessor.classname);
/* 158 */     return acc.getPackageName().equals(jc.getPackageName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\ObjectType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */