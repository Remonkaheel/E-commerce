/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.Constant;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantDouble;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantFloat;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantInteger;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantLong;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantObject;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantString;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantValue;
/*     */ import org.aspectj.apache.bcel.classfile.Field;
/*     */ import org.aspectj.apache.bcel.classfile.Utility;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeAnnos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldGen
/*     */   extends FieldGenOrMethodGen
/*     */ {
/*  84 */   private Object value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldGen(int modifiers, Type type, String name, ConstantPool cpool) {
/*  96 */     setModifiers(modifiers);
/*  97 */     setType(type);
/*  98 */     setName(name);
/*  99 */     setConstantPool(cpool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldGen(Field field, ConstantPool cp) {
/* 109 */     this(field.getModifiers(), Type.getType(field.getSignature()), field.getName(), cp);
/*     */     
/* 111 */     Attribute[] attrs = field.getAttributes();
/*     */     
/* 113 */     for (Attribute attr : attrs) {
/* 114 */       if (attr instanceof ConstantValue) {
/* 115 */         setValue(((ConstantValue)attr).getConstantValueIndex());
/* 116 */       } else if (attr instanceof RuntimeAnnos) {
/* 117 */         RuntimeAnnos runtimeAnnotations = (RuntimeAnnos)attr;
/* 118 */         List<AnnotationGen> l = runtimeAnnotations.getAnnotations();
/* 119 */         for (AnnotationGen element : l) {
/* 120 */           addAnnotation(new AnnotationGen(element, cp, false));
/*     */         }
/*     */       } else {
/* 123 */         addAttribute(attr);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setValue(int index) {
/* 129 */     ConstantPool cp = this.cp;
/* 130 */     Constant c = cp.getConstant(index);
/* 131 */     if (c instanceof ConstantInteger) {
/* 132 */       this.value = Integer.valueOf(((ConstantInteger)c).getIntValue());
/* 133 */     } else if (c instanceof ConstantFloat) {
/* 134 */       this.value = ((ConstantFloat)c).getValue();
/* 135 */     } else if (c instanceof ConstantDouble) {
/* 136 */       this.value = ((ConstantDouble)c).getValue();
/* 137 */     } else if (c instanceof ConstantLong) {
/* 138 */       this.value = ((ConstantLong)c).getValue();
/* 139 */     } else if (c instanceof ConstantString) {
/* 140 */       this.value = ((ConstantString)c).getString(cp);
/*     */     } else {
/* 142 */       this.value = ((ConstantObject)c).getConstantValue(cp);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setValue(String constantString) {
/* 147 */     this.value = constantString;
/*     */   }
/*     */   
/*     */   public void wipeValue() {
/* 151 */     this.value = null;
/*     */   }
/*     */   
/*     */   private void checkType(Type atype) {
/* 155 */     if (this.type == null) {
/* 156 */       throw new ClassGenException("You haven't defined the type of the field yet");
/*     */     }
/* 158 */     if (!isFinal()) {
/* 159 */       throw new ClassGenException("Only final fields may have an initial value!");
/*     */     }
/* 161 */     if (!this.type.equals(atype)) {
/* 162 */       throw new ClassGenException("Types are not compatible: " + this.type + " vs. " + atype);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Field getField() {
/* 169 */     String signature = getSignature();
/* 170 */     int nameIndex = this.cp.addUtf8(this.name);
/* 171 */     int signatureIndex = this.cp.addUtf8(signature);
/*     */     
/* 173 */     if (this.value != null) {
/* 174 */       checkType(this.type);
/* 175 */       int index = addConstant();
/* 176 */       addAttribute((Attribute)new ConstantValue(this.cp.addUtf8("ConstantValue"), 2, index, this.cp));
/*     */     } 
/*     */     
/* 179 */     addAnnotationsAsAttribute(this.cp);
/*     */     
/* 181 */     return new Field(this.modifiers, nameIndex, signatureIndex, getAttributesImmutable(), this.cp);
/*     */   }
/*     */   
/*     */   private int addConstant() {
/* 185 */     switch (this.type.getType()) {
/*     */       case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 191 */         return this.cp.addInteger(((Integer)this.value).intValue());
/*     */       
/*     */       case 6:
/* 194 */         return this.cp.addFloat(((Float)this.value).floatValue());
/*     */       
/*     */       case 7:
/* 197 */         return this.cp.addDouble(((Double)this.value).doubleValue());
/*     */       
/*     */       case 11:
/* 200 */         return this.cp.addLong(((Long)this.value).longValue());
/*     */       
/*     */       case 14:
/* 203 */         return this.cp.addString((String)this.value);
/*     */     } 
/*     */     
/* 206 */     throw new RuntimeException("Oops: Unhandled : " + this.type.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSignature() {
/* 212 */     return this.type.getSignature();
/*     */   }
/*     */   
/*     */   public String getInitialValue() {
/* 216 */     return (this.value == null) ? null : this.value.toString();
/*     */   }
/*     */   
/*     */   public void setInitialStringValue(String value) {
/* 220 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 228 */     String access = Utility.accessToString(this.modifiers);
/* 229 */     access = access.equals("") ? "" : (access + " ");
/* 230 */     String signature = this.type.toString();
/* 231 */     String name = getName();
/*     */     
/* 233 */     StringBuilder buf = (new StringBuilder(access)).append(signature).append(" ").append(name);
/* 234 */     String value = getInitialValue();
/*     */     
/* 236 */     if (value != null) {
/* 237 */       buf.append(" = ").append(value);
/*     */     }
/*     */     
/* 240 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\FieldGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */