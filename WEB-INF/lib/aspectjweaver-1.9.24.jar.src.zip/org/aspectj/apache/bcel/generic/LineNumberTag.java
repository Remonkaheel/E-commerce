/*    */ package org.aspectj.apache.bcel.generic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineNumberTag
/*    */   extends Tag
/*    */ {
/*    */   private final int lineNumber;
/*    */   
/*    */   public LineNumberTag(int lineNumber) {
/* 25 */     this.lineNumber = lineNumber;
/*    */   }
/*    */   
/*    */   public int getLineNumber() {
/* 29 */     return this.lineNumber;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 33 */     return "line " + this.lineNumber;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 37 */     if (!(other instanceof LineNumberTag)) return false; 
/* 38 */     return (this.lineNumber == ((LineNumberTag)other).lineNumber);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 42 */     return this.lineNumber;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\LineNumberTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */