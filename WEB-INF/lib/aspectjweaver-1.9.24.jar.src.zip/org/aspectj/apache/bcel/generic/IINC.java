/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IINC
/*     */   extends InstructionLV
/*     */ {
/*     */   private int c;
/*     */   
/*     */   public IINC(int n, int c, boolean w) {
/*  71 */     super((short)132, n);
/*  72 */     this.c = c;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean wide() {
/*  77 */     return (this.lvar > 255 || Math.abs(this.c) > 127);
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  81 */     if (wide()) {
/*  82 */       out.writeByte(196);
/*  83 */       out.writeByte(this.opcode);
/*  84 */       out.writeShort(this.lvar);
/*  85 */       out.writeShort(this.c);
/*     */     } else {
/*  87 */       out.writeByte(this.opcode);
/*  88 */       out.writeByte(this.lvar);
/*  89 */       out.writeByte(this.c);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLength() {
/*  94 */     if (wide()) {
/*  95 */       return 6;
/*     */     }
/*  97 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 102 */     return super.toString(verbose) + " " + this.c;
/*     */   }
/*     */   
/*     */   public final int getIncrement() {
/* 106 */     return this.c;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 110 */     if (!(other instanceof IINC)) {
/* 111 */       return false;
/*     */     }
/* 113 */     IINC o = (IINC)other;
/* 114 */     return (o.lvar == this.lvar && o.c == this.c);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 118 */     return this.opcode * 37 + this.lvar * (this.c + 17);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\IINC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */