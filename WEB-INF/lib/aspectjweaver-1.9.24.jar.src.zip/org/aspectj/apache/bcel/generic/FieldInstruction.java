/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldInstruction
/*     */   extends FieldOrMethod
/*     */ {
/*     */   public FieldInstruction(short opcode, int index) {
/*  68 */     super(opcode, index);
/*     */   }
/*     */   
/*     */   public String toString(ConstantPool cp) {
/*  72 */     return Constants.OPCODE_NAMES[this.opcode] + " " + cp
/*  73 */       .constantToString(this.index, (byte)9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getFieldSize(ConstantPool cpg) {
/*  80 */     return Type.getTypeSize(getSignature(cpg));
/*     */   }
/*     */   
/*     */   public Type getType(ConstantPool cpg) {
/*  84 */     return getFieldType(cpg);
/*     */   }
/*     */   
/*     */   public Type getFieldType(ConstantPool cpg) {
/*  88 */     return Type.getType(getSignature(cpg));
/*     */   }
/*     */   
/*     */   public String getFieldName(ConstantPool cpg) {
/*  92 */     return getName(cpg);
/*     */   }
/*     */   
/*     */   public int produceStack(ConstantPool cpg) {
/*  96 */     if (!isStackProducer()) {
/*  97 */       return 0;
/*     */     }
/*     */     
/* 100 */     return getFieldSize(cpg);
/*     */   }
/*     */   
/*     */   public int consumeStack(ConstantPool cpg) {
/* 104 */     if (!isStackConsumer()) {
/* 105 */       return 0;
/*     */     }
/* 107 */     if (this.opcode == 180) {
/* 108 */       return 1;
/*     */     }
/* 110 */     return getFieldSize(cpg) + ((this.opcode == 181) ? 1 : 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\FieldInstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */