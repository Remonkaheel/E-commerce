/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionLV
/*     */   extends Instruction
/*     */ {
/*  68 */   protected int lvar = -1;
/*     */   
/*     */   public InstructionLV(short opcode, int lvar) {
/*  71 */     super(opcode);
/*  72 */     this.lvar = lvar;
/*     */   }
/*     */   
/*     */   public InstructionLV(short opcode) {
/*  76 */     super(opcode);
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  80 */     if (this.lvar == -1) {
/*  81 */       out.writeByte(this.opcode);
/*     */     }
/*  83 */     else if (this.lvar < 4) {
/*  84 */       if (this.opcode == 25) {
/*  85 */         out.writeByte(42 + this.lvar);
/*  86 */       } else if (this.opcode == 58) {
/*  87 */         out.writeByte(75 + this.lvar);
/*  88 */       } else if (this.opcode == 21) {
/*  89 */         out.writeByte(26 + this.lvar);
/*  90 */       } else if (this.opcode == 54) {
/*  91 */         out.writeByte(59 + this.lvar);
/*  92 */       } else if (this.opcode == 24) {
/*  93 */         out.writeByte(38 + this.lvar);
/*  94 */       } else if (this.opcode == 57) {
/*  95 */         out.writeByte(71 + this.lvar);
/*  96 */       } else if (this.opcode == 23) {
/*  97 */         out.writeByte(34 + this.lvar);
/*  98 */       } else if (this.opcode == 56) {
/*  99 */         out.writeByte(67 + this.lvar);
/* 100 */       } else if (this.opcode == 22) {
/* 101 */         out.writeByte(30 + this.lvar);
/* 102 */       } else if (this.opcode == 55) {
/* 103 */         out.writeByte(63 + this.lvar);
/*     */       } else {
/* 105 */         if (wide()) {
/* 106 */           out.writeByte(196);
/*     */         }
/* 108 */         out.writeByte(this.opcode);
/* 109 */         if (wide()) {
/* 110 */           out.writeShort(this.lvar);
/*     */         } else {
/* 112 */           out.writeByte(this.lvar);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 116 */       if (wide()) {
/* 117 */         out.writeByte(196);
/*     */       }
/* 119 */       out.writeByte(this.opcode);
/* 120 */       if (wide()) {
/* 121 */         out.writeShort(this.lvar);
/*     */       } else {
/* 123 */         out.writeByte(this.lvar);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 135 */     if ((this.opcode >= 26 && this.opcode <= 45) || (this.opcode >= 59 && this.opcode <= 78))
/*     */     {
/* 137 */       return super.toString(verbose);
/*     */     }
/* 139 */     return super.toString(verbose) + ((this.lvar != -1 && this.lvar < 4) ? "_" : " ") + this.lvar;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isALOAD() {
/* 144 */     return (this.opcode == 25 || (this.opcode >= 42 && this.opcode <= 45));
/*     */   }
/*     */   
/*     */   public boolean isASTORE() {
/* 148 */     return (this.opcode == 58 || (this.opcode >= 75 && this.opcode <= 78));
/*     */   }
/*     */   
/*     */   public int getBaseOpcode() {
/* 152 */     if ((this.opcode >= 21 && this.opcode <= 25) || (this.opcode >= 54 && this.opcode <= 58))
/*     */     {
/* 154 */       return this.opcode;
/*     */     }
/* 156 */     if (this.opcode >= 26 && this.opcode <= 45) {
/* 157 */       int i = this.opcode - 26;
/* 158 */       i -= i % 4;
/* 159 */       i /= 4;
/* 160 */       return i + 21;
/*     */     } 
/* 162 */     int ret = this.opcode - 59;
/* 163 */     ret -= ret % 4;
/* 164 */     ret /= 4;
/* 165 */     return ret + 54;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getIndex() {
/* 173 */     if (this.lvar != -1) {
/* 174 */       return this.lvar;
/*     */     }
/* 176 */     if (this.opcode >= 26 && this.opcode <= 45)
/* 177 */       return (this.opcode - 26) % 4; 
/* 178 */     if (this.opcode >= 59 && this.opcode <= 78) {
/* 179 */       return (this.opcode - 59) % 4;
/*     */     }
/* 181 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndex(int i) {
/* 187 */     if (getIndex() != i) {
/* 188 */       if (this.opcode >= 26 && this.opcode <= 45) {
/* 189 */         this.opcode = (short)(21 + (this.opcode - 26) / 4);
/* 190 */       } else if (this.opcode >= 59 && this.opcode <= 78) {
/* 191 */         this.opcode = (short)(54 + (this.opcode - 59) / 4);
/*     */       } 
/* 193 */       this.lvar = i;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean canSetIndex() {
/* 198 */     return true;
/*     */   }
/*     */   
/*     */   public InstructionLV setIndexAndCopyIfNecessary(int newIndex) {
/* 202 */     if (canSetIndex()) {
/* 203 */       setIndex(newIndex);
/* 204 */       return this;
/*     */     } 
/* 206 */     if (getIndex() == newIndex) {
/* 207 */       return this;
/*     */     }
/* 209 */     InstructionLV newInstruction = null;
/* 210 */     int baseOpCode = getBaseOpcode();
/* 211 */     if (newIndex < 4) {
/* 212 */       if (isStoreInstruction()) {
/* 213 */         newInstruction = (InstructionLV)InstructionConstants.INSTRUCTIONS[(baseOpCode - 54) * 4 + 59 + newIndex];
/*     */       } else {
/*     */         
/* 216 */         newInstruction = (InstructionLV)InstructionConstants.INSTRUCTIONS[(baseOpCode - 21) * 4 + 26 + newIndex];
/*     */       } 
/*     */     } else {
/*     */       
/* 220 */       newInstruction = new InstructionLV((short)baseOpCode, newIndex);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     return newInstruction;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 232 */     int size = Constants.iLen[this.opcode];
/* 233 */     if (this.lvar == -1) {
/* 234 */       return size;
/*     */     }
/* 236 */     if (this.lvar < 4) {
/* 237 */       if (this.opcode == 25 || this.opcode == 58)
/* 238 */         return 1; 
/* 239 */       if (this.opcode == 21 || this.opcode == 54)
/* 240 */         return 1; 
/* 241 */       if (this.opcode == 24 || this.opcode == 57)
/* 242 */         return 1; 
/* 243 */       if (this.opcode == 23 || this.opcode == 56)
/* 244 */         return 1; 
/* 245 */       if (this.opcode == 22 || this.opcode == 55) {
/* 246 */         return 1;
/*     */       }
/* 248 */       if (wide()) {
/* 249 */         return size + 2;
/*     */       }
/* 251 */       return size;
/*     */     } 
/*     */     
/* 254 */     if (wide()) {
/* 255 */       return size + 2;
/*     */     }
/* 257 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean wide() {
/* 263 */     return (this.lvar > 255);
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 267 */     if (!(other instanceof InstructionLV)) {
/* 268 */       return false;
/*     */     }
/* 270 */     InstructionLV o = (InstructionLV)other;
/* 271 */     return (o.opcode == this.opcode && o.lvar == this.lvar);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 275 */     return this.opcode * 37 + this.lvar;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionLV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */