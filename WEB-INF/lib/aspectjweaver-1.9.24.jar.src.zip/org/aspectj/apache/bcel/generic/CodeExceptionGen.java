/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.apache.bcel.classfile.CodeException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CodeExceptionGen
/*     */   implements InstructionTargeter, Cloneable, Serializable
/*     */ {
/*     */   private InstructionHandle start_pc;
/*     */   private InstructionHandle end_pc;
/*     */   private InstructionHandle handler_pc;
/*     */   private ObjectType catch_type;
/*     */   
/*     */   public CodeExceptionGen(InstructionHandle start_pc, InstructionHandle end_pc, InstructionHandle handler_pc, ObjectType catch_type) {
/*  93 */     setStartPC(start_pc);
/*  94 */     setEndPC(end_pc);
/*  95 */     setHandlerPC(handler_pc);
/*  96 */     this.catch_type = catch_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeException getCodeException(ConstantPool cp) {
/* 109 */     return new CodeException(this.start_pc.getPosition(), this.end_pc
/* 110 */         .getPosition() + this.end_pc.getInstruction().getLength(), this.handler_pc
/* 111 */         .getPosition(), 
/* 112 */         (this.catch_type == null) ? 0 : cp.addClass(this.catch_type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartPC(InstructionHandle start_pc) {
/* 119 */     InstructionBranch.notifyTarget(this.start_pc, start_pc, this);
/* 120 */     this.start_pc = start_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndPC(InstructionHandle end_pc) {
/* 127 */     InstructionBranch.notifyTarget(this.end_pc, end_pc, this);
/* 128 */     this.end_pc = end_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerPC(InstructionHandle handler_pc) {
/* 135 */     InstructionBranch.notifyTarget(this.handler_pc, handler_pc, this);
/* 136 */     this.handler_pc = handler_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 144 */     boolean targeted = false;
/*     */     
/* 146 */     if (this.start_pc == old_ih) {
/* 147 */       targeted = true;
/* 148 */       setStartPC(new_ih);
/*     */     } 
/*     */     
/* 151 */     if (this.end_pc == old_ih) {
/* 152 */       targeted = true;
/* 153 */       setEndPC(new_ih);
/*     */     } 
/*     */     
/* 156 */     if (this.handler_pc == old_ih) {
/* 157 */       targeted = true;
/* 158 */       setHandlerPC(new_ih);
/*     */     } 
/*     */     
/* 161 */     if (!targeted) {
/* 162 */       throw new ClassGenException("Not targeting " + old_ih + ", but {" + this.start_pc + ", " + this.end_pc + ", " + this.handler_pc + "}");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTarget(InstructionHandle ih) {
/* 170 */     return (this.start_pc == ih || this.end_pc == ih || this.handler_pc == ih);
/*     */   }
/*     */   
/*     */   public void setCatchType(ObjectType catch_type) {
/* 174 */     this.catch_type = catch_type;
/*     */   } public ObjectType getCatchType() {
/* 176 */     return this.catch_type;
/*     */   }
/*     */   
/*     */   public InstructionHandle getStartPC() {
/* 180 */     return this.start_pc;
/*     */   }
/*     */   
/*     */   public InstructionHandle getEndPC() {
/* 184 */     return this.end_pc;
/*     */   }
/*     */   
/*     */   public InstructionHandle getHandlerPC() {
/* 188 */     return this.handler_pc;
/*     */   }
/*     */   public String toString() {
/* 191 */     return "CodeExceptionGen(" + this.start_pc + ", " + this.end_pc + ", " + this.handler_pc + ")";
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 196 */       return super.clone();
/* 197 */     } catch (CloneNotSupportedException e) {
/* 198 */       System.err.println(e);
/* 199 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\CodeExceptionGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */