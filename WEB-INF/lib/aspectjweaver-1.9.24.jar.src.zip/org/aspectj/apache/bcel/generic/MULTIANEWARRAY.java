/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.ExceptionConstants;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MULTIANEWARRAY
/*     */   extends InstructionCP
/*     */ {
/*     */   private short dimensions;
/*     */   
/*     */   public MULTIANEWARRAY(int index, short dimensions) {
/*  77 */     super((short)197, index);
/*  78 */     this.dimensions = dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  87 */     out.writeByte(this.opcode);
/*  88 */     out.writeShort(this.index);
/*  89 */     out.writeByte(this.dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final short getDimensions() {
/* 107 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 114 */     return super.toString(verbose) + " " + this.index + " " + this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(ConstantPool cp) {
/* 121 */     return super.toString(cp) + " " + this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int consumeStack(ConstantPool cpg) {
/* 130 */     return this.dimensions;
/*     */   }
/*     */   
/*     */   public Class[] getExceptions() {
/* 134 */     Class[] cs = new Class[2 + ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION.length];
/*     */     
/* 136 */     System.arraycopy(ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION, 0, cs, 0, ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION.length);
/*     */ 
/*     */     
/* 139 */     cs[ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION.length + 1] = ExceptionConstants.NEGATIVE_ARRAY_SIZE_EXCEPTION;
/* 140 */     cs[ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION.length] = ExceptionConstants.ILLEGAL_ACCESS_ERROR;
/*     */     
/* 142 */     return cs;
/*     */   }
/*     */   
/*     */   public ObjectType getLoadClassType(ConstantPool cpg) {
/* 146 */     Type t = getType(cpg);
/*     */     
/* 148 */     if (t instanceof ArrayType) {
/* 149 */       t = ((ArrayType)t).getBasicType();
/*     */     }
/*     */     
/* 152 */     return (t instanceof ObjectType) ? (ObjectType)t : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 173 */     if (!(other instanceof MULTIANEWARRAY)) {
/* 174 */       return false;
/*     */     }
/* 176 */     MULTIANEWARRAY o = (MULTIANEWARRAY)other;
/* 177 */     return (o.opcode == this.opcode && o.index == this.index && o.dimensions == this.dimensions);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 181 */     return this.opcode * 37 + this.index * (this.dimensions + 17);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\MULTIANEWARRAY.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */