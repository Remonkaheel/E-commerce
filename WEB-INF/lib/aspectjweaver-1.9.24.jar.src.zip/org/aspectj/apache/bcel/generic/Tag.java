/*    */ package org.aspectj.apache.bcel.generic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Tag
/*    */   implements InstructionTargeter, Cloneable
/*    */ {
/*    */   public boolean containsTarget(InstructionHandle ih) {
/* 28 */     return false;
/*    */   }
/*    */   
/*    */   public void updateTarget(InstructionHandle oldHandle, InstructionHandle newHandle) {
/* 32 */     oldHandle.removeTargeter(this);
/* 33 */     if (newHandle != null) {
/* 34 */       newHandle.addTargeter(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public Tag copy() {
/*    */     try {
/* 40 */       return (Tag)clone();
/* 41 */     } catch (CloneNotSupportedException e) {
/* 42 */       throw new RuntimeException("Sanity check, can't clone me");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\Tag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */