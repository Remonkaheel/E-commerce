/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface InstructionConstants
/*     */ {
/*  79 */   public static final Instruction NOP = new Instruction((short)0);
/*  80 */   public static final Instruction ACONST_NULL = new Instruction((short)1);
/*  81 */   public static final Instruction ICONST_M1 = new Instruction((short)2);
/*  82 */   public static final Instruction ICONST_0 = new Instruction((short)3);
/*  83 */   public static final Instruction ICONST_1 = new Instruction((short)4);
/*  84 */   public static final Instruction ICONST_2 = new Instruction((short)5);
/*  85 */   public static final Instruction ICONST_3 = new Instruction((short)6);
/*  86 */   public static final Instruction ICONST_4 = new Instruction((short)7);
/*  87 */   public static final Instruction ICONST_5 = new Instruction((short)8);
/*  88 */   public static final Instruction LCONST_0 = new Instruction((short)9);
/*  89 */   public static final Instruction LCONST_1 = new Instruction((short)10);
/*  90 */   public static final Instruction FCONST_0 = new Instruction((short)11);
/*  91 */   public static final Instruction FCONST_1 = new Instruction((short)12);
/*  92 */   public static final Instruction FCONST_2 = new Instruction((short)13);
/*  93 */   public static final Instruction DCONST_0 = new Instruction((short)14);
/*  94 */   public static final Instruction DCONST_1 = new Instruction((short)15);
/*  95 */   public static final Instruction IALOAD = new Instruction((short)46);
/*  96 */   public static final Instruction LALOAD = new Instruction((short)47);
/*  97 */   public static final Instruction FALOAD = new Instruction((short)48);
/*  98 */   public static final Instruction DALOAD = new Instruction((short)49);
/*  99 */   public static final Instruction AALOAD = new Instruction((short)50);
/* 100 */   public static final Instruction BALOAD = new Instruction((short)51);
/* 101 */   public static final Instruction CALOAD = new Instruction((short)52);
/* 102 */   public static final Instruction SALOAD = new Instruction((short)53);
/* 103 */   public static final Instruction IASTORE = new Instruction((short)79);
/* 104 */   public static final Instruction LASTORE = new Instruction((short)80);
/* 105 */   public static final Instruction FASTORE = new Instruction((short)81);
/* 106 */   public static final Instruction DASTORE = new Instruction((short)82);
/* 107 */   public static final Instruction AASTORE = new Instruction((short)83);
/* 108 */   public static final Instruction BASTORE = new Instruction((short)84);
/* 109 */   public static final Instruction CASTORE = new Instruction((short)85);
/* 110 */   public static final Instruction SASTORE = new Instruction((short)86);
/* 111 */   public static final Instruction POP = new Instruction((short)87);
/* 112 */   public static final Instruction POP2 = new Instruction((short)88);
/* 113 */   public static final Instruction DUP = new Instruction((short)89);
/* 114 */   public static final Instruction DUP_X1 = new Instruction((short)90);
/* 115 */   public static final Instruction DUP_X2 = new Instruction((short)91);
/* 116 */   public static final Instruction DUP2 = new Instruction((short)92);
/* 117 */   public static final Instruction DUP2_X1 = new Instruction((short)93);
/* 118 */   public static final Instruction DUP2_X2 = new Instruction((short)94);
/* 119 */   public static final Instruction SWAP = new Instruction((short)95);
/* 120 */   public static final Instruction IADD = new Instruction((short)96);
/* 121 */   public static final Instruction LADD = new Instruction((short)97);
/* 122 */   public static final Instruction FADD = new Instruction((short)98);
/* 123 */   public static final Instruction DADD = new Instruction((short)99);
/* 124 */   public static final Instruction ISUB = new Instruction((short)100);
/* 125 */   public static final Instruction LSUB = new Instruction((short)101);
/* 126 */   public static final Instruction FSUB = new Instruction((short)102);
/* 127 */   public static final Instruction DSUB = new Instruction((short)103);
/* 128 */   public static final Instruction IMUL = new Instruction((short)104);
/* 129 */   public static final Instruction LMUL = new Instruction((short)105);
/* 130 */   public static final Instruction FMUL = new Instruction((short)106);
/* 131 */   public static final Instruction DMUL = new Instruction((short)107);
/* 132 */   public static final Instruction IDIV = new Instruction((short)108);
/* 133 */   public static final Instruction LDIV = new Instruction((short)109);
/* 134 */   public static final Instruction FDIV = new Instruction((short)110);
/* 135 */   public static final Instruction DDIV = new Instruction((short)111);
/* 136 */   public static final Instruction IREM = new Instruction((short)112);
/* 137 */   public static final Instruction LREM = new Instruction((short)113);
/* 138 */   public static final Instruction FREM = new Instruction((short)114);
/* 139 */   public static final Instruction DREM = new Instruction((short)115);
/* 140 */   public static final Instruction INEG = new Instruction((short)116);
/* 141 */   public static final Instruction LNEG = new Instruction((short)117);
/* 142 */   public static final Instruction FNEG = new Instruction((short)118);
/* 143 */   public static final Instruction DNEG = new Instruction((short)119);
/* 144 */   public static final Instruction ISHL = new Instruction((short)120);
/* 145 */   public static final Instruction LSHL = new Instruction((short)121);
/* 146 */   public static final Instruction ISHR = new Instruction((short)122);
/* 147 */   public static final Instruction LSHR = new Instruction((short)123);
/* 148 */   public static final Instruction IUSHR = new Instruction((short)124);
/* 149 */   public static final Instruction LUSHR = new Instruction((short)125);
/* 150 */   public static final Instruction IAND = new Instruction((short)126);
/* 151 */   public static final Instruction LAND = new Instruction((short)127);
/* 152 */   public static final Instruction IOR = new Instruction((short)128);
/* 153 */   public static final Instruction LOR = new Instruction((short)129);
/* 154 */   public static final Instruction IXOR = new Instruction((short)130);
/* 155 */   public static final Instruction LXOR = new Instruction((short)131);
/* 156 */   public static final Instruction I2L = new Instruction((short)133);
/* 157 */   public static final Instruction I2F = new Instruction((short)134);
/* 158 */   public static final Instruction I2D = new Instruction((short)135);
/* 159 */   public static final Instruction L2I = new Instruction((short)136);
/* 160 */   public static final Instruction L2F = new Instruction((short)137);
/* 161 */   public static final Instruction L2D = new Instruction((short)138);
/* 162 */   public static final Instruction F2I = new Instruction((short)139);
/* 163 */   public static final Instruction F2L = new Instruction((short)140);
/* 164 */   public static final Instruction F2D = new Instruction((short)141);
/* 165 */   public static final Instruction D2I = new Instruction((short)142);
/* 166 */   public static final Instruction D2L = new Instruction((short)143);
/* 167 */   public static final Instruction D2F = new Instruction((short)144);
/* 168 */   public static final Instruction I2B = new Instruction((short)145);
/* 169 */   public static final Instruction I2C = new Instruction((short)146);
/* 170 */   public static final Instruction I2S = new Instruction((short)147);
/* 171 */   public static final Instruction LCMP = new Instruction((short)148);
/* 172 */   public static final Instruction FCMPL = new Instruction((short)149);
/* 173 */   public static final Instruction FCMPG = new Instruction((short)150);
/* 174 */   public static final Instruction DCMPL = new Instruction((short)151);
/* 175 */   public static final Instruction DCMPG = new Instruction((short)152);
/* 176 */   public static final Instruction IRETURN = new Instruction((short)172);
/* 177 */   public static final Instruction LRETURN = new Instruction((short)173);
/* 178 */   public static final Instruction FRETURN = new Instruction((short)174);
/* 179 */   public static final Instruction DRETURN = new Instruction((short)175);
/* 180 */   public static final Instruction ARETURN = new Instruction((short)176);
/* 181 */   public static final Instruction RETURN = new Instruction((short)177);
/* 182 */   public static final Instruction ARRAYLENGTH = new Instruction((short)190);
/* 183 */   public static final Instruction ATHROW = new Instruction((short)191);
/* 184 */   public static final Instruction MONITORENTER = new Instruction((short)194);
/* 185 */   public static final Instruction MONITOREXIT = new Instruction((short)195);
/* 186 */   public static final Instruction IMPDEP1 = new Instruction((short)254);
/* 187 */   public static final Instruction IMPDEP2 = new Instruction((short)255);
/*     */ 
/*     */ 
/*     */   
/* 191 */   public static final InstructionLV THIS = new InstructionCLV((short)25, 0);
/* 192 */   public static final InstructionLV ALOAD_0 = new InstructionCLV((short)42);
/* 193 */   public static final InstructionLV ALOAD_1 = new InstructionCLV((short)43);
/* 194 */   public static final InstructionLV ALOAD_2 = new InstructionCLV((short)44);
/* 195 */   public static final InstructionLV ALOAD_3 = new InstructionCLV((short)45);
/* 196 */   public static final InstructionLV ILOAD_0 = new InstructionCLV((short)26);
/* 197 */   public static final InstructionLV ILOAD_1 = new InstructionCLV((short)27);
/* 198 */   public static final InstructionLV ILOAD_2 = new InstructionCLV((short)28);
/* 199 */   public static final InstructionLV ILOAD_3 = new InstructionCLV((short)29);
/* 200 */   public static final InstructionLV DLOAD_0 = new InstructionCLV((short)38);
/* 201 */   public static final InstructionLV DLOAD_1 = new InstructionCLV((short)39);
/* 202 */   public static final InstructionLV DLOAD_2 = new InstructionCLV((short)40);
/* 203 */   public static final InstructionLV DLOAD_3 = new InstructionCLV((short)41);
/* 204 */   public static final InstructionLV FLOAD_0 = new InstructionCLV((short)34);
/* 205 */   public static final InstructionLV FLOAD_1 = new InstructionCLV((short)35);
/* 206 */   public static final InstructionLV FLOAD_2 = new InstructionCLV((short)36);
/* 207 */   public static final InstructionLV FLOAD_3 = new InstructionCLV((short)37);
/* 208 */   public static final InstructionLV LLOAD_0 = new InstructionCLV((short)30);
/* 209 */   public static final InstructionLV LLOAD_1 = new InstructionCLV((short)31);
/* 210 */   public static final InstructionLV LLOAD_2 = new InstructionCLV((short)32);
/* 211 */   public static final InstructionLV LLOAD_3 = new InstructionCLV((short)33);
/* 212 */   public static final InstructionLV ASTORE_0 = new InstructionCLV((short)75);
/* 213 */   public static final InstructionLV ASTORE_1 = new InstructionCLV((short)76);
/* 214 */   public static final InstructionLV ASTORE_2 = new InstructionCLV((short)77);
/* 215 */   public static final InstructionLV ASTORE_3 = new InstructionCLV((short)78);
/* 216 */   public static final InstructionLV ISTORE_0 = new InstructionCLV((short)59);
/* 217 */   public static final InstructionLV ISTORE_1 = new InstructionCLV((short)60);
/* 218 */   public static final InstructionLV ISTORE_2 = new InstructionCLV((short)61);
/* 219 */   public static final InstructionLV ISTORE_3 = new InstructionCLV((short)62);
/* 220 */   public static final InstructionLV LSTORE_0 = new InstructionCLV((short)63);
/* 221 */   public static final InstructionLV LSTORE_1 = new InstructionCLV((short)64);
/* 222 */   public static final InstructionLV LSTORE_2 = new InstructionCLV((short)65);
/* 223 */   public static final InstructionLV LSTORE_3 = new InstructionCLV((short)66);
/* 224 */   public static final InstructionLV FSTORE_0 = new InstructionCLV((short)67);
/* 225 */   public static final InstructionLV FSTORE_1 = new InstructionCLV((short)68);
/* 226 */   public static final InstructionLV FSTORE_2 = new InstructionCLV((short)69);
/* 227 */   public static final InstructionLV FSTORE_3 = new InstructionCLV((short)70);
/* 228 */   public static final InstructionLV DSTORE_0 = new InstructionCLV((short)71);
/* 229 */   public static final InstructionLV DSTORE_1 = new InstructionCLV((short)72);
/* 230 */   public static final InstructionLV DSTORE_2 = new InstructionCLV((short)73);
/* 231 */   public static final InstructionLV DSTORE_3 = new InstructionCLV((short)74);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public static final Instruction[] INSTRUCTIONS = new Instruction[256];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 242 */   public static final Clinit bla = new Clinit();
/*     */   
/*     */   public static class Clinit {
/*     */     Clinit() {
/* 246 */       InstructionConstants.INSTRUCTIONS[0] = InstructionConstants.NOP;
/* 247 */       InstructionConstants.INSTRUCTIONS[1] = InstructionConstants.ACONST_NULL;
/* 248 */       InstructionConstants.INSTRUCTIONS[2] = InstructionConstants.ICONST_M1;
/* 249 */       InstructionConstants.INSTRUCTIONS[3] = InstructionConstants.ICONST_0;
/* 250 */       InstructionConstants.INSTRUCTIONS[4] = InstructionConstants.ICONST_1;
/* 251 */       InstructionConstants.INSTRUCTIONS[5] = InstructionConstants.ICONST_2;
/* 252 */       InstructionConstants.INSTRUCTIONS[6] = InstructionConstants.ICONST_3;
/* 253 */       InstructionConstants.INSTRUCTIONS[7] = InstructionConstants.ICONST_4;
/* 254 */       InstructionConstants.INSTRUCTIONS[8] = InstructionConstants.ICONST_5;
/* 255 */       InstructionConstants.INSTRUCTIONS[9] = InstructionConstants.LCONST_0;
/* 256 */       InstructionConstants.INSTRUCTIONS[10] = InstructionConstants.LCONST_1;
/* 257 */       InstructionConstants.INSTRUCTIONS[11] = InstructionConstants.FCONST_0;
/* 258 */       InstructionConstants.INSTRUCTIONS[12] = InstructionConstants.FCONST_1;
/* 259 */       InstructionConstants.INSTRUCTIONS[13] = InstructionConstants.FCONST_2;
/* 260 */       InstructionConstants.INSTRUCTIONS[14] = InstructionConstants.DCONST_0;
/* 261 */       InstructionConstants.INSTRUCTIONS[15] = InstructionConstants.DCONST_1;
/* 262 */       InstructionConstants.INSTRUCTIONS[46] = InstructionConstants.IALOAD;
/* 263 */       InstructionConstants.INSTRUCTIONS[47] = InstructionConstants.LALOAD;
/* 264 */       InstructionConstants.INSTRUCTIONS[48] = InstructionConstants.FALOAD;
/* 265 */       InstructionConstants.INSTRUCTIONS[49] = InstructionConstants.DALOAD;
/* 266 */       InstructionConstants.INSTRUCTIONS[50] = InstructionConstants.AALOAD;
/* 267 */       InstructionConstants.INSTRUCTIONS[51] = InstructionConstants.BALOAD;
/* 268 */       InstructionConstants.INSTRUCTIONS[52] = InstructionConstants.CALOAD;
/* 269 */       InstructionConstants.INSTRUCTIONS[53] = InstructionConstants.SALOAD;
/* 270 */       InstructionConstants.INSTRUCTIONS[79] = InstructionConstants.IASTORE;
/* 271 */       InstructionConstants.INSTRUCTIONS[80] = InstructionConstants.LASTORE;
/* 272 */       InstructionConstants.INSTRUCTIONS[81] = InstructionConstants.FASTORE;
/* 273 */       InstructionConstants.INSTRUCTIONS[82] = InstructionConstants.DASTORE;
/* 274 */       InstructionConstants.INSTRUCTIONS[83] = InstructionConstants.AASTORE;
/* 275 */       InstructionConstants.INSTRUCTIONS[84] = InstructionConstants.BASTORE;
/* 276 */       InstructionConstants.INSTRUCTIONS[85] = InstructionConstants.CASTORE;
/* 277 */       InstructionConstants.INSTRUCTIONS[86] = InstructionConstants.SASTORE;
/* 278 */       InstructionConstants.INSTRUCTIONS[87] = InstructionConstants.POP;
/* 279 */       InstructionConstants.INSTRUCTIONS[88] = InstructionConstants.POP2;
/* 280 */       InstructionConstants.INSTRUCTIONS[89] = InstructionConstants.DUP;
/* 281 */       InstructionConstants.INSTRUCTIONS[90] = InstructionConstants.DUP_X1;
/* 282 */       InstructionConstants.INSTRUCTIONS[91] = InstructionConstants.DUP_X2;
/* 283 */       InstructionConstants.INSTRUCTIONS[92] = InstructionConstants.DUP2;
/* 284 */       InstructionConstants.INSTRUCTIONS[93] = InstructionConstants.DUP2_X1;
/* 285 */       InstructionConstants.INSTRUCTIONS[94] = InstructionConstants.DUP2_X2;
/* 286 */       InstructionConstants.INSTRUCTIONS[95] = InstructionConstants.SWAP;
/* 287 */       InstructionConstants.INSTRUCTIONS[96] = InstructionConstants.IADD;
/* 288 */       InstructionConstants.INSTRUCTIONS[97] = InstructionConstants.LADD;
/* 289 */       InstructionConstants.INSTRUCTIONS[98] = InstructionConstants.FADD;
/* 290 */       InstructionConstants.INSTRUCTIONS[99] = InstructionConstants.DADD;
/* 291 */       InstructionConstants.INSTRUCTIONS[100] = InstructionConstants.ISUB;
/* 292 */       InstructionConstants.INSTRUCTIONS[101] = InstructionConstants.LSUB;
/* 293 */       InstructionConstants.INSTRUCTIONS[102] = InstructionConstants.FSUB;
/* 294 */       InstructionConstants.INSTRUCTIONS[103] = InstructionConstants.DSUB;
/* 295 */       InstructionConstants.INSTRUCTIONS[104] = InstructionConstants.IMUL;
/* 296 */       InstructionConstants.INSTRUCTIONS[105] = InstructionConstants.LMUL;
/* 297 */       InstructionConstants.INSTRUCTIONS[106] = InstructionConstants.FMUL;
/* 298 */       InstructionConstants.INSTRUCTIONS[107] = InstructionConstants.DMUL;
/* 299 */       InstructionConstants.INSTRUCTIONS[108] = InstructionConstants.IDIV;
/* 300 */       InstructionConstants.INSTRUCTIONS[109] = InstructionConstants.LDIV;
/* 301 */       InstructionConstants.INSTRUCTIONS[110] = InstructionConstants.FDIV;
/* 302 */       InstructionConstants.INSTRUCTIONS[111] = InstructionConstants.DDIV;
/* 303 */       InstructionConstants.INSTRUCTIONS[112] = InstructionConstants.IREM;
/* 304 */       InstructionConstants.INSTRUCTIONS[113] = InstructionConstants.LREM;
/* 305 */       InstructionConstants.INSTRUCTIONS[114] = InstructionConstants.FREM;
/* 306 */       InstructionConstants.INSTRUCTIONS[115] = InstructionConstants.DREM;
/* 307 */       InstructionConstants.INSTRUCTIONS[116] = InstructionConstants.INEG;
/* 308 */       InstructionConstants.INSTRUCTIONS[117] = InstructionConstants.LNEG;
/* 309 */       InstructionConstants.INSTRUCTIONS[118] = InstructionConstants.FNEG;
/* 310 */       InstructionConstants.INSTRUCTIONS[119] = InstructionConstants.DNEG;
/* 311 */       InstructionConstants.INSTRUCTIONS[120] = InstructionConstants.ISHL;
/* 312 */       InstructionConstants.INSTRUCTIONS[121] = InstructionConstants.LSHL;
/* 313 */       InstructionConstants.INSTRUCTIONS[122] = InstructionConstants.ISHR;
/* 314 */       InstructionConstants.INSTRUCTIONS[123] = InstructionConstants.LSHR;
/* 315 */       InstructionConstants.INSTRUCTIONS[124] = InstructionConstants.IUSHR;
/* 316 */       InstructionConstants.INSTRUCTIONS[125] = InstructionConstants.LUSHR;
/* 317 */       InstructionConstants.INSTRUCTIONS[126] = InstructionConstants.IAND;
/* 318 */       InstructionConstants.INSTRUCTIONS[127] = InstructionConstants.LAND;
/* 319 */       InstructionConstants.INSTRUCTIONS[128] = InstructionConstants.IOR;
/* 320 */       InstructionConstants.INSTRUCTIONS[129] = InstructionConstants.LOR;
/* 321 */       InstructionConstants.INSTRUCTIONS[130] = InstructionConstants.IXOR;
/* 322 */       InstructionConstants.INSTRUCTIONS[131] = InstructionConstants.LXOR;
/* 323 */       InstructionConstants.INSTRUCTIONS[133] = InstructionConstants.I2L;
/* 324 */       InstructionConstants.INSTRUCTIONS[134] = InstructionConstants.I2F;
/* 325 */       InstructionConstants.INSTRUCTIONS[135] = InstructionConstants.I2D;
/* 326 */       InstructionConstants.INSTRUCTIONS[136] = InstructionConstants.L2I;
/* 327 */       InstructionConstants.INSTRUCTIONS[137] = InstructionConstants.L2F;
/* 328 */       InstructionConstants.INSTRUCTIONS[138] = InstructionConstants.L2D;
/* 329 */       InstructionConstants.INSTRUCTIONS[139] = InstructionConstants.F2I;
/* 330 */       InstructionConstants.INSTRUCTIONS[140] = InstructionConstants.F2L;
/* 331 */       InstructionConstants.INSTRUCTIONS[141] = InstructionConstants.F2D;
/* 332 */       InstructionConstants.INSTRUCTIONS[142] = InstructionConstants.D2I;
/* 333 */       InstructionConstants.INSTRUCTIONS[143] = InstructionConstants.D2L;
/* 334 */       InstructionConstants.INSTRUCTIONS[144] = InstructionConstants.D2F;
/* 335 */       InstructionConstants.INSTRUCTIONS[145] = InstructionConstants.I2B;
/* 336 */       InstructionConstants.INSTRUCTIONS[146] = InstructionConstants.I2C;
/* 337 */       InstructionConstants.INSTRUCTIONS[147] = InstructionConstants.I2S;
/* 338 */       InstructionConstants.INSTRUCTIONS[148] = InstructionConstants.LCMP;
/* 339 */       InstructionConstants.INSTRUCTIONS[149] = InstructionConstants.FCMPL;
/* 340 */       InstructionConstants.INSTRUCTIONS[150] = InstructionConstants.FCMPG;
/* 341 */       InstructionConstants.INSTRUCTIONS[151] = InstructionConstants.DCMPL;
/* 342 */       InstructionConstants.INSTRUCTIONS[152] = InstructionConstants.DCMPG;
/* 343 */       InstructionConstants.INSTRUCTIONS[172] = InstructionConstants.IRETURN;
/* 344 */       InstructionConstants.INSTRUCTIONS[173] = InstructionConstants.LRETURN;
/* 345 */       InstructionConstants.INSTRUCTIONS[174] = InstructionConstants.FRETURN;
/* 346 */       InstructionConstants.INSTRUCTIONS[175] = InstructionConstants.DRETURN;
/* 347 */       InstructionConstants.INSTRUCTIONS[176] = InstructionConstants.ARETURN;
/* 348 */       InstructionConstants.INSTRUCTIONS[177] = InstructionConstants.RETURN;
/* 349 */       InstructionConstants.INSTRUCTIONS[190] = InstructionConstants.ARRAYLENGTH;
/* 350 */       InstructionConstants.INSTRUCTIONS[191] = InstructionConstants.ATHROW;
/* 351 */       InstructionConstants.INSTRUCTIONS[194] = InstructionConstants.MONITORENTER;
/* 352 */       InstructionConstants.INSTRUCTIONS[195] = InstructionConstants.MONITOREXIT;
/* 353 */       InstructionConstants.INSTRUCTIONS[254] = InstructionConstants.IMPDEP1;
/* 354 */       InstructionConstants.INSTRUCTIONS[255] = InstructionConstants.IMPDEP2;
/*     */       
/* 356 */       InstructionConstants.INSTRUCTIONS[42] = InstructionConstants.ALOAD_0; InstructionConstants.INSTRUCTIONS[43] = InstructionConstants.ALOAD_1;
/* 357 */       InstructionConstants.INSTRUCTIONS[44] = InstructionConstants.ALOAD_2; InstructionConstants.INSTRUCTIONS[45] = InstructionConstants.ALOAD_3;
/* 358 */       InstructionConstants.INSTRUCTIONS[30] = InstructionConstants.LLOAD_0; InstructionConstants.INSTRUCTIONS[31] = InstructionConstants.LLOAD_1;
/* 359 */       InstructionConstants.INSTRUCTIONS[32] = InstructionConstants.LLOAD_2; InstructionConstants.INSTRUCTIONS[33] = InstructionConstants.LLOAD_3;
/* 360 */       InstructionConstants.INSTRUCTIONS[38] = InstructionConstants.DLOAD_0; InstructionConstants.INSTRUCTIONS[39] = InstructionConstants.DLOAD_1;
/* 361 */       InstructionConstants.INSTRUCTIONS[40] = InstructionConstants.DLOAD_2; InstructionConstants.INSTRUCTIONS[41] = InstructionConstants.DLOAD_3;
/* 362 */       InstructionConstants.INSTRUCTIONS[34] = InstructionConstants.FLOAD_0; InstructionConstants.INSTRUCTIONS[35] = InstructionConstants.FLOAD_1;
/* 363 */       InstructionConstants.INSTRUCTIONS[36] = InstructionConstants.FLOAD_2; InstructionConstants.INSTRUCTIONS[37] = InstructionConstants.FLOAD_3;
/* 364 */       InstructionConstants.INSTRUCTIONS[26] = InstructionConstants.ILOAD_0; InstructionConstants.INSTRUCTIONS[27] = InstructionConstants.ILOAD_1;
/* 365 */       InstructionConstants.INSTRUCTIONS[28] = InstructionConstants.ILOAD_2; InstructionConstants.INSTRUCTIONS[29] = InstructionConstants.ILOAD_3;
/*     */       
/* 367 */       InstructionConstants.INSTRUCTIONS[75] = InstructionConstants.ASTORE_0; InstructionConstants.INSTRUCTIONS[76] = InstructionConstants.ASTORE_1;
/* 368 */       InstructionConstants.INSTRUCTIONS[77] = InstructionConstants.ASTORE_2; InstructionConstants.INSTRUCTIONS[78] = InstructionConstants.ASTORE_3;
/* 369 */       InstructionConstants.INSTRUCTIONS[63] = InstructionConstants.LSTORE_0; InstructionConstants.INSTRUCTIONS[64] = InstructionConstants.LSTORE_1;
/* 370 */       InstructionConstants.INSTRUCTIONS[65] = InstructionConstants.LSTORE_2; InstructionConstants.INSTRUCTIONS[66] = InstructionConstants.LSTORE_3;
/* 371 */       InstructionConstants.INSTRUCTIONS[71] = InstructionConstants.DSTORE_0; InstructionConstants.INSTRUCTIONS[72] = InstructionConstants.DSTORE_1;
/* 372 */       InstructionConstants.INSTRUCTIONS[73] = InstructionConstants.DSTORE_2; InstructionConstants.INSTRUCTIONS[74] = InstructionConstants.DSTORE_3;
/* 373 */       InstructionConstants.INSTRUCTIONS[67] = InstructionConstants.FSTORE_0; InstructionConstants.INSTRUCTIONS[68] = InstructionConstants.FSTORE_1;
/* 374 */       InstructionConstants.INSTRUCTIONS[69] = InstructionConstants.FSTORE_2; InstructionConstants.INSTRUCTIONS[70] = InstructionConstants.FSTORE_3;
/* 375 */       InstructionConstants.INSTRUCTIONS[59] = InstructionConstants.ISTORE_0; InstructionConstants.INSTRUCTIONS[60] = InstructionConstants.ISTORE_1;
/* 376 */       InstructionConstants.INSTRUCTIONS[61] = InstructionConstants.ISTORE_2; InstructionConstants.INSTRUCTIONS[62] = InstructionConstants.ISTORE_3;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */