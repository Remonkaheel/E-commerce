/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.Constant;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvokeInstruction
/*     */   extends FieldOrMethod
/*     */ {
/*     */   public InvokeInstruction(short opcode, int index) {
/*  74 */     super(opcode, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(ConstantPool cp) {
/*  81 */     Constant c = cp.getConstant(this.index);
/*  82 */     StringTokenizer tok = new StringTokenizer(cp.constantToString(c));
/*     */     
/*  84 */     return Constants.OPCODE_NAMES[this.opcode] + " " + tok.nextToken().replace('.', '/') + tok.nextToken();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int consumeStack(ConstantPool cpg) {
/*  93 */     String signature = getSignature(cpg);
/*  94 */     int sum = Type.getArgumentSizes(signature);
/*  95 */     if (this.opcode != 184) {
/*  96 */       sum++;
/*     */     }
/*  98 */     return sum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int produceStack(ConstantPool cpg) {
/* 107 */     return getReturnType(cpg).getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType(ConstantPool cpg) {
/* 114 */     return getReturnType(cpg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodName(ConstantPool cpg) {
/* 121 */     return getName(cpg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getReturnType(ConstantPool cpg) {
/* 128 */     return Type.getReturnType(getSignature(cpg));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type[] getArgumentTypes(ConstantPool cpg) {
/* 135 */     return Type.getArgumentTypes(getSignature(cpg));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InvokeInstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */