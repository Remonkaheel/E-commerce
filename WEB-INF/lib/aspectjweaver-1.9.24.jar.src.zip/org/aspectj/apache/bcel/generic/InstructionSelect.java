/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InstructionSelect
/*     */   extends InstructionBranch
/*     */ {
/*     */   protected int[] match;
/*     */   protected int[] indices;
/*     */   protected InstructionHandle[] targets;
/*     */   protected int fixedLength;
/*     */   protected int matchLength;
/*  76 */   protected int padding = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected short length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InstructionSelect(short opcode, int[] match, InstructionHandle[] targets, InstructionHandle target) {
/*  88 */     super(opcode, target);
/*     */     
/*  90 */     this.targets = targets;
/*  91 */     for (InstructionHandle instructionHandle : targets) {
/*  92 */       notifyTarget((InstructionHandle)null, instructionHandle, this);
/*     */     }
/*     */     
/*  95 */     this.match = match;
/*     */     
/*  97 */     if ((this.matchLength = match.length) != targets.length) {
/*  98 */       throw new ClassGenException("Match and target array have not the same length");
/*     */     }
/*     */     
/* 101 */     this.indices = new int[this.matchLength];
/*     */   }
/*     */   
/*     */   protected int getTargetOffset(InstructionHandle target) {
/* 105 */     if (target == null) {
/* 106 */       throw new ClassGenException("Target of " + super.toString(true) + " is invalid null handle");
/*     */     }
/*     */     
/* 109 */     int t = target.getPosition();
/*     */     
/* 111 */     if (t < 0) {
/* 112 */       throw new ClassGenException("Invalid branch target position offset for " + super.toString(true) + ":" + t + ":" + target);
/*     */     }
/*     */ 
/*     */     
/* 116 */     return t - this.positionOfThisInstruction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 132 */     this.positionOfThisInstruction += offset;
/*     */ 
/*     */ 
/*     */     
/* 136 */     short old_length = this.length;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.padding = (4 - (this.positionOfThisInstruction + 1) % 4) % 4;
/* 142 */     this.length = (short)(this.fixedLength + this.padding);
/*     */     
/* 144 */     return this.length - old_length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/* 153 */     out.writeByte(this.opcode);
/*     */     
/* 155 */     for (int i = 0; i < this.padding; i++) {
/* 156 */       out.writeByte(0);
/*     */     }
/*     */     
/* 159 */     this.targetIndex = getTargetOffset();
/* 160 */     out.writeInt(this.targetIndex);
/*     */   }
/*     */   
/*     */   public InstructionSelect(short opcode, ByteSequence bytes) throws IOException {
/* 164 */     super(opcode);
/* 165 */     this.padding = (4 - bytes.getIndex() % 4) % 4;
/*     */     
/* 167 */     for (int i = 0; i < this.padding; i++) {
/* 168 */       bytes.readByte();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 173 */     this.targetIndex = bytes.readInt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 180 */     StringBuilder buf = new StringBuilder(super.toString(verbose));
/*     */     
/* 182 */     if (verbose) {
/* 183 */       for (int i = 0; i < this.matchLength; i++) {
/* 184 */         String s = "null";
/*     */         
/* 186 */         if (this.targets[i] != null) {
/* 187 */           s = this.targets[i].getInstruction().toString();
/*     */         }
/*     */         
/* 190 */         buf.append("(" + this.match[i] + ", " + s + " = {" + this.indices[i] + "})");
/*     */       } 
/*     */     } else {
/* 193 */       buf.append(" ...");
/*     */     } 
/*     */     
/* 196 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(int i, InstructionHandle target) {
/* 203 */     notifyTarget(this.targets[i], target, this);
/* 204 */     this.targets[i] = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 212 */     boolean targeted = false;
/*     */     
/* 214 */     if (this.targetInstruction == old_ih) {
/* 215 */       targeted = true;
/* 216 */       setTarget(new_ih);
/*     */     } 
/*     */     
/* 219 */     for (int i = 0; i < this.targets.length; i++) {
/* 220 */       if (this.targets[i] == old_ih) {
/* 221 */         targeted = true;
/* 222 */         setTarget(i, new_ih);
/*     */       } 
/*     */     } 
/*     */     
/* 226 */     if (!targeted) {
/* 227 */       throw new ClassGenException("Not targeting " + old_ih);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTarget(InstructionHandle ih) {
/* 235 */     if (this.targetInstruction == ih) {
/* 236 */       return true;
/*     */     }
/*     */     
/* 239 */     for (InstructionHandle target : this.targets) {
/* 240 */       if (target == ih) {
/* 241 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 245 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 252 */     super.dispose();
/*     */     
/* 254 */     for (InstructionHandle target : this.targets) {
/* 255 */       target.removeTargeter(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getMatchs() {
/* 263 */     return this.match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getIndices() {
/* 270 */     return this.indices;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 274 */     return (this == other);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 278 */     return this.opcode * 37;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionHandle[] getTargets() {
/* 285 */     return this.targets;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 289 */     return this.length;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionSelect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */