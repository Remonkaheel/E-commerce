/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionByte
/*     */   extends Instruction
/*     */ {
/*     */   private final byte theByte;
/*     */   
/*     */   public InstructionByte(short opcode, byte b) {
/*  66 */     super(opcode);
/*  67 */     this.theByte = b;
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  71 */     out.writeByte(this.opcode);
/*  72 */     out.writeByte(this.theByte);
/*     */   }
/*     */   
/*     */   public String toString(boolean verbose) {
/*  76 */     return super.toString(verbose) + " " + this.theByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte getTypecode() {
/*  85 */     return this.theByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Type getType() {
/*  94 */     return new ArrayType(BasicType.getType(this.theByte), 1);
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  98 */     if (!(other instanceof InstructionByte)) {
/*  99 */       return false;
/*     */     }
/* 101 */     InstructionByte o = (InstructionByte)other;
/* 102 */     return (o.opcode == this.opcode && o.theByte == this.theByte);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 106 */     return this.opcode * 37 + this.theByte;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\InstructionByte.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */