/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BasicType
/*     */   extends Type
/*     */ {
/*     */   BasicType(byte type) {
/*  72 */     super(type, Constants.SHORT_TYPE_NAMES[type]);
/*     */     
/*  74 */     if (type < 4 || type > 12) {
/*  75 */       throw new ClassGenException("Invalid type: " + type);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final BasicType getType(byte type) {
/*  80 */     switch (type) {
/*     */       case 12:
/*  82 */         return VOID;
/*     */       case 4:
/*  84 */         return BOOLEAN;
/*     */       case 8:
/*  86 */         return BYTE;
/*     */       case 9:
/*  88 */         return SHORT;
/*     */       case 5:
/*  90 */         return CHAR;
/*     */       case 10:
/*  92 */         return INT;
/*     */       case 11:
/*  94 */         return LONG;
/*     */       case 7:
/*  96 */         return DOUBLE;
/*     */       case 6:
/*  98 */         return FLOAT;
/*     */     } 
/*     */     
/* 101 */     throw new ClassGenException("Invalid type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object type) {
/* 109 */     return (type instanceof BasicType) ? ((((BasicType)type).type == this.type)) : false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\BasicType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */