/*    */ package org.aspectj.apache.bcel.generic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LocalVariableTag
/*    */   extends Tag
/*    */ {
/*    */   private final String signature;
/*    */   private String name;
/*    */   private int slot;
/*    */   private final int startPosition;
/*    */   private boolean remapped = false;
/* 23 */   private int hashCode = 0;
/*    */   
/*    */   private Type type;
/*    */ 
/*    */   
/*    */   public LocalVariableTag(String signature, String name, int slot, int startPosition) {
/* 29 */     this.signature = signature;
/* 30 */     this.name = name;
/* 31 */     this.slot = slot;
/* 32 */     this.startPosition = startPosition;
/*    */   }
/*    */   
/*    */   public LocalVariableTag(Type type, String signature, String name, int slot, int startPosition) {
/* 36 */     this.type = type;
/* 37 */     this.signature = signature;
/* 38 */     this.name = name;
/* 39 */     this.slot = slot;
/* 40 */     this.startPosition = startPosition;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 44 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getSlot() {
/* 48 */     return this.slot;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 52 */     return this.signature;
/*    */   }
/*    */   
/*    */   public Type getRealType() {
/* 56 */     return this.type;
/*    */   }
/*    */   
/*    */   public void updateSlot(int newSlot) {
/* 60 */     this.slot = newSlot;
/* 61 */     this.remapped = true;
/* 62 */     this.hashCode = 0;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 66 */     this.name = name;
/* 67 */     this.hashCode = 0;
/*    */   }
/*    */   
/*    */   public boolean isRemapped() {
/* 71 */     return this.remapped;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 75 */     return "local " + this.slot + ": " + this.signature + " " + this.name;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 79 */     if (!(other instanceof LocalVariableTag)) {
/* 80 */       return false;
/*    */     }
/* 82 */     LocalVariableTag o = (LocalVariableTag)other;
/* 83 */     return (o.slot == this.slot && o.startPosition == this.startPosition && o.signature.equals(this.signature) && o.name.equals(this.name));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 87 */     if (this.hashCode == 0) {
/* 88 */       int ret = this.signature.hashCode();
/* 89 */       ret = 37 * ret + this.name.hashCode();
/* 90 */       ret = 37 * ret + this.slot;
/* 91 */       ret = 37 * ret + this.startPosition;
/* 92 */       this.hashCode = ret;
/*    */     } 
/* 94 */     return this.hashCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\LocalVariableTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */