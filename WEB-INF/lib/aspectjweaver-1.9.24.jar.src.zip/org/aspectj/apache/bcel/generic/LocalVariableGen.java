/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.LocalVariable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariableGen
/*     */   implements InstructionTargeter, Cloneable, Serializable
/*     */ {
/*     */   private int index;
/*     */   private String name;
/*     */   private Type type;
/*     */   private InstructionHandle start;
/*     */   private InstructionHandle end;
/*     */   
/*     */   public LocalVariableGen(int index, String name, Type type, InstructionHandle start, InstructionHandle end) {
/*  87 */     if (index < 0 || index > 65535) {
/*  88 */       throw new ClassGenException("Invalid index index: " + index);
/*     */     }
/*     */     
/*  91 */     this.name = name;
/*  92 */     this.type = type;
/*  93 */     this.index = index;
/*  94 */     setStart(start);
/*  95 */     setEnd(end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariable getLocalVariable(ConstantPool cp) {
/* 112 */     int start_pc = this.start.getPosition();
/* 113 */     int length = this.end.getPosition() - start_pc;
/*     */     
/* 115 */     if (length > 0) {
/* 116 */       length += this.end.getInstruction().getLength();
/*     */     }
/*     */     
/* 119 */     int name_index = cp.addUtf8(this.name);
/* 120 */     int signature_index = cp.addUtf8(this.type.getSignature());
/*     */     
/* 122 */     return new LocalVariable(start_pc, length, name_index, signature_index, this.index, cp);
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 126 */     this.index = index;
/*     */   }
/*     */   
/*     */   public int getIndex() {
/* 130 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 134 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 138 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setType(Type type) {
/* 142 */     this.type = type;
/*     */   }
/*     */   
/*     */   public Type getType() {
/* 146 */     return this.type;
/*     */   }
/*     */   
/*     */   public InstructionHandle getStart() {
/* 150 */     return this.start;
/*     */   }
/*     */   
/*     */   public InstructionHandle getEnd() {
/* 154 */     return this.end;
/*     */   }
/*     */   
/*     */   public void setStart(InstructionHandle start) {
/* 158 */     InstructionBranch.notifyTarget(this.start, start, this);
/* 159 */     this.start = start;
/*     */   }
/*     */   
/*     */   public void setEnd(InstructionHandle end) {
/* 163 */     InstructionBranch.notifyTarget(this.end, end, this);
/* 164 */     this.end = end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 172 */     boolean targeted = false;
/*     */     
/* 174 */     if (this.start == old_ih) {
/* 175 */       targeted = true;
/* 176 */       setStart(new_ih);
/*     */     } 
/*     */     
/* 179 */     if (this.end == old_ih) {
/* 180 */       targeted = true;
/* 181 */       setEnd(new_ih);
/*     */     } 
/*     */     
/* 184 */     if (!targeted) {
/* 185 */       throw new ClassGenException("Not targeting " + old_ih + ", but {" + this.start + ", " + this.end + "}");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTarget(InstructionHandle ih) {
/* 193 */     return (this.start == ih || this.end == ih);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 200 */     if (!(o instanceof LocalVariableGen)) {
/* 201 */       return false;
/*     */     }
/*     */     
/* 204 */     LocalVariableGen l = (LocalVariableGen)o;
/* 205 */     return (l.index == this.index && l.start == this.start && l.end == this.end);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 209 */     return "LocalVariableGen(" + this.name + ", " + this.type + ", " + this.start + ", " + this.end + ")";
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 214 */       return super.clone();
/* 215 */     } catch (CloneNotSupportedException e) {
/* 216 */       System.err.println(e);
/* 217 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\LocalVariableGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */