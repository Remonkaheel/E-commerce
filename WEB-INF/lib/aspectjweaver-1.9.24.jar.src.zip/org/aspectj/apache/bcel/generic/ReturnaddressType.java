/*    */ package org.aspectj.apache.bcel.generic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReturnaddressType
/*    */   extends Type
/*    */ {
/* 67 */   public static final ReturnaddressType NO_TARGET = new ReturnaddressType();
/*    */ 
/*    */   
/*    */   private InstructionHandle returnTarget;
/*    */ 
/*    */   
/*    */   private ReturnaddressType() {
/* 74 */     super((byte)16, "<return address>");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReturnaddressType(InstructionHandle returnTarget) {
/* 81 */     super((byte)16, "<return address targeting " + returnTarget + ">");
/* 82 */     this.returnTarget = returnTarget;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object rat) {
/* 89 */     if (!(rat instanceof ReturnaddressType)) {
/* 90 */       return false;
/*    */     }
/* 92 */     return ((ReturnaddressType)rat).returnTarget.equals(this.returnTarget);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InstructionHandle getTarget() {
/* 99 */     return this.returnTarget;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\ReturnaddressType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */