/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TABLESWITCH
/*     */   extends InstructionSelect
/*     */ {
/*     */   public TABLESWITCH(int[] match, InstructionHandle[] targets, InstructionHandle target) {
/*  77 */     super((short)170, match, targets, target);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.length = (short)(13 + this.matchLength * 4);
/*  85 */     this.fixedLength = this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  94 */     super.dump(out);
/*     */     
/*  96 */     int low = (this.matchLength > 0) ? this.match[0] : 0;
/*  97 */     out.writeInt(low);
/*     */     
/*  99 */     int high = (this.matchLength > 0) ? this.match[this.matchLength - 1] : 0;
/* 100 */     out.writeInt(high);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     for (int i = 0; i < this.matchLength; i++) {
/* 106 */       out.writeInt(this.indices[i] = getTargetOffset(this.targets[i]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TABLESWITCH(ByteSequence bytes) throws IOException {
/* 114 */     super((short)170, bytes);
/*     */     
/* 116 */     int low = bytes.readInt();
/* 117 */     int high = bytes.readInt();
/*     */     
/* 119 */     this.matchLength = high - low + 1;
/* 120 */     this.fixedLength = (short)(13 + this.matchLength * 4);
/* 121 */     this.length = (short)(this.fixedLength + this.padding);
/*     */     
/* 123 */     this.match = new int[this.matchLength];
/* 124 */     this.indices = new int[this.matchLength];
/* 125 */     this.targets = new InstructionHandle[this.matchLength];
/*     */     int i;
/* 127 */     for (i = 0; i < this.matchLength; i++) {
/* 128 */       this.match[i] = low + i;
/*     */     }
/*     */     
/* 131 */     for (i = 0; i < this.matchLength; i++)
/* 132 */       this.indices[i] = bytes.readInt(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\TABLESWITCH.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */