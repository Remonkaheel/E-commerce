/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import org.aspectj.apache.bcel.classfile.Constant;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantCP;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldOrMethod
/*     */   extends InstructionCP
/*     */ {
/*     */   protected String signature;
/*     */   protected String name;
/*     */   private String classname;
/*     */   
/*     */   protected FieldOrMethod(short opcode, int index) {
/*  75 */     super(opcode, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSignature(ConstantPool cp) {
/*  82 */     if (this.signature == null) {
/*  83 */       Constant c = cp.getConstant(this.index);
/*  84 */       ConstantCP cmr = (ConstantCP)c;
/*  85 */       ConstantNameAndType cnat = (ConstantNameAndType)cp.getConstant(cmr.getNameAndTypeIndex());
/*  86 */       this.signature = ((ConstantUtf8)cp.getConstant(cnat.getSignatureIndex())).getValue();
/*     */     } 
/*  88 */     return this.signature;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(ConstantPool cp) {
/*  95 */     if (this.name == null) {
/*  96 */       ConstantCP cmr = (ConstantCP)cp.getConstant(this.index);
/*  97 */       ConstantNameAndType cnat = (ConstantNameAndType)cp.getConstant(cmr.getNameAndTypeIndex());
/*  98 */       this.name = ((ConstantUtf8)cp.getConstant(cnat.getNameIndex())).getValue();
/*     */     } 
/* 100 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName(ConstantPool cp) {
/* 107 */     if (this.classname == null) {
/* 108 */       ConstantCP cmr = (ConstantCP)cp.getConstant(this.index);
/* 109 */       String str = cp.getConstantString(cmr.getClassIndex(), (byte)7);
/* 110 */       if (str.charAt(0) == '[') {
/* 111 */         this.classname = str;
/*     */       } else {
/* 113 */         this.classname = str.replace('/', '.');
/*     */       } 
/*     */     } 
/* 116 */     return this.classname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectType getClassType(ConstantPool cpg) {
/* 123 */     return new ObjectType(getClassName(cpg));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectType getLoadClassType(ConstantPool cpg) {
/* 131 */     return getClassType(cpg);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\FieldOrMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */