/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class INVOKEINTERFACE
/*     */   extends InvokeInstruction
/*     */ {
/*     */   private int nargs;
/*     */   
/*     */   public INVOKEINTERFACE(int index, int nargs, int zerobyte) {
/*  76 */     super((short)185, index);
/*     */     
/*  78 */     if (nargs < 1) {
/*  79 */       throw new ClassGenException("Number of arguments must be > 0 " + nargs);
/*     */     }
/*     */     
/*  82 */     this.nargs = nargs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  91 */     out.writeByte(this.opcode);
/*  92 */     out.writeShort(this.index);
/*  93 */     out.writeByte(this.nargs);
/*  94 */     out.writeByte(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() {
/* 101 */     return this.nargs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(ConstantPool cp) {
/* 108 */     return super.toString(cp) + " " + this.nargs;
/*     */   }
/*     */   
/*     */   public int consumeStack(ConstantPool cpg) {
/* 112 */     return this.nargs;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 116 */     if (!(other instanceof INVOKEINTERFACE)) {
/* 117 */       return false;
/*     */     }
/* 119 */     INVOKEINTERFACE o = (INVOKEINTERFACE)other;
/* 120 */     return (o.opcode == this.opcode && o.index == this.index && o.nargs == this.nargs);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 124 */     return this.opcode * 37 + this.index * (this.nargs + 17);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\INVOKEINTERFACE.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */