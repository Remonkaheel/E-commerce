/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.Modifiers;
/*     */ import org.aspectj.apache.bcel.classfile.Utility;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeAnnos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldGenOrMethodGen
/*     */   extends Modifiers
/*     */ {
/*     */   protected String name;
/*     */   protected Type type;
/*     */   protected ConstantPool cp;
/*  79 */   private List<Attribute> attributeList = new ArrayList<>();
/*  80 */   protected List<AnnotationGen> annotationList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/*  86 */     this.type = type;
/*     */   }
/*     */   
/*     */   public Type getType() {
/*  90 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  94 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  98 */     this.name = name;
/*     */   }
/*     */   
/*     */   public ConstantPool getConstantPool() {
/* 102 */     return this.cp;
/*     */   }
/*     */   
/*     */   public void setConstantPool(ConstantPool cp) {
/* 106 */     this.cp = cp;
/*     */   }
/*     */   
/*     */   public void addAttribute(Attribute a) {
/* 110 */     this.attributeList.add(a);
/*     */   }
/*     */   
/*     */   public void removeAttribute(Attribute a) {
/* 114 */     this.attributeList.remove(a);
/*     */   }
/*     */   
/*     */   public void removeAttributes() {
/* 118 */     this.attributeList.clear();
/*     */   }
/*     */   
/*     */   public List<AnnotationGen> getAnnotations() {
/* 122 */     return this.annotationList;
/*     */   }
/*     */   
/*     */   public void addAnnotation(AnnotationGen ag) {
/* 126 */     this.annotationList.add(ag);
/*     */   }
/*     */   
/*     */   public void removeAnnotation(AnnotationGen ag) {
/* 130 */     this.annotationList.remove(ag);
/*     */   }
/*     */   
/*     */   public void removeAnnotations() {
/* 134 */     this.annotationList.clear();
/*     */   }
/*     */   
/*     */   public List<Attribute> getAttributes() {
/* 138 */     return this.attributeList;
/*     */   }
/*     */   
/*     */   public Attribute[] getAttributesImmutable() {
/* 142 */     Attribute[] attributes = new Attribute[this.attributeList.size()];
/* 143 */     this.attributeList.toArray(attributes);
/* 144 */     return attributes;
/*     */   }
/*     */   
/*     */   protected void addAnnotationsAsAttribute(ConstantPool cp) {
/* 148 */     Collection<RuntimeAnnos> attrs = Utility.getAnnotationAttributes(cp, this.annotationList);
/* 149 */     if (attrs != null)
/* 150 */       for (Attribute attr : attrs)
/* 151 */         addAttribute(attr);  
/*     */   }
/*     */   
/*     */   public abstract String getSignature();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\FieldGenOrMethodGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */