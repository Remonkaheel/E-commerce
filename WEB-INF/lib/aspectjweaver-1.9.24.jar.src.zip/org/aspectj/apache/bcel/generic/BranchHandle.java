/*     */ package org.aspectj.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BranchHandle
/*     */   extends InstructionHandle
/*     */ {
/*     */   private InstructionBranch bi;
/*     */   
/*     */   private BranchHandle(InstructionBranch i) {
/*  71 */     super(i);
/*  72 */     this.bi = i;
/*     */   }
/*     */   
/*     */   static final BranchHandle getBranchHandle(InstructionBranch i) {
/*  76 */     return new BranchHandle(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  84 */     return this.bi.positionOfThisInstruction;
/*     */   }
/*     */   
/*     */   void setPosition(int pos) {
/*  88 */     this.pos = this.bi.positionOfThisInstruction = pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 101 */     int x = this.bi.updatePosition(offset, max_offset);
/* 102 */     this.pos = this.bi.positionOfThisInstruction;
/* 103 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(InstructionHandle ih) {
/* 110 */     this.bi.setTarget(ih);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 117 */     this.bi.updateTarget(old_ih, new_ih);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionHandle getTarget() {
/* 124 */     return this.bi.getTarget();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstruction(Instruction i) {
/* 131 */     super.setInstruction(i);
/* 132 */     this.bi = (InstructionBranch)i;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\generic\BranchHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */