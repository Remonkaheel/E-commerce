/*     */ package org.aspectj.apache.bcel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.JavaClass;
/*     */ import org.aspectj.apache.bcel.util.ClassPath;
/*     */ import org.aspectj.apache.bcel.util.Repository;
/*     */ import org.aspectj.apache.bcel.util.SyntheticRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Repository
/*     */ {
/*  74 */   private static Repository _repository = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Repository getRepository() {
/*  80 */     if (_repository == null) {
/*  81 */       _repository = (Repository)SyntheticRepository.getInstance();
/*     */     }
/*  83 */     return _repository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setRepository(Repository rep) {
/*  90 */     _repository = rep;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClass lookupClass(String class_name) {
/*     */     try {
/* 100 */       JavaClass clazz = getRepository().findClass(class_name);
/*     */       
/* 102 */       if (clazz != null) {
/* 103 */         return clazz;
/*     */       }
/*     */       
/* 106 */       return getRepository().loadClass(class_name);
/* 107 */     } catch (ClassNotFoundException ex) {
/* 108 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassPath.ClassFile lookupClassFile(String class_name) {
/*     */     try {
/* 131 */       return ClassPath.getSystemClassPath().getClassFile(class_name);
/* 132 */     } catch (IOException e) {
/* 133 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearCache() {
/* 141 */     getRepository().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClass addClass(JavaClass clazz) {
/* 150 */     JavaClass old = getRepository().findClass(clazz.getClassName());
/* 151 */     getRepository().storeClass(clazz);
/* 152 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeClass(String clazz) {
/* 159 */     getRepository().removeClass(getRepository().findClass(clazz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean instanceOf(JavaClass clazz, JavaClass super_class) {
/* 208 */     return clazz.instanceOf(super_class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean instanceOf(String clazz, String super_class) {
/* 215 */     return instanceOf(lookupClass(clazz), lookupClass(super_class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implementationOf(JavaClass clazz, JavaClass inter) {
/* 236 */     return clazz.implementationOf(inter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implementationOf(String clazz, String inter) {
/* 243 */     return implementationOf(lookupClass(clazz), lookupClass(inter));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\Repository.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */