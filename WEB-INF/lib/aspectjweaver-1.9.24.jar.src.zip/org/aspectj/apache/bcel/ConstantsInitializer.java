/*     */ package org.aspectj.apache.bcel;
/*     */ 
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantsInitializer
/*     */ {
/*     */   public static Object initialize() {
/*  62 */     Constants.types[21] = (Type)Type.INT;
/*  63 */     Constants.types[54] = (Type)Type.INT;
/*  64 */     Constants.types[26] = (Type)Type.INT;
/*  65 */     Constants.types[59] = (Type)Type.INT;
/*  66 */     Constants.types[27] = (Type)Type.INT;
/*  67 */     Constants.types[60] = (Type)Type.INT;
/*  68 */     Constants.types[28] = (Type)Type.INT;
/*  69 */     Constants.types[61] = (Type)Type.INT;
/*  70 */     Constants.types[29] = (Type)Type.INT;
/*  71 */     Constants.types[62] = (Type)Type.INT;
/*  72 */     Constants.types[22] = (Type)Type.LONG;
/*  73 */     Constants.types[55] = (Type)Type.LONG;
/*  74 */     Constants.types[30] = (Type)Type.LONG;
/*  75 */     Constants.types[63] = (Type)Type.LONG;
/*  76 */     Constants.types[31] = (Type)Type.LONG;
/*  77 */     Constants.types[64] = (Type)Type.LONG;
/*  78 */     Constants.types[32] = (Type)Type.LONG;
/*  79 */     Constants.types[65] = (Type)Type.LONG;
/*  80 */     Constants.types[33] = (Type)Type.LONG;
/*  81 */     Constants.types[66] = (Type)Type.LONG;
/*  82 */     Constants.types[24] = (Type)Type.DOUBLE;
/*  83 */     Constants.types[57] = (Type)Type.DOUBLE;
/*  84 */     Constants.types[38] = (Type)Type.DOUBLE;
/*  85 */     Constants.types[71] = (Type)Type.DOUBLE;
/*  86 */     Constants.types[39] = (Type)Type.DOUBLE;
/*  87 */     Constants.types[72] = (Type)Type.DOUBLE;
/*  88 */     Constants.types[40] = (Type)Type.DOUBLE;
/*  89 */     Constants.types[73] = (Type)Type.DOUBLE;
/*  90 */     Constants.types[41] = (Type)Type.DOUBLE;
/*  91 */     Constants.types[74] = (Type)Type.DOUBLE;
/*  92 */     Constants.types[23] = (Type)Type.FLOAT;
/*  93 */     Constants.types[56] = (Type)Type.FLOAT;
/*  94 */     Constants.types[34] = (Type)Type.FLOAT;
/*  95 */     Constants.types[67] = (Type)Type.FLOAT;
/*  96 */     Constants.types[35] = (Type)Type.FLOAT;
/*  97 */     Constants.types[68] = (Type)Type.FLOAT;
/*  98 */     Constants.types[36] = (Type)Type.FLOAT;
/*  99 */     Constants.types[69] = (Type)Type.FLOAT;
/* 100 */     Constants.types[37] = (Type)Type.FLOAT;
/* 101 */     Constants.types[70] = (Type)Type.FLOAT;
/* 102 */     Constants.types[25] = (Type)Type.OBJECT;
/* 103 */     Constants.types[58] = (Type)Type.OBJECT;
/* 104 */     Constants.types[42] = (Type)Type.OBJECT;
/* 105 */     Constants.types[75] = (Type)Type.OBJECT;
/* 106 */     Constants.types[43] = (Type)Type.OBJECT;
/* 107 */     Constants.types[76] = (Type)Type.OBJECT;
/* 108 */     Constants.types[44] = (Type)Type.OBJECT;
/* 109 */     Constants.types[77] = (Type)Type.OBJECT;
/* 110 */     Constants.types[45] = (Type)Type.OBJECT;
/* 111 */     Constants.types[78] = (Type)Type.OBJECT;
/*     */ 
/*     */     
/* 114 */     Constants.instFlags[0] = 0L;
/* 115 */     Constants.instFlags[1] = 1L;
/* 116 */     Constants.instFlags[2] = 3L;
/* 117 */     Constants.instFlags[3] = 3L;
/* 118 */     Constants.instFlags[4] = 3L;
/* 119 */     Constants.instFlags[5] = 3L;
/* 120 */     Constants.instFlags[6] = 3L;
/* 121 */     Constants.instFlags[7] = 3L;
/* 122 */     Constants.instFlags[8] = 3L;
/* 123 */     Constants.instFlags[9] = 3L;
/* 124 */     Constants.instFlags[10] = 3L;
/* 125 */     Constants.instFlags[11] = 3L;
/* 126 */     Constants.instFlags[12] = 3L;
/* 127 */     Constants.instFlags[13] = 3L;
/* 128 */     Constants.instFlags[14] = 3L;
/* 129 */     Constants.instFlags[15] = 3L;
/*     */     
/* 131 */     Constants.instFlags[16] = 3L;
/* 132 */     Constants.instFlags[17] = 3L;
/*     */     
/* 134 */     Constants.instFlags[18] = 65561L;
/*     */ 
/*     */     
/* 137 */     Constants.instFlags[19] = 65561L;
/*     */ 
/*     */     
/* 140 */     Constants.instFlags[20] = 65561L;
/*     */ 
/*     */ 
/*     */     
/* 144 */     Constants.instFlags[21] = 113L;
/* 145 */     Constants.instFlags[22] = 113L;
/* 146 */     Constants.instFlags[23] = 113L;
/* 147 */     Constants.instFlags[24] = 113L;
/* 148 */     Constants.instFlags[25] = 113L; int ii;
/* 149 */     for (ii = 26; ii <= 45; ii++) {
/* 150 */       Constants.instFlags[ii] = 113L;
/*     */     }
/*     */ 
/*     */     
/* 154 */     Constants.instFlags[54] = 464L;
/* 155 */     Constants.instFlags[55] = 464L;
/* 156 */     Constants.instFlags[56] = 464L;
/* 157 */     Constants.instFlags[57] = 464L;
/* 158 */     Constants.instFlags[58] = 464L;
/* 159 */     for (ii = 59; ii <= 78; ii++) {
/* 160 */       Constants.instFlags[ii] = 464L;
/*     */     }
/*     */     
/* 163 */     Constants.instFlags[108] = 65536L;
/* 164 */     (new Class[1])[0] = ExceptionConstants.ARITHMETIC_EXCEPTION; Constants.instExcs[108] = (Class<Throwable>[])new Class[1];
/* 165 */     Constants.instFlags[112] = 65536L;
/* 166 */     (new Class[1])[0] = ExceptionConstants.ARITHMETIC_EXCEPTION; Constants.instExcs[112] = (Class<Throwable>[])new Class[1];
/* 167 */     Constants.instFlags[109] = 65536L;
/* 168 */     (new Class[1])[0] = ExceptionConstants.ARITHMETIC_EXCEPTION; Constants.instExcs[109] = (Class<Throwable>[])new Class[1];
/* 169 */     Constants.instFlags[113] = 65536L;
/* 170 */     (new Class[1])[0] = ExceptionConstants.ARITHMETIC_EXCEPTION; Constants.instExcs[113] = (Class<Throwable>[])new Class[1];
/*     */     
/* 172 */     Constants.instFlags[190] = 65536L;
/* 173 */     (new Class[1])[0] = ExceptionConstants.NULL_POINTER_EXCEPTION; Constants.instExcs[190] = (Class<Throwable>[])new Class[1];
/* 174 */     Constants.instFlags[191] = 65536L;
/* 175 */     (new Class[1])[0] = ExceptionConstants.THROWABLE; Constants.instExcs[191] = (Class<Throwable>[])new Class[1];
/*     */     
/* 177 */     Constants.instFlags[50] = 65536L;
/* 178 */     Constants.instExcs[50] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 179 */     Constants.instFlags[46] = 65536L;
/* 180 */     Constants.instExcs[46] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 181 */     Constants.instFlags[51] = 65536L;
/* 182 */     Constants.instExcs[51] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 183 */     Constants.instFlags[48] = 65536L;
/* 184 */     Constants.instExcs[48] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 185 */     Constants.instFlags[49] = 65536L;
/* 186 */     Constants.instExcs[49] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 187 */     Constants.instFlags[52] = 65536L;
/* 188 */     Constants.instExcs[52] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 189 */     Constants.instFlags[47] = 65536L;
/* 190 */     Constants.instExcs[47] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 191 */     Constants.instFlags[53] = 65536L;
/* 192 */     Constants.instExcs[53] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/*     */     
/* 194 */     Constants.instFlags[83] = 65536L;
/* 195 */     Constants.instExcs[83] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 196 */     Constants.instFlags[79] = 65536L;
/* 197 */     Constants.instExcs[79] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 198 */     Constants.instFlags[84] = 65536L;
/* 199 */     Constants.instExcs[84] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 200 */     Constants.instFlags[81] = 65536L;
/* 201 */     Constants.instExcs[81] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 202 */     Constants.instFlags[82] = 65536L;
/* 203 */     Constants.instExcs[82] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 204 */     Constants.instFlags[85] = 65536L;
/* 205 */     Constants.instExcs[85] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 206 */     Constants.instFlags[80] = 65536L;
/* 207 */     Constants.instExcs[80] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/* 208 */     Constants.instFlags[86] = 65536L;
/* 209 */     Constants.instExcs[86] = (Class<Throwable>[])ExceptionConstants.EXCS_ARRAY_EXCEPTION;
/*     */ 
/*     */     
/* 212 */     Constants.instFlags[89] = 513L;
/* 213 */     Constants.instFlags[90] = 512L;
/*     */     
/* 215 */     Constants.instFlags[91] = 512L;
/* 216 */     Constants.instFlags[92] = 513L;
/* 217 */     Constants.instFlags[93] = 512L;
/*     */     
/* 219 */     Constants.instFlags[94] = 512L;
/* 220 */     Constants.instFlags[87] = 640L;
/* 221 */     Constants.instFlags[88] = 640L;
/* 222 */     Constants.instFlags[95] = 512L;
/*     */     
/* 224 */     Constants.instFlags[194] = 65536L;
/* 225 */     (new Class[1])[0] = ExceptionConstants.NULL_POINTER_EXCEPTION; Constants.instExcs[194] = (Class<Throwable>[])new Class[1];
/* 226 */     Constants.instFlags[195] = 65536L;
/* 227 */     (new Class[1])[0] = ExceptionConstants.NULL_POINTER_EXCEPTION; Constants.instExcs[195] = (Class<Throwable>[])new Class[1];
/*     */ 
/*     */     
/* 230 */     Constants.instFlags[167] = 3072L;
/* 231 */     Constants.instFlags[200] = 3072L;
/* 232 */     Constants.instFlags[168] = 19456L;
/*     */     
/* 234 */     Constants.instFlags[201] = 19456L;
/*     */ 
/*     */     
/* 237 */     Constants.instFlags[157] = 15360L;
/*     */     
/* 239 */     Constants.instFlags[158] = 15360L;
/*     */     
/* 241 */     Constants.instFlags[154] = 15360L;
/*     */     
/* 243 */     Constants.instFlags[153] = 15360L;
/*     */     
/* 245 */     Constants.instFlags[156] = 15360L;
/*     */     
/* 247 */     Constants.instFlags[155] = 15360L;
/*     */     
/* 249 */     Constants.instFlags[198] = 15360L;
/*     */     
/* 251 */     Constants.instFlags[199] = 15360L;
/*     */     
/* 253 */     Constants.instFlags[165] = 15360L;
/*     */     
/* 255 */     Constants.instFlags[166] = 15360L;
/*     */     
/* 257 */     Constants.instFlags[159] = 15360L;
/*     */     
/* 259 */     Constants.instFlags[162] = 15360L;
/*     */     
/* 261 */     Constants.instFlags[163] = 15360L;
/*     */     
/* 263 */     Constants.instFlags[164] = 15360L;
/*     */     
/* 265 */     Constants.instFlags[161] = 15360L;
/*     */     
/* 267 */     Constants.instFlags[160] = 15360L;
/*     */ 
/*     */     
/* 270 */     Constants.instFlags[171] = 3072L;
/* 271 */     Constants.instFlags[170] = 3072L;
/*     */ 
/*     */     
/* 274 */     Constants.instFlags[176] = 98304L;
/* 275 */     (new Class[1])[0] = ExceptionConstants.ILLEGAL_MONITOR_STATE; Constants.instExcs[176] = (Class<Throwable>[])new Class[1];
/* 276 */     Constants.instFlags[175] = 98304L;
/* 277 */     (new Class[1])[0] = ExceptionConstants.ILLEGAL_MONITOR_STATE; Constants.instExcs[175] = (Class<Throwable>[])new Class[1];
/* 278 */     Constants.instFlags[174] = 98304L;
/* 279 */     (new Class[1])[0] = ExceptionConstants.ILLEGAL_MONITOR_STATE; Constants.instExcs[174] = (Class<Throwable>[])new Class[1];
/* 280 */     Constants.instFlags[172] = 98304L;
/* 281 */     (new Class[1])[0] = ExceptionConstants.ILLEGAL_MONITOR_STATE; Constants.instExcs[172] = (Class<Throwable>[])new Class[1];
/* 282 */     Constants.instFlags[173] = 98304L;
/* 283 */     (new Class[1])[0] = ExceptionConstants.ILLEGAL_MONITOR_STATE; Constants.instExcs[173] = (Class<Throwable>[])new Class[1];
/* 284 */     Constants.instFlags[177] = 98304L;
/* 285 */     (new Class[1])[0] = ExceptionConstants.ILLEGAL_MONITOR_STATE; Constants.instExcs[177] = (Class<Throwable>[])new Class[1];
/*     */     
/* 287 */     Constants.instFlags[187] = 65564L;
/*     */     
/* 289 */     Constants.instExcs[187] = (Class<Throwable>[])ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION_FOR_ALLOCATIONS;
/* 290 */     Constants.instFlags[188] = 65536L;
/* 291 */     (new Class[1])[0] = ExceptionConstants.NEGATIVE_ARRAY_SIZE_EXCEPTION; Constants.instExcs[188] = (Class<Throwable>[])new Class[1];
/*     */     
/* 293 */     Constants.types[132] = (Type)Type.INT;
/* 294 */     Constants.instFlags[132] = 80L;
/* 295 */     Constants.instFlags[169] = 16L;
/*     */     
/* 297 */     Constants.instFlags[189] = 65564L;
/*     */     
/* 299 */     Constants.instExcs[189] = (Class<Throwable>[])ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION_ANEWARRAY;
/* 300 */     Constants.instFlags[192] = 65564L;
/*     */     
/* 302 */     Constants.instExcs[192] = (Class<Throwable>[])ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION_CHECKCAST;
/* 303 */     Constants.instFlags[193] = 65564L;
/*     */     
/* 305 */     Constants.instExcs[193] = (Class<Throwable>[])ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION;
/* 306 */     Constants.instFlags[197] = 65564L;
/*     */     
/* 308 */     Constants.instExcs[197] = (Class<Throwable>[])ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION_ANEWARRAY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     Constants.instFlags[180] = 65564L;
/*     */     
/* 317 */     Constants.instExcs[180] = (Class<Throwable>[])ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION_GETFIELD_PUTFIELD;
/* 318 */     Constants.instFlags[178] = 65565L;
/*     */     
/* 320 */     Constants.instExcs[178] = (Class<Throwable>[])ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION_GETSTATIC_PUTSTATIC;
/* 321 */     Constants.instFlags[181] = 65692L;
/*     */     
/* 323 */     Constants.instExcs[181] = (Class<Throwable>[])ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION_GETFIELD_PUTFIELD;
/* 324 */     Constants.instFlags[179] = 65692L;
/*     */     
/* 326 */     Constants.instExcs[179] = (Class<Throwable>[])ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION_GETSTATIC_PUTSTATIC;
/*     */     
/* 328 */     Constants.instFlags[185] = 65564L;
/*     */     
/* 330 */     Constants.instExcs[185] = (Class<Throwable>[])ExceptionConstants.EXCS_INTERFACE_METHOD_RESOLUTION_INVOKEINTERFACE;
/* 331 */     Constants.instFlags[183] = 65564L;
/*     */     
/* 333 */     Constants.instExcs[183] = (Class<Throwable>[])ExceptionConstants.EXCS_INTERFACE_METHOD_RESOLUTION_INVOKESPECIAL_INVOKEVIRTUAL;
/* 334 */     Constants.instFlags[184] = 65564L;
/*     */     
/* 336 */     Constants.instExcs[184] = (Class<Throwable>[])ExceptionConstants.EXCS_INTERFACE_METHOD_RESOLUTION_INVOKESTATIC;
/* 337 */     Constants.instFlags[182] = 65564L;
/*     */     
/* 339 */     Constants.instExcs[182] = (Class<Throwable>[])ExceptionConstants.EXCS_INTERFACE_METHOD_RESOLUTION_INVOKESPECIAL_INVOKEVIRTUAL;
/*     */     
/* 341 */     Constants.instFlags[186] = 65564L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     char[] lengths = "11111111111111112323322222111111111111111111111111111122222111111111111111111111111111111111111111111111111111111111111111111111111131111111111111111111133333333333333332..111111333333355323113311.433551/////".toCharArray();
/*     */     
/* 362 */     int count = 0;
/* 363 */     for (; count < lengths.length; count++) {
/* 364 */       Constants.iLen[count] = (byte)(lengths[count] - 48);
/*     */     }
/* 366 */     while (count < 256) {
/* 367 */       Constants.iLen[count] = -1;
/* 368 */       count++;
/*     */     } 
/* 370 */     Constants.iLen[202] = 1;
/* 371 */     Constants.iLen[254] = 1;
/* 372 */     Constants.iLen[255] = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 386 */     char[] producesOnStack = "0111111112211122111121212111112222111122221111121211110000000000000000000000000000000000023445621212121212121212121212121212121212120212112122121111111110000000000000001000000000.0.0.....1111111000100010/".toCharArray();
/* 387 */     count = 0;
/* 388 */     for (; count < producesOnStack.length; count++) {
/* 389 */       Constants.stackEntriesProduced[count] = (byte)(producesOnStack[count] - 48);
/*     */     }
/* 391 */     while (count < 256) {
/* 392 */       Constants.iLen[count] = -1;
/* 393 */       count++;
/*     */     } 
/* 395 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\ConstantsInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */