/*     */ package org.aspectj.apache.bcel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ExceptionConstants
/*     */ {
/*  68 */   public static final Class<Throwable> THROWABLE = Throwable.class;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final Class<RuntimeException> RUNTIME_EXCEPTION = RuntimeException.class;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final Class<LinkageError> LINKING_EXCEPTION = LinkageError.class;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final Class<ClassCircularityError> CLASS_CIRCULARITY_ERROR = ClassCircularityError.class;
/*  84 */   public static final Class<ClassFormatError> CLASS_FORMAT_ERROR = ClassFormatError.class;
/*  85 */   public static final Class<ExceptionInInitializerError> EXCEPTION_IN_INITIALIZER_ERROR = ExceptionInInitializerError.class;
/*  86 */   public static final Class<IncompatibleClassChangeError> INCOMPATIBLE_CLASS_CHANGE_ERROR = IncompatibleClassChangeError.class;
/*  87 */   public static final Class<AbstractMethodError> ABSTRACT_METHOD_ERROR = AbstractMethodError.class;
/*  88 */   public static final Class<IllegalAccessError> ILLEGAL_ACCESS_ERROR = IllegalAccessError.class;
/*  89 */   public static final Class<InstantiationError> INSTANTIATION_ERROR = InstantiationError.class;
/*  90 */   public static final Class<NoSuchFieldError> NO_SUCH_FIELD_ERROR = NoSuchFieldError.class;
/*  91 */   public static final Class<NoSuchMethodError> NO_SUCH_METHOD_ERROR = NoSuchMethodError.class;
/*  92 */   public static final Class<NoClassDefFoundError> NO_CLASS_DEF_FOUND_ERROR = NoClassDefFoundError.class;
/*  93 */   public static final Class<UnsatisfiedLinkError> UNSATISFIED_LINK_ERROR = UnsatisfiedLinkError.class;
/*  94 */   public static final Class<VerifyError> VERIFY_ERROR = VerifyError.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static final Class<NullPointerException> NULL_POINTER_EXCEPTION = NullPointerException.class;
/* 102 */   public static final Class<ArrayIndexOutOfBoundsException> ARRAY_INDEX_OUT_OF_BOUNDS_EXCEPTION = ArrayIndexOutOfBoundsException.class;
/* 103 */   public static final Class<ArithmeticException> ARITHMETIC_EXCEPTION = ArithmeticException.class;
/* 104 */   public static final Class<NegativeArraySizeException> NEGATIVE_ARRAY_SIZE_EXCEPTION = NegativeArraySizeException.class;
/* 105 */   public static final Class<ClassCastException> CLASS_CAST_EXCEPTION = ClassCastException.class;
/* 106 */   public static final Class<IllegalMonitorStateException> ILLEGAL_MONITOR_STATE = IllegalMonitorStateException.class;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static final Class[] EXCS_CLASS_AND_INTERFACE_RESOLUTION = new Class[] { NO_CLASS_DEF_FOUND_ERROR, CLASS_FORMAT_ERROR, VERIFY_ERROR, ABSTRACT_METHOD_ERROR, EXCEPTION_IN_INITIALIZER_ERROR, ILLEGAL_ACCESS_ERROR };
/*     */   
/* 113 */   public static final Class[] EXCS_CLASS_AND_INTERFACE_RESOLUTION_MULTIANEWARRAY = new Class[] { NO_CLASS_DEF_FOUND_ERROR, CLASS_FORMAT_ERROR, VERIFY_ERROR, ABSTRACT_METHOD_ERROR, EXCEPTION_IN_INITIALIZER_ERROR, ILLEGAL_ACCESS_ERROR, NEGATIVE_ARRAY_SIZE_EXCEPTION, ILLEGAL_ACCESS_ERROR };
/*     */ 
/*     */   
/* 116 */   public static final Class[] EXCS_CLASS_AND_INTERFACE_RESOLUTION_ANEWARRAY = new Class[] { NO_CLASS_DEF_FOUND_ERROR, CLASS_FORMAT_ERROR, VERIFY_ERROR, ABSTRACT_METHOD_ERROR, EXCEPTION_IN_INITIALIZER_ERROR, ILLEGAL_ACCESS_ERROR, NEGATIVE_ARRAY_SIZE_EXCEPTION };
/*     */ 
/*     */   
/* 119 */   public static final Class[] EXCS_CLASS_AND_INTERFACE_RESOLUTION_CHECKCAST = new Class[] { NO_CLASS_DEF_FOUND_ERROR, CLASS_FORMAT_ERROR, VERIFY_ERROR, ABSTRACT_METHOD_ERROR, EXCEPTION_IN_INITIALIZER_ERROR, ILLEGAL_ACCESS_ERROR, CLASS_CAST_EXCEPTION };
/*     */ 
/*     */   
/* 122 */   public static final Class[] EXCS_CLASS_AND_INTERFACE_RESOLUTION_FOR_ALLOCATIONS = new Class[] { NO_CLASS_DEF_FOUND_ERROR, CLASS_FORMAT_ERROR, VERIFY_ERROR, ABSTRACT_METHOD_ERROR, EXCEPTION_IN_INITIALIZER_ERROR, ILLEGAL_ACCESS_ERROR, INSTANTIATION_ERROR, ILLEGAL_ACCESS_ERROR };
/*     */ 
/*     */ 
/*     */   
/* 126 */   public static final Class[] EXCS_FIELD_AND_METHOD_RESOLUTION = new Class[] { NO_SUCH_FIELD_ERROR, ILLEGAL_ACCESS_ERROR, NO_SUCH_METHOD_ERROR };
/*     */ 
/*     */   
/* 129 */   public static final Class[] EXCS_FIELD_AND_METHOD_RESOLUTION_GETFIELD_PUTFIELD = new Class[] { NO_SUCH_FIELD_ERROR, ILLEGAL_ACCESS_ERROR, NO_SUCH_METHOD_ERROR, INCOMPATIBLE_CLASS_CHANGE_ERROR, NULL_POINTER_EXCEPTION };
/*     */ 
/*     */   
/* 132 */   public static final Class[] EXCS_FIELD_AND_METHOD_RESOLUTION_GETSTATIC_PUTSTATIC = new Class[] { NO_SUCH_FIELD_ERROR, ILLEGAL_ACCESS_ERROR, NO_SUCH_METHOD_ERROR, INCOMPATIBLE_CLASS_CHANGE_ERROR };
/*     */ 
/*     */   
/* 135 */   public static final Class[] EXCS_INTERFACE_METHOD_RESOLUTION_INVOKEINTERFACE = new Class[] { INCOMPATIBLE_CLASS_CHANGE_ERROR, ILLEGAL_ACCESS_ERROR, ABSTRACT_METHOD_ERROR, UNSATISFIED_LINK_ERROR };
/*     */   
/* 137 */   public static final Class[] EXCS_INTERFACE_METHOD_RESOLUTION_INVOKESPECIAL_INVOKEVIRTUAL = new Class[] { INCOMPATIBLE_CLASS_CHANGE_ERROR, NULL_POINTER_EXCEPTION, ABSTRACT_METHOD_ERROR, UNSATISFIED_LINK_ERROR };
/*     */ 
/*     */ 
/*     */   
/* 141 */   public static final Class[] EXCS_INTERFACE_METHOD_RESOLUTION_INVOKESTATIC = new Class[] { INCOMPATIBLE_CLASS_CHANGE_ERROR, UNSATISFIED_LINK_ERROR };
/*     */ 
/*     */   
/* 144 */   public static final Class[] EXCS_INTERFACE_METHOD_RESOLUTION = new Class[0];
/* 145 */   public static final Class[] EXCS_STRING_RESOLUTION = new Class[0];
/*     */ 
/*     */   
/* 148 */   public static final Class[] EXCS_ARRAY_EXCEPTION = new Class[] { NULL_POINTER_EXCEPTION, ARRAY_INDEX_OUT_OF_BOUNDS_EXCEPTION };
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\ExceptionConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */