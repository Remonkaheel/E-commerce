/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantMethodHandle
/*     */   extends Constant
/*     */ {
/*     */   private byte referenceKind;
/*     */   private int referenceIndex;
/*     */   
/*     */   ConstantMethodHandle(DataInputStream file) throws IOException {
/*  77 */     this(file.readByte(), file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public ConstantMethodHandle(byte referenceKind, int referenceIndex) {
/*  81 */     super((byte)15);
/*  82 */     this.referenceKind = referenceKind;
/*  83 */     this.referenceIndex = referenceIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  88 */     file.writeByte(this.tag);
/*  89 */     file.writeByte(this.referenceKind);
/*  90 */     file.writeShort(this.referenceIndex);
/*     */   }
/*     */   
/*     */   public final byte getReferenceKind() {
/*  94 */     return this.referenceKind;
/*     */   }
/*     */   
/*     */   public final int getReferenceIndex() {
/*  98 */     return this.referenceIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 103 */     return super.toString() + "(referenceKind=" + this.referenceKind + ",referenceIndex=" + this.referenceIndex + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 108 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 113 */     v.visitConstantMethodHandle(this);
/*     */   }
/*     */   
/*     */   public static String kindToString(byte kind) {
/* 117 */     switch (kind) { case 1:
/* 118 */         return "getfield";
/* 119 */       case 2: return "getstatic";
/* 120 */       case 3: return "putfield";
/* 121 */       case 4: return "putstatic";
/* 122 */       case 5: return "invokevirtual";
/* 123 */       case 6: return "invokestatic";
/* 124 */       case 7: return "invokespecial";
/* 125 */       case 8: return "newinvokespecial";
/* 126 */       case 9: return "invokeinterface"; }
/*     */     
/* 128 */     return "nyi";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantMethodHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */