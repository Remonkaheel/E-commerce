/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RuntimeTypeAnnos
/*     */   extends Attribute
/*     */ {
/*     */   private boolean visible;
/*     */   private TypeAnnotationGen[] typeAnnotations;
/*     */   private byte[] annotation_data;
/*     */   
/*     */   public RuntimeTypeAnnos(byte attrid, boolean visible, int nameIdx, int len, ConstantPool cpool) {
/*  31 */     super(attrid, nameIdx, len, cpool);
/*  32 */     this.visible = visible;
/*     */   }
/*     */   
/*     */   protected void readTypeAnnotations(DataInputStream dis, ConstantPool cpool) throws IOException {
/*  36 */     this.annotation_data = new byte[this.length];
/*  37 */     dis.readFully(this.annotation_data, 0, this.length);
/*     */   }
/*     */   
/*     */   public final void dump(DataOutputStream dos) throws IOException {
/*  41 */     super.dump(dos);
/*  42 */     writeTypeAnnotations(dos);
/*     */   }
/*     */   
/*     */   protected void writeTypeAnnotations(DataOutputStream dos) throws IOException {
/*  46 */     if (this.typeAnnotations == null) {
/*  47 */       dos.write(this.annotation_data, 0, this.length);
/*     */     } else {
/*  49 */       dos.writeShort(this.typeAnnotations.length);
/*  50 */       for (TypeAnnotationGen typeAnnotation : this.typeAnnotations) {
/*  51 */         typeAnnotation.dump(dos);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/*  64 */     throw new RuntimeException("Not implemented yet!");
/*     */   }
/*     */   
/*     */   public TypeAnnotationGen[] getTypeAnnotations() {
/*  68 */     ensureInflated();
/*  69 */     return this.typeAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean areVisible() {
/*  74 */     return this.visible;
/*     */   }
/*     */   
/*     */   private void ensureInflated() {
/*  78 */     if (this.typeAnnotations != null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  82 */       DataInputStream dis = new DataInputStream(new ByteArrayInputStream(this.annotation_data));
/*  83 */       int numTypeAnnotations = dis.readUnsignedShort();
/*  84 */       if (numTypeAnnotations == 0) {
/*  85 */         this.typeAnnotations = TypeAnnotationGen.NO_TYPE_ANNOTATIONS;
/*     */       } else {
/*  87 */         this.typeAnnotations = new TypeAnnotationGen[numTypeAnnotations];
/*  88 */         for (int i = 0; i < numTypeAnnotations; i++) {
/*  89 */           this.typeAnnotations[i] = TypeAnnotationGen.read(dis, getConstantPool(), this.visible);
/*     */         }
/*     */       } 
/*  92 */     } catch (IOException ioe) {
/*  93 */       throw new RuntimeException("Unabled to inflate type annotation data, badly formed?");
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/*  98 */     return "Runtime" + (this.visible ? "Visible" : "Invisible") + "TypeAnnotations [" + (isInflated() ? "inflated" : "not yet inflated") + "]";
/*     */   }
/*     */   
/*     */   public boolean isInflated() {
/* 102 */     return (this.typeAnnotations != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeTypeAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */