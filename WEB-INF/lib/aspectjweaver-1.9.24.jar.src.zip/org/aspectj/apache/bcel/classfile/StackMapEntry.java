/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackMapEntry
/*     */   implements Cloneable
/*     */ {
/*     */   private int byte_code_offset;
/*     */   private int number_of_locals;
/*     */   private StackMapType[] types_of_locals;
/*     */   private int number_of_stack_items;
/*     */   private StackMapType[] types_of_stack_items;
/*     */   private ConstantPool constant_pool;
/*     */   
/*     */   StackMapEntry(DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  86 */     this(file.readShort(), file.readShort(), null, -1, null, constant_pool);
/*     */     
/*  88 */     this.types_of_locals = new StackMapType[this.number_of_locals]; int i;
/*  89 */     for (i = 0; i < this.number_of_locals; i++) {
/*  90 */       this.types_of_locals[i] = new StackMapType(file, constant_pool);
/*     */     }
/*  92 */     this.number_of_stack_items = file.readShort();
/*  93 */     this.types_of_stack_items = new StackMapType[this.number_of_stack_items];
/*  94 */     for (i = 0; i < this.number_of_stack_items; i++) {
/*  95 */       this.types_of_stack_items[i] = new StackMapType(file, constant_pool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackMapEntry(int byte_code_offset, int number_of_locals, StackMapType[] types_of_locals, int number_of_stack_items, StackMapType[] types_of_stack_items, ConstantPool constant_pool) {
/* 103 */     this.byte_code_offset = byte_code_offset;
/* 104 */     this.number_of_locals = number_of_locals;
/* 105 */     this.types_of_locals = types_of_locals;
/* 106 */     this.number_of_stack_items = number_of_stack_items;
/* 107 */     this.types_of_stack_items = types_of_stack_items;
/* 108 */     this.constant_pool = constant_pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 119 */     file.writeShort(this.byte_code_offset);
/*     */     
/* 121 */     file.writeShort(this.number_of_locals); int i;
/* 122 */     for (i = 0; i < this.number_of_locals; i++) {
/* 123 */       this.types_of_locals[i].dump(file);
/*     */     }
/* 125 */     file.writeShort(this.number_of_stack_items);
/* 126 */     for (i = 0; i < this.number_of_stack_items; i++) {
/* 127 */       this.types_of_stack_items[i].dump(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 134 */     StringBuilder buf = new StringBuilder("(offset=" + this.byte_code_offset);
/*     */     
/* 136 */     if (this.number_of_locals > 0) {
/* 137 */       buf.append(", locals={");
/*     */       
/* 139 */       for (int i = 0; i < this.number_of_locals; i++) {
/* 140 */         buf.append(this.types_of_locals[i]);
/* 141 */         if (i < this.number_of_locals - 1) {
/* 142 */           buf.append(", ");
/*     */         }
/*     */       } 
/* 145 */       buf.append("}");
/*     */     } 
/*     */     
/* 148 */     if (this.number_of_stack_items > 0) {
/* 149 */       buf.append(", stack items={");
/*     */       
/* 151 */       for (int i = 0; i < this.number_of_stack_items; i++) {
/* 152 */         buf.append(this.types_of_stack_items[i]);
/* 153 */         if (i < this.number_of_stack_items - 1) {
/* 154 */           buf.append(", ");
/*     */         }
/*     */       } 
/* 157 */       buf.append("}");
/*     */     } 
/*     */     
/* 160 */     buf.append(")");
/*     */     
/* 162 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public void setByteCodeOffset(int b) {
/* 166 */     this.byte_code_offset = b;
/* 167 */   } public int getByteCodeOffset() { return this.byte_code_offset; }
/* 168 */   public void setNumberOfLocals(int n) { this.number_of_locals = n; }
/* 169 */   public int getNumberOfLocals() { return this.number_of_locals; }
/* 170 */   public void setTypesOfLocals(StackMapType[] t) { this.types_of_locals = t; }
/* 171 */   public StackMapType[] getTypesOfLocals() { return this.types_of_locals; }
/* 172 */   public void setNumberOfStackItems(int n) { this.number_of_stack_items = n; }
/* 173 */   public int getNumberOfStackItems() { return this.number_of_stack_items; }
/* 174 */   public void setTypesOfStackItems(StackMapType[] t) { this.types_of_stack_items = t; } public StackMapType[] getTypesOfStackItems() {
/* 175 */     return this.types_of_stack_items;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StackMapEntry copy() {
/*     */     try {
/* 182 */       return (StackMapEntry)clone();
/* 183 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 185 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 196 */     v.visitStackMapEntry(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConstantPool getConstantPool() {
/* 202 */     return this.constant_pool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setConstantPool(ConstantPool constant_pool) {
/* 208 */     this.constant_pool = constant_pool;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\StackMapEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */