/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodParameters
/*     */   extends Attribute
/*     */ {
/*  25 */   public static final int[] NO_PARAMETER_NAME_INDEXES = new int[0];
/*  26 */   public static final int[] NO_PARAMETER_ACCESS_FLAGS = new int[0];
/*     */   
/*     */   public static final int ACCESS_FLAGS_FINAL = 16;
/*     */   
/*     */   public static final int ACCESS_FLAGS_SYNTHETIC = 4096;
/*     */   
/*     */   public static final int ACCESS_FLAGS_MANDATED = 32768;
/*     */   private boolean isInPackedState = false;
/*     */   private byte[] data;
/*     */   private int[] names;
/*     */   private int[] accessFlags;
/*     */   
/*     */   public MethodParameters(int index, int length, DataInputStream dis, ConstantPool cpool) throws IOException {
/*  39 */     super((byte)22, index, length, cpool);
/*  40 */     this.data = new byte[length];
/*  41 */     dis.readFully(this.data, 0, length);
/*  42 */     this.isInPackedState = true;
/*     */   }
/*     */   
/*     */   private void ensureInflated() {
/*  46 */     if (this.names != null)
/*     */       return;  try {
/*  48 */       DataInputStream dis = new DataInputStream(new ByteArrayInputStream(this.data));
/*  49 */       int parametersCount = dis.readUnsignedByte();
/*  50 */       if (parametersCount == 0) {
/*  51 */         this.names = NO_PARAMETER_NAME_INDEXES;
/*  52 */         this.accessFlags = NO_PARAMETER_ACCESS_FLAGS;
/*     */       } else {
/*  54 */         this.names = new int[parametersCount];
/*  55 */         this.accessFlags = new int[parametersCount];
/*  56 */         for (int i = 0; i < parametersCount; i++) {
/*  57 */           this.names[i] = dis.readUnsignedShort();
/*  58 */           this.accessFlags[i] = dis.readUnsignedShort();
/*     */         } 
/*     */       } 
/*  61 */       this.isInPackedState = false;
/*  62 */     } catch (IOException ioe) {
/*  63 */       throw new RuntimeException("Unabled to inflate type annotation data, badly formed?");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream dos) throws IOException {
/*  68 */     super.dump(dos);
/*  69 */     if (this.isInPackedState) {
/*  70 */       dos.write(this.data);
/*     */     } else {
/*  72 */       dos.writeByte(this.names.length);
/*  73 */       for (int i = 0; i < this.names.length; i++) {
/*  74 */         dos.writeShort(this.names[i]);
/*  75 */         dos.writeShort(this.accessFlags[i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getParametersCount() {
/*  81 */     ensureInflated();
/*  82 */     return this.names.length;
/*     */   }
/*     */   
/*     */   public String getParameterName(int parameter) {
/*  86 */     ensureInflated();
/*  87 */     ConstantUtf8 c = (ConstantUtf8)this.cpool.getConstant(this.names[parameter], (byte)1);
/*  88 */     return c.getValue();
/*     */   }
/*     */   
/*     */   public int getAccessFlags(int parameter) {
/*  92 */     ensureInflated();
/*  93 */     return this.accessFlags[parameter];
/*     */   }
/*     */   
/*     */   public boolean isFinal(int parameter) {
/*  97 */     return ((getAccessFlags(parameter) & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public boolean isSynthetic(int parameter) {
/* 101 */     return ((getAccessFlags(parameter) & 0x1000) != 0);
/*     */   }
/*     */   
/*     */   public boolean isMandated(int parameter) {
/* 105 */     return ((getAccessFlags(parameter) & 0x8000) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 110 */     v.visitMethodParameters(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\MethodParameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */