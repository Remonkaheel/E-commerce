/*    */ package org.aspectj.apache.bcel.classfile;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConstantFieldref
/*    */   extends ConstantCP
/*    */ {
/*    */   ConstantFieldref(DataInputStream file) throws IOException {
/* 71 */     super((byte)9, file);
/*    */   }
/*    */   
/*    */   public ConstantFieldref(int class_index, int name_and_type_index) {
/* 75 */     super((byte)9, class_index, name_and_type_index);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 80 */     v.visitConstantFieldref(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 85 */     return toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantFieldref.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */