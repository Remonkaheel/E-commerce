/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Signature
/*     */   extends Attribute
/*     */ {
/*     */   private int signature_index;
/*     */   
/*     */   public Signature(Signature c) {
/*  83 */     this(c.getNameIndex(), c.getLength(), c.getSignatureIndex(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Signature(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  96 */     this(name_index, length, file.readUnsignedShort(), constant_pool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Signature(int name_index, int length, int signature_index, ConstantPool constant_pool) {
/* 106 */     super((byte)10, name_index, length, constant_pool);
/* 107 */     this.signature_index = signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 118 */     System.err.println("Visiting non-standard Signature object");
/* 119 */     v.visitSignature(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 130 */     super.dump(file);
/* 131 */     file.writeShort(this.signature_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getSignatureIndex() {
/* 138 */     return this.signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSignatureIndex(int signature_index) {
/* 145 */     this.signature_index = signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSignature() {
/* 152 */     ConstantUtf8 c = (ConstantUtf8)this.cpool.getConstant(this.signature_index, (byte)1);
/* 153 */     return c.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MyByteArrayInputStream
/*     */     extends ByteArrayInputStream
/*     */   {
/*     */     MyByteArrayInputStream(String data) {
/* 161 */       super(data.getBytes());
/*     */     }
/*     */     
/*     */     final int mark() {
/* 165 */       return this.pos;
/*     */     }
/*     */     
/*     */     final String getData() {
/* 169 */       return new String(this.buf);
/*     */     }
/*     */     
/*     */     final void reset(int p) {
/* 173 */       this.pos = p;
/*     */     }
/*     */     
/*     */     final void unread() {
/* 177 */       if (this.pos > 0)
/* 178 */         this.pos--; 
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean identStart(int ch) {
/* 183 */     return (ch == 84 || ch == 76);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void matchIdent(MyByteArrayInputStream in, StringBuilder buf) {
/*     */     int ch;
/* 189 */     if ((ch = in.read()) == -1) {
/* 190 */       throw new RuntimeException("Illegal signature: " + in.getData() + " no ident, reaching EOF");
/*     */     }
/*     */ 
/*     */     
/* 194 */     if (!identStart(ch)) {
/* 195 */       StringBuilder stringBuilder = new StringBuilder();
/*     */       
/* 197 */       int count = 1;
/* 198 */       while (Character.isJavaIdentifierPart((char)ch)) {
/* 199 */         stringBuilder.append((char)ch);
/* 200 */         count++;
/* 201 */         ch = in.read();
/*     */       } 
/*     */       
/* 204 */       if (ch == 58) {
/* 205 */         in.skip("Ljava/lang/Object".length());
/* 206 */         buf.append(stringBuilder);
/*     */         
/* 208 */         ch = in.read();
/* 209 */         in.unread();
/*     */       } else {
/*     */         
/* 212 */         for (int i = 0; i < count; i++) {
/* 213 */           in.unread();
/*     */         }
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 219 */     StringBuilder buf2 = new StringBuilder();
/* 220 */     ch = in.read();
/*     */     
/*     */     do {
/* 223 */       buf2.append((char)ch);
/* 224 */       ch = in.read();
/*     */     
/*     */     }
/* 227 */     while (ch != -1 && (Character.isJavaIdentifierPart((char)ch) || ch == 47));
/*     */     
/* 229 */     buf.append(buf2.toString().replace('/', '.'));
/*     */ 
/*     */ 
/*     */     
/* 233 */     if (ch != -1) {
/* 234 */       in.unread();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void matchGJIdent(MyByteArrayInputStream in, StringBuilder buf) {
/* 240 */     matchIdent(in, buf);
/*     */     
/* 242 */     int ch = in.read();
/* 243 */     if (ch == 60 || ch == 40) {
/*     */       
/* 245 */       buf.append((char)ch);
/* 246 */       matchGJIdent(in, buf);
/*     */       
/* 248 */       while ((ch = in.read()) != 62 && ch != 41) {
/* 249 */         if (ch == -1) {
/* 250 */           throw new RuntimeException("Illegal signature: " + in.getData() + " reaching EOF");
/*     */         }
/*     */         
/* 253 */         buf.append(", ");
/* 254 */         in.unread();
/* 255 */         matchGJIdent(in, buf);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 260 */       buf.append((char)ch);
/*     */     } else {
/* 262 */       in.unread();
/*     */     } 
/* 264 */     ch = in.read();
/* 265 */     if (identStart(ch))
/* 266 */     { in.unread();
/* 267 */       matchGJIdent(in, buf); }
/* 268 */     else { if (ch == 41) {
/* 269 */         in.unread(); return;
/*     */       } 
/* 271 */       if (ch != 59)
/* 272 */         throw new RuntimeException("Illegal signature: " + in.getData() + " read " + (char)ch);  }
/*     */   
/*     */   }
/*     */   
/*     */   public static String translate(String s) {
/* 277 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 279 */     matchGJIdent(new MyByteArrayInputStream(s), buf);
/*     */     
/* 281 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static final boolean isFormalParameterList(String s) {
/* 285 */     return (s.startsWith("<") && s.indexOf(':') > 0);
/*     */   }
/*     */   
/*     */   public static final boolean isActualParameterList(String s) {
/* 289 */     return (s.startsWith("L") && s.endsWith(">;"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 297 */     String s = getSignature();
/*     */     
/* 299 */     return "Signature(" + s + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Signature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */