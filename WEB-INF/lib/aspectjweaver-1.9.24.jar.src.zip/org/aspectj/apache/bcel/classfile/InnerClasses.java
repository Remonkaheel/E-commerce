/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InnerClasses
/*     */   extends Attribute
/*     */ {
/*     */   private InnerClass[] inner_classes;
/*     */   private int number_of_classes;
/*     */   
/*     */   public InnerClasses(InnerClasses c) {
/*  80 */     this(c.getNameIndex(), c.getLength(), c.getInnerClasses(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InnerClasses(int name_index, int length, InnerClass[] inner_classes, ConstantPool constant_pool) {
/*  91 */     super((byte)6, name_index, length, constant_pool);
/*  92 */     setInnerClasses(inner_classes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InnerClasses(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 105 */     this(name_index, length, (InnerClass[])null, constant_pool);
/*     */     
/* 107 */     this.number_of_classes = file.readUnsignedShort();
/* 108 */     this.inner_classes = new InnerClass[this.number_of_classes];
/*     */     
/* 110 */     for (int i = 0; i < this.number_of_classes; i++) {
/* 111 */       this.inner_classes[i] = new InnerClass(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 122 */     v.visitInnerClasses(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 133 */     super.dump(file);
/* 134 */     file.writeShort(this.number_of_classes);
/*     */     
/* 136 */     for (int i = 0; i < this.number_of_classes; i++) {
/* 137 */       this.inner_classes[i].dump(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final InnerClass[] getInnerClasses() {
/* 144 */     return this.inner_classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInnerClasses(InnerClass[] inner_classes) {
/* 151 */     this.inner_classes = inner_classes;
/* 152 */     this.number_of_classes = (inner_classes == null) ? 0 : inner_classes.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 160 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 162 */     for (int i = 0; i < this.number_of_classes; i++) {
/* 163 */       buf.append(this.inner_classes[i].toString(this.cpool) + "\n");
/*     */     }
/* 165 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\InnerClasses.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */