/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConstantCP
/*     */   extends Constant
/*     */ {
/*     */   protected int classIndex;
/*     */   protected int nameAndTypeIndex;
/*     */   
/*     */   ConstantCP(byte tag, DataInputStream file) throws IOException {
/*  76 */     this(tag, file.readUnsignedShort(), file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   protected ConstantCP(byte tag, int classIndex, int nameAndTypeIndex) {
/*  80 */     super(tag);
/*  81 */     this.classIndex = classIndex;
/*  82 */     this.nameAndTypeIndex = nameAndTypeIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  87 */     file.writeByte(this.tag);
/*  88 */     file.writeShort(this.classIndex);
/*  89 */     file.writeShort(this.nameAndTypeIndex);
/*     */   }
/*     */   
/*     */   public final int getClassIndex() {
/*  93 */     return this.classIndex;
/*     */   }
/*     */   
/*     */   public final int getNameAndTypeIndex() {
/*  97 */     return this.nameAndTypeIndex;
/*     */   }
/*     */   
/*     */   public String getClass(ConstantPool cp) {
/* 101 */     return cp.constantToString(this.classIndex, (byte)7);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 106 */     return super.toString() + "(classIndex = " + this.classIndex + ", nameAndTypeIndex = " + this.nameAndTypeIndex + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantCP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */