/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.ClassVisitor;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeVisTypeAnnos
/*    */   extends RuntimeTypeAnnos
/*    */ {
/*    */   public RuntimeVisTypeAnnos(int nameIdx, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 24 */     this(nameIdx, len, cpool);
/* 25 */     readTypeAnnotations(dis, cpool);
/*    */   }
/*    */   
/*    */   public RuntimeVisTypeAnnos(int nameIdx, int len, ConstantPool cpool) {
/* 29 */     super((byte)20, true, nameIdx, len, cpool);
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 33 */     v.visitRuntimeVisibleTypeAnnotations(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeVisTypeAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */