/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationElementValue
/*    */   extends ElementValue
/*    */ {
/*    */   private AnnotationGen a;
/*    */   
/*    */   public AnnotationElementValue(AnnotationGen a, ConstantPool cpool) {
/* 28 */     super(64, cpool);
/* 29 */     this.a = a;
/*    */   }
/*    */   
/*    */   public AnnotationElementValue(int type, AnnotationGen annotation, ConstantPool cpool) {
/* 33 */     super(type, cpool);
/* 34 */     assert type == 64;
/* 35 */     this.a = annotation;
/*    */   }
/*    */   
/*    */   public AnnotationElementValue(AnnotationElementValue value, ConstantPool cpool, boolean copyPoolEntries) {
/* 39 */     super(64, cpool);
/* 40 */     this.a = new AnnotationGen(value.getAnnotation(), cpool, copyPoolEntries);
/*    */   }
/*    */ 
/*    */   
/*    */   public void dump(DataOutputStream dos) throws IOException {
/* 45 */     dos.writeByte(this.type);
/* 46 */     this.a.dump(dos);
/*    */   }
/*    */ 
/*    */   
/*    */   public String stringifyValue() {
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     ConstantUtf8 cu8 = (ConstantUtf8)this.cpool.getConstant(this.a.getTypeIndex(), (byte)1);
/* 53 */     sb.append(cu8.getValue());
/*    */     
/* 55 */     List<NameValuePair> pairs = this.a.getValues();
/* 56 */     if (pairs != null && pairs.size() > 0) {
/* 57 */       sb.append("(");
/* 58 */       for (int p = 0; p < pairs.size(); p++) {
/* 59 */         if (p > 0) {
/* 60 */           sb.append(",");
/*    */         }
/* 62 */         sb.append(((NameValuePair)pairs.get(p)).getNameString()).append("=").append(((NameValuePair)pairs.get(p)).getValue().stringifyValue());
/*    */       } 
/* 64 */       sb.append(")");
/*    */     } 
/* 66 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public AnnotationGen getAnnotation() {
/* 70 */     return this.a;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\AnnotationElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */