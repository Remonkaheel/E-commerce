/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleMainClass
/*     */   extends Attribute
/*     */ {
/*     */   private int mainClassIndex;
/*     */   
/*     */   public ModuleMainClass(ModuleMainClass c) {
/*  73 */     this(c.getNameIndex(), c.getLength(), c.getMainClassIndex(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public ModuleMainClass(int nameIndex, int length, int mainClassIndex, ConstantPool cp) {
/*  77 */     super((byte)25, nameIndex, length, cp);
/*  78 */     this.mainClassIndex = mainClassIndex;
/*     */   }
/*     */   
/*     */   ModuleMainClass(int nameIndex, int length, DataInputStream stream, ConstantPool cp) throws IOException {
/*  82 */     this(nameIndex, length, 0, cp);
/*  83 */     this.mainClassIndex = stream.readUnsignedShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  88 */     v.visitModuleMainClass(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream stream) throws IOException {
/*  93 */     super.dump(stream);
/*  94 */     stream.writeShort(this.mainClassIndex);
/*     */   }
/*     */   
/*     */   public final int getMainClassIndex() {
/*  98 */     return this.mainClassIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 103 */     return this.cpool.getConstantString_CONSTANTClass(this.mainClassIndex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ModuleMainClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */