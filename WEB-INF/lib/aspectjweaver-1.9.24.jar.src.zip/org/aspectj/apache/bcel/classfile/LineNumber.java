/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LineNumber
/*     */   implements Node
/*     */ {
/*     */   private int startPC;
/*     */   private int lineNumber;
/*     */   
/*     */   public LineNumber(LineNumber c) {
/*  75 */     this(c.getStartPC(), c.getLineNumber());
/*     */   }
/*     */   
/*     */   LineNumber(DataInputStream file) throws IOException {
/*  79 */     this(file.readUnsignedShort(), file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public LineNumber(int startPC, int lineNumber) {
/*  83 */     this.startPC = startPC;
/*  84 */     this.lineNumber = lineNumber;
/*     */   }
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  88 */     v.visitLineNumber(this);
/*     */   }
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  92 */     file.writeShort(this.startPC);
/*  93 */     file.writeShort(this.lineNumber);
/*     */   }
/*     */   
/*     */   public final int getLineNumber() {
/*  97 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */   public final int getStartPC() {
/* 101 */     return this.startPC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 114 */     return "LineNumber(" + this.startPC + ", " + this.lineNumber + ")";
/*     */   }
/*     */   
/*     */   public LineNumber copy() {
/* 118 */     return new LineNumber(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\LineNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */