/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayElementValue
/*    */   extends ElementValue
/*    */ {
/* 21 */   private static final ElementValue[] NO_VALUES = new ElementValue[0];
/*    */ 
/*    */   
/* 24 */   private ElementValue[] evalues = NO_VALUES;
/*    */   
/*    */   public ElementValue[] getElementValuesArray() {
/* 27 */     return this.evalues;
/*    */   }
/*    */   
/*    */   public int getElementValuesArraySize() {
/* 31 */     return this.evalues.length;
/*    */   }
/*    */   
/*    */   public ArrayElementValue(ConstantPool cp) {
/* 35 */     super(91, cp);
/*    */   }
/*    */   
/*    */   public ArrayElementValue(int type, ElementValue[] datums, ConstantPool cpool) {
/* 39 */     super(type, cpool);
/* 40 */     if (type != 91)
/* 41 */       throw new RuntimeException("Only element values of type array can be built with this ctor"); 
/* 42 */     this.evalues = datums;
/*    */   }
/*    */   
/*    */   public ArrayElementValue(ArrayElementValue value, ConstantPool cpool, boolean copyPoolEntries) {
/* 46 */     super(91, cpool);
/* 47 */     this.evalues = new ElementValue[value.getElementValuesArraySize()];
/* 48 */     ElementValue[] in = value.getElementValuesArray();
/* 49 */     for (int i = 0; i < in.length; i++) {
/* 50 */       this.evalues[i] = ElementValue.copy(in[i], cpool, copyPoolEntries);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void dump(DataOutputStream dos) throws IOException {
/* 56 */     dos.writeByte(this.type);
/* 57 */     dos.writeShort(this.evalues.length);
/* 58 */     for (ElementValue evalue : this.evalues) {
/* 59 */       evalue.dump(dos);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String stringifyValue() {
/* 65 */     StringBuilder sb = new StringBuilder();
/* 66 */     sb.append("[");
/* 67 */     for (int i = 0; i < this.evalues.length; i++) {
/* 68 */       ElementValue element = this.evalues[i];
/* 69 */       sb.append(element.stringifyValue());
/* 70 */       if (i + 1 < this.evalues.length)
/* 71 */         sb.append(","); 
/*    */     } 
/* 73 */     sb.append("]");
/* 74 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public void addElement(ElementValue gen) {
/* 78 */     ElementValue[] old = this.evalues;
/* 79 */     this.evalues = new ElementValue[this.evalues.length + 1];
/* 80 */     System.arraycopy(old, 0, this.evalues, 0, old.length);
/* 81 */     this.evalues[old.length] = gen;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\ArrayElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */