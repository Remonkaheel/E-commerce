/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantString
/*     */   extends Constant
/*     */ {
/*     */   private int stringIndex;
/*     */   
/*     */   ConstantString(DataInputStream file) throws IOException {
/*  76 */     this(file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public ConstantString(int stringIndex) {
/*  80 */     super((byte)8);
/*  81 */     this.stringIndex = stringIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  86 */     v.visitConstantString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  91 */     file.writeByte(this.tag);
/*  92 */     file.writeShort(this.stringIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getValue() {
/* 101 */     return Integer.valueOf(this.stringIndex);
/*     */   }
/*     */   
/*     */   public final int getStringIndex() {
/* 105 */     return this.stringIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 110 */     return super.toString() + "(string_index = " + this.stringIndex + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(ConstantPool cpool) {
/* 117 */     Constant c = cpool.getConstant(this.stringIndex, (byte)1);
/* 118 */     return ((ConstantUtf8)c).getValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */