/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeAnnotationGen
/*     */ {
/*  22 */   public static final TypeAnnotationGen[] NO_TYPE_ANNOTATIONS = new TypeAnnotationGen[0];
/*  23 */   public static final int[] NO_TYPE_PATH = new int[0];
/*     */   private ConstantPool cpool;
/*     */   private int targetType;
/*     */   
/*     */   private TypeAnnotationGen(ConstantPool cpool) {
/*  28 */     this.cpool = cpool;
/*     */   }
/*     */ 
/*     */   
/*     */   private int[] typePath;
/*     */   
/*     */   private AnnotationGen annotation;
/*     */   
/*     */   private int info;
/*     */   
/*     */   private int info2;
/*     */   
/*     */   private int[] localVarTarget;
/*     */   
/*     */   public static final int CLASS_TYPE_PARAMETER = 0;
/*     */   
/*     */   public static final int METHOD_TYPE_PARAMETER = 1;
/*     */   public static final int CLASS_EXTENDS = 16;
/*     */   public static final int CLASS_TYPE_PARAMETER_BOUND = 17;
/*     */   public static final int METHOD_TYPE_PARAMETER_BOUND = 18;
/*     */   public static final int FIELD = 19;
/*     */   public static final int METHOD_RETURN = 20;
/*     */   public static final int METHOD_RECEIVER = 21;
/*     */   public static final int METHOD_FORMAL_PARAMETER = 22;
/*     */   public static final int THROWS = 23;
/*     */   public static final int LOCAL_VARIABLE = 64;
/*     */   public static final int RESOURCE_VARIABLE = 65;
/*     */   public static final int EXCEPTION_PARAMETER = 66;
/*     */   public static final int INSTANCEOF = 67;
/*     */   public static final int NEW = 68;
/*     */   public static final int CONSTRUCTOR_REFERENCE = 69;
/*     */   public static final int METHOD_REFERENCE = 70;
/*     */   public static final int CAST = 71;
/*     */   public static final int CONSTRUCTOR_INVOCATION_TYPE_ARGUMENT = 72;
/*     */   public static final int METHOD_INVOCATION_TYPE_ARGUMENT = 73;
/*     */   public static final int CONSTRUCTOR_REFERENCE_TYPE_ARGUMENT = 74;
/*     */   public static final int METHOD_REFERENCE_TYPE_ARGUMENT = 75;
/*     */   public static final int TYPE_PATH_ENTRY_KIND_ARRAY = 0;
/*     */   public static final int TYPE_PATH_ENTRY_KIND_INNER_TYPE = 1;
/*     */   public static final int TYPE_PATH_ENTRY_KIND_WILDCARD = 2;
/*     */   public static final int TYPE_PATH_ENTRY_KIND_TYPE_ARGUMENT = 3;
/*     */   
/*     */   public static TypeAnnotationGen read(DataInputStream dis, ConstantPool cpool, boolean isVisible) throws IOException {
/*     */     int superTypeIndex;
/*  72 */     TypeAnnotationGen typeAnno = new TypeAnnotationGen(cpool);
/*  73 */     typeAnno.targetType = dis.readUnsignedByte();
/*     */     
/*  75 */     switch (typeAnno.targetType) {
/*     */       case 0:
/*  77 */         typeAnno.info = dis.readUnsignedByte();
/*     */         break;
/*     */       case 1:
/*  80 */         typeAnno.info = dis.readUnsignedByte();
/*     */         break;
/*     */       case 16:
/*  83 */         superTypeIndex = dis.readUnsignedShort();
/*  84 */         if (superTypeIndex == 65535) {
/*  85 */           typeAnno.info = -1; break;
/*     */         } 
/*  87 */         typeAnno.info = superTypeIndex;
/*     */         break;
/*     */       
/*     */       case 17:
/*     */       case 18:
/*  92 */         typeAnno.info = dis.readUnsignedByte();
/*  93 */         typeAnno.info2 = dis.readUnsignedByte();
/*     */         break;
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*     */         break;
/*     */       case 22:
/* 100 */         typeAnno.info = dis.readUnsignedByte();
/*     */         break;
/*     */       case 23:
/* 103 */         typeAnno.info = dis.readUnsignedShort();
/*     */         break;
/*     */       case 64:
/*     */       case 65:
/* 107 */         typeAnno.localVarTarget = readLocalVarTarget(dis);
/*     */         break;
/*     */       
/*     */       case 66:
/* 111 */         typeAnno.info = dis.readUnsignedByte();
/*     */         break;
/*     */       case 67:
/*     */       case 68:
/*     */       case 69:
/*     */       case 70:
/* 117 */         typeAnno.info = dis.readUnsignedShort();
/*     */         break;
/*     */       case 71:
/*     */       case 72:
/*     */       case 73:
/*     */       case 74:
/*     */       case 75:
/* 124 */         typeAnno.info = dis.readUnsignedShort();
/* 125 */         typeAnno.info2 = dis.readUnsignedByte();
/*     */         break;
/*     */       default:
/* 128 */         throw new IllegalStateException("nyi " + typeAnno.targetType);
/*     */     } 
/* 130 */     int typepathlength = dis.readUnsignedByte();
/* 131 */     if (typepathlength == 0) {
/* 132 */       typeAnno.typePath = NO_TYPE_PATH;
/*     */     } else {
/* 134 */       typeAnno.typePath = new int[typepathlength * 2];
/* 135 */       for (int i = 0, max = typepathlength * 2; i < max; i++) {
/* 136 */         typeAnno.typePath[i] = dis.readUnsignedByte();
/*     */       }
/*     */     } 
/* 139 */     typeAnno.annotation = AnnotationGen.read(dis, cpool, isVisible);
/* 140 */     return typeAnno;
/*     */   }
/*     */   
/*     */   public static int[] readLocalVarTarget(DataInputStream dis) throws IOException {
/* 144 */     int tableLength = dis.readUnsignedShort();
/* 145 */     int[] table = new int[tableLength * 3];
/* 146 */     int count = 0;
/* 147 */     for (int i = 0; i < tableLength; i++) {
/* 148 */       table[count++] = dis.readUnsignedShort();
/* 149 */       table[count++] = dis.readUnsignedShort();
/* 150 */       table[count++] = dis.readUnsignedShort();
/*     */     } 
/* 152 */     return table;
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream dos) throws IOException {
/* 156 */     dos.writeByte(this.targetType);
/* 157 */     switch (this.targetType) {
/*     */       case 0:
/* 159 */         dos.writeByte(this.info);
/*     */         break;
/*     */       case 1:
/* 162 */         dos.writeByte(this.info);
/*     */         break;
/*     */       case 16:
/* 165 */         dos.writeShort(this.info);
/*     */         break;
/*     */       case 17:
/*     */       case 18:
/* 169 */         dos.writeByte(this.info);
/* 170 */         dos.writeByte(this.info2);
/*     */         break;
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*     */         break;
/*     */       case 22:
/* 177 */         dos.writeByte(this.info);
/*     */         break;
/*     */       case 23:
/* 180 */         dos.writeShort(this.info);
/*     */         break;
/*     */       case 64:
/*     */       case 65:
/* 184 */         dos.writeShort(this.localVarTarget.length / 3);
/* 185 */         for (int j : this.localVarTarget) {
/* 186 */           dos.writeShort(j);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 66:
/* 191 */         dos.writeByte(this.info);
/*     */         break;
/*     */       case 67:
/*     */       case 68:
/*     */       case 69:
/*     */       case 70:
/* 197 */         dos.writeShort(this.info);
/*     */         break;
/*     */       case 71:
/*     */       case 72:
/*     */       case 73:
/*     */       case 74:
/*     */       case 75:
/* 204 */         dos.writeShort(this.info);
/* 205 */         dos.writeByte(this.info);
/*     */         break;
/*     */       default:
/* 208 */         throw new IllegalStateException("nyi " + this.targetType);
/*     */     } 
/* 210 */     dos.writeByte(this.typePath.length);
/* 211 */     for (int j : this.typePath) {
/* 212 */       dos.writeByte(j);
/*     */     }
/* 214 */     this.annotation.dump(dos);
/*     */   }
/*     */   
/*     */   public int getSupertypeIndex() {
/* 218 */     assert this.targetType == 16;
/* 219 */     return this.info;
/*     */   }
/*     */   
/*     */   public int getOffset() {
/* 223 */     assert this.targetType == 67 || this.targetType == 68 || this.targetType == 69 || this.targetType == 70 || this.targetType == 71 || this.targetType == 72 || this.targetType == 73 || this.targetType == 74 || this.targetType == 75;
/*     */ 
/*     */ 
/*     */     
/* 227 */     return this.info;
/*     */   }
/*     */   
/*     */   public int getTypeParameterIndex() {
/* 231 */     assert this.targetType == 0 || this.targetType == 1 || this.targetType == 17 || this.targetType == 18;
/*     */     
/* 233 */     return this.info;
/*     */   }
/*     */   
/*     */   public int getTypeArgumentIndex() {
/* 237 */     assert this.targetType == 71 || this.targetType == 72 || this.targetType == 73 || this.targetType == 74 || this.targetType == 75;
/*     */     
/* 239 */     return this.info2;
/*     */   }
/*     */   
/*     */   public int getBoundIndex() {
/* 243 */     assert this.targetType == 17 || this.targetType == 18;
/* 244 */     return this.info2;
/*     */   }
/*     */   
/*     */   public int getMethodFormalParameterIndex() {
/* 248 */     assert this.targetType == 22;
/* 249 */     return this.info;
/*     */   }
/*     */   
/*     */   public int getThrowsTypeIndex() {
/* 253 */     assert this.targetType == 23;
/* 254 */     return this.info;
/*     */   }
/*     */   
/*     */   public int[] getLocalVarTarget() {
/* 258 */     assert this.targetType == 64 || this.targetType == 65;
/* 259 */     return this.localVarTarget;
/*     */   }
/*     */   
/*     */   public int getExceptionTableIndex() {
/* 263 */     assert this.targetType == 66;
/* 264 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTargetType() {
/* 270 */     return this.targetType;
/*     */   }
/*     */   
/*     */   public AnnotationGen getAnnotation() {
/* 274 */     return this.annotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getTypePath() {
/* 370 */     return this.typePath;
/*     */   }
/*     */   
/*     */   public String getTypePathString() {
/* 374 */     return toTypePathString(this.typePath);
/*     */   }
/*     */   
/*     */   public static String toTypePathString(int[] typepath) {
/* 378 */     StringBuilder sb = new StringBuilder();
/* 379 */     int count = 0;
/* 380 */     sb.append("[");
/* 381 */     while (count < typepath.length) {
/* 382 */       if (count > 0) sb.append(","); 
/* 383 */       switch (typepath[count++]) {
/*     */         case 0:
/* 385 */           sb.append("ARRAY");
/* 386 */           count++;
/*     */         
/*     */         case 1:
/* 389 */           sb.append("INNER_TYPE");
/* 390 */           count++;
/*     */         
/*     */         case 2:
/* 393 */           sb.append("WILDCARD");
/* 394 */           count++;
/*     */         
/*     */         case 3:
/* 397 */           sb.append("TYPE_ARGUMENT(").append(typepath[count++]).append(")");
/*     */       } 
/*     */     
/*     */     } 
/* 401 */     sb.append("]");
/* 402 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\TypeAnnotationGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */