/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LineNumberTable
/*     */   extends Attribute
/*     */ {
/*     */   private boolean isInPackedState = false;
/*     */   private byte[] data;
/*     */   private int tableLength;
/*     */   private LineNumber[] table;
/*     */   
/*     */   public LineNumberTable(LineNumberTable c) {
/*  86 */     this(c.getNameIndex(), c.getLength(), c.getLineNumberTable(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public LineNumberTable(int nameIndex, int length, LineNumber[] lineNumberTable, ConstantPool constantPool) {
/*  90 */     super((byte)4, nameIndex, length, constantPool);
/*  91 */     setLineNumberTable(lineNumberTable);
/*  92 */     this.isInPackedState = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LineNumberTable(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 105 */     this(name_index, length, (LineNumber[])null, constant_pool);
/* 106 */     this.data = new byte[length];
/* 107 */     file.readFully(this.data);
/* 108 */     this.isInPackedState = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void unpack() {
/* 114 */     if (this.isInPackedState) {
/*     */       try {
/* 116 */         ByteArrayInputStream bs = new ByteArrayInputStream(this.data);
/* 117 */         DataInputStream dis = new DataInputStream(bs);
/* 118 */         this.tableLength = dis.readUnsignedShort();
/* 119 */         this.table = new LineNumber[this.tableLength];
/* 120 */         for (int i = 0; i < this.tableLength; i++) {
/* 121 */           this.table[i] = new LineNumber(dis);
/*     */         }
/* 123 */         dis.close();
/* 124 */         this.data = null;
/* 125 */       } catch (IOException e) {
/* 126 */         throw new RuntimeException("Unpacking of LineNumberTable attribute failed");
/*     */       } 
/* 128 */       this.isInPackedState = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 140 */     unpack();
/* 141 */     v.visitLineNumberTable(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 152 */     super.dump(file);
/* 153 */     if (this.isInPackedState) {
/* 154 */       file.write(this.data);
/*     */     } else {
/* 156 */       file.writeShort(this.tableLength);
/* 157 */       for (int i = 0; i < this.tableLength; i++) {
/* 158 */         this.table[i].dump(file);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LineNumber[] getLineNumberTable() {
/* 167 */     unpack();
/* 168 */     return this.table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLineNumberTable(LineNumber[] line_number_table) {
/* 175 */     this.data = null;
/* 176 */     this.isInPackedState = false;
/* 177 */     this.table = line_number_table;
/* 178 */     this.tableLength = (line_number_table == null) ? 0 : line_number_table.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 186 */     unpack();
/* 187 */     StringBuilder buf = new StringBuilder();
/* 188 */     StringBuilder line = new StringBuilder();
/*     */     
/* 190 */     for (int i = 0; i < this.tableLength; i++) {
/* 191 */       line.append(this.table[i].toString());
/*     */       
/* 193 */       if (i < this.tableLength - 1) {
/* 194 */         line.append(", ");
/*     */       }
/*     */       
/* 197 */       if (line.length() > 72) {
/* 198 */         line.append('\n');
/* 199 */         buf.append(line);
/* 200 */         line.setLength(0);
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     buf.append(line);
/*     */     
/* 206 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSourceLine(int pos) {
/* 216 */     unpack();
/* 217 */     int l = 0, r = this.tableLength - 1;
/*     */     
/* 219 */     if (r < 0) {
/* 220 */       return -1;
/*     */     }
/* 222 */     int min_index = -1, min = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 228 */       int i = (l + r) / 2;
/* 229 */       int j = this.table[i].getStartPC();
/*     */       
/* 231 */       if (j == pos)
/* 232 */         return this.table[i].getLineNumber(); 
/* 233 */       if (pos < j) {
/* 234 */         r = i - 1;
/*     */       } else {
/*     */         
/* 237 */         l = i + 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 243 */       if (j >= pos || j <= min)
/* 244 */         continue;  min = j;
/* 245 */       min_index = i;
/*     */     }
/* 247 */     while (l <= r);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     if (min_index < 0) {
/* 253 */       return -1;
/*     */     }
/* 255 */     return this.table[min_index].getLineNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTableLength() {
/* 273 */     unpack();
/* 274 */     return this.tableLength;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\LineNumberTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */