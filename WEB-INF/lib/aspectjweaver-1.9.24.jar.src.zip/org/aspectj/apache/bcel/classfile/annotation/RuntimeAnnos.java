/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.aspectj.apache.bcel.classfile.Attribute;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RuntimeAnnos
/*    */   extends Attribute
/*    */ {
/*    */   private List<AnnotationGen> annotations;
/*    */   private boolean visible;
/*    */   private boolean inflated = false;
/*    */   private byte[] annotation_data;
/*    */   
/*    */   public RuntimeAnnos(byte attrid, boolean visible, int nameIdx, int len, ConstantPool cpool) {
/* 34 */     super(attrid, nameIdx, len, cpool);
/* 35 */     this.visible = visible;
/* 36 */     this.annotations = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public RuntimeAnnos(byte attrid, boolean visible, int nameIdx, int len, byte[] data, ConstantPool cpool) {
/* 40 */     super(attrid, nameIdx, len, cpool);
/* 41 */     this.visible = visible;
/* 42 */     this.annotations = new ArrayList<>();
/* 43 */     this.annotation_data = data;
/*    */   }
/*    */   
/*    */   public List<AnnotationGen> getAnnotations() {
/* 47 */     if (!this.inflated)
/* 48 */       inflate(); 
/* 49 */     return this.annotations;
/*    */   }
/*    */   
/*    */   public boolean areVisible() {
/* 53 */     return this.visible;
/*    */   }
/*    */   
/*    */   protected void readAnnotations(DataInputStream dis, ConstantPool cpool) throws IOException {
/* 57 */     this.annotation_data = new byte[this.length];
/* 58 */     dis.readFully(this.annotation_data, 0, this.length);
/*    */   }
/*    */   
/*    */   protected void writeAnnotations(DataOutputStream dos) throws IOException {
/* 62 */     if (!this.inflated) {
/* 63 */       dos.write(this.annotation_data, 0, this.length);
/*    */     } else {
/* 65 */       dos.writeShort(this.annotations.size());
/* 66 */       for (AnnotationGen ann : this.annotations) {
/* 67 */         ann.dump(dos);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void inflate() {
/*    */     try {
/* 75 */       DataInputStream dis = new DataInputStream(new ByteArrayInputStream(this.annotation_data));
/* 76 */       int numberOfAnnotations = dis.readUnsignedShort();
/* 77 */       if (numberOfAnnotations > 0) {
/* 78 */         List<AnnotationGen> inflatedAnnotations = new ArrayList<>();
/* 79 */         for (int i = 0; i < numberOfAnnotations; i++) {
/* 80 */           inflatedAnnotations.add(AnnotationGen.read(dis, getConstantPool(), this.visible));
/*    */         }
/* 82 */         this.annotations = inflatedAnnotations;
/*    */       } 
/* 84 */       dis.close();
/* 85 */       this.inflated = true;
/* 86 */     } catch (IOException ioe) {
/* 87 */       throw new RuntimeException("Unabled to inflate annotation data, badly formed? ");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInflated() {
/* 93 */     return this.inflated;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */