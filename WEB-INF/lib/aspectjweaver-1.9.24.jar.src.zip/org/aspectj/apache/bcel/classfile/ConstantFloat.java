/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantFloat
/*     */   extends Constant
/*     */   implements SimpleConstant
/*     */ {
/*     */   private float floatValue;
/*     */   
/*     */   public ConstantFloat(float floatValue) {
/*  75 */     super((byte)4);
/*  76 */     this.floatValue = floatValue;
/*     */   }
/*     */   
/*     */   ConstantFloat(DataInputStream file) throws IOException {
/*  80 */     this(file.readFloat());
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  85 */     v.visitConstantFloat(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  90 */     file.writeByte(this.tag);
/*  91 */     file.writeFloat(this.floatValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Float getValue() {
/*  96 */     return Float.valueOf(this.floatValue);
/*     */   }
/*     */   
/*     */   public final String getStringValue() {
/* 100 */     return Float.toString(this.floatValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 105 */     return super.toString() + "(bytes = " + this.floatValue + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */