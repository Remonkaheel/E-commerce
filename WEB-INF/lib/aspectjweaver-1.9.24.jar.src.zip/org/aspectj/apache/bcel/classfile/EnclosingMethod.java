/*    */ package org.aspectj.apache.bcel.classfile;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnclosingMethod
/*    */   extends Attribute
/*    */ {
/*    */   private int classIndex;
/*    */   private int methodIndex;
/*    */   
/*    */   public EnclosingMethod(int nameIndex, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 43 */     this(nameIndex, len, dis.readUnsignedShort(), dis.readUnsignedShort(), cpool);
/*    */   }
/*    */   
/*    */   private EnclosingMethod(int nameIndex, int len, int classIdx, int methodIdx, ConstantPool cpool) {
/* 47 */     super((byte)17, nameIndex, len, cpool);
/* 48 */     this.classIndex = classIdx;
/* 49 */     this.methodIndex = methodIdx;
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 53 */     v.visitEnclosingMethod(this);
/*    */   }
/*    */   
/*    */   public Attribute copy(ConstantPool constant_pool) {
/* 57 */     throw new RuntimeException("Not implemented yet!");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getEnclosingClassIndex() {
/* 63 */     return this.classIndex; } public final int getEnclosingMethodIndex() {
/* 64 */     return this.methodIndex;
/*    */   }
/* 66 */   public final void setEnclosingClassIndex(int idx) { this.classIndex = idx; } public final void setEnclosingMethodIndex(int idx) {
/* 67 */     this.methodIndex = idx;
/*    */   }
/*    */   
/*    */   public final ConstantClass getEnclosingClass() {
/* 71 */     ConstantClass c = (ConstantClass)this.cpool.getConstant(this.classIndex, (byte)7);
/* 72 */     return c;
/*    */   }
/*    */   
/*    */   public final ConstantNameAndType getEnclosingMethod() {
/* 76 */     if (this.methodIndex == 0) return null;
/*    */     
/* 78 */     ConstantNameAndType nat = (ConstantNameAndType)this.cpool.getConstant(this.methodIndex, (byte)12);
/* 79 */     return nat;
/*    */   }
/*    */   
/*    */   public final void dump(DataOutputStream file) throws IOException {
/* 83 */     super.dump(file);
/* 84 */     file.writeShort(this.classIndex);
/* 85 */     file.writeShort(this.methodIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\EnclosingMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */