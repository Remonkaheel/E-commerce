/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Modifiers
/*     */ {
/*     */   protected int modifiers;
/*     */   
/*     */   public Modifiers() {}
/*     */   
/*     */   public Modifiers(int a) {
/*  74 */     this.modifiers = a;
/*     */   }
/*     */   
/*     */   public final int getModifiers() {
/*  78 */     return this.modifiers;
/*     */   }
/*     */   
/*     */   public final void setModifiers(int modifiers) {
/*  82 */     this.modifiers = modifiers;
/*     */   }
/*     */   
/*     */   public final boolean isPublic() {
/*  86 */     return ((this.modifiers & 0x1) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isPrivate() {
/*  90 */     return ((this.modifiers & 0x2) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isProtected() {
/*  94 */     return ((this.modifiers & 0x4) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isStatic() {
/*  98 */     return ((this.modifiers & 0x8) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isFinal() {
/* 102 */     return ((this.modifiers & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isSynchronized() {
/* 106 */     return ((this.modifiers & 0x20) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isVolatile() {
/* 110 */     return ((this.modifiers & 0x40) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isTransient() {
/* 114 */     return ((this.modifiers & 0x80) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isNative() {
/* 118 */     return ((this.modifiers & 0x100) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isInterface() {
/* 122 */     return ((this.modifiers & 0x200) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isAbstract() {
/* 126 */     return ((this.modifiers & 0x400) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isStrictfp() {
/* 130 */     return ((this.modifiers & 0x800) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isVarargs() {
/* 134 */     return ((this.modifiers & 0x80) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isBridge() {
/* 138 */     return ((this.modifiers & 0x40) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Modifiers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */