/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantInvokeDynamic
/*     */   extends Constant
/*     */ {
/*     */   private final int bootstrapMethodAttrIndex;
/*     */   private final int nameAndTypeIndex;
/*     */   
/*     */   ConstantInvokeDynamic(DataInputStream file) throws IOException {
/*  77 */     this(file.readUnsignedShort(), file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public ConstantInvokeDynamic(int readUnsignedShort, int nameAndTypeIndex) {
/*  81 */     super((byte)18);
/*  82 */     this.bootstrapMethodAttrIndex = readUnsignedShort;
/*  83 */     this.nameAndTypeIndex = nameAndTypeIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  88 */     file.writeByte(this.tag);
/*  89 */     file.writeShort(this.bootstrapMethodAttrIndex);
/*  90 */     file.writeShort(this.nameAndTypeIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNameAndTypeIndex() {
/* 110 */     return this.nameAndTypeIndex;
/*     */   }
/*     */   
/*     */   public final int getBootstrapMethodAttrIndex() {
/* 114 */     return this.bootstrapMethodAttrIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 119 */     return super.toString() + "(bootstrapMethodAttrIndex=" + this.bootstrapMethodAttrIndex + ",nameAndTypeIndex=" + this.nameAndTypeIndex + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 124 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 129 */     v.visitConstantInvokeDynamic(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantInvokeDynamic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */