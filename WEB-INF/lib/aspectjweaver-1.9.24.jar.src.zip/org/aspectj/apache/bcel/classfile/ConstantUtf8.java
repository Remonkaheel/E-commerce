/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantUtf8
/*     */   extends Constant
/*     */   implements SimpleConstant
/*     */ {
/*     */   private String string;
/*     */   
/*     */   ConstantUtf8(DataInputStream file) throws IOException {
/*  75 */     super((byte)1);
/*  76 */     this.string = file.readUTF();
/*     */   }
/*     */   
/*     */   public ConstantUtf8(String string) {
/*  80 */     super((byte)1);
/*  81 */     assert string != null;
/*  82 */     this.string = string;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  87 */     v.visitConstantUtf8(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  92 */     file.writeByte(this.tag);
/*  93 */     file.writeUTF(this.string);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  98 */     return super.toString() + "(\"" + Utility.replace(this.string, "\n", "\\n") + "\")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 103 */     return this.string;
/*     */   }
/*     */   
/*     */   public String getStringValue() {
/* 107 */     return this.string;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantUtf8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */