/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NestMembers
/*     */   extends Attribute
/*     */ {
/*     */   private int numberOfClasses;
/*     */   private int[] classes;
/*     */   
/*     */   public NestMembers(NestMembers c) {
/*  73 */     this(c.getNameIndex(), c.getLength(), c.getClasses(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public NestMembers(int nameIndex, int length, int[] classes, ConstantPool cp) {
/*  77 */     super((byte)27, nameIndex, length, cp);
/*  78 */     setClasses(classes);
/*     */   }
/*     */   
/*     */   NestMembers(int nameIndex, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  82 */     this(nameIndex, length, (int[])null, constant_pool);
/*  83 */     this.numberOfClasses = file.readUnsignedShort();
/*  84 */     this.classes = new int[this.numberOfClasses];
/*  85 */     for (int i = 0; i < this.numberOfClasses; i++) {
/*  86 */       this.classes[i] = file.readUnsignedShort();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  92 */     v.visitNestMembers(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  97 */     super.dump(file);
/*  98 */     file.writeShort(this.numberOfClasses);
/*  99 */     for (int i = 0; i < this.numberOfClasses; i++) {
/* 100 */       file.writeShort(this.classes[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public final int[] getClasses() {
/* 105 */     return this.classes;
/*     */   }
/*     */   
/*     */   public final void setClasses(int[] inner_classes) {
/* 109 */     this.classes = inner_classes;
/* 110 */     this.numberOfClasses = (inner_classes == null) ? 0 : inner_classes.length;
/*     */   }
/*     */   
/*     */   public final String[] getClassesNames() {
/* 114 */     String[] result = new String[this.numberOfClasses];
/* 115 */     for (int i = 0; i < this.numberOfClasses; i++) {
/* 116 */       ConstantClass constantClass = (ConstantClass)this.cpool.getConstant(this.classes[i], (byte)7);
/* 117 */       result[i] = constantClass.getClassname(this.cpool);
/*     */     } 
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 124 */     StringBuilder buf = new StringBuilder();
/* 125 */     for (int i = 0; i < this.numberOfClasses; i++) {
/* 126 */       ConstantClass constantClass = (ConstantClass)this.cpool.getConstant(this.classes[i], (byte)7);
/* 127 */       buf.append(constantClass.getClassname(this.cpool)).append(" ");
/*     */     } 
/* 129 */     return "NestMembers(" + buf.toString().trim() + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\NestMembers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */