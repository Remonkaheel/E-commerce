/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeAnnos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldOrMethod
/*     */   extends Modifiers
/*     */   implements Node
/*     */ {
/*     */   protected int nameIndex;
/*     */   protected int signatureIndex;
/*     */   protected Attribute[] attributes;
/*     */   protected ConstantPool cpool;
/*     */   private String name;
/*     */   private String signature;
/*     */   private AnnotationGen[] annotations;
/*  81 */   private String signatureAttributeString = null;
/*     */ 
/*     */   
/*     */   private boolean searchedForSignatureAttribute = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldOrMethod() {}
/*     */ 
/*     */   
/*     */   protected FieldOrMethod(FieldOrMethod c) {
/*  92 */     this(c.getModifiers(), c.getNameIndex(), c.getSignatureIndex(), c.getAttributes(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   protected FieldOrMethod(DataInputStream file, ConstantPool cpool) throws IOException {
/*  96 */     this(file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), (Attribute[])null, cpool);
/*  97 */     this.attributes = AttributeUtils.readAttributes(file, cpool);
/*     */   }
/*     */   
/*     */   protected FieldOrMethod(int accessFlags, int nameIndex, int signatureIndex, Attribute[] attributes, ConstantPool cpool) {
/* 101 */     this.modifiers = accessFlags;
/* 102 */     this.nameIndex = nameIndex;
/* 103 */     this.signatureIndex = signatureIndex;
/* 104 */     this.cpool = cpool;
/* 105 */     this.attributes = attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Attribute[] attributes) {
/* 112 */     this.attributes = attributes;
/*     */   }
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 116 */     file.writeShort(this.modifiers);
/* 117 */     file.writeShort(this.nameIndex);
/* 118 */     file.writeShort(this.signatureIndex);
/* 119 */     AttributeUtils.writeAttributes(this.attributes, file);
/*     */   }
/*     */   
/*     */   public final Attribute[] getAttributes() {
/* 123 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public final ConstantPool getConstantPool() {
/* 127 */     return this.cpool;
/*     */   }
/*     */   
/*     */   public final int getNameIndex() {
/* 131 */     return this.nameIndex;
/*     */   }
/*     */   
/*     */   public final int getSignatureIndex() {
/* 135 */     return this.signatureIndex;
/*     */   }
/*     */   
/*     */   public final String getName() {
/* 139 */     if (this.name == null) {
/* 140 */       ConstantUtf8 c = (ConstantUtf8)this.cpool.getConstant(this.nameIndex, (byte)1);
/* 141 */       this.name = c.getValue();
/*     */     } 
/* 143 */     return this.name;
/*     */   }
/*     */   
/*     */   public final String getSignature() {
/* 147 */     if (this.signature == null) {
/* 148 */       ConstantUtf8 c = (ConstantUtf8)this.cpool.getConstant(this.signatureIndex, (byte)1);
/* 149 */       this.signature = c.getValue();
/*     */     } 
/* 151 */     return this.signature;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getDeclaredSignature() {
/* 159 */     if (getGenericSignature() != null)
/* 160 */       return getGenericSignature(); 
/* 161 */     return getSignature();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationGen[] getAnnotations() {
/* 168 */     if (this.annotations == null) {
/*     */       
/* 170 */       List<AnnotationGen> accumulatedAnnotations = new ArrayList<>();
/* 171 */       for (Attribute attribute : this.attributes) {
/* 172 */         if (attribute instanceof RuntimeAnnos) {
/* 173 */           RuntimeAnnos runtimeAnnotations = (RuntimeAnnos)attribute;
/* 174 */           accumulatedAnnotations.addAll(runtimeAnnotations.getAnnotations());
/*     */         } 
/*     */       } 
/* 177 */       if (accumulatedAnnotations.size() == 0) {
/* 178 */         this.annotations = AnnotationGen.NO_ANNOTATIONS;
/*     */       } else {
/* 180 */         this.annotations = accumulatedAnnotations.<AnnotationGen>toArray(AnnotationGen.NO_ANNOTATIONS);
/*     */       } 
/*     */     } 
/* 183 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getGenericSignature() {
/* 192 */     if (!this.searchedForSignatureAttribute) {
/* 193 */       Signature sig = AttributeUtils.getSignatureAttribute(this.attributes);
/* 194 */       this.signatureAttributeString = (sig == null) ? null : sig.getSignature();
/* 195 */       this.searchedForSignatureAttribute = true;
/*     */     } 
/* 197 */     return this.signatureAttributeString;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\FieldOrMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */