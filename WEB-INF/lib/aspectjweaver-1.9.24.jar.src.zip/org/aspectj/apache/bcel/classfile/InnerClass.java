/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InnerClass
/*     */   implements Cloneable, Node
/*     */ {
/*     */   private int inner_class_index;
/*     */   private int outer_class_index;
/*     */   private int inner_name_index;
/*     */   private int inner_access_flags;
/*     */   
/*     */   public InnerClass(InnerClass c) {
/*  81 */     this(c.getInnerClassIndex(), c.getOuterClassIndex(), c.getInnerNameIndex(), c.getInnerAccessFlags());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InnerClass(DataInputStream file) throws IOException {
/*  91 */     this(file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InnerClass(int inner_class_index, int outer_class_index, int inner_name_index, int inner_access_flags) {
/* 101 */     this.inner_class_index = inner_class_index;
/* 102 */     this.outer_class_index = outer_class_index;
/* 103 */     this.inner_name_index = inner_name_index;
/* 104 */     this.inner_access_flags = inner_access_flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 114 */     v.visitInnerClass(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 124 */     file.writeShort(this.inner_class_index);
/* 125 */     file.writeShort(this.outer_class_index);
/* 126 */     file.writeShort(this.inner_name_index);
/* 127 */     file.writeShort(this.inner_access_flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getInnerAccessFlags() {
/* 134 */     return this.inner_access_flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getInnerClassIndex() {
/* 141 */     return this.inner_class_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getInnerNameIndex() {
/* 148 */     return this.inner_name_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOuterClassIndex() {
/* 155 */     return this.outer_class_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInnerAccessFlags(int inner_access_flags) {
/* 162 */     this.inner_access_flags = inner_access_flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInnerClassIndex(int inner_class_index) {
/* 169 */     this.inner_class_index = inner_class_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInnerNameIndex(int inner_name_index) {
/* 176 */     this.inner_name_index = inner_name_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOuterClassIndex(int outer_class_index) {
/* 183 */     this.outer_class_index = outer_class_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 191 */     return "InnerClass(" + this.inner_class_index + ", " + this.outer_class_index + ", " + this.inner_name_index + ", " + this.inner_access_flags + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(ConstantPool constant_pool) {
/* 201 */     String outer_class_name, inner_name, inner_class_name = constant_pool.getConstantString(this.inner_class_index, (byte)7);
/* 202 */     inner_class_name = Utility.compactClassName(inner_class_name);
/*     */     
/* 204 */     if (this.outer_class_index != 0) {
/* 205 */       outer_class_name = constant_pool.getConstantString(this.outer_class_index, (byte)7);
/* 206 */       outer_class_name = Utility.compactClassName(outer_class_name);
/*     */     } else {
/* 208 */       outer_class_name = "<not a member>";
/*     */     } 
/* 210 */     if (this.inner_name_index != 0) {
/* 211 */       inner_name = ((ConstantUtf8)constant_pool.getConstant(this.inner_name_index, (byte)1)).getValue();
/*     */     } else {
/* 213 */       inner_name = "<anonymous>";
/*     */     } 
/* 215 */     String access = Utility.accessToString(this.inner_access_flags, true);
/* 216 */     access = access.equals("") ? "" : (access + " ");
/*     */     
/* 218 */     return "InnerClass:" + access + inner_class_name + "(\"" + outer_class_name + "\", \"" + inner_name + "\")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InnerClass copy() {
/*     */     try {
/* 226 */       return (InnerClass)clone();
/* 227 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */ 
/*     */       
/* 230 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\InnerClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */