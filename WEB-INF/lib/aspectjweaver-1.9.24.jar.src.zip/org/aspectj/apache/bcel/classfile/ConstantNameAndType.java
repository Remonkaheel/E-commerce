/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantNameAndType
/*     */   extends Constant
/*     */ {
/*     */   private int name_index;
/*     */   private int signature_index;
/*     */   
/*     */   ConstantNameAndType(DataInputStream file) throws IOException {
/*  82 */     this(file.readUnsignedShort(), file.readUnsignedShort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantNameAndType(int name_index, int signature_index) {
/*  90 */     super((byte)12);
/*  91 */     this.name_index = name_index;
/*  92 */     this.signature_index = signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 103 */     v.visitConstantNameAndType(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 114 */     file.writeByte(this.tag);
/* 115 */     file.writeShort(this.name_index);
/* 116 */     file.writeShort(this.signature_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNameIndex() {
/* 123 */     return this.name_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName(ConstantPool cp) {
/* 130 */     return cp.constantToString(getNameIndex(), (byte)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getSignatureIndex() {
/* 137 */     return this.signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSignature(ConstantPool cp) {
/* 144 */     return cp.constantToString(getSignatureIndex(), (byte)1);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 149 */     return super.toString() + "(name_index = " + this.name_index + ", signature_index = " + this.signature_index + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 154 */     return toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantNameAndType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */