/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CodeException
/*     */   implements Cloneable, Constants, Node, Serializable
/*     */ {
/*     */   private int start_pc;
/*     */   private int end_pc;
/*     */   private int handler_pc;
/*     */   private int catch_type;
/*     */   
/*     */   public CodeException(CodeException c) {
/*  85 */     this(c.getStartPC(), c.getEndPC(), c.getHandlerPC(), c.getCatchType());
/*     */   }
/*     */   
/*     */   CodeException(DataInputStream file) throws IOException {
/*  89 */     this.start_pc = file.readUnsignedShort();
/*  90 */     this.end_pc = file.readUnsignedShort();
/*  91 */     this.handler_pc = file.readUnsignedShort();
/*  92 */     this.catch_type = file.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public CodeException(int start_pc, int end_pc, int handler_pc, int catch_type) {
/*  96 */     this.start_pc = start_pc;
/*  97 */     this.end_pc = end_pc;
/*  98 */     this.handler_pc = handler_pc;
/*  99 */     this.catch_type = catch_type;
/*     */   }
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 103 */     v.visitCodeException(this);
/*     */   }
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 107 */     file.writeShort(this.start_pc);
/* 108 */     file.writeShort(this.end_pc);
/* 109 */     file.writeShort(this.handler_pc);
/* 110 */     file.writeShort(this.catch_type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getCatchType() {
/* 117 */     return this.catch_type;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getEndPC() {
/* 122 */     return this.end_pc;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getHandlerPC() {
/* 127 */     return this.handler_pc;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getStartPC() {
/* 132 */     return this.start_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCatchType(int catch_type) {
/* 138 */     this.catch_type = catch_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setEndPC(int end_pc) {
/* 145 */     this.end_pc = end_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHandlerPC(int handler_pc) {
/* 152 */     this.handler_pc = handler_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setStartPC(int start_pc) {
/* 159 */     this.start_pc = start_pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 166 */     return "CodeException(start_pc = " + this.start_pc + ", end_pc = " + this.end_pc + ", handler_pc = " + this.handler_pc + ", catch_type = " + this.catch_type + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(ConstantPool cp, boolean verbose) {
/*     */     String str;
/* 177 */     if (this.catch_type == 0) {
/* 178 */       str = "<Any exception>(0)";
/*     */     } else {
/*     */       
/* 181 */       str = Utility.compactClassName(cp.getConstantString(this.catch_type, (byte)7), false) + (verbose ? ("(" + this.catch_type + ")") : "");
/*     */     } 
/* 183 */     return this.start_pc + "\t" + this.end_pc + "\t" + this.handler_pc + "\t" + str;
/*     */   }
/*     */   
/*     */   public final String toString(ConstantPool cp) {
/* 187 */     return toString(cp, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeException copy() {
/*     */     try {
/* 195 */       return (CodeException)clone();
/* 196 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 198 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\CodeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */