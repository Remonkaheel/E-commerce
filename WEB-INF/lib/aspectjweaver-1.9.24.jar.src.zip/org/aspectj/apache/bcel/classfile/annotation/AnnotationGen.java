/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*     */ import org.aspectj.apache.bcel.classfile.Utility;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationGen
/*     */ {
/*  28 */   public static final AnnotationGen[] NO_ANNOTATIONS = new AnnotationGen[0];
/*     */   
/*     */   private int typeIndex;
/*  31 */   private List<NameValuePair> pairs = Collections.emptyList();
/*     */   private ConstantPool cpool;
/*     */   private boolean isRuntimeVisible = false;
/*     */   
/*     */   public AnnotationGen(AnnotationGen a, ConstantPool cpool, boolean copyPoolEntries) {
/*  36 */     this.cpool = cpool;
/*  37 */     if (copyPoolEntries) {
/*  38 */       this.typeIndex = cpool.addUtf8(a.getTypeSignature());
/*     */     } else {
/*  40 */       this.typeIndex = a.getTypeIndex();
/*     */     } 
/*  42 */     this.isRuntimeVisible = a.isRuntimeVisible();
/*  43 */     this.pairs = copyValues(a.getValues(), cpool, copyPoolEntries);
/*     */   }
/*     */   
/*     */   private List<NameValuePair> copyValues(List<NameValuePair> in, ConstantPool cpool, boolean copyPoolEntries) {
/*  47 */     List<NameValuePair> out = new ArrayList<>();
/*  48 */     for (NameValuePair nvp : in) {
/*  49 */       out.add(new NameValuePair(nvp, cpool, copyPoolEntries));
/*     */     }
/*  51 */     return out;
/*     */   }
/*     */   
/*     */   private AnnotationGen(ConstantPool cpool) {
/*  55 */     this.cpool = cpool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationGen(ObjectType type, List<NameValuePair> pairs, boolean runtimeVisible, ConstantPool cpool) {
/*  62 */     this.cpool = cpool;
/*  63 */     if (type != null) {
/*  64 */       this.typeIndex = cpool.addUtf8(type.getSignature());
/*     */     }
/*  66 */     this.pairs = pairs;
/*  67 */     this.isRuntimeVisible = runtimeVisible;
/*     */   }
/*     */   
/*     */   public static AnnotationGen read(DataInputStream dis, ConstantPool cpool, boolean b) throws IOException {
/*  71 */     AnnotationGen a = new AnnotationGen(cpool);
/*  72 */     a.typeIndex = dis.readUnsignedShort();
/*  73 */     int elemValuePairCount = dis.readUnsignedShort();
/*  74 */     for (int i = 0; i < elemValuePairCount; i++) {
/*  75 */       int nidx = dis.readUnsignedShort();
/*  76 */       a.addElementNameValuePair(new NameValuePair(nidx, ElementValue.readElementValue(dis, cpool), cpool));
/*     */     } 
/*  78 */     a.isRuntimeVisible(b);
/*  79 */     return a;
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream dos) throws IOException {
/*  83 */     dos.writeShort(this.typeIndex);
/*  84 */     dos.writeShort(this.pairs.size());
/*  85 */     for (NameValuePair envp : this.pairs) {
/*  86 */       envp.dump(dos);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addElementNameValuePair(NameValuePair evp) {
/*  91 */     if (this.pairs == Collections.EMPTY_LIST) {
/*  92 */       this.pairs = new ArrayList<>();
/*     */     }
/*  94 */     this.pairs.add(evp);
/*     */   }
/*     */   
/*     */   public int getTypeIndex() {
/*  98 */     return this.typeIndex;
/*     */   }
/*     */   
/*     */   public String getTypeSignature() {
/* 102 */     ConstantUtf8 utf8 = (ConstantUtf8)this.cpool.getConstant(this.typeIndex);
/* 103 */     return utf8.getValue();
/*     */   }
/*     */   
/*     */   public String getTypeName() {
/* 107 */     return Utility.signatureToString(getTypeSignature());
/*     */   }
/*     */   
/*     */   public List<NameValuePair> getValues() {
/* 111 */     return this.pairs;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 116 */     StringBuilder s = new StringBuilder();
/* 117 */     s.append("AnnotationGen:[" + getTypeName() + " #" + this.pairs.size() + " {");
/* 118 */     for (int i = 0; i < this.pairs.size(); i++) {
/* 119 */       s.append(this.pairs.get(i));
/* 120 */       if (i + 1 < this.pairs.size())
/* 121 */         s.append(","); 
/*     */     } 
/* 123 */     s.append("}]");
/* 124 */     return s.toString();
/*     */   }
/*     */   
/*     */   public String toShortString() {
/* 128 */     StringBuilder s = new StringBuilder();
/* 129 */     s.append("@").append(getTypeName());
/* 130 */     if (this.pairs.size() != 0) {
/* 131 */       s.append("(");
/* 132 */       for (int i = 0; i < this.pairs.size(); i++) {
/* 133 */         s.append(this.pairs.get(i));
/* 134 */         if (i + 1 < this.pairs.size())
/* 135 */           s.append(","); 
/*     */       } 
/* 137 */       s.append(")");
/*     */     } 
/* 139 */     return s.toString();
/*     */   }
/*     */   
/*     */   private void isRuntimeVisible(boolean b) {
/* 143 */     this.isRuntimeVisible = b;
/*     */   }
/*     */   
/*     */   public boolean isRuntimeVisible() {
/* 147 */     return this.isRuntimeVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNameValuePair(String name, String value) {
/* 154 */     for (NameValuePair pair : this.pairs) {
/* 155 */       if (pair.getNameString().equals(name) && 
/* 156 */         pair.getValue().stringifyValue().equals(value)) {
/* 157 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNamedValue(String name) {
/* 168 */     for (NameValuePair pair : this.pairs) {
/* 169 */       if (pair.getNameString().equals(name)) {
/* 170 */         return true;
/*     */       }
/*     */     } 
/* 173 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\AnnotationGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */