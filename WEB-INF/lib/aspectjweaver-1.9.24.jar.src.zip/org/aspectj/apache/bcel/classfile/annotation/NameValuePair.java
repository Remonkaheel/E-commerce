/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameValuePair
/*    */ {
/*    */   private int nameIdx;
/*    */   private ElementValue value;
/*    */   private ConstantPool cpool;
/*    */   
/*    */   public NameValuePair(NameValuePair pair, ConstantPool cpool, boolean copyPoolEntries) {
/* 26 */     this.cpool = cpool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 32 */     if (copyPoolEntries) {
/* 33 */       this.nameIdx = cpool.addUtf8(pair.getNameString());
/*    */     } else {
/* 35 */       this.nameIdx = pair.getNameIndex();
/*    */     } 
/* 37 */     this.value = ElementValue.copy(pair.getValue(), cpool, copyPoolEntries);
/*    */   }
/*    */   
/*    */   protected NameValuePair(int idx, ElementValue value, ConstantPool cpool) {
/* 41 */     this.nameIdx = idx;
/* 42 */     this.value = value;
/* 43 */     this.cpool = cpool;
/*    */   }
/*    */   
/*    */   public NameValuePair(String name, ElementValue value, ConstantPool cpool) {
/* 47 */     this.nameIdx = cpool.addUtf8(name);
/* 48 */     this.value = value;
/* 49 */     this.cpool = cpool;
/*    */   }
/*    */   
/*    */   protected void dump(DataOutputStream dos) throws IOException {
/* 53 */     dos.writeShort(this.nameIdx);
/* 54 */     this.value.dump(dos);
/*    */   }
/*    */   
/*    */   public int getNameIndex() {
/* 58 */     return this.nameIdx;
/*    */   }
/*    */   
/*    */   public final String getNameString() {
/* 62 */     return this.cpool.getConstantUtf8(this.nameIdx).getValue();
/*    */   }
/*    */   
/*    */   public final ElementValue getValue() {
/* 66 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     StringBuilder sb = new StringBuilder();
/* 72 */     sb.append(getNameString()).append("=").append(this.value.stringifyValue());
/* 73 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\NameValuePair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */