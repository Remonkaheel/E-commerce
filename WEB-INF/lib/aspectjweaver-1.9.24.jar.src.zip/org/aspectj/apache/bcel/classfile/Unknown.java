/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Unknown
/*     */   extends Attribute
/*     */ {
/*     */   private byte[] bytes;
/*     */   private String name;
/*     */   
/*     */   public Unknown(Unknown c) {
/* 100 */     this(c.getNameIndex(), c.getLength(), c.getBytes(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Unknown(int name_index, int length, byte[] bytes, ConstantPool constant_pool) {
/* 112 */     super((byte)-1, name_index, length, constant_pool);
/* 113 */     this.bytes = bytes;
/*     */     
/* 115 */     this.name = ((ConstantUtf8)constant_pool.getConstant(name_index, (byte)1)).getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Unknown(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 129 */     this(name_index, length, (byte[])null, constant_pool);
/*     */     
/* 131 */     if (length > 0) {
/* 132 */       this.bytes = new byte[length];
/* 133 */       file.readFully(this.bytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 145 */     v.visitUnknown(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 156 */     super.dump(file);
/* 157 */     if (this.length > 0) {
/* 158 */       file.write(this.bytes, 0, this.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getBytes() {
/* 165 */     return this.bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 173 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBytes(byte[] bytes) {
/* 180 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/*     */     String hex;
/* 188 */     if (this.length == 0 || this.bytes == null) {
/* 189 */       return "(Unknown attribute " + this.name + ")";
/*     */     }
/*     */     
/* 192 */     if (this.length > 10) {
/* 193 */       byte[] tmp = new byte[10];
/* 194 */       System.arraycopy(this.bytes, 0, tmp, 0, 10);
/* 195 */       hex = Utility.toHexString(tmp) + "... (truncated)";
/*     */     } else {
/* 197 */       hex = Utility.toHexString(this.bytes);
/*     */     } 
/* 199 */     return "(Unknown attribute " + this.name + ": " + hex + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Unknown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */