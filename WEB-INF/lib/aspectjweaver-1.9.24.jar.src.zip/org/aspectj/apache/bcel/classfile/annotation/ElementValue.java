/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementValue
/*     */ {
/*     */   public static final int STRING = 115;
/*     */   public static final int ENUM_CONSTANT = 101;
/*     */   public static final int CLASS = 99;
/*     */   public static final int ANNOTATION = 64;
/*     */   public static final int ARRAY = 91;
/*     */   public static final int PRIMITIVE_INT = 73;
/*     */   public static final int PRIMITIVE_BYTE = 66;
/*     */   public static final int PRIMITIVE_CHAR = 67;
/*     */   public static final int PRIMITIVE_DOUBLE = 68;
/*     */   public static final int PRIMITIVE_FLOAT = 70;
/*     */   public static final int PRIMITIVE_LONG = 74;
/*     */   public static final int PRIMITIVE_SHORT = 83;
/*     */   public static final int PRIMITIVE_BOOLEAN = 90;
/*     */   protected int type;
/*     */   protected ConstantPool cpool;
/*     */   
/*     */   protected ElementValue(int type, ConstantPool cpool) {
/*  42 */     this.type = type;
/*  43 */     this.cpool = cpool;
/*     */   }
/*     */   
/*     */   public int getElementValueType() {
/*  47 */     return this.type;
/*     */   }
/*     */   
/*     */   public abstract String stringifyValue();
/*     */   
/*     */   public static ElementValue readElementValue(DataInputStream dis, ConstantPool cpGen) throws IOException {
/*     */     int numArrayVals;
/*     */     ElementValue[] evalues;
/*  55 */     int j, type = dis.readUnsignedByte();
/*  56 */     switch (type) {
/*     */       case 66:
/*  58 */         return new SimpleElementValue(66, dis.readUnsignedShort(), cpGen);
/*     */       case 67:
/*  60 */         return new SimpleElementValue(67, dis.readUnsignedShort(), cpGen);
/*     */       case 68:
/*  62 */         return new SimpleElementValue(68, dis.readUnsignedShort(), cpGen);
/*     */       case 70:
/*  64 */         return new SimpleElementValue(70, dis.readUnsignedShort(), cpGen);
/*     */       case 73:
/*  66 */         return new SimpleElementValue(73, dis.readUnsignedShort(), cpGen);
/*     */       case 74:
/*  68 */         return new SimpleElementValue(74, dis.readUnsignedShort(), cpGen);
/*     */       case 83:
/*  70 */         return new SimpleElementValue(83, dis.readUnsignedShort(), cpGen);
/*     */       case 90:
/*  72 */         return new SimpleElementValue(90, dis.readUnsignedShort(), cpGen);
/*     */       case 115:
/*  74 */         return new SimpleElementValue(115, dis.readUnsignedShort(), cpGen);
/*     */       
/*     */       case 101:
/*  77 */         return new EnumElementValue(dis.readUnsignedShort(), dis.readUnsignedShort(), cpGen);
/*     */       
/*     */       case 99:
/*  80 */         return new ClassElementValue(dis.readUnsignedShort(), cpGen);
/*     */ 
/*     */       
/*     */       case 64:
/*  84 */         return new AnnotationElementValue(64, AnnotationGen.read(dis, cpGen, true), cpGen);
/*     */       
/*     */       case 91:
/*  87 */         numArrayVals = dis.readUnsignedShort();
/*  88 */         evalues = new ElementValue[numArrayVals];
/*  89 */         for (j = 0; j < numArrayVals; j++) {
/*  90 */           evalues[j] = readElementValue(dis, cpGen);
/*     */         }
/*  92 */         return new ArrayElementValue(91, evalues, cpGen);
/*     */     } 
/*     */     
/*  95 */     throw new RuntimeException("Unexpected element value kind in annotation: " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ConstantPool getConstantPool() {
/* 100 */     return this.cpool;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void dump(DataOutputStream paramDataOutputStream) throws IOException;
/*     */   
/*     */   public static ElementValue copy(ElementValue value, ConstantPool cpool, boolean copyPoolEntries) {
/* 107 */     switch (value.getElementValueType()) {
/*     */       case 66:
/*     */       case 67:
/*     */       case 68:
/*     */       case 70:
/*     */       case 73:
/*     */       case 74:
/*     */       case 83:
/*     */       case 90:
/*     */       case 115:
/* 117 */         return new SimpleElementValue((SimpleElementValue)value, cpool, copyPoolEntries);
/*     */       
/*     */       case 101:
/* 120 */         return new EnumElementValue((EnumElementValue)value, cpool, copyPoolEntries);
/*     */       
/*     */       case 64:
/* 123 */         return new AnnotationElementValue((AnnotationElementValue)value, cpool, copyPoolEntries);
/*     */       
/*     */       case 91:
/* 126 */         return new ArrayElementValue((ArrayElementValue)value, cpool, copyPoolEntries);
/*     */       
/*     */       case 99:
/* 129 */         return new ClassElementValue((ClassElementValue)value, cpool, copyPoolEntries);
/*     */     } 
/*     */     
/* 132 */     throw new RuntimeException("Not implemented yet! (" + value.getElementValueType() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\ElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */