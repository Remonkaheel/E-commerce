package org.aspectj.apache.bcel.classfile;

public interface ConstantObject {
  Object getConstantValue(ConstantPool paramConstantPool);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */