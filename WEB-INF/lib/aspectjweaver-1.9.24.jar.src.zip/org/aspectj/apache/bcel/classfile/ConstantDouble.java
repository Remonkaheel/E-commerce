/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantDouble
/*     */   extends Constant
/*     */   implements SimpleConstant
/*     */ {
/*     */   private double value;
/*     */   
/*     */   public ConstantDouble(double value) {
/*  75 */     super((byte)6);
/*  76 */     this.value = value;
/*     */   }
/*     */   
/*     */   ConstantDouble(DataInputStream file) throws IOException {
/*  80 */     this(file.readDouble());
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  85 */     v.visitConstantDouble(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  90 */     file.writeByte(this.tag);
/*  91 */     file.writeDouble(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  96 */     return super.toString() + "(bytes = " + this.value + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public Double getValue() {
/* 101 */     return Double.valueOf(this.value);
/*     */   }
/*     */   
/*     */   public String getStringValue() {
/* 105 */     return Double.toString(this.value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */