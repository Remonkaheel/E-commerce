/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.Attribute;
/*    */ import org.aspectj.apache.bcel.classfile.ClassVisitor;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeVisAnnos
/*    */   extends RuntimeAnnos
/*    */ {
/*    */   public RuntimeVisAnnos(int nameIdx, int len, ConstantPool cpool) {
/* 26 */     super((byte)12, true, nameIdx, len, cpool);
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeVisAnnos(int nameIdx, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 31 */     this(nameIdx, len, cpool);
/* 32 */     readAnnotations(dis, cpool);
/*    */   }
/*    */   
/*    */   public RuntimeVisAnnos(int nameIndex, int len, byte[] rvaData, ConstantPool cpool) {
/* 36 */     super((byte)12, true, nameIndex, len, rvaData, cpool);
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 40 */     v.visitRuntimeVisibleAnnotations(this);
/*    */   }
/*    */   
/*    */   public final void dump(DataOutputStream dos) throws IOException {
/* 44 */     super.dump(dos);
/* 45 */     writeAnnotations(dos);
/*    */   }
/*    */   
/*    */   public Attribute copy(ConstantPool constant_pool) {
/* 49 */     throw new RuntimeException("Not implemented yet!");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeVisAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */