/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.Attribute;
/*    */ import org.aspectj.apache.bcel.classfile.ClassVisitor;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeInvisParamAnnos
/*    */   extends RuntimeParamAnnos
/*    */ {
/*    */   public RuntimeInvisParamAnnos(int nameIdx, int len, ConstantPool cpool) {
/* 25 */     super((byte)15, false, nameIdx, len, cpool);
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeInvisParamAnnos(int nameIdx, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 30 */     this(nameIdx, len, cpool);
/* 31 */     readParameterAnnotations(dis, cpool);
/*    */   }
/*    */   
/*    */   public RuntimeInvisParamAnnos(int nameIndex, int len, byte[] rvaData, ConstantPool cpool) {
/* 35 */     super((byte)15, false, nameIndex, len, rvaData, cpool);
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 39 */     v.visitRuntimeInvisibleParameterAnnotations(this);
/*    */   }
/*    */   
/*    */   public Attribute copy(ConstantPool constant_pool) {
/* 43 */     throw new RuntimeException("Not implemented yet!");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeInvisParamAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */