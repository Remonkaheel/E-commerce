/*    */ package org.aspectj.apache.bcel.classfile;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeUtils
/*    */ {
/*    */   public static Attribute[] readAttributes(DataInputStream dataInputstream, ConstantPool cpool) {
/*    */     try {
/* 13 */       int length = dataInputstream.readUnsignedShort();
/* 14 */       if (length == 0) {
/* 15 */         return Attribute.NoAttributes;
/*    */       }
/* 17 */       Attribute[] attrs = new Attribute[length];
/* 18 */       for (int i = 0; i < length; i++) {
/* 19 */         attrs[i] = Attribute.readAttribute(dataInputstream, cpool);
/*    */       }
/* 21 */       return attrs;
/* 22 */     } catch (IOException e) {
/* 23 */       throw new ClassFormatException("IOException whilst reading set of attributes: " + e.toString());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void writeAttributes(Attribute[] attributes, DataOutputStream file) throws IOException {
/* 29 */     if (attributes == null) {
/* 30 */       file.writeShort(0);
/*    */     } else {
/* 32 */       file.writeShort(attributes.length);
/* 33 */       for (Attribute attribute : attributes) {
/* 34 */         attribute.dump(file);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Signature getSignatureAttribute(Attribute[] attributes) {
/* 40 */     for (Attribute attribute : attributes) {
/* 41 */       if (attribute.tag == 10) {
/* 42 */         return (Signature)attribute;
/*    */       }
/*    */     } 
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public static Code getCodeAttribute(Attribute[] attributes) {
/* 49 */     for (Attribute attribute : attributes) {
/* 50 */       if (attribute.tag == 2) {
/* 51 */         return (Code)attribute;
/*    */       }
/*    */     } 
/* 54 */     return null;
/*    */   }
/*    */   
/*    */   public static ExceptionTable getExceptionTableAttribute(Attribute[] attributes) {
/* 58 */     for (Attribute attribute : attributes) {
/* 59 */       if (attribute.tag == 3) {
/* 60 */         return (ExceptionTable)attribute;
/*    */       }
/*    */     } 
/* 63 */     return null;
/*    */   }
/*    */   
/*    */   public static ConstantValue getConstantValueAttribute(Attribute[] attributes) {
/* 67 */     for (Attribute attribute : attributes) {
/* 68 */       if (attribute.getTag() == 1) {
/* 69 */         return (ConstantValue)attribute;
/*    */       }
/*    */     } 
/* 72 */     return null;
/*    */   }
/*    */   
/*    */   public static void accept(Attribute[] attributes, ClassVisitor visitor) {
/* 76 */     for (Attribute attribute : attributes) {
/* 77 */       attribute.accept(visitor);
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean hasSyntheticAttribute(Attribute[] attributes) {
/* 82 */     for (Attribute attribute : attributes) {
/* 83 */       if (attribute.tag == 7) {
/* 84 */         return true;
/*    */       }
/*    */     } 
/* 87 */     return false;
/*    */   }
/*    */   
/*    */   public static SourceFile getSourceFileAttribute(Attribute[] attributes) {
/* 91 */     for (Attribute attribute : attributes) {
/* 92 */       if (attribute.tag == 0) {
/* 93 */         return (SourceFile)attribute;
/*    */       }
/*    */     } 
/* 96 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\AttributeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */