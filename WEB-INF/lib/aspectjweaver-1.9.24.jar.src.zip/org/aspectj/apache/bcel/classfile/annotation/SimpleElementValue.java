/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantDouble;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantFloat;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantInteger;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantLong;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleElementValue
/*     */   extends ElementValue
/*     */ {
/*     */   private int idx;
/*     */   
/*     */   protected SimpleElementValue(int type, int idx, ConstantPool cpGen) {
/*  40 */     super(type, cpGen);
/*  41 */     this.idx = idx;
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, int value) {
/*  45 */     super(type, cpGen);
/*  46 */     this.idx = cpGen.addInteger(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, long value) {
/*  50 */     super(type, cpGen);
/*  51 */     this.idx = cpGen.addLong(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, double value) {
/*  55 */     super(type, cpGen);
/*  56 */     this.idx = cpGen.addDouble(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, float value) {
/*  60 */     super(type, cpGen);
/*  61 */     this.idx = cpGen.addFloat(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, short value) {
/*  65 */     super(type, cpGen);
/*  66 */     this.idx = cpGen.addInteger(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, byte value) {
/*  70 */     super(type, cpGen);
/*  71 */     this.idx = cpGen.addInteger(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, char value) {
/*  75 */     super(type, cpGen);
/*  76 */     this.idx = cpGen.addInteger(value);
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, boolean value) {
/*  80 */     super(type, cpGen);
/*  81 */     if (value) {
/*  82 */       this.idx = cpGen.addInteger(1);
/*     */     } else {
/*  84 */       this.idx = cpGen.addInteger(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public SimpleElementValue(int type, ConstantPool cpGen, String value) {
/*  89 */     super(type, cpGen);
/*  90 */     this.idx = cpGen.addUtf8(value);
/*     */   }
/*     */   
/*     */   public byte getValueByte() {
/*  94 */     if (this.type != 66) {
/*  95 */       throw new RuntimeException("Dont call getValueByte() on a non BYTE ElementValue");
/*     */     }
/*  97 */     ConstantInteger c = (ConstantInteger)this.cpool.getConstant(this.idx, (byte)3);
/*  98 */     return (byte)c.getIntValue();
/*     */   }
/*     */   
/*     */   public char getValueChar() {
/* 102 */     if (this.type != 67) {
/* 103 */       throw new RuntimeException("Dont call getValueChar() on a non CHAR ElementValue");
/*     */     }
/* 105 */     ConstantInteger c = (ConstantInteger)this.cpool.getConstant(this.idx, (byte)3);
/* 106 */     return (char)c.getIntValue();
/*     */   }
/*     */   
/*     */   public long getValueLong() {
/* 110 */     if (this.type != 74) {
/* 111 */       throw new RuntimeException("Dont call getValueLong() on a non LONG ElementValue");
/*     */     }
/* 113 */     ConstantLong j = (ConstantLong)this.cpool.getConstant(this.idx);
/* 114 */     return j.getValue().longValue();
/*     */   }
/*     */   
/*     */   public float getValueFloat() {
/* 118 */     if (this.type != 70) {
/* 119 */       throw new RuntimeException("Dont call getValueFloat() on a non FLOAT ElementValue");
/*     */     }
/* 121 */     ConstantFloat f = (ConstantFloat)this.cpool.getConstant(this.idx);
/* 122 */     return f.getValue().floatValue();
/*     */   }
/*     */   
/*     */   public double getValueDouble() {
/* 126 */     if (this.type != 68) {
/* 127 */       throw new RuntimeException("Dont call getValueDouble() on a non DOUBLE ElementValue");
/*     */     }
/* 129 */     ConstantDouble d = (ConstantDouble)this.cpool.getConstant(this.idx);
/* 130 */     return d.getValue().doubleValue();
/*     */   }
/*     */   
/*     */   public boolean getValueBoolean() {
/* 134 */     if (this.type != 90) {
/* 135 */       throw new RuntimeException("Dont call getValueBoolean() on a non BOOLEAN ElementValue");
/*     */     }
/* 137 */     ConstantInteger bo = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 138 */     return (bo.getValue().intValue() != 0);
/*     */   }
/*     */   
/*     */   public short getValueShort() {
/* 142 */     if (this.type != 83) {
/* 143 */       throw new RuntimeException("Dont call getValueShort() on a non SHORT ElementValue");
/*     */     }
/* 145 */     ConstantInteger s = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 146 */     return (short)s.getIntValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleElementValue(SimpleElementValue value, ConstantPool cpool, boolean copyPoolEntries) {
/* 154 */     super(value.getElementValueType(), cpool);
/* 155 */     if (!copyPoolEntries) {
/*     */ 
/*     */       
/* 158 */       this.idx = value.getIndex();
/*     */     } else {
/* 160 */       switch (value.getElementValueType()) {
/*     */         case 115:
/* 162 */           this.idx = cpool.addUtf8(value.getValueString());
/*     */           return;
/*     */         case 73:
/* 165 */           this.idx = cpool.addInteger(value.getValueInt());
/*     */           return;
/*     */         case 66:
/* 168 */           this.idx = cpool.addInteger(value.getValueByte());
/*     */           return;
/*     */         case 67:
/* 171 */           this.idx = cpool.addInteger(value.getValueChar());
/*     */           return;
/*     */         case 74:
/* 174 */           this.idx = cpool.addLong(value.getValueLong());
/*     */           return;
/*     */         case 70:
/* 177 */           this.idx = cpool.addFloat(value.getValueFloat());
/*     */           return;
/*     */         case 68:
/* 180 */           this.idx = cpool.addDouble(value.getValueDouble());
/*     */           return;
/*     */         case 90:
/* 183 */           if (value.getValueBoolean()) {
/* 184 */             this.idx = cpool.addInteger(1);
/*     */           } else {
/* 186 */             this.idx = cpool.addInteger(0);
/*     */           } 
/*     */           return;
/*     */         case 83:
/* 190 */           this.idx = cpool.addInteger(value.getValueShort());
/*     */           return;
/*     */       } 
/* 193 */       throw new RuntimeException("SimpleElementValueGen class does not know how to copy this type " + this.type);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIndex() {
/* 199 */     return this.idx;
/*     */   }
/*     */   
/*     */   public String getValueString() {
/* 203 */     if (this.type != 115) {
/* 204 */       throw new RuntimeException("Dont call getValueString() on a non STRING ElementValue");
/*     */     }
/* 206 */     ConstantUtf8 c = (ConstantUtf8)this.cpool.getConstant(this.idx);
/* 207 */     return c.getValue();
/*     */   }
/*     */   
/*     */   public int getValueInt() {
/* 211 */     if (this.type != 73) {
/* 212 */       throw new RuntimeException("Dont call getValueString() on a non STRING ElementValue");
/*     */     }
/* 214 */     ConstantInteger c = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 215 */     return c.getValue().intValue(); } public String stringifyValue() { ConstantInteger c; ConstantLong j; ConstantDouble d; ConstantFloat f;
/*     */     ConstantInteger s;
/*     */     ConstantInteger b;
/*     */     ConstantInteger ch;
/*     */     ConstantInteger bo;
/*     */     ConstantUtf8 cu8;
/* 221 */     switch (this.type) {
/*     */       case 73:
/* 223 */         c = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 224 */         return Integer.toString(c.getValue().intValue());
/*     */       case 74:
/* 226 */         j = (ConstantLong)this.cpool.getConstant(this.idx);
/* 227 */         return Long.toString(j.getValue().longValue());
/*     */       case 68:
/* 229 */         d = (ConstantDouble)this.cpool.getConstant(this.idx);
/* 230 */         return d.getValue().toString();
/*     */       case 70:
/* 232 */         f = (ConstantFloat)this.cpool.getConstant(this.idx);
/* 233 */         return Float.toString(f.getValue().floatValue());
/*     */       case 83:
/* 235 */         s = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 236 */         return Integer.toString(s.getValue().intValue());
/*     */       case 66:
/* 238 */         b = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 239 */         return Integer.toString(b.getValue().intValue());
/*     */       case 67:
/* 241 */         ch = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 242 */         return Character.toString((char)ch.getIntValue());
/*     */       case 90:
/* 244 */         bo = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 245 */         if (bo.getValue().intValue() == 0) {
/* 246 */           return "false";
/*     */         }
/* 248 */         return "true";
/*     */       
/*     */       case 115:
/* 251 */         cu8 = (ConstantUtf8)this.cpool.getConstant(this.idx);
/* 252 */         return cu8.getValue();
/*     */     } 
/*     */     
/* 255 */     throw new RuntimeException("SimpleElementValueGen class does not know how to stringify type " + this.type); } public String toString() { ConstantInteger c;
/*     */     ConstantLong j;
/*     */     ConstantDouble d;
/*     */     ConstantFloat f;
/*     */     ConstantInteger ci, b, ch, bo;
/*     */     ConstantUtf8 cu8;
/* 261 */     StringBuilder s = new StringBuilder();
/* 262 */     switch (this.type) {
/*     */       case 73:
/* 264 */         c = (ConstantInteger)this.cpool.getConstant(this.idx);
/* 265 */         s.append("(int)").append(c.getValue());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 307 */         return s.toString();case 74: j = (ConstantLong)this.cpool.getConstant(this.idx); s.append("(long)").append(j.getValue()); return s.toString();case 68: d = (ConstantDouble)this.cpool.getConstant(this.idx); s.append("(double)").append(d.getValue().toString()); return s.toString();case 70: f = (ConstantFloat)this.cpool.getConstant(this.idx); s.append("(float)").append(f.getValue()); return s.toString();case 83: ci = (ConstantInteger)this.cpool.getConstant(this.idx); s.append("(short)").append(ci.getValue()); return s.toString();case 66: b = (ConstantInteger)this.cpool.getConstant(this.idx); s.append("(byte)").append(b.getValue()); return s.toString();case 67: ch = (ConstantInteger)this.cpool.getConstant(this.idx); s.append("(char)").append((char)ch.getIntValue()); return s.toString();case 90: bo = (ConstantInteger)this.cpool.getConstant(this.idx); s.append("(boolean)"); if (bo.getValue().intValue() == 0) { s.append("false"); } else { s.append("true"); }  return s.toString();case 115: cu8 = (ConstantUtf8)this.cpool.getConstant(this.idx); s.append("(string)").append(cu8.getValue()); return s.toString();
/*     */     } 
/*     */     throw new RuntimeException("SimpleElementValueGen class does not know how to stringify type " + this.type); }
/*     */   
/*     */   public void dump(DataOutputStream dos) throws IOException {
/* 312 */     dos.writeByte(this.type);
/* 313 */     switch (this.type) {
/*     */       case 66:
/*     */       case 67:
/*     */       case 68:
/*     */       case 70:
/*     */       case 73:
/*     */       case 74:
/*     */       case 83:
/*     */       case 90:
/*     */       case 115:
/* 323 */         dos.writeShort(this.idx);
/*     */         return;
/*     */     } 
/* 326 */     throw new RuntimeException("SimpleElementValueGen doesnt know how to write out type " + this.type);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\SimpleElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */