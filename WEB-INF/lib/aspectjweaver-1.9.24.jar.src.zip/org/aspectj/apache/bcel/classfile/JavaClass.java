/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.StringTokenizer;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeAnnos;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ import org.aspectj.apache.bcel.util.Repository;
/*     */ import org.aspectj.apache.bcel.util.SyntheticRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaClass
/*     */   extends Modifiers
/*     */   implements Cloneable, Node
/*     */ {
/*  90 */   private static final String[] NoInterfaceNames = new String[0];
/*  91 */   private static final int[] NoInterfaceIndices = new int[0];
/*     */   
/*     */   private String fileName;
/*     */   
/*     */   private String packageName;
/*     */   
/*     */   private String sourcefileName;
/*     */   
/*     */   private int classnameIdx;
/*     */   
/*     */   private int superclassnameIdx;
/*     */   private String classname;
/*     */   private String superclassname;
/*     */   private int major;
/*     */   private int minor;
/*     */   private ConstantPool cpool;
/*     */   private int[] interfaces;
/*     */   private String[] interfacenames;
/*     */   private Field[] fields;
/*     */   private Method[] methods;
/*     */   private Attribute[] attributes;
/*     */   private AnnotationGen[] annotations;
/*     */   private boolean isGeneric = false;
/*     */   private boolean isAnonymous = false;
/*     */   private boolean isNested = false;
/*     */   private boolean computedNestedTypeStatus = false;
/*     */   private boolean annotationsOutOfDate = true;
/* 118 */   private String signatureAttributeString = null;
/* 119 */   private Signature signatureAttribute = null;
/*     */ 
/*     */   
/*     */   private boolean searchedForSignatureAttribute = false;
/*     */ 
/*     */   
/* 125 */   private transient Repository repository = null;
/*     */ 
/*     */   
/*     */   public JavaClass(int classnameIndex, int superclassnameIndex, String filename, int major, int minor, int access_flags, ConstantPool cpool, int[] interfaces, Field[] fields, Method[] methods, Attribute[] attributes) {
/* 129 */     if (interfaces == null) {
/* 130 */       interfaces = NoInterfaceIndices;
/*     */     }
/*     */     
/* 133 */     this.classnameIdx = classnameIndex;
/* 134 */     this.superclassnameIdx = superclassnameIndex;
/* 135 */     this.fileName = filename;
/* 136 */     this.major = major;
/* 137 */     this.minor = minor;
/* 138 */     this.modifiers = access_flags;
/* 139 */     this.cpool = cpool;
/* 140 */     this.interfaces = interfaces;
/* 141 */     this.fields = (fields == null) ? Field.NoFields : fields;
/* 142 */     this.methods = (methods == null) ? Method.NoMethods : methods;
/* 143 */     this.attributes = (attributes == null) ? Attribute.NoAttributes : attributes;
/* 144 */     this.annotationsOutOfDate = true;
/*     */ 
/*     */     
/* 147 */     SourceFile sfAttribute = AttributeUtils.getSourceFileAttribute(attributes);
/* 148 */     this.sourcefileName = (sfAttribute == null) ? "<Unknown>" : sfAttribute.getSourceFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     this.classname = cpool.getConstantString(classnameIndex, (byte)7);
/* 155 */     this.classname = Utility.compactClassName(this.classname, false);
/*     */     
/* 157 */     int index = this.classname.lastIndexOf('.');
/* 158 */     if (index < 0) {
/* 159 */       this.packageName = "";
/*     */     } else {
/* 161 */       this.packageName = this.classname.substring(0, index);
/*     */     } 
/*     */     
/* 164 */     if (superclassnameIndex > 0) {
/* 165 */       this.superclassname = cpool.getConstantString(superclassnameIndex, (byte)7);
/* 166 */       this.superclassname = Utility.compactClassName(this.superclassname, false);
/*     */     } else {
/* 168 */       this.superclassname = "java.lang.Object";
/*     */     } 
/*     */     
/* 171 */     if (interfaces.length == 0) {
/* 172 */       this.interfacenames = NoInterfaceNames;
/*     */     } else {
/* 174 */       this.interfacenames = new String[interfaces.length];
/* 175 */       for (int i = 0; i < interfaces.length; i++) {
/* 176 */         String str = cpool.getConstantString(interfaces[i], (byte)7);
/* 177 */         this.interfacenames[i] = Utility.compactClassName(str, false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 189 */     v.visitJavaClass(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(File file) throws IOException {
/* 199 */     String parent = file.getParent();
/* 200 */     if (parent != null) {
/* 201 */       File dir = new File(parent);
/* 202 */       dir.mkdirs();
/*     */     } 
/* 204 */     dump(new DataOutputStream(new FileOutputStream(file)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(String file_name) throws IOException {
/* 214 */     dump(new File(file_name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 221 */     ByteArrayOutputStream s = new ByteArrayOutputStream();
/* 222 */     DataOutputStream ds = new DataOutputStream(s);
/*     */     
/*     */     try {
/* 225 */       dump(ds);
/* 226 */     } catch (IOException e) {
/* 227 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 230 */         ds.close();
/* 231 */       } catch (IOException e2) {
/* 232 */         e2.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 236 */     return s.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(OutputStream file) throws IOException {
/* 243 */     dump(new DataOutputStream(file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream file) throws IOException {
/* 250 */     file.writeInt(-889275714);
/* 251 */     file.writeShort(this.minor);
/* 252 */     file.writeShort(this.major);
/*     */     
/* 254 */     this.cpool.dump(file);
/*     */     
/* 256 */     file.writeShort(this.modifiers);
/* 257 */     file.writeShort(this.classnameIdx);
/* 258 */     file.writeShort(this.superclassnameIdx);
/*     */     
/* 260 */     file.writeShort(this.interfaces.length);
/* 261 */     for (int anInterface : this.interfaces) {
/* 262 */       file.writeShort(anInterface);
/*     */     }
/*     */     
/* 265 */     file.writeShort(this.fields.length);
/* 266 */     for (Field field : this.fields) {
/* 267 */       field.dump(file);
/*     */     }
/*     */     
/* 270 */     file.writeShort(this.methods.length);
/* 271 */     for (Method method : this.methods) {
/* 272 */       method.dump(file);
/*     */     }
/*     */     
/* 275 */     AttributeUtils.writeAttributes(this.attributes, file);
/*     */     
/* 277 */     file.close();
/*     */   }
/*     */   
/*     */   public Attribute[] getAttributes() {
/* 281 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public AnnotationGen[] getAnnotations() {
/* 285 */     if (this.annotationsOutOfDate) {
/*     */       
/* 287 */       List<AnnotationGen> accumulatedAnnotations = new ArrayList<>();
/* 288 */       for (Attribute attribute : this.attributes) {
/* 289 */         if (attribute instanceof RuntimeAnnos) {
/* 290 */           RuntimeAnnos runtimeAnnotations = (RuntimeAnnos)attribute;
/* 291 */           accumulatedAnnotations.addAll(runtimeAnnotations.getAnnotations());
/*     */         } 
/*     */       } 
/* 294 */       this.annotations = accumulatedAnnotations.<AnnotationGen>toArray(AnnotationGen.NO_ANNOTATIONS);
/* 295 */       this.annotationsOutOfDate = false;
/*     */     } 
/* 297 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 304 */     return this.classname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackageName() {
/* 311 */     return this.packageName;
/*     */   }
/*     */   
/*     */   public int getClassNameIndex() {
/* 315 */     return this.classnameIdx;
/*     */   }
/*     */   
/*     */   public ConstantPool getConstantPool() {
/* 319 */     return this.cpool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Field[] getFields() {
/* 327 */     return this.fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 334 */     return this.fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getInterfaceNames() {
/* 341 */     return this.interfacenames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getInterfaceIndices() {
/* 348 */     return this.interfaces;
/*     */   }
/*     */   
/*     */   public int getMajor() {
/* 352 */     return this.major;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method[] getMethods() {
/* 359 */     return this.methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod(Method m) {
/* 366 */     for (Method method : this.methods) {
/* 367 */       if (m.getName().equals(method.getName()) && m.getModifiers() == method.getModifiers() && 
/* 368 */         Type.getSignature(m).equals(method.getSignature())) {
/* 369 */         return method;
/*     */       }
/*     */     } 
/*     */     
/* 373 */     return null;
/*     */   }
/*     */   
/*     */   public Method getMethod(Constructor<?> c) {
/* 377 */     for (Method method : this.methods) {
/* 378 */       if (method.getName().equals("<init>") && c.getModifiers() == method.getModifiers() && 
/* 379 */         Type.getSignature(c).equals(method.getSignature())) {
/* 380 */         return method;
/*     */       }
/*     */     } 
/*     */     
/* 384 */     return null;
/*     */   }
/*     */   
/*     */   public Field getField(Field field) {
/* 388 */     String fieldName = field.getName();
/* 389 */     for (Field f : this.fields) {
/* 390 */       if (f.getName().equals(fieldName)) {
/* 391 */         return f;
/*     */       }
/*     */     } 
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinor() {
/* 401 */     return this.minor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceFileName() {
/* 408 */     return this.sourcefileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuperclassName() {
/* 415 */     return this.superclassname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSuperclassNameIndex() {
/* 422 */     return this.superclassnameIdx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Attribute[] attributes) {
/* 429 */     this.attributes = attributes;
/* 430 */     this.annotationsOutOfDate = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassName(String class_name) {
/* 437 */     this.classname = class_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassNameIndex(int class_name_index) {
/* 444 */     this.classnameIdx = class_name_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConstantPool(ConstantPool constant_pool) {
/* 451 */     this.cpool = constant_pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFields(Field[] fields) {
/* 458 */     this.fields = fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileName(String file_name) {
/* 465 */     this.fileName = file_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterfaceNames(String[] interface_names) {
/* 472 */     this.interfacenames = interface_names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterfaces(int[] interfaces) {
/* 479 */     this.interfaces = interfaces;
/*     */   }
/*     */   
/*     */   public void setMajor(int major) {
/* 483 */     this.major = major;
/*     */   }
/*     */   
/*     */   public void setMethods(Method[] methods) {
/* 487 */     this.methods = methods;
/*     */   }
/*     */   
/*     */   public void setMinor(int minor) {
/* 491 */     this.minor = minor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceFileName(String source_file_name) {
/* 498 */     this.sourcefileName = source_file_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuperclassName(String superclass_name) {
/* 505 */     this.superclassname = superclass_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuperclassNameIndex(int superclass_name_index) {
/* 512 */     this.superclassnameIdx = superclass_name_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 520 */     String access = Utility.accessToString(this.modifiers, true);
/* 521 */     access = access.equals("") ? "" : (access + " ");
/*     */ 
/*     */     
/* 524 */     StringBuilder buf = new StringBuilder(access + Utility.classOrInterface(this.modifiers) + " " + this.classname + " extends " + Utility.compactClassName(this.superclassname, false) + '\n');
/* 525 */     int size = this.interfaces.length;
/*     */     
/* 527 */     if (size > 0) {
/* 528 */       buf.append("implements\t\t");
/*     */       
/* 530 */       for (int i = 0; i < size; i++) {
/* 531 */         buf.append(this.interfacenames[i]);
/* 532 */         if (i < size - 1) {
/* 533 */           buf.append(", ");
/*     */         }
/*     */       } 
/*     */       
/* 537 */       buf.append('\n');
/*     */     } 
/*     */     
/* 540 */     buf.append("filename\t\t" + this.fileName + '\n');
/* 541 */     buf.append("compiled from\t\t" + this.sourcefileName + '\n');
/* 542 */     buf.append("compiler version\t" + this.major + "." + this.minor + '\n');
/* 543 */     buf.append("access flags\t\t" + this.modifiers + '\n');
/* 544 */     buf.append("constant pool\t\t" + this.cpool.getLength() + " entries\n");
/* 545 */     buf.append("ACC_SUPER flag\t\t" + isSuper() + "\n");
/*     */     
/* 547 */     if (this.attributes.length > 0) {
/* 548 */       buf.append("\nAttribute(s):\n");
/* 549 */       for (Attribute attribute : this.attributes) {
/* 550 */         buf.append(indent(attribute));
/*     */       }
/*     */     } 
/*     */     
/* 554 */     if (this.annotations != null && this.annotations.length > 0) {
/* 555 */       buf.append("\nAnnotation(s):\n");
/* 556 */       for (AnnotationGen annotation : this.annotations) {
/* 557 */         buf.append(indent(annotation));
/*     */       }
/*     */     } 
/*     */     
/* 561 */     if (this.fields.length > 0) {
/* 562 */       buf.append("\n" + this.fields.length + " fields:\n");
/* 563 */       for (Field field : this.fields) {
/* 564 */         buf.append("\t" + field + '\n');
/*     */       }
/*     */     } 
/*     */     
/* 568 */     if (this.methods.length > 0) {
/* 569 */       buf.append("\n" + this.methods.length + " methods:\n");
/* 570 */       for (Method method : this.methods) {
/* 571 */         buf.append("\t" + method + '\n');
/*     */       }
/*     */     } 
/*     */     
/* 575 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private static final String indent(Object obj) {
/* 579 */     StringTokenizer tok = new StringTokenizer(obj.toString(), "\n");
/* 580 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 582 */     while (tok.hasMoreTokens()) {
/* 583 */       buf.append("\t" + tok.nextToken() + "\n");
/*     */     }
/*     */     
/* 586 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public final boolean isSuper() {
/* 590 */     return ((this.modifiers & 0x20) != 0);
/*     */   }
/*     */   
/*     */   public final boolean isClass() {
/* 594 */     return ((this.modifiers & 0x200) == 0);
/*     */   }
/*     */   
/*     */   public final boolean isAnonymous() {
/* 598 */     computeNestedTypeStatus();
/* 599 */     return this.isAnonymous;
/*     */   }
/*     */   
/*     */   public final boolean isNested() {
/* 603 */     computeNestedTypeStatus();
/* 604 */     return this.isNested;
/*     */   }
/*     */   
/*     */   private final void computeNestedTypeStatus() {
/* 608 */     if (this.computedNestedTypeStatus) {
/*     */       return;
/*     */     }
/*     */     
/* 612 */     for (Attribute attribute : this.attributes) {
/* 613 */       if (attribute instanceof InnerClasses) {
/* 614 */         InnerClass[] innerClasses = ((InnerClasses)attribute).getInnerClasses();
/* 615 */         for (InnerClass innerClass : innerClasses) {
/* 616 */           boolean innerClassAttributeRefersToMe = false;
/* 617 */           String inner_class_name = this.cpool.getConstantString(innerClass.getInnerClassIndex(), (byte)7);
/*     */           
/* 619 */           inner_class_name = Utility.compactClassName(inner_class_name);
/* 620 */           if (inner_class_name.equals(getClassName())) {
/* 621 */             innerClassAttributeRefersToMe = true;
/*     */           }
/* 623 */           if (innerClassAttributeRefersToMe) {
/* 624 */             this.isNested = true;
/* 625 */             if (innerClass.getInnerNameIndex() == 0) {
/* 626 */               this.isAnonymous = true;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 632 */     this.computedNestedTypeStatus = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAnnotation() {
/* 640 */     return ((this.modifiers & 0x2000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnum() {
/* 647 */     return ((this.modifiers & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Repository getRepository() {
/* 656 */     if (this.repository == null) {
/* 657 */       this.repository = (Repository)SyntheticRepository.getInstance();
/*     */     }
/* 659 */     return this.repository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRepository(Repository repository) {
/* 666 */     this.repository = repository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean instanceOf(JavaClass super_class) {
/* 675 */     if (equals(super_class)) {
/* 676 */       return true;
/*     */     }
/*     */     
/* 679 */     JavaClass[] super_classes = getSuperClasses();
/*     */     
/* 681 */     for (JavaClass superClass : super_classes) {
/* 682 */       if (superClass.equals(super_class)) {
/* 683 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 687 */     if (super_class.isInterface()) {
/* 688 */       return implementationOf(super_class);
/*     */     }
/*     */     
/* 691 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implementationOf(JavaClass inter) {
/* 698 */     if (!inter.isInterface()) {
/* 699 */       throw new IllegalArgumentException(inter.getClassName() + " is no interface");
/*     */     }
/*     */     
/* 702 */     if (equals(inter)) {
/* 703 */       return true;
/*     */     }
/*     */     
/* 706 */     Collection<JavaClass> superInterfaces = getAllInterfaces();
/*     */     
/* 708 */     for (JavaClass superInterface : superInterfaces) {
/* 709 */       if (superInterface.equals(inter)) {
/* 710 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 719 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass getSuperClass() {
/* 726 */     if ("java.lang.Object".equals(getClassName())) {
/* 727 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 731 */       return getRepository().loadClass(getSuperclassName());
/* 732 */     } catch (ClassNotFoundException e) {
/* 733 */       System.err.println(e);
/* 734 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass[] getSuperClasses() {
/* 742 */     JavaClass clazz = this;
/* 743 */     List<JavaClass> vec = new ArrayList<>();
/* 744 */     for (clazz = clazz.getSuperClass(); clazz != null; clazz = clazz.getSuperClass()) {
/* 745 */       vec.add(clazz);
/*     */     }
/* 747 */     return vec.<JavaClass>toArray(new JavaClass[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass[] getInterfaces() {
/* 754 */     String[] interfaces = getInterfaceNames();
/* 755 */     JavaClass[] classes = new JavaClass[interfaces.length];
/*     */     
/*     */     try {
/* 758 */       for (int i = 0; i < interfaces.length; i++) {
/* 759 */         classes[i] = getRepository().loadClass(interfaces[i]);
/*     */       }
/* 761 */     } catch (ClassNotFoundException e) {
/* 762 */       System.err.println(e);
/* 763 */       return null;
/*     */     } 
/*     */     
/* 766 */     return classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<JavaClass> getAllInterfaces() {
/* 773 */     Queue<JavaClass> queue = new LinkedList<>();
/* 774 */     List<JavaClass> interfaceList = new ArrayList<>();
/*     */     
/* 776 */     queue.add(this);
/*     */     
/* 778 */     while (!queue.isEmpty()) {
/* 779 */       JavaClass clazz = queue.remove();
/*     */       
/* 781 */       JavaClass souper = clazz.getSuperClass();
/* 782 */       JavaClass[] interfaces = clazz.getInterfaces();
/*     */       
/* 784 */       if (clazz.isInterface()) {
/* 785 */         interfaceList.add(clazz);
/*     */       }
/* 787 */       else if (souper != null) {
/* 788 */         queue.add(souper);
/*     */       } 
/*     */ 
/*     */       
/* 792 */       Collections.addAll(queue, interfaces);
/*     */     } 
/*     */     
/* 795 */     return interfaceList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getGenericSignature() {
/* 806 */     loadGenericSignatureInfoIfNecessary();
/* 807 */     return this.signatureAttributeString;
/*     */   }
/*     */   
/*     */   public boolean isGeneric() {
/* 811 */     loadGenericSignatureInfoIfNecessary();
/* 812 */     return this.isGeneric;
/*     */   }
/*     */   
/*     */   private void loadGenericSignatureInfoIfNecessary() {
/* 816 */     if (!this.searchedForSignatureAttribute) {
/* 817 */       this.signatureAttribute = AttributeUtils.getSignatureAttribute(this.attributes);
/* 818 */       this.signatureAttributeString = (this.signatureAttribute == null) ? null : this.signatureAttribute.getSignature();
/* 819 */       this.isGeneric = (this.signatureAttribute != null && this.signatureAttributeString.charAt(0) == '<');
/* 820 */       this.searchedForSignatureAttribute = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final Signature getSignatureAttribute() {
/* 825 */     loadGenericSignatureInfoIfNecessary();
/* 826 */     return this.signatureAttribute;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\JavaClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */