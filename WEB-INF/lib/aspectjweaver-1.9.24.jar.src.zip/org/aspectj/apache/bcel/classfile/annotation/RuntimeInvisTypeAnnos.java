/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.ClassVisitor;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeInvisTypeAnnos
/*    */   extends RuntimeTypeAnnos
/*    */ {
/*    */   public RuntimeInvisTypeAnnos(int nameIdx, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 25 */     this(nameIdx, len, cpool);
/* 26 */     readTypeAnnotations(dis, cpool);
/*    */   }
/*    */   
/*    */   public RuntimeInvisTypeAnnos(int nameIdx, int len, ConstantPool cpool) {
/* 30 */     super((byte)21, false, nameIdx, len, cpool);
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 34 */     v.visitRuntimeInvisibleTypeAnnotations(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeInvisTypeAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */