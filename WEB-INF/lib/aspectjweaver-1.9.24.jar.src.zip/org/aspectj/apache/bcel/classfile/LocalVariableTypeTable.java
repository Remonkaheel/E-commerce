/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariableTypeTable
/*     */   extends Attribute
/*     */ {
/*     */   private int local_variable_type_table_length;
/*     */   private LocalVariable[] local_variable_type_table;
/*     */   
/*     */   public LocalVariableTypeTable(LocalVariableTypeTable c) {
/*  54 */     this(c.getNameIndex(), c.getLength(), c.getLocalVariableTypeTable(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public LocalVariableTypeTable(int name_index, int length, LocalVariable[] local_variable_table, ConstantPool constant_pool) {
/*  58 */     super((byte)16, name_index, length, constant_pool);
/*  59 */     setLocalVariableTable(local_variable_table);
/*     */   }
/*     */   
/*     */   LocalVariableTypeTable(int nameIdx, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/*  63 */     this(nameIdx, len, (LocalVariable[])null, cpool);
/*     */     
/*  65 */     this.local_variable_type_table_length = dis.readUnsignedShort();
/*  66 */     this.local_variable_type_table = new LocalVariable[this.local_variable_type_table_length];
/*     */     
/*  68 */     for (int i = 0; i < this.local_variable_type_table_length; i++) {
/*  69 */       this.local_variable_type_table[i] = new LocalVariable(dis, cpool);
/*     */     }
/*     */   }
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  74 */     v.visitLocalVariableTypeTable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  79 */     super.dump(file);
/*  80 */     file.writeShort(this.local_variable_type_table_length);
/*  81 */     for (int i = 0; i < this.local_variable_type_table_length; i++)
/*  82 */       this.local_variable_type_table[i].dump(file); 
/*     */   }
/*     */   
/*     */   public final LocalVariable[] getLocalVariableTypeTable() {
/*  86 */     return this.local_variable_type_table;
/*     */   }
/*     */   
/*     */   public final LocalVariable getLocalVariable(int index) {
/*  90 */     for (int i = 0; i < this.local_variable_type_table_length; i++) {
/*  91 */       if (this.local_variable_type_table[i].getIndex() == index)
/*  92 */         return this.local_variable_type_table[i]; 
/*     */     } 
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public final void setLocalVariableTable(LocalVariable[] local_variable_table) {
/*  98 */     this.local_variable_type_table = local_variable_table;
/*  99 */     this.local_variable_type_table_length = (local_variable_table == null) ? 0 : local_variable_table.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 107 */     StringBuilder buf = new StringBuilder("");
/*     */     
/* 109 */     for (int i = 0; i < this.local_variable_type_table_length; i++) {
/* 110 */       buf.append(this.local_variable_type_table[i].toString());
/*     */       
/* 112 */       if (i < this.local_variable_type_table_length - 1) {
/* 113 */         buf.append('\n');
/*     */       }
/*     */     } 
/* 116 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTableLength() {
/* 134 */     return this.local_variable_type_table_length;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\LocalVariableTypeTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */