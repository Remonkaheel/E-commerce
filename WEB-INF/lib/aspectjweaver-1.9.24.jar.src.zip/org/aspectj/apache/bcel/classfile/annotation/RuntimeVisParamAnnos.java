/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.Attribute;
/*    */ import org.aspectj.apache.bcel.classfile.ClassVisitor;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeVisParamAnnos
/*    */   extends RuntimeParamAnnos
/*    */ {
/*    */   public RuntimeVisParamAnnos(int nameIdx, int len, ConstantPool cpool) {
/* 25 */     super((byte)14, true, nameIdx, len, cpool);
/*    */   }
/*    */   
/*    */   public RuntimeVisParamAnnos(int nameIndex, int len, byte[] rvaData, ConstantPool cpool) {
/* 29 */     super((byte)14, true, nameIndex, len, rvaData, cpool);
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeVisParamAnnos(int nameIdx, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 34 */     this(nameIdx, len, cpool);
/* 35 */     readParameterAnnotations(dis, cpool);
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 39 */     v.visitRuntimeVisibleParameterAnnotations(this);
/*    */   }
/*    */   
/*    */   public Attribute copy(ConstantPool constant_pool) {
/* 43 */     throw new RuntimeException("Not implemented yet!");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeVisParamAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */