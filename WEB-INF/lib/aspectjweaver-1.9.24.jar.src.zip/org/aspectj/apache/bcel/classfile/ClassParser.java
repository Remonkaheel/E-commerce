/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassParser
/*     */ {
/*     */   private DataInputStream file;
/*     */   private String filename;
/*     */   private int classnameIndex;
/*     */   private int superclassnameIndex;
/*     */   private int major;
/*     */   private int minor;
/*     */   private int accessflags;
/*     */   private int[] interfaceIndices;
/*     */   private ConstantPool cpool;
/*     */   private Field[] fields;
/*     */   private Method[] methods;
/*     */   private Attribute[] attributes;
/*     */   private static final int BUFSIZE = 8192;
/*     */   
/*     */   public ClassParser(InputStream file, String filename) {
/*  97 */     this.filename = filename;
/*  98 */     if (file instanceof DataInputStream) { this.file = (DataInputStream)file; }
/*  99 */     else { this.file = new DataInputStream(new BufferedInputStream(file, 8192)); }
/*     */   
/*     */   }
/*     */   public ClassParser(ByteArrayInputStream baos, String filename) {
/* 103 */     this.filename = filename;
/* 104 */     this.file = new DataInputStream(baos);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassParser(String file_name) throws IOException {
/* 109 */     this.filename = file_name;
/* 110 */     this.file = new DataInputStream(new BufferedInputStream(new FileInputStream(file_name), 8192));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass parse() throws IOException, ClassFormatException {
/* 123 */     readID();
/*     */ 
/*     */     
/* 126 */     readVersion();
/*     */ 
/*     */ 
/*     */     
/* 130 */     readConstantPool();
/*     */ 
/*     */     
/* 133 */     readClassInfo();
/*     */ 
/*     */     
/* 136 */     readInterfaces();
/*     */ 
/*     */ 
/*     */     
/* 140 */     readFields();
/*     */ 
/*     */     
/* 143 */     readMethods();
/*     */ 
/*     */     
/* 146 */     readAttributes();
/*     */ 
/*     */     
/* 149 */     this.file.close();
/*     */ 
/*     */     
/* 152 */     JavaClass jc = new JavaClass(this.classnameIndex, this.superclassnameIndex, this.filename, this.major, this.minor, this.accessflags, this.cpool, this.interfaceIndices, this.fields, this.methods, this.attributes);
/*     */ 
/*     */ 
/*     */     
/* 156 */     return jc;
/*     */   }
/*     */ 
/*     */   
/*     */   private final void readAttributes() {
/* 161 */     this.attributes = AttributeUtils.readAttributes(this.file, this.cpool);
/*     */   }
/*     */ 
/*     */   
/*     */   private final void readClassInfo() throws IOException {
/* 166 */     this.accessflags = this.file.readUnsignedShort();
/*     */ 
/*     */ 
/*     */     
/* 170 */     if ((this.accessflags & 0x200) != 0) {
/* 171 */       this.accessflags |= 0x400;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     this.classnameIndex = this.file.readUnsignedShort();
/* 179 */     this.superclassnameIndex = this.file.readUnsignedShort();
/*     */   }
/*     */   
/*     */   private final void readConstantPool() throws IOException {
/*     */     try {
/* 184 */       this.cpool = new ConstantPool(this.file);
/* 185 */     } catch (ClassFormatException cfe) {
/*     */       
/* 187 */       cfe.printStackTrace();
/* 188 */       if (this.filename != null) {
/* 189 */         String newmessage = "File: '" + this.filename + "': " + cfe.getMessage();
/* 190 */         throw new ClassFormatException(newmessage);
/*     */       } 
/* 192 */       throw cfe;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final void readFields() throws IOException, ClassFormatException {
/* 198 */     int fieldCount = this.file.readUnsignedShort();
/* 199 */     if (fieldCount == 0) {
/* 200 */       this.fields = Field.NoFields;
/*     */     } else {
/* 202 */       this.fields = new Field[fieldCount];
/* 203 */       for (int i = 0; i < fieldCount; i++) {
/* 204 */         this.fields[i] = new Field(this.file, this.cpool);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final void readID() throws IOException {
/* 211 */     int magic = -889275714;
/* 212 */     if (this.file.readInt() != magic)
/* 213 */       throw new ClassFormatException(this.filename + " is not a Java .class file"); 
/*     */   }
/*     */   
/* 216 */   private static final int[] NO_INTERFACES = new int[0];
/*     */ 
/*     */   
/*     */   private final void readInterfaces() throws IOException {
/* 220 */     int interfacesCount = this.file.readUnsignedShort();
/* 221 */     if (interfacesCount == 0) {
/* 222 */       this.interfaceIndices = NO_INTERFACES;
/*     */     } else {
/* 224 */       this.interfaceIndices = new int[interfacesCount];
/* 225 */       for (int i = 0; i < interfacesCount; i++) {
/* 226 */         this.interfaceIndices[i] = this.file.readUnsignedShort();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void readMethods() throws IOException {
/* 232 */     int methodsCount = this.file.readUnsignedShort();
/* 233 */     if (methodsCount == 0) {
/* 234 */       this.methods = Method.NoMethods;
/*     */     } else {
/* 236 */       this.methods = new Method[methodsCount];
/* 237 */       for (int i = 0; i < methodsCount; i++) {
/* 238 */         this.methods[i] = new Method(this.file, this.cpool);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void readVersion() throws IOException {
/* 244 */     this.minor = this.file.readUnsignedShort();
/* 245 */     this.major = this.file.readUnsignedShort();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ClassParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */