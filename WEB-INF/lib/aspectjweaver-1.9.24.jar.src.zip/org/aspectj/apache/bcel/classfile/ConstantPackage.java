/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantPackage
/*     */   extends Constant
/*     */ {
/*     */   private int nameIndex;
/*     */   
/*     */   ConstantPackage(DataInputStream file) throws IOException {
/*  74 */     this(file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public ConstantPackage(int nameIndex) {
/*  78 */     super((byte)20);
/*  79 */     this.nameIndex = nameIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  84 */     v.visitConstantPackage(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  89 */     file.writeByte(this.tag);
/*  90 */     file.writeShort(this.nameIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getValue() {
/*  95 */     return Integer.valueOf(this.nameIndex);
/*     */   }
/*     */   
/*     */   public final int getNameIndex() {
/*  99 */     return this.nameIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 104 */     return super.toString() + "(name_index = " + this.nameIndex + ")";
/*     */   }
/*     */   
/*     */   public String getPackageName(ConstantPool cpool) {
/* 108 */     Constant c = cpool.getConstant(this.nameIndex, (byte)1);
/* 109 */     return ((ConstantUtf8)c).getValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */