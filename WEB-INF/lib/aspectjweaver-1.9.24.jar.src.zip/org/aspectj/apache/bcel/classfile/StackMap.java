/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackMap
/*     */   extends Attribute
/*     */ {
/*     */   private int map_length;
/*     */   private StackMapEntry[] map;
/*     */   
/*     */   public StackMap(int name_index, int length, StackMapEntry[] map, ConstantPool constant_pool) {
/*  88 */     super((byte)11, name_index, length, constant_pool);
/*     */     
/*  90 */     setStackMap(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StackMap(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 103 */     this(name_index, length, (StackMapEntry[])null, constant_pool);
/*     */     
/* 105 */     this.map_length = file.readUnsignedShort();
/* 106 */     this.map = new StackMapEntry[this.map_length];
/*     */     
/* 108 */     for (int i = 0; i < this.map_length; i++) {
/* 109 */       this.map[i] = new StackMapEntry(file, constant_pool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 120 */     super.dump(file);
/* 121 */     file.writeShort(this.map_length);
/* 122 */     for (int i = 0; i < this.map_length; i++) {
/* 123 */       this.map[i].dump(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final StackMapEntry[] getStackMap() {
/* 130 */     return this.map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setStackMap(StackMapEntry[] map) {
/* 137 */     this.map = map;
/*     */     
/* 139 */     this.map_length = (map == null) ? 0 : map.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 147 */     StringBuilder buf = new StringBuilder("StackMap(");
/*     */     
/* 149 */     for (int i = 0; i < this.map_length; i++) {
/* 150 */       buf.append(this.map[i].toString());
/*     */       
/* 152 */       if (i < this.map_length - 1) {
/* 153 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 156 */     buf.append(')');
/*     */     
/* 158 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 184 */     v.visitStackMap(this);
/*     */   }
/*     */   
/*     */   public final int getMapLength() {
/* 188 */     return this.map_length;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\StackMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */