/*    */ package org.aspectj.apache.bcel.classfile.annotation;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*    */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*    */ import org.aspectj.apache.bcel.generic.ObjectType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassElementValue
/*    */   extends ElementValue
/*    */ {
/*    */   private int idx;
/*    */   
/*    */   protected ClassElementValue(int typeIdx, ConstantPool cpool) {
/* 29 */     super(99, cpool);
/* 30 */     this.idx = typeIdx;
/*    */   }
/*    */   
/*    */   public ClassElementValue(ObjectType t, ConstantPool cpool) {
/* 34 */     super(99, cpool);
/*    */     
/* 36 */     this.idx = cpool.addUtf8(t.getSignature());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClassElementValue(ClassElementValue value, ConstantPool cpool, boolean copyPoolEntries) {
/* 46 */     super(99, cpool);
/* 47 */     if (copyPoolEntries) {
/*    */       
/* 49 */       this.idx = cpool.addUtf8(value.getClassString());
/*    */     } else {
/* 51 */       this.idx = value.getIndex();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIndex() {
/* 57 */     return this.idx;
/*    */   }
/*    */   
/*    */   public String getClassString() {
/* 61 */     ConstantUtf8 cu8 = (ConstantUtf8)getConstantPool().getConstant(this.idx);
/* 62 */     return cu8.getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String stringifyValue() {
/* 70 */     return getClassString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void dump(DataOutputStream dos) throws IOException {
/* 75 */     dos.writeByte(this.type);
/* 76 */     dos.writeShort(this.idx);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\ClassElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */