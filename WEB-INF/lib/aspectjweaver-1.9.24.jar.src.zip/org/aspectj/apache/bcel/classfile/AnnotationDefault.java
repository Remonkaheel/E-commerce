/*    */ package org.aspectj.apache.bcel.classfile;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.aspectj.apache.bcel.classfile.annotation.ElementValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationDefault
/*    */   extends Attribute
/*    */ {
/*    */   private ElementValue value;
/*    */   
/*    */   public AnnotationDefault(int nameIndex, int len, DataInputStream dis, ConstantPool cpool) throws IOException {
/* 31 */     this(nameIndex, len, ElementValue.readElementValue(dis, cpool), cpool);
/*    */   }
/*    */   
/*    */   private AnnotationDefault(int nameIndex, int len, ElementValue value, ConstantPool cpool) {
/* 35 */     super((byte)18, nameIndex, len, cpool);
/* 36 */     this.value = value;
/*    */   }
/*    */   
/*    */   public Attribute copy(ConstantPool constant_pool) {
/* 40 */     throw new RuntimeException("Not implemented yet!");
/*    */   }
/*    */ 
/*    */   
/*    */   public final ElementValue getElementValue() {
/* 45 */     return this.value;
/*    */   }
/*    */   public final void dump(DataOutputStream dos) throws IOException {
/* 48 */     super.dump(dos);
/* 49 */     this.value.dump(dos);
/*    */   }
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 53 */     v.visitAnnotationDefault(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\AnnotationDefault.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */