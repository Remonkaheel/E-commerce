/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Deprecated
/*     */   extends Attribute
/*     */ {
/*     */   private byte[] bytes;
/*     */   
/*     */   public Deprecated(Deprecated c) {
/*  79 */     this(c.getNameIndex(), c.getLength(), c.getBytes(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Deprecated(int name_index, int length, byte[] bytes, ConstantPool constant_pool) {
/*  89 */     super((byte)8, name_index, length, constant_pool);
/*  90 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deprecated(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 103 */     this(name_index, length, (byte[])null, constant_pool);
/*     */     
/* 105 */     if (length > 0) {
/* 106 */       this.bytes = new byte[length];
/* 107 */       file.readFully(this.bytes);
/* 108 */       System.err.println("Deprecated attribute with length > 0");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 120 */     v.visitDeprecated(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 131 */     super.dump(file);
/*     */     
/* 133 */     if (this.length > 0) {
/* 134 */       file.write(this.bytes, 0, this.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getBytes() {
/* 141 */     return this.bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBytes(byte[] bytes) {
/* 148 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 156 */     return Constants.ATTRIBUTE_NAMES[8];
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Deprecated.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */