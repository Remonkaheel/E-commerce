package org.aspectj.apache.bcel.classfile;

import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisAnnos;
import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisParamAnnos;
import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisTypeAnnos;
import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisAnnos;
import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisParamAnnos;
import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisTypeAnnos;

public interface ClassVisitor {
  void visitCode(Code paramCode);
  
  void visitCodeException(CodeException paramCodeException);
  
  void visitConstantClass(ConstantClass paramConstantClass);
  
  void visitConstantDouble(ConstantDouble paramConstantDouble);
  
  void visitConstantFieldref(ConstantFieldref paramConstantFieldref);
  
  void visitConstantFloat(ConstantFloat paramConstantFloat);
  
  void visitConstantInteger(ConstantInteger paramConstantInteger);
  
  void visitConstantInterfaceMethodref(ConstantInterfaceMethodref paramConstantInterfaceMethodref);
  
  void visitConstantLong(ConstantLong paramConstantLong);
  
  void visitConstantMethodref(ConstantMethodref paramConstantMethodref);
  
  void visitConstantMethodHandle(ConstantMethodHandle paramConstantMethodHandle);
  
  void visitConstantNameAndType(ConstantNameAndType paramConstantNameAndType);
  
  void visitConstantMethodType(ConstantMethodType paramConstantMethodType);
  
  void visitConstantInvokeDynamic(ConstantInvokeDynamic paramConstantInvokeDynamic);
  
  void visitConstantDynamic(ConstantDynamic paramConstantDynamic);
  
  void visitConstantPool(ConstantPool paramConstantPool);
  
  void visitConstantString(ConstantString paramConstantString);
  
  void visitConstantModule(ConstantModule paramConstantModule);
  
  void visitConstantPackage(ConstantPackage paramConstantPackage);
  
  void visitConstantUtf8(ConstantUtf8 paramConstantUtf8);
  
  void visitConstantValue(ConstantValue paramConstantValue);
  
  void visitDeprecated(Deprecated paramDeprecated);
  
  void visitExceptionTable(ExceptionTable paramExceptionTable);
  
  void visitField(Field paramField);
  
  void visitInnerClass(InnerClass paramInnerClass);
  
  void visitInnerClasses(InnerClasses paramInnerClasses);
  
  void visitJavaClass(JavaClass paramJavaClass);
  
  void visitLineNumber(LineNumber paramLineNumber);
  
  void visitLineNumberTable(LineNumberTable paramLineNumberTable);
  
  void visitLocalVariable(LocalVariable paramLocalVariable);
  
  void visitLocalVariableTable(LocalVariableTable paramLocalVariableTable);
  
  void visitMethod(Method paramMethod);
  
  void visitSignature(Signature paramSignature);
  
  void visitSourceFile(SourceFile paramSourceFile);
  
  void visitSynthetic(Synthetic paramSynthetic);
  
  void visitBootstrapMethods(BootstrapMethods paramBootstrapMethods);
  
  void visitUnknown(Unknown paramUnknown);
  
  void visitStackMap(StackMap paramStackMap);
  
  void visitStackMapEntry(StackMapEntry paramStackMapEntry);
  
  void visitEnclosingMethod(EnclosingMethod paramEnclosingMethod);
  
  void visitRuntimeVisibleAnnotations(RuntimeVisAnnos paramRuntimeVisAnnos);
  
  void visitRuntimeInvisibleAnnotations(RuntimeInvisAnnos paramRuntimeInvisAnnos);
  
  void visitRuntimeVisibleParameterAnnotations(RuntimeVisParamAnnos paramRuntimeVisParamAnnos);
  
  void visitRuntimeInvisibleParameterAnnotations(RuntimeInvisParamAnnos paramRuntimeInvisParamAnnos);
  
  void visitRuntimeVisibleTypeAnnotations(RuntimeVisTypeAnnos paramRuntimeVisTypeAnnos);
  
  void visitRuntimeInvisibleTypeAnnotations(RuntimeInvisTypeAnnos paramRuntimeInvisTypeAnnos);
  
  void visitAnnotationDefault(AnnotationDefault paramAnnotationDefault);
  
  void visitLocalVariableTypeTable(LocalVariableTypeTable paramLocalVariableTypeTable);
  
  void visitMethodParameters(MethodParameters paramMethodParameters);
  
  void visitModule(Module paramModule);
  
  void visitModulePackages(ModulePackages paramModulePackages);
  
  void visitModuleMainClass(ModuleMainClass paramModuleMainClass);
  
  void visitNestHost(NestHost paramNestHost);
  
  void visitNestMembers(NestMembers paramNestMembers);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ClassVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */