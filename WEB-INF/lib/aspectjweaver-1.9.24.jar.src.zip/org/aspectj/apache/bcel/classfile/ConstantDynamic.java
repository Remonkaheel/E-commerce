/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantDynamic
/*     */   extends Constant
/*     */ {
/*     */   private final int bootstrapMethodAttrIndex;
/*     */   private final int nameAndTypeIndex;
/*     */   
/*     */   ConstantDynamic(DataInputStream file) throws IOException {
/*  77 */     this(file.readUnsignedShort(), file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public ConstantDynamic(int readUnsignedShort, int nameAndTypeIndex) {
/*  81 */     super((byte)17);
/*  82 */     this.bootstrapMethodAttrIndex = readUnsignedShort;
/*  83 */     this.nameAndTypeIndex = nameAndTypeIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  88 */     file.writeByte(this.tag);
/*  89 */     file.writeShort(this.bootstrapMethodAttrIndex);
/*  90 */     file.writeShort(this.nameAndTypeIndex);
/*     */   }
/*     */   
/*     */   public final int getNameAndTypeIndex() {
/*  94 */     return this.nameAndTypeIndex;
/*     */   }
/*     */   
/*     */   public final int getBootstrapMethodAttrIndex() {
/*  98 */     return this.bootstrapMethodAttrIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 103 */     return super.toString() + "(bootstrapMethodAttrIndex=" + this.bootstrapMethodAttrIndex + ",nameAndTypeIndex=" + this.nameAndTypeIndex + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 108 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 113 */     v.visitConstantDynamic(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantDynamic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */