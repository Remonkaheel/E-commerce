/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NestHost
/*     */   extends Attribute
/*     */ {
/*     */   private int hostClassIndex;
/*     */   
/*     */   public NestHost(NestHost c) {
/*  72 */     this(c.getNameIndex(), c.getLength(), c.getHostClassIndex(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public NestHost(int nameIndex, int length, int hostClassIndex, ConstantPool cp) {
/*  76 */     super((byte)27, nameIndex, length, cp);
/*  77 */     this.hostClassIndex = hostClassIndex;
/*     */   }
/*     */   
/*     */   NestHost(int nameIndex, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  81 */     this(nameIndex, length, 0, constant_pool);
/*  82 */     this.hostClassIndex = file.readUnsignedShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  87 */     v.visitNestHost(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  92 */     super.dump(file);
/*  93 */     file.writeShort(this.hostClassIndex);
/*     */   }
/*     */   
/*     */   public final int getHostClassIndex() {
/*  97 */     return this.hostClassIndex;
/*     */   }
/*     */   
/*     */   public final void setHostClassIndex(int hostClassIndex) {
/* 101 */     this.hostClassIndex = hostClassIndex;
/*     */   }
/*     */   
/*     */   public final String getHostClassName() {
/* 105 */     ConstantClass constantClass = (ConstantClass)this.cpool.getConstant(this.hostClassIndex, (byte)7);
/* 106 */     return constantClass.getClassname(this.cpool);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 111 */     StringBuilder buf = new StringBuilder();
/* 112 */     buf.append("NestHost(");
/* 113 */     ConstantClass constantClass = (ConstantClass)this.cpool.getConstant(this.hostClassIndex, (byte)7);
/* 114 */     buf.append(constantClass.getClassname(this.cpool));
/* 115 */     buf.append(")");
/* 116 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\NestHost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */