/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BootstrapMethods
/*     */   extends Attribute
/*     */ {
/*     */   private boolean isInPackedState = false;
/*     */   private byte[] data;
/*     */   private int numBootstrapMethods;
/*     */   private BootstrapMethod[] bootstrapMethods;
/*     */   
/*     */   public BootstrapMethods(BootstrapMethods c) {
/*  79 */     this(c.getNameIndex(), c.getLength(), c.getBootstrapMethods(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public BootstrapMethods(int nameIndex, int length, BootstrapMethod[] lineNumberTable, ConstantPool constantPool) {
/*  83 */     super((byte)19, nameIndex, length, constantPool);
/*  84 */     setBootstrapMethods(lineNumberTable);
/*  85 */     this.isInPackedState = false;
/*     */   }
/*     */   
/*     */   public final void setBootstrapMethods(BootstrapMethod[] bootstrapMethods) {
/*  89 */     this.data = null;
/*  90 */     this.isInPackedState = false;
/*  91 */     this.bootstrapMethods = bootstrapMethods;
/*  92 */     this.numBootstrapMethods = (bootstrapMethods == null) ? 0 : bootstrapMethods.length;
/*     */   }
/*     */   
/*     */   BootstrapMethods(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  96 */     this(name_index, length, (BootstrapMethod[])null, constant_pool);
/*  97 */     this.data = new byte[length];
/*  98 */     file.readFully(this.data);
/*  99 */     this.isInPackedState = true;
/*     */   }
/*     */   
/*     */   public static class BootstrapMethod {
/*     */     private int bootstrapMethodRef;
/*     */     private int[] bootstrapArguments;
/*     */     
/*     */     BootstrapMethod(DataInputStream file) throws IOException {
/* 107 */       this(file.readUnsignedShort(), readBootstrapArguments(file));
/*     */     }
/*     */     
/*     */     private static int[] readBootstrapArguments(DataInputStream dis) throws IOException {
/* 111 */       int numBootstrapMethods = dis.readUnsignedShort();
/* 112 */       int[] bootstrapArguments = new int[numBootstrapMethods];
/* 113 */       for (int i = 0; i < numBootstrapMethods; i++) {
/* 114 */         bootstrapArguments[i] = dis.readUnsignedShort();
/*     */       }
/* 116 */       return bootstrapArguments;
/*     */     }
/*     */     
/*     */     public BootstrapMethod(int bootstrapMethodRef, int[] bootstrapArguments) {
/* 120 */       this.bootstrapMethodRef = bootstrapMethodRef;
/* 121 */       this.bootstrapArguments = bootstrapArguments;
/*     */     }
/*     */     
/*     */     public int getBootstrapMethodRef() {
/* 125 */       return this.bootstrapMethodRef;
/*     */     }
/*     */     
/*     */     public int[] getBootstrapArguments() {
/* 129 */       return this.bootstrapArguments;
/*     */     }
/*     */     
/*     */     public final void dump(DataOutputStream file) throws IOException {
/* 133 */       file.writeShort(this.bootstrapMethodRef);
/* 134 */       int len = this.bootstrapArguments.length;
/* 135 */       file.writeShort(len);
/* 136 */       for (int bootstrapArgument : this.bootstrapArguments) {
/* 137 */         file.writeShort(bootstrapArgument);
/*     */       }
/*     */     }
/*     */     
/*     */     public final int getLength() {
/* 142 */       return 4 + 2 * this.bootstrapArguments.length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unpack() {
/* 151 */     if (this.isInPackedState) {
/*     */       try {
/* 153 */         ByteArrayInputStream bs = new ByteArrayInputStream(this.data);
/* 154 */         DataInputStream dis = new DataInputStream(bs);
/* 155 */         this.numBootstrapMethods = dis.readUnsignedShort();
/* 156 */         this.bootstrapMethods = new BootstrapMethod[this.numBootstrapMethods];
/* 157 */         for (int i = 0; i < this.numBootstrapMethods; i++) {
/* 158 */           this.bootstrapMethods[i] = new BootstrapMethod(dis);
/*     */         }
/* 160 */         dis.close();
/* 161 */         this.data = null;
/* 162 */       } catch (IOException e) {
/* 163 */         throw new RuntimeException("Unpacking of LineNumberTable attribute failed");
/*     */       } 
/* 165 */       this.isInPackedState = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 177 */     unpack();
/* 178 */     v.visitBootstrapMethods(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 189 */     super.dump(file);
/* 190 */     if (this.isInPackedState) {
/* 191 */       file.write(this.data);
/*     */     } else {
/* 193 */       int blen = this.bootstrapMethods.length;
/* 194 */       file.writeShort(blen);
/* 195 */       for (BootstrapMethod bootstrapMethod : this.bootstrapMethods) {
/* 196 */         bootstrapMethod.dump(file);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public final BootstrapMethod[] getBootstrapMethods() {
/* 202 */     unpack();
/* 203 */     return this.bootstrapMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 212 */     unpack();
/* 213 */     StringBuilder buf = new StringBuilder();
/* 214 */     StringBuilder line = new StringBuilder();
/*     */     
/* 216 */     for (int i = 0; i < this.numBootstrapMethods; i++) {
/* 217 */       BootstrapMethod bm = this.bootstrapMethods[i];
/* 218 */       line.append("BootstrapMethod[").append(i).append("]:");
/* 219 */       int ref = bm.getBootstrapMethodRef();
/* 220 */       ConstantMethodHandle mh = (ConstantMethodHandle)getConstantPool().getConstant(ref);
/* 221 */       line.append("#" + ref + ":");
/* 222 */       line.append(ConstantMethodHandle.kindToString(mh.getReferenceKind()));
/* 223 */       line.append(" ").append(getConstantPool().getConstant(mh.getReferenceIndex()));
/* 224 */       int[] args = bm.getBootstrapArguments();
/* 225 */       line.append(" argcount:").append((args == null) ? 0 : args.length).append(" ");
/* 226 */       if (args != null) {
/* 227 */         for (int arg : args) {
/* 228 */           line.append(arg).append("(").append(getConstantPool().getConstant(arg)).append(") ");
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 233 */       if (i < this.numBootstrapMethods - 1) {
/* 234 */         line.append(", ");
/*     */       }
/*     */       
/* 237 */       if (line.length() > 72) {
/* 238 */         line.append('\n');
/* 239 */         buf.append(line);
/* 240 */         line.setLength(0);
/*     */       } 
/*     */     } 
/*     */     
/* 244 */     buf.append(line);
/*     */     
/* 246 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNumBootstrapMethods() {
/* 265 */     unpack();
/* 266 */     return this.bootstrapMethods.length;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\BootstrapMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */