/*      */ package org.aspectj.apache.bcel.classfile;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import org.aspectj.apache.bcel.Constants;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeAnnos;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisAnnos;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisParamAnnos;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeParamAnnos;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisAnnos;
/*      */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisParamAnnos;
/*      */ import org.aspectj.apache.bcel.generic.Type;
/*      */ import org.aspectj.apache.bcel.util.ByteSequence;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Utility
/*      */ {
/*      */   private static boolean wide = false;
/*      */   
/*      */   public static final String accessToString(int access_flags) {
/*   99 */     return accessToString(access_flags, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String accessToString(int access_flags, boolean for_class) {
/*  113 */     StringBuilder buf = new StringBuilder();
/*      */     
/*  115 */     int p = 0;
/*  116 */     for (int i = 0; p < 2048; i++) {
/*  117 */       p = pow2(i);
/*  118 */       if ((access_flags & p) != 0)
/*      */       {
/*  120 */         if (!for_class || (p != 32 && p != 512))
/*      */         {
/*      */           
/*  123 */           buf.append(Constants.ACCESS_NAMES[i]).append(" "); } 
/*      */       }
/*      */     } 
/*  126 */     return buf.toString().trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String classOrInterface(int access_flags) {
/*  133 */     return ((access_flags & 0x200) != 0) ? "interface" : "class";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String codeToString(byte[] code, ConstantPool constant_pool, int index, int length, boolean verbose) {
/*  148 */     StringBuilder buf = new StringBuilder(code.length * 20);
/*  149 */     ByteSequence stream = new ByteSequence(code);
/*      */     try {
/*      */       int i;
/*  152 */       for (i = 0; i < index; i++)
/*      */       {
/*  154 */         codeToString(stream, constant_pool, verbose);
/*      */       }
/*      */       
/*  157 */       for (i = 0; stream.available() > 0; i++) {
/*  158 */         if (length < 0 || i < length) {
/*  159 */           String indices = fillup(stream.getIndex() + ":", 6, true, ' ');
/*  160 */           buf.append(indices + codeToString(stream, constant_pool, verbose) + '\n');
/*      */         } 
/*      */       } 
/*  163 */     } catch (IOException e) {
/*  164 */       System.out.println(buf.toString());
/*  165 */       e.printStackTrace();
/*  166 */       throw new ClassFormatException("Byte code error: " + e);
/*      */     } 
/*      */     
/*  169 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String codeToString(byte[] code, ConstantPool constant_pool, int index, int length) {
/*  176 */     return codeToString(code, constant_pool, index, length, true);
/*      */   }
/*      */   
/*      */   public static final String codeToString(ByteSequence bytes, ConstantPool constant_pool) throws IOException {
/*  180 */     return codeToString(bytes, constant_pool, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String compactClassName(String str) {
/*  190 */     return compactClassName(str, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String compactClassName(String str, String prefix, boolean chopit) {
/*  203 */     str = str.replace('/', '.');
/*  204 */     if (chopit) {
/*  205 */       int len = prefix.length();
/*      */       
/*  207 */       if (str.startsWith(prefix)) {
/*  208 */         String result = str.substring(len);
/*  209 */         if (result.indexOf('.') == -1) {
/*  210 */           str = result;
/*      */         }
/*      */       } 
/*      */     } 
/*  214 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String compactClassName(String str, boolean chopit) {
/*  226 */     return compactClassName(str, "java.lang.", chopit);
/*      */   }
/*      */   
/*      */   public static final String methodSignatureToString(String signature, String name, String access) {
/*  230 */     return methodSignatureToString(signature, name, access, true);
/*      */   }
/*      */   
/*      */   public static final String methodSignatureToString(String signature, String name, String access, boolean chopit) {
/*  234 */     return methodSignatureToString(signature, name, access, chopit, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String methodSignatureToString(String signature, String name, String access, boolean chopit, LocalVariableTable vars) throws ClassFormatException {
/*      */     String type;
/*  243 */     StringBuilder buf = new StringBuilder("(");
/*      */ 
/*      */     
/*  246 */     int var_index = access.contains("static") ? 0 : 1;
/*      */     
/*      */     try {
/*  249 */       if (signature.charAt(0) != '(') {
/*  250 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*      */       }
/*      */       
/*  253 */       int index = 1;
/*      */       
/*  255 */       while (signature.charAt(index) != ')') {
/*  256 */         ResultHolder rh = signatureToStringInternal(signature.substring(index), chopit);
/*  257 */         String param_type = rh.getResult();
/*  258 */         buf.append(param_type);
/*      */         
/*  260 */         if (vars != null) {
/*  261 */           LocalVariable l = vars.getLocalVariable(var_index);
/*      */           
/*  263 */           if (l != null) {
/*  264 */             buf.append(" " + l.getName());
/*      */           }
/*      */         } else {
/*  267 */           buf.append(" arg" + var_index);
/*      */         } 
/*      */         
/*  270 */         if ("double".equals(param_type) || "long".equals(param_type)) {
/*  271 */           var_index += 2;
/*      */         } else {
/*  273 */           var_index++;
/*      */         } 
/*      */         
/*  276 */         buf.append(", ");
/*  277 */         index += rh.getConsumedChars();
/*      */       } 
/*      */       
/*  280 */       index++;
/*      */ 
/*      */       
/*  283 */       type = signatureToString(signature.substring(index), chopit);
/*      */     }
/*  285 */     catch (StringIndexOutOfBoundsException e) {
/*  286 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */     
/*  289 */     if (buf.length() > 1) {
/*  290 */       buf.setLength(buf.length() - 2);
/*      */     }
/*      */     
/*  293 */     buf.append(")");
/*      */     
/*  295 */     return access + ((access.length() > 0) ? " " : "") + type + " " + name + buf
/*  296 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String replace(String str, String old, String new_) {
/*  309 */     StringBuilder buf = new StringBuilder();
/*      */     
/*      */     try {
/*  312 */       int index = str.indexOf(old);
/*  313 */       if (index != -1) {
/*  314 */         int old_index = 0;
/*      */ 
/*      */         
/*  317 */         while ((index = str.indexOf(old, old_index)) != -1) {
/*  318 */           buf.append(str.substring(old_index, index));
/*  319 */           buf.append(new_);
/*  320 */           old_index = index + old.length();
/*      */         } 
/*      */         
/*  323 */         buf.append(str.substring(old_index));
/*  324 */         str = buf.toString();
/*      */       } 
/*  326 */     } catch (StringIndexOutOfBoundsException e) {
/*  327 */       System.err.println(e);
/*      */     } 
/*      */     
/*  330 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String signatureToString(String signature) {
/*  340 */     return signatureToString(signature, true);
/*      */   }
/*      */   
/*      */   public static final String signatureToString(String signature, boolean chopit) {
/*  344 */     ResultHolder rh = signatureToStringInternal(signature, chopit);
/*  345 */     return rh.getResult();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultHolder signatureToStringInternal(String signature, boolean chopit) {
/*  353 */     int processedChars = 1; try {
/*      */       int index; StringBuilder brackets; int genericStart; int consumedChars; ResultHolder retval; int n; ResultHolder restOfIt;
/*  355 */       switch (signature.charAt(0)) {
/*      */         case 'B':
/*  357 */           return ResultHolder.BYTE;
/*      */         case 'C':
/*  359 */           return ResultHolder.CHAR;
/*      */         case 'D':
/*  361 */           return ResultHolder.DOUBLE;
/*      */         case 'F':
/*  363 */           return ResultHolder.FLOAT;
/*      */         case 'I':
/*  365 */           return ResultHolder.INT;
/*      */         case 'J':
/*  367 */           return ResultHolder.LONG;
/*      */         case 'L':
/*  369 */           index = signature.indexOf(';');
/*      */           
/*  371 */           if (index < 0) {
/*  372 */             throw new ClassFormatException("Invalid signature: " + signature);
/*      */           }
/*      */           
/*  375 */           if (signature.length() > index + 1 && signature.charAt(index + 1) == '>') {
/*  376 */             index += 2;
/*      */           }
/*      */           
/*  379 */           genericStart = signature.indexOf('<');
/*  380 */           if (genericStart != -1) {
/*  381 */             int genericEnd = signature.indexOf('>');
/*      */             
/*  383 */             ResultHolder rh = signatureToStringInternal(signature.substring(genericStart + 1, genericEnd), chopit);
/*  384 */             StringBuilder sb = new StringBuilder();
/*  385 */             sb.append(signature.substring(1, genericStart));
/*  386 */             sb.append("<").append(rh.getResult()).append(">");
/*  387 */             ResultHolder resultHolder1 = new ResultHolder(compactClassName(sb.toString(), chopit), genericEnd + 1);
/*  388 */             return resultHolder1;
/*      */           } 
/*  390 */           processedChars = index + 1;
/*  391 */           retval = new ResultHolder(compactClassName(signature.substring(1, index), chopit), processedChars);
/*  392 */           return retval;
/*      */ 
/*      */ 
/*      */         
/*      */         case 'S':
/*  397 */           return ResultHolder.SHORT;
/*      */         case 'Z':
/*  399 */           return ResultHolder.BOOLEAN;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case '[':
/*  405 */           brackets = new StringBuilder();
/*      */           
/*  407 */           for (n = 0; signature.charAt(n) == '['; n++) {
/*  408 */             brackets.append("[]");
/*      */           }
/*  410 */           consumedChars = n;
/*  411 */           restOfIt = signatureToStringInternal(signature.substring(n), chopit);
/*  412 */           consumedChars += restOfIt.getConsumedChars();
/*  413 */           brackets.insert(0, restOfIt.getResult());
/*  414 */           return new ResultHolder(brackets.toString(), consumedChars);
/*      */         
/*      */         case 'V':
/*  417 */           return ResultHolder.VOID;
/*      */       } 
/*      */       
/*  420 */       throw new ClassFormatException("Invalid signature: `" + signature + "'");
/*      */     }
/*  422 */     catch (StringIndexOutOfBoundsException e) {
/*  423 */       throw new ClassFormatException("Invalid signature: " + e + ":" + signature);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte typeOfMethodSignature(String signature) throws ClassFormatException {
/*      */     try {
/*  437 */       if (signature.charAt(0) != '(') {
/*  438 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*      */       }
/*  440 */       int index = signature.lastIndexOf(')') + 1;
/*  441 */       return typeOfSignature(signature.substring(index));
/*  442 */     } catch (StringIndexOutOfBoundsException e) {
/*  443 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final short byteToShort(byte b) {
/*  451 */     return (b < 0) ? (short)(256 + b) : (short)b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String toHexString(byte[] bytes) {
/*  460 */     StringBuilder buf = new StringBuilder();
/*      */     
/*  462 */     for (int i = 0; i < bytes.length; i++) {
/*  463 */       short b = byteToShort(bytes[i]);
/*  464 */       String hex = Integer.toString(b, 16);
/*      */ 
/*      */       
/*  467 */       if (b < 16) {
/*  468 */         buf.append('0');
/*      */       }
/*      */       
/*  471 */       buf.append(hex);
/*      */       
/*  473 */       if (i < bytes.length - 1) {
/*  474 */         buf.append(' ');
/*      */       }
/*      */     } 
/*      */     
/*  478 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String format(int i, int length, boolean left_justify, char fill) {
/*  491 */     return fillup(Integer.toString(i), length, left_justify, fill);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String fillup(String str, int length, boolean left_justify, char fill) {
/*  504 */     int len = length - str.length();
/*  505 */     char[] buf = new char[(len < 0) ? 0 : len];
/*      */     
/*  507 */     for (int j = 0; j < buf.length; j++) {
/*  508 */       buf[j] = fill;
/*      */     }
/*      */     
/*  511 */     if (left_justify) {
/*  512 */       return str + new String(buf);
/*      */     }
/*  514 */     return new String(buf) + str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String convertString(String label) {
/*  522 */     char[] ch = label.toCharArray();
/*  523 */     StringBuilder buf = new StringBuilder();
/*      */     
/*  525 */     for (char c : ch) {
/*  526 */       switch (c) {
/*      */         case '\n':
/*  528 */           buf.append("\\n");
/*      */           break;
/*      */         case '\r':
/*  531 */           buf.append("\\r");
/*      */           break;
/*      */         case '"':
/*  534 */           buf.append("\\\"");
/*      */           break;
/*      */         case '\'':
/*  537 */           buf.append("\\'");
/*      */           break;
/*      */         case '\\':
/*  540 */           buf.append("\\\\");
/*      */           break;
/*      */         default:
/*  543 */           buf.append(c);
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/*  548 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection<RuntimeAnnos> getAnnotationAttributes(ConstantPool cp, List<AnnotationGen> annotations) {
/*  559 */     if (annotations.size() == 0) {
/*  560 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  564 */       int countVisible = 0;
/*  565 */       int countInvisible = 0;
/*      */ 
/*      */       
/*  568 */       for (AnnotationGen a : annotations) {
/*  569 */         if (a.isRuntimeVisible()) {
/*  570 */           countVisible++; continue;
/*      */         } 
/*  572 */         countInvisible++;
/*      */       } 
/*      */ 
/*      */       
/*  576 */       ByteArrayOutputStream rvaBytes = new ByteArrayOutputStream();
/*  577 */       ByteArrayOutputStream riaBytes = new ByteArrayOutputStream();
/*  578 */       DataOutputStream rvaDos = new DataOutputStream(rvaBytes);
/*  579 */       DataOutputStream riaDos = new DataOutputStream(riaBytes);
/*      */       
/*  581 */       rvaDos.writeShort(countVisible);
/*  582 */       riaDos.writeShort(countInvisible);
/*      */ 
/*      */       
/*  585 */       for (AnnotationGen a : annotations) {
/*  586 */         if (a.isRuntimeVisible()) {
/*  587 */           a.dump(rvaDos); continue;
/*      */         } 
/*  589 */         a.dump(riaDos);
/*      */       } 
/*      */ 
/*      */       
/*  593 */       rvaDos.close();
/*  594 */       riaDos.close();
/*      */       
/*  596 */       byte[] rvaData = rvaBytes.toByteArray();
/*  597 */       byte[] riaData = riaBytes.toByteArray();
/*      */       
/*  599 */       int rvaIndex = -1;
/*  600 */       int riaIndex = -1;
/*      */       
/*  602 */       if (rvaData.length > 2) {
/*  603 */         rvaIndex = cp.addUtf8("RuntimeVisibleAnnotations");
/*      */       }
/*  605 */       if (riaData.length > 2) {
/*  606 */         riaIndex = cp.addUtf8("RuntimeInvisibleAnnotations");
/*      */       }
/*      */       
/*  609 */       List<RuntimeAnnos> newAttributes = new ArrayList<>();
/*  610 */       if (rvaData.length > 2) {
/*  611 */         newAttributes.add(new RuntimeVisAnnos(rvaIndex, rvaData.length, rvaData, cp));
/*      */       }
/*  613 */       if (riaData.length > 2) {
/*  614 */         newAttributes.add(new RuntimeInvisAnnos(riaIndex, riaData.length, riaData, cp));
/*      */       }
/*      */       
/*  617 */       return newAttributes;
/*  618 */     } catch (IOException e) {
/*  619 */       System.err.println("IOException whilst processing annotations");
/*  620 */       e.printStackTrace();
/*      */       
/*  622 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attribute[] getParameterAnnotationAttributes(ConstantPool cp, List<AnnotationGen>[] vec) {
/*  632 */     int[] visCount = new int[vec.length];
/*  633 */     int totalVisCount = 0;
/*  634 */     int[] invisCount = new int[vec.length];
/*  635 */     int totalInvisCount = 0;
/*      */     
/*      */     try {
/*  638 */       for (int i = 0; i < vec.length; i++) {
/*  639 */         List<AnnotationGen> l = vec[i];
/*  640 */         if (l != null) {
/*  641 */           for (AnnotationGen element : l) {
/*  642 */             if (element.isRuntimeVisible()) {
/*  643 */               visCount[i] = visCount[i] + 1;
/*  644 */               totalVisCount++; continue;
/*      */             } 
/*  646 */             invisCount[i] = invisCount[i] + 1;
/*  647 */             totalInvisCount++;
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  654 */       ByteArrayOutputStream rvaBytes = new ByteArrayOutputStream();
/*  655 */       DataOutputStream rvaDos = new DataOutputStream(rvaBytes);
/*  656 */       rvaDos.writeByte(vec.length);
/*      */       
/*  658 */       for (int j = 0; j < vec.length; j++) {
/*  659 */         rvaDos.writeShort(visCount[j]);
/*  660 */         if (visCount[j] > 0) {
/*  661 */           List<AnnotationGen> l = vec[j];
/*  662 */           for (AnnotationGen element : l) {
/*  663 */             if (element.isRuntimeVisible()) {
/*  664 */               element.dump(rvaDos);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*  669 */       rvaDos.close();
/*      */ 
/*      */       
/*  672 */       ByteArrayOutputStream riaBytes = new ByteArrayOutputStream();
/*  673 */       DataOutputStream riaDos = new DataOutputStream(riaBytes);
/*  674 */       riaDos.writeByte(vec.length);
/*      */       
/*  676 */       for (int k = 0; k < vec.length; k++) {
/*  677 */         riaDos.writeShort(invisCount[k]);
/*  678 */         if (invisCount[k] > 0) {
/*  679 */           List<AnnotationGen> l = vec[k];
/*  680 */           for (AnnotationGen element : l) {
/*  681 */             if (!element.isRuntimeVisible()) {
/*  682 */               element.dump(riaDos);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*  687 */       riaDos.close();
/*      */       
/*  689 */       byte[] rvaData = rvaBytes.toByteArray();
/*  690 */       byte[] riaData = riaBytes.toByteArray();
/*      */       
/*  692 */       int rvaIndex = -1;
/*  693 */       int riaIndex = -1;
/*      */       
/*  695 */       if (totalVisCount > 0) {
/*  696 */         rvaIndex = cp.addUtf8("RuntimeVisibleParameterAnnotations");
/*      */       }
/*  698 */       if (totalInvisCount > 0) {
/*  699 */         riaIndex = cp.addUtf8("RuntimeInvisibleParameterAnnotations");
/*      */       }
/*      */       
/*  702 */       List<RuntimeParamAnnos> newAttributes = new ArrayList<>();
/*      */       
/*  704 */       if (totalVisCount > 0) {
/*  705 */         newAttributes.add(new RuntimeVisParamAnnos(rvaIndex, rvaData.length, rvaData, cp));
/*      */       }
/*      */       
/*  708 */       if (totalInvisCount > 0) {
/*  709 */         newAttributes.add(new RuntimeInvisParamAnnos(riaIndex, riaData.length, riaData, cp));
/*      */       }
/*      */       
/*  712 */       return newAttributes.<Attribute>toArray(Attribute.NoAttributes);
/*  713 */     } catch (IOException e) {
/*  714 */       System.err.println("IOException whilst processing parameter annotations");
/*  715 */       e.printStackTrace();
/*      */       
/*  717 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static class ResultHolder {
/*      */     private String result;
/*      */     private int consumed;
/*  724 */     public static final ResultHolder BYTE = new ResultHolder("byte", 1);
/*  725 */     public static final ResultHolder CHAR = new ResultHolder("char", 1);
/*  726 */     public static final ResultHolder DOUBLE = new ResultHolder("double", 1);
/*  727 */     public static final ResultHolder FLOAT = new ResultHolder("float", 1);
/*  728 */     public static final ResultHolder INT = new ResultHolder("int", 1);
/*  729 */     public static final ResultHolder LONG = new ResultHolder("long", 1);
/*  730 */     public static final ResultHolder SHORT = new ResultHolder("short", 1);
/*  731 */     public static final ResultHolder BOOLEAN = new ResultHolder("boolean", 1);
/*  732 */     public static final ResultHolder VOID = new ResultHolder("void", 1);
/*      */     
/*      */     public ResultHolder(String s, int c) {
/*  735 */       this.result = s;
/*  736 */       this.consumed = c;
/*      */     }
/*      */     
/*      */     public String getResult() {
/*  740 */       return this.result;
/*      */     }
/*      */     
/*      */     public int getConsumedChars() {
/*  744 */       return this.consumed;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte typeOfSignature(String signature) throws ClassFormatException {
/*      */     try {
/*  757 */       switch (signature.charAt(0)) {
/*      */         case 'B':
/*  759 */           return 8;
/*      */         case 'C':
/*  761 */           return 5;
/*      */         case 'D':
/*  763 */           return 7;
/*      */         case 'F':
/*  765 */           return 6;
/*      */         case 'I':
/*  767 */           return 10;
/*      */         case 'J':
/*  769 */           return 11;
/*      */         case 'L':
/*  771 */           return 14;
/*      */         case '[':
/*  773 */           return 13;
/*      */         case 'V':
/*  775 */           return 12;
/*      */         case 'Z':
/*  777 */           return 4;
/*      */         case 'S':
/*  779 */           return 9;
/*      */       } 
/*  781 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     }
/*  783 */     catch (StringIndexOutOfBoundsException e) {
/*  784 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static final byte typeOfSignature(char c) throws ClassFormatException {
/*  789 */     switch (c) {
/*      */       case 'B':
/*  791 */         return 8;
/*      */       case 'C':
/*  793 */         return 5;
/*      */       case 'D':
/*  795 */         return 7;
/*      */       case 'F':
/*  797 */         return 6;
/*      */       case 'I':
/*  799 */         return 10;
/*      */       case 'J':
/*  801 */         return 11;
/*      */       case 'L':
/*  803 */         return 14;
/*      */       case '[':
/*  805 */         return 13;
/*      */       case 'V':
/*  807 */         return 12;
/*      */       case 'Z':
/*  809 */         return 4;
/*      */       case 'S':
/*  811 */         return 9;
/*      */     } 
/*  813 */     throw new ClassFormatException("Invalid type of signature: " + c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String codeToString(ByteSequence bytes, ConstantPool constant_pool, boolean verbose) throws IOException {
/*      */     int low, high, npairs, index, vindex, constant, match[], jump_table[], offset, i, nargs, dimensions;
/*  826 */     short opcode = (short)bytes.readUnsignedByte();
/*  827 */     int default_offset = 0;
/*      */ 
/*      */     
/*  830 */     int no_pad_bytes = 0;
/*  831 */     StringBuilder buf = new StringBuilder(Constants.OPCODE_NAMES[opcode]);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  836 */     if (opcode == 170 || opcode == 171) {
/*  837 */       int remainder = bytes.getIndex() % 4;
/*  838 */       no_pad_bytes = (remainder == 0) ? 0 : (4 - remainder);
/*      */       
/*  840 */       for (int j = 0; j < no_pad_bytes; j++) {
/*  841 */         byte b = bytes.readByte();
/*  842 */         if (b != 0) {
/*  843 */           System.err.println("Warning: Padding byte != 0 in " + Constants.OPCODE_NAMES[opcode] + ":" + b);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  848 */       default_offset = bytes.readInt();
/*      */     } 
/*      */     
/*  851 */     switch (opcode)
/*      */     
/*      */     { 
/*      */       
/*      */       case 170:
/*  856 */         low = bytes.readInt();
/*  857 */         high = bytes.readInt();
/*      */         
/*  859 */         offset = bytes.getIndex() - 12 - no_pad_bytes - 1;
/*  860 */         default_offset += offset;
/*      */         
/*  862 */         buf.append("\tdefault = " + default_offset + ", low = " + low + ", high = " + high + "(");
/*      */         
/*  864 */         jump_table = new int[high - low + 1];
/*  865 */         for (i = 0; i < jump_table.length; i++) {
/*  866 */           jump_table[i] = offset + bytes.readInt();
/*  867 */           buf.append(jump_table[i]);
/*  868 */           if (i < jump_table.length - 1) {
/*  869 */             buf.append(", ");
/*      */           }
/*      */         } 
/*  872 */         buf.append(")");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1069 */         return buf.toString();case 171: npairs = bytes.readInt(); offset = bytes.getIndex() - 8 - no_pad_bytes - 1; match = new int[npairs]; jump_table = new int[npairs]; default_offset += offset; buf.append("\tdefault = " + default_offset + ", npairs = " + npairs + " ("); for (i = 0; i < npairs; i++) { match[i] = bytes.readInt(); jump_table[i] = offset + bytes.readInt(); buf.append("(" + match[i] + ", " + jump_table[i] + ")"); if (i < npairs - 1) buf.append(", ");  }  buf.append(")"); return buf.toString();case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161: case 162: case 163: case 164: case 165: case 166: case 167: case 168: case 198: case 199: buf.append("\t\t#" + (bytes.getIndex() - 1 + bytes.readShort())); return buf.toString();case 200: case 201: buf.append("\t\t#" + (bytes.getIndex() - 1 + bytes.readInt())); return buf.toString();case 21: case 22: case 23: case 24: case 25: case 54: case 55: case 56: case 57: case 58: case 169: if (wide) { vindex = bytes.readUnsignedShort(); wide = false; } else { vindex = bytes.readUnsignedByte(); }  buf.append("\t\t%" + vindex); return buf.toString();case 196: wide = true; buf.append("\t(wide)"); return buf.toString();case 188: buf.append("\t\t<" + Constants.TYPE_NAMES[bytes.readByte()] + ">"); return buf.toString();case 178: case 179: case 180: case 181: index = bytes.readUnsignedShort(); buf.append("\t\t" + constant_pool.constantToString(index, (byte)9) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 187: case 192: buf.append("\t");case 193: index = bytes.readUnsignedShort(); buf.append("\t<" + constant_pool.constantToString(index) + ">" + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 182: case 183: case 184: index = bytes.readUnsignedShort(); buf.append("\t" + constant_pool.constantToString(index) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 185: index = bytes.readUnsignedShort(); nargs = bytes.readUnsignedByte(); buf.append("\t" + constant_pool.constantToString(index) + (verbose ? (" (" + index + ")\t") : "") + nargs + "\t" + bytes.readUnsignedByte()); return buf.toString();case 186: index = bytes.readUnsignedShort(); bytes.readUnsignedShort(); buf.append("\t" + constant_pool.constantToString(index) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 19: case 20: index = bytes.readUnsignedShort(); buf.append("\t\t" + constant_pool.constantToString(index) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 18: index = bytes.readUnsignedByte(); buf.append("\t\t" + constant_pool.constantToString(index) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 189: index = bytes.readUnsignedShort(); buf.append("\t\t<" + compactClassName(constant_pool.getConstantString(index, (byte)7), false) + ">" + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 197: index = bytes.readUnsignedShort(); dimensions = bytes.readUnsignedByte(); buf.append("\t<" + compactClassName(constant_pool.getConstantString(index, (byte)7), false) + ">\t" + dimensions + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 132: if (wide) { vindex = bytes.readUnsignedShort(); constant = bytes.readShort(); wide = false; } else { vindex = bytes.readUnsignedByte(); constant = bytes.readByte(); }  buf.append("\t\t%" + vindex + "\t" + constant); return buf.toString(); }  if (Constants.iLen[opcode] - 1 > 0) for (int j = 0; j < (Constants.TYPE_OF_OPERANDS[opcode]).length; j++) { buf.append("\t\t"); switch (Constants.TYPE_OF_OPERANDS[opcode][j]) { case 8: buf.append(bytes.readByte()); break;case 9: buf.append(bytes.readShort()); break;case 10: buf.append(bytes.readInt()); break;default: System.err.println("Unreachable default case reached!"); System.exit(-1); break; }  }   return buf.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int pow2(int n) {
/* 1074 */     return 1 << n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toMethodSignature(Type returnType, Type[] argTypes) {
/* 1085 */     StringBuilder buf = new StringBuilder("(");
/* 1086 */     int length = (argTypes == null) ? 0 : argTypes.length;
/* 1087 */     for (int i = 0; i < length; i++) {
/* 1088 */       buf.append(argTypes[i].getSignature());
/*      */     }
/* 1090 */     buf.append(')');
/* 1091 */     buf.append(returnType.getSignature());
/* 1092 */     return buf.toString();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Utility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */