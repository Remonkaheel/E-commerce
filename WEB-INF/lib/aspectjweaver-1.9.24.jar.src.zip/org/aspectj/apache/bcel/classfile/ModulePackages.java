/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModulePackages
/*     */   extends Attribute
/*     */ {
/*  70 */   private static int[] NO_PACKAGES = new int[0];
/*     */   private int[] packageIndices;
/*     */   
/*     */   public ModulePackages(ModulePackages c) {
/*  74 */     this(c.getNameIndex(), c.getLength(), c.getPackageIndices(), c.getConstantPool());
/*     */   }
/*     */   
/*     */   public ModulePackages(int nameIndex, int length, int[] packageIndices, ConstantPool cp) {
/*  78 */     super((byte)24, nameIndex, length, cp);
/*  79 */     setPackageIndices(packageIndices);
/*     */   }
/*     */   
/*     */   ModulePackages(int nameIndex, int length, DataInputStream stream, ConstantPool cp) throws IOException {
/*  83 */     this(nameIndex, length, (int[])null, cp);
/*  84 */     int packageIndicesCount = stream.readUnsignedShort();
/*  85 */     this.packageIndices = new int[packageIndicesCount];
/*  86 */     for (int i = 0; i < packageIndicesCount; i++) {
/*  87 */       this.packageIndices[i] = stream.readUnsignedShort();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  93 */     v.visitModulePackages(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream stream) throws IOException {
/*  98 */     super.dump(stream);
/*  99 */     stream.writeShort(this.packageIndices.length);
/* 100 */     for (int packageIndex : this.packageIndices) {
/* 101 */       stream.writeShort(packageIndex);
/*     */     }
/*     */   }
/*     */   
/*     */   public final int[] getPackageIndices() {
/* 106 */     return this.packageIndices;
/*     */   }
/*     */   
/*     */   public final void setPackageIndices(int[] packageIndices) {
/* 110 */     if (packageIndices == null) {
/* 111 */       this.packageIndices = NO_PACKAGES;
/*     */     } else {
/* 113 */       this.packageIndices = packageIndices;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 119 */     StringBuilder buf = new StringBuilder();
/* 120 */     for (int packageIndex : this.packageIndices) {
/* 121 */       buf.append(this.cpool.getPackageName(packageIndex) + "\n");
/*     */     }
/* 123 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ModulePackages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */