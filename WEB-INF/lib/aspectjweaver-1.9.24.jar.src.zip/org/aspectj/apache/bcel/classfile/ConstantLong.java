/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantLong
/*     */   extends Constant
/*     */   implements SimpleConstant
/*     */ {
/*     */   private long longValue;
/*     */   
/*     */   public ConstantLong(long longValue) {
/*  75 */     super((byte)5);
/*  76 */     this.longValue = longValue;
/*     */   }
/*     */   
/*     */   ConstantLong(DataInputStream file) throws IOException {
/*  80 */     this(file.readLong());
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  85 */     v.visitConstantLong(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  90 */     file.writeByte(this.tag);
/*  91 */     file.writeLong(this.longValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Long getValue() {
/*  96 */     return Long.valueOf(this.longValue);
/*     */   }
/*     */   
/*     */   public final String getStringValue() {
/* 100 */     return Long.toString(this.longValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 105 */     return super.toString() + "(longValue = " + this.longValue + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */