/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Constant
/*     */   implements Cloneable, Node
/*     */ {
/*     */   protected byte tag;
/*     */   
/*     */   Constant(byte tag) {
/*  75 */     this.tag = tag;
/*     */   }
/*     */   
/*     */   public final byte getTag() {
/*  79 */     return this.tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  84 */     return Constants.CONSTANT_NAMES[this.tag] + "[" + this.tag + "]";
/*     */   }
/*     */   
/*     */   public abstract void accept(ClassVisitor paramClassVisitor);
/*     */   
/*     */   public abstract void dump(DataOutputStream paramDataOutputStream) throws IOException;
/*     */   
/*     */   public abstract Object getValue();
/*     */   
/*     */   public Constant copy() {
/*     */     try {
/*  95 */       return (Constant)super.clone();
/*  96 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */ 
/*     */       
/*  99 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/* 104 */     return super.clone();
/*     */   }
/*     */   
/*     */   static final Constant readConstant(DataInputStream dis) throws IOException, ClassFormatException {
/* 108 */     byte b = dis.readByte();
/* 109 */     switch (b) {
/*     */       case 7:
/* 111 */         return new ConstantClass(dis);
/*     */       case 12:
/* 113 */         return new ConstantNameAndType(dis);
/*     */       case 1:
/* 115 */         return new ConstantUtf8(dis);
/*     */       case 9:
/* 117 */         return new ConstantFieldref(dis);
/*     */       case 10:
/* 119 */         return new ConstantMethodref(dis);
/*     */       case 11:
/* 121 */         return new ConstantInterfaceMethodref(dis);
/*     */       case 8:
/* 123 */         return new ConstantString(dis);
/*     */       case 3:
/* 125 */         return new ConstantInteger(dis);
/*     */       case 4:
/* 127 */         return new ConstantFloat(dis);
/*     */       case 5:
/* 129 */         return new ConstantLong(dis);
/*     */       case 6:
/* 131 */         return new ConstantDouble(dis);
/*     */       case 15:
/* 133 */         return new ConstantMethodHandle(dis);
/*     */       case 16:
/* 135 */         return new ConstantMethodType(dis);
/*     */       case 18:
/* 137 */         return new ConstantInvokeDynamic(dis);
/*     */       case 19:
/* 139 */         return new ConstantModule(dis);
/*     */       case 20:
/* 141 */         return new ConstantPackage(dis);
/*     */       case 17:
/* 143 */         return new ConstantDynamic(dis);
/*     */     } 
/* 145 */     throw new ClassFormatException("Invalid byte tag in constant pool: " + b);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Constant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */