/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Code
/*     */   extends Attribute
/*     */ {
/*     */   private int maxStack;
/*     */   private int maxLocals;
/*     */   private byte[] code;
/*     */   private CodeException[] exceptionTable;
/*     */   private Attribute[] attributes;
/*  84 */   private static final CodeException[] NO_EXCEPTIONS = new CodeException[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Code(Code c) {
/*  91 */     this(c.getNameIndex(), c.getLength(), c.getMaxStack(), c.getMaxLocals(), c.getCode(), c.getExceptionTable(), c
/*  92 */         .getAttributes(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */   
/*     */   Code(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  97 */     this(name_index, length, file.readUnsignedShort(), file.readUnsignedShort(), (byte[])null, (CodeException[])null, (Attribute[])null, constant_pool);
/*     */ 
/*     */     
/* 100 */     int len = file.readInt();
/* 101 */     this.code = new byte[len];
/* 102 */     file.readFully(this.code);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     len = file.readUnsignedShort();
/* 108 */     if (len == 0) {
/* 109 */       this.exceptionTable = NO_EXCEPTIONS;
/*     */     } else {
/* 111 */       this.exceptionTable = new CodeException[len];
/* 112 */       for (int i = 0; i < len; i++) {
/* 113 */         this.exceptionTable[i] = new CodeException(file);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 118 */     this.attributes = AttributeUtils.readAttributes(file, constant_pool);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Code(int name_index, int length, int max_stack, int max_locals, byte[] code, CodeException[] exception_table, Attribute[] attributes, ConstantPool constant_pool) {
/* 139 */     super((byte)2, name_index, length, constant_pool);
/*     */     
/* 141 */     this.maxStack = max_stack;
/* 142 */     this.maxLocals = max_locals;
/*     */     
/* 144 */     setCode(code);
/* 145 */     setExceptionTable(exception_table);
/* 146 */     setAttributes(attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 157 */     v.visitCode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 168 */     super.dump(file);
/*     */     
/* 170 */     file.writeShort(this.maxStack);
/* 171 */     file.writeShort(this.maxLocals);
/* 172 */     file.writeInt(this.code.length);
/* 173 */     file.write(this.code, 0, this.code.length);
/*     */     
/* 175 */     file.writeShort(this.exceptionTable.length);
/* 176 */     for (CodeException e : this.exceptionTable) {
/* 177 */       e.dump(file);
/*     */     }
/*     */     
/* 180 */     file.writeShort(this.attributes.length);
/* 181 */     for (Attribute attribute : this.attributes) {
/* 182 */       attribute.dump(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Attribute[] getAttributes() {
/* 191 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberTable getLineNumberTable() {
/* 198 */     for (Attribute attribute : this.attributes) {
/* 199 */       if (attribute.tag == 4) {
/* 200 */         return (LineNumberTable)attribute;
/*     */       }
/*     */     } 
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariableTable getLocalVariableTable() {
/* 210 */     for (Attribute attribute : this.attributes) {
/* 211 */       if (attribute.tag == 5) {
/* 212 */         return (LocalVariableTable)attribute;
/*     */       }
/*     */     } 
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getCode() {
/* 222 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CodeException[] getExceptionTable() {
/* 230 */     return this.exceptionTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxLocals() {
/* 237 */     return this.maxLocals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxStack() {
/* 245 */     return this.maxStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int getInternalLength() {
/* 252 */     return 8 + (
/* 253 */       (this.code == null) ? 0 : this.code.length) + 2 + 8 * (
/*     */       
/* 255 */       (this.exceptionTable == null) ? 0 : this.exceptionTable.length) + 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int calculateLength() {
/* 263 */     int len = 0;
/* 264 */     if (this.attributes != null) {
/* 265 */       for (Attribute attribute : this.attributes) {
/* 266 */         len += attribute.length + 6;
/*     */       }
/*     */     }
/* 269 */     return len + getInternalLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAttributes(Attribute[] attributes) {
/* 276 */     this.attributes = attributes;
/* 277 */     this.length = calculateLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCode(byte[] code) {
/* 284 */     this.code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setExceptionTable(CodeException[] exception_table) {
/* 291 */     this.exceptionTable = exception_table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMaxLocals(int max_locals) {
/* 298 */     this.maxLocals = max_locals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMaxStack(int max_stack) {
/* 305 */     this.maxStack = max_stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(boolean verbose) {
/* 315 */     StringBuilder buf = new StringBuilder("Code(max_stack = " + this.maxStack + ", max_locals = " + this.maxLocals + ", code_length = " + this.code.length + ")\n" + Utility.codeToString(this.code, this.cpool, 0, -1, verbose));
/*     */     
/* 317 */     if (this.exceptionTable.length > 0) {
/* 318 */       buf.append("\nException handler(s) = \nFrom\tTo\tHandler\tType\n");
/*     */       
/* 320 */       for (CodeException e : this.exceptionTable) {
/* 321 */         buf.append(e.toString(this.cpool, verbose) + "\n");
/*     */       }
/*     */     } 
/*     */     
/* 325 */     if (this.attributes.length > 0) {
/* 326 */       buf.append("\nAttribute(s) = \n");
/*     */       
/* 328 */       for (Attribute attribute : this.attributes) {
/* 329 */         buf.append(attribute.toString() + "\n");
/*     */       }
/*     */     } 
/*     */     
/* 333 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 341 */     return toString(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodeString() {
/* 368 */     StringBuilder codeString = new StringBuilder();
/* 369 */     codeString.append("Code(max_stack = ").append(this.maxStack);
/* 370 */     codeString.append(", max_locals = ").append(this.maxLocals);
/* 371 */     codeString.append(", code_length = ").append(this.code.length).append(")\n");
/* 372 */     codeString.append(Utility.codeToString(this.code, this.cpool, 0, -1, true));
/* 373 */     if (this.exceptionTable.length > 0) {
/* 374 */       codeString.append("\n").append("Exception entries =  ").append(this.exceptionTable.length).append("\n");
/* 375 */       for (CodeException exc : this.exceptionTable) {
/* 376 */         int type = exc.getCatchType();
/* 377 */         String name = "finally";
/* 378 */         if (type != 0) {
/* 379 */           name = this.cpool.getConstantString(type, (byte)7);
/*     */         }
/* 381 */         codeString.append(name).append("[");
/* 382 */         codeString.append(exc.getStartPC()).append(">").append(exc.getEndPC()).append("]\n");
/*     */       } 
/*     */     } 
/* 385 */     return codeString.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Code.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */