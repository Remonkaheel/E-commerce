/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantValue
/*     */   extends Attribute
/*     */ {
/*     */   private int constantvalue_index;
/*     */   
/*     */   ConstantValue(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  75 */     this(name_index, length, file.readUnsignedShort(), constant_pool);
/*     */   }
/*     */   
/*     */   public ConstantValue(int name_index, int length, int constantvalue_index, ConstantPool constant_pool) {
/*  79 */     super((byte)1, name_index, length, constant_pool);
/*  80 */     this.constantvalue_index = constantvalue_index;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  85 */     v.visitConstantValue(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  90 */     super.dump(file);
/*  91 */     file.writeShort(this.constantvalue_index);
/*     */   }
/*     */   
/*     */   public final int getConstantValueIndex() {
/*  95 */     return this.constantvalue_index;
/*     */   }
/*     */   public final String toString() {
/*     */     String buf;
/*     */     int i;
/* 100 */     Constant c = this.cpool.getConstant(this.constantvalue_index);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     switch (c.getTag()) {
/*     */       case 5:
/* 108 */         buf = "" + ((ConstantLong)c).getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 129 */         return buf;case 4: buf = "" + ((ConstantFloat)c).getValue(); return buf;case 6: buf = "" + ((ConstantDouble)c).getValue(); return buf;case 3: buf = "" + ((ConstantInteger)c).getValue(); return buf;case 8: i = ((ConstantString)c).getStringIndex(); c = this.cpool.getConstant(i, (byte)1); buf = "\"" + Utility.convertString(((ConstantUtf8)c).getValue()) + "\""; return buf;
/*     */     } 
/*     */     throw new IllegalStateException("Type of ConstValue invalid: " + c);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */