/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.Attribute;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RuntimeParamAnnos
/*     */   extends Attribute
/*     */ {
/*     */   private List<AnnotationGen[]> parameterAnnotations;
/*     */   private boolean visible;
/*     */   private boolean inflated = false;
/*     */   private byte[] annotation_data;
/*     */   
/*     */   public RuntimeParamAnnos(byte attrid, boolean visible, int nameIdx, int len, ConstantPool cpool) {
/*  37 */     super(attrid, nameIdx, len, cpool);
/*  38 */     this.visible = visible;
/*  39 */     this.parameterAnnotations = (List)new ArrayList<>();
/*     */   }
/*     */   
/*     */   public RuntimeParamAnnos(byte attrid, boolean visible, int nameIdx, int len, byte[] data, ConstantPool cpool) {
/*  43 */     super(attrid, nameIdx, len, cpool);
/*  44 */     this.visible = visible;
/*  45 */     this.parameterAnnotations = (List)new ArrayList<>();
/*  46 */     this.annotation_data = data;
/*     */   }
/*     */   
/*     */   public final void dump(DataOutputStream dos) throws IOException {
/*  50 */     super.dump(dos);
/*  51 */     writeAnnotations(dos);
/*     */   }
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/*  55 */     throw new RuntimeException("Not implemented yet!");
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotationGen[]> getParameterAnnotations() {
/*  60 */     if (!this.inflated) inflate(); 
/*  61 */     return this.parameterAnnotations;
/*     */   }
/*     */   
/*     */   public AnnotationGen[] getAnnotationsOnParameter(int parameterIndex) {
/*  65 */     if (!this.inflated) inflate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     if (parameterIndex >= this.parameterAnnotations.size()) {
/*  72 */       return AnnotationGen.NO_ANNOTATIONS;
/*     */     }
/*  74 */     return this.parameterAnnotations.get(parameterIndex);
/*     */   }
/*     */   
/*     */   public boolean areVisible() {
/*  78 */     return this.visible;
/*     */   }
/*     */   
/*     */   protected void readParameterAnnotations(DataInputStream dis, ConstantPool cpool) throws IOException {
/*  82 */     this.annotation_data = new byte[this.length];
/*  83 */     dis.readFully(this.annotation_data, 0, this.length);
/*     */   }
/*     */   
/*     */   private void inflate() {
/*     */     try {
/*  88 */       DataInputStream dis = new DataInputStream(new ByteArrayInputStream(this.annotation_data));
/*  89 */       int numParameters = dis.readUnsignedByte();
/*  90 */       if (numParameters > 0) {
/*  91 */         List<AnnotationGen[]> inflatedParameterAnnotations = (List)new ArrayList<>();
/*  92 */         for (int i = 0; i < numParameters; i++) {
/*  93 */           int numAnnotations = dis.readUnsignedShort();
/*  94 */           if (numAnnotations == 0) {
/*  95 */             inflatedParameterAnnotations.add(AnnotationGen.NO_ANNOTATIONS);
/*     */           } else {
/*  97 */             AnnotationGen[] annotations = new AnnotationGen[numAnnotations];
/*  98 */             for (int j = 0; j < numAnnotations; j++) {
/*  99 */               annotations[j] = AnnotationGen.read(dis, getConstantPool(), this.visible);
/*     */             }
/* 101 */             inflatedParameterAnnotations.add(annotations);
/*     */           } 
/*     */         } 
/* 104 */         this.parameterAnnotations = inflatedParameterAnnotations;
/*     */       } 
/* 106 */       this.inflated = true;
/* 107 */     } catch (IOException ioe) {
/* 108 */       throw new RuntimeException("Unabled to inflate annotation data, badly formed?");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeAnnotations(DataOutputStream dos) throws IOException {
/* 114 */     if (!this.inflated) {
/* 115 */       dos.write(this.annotation_data, 0, this.length);
/*     */     } else {
/* 117 */       dos.writeByte(this.parameterAnnotations.size());
/* 118 */       for (AnnotationGen[] annotations : this.parameterAnnotations) {
/* 119 */         dos.writeShort(annotations.length);
/* 120 */         for (AnnotationGen annotation : annotations) {
/* 121 */           annotation.dump(dos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInflated() {
/* 129 */     return this.inflated;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 133 */     return "Runtime" + (this.visible ? "Visible" : "Invisible") + "ParameterAnnotations [" + (this.inflated ? "inflated" : "not yet inflated") + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\RuntimeParamAnnos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */