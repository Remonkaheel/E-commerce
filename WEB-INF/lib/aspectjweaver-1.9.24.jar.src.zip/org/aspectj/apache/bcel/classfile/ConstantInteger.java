/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantInteger
/*     */   extends Constant
/*     */   implements SimpleConstant
/*     */ {
/*     */   private int intValue;
/*     */   
/*     */   public ConstantInteger(int intValue) {
/*  75 */     super((byte)3);
/*  76 */     this.intValue = intValue;
/*     */   }
/*     */   
/*     */   ConstantInteger(DataInputStream file) throws IOException {
/*  80 */     this(file.readInt());
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  85 */     v.visitConstantInteger(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  90 */     file.writeByte(this.tag);
/*  91 */     file.writeInt(this.intValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  96 */     return super.toString() + "(bytes = " + this.intValue + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getValue() {
/* 101 */     return Integer.valueOf(this.intValue);
/*     */   }
/*     */   
/*     */   public int getIntValue() {
/* 105 */     return this.intValue;
/*     */   }
/*     */   
/*     */   public String getStringValue() {
/* 109 */     return Integer.toString(this.intValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantInteger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */