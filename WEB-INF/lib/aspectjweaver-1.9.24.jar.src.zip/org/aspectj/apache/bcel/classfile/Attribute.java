/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisAnnos;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisParamAnnos;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisTypeAnnos;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisAnnos;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisParamAnnos;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisTypeAnnos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Attribute
/*     */   implements Cloneable, Node, Serializable
/*     */ {
/*  90 */   public static final Attribute[] NoAttributes = new Attribute[0];
/*     */   
/*     */   protected byte tag;
/*     */   protected int nameIndex;
/*     */   protected int length;
/*     */   protected ConstantPool cpool;
/*     */   
/*     */   protected Attribute(byte tag, int nameIndex, int length, ConstantPool cpool) {
/*  98 */     this.tag = tag;
/*  99 */     this.nameIndex = nameIndex;
/* 100 */     this.length = length;
/* 101 */     this.cpool = cpool;
/*     */   }
/*     */   
/*     */   public void dump(DataOutputStream file) throws IOException {
/* 105 */     file.writeShort(this.nameIndex);
/* 106 */     file.writeInt(this.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final Attribute readAttribute(DataInputStream file, ConstantPool cpool) throws IOException {
/* 111 */     byte tag = -1;
/* 112 */     int idx = file.readUnsignedShort();
/* 113 */     String name = cpool.getConstantUtf8(idx).getValue();
/* 114 */     int len = file.readInt();
/*     */     
/*     */     byte i;
/* 117 */     for (i = 0; i < 28; i = (byte)(i + 1)) {
/* 118 */       if (name.equals(Constants.ATTRIBUTE_NAMES[i])) {
/* 119 */         tag = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 123 */     switch (tag) {
/*     */       case -1:
/* 125 */         return new Unknown(idx, len, file, cpool);
/*     */       case 1:
/* 127 */         return new ConstantValue(idx, len, file, cpool);
/*     */       case 0:
/* 129 */         return new SourceFile(idx, len, file, cpool);
/*     */       case 2:
/* 131 */         return new Code(idx, len, file, cpool);
/*     */       case 3:
/* 133 */         return new ExceptionTable(idx, len, file, cpool);
/*     */       case 4:
/* 135 */         return new LineNumberTable(idx, len, file, cpool);
/*     */       case 5:
/* 137 */         return new LocalVariableTable(idx, len, file, cpool);
/*     */       case 6:
/* 139 */         return new InnerClasses(idx, len, file, cpool);
/*     */       case 7:
/* 141 */         return new Synthetic(idx, len, file, cpool);
/*     */       case 8:
/* 143 */         return new Deprecated(idx, len, file, cpool);
/*     */       case 10:
/* 145 */         return new Signature(idx, len, file, cpool);
/*     */       case 11:
/* 147 */         return new StackMap(idx, len, file, cpool);
/*     */       case 12:
/* 149 */         return (Attribute)new RuntimeVisAnnos(idx, len, file, cpool);
/*     */       case 13:
/* 151 */         return (Attribute)new RuntimeInvisAnnos(idx, len, file, cpool);
/*     */       case 14:
/* 153 */         return (Attribute)new RuntimeVisParamAnnos(idx, len, file, cpool);
/*     */       case 15:
/* 155 */         return (Attribute)new RuntimeInvisParamAnnos(idx, len, file, cpool);
/*     */       case 18:
/* 157 */         return new AnnotationDefault(idx, len, file, cpool);
/*     */       case 16:
/* 159 */         return new LocalVariableTypeTable(idx, len, file, cpool);
/*     */       case 17:
/* 161 */         return new EnclosingMethod(idx, len, file, cpool);
/*     */       case 19:
/* 163 */         return new BootstrapMethods(idx, len, file, cpool);
/*     */       case 20:
/* 165 */         return (Attribute)new RuntimeVisTypeAnnos(idx, len, file, cpool);
/*     */       case 21:
/* 167 */         return (Attribute)new RuntimeInvisTypeAnnos(idx, len, file, cpool);
/*     */       case 22:
/* 169 */         return new MethodParameters(idx, len, file, cpool);
/*     */       case 23:
/* 171 */         return new Module(idx, len, file, cpool);
/*     */       case 24:
/* 173 */         return new ModulePackages(idx, len, file, cpool);
/*     */       case 25:
/* 175 */         return new ModuleMainClass(idx, len, file, cpool);
/*     */       case 26:
/* 177 */         return new NestHost(idx, len, file, cpool);
/*     */       case 27:
/* 179 */         return new NestMembers(idx, len, file, cpool);
/*     */     } 
/* 181 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 186 */     return this.cpool.getConstantUtf8(this.nameIndex).getValue();
/*     */   }
/*     */   
/*     */   public final int getLength() {
/* 190 */     return this.length;
/*     */   }
/*     */   
/*     */   public final int getNameIndex() {
/* 194 */     return this.nameIndex;
/*     */   }
/*     */   
/*     */   public final byte getTag() {
/* 198 */     return this.tag;
/*     */   }
/*     */   
/*     */   public final ConstantPool getConstantPool() {
/* 202 */     return this.cpool;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 207 */     return Constants.ATTRIBUTE_NAMES[this.tag];
/*     */   }
/*     */   
/*     */   public abstract void accept(ClassVisitor paramClassVisitor);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Attribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */