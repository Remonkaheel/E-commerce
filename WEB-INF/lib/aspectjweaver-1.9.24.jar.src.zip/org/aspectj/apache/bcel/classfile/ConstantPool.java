/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aspectj.apache.bcel.Constants;
/*     */ import org.aspectj.apache.bcel.generic.ArrayType;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantPool
/*     */   implements Node
/*     */ {
/*     */   private Constant[] pool;
/*     */   private int poolSize;
/*  74 */   private Map<String, Integer> utf8Cache = new HashMap<>();
/*  75 */   private Map<String, Integer> methodCache = new HashMap<>();
/*  76 */   private Map<String, Integer> fieldCache = new HashMap<>();
/*     */   
/*     */   public int getSize() {
/*  79 */     return this.poolSize;
/*     */   }
/*     */   
/*     */   public ConstantPool() {
/*  83 */     this.pool = new Constant[10];
/*  84 */     this.poolSize = 0;
/*     */   }
/*     */   
/*     */   public ConstantPool(Constant[] constants) {
/*  88 */     this.pool = constants;
/*  89 */     this.poolSize = (constants == null) ? 0 : constants.length;
/*     */   }
/*     */ 
/*     */   
/*     */   ConstantPool(DataInputStream file) throws IOException {
/*  94 */     this.poolSize = file.readUnsignedShort();
/*  95 */     this.pool = new Constant[this.poolSize];
/*     */     
/*  97 */     for (int i = 1; i < this.poolSize; i++) {
/*  98 */       this.pool[i] = Constant.readConstant(file);
/*  99 */       byte tag = this.pool[i].getTag();
/* 100 */       if (tag == 6 || tag == 5) {
/* 101 */         i++;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Constant getConstant(int index, byte tag) {
/* 107 */     Constant c = getConstant(index);
/*     */     
/* 109 */     if (c.tag == tag)
/* 110 */       return c; 
/* 111 */     throw new ClassFormatException("Expected class '" + Constants.CONSTANT_NAMES[tag] + "' at index " + index + " and found " + c);
/*     */   }
/*     */ 
/*     */   
/*     */   public Constant getConstant(int index) {
/*     */     try {
/* 117 */       return this.pool[index];
/* 118 */     } catch (ArrayIndexOutOfBoundsException aioobe) {
/* 119 */       throw new ClassFormatException("Index " + index + " into constant pool (size:" + this.poolSize + ") is invalid");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantPool copy() {
/* 127 */     Constant[] newConstants = new Constant[this.poolSize];
/* 128 */     for (int i = 1; i < this.poolSize; i++) {
/* 129 */       if (this.pool[i] != null) {
/* 130 */         newConstants[i] = this.pool[i].copy();
/*     */       }
/*     */     } 
/* 133 */     return new ConstantPool(newConstants);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConstantString(int index, byte tag) throws ClassFormatException {
/*     */     int i;
/* 148 */     Constant c = getConstant(index, tag);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     switch (tag) {
/*     */       case 7:
/* 158 */         i = ((ConstantClass)c).getNameIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         c = getConstant(i, (byte)1);
/* 168 */         return ((ConstantUtf8)c).getValue();case 8: i = ((ConstantString)c).getStringIndex(); c = getConstant(i, (byte)1); return ((ConstantUtf8)c).getValue();
/*     */     } 
/*     */     throw new RuntimeException("getConstantString called with illegal tag " + tag); } public String constantToString(Constant c) { String str;
/*     */     int i;
/*     */     ConstantInvokeDynamic cID;
/*     */     ConstantDynamic cD;
/*     */     ConstantMethodHandle cMH;
/*     */     ConstantMethodType cMT;
/*     */     ConstantModule cM;
/*     */     ConstantPackage cP;
/* 178 */     switch (c.tag)
/*     */     { case 7:
/* 180 */         i = ((ConstantClass)c).getNameIndex();
/* 181 */         c = getConstant(i, (byte)1);
/* 182 */         str = Utility.compactClassName(((ConstantUtf8)c).getValue(), false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 239 */         return str;case 8: i = ((ConstantString)c).getStringIndex(); c = getConstant(i, (byte)1); str = "\"" + escape(((ConstantUtf8)c).getValue()) + "\""; return str;case 1: case 3: case 4: case 5: case 6: str = ((SimpleConstant)c).getStringValue(); return str;case 12: str = constantToString(((ConstantNameAndType)c).getNameIndex(), (byte)1) + " " + constantToString(((ConstantNameAndType)c).getSignatureIndex(), (byte)1); return str;case 9: case 10: case 11: str = constantToString(((ConstantCP)c).getClassIndex(), (byte)7) + "." + constantToString(((ConstantCP)c).getNameAndTypeIndex(), (byte)12); return str;case 18: cID = (ConstantInvokeDynamic)c; return "#" + cID.getBootstrapMethodAttrIndex() + "." + constantToString(cID.getNameAndTypeIndex(), (byte)12);case 17: cD = (ConstantDynamic)c; return "#" + cD.getBootstrapMethodAttrIndex() + "." + constantToString(cD.getNameAndTypeIndex(), (byte)12);
/*     */       case 15: cMH = (ConstantMethodHandle)c; return cMH.getReferenceKind() + ":" + constantToString(cMH.getReferenceIndex(), (byte)10);
/*     */       case 16: cMT = (ConstantMethodType)c; return constantToString(cMT.getDescriptorIndex(), (byte)1);
/*     */       case 19: cM = (ConstantModule)c; return "Module:" + constantToString(cM.getNameIndex(), (byte)1);
/* 243 */       case 20: cP = (ConstantPackage)c; return "Package:" + constantToString(cP.getNameIndex(), (byte)1); }  throw new RuntimeException("Unknown constant type " + c.tag); } private static final String escape(String str) { int len = str.length();
/* 244 */     StringBuilder buf = new StringBuilder(len + 5);
/* 245 */     char[] ch = str.toCharArray();
/*     */     
/* 247 */     for (int i = 0; i < len; i++) {
/* 248 */       switch (ch[i]) {
/*     */         case '\n':
/* 250 */           buf.append("\\n");
/*     */           break;
/*     */         case '\r':
/* 253 */           buf.append("\\r");
/*     */           break;
/*     */         case '\t':
/* 256 */           buf.append("\\t");
/*     */           break;
/*     */         case '\b':
/* 259 */           buf.append("\\b");
/*     */           break;
/*     */         case '"':
/* 262 */           buf.append("\\\"");
/*     */           break;
/*     */         default:
/* 265 */           buf.append(ch[i]);
/*     */           break;
/*     */       } 
/*     */     } 
/* 269 */     return buf.toString(); }
/*     */ 
/*     */   
/*     */   public String constantToString(int index, byte tag) {
/* 273 */     Constant c = getConstant(index, tag);
/* 274 */     return constantToString(c);
/*     */   }
/*     */   
/*     */   public String constantToString(int index) {
/* 278 */     return constantToString(getConstant(index));
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 283 */     v.visitConstantPool(this);
/*     */   }
/*     */   
/*     */   public Constant[] getConstantPool() {
/* 287 */     return this.pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream file) throws IOException {
/* 296 */     int size = Math.min(this.poolSize, 65535);
/* 297 */     file.writeShort(size);
/* 298 */     for (int i = 1; i < size; i++) {
/* 299 */       if (this.pool[i] != null)
/* 300 */         this.pool[i].dump(file); 
/*     */     } 
/*     */   }
/*     */   public ConstantUtf8 getConstantUtf8(int index) {
/* 304 */     Constant c = getConstant(index);
/* 305 */     assert c != null;
/* 306 */     assert c.tag == 1;
/* 307 */     return (ConstantUtf8)c;
/*     */   }
/*     */   
/*     */   public ConstantModule getConstantModule(int index) {
/* 311 */     Constant c = getConstant(index);
/* 312 */     assert c != null;
/* 313 */     assert c.tag == 19;
/* 314 */     return (ConstantModule)c;
/*     */   }
/*     */   
/*     */   public ConstantPackage getConstantPackage(int index) {
/* 318 */     Constant c = getConstant(index);
/* 319 */     assert c != null;
/* 320 */     assert c.tag == 20;
/* 321 */     return (ConstantPackage)c;
/*     */   }
/*     */   
/*     */   public String getConstantString_CONSTANTClass(int index) {
/* 325 */     ConstantClass c = (ConstantClass)getConstant(index, (byte)7);
/* 326 */     index = c.getNameIndex();
/* 327 */     return ((ConstantUtf8)getConstant(index, (byte)1)).getValue();
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 331 */     return this.poolSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 336 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 338 */     for (int i = 1; i < this.poolSize; i++) {
/* 339 */       buf.append(i).append(") ").append(this.pool[i]).append("\n");
/*     */     }
/* 341 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public int lookupInteger(int n) {
/* 345 */     for (int i = 1; i < this.poolSize; i++) {
/* 346 */       if (this.pool[i] instanceof ConstantInteger) {
/* 347 */         ConstantInteger c = (ConstantInteger)this.pool[i];
/* 348 */         if (c.getValue().intValue() == n)
/* 349 */           return i; 
/*     */       } 
/*     */     } 
/* 352 */     return -1;
/*     */   }
/*     */   
/*     */   public int lookupUtf8(String string) {
/* 356 */     Integer pos = this.utf8Cache.get(string);
/* 357 */     if (pos != null) {
/* 358 */       return pos.intValue();
/*     */     }
/* 360 */     for (int i = 1; i < this.poolSize; i++) {
/* 361 */       Constant c = this.pool[i];
/* 362 */       if (c != null && c.tag == 1 && (
/* 363 */         (ConstantUtf8)c).getValue().equals(string)) {
/* 364 */         this.utf8Cache.put(string, Integer.valueOf(i));
/* 365 */         return i;
/*     */       } 
/*     */     } 
/*     */     
/* 369 */     return -1;
/*     */   }
/*     */   
/*     */   public int lookupClass(String classname) {
/* 373 */     for (int i = 1; i < this.poolSize; i++) {
/* 374 */       Constant c = this.pool[i];
/* 375 */       if (c != null && c.tag == 7) {
/* 376 */         int cIndex = ((ConstantClass)c).getNameIndex();
/* 377 */         String cName = ((ConstantUtf8)this.pool[cIndex]).getValue();
/* 378 */         if (cName.equals(classname))
/* 379 */           return i; 
/*     */       } 
/*     */     } 
/* 382 */     return -1;
/*     */   }
/*     */   
/*     */   public int addUtf8(String n) {
/* 386 */     int ret = lookupUtf8(n);
/* 387 */     if (ret != -1)
/* 388 */       return ret; 
/* 389 */     adjustSize();
/* 390 */     ret = this.poolSize;
/* 391 */     this.pool[this.poolSize++] = new ConstantUtf8(n);
/* 392 */     return ret;
/*     */   }
/*     */   
/*     */   public int addInteger(int n) {
/* 396 */     int ret = lookupInteger(n);
/* 397 */     if (ret != -1)
/* 398 */       return ret; 
/* 399 */     adjustSize();
/* 400 */     ret = this.poolSize;
/* 401 */     this.pool[this.poolSize++] = new ConstantInteger(n);
/* 402 */     return ret;
/*     */   }
/*     */   
/*     */   public int addArrayClass(ArrayType type) {
/* 406 */     return addClass(type.getSignature());
/*     */   }
/*     */   
/*     */   public int addClass(ObjectType type) {
/* 410 */     return addClass(type.getClassName());
/*     */   }
/*     */   
/*     */   public int addClass(String classname) {
/* 414 */     String toAdd = classname.replace('.', '/');
/* 415 */     int ret = lookupClass(toAdd);
/* 416 */     if (ret != -1)
/* 417 */       return ret; 
/* 418 */     adjustSize();
/* 419 */     ConstantClass c = new ConstantClass(addUtf8(toAdd));
/* 420 */     ret = this.poolSize;
/* 421 */     this.pool[this.poolSize++] = c;
/* 422 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private void adjustSize() {
/* 427 */     if (this.poolSize + 3 >= 65536) {
/* 428 */       throw new IllegalStateException("The number of constants " + (this.poolSize + 3) + " is over the size of the constant pool: " + Character.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 433 */     if (this.poolSize + 3 >= this.pool.length) {
/* 434 */       Constant[] cs = this.pool;
/* 435 */       int size = cs.length + 8;
/*     */       
/* 437 */       size = Math.min(size, 65536);
/* 438 */       this.pool = new Constant[size];
/* 439 */       System.arraycopy(cs, 0, this.pool, 0, cs.length);
/*     */     } 
/* 441 */     if (this.poolSize == 0)
/* 442 */       this.poolSize = 1; 
/*     */   }
/*     */   
/*     */   public int addFieldref(String class_name, String field_name, String signature) {
/* 446 */     int ret = lookupFieldref(class_name, field_name, signature);
/*     */ 
/*     */     
/* 449 */     if (ret != -1) {
/* 450 */       return ret;
/*     */     }
/* 452 */     adjustSize();
/*     */     
/* 454 */     int class_index = addClass(class_name);
/* 455 */     int name_and_type_index = addNameAndType(field_name, signature);
/* 456 */     ret = this.poolSize;
/* 457 */     this.pool[this.poolSize++] = new ConstantFieldref(class_index, name_and_type_index);
/*     */     
/* 459 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupFieldref(String searchClassname, String searchFieldname, String searchSignature) {
/* 463 */     searchClassname = searchClassname.replace('.', '/');
/* 464 */     String k = searchClassname + searchFieldname + searchSignature;
/* 465 */     Integer pos = this.fieldCache.get(k);
/* 466 */     if (pos != null)
/* 467 */       return pos.intValue(); 
/* 468 */     for (int i = 1; i < this.poolSize; i++) {
/* 469 */       Constant c = this.pool[i];
/* 470 */       if (c != null && c.tag == 9) {
/* 471 */         ConstantFieldref cfr = (ConstantFieldref)c;
/* 472 */         ConstantNameAndType cnat = (ConstantNameAndType)this.pool[cfr.getNameAndTypeIndex()];
/*     */ 
/*     */         
/* 475 */         int cIndex = cfr.getClassIndex();
/* 476 */         ConstantClass cc = (ConstantClass)this.pool[cIndex];
/* 477 */         String cName = ((ConstantUtf8)this.pool[cc.getNameIndex()]).getValue();
/* 478 */         if (cName.equals(searchClassname)) {
/*     */ 
/*     */ 
/*     */           
/* 482 */           String name = ((ConstantUtf8)this.pool[cnat.getNameIndex()]).getValue();
/* 483 */           if (name.equals(searchFieldname))
/*     */           
/* 485 */           { String typeSignature = ((ConstantUtf8)this.pool[cnat.getSignatureIndex()]).getValue();
/* 486 */             if (typeSignature.equals(searchSignature))
/*     */             
/* 488 */             { this.fieldCache.put(k, Integer.valueOf(i));
/* 489 */               return i; }  } 
/*     */         } 
/*     */       } 
/* 492 */     }  return -1;
/*     */   }
/*     */   
/*     */   public int addNameAndType(String name, String signature) {
/* 496 */     int ret = lookupNameAndType(name, signature);
/* 497 */     if (ret != -1)
/* 498 */       return ret; 
/* 499 */     adjustSize();
/* 500 */     int name_index = addUtf8(name);
/* 501 */     int signature_index = addUtf8(signature);
/* 502 */     ret = this.poolSize;
/* 503 */     this.pool[this.poolSize++] = new ConstantNameAndType(name_index, signature_index);
/* 504 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupNameAndType(String searchName, String searchTypeSignature) {
/* 508 */     for (int i = 1; i < this.poolSize; i++) {
/* 509 */       Constant c = this.pool[i];
/* 510 */       if (c != null && c.tag == 12) {
/* 511 */         ConstantNameAndType cnat = (ConstantNameAndType)c;
/* 512 */         String name = ((ConstantUtf8)this.pool[cnat.getNameIndex()]).getValue();
/* 513 */         if (name.equals(searchName)) {
/*     */           
/* 515 */           String typeSignature = ((ConstantUtf8)this.pool[cnat.getSignatureIndex()]).getValue();
/* 516 */           if (typeSignature.equals(searchTypeSignature))
/*     */           {
/* 518 */             return i; } 
/*     */         } 
/*     */       } 
/* 521 */     }  return -1;
/*     */   }
/*     */   
/*     */   public int addFloat(float f) {
/* 525 */     int ret = lookupFloat(f);
/* 526 */     if (ret != -1)
/* 527 */       return ret; 
/* 528 */     adjustSize();
/* 529 */     ret = this.poolSize;
/* 530 */     this.pool[this.poolSize++] = new ConstantFloat(f);
/* 531 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupFloat(float f) {
/* 535 */     int bits = Float.floatToIntBits(f);
/* 536 */     for (int i = 1; i < this.poolSize; i++) {
/* 537 */       Constant c = this.pool[i];
/* 538 */       if (c != null && c.tag == 4) {
/* 539 */         ConstantFloat cf = (ConstantFloat)c;
/* 540 */         if (Float.floatToIntBits(cf.getValue().floatValue()) == bits)
/* 541 */           return i; 
/*     */       } 
/*     */     } 
/* 544 */     return -1;
/*     */   }
/*     */   
/*     */   public int addDouble(double d) {
/* 548 */     int ret = lookupDouble(d);
/* 549 */     if (ret != -1)
/* 550 */       return ret; 
/* 551 */     adjustSize();
/* 552 */     ret = this.poolSize;
/* 553 */     this.pool[this.poolSize] = new ConstantDouble(d);
/* 554 */     this.poolSize += 2;
/* 555 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupDouble(double d) {
/* 559 */     long bits = Double.doubleToLongBits(d);
/* 560 */     for (int i = 1; i < this.poolSize; i++) {
/* 561 */       Constant c = this.pool[i];
/* 562 */       if (c != null && c.tag == 6) {
/* 563 */         ConstantDouble cf = (ConstantDouble)c;
/* 564 */         if (Double.doubleToLongBits(cf.getValue().doubleValue()) == bits)
/* 565 */           return i; 
/*     */       } 
/*     */     } 
/* 568 */     return -1;
/*     */   }
/*     */   
/*     */   public int addLong(long l) {
/* 572 */     int ret = lookupLong(l);
/* 573 */     if (ret != -1)
/* 574 */       return ret; 
/* 575 */     adjustSize();
/* 576 */     ret = this.poolSize;
/* 577 */     this.pool[this.poolSize] = new ConstantLong(l);
/* 578 */     this.poolSize += 2;
/* 579 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupString(String s) {
/* 583 */     for (int i = 1; i < this.poolSize; i++) {
/* 584 */       Constant c = this.pool[i];
/* 585 */       if (c != null && c.tag == 8) {
/* 586 */         ConstantString cs = (ConstantString)c;
/* 587 */         ConstantUtf8 cu8 = (ConstantUtf8)this.pool[cs.getStringIndex()];
/* 588 */         if (cu8.getValue().equals(s))
/* 589 */           return i; 
/*     */       } 
/*     */     } 
/* 592 */     return -1;
/*     */   }
/*     */   
/*     */   public int addString(String str) {
/* 596 */     int ret = lookupString(str);
/* 597 */     if (ret != -1)
/* 598 */       return ret; 
/* 599 */     int utf8 = addUtf8(str);
/* 600 */     adjustSize();
/* 601 */     ConstantString s = new ConstantString(utf8);
/* 602 */     ret = this.poolSize;
/* 603 */     this.pool[this.poolSize++] = s;
/* 604 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupLong(long l) {
/* 608 */     for (int i = 1; i < this.poolSize; i++) {
/* 609 */       Constant c = this.pool[i];
/* 610 */       if (c != null && c.tag == 5) {
/* 611 */         ConstantLong cf = (ConstantLong)c;
/* 612 */         if (cf.getValue().longValue() == l)
/* 613 */           return i; 
/*     */       } 
/*     */     } 
/* 616 */     return -1; } public int addConstant(Constant c, ConstantPool cp) { ConstantString constantString; ConstantClass s; ConstantNameAndType n; ConstantInvokeDynamic cid; ConstantDynamic cd; ConstantMethodHandle cmh; ConstantUtf8 u8; int index1; ConstantMethodType cmt; ConstantUtf8 u8_2; ConstantNameAndType cnat; ConstantCP m; ConstantUtf8 name; ConstantClass clazz; ConstantUtf8 signature; ConstantNameAndType constantNameAndType1;
/*     */     int index2;
/*     */     ConstantUtf8 constantUtf81;
/*     */     String class_name, str1, str2;
/* 620 */     Constant[] constants = cp.getConstantPool();
/* 621 */     switch (c.getTag()) {
/*     */       
/*     */       case 8:
/* 624 */         constantString = (ConstantString)c;
/* 625 */         u8 = (ConstantUtf8)constants[constantString.getStringIndex()];
/*     */         
/* 627 */         return addString(u8.getValue());
/*     */ 
/*     */       
/*     */       case 7:
/* 631 */         s = (ConstantClass)c;
/* 632 */         u8 = (ConstantUtf8)constants[s.getNameIndex()];
/*     */         
/* 634 */         return addClass(u8.getValue());
/*     */ 
/*     */       
/*     */       case 12:
/* 638 */         n = (ConstantNameAndType)c;
/* 639 */         u8 = (ConstantUtf8)constants[n.getNameIndex()];
/* 640 */         u8_2 = (ConstantUtf8)constants[n.getSignatureIndex()];
/*     */         
/* 642 */         return addNameAndType(u8.getValue(), u8_2.getValue());
/*     */ 
/*     */       
/*     */       case 18:
/* 646 */         cid = (ConstantInvokeDynamic)c;
/* 647 */         index1 = cid.getBootstrapMethodAttrIndex();
/* 648 */         cnat = (ConstantNameAndType)constants[cid.getNameAndTypeIndex()];
/* 649 */         name = (ConstantUtf8)constants[cnat.getNameIndex()];
/* 650 */         signature = (ConstantUtf8)constants[cnat.getSignatureIndex()];
/* 651 */         index2 = addNameAndType(name.getValue(), signature.getValue());
/* 652 */         return addInvokeDynamic(index1, index2);
/*     */ 
/*     */       
/*     */       case 17:
/* 656 */         cd = (ConstantDynamic)c;
/* 657 */         index1 = cd.getBootstrapMethodAttrIndex();
/* 658 */         cnat = (ConstantNameAndType)constants[cd.getNameAndTypeIndex()];
/* 659 */         name = (ConstantUtf8)constants[cnat.getNameIndex()];
/* 660 */         signature = (ConstantUtf8)constants[cnat.getSignatureIndex()];
/* 661 */         index2 = addNameAndType(name.getValue(), signature.getValue());
/* 662 */         return addConstantDynamic(index1, index2);
/*     */ 
/*     */       
/*     */       case 15:
/* 666 */         cmh = (ConstantMethodHandle)c;
/* 667 */         return addMethodHandle(cmh.getReferenceKind(), addConstant(constants[cmh.getReferenceIndex()], cp));
/*     */       
/*     */       case 1:
/* 670 */         return addUtf8(((ConstantUtf8)c).getValue());
/*     */       
/*     */       case 6:
/* 673 */         return addDouble(((ConstantDouble)c).getValue().doubleValue());
/*     */       
/*     */       case 4:
/* 676 */         return addFloat(((ConstantFloat)c).getValue().floatValue());
/*     */       
/*     */       case 5:
/* 679 */         return addLong(((ConstantLong)c).getValue().longValue());
/*     */       
/*     */       case 3:
/* 682 */         return addInteger(((ConstantInteger)c).getValue().intValue());
/*     */       
/*     */       case 16:
/* 685 */         cmt = (ConstantMethodType)c;
/* 686 */         return addMethodType(addConstant(constants[cmt.getDescriptorIndex()], cp));
/*     */       
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/* 691 */         m = (ConstantCP)c;
/* 692 */         clazz = (ConstantClass)constants[m.getClassIndex()];
/* 693 */         constantNameAndType1 = (ConstantNameAndType)constants[m.getNameAndTypeIndex()];
/* 694 */         constantUtf81 = (ConstantUtf8)constants[clazz.getNameIndex()];
/* 695 */         class_name = constantUtf81.getValue().replace('/', '.');
/*     */         
/* 697 */         constantUtf81 = (ConstantUtf8)constants[constantNameAndType1.getNameIndex()];
/* 698 */         str1 = constantUtf81.getValue();
/*     */         
/* 700 */         constantUtf81 = (ConstantUtf8)constants[constantNameAndType1.getSignatureIndex()];
/* 701 */         str2 = constantUtf81.getValue();
/*     */         
/* 703 */         switch (c.getTag()) {
/*     */           case 11:
/* 705 */             return addInterfaceMethodref(class_name, str1, str2);
/*     */           
/*     */           case 10:
/* 708 */             return addMethodref(class_name, str1, str2);
/*     */           
/*     */           case 9:
/* 711 */             return addFieldref(class_name, str1, str2);
/*     */         } 
/*     */         
/* 714 */         throw new RuntimeException("Unknown constant type " + c);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 719 */     throw new RuntimeException("Unknown constant type " + c); }
/*     */ 
/*     */ 
/*     */   
/*     */   public int addMethodHandle(byte referenceKind, int referenceIndex) {
/* 724 */     adjustSize();
/* 725 */     int ret = this.poolSize;
/* 726 */     this.pool[this.poolSize++] = new ConstantMethodHandle(referenceKind, referenceIndex);
/* 727 */     return ret;
/*     */   }
/*     */   
/*     */   public int addMethodType(int descriptorIndex) {
/* 731 */     adjustSize();
/* 732 */     int ret = this.poolSize;
/* 733 */     this.pool[this.poolSize++] = new ConstantMethodType(descriptorIndex);
/* 734 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public int addMethodref(String class_name, String method_name, String signature) {
/*     */     int ret;
/* 740 */     if ((ret = lookupMethodref(class_name, method_name, signature)) != -1) {
/* 741 */       return ret;
/*     */     }
/* 743 */     adjustSize();
/*     */     
/* 745 */     int name_and_type_index = addNameAndType(method_name, signature);
/* 746 */     int class_index = addClass(class_name);
/* 747 */     ret = this.poolSize;
/* 748 */     this.pool[this.poolSize++] = new ConstantMethodref(class_index, name_and_type_index);
/* 749 */     return ret;
/*     */   }
/*     */   
/*     */   public int addInvokeDynamic(int bootstrapMethodIndex, int constantNameAndTypeIndex) {
/* 753 */     adjustSize();
/* 754 */     int ret = this.poolSize;
/* 755 */     this.pool[this.poolSize++] = new ConstantInvokeDynamic(bootstrapMethodIndex, constantNameAndTypeIndex);
/* 756 */     return ret;
/*     */   }
/*     */   public int addConstantDynamic(int bootstrapMethodIndex, int constantNameAndTypeIndex) {
/* 759 */     adjustSize();
/* 760 */     int ret = this.poolSize;
/* 761 */     this.pool[this.poolSize++] = new ConstantDynamic(bootstrapMethodIndex, constantNameAndTypeIndex);
/* 762 */     return ret;
/*     */   }
/*     */   
/*     */   public int addInterfaceMethodref(String class_name, String method_name, String signature) {
/* 766 */     int ret = lookupInterfaceMethodref(class_name, method_name, signature);
/*     */ 
/*     */     
/* 769 */     if (ret != -1)
/* 770 */       return ret; 
/* 771 */     adjustSize();
/*     */     
/* 773 */     int class_index = addClass(class_name);
/* 774 */     int name_and_type_index = addNameAndType(method_name, signature);
/* 775 */     ret = this.poolSize;
/* 776 */     this.pool[this.poolSize++] = new ConstantInterfaceMethodref(class_index, name_and_type_index);
/* 777 */     return ret;
/*     */   }
/*     */   
/*     */   public int lookupInterfaceMethodref(String searchClassname, String searchMethodName, String searchSignature) {
/* 781 */     searchClassname = searchClassname.replace('.', '/');
/* 782 */     for (int i = 1; i < this.poolSize; i++) {
/* 783 */       Constant c = this.pool[i];
/* 784 */       if (c != null && c.tag == 11) {
/* 785 */         ConstantInterfaceMethodref cfr = (ConstantInterfaceMethodref)c;
/*     */         
/* 787 */         ConstantClass cc = (ConstantClass)this.pool[cfr.getClassIndex()];
/* 788 */         String cName = ((ConstantUtf8)this.pool[cc.getNameIndex()]).getValue();
/* 789 */         if (cName.equals(searchClassname)) {
/*     */ 
/*     */ 
/*     */           
/* 793 */           ConstantNameAndType cnat = (ConstantNameAndType)this.pool[cfr.getNameAndTypeIndex()];
/* 794 */           String name = ((ConstantUtf8)this.pool[cnat.getNameIndex()]).getValue();
/* 795 */           if (name.equals(searchMethodName))
/*     */           
/* 797 */           { String typeSignature = ((ConstantUtf8)this.pool[cnat.getSignatureIndex()]).getValue();
/* 798 */             if (typeSignature.equals(searchSignature))
/*     */             {
/* 800 */               return i; }  } 
/*     */         } 
/*     */       } 
/* 803 */     }  return -1;
/*     */   }
/*     */   
/*     */   public int lookupMethodref(String searchClassname, String searchMethodName, String searchSignature) {
/* 807 */     String key = searchClassname + searchMethodName + searchSignature;
/* 808 */     Integer cached = this.methodCache.get(key);
/* 809 */     if (cached != null)
/* 810 */       return cached.intValue(); 
/* 811 */     searchClassname = searchClassname.replace('.', '/');
/* 812 */     for (int i = 1; i < this.poolSize; i++) {
/* 813 */       Constant c = this.pool[i];
/* 814 */       if (c != null && c.tag == 10) {
/* 815 */         ConstantMethodref cfr = (ConstantMethodref)c;
/* 816 */         ConstantNameAndType cnat = (ConstantNameAndType)this.pool[cfr.getNameAndTypeIndex()];
/*     */ 
/*     */         
/* 819 */         int cIndex = cfr.getClassIndex();
/* 820 */         ConstantClass cc = (ConstantClass)this.pool[cIndex];
/* 821 */         String cName = ((ConstantUtf8)this.pool[cc.getNameIndex()]).getValue();
/* 822 */         if (cName.equals(searchClassname)) {
/*     */ 
/*     */ 
/*     */           
/* 826 */           String name = ((ConstantUtf8)this.pool[cnat.getNameIndex()]).getValue();
/* 827 */           if (name.equals(searchMethodName))
/*     */           
/* 829 */           { String typeSignature = ((ConstantUtf8)this.pool[cnat.getSignatureIndex()]).getValue();
/* 830 */             if (typeSignature.equals(searchSignature))
/*     */             
/* 832 */             { this.methodCache.put(key, Integer.valueOf(i));
/* 833 */               return i; }  } 
/*     */         } 
/*     */       } 
/* 836 */     }  return -1;
/*     */   }
/*     */   
/*     */   public ConstantPool getFinalConstantPool() {
/* 840 */     Constant[] cs = new Constant[this.poolSize];
/* 841 */     System.arraycopy(this.pool, 0, cs, 0, this.poolSize);
/* 842 */     return new ConstantPool(cs);
/*     */   }
/*     */   
/*     */   public String getModuleName(int moduleIndex) {
/* 846 */     return getConstantModule(moduleIndex).getModuleName(this);
/*     */   }
/*     */   
/*     */   public String getPackageName(int packageIndex) {
/* 850 */     return getConstantPackage(packageIndex).getPackageName(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */