/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariableTable
/*     */   extends Attribute
/*     */ {
/*     */   private boolean isInPackedState = false;
/*     */   private byte[] data;
/*     */   private int localVariableTableLength;
/*     */   private LocalVariable[] localVariableTable;
/*     */   
/*     */   public LocalVariableTable(LocalVariableTable c) {
/*  86 */     this(c.getNameIndex(), c.getLength(), c.getLocalVariableTable(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariableTable(int name_index, int length, LocalVariable[] local_variable_table, ConstantPool constant_pool) {
/*  96 */     super((byte)5, name_index, length, constant_pool);
/*  97 */     setLocalVariableTable(local_variable_table);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LocalVariableTable(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 110 */     super((byte)5, name_index, length, constant_pool);
/* 111 */     this.data = new byte[length];
/* 112 */     file.readFully(this.data);
/* 113 */     this.isInPackedState = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 125 */     unpack();
/* 126 */     v.visitLocalVariableTable(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void dump(DataOutputStream file) throws IOException {
/* 137 */     super.dump(file);
/* 138 */     if (this.isInPackedState) {
/* 139 */       file.write(this.data);
/*     */     } else {
/* 141 */       file.writeShort(this.localVariableTableLength);
/* 142 */       for (int i = 0; i < this.localVariableTableLength; i++) {
/* 143 */         this.localVariableTable[i].dump(file);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final LocalVariable[] getLocalVariableTable() {
/* 151 */     unpack();
/* 152 */     return this.localVariableTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LocalVariable getLocalVariable(int index) {
/* 159 */     unpack();
/* 160 */     for (int i = 0; i < this.localVariableTableLength; i++) {
/* 161 */       if (this.localVariableTable[i] != null && this.localVariableTable[i].getIndex() == index) {
/* 162 */         return this.localVariableTable[i];
/*     */       }
/*     */     } 
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   public final synchronized void setLocalVariableTable(LocalVariable[] local_variable_table) {
/* 169 */     this.data = null;
/* 170 */     this.isInPackedState = false;
/* 171 */     this.localVariableTable = local_variable_table;
/* 172 */     this.localVariableTableLength = (local_variable_table == null) ? 0 : local_variable_table.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 180 */     StringBuilder buf = new StringBuilder("");
/* 181 */     unpack();
/* 182 */     for (int i = 0; i < this.localVariableTableLength; i++) {
/* 183 */       buf.append(this.localVariableTable[i].toString());
/*     */       
/* 185 */       if (i < this.localVariableTableLength - 1) {
/* 186 */         buf.append('\n');
/*     */       }
/*     */     } 
/* 189 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized LocalVariableTable copyFromPackedState() {
/* 196 */     if (!this.isInPackedState) throw new IllegalStateException("No in packed state"); 
/*     */     try {
/* 198 */       return new LocalVariableTable(this.nameIndex, this.length, new DataInputStream(new ByteArrayInputStream(this.data)), getConstantPool());
/* 199 */     } catch (IOException e) {
/* 200 */       throw new RuntimeException("Failed to unpack clone", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTableLength() {
/* 219 */     unpack();
/* 220 */     return this.localVariableTableLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void unpack() {
/* 226 */     if (!this.isInPackedState)
/*     */       return; 
/*     */     try {
/* 229 */       ByteArrayInputStream bs = new ByteArrayInputStream(this.data);
/* 230 */       DataInputStream dis = new DataInputStream(bs);
/* 231 */       this.localVariableTableLength = dis.readUnsignedShort();
/* 232 */       this.localVariableTable = new LocalVariable[this.localVariableTableLength];
/* 233 */       for (int i = 0; i < this.localVariableTableLength; i++)
/* 234 */         this.localVariableTable[i] = new LocalVariable(dis, this.cpool); 
/* 235 */       dis.close();
/* 236 */       this.data = null;
/* 237 */     } catch (IOException e) {
/* 238 */       throw new RuntimeException("Unpacking of LocalVariableTable attribute failed", e);
/*     */     } 
/* 240 */     this.isInPackedState = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\LocalVariableTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */