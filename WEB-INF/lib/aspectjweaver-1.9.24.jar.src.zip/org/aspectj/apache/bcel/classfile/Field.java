/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Field
/*     */   extends FieldOrMethod
/*     */ {
/*  70 */   public static final Field[] NoFields = new Field[0];
/*     */   
/*  72 */   private Type fieldType = null;
/*     */ 
/*     */   
/*     */   private Field() {}
/*     */   
/*     */   public Field(Field c) {
/*  78 */     super(c);
/*     */   }
/*     */   
/*     */   Field(DataInputStream dis, ConstantPool cpool) throws IOException {
/*  82 */     super(dis, cpool);
/*     */   }
/*     */   
/*     */   public Field(int modifiers, int nameIndex, int signatureIndex, Attribute[] attributes, ConstantPool cpool) {
/*  86 */     super(modifiers, nameIndex, signatureIndex, attributes, cpool);
/*     */   }
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  90 */     v.visitField(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConstantValue getConstantValue() {
/*  97 */     return AttributeUtils.getConstantValueAttribute(this.attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 106 */     StringBuilder buf = new StringBuilder(Utility.accessToString(this.modifiers));
/* 107 */     if (buf.length() > 0) {
/* 108 */       buf.append(" ");
/*     */     }
/* 110 */     String signature = Utility.signatureToString(getSignature());
/*     */     
/* 112 */     buf.append(signature).append(" ").append(getName());
/*     */     
/* 114 */     ConstantValue cv = getConstantValue();
/* 115 */     if (cv != null) {
/* 116 */       buf.append(" = ").append(cv);
/*     */     }
/*     */ 
/*     */     
/* 120 */     for (Attribute a : this.attributes) {
/* 121 */       if (!(a instanceof ConstantValue)) {
/* 122 */         buf.append(" [").append(a.toString()).append("]");
/*     */       }
/*     */     } 
/*     */     
/* 126 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 131 */     if (this.fieldType == null) {
/* 132 */       this.fieldType = Type.getReturnType(getSignature());
/*     */     }
/* 134 */     return this.fieldType;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Field.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */