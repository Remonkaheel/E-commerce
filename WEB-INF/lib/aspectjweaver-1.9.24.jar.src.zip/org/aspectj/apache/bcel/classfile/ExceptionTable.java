/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExceptionTable
/*     */   extends Attribute
/*     */ {
/*     */   private int number_of_exceptions;
/*     */   private int[] exception_index_table;
/*     */   
/*     */   public ExceptionTable(ExceptionTable c) {
/*  81 */     this(c.getNameIndex(), c.getLength(), c.getExceptionIndexTable(), c.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionTable(int name_index, int length, int[] exception_index_table, ConstantPool constant_pool) {
/*  91 */     super((byte)3, name_index, length, constant_pool);
/*  92 */     setExceptionIndexTable(exception_index_table);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExceptionTable(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 105 */     this(name_index, length, (int[])null, constant_pool);
/*     */     
/* 107 */     this.number_of_exceptions = file.readUnsignedShort();
/* 108 */     this.exception_index_table = new int[this.number_of_exceptions];
/*     */     
/* 110 */     for (int i = 0; i < this.number_of_exceptions; i++) {
/* 111 */       this.exception_index_table[i] = file.readUnsignedShort();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 122 */     v.visitExceptionTable(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 133 */     super.dump(file);
/* 134 */     file.writeShort(this.number_of_exceptions);
/* 135 */     for (int i = 0; i < this.number_of_exceptions; i++) {
/* 136 */       file.writeShort(this.exception_index_table[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int[] getExceptionIndexTable() {
/* 143 */     return this.exception_index_table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNumberOfExceptions() {
/* 150 */     return this.number_of_exceptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getExceptionNames() {
/* 157 */     String[] names = new String[this.number_of_exceptions];
/* 158 */     for (int i = 0; i < this.number_of_exceptions; i++)
/* 159 */       names[i] = this.cpool.getConstantString(this.exception_index_table[i], (byte)7).replace('/', '.'); 
/* 160 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setExceptionIndexTable(int[] exception_index_table) {
/* 167 */     this.exception_index_table = exception_index_table;
/* 168 */     this.number_of_exceptions = (exception_index_table == null) ? 0 : exception_index_table.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 176 */     StringBuilder buf = new StringBuilder("");
/*     */ 
/*     */     
/* 179 */     for (int i = 0; i < this.number_of_exceptions; i++) {
/* 180 */       String str = this.cpool.getConstantString(this.exception_index_table[i], (byte)7);
/* 181 */       buf.append(Utility.compactClassName(str, false));
/*     */       
/* 183 */       if (i < this.number_of_exceptions - 1) {
/* 184 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 187 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ExceptionTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */