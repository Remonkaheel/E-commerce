/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantMethodType
/*     */   extends Constant
/*     */ {
/*     */   private int descriptorIndex;
/*     */   
/*     */   ConstantMethodType(DataInputStream file) throws IOException {
/*  76 */     this(file.readUnsignedShort());
/*     */   }
/*     */   
/*     */   public ConstantMethodType(int descriptorIndex) {
/*  80 */     super((byte)16);
/*  81 */     this.descriptorIndex = descriptorIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  86 */     file.writeByte(this.tag);
/*  87 */     file.writeShort(this.descriptorIndex);
/*     */   }
/*     */   
/*     */   public final int getDescriptorIndex() {
/*  91 */     return this.descriptorIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 108 */     return super.toString() + "(descriptorIndex=" + this.descriptorIndex + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 113 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 118 */     v.visitConstantMethodType(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantMethodType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */