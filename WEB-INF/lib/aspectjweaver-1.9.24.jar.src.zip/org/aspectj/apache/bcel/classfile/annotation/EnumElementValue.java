/*     */ package org.aspectj.apache.bcel.classfile.annotation;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantPool;
/*     */ import org.aspectj.apache.bcel.classfile.ConstantUtf8;
/*     */ import org.aspectj.apache.bcel.generic.ObjectType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumElementValue
/*     */   extends ElementValue
/*     */ {
/*     */   private int typeIdx;
/*     */   private int valueIdx;
/*     */   
/*     */   protected EnumElementValue(int typeIdx, int valueIdx, ConstantPool cpool) {
/*  34 */     super(101, cpool);
/*  35 */     if (this.type != 101) {
/*  36 */       throw new RuntimeException("Only element values of type enum can be built with this ctor");
/*     */     }
/*  38 */     this.typeIdx = typeIdx;
/*  39 */     this.valueIdx = valueIdx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumElementValue(ObjectType t, String value, ConstantPool cpool) {
/*  51 */     super(101, cpool);
/*  52 */     this.typeIdx = cpool.addUtf8(t.getSignature());
/*  53 */     this.valueIdx = cpool.addUtf8(value);
/*     */   }
/*     */   
/*     */   public EnumElementValue(EnumElementValue value, ConstantPool cpool, boolean copyPoolEntries) {
/*  57 */     super(101, cpool);
/*  58 */     if (copyPoolEntries) {
/*  59 */       this.typeIdx = cpool.addUtf8(value.getEnumTypeString());
/*  60 */       this.valueIdx = cpool.addUtf8(value.getEnumValueString());
/*     */     } else {
/*  62 */       this.typeIdx = value.getTypeIndex();
/*  63 */       this.valueIdx = value.getValueIndex();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream dos) throws IOException {
/*  69 */     dos.writeByte(this.type);
/*  70 */     dos.writeShort(this.typeIdx);
/*  71 */     dos.writeShort(this.valueIdx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String stringifyValue() {
/*  79 */     StringBuilder sb = new StringBuilder();
/*  80 */     ConstantUtf8 cu8 = (ConstantUtf8)this.cpool.getConstant(this.typeIdx, (byte)1);
/*  81 */     sb.append(cu8.getValue());
/*  82 */     cu8 = (ConstantUtf8)this.cpool.getConstant(this.valueIdx, (byte)1);
/*  83 */     sb.append(cu8.getValue());
/*  84 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  88 */     StringBuilder s = new StringBuilder("E(");
/*  89 */     s.append(getEnumTypeString()).append(" ").append(getEnumValueString()).append(")");
/*  90 */     return s.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEnumTypeString() {
/*  98 */     return ((ConstantUtf8)getConstantPool().getConstant(this.typeIdx)).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEnumValueString() {
/* 103 */     return ((ConstantUtf8)getConstantPool().getConstant(this.valueIdx)).getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueIndex() {
/* 109 */     return this.valueIdx;
/*     */   }
/*     */   
/*     */   public int getTypeIndex() {
/* 113 */     return this.typeIdx;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\annotation\EnumElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */