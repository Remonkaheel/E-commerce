/*    */ package org.aspectj.apache.bcel.classfile;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConstantInterfaceMethodref
/*    */   extends ConstantCP
/*    */ {
/*    */   ConstantInterfaceMethodref(DataInputStream file) throws IOException {
/* 71 */     super((byte)11, file);
/*    */   }
/*    */   
/*    */   public ConstantInterfaceMethodref(int classIndex, int nameAndTypeIndex) {
/* 75 */     super((byte)11, classIndex, nameAndTypeIndex);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ClassVisitor v) {
/* 80 */     v.visitConstantInterfaceMethodref(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 85 */     return toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantInterfaceMethodref.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */