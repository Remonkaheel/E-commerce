/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantClass
/*     */   extends Constant
/*     */ {
/*     */   private int nameIndex;
/*     */   
/*     */   ConstantClass(DataInputStream file) throws IOException {
/*  75 */     super((byte)7);
/*  76 */     this.nameIndex = file.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public ConstantClass(int nameIndex) {
/*  80 */     super((byte)7);
/*  81 */     this.nameIndex = nameIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor v) {
/*  86 */     v.visitConstantClass(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/*  91 */     file.writeByte(this.tag);
/*  92 */     file.writeShort(this.nameIndex);
/*     */   }
/*     */   
/*     */   public final int getNameIndex() {
/*  96 */     return this.nameIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getValue() {
/* 101 */     return Integer.valueOf(this.nameIndex);
/*     */   }
/*     */   
/*     */   public String getClassname(ConstantPool cpool) {
/* 105 */     return cpool.getConstantUtf8(this.nameIndex).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 110 */     return super.toString() + "(name_index = " + this.nameIndex + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\ConstantClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */