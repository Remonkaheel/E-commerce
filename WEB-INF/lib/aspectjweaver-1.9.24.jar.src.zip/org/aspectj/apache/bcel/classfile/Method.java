/*     */ package org.aspectj.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.AnnotationGen;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeInvisParamAnnos;
/*     */ import org.aspectj.apache.bcel.classfile.annotation.RuntimeVisParamAnnos;
/*     */ import org.aspectj.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Method
/*     */   extends FieldOrMethod
/*     */ {
/*  76 */   public static final AnnotationGen[][] NO_PARAMETER_ANNOTATIONS = new AnnotationGen[0][];
/*     */   
/*  78 */   public static final Method[] NoMethods = new Method[0];
/*     */   
/*     */   private boolean parameterAnnotationsOutOfDate = true;
/*     */   private AnnotationGen[][] unpackedParameterAnnotations;
/*     */   
/*     */   private Method() {
/*  84 */     this.parameterAnnotationsOutOfDate = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method(Method c) {
/*  92 */     super(c);
/*  93 */     this.parameterAnnotationsOutOfDate = true;
/*     */   }
/*     */   
/*     */   Method(DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  97 */     super(file, constant_pool);
/*     */   }
/*     */   
/*     */   public Method(int access_flags, int name_index, int signature_index, Attribute[] attributes, ConstantPool constant_pool) {
/* 101 */     super(access_flags, name_index, signature_index, attributes, constant_pool);
/* 102 */     this.parameterAnnotationsOutOfDate = true;
/*     */   }
/*     */   
/*     */   public void accept(ClassVisitor v) {
/* 106 */     v.visitMethod(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Attribute[] attributes) {
/* 112 */     this.parameterAnnotationsOutOfDate = true;
/* 113 */     super.setAttributes(attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Code getCode() {
/* 120 */     return AttributeUtils.getCodeAttribute(this.attributes);
/*     */   }
/*     */   
/*     */   public final ExceptionTable getExceptionTable() {
/* 124 */     return AttributeUtils.getExceptionTableAttribute(this.attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LocalVariableTable getLocalVariableTable() {
/* 131 */     Code code = getCode();
/* 132 */     if (code != null)
/* 133 */       return code.getLocalVariableTable(); 
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LineNumberTable getLineNumberTable() {
/* 141 */     Code code = getCode();
/* 142 */     if (code != null)
/* 143 */       return code.getLineNumberTable(); 
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 156 */     String access = Utility.accessToString(this.modifiers);
/*     */ 
/*     */     
/* 159 */     ConstantUtf8 c = (ConstantUtf8)this.cpool.getConstant(this.signatureIndex, (byte)1);
/* 160 */     String signature = c.getValue();
/*     */     
/* 162 */     c = (ConstantUtf8)this.cpool.getConstant(this.nameIndex, (byte)1);
/* 163 */     String name = c.getValue();
/*     */     
/* 165 */     signature = Utility.methodSignatureToString(signature, name, access, true, getLocalVariableTable());
/* 166 */     StringBuilder buf = new StringBuilder(signature);
/*     */     
/* 168 */     for (Attribute a : this.attributes) {
/* 169 */       if (!(a instanceof Code) && !(a instanceof ExceptionTable)) {
/* 170 */         buf.append(" [" + a.toString() + "]");
/*     */       }
/*     */     } 
/* 173 */     ExceptionTable e = getExceptionTable();
/* 174 */     if (e != null) {
/* 175 */       String str = e.toString();
/* 176 */       if (!str.equals("")) {
/* 177 */         buf.append("\n\t\tthrows " + str);
/*     */       }
/*     */     } 
/* 180 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getReturnType() {
/* 187 */     return Type.getReturnType(getSignature());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type[] getArgumentTypes() {
/* 194 */     return Type.getArgumentTypes(getSignature());
/*     */   }
/*     */   
/*     */   private void ensureParameterAnnotationsUnpacked() {
/* 198 */     if (!this.parameterAnnotationsOutOfDate)
/*     */       return; 
/* 200 */     this.parameterAnnotationsOutOfDate = false;
/*     */     
/* 202 */     int parameterCount = (getArgumentTypes()).length;
/* 203 */     if (parameterCount == 0) {
/* 204 */       this.unpackedParameterAnnotations = NO_PARAMETER_ANNOTATIONS;
/*     */       
/*     */       return;
/*     */     } 
/* 208 */     RuntimeVisParamAnnos parameterAnnotationsVis = null;
/* 209 */     RuntimeInvisParamAnnos parameterAnnotationsInvis = null;
/*     */ 
/*     */     
/* 212 */     Attribute[] attrs = getAttributes();
/*     */     
/* 214 */     for (Attribute attribute : attrs) {
/* 215 */       if (attribute instanceof RuntimeVisParamAnnos) {
/* 216 */         parameterAnnotationsVis = (RuntimeVisParamAnnos)attribute;
/*     */       }
/* 218 */       else if (attribute instanceof RuntimeInvisParamAnnos) {
/* 219 */         parameterAnnotationsInvis = (RuntimeInvisParamAnnos)attribute;
/*     */       } 
/*     */     } 
/*     */     
/* 223 */     boolean foundSome = false;
/*     */     
/* 225 */     if (parameterAnnotationsInvis != null || parameterAnnotationsVis != null) {
/* 226 */       List<AnnotationGen[]> annotationsForEachParameter = (List)new ArrayList<>();
/* 227 */       AnnotationGen[] visibleOnes = null;
/* 228 */       AnnotationGen[] invisibleOnes = null;
/* 229 */       for (int i = 0; i < parameterCount; i++) {
/* 230 */         int count = 0;
/* 231 */         visibleOnes = AnnotationGen.NO_ANNOTATIONS;
/* 232 */         invisibleOnes = AnnotationGen.NO_ANNOTATIONS;
/* 233 */         if (parameterAnnotationsVis != null) {
/* 234 */           visibleOnes = parameterAnnotationsVis.getAnnotationsOnParameter(i);
/* 235 */           count += visibleOnes.length;
/*     */         } 
/* 237 */         if (parameterAnnotationsInvis != null) {
/* 238 */           invisibleOnes = parameterAnnotationsInvis.getAnnotationsOnParameter(i);
/* 239 */           count += invisibleOnes.length;
/*     */         } 
/*     */         
/* 242 */         AnnotationGen[] complete = AnnotationGen.NO_ANNOTATIONS;
/* 243 */         if (count != 0) {
/* 244 */           complete = new AnnotationGen[visibleOnes.length + invisibleOnes.length];
/* 245 */           System.arraycopy(visibleOnes, 0, complete, 0, visibleOnes.length);
/* 246 */           System.arraycopy(invisibleOnes, 0, complete, visibleOnes.length, invisibleOnes.length);
/* 247 */           foundSome = true;
/*     */         } 
/* 249 */         annotationsForEachParameter.add(complete);
/*     */       } 
/* 251 */       if (foundSome) {
/* 252 */         this.unpackedParameterAnnotations = annotationsForEachParameter.<AnnotationGen[]>toArray(new AnnotationGen[0][]);
/*     */         return;
/*     */       } 
/*     */     } 
/* 256 */     this.unpackedParameterAnnotations = NO_PARAMETER_ANNOTATIONS;
/*     */   }
/*     */   
/*     */   public AnnotationGen[] getAnnotationsOnParameter(int i) {
/* 260 */     ensureParameterAnnotationsUnpacked();
/* 261 */     if (this.unpackedParameterAnnotations == NO_PARAMETER_ANNOTATIONS) {
/* 262 */       return AnnotationGen.NO_ANNOTATIONS;
/*     */     }
/* 264 */     return this.unpackedParameterAnnotations[i];
/*     */   }
/*     */   
/*     */   public AnnotationGen[][] getParameterAnnotations() {
/* 268 */     ensureParameterAnnotationsUnpacked();
/* 269 */     return this.unpackedParameterAnnotations;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\org\aspectj\apache\bcel\classfile\Method.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */