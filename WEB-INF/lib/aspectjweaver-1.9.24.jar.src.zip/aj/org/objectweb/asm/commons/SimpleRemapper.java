/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleRemapper
/*     */   extends Remapper
/*     */ {
/*     */   private final Map<String, String> mapping;
/*     */   
/*     */   public SimpleRemapper(Map<String, String> mapping) {
/*  63 */     this.mapping = mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleRemapper(String oldName, String newName) {
/*  75 */     this.mapping = Collections.singletonMap(oldName, newName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapMethodName(String owner, String name, String descriptor) {
/*  80 */     String remappedName = map(stringConcat$0(owner, name, descriptor));
/*  81 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapInvokeDynamicMethodName(String name, String descriptor) {
/*  86 */     String remappedName = map(stringConcat$1(name, descriptor));
/*  87 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapAnnotationAttributeName(String descriptor, String name) {
/*  92 */     String remappedName = map(stringConcat$2(descriptor, name));
/*  93 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapFieldName(String owner, String name, String descriptor) {
/*  98 */     String remappedName = map(stringConcat$3(owner, name));
/*  99 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String map(String key) {
/* 104 */     return this.mapping.get(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\SimpleRemapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */