/*      */ package aj.org.objectweb.asm.commons;
/*      */ 
/*      */ import aj.org.objectweb.asm.ConstantDynamic;
/*      */ import aj.org.objectweb.asm.Handle;
/*      */ import aj.org.objectweb.asm.Label;
/*      */ import aj.org.objectweb.asm.MethodVisitor;
/*      */ import aj.org.objectweb.asm.Type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class InstructionAdapter
/*      */   extends MethodVisitor
/*      */ {
/*   46 */   public static final Type OBJECT_TYPE = Type.getType("Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InstructionAdapter(MethodVisitor methodVisitor) {
/*   56 */     this(589824, methodVisitor);
/*   57 */     if (getClass() != InstructionAdapter.class) {
/*   58 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InstructionAdapter(int api, MethodVisitor methodVisitor) {
/*   70 */     super(api, methodVisitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitInsn(int opcode) {
/*   75 */     switch (opcode) {
/*      */       case 0:
/*   77 */         nop();
/*      */         return;
/*      */       case 1:
/*   80 */         aconst((Object)null);
/*      */         return;
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*   89 */         iconst(opcode - 3);
/*      */         return;
/*      */       case 9:
/*      */       case 10:
/*   93 */         lconst((opcode - 9));
/*      */         return;
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*   98 */         fconst((opcode - 11));
/*      */         return;
/*      */       case 14:
/*      */       case 15:
/*  102 */         dconst((opcode - 14));
/*      */         return;
/*      */       case 46:
/*  105 */         aload(Type.INT_TYPE);
/*      */         return;
/*      */       case 47:
/*  108 */         aload(Type.LONG_TYPE);
/*      */         return;
/*      */       case 48:
/*  111 */         aload(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 49:
/*  114 */         aload(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 50:
/*  117 */         aload(OBJECT_TYPE);
/*      */         return;
/*      */       case 51:
/*  120 */         aload(Type.BYTE_TYPE);
/*      */         return;
/*      */       case 52:
/*  123 */         aload(Type.CHAR_TYPE);
/*      */         return;
/*      */       case 53:
/*  126 */         aload(Type.SHORT_TYPE);
/*      */         return;
/*      */       case 79:
/*  129 */         astore(Type.INT_TYPE);
/*      */         return;
/*      */       case 80:
/*  132 */         astore(Type.LONG_TYPE);
/*      */         return;
/*      */       case 81:
/*  135 */         astore(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 82:
/*  138 */         astore(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 83:
/*  141 */         astore(OBJECT_TYPE);
/*      */         return;
/*      */       case 84:
/*  144 */         astore(Type.BYTE_TYPE);
/*      */         return;
/*      */       case 85:
/*  147 */         astore(Type.CHAR_TYPE);
/*      */         return;
/*      */       case 86:
/*  150 */         astore(Type.SHORT_TYPE);
/*      */         return;
/*      */       case 87:
/*  153 */         pop();
/*      */         return;
/*      */       case 88:
/*  156 */         pop2();
/*      */         return;
/*      */       case 89:
/*  159 */         dup();
/*      */         return;
/*      */       case 90:
/*  162 */         dupX1();
/*      */         return;
/*      */       case 91:
/*  165 */         dupX2();
/*      */         return;
/*      */       case 92:
/*  168 */         dup2();
/*      */         return;
/*      */       case 93:
/*  171 */         dup2X1();
/*      */         return;
/*      */       case 94:
/*  174 */         dup2X2();
/*      */         return;
/*      */       case 95:
/*  177 */         swap();
/*      */         return;
/*      */       case 96:
/*  180 */         add(Type.INT_TYPE);
/*      */         return;
/*      */       case 97:
/*  183 */         add(Type.LONG_TYPE);
/*      */         return;
/*      */       case 98:
/*  186 */         add(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 99:
/*  189 */         add(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 100:
/*  192 */         sub(Type.INT_TYPE);
/*      */         return;
/*      */       case 101:
/*  195 */         sub(Type.LONG_TYPE);
/*      */         return;
/*      */       case 102:
/*  198 */         sub(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 103:
/*  201 */         sub(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 104:
/*  204 */         mul(Type.INT_TYPE);
/*      */         return;
/*      */       case 105:
/*  207 */         mul(Type.LONG_TYPE);
/*      */         return;
/*      */       case 106:
/*  210 */         mul(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 107:
/*  213 */         mul(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 108:
/*  216 */         div(Type.INT_TYPE);
/*      */         return;
/*      */       case 109:
/*  219 */         div(Type.LONG_TYPE);
/*      */         return;
/*      */       case 110:
/*  222 */         div(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 111:
/*  225 */         div(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 112:
/*  228 */         rem(Type.INT_TYPE);
/*      */         return;
/*      */       case 113:
/*  231 */         rem(Type.LONG_TYPE);
/*      */         return;
/*      */       case 114:
/*  234 */         rem(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 115:
/*  237 */         rem(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 116:
/*  240 */         neg(Type.INT_TYPE);
/*      */         return;
/*      */       case 117:
/*  243 */         neg(Type.LONG_TYPE);
/*      */         return;
/*      */       case 118:
/*  246 */         neg(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 119:
/*  249 */         neg(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 120:
/*  252 */         shl(Type.INT_TYPE);
/*      */         return;
/*      */       case 121:
/*  255 */         shl(Type.LONG_TYPE);
/*      */         return;
/*      */       case 122:
/*  258 */         shr(Type.INT_TYPE);
/*      */         return;
/*      */       case 123:
/*  261 */         shr(Type.LONG_TYPE);
/*      */         return;
/*      */       case 124:
/*  264 */         ushr(Type.INT_TYPE);
/*      */         return;
/*      */       case 125:
/*  267 */         ushr(Type.LONG_TYPE);
/*      */         return;
/*      */       case 126:
/*  270 */         and(Type.INT_TYPE);
/*      */         return;
/*      */       case 127:
/*  273 */         and(Type.LONG_TYPE);
/*      */         return;
/*      */       case 128:
/*  276 */         or(Type.INT_TYPE);
/*      */         return;
/*      */       case 129:
/*  279 */         or(Type.LONG_TYPE);
/*      */         return;
/*      */       case 130:
/*  282 */         xor(Type.INT_TYPE);
/*      */         return;
/*      */       case 131:
/*  285 */         xor(Type.LONG_TYPE);
/*      */         return;
/*      */       case 133:
/*  288 */         cast(Type.INT_TYPE, Type.LONG_TYPE);
/*      */         return;
/*      */       case 134:
/*  291 */         cast(Type.INT_TYPE, Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 135:
/*  294 */         cast(Type.INT_TYPE, Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 136:
/*  297 */         cast(Type.LONG_TYPE, Type.INT_TYPE);
/*      */         return;
/*      */       case 137:
/*  300 */         cast(Type.LONG_TYPE, Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 138:
/*  303 */         cast(Type.LONG_TYPE, Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 139:
/*  306 */         cast(Type.FLOAT_TYPE, Type.INT_TYPE);
/*      */         return;
/*      */       case 140:
/*  309 */         cast(Type.FLOAT_TYPE, Type.LONG_TYPE);
/*      */         return;
/*      */       case 141:
/*  312 */         cast(Type.FLOAT_TYPE, Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 142:
/*  315 */         cast(Type.DOUBLE_TYPE, Type.INT_TYPE);
/*      */         return;
/*      */       case 143:
/*  318 */         cast(Type.DOUBLE_TYPE, Type.LONG_TYPE);
/*      */         return;
/*      */       case 144:
/*  321 */         cast(Type.DOUBLE_TYPE, Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 145:
/*  324 */         cast(Type.INT_TYPE, Type.BYTE_TYPE);
/*      */         return;
/*      */       case 146:
/*  327 */         cast(Type.INT_TYPE, Type.CHAR_TYPE);
/*      */         return;
/*      */       case 147:
/*  330 */         cast(Type.INT_TYPE, Type.SHORT_TYPE);
/*      */         return;
/*      */       case 148:
/*  333 */         lcmp();
/*      */         return;
/*      */       case 149:
/*  336 */         cmpl(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 150:
/*  339 */         cmpg(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 151:
/*  342 */         cmpl(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 152:
/*  345 */         cmpg(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 172:
/*  348 */         areturn(Type.INT_TYPE);
/*      */         return;
/*      */       case 173:
/*  351 */         areturn(Type.LONG_TYPE);
/*      */         return;
/*      */       case 174:
/*  354 */         areturn(Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 175:
/*  357 */         areturn(Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 176:
/*  360 */         areturn(OBJECT_TYPE);
/*      */         return;
/*      */       case 177:
/*  363 */         areturn(Type.VOID_TYPE);
/*      */         return;
/*      */       case 190:
/*  366 */         arraylength();
/*      */         return;
/*      */       case 191:
/*  369 */         athrow();
/*      */         return;
/*      */       case 194:
/*  372 */         monitorenter();
/*      */         return;
/*      */       case 195:
/*  375 */         monitorexit();
/*      */         return;
/*      */     } 
/*  378 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIntInsn(int opcode, int operand) {
/*  384 */     switch (opcode) {
/*      */       case 16:
/*  386 */         iconst(operand);
/*      */         return;
/*      */       case 17:
/*  389 */         iconst(operand);
/*      */         return;
/*      */       case 188:
/*  392 */         switch (operand) {
/*      */           case 4:
/*  394 */             newarray(Type.BOOLEAN_TYPE);
/*      */             return;
/*      */           case 5:
/*  397 */             newarray(Type.CHAR_TYPE);
/*      */             return;
/*      */           case 8:
/*  400 */             newarray(Type.BYTE_TYPE);
/*      */             return;
/*      */           case 9:
/*  403 */             newarray(Type.SHORT_TYPE);
/*      */             return;
/*      */           case 10:
/*  406 */             newarray(Type.INT_TYPE);
/*      */             return;
/*      */           case 6:
/*  409 */             newarray(Type.FLOAT_TYPE);
/*      */             return;
/*      */           case 11:
/*  412 */             newarray(Type.LONG_TYPE);
/*      */             return;
/*      */           case 7:
/*  415 */             newarray(Type.DOUBLE_TYPE);
/*      */             return;
/*      */         } 
/*  418 */         throw new IllegalArgumentException();
/*      */     } 
/*      */ 
/*      */     
/*  422 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitVarInsn(int opcode, int varIndex) {
/*  428 */     switch (opcode) {
/*      */       case 21:
/*  430 */         load(varIndex, Type.INT_TYPE);
/*      */         return;
/*      */       case 22:
/*  433 */         load(varIndex, Type.LONG_TYPE);
/*      */         return;
/*      */       case 23:
/*  436 */         load(varIndex, Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 24:
/*  439 */         load(varIndex, Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 25:
/*  442 */         load(varIndex, OBJECT_TYPE);
/*      */         return;
/*      */       case 54:
/*  445 */         store(varIndex, Type.INT_TYPE);
/*      */         return;
/*      */       case 55:
/*  448 */         store(varIndex, Type.LONG_TYPE);
/*      */         return;
/*      */       case 56:
/*  451 */         store(varIndex, Type.FLOAT_TYPE);
/*      */         return;
/*      */       case 57:
/*  454 */         store(varIndex, Type.DOUBLE_TYPE);
/*      */         return;
/*      */       case 58:
/*  457 */         store(varIndex, OBJECT_TYPE);
/*      */         return;
/*      */       case 169:
/*  460 */         ret(varIndex);
/*      */         return;
/*      */     } 
/*  463 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitTypeInsn(int opcode, String type) {
/*  469 */     Type objectType = Type.getObjectType(type);
/*  470 */     switch (opcode) {
/*      */       case 187:
/*  472 */         anew(objectType);
/*      */         return;
/*      */       case 189:
/*  475 */         newarray(objectType);
/*      */         return;
/*      */       case 192:
/*  478 */         checkcast(objectType);
/*      */         return;
/*      */       case 193:
/*  481 */         instanceOf(objectType);
/*      */         return;
/*      */     } 
/*  484 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
/*  491 */     switch (opcode) {
/*      */       case 178:
/*  493 */         getstatic(owner, name, descriptor);
/*      */         return;
/*      */       case 179:
/*  496 */         putstatic(owner, name, descriptor);
/*      */         return;
/*      */       case 180:
/*  499 */         getfield(owner, name, descriptor);
/*      */         return;
/*      */       case 181:
/*  502 */         putfield(owner, name, descriptor);
/*      */         return;
/*      */     } 
/*  505 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitMethodInsn(int opcodeAndSource, String owner, String name, String descriptor, boolean isInterface) {
/*  516 */     if (this.api < 327680 && (opcodeAndSource & 0x100) == 0) {
/*      */       
/*  518 */       super.visitMethodInsn(opcodeAndSource, owner, name, descriptor, isInterface);
/*      */       return;
/*      */     } 
/*  521 */     int opcode = opcodeAndSource & 0xFFFFFEFF;
/*      */     
/*  523 */     switch (opcode) {
/*      */       case 183:
/*  525 */         invokespecial(owner, name, descriptor, isInterface);
/*      */         return;
/*      */       case 182:
/*  528 */         invokevirtual(owner, name, descriptor, isInterface);
/*      */         return;
/*      */       case 184:
/*  531 */         invokestatic(owner, name, descriptor, isInterface);
/*      */         return;
/*      */       case 185:
/*  534 */         invokeinterface(owner, name, descriptor);
/*      */         return;
/*      */     } 
/*  537 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/*  547 */     invokedynamic(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitJumpInsn(int opcode, Label label) {
/*  552 */     switch (opcode) {
/*      */       case 153:
/*  554 */         ifeq(label);
/*      */         return;
/*      */       case 154:
/*  557 */         ifne(label);
/*      */         return;
/*      */       case 155:
/*  560 */         iflt(label);
/*      */         return;
/*      */       case 156:
/*  563 */         ifge(label);
/*      */         return;
/*      */       case 157:
/*  566 */         ifgt(label);
/*      */         return;
/*      */       case 158:
/*  569 */         ifle(label);
/*      */         return;
/*      */       case 159:
/*  572 */         ificmpeq(label);
/*      */         return;
/*      */       case 160:
/*  575 */         ificmpne(label);
/*      */         return;
/*      */       case 161:
/*  578 */         ificmplt(label);
/*      */         return;
/*      */       case 162:
/*  581 */         ificmpge(label);
/*      */         return;
/*      */       case 163:
/*  584 */         ificmpgt(label);
/*      */         return;
/*      */       case 164:
/*  587 */         ificmple(label);
/*      */         return;
/*      */       case 165:
/*  590 */         ifacmpeq(label);
/*      */         return;
/*      */       case 166:
/*  593 */         ifacmpne(label);
/*      */         return;
/*      */       case 167:
/*  596 */         goTo(label);
/*      */         return;
/*      */       case 168:
/*  599 */         jsr(label);
/*      */         return;
/*      */       case 198:
/*  602 */         ifnull(label);
/*      */         return;
/*      */       case 199:
/*  605 */         ifnonnull(label);
/*      */         return;
/*      */     } 
/*  608 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLabel(Label label) {
/*  614 */     mark(label);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitLdcInsn(Object value) {
/*  619 */     if (this.api < 327680 && (value instanceof Handle || (value instanceof Type && ((Type)value)
/*      */       
/*  621 */       .getSort() == 11))) {
/*  622 */       throw new UnsupportedOperationException("This feature requires ASM5");
/*      */     }
/*  624 */     if (this.api < 458752 && value instanceof ConstantDynamic) {
/*  625 */       throw new UnsupportedOperationException("This feature requires ASM7");
/*      */     }
/*  627 */     if (value instanceof Integer) {
/*  628 */       iconst(((Integer)value).intValue());
/*  629 */     } else if (value instanceof Byte) {
/*  630 */       iconst(((Byte)value).intValue());
/*  631 */     } else if (value instanceof Character) {
/*  632 */       iconst(((Character)value).charValue());
/*  633 */     } else if (value instanceof Short) {
/*  634 */       iconst(((Short)value).intValue());
/*  635 */     } else if (value instanceof Boolean) {
/*  636 */       iconst(((Boolean)value).booleanValue() ? 1 : 0);
/*  637 */     } else if (value instanceof Float) {
/*  638 */       fconst(((Float)value).floatValue());
/*  639 */     } else if (value instanceof Long) {
/*  640 */       lconst(((Long)value).longValue());
/*  641 */     } else if (value instanceof Double) {
/*  642 */       dconst(((Double)value).doubleValue());
/*  643 */     } else if (value instanceof String) {
/*  644 */       aconst(value);
/*  645 */     } else if (value instanceof Type) {
/*  646 */       tconst((Type)value);
/*  647 */     } else if (value instanceof Handle) {
/*  648 */       hconst((Handle)value);
/*  649 */     } else if (value instanceof ConstantDynamic) {
/*  650 */       cconst((ConstantDynamic)value);
/*      */     } else {
/*  652 */       throw new IllegalArgumentException();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitIincInsn(int varIndex, int increment) {
/*  658 */     iinc(varIndex, increment);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
/*  664 */     tableswitch(min, max, dflt, labels);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
/*  669 */     lookupswitch(dflt, keys, labels);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitMultiANewArrayInsn(String descriptor, int numDimensions) {
/*  674 */     multianewarray(descriptor, numDimensions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nop() {
/*  681 */     this.mv.visitInsn(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void aconst(Object value) {
/*  695 */     if (value == null) {
/*  696 */       this.mv.visitInsn(1);
/*      */     } else {
/*  698 */       this.mv.visitLdcInsn(value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void iconst(int intValue) {
/*  708 */     if (intValue >= -1 && intValue <= 5) {
/*  709 */       this.mv.visitInsn(3 + intValue);
/*  710 */     } else if (intValue >= -128 && intValue <= 127) {
/*  711 */       this.mv.visitIntInsn(16, intValue);
/*  712 */     } else if (intValue >= -32768 && intValue <= 32767) {
/*  713 */       this.mv.visitIntInsn(17, intValue);
/*      */     } else {
/*  715 */       this.mv.visitLdcInsn(Integer.valueOf(intValue));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lconst(long longValue) {
/*  725 */     if (longValue == 0L || longValue == 1L) {
/*  726 */       this.mv.visitInsn(9 + (int)longValue);
/*      */     } else {
/*  728 */       this.mv.visitLdcInsn(Long.valueOf(longValue));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fconst(float floatValue) {
/*  738 */     int bits = Float.floatToIntBits(floatValue);
/*  739 */     if (bits == 0L || bits == 1065353216 || bits == 1073741824) {
/*  740 */       this.mv.visitInsn(11 + (int)floatValue);
/*      */     } else {
/*  742 */       this.mv.visitLdcInsn(Float.valueOf(floatValue));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dconst(double doubleValue) {
/*  752 */     long bits = Double.doubleToLongBits(doubleValue);
/*  753 */     if (bits == 0L || bits == 4607182418800017408L) {
/*  754 */       this.mv.visitInsn(14 + (int)doubleValue);
/*      */     } else {
/*  756 */       this.mv.visitLdcInsn(Double.valueOf(doubleValue));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tconst(Type type) {
/*  766 */     this.mv.visitLdcInsn(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void hconst(Handle handle) {
/*  775 */     this.mv.visitLdcInsn(handle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cconst(ConstantDynamic constantDynamic) {
/*  784 */     this.mv.visitLdcInsn(constantDynamic);
/*      */   }
/*      */   
/*      */   public void load(int varIndex, Type type) {
/*  788 */     this.mv.visitVarInsn(type.getOpcode(21), varIndex);
/*      */   }
/*      */   
/*      */   public void aload(Type type) {
/*  792 */     this.mv.visitInsn(type.getOpcode(46));
/*      */   }
/*      */   
/*      */   public void store(int varIndex, Type type) {
/*  796 */     this.mv.visitVarInsn(type.getOpcode(54), varIndex);
/*      */   }
/*      */   
/*      */   public void astore(Type type) {
/*  800 */     this.mv.visitInsn(type.getOpcode(79));
/*      */   }
/*      */   
/*      */   public void pop() {
/*  804 */     this.mv.visitInsn(87);
/*      */   }
/*      */   
/*      */   public void pop2() {
/*  808 */     this.mv.visitInsn(88);
/*      */   }
/*      */   
/*      */   public void dup() {
/*  812 */     this.mv.visitInsn(89);
/*      */   }
/*      */   
/*      */   public void dup2() {
/*  816 */     this.mv.visitInsn(92);
/*      */   }
/*      */   
/*      */   public void dupX1() {
/*  820 */     this.mv.visitInsn(90);
/*      */   }
/*      */   
/*      */   public void dupX2() {
/*  824 */     this.mv.visitInsn(91);
/*      */   }
/*      */   
/*      */   public void dup2X1() {
/*  828 */     this.mv.visitInsn(93);
/*      */   }
/*      */   
/*      */   public void dup2X2() {
/*  832 */     this.mv.visitInsn(94);
/*      */   }
/*      */   
/*      */   public void swap() {
/*  836 */     this.mv.visitInsn(95);
/*      */   }
/*      */   
/*      */   public void add(Type type) {
/*  840 */     this.mv.visitInsn(type.getOpcode(96));
/*      */   }
/*      */   
/*      */   public void sub(Type type) {
/*  844 */     this.mv.visitInsn(type.getOpcode(100));
/*      */   }
/*      */   
/*      */   public void mul(Type type) {
/*  848 */     this.mv.visitInsn(type.getOpcode(104));
/*      */   }
/*      */   
/*      */   public void div(Type type) {
/*  852 */     this.mv.visitInsn(type.getOpcode(108));
/*      */   }
/*      */   
/*      */   public void rem(Type type) {
/*  856 */     this.mv.visitInsn(type.getOpcode(112));
/*      */   }
/*      */   
/*      */   public void neg(Type type) {
/*  860 */     this.mv.visitInsn(type.getOpcode(116));
/*      */   }
/*      */   
/*      */   public void shl(Type type) {
/*  864 */     this.mv.visitInsn(type.getOpcode(120));
/*      */   }
/*      */   
/*      */   public void shr(Type type) {
/*  868 */     this.mv.visitInsn(type.getOpcode(122));
/*      */   }
/*      */   
/*      */   public void ushr(Type type) {
/*  872 */     this.mv.visitInsn(type.getOpcode(124));
/*      */   }
/*      */   
/*      */   public void and(Type type) {
/*  876 */     this.mv.visitInsn(type.getOpcode(126));
/*      */   }
/*      */   
/*      */   public void or(Type type) {
/*  880 */     this.mv.visitInsn(type.getOpcode(128));
/*      */   }
/*      */   
/*      */   public void xor(Type type) {
/*  884 */     this.mv.visitInsn(type.getOpcode(130));
/*      */   }
/*      */   
/*      */   public void iinc(int varIndex, int increment) {
/*  888 */     this.mv.visitIincInsn(varIndex, increment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cast(Type from, Type to) {
/*  898 */     cast(this.mv, from, to);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void cast(MethodVisitor methodVisitor, Type from, Type to) {
/*  909 */     if (from != to) {
/*  910 */       if (from == Type.DOUBLE_TYPE) {
/*  911 */         if (to == Type.FLOAT_TYPE) {
/*  912 */           methodVisitor.visitInsn(144);
/*  913 */         } else if (to == Type.LONG_TYPE) {
/*  914 */           methodVisitor.visitInsn(143);
/*      */         } else {
/*  916 */           methodVisitor.visitInsn(142);
/*  917 */           cast(methodVisitor, Type.INT_TYPE, to);
/*      */         } 
/*  919 */       } else if (from == Type.FLOAT_TYPE) {
/*  920 */         if (to == Type.DOUBLE_TYPE) {
/*  921 */           methodVisitor.visitInsn(141);
/*  922 */         } else if (to == Type.LONG_TYPE) {
/*  923 */           methodVisitor.visitInsn(140);
/*      */         } else {
/*  925 */           methodVisitor.visitInsn(139);
/*  926 */           cast(methodVisitor, Type.INT_TYPE, to);
/*      */         } 
/*  928 */       } else if (from == Type.LONG_TYPE) {
/*  929 */         if (to == Type.DOUBLE_TYPE) {
/*  930 */           methodVisitor.visitInsn(138);
/*  931 */         } else if (to == Type.FLOAT_TYPE) {
/*  932 */           methodVisitor.visitInsn(137);
/*      */         } else {
/*  934 */           methodVisitor.visitInsn(136);
/*  935 */           cast(methodVisitor, Type.INT_TYPE, to);
/*      */         }
/*      */       
/*  938 */       } else if (to == Type.BYTE_TYPE) {
/*  939 */         methodVisitor.visitInsn(145);
/*  940 */       } else if (to == Type.CHAR_TYPE) {
/*  941 */         methodVisitor.visitInsn(146);
/*  942 */       } else if (to == Type.DOUBLE_TYPE) {
/*  943 */         methodVisitor.visitInsn(135);
/*  944 */       } else if (to == Type.FLOAT_TYPE) {
/*  945 */         methodVisitor.visitInsn(134);
/*  946 */       } else if (to == Type.LONG_TYPE) {
/*  947 */         methodVisitor.visitInsn(133);
/*  948 */       } else if (to == Type.SHORT_TYPE) {
/*  949 */         methodVisitor.visitInsn(147);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void lcmp() {
/*  956 */     this.mv.visitInsn(148);
/*      */   }
/*      */   
/*      */   public void cmpl(Type type) {
/*  960 */     this.mv.visitInsn((type == Type.FLOAT_TYPE) ? 149 : 151);
/*      */   }
/*      */   
/*      */   public void cmpg(Type type) {
/*  964 */     this.mv.visitInsn((type == Type.FLOAT_TYPE) ? 150 : 152);
/*      */   }
/*      */   
/*      */   public void ifeq(Label label) {
/*  968 */     this.mv.visitJumpInsn(153, label);
/*      */   }
/*      */   
/*      */   public void ifne(Label label) {
/*  972 */     this.mv.visitJumpInsn(154, label);
/*      */   }
/*      */   
/*      */   public void iflt(Label label) {
/*  976 */     this.mv.visitJumpInsn(155, label);
/*      */   }
/*      */   
/*      */   public void ifge(Label label) {
/*  980 */     this.mv.visitJumpInsn(156, label);
/*      */   }
/*      */   
/*      */   public void ifgt(Label label) {
/*  984 */     this.mv.visitJumpInsn(157, label);
/*      */   }
/*      */   
/*      */   public void ifle(Label label) {
/*  988 */     this.mv.visitJumpInsn(158, label);
/*      */   }
/*      */   
/*      */   public void ificmpeq(Label label) {
/*  992 */     this.mv.visitJumpInsn(159, label);
/*      */   }
/*      */   
/*      */   public void ificmpne(Label label) {
/*  996 */     this.mv.visitJumpInsn(160, label);
/*      */   }
/*      */   
/*      */   public void ificmplt(Label label) {
/* 1000 */     this.mv.visitJumpInsn(161, label);
/*      */   }
/*      */   
/*      */   public void ificmpge(Label label) {
/* 1004 */     this.mv.visitJumpInsn(162, label);
/*      */   }
/*      */   
/*      */   public void ificmpgt(Label label) {
/* 1008 */     this.mv.visitJumpInsn(163, label);
/*      */   }
/*      */   
/*      */   public void ificmple(Label label) {
/* 1012 */     this.mv.visitJumpInsn(164, label);
/*      */   }
/*      */   
/*      */   public void ifacmpeq(Label label) {
/* 1016 */     this.mv.visitJumpInsn(165, label);
/*      */   }
/*      */   
/*      */   public void ifacmpne(Label label) {
/* 1020 */     this.mv.visitJumpInsn(166, label);
/*      */   }
/*      */   
/*      */   public void goTo(Label label) {
/* 1024 */     this.mv.visitJumpInsn(167, label);
/*      */   }
/*      */   
/*      */   public void jsr(Label label) {
/* 1028 */     this.mv.visitJumpInsn(168, label);
/*      */   }
/*      */   
/*      */   public void ret(int varIndex) {
/* 1032 */     this.mv.visitVarInsn(169, varIndex);
/*      */   }
/*      */   
/*      */   public void tableswitch(int min, int max, Label dflt, Label... labels) {
/* 1036 */     this.mv.visitTableSwitchInsn(min, max, dflt, labels);
/*      */   }
/*      */   
/*      */   public void lookupswitch(Label dflt, int[] keys, Label[] labels) {
/* 1040 */     this.mv.visitLookupSwitchInsn(dflt, keys, labels);
/*      */   }
/*      */   
/*      */   public void areturn(Type type) {
/* 1044 */     this.mv.visitInsn(type.getOpcode(172));
/*      */   }
/*      */   
/*      */   public void getstatic(String owner, String name, String descriptor) {
/* 1048 */     this.mv.visitFieldInsn(178, owner, name, descriptor);
/*      */   }
/*      */   
/*      */   public void putstatic(String owner, String name, String descriptor) {
/* 1052 */     this.mv.visitFieldInsn(179, owner, name, descriptor);
/*      */   }
/*      */   
/*      */   public void getfield(String owner, String name, String descriptor) {
/* 1056 */     this.mv.visitFieldInsn(180, owner, name, descriptor);
/*      */   }
/*      */   
/*      */   public void putfield(String owner, String name, String descriptor) {
/* 1060 */     this.mv.visitFieldInsn(181, owner, name, descriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void invokevirtual(String owner, String name, String descriptor) {
/* 1074 */     if (this.api >= 327680) {
/* 1075 */       invokevirtual(owner, name, descriptor, false);
/*      */       return;
/*      */     } 
/* 1078 */     this.mv.visitMethodInsn(182, owner, name, descriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokevirtual(String owner, String name, String descriptor, boolean isInterface) {
/* 1092 */     if (this.api < 327680) {
/* 1093 */       if (isInterface) {
/* 1094 */         throw new UnsupportedOperationException("INVOKEVIRTUAL on interfaces require ASM 5");
/*      */       }
/* 1096 */       invokevirtual(owner, name, descriptor);
/*      */       return;
/*      */     } 
/* 1099 */     this.mv.visitMethodInsn(182, owner, name, descriptor, isInterface);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void invokespecial(String owner, String name, String descriptor) {
/* 1113 */     if (this.api >= 327680) {
/* 1114 */       invokespecial(owner, name, descriptor, false);
/*      */       return;
/*      */     } 
/* 1117 */     this.mv.visitMethodInsn(183, owner, name, descriptor, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokespecial(String owner, String name, String descriptor, boolean isInterface) {
/* 1131 */     if (this.api < 327680) {
/* 1132 */       if (isInterface) {
/* 1133 */         throw new UnsupportedOperationException("INVOKESPECIAL on interfaces require ASM 5");
/*      */       }
/* 1135 */       invokespecial(owner, name, descriptor);
/*      */       return;
/*      */     } 
/* 1138 */     this.mv.visitMethodInsn(183, owner, name, descriptor, isInterface);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void invokestatic(String owner, String name, String descriptor) {
/* 1152 */     if (this.api >= 327680) {
/* 1153 */       invokestatic(owner, name, descriptor, false);
/*      */       return;
/*      */     } 
/* 1156 */     this.mv.visitMethodInsn(184, owner, name, descriptor, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokestatic(String owner, String name, String descriptor, boolean isInterface) {
/* 1170 */     if (this.api < 327680) {
/* 1171 */       if (isInterface) {
/* 1172 */         throw new UnsupportedOperationException("INVOKESTATIC on interfaces require ASM 5");
/*      */       }
/* 1174 */       invokestatic(owner, name, descriptor);
/*      */       return;
/*      */     } 
/* 1177 */     this.mv.visitMethodInsn(184, owner, name, descriptor, isInterface);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeinterface(String owner, String name, String descriptor) {
/* 1189 */     this.mv.visitMethodInsn(185, owner, name, descriptor, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokedynamic(String name, String descriptor, Handle bootstrapMethodHandle, Object[] bootstrapMethodArguments) {
/* 1208 */     this.mv.visitInvokeDynamicInsn(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments);
/*      */   }
/*      */   
/*      */   public void anew(Type type) {
/* 1212 */     this.mv.visitTypeInsn(187, type.getInternalName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newarray(Type type) {
/* 1221 */     newarray(this.mv, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void newarray(MethodVisitor methodVisitor, Type type) {
/*      */     int arrayType;
/* 1232 */     switch (type.getSort()) {
/*      */       case 1:
/* 1234 */         arrayType = 4;
/*      */         break;
/*      */       case 2:
/* 1237 */         arrayType = 5;
/*      */         break;
/*      */       case 3:
/* 1240 */         arrayType = 8;
/*      */         break;
/*      */       case 4:
/* 1243 */         arrayType = 9;
/*      */         break;
/*      */       case 5:
/* 1246 */         arrayType = 10;
/*      */         break;
/*      */       case 6:
/* 1249 */         arrayType = 6;
/*      */         break;
/*      */       case 7:
/* 1252 */         arrayType = 11;
/*      */         break;
/*      */       case 8:
/* 1255 */         arrayType = 7;
/*      */         break;
/*      */       default:
/* 1258 */         methodVisitor.visitTypeInsn(189, type.getInternalName());
/*      */         return;
/*      */     } 
/* 1261 */     methodVisitor.visitIntInsn(188, arrayType);
/*      */   }
/*      */   
/*      */   public void arraylength() {
/* 1265 */     this.mv.visitInsn(190);
/*      */   }
/*      */   
/*      */   public void athrow() {
/* 1269 */     this.mv.visitInsn(191);
/*      */   }
/*      */   
/*      */   public void checkcast(Type type) {
/* 1273 */     this.mv.visitTypeInsn(192, type.getInternalName());
/*      */   }
/*      */   
/*      */   public void instanceOf(Type type) {
/* 1277 */     this.mv.visitTypeInsn(193, type.getInternalName());
/*      */   }
/*      */   
/*      */   public void monitorenter() {
/* 1281 */     this.mv.visitInsn(194);
/*      */   }
/*      */   
/*      */   public void monitorexit() {
/* 1285 */     this.mv.visitInsn(195);
/*      */   }
/*      */   
/*      */   public void multianewarray(String descriptor, int numDimensions) {
/* 1289 */     this.mv.visitMultiANewArrayInsn(descriptor, numDimensions);
/*      */   }
/*      */   
/*      */   public void ifnull(Label label) {
/* 1293 */     this.mv.visitJumpInsn(198, label);
/*      */   }
/*      */   
/*      */   public void ifnonnull(Label label) {
/* 1297 */     this.mv.visitJumpInsn(199, label);
/*      */   }
/*      */   
/*      */   public void mark(Label label) {
/* 1301 */     this.mv.visitLabel(label);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\InstructionAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */