/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.AnnotationVisitor;
/*     */ import aj.org.objectweb.asm.Handle;
/*     */ import aj.org.objectweb.asm.Label;
/*     */ import aj.org.objectweb.asm.MethodVisitor;
/*     */ import aj.org.objectweb.asm.TypePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodRemapper
/*     */   extends MethodVisitor
/*     */ {
/*     */   protected final Remapper remapper;
/*     */   
/*     */   public MethodRemapper(MethodVisitor methodVisitor, Remapper remapper) {
/*  56 */     this(589824, methodVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodRemapper(int api, MethodVisitor methodVisitor, Remapper remapper) {
/*  69 */     super(api, methodVisitor);
/*  70 */     this.remapper = remapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotationDefault() {
/*  75 */     AnnotationVisitor annotationVisitor = super.visitAnnotationDefault();
/*  76 */     return (annotationVisitor == null) ? 
/*  77 */       annotationVisitor : 
/*  78 */       createAnnotationRemapper(null, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/*  84 */     AnnotationVisitor annotationVisitor = super.visitAnnotation(this.remapper.mapDesc(descriptor), visible);
/*  85 */     return (annotationVisitor == null) ? 
/*  86 */       annotationVisitor : 
/*  87 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
/*  94 */     AnnotationVisitor annotationVisitor = super.visitTypeAnnotation(typeRef, typePath, this.remapper.mapDesc(descriptor), visible);
/*  95 */     return (annotationVisitor == null) ? 
/*  96 */       annotationVisitor : 
/*  97 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitParameterAnnotation(int parameter, String descriptor, boolean visible) {
/* 104 */     AnnotationVisitor annotationVisitor = super.visitParameterAnnotation(parameter, this.remapper.mapDesc(descriptor), visible);
/* 105 */     return (annotationVisitor == null) ? 
/* 106 */       annotationVisitor : 
/* 107 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFrame(int type, int numLocal, Object[] local, int numStack, Object[] stack) {
/* 117 */     super.visitFrame(type, numLocal, 
/*     */ 
/*     */         
/* 120 */         remapFrameTypes(numLocal, local), numStack, 
/*     */         
/* 122 */         remapFrameTypes(numStack, stack));
/*     */   }
/*     */   
/*     */   private Object[] remapFrameTypes(int numTypes, Object[] frameTypes) {
/* 126 */     if (frameTypes == null) {
/* 127 */       return frameTypes;
/*     */     }
/* 129 */     Object[] remappedFrameTypes = null;
/* 130 */     for (int i = 0; i < numTypes; i++) {
/* 131 */       if (frameTypes[i] instanceof String) {
/* 132 */         if (remappedFrameTypes == null) {
/* 133 */           remappedFrameTypes = new Object[numTypes];
/* 134 */           System.arraycopy(frameTypes, 0, remappedFrameTypes, 0, numTypes);
/*     */         } 
/* 136 */         remappedFrameTypes[i] = this.remapper.mapType((String)frameTypes[i]);
/*     */       } 
/*     */     } 
/* 139 */     return (remappedFrameTypes == null) ? frameTypes : remappedFrameTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
/* 145 */     super.visitFieldInsn(opcode, this.remapper
/*     */         
/* 147 */         .mapType(owner), this.remapper
/* 148 */         .mapFieldName(owner, name, descriptor), this.remapper
/* 149 */         .mapDesc(descriptor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodInsn(int opcodeAndSource, String owner, String name, String descriptor, boolean isInterface) {
/* 159 */     if (this.api < 327680 && (opcodeAndSource & 0x100) == 0) {
/*     */       
/* 161 */       super.visitMethodInsn(opcodeAndSource, owner, name, descriptor, isInterface);
/*     */       return;
/*     */     } 
/* 164 */     super.visitMethodInsn(opcodeAndSource, this.remapper
/*     */         
/* 166 */         .mapType(owner), this.remapper
/* 167 */         .mapMethodName(owner, name, descriptor), this.remapper
/* 168 */         .mapMethodDesc(descriptor), isInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 178 */     Object[] remappedBootstrapMethodArguments = new Object[bootstrapMethodArguments.length];
/* 179 */     for (int i = 0; i < bootstrapMethodArguments.length; i++) {
/* 180 */       remappedBootstrapMethodArguments[i] = this.remapper.mapValue(bootstrapMethodArguments[i]);
/*     */     }
/* 182 */     super.visitInvokeDynamicInsn(this.remapper
/* 183 */         .mapInvokeDynamicMethodName(name, descriptor), this.remapper
/* 184 */         .mapMethodDesc(descriptor), (Handle)this.remapper
/* 185 */         .mapValue(bootstrapMethodHandle), remappedBootstrapMethodArguments);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type) {
/* 191 */     super.visitTypeInsn(opcode, this.remapper.mapType(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLdcInsn(Object value) {
/* 196 */     super.visitLdcInsn(this.remapper.mapValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMultiANewArrayInsn(String descriptor, int numDimensions) {
/* 201 */     super.visitMultiANewArrayInsn(this.remapper.mapDesc(descriptor), numDimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
/* 208 */     AnnotationVisitor annotationVisitor = super.visitInsnAnnotation(typeRef, typePath, this.remapper.mapDesc(descriptor), visible);
/* 209 */     return (annotationVisitor == null) ? 
/* 210 */       annotationVisitor : 
/* 211 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
/* 217 */     super.visitTryCatchBlock(start, end, handler, (type == null) ? null : this.remapper.mapType(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
/* 224 */     AnnotationVisitor annotationVisitor = super.visitTryCatchAnnotation(typeRef, typePath, this.remapper.mapDesc(descriptor), visible);
/* 225 */     return (annotationVisitor == null) ? 
/* 226 */       annotationVisitor : 
/* 227 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitLocalVariable(String name, String descriptor, String signature, Label start, Label end, int index) {
/* 238 */     super.visitLocalVariable(name, this.remapper
/*     */         
/* 240 */         .mapDesc(descriptor), this.remapper
/* 241 */         .mapSignature(signature, true), start, end, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, int[] index, String descriptor, boolean visible) {
/* 257 */     AnnotationVisitor annotationVisitor = super.visitLocalVariableAnnotation(typeRef, typePath, start, end, index, this.remapper
/* 258 */         .mapDesc(descriptor), visible);
/* 259 */     return (annotationVisitor == null) ? 
/* 260 */       annotationVisitor : 
/* 261 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AnnotationVisitor createAnnotationRemapper(AnnotationVisitor annotationVisitor) {
/* 274 */     return new AnnotationRemapper(this.api, null, annotationVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationVisitor createAnnotationRemapper(String descriptor, AnnotationVisitor annotationVisitor) {
/* 287 */     return (new AnnotationRemapper(this.api, descriptor, annotationVisitor, this.remapper))
/* 288 */       .orDeprecatedValue(createAnnotationRemapper(annotationVisitor));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\MethodRemapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */