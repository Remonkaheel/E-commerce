/*    */ package aj.org.objectweb.asm.commons;
/*    */ 
/*    */ import aj.org.objectweb.asm.Attribute;
/*    */ import aj.org.objectweb.asm.ByteVector;
/*    */ import aj.org.objectweb.asm.ClassReader;
/*    */ import aj.org.objectweb.asm.ClassWriter;
/*    */ import aj.org.objectweb.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ModuleTargetAttribute
/*    */   extends Attribute
/*    */ {
/*    */   public String platform;
/*    */   
/*    */   public ModuleTargetAttribute(String platform) {
/* 53 */     super("ModuleTarget");
/* 54 */     this.platform = platform;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ModuleTargetAttribute() {
/* 62 */     this(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Attribute read(ClassReader classReader, int offset, int length, char[] charBuffer, int codeOffset, Label[] labels) {
/* 73 */     return new ModuleTargetAttribute(classReader.readUTF8(offset, charBuffer));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ByteVector write(ClassWriter classWriter, byte[] code, int codeLength, int maxStack, int maxLocals) {
/* 83 */     ByteVector byteVector = new ByteVector();
/* 84 */     byteVector.putShort((this.platform == null) ? 0 : classWriter.newUTF8(this.platform));
/* 85 */     return byteVector;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\ModuleTargetAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */