/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.AnnotationVisitor;
/*     */ import aj.org.objectweb.asm.Label;
/*     */ import aj.org.objectweb.asm.MethodVisitor;
/*     */ import aj.org.objectweb.asm.Opcodes;
/*     */ import aj.org.objectweb.asm.Type;
/*     */ import aj.org.objectweb.asm.TypePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariablesSorter
/*     */   extends MethodVisitor
/*     */ {
/*  51 */   private static final Type OBJECT_TYPE = Type.getObjectType("java/lang/Object");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private int[] remappedVariableIndices = new int[40];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private Object[] remappedLocalTypes = new Object[20];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int firstLocal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int nextLocal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariablesSorter(int access, String descriptor, MethodVisitor methodVisitor) {
/*  84 */     this(589824, access, descriptor, methodVisitor);
/*  85 */     if (getClass() != LocalVariablesSorter.class) {
/*  86 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalVariablesSorter(int api, int access, String descriptor, MethodVisitor methodVisitor) {
/* 101 */     super(api, methodVisitor);
/* 102 */     this.nextLocal = ((0x8 & access) == 0) ? 1 : 0;
/* 103 */     for (Type argumentType : Type.getArgumentTypes(descriptor)) {
/* 104 */       this.nextLocal += argumentType.getSize();
/*     */     }
/* 106 */     this.firstLocal = this.nextLocal;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitVarInsn(int opcode, int varIndex) {
/*     */     Type varType;
/* 112 */     switch (opcode) {
/*     */       case 22:
/*     */       case 55:
/* 115 */         varType = Type.LONG_TYPE;
/*     */         break;
/*     */       case 24:
/*     */       case 57:
/* 119 */         varType = Type.DOUBLE_TYPE;
/*     */         break;
/*     */       case 23:
/*     */       case 56:
/* 123 */         varType = Type.FLOAT_TYPE;
/*     */         break;
/*     */       case 21:
/*     */       case 54:
/* 127 */         varType = Type.INT_TYPE;
/*     */         break;
/*     */       case 25:
/*     */       case 58:
/*     */       case 169:
/* 132 */         varType = OBJECT_TYPE;
/*     */         break;
/*     */       default:
/* 135 */         throw new IllegalArgumentException(stringConcat$0(opcode));
/*     */     } 
/* 137 */     super.visitVarInsn(opcode, remap(varIndex, varType));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIincInsn(int varIndex, int increment) {
/* 142 */     super.visitIincInsn(remap(varIndex, Type.INT_TYPE), increment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMaxs(int maxStack, int maxLocals) {
/* 147 */     super.visitMaxs(maxStack, this.nextLocal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitLocalVariable(String name, String descriptor, String signature, Label start, Label end, int index) {
/* 158 */     int remappedIndex = remap(index, Type.getType(descriptor));
/* 159 */     super.visitLocalVariable(name, descriptor, signature, start, end, remappedIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, int[] index, String descriptor, boolean visible) {
/* 171 */     Type type = Type.getType(descriptor);
/* 172 */     int[] remappedIndex = new int[index.length];
/* 173 */     for (int i = 0; i < remappedIndex.length; i++) {
/* 174 */       remappedIndex[i] = remap(index[i], type);
/*     */     }
/* 176 */     return super.visitLocalVariableAnnotation(typeRef, typePath, start, end, remappedIndex, descriptor, visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFrame(int type, int numLocal, Object[] local, int numStack, Object[] stack) {
/* 187 */     if (type != -1) {
/* 188 */       throw new IllegalArgumentException("LocalVariablesSorter only accepts expanded frames (see ClassReader.EXPAND_FRAMES)");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 193 */     Object[] oldRemappedLocals = new Object[this.remappedLocalTypes.length];
/* 194 */     System.arraycopy(this.remappedLocalTypes, 0, oldRemappedLocals, 0, oldRemappedLocals.length);
/*     */     
/* 196 */     updateNewLocals(this.remappedLocalTypes);
/*     */ 
/*     */ 
/*     */     
/* 200 */     int oldVar = 0;
/* 201 */     for (int i = 0; i < numLocal; i++) {
/* 202 */       Object localType = local[i];
/* 203 */       if (localType != Opcodes.TOP) {
/* 204 */         Type varType = OBJECT_TYPE;
/* 205 */         if (localType == Opcodes.INTEGER) {
/* 206 */           varType = Type.INT_TYPE;
/* 207 */         } else if (localType == Opcodes.FLOAT) {
/* 208 */           varType = Type.FLOAT_TYPE;
/* 209 */         } else if (localType == Opcodes.LONG) {
/* 210 */           varType = Type.LONG_TYPE;
/* 211 */         } else if (localType == Opcodes.DOUBLE) {
/* 212 */           varType = Type.DOUBLE_TYPE;
/* 213 */         } else if (localType instanceof String) {
/* 214 */           varType = Type.getObjectType((String)localType);
/*     */         } 
/* 216 */         setFrameLocal(remap(oldVar, varType), localType);
/*     */       } 
/* 218 */       oldVar += (localType == Opcodes.LONG || localType == Opcodes.DOUBLE) ? 2 : 1;
/*     */     } 
/*     */ 
/*     */     
/* 222 */     oldVar = 0;
/* 223 */     int newVar = 0;
/* 224 */     int remappedNumLocal = 0;
/* 225 */     while (oldVar < this.remappedLocalTypes.length) {
/* 226 */       Object localType = this.remappedLocalTypes[oldVar];
/* 227 */       oldVar += (localType == Opcodes.LONG || localType == Opcodes.DOUBLE) ? 2 : 1;
/* 228 */       if (localType != null && localType != Opcodes.TOP) {
/* 229 */         this.remappedLocalTypes[newVar++] = localType;
/* 230 */         remappedNumLocal = newVar; continue;
/*     */       } 
/* 232 */       this.remappedLocalTypes[newVar++] = Opcodes.TOP;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 237 */     super.visitFrame(type, remappedNumLocal, this.remappedLocalTypes, numStack, stack);
/*     */ 
/*     */     
/* 240 */     this.remappedLocalTypes = oldRemappedLocals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int newLocal(Type type) {
/*     */     Object localType;
/*     */     int local;
/* 253 */     switch (type.getSort()) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/* 259 */         localType = Opcodes.INTEGER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 279 */         local = newLocalMapping(type);
/* 280 */         setLocalType(local, type);
/* 281 */         setFrameLocal(local, localType);
/* 282 */         return local;case 6: localType = Opcodes.FLOAT; local = newLocalMapping(type); setLocalType(local, type); setFrameLocal(local, localType); return local;case 7: localType = Opcodes.LONG; local = newLocalMapping(type); setLocalType(local, type); setFrameLocal(local, localType); return local;case 8: localType = Opcodes.DOUBLE; local = newLocalMapping(type); setLocalType(local, type); setFrameLocal(local, localType); return local;case 9: localType = type.getDescriptor(); local = newLocalMapping(type); setLocalType(local, type); setFrameLocal(local, localType); return local;case 10: localType = type.getInternalName(); local = newLocalMapping(type); setLocalType(local, type); setFrameLocal(local, localType); return local;
/*     */     } 
/*     */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateNewLocals(Object[] newLocals) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLocalType(int local, Type type) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setFrameLocal(int local, Object type) {
/* 315 */     int numLocals = this.remappedLocalTypes.length;
/* 316 */     if (local >= numLocals) {
/* 317 */       Object[] newRemappedLocalTypes = new Object[Math.max(2 * numLocals, local + 1)];
/* 318 */       System.arraycopy(this.remappedLocalTypes, 0, newRemappedLocalTypes, 0, numLocals);
/* 319 */       this.remappedLocalTypes = newRemappedLocalTypes;
/*     */     } 
/* 321 */     this.remappedLocalTypes[local] = type;
/*     */   }
/*     */   
/*     */   private int remap(int varIndex, Type type) {
/* 325 */     if (varIndex + type.getSize() <= this.firstLocal) {
/* 326 */       return varIndex;
/*     */     }
/* 328 */     int key = 2 * varIndex + type.getSize() - 1;
/* 329 */     int size = this.remappedVariableIndices.length;
/* 330 */     if (key >= size) {
/* 331 */       int[] newRemappedVariableIndices = new int[Math.max(2 * size, key + 1)];
/* 332 */       System.arraycopy(this.remappedVariableIndices, 0, newRemappedVariableIndices, 0, size);
/* 333 */       this.remappedVariableIndices = newRemappedVariableIndices;
/*     */     } 
/* 335 */     int value = this.remappedVariableIndices[key];
/* 336 */     if (value == 0) {
/* 337 */       value = newLocalMapping(type);
/* 338 */       setLocalType(value, type);
/* 339 */       this.remappedVariableIndices[key] = value + 1;
/*     */     } else {
/* 341 */       value--;
/*     */     } 
/* 343 */     return value;
/*     */   }
/*     */   
/*     */   protected int newLocalMapping(Type type) {
/* 347 */     int local = this.nextLocal;
/* 348 */     this.nextLocal += type.getSize();
/* 349 */     return local;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\LocalVariablesSorter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */