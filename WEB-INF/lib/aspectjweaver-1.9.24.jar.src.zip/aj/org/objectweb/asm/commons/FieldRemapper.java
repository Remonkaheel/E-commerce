/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.AnnotationVisitor;
/*     */ import aj.org.objectweb.asm.FieldVisitor;
/*     */ import aj.org.objectweb.asm.TypePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldRemapper
/*     */   extends FieldVisitor
/*     */ {
/*     */   protected final Remapper remapper;
/*     */   
/*     */   public FieldRemapper(FieldVisitor fieldVisitor, Remapper remapper) {
/*  54 */     this(589824, fieldVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldRemapper(int api, FieldVisitor fieldVisitor, Remapper remapper) {
/*  66 */     super(api, fieldVisitor);
/*  67 */     this.remapper = remapper;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/*  73 */     AnnotationVisitor annotationVisitor = super.visitAnnotation(this.remapper.mapDesc(descriptor), visible);
/*  74 */     return (annotationVisitor == null) ? 
/*  75 */       null : 
/*  76 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
/*  83 */     AnnotationVisitor annotationVisitor = super.visitTypeAnnotation(typeRef, typePath, this.remapper.mapDesc(descriptor), visible);
/*  84 */     return (annotationVisitor == null) ? 
/*  85 */       null : 
/*  86 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AnnotationVisitor createAnnotationRemapper(AnnotationVisitor annotationVisitor) {
/*  99 */     return new AnnotationRemapper(this.api, null, annotationVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationVisitor createAnnotationRemapper(String descriptor, AnnotationVisitor annotationVisitor) {
/* 112 */     return (new AnnotationRemapper(this.api, descriptor, annotationVisitor, this.remapper))
/* 113 */       .orDeprecatedValue(createAnnotationRemapper(annotationVisitor));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\FieldRemapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */