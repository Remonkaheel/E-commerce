/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.AnnotationVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationRemapper
/*     */   extends AnnotationVisitor
/*     */ {
/*     */   protected final String descriptor;
/*     */   protected final Remapper remapper;
/*     */   
/*     */   @Deprecated
/*     */   public AnnotationRemapper(AnnotationVisitor annotationVisitor, Remapper remapper) {
/*  60 */     this((String)null, annotationVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationRemapper(String descriptor, AnnotationVisitor annotationVisitor, Remapper remapper) {
/*  74 */     this(589824, descriptor, annotationVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AnnotationRemapper(int api, AnnotationVisitor annotationVisitor, Remapper remapper) {
/*  89 */     this(api, (String)null, annotationVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationRemapper(int api, String descriptor, AnnotationVisitor annotationVisitor, Remapper remapper) {
/* 106 */     super(api, annotationVisitor);
/* 107 */     this.descriptor = descriptor;
/* 108 */     this.remapper = remapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(String name, Object value) {
/* 113 */     super.visit(mapAnnotationAttributeName(name), this.remapper.mapValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitEnum(String name, String descriptor, String value) {
/* 118 */     super.visitEnum(mapAnnotationAttributeName(name), this.remapper.mapDesc(descriptor), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotation(String name, String descriptor) {
/* 124 */     AnnotationVisitor annotationVisitor = super.visitAnnotation(mapAnnotationAttributeName(name), this.remapper.mapDesc(descriptor));
/* 125 */     if (annotationVisitor == null) {
/* 126 */       return null;
/*     */     }
/* 128 */     return (annotationVisitor == this.av) ? 
/* 129 */       this : 
/* 130 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitArray(String name) {
/* 136 */     AnnotationVisitor annotationVisitor = super.visitArray(mapAnnotationAttributeName(name));
/* 137 */     if (annotationVisitor == null) {
/* 138 */       return null;
/*     */     }
/* 140 */     return (annotationVisitor == this.av) ? 
/* 141 */       this : 
/* 142 */       createAnnotationRemapper((String)null, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AnnotationVisitor createAnnotationRemapper(AnnotationVisitor annotationVisitor) {
/* 156 */     return new AnnotationRemapper(this.api, null, annotationVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationVisitor createAnnotationRemapper(String descriptor, AnnotationVisitor annotationVisitor) {
/* 169 */     return (new AnnotationRemapper(this.api, descriptor, annotationVisitor, this.remapper))
/* 170 */       .orDeprecatedValue(createAnnotationRemapper(annotationVisitor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final AnnotationVisitor orDeprecatedValue(AnnotationVisitor deprecatedAnnotationVisitor) {
/* 185 */     if (deprecatedAnnotationVisitor.getClass() == getClass()) {
/* 186 */       AnnotationRemapper deprecatedAnnotationRemapper = (AnnotationRemapper)deprecatedAnnotationVisitor;
/*     */       
/* 188 */       if (deprecatedAnnotationRemapper.api == this.api && deprecatedAnnotationRemapper.av == this.av && deprecatedAnnotationRemapper.remapper == this.remapper)
/*     */       {
/*     */         
/* 191 */         return this;
/*     */       }
/*     */     } 
/* 194 */     return deprecatedAnnotationVisitor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String mapAnnotationAttributeName(String name) {
/* 205 */     if (this.descriptor == null) {
/* 206 */       return name;
/*     */     }
/* 208 */     return this.remapper.mapAnnotationAttributeName(this.descriptor, name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\AnnotationRemapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */