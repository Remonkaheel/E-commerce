/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.signature.SignatureVisitor;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureRemapper
/*     */   extends SignatureVisitor
/*     */ {
/*     */   private final SignatureVisitor signatureVisitor;
/*     */   private final Remapper remapper;
/*  46 */   private ArrayList<String> classNames = new ArrayList<String>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SignatureRemapper(SignatureVisitor signatureVisitor, Remapper remapper) {
/*  56 */     this(589824, signatureVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SignatureRemapper(int api, SignatureVisitor signatureVisitor, Remapper remapper) {
/*  69 */     super(api);
/*  70 */     this.signatureVisitor = signatureVisitor;
/*  71 */     this.remapper = remapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitClassType(String name) {
/*  76 */     this.classNames.add(name);
/*  77 */     this.signatureVisitor.visitClassType(this.remapper.mapType(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInnerClassType(String name) {
/*  82 */     String outerClassName = this.classNames.remove(this.classNames.size() - 1);
/*  83 */     String className = stringConcat$0(outerClassName, name);
/*  84 */     this.classNames.add(className);
/*  85 */     String remappedOuter = stringConcat$1(this.remapper.mapType(outerClassName));
/*  86 */     String remappedName = this.remapper.mapType(className);
/*     */ 
/*     */ 
/*     */     
/*  90 */     int index = remappedName.startsWith(remappedOuter) ? remappedOuter.length() : (remappedName.lastIndexOf('$') + 1);
/*  91 */     this.signatureVisitor.visitInnerClassType(remappedName.substring(index));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitFormalTypeParameter(String name) {
/*  96 */     this.signatureVisitor.visitFormalTypeParameter(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTypeVariable(String name) {
/* 101 */     this.signatureVisitor.visitTypeVariable(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitArrayType() {
/* 106 */     this.signatureVisitor.visitArrayType();
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitBaseType(char descriptor) {
/* 112 */     this.signatureVisitor.visitBaseType(descriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitClassBound() {
/* 117 */     this.signatureVisitor.visitClassBound();
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitExceptionType() {
/* 123 */     this.signatureVisitor.visitExceptionType();
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitInterface() {
/* 129 */     this.signatureVisitor.visitInterface();
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitInterfaceBound() {
/* 135 */     this.signatureVisitor.visitInterfaceBound();
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitParameterType() {
/* 141 */     this.signatureVisitor.visitParameterType();
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitReturnType() {
/* 147 */     this.signatureVisitor.visitReturnType();
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitSuperclass() {
/* 153 */     this.signatureVisitor.visitSuperclass();
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTypeArgument() {
/* 159 */     this.signatureVisitor.visitTypeArgument();
/*     */   }
/*     */ 
/*     */   
/*     */   public SignatureVisitor visitTypeArgument(char wildcard) {
/* 164 */     this.signatureVisitor.visitTypeArgument(wildcard);
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitEnd() {
/* 170 */     this.signatureVisitor.visitEnd();
/* 171 */     this.classNames.remove(this.classNames.size() - 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\SignatureRemapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */