/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.ClassVisitor;
/*     */ import aj.org.objectweb.asm.FieldVisitor;
/*     */ import aj.org.objectweb.asm.MethodVisitor;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialVersionUIDAdder
/*     */   extends ClassVisitor
/*     */ {
/*     */   private static final String CLINIT = "<clinit>";
/*     */   private boolean computeSvuid;
/*     */   private boolean hasSvuid;
/*     */   private int access;
/*     */   private String name;
/*     */   private String[] interfaces;
/*     */   private Collection<Item> svuidFields;
/*     */   private boolean hasStaticInitializer;
/*     */   private Collection<Item> svuidConstructors;
/*     */   private Collection<Item> svuidMethods;
/*     */   
/*     */   public SerialVersionUIDAdder(ClassVisitor classVisitor) {
/* 153 */     this(589824, classVisitor);
/* 154 */     if (getClass() != SerialVersionUIDAdder.class) {
/* 155 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerialVersionUIDAdder(int api, ClassVisitor classVisitor) {
/* 167 */     super(api, classVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/* 184 */     this.computeSvuid = ((access & 0x4000) == 0);
/*     */     
/* 186 */     if (this.computeSvuid) {
/* 187 */       this.name = name;
/* 188 */       this.access = access;
/* 189 */       this.interfaces = (String[])interfaces.clone();
/* 190 */       this.svuidFields = new ArrayList<Item>();
/* 191 */       this.svuidConstructors = new ArrayList<Item>();
/* 192 */       this.svuidMethods = new ArrayList<Item>();
/*     */     } 
/*     */     
/* 195 */     super.visit(version, access, name, signature, superName, interfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
/* 207 */     if (this.computeSvuid) {
/* 208 */       if ("<clinit>".equals(name)) {
/* 209 */         this.hasStaticInitializer = true;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 214 */       int mods = access & 0xD3F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 226 */       if ((access & 0x2) == 0) {
/* 227 */         if ("<init>".equals(name)) {
/* 228 */           this.svuidConstructors.add(new Item(name, mods, descriptor));
/* 229 */         } else if (!"<clinit>".equals(name)) {
/* 230 */           this.svuidMethods.add(new Item(name, mods, descriptor));
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 235 */     return super.visitMethod(access, name, descriptor, signature, exceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
/* 247 */     if (this.computeSvuid) {
/* 248 */       if ("serialVersionUID".equals(name)) {
/*     */         
/* 250 */         this.computeSvuid = false;
/* 251 */         this.hasSvuid = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 256 */       if ((access & 0x2) == 0 || (access & 0x88) == 0) {
/*     */         
/* 258 */         int mods = access & 0xDF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 267 */         this.svuidFields.add(new Item(name, mods, desc));
/*     */       } 
/*     */     } 
/*     */     
/* 271 */     return super.visitField(access, name, desc, signature, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitInnerClass(String innerClassName, String outerName, String innerName, int innerClassAccess) {
/* 284 */     if (this.name != null && this.name.equals(innerClassName)) {
/* 285 */       this.access = innerClassAccess;
/*     */     }
/* 287 */     super.visitInnerClass(innerClassName, outerName, innerName, innerClassAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitEnd() {
/* 293 */     if (this.computeSvuid && !this.hasSvuid) {
/*     */       try {
/* 295 */         addSVUID(computeSVUID());
/* 296 */       } catch (IOException e) {
/* 297 */         throw new IllegalStateException(stringConcat$0(this.name), e);
/*     */       } 
/*     */     }
/*     */     
/* 301 */     super.visitEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSVUID() {
/* 316 */     return this.hasSvuid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addSVUID(long svuid) {
/* 327 */     FieldVisitor fieldVisitor = super.visitField(24, "serialVersionUID", "J", null, 
/* 328 */         Long.valueOf(svuid));
/* 329 */     if (fieldVisitor != null) {
/* 330 */       fieldVisitor.visitEnd();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long computeSVUID() throws IOException {
/* 342 */     long svuid = 0L;
/*     */     
/* 344 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(); 
/* 345 */     try { DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
/*     */ 
/*     */       
/* 348 */       try { dataOutputStream.writeUTF(this.name.replace('/', '.'));
/*     */ 
/*     */         
/* 351 */         int mods = this.access;
/* 352 */         if ((mods & 0x200) != 0)
/*     */         {
/* 354 */           mods = this.svuidMethods.isEmpty() ? (mods & 0xFFFFFBFF) : (mods | 0x400);
/*     */         }
/* 356 */         dataOutputStream.writeInt(mods & 0x611);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 364 */         Arrays.sort((Object[])this.interfaces);
/* 365 */         for (String interfaceName : this.interfaces) {
/* 366 */           dataOutputStream.writeUTF(interfaceName.replace('/', '.'));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 376 */         writeItems(this.svuidFields, dataOutputStream, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 382 */         if (this.hasStaticInitializer) {
/* 383 */           dataOutputStream.writeUTF("<clinit>");
/* 384 */           dataOutputStream.writeInt(8);
/* 385 */           dataOutputStream.writeUTF("()V");
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 392 */         writeItems(this.svuidConstructors, dataOutputStream, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 398 */         writeItems(this.svuidMethods, dataOutputStream, true);
/*     */         
/* 400 */         dataOutputStream.flush();
/*     */ 
/*     */ 
/*     */         
/* 404 */         byte[] hashBytes = computeSHAdigest(byteArrayOutputStream.toByteArray());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 409 */         for (int i = Math.min(hashBytes.length, 8) - 1; i >= 0; i--) {
/* 410 */           svuid = svuid << 8L | (hashBytes[i] & 0xFF);
/*     */         }
/* 412 */         dataOutputStream.close(); } catch (Throwable throwable) { try { dataOutputStream.close(); } catch (Throwable throwable1) {} throw throwable; }  byteArrayOutputStream.close(); } catch (Throwable throwable) { try { byteArrayOutputStream.close(); }
/*     */       catch (Throwable throwable1) {} throw throwable; }
/* 414 */      return svuid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] computeSHAdigest(byte[] value) {
/*     */     try {
/* 426 */       return MessageDigest.getInstance("SHA").digest(value);
/* 427 */     } catch (NoSuchAlgorithmException e) {
/* 428 */       throw new UnsupportedOperationException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeItems(Collection<Item> itemCollection, DataOutput dataOutputStream, boolean dotted) throws IOException {
/* 445 */     Item[] items = itemCollection.<Item>toArray(new Item[0]);
/* 446 */     Arrays.sort((Object[])items);
/* 447 */     for (Item item : items) {
/* 448 */       dataOutputStream.writeUTF(item.name);
/* 449 */       dataOutputStream.writeInt(item.access);
/* 450 */       dataOutputStream.writeUTF(dotted ? item.descriptor.replace('/', '.') : item.descriptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Item
/*     */     implements Comparable<Item>
/*     */   {
/*     */     final String name;
/*     */     
/*     */     final int access;
/*     */     
/*     */     final String descriptor;
/*     */     
/*     */     Item(String name, int access, String descriptor) {
/* 465 */       this.name = name;
/* 466 */       this.access = access;
/* 467 */       this.descriptor = descriptor;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Item item) {
/* 472 */       int result = this.name.compareTo(item.name);
/* 473 */       if (result == 0) {
/* 474 */         result = this.descriptor.compareTo(item.descriptor);
/*     */       }
/* 476 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 481 */       if (other instanceof Item) {
/* 482 */         return (compareTo((Item)other) == 0);
/*     */       }
/* 484 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 489 */       return this.name.hashCode() ^ this.descriptor.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\SerialVersionUIDAdder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */