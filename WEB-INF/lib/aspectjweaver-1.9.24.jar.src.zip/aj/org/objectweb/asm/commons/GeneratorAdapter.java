/*      */ package aj.org.objectweb.asm.commons;
/*      */ 
/*      */ import aj.org.objectweb.asm.ClassVisitor;
/*      */ import aj.org.objectweb.asm.ConstantDynamic;
/*      */ import aj.org.objectweb.asm.Handle;
/*      */ import aj.org.objectweb.asm.Label;
/*      */ import aj.org.objectweb.asm.MethodVisitor;
/*      */ import aj.org.objectweb.asm.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GeneratorAdapter
/*      */   extends LocalVariablesSorter
/*      */ {
/*      */   private static final String CLASS_DESCRIPTOR = "Ljava/lang/Class;";
/*   87 */   private static final Type BYTE_TYPE = Type.getObjectType("java/lang/Byte");
/*      */   
/*   89 */   private static final Type BOOLEAN_TYPE = Type.getObjectType("java/lang/Boolean");
/*      */   
/*   91 */   private static final Type SHORT_TYPE = Type.getObjectType("java/lang/Short");
/*      */   
/*   93 */   private static final Type CHARACTER_TYPE = Type.getObjectType("java/lang/Character");
/*      */   
/*   95 */   private static final Type INTEGER_TYPE = Type.getObjectType("java/lang/Integer");
/*      */   
/*   97 */   private static final Type FLOAT_TYPE = Type.getObjectType("java/lang/Float");
/*      */   
/*   99 */   private static final Type LONG_TYPE = Type.getObjectType("java/lang/Long");
/*      */   
/*  101 */   private static final Type DOUBLE_TYPE = Type.getObjectType("java/lang/Double");
/*      */   
/*  103 */   private static final Type NUMBER_TYPE = Type.getObjectType("java/lang/Number");
/*      */   
/*  105 */   private static final Type OBJECT_TYPE = Type.getObjectType("java/lang/Object");
/*      */   
/*  107 */   private static final Method BOOLEAN_VALUE = Method.getMethod("boolean booleanValue()");
/*      */   
/*  109 */   private static final Method CHAR_VALUE = Method.getMethod("char charValue()");
/*      */   
/*  111 */   private static final Method INT_VALUE = Method.getMethod("int intValue()");
/*      */   
/*  113 */   private static final Method FLOAT_VALUE = Method.getMethod("float floatValue()");
/*      */   
/*  115 */   private static final Method LONG_VALUE = Method.getMethod("long longValue()");
/*      */   
/*  117 */   private static final Method DOUBLE_VALUE = Method.getMethod("double doubleValue()");
/*      */ 
/*      */   
/*      */   public static final int ADD = 96;
/*      */ 
/*      */   
/*      */   public static final int SUB = 100;
/*      */ 
/*      */   
/*      */   public static final int MUL = 104;
/*      */ 
/*      */   
/*      */   public static final int DIV = 108;
/*      */ 
/*      */   
/*      */   public static final int REM = 112;
/*      */ 
/*      */   
/*      */   public static final int NEG = 116;
/*      */ 
/*      */   
/*      */   public static final int SHL = 120;
/*      */ 
/*      */   
/*      */   public static final int SHR = 122;
/*      */ 
/*      */   
/*      */   public static final int USHR = 124;
/*      */ 
/*      */   
/*      */   public static final int AND = 126;
/*      */ 
/*      */   
/*      */   public static final int OR = 128;
/*      */ 
/*      */   
/*      */   public static final int XOR = 130;
/*      */ 
/*      */   
/*      */   public static final int EQ = 153;
/*      */ 
/*      */   
/*      */   public static final int NE = 154;
/*      */ 
/*      */   
/*      */   public static final int LT = 155;
/*      */ 
/*      */   
/*      */   public static final int GE = 156;
/*      */ 
/*      */   
/*      */   public static final int GT = 157;
/*      */ 
/*      */   
/*      */   public static final int LE = 158;
/*      */ 
/*      */   
/*      */   private final int access;
/*      */ 
/*      */   
/*      */   private final String name;
/*      */ 
/*      */   
/*      */   private final Type returnType;
/*      */ 
/*      */   
/*      */   private final Type[] argumentTypes;
/*      */ 
/*      */   
/*  186 */   private final List<Type> localTypes = new ArrayList<Type>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeneratorAdapter(MethodVisitor methodVisitor, int access, String name, String descriptor) {
/*  204 */     this(589824, methodVisitor, access, name, descriptor);
/*  205 */     if (getClass() != GeneratorAdapter.class) {
/*  206 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected GeneratorAdapter(int api, MethodVisitor methodVisitor, int access, String name, String descriptor) {
/*  226 */     super(api, access, descriptor, methodVisitor);
/*  227 */     this.access = access;
/*  228 */     this.name = name;
/*  229 */     this.returnType = Type.getReturnType(descriptor);
/*  230 */     this.argumentTypes = Type.getArgumentTypes(descriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeneratorAdapter(int access, Method method, MethodVisitor methodVisitor) {
/*  244 */     this(methodVisitor, access, method.getName(), method.getDescriptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeneratorAdapter(int access, Method method, String signature, Type[] exceptions, ClassVisitor classVisitor) {
/*  264 */     this(access, method, classVisitor
/*      */ 
/*      */         
/*  267 */         .visitMethod(access, method
/*      */           
/*  269 */           .getName(), method
/*  270 */           .getDescriptor(), signature, 
/*      */           
/*  272 */           (exceptions == null) ? null : getInternalNames(exceptions)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] getInternalNames(Type[] types) {
/*  282 */     String[] names = new String[types.length];
/*  283 */     for (int i = 0; i < names.length; i++) {
/*  284 */       names[i] = types[i].getInternalName();
/*      */     }
/*  286 */     return names;
/*      */   }
/*      */   
/*      */   public int getAccess() {
/*  290 */     return this.access;
/*      */   }
/*      */   
/*      */   public String getName() {
/*  294 */     return this.name;
/*      */   }
/*      */   
/*      */   public Type getReturnType() {
/*  298 */     return this.returnType;
/*      */   }
/*      */   
/*      */   public Type[] getArgumentTypes() {
/*  302 */     return (Type[])this.argumentTypes.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(boolean value) {
/*  315 */     push(value ? 1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(int value) {
/*  324 */     if (value >= -1 && value <= 5) {
/*  325 */       this.mv.visitInsn(3 + value);
/*  326 */     } else if (value >= -128 && value <= 127) {
/*  327 */       this.mv.visitIntInsn(16, value);
/*  328 */     } else if (value >= -32768 && value <= 32767) {
/*  329 */       this.mv.visitIntInsn(17, value);
/*      */     } else {
/*  331 */       this.mv.visitLdcInsn(Integer.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(long value) {
/*  341 */     if (value == 0L || value == 1L) {
/*  342 */       this.mv.visitInsn(9 + (int)value);
/*      */     } else {
/*  344 */       this.mv.visitLdcInsn(Long.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(float value) {
/*  354 */     int bits = Float.floatToIntBits(value);
/*  355 */     if (bits == 0L || bits == 1065353216 || bits == 1073741824) {
/*  356 */       this.mv.visitInsn(11 + (int)value);
/*      */     } else {
/*  358 */       this.mv.visitLdcInsn(Float.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(double value) {
/*  368 */     long bits = Double.doubleToLongBits(value);
/*  369 */     if (bits == 0L || bits == 4607182418800017408L) {
/*  370 */       this.mv.visitInsn(14 + (int)value);
/*      */     } else {
/*  372 */       this.mv.visitLdcInsn(Double.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(String value) {
/*  382 */     if (value == null) {
/*  383 */       this.mv.visitInsn(1);
/*      */     } else {
/*  385 */       this.mv.visitLdcInsn(value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(Type value) {
/*  395 */     if (value == null) {
/*  396 */       this.mv.visitInsn(1);
/*      */     } else {
/*  398 */       switch (value.getSort()) {
/*      */         case 0:
/*  400 */           this.mv.visitFieldInsn(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 1:
/*  403 */           this.mv.visitFieldInsn(178, "java/lang/Boolean", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 2:
/*  406 */           this.mv.visitFieldInsn(178, "java/lang/Character", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 3:
/*  409 */           this.mv.visitFieldInsn(178, "java/lang/Byte", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 4:
/*  412 */           this.mv.visitFieldInsn(178, "java/lang/Short", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 5:
/*  415 */           this.mv.visitFieldInsn(178, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 6:
/*  418 */           this.mv.visitFieldInsn(178, "java/lang/Float", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 7:
/*  421 */           this.mv.visitFieldInsn(178, "java/lang/Long", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */         case 8:
/*  424 */           this.mv.visitFieldInsn(178, "java/lang/Double", "TYPE", "Ljava/lang/Class;");
/*      */           return;
/*      */       } 
/*  427 */       this.mv.visitLdcInsn(value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(Handle handle) {
/*  439 */     if (handle == null) {
/*  440 */       this.mv.visitInsn(1);
/*      */     } else {
/*  442 */       this.mv.visitLdcInsn(handle);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void push(ConstantDynamic constantDynamic) {
/*  452 */     if (constantDynamic == null) {
/*  453 */       this.mv.visitInsn(1);
/*      */     } else {
/*  455 */       this.mv.visitLdcInsn(constantDynamic);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getArgIndex(int arg) {
/*  470 */     int index = ((this.access & 0x8) == 0) ? 1 : 0;
/*  471 */     for (int i = 0; i < arg; i++) {
/*  472 */       index += this.argumentTypes[i].getSize();
/*      */     }
/*  474 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadInsn(Type type, int index) {
/*  484 */     this.mv.visitVarInsn(type.getOpcode(21), index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void storeInsn(Type type, int index) {
/*  494 */     this.mv.visitVarInsn(type.getOpcode(54), index);
/*      */   }
/*      */ 
/*      */   
/*      */   public void loadThis() {
/*  499 */     if ((this.access & 0x8) != 0) {
/*  500 */       throw new IllegalStateException("no 'this' pointer within static method");
/*      */     }
/*  502 */     this.mv.visitVarInsn(25, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadArg(int arg) {
/*  511 */     loadInsn(this.argumentTypes[arg], getArgIndex(arg));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadArgs(int arg, int count) {
/*  521 */     int index = getArgIndex(arg);
/*  522 */     for (int i = 0; i < count; i++) {
/*  523 */       Type argumentType = this.argumentTypes[arg + i];
/*  524 */       loadInsn(argumentType, index);
/*  525 */       index += argumentType.getSize();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void loadArgs() {
/*  531 */     loadArgs(0, this.argumentTypes.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadArgArray() {
/*  539 */     push(this.argumentTypes.length);
/*  540 */     newArray(OBJECT_TYPE);
/*  541 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/*  542 */       dup();
/*  543 */       push(i);
/*  544 */       loadArg(i);
/*  545 */       box(this.argumentTypes[i]);
/*  546 */       arrayStore(OBJECT_TYPE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void storeArg(int arg) {
/*  556 */     storeInsn(this.argumentTypes[arg], getArgIndex(arg));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getLocalType(int local) {
/*  571 */     return this.localTypes.get(local - this.firstLocal);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setLocalType(int local, Type type) {
/*  576 */     int index = local - this.firstLocal;
/*  577 */     while (this.localTypes.size() < index + 1) {
/*  578 */       this.localTypes.add(null);
/*      */     }
/*  580 */     this.localTypes.set(index, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadLocal(int local) {
/*  590 */     loadInsn(getLocalType(local), local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadLocal(int local, Type type) {
/*  601 */     setLocalType(local, type);
/*  602 */     loadInsn(type, local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void storeLocal(int local) {
/*  612 */     storeInsn(getLocalType(local), local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void storeLocal(int local, Type type) {
/*  623 */     setLocalType(local, type);
/*  624 */     storeInsn(type, local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void arrayLoad(Type type) {
/*  633 */     this.mv.visitInsn(type.getOpcode(46));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void arrayStore(Type type) {
/*  642 */     this.mv.visitInsn(type.getOpcode(79));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pop() {
/*  651 */     this.mv.visitInsn(87);
/*      */   }
/*      */ 
/*      */   
/*      */   public void pop2() {
/*  656 */     this.mv.visitInsn(88);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dup() {
/*  661 */     this.mv.visitInsn(89);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dup2() {
/*  666 */     this.mv.visitInsn(92);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dupX1() {
/*  671 */     this.mv.visitInsn(90);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dupX2() {
/*  676 */     this.mv.visitInsn(91);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dup2X1() {
/*  681 */     this.mv.visitInsn(93);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dup2X2() {
/*  686 */     this.mv.visitInsn(94);
/*      */   }
/*      */ 
/*      */   
/*      */   public void swap() {
/*  691 */     this.mv.visitInsn(95);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void swap(Type prev, Type type) {
/*  701 */     if (type.getSize() == 1) {
/*  702 */       if (prev.getSize() == 1) {
/*  703 */         swap();
/*      */       } else {
/*  705 */         dupX2();
/*  706 */         pop();
/*      */       }
/*      */     
/*  709 */     } else if (prev.getSize() == 1) {
/*  710 */       dup2X1();
/*  711 */       pop2();
/*      */     } else {
/*  713 */       dup2X2();
/*  714 */       pop2();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void math(int op, Type type) {
/*  731 */     this.mv.visitInsn(type.getOpcode(op));
/*      */   }
/*      */ 
/*      */   
/*      */   public void not() {
/*  736 */     this.mv.visitInsn(4);
/*  737 */     this.mv.visitInsn(130);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void iinc(int local, int amount) {
/*  747 */     this.mv.visitIincInsn(local, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cast(Type from, Type to) {
/*  757 */     if (from != to) {
/*  758 */       if (from.getSort() < 1 || from
/*  759 */         .getSort() > 8 || to
/*  760 */         .getSort() < 1 || to
/*  761 */         .getSort() > 8) {
/*  762 */         throw new IllegalArgumentException(stringConcat$0(String.valueOf(from), String.valueOf(to)));
/*      */       }
/*  764 */       InstructionAdapter.cast(this.mv, from, to);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Type getBoxedType(Type type) {
/*  773 */     switch (type.getSort()) {
/*      */       case 3:
/*  775 */         return BYTE_TYPE;
/*      */       case 1:
/*  777 */         return BOOLEAN_TYPE;
/*      */       case 4:
/*  779 */         return SHORT_TYPE;
/*      */       case 2:
/*  781 */         return CHARACTER_TYPE;
/*      */       case 5:
/*  783 */         return INTEGER_TYPE;
/*      */       case 6:
/*  785 */         return FLOAT_TYPE;
/*      */       case 7:
/*  787 */         return LONG_TYPE;
/*      */       case 8:
/*  789 */         return DOUBLE_TYPE;
/*      */     } 
/*  791 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void box(Type type) {
/*  802 */     if (type.getSort() == 10 || type.getSort() == 9) {
/*      */       return;
/*      */     }
/*  805 */     if (type == Type.VOID_TYPE) {
/*  806 */       push((String)null);
/*      */     } else {
/*  808 */       Type boxedType = getBoxedType(type);
/*  809 */       newInstance(boxedType);
/*  810 */       if (type.getSize() == 2) {
/*      */         
/*  812 */         dupX2();
/*  813 */         dupX2();
/*  814 */         pop();
/*      */       } else {
/*      */         
/*  817 */         dupX1();
/*  818 */         swap();
/*      */       } 
/*  820 */       invokeConstructor(boxedType, new Method("<init>", Type.VOID_TYPE, new Type[] { type }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void valueOf(Type type) {
/*  831 */     if (type.getSort() == 10 || type.getSort() == 9) {
/*      */       return;
/*      */     }
/*  834 */     if (type == Type.VOID_TYPE) {
/*  835 */       push((String)null);
/*      */     } else {
/*  837 */       Type boxedType = getBoxedType(type);
/*  838 */       invokeStatic(boxedType, new Method("valueOf", boxedType, new Type[] { type }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unbox(Type type) {
/*      */     Method unboxMethod;
/*  849 */     Type boxedType = NUMBER_TYPE;
/*      */     
/*  851 */     switch (type.getSort()) {
/*      */       case 0:
/*      */         return;
/*      */       case 2:
/*  855 */         boxedType = CHARACTER_TYPE;
/*  856 */         unboxMethod = CHAR_VALUE;
/*      */         break;
/*      */       case 1:
/*  859 */         boxedType = BOOLEAN_TYPE;
/*  860 */         unboxMethod = BOOLEAN_VALUE;
/*      */         break;
/*      */       case 8:
/*  863 */         unboxMethod = DOUBLE_VALUE;
/*      */         break;
/*      */       case 6:
/*  866 */         unboxMethod = FLOAT_VALUE;
/*      */         break;
/*      */       case 7:
/*  869 */         unboxMethod = LONG_VALUE;
/*      */         break;
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*  874 */         unboxMethod = INT_VALUE;
/*      */         break;
/*      */       default:
/*  877 */         unboxMethod = null;
/*      */         break;
/*      */     } 
/*  880 */     if (unboxMethod == null) {
/*  881 */       checkCast(type);
/*      */     } else {
/*  883 */       checkCast(boxedType);
/*  884 */       invokeVirtual(boxedType, unboxMethod);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Label newLabel() {
/*  898 */     return new Label();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mark(Label label) {
/*  907 */     this.mv.visitLabel(label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Label mark() {
/*  916 */     Label label = new Label();
/*  917 */     this.mv.visitLabel(label);
/*  918 */     return label;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ifCmp(Type type, int mode, Label label) {
/*      */     int intOp;
/*  930 */     switch (type.getSort()) {
/*      */       case 7:
/*  932 */         this.mv.visitInsn(148);
/*      */         break;
/*      */       case 8:
/*  935 */         this.mv.visitInsn((mode == 156 || mode == 157) ? 151 : 152);
/*      */         break;
/*      */       case 6:
/*  938 */         this.mv.visitInsn((mode == 156 || mode == 157) ? 149 : 150);
/*      */         break;
/*      */       case 9:
/*      */       case 10:
/*  942 */         if (mode == 153) {
/*  943 */           this.mv.visitJumpInsn(165, label); return;
/*      */         } 
/*  945 */         if (mode == 154) {
/*  946 */           this.mv.visitJumpInsn(166, label);
/*      */           return;
/*      */         } 
/*  949 */         throw new IllegalArgumentException(stringConcat$1(String.valueOf(type)));
/*      */       
/*      */       default:
/*  952 */         intOp = -1;
/*  953 */         switch (mode) {
/*      */           case 153:
/*  955 */             intOp = 159;
/*      */             break;
/*      */           case 154:
/*  958 */             intOp = 160;
/*      */             break;
/*      */           case 156:
/*  961 */             intOp = 162;
/*      */             break;
/*      */           case 155:
/*  964 */             intOp = 161;
/*      */             break;
/*      */           case 158:
/*  967 */             intOp = 164;
/*      */             break;
/*      */           case 157:
/*  970 */             intOp = 163;
/*      */             break;
/*      */           default:
/*  973 */             throw new IllegalArgumentException(stringConcat$2(mode));
/*      */         } 
/*  975 */         this.mv.visitJumpInsn(intOp, label);
/*      */         return;
/*      */     } 
/*  978 */     this.mv.visitJumpInsn(mode, label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ifICmp(int mode, Label label) {
/*  989 */     ifCmp(Type.INT_TYPE, mode, label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ifZCmp(int mode, Label label) {
/* 1000 */     this.mv.visitJumpInsn(mode, label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ifNull(Label label) {
/* 1009 */     this.mv.visitJumpInsn(198, label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ifNonNull(Label label) {
/* 1018 */     this.mv.visitJumpInsn(199, label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void goTo(Label label) {
/* 1027 */     this.mv.visitJumpInsn(167, label);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ret(int local) {
/* 1037 */     this.mv.visitVarInsn(169, local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tableSwitch(int[] keys, TableSwitchGenerator generator) {
/*      */     float density;
/* 1048 */     if (keys.length == 0) {
/* 1049 */       density = 0.0F;
/*      */     } else {
/* 1051 */       density = keys.length / (keys[keys.length - 1] - keys[0] + 1);
/*      */     } 
/* 1053 */     tableSwitch(keys, generator, (density >= 0.5F));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tableSwitch(int[] keys, TableSwitchGenerator generator, boolean useTable) {
/* 1066 */     for (int i = 1; i < keys.length; i++) {
/* 1067 */       if (keys[i] < keys[i - 1]) {
/* 1068 */         throw new IllegalArgumentException("keys must be sorted in ascending order");
/*      */       }
/*      */     } 
/* 1071 */     Label defaultLabel = newLabel();
/* 1072 */     Label endLabel = newLabel();
/* 1073 */     if (keys.length > 0) {
/* 1074 */       int numKeys = keys.length;
/* 1075 */       if (useTable) {
/* 1076 */         int min = keys[0];
/* 1077 */         int max = keys[numKeys - 1];
/* 1078 */         int range = max - min + 1;
/* 1079 */         Label[] labels = new Label[range];
/* 1080 */         Arrays.fill((Object[])labels, defaultLabel); int j;
/* 1081 */         for (j = 0; j < numKeys; j++) {
/* 1082 */           labels[keys[j] - min] = newLabel();
/*      */         }
/* 1084 */         this.mv.visitTableSwitchInsn(min, max, defaultLabel, labels);
/* 1085 */         for (j = 0; j < range; j++) {
/* 1086 */           Label label = labels[j];
/* 1087 */           if (label != defaultLabel) {
/* 1088 */             mark(label);
/* 1089 */             generator.generateCase(j + min, endLabel);
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1093 */         Label[] labels = new Label[numKeys]; int j;
/* 1094 */         for (j = 0; j < numKeys; j++) {
/* 1095 */           labels[j] = newLabel();
/*      */         }
/* 1097 */         this.mv.visitLookupSwitchInsn(defaultLabel, keys, labels);
/* 1098 */         for (j = 0; j < numKeys; j++) {
/* 1099 */           mark(labels[j]);
/* 1100 */           generator.generateCase(keys[j], endLabel);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1104 */     mark(defaultLabel);
/* 1105 */     generator.generateDefault();
/* 1106 */     mark(endLabel);
/*      */   }
/*      */ 
/*      */   
/*      */   public void returnValue() {
/* 1111 */     this.mv.visitInsn(this.returnType.getOpcode(172));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fieldInsn(int opcode, Type ownerType, String name, Type fieldType) {
/* 1128 */     this.mv.visitFieldInsn(opcode, ownerType.getInternalName(), name, fieldType.getDescriptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getStatic(Type owner, String name, Type type) {
/* 1139 */     fieldInsn(178, owner, name, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void putStatic(Type owner, String name, Type type) {
/* 1150 */     fieldInsn(179, owner, name, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getField(Type owner, String name, Type type) {
/* 1161 */     fieldInsn(180, owner, name, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void putField(Type owner, String name, Type type) {
/* 1172 */     fieldInsn(181, owner, name, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeInsn(int opcode, Type type, Method method, boolean isInterface) {
/* 1189 */     String owner = (type.getSort() == 9) ? type.getDescriptor() : type.getInternalName();
/* 1190 */     this.mv.visitMethodInsn(opcode, owner, method.getName(), method.getDescriptor(), isInterface);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeVirtual(Type owner, Method method) {
/* 1200 */     invokeInsn(182, owner, method, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeConstructor(Type type, Method method) {
/* 1210 */     invokeInsn(183, type, method, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeStatic(Type owner, Method method) {
/* 1220 */     invokeInsn(184, owner, method, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeInterface(Type owner, Method method) {
/* 1230 */     invokeInsn(185, owner, method, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeDynamic(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 1249 */     this.mv.visitInvokeDynamicInsn(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void typeInsn(int opcode, Type type) {
/* 1263 */     this.mv.visitTypeInsn(opcode, type.getInternalName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newInstance(Type type) {
/* 1272 */     typeInsn(187, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newArray(Type type) {
/* 1281 */     InstructionAdapter.newarray(this.mv, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void arrayLength() {
/* 1290 */     this.mv.visitInsn(190);
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwException() {
/* 1295 */     this.mv.visitInsn(191);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void throwException(Type type, String message) {
/* 1306 */     newInstance(type);
/* 1307 */     dup();
/* 1308 */     push(message);
/* 1309 */     invokeConstructor(type, Method.getMethod("void <init> (String)"));
/* 1310 */     throwException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkCast(Type type) {
/* 1319 */     if (!type.equals(OBJECT_TYPE)) {
/* 1320 */       typeInsn(192, type);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void instanceOf(Type type) {
/* 1330 */     typeInsn(193, type);
/*      */   }
/*      */ 
/*      */   
/*      */   public void monitorEnter() {
/* 1335 */     this.mv.visitInsn(194);
/*      */   }
/*      */ 
/*      */   
/*      */   public void monitorExit() {
/* 1340 */     this.mv.visitInsn(195);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endMethod() {
/* 1349 */     if ((this.access & 0x400) == 0) {
/* 1350 */       this.mv.visitMaxs(0, 0);
/*      */     }
/* 1352 */     this.mv.visitEnd();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void catchException(Label start, Label end, Type exception) {
/* 1364 */     Label catchLabel = new Label();
/* 1365 */     if (exception == null) {
/* 1366 */       this.mv.visitTryCatchBlock(start, end, catchLabel, null);
/*      */     } else {
/* 1368 */       this.mv.visitTryCatchBlock(start, end, catchLabel, exception.getInternalName());
/*      */     } 
/* 1370 */     mark(catchLabel);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\GeneratorAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */