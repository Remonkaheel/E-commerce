package aj.org.objectweb.asm.commons;

import aj.org.objectweb.asm.Label;

public interface TableSwitchGenerator {
  void generateCase(int paramInt, Label paramLabel);
  
  void generateDefault();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\TableSwitchGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */