/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.ClassVisitor;
/*     */ import aj.org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticInitMerger
/*     */   extends ClassVisitor
/*     */ {
/*     */   private String owner;
/*     */   private final String renamedClinitMethodPrefix;
/*     */   private int numClinitMethods;
/*     */   private MethodVisitor mergedClinitVisitor;
/*     */   
/*     */   public StaticInitMerger(String prefix, ClassVisitor classVisitor) {
/*  64 */     this(589824, prefix, classVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StaticInitMerger(int api, String prefix, ClassVisitor classVisitor) {
/*  77 */     super(api, classVisitor);
/*  78 */     this.renamedClinitMethodPrefix = prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/*  89 */     super.visit(version, access, name, signature, superName, interfaces);
/*  90 */     this.owner = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
/*     */     MethodVisitor methodVisitor;
/* 101 */     if ("<clinit>".equals(name)) {
/* 102 */       int newAccess = 10;
/* 103 */       String newName = stringConcat$0(this.renamedClinitMethodPrefix, this.numClinitMethods++);
/* 104 */       methodVisitor = super.visitMethod(newAccess, newName, descriptor, signature, exceptions);
/*     */       
/* 106 */       if (this.mergedClinitVisitor == null) {
/* 107 */         this.mergedClinitVisitor = super.visitMethod(newAccess, name, descriptor, null, null);
/*     */       }
/* 109 */       this.mergedClinitVisitor.visitMethodInsn(184, this.owner, newName, descriptor, false);
/*     */     } else {
/* 111 */       methodVisitor = super.visitMethod(access, name, descriptor, signature, exceptions);
/*     */     } 
/* 113 */     return methodVisitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitEnd() {
/* 118 */     if (this.mergedClinitVisitor != null) {
/* 119 */       this.mergedClinitVisitor.visitInsn(177);
/* 120 */       this.mergedClinitVisitor.visitMaxs(0, 0);
/*     */     } 
/* 122 */     super.visitEnd();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\StaticInitMerger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */