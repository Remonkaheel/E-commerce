/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.ConstantDynamic;
/*     */ import aj.org.objectweb.asm.Handle;
/*     */ import aj.org.objectweb.asm.Label;
/*     */ import aj.org.objectweb.asm.MethodVisitor;
/*     */ import aj.org.objectweb.asm.Opcodes;
/*     */ import aj.org.objectweb.asm.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AdviceAdapter
/*     */   extends GeneratorAdapter
/*     */   implements Opcodes
/*     */ {
/*  54 */   private static final Object UNINITIALIZED_THIS = new Object();
/*     */ 
/*     */   
/*  57 */   private static final Object OTHER = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String INVALID_OPCODE = "Invalid opcode ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int methodAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String methodDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean isConstructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean superClassConstructorCalled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Object> stackFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Label, List<Object>> forwardJumpStackFrames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AdviceAdapter(int api, MethodVisitor methodVisitor, int access, String name, String descriptor) {
/* 114 */     super(api, methodVisitor, access, name, descriptor);
/* 115 */     this.methodAccess = access;
/* 116 */     this.methodDesc = descriptor;
/* 117 */     this.isConstructor = "<init>".equals(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitCode() {
/* 122 */     super.visitCode();
/* 123 */     if (this.isConstructor) {
/* 124 */       this.stackFrame = new ArrayList();
/* 125 */       this.forwardJumpStackFrames = new HashMap<Label, List<Object>>();
/*     */     } else {
/* 127 */       onMethodEnter();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLabel(Label label) {
/* 133 */     super.visitLabel(label);
/* 134 */     if (this.isConstructor && this.forwardJumpStackFrames != null) {
/* 135 */       List<Object> labelStackFrame = this.forwardJumpStackFrames.get(label);
/* 136 */       if (labelStackFrame != null) {
/* 137 */         this.stackFrame = labelStackFrame;
/* 138 */         this.superClassConstructorCalled = false;
/* 139 */         this.forwardJumpStackFrames.remove(label);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInsn(int opcode) {
/* 146 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/*     */       int stackSize;
/* 148 */       switch (opcode) {
/*     */         case 172:
/*     */         case 173:
/*     */         case 174:
/*     */         case 175:
/*     */         case 176:
/* 154 */           throw new IllegalArgumentException("Invalid return in constructor");
/*     */         case 177:
/* 156 */           onMethodExit(opcode);
/* 157 */           endConstructorBasicBlockWithoutSuccessor();
/*     */           break;
/*     */         case 191:
/* 160 */           popValue();
/* 161 */           onMethodExit(opcode);
/* 162 */           endConstructorBasicBlockWithoutSuccessor();
/*     */           break;
/*     */         case 0:
/*     */         case 47:
/*     */         case 49:
/*     */         case 116:
/*     */         case 117:
/*     */         case 118:
/*     */         case 119:
/*     */         case 134:
/*     */         case 138:
/*     */         case 139:
/*     */         case 143:
/*     */         case 145:
/*     */         case 146:
/*     */         case 147:
/*     */         case 190:
/*     */           break;
/*     */         case 1:
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 133:
/*     */         case 135:
/*     */         case 140:
/*     */         case 141:
/* 195 */           pushValue(OTHER);
/*     */           break;
/*     */         case 9:
/*     */         case 10:
/*     */         case 14:
/*     */         case 15:
/* 201 */           pushValue(OTHER);
/* 202 */           pushValue(OTHER);
/*     */           break;
/*     */         case 46:
/*     */         case 48:
/*     */         case 50:
/*     */         case 51:
/*     */         case 52:
/*     */         case 53:
/*     */         case 87:
/*     */         case 96:
/*     */         case 98:
/*     */         case 100:
/*     */         case 102:
/*     */         case 104:
/*     */         case 106:
/*     */         case 108:
/*     */         case 110:
/*     */         case 112:
/*     */         case 114:
/*     */         case 120:
/*     */         case 121:
/*     */         case 122:
/*     */         case 123:
/*     */         case 124:
/*     */         case 125:
/*     */         case 126:
/*     */         case 128:
/*     */         case 130:
/*     */         case 136:
/*     */         case 137:
/*     */         case 142:
/*     */         case 144:
/*     */         case 149:
/*     */         case 150:
/*     */         case 194:
/*     */         case 195:
/* 238 */           popValue();
/*     */           break;
/*     */         case 88:
/*     */         case 97:
/*     */         case 99:
/*     */         case 101:
/*     */         case 103:
/*     */         case 105:
/*     */         case 107:
/*     */         case 109:
/*     */         case 111:
/*     */         case 113:
/*     */         case 115:
/*     */         case 127:
/*     */         case 129:
/*     */         case 131:
/* 254 */           popValue();
/* 255 */           popValue();
/*     */           break;
/*     */         case 79:
/*     */         case 81:
/*     */         case 83:
/*     */         case 84:
/*     */         case 85:
/*     */         case 86:
/*     */         case 148:
/*     */         case 151:
/*     */         case 152:
/* 266 */           popValue();
/* 267 */           popValue();
/* 268 */           popValue();
/*     */           break;
/*     */         case 80:
/*     */         case 82:
/* 272 */           popValue();
/* 273 */           popValue();
/* 274 */           popValue();
/* 275 */           popValue();
/*     */           break;
/*     */         case 89:
/* 278 */           pushValue(peekValue());
/*     */           break;
/*     */         case 90:
/* 281 */           stackSize = this.stackFrame.size();
/* 282 */           this.stackFrame.add(stackSize - 2, this.stackFrame.get(stackSize - 1));
/*     */           break;
/*     */         case 91:
/* 285 */           stackSize = this.stackFrame.size();
/* 286 */           this.stackFrame.add(stackSize - 3, this.stackFrame.get(stackSize - 1));
/*     */           break;
/*     */         case 92:
/* 289 */           stackSize = this.stackFrame.size();
/* 290 */           this.stackFrame.add(stackSize - 2, this.stackFrame.get(stackSize - 1));
/* 291 */           this.stackFrame.add(stackSize - 2, this.stackFrame.get(stackSize - 1));
/*     */           break;
/*     */         case 93:
/* 294 */           stackSize = this.stackFrame.size();
/* 295 */           this.stackFrame.add(stackSize - 3, this.stackFrame.get(stackSize - 1));
/* 296 */           this.stackFrame.add(stackSize - 3, this.stackFrame.get(stackSize - 1));
/*     */           break;
/*     */         case 94:
/* 299 */           stackSize = this.stackFrame.size();
/* 300 */           this.stackFrame.add(stackSize - 4, this.stackFrame.get(stackSize - 1));
/* 301 */           this.stackFrame.add(stackSize - 4, this.stackFrame.get(stackSize - 1));
/*     */           break;
/*     */         case 95:
/* 304 */           stackSize = this.stackFrame.size();
/* 305 */           this.stackFrame.add(stackSize - 2, this.stackFrame.get(stackSize - 1));
/* 306 */           this.stackFrame.remove(stackSize);
/*     */           break;
/*     */         default:
/* 309 */           throw new IllegalArgumentException(stringConcat$0(opcode));
/*     */       } 
/*     */     } else {
/* 312 */       switch (opcode) {
/*     */         case 172:
/*     */         case 173:
/*     */         case 174:
/*     */         case 175:
/*     */         case 176:
/*     */         case 177:
/*     */         case 191:
/* 320 */           onMethodExit(opcode);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 326 */     super.visitInsn(opcode);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitVarInsn(int opcode, int varIndex) {
/* 331 */     super.visitVarInsn(opcode, varIndex);
/* 332 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 333 */       switch (opcode) {
/*     */         case 21:
/*     */         case 23:
/* 336 */           pushValue(OTHER);
/*     */           return;
/*     */         case 22:
/*     */         case 24:
/* 340 */           pushValue(OTHER);
/* 341 */           pushValue(OTHER);
/*     */           return;
/*     */         case 25:
/* 344 */           pushValue((varIndex == 0) ? UNINITIALIZED_THIS : OTHER);
/*     */           return;
/*     */         case 54:
/*     */         case 56:
/*     */         case 58:
/* 349 */           popValue();
/*     */           return;
/*     */         case 55:
/*     */         case 57:
/* 353 */           popValue();
/* 354 */           popValue();
/*     */           return;
/*     */         case 169:
/* 357 */           endConstructorBasicBlockWithoutSuccessor();
/*     */           return;
/*     */       } 
/* 360 */       throw new IllegalArgumentException(stringConcat$1(opcode));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
/* 368 */     super.visitFieldInsn(opcode, owner, name, descriptor);
/* 369 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 370 */       char firstDescriptorChar = descriptor.charAt(0);
/* 371 */       boolean longOrDouble = (firstDescriptorChar == 'J' || firstDescriptorChar == 'D');
/* 372 */       switch (opcode) {
/*     */         case 178:
/* 374 */           pushValue(OTHER);
/* 375 */           if (longOrDouble) {
/* 376 */             pushValue(OTHER);
/*     */           }
/*     */           return;
/*     */         case 179:
/* 380 */           popValue();
/* 381 */           if (longOrDouble) {
/* 382 */             popValue();
/*     */           }
/*     */           return;
/*     */         case 181:
/* 386 */           popValue();
/* 387 */           popValue();
/* 388 */           if (longOrDouble) {
/* 389 */             popValue();
/*     */           }
/*     */           return;
/*     */         case 180:
/* 393 */           if (longOrDouble) {
/* 394 */             pushValue(OTHER);
/*     */           }
/*     */           return;
/*     */       } 
/* 398 */       throw new IllegalArgumentException(stringConcat$2(opcode));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand) {
/* 405 */     super.visitIntInsn(opcode, operand);
/* 406 */     if (this.isConstructor && !this.superClassConstructorCalled && opcode != 188) {
/* 407 */       pushValue(OTHER);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLdcInsn(Object value) {
/* 413 */     super.visitLdcInsn(value);
/* 414 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 415 */       pushValue(OTHER);
/* 416 */       if (value instanceof Double || value instanceof Long || (value instanceof ConstantDynamic && ((ConstantDynamic)value)
/*     */         
/* 418 */         .getSize() == 2)) {
/* 419 */         pushValue(OTHER);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMultiANewArrayInsn(String descriptor, int numDimensions) {
/* 426 */     super.visitMultiANewArrayInsn(descriptor, numDimensions);
/* 427 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 428 */       for (int i = 0; i < numDimensions; i++) {
/* 429 */         popValue();
/*     */       }
/* 431 */       pushValue(OTHER);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type) {
/* 437 */     super.visitTypeInsn(opcode, type);
/*     */     
/* 439 */     if (this.isConstructor && !this.superClassConstructorCalled && opcode == 187) {
/* 440 */       pushValue(OTHER);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodInsn(int opcodeAndSource, String owner, String name, String descriptor, boolean isInterface) {
/* 451 */     if (this.api < 327680 && (opcodeAndSource & 0x100) == 0) {
/*     */       
/* 453 */       super.visitMethodInsn(opcodeAndSource, owner, name, descriptor, isInterface);
/*     */       return;
/*     */     } 
/* 456 */     super.visitMethodInsn(opcodeAndSource, owner, name, descriptor, isInterface);
/* 457 */     int opcode = opcodeAndSource & 0xFFFFFEFF;
/*     */     
/* 459 */     doVisitMethodInsn(opcode, name, descriptor);
/*     */   }
/*     */   
/*     */   private void doVisitMethodInsn(int opcode, String name, String descriptor) {
/* 463 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 464 */       Object value; for (Type argumentType : Type.getArgumentTypes(descriptor)) {
/* 465 */         popValue();
/* 466 */         if (argumentType.getSize() == 2) {
/* 467 */           popValue();
/*     */         }
/*     */       } 
/* 470 */       switch (opcode) {
/*     */         case 182:
/*     */         case 185:
/* 473 */           popValue();
/*     */           break;
/*     */         case 183:
/* 476 */           value = popValue();
/* 477 */           if (value == UNINITIALIZED_THIS && !this.superClassConstructorCalled && name
/*     */             
/* 479 */             .equals("<init>")) {
/* 480 */             this.superClassConstructorCalled = true;
/* 481 */             onMethodEnter();
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 488 */       Type returnType = Type.getReturnType(descriptor);
/* 489 */       if (returnType != Type.VOID_TYPE) {
/* 490 */         pushValue(OTHER);
/* 491 */         if (returnType.getSize() == 2) {
/* 492 */           pushValue(OTHER);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 504 */     super.visitInvokeDynamicInsn(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments);
/* 505 */     doVisitMethodInsn(186, name, descriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label) {
/* 510 */     super.visitJumpInsn(opcode, label);
/* 511 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 512 */       switch (opcode) {
/*     */         case 153:
/*     */         case 154:
/*     */         case 155:
/*     */         case 156:
/*     */         case 157:
/*     */         case 158:
/*     */         case 198:
/*     */         case 199:
/* 521 */           popValue();
/*     */           break;
/*     */         case 159:
/*     */         case 160:
/*     */         case 161:
/*     */         case 162:
/*     */         case 163:
/*     */         case 164:
/*     */         case 165:
/*     */         case 166:
/* 531 */           popValue();
/* 532 */           popValue();
/*     */           break;
/*     */         case 168:
/* 535 */           pushValue(OTHER);
/*     */           break;
/*     */         case 167:
/* 538 */           endConstructorBasicBlockWithoutSuccessor();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 543 */       addForwardJump(label);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
/* 549 */     super.visitLookupSwitchInsn(dflt, keys, labels);
/* 550 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 551 */       popValue();
/* 552 */       addForwardJumps(dflt, labels);
/* 553 */       endConstructorBasicBlockWithoutSuccessor();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
/* 560 */     super.visitTableSwitchInsn(min, max, dflt, labels);
/* 561 */     if (this.isConstructor && !this.superClassConstructorCalled) {
/* 562 */       popValue();
/* 563 */       addForwardJumps(dflt, labels);
/* 564 */       endConstructorBasicBlockWithoutSuccessor();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
/* 571 */     super.visitTryCatchBlock(start, end, handler, type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 580 */     if (this.isConstructor && !this.forwardJumpStackFrames.containsKey(handler)) {
/* 581 */       List<Object> handlerStackFrame = new ArrayList();
/* 582 */       handlerStackFrame.add(OTHER);
/* 583 */       this.forwardJumpStackFrames.put(handler, handlerStackFrame);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addForwardJumps(Label dflt, Label[] labels) {
/* 588 */     addForwardJump(dflt);
/* 589 */     for (Label label : labels) {
/* 590 */       addForwardJump(label);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addForwardJump(Label label) {
/* 595 */     if (this.forwardJumpStackFrames.containsKey(label)) {
/*     */       return;
/*     */     }
/* 598 */     this.forwardJumpStackFrames.put(label, new ArrayList(this.stackFrame));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void endConstructorBasicBlockWithoutSuccessor() {
/* 611 */     this.superClassConstructorCalled = true;
/*     */   }
/*     */   
/*     */   private Object popValue() {
/* 615 */     return this.stackFrame.remove(this.stackFrame.size() - 1);
/*     */   }
/*     */   
/*     */   private Object peekValue() {
/* 619 */     return this.stackFrame.get(this.stackFrame.size() - 1);
/*     */   }
/*     */   
/*     */   private void pushValue(Object value) {
/* 623 */     this.stackFrame.add(value);
/*     */   }
/*     */   
/*     */   protected void onMethodEnter() {}
/*     */   
/*     */   protected void onMethodExit(int opcode) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\AdviceAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */