/*     */ package aj.org.objectweb.asm.commons;
/*     */ 
/*     */ import aj.org.objectweb.asm.ConstantDynamic;
/*     */ import aj.org.objectweb.asm.Handle;
/*     */ import aj.org.objectweb.asm.Type;
/*     */ import aj.org.objectweb.asm.signature.SignatureReader;
/*     */ import aj.org.objectweb.asm.signature.SignatureVisitor;
/*     */ import aj.org.objectweb.asm.signature.SignatureWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Remapper
/*     */ {
/*     */   public String mapDesc(String descriptor) {
/*  55 */     return mapType(Type.getType(descriptor)).getDescriptor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type mapType(Type type) {
/*     */     StringBuilder remappedDescriptor;
/*     */     int i;
/*     */     String remappedInternalName;
/*  69 */     switch (type.getSort()) {
/*     */       case 9:
/*  71 */         remappedDescriptor = new StringBuilder();
/*  72 */         for (i = 0; i < type.getDimensions(); i++) {
/*  73 */           remappedDescriptor.append('[');
/*     */         }
/*  75 */         remappedDescriptor.append(mapType(type.getElementType()).getDescriptor());
/*  76 */         return Type.getType(remappedDescriptor.toString());
/*     */       case 10:
/*  78 */         remappedInternalName = map(type.getInternalName());
/*  79 */         return (remappedInternalName != null) ? Type.getObjectType(remappedInternalName) : type;
/*     */       case 11:
/*  81 */         return Type.getMethodType(mapMethodDesc(type.getDescriptor()));
/*     */     } 
/*  83 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapType(String internalName) {
/*  96 */     if (internalName == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     return mapType(Type.getObjectType(internalName)).getInternalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] mapTypes(String[] internalNames) {
/* 111 */     String[] remappedInternalNames = null;
/* 112 */     for (int i = 0; i < internalNames.length; i++) {
/* 113 */       String internalName = internalNames[i];
/* 114 */       String remappedInternalName = mapType(internalName);
/* 115 */       if (remappedInternalName != null) {
/* 116 */         if (remappedInternalNames == null) {
/* 117 */           remappedInternalNames = (String[])internalNames.clone();
/*     */         }
/* 119 */         remappedInternalNames[i] = remappedInternalName;
/*     */       } 
/*     */     } 
/* 122 */     return (remappedInternalNames != null) ? remappedInternalNames : internalNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapMethodDesc(String methodDescriptor) {
/* 134 */     if ("()V".equals(methodDescriptor)) {
/* 135 */       return methodDescriptor;
/*     */     }
/*     */     
/* 138 */     StringBuilder stringBuilder = new StringBuilder("(");
/* 139 */     for (Type argumentType : Type.getArgumentTypes(methodDescriptor)) {
/* 140 */       stringBuilder.append(mapType(argumentType).getDescriptor());
/*     */     }
/* 142 */     Type returnType = Type.getReturnType(methodDescriptor);
/* 143 */     if (returnType == Type.VOID_TYPE) {
/* 144 */       stringBuilder.append(")V");
/*     */     } else {
/* 146 */       stringBuilder.append(')').append(mapType(returnType).getDescriptor());
/*     */     } 
/* 148 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object mapValue(Object value) {
/* 162 */     if (value instanceof Type) {
/* 163 */       return mapType((Type)value);
/*     */     }
/* 165 */     if (value instanceof Handle) {
/* 166 */       Handle handle = (Handle)value;
/* 167 */       boolean isFieldHandle = (handle.getTag() <= 4);
/*     */       
/* 169 */       return new Handle(handle
/* 170 */           .getTag(), 
/* 171 */           mapType(handle.getOwner()), 
/* 172 */           isFieldHandle ? 
/* 173 */           mapFieldName(handle.getOwner(), handle.getName(), handle.getDesc()) : 
/* 174 */           mapMethodName(handle.getOwner(), handle.getName(), handle.getDesc()), 
/* 175 */           isFieldHandle ? mapDesc(handle.getDesc()) : mapMethodDesc(handle.getDesc()), handle
/* 176 */           .isInterface());
/*     */     } 
/* 178 */     if (value instanceof ConstantDynamic) {
/* 179 */       ConstantDynamic constantDynamic = (ConstantDynamic)value;
/* 180 */       int bootstrapMethodArgumentCount = constantDynamic.getBootstrapMethodArgumentCount();
/* 181 */       Object[] remappedBootstrapMethodArguments = new Object[bootstrapMethodArgumentCount];
/* 182 */       for (int i = 0; i < bootstrapMethodArgumentCount; i++) {
/* 183 */         remappedBootstrapMethodArguments[i] = 
/* 184 */           mapValue(constantDynamic.getBootstrapMethodArgument(i));
/*     */       }
/* 186 */       String descriptor = constantDynamic.getDescriptor();
/* 187 */       return new ConstantDynamic(
/* 188 */           mapInvokeDynamicMethodName(constantDynamic.getName(), descriptor), 
/* 189 */           mapDesc(descriptor), (Handle)
/* 190 */           mapValue(constantDynamic.getBootstrapMethod()), remappedBootstrapMethodArguments);
/*     */     } 
/*     */     
/* 193 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapSignature(String signature, boolean typeSignature) {
/* 206 */     if (signature == null) {
/* 207 */       return null;
/*     */     }
/* 209 */     SignatureReader signatureReader = new SignatureReader(signature);
/* 210 */     SignatureWriter signatureWriter = new SignatureWriter();
/* 211 */     SignatureVisitor signatureRemapper = createSignatureRemapper((SignatureVisitor)signatureWriter);
/* 212 */     if (typeSignature) {
/* 213 */       signatureReader.acceptType(signatureRemapper);
/*     */     } else {
/* 215 */       signatureReader.accept(signatureRemapper);
/*     */     } 
/* 217 */     return signatureWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected SignatureVisitor createRemappingSignatureAdapter(SignatureVisitor signatureVisitor) {
/* 231 */     return createSignatureRemapper(signatureVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SignatureVisitor createSignatureRemapper(SignatureVisitor signatureVisitor) {
/* 242 */     return new SignatureRemapper(signatureVisitor, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapAnnotationAttributeName(String descriptor, String name) {
/* 254 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapInnerClassName(String name, String ownerName, String innerName) {
/* 271 */     String remappedInnerName = mapType(name);
/*     */     
/* 273 */     if (remappedInnerName.equals(name)) {
/* 274 */       return innerName;
/*     */     }
/* 276 */     int originSplit = name.lastIndexOf('/');
/* 277 */     int remappedSplit = remappedInnerName.lastIndexOf('/');
/* 278 */     if (originSplit != -1 && remappedSplit != -1 && 
/* 279 */       name.substring(originSplit).equals(remappedInnerName.substring(remappedSplit)))
/*     */     {
/* 281 */       return innerName;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 286 */     if (remappedInnerName.contains("$")) {
/* 287 */       int index = remappedInnerName.lastIndexOf('$') + 1;
/* 288 */       while (index < remappedInnerName.length() && 
/* 289 */         Character.isDigit(remappedInnerName.charAt(index))) {
/* 290 */         index++;
/*     */       }
/* 292 */       return remappedInnerName.substring(index);
/*     */     } 
/* 294 */     return innerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapMethodName(String owner, String name, String descriptor) {
/* 309 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapInvokeDynamicMethodName(String name, String descriptor) {
/* 321 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapRecordComponentName(String owner, String name, String descriptor) {
/* 336 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapFieldName(String owner, String name, String descriptor) {
/* 350 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapPackageName(String name) {
/* 361 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapModuleName(String name) {
/* 372 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String map(String internalName) {
/* 383 */     return internalName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\aspectjweaver-1.9.24.jar!\aj\org\objectweb\asm\commons\Remapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */