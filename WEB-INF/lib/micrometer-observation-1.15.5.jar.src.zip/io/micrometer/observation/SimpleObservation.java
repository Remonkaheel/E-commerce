/*     */ package io.micrometer.observation;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import io.micrometer.common.util.StringUtils;
/*     */ import io.micrometer.common.util.internal.logging.InternalLogger;
/*     */ import io.micrometer.common.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collection;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimpleObservation
/*     */   implements Observation
/*     */ {
/*     */   final ObservationRegistry registry;
/*     */   private final Observation.Context context;
/*     */   @Nullable
/*     */   private ObservationConvention convention;
/*     */   private final Deque<ObservationHandler> handlers;
/*     */   private final Collection<ObservationFilter> filters;
/*  56 */   final Map<Thread, Observation.Scope> lastScope = new ConcurrentHashMap<>();
/*     */   
/*     */   SimpleObservation(@Nullable String name, ObservationRegistry registry, Observation.Context context) {
/*  59 */     this.registry = registry;
/*  60 */     this.context = context;
/*  61 */     this.context.setName(name);
/*  62 */     this.convention = getConventionFromConfig(registry, context);
/*  63 */     this.handlers = getHandlersFromConfig(registry, context);
/*  64 */     this.filters = registry.observationConfig().getObservationFilters();
/*     */   }
/*     */ 
/*     */   
/*     */   SimpleObservation(ObservationConvention<? extends Observation.Context> convention, ObservationRegistry registry, Observation.Context context) {
/*  69 */     this.registry = registry;
/*  70 */     this.context = context;
/*     */     
/*  72 */     this.handlers = getHandlersFromConfig(registry, context);
/*  73 */     this.filters = registry.observationConfig().getObservationFilters();
/*  74 */     if (convention.supportsContext(context)) {
/*  75 */       this.convention = convention;
/*     */     } else {
/*     */       
/*  78 */       throw new IllegalStateException("Convention [" + convention + "] doesn't support context [" + context + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static ObservationConvention getConventionFromConfig(ObservationRegistry registry, Observation.Context context) {
/*  85 */     for (ObservationConvention<?> convention : registry.observationConfig().getObservationConventions()) {
/*  86 */       if (convention.supportsContext(context)) {
/*  87 */         return convention;
/*     */       }
/*     */     } 
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   private static Deque<ObservationHandler> getHandlersFromConfig(ObservationRegistry registry, Observation.Context context) {
/*  94 */     Collection<ObservationHandler<?>> handlers = registry.observationConfig().getObservationHandlers();
/*  95 */     Deque<ObservationHandler> deque = new ArrayDeque<>(handlers.size());
/*  96 */     for (ObservationHandler<?> handler : handlers) {
/*  97 */       if (handler.supportsContext(context)) {
/*  98 */         deque.add(handler);
/*     */       }
/*     */     } 
/* 101 */     return deque;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation contextualName(@Nullable String contextualName) {
/* 106 */     this.context.setContextualName(contextualName);
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation parentObservation(@Nullable Observation parentObservation) {
/* 112 */     this.context.setParentObservation(parentObservation);
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 118 */     this.context.addLowCardinalityKeyValue(keyValue);
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 124 */     this.context.addHighCardinalityKeyValue(keyValue);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation observationConvention(ObservationConvention<?> convention) {
/* 130 */     if (convention.supportsContext(this.context)) {
/* 131 */       this.convention = convention;
/*     */     }
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation error(Throwable error) {
/* 138 */     this.context.setError(error);
/* 139 */     notifyOnError();
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation event(Observation.Event event) {
/* 145 */     notifyOnEvent(event);
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation start() {
/* 151 */     if (this.convention != null) {
/* 152 */       this.context.addLowCardinalityKeyValues(this.convention.getLowCardinalityKeyValues(this.context));
/* 153 */       this.context.addHighCardinalityKeyValues(this.convention.getHighCardinalityKeyValues(this.context));
/*     */       
/* 155 */       String newName = this.convention.getName();
/* 156 */       if (StringUtils.isNotBlank(newName)) {
/* 157 */         this.context.setName(newName);
/*     */       }
/*     */     } 
/*     */     
/* 161 */     notifyOnObservationStarted();
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation.Context getContext() {
/* 167 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 173 */     if (this.convention != null) {
/* 174 */       this.context.addLowCardinalityKeyValues(this.convention.getLowCardinalityKeyValues(this.context));
/* 175 */       this.context.addHighCardinalityKeyValues(this.convention.getHighCardinalityKeyValues(this.context));
/*     */       
/* 177 */       String newContextualName = this.convention.getContextualName(this.context);
/* 178 */       if (StringUtils.isNotBlank(newContextualName)) {
/* 179 */         this.context.setContextualName(newContextualName);
/*     */       }
/*     */     } 
/*     */     
/* 183 */     Observation.Context modifiedContext = this.context;
/* 184 */     for (ObservationFilter filter : this.filters) {
/* 185 */       modifiedContext = filter.map(modifiedContext);
/*     */     }
/*     */     
/* 188 */     notifyOnObservationStopped(modifiedContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation.Scope openScope() {
/* 193 */     Observation.Scope scope = new SimpleScope(this.registry, this);
/* 194 */     notifyOnScopeOpened();
/* 195 */     this.lastScope.put(Thread.currentThread(), scope);
/* 196 */     return scope;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Observation.Scope getEnclosingScope() {
/* 202 */     return this.lastScope.get(Thread.currentThread());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 207 */     return "{name=" + this.context.getName() + "(" + this.context.getContextualName() + "), error=" + this.context
/* 208 */       .getError() + ", context=" + this.context + '}';
/*     */   }
/*     */ 
/*     */   
/*     */   void notifyOnObservationStarted() {
/* 213 */     for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 214 */       handler.onStart(this.context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void notifyOnError() {
/* 220 */     for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 221 */       handler.onError(this.context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void notifyOnEvent(Observation.Event event) {
/* 227 */     for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 228 */       handler.onEvent(event, this.context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void notifyOnScopeOpened() {
/* 234 */     for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 235 */       handler.onScopeOpened(this.context);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyOnScopeClosed() {
/* 243 */     Iterator<ObservationHandler> iterator = this.handlers.descendingIterator();
/* 244 */     while (iterator.hasNext()) {
/* 245 */       ObservationHandler<Observation.Context> handler = iterator.next();
/* 246 */       handler.onScopeClosed(this.context);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void notifyOnScopeMakeCurrent() {
/* 252 */     for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 253 */       handler.onScopeOpened(this.context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void notifyOnScopeReset() {
/* 259 */     for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 260 */       handler.onScopeReset(this.context);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyOnObservationStopped(Observation.Context context) {
/* 268 */     this.handlers.descendingIterator().forEachRemaining(handler -> handler.onStop(context));
/*     */   }
/*     */ 
/*     */   
/*     */   public ObservationRegistry getObservationRegistry() {
/* 273 */     return this.registry;
/*     */   }
/*     */   
/*     */   static class SimpleScope
/*     */     implements Observation.Scope {
/* 278 */     private static final InternalLogger log = InternalLoggerFactory.getInstance(SimpleScope.class);
/*     */     
/*     */     final ObservationRegistry registry;
/*     */     
/*     */     private final Observation currentObservation;
/*     */     
/*     */     @Nullable
/*     */     final Observation.Scope previousObservationScope;
/*     */     
/*     */     SimpleScope(ObservationRegistry registry, Observation current) {
/* 288 */       this.registry = registry;
/* 289 */       this.currentObservation = current;
/* 290 */       this.previousObservationScope = registry.getCurrentObservationScope();
/* 291 */       this.registry.setCurrentObservationScope(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation getCurrentObservation() {
/* 296 */       return this.currentObservation;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 301 */       if (this.currentObservation instanceof SimpleObservation) {
/* 302 */         SimpleObservation observation = (SimpleObservation)this.currentObservation;
/* 303 */         SimpleScope lastScopeForThisObservation = getLastScope(this);
/* 304 */         if (lastScopeForThisObservation != null) {
/* 305 */           observation.lastScope.put(Thread.currentThread(), lastScopeForThisObservation);
/*     */         } else {
/*     */           
/* 308 */           observation.lastScope.remove(Thread.currentThread());
/*     */         } 
/* 310 */         observation.notifyOnScopeClosed();
/*     */       }
/* 312 */       else if (this.currentObservation != null && !this.currentObservation.isNoop()) {
/* 313 */         log.debug("Custom observation type was used in combination with SimpleScope - that's unexpected");
/*     */       } else {
/*     */         
/* 316 */         log.trace("NoOp observation used with SimpleScope");
/*     */       } 
/* 318 */       this.registry.setCurrentObservationScope(this.previousObservationScope);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private SimpleScope getLastScope(SimpleScope simpleScope) {
/* 323 */       SimpleScope scope = simpleScope;
/*     */       do {
/* 325 */         scope = (SimpleScope)scope.previousObservationScope;
/*     */       }
/* 327 */       while (scope != null && !this.currentObservation.equals(scope.currentObservation));
/* 328 */       return scope;
/*     */     }
/*     */ 
/*     */     
/*     */     public void reset() {
/* 333 */       SimpleScope scope = this;
/* 334 */       if (scope.currentObservation instanceof SimpleObservation) {
/* 335 */         SimpleObservation simpleObservation = (SimpleObservation)scope.currentObservation;
/*     */ 
/*     */ 
/*     */         
/*     */         do {
/* 340 */           simpleObservation.notifyOnScopeReset();
/* 341 */           scope = (SimpleScope)scope.previousObservationScope;
/*     */         }
/* 343 */         while (scope != null);
/*     */       } 
/* 345 */       this.registry.setCurrentObservationScope(null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void makeCurrent() {
/* 367 */       SimpleScope scope = this;
/*     */ 
/*     */ 
/*     */       
/*     */       do {
/* 372 */         if (scope.currentObservation instanceof SimpleObservation) {
/* 373 */           ((SimpleObservation)scope.currentObservation).notifyOnScopeReset();
/*     */         }
/* 375 */         scope = (SimpleScope)scope.previousObservationScope;
/*     */       }
/* 377 */       while (scope != null);
/*     */       
/* 379 */       Deque<SimpleScope> scopes = new ArrayDeque<>();
/* 380 */       scope = this;
/*     */       while (true) {
/* 382 */         scopes.addFirst(scope);
/* 383 */         scope = (SimpleScope)scope.previousObservationScope;
/*     */         
/* 385 */         if (scope == null) {
/* 386 */           for (SimpleScope simpleScope : scopes) {
/* 387 */             if (simpleScope.currentObservation instanceof SimpleObservation) {
/* 388 */               ((SimpleObservation)simpleScope.currentObservation).notifyOnScopeMakeCurrent();
/*     */             }
/*     */           } 
/* 391 */           this.registry.setCurrentObservationScope(this);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } @Nullable
/*     */     public Observation.Scope getPreviousObservationScope() {
/* 397 */       return this.previousObservationScope;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\SimpleObservation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */