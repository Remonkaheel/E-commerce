/*      */ package io.micrometer.observation;
/*      */ 
/*      */ import io.micrometer.common.KeyValue;
/*      */ import io.micrometer.common.KeyValues;
/*      */ import io.micrometer.common.lang.NonNull;
/*      */ import io.micrometer.common.lang.Nullable;
/*      */ import io.micrometer.common.util.internal.logging.InternalLoggerFactory;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface Observation
/*      */   extends ObservationView
/*      */ {
/*   55 */   public static final Observation NOOP = new NoopObservation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Observation start(String name, @Nullable ObservationRegistry registry) {
/*   69 */     return start(name, Context::new, registry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Context> Observation start(String name, Supplier<T> contextSupplier, @Nullable ObservationRegistry registry) {
/*   89 */     return createNotStarted(name, contextSupplier, registry).start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Observation createNotStarted(String name, @Nullable ObservationRegistry registry) {
/*  102 */     return createNotStarted(name, Context::new, registry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Context> Observation createNotStarted(String name, Supplier<T> contextSupplier, @Nullable ObservationRegistry registry) {
/*  124 */     if (registry == null || registry.isNoop()) {
/*  125 */       return NOOP;
/*      */     }
/*  127 */     Context context = (Context)contextSupplier.get();
/*  128 */     context.setParentFromCurrentObservation(registry);
/*  129 */     if (!registry.observationConfig().isObservationEnabled(name, context)) {
/*  130 */       return NOOP;
/*      */     }
/*  132 */     return new SimpleObservation(name, registry, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Context> Observation createNotStarted(@Nullable ObservationConvention<T> customConvention, ObservationConvention<T> defaultConvention, Supplier<T> contextSupplier, @Nullable ObservationRegistry registry) {
/*      */     ObservationConvention<T> convention;
/*  167 */     if (registry == null || registry.isNoop()) {
/*  168 */       return NOOP;
/*      */     }
/*      */     
/*  171 */     Context context = (Context)contextSupplier.get();
/*  172 */     context.setParentFromCurrentObservation(registry);
/*  173 */     if (customConvention != null) {
/*  174 */       convention = customConvention;
/*      */     } else {
/*      */       
/*  177 */       convention = registry.observationConfig().getObservationConvention((T)context, defaultConvention);
/*      */     } 
/*  179 */     if (!registry.observationConfig().isObservationEnabled(convention.getName(), context)) {
/*  180 */       return NOOP;
/*      */     }
/*  182 */     return new SimpleObservation(convention, registry, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Observation start(ObservationConvention<Context> observationConvention, ObservationRegistry registry) {
/*  198 */     return start(observationConvention, Context::new, registry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Context> Observation start(ObservationConvention<T> observationConvention, Supplier<T> contextSupplier, ObservationRegistry registry) {
/*  224 */     return createNotStarted(observationConvention, contextSupplier, registry).start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Context> Observation start(@Nullable ObservationConvention<T> customConvention, ObservationConvention<T> defaultConvention, Supplier<T> contextSupplier, ObservationRegistry registry) {
/*  256 */     return createNotStarted(customConvention, defaultConvention, contextSupplier, registry).start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Observation createNotStarted(ObservationConvention<Context> observationConvention, ObservationRegistry registry) {
/*  275 */     return createNotStarted(observationConvention, Context::new, registry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Context> Observation createNotStarted(ObservationConvention<T> observationConvention, Supplier<T> contextSupplier, ObservationRegistry registry) {
/*  312 */     if (registry == null || registry.isNoop() || observationConvention == NoopObservationConvention.INSTANCE) {
/*  313 */       return NOOP;
/*      */     }
/*  315 */     Context context = (Context)contextSupplier.get();
/*  316 */     context.setParentFromCurrentObservation(registry);
/*  317 */     if (!registry.observationConfig().isObservationEnabled(observationConvention.getName(), context)) {
/*  318 */       return NOOP;
/*      */     }
/*  320 */     return new SimpleObservation(observationConvention, registry, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default Observation lowCardinalityKeyValue(String key, String value) {
/*  362 */     return lowCardinalityKeyValue(KeyValue.of(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default Observation lowCardinalityKeyValues(KeyValues keyValues) {
/*  373 */     for (KeyValue keyValue : keyValues) {
/*  374 */       lowCardinalityKeyValue(keyValue);
/*      */     }
/*  376 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default Observation highCardinalityKeyValue(String key, String value) {
/*  397 */     return highCardinalityKeyValue(KeyValue.of(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default Observation highCardinalityKeyValues(KeyValues keyValues) {
/*  408 */     for (KeyValue keyValue : keyValues) {
/*  409 */       highCardinalityKeyValue(keyValue);
/*      */     }
/*  411 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default boolean isNoop() {
/*  419 */     return (this == NOOP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default ContextView getContextView() {
/*  466 */     return getContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default void observe(Runnable runnable) {
/*  496 */     start(); 
/*  497 */     try { Scope scope = openScope(); 
/*  498 */       try { runnable.run();
/*  499 */         if (scope != null) scope.close();  } catch (Throwable throwable) { if (scope != null)
/*  500 */           try { scope.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable error)
/*  501 */     { error(error);
/*  502 */       throw error; }
/*      */     finally
/*      */     
/*  505 */     { stop(); }
/*      */   
/*      */   }
/*      */   
/*      */   default Runnable wrap(Runnable runnable) {
/*  510 */     return () -> observe(runnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default <E extends Throwable> void observeChecked(CheckedRunnable<E> checkedRunnable) throws E {
/*  528 */     start(); 
/*  529 */     try { Scope scope = openScope(); 
/*  530 */       try { checkedRunnable.run();
/*  531 */         if (scope != null) scope.close();  } catch (Throwable throwable) { if (scope != null)
/*  532 */           try { scope.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw (E)throwable; }  } catch (Throwable error)
/*  533 */     { error(error);
/*  534 */       throw (E)error; }
/*      */     finally
/*      */     
/*  537 */     { stop(); }
/*      */   
/*      */   }
/*      */   
/*      */   default <E extends Throwable> CheckedRunnable<E> wrapChecked(CheckedRunnable<E> checkedRunnable) throws E {
/*  542 */     return () -> observeChecked(checkedRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   default <T> T observe(Supplier<T> supplier) {
/*  562 */     start(); try {
/*  563 */       Scope scope = openScope();
/*      */     
/*      */     }
/*  566 */     catch (Throwable error) {
/*  567 */       error(error);
/*  568 */       throw error;
/*      */     } finally {
/*      */       
/*  571 */       stop();
/*      */     } 
/*      */   }
/*      */   
/*      */   default <T> Supplier<T> wrap(Supplier<T> supplier) {
/*  576 */     return () -> observe(supplier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   default <T, E extends Throwable> T observeChecked(CheckedCallable<T, E> checkedCallable) throws E {
/*  597 */     start(); try {
/*  598 */       Scope scope = openScope();
/*      */     
/*      */     }
/*  601 */     catch (Throwable error) {
/*  602 */       error(error);
/*  603 */       throw (E)error;
/*      */     } finally {
/*      */       
/*  606 */       stop();
/*      */     } 
/*      */   }
/*      */   
/*      */   default <T, E extends Throwable> CheckedCallable<T, E> wrapChecked(CheckedCallable<T, E> checkedCallable) throws E {
/*  611 */     return () -> observeChecked(checkedCallable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   @Deprecated
/*      */   default <C extends Context, T> T observeWithContext(Function<C, T> function) {
/*  641 */     InternalLoggerFactory.getInstance(Observation.class)
/*  642 */       .warn("This method is deprecated. Please migrate to observation.observe(...)");
/*  643 */     start(); try {
/*  644 */       Scope scope = openScope();
/*      */     
/*      */     }
/*  647 */     catch (Throwable error) {
/*  648 */       error(error);
/*  649 */       throw error;
/*      */     } finally {
/*      */       
/*  652 */       stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   @Deprecated
/*      */   default <C extends Context, T, E extends Throwable> T observeCheckedWithContext(CheckedFunction<C, T, E> function) throws E {
/*  686 */     InternalLoggerFactory.getInstance(Observation.class)
/*  687 */       .warn("This method is deprecated. Please migrate to observation.observeChecked(...)");
/*  688 */     start(); try {
/*  689 */       Scope scope = openScope();
/*      */     
/*      */     }
/*  692 */     catch (Throwable error) {
/*  693 */       error(error);
/*  694 */       throw (E)error;
/*      */     } finally {
/*      */       
/*  697 */       stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default void scoped(Runnable runnable) {
/*      */     
/*  707 */     try { Scope scope = openScope(); 
/*  708 */       try { runnable.run();
/*  709 */         if (scope != null) scope.close();  } catch (Throwable throwable) { if (scope != null)
/*  710 */           try { scope.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception exception)
/*  711 */     { error(exception);
/*  712 */       throw exception; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default <E extends Throwable> void scopedChecked(CheckedRunnable<E> checkedRunnable) throws E {
/*      */     
/*  723 */     try { Scope scope = openScope(); 
/*  724 */       try { checkedRunnable.run();
/*  725 */         if (scope != null) scope.close();  } catch (Throwable throwable) { if (scope != null)
/*  726 */           try { scope.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw (E)throwable; }  } catch (Throwable throwable)
/*  727 */     { error(throwable);
/*  728 */       throw (E)throwable; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default <T> T scoped(Supplier<T> supplier) {
/*      */     
/*  740 */     try { Scope scope = openScope(); 
/*  741 */       try { T t = supplier.get();
/*  742 */         if (scope != null) scope.close();  return t; } catch (Throwable throwable) { if (scope != null)
/*  743 */           try { scope.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception exception)
/*  744 */     { error(exception);
/*  745 */       throw exception; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default <T, E extends Throwable> T scopedChecked(CheckedCallable<T, E> checkedCallable) throws E {
/*      */     
/*  758 */     try { Scope scope = openScope(); 
/*  759 */       try { T t = checkedCallable.call();
/*  760 */         if (scope != null) scope.close();  return t; } catch (Throwable throwable) { if (scope != null)
/*  761 */           try { scope.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw (E)throwable; }  } catch (Throwable error)
/*  762 */     { error(error);
/*  763 */       throw (E)error; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void tryScoped(@Nullable Observation parent, Runnable action) {
/*  774 */     if (parent != null) {
/*  775 */       parent.scoped(action);
/*      */     } else {
/*      */       
/*  778 */       action.run();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <E extends Throwable> void tryScopedChecked(@Nullable Observation parent, CheckedRunnable<E> checkedRunnable) throws E {
/*  791 */     if (parent != null) {
/*  792 */       parent.scopedChecked(checkedRunnable);
/*      */     } else {
/*      */       
/*  795 */       checkedRunnable.run();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> T tryScoped(@Nullable Observation parent, Supplier<T> action) {
/*  807 */     if (parent != null) {
/*  808 */       return parent.scoped(action);
/*      */     }
/*  810 */     return action.get();
/*      */   }
/*      */   Observation contextualName(@Nullable String paramString);
/*      */   Observation parentObservation(@Nullable Observation paramObservation);
/*      */   
/*      */   Observation lowCardinalityKeyValue(KeyValue paramKeyValue);
/*      */   
/*      */   Observation highCardinalityKeyValue(KeyValue paramKeyValue);
/*      */   
/*      */   Observation observationConvention(ObservationConvention<?> paramObservationConvention);
/*      */   
/*      */   Observation error(Throwable paramThrowable);
/*      */   
/*      */   static <T, E extends Throwable> T tryScopedChecked(@Nullable Observation parent, CheckedCallable<T, E> checkedCallable) throws E {
/*  824 */     if (parent != null) {
/*  825 */       return parent.scopedChecked(checkedCallable);
/*      */     }
/*  827 */     return checkedCallable.call();
/*      */   }
/*      */   
/*      */   Observation event(Event paramEvent);
/*      */   
/*      */   Observation start();
/*      */   
/*      */   Context getContext();
/*      */   
/*      */   void stop();
/*      */   
/*      */   Scope openScope();
/*      */   
/*      */   public static interface Scope
/*      */     extends AutoCloseable {
/*  842 */     public static final Scope NOOP = NoopObservation.NoopScope.INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Observation getCurrentObservation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     default Scope getPreviousObservationScope() {
/*  857 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void close();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void reset();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void makeCurrent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default boolean isNoop() {
/*  900 */       return (this == NOOP);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Context
/*      */     implements ContextView
/*      */   {
/*  914 */     private final Map<Object, Object> map = new ConcurrentHashMap<>();
/*      */     
/*      */     private String name;
/*      */     
/*      */     @Nullable
/*      */     private String contextualName;
/*      */     
/*      */     @Nullable
/*      */     private Throwable error;
/*      */     
/*      */     @Nullable
/*      */     private ObservationView parentObservation;
/*      */     
/*  927 */     private final Map<String, KeyValue> lowCardinalityKeyValues = new ConcurrentHashMap<>();
/*      */     
/*  929 */     private final Map<String, KeyValue> highCardinalityKeyValues = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  937 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setName(String name) {
/*  945 */       this.name = name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getContextualName() {
/*  955 */       return this.contextualName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setContextualName(@Nullable String contextualName) {
/*  963 */       this.contextualName = contextualName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public ObservationView getParentObservation() {
/*  973 */       return this.parentObservation;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setParentObservation(@Nullable ObservationView parentObservation) {
/*  981 */       this.parentObservation = parentObservation;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setParentFromCurrentObservation(ObservationRegistry registry) {
/*  990 */       if (this.parentObservation == null) {
/*  991 */         Observation currentObservation = registry.getCurrentObservation();
/*  992 */         if (currentObservation != null) {
/*  993 */           setParentObservation(currentObservation);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Throwable getError() {
/* 1005 */       return this.error;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setError(Throwable error) {
/* 1013 */       this.error = error;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T> Context put(Object key, T object) {
/* 1024 */       this.map.put(key, object);
/* 1025 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public <T> T get(Object key) {
/* 1037 */       return (T)this.map.get(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object remove(Object key) {
/* 1047 */       return this.map.remove(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @NonNull
/*      */     public <T> T getRequired(Object key) {
/* 1060 */       T object = (T)this.map.get(key);
/* 1061 */       if (object == null) {
/* 1062 */         throw new IllegalArgumentException("Context does not have an entry for key [" + key + "]");
/*      */       }
/* 1064 */       return object;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object key) {
/* 1074 */       return this.map.containsKey(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T> T getOrDefault(Object key, T defaultObject) {
/* 1086 */       return (T)this.map.getOrDefault(key, defaultObject);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T> T computeIfAbsent(Object key, Function<Object, ? extends T> mappingFunction) {
/* 1098 */       return (T)this.map.computeIfAbsent(key, mappingFunction);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1105 */       this.map.clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context addLowCardinalityKeyValue(KeyValue keyValue) {
/* 1115 */       this.lowCardinalityKeyValues.put(keyValue.getKey(), keyValue);
/* 1116 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context addHighCardinalityKeyValue(KeyValue keyValue) {
/* 1127 */       this.highCardinalityKeyValues.put(keyValue.getKey(), keyValue);
/* 1128 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context removeLowCardinalityKeyValue(String keyName) {
/* 1140 */       this.lowCardinalityKeyValues.remove(keyName);
/* 1141 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context removeHighCardinalityKeyValue(String keyName) {
/* 1153 */       this.highCardinalityKeyValues.remove(keyName);
/* 1154 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context addLowCardinalityKeyValues(KeyValues keyValues) {
/* 1163 */       for (KeyValue keyValue : keyValues) {
/* 1164 */         addLowCardinalityKeyValue(keyValue);
/*      */       }
/* 1166 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context addHighCardinalityKeyValues(KeyValues keyValues) {
/* 1175 */       for (KeyValue keyValue : keyValues) {
/* 1176 */         addHighCardinalityKeyValue(keyValue);
/*      */       }
/* 1178 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context removeLowCardinalityKeyValues(String... keyNames) {
/* 1188 */       for (String keyName : keyNames) {
/* 1189 */         removeLowCardinalityKeyValue(keyName);
/*      */       }
/* 1191 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Context removeHighCardinalityKeyValues(String... keyNames) {
/* 1201 */       for (String keyName : keyNames) {
/* 1202 */         removeHighCardinalityKeyValue(keyName);
/*      */       }
/* 1204 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     @NonNull
/*      */     public KeyValues getLowCardinalityKeyValues() {
/* 1210 */       return KeyValues.of(this.lowCardinalityKeyValues.values());
/*      */     }
/*      */ 
/*      */     
/*      */     @NonNull
/*      */     public KeyValues getHighCardinalityKeyValues() {
/* 1216 */       return KeyValues.of(this.highCardinalityKeyValues.values());
/*      */     }
/*      */ 
/*      */     
/*      */     public KeyValue getLowCardinalityKeyValue(String key) {
/* 1221 */       return this.lowCardinalityKeyValues.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public KeyValue getHighCardinalityKeyValue(String key) {
/* 1226 */       return this.highCardinalityKeyValues.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     @NonNull
/*      */     public KeyValues getAllKeyValues() {
/* 1232 */       return getLowCardinalityKeyValues().and((Iterable)getHighCardinalityKeyValues());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1237 */       return "name='" + this.name + '\'' + ", contextualName='" + this.contextualName + '\'' + ", error='" + this.error + '\'' + ", lowCardinalityKeyValues=" + 
/* 1238 */         toString(getLowCardinalityKeyValues()) + ", highCardinalityKeyValues=" + 
/* 1239 */         toString(getHighCardinalityKeyValues()) + ", map=" + toString(this.map) + ", parentObservation=" + this.parentObservation;
/*      */     }
/*      */ 
/*      */     
/*      */     private String toString(KeyValues keyValues) {
/* 1244 */       return keyValues.stream()
/* 1245 */         .map(keyValue -> String.format("%s='%s'", new Object[] { keyValue.getKey(), keyValue.getValue()
/* 1246 */             })).collect(Collectors.joining(", ", "[", "]"));
/*      */     }
/*      */     
/*      */     private String toString(Map<Object, Object> map) {
/* 1250 */       return map.entrySet()
/* 1251 */         .stream()
/* 1252 */         .map(entry -> String.format("%s='%s'", new Object[] { entry.getKey(), entry.getValue()
/* 1253 */             })).collect(Collectors.joining(", ", "[", "]"));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Event
/*      */   {
/*      */     static Event of(String name, String contextualName) {
/* 1274 */       return new SimpleEvent(name, contextualName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static Event of(String name, String contextualName, long wallTime) {
/* 1287 */       return new SimpleEvent(name, contextualName, wallTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static Event of(String name) {
/* 1296 */       return of(name, name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default long getWallTime() {
/* 1313 */       return 0L;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default String getContextualName() {
/* 1323 */       return getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Event format(Object... dynamicEntriesForContextualName) {
/* 1333 */       return of(getName(), String.format(getContextualName(), dynamicEntriesForContextualName));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface ContextView
/*      */   {
/*      */     String getName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     String getContextualName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     ObservationView getParentObservation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     Throwable getError();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     <T> T get(Object param1Object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @NonNull
/*      */     <T> T getRequired(Object param1Object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean containsKey(Object param1Object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <T> T getOrDefault(Object param1Object, T param1T);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default <T> T getOrDefault(Object key, Supplier<T> defaultObjectSupplier) {
/* 1415 */       T value = get(key);
/* 1416 */       return (value != null) ? value : defaultObjectSupplier.get();
/*      */     }
/*      */     
/*      */     KeyValues getLowCardinalityKeyValues();
/*      */     
/*      */     @NonNull
/*      */     KeyValues getHighCardinalityKeyValues();
/*      */     
/*      */     @Nullable
/*      */     KeyValue getLowCardinalityKeyValue(String param1String);
/*      */     
/*      */     @Nullable
/*      */     KeyValue getHighCardinalityKeyValue(String param1String);
/*      */     
/*      */     @NonNull
/*      */     KeyValues getAllKeyValues();
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface CheckedRunnable<E extends Throwable> {
/*      */     void run() throws E;
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface CheckedCallable<T, E extends Throwable> {
/*      */     T call() throws E;
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface CheckedFunction<T, R, E extends Throwable> {
/*      */     @Nullable
/*      */     R apply(T param1T) throws E;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\Observation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */