/*   1 */ package io.micrometer.observation.aop;@Aspect @NonNullApi public class ObservedAspect { public static ObservedAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("io.micrometer.observation.aop.ObservedAspect", ajc$initFailureCause);  return ajc$perSingletonInstance; } public static boolean hasAspect() { return (ajc$perSingletonInstance != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Predicate<ProceedingJoinPoint> DONT_SKIP_ANYTHING = pjp -> false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObservationRegistry registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final ObservationConvention<ObservedAspectContext> observationConvention;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Predicate<ProceedingJoinPoint> shouldSkip;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     
/*  81 */     try { ajc$postClinit(); } catch (Throwable throwable) { ajc$initFailureCause = throwable = null; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservedAspect() {
/*  98 */     this(Observations.getGlobalRegistry(), null, DONT_SKIP_ANYTHING);
/*     */   }
/*     */   
/*     */   public ObservedAspect(ObservationRegistry registry) {
/* 102 */     this(registry, null, DONT_SKIP_ANYTHING);
/*     */   }
/*     */ 
/*     */   
/*     */   public ObservedAspect(ObservationRegistry registry, ObservationConvention<ObservedAspectContext> observationConvention) {
/* 107 */     this(registry, observationConvention, DONT_SKIP_ANYTHING);
/*     */   }
/*     */   
/*     */   public ObservedAspect(ObservationRegistry registry, Predicate<ProceedingJoinPoint> shouldSkip) {
/* 111 */     this(registry, null, shouldSkip);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservedAspect(ObservationRegistry registry, @Nullable ObservationConvention<ObservedAspectContext> observationConvention, Predicate<ProceedingJoinPoint> shouldSkip) {
/* 117 */     this.registry = registry;
/* 118 */     this.observationConvention = observationConvention;
/* 119 */     this.shouldSkip = shouldSkip;
/*     */   }
/*     */   
/*     */   @Around("@within(io.micrometer.observation.annotation.Observed) && !@annotation(io.micrometer.observation.annotation.Observed) && execution(* *.*(..))")
/*     */   @Nullable
/*     */   public Object observeClass(ProceedingJoinPoint pjp) throws Throwable {
/* 125 */     if (ajc$inlineAccessFieldGet$io_micrometer_observation_aop_ObservedAspect$io_micrometer_observation_aop_ObservedAspect$shouldSkip(this).test(pjp)) {
/* 126 */       return pjp.proceed();
/*     */     }
/*     */     
/* 129 */     Method method = ((MethodSignature)pjp.getSignature()).getMethod();
/* 130 */     Observed observed = (Observed)ajc$inlineAccessMethod$io_micrometer_observation_aop_ObservedAspect$io_micrometer_observation_aop_ObservedAspect$getDeclaringClass(this, pjp).getAnnotation(Observed.class);
/* 131 */     return ajc$inlineAccessMethod$io_micrometer_observation_aop_ObservedAspect$io_micrometer_observation_aop_ObservedAspect$observe(this, pjp, method, observed);
/*     */   }
/*     */   
/*     */   @Around("execution (@io.micrometer.observation.annotation.Observed * *.*(..))")
/*     */   @Nullable
/*     */   public Object observeMethod(ProceedingJoinPoint pjp) throws Throwable {
/* 137 */     if (ajc$inlineAccessFieldGet$io_micrometer_observation_aop_ObservedAspect$io_micrometer_observation_aop_ObservedAspect$shouldSkip(this).test(pjp)) {
/* 138 */       return pjp.proceed();
/*     */     }
/*     */     
/* 141 */     Method method = ajc$inlineAccessMethod$io_micrometer_observation_aop_ObservedAspect$io_micrometer_observation_aop_ObservedAspect$getMethod(this, pjp);
/* 142 */     Observed observed = method.<Observed>getAnnotation(Observed.class);
/* 143 */     return ajc$inlineAccessMethod$io_micrometer_observation_aop_ObservedAspect$io_micrometer_observation_aop_ObservedAspect$observe(this, pjp, method, observed);
/*     */   }
/*     */   
/*     */   private Object observe(ProceedingJoinPoint pjp, Method method, Observed observed) throws Throwable {
/* 147 */     Observation observation = ObservedAspectObservationDocumentation.of(pjp, observed, this.registry, this.observationConvention);
/*     */     
/* 149 */     if (CompletionStage.class.isAssignableFrom(method.getReturnType())) {
/* 150 */       observation.start();
/* 151 */       Observation.Scope scope = observation.openScope();
/*     */       try {
/* 153 */         Object result = pjp.proceed();
/* 154 */         if (result == null) {
/* 155 */           stopObservation(observation, null);
/* 156 */           return result;
/*     */         } 
/*     */         
/* 159 */         CompletionStage<?> stage = (CompletionStage)result;
/* 160 */         return stage.whenComplete((res, error) -> stopObservation(observation, error));
/*     */       
/*     */       }
/* 163 */       catch (Throwable error) {
/* 164 */         stopObservation(observation, error);
/* 165 */         throw error;
/*     */       } finally {
/*     */         
/* 168 */         scope.close();
/*     */       } 
/*     */     } 
/*     */     
/* 172 */     return observation.observeChecked(() -> pjp.proceed());
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> getDeclaringClass(ProceedingJoinPoint pjp) {
/* 177 */     Method method = ((MethodSignature)pjp.getSignature()).getMethod();
/* 178 */     Class<?> declaringClass = method.getDeclaringClass();
/* 179 */     if (!declaringClass.isAnnotationPresent((Class)Observed.class)) {
/* 180 */       return pjp.getTarget().getClass();
/*     */     }
/*     */     
/* 183 */     return declaringClass;
/*     */   }
/*     */   
/*     */   private Method getMethod(ProceedingJoinPoint pjp) throws NoSuchMethodException {
/* 187 */     Method method = ((MethodSignature)pjp.getSignature()).getMethod();
/* 188 */     if (method.getAnnotation(Observed.class) == null) {
/* 189 */       return pjp.getTarget().getClass().getMethod(method.getName(), method.getParameterTypes());
/*     */     }
/*     */     
/* 192 */     return method;
/*     */   }
/*     */   
/*     */   private void stopObservation(Observation observation, @Nullable Throwable error) {
/* 196 */     if (error != null) {
/* 197 */       observation.error(error);
/*     */     }
/* 199 */     observation.stop();
/*     */   }
/*     */   
/*     */   public static class ObservedAspectContext
/*     */     extends Observation.Context {
/*     */     private final ProceedingJoinPoint proceedingJoinPoint;
/*     */     
/*     */     public ObservedAspectContext(ProceedingJoinPoint proceedingJoinPoint) {
/* 207 */       this.proceedingJoinPoint = proceedingJoinPoint;
/*     */     }
/*     */     
/*     */     public ProceedingJoinPoint getProceedingJoinPoint() {
/* 211 */       return this.proceedingJoinPoint;
/*     */     }
/*     */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\aop\ObservedAspect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */