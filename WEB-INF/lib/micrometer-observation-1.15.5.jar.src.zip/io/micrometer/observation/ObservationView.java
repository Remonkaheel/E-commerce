/*    */ package io.micrometer.observation;
/*    */ 
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ObservationView
/*    */ {
/*    */   default ObservationRegistry getObservationRegistry() {
/* 34 */     return ObservationRegistry.NOOP;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Observation.ContextView getContextView();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   default Observation.Scope getEnclosingScope() {
/* 50 */     return Observation.Scope.NOOP;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\ObservationView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */