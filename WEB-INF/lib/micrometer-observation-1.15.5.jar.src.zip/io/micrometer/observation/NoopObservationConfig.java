/*    */ package io.micrometer.observation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NoopObservationConfig
/*    */   extends ObservationRegistry.ObservationConfig
/*    */ {
/* 35 */   static final NoopObservationConfig INSTANCE = new NoopObservationConfig();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ObservationRegistry.ObservationConfig observationHandler(ObservationHandler<?> handler) {
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public ObservationRegistry.ObservationConfig observationPredicate(ObservationPredicate predicate) {
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isObservationEnabled(String name, Observation.Context context) {
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   Collection<ObservationHandler<?>> getObservationHandlers() {
/* 57 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\NoopObservationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */