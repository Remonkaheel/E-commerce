/*    */ package io.micrometer.observation.transport;
/*    */ 
/*    */ import io.micrometer.common.lang.NonNull;
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestReplyReceiverContext<C, RES>
/*    */   extends ReceiverContext<C>
/*    */   implements ResponseContext<RES>
/*    */ {
/*    */   @Nullable
/*    */   private RES response;
/*    */   
/*    */   public RequestReplyReceiverContext(@NonNull Propagator.Getter<C> getter, @NonNull Kind kind) {
/* 41 */     super(getter, kind);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RequestReplyReceiverContext(@NonNull Propagator.Getter<C> getter) {
/* 49 */     this(getter, Kind.SERVER);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public RES getResponse() {
/* 55 */     return this.response;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setResponse(RES response) {
/* 60 */     this.response = response;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\transport\RequestReplyReceiverContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */