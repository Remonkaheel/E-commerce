/*     */ package io.micrometer.observation.transport;
/*     */ 
/*     */ import io.micrometer.common.lang.NonNull;
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import io.micrometer.observation.Observation;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReceiverContext<C>
/*     */   extends Observation.Context
/*     */ {
/*     */   private final Propagator.Getter<C> getter;
/*     */   private final Kind kind;
/*     */   private C carrier;
/*     */   @Nullable
/*     */   private String remoteServiceName;
/*     */   @Nullable
/*     */   private String remoteServiceAddress;
/*     */   
/*     */   public ReceiverContext(@NonNull Propagator.Getter<C> getter, @NonNull Kind kind) {
/*  52 */     this.getter = Objects.<Propagator.Getter<C>>requireNonNull(getter, "Getter must be set");
/*  53 */     this.kind = Objects.<Kind>requireNonNull(kind, "Kind must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReceiverContext(@NonNull Propagator.Getter<C> getter) {
/*  61 */     this(getter, Kind.CONSUMER);
/*     */   }
/*     */   
/*     */   public C getCarrier() {
/*  65 */     return this.carrier;
/*     */   }
/*     */   
/*     */   public void setCarrier(C carrier) {
/*  69 */     this.carrier = carrier;
/*     */   }
/*     */   
/*     */   public Propagator.Getter<C> getGetter() {
/*  73 */     return this.getter;
/*     */   }
/*     */   
/*     */   public Kind getKind() {
/*  77 */     return this.kind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getRemoteServiceName() {
/*  86 */     return this.remoteServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteServiceName(@Nullable String remoteServiceName) {
/*  94 */     this.remoteServiceName = remoteServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getRemoteServiceAddress() {
/* 103 */     return this.remoteServiceAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteServiceAddress(@Nullable String remoteServiceAddress) {
/* 111 */     this.remoteServiceAddress = remoteServiceAddress;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\transport\ReceiverContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */