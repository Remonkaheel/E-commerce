/*    */ package io.micrometer.observation.transport;
/*    */ 
/*    */ import io.micrometer.common.lang.NonNull;
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestReplySenderContext<C, RES>
/*    */   extends SenderContext<C>
/*    */   implements ResponseContext<RES>
/*    */ {
/*    */   @Nullable
/*    */   private RES response;
/*    */   
/*    */   public RequestReplySenderContext(@NonNull Propagator.Setter<C> setter, @NonNull Kind kind) {
/* 41 */     super(setter, kind);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RequestReplySenderContext(@NonNull Propagator.Setter<C> setter) {
/* 49 */     this(setter, Kind.CLIENT);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public RES getResponse() {
/* 55 */     return this.response;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setResponse(RES response) {
/* 60 */     this.response = response;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\transport\RequestReplySenderContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */