package io.micrometer.observation.transport;

import io.micrometer.common.lang.Nullable;

public interface ResponseContext<RES> {
  @Nullable
  RES getResponse();
  
  void setResponse(RES paramRES);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\transport\ResponseContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */