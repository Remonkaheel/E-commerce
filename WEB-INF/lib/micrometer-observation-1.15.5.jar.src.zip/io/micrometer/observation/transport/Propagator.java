package io.micrometer.observation.transport;

import io.micrometer.common.lang.Nullable;

public interface Propagator {
  public static interface Getter<C> {
    @Nullable
    String get(C param1C, String param1String);
  }
  
  public static interface Setter<C> {
    void set(@Nullable C param1C, String param1String1, String param1String2);
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\transport\Propagator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */