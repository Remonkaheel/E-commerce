/*     */ package io.micrometer.observation.transport;
/*     */ 
/*     */ import io.micrometer.common.lang.NonNull;
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import io.micrometer.observation.Observation;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SenderContext<C>
/*     */   extends Observation.Context
/*     */ {
/*     */   private final Propagator.Setter<C> setter;
/*     */   private final Kind kind;
/*     */   @Nullable
/*     */   private C carrier;
/*     */   @Nullable
/*     */   private String remoteServiceName;
/*     */   @Nullable
/*     */   private String remoteServiceAddress;
/*     */   
/*     */   public SenderContext(@NonNull Propagator.Setter<C> setter, @NonNull Kind kind) {
/*  52 */     this.setter = Objects.<Propagator.Setter<C>>requireNonNull(setter, "Setter must be set");
/*  53 */     this.kind = Objects.<Kind>requireNonNull(kind, "Kind must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SenderContext(@NonNull Propagator.Setter<C> setter) {
/*  61 */     this(setter, Kind.PRODUCER);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public C getCarrier() {
/*  66 */     return this.carrier;
/*     */   }
/*     */   
/*     */   public void setCarrier(C carrier) {
/*  70 */     this.carrier = carrier;
/*     */   }
/*     */   
/*     */   public Propagator.Setter<C> getSetter() {
/*  74 */     return this.setter;
/*     */   }
/*     */   
/*     */   public Kind getKind() {
/*  78 */     return this.kind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getRemoteServiceName() {
/*  87 */     return this.remoteServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteServiceName(@Nullable String remoteServiceName) {
/*  95 */     this.remoteServiceName = remoteServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getRemoteServiceAddress() {
/* 104 */     return this.remoteServiceAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteServiceAddress(@Nullable String remoteServiceAddress) {
/* 112 */     this.remoteServiceAddress = remoteServiceAddress;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\transport\SenderContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */