/*     */ package io.micrometer.observation;
/*     */ 
/*     */ import io.micrometer.common.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObservationTextPublisher
/*     */   implements ObservationHandler<Observation.Context>
/*     */ {
/*     */   private final Consumer<String> consumer;
/*     */   private final Predicate<Observation.Context> supportsContextPredicate;
/*     */   private final Function<Observation.Context, String> converter;
/*     */   
/*     */   public ObservationTextPublisher() {
/*  43 */     this(InternalLoggerFactory.getInstance(ObservationTextPublisher.class)::info, context -> true, String::valueOf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservationTextPublisher(Consumer<String> consumer) {
/*  51 */     this(consumer, context -> true, String::valueOf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservationTextPublisher(Consumer<String> consumer, Predicate<Observation.Context> supportsContextPredicate) {
/*  63 */     this(consumer, supportsContextPredicate, String::valueOf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservationTextPublisher(Consumer<String> consumer, Predicate<Observation.Context> supportsContextPredicate, Function<Observation.Context, String> converter) {
/*  76 */     this.consumer = consumer;
/*  77 */     this.supportsContextPredicate = supportsContextPredicate;
/*  78 */     this.converter = converter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStart(Observation.Context context) {
/*  83 */     publish("START", context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Observation.Context context) {
/*  88 */     publish("ERROR", context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEvent(Observation.Event event, Observation.Context context) {
/*  93 */     publishUnformatted(String.format("%5s - %s, %s", new Object[] { "EVENT", event, this.converter.apply(context) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onScopeOpened(Observation.Context context) {
/*  98 */     publish("OPEN", context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onScopeClosed(Observation.Context context) {
/* 103 */     publish("CLOSE", context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStop(Observation.Context context) {
/* 108 */     publish("STOP", context);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsContext(Observation.Context context) {
/* 113 */     return this.supportsContextPredicate.test(context);
/*     */   }
/*     */   
/*     */   private void publish(String event, Observation.Context context) {
/* 117 */     publishUnformatted(String.format("%5s - %s", new Object[] { event, this.converter.apply(context) }));
/*     */   }
/*     */   
/*     */   private void publishUnformatted(String event) {
/* 121 */     this.consumer.accept(event);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\ObservationTextPublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */