package io.micrometer.observation;

public interface GlobalObservationConvention<T extends Observation.Context> extends ObservationConvention<T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\GlobalObservationConvention.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */