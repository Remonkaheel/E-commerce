/*     */ package io.micrometer.observation;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NoopObservation
/*     */   implements Observation
/*     */ {
/*  32 */   private static final Observation.Context CONTEXT = new Observation.Context();
/*     */ 
/*     */   
/*     */   public Observation contextualName(@Nullable String contextualName) {
/*  36 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation parentObservation(@Nullable Observation parentObservation) {
/*  41 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation lowCardinalityKeyValue(String key, String value) {
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation highCardinalityKeyValue(KeyValue keyValue) {
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation highCardinalityKeyValue(String key, String value) {
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation observationConvention(ObservationConvention<?> observationConvention) {
/*  66 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation error(Throwable error) {
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation event(Observation.Event event) {
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation start() {
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Observation.Context getContext() {
/*  86 */     return CONTEXT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {}
/*     */ 
/*     */   
/*     */   public Observation.Scope openScope() {
/*  95 */     return new SimpleObservation.SimpleScope(NoopObservationRegistry.FOR_SCOPES, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class NoopScope
/*     */     implements Observation.Scope
/*     */   {
/* 106 */     static final Observation.Scope INSTANCE = new NoopScope();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Observation getCurrentObservation() {
/* 114 */       return Observation.NOOP;
/*     */     }
/*     */     
/*     */     public void close() {}
/*     */     
/*     */     public void reset() {}
/*     */     
/*     */     public void makeCurrent() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\NoopObservation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */