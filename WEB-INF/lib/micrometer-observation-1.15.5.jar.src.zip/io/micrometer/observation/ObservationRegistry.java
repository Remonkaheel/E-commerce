/*     */ package io.micrometer.observation;
/*     */ 
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ObservationRegistry
/*     */ {
/*     */   static ObservationRegistry create() {
/*  42 */     return new SimpleObservationRegistry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final ObservationRegistry NOOP = new NoopObservationRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Observation getCurrentObservation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Observation.Scope getCurrentObservationScope();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCurrentObservationScope(@Nullable Observation.Scope paramScope);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ObservationConfig observationConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isNoop() {
/*  89 */     return (this == NOOP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ObservationConfig
/*     */   {
/*  97 */     private final List<ObservationHandler<?>> observationHandlers = new CopyOnWriteArrayList<>();
/*     */     
/*  99 */     private final List<ObservationPredicate> observationPredicates = new CopyOnWriteArrayList<>();
/*     */     
/* 101 */     private final List<ObservationConvention<?>> observationConventions = new CopyOnWriteArrayList<>();
/*     */     
/* 103 */     private final List<ObservationFilter> observationFilters = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObservationConfig observationHandler(ObservationHandler<?> handler) {
/* 111 */       this.observationHandlers.add(handler);
/* 112 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObservationConfig observationPredicate(ObservationPredicate predicate) {
/* 122 */       this.observationPredicates.add(predicate);
/* 123 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObservationConfig observationFilter(ObservationFilter observationFilter) {
/* 133 */       this.observationFilters.add(observationFilter);
/* 134 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObservationConfig observationConvention(GlobalObservationConvention<?> observationConvention) {
/* 148 */       this.observationConventions.add(observationConvention);
/* 149 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     <T extends Observation.Context> ObservationConvention<T> getObservationConvention(T context, ObservationConvention<T> defaultConvention) {
/* 163 */       for (ObservationConvention<?> convention : this.observationConventions) {
/* 164 */         if (convention.supportsContext((Observation.Context)context)) {
/* 165 */           return (ObservationConvention)convention;
/*     */         }
/*     */       } 
/* 168 */       return Objects.<ObservationConvention<T>>requireNonNull(defaultConvention, "Default ObservationConvention must not be null");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isObservationEnabled(String name, @Nullable Observation.Context context) {
/* 179 */       for (ObservationPredicate predicate : this.observationPredicates) {
/* 180 */         if (!predicate.test(name, context)) {
/* 181 */           return false;
/*     */         }
/*     */       } 
/* 184 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     Collection<ObservationHandler<?>> getObservationHandlers() {
/* 189 */       return this.observationHandlers;
/*     */     }
/*     */     
/*     */     Collection<ObservationFilter> getObservationFilters() {
/* 193 */       return this.observationFilters;
/*     */     }
/*     */     
/*     */     Collection<ObservationConvention<?>> getObservationConventions() {
/* 197 */       return this.observationConventions;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\ObservationRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */