/*    */ package io.micrometer.observation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimpleEvent
/*    */   implements Observation.Event
/*    */ {
/*    */   private final String name;
/*    */   private final String contextualName;
/*    */   private final long wallTime;
/*    */   
/*    */   SimpleEvent(String name, String contextualName) {
/* 36 */     this(name, contextualName, System.currentTimeMillis());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SimpleEvent(String name, String contextualName, long wallTime) {
/* 45 */     this.name = name;
/* 46 */     this.contextualName = contextualName;
/* 47 */     this.wallTime = wallTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 52 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getContextualName() {
/* 57 */     return this.contextualName;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getWallTime() {
/* 62 */     return this.wallTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "event.name='" + getName() + "', event.contextualName='" + getContextualName() + "', event.wallTime=" + 
/* 68 */       getWallTime();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\SimpleEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */