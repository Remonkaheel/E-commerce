/*    */ package io.micrometer.observation;
/*    */ 
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimpleObservationRegistry
/*    */   implements ObservationRegistry
/*    */ {
/* 30 */   private static final ThreadLocal<Observation.Scope> localObservationScope = new ThreadLocal<>();
/*    */   
/* 32 */   private final ObservationRegistry.ObservationConfig observationConfig = new ObservationRegistry.ObservationConfig();
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Observation getCurrentObservation() {
/* 37 */     Observation.Scope scope = localObservationScope.get();
/* 38 */     if (scope != null) {
/* 39 */       return scope.getCurrentObservation();
/*    */     }
/* 41 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Observation.Scope getCurrentObservationScope() {
/* 46 */     return localObservationScope.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCurrentObservationScope(Observation.Scope current) {
/* 51 */     localObservationScope.set(current);
/*    */   }
/*    */ 
/*    */   
/*    */   public ObservationRegistry.ObservationConfig observationConfig() {
/* 56 */     return this.observationConfig;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNoop() {
/* 61 */     return (super.isNoop() || observationConfig().getObservationHandlers().isEmpty());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\SimpleObservationRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */