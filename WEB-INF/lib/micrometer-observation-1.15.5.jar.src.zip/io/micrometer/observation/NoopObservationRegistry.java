/*    */ package io.micrometer.observation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NoopObservationRegistry
/*    */   implements ObservationRegistry
/*    */ {
/* 29 */   static final ObservationRegistry FOR_SCOPES = ObservationRegistry.create();
/*    */   
/* 31 */   private final ObservationRegistry.ObservationConfig observationConfig = NoopObservationConfig.INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Observation getCurrentObservation() {
/* 38 */     return FOR_SCOPES.getCurrentObservation();
/*    */   }
/*    */ 
/*    */   
/*    */   public Observation.Scope getCurrentObservationScope() {
/* 43 */     return FOR_SCOPES.getCurrentObservationScope();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCurrentObservationScope(Observation.Scope current) {
/* 48 */     FOR_SCOPES.setCurrentObservationScope(current);
/*    */   }
/*    */ 
/*    */   
/*    */   public ObservationRegistry.ObservationConfig observationConfig() {
/* 53 */     return this.observationConfig;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\NoopObservationRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */