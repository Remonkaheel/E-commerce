/*    */ package io.micrometer.observation;
/*    */ 
/*    */ import io.micrometer.common.KeyValues;
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ObservationConvention<T extends Observation.Context>
/*    */   extends KeyValuesConvention
/*    */ {
/*    */   public static final ObservationConvention<Observation.Context> EMPTY = context -> false;
/*    */   
/*    */   default KeyValues getLowCardinalityKeyValues(T context) {
/* 40 */     return KeyValues.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default KeyValues getHighCardinalityKeyValues(T context) {
/* 48 */     return KeyValues.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   default String getName() {
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   default String getContextualName(T context) {
/* 77 */     return null;
/*    */   }
/*    */   
/*    */   boolean supportsContext(Observation.Context paramContext);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\ObservationConvention.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */