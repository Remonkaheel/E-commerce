/*     */ package io.micrometer.observation.docs;
/*     */ 
/*     */ import io.micrometer.common.docs.KeyName;
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ObservationDocumentation
/*     */ {
/*  55 */   public static final KeyName[] EMPTY = new KeyName[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final Observation.Event[] EMPTY_EVENT_NAMES = new Observation.Event[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default String getName() {
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default Class<? extends ObservationConvention<? extends Observation.Context>> getDefaultConvention() {
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default String getContextualName() {
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default KeyName[] getLowCardinalityKeyNames() {
/*  99 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default KeyName[] getHighCardinalityKeyNames() {
/* 107 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Observation.Event[] getEvents() {
/* 115 */     return EMPTY_EVENT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getPrefix() {
/* 124 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Observation observation(ObservationRegistry registry) {
/* 133 */     return observation(registry, io.micrometer.observation.Observation.Context::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Observation observation(ObservationRegistry registry, Supplier<Observation.Context> contextSupplier) {
/* 149 */     Observation observation = Observation.createNotStarted(getName(), contextSupplier, registry);
/* 150 */     if (getContextualName() != null) {
/* 151 */       observation.contextualName(getContextualName());
/*     */     }
/* 153 */     return observation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T extends Observation.Context> Observation observation(@Nullable ObservationConvention<T> customConvention, ObservationConvention<T> defaultConvention, Supplier<T> contextSupplier, ObservationRegistry registry) {
/* 175 */     if (getDefaultConvention() == null) {
/* 176 */       throw new IllegalStateException("You've decided to use convention based naming yet this observation [" + 
/* 177 */           getClass() + "] has not defined any default convention");
/*     */     }
/* 179 */     if (!getDefaultConvention().isAssignableFrom((
/*     */         
/* 181 */         (ObservationConvention)Objects.<ObservationConvention>requireNonNull(defaultConvention, "You have not provided a default convention in the Observation factory method"))
/*     */         
/* 183 */         .getClass())) {
/* 184 */       throw new IllegalArgumentException("Observation [" + getClass() + "] defined default convention to be of type [" + 
/* 185 */           getDefaultConvention() + "] but you have provided an incompatible one of type [" + defaultConvention
/* 186 */           .getClass() + "]");
/*     */     }
/* 188 */     Observation observation = Observation.createNotStarted(customConvention, defaultConvention, contextSupplier, registry);
/*     */     
/* 190 */     if (getName() != null) {
/* 191 */       observation.getContext().setName(getName());
/*     */     }
/* 193 */     if (getContextualName() != null) {
/* 194 */       observation.contextualName(getContextualName());
/*     */     }
/* 196 */     return observation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Observation start(ObservationRegistry registry) {
/* 205 */     return start(registry, io.micrometer.observation.Observation.Context::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Observation start(ObservationRegistry registry, Supplier<Observation.Context> contextSupplier) {
/* 220 */     return observation(registry, contextSupplier).start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T extends Observation.Context> Observation start(@Nullable ObservationConvention<T> customConvention, ObservationConvention<T> defaultConvention, Supplier<T> contextSupplier, ObservationRegistry registry) {
/* 241 */     return observation(customConvention, defaultConvention, contextSupplier, registry).start();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\docs\ObservationDocumentation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */