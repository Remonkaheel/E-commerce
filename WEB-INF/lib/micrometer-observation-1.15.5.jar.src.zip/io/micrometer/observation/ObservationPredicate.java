package io.micrometer.observation;

import java.util.function.BiPredicate;

public interface ObservationPredicate extends BiPredicate<String, Observation.Context> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\ObservationPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */