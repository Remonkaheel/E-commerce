/*     */ package io.micrometer.observation;
/*     */ 
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ObservationHandler<T extends Observation.Context>
/*     */ {
/*     */   default void onStart(T context) {}
/*     */   
/*     */   default void onError(T context) {}
/*     */   
/*     */   default void onEvent(Observation.Event event, T context) {}
/*     */   
/*     */   default void onScopeOpened(T context) {}
/*     */   
/*     */   default void onScopeClosed(T context) {}
/*     */   
/*     */   default void onScopeReset(T context) {}
/*     */   
/*     */   default void onStop(T context) {}
/*     */   
/*     */   boolean supportsContext(Observation.Context paramContext);
/*     */   
/*     */   public static interface CompositeObservationHandler
/*     */     extends ObservationHandler<Observation.Context>
/*     */   {
/*     */     List<ObservationHandler<Observation.Context>> getHandlers();
/*     */   }
/*     */   
/*     */   public static class FirstMatchingCompositeObservationHandler
/*     */     implements CompositeObservationHandler
/*     */   {
/*     */     private final List<ObservationHandler<Observation.Context>> handlers;
/*     */     
/*     */     @SafeVarargs
/*     */     public FirstMatchingCompositeObservationHandler(ObservationHandler<? extends Observation.Context>... handlers) {
/* 123 */       this(Arrays.asList(handlers));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FirstMatchingCompositeObservationHandler(List<? extends ObservationHandler<? extends Observation.Context>> handlers) {
/* 133 */       List<ObservationHandler<Observation.Context>> castedHandlers = new ArrayList<>(handlers.size());
/* 134 */       for (ObservationHandler<? extends Observation.Context> handler : handlers) {
/* 135 */         castedHandlers.add(handler);
/*     */       }
/* 137 */       this.handlers = castedHandlers;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<ObservationHandler<Observation.Context>> getHandlers() {
/* 142 */       return this.handlers;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStart(Observation.Context context) {
/* 147 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 148 */       if (handler != null) {
/* 149 */         handler.onStart(context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Observation.Context context) {
/* 155 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 156 */       if (handler != null) {
/* 157 */         handler.onError(context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onEvent(Observation.Event event, Observation.Context context) {
/* 163 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 164 */       if (handler != null) {
/* 165 */         handler.onEvent(event, context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onScopeOpened(Observation.Context context) {
/* 171 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 172 */       if (handler != null) {
/* 173 */         handler.onScopeOpened(context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onScopeClosed(Observation.Context context) {
/* 179 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 180 */       if (handler != null) {
/* 181 */         handler.onScopeClosed(context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onScopeReset(Observation.Context context) {
/* 187 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 188 */       if (handler != null) {
/* 189 */         handler.onScopeReset(context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStop(Observation.Context context) {
/* 195 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 196 */       if (handler != null) {
/* 197 */         handler.onStop(context);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supportsContext(Observation.Context context) {
/* 203 */       ObservationHandler<Observation.Context> handler = getFirstApplicableHandler(context);
/* 204 */       return (handler != null);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private ObservationHandler<Observation.Context> getFirstApplicableHandler(Observation.Context context) {
/* 209 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 210 */         if (handler.supportsContext(context)) {
/* 211 */           return handler;
/*     */         }
/*     */       } 
/* 214 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AllMatchingCompositeObservationHandler
/*     */     implements CompositeObservationHandler
/*     */   {
/*     */     private final List<ObservationHandler<Observation.Context>> handlers;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SafeVarargs
/*     */     public AllMatchingCompositeObservationHandler(ObservationHandler<? extends Observation.Context>... handlers) {
/* 232 */       this(Arrays.asList(handlers));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AllMatchingCompositeObservationHandler(List<? extends ObservationHandler<? extends Observation.Context>> handlers) {
/* 242 */       List<ObservationHandler<Observation.Context>> castedHandlers = new ArrayList<>(handlers.size());
/* 243 */       for (ObservationHandler<? extends Observation.Context> handler : handlers) {
/* 244 */         castedHandlers.add(handler);
/*     */       }
/* 246 */       this.handlers = castedHandlers;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<ObservationHandler<Observation.Context>> getHandlers() {
/* 251 */       return this.handlers;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStart(Observation.Context context) {
/* 256 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 257 */         if (handler.supportsContext(context)) {
/* 258 */           handler.onStart(context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Observation.Context context) {
/* 265 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 266 */         if (handler.supportsContext(context)) {
/* 267 */           handler.onError(context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onEvent(Observation.Event event, Observation.Context context) {
/* 274 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 275 */         if (handler.supportsContext(context)) {
/* 276 */           handler.onEvent(event, context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onScopeOpened(Observation.Context context) {
/* 283 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 284 */         if (handler.supportsContext(context)) {
/* 285 */           handler.onScopeOpened(context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onScopeClosed(Observation.Context context) {
/* 292 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 293 */         if (handler.supportsContext(context)) {
/* 294 */           handler.onScopeClosed(context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onScopeReset(Observation.Context context) {
/* 301 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 302 */         if (handler.supportsContext(context)) {
/* 303 */           handler.onScopeReset(context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStop(Observation.Context context) {
/* 310 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 311 */         if (handler.supportsContext(context)) {
/* 312 */           handler.onStop(context);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supportsContext(Observation.Context context) {
/* 319 */       for (ObservationHandler<Observation.Context> handler : this.handlers) {
/* 320 */         if (handler.supportsContext(context)) {
/* 321 */           return true;
/*     */         }
/*     */       } 
/* 324 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\ObservationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */