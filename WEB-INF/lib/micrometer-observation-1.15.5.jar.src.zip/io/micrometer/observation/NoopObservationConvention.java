/*    */ package io.micrometer.observation;
/*    */ 
/*    */ import io.micrometer.common.KeyValues;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NoopObservationConvention
/*    */   implements ObservationConvention<Observation.Context>
/*    */ {
/* 34 */   static final NoopObservationConvention INSTANCE = new NoopObservationConvention();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 41 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getContextualName(Observation.Context context) {
/* 46 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportsContext(Observation.Context context) {
/* 51 */     return ObservationConvention.EMPTY.supportsContext(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyValues getLowCardinalityKeyValues(Observation.Context context) {
/* 56 */     return ObservationConvention.EMPTY.getLowCardinalityKeyValues(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyValues getHighCardinalityKeyValues(Observation.Context context) {
/* 61 */     return ObservationConvention.EMPTY.getHighCardinalityKeyValues(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\NoopObservationConvention.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */