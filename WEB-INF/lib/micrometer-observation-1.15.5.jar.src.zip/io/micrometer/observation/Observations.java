/*     */ package io.micrometer.observation;
/*     */ 
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Observations
/*     */ {
/*  33 */   private static final ObservationRegistry initialRegistry = ObservationRegistry.create();
/*     */   
/*  35 */   private static final DelegatingObservationRegistry globalRegistry = new DelegatingObservationRegistry(initialRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setRegistry(ObservationRegistry registry) {
/*  46 */     globalRegistry.setDelegate(registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetRegistry() {
/*  53 */     globalRegistry.setDelegate(initialRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ObservationRegistry getGlobalRegistry() {
/*  61 */     return globalRegistry;
/*     */   }
/*     */   
/*     */   private static final class DelegatingObservationRegistry
/*     */     implements ObservationRegistry {
/*  66 */     private final AtomicReference<ObservationRegistry> delegate = new AtomicReference<>(ObservationRegistry.NOOP);
/*     */     
/*     */     DelegatingObservationRegistry(ObservationRegistry delegate) {
/*  69 */       setDelegate(delegate);
/*     */     }
/*     */     
/*     */     void setDelegate(ObservationRegistry delegate) {
/*  73 */       this.delegate.set(Objects.<ObservationRegistry>requireNonNull(delegate, "Delegate must not be null"));
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Observation getCurrentObservation() {
/*  79 */       return ((ObservationRegistry)this.delegate.get()).getCurrentObservation();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Observation.Scope getCurrentObservationScope() {
/*  85 */       return ((ObservationRegistry)this.delegate.get()).getCurrentObservationScope();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setCurrentObservationScope(@Nullable Observation.Scope current) {
/*  90 */       ((ObservationRegistry)this.delegate.get()).setCurrentObservationScope(current);
/*     */     }
/*     */ 
/*     */     
/*     */     public ObservationRegistry.ObservationConfig observationConfig() {
/*  95 */       return ((ObservationRegistry)this.delegate.get()).observationConfig();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNoop() {
/* 100 */       return ((ObservationRegistry)this.delegate.get()).isNoop();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-observation-1.15.5.jar!\io\micrometer\observation\Observations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */