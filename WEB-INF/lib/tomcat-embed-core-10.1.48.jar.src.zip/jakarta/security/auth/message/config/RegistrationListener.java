package jakarta.security.auth.message.config;

public interface RegistrationListener {
  void notify(String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\RegistrationListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */