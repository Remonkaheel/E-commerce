package jakarta.security.auth.message.config;

import jakarta.security.auth.message.AuthException;
import java.util.Map;
import javax.security.auth.Subject;

public interface ServerAuthConfig extends AuthConfig {
  ServerAuthContext getAuthContext(String paramString, Subject paramSubject, Map<String, Object> paramMap) throws AuthException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\ServerAuthConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */