package jakarta.security.auth.message.config;

import jakarta.security.auth.message.AuthException;
import javax.security.auth.callback.CallbackHandler;

public interface AuthConfigProvider {
  ClientAuthConfig getClientAuthConfig(String paramString1, String paramString2, CallbackHandler paramCallbackHandler) throws AuthException;
  
  ServerAuthConfig getServerAuthConfig(String paramString1, String paramString2, CallbackHandler paramCallbackHandler) throws AuthException;
  
  void refresh();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\AuthConfigProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */