package jakarta.security.auth.message.config;

import jakarta.security.auth.message.ClientAuth;

public interface ClientAuthContext extends ClientAuth {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\ClientAuthContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */