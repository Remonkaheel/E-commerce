package jakarta.security.auth.message.config;

import jakarta.security.auth.message.ServerAuth;

public interface ServerAuthContext extends ServerAuth {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\ServerAuthContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */