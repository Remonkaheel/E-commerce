package jakarta.security.auth.message.config;

import jakarta.security.auth.message.MessageInfo;

public interface AuthConfig {
  String getMessageLayer();
  
  String getAppContext();
  
  String getAuthContextID(MessageInfo paramMessageInfo);
  
  void refresh();
  
  boolean isProtected();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\AuthConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */