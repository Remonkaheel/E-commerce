/*     */ package jakarta.security.auth.message.config;
/*     */ 
/*     */ import jakarta.security.auth.message.module.ServerAuthModule;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.Security;
/*     */ import java.security.SecurityPermission;
/*     */ import java.util.Map;
/*     */ import org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AuthConfigFactory
/*     */ {
/*     */   public static final String DEFAULT_FACTORY_SECURITY_PROPERTY = "authconfigprovider.factory";
/*     */   public static final String GET_FACTORY_PERMISSION_NAME = "getProperty.authconfigprovider.factory";
/*     */   public static final String SET_FACTORY_PERMISSION_NAME = "setProperty.authconfigprovider.factory";
/*     */   public static final String PROVIDER_REGISTRATION_PERMISSION_NAME = "setProperty.authconfigfactory.provider";
/*     */   @Deprecated(forRemoval = true)
/*  41 */   public static final SecurityPermission getFactorySecurityPermission = new SecurityPermission("getProperty.authconfigprovider.factory");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*  48 */   public static final SecurityPermission setFactorySecurityPermission = new SecurityPermission("setProperty.authconfigprovider.factory");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*  55 */   public static final SecurityPermission providerRegistrationSecurityPermission = new SecurityPermission("setProperty.authconfigfactory.provider");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_JASPI_AUTHCONFIGFACTORYIMPL = "org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl";
/*     */ 
/*     */   
/*     */   private static volatile AuthConfigFactory factory;
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthConfigFactory getFactory() {
/*  67 */     checkPermission(getFactorySecurityPermission);
/*  68 */     if (factory != null) {
/*  69 */       return factory;
/*     */     }
/*     */     
/*  72 */     synchronized (AuthConfigFactory.class) {
/*  73 */       if (factory == null) {
/*  74 */         String className = getFactoryClassName();
/*     */         try {
/*  76 */           factory = AccessController.<AuthConfigFactory>doPrivileged(() -> {
/*     */                 if (className.equals("org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl")) {
/*     */                   return (AuthConfigFactory)new AuthConfigFactoryImpl();
/*     */                 }
/*     */ 
/*     */ 
/*     */                 
/*     */                 Class<?> clazz = Class.forName(className);
/*     */ 
/*     */                 
/*     */                 return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */               });
/*  88 */         } catch (PrivilegedActionException e) {
/*  89 */           Exception inner = e.getException();
/*  90 */           if (inner instanceof InstantiationException) {
/*  91 */             throw new SecurityException("AuthConfigFactory error:" + inner.getCause().getMessage(), inner
/*  92 */                 .getCause());
/*     */           }
/*  94 */           throw new SecurityException("AuthConfigFactory error: " + String.valueOf(inner), inner);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return factory;
/*     */   }
/*     */   
/*     */   public static synchronized void setFactory(AuthConfigFactory factory) {
/* 104 */     checkPermission(setFactorySecurityPermission);
/* 105 */     AuthConfigFactory.factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   private static void checkPermission(Permission permission) {
/* 156 */     SecurityManager securityManager = System.getSecurityManager();
/* 157 */     if (securityManager != null) {
/* 158 */       securityManager.checkPermission(permission);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getFactoryClassName() {
/* 164 */     String className = AccessController.<String>doPrivileged(() -> Security.getProperty("authconfigprovider.factory"));
/*     */     
/* 166 */     if (className != null) {
/* 167 */       return className;
/*     */     }
/*     */     
/* 170 */     return "org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl";
/*     */   }
/*     */   
/*     */   public abstract AuthConfigProvider getConfigProvider(String paramString1, String paramString2, RegistrationListener paramRegistrationListener);
/*     */   
/*     */   public abstract String registerConfigProvider(String paramString1, Map<String, String> paramMap, String paramString2, String paramString3, String paramString4);
/*     */   
/*     */   public abstract String registerConfigProvider(AuthConfigProvider paramAuthConfigProvider, String paramString1, String paramString2, String paramString3);
/*     */   
/*     */   public abstract boolean removeRegistration(String paramString);
/*     */   
/*     */   public abstract String[] detachListener(RegistrationListener paramRegistrationListener, String paramString1, String paramString2);
/*     */   
/*     */   public abstract String[] getRegistrationIDs(AuthConfigProvider paramAuthConfigProvider);
/*     */   
/*     */   public abstract RegistrationContext getRegistrationContext(String paramString);
/*     */   
/*     */   public abstract void refresh();
/*     */   
/*     */   public abstract String registerServerAuthModule(ServerAuthModule paramServerAuthModule, Object paramObject);
/*     */   
/*     */   public abstract void removeServerAuthModule(Object paramObject);
/*     */   
/*     */   public static interface RegistrationContext {
/*     */     String getMessageLayer();
/*     */     
/*     */     String getAppContext();
/*     */     
/*     */     String getDescription();
/*     */     
/*     */     boolean isPersistent();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\config\AuthConfigFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */