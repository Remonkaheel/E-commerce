package jakarta.security.auth.message.module;

import jakarta.security.auth.message.AuthException;
import jakarta.security.auth.message.ClientAuth;
import jakarta.security.auth.message.MessagePolicy;
import java.util.Map;
import javax.security.auth.callback.CallbackHandler;

public interface ClientAuthModule extends ClientAuth {
  void initialize(MessagePolicy paramMessagePolicy1, MessagePolicy paramMessagePolicy2, CallbackHandler paramCallbackHandler, Map<String, Object> paramMap) throws AuthException;
  
  Class<?>[] getSupportedMessageTypes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\module\ClientAuthModule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */