package jakarta.security.auth.message;

import java.util.Map;

public interface MessageInfo {
  Object getRequestMessage();
  
  Object getResponseMessage();
  
  void setRequestMessage(Object paramObject);
  
  void setResponseMessage(Object paramObject);
  
  Map<String, Object> getMap();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\MessageInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */