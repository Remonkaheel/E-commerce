/*    */ package jakarta.security.auth.message.callback;
/*    */ 
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.security.auth.callback.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecretKeyCallback
/*    */   implements Callback
/*    */ {
/*    */   private final Request request;
/*    */   private SecretKey key;
/*    */   
/*    */   public SecretKeyCallback(Request request) {
/* 32 */     this.request = request;
/*    */   }
/*    */   
/*    */   public Request getRequest() {
/* 36 */     return this.request;
/*    */   }
/*    */   
/*    */   public void setKey(SecretKey key) {
/* 40 */     this.key = key;
/*    */   }
/*    */   
/*    */   public SecretKey getKey() {
/* 44 */     return this.key;
/*    */   }
/*    */   
/*    */   public static interface Request {}
/*    */   
/*    */   public static class AliasRequest
/*    */     implements Request
/*    */   {
/*    */     private final String alias;
/*    */     
/*    */     public AliasRequest(String alias) {
/* 55 */       this.alias = alias;
/*    */     }
/*    */     
/*    */     public String getAlias() {
/* 59 */       return this.alias;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\callback\SecretKeyCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */