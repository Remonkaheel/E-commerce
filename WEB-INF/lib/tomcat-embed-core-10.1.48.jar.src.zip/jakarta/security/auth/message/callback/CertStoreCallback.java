/*    */ package jakarta.security.auth.message.callback;
/*    */ 
/*    */ import java.security.cert.CertStore;
/*    */ import javax.security.auth.callback.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertStoreCallback
/*    */   implements Callback
/*    */ {
/*    */   private CertStore certStore;
/*    */   
/*    */   public void setCertStore(CertStore certStore) {
/* 34 */     this.certStore = certStore;
/*    */   }
/*    */   
/*    */   public CertStore getCertStore() {
/* 38 */     return this.certStore;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\callback\CertStoreCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */