/*     */ package jakarta.security.auth.message.callback;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.Certificate;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrivateKeyCallback
/*     */   implements Callback
/*     */ {
/*     */   private final Request request;
/*     */   private Certificate[] chain;
/*     */   private PrivateKey key;
/*     */   
/*     */   public PrivateKeyCallback(Request request) {
/*  38 */     this.request = request;
/*     */   }
/*     */   
/*     */   public Request getRequest() {
/*  42 */     return this.request;
/*     */   }
/*     */   
/*     */   public void setKey(PrivateKey key, Certificate[] chain) {
/*  46 */     this.key = key;
/*  47 */     this.chain = chain;
/*     */   }
/*     */   
/*     */   public PrivateKey getKey() {
/*  51 */     return this.key;
/*     */   }
/*     */   
/*     */   public Certificate[] getChain() {
/*  55 */     return this.chain;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class AliasRequest
/*     */     implements Request
/*     */   {
/*     */     private final String alias;
/*     */ 
/*     */     
/*     */     public AliasRequest(String alias) {
/*  66 */       this.alias = alias;
/*     */     }
/*     */     
/*     */     public String getAlias() {
/*  70 */       return this.alias;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DigestRequest implements Request {
/*     */     private final byte[] digest;
/*     */     private final String algorithm;
/*     */     
/*     */     public DigestRequest(byte[] digest, String algorithm) {
/*  79 */       this.digest = digest;
/*  80 */       this.algorithm = algorithm;
/*     */     }
/*     */     
/*     */     public byte[] getDigest() {
/*  84 */       return this.digest;
/*     */     }
/*     */     
/*     */     public String getAlgorithm() {
/*  88 */       return this.algorithm;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SubjectKeyIDRequest
/*     */     implements Request {
/*     */     private final byte[] subjectKeyID;
/*     */     
/*     */     public SubjectKeyIDRequest(byte[] subjectKeyID) {
/*  97 */       this.subjectKeyID = subjectKeyID;
/*     */     }
/*     */     
/*     */     public byte[] getSubjectKeyID() {
/* 101 */       return this.subjectKeyID;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class IssuerSerialNumRequest implements Request {
/*     */     private final X500Principal issuer;
/*     */     private final BigInteger serialNum;
/*     */     
/*     */     public IssuerSerialNumRequest(X500Principal issuer, BigInteger serialNum) {
/* 110 */       this.issuer = issuer;
/* 111 */       this.serialNum = serialNum;
/*     */     }
/*     */     
/*     */     public X500Principal getIssuer() {
/* 115 */       return this.issuer;
/*     */     }
/*     */     
/*     */     public BigInteger getSerialNum() {
/* 119 */       return this.serialNum;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Request {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\callback\PrivateKeyCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */