/*    */ package jakarta.security.auth.message.callback;
/*    */ 
/*    */ import javax.security.auth.Subject;
/*    */ import javax.security.auth.callback.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupPrincipalCallback
/*    */   implements Callback
/*    */ {
/*    */   private final Subject subject;
/*    */   private final String[] groups;
/*    */   
/*    */   public GroupPrincipalCallback(Subject subject, String[] groups) {
/* 31 */     this.subject = subject;
/* 32 */     this.groups = groups;
/*    */   }
/*    */   
/*    */   public Subject getSubject() {
/* 36 */     return this.subject;
/*    */   }
/*    */   
/*    */   public String[] getGroups() {
/* 40 */     return this.groups;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\callback\GroupPrincipalCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */