/*    */ package jakarta.security.auth.message.callback;
/*    */ 
/*    */ import java.security.KeyStore;
/*    */ import javax.security.auth.callback.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrustStoreCallback
/*    */   implements Callback
/*    */ {
/*    */   private KeyStore trustStore;
/*    */   
/*    */   public void setTrustStore(KeyStore trustStore) {
/* 31 */     this.trustStore = trustStore;
/*    */   }
/*    */   
/*    */   public KeyStore getTrustStore() {
/* 35 */     return this.trustStore;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\callback\TrustStoreCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */