/*    */ package jakarta.security.auth.message;
/*    */ 
/*    */ import javax.security.auth.Subject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ServerAuth
/*    */ {
/*    */   AuthStatus validateRequest(MessageInfo paramMessageInfo, Subject paramSubject1, Subject paramSubject2) throws AuthException;
/*    */   
/*    */   default AuthStatus secureResponse(MessageInfo messageInfo, Subject serviceSubject) throws AuthException {
/* 50 */     return AuthStatus.SUCCESS;
/*    */   }
/*    */   
/*    */   default void cleanSubject(MessageInfo messageInfo, Subject subject) throws AuthException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\ServerAuth.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */