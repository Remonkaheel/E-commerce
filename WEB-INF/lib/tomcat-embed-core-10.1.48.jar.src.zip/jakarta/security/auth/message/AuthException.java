/*    */ package jakarta.security.auth.message;
/*    */ 
/*    */ import javax.security.auth.login.LoginException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthException
/*    */   extends LoginException
/*    */ {
/*    */   private static final long serialVersionUID = -1156951780670243758L;
/*    */   
/*    */   public AuthException() {}
/*    */   
/*    */   public AuthException(String msg) {
/* 28 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthException(String msg, Throwable cause) {
/* 40 */     super(msg);
/* 41 */     initCause(cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthException(Throwable cause) {
/* 52 */     initCause(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\security\auth\message\AuthException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */