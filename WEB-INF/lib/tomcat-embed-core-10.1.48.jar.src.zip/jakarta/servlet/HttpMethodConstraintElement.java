/*    */ package jakarta.servlet;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpMethodConstraintElement
/*    */   extends HttpConstraintElement
/*    */ {
/*    */   private static final String LSTRING_FILE = "jakarta.servlet.LocalStrings";
/* 30 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.LocalStrings");
/*    */ 
/*    */ 
/*    */   
/*    */   private final String methodName;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpMethodConstraintElement(String methodName) {
/* 40 */     if (methodName == null || methodName.length() == 0) {
/* 41 */       throw new IllegalArgumentException(lStrings.getString("httpMethodConstraintElement.invalidMethod"));
/*    */     }
/* 43 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpMethodConstraintElement(String methodName, HttpConstraintElement constraint) {
/* 53 */     super(constraint.getEmptyRoleSemantic(), constraint.getTransportGuarantee(), constraint.getRolesAllowed());
/* 54 */     if (methodName == null || methodName.length() == 0) {
/* 55 */       throw new IllegalArgumentException(lStrings.getString("httpMethodConstraintElement.invalidMethod"));
/*    */     }
/* 57 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMethodName() {
/* 66 */     return this.methodName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\HttpMethodConstraintElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */