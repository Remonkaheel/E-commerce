package jakarta.servlet;

public interface ServletConnection {
  String getConnectionId();
  
  String getProtocol();
  
  String getProtocolConnectionId();
  
  boolean isSecure();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */