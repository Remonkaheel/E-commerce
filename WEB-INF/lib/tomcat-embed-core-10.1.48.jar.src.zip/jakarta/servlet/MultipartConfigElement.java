/*     */ package jakarta.servlet;
/*     */ 
/*     */ import jakarta.servlet.annotation.MultipartConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartConfigElement
/*     */ {
/*     */   private final String location;
/*     */   private final long maxFileSize;
/*     */   private final long maxRequestSize;
/*     */   private final int fileSizeThreshold;
/*     */   
/*     */   public MultipartConfigElement(String location) {
/*  42 */     if (location != null) {
/*  43 */       this.location = location;
/*     */     } else {
/*  45 */       this.location = "";
/*     */     } 
/*  47 */     this.maxFileSize = -1L;
/*  48 */     this.maxRequestSize = -1L;
/*  49 */     this.fileSizeThreshold = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartConfigElement(String location, long maxFileSize, long maxRequestSize, int fileSizeThreshold) {
/*  63 */     if (location != null) {
/*  64 */       this.location = location;
/*     */     } else {
/*  66 */       this.location = "";
/*     */     } 
/*  68 */     this.maxFileSize = maxFileSize;
/*  69 */     this.maxRequestSize = maxRequestSize;
/*     */ 
/*     */     
/*  72 */     if (fileSizeThreshold > 0) {
/*  73 */       this.fileSizeThreshold = fileSizeThreshold;
/*     */     } else {
/*  75 */       this.fileSizeThreshold = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartConfigElement(MultipartConfig annotation) {
/*  85 */     this.location = annotation.location();
/*  86 */     this.maxFileSize = annotation.maxFileSize();
/*  87 */     this.maxRequestSize = annotation.maxRequestSize();
/*  88 */     this.fileSizeThreshold = annotation.fileSizeThreshold();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/*  97 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxFileSize() {
/* 106 */     return this.maxFileSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxRequestSize() {
/* 115 */     return this.maxRequestSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileSizeThreshold() {
/* 124 */     return this.fileSizeThreshold;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\MultipartConfigElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */