package jakarta.servlet;

import java.util.Map;

public interface SessionCookieConfig {
  void setName(String paramString);
  
  String getName();
  
  void setDomain(String paramString);
  
  String getDomain();
  
  void setPath(String paramString);
  
  String getPath();
  
  @Deprecated(since = "Servlet 6.0", forRemoval = true)
  void setComment(String paramString);
  
  @Deprecated(since = "Servlet 6.0", forRemoval = true)
  String getComment();
  
  void setHttpOnly(boolean paramBoolean);
  
  boolean isHttpOnly();
  
  void setSecure(boolean paramBoolean);
  
  boolean isSecure();
  
  void setMaxAge(int paramInt);
  
  int getMaxAge();
  
  void setAttribute(String paramString1, String paramString2);
  
  String getAttribute(String paramString);
  
  Map<String, String> getAttributes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\SessionCookieConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */