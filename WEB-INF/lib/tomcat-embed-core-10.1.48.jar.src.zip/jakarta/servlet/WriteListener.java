package jakarta.servlet;

import java.io.IOException;
import java.util.EventListener;

public interface WriteListener extends EventListener {
  void onWritePossible() throws IOException;
  
  void onError(Throwable paramThrowable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\WriteListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */