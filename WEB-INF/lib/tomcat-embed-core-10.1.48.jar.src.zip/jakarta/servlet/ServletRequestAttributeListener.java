package jakarta.servlet;

import java.util.EventListener;

public interface ServletRequestAttributeListener extends EventListener {
  default void attributeAdded(ServletRequestAttributeEvent srae) {}
  
  default void attributeRemoved(ServletRequestAttributeEvent srae) {}
  
  default void attributeReplaced(ServletRequestAttributeEvent srae) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletRequestAttributeListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */