package jakarta.servlet;

import java.util.Set;

public interface ServletContainerInitializer {
  void onStartup(Set<Class<?>> paramSet, ServletContext paramServletContext) throws ServletException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletContainerInitializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */