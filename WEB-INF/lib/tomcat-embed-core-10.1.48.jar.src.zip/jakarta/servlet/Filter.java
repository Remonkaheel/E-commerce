package jakarta.servlet;

import java.io.IOException;

public interface Filter {
  default void init(FilterConfig filterConfig) throws ServletException {}
  
  void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException;
  
  default void destroy() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\Filter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */