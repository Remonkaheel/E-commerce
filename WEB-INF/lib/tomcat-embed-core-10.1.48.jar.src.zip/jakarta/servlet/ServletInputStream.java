/*    */ package jakarta.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServletInputStream
/*    */   extends InputStream
/*    */ {
/*    */   public int readLine(byte[] b, int off, int len) throws IOException {
/* 59 */     if (len <= 0) {
/* 60 */       return 0;
/*    */     }
/* 62 */     int count = 0;
/*    */     int c;
/* 64 */     while ((c = read()) != -1) {
/* 65 */       b[off++] = (byte)c;
/* 66 */       count++;
/* 67 */       if (c == 10 || count == len) {
/*    */         break;
/*    */       }
/*    */     } 
/* 71 */     return (count > 0) ? count : -1;
/*    */   }
/*    */   
/*    */   public abstract boolean isFinished();
/*    */   
/*    */   public abstract boolean isReady();
/*    */   
/*    */   public abstract void setReadListener(ReadListener paramReadListener);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */