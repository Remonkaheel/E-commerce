package jakarta.servlet;

import java.io.IOException;

public interface Servlet {
  void init(ServletConfig paramServletConfig) throws ServletException;
  
  ServletConfig getServletConfig();
  
  void service(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException;
  
  String getServletInfo();
  
  void destroy();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\Servlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */