package jakarta.servlet.http;

import jakarta.servlet.ServletContext;
import java.util.Enumeration;

public interface HttpSession {
  long getCreationTime();
  
  String getId();
  
  long getLastAccessedTime();
  
  ServletContext getServletContext();
  
  void setMaxInactiveInterval(int paramInt);
  
  int getMaxInactiveInterval();
  
  Object getAttribute(String paramString);
  
  Enumeration<String> getAttributeNames();
  
  void setAttribute(String paramString, Object paramObject);
  
  void removeAttribute(String paramString);
  
  void invalidate();
  
  boolean isNew();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpSession.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */