package jakarta.servlet.http;

import jakarta.servlet.ServletInputStream;
import jakarta.servlet.ServletOutputStream;
import java.io.IOException;

public interface WebConnection extends AutoCloseable {
  ServletInputStream getInputStream() throws IOException;
  
  ServletOutputStream getOutputStream() throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\WebConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */