/*      */ package jakarta.servlet.http;
/*      */ 
/*      */ import jakarta.servlet.AsyncEvent;
/*      */ import jakarta.servlet.AsyncListener;
/*      */ import jakarta.servlet.DispatcherType;
/*      */ import jakarta.servlet.GenericServlet;
/*      */ import jakarta.servlet.ServletConfig;
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.ServletOutputStream;
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import jakarta.servlet.ServletResponse;
/*      */ import jakarta.servlet.WriteListener;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Method;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.ResourceBundle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class HttpServlet
/*      */   extends GenericServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static final String METHOD_DELETE = "DELETE";
/*      */   private static final String METHOD_HEAD = "HEAD";
/*      */   private static final String METHOD_GET = "GET";
/*      */   private static final String METHOD_OPTIONS = "OPTIONS";
/*      */   private static final String METHOD_POST = "POST";
/*      */   private static final String METHOD_PUT = "PUT";
/*      */   private static final String METHOD_TRACE = "TRACE";
/*      */   private static final String HEADER_IFMODSINCE = "If-Modified-Since";
/*      */   private static final String HEADER_LASTMOD = "Last-Modified";
/*      */   private static final String LSTRING_FILE = "jakarta.servlet.http.LocalStrings";
/*   85 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.http.LocalStrings");
/*      */ 
/*      */   
/*   88 */   private static final List<String> SENSITIVE_HTTP_HEADERS = Arrays.asList(new String[] { "authorization", "cookie", "x-forwarded", "forwarded", "proxy-authorization" });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(forRemoval = true, since = "Servlet 6.0")
/*      */   public static final String LEGACY_DO_HEAD = "jakarta.servlet.http.legacyDoHead";
/*      */ 
/*      */ 
/*      */   
/*   98 */   private final transient Object cachedAllowHeaderValueLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   private volatile String cachedAllowHeaderValue = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile boolean cachedUseLegacyDoHead;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(ServletConfig config) throws ServletException {
/*  121 */     super.init(config);
/*  122 */     this.cachedUseLegacyDoHead = Boolean.parseBoolean(config.getInitParameter("jakarta.servlet.http.legacyDoHead"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  167 */     String msg = lStrings.getString("http.method_get_not_supported");
/*  168 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long getLastModified(HttpServletRequest req) {
/*  186 */     return -1L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  210 */     if (DispatcherType.INCLUDE.equals(req.getDispatcherType()) || !this.cachedUseLegacyDoHead) {
/*  211 */       doGet(req, resp);
/*      */     } else {
/*  213 */       NoBodyResponse response = new NoBodyResponse(resp);
/*  214 */       doGet(req, response);
/*  215 */       if (req.isAsyncStarted()) {
/*  216 */         req.getAsyncContext().addListener(new NoBodyAsyncContextListener(response));
/*      */       } else {
/*  218 */         response.setContentLength();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  261 */     String msg = lStrings.getString("http.method_post_not_supported");
/*  262 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  290 */     String msg = lStrings.getString("http.method_put_not_supported");
/*  291 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  313 */     String msg = lStrings.getString("http.method_delete_not_supported");
/*  314 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */ 
/*      */   
/*      */   private void sendMethodNotAllowed(HttpServletRequest req, HttpServletResponse resp, String msg) throws IOException {
/*  319 */     String protocol = req.getProtocol();
/*      */ 
/*      */     
/*  322 */     if (protocol.length() == 0 || protocol.endsWith("0.9") || protocol.endsWith("1.0")) {
/*  323 */       resp.sendError(400, msg);
/*      */     } else {
/*  325 */       resp.sendError(405, msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private String getCachedAllowHeaderValue() {
/*  331 */     if (this.cachedAllowHeaderValue == null) {
/*  332 */       synchronized (this.cachedAllowHeaderValueLock) {
/*  333 */         if (this.cachedAllowHeaderValue == null) {
/*      */           
/*  335 */           Method[] methods = getAllDeclaredMethods(getClass());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  343 */           boolean allowGet = false;
/*  344 */           boolean allowHead = false;
/*  345 */           boolean allowPost = false;
/*  346 */           boolean allowPut = false;
/*  347 */           boolean allowDelete = false;
/*      */           
/*  349 */           for (Method method : methods) {
/*  350 */             switch (method.getName()) {
/*      */               case "doGet":
/*  352 */                 allowGet = true;
/*  353 */                 allowHead = true;
/*      */                 break;
/*      */               
/*      */               case "doPost":
/*  357 */                 allowPost = true;
/*      */                 break;
/*      */               
/*      */               case "doPut":
/*  361 */                 allowPut = true;
/*      */                 break;
/*      */               
/*      */               case "doDelete":
/*  365 */                 allowDelete = true;
/*      */                 break;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           } 
/*  374 */           StringBuilder allow = new StringBuilder();
/*      */           
/*  376 */           if (allowGet) {
/*  377 */             allow.append("GET");
/*  378 */             allow.append(", ");
/*      */           } 
/*      */           
/*  381 */           if (allowHead) {
/*  382 */             allow.append("HEAD");
/*  383 */             allow.append(", ");
/*      */           } 
/*      */           
/*  386 */           if (allowPost) {
/*  387 */             allow.append("POST");
/*  388 */             allow.append(", ");
/*      */           } 
/*      */           
/*  391 */           if (allowPut) {
/*  392 */             allow.append("PUT");
/*  393 */             allow.append(", ");
/*      */           } 
/*      */           
/*  396 */           if (allowDelete) {
/*  397 */             allow.append("DELETE");
/*  398 */             allow.append(", ");
/*      */           } 
/*      */ 
/*      */           
/*  402 */           allow.append("OPTIONS");
/*      */           
/*  404 */           this.cachedAllowHeaderValue = allow.toString();
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  409 */     return this.cachedAllowHeaderValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Method[] getAllDeclaredMethods(Class<?> c) {
/*  415 */     if (c.equals(HttpServlet.class)) {
/*  416 */       return null;
/*      */     }
/*      */     
/*  419 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/*  420 */     Method[] thisMethods = c.getDeclaredMethods();
/*      */     
/*  422 */     if (parentMethods != null && parentMethods.length > 0) {
/*  423 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*  424 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/*  425 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*  426 */       thisMethods = allMethods;
/*      */     } 
/*      */     
/*  429 */     return thisMethods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  451 */     String allow = getCachedAllowHeaderValue();
/*      */ 
/*      */     
/*  454 */     if (TomcatHack.getAllowTrace(req)) {
/*  455 */       if (allow.length() == 0) {
/*  456 */         allow = "TRACE";
/*      */       } else {
/*  458 */         allow = allow + ", TRACE";
/*      */       } 
/*      */     }
/*      */     
/*  462 */     resp.setHeader("Allow", allow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  481 */     String CRLF = "\r\n";
/*      */     
/*  483 */     StringBuilder buffer = (new StringBuilder("TRACE ")).append(req.getRequestURI()).append(' ').append(req.getProtocol());
/*      */     
/*  485 */     Enumeration<String> reqHeaderNames = req.getHeaderNames();
/*      */     
/*  487 */     while (reqHeaderNames.hasMoreElements()) {
/*  488 */       String headerName = reqHeaderNames.nextElement();
/*      */       
/*  490 */       if (!isSensitiveHeader(headerName)) {
/*  491 */         Enumeration<String> headerValues = req.getHeaders(headerName);
/*  492 */         while (headerValues.hasMoreElements()) {
/*  493 */           String headerValue = headerValues.nextElement();
/*  494 */           buffer.append(CRLF).append(headerName).append(": ").append(headerValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  499 */     buffer.append(CRLF);
/*      */     
/*  501 */     int responseLength = buffer.length();
/*      */     
/*  503 */     resp.setContentType("message/http");
/*  504 */     resp.setContentLength(responseLength);
/*  505 */     ServletOutputStream out = resp.getOutputStream();
/*  506 */     out.print(buffer.toString());
/*  507 */     out.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isSensitiveHeader(String headerName) {
/*  532 */     String lcHeaderName = headerName.toLowerCase(Locale.ENGLISH);
/*  533 */     for (String sensitiveHeaderName : SENSITIVE_HTTP_HEADERS) {
/*  534 */       if (lcHeaderName.startsWith(sensitiveHeaderName)) {
/*  535 */         return true;
/*      */       }
/*      */     } 
/*  538 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/*  557 */     String method = req.getMethod();
/*      */     
/*  559 */     if (method.equals("GET")) {
/*  560 */       long lastModified = getLastModified(req);
/*  561 */       if (lastModified == -1L) {
/*      */ 
/*      */         
/*  564 */         doGet(req, resp);
/*      */       } else {
/*      */         long ifModifiedSince;
/*      */         try {
/*  568 */           ifModifiedSince = req.getDateHeader("If-Modified-Since");
/*  569 */         } catch (IllegalArgumentException iae) {
/*      */           
/*  571 */           ifModifiedSince = -1L;
/*      */         } 
/*  573 */         if (ifModifiedSince < lastModified / 1000L * 1000L) {
/*      */ 
/*      */ 
/*      */           
/*  577 */           maybeSetLastModified(resp, lastModified);
/*  578 */           doGet(req, resp);
/*      */         } else {
/*  580 */           resp.setStatus(304);
/*      */         }
/*      */       
/*      */       } 
/*  584 */     } else if (method.equals("HEAD")) {
/*  585 */       long lastModified = getLastModified(req);
/*  586 */       maybeSetLastModified(resp, lastModified);
/*  587 */       doHead(req, resp);
/*      */     }
/*  589 */     else if (method.equals("POST")) {
/*  590 */       doPost(req, resp);
/*      */     }
/*  592 */     else if (method.equals("PUT")) {
/*  593 */       doPut(req, resp);
/*      */     }
/*  595 */     else if (method.equals("DELETE")) {
/*  596 */       doDelete(req, resp);
/*      */     }
/*  598 */     else if (method.equals("OPTIONS")) {
/*  599 */       doOptions(req, resp);
/*      */     }
/*  601 */     else if (method.equals("TRACE")) {
/*  602 */       doTrace(req, resp);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  610 */       String errMsg = lStrings.getString("http.method_not_implemented");
/*  611 */       Object[] errArgs = new Object[1];
/*  612 */       errArgs[0] = method;
/*  613 */       errMsg = MessageFormat.format(errMsg, errArgs);
/*      */       
/*  615 */       resp.sendError(501, errMsg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
/*  626 */     if (resp.containsHeader("Last-Modified")) {
/*      */       return;
/*      */     }
/*  629 */     if (lastModified >= 0L) {
/*  630 */       resp.setDateHeader("Last-Modified", lastModified);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
/*      */     HttpServletRequest request;
/*      */     HttpServletResponse response;
/*      */     try {
/*  653 */       request = (HttpServletRequest)req;
/*  654 */       response = (HttpServletResponse)res;
/*  655 */     } catch (ClassCastException e) {
/*  656 */       throw new ServletException(lStrings.getString("http.non_http"));
/*      */     } 
/*  658 */     service(request, response);
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TomcatHack
/*      */   {
/*      */     private static final Class<?> REQUEST_FACADE_CLAZZ;
/*      */     
/*      */     private static final Method GET_ALLOW_TRACE;
/*      */     
/*      */     static {
/*  669 */       Method m1 = null;
/*  670 */       Class<?> c1 = null;
/*      */       try {
/*  672 */         c1 = Class.forName("org.apache.catalina.connector.RequestFacade");
/*  673 */         m1 = c1.getMethod("getAllowTrace", (Class[])null);
/*  674 */       } catch (ReflectiveOperationException|SecurityException|IllegalArgumentException reflectiveOperationException) {}
/*      */ 
/*      */       
/*  677 */       REQUEST_FACADE_CLAZZ = c1;
/*  678 */       GET_ALLOW_TRACE = m1;
/*      */     }
/*      */     
/*      */     public static boolean getAllowTrace(HttpServletRequest req) {
/*  682 */       if (REQUEST_FACADE_CLAZZ != null && GET_ALLOW_TRACE != null && 
/*  683 */         REQUEST_FACADE_CLAZZ.isAssignableFrom(req.getClass())) {
/*      */         try {
/*  685 */           return ((Boolean)GET_ALLOW_TRACE.invoke(req, (Object[])null)).booleanValue();
/*  686 */         } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  691 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class NoBodyResponse
/*      */     extends HttpServletResponseWrapper
/*      */   {
/*      */     private final HttpServlet.NoBodyOutputStream noBodyOutputStream;
/*      */     
/*      */     private ServletOutputStream originalOutputStream;
/*      */     
/*      */     private HttpServlet.NoBodyPrintWriter noBodyWriter;
/*      */     private boolean didSetContentLength;
/*      */     
/*      */     private NoBodyResponse(HttpServletResponse r) {
/*  707 */       super(r);
/*  708 */       this.noBodyOutputStream = new HttpServlet.NoBodyOutputStream(this);
/*      */     }
/*      */     
/*      */     private void setContentLength() {
/*  712 */       if (!this.didSetContentLength) {
/*  713 */         if (this.noBodyWriter != null) {
/*  714 */           this.noBodyWriter.flush();
/*      */         }
/*  716 */         super.setContentLengthLong(this.noBodyOutputStream.getWrittenByteCount());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setContentLength(int len) {
/*  723 */       super.setContentLength(len);
/*  724 */       this.didSetContentLength = true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setContentLengthLong(long len) {
/*  729 */       super.setContentLengthLong(len);
/*  730 */       this.didSetContentLength = true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setHeader(String name, String value) {
/*  735 */       super.setHeader(name, value);
/*  736 */       checkHeader(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void addHeader(String name, String value) {
/*  741 */       super.addHeader(name, value);
/*  742 */       checkHeader(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setIntHeader(String name, int value) {
/*  747 */       super.setIntHeader(name, value);
/*  748 */       checkHeader(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void addIntHeader(String name, int value) {
/*  753 */       super.addIntHeader(name, value);
/*  754 */       checkHeader(name);
/*      */     }
/*      */     
/*      */     private void checkHeader(String name) {
/*  758 */       if ("content-length".equalsIgnoreCase(name)) {
/*  759 */         this.didSetContentLength = true;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public ServletOutputStream getOutputStream() throws IOException {
/*  765 */       this.originalOutputStream = getResponse().getOutputStream();
/*  766 */       return this.noBodyOutputStream;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public PrintWriter getWriter() throws UnsupportedEncodingException {
/*  772 */       if (this.noBodyWriter == null) {
/*  773 */         this.noBodyWriter = new HttpServlet.NoBodyPrintWriter(this.noBodyOutputStream, getCharacterEncoding());
/*      */       }
/*  775 */       return this.noBodyWriter;
/*      */     }
/*      */ 
/*      */     
/*      */     public void reset() {
/*  780 */       super.reset();
/*  781 */       resetBuffer();
/*  782 */       this.originalOutputStream = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void resetBuffer() {
/*  787 */       this.noBodyOutputStream.resetBuffer();
/*  788 */       if (this.noBodyWriter != null) {
/*  789 */         this.noBodyWriter.resetBuffer();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NoBodyOutputStream
/*      */     extends ServletOutputStream
/*      */   {
/*      */     private static final String LSTRING_FILE = "jakarta.servlet.http.LocalStrings";
/*      */     
/*  801 */     private static final ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.http.LocalStrings");
/*      */     
/*      */     private final HttpServlet.NoBodyResponse response;
/*      */     private boolean flushed = false;
/*  805 */     private long writtenByteCount = 0L;
/*      */     
/*      */     private NoBodyOutputStream(HttpServlet.NoBodyResponse response) {
/*  808 */       this.response = response;
/*      */     }
/*      */     
/*      */     private long getWrittenByteCount() {
/*  812 */       return this.writtenByteCount;
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(int b) throws IOException {
/*  817 */       this.writtenByteCount++;
/*  818 */       checkCommit();
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(byte[] buf, int offset, int len) throws IOException {
/*  823 */       if (buf == null) {
/*  824 */         throw new NullPointerException(lStrings.getString("err.io.nullArray"));
/*      */       }
/*      */       
/*  827 */       if (offset < 0 || len < 0 || offset + len > buf.length) {
/*  828 */         String msg = lStrings.getString("err.io.indexOutOfBounds");
/*  829 */         Object[] msgArgs = new Object[3];
/*  830 */         msgArgs[0] = Integer.valueOf(offset);
/*  831 */         msgArgs[1] = Integer.valueOf(len);
/*  832 */         msgArgs[2] = Integer.valueOf(buf.length);
/*  833 */         msg = MessageFormat.format(msg, msgArgs);
/*  834 */         throw new IndexOutOfBoundsException(msg);
/*      */       } 
/*      */       
/*  837 */       this.writtenByteCount += len;
/*  838 */       checkCommit();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isReady() {
/*  844 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWriteListener(WriteListener listener) {
/*  849 */       this.response.originalOutputStream.setWriteListener(listener);
/*      */     }
/*      */     
/*      */     private void checkCommit() throws IOException {
/*  853 */       if (!this.flushed && this.writtenByteCount > this.response.getBufferSize()) {
/*  854 */         this.response.flushBuffer();
/*  855 */         this.flushed = true;
/*      */       } 
/*      */     }
/*      */     
/*      */     private void resetBuffer() {
/*  860 */       if (this.flushed) {
/*  861 */         throw new IllegalStateException(lStrings.getString("err.state.commit"));
/*      */       }
/*  863 */       this.writtenByteCount = 0L;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NoBodyPrintWriter
/*      */     extends PrintWriter
/*      */   {
/*      */     private final HttpServlet.NoBodyOutputStream out;
/*      */     
/*      */     private final String encoding;
/*      */     
/*      */     private PrintWriter pw;
/*      */ 
/*      */     
/*      */     NoBodyPrintWriter(HttpServlet.NoBodyOutputStream out, String encoding) throws UnsupportedEncodingException {
/*  880 */       super((OutputStream)out);
/*  881 */       this.out = out;
/*  882 */       this.encoding = encoding;
/*      */       
/*  884 */       Writer osw = new OutputStreamWriter((OutputStream)out, encoding);
/*  885 */       this.pw = new PrintWriter(osw);
/*      */     }
/*      */     
/*      */     private void resetBuffer() {
/*  889 */       this.out.resetBuffer();
/*      */       
/*  891 */       Writer osw = null;
/*      */       try {
/*  893 */         osw = new OutputStreamWriter((OutputStream)this.out, this.encoding);
/*  894 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  900 */       this.pw = new PrintWriter(osw);
/*      */     }
/*      */ 
/*      */     
/*      */     public void flush() {
/*  905 */       this.pw.flush();
/*      */     }
/*      */ 
/*      */     
/*      */     public void close() {
/*  910 */       this.pw.close();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean checkError() {
/*  915 */       return this.pw.checkError();
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(int c) {
/*  920 */       this.pw.write(c);
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(char[] buf, int off, int len) {
/*  925 */       this.pw.write(buf, off, len);
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(char[] buf) {
/*  930 */       this.pw.write(buf);
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(String s, int off, int len) {
/*  935 */       this.pw.write(s, off, len);
/*      */     }
/*      */ 
/*      */     
/*      */     public void write(String s) {
/*  940 */       this.pw.write(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(boolean b) {
/*  945 */       this.pw.print(b);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(char c) {
/*  950 */       this.pw.print(c);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(int i) {
/*  955 */       this.pw.print(i);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(long l) {
/*  960 */       this.pw.print(l);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(float f) {
/*  965 */       this.pw.print(f);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(double d) {
/*  970 */       this.pw.print(d);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(char[] s) {
/*  975 */       this.pw.print(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(String s) {
/*  980 */       this.pw.print(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public void print(Object obj) {
/*  985 */       this.pw.print(obj);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println() {
/*  990 */       this.pw.println();
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(boolean x) {
/*  995 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(char x) {
/* 1000 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(int x) {
/* 1005 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(long x) {
/* 1010 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(float x) {
/* 1015 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(double x) {
/* 1020 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(char[] x) {
/* 1025 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(String x) {
/* 1030 */       this.pw.println(x);
/*      */     }
/*      */ 
/*      */     
/*      */     public void println(Object x) {
/* 1035 */       this.pw.println(x);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NoBodyAsyncContextListener
/*      */     implements AsyncListener
/*      */   {
/*      */     private final HttpServlet.NoBodyResponse noBodyResponse;
/*      */ 
/*      */     
/*      */     NoBodyAsyncContextListener(HttpServlet.NoBodyResponse noBodyResponse) {
/* 1048 */       this.noBodyResponse = noBodyResponse;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete(AsyncEvent event) throws IOException {
/* 1053 */       this.noBodyResponse.setContentLength();
/*      */     }
/*      */     
/*      */     public void onTimeout(AsyncEvent event) throws IOException {}
/*      */     
/*      */     public void onError(AsyncEvent event) throws IOException {}
/*      */     
/*      */     public void onStartAsync(AsyncEvent event) throws IOException {}
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */