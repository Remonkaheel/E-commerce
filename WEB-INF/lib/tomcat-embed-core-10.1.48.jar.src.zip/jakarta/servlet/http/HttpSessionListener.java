package jakarta.servlet.http;

import java.util.EventListener;

public interface HttpSessionListener extends EventListener {
  default void sessionCreated(HttpSessionEvent se) {}
  
  default void sessionDestroyed(HttpSessionEvent se) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpSessionListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */