package jakarta.servlet.http;

import java.util.EventListener;

public interface HttpSessionActivationListener extends EventListener {
  default void sessionWillPassivate(HttpSessionEvent se) {}
  
  default void sessionDidActivate(HttpSessionEvent se) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpSessionActivationListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */