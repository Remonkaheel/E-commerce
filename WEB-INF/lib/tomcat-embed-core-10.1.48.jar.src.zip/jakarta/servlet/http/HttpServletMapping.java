package jakarta.servlet.http;

public interface HttpServletMapping {
  String getMatchValue();
  
  String getPattern();
  
  String getServletName();
  
  MappingMatch getMappingMatch();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpServletMapping.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */