package jakarta.servlet.http;

import java.util.EventListener;

public interface HttpSessionBindingListener extends EventListener {
  default void valueBound(HttpSessionBindingEvent event) {}
  
  default void valueUnbound(HttpSessionBindingEvent event) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpSessionBindingListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */