/*     */ package jakarta.servlet.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cookie
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final String LSTRING_FILE = "jakarta.servlet.http.LocalStrings";
/*  53 */   private static final ResourceBundle LSTRINGS = ResourceBundle.getBundle("jakarta.servlet.http.LocalStrings");
/*     */   
/*  55 */   private static final CookieNameValidator validation = new RFC6265Validator();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */   
/*     */   private String value;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Map<String, String> attributes;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DOMAIN = "Domain";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String MAX_AGE = "Max-Age";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PATH = "Path";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SECURE = "Secure";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String HTTP_ONLY = "HttpOnly";
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie(String name, String value) {
/*  96 */     validation.validate(name);
/*  97 */     this.name = name;
/*  98 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "Servlet 6.0", forRemoval = true)
/*     */   public void setComment(String purpose) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "Servlet 6.0", forRemoval = true)
/*     */   public String getComment() {
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDomain(String pattern) {
/* 142 */     if (pattern == null) {
/* 143 */       setAttributeInternal("Domain", null);
/*     */     } else {
/*     */       
/* 146 */       setAttributeInternal("Domain", pattern.toLowerCase(Locale.ENGLISH));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDomain() {
/* 159 */     return getAttribute("Domain");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAge(int expiry) {
/* 178 */     setAttributeInternal("Max-Age", Integer.toString(expiry));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxAge() {
/* 192 */     String maxAge = getAttribute("Max-Age");
/* 193 */     if (maxAge == null) {
/* 194 */       return -1;
/*     */     }
/* 196 */     return Integer.parseInt(maxAge);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPath(String uri) {
/* 213 */     setAttributeInternal("Path", uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 226 */     return getAttribute("Path");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecure(boolean flag) {
/* 241 */     setAttributeInternal("Secure", Boolean.toString(flag));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSecure() {
/* 254 */     return Boolean.parseBoolean(getAttribute("Secure"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 264 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String newValue) {
/* 282 */     this.value = newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 295 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "Servlet 6.0", forRemoval = true)
/*     */   public int getVersion() {
/* 310 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "Servlet 6.0", forRemoval = true)
/*     */   public void setVersion(int v) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 335 */       return super.clone();
/* 336 */     } catch (CloneNotSupportedException e) {
/* 337 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpOnly(boolean httpOnly) {
/* 350 */     setAttributeInternal("HttpOnly", Boolean.toString(httpOnly));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHttpOnly() {
/* 362 */     return Boolean.parseBoolean(getAttribute("HttpOnly"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, String value) {
/* 381 */     if (name == null) {
/* 382 */       throw new IllegalArgumentException(LSTRINGS.getString("cookie.attribute.invalidName.null"));
/*     */     }
/* 384 */     if (!validation.isToken(name)) {
/* 385 */       String msg = LSTRINGS.getString("cookie.attribute.invalidName.notToken");
/* 386 */       throw new IllegalArgumentException(MessageFormat.format(msg, new Object[] { name }));
/*     */     } 
/*     */     
/* 389 */     if (name.equalsIgnoreCase("Max-Age")) {
/* 390 */       if (value == null) {
/* 391 */         setAttributeInternal("Max-Age", null);
/*     */       } else {
/*     */         
/* 394 */         setMaxAge(Integer.parseInt(value));
/*     */       } 
/*     */     } else {
/* 397 */       setAttributeInternal(name, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setAttributeInternal(String name, String value) {
/* 403 */     if (this.attributes == null) {
/* 404 */       if (value == null) {
/*     */         return;
/*     */       }
/*     */       
/* 408 */       this.attributes = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */     } 
/*     */ 
/*     */     
/* 412 */     if (value == null) {
/* 413 */       this.attributes.remove(name);
/*     */     } else {
/* 415 */       this.attributes.put(name, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String name) {
/* 431 */     if (this.attributes == null) {
/* 432 */       return null;
/*     */     }
/* 434 */     return this.attributes.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getAttributes() {
/* 447 */     if (this.attributes == null) {
/* 448 */       return Collections.emptyMap();
/*     */     }
/* 450 */     return Collections.unmodifiableMap(this.attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 457 */     int prime = 31;
/* 458 */     int result = 1;
/* 459 */     result = 31 * result + ((this.attributes == null) ? 0 : this.attributes.hashCode());
/* 460 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 461 */     result = 31 * result + ((this.value == null) ? 0 : this.value.hashCode());
/* 462 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 468 */     if (this == obj) {
/* 469 */       return true;
/*     */     }
/* 471 */     if (obj == null) {
/* 472 */       return false;
/*     */     }
/* 474 */     if (getClass() != obj.getClass()) {
/* 475 */       return false;
/*     */     }
/* 477 */     Cookie other = (Cookie)obj;
/* 478 */     if (this.attributes == null) {
/* 479 */       if (other.attributes != null) {
/* 480 */         return false;
/*     */       }
/* 482 */     } else if (!this.attributes.equals(other.attributes)) {
/* 483 */       return false;
/*     */     } 
/* 485 */     if (this.name == null) {
/* 486 */       if (other.name != null) {
/* 487 */         return false;
/*     */       }
/* 489 */     } else if (!this.name.equals(other.name)) {
/* 490 */       return false;
/*     */     } 
/* 492 */     if (this.value == null) {
/* 493 */       if (other.value != null) {
/* 494 */         return false;
/*     */       }
/* 496 */     } else if (!this.value.equals(other.value)) {
/* 497 */       return false;
/*     */     } 
/* 499 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\Cookie.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */