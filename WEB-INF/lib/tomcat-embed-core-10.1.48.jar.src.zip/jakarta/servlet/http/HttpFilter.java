/*    */ package jakarta.servlet.http;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.GenericFilter;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HttpFilter
/*    */   extends GenericFilter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 47 */     if (!(request instanceof HttpServletRequest)) {
/* 48 */       throw new ServletException(String.valueOf(request) + " not HttpServletRequest");
/*    */     }
/* 50 */     if (!(response instanceof HttpServletResponse)) {
/* 51 */       throw new ServletException(String.valueOf(response) + " not HttpServletResponse");
/*    */     }
/* 53 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 85 */     chain.doFilter(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\http\HttpFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */