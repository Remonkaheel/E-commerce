package jakarta.servlet;

import java.util.EventListener;

public interface ServletContextAttributeListener extends EventListener {
  default void attributeAdded(ServletContextAttributeEvent scae) {}
  
  default void attributeRemoved(ServletContextAttributeEvent scae) {}
  
  default void attributeReplaced(ServletContextAttributeEvent scae) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletContextAttributeListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */