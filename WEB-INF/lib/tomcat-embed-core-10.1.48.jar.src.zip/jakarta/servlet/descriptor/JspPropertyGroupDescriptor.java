package jakarta.servlet.descriptor;

import java.util.Collection;

public interface JspPropertyGroupDescriptor {
  Collection<String> getUrlPatterns();
  
  String getElIgnored();
  
  String getErrorOnELNotFound();
  
  String getPageEncoding();
  
  String getScriptingInvalid();
  
  String getIsXml();
  
  Collection<String> getIncludePreludes();
  
  Collection<String> getIncludeCodas();
  
  String getDeferredSyntaxAllowedAsLiteral();
  
  String getTrimDirectiveWhitespaces();
  
  String getDefaultContentType();
  
  String getBuffer();
  
  String getErrorOnUndeclaredNamespace();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\descriptor\JspPropertyGroupDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */