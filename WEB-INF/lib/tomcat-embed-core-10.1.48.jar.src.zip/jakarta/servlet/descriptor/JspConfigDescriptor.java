package jakarta.servlet.descriptor;

import java.util.Collection;

public interface JspConfigDescriptor {
  Collection<TaglibDescriptor> getTaglibs();
  
  Collection<JspPropertyGroupDescriptor> getJspPropertyGroups();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\descriptor\JspConfigDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */