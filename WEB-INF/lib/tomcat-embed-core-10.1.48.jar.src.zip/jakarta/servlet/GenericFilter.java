/*    */ package jakarta.servlet;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GenericFilter
/*    */   implements Filter, FilterConfig, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private volatile FilterConfig filterConfig;
/*    */   
/*    */   public String getInitParameter(String name) {
/* 43 */     return getFilterConfig().getInitParameter(name);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Enumeration<String> getInitParameterNames() {
/* 49 */     return getFilterConfig().getInitParameterNames();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterConfig getFilterConfig() {
/* 59 */     return this.filterConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ServletContext getServletContext() {
/* 65 */     return getFilterConfig().getServletContext();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(FilterConfig filterConfig) throws ServletException {
/* 71 */     this.filterConfig = filterConfig;
/* 72 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() throws ServletException {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getFilterName() {
/* 89 */     return getFilterConfig().getFilterName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\GenericFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */