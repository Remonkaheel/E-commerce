package jakarta.servlet;

import java.util.EventListener;

public interface ServletRequestListener extends EventListener {
  default void requestDestroyed(ServletRequestEvent sre) {}
  
  default void requestInitialized(ServletRequestEvent sre) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletRequestListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */