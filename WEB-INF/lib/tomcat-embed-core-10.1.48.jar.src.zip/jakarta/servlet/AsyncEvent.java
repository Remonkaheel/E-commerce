/*     */ package jakarta.servlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncEvent
/*     */ {
/*     */   private final AsyncContext context;
/*     */   private final ServletRequest request;
/*     */   private final ServletResponse response;
/*     */   private final Throwable throwable;
/*     */   
/*     */   public AsyncEvent(AsyncContext context) {
/*  36 */     this.context = context;
/*  37 */     this.request = null;
/*  38 */     this.response = null;
/*  39 */     this.throwable = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncEvent(AsyncContext context, ServletRequest request, ServletResponse response) {
/*  50 */     this.context = context;
/*  51 */     this.request = request;
/*  52 */     this.response = response;
/*  53 */     this.throwable = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncEvent(AsyncContext context, Throwable throwable) {
/*  63 */     this.context = context;
/*  64 */     this.throwable = throwable;
/*  65 */     this.request = null;
/*  66 */     this.response = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncEvent(AsyncContext context, ServletRequest request, ServletResponse response, Throwable throwable) {
/*  78 */     this.context = context;
/*  79 */     this.request = request;
/*  80 */     this.response = response;
/*  81 */     this.throwable = throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncContext getAsyncContext() {
/*  90 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRequest getSuppliedRequest() {
/*  99 */     return this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletResponse getSuppliedResponse() {
/* 108 */     return this.response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 117 */     return this.throwable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\AsyncEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */