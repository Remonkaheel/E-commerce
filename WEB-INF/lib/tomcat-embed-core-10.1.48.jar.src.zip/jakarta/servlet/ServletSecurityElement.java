/*     */ package jakarta.servlet;
/*     */ 
/*     */ import jakarta.servlet.annotation.HttpMethodConstraint;
/*     */ import jakarta.servlet.annotation.ServletSecurity;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletSecurityElement
/*     */   extends HttpConstraintElement
/*     */ {
/*  37 */   private final Map<String, HttpMethodConstraintElement> methodConstraints = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(HttpConstraintElement httpConstraintElement) {
/*  52 */     this(httpConstraintElement, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(Collection<HttpMethodConstraintElement> httpMethodConstraints) {
/*  64 */     addHttpMethodConstraints(httpMethodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(HttpConstraintElement httpConstraintElement, Collection<HttpMethodConstraintElement> httpMethodConstraints) {
/*  78 */     super(httpConstraintElement.getEmptyRoleSemantic(), httpConstraintElement.getTransportGuarantee(), httpConstraintElement
/*  79 */         .getRolesAllowed());
/*  80 */     addHttpMethodConstraints(httpMethodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(ServletSecurity annotation) {
/*  91 */     this(new HttpConstraintElement(annotation.value().value(), annotation.value().transportGuarantee(), annotation
/*  92 */           .value().rolesAllowed()));
/*     */     
/*  94 */     List<HttpMethodConstraintElement> l = new ArrayList<>();
/*  95 */     HttpMethodConstraint[] constraints = annotation.httpMethodConstraints();
/*  96 */     if (constraints != null) {
/*  97 */       for (HttpMethodConstraint constraint : constraints) {
/*     */ 
/*     */         
/* 100 */         HttpMethodConstraintElement e = new HttpMethodConstraintElement(constraint.value(), new HttpConstraintElement(constraint.emptyRoleSemantic(), constraint.transportGuarantee(), constraint.rolesAllowed()));
/* 101 */         l.add(e);
/*     */       } 
/*     */     }
/* 104 */     addHttpMethodConstraints(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<HttpMethodConstraintElement> getHttpMethodConstraints() {
/* 113 */     Collection<HttpMethodConstraintElement> result = new HashSet<>(this.methodConstraints.values());
/* 114 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getMethodNames() {
/* 123 */     Collection<String> result = new HashSet<>(this.methodConstraints.keySet());
/* 124 */     return result;
/*     */   }
/*     */   
/*     */   private void addHttpMethodConstraints(Collection<HttpMethodConstraintElement> httpMethodConstraints) {
/* 128 */     if (httpMethodConstraints == null) {
/*     */       return;
/*     */     }
/* 131 */     for (HttpMethodConstraintElement constraint : httpMethodConstraints) {
/* 132 */       String method = constraint.getMethodName();
/* 133 */       if (this.methodConstraints.containsKey(method)) {
/* 134 */         throw new IllegalArgumentException("Duplicate method name: " + method);
/*     */       }
/* 136 */       this.methodConstraints.put(method, constraint);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletSecurityElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */