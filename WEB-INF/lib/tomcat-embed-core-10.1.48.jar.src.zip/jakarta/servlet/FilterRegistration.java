package jakarta.servlet;

import java.util.Collection;
import java.util.EnumSet;

public interface FilterRegistration extends Registration {
  void addMappingForServletNames(EnumSet<DispatcherType> paramEnumSet, boolean paramBoolean, String... paramVarArgs);
  
  Collection<String> getServletNameMappings();
  
  void addMappingForUrlPatterns(EnumSet<DispatcherType> paramEnumSet, boolean paramBoolean, String... paramVarArgs);
  
  Collection<String> getUrlPatternMappings();
  
  public static interface Dynamic extends FilterRegistration, Registration.Dynamic {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\FilterRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */