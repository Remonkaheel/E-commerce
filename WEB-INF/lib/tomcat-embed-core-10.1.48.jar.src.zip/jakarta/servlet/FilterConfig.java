package jakarta.servlet;

import java.util.Enumeration;

public interface FilterConfig {
  String getFilterName();
  
  ServletContext getServletContext();
  
  String getInitParameter(String paramString);
  
  Enumeration<String> getInitParameterNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\FilterConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */