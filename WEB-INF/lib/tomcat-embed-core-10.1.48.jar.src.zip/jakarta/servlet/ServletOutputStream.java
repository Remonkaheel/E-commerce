/*     */ package jakarta.servlet;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServletOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   private static final String LSTRING_FILE = "jakarta.servlet.LocalStrings";
/*  37 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.LocalStrings");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String s) throws IOException {
/*  54 */     if (s == null) {
/*  55 */       s = "null";
/*     */     }
/*  57 */     int len = s.length();
/*  58 */     byte[] buffer = new byte[len];
/*     */     
/*  60 */     for (int i = 0; i < len; i++) {
/*  61 */       char c = s.charAt(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  69 */       if ((c & 0xFF00) != 0) {
/*  70 */         String errMsg = lStrings.getString("err.not_iso8859_1");
/*  71 */         Object[] errArgs = new Object[1];
/*  72 */         errArgs[0] = Character.valueOf(c);
/*  73 */         errMsg = MessageFormat.format(errMsg, errArgs);
/*  74 */         throw new CharConversionException(errMsg);
/*     */       } 
/*  76 */       buffer[i] = (byte)(c & 0xFF);
/*     */     } 
/*  78 */     write(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(boolean b) throws IOException {
/*     */     String msg;
/*  90 */     if (b) {
/*  91 */       msg = lStrings.getString("value.true");
/*     */     } else {
/*  93 */       msg = lStrings.getString("value.false");
/*     */     } 
/*  95 */     print(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(char c) throws IOException {
/* 106 */     print(String.valueOf(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(int i) throws IOException {
/* 117 */     print(String.valueOf(i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(long l) throws IOException {
/* 128 */     print(String.valueOf(l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(float f) throws IOException {
/* 139 */     print(String.valueOf(f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(double d) throws IOException {
/* 150 */     print(String.valueOf(d));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println() throws IOException {
/* 159 */     print("\r\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(String s) throws IOException {
/* 170 */     StringBuilder sb = new StringBuilder();
/* 171 */     sb.append(s);
/* 172 */     sb.append("\r\n");
/* 173 */     print(sb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(boolean b) throws IOException {
/* 184 */     StringBuilder sb = new StringBuilder();
/* 185 */     if (b) {
/* 186 */       sb.append(lStrings.getString("value.true"));
/*     */     } else {
/* 188 */       sb.append(lStrings.getString("value.false"));
/*     */     } 
/* 190 */     sb.append("\r\n");
/* 191 */     print(sb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(char c) throws IOException {
/* 202 */     println(String.valueOf(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(int i) throws IOException {
/* 213 */     println(String.valueOf(i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(long l) throws IOException {
/* 224 */     println(String.valueOf(l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(float f) throws IOException {
/* 235 */     println(String.valueOf(f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(double d) throws IOException {
/* 246 */     println(String.valueOf(d));
/*     */   }
/*     */   
/*     */   public abstract boolean isReady();
/*     */   
/*     */   public abstract void setWriteListener(WriteListener paramWriteListener);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletOutputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */