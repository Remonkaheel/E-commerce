package jakarta.servlet;

import java.util.EventListener;

public interface ServletContextListener extends EventListener {
  default void contextInitialized(ServletContextEvent sce) {}
  
  default void contextDestroyed(ServletContextEvent sce) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\ServletContextListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */