/*     */ package jakarta.servlet;
/*     */ 
/*     */ import jakarta.servlet.annotation.ServletSecurity;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpConstraintElement
/*     */ {
/*     */   private static final String LSTRING_FILE = "jakarta.servlet.LocalStrings";
/*  33 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.LocalStrings");
/*     */ 
/*     */   
/*     */   private final ServletSecurity.EmptyRoleSemantic emptyRoleSemantic;
/*     */   
/*     */   private final ServletSecurity.TransportGuarantee transportGuarantee;
/*     */   
/*     */   private final String[] rolesAllowed;
/*     */ 
/*     */   
/*     */   public HttpConstraintElement() {
/*  44 */     this.emptyRoleSemantic = ServletSecurity.EmptyRoleSemantic.PERMIT;
/*  45 */     this.transportGuarantee = ServletSecurity.TransportGuarantee.NONE;
/*  46 */     this.rolesAllowed = new String[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConstraintElement(ServletSecurity.EmptyRoleSemantic emptyRoleSemantic) {
/*  55 */     this.emptyRoleSemantic = emptyRoleSemantic;
/*  56 */     this.transportGuarantee = ServletSecurity.TransportGuarantee.NONE;
/*  57 */     this.rolesAllowed = new String[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConstraintElement(ServletSecurity.TransportGuarantee transportGuarantee, String... rolesAllowed) {
/*  67 */     this.emptyRoleSemantic = ServletSecurity.EmptyRoleSemantic.PERMIT;
/*  68 */     this.transportGuarantee = transportGuarantee;
/*  69 */     this.rolesAllowed = rolesAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConstraintElement(ServletSecurity.EmptyRoleSemantic emptyRoleSemantic, ServletSecurity.TransportGuarantee transportGuarantee, String... rolesAllowed) {
/*  83 */     if (rolesAllowed != null && rolesAllowed.length > 0 && ServletSecurity.EmptyRoleSemantic.DENY.equals(emptyRoleSemantic)) {
/*  84 */       throw new IllegalArgumentException(lStrings.getString("httpConstraintElement.invalidRolesDeny"));
/*     */     }
/*  86 */     this.emptyRoleSemantic = emptyRoleSemantic;
/*  87 */     this.transportGuarantee = transportGuarantee;
/*  88 */     this.rolesAllowed = rolesAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurity.EmptyRoleSemantic getEmptyRoleSemantic() {
/*  97 */     return this.emptyRoleSemantic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurity.TransportGuarantee getTransportGuarantee() {
/* 106 */     return this.transportGuarantee;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRolesAllowed() {
/* 115 */     return this.rolesAllowed;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\HttpConstraintElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */