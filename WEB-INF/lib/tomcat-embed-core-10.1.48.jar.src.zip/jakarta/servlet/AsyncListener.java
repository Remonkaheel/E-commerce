package jakarta.servlet;

import java.io.IOException;
import java.util.EventListener;

public interface AsyncListener extends EventListener {
  void onComplete(AsyncEvent paramAsyncEvent) throws IOException;
  
  void onTimeout(AsyncEvent paramAsyncEvent) throws IOException;
  
  void onError(AsyncEvent paramAsyncEvent) throws IOException;
  
  void onStartAsync(AsyncEvent paramAsyncEvent) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\jakarta\servlet\AsyncListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */