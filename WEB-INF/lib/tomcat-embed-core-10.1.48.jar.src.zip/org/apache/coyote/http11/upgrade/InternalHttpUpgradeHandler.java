/*    */ package org.apache.coyote.http11.upgrade;
/*    */ 
/*    */ import jakarta.servlet.http.HttpUpgradeHandler;
/*    */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*    */ import org.apache.tomcat.util.net.SSLSupport;
/*    */ import org.apache.tomcat.util.net.SocketEvent;
/*    */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InternalHttpUpgradeHandler
/*    */   extends HttpUpgradeHandler
/*    */ {
/*    */   AbstractEndpoint.Handler.SocketState upgradeDispatch(SocketEvent paramSocketEvent);
/*    */   
/*    */   void timeoutAsync(long paramLong);
/*    */   
/*    */   void setSocketWrapper(SocketWrapperBase<?> paramSocketWrapperBase);
/*    */   
/*    */   void setSslSupport(SSLSupport paramSSLSupport);
/*    */   
/*    */   void pause();
/*    */   
/*    */   default boolean hasAsyncIO() {
/* 72 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default UpgradeInfo getUpgradeInfo() {
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http1\\upgrade\InternalHttpUpgradeHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */