/*    */ package org.apache.coyote.http11.upgrade;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpgradeApplicationBufferHandler
/*    */   implements ApplicationBufferHandler
/*    */ {
/*    */   private ByteBuffer byteBuffer;
/*    */   
/*    */   public void setByteBuffer(ByteBuffer byteBuffer) {
/* 33 */     this.byteBuffer = byteBuffer;
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteBuffer getByteBuffer() {
/* 38 */     return this.byteBuffer;
/*    */   }
/*    */   
/*    */   public void expand(int size) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http1\\upgrade\UpgradeApplicationBufferHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */