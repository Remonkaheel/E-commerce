/*     */ package org.apache.coyote.http11.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.coyote.InputBuffer;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.coyote.http11.InputFilter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentityInputFilter
/*     */   implements InputFilter, ApplicationBufferHandler
/*     */ {
/*  35 */   private static final StringManager sm = StringManager.getManager(IdentityInputFilter.class);
/*     */ 
/*     */   
/*     */   protected static final String ENCODING_NAME = "identity";
/*     */ 
/*     */   
/*  41 */   protected static final ByteChunk ENCODING = new ByteChunk();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  47 */     ENCODING.setBytes("identity".getBytes(StandardCharsets.ISO_8859_1), 0, "identity".length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   protected long contentLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected long remaining = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputBuffer buffer;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteBuffer tempRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int maxSwallowSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentityInputFilter(int maxSwallowSize) {
/*  81 */     this.maxSwallowSize = maxSwallowSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doRead(ApplicationBufferHandler handler) throws IOException {
/*     */     int result;
/*  92 */     if (this.contentLength >= 0L) {
/*  93 */       if (this.remaining > 0L) {
/*  94 */         int nRead = this.buffer.doRead(handler);
/*  95 */         if (nRead > this.remaining) {
/*     */ 
/*     */ 
/*     */           
/*  99 */           handler.getByteBuffer().limit(handler.getByteBuffer().position() + (int)this.remaining);
/* 100 */           result = (int)this.remaining;
/*     */         } else {
/* 102 */           result = nRead;
/*     */         } 
/* 104 */         if (nRead > 0) {
/* 105 */           this.remaining -= nRead;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 110 */         if (handler.getByteBuffer() != null) {
/* 111 */           handler.getByteBuffer().position(0).limit(0);
/*     */         }
/* 113 */         result = -1;
/*     */       } 
/*     */     } else {
/* 116 */       result = -1;
/*     */     } 
/*     */     
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequest(Request request) {
/* 132 */     this.contentLength = request.getContentLengthLong();
/* 133 */     this.remaining = this.contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long end() throws IOException {
/* 140 */     boolean maxSwallowSizeExceeded = (this.maxSwallowSize > -1 && this.remaining > this.maxSwallowSize);
/* 141 */     long swallowed = 0L;
/*     */ 
/*     */     
/* 144 */     while (this.remaining > 0L) {
/*     */       
/* 146 */       int nread = this.buffer.doRead(this);
/* 147 */       this.tempRead = null;
/* 148 */       if (nread > 0) {
/* 149 */         swallowed += nread;
/* 150 */         this.remaining -= nread;
/* 151 */         if (maxSwallowSizeExceeded && swallowed > this.maxSwallowSize)
/*     */         {
/*     */ 
/*     */           
/* 155 */           throw new IOException(sm.getString("inputFilter.maxSwallow")); } 
/*     */         continue;
/*     */       } 
/* 158 */       this.remaining = 0L;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 163 */     return -this.remaining;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() {
/* 171 */     return this.buffer.available();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuffer(InputBuffer buffer) {
/* 177 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recycle() {
/* 183 */     this.contentLength = -1L;
/* 184 */     this.remaining = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteChunk getEncodingName() {
/* 190 */     return ENCODING;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinished() {
/* 198 */     return (this.contentLength > -1L && this.remaining <= 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setByteBuffer(ByteBuffer buffer) {
/* 204 */     this.tempRead = buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getByteBuffer() {
/* 210 */     return this.tempRead;
/*     */   }
/*     */   
/*     */   public void expand(int size) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\IdentityInputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */