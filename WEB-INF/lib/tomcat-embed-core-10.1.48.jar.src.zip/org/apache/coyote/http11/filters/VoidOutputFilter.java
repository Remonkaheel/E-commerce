/*    */ package org.apache.coyote.http11.filters;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.apache.coyote.Response;
/*    */ import org.apache.coyote.http11.HttpOutputBuffer;
/*    */ import org.apache.coyote.http11.OutputFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidOutputFilter
/*    */   implements OutputFilter
/*    */ {
/* 31 */   private HttpOutputBuffer buffer = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int doWrite(ByteBuffer chunk) throws IOException {
/* 38 */     return chunk.remaining();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long getBytesWritten() {
/* 44 */     return 0L;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResponse(Response response) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBuffer(HttpOutputBuffer buffer) {
/* 58 */     this.buffer = buffer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void flush() throws IOException {
/* 64 */     this.buffer.flush();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void recycle() {
/* 70 */     this.buffer = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void end() throws IOException {
/* 76 */     this.buffer.end();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\VoidOutputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */