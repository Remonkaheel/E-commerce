/*     */ package org.apache.coyote.http11.filters;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.coyote.http11.HttpOutputBuffer;
/*     */ import org.apache.coyote.http11.OutputFilter;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkedOutputFilter
/*     */   implements OutputFilter
/*     */ {
/*  40 */   private static final byte[] LAST_CHUNK_BYTES = new byte[] { 48, 13, 10 };
/*  41 */   private static final byte[] CRLF_BYTES = new byte[] { 13, 10 };
/*  42 */   private static final byte[] END_CHUNK_BYTES = new byte[] { 48, 13, 10, 13, 10 };
/*     */   
/*  44 */   private static final Set<String> disallowedTrailerFieldNames = new HashSet<>();
/*     */   protected HttpOutputBuffer buffer;
/*     */   
/*     */   static {
/*  48 */     disallowedTrailerFieldNames.add("age");
/*  49 */     disallowedTrailerFieldNames.add("cache-control");
/*  50 */     disallowedTrailerFieldNames.add("content-length");
/*  51 */     disallowedTrailerFieldNames.add("content-encoding");
/*  52 */     disallowedTrailerFieldNames.add("content-range");
/*  53 */     disallowedTrailerFieldNames.add("content-type");
/*  54 */     disallowedTrailerFieldNames.add("date");
/*  55 */     disallowedTrailerFieldNames.add("expires");
/*  56 */     disallowedTrailerFieldNames.add("location");
/*  57 */     disallowedTrailerFieldNames.add("retry-after");
/*  58 */     disallowedTrailerFieldNames.add("trailer");
/*  59 */     disallowedTrailerFieldNames.add("transfer-encoding");
/*  60 */     disallowedTrailerFieldNames.add("vary");
/*  61 */     disallowedTrailerFieldNames.add("warning");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   protected final ByteBuffer chunkHeader = ByteBuffer.allocate(10);
/*     */ 
/*     */   
/*  76 */   protected final ByteBuffer lastChunk = ByteBuffer.wrap(LAST_CHUNK_BYTES);
/*  77 */   protected final ByteBuffer crlfChunk = ByteBuffer.wrap(CRLF_BYTES);
/*     */ 
/*     */ 
/*     */   
/*  81 */   protected final ByteBuffer endChunk = ByteBuffer.wrap(END_CHUNK_BYTES);
/*     */ 
/*     */   
/*     */   private Response response;
/*     */ 
/*     */   
/*     */   public ChunkedOutputFilter() {
/*  88 */     this.chunkHeader.put(8, (byte)13);
/*  89 */     this.chunkHeader.put(9, (byte)10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doWrite(ByteBuffer chunk) throws IOException {
/*  98 */     int result = chunk.remaining();
/*     */     
/* 100 */     if (result <= 0) {
/* 101 */       return 0;
/*     */     }
/*     */     
/* 104 */     int pos = calculateChunkHeader(result);
/*     */     
/* 106 */     this.chunkHeader.position(pos).limit(10);
/* 107 */     this.buffer.doWrite(this.chunkHeader);
/*     */     
/* 109 */     this.buffer.doWrite(chunk);
/*     */     
/* 111 */     this.chunkHeader.position(8).limit(10);
/* 112 */     this.buffer.doWrite(this.chunkHeader);
/*     */     
/* 114 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int calculateChunkHeader(int len) {
/* 120 */     int pos = 8;
/* 121 */     int current = len;
/* 122 */     while (current > 0) {
/* 123 */       int digit = current % 16;
/* 124 */       current /= 16;
/* 125 */       this.chunkHeader.put(--pos, HexUtils.getHex(digit));
/*     */     } 
/* 127 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getBytesWritten() {
/* 133 */     return this.buffer.getBytesWritten();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponse(Response response) {
/* 141 */     this.response = response;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuffer(HttpOutputBuffer buffer) {
/* 147 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 154 */     this.buffer.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void end() throws IOException {
/* 161 */     Supplier<Map<String, String>> trailerFieldsSupplier = this.response.getTrailerFields();
/* 162 */     Map<String, String> trailerFields = null;
/*     */     
/* 164 */     if (trailerFieldsSupplier != null) {
/* 165 */       trailerFields = trailerFieldsSupplier.get();
/*     */     }
/*     */     
/* 168 */     if (trailerFields == null) {
/*     */       
/* 170 */       this.buffer.doWrite(this.endChunk);
/* 171 */       this.endChunk.position(0).limit(this.endChunk.capacity());
/*     */     } else {
/* 173 */       this.buffer.doWrite(this.lastChunk);
/* 174 */       this.lastChunk.position(0).limit(this.lastChunk.capacity());
/*     */       
/* 176 */       ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
/*     */       
/* 178 */       OutputStreamWriter osw = new OutputStreamWriter(baos, StandardCharsets.ISO_8859_1); 
/* 179 */       try { for (Map.Entry<String, String> trailerField : trailerFields.entrySet()) {
/*     */           
/* 181 */           if (disallowedTrailerFieldNames.contains(((String)trailerField.getKey()).toLowerCase(Locale.ENGLISH))) {
/*     */             continue;
/*     */           }
/* 184 */           osw.write(trailerField.getKey());
/* 185 */           osw.write(58);
/* 186 */           osw.write(32);
/* 187 */           osw.write(trailerField.getValue());
/* 188 */           osw.write("\r\n");
/*     */         } 
/* 190 */         osw.close(); } catch (Throwable throwable) { try { osw.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 192 */        this.buffer.doWrite(ByteBuffer.wrap(baos.toByteArray()));
/*     */       
/* 194 */       this.buffer.doWrite(this.crlfChunk);
/* 195 */       this.crlfChunk.position(0).limit(this.crlfChunk.capacity());
/*     */     } 
/* 197 */     this.buffer.end();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recycle() {
/* 203 */     this.response = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\ChunkedOutputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */