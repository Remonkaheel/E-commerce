/*    */ package org.apache.coyote.http11.filters;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.apache.coyote.InputBuffer;
/*    */ import org.apache.coyote.Request;
/*    */ import org.apache.coyote.http11.InputFilter;
/*    */ import org.apache.tomcat.util.buf.ByteChunk;
/*    */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidInputFilter
/*    */   implements InputFilter
/*    */ {
/*    */   protected static final String ENCODING_NAME = "void";
/* 37 */   protected static final ByteChunk ENCODING = new ByteChunk();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 43 */     ENCODING.setBytes("void".getBytes(StandardCharsets.ISO_8859_1), 0, "void".length());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int doRead(ApplicationBufferHandler handler) throws IOException {
/* 51 */     return -1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequest(Request request) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBuffer(InputBuffer buffer) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void recycle() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteChunk getEncodingName() {
/* 77 */     return ENCODING;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long end() throws IOException {
/* 83 */     return 0L;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int available() {
/* 89 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isFinished() {
/* 95 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\VoidInputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */