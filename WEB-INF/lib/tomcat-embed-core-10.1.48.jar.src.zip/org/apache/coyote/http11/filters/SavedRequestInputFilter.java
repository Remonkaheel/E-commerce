/*     */ package org.apache.coyote.http11.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.coyote.InputBuffer;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.coyote.http11.InputFilter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SavedRequestInputFilter
/*     */   implements InputFilter
/*     */ {
/*     */   protected ByteChunk input;
/*     */   
/*     */   public SavedRequestInputFilter(ByteChunk input) {
/*  43 */     this.input = input;
/*     */   }
/*     */ 
/*     */   
/*     */   public int doRead(ApplicationBufferHandler handler) throws IOException {
/*  48 */     if (this.input.getStart() >= this.input.getEnd()) {
/*  49 */       return -1;
/*     */     }
/*     */     
/*  52 */     int len = this.input.getLength();
/*  53 */     handler.setByteBuffer(ByteBuffer.wrap(this.input.getBytes(), this.input.getStart(), len));
/*  54 */     this.input.setStart(this.input.getEnd());
/*  55 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequest(Request request) {
/*  63 */     request.setContentLength(this.input.getLength());
/*     */   }
/*     */ 
/*     */   
/*     */   public void recycle() {
/*  68 */     this.input = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteChunk getEncodingName() {
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuffer(InputBuffer buffer) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() {
/*  91 */     return this.input.getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long end() throws IOException {
/* 101 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFinished() {
/* 106 */     return (this.input.getStart() >= this.input.getEnd());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\SavedRequestInputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */