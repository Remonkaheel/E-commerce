/*     */ package org.apache.coyote.http11.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.coyote.InputBuffer;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.coyote.http11.InputFilter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedInputFilter
/*     */   implements InputFilter, ApplicationBufferHandler
/*     */ {
/*  37 */   private static final StringManager sm = StringManager.getManager(BufferedInputFilter.class);
/*     */   
/*     */   private static final String ENCODING_NAME = "buffered";
/*  40 */   private static final ByteChunk ENCODING = new ByteChunk();
/*     */   private ByteChunk buffered;
/*     */   
/*     */   static {
/*  44 */     ENCODING.setBytes("buffered".getBytes(StandardCharsets.ISO_8859_1), 0, "buffered".length());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteBuffer tempRead;
/*     */   
/*     */   private InputBuffer buffer;
/*     */   
/*     */   private boolean hasRead = false;
/*     */   
/*     */   private final int maxSwallowSize;
/*     */ 
/*     */   
/*     */   public BufferedInputFilter(int maxSwallowSize) {
/*  59 */     this.maxSwallowSize = maxSwallowSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLimit(int limit) {
/*  71 */     if (this.buffered == null) {
/*  72 */       this.buffered = new ByteChunk();
/*  73 */       this.buffered.setLimit(limit);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequest(Request request) {
/*     */     try {
/*  88 */       if (this.buffered.getLimit() == 0) {
/*     */         
/*  90 */         long swallowed = 0L;
/*     */         int read;
/*  92 */         while ((read = this.buffer.doRead(this)) >= 0) {
/*  93 */           swallowed += read;
/*  94 */           if (this.maxSwallowSize > -1 && swallowed > this.maxSwallowSize)
/*     */           {
/*  96 */             throw new IOException(sm.getString("bufferedInputFilter.maxSwallowSize"));
/*     */           }
/*     */         } 
/*     */       } else {
/* 100 */         while (this.buffer.doRead(this) >= 0) {
/* 101 */           this.buffered.append(this.tempRead);
/* 102 */           this.tempRead = null;
/*     */         } 
/*     */       } 
/* 105 */     } catch (IOException|java.nio.BufferOverflowException ioe) {
/*     */       
/* 107 */       throw new IllegalStateException(sm.getString("bufferedInputFilter.bodySize", new Object[] { ioe.getMessage() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doRead(ApplicationBufferHandler handler) throws IOException {
/* 116 */     if (isFinished()) {
/* 117 */       return -1;
/*     */     }
/*     */     
/* 120 */     handler.setByteBuffer(ByteBuffer.wrap(this.buffered.getBuffer(), this.buffered.getStart(), this.buffered.getLength()));
/* 121 */     this.hasRead = true;
/* 122 */     return this.buffered.getLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBuffer(InputBuffer buffer) {
/* 127 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void recycle() {
/* 132 */     if (this.buffered != null) {
/* 133 */       if (this.buffered.getBuffer() != null && (this.buffered.getBuffer()).length > 65536) {
/* 134 */         this.buffered = null;
/*     */       } else {
/* 136 */         this.buffered.recycle();
/*     */       } 
/*     */     }
/* 139 */     this.hasRead = false;
/* 140 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteChunk getEncodingName() {
/* 145 */     return ENCODING;
/*     */   }
/*     */ 
/*     */   
/*     */   public long end() throws IOException {
/* 150 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() {
/* 155 */     int available = this.buffered.getLength();
/* 156 */     if (available == 0)
/*     */     {
/* 158 */       return this.buffer.available();
/*     */     }
/* 160 */     return available;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinished() {
/* 167 */     return (this.hasRead || this.buffered.getLength() <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setByteBuffer(ByteBuffer buffer) {
/* 173 */     this.tempRead = buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getByteBuffer() {
/* 179 */     return this.tempRead;
/*     */   }
/*     */   
/*     */   public void expand(int size) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\BufferedInputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */