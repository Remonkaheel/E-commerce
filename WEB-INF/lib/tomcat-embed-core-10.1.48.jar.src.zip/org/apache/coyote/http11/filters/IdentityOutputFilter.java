/*     */ package org.apache.coyote.http11.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.coyote.http11.HttpOutputBuffer;
/*     */ import org.apache.coyote.http11.OutputFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentityOutputFilter
/*     */   implements OutputFilter
/*     */ {
/*  36 */   protected long contentLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   protected long remaining = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpOutputBuffer buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doWrite(ByteBuffer chunk) throws IOException {
/*     */     int result;
/*  58 */     if (this.contentLength >= 0L) {
/*  59 */       if (this.remaining > 0L) {
/*  60 */         result = chunk.remaining();
/*  61 */         if (result > this.remaining) {
/*     */ 
/*     */ 
/*     */           
/*  65 */           chunk.limit(chunk.position() + (int)this.remaining);
/*  66 */           result = (int)this.remaining;
/*  67 */           this.remaining = 0L;
/*     */         } else {
/*  69 */           this.remaining -= result;
/*     */         } 
/*  71 */         this.buffer.doWrite(chunk);
/*     */       }
/*     */       else {
/*     */         
/*  75 */         chunk.position(0);
/*  76 */         chunk.limit(0);
/*  77 */         result = -1;
/*     */       } 
/*     */     } else {
/*     */       
/*  81 */       result = chunk.remaining();
/*  82 */       this.buffer.doWrite(chunk);
/*  83 */       result -= chunk.remaining();
/*     */     } 
/*     */     
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getBytesWritten() {
/*  93 */     return this.buffer.getBytesWritten();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponse(Response response) {
/* 101 */     this.contentLength = response.getContentLengthLong();
/* 102 */     this.remaining = this.contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuffer(HttpOutputBuffer buffer) {
/* 108 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 115 */     this.buffer.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void end() throws IOException {
/* 121 */     this.buffer.end();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recycle() {
/* 127 */     this.contentLength = -1L;
/* 128 */     this.remaining = 0L;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\http11\filters\IdentityOutputFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */