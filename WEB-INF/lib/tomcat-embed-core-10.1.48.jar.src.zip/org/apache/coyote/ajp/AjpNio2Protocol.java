/*    */ package org.apache.coyote.ajp;
/*    */ 
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*    */ import org.apache.tomcat.util.net.Nio2Channel;
/*    */ import org.apache.tomcat.util.net.Nio2Endpoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AjpNio2Protocol
/*    */   extends AbstractAjpProtocol<Nio2Channel>
/*    */ {
/* 30 */   private static final Log log = LogFactory.getLog(AjpNio2Protocol.class);
/*    */ 
/*    */   
/*    */   protected Log getLog() {
/* 34 */     return log;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AjpNio2Protocol() {
/* 41 */     super((AbstractEndpoint<Nio2Channel, ?>)new Nio2Endpoint());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getNamePrefix() {
/* 49 */     return "ajp-nio2";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\ajp\AjpNio2Protocol.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */