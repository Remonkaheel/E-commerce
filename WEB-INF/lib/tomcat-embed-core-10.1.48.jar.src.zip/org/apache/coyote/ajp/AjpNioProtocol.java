/*    */ package org.apache.coyote.ajp;
/*    */ 
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*    */ import org.apache.tomcat.util.net.NioChannel;
/*    */ import org.apache.tomcat.util.net.NioEndpoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AjpNioProtocol
/*    */   extends AbstractAjpProtocol<NioChannel>
/*    */ {
/* 29 */   private static final Log log = LogFactory.getLog(AjpNioProtocol.class);
/*    */ 
/*    */   
/*    */   protected Log getLog() {
/* 33 */     return log;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AjpNioProtocol() {
/* 40 */     super((AbstractEndpoint<NioChannel, ?>)new NioEndpoint());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getNamePrefix() {
/* 48 */     return "ajp-nio";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\ajp\AjpNioProtocol.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */