/*     */ package org.apache.coyote.ajp;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.coyote.AbstractProtocol;
/*     */ import org.apache.coyote.Processor;
/*     */ import org.apache.coyote.UpgradeProtocol;
/*     */ import org.apache.coyote.UpgradeToken;
/*     */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAjpProtocol<S>
/*     */   extends AbstractProtocol<S>
/*     */ {
/*  43 */   protected static final StringManager sm = StringManager.getManager(AbstractAjpProtocol.class); private boolean ajpFlush; private boolean tomcatAuthentication; private boolean tomcatAuthorization; private String secret; private boolean secretRequired;
/*     */   private Pattern allowedRequestAttributesPattern;
/*     */   private int packetSize;
/*     */   
/*  47 */   public AbstractAjpProtocol(AbstractEndpoint<S, ?> endpoint) { super(endpoint);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     this.ajpFlush = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.tomcatAuthentication = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     this.tomcatAuthorization = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.secret = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     this.secretRequired = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     this.packetSize = 8192; setConnectionTimeout(-1); getEndpoint().setUseSendfile(false); getEndpoint().setAddress(InetAddress.getLoopbackAddress()); }
/*     */   protected String getProtocolName() { return "Ajp"; }
/*     */   protected AbstractEndpoint<S, ?> getEndpoint() { return super.getEndpoint(); }
/* 212 */   protected UpgradeProtocol getNegotiatedProtocol(String name) { return null; } protected UpgradeProtocol getUpgradeProtocol(String name) { return null; } public boolean getAjpFlush() { return this.ajpFlush; } public void setAjpFlush(boolean ajpFlush) { this.ajpFlush = ajpFlush; } public boolean getTomcatAuthentication() { return this.tomcatAuthentication; } public void setTomcatAuthentication(boolean tomcatAuthentication) { this.tomcatAuthentication = tomcatAuthentication; } public boolean getTomcatAuthorization() { return this.tomcatAuthorization; } public int getPacketSize() { return this.packetSize; }
/*     */   public void setTomcatAuthorization(boolean tomcatAuthorization) { this.tomcatAuthorization = tomcatAuthorization; }
/*     */   public void setSecret(String secret) { this.secret = secret; }
/*     */   protected String getSecret() { return this.secret; }
/* 216 */   @Deprecated public void setRequiredSecret(String requiredSecret) { setSecret(requiredSecret); } @Deprecated protected String getRequiredSecret() { return getSecret(); } public void setSecretRequired(boolean secretRequired) { this.secretRequired = secretRequired; } public boolean getSecretRequired() { return this.secretRequired; } public void setAllowedRequestAttributesPattern(String allowedRequestAttributesPattern) { this.allowedRequestAttributesPattern = Pattern.compile(allowedRequestAttributesPattern); } public String getAllowedRequestAttributesPattern() { return this.allowedRequestAttributesPattern.pattern(); } protected Pattern getAllowedRequestAttributesPatternInternal() { return this.allowedRequestAttributesPattern; } public void setPacketSize(int packetSize) { this.packetSize = Math.max(packetSize, 8192); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDesiredBufferSize() {
/* 222 */     return getPacketSize() - 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSslHostConfig(SSLHostConfig sslHostConfig) {
/* 230 */     getLog().warn(sm.getString("ajpprotocol.noSSL", new Object[] { sslHostConfig.getHostName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSslHostConfig(SSLHostConfig sslHostConfig, boolean replace) {
/* 236 */     getLog().warn(sm.getString("ajpprotocol.noSSL", new Object[] { sslHostConfig.getHostName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLHostConfig[] findSslHostConfigs() {
/* 242 */     return new SSLHostConfig[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUpgradeProtocol(UpgradeProtocol upgradeProtocol) {
/* 248 */     getLog().warn(sm.getString("ajpprotocol.noUpgrade", new Object[] { upgradeProtocol.getClass().getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UpgradeProtocol[] findUpgradeProtocols() {
/* 254 */     return new UpgradeProtocol[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Processor createProcessor() {
/* 260 */     return (Processor)new AjpProcessor(this, getAdapter());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Processor createUpgradeProcessor(SocketWrapperBase<?> socket, UpgradeToken upgradeToken) {
/* 266 */     throw new IllegalStateException(sm.getString("ajpprotocol.noUpgradeHandler", new Object[] { upgradeToken
/* 267 */             .getHttpUpgradeHandler().getClass().getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws Exception {
/* 273 */     if (getSecretRequired()) {
/* 274 */       String secret = getSecret();
/* 275 */       if (secret == null || secret.isEmpty()) {
/* 276 */         throw new IllegalArgumentException(sm.getString("ajpprotocol.noSecret"));
/*     */       }
/*     */     } 
/* 279 */     super.start();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\ajp\AbstractAjpProtocol.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */