/*     */ package org.apache.coyote.ajp;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AjpMessage
/*     */ {
/*  35 */   private static final Log log = LogFactory.getLog(AjpMessage.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   protected static final StringManager sm = StringManager.getManager(AjpMessage.class);
/*     */   protected final byte[] buf;
/*     */   
/*     */   public AjpMessage(int packetSize) {
/*  44 */     this.buf = new byte[packetSize];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  73 */     this.len = 4;
/*  74 */     this.pos = 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void end() {
/*  83 */     this.len = this.pos;
/*  84 */     int dLen = this.len - 4;
/*     */     
/*  86 */     this.buf[0] = 65;
/*  87 */     this.buf[1] = 66;
/*  88 */     this.buf[2] = (byte)(dLen >>> 8 & 0xFF);
/*  89 */     this.buf[3] = (byte)(dLen & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBuffer() {
/*  99 */     return this.buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLen() {
/* 110 */     return this.len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendInt(int val) {
/* 120 */     this.buf[this.pos++] = (byte)(val >>> 8 & 0xFF);
/* 121 */     this.buf[this.pos++] = (byte)(val & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendByte(int val) {
/* 131 */     this.buf[this.pos++] = (byte)val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendBytes(MessageBytes mb) {
/* 141 */     if (mb == null) {
/* 142 */       log.error(sm.getString("ajpmessage.null"), new NullPointerException());
/* 143 */       appendInt(0);
/* 144 */       appendByte(0);
/*     */       return;
/*     */     } 
/* 147 */     if (mb.getType() != 2) {
/* 148 */       mb.toBytes();
/* 149 */       ByteChunk bc = mb.getByteChunk();
/*     */ 
/*     */ 
/*     */       
/* 153 */       byte[] buffer = bc.getBuffer();
/* 154 */       for (int i = bc.getStart(); i < bc.getLength(); i++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 160 */         if ((buffer[i] > -1 && buffer[i] <= 31 && buffer[i] != 9) || buffer[i] == Byte.MAX_VALUE) {
/* 161 */           buffer[i] = 32;
/*     */         }
/*     */       } 
/*     */     } 
/* 165 */     appendByteChunk(mb.getByteChunk());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendByteChunk(ByteChunk bc) {
/* 175 */     if (bc == null) {
/* 176 */       log.error(sm.getString("ajpmessage.null"), new NullPointerException());
/* 177 */       appendInt(0);
/* 178 */       appendByte(0);
/*     */       return;
/*     */     } 
/* 181 */     appendBytes(bc.getBytes(), bc.getStart(), bc.getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendBytes(byte[] b, int off, int numBytes) {
/* 195 */     if (checkOverflow(numBytes)) {
/*     */       return;
/*     */     }
/* 198 */     appendInt(numBytes);
/* 199 */     System.arraycopy(b, off, this.buf, this.pos, numBytes);
/* 200 */     this.pos += numBytes;
/* 201 */     appendByte(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendBytes(ByteBuffer b) {
/* 213 */     int numBytes = b.remaining();
/* 214 */     if (checkOverflow(numBytes)) {
/*     */       return;
/*     */     }
/* 217 */     appendInt(numBytes);
/* 218 */     b.get(this.buf, this.pos, numBytes);
/* 219 */     this.pos += numBytes;
/* 220 */     appendByte(0);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkOverflow(int numBytes) {
/* 225 */     if (this.pos + numBytes + 3 > this.buf.length) {
/* 226 */       log.error(sm.getString("ajpmessage.overflow", new Object[] { "" + numBytes, "" + this.pos }), new ArrayIndexOutOfBoundsException());
/*     */       
/* 228 */       if (log.isDebugEnabled()) {
/* 229 */         dump("Overflow/coBytes");
/*     */       }
/* 231 */       return true;
/*     */     } 
/* 233 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 244 */     int b1 = this.buf[this.pos++] & 0xFF;
/* 245 */     int b2 = this.buf[this.pos++] & 0xFF;
/* 246 */     validatePos(this.pos);
/* 247 */     return (b1 << 8) + b2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int peekInt() {
/* 252 */     validatePos(this.pos + 2);
/* 253 */     int b1 = this.buf[this.pos] & 0xFF;
/* 254 */     int b2 = this.buf[this.pos + 1] & 0xFF;
/* 255 */     return (b1 << 8) + b2;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte() {
/* 260 */     byte res = this.buf[this.pos++];
/* 261 */     validatePos(this.pos);
/* 262 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getBytes(MessageBytes mb) {
/* 267 */     doGetBytes(mb, true);
/*     */   }
/*     */   
/*     */   public void getBodyBytes(MessageBytes mb) {
/* 271 */     doGetBytes(mb, false);
/*     */   }
/*     */   
/*     */   private void doGetBytes(MessageBytes mb, boolean terminated) {
/* 275 */     int length = getInt();
/* 276 */     if (length == 65535 || length == -1) {
/* 277 */       mb.recycle();
/*     */       return;
/*     */     } 
/* 280 */     if (terminated) {
/* 281 */       validatePos(this.pos + length + 1);
/*     */     } else {
/* 283 */       validatePos(this.pos + length);
/*     */     } 
/* 285 */     mb.setBytes(this.buf, this.pos, length);
/* 286 */     mb.getCharChunk().recycle();
/* 287 */     this.pos += length;
/* 288 */     if (terminated) {
/* 289 */       this.pos++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLongInt() {
/* 301 */     int b1 = this.buf[this.pos++] & 0xFF;
/* 302 */     b1 <<= 8;
/* 303 */     b1 |= this.buf[this.pos++] & 0xFF;
/* 304 */     b1 <<= 8;
/* 305 */     b1 |= this.buf[this.pos++] & 0xFF;
/* 306 */     b1 <<= 8;
/* 307 */     b1 |= this.buf[this.pos++] & 0xFF;
/* 308 */     validatePos(this.pos);
/* 309 */     return b1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int processHeader(boolean toContainer) {
/* 314 */     this.pos = 0;
/* 315 */     int mark = getInt();
/* 316 */     this.len = getInt();
/*     */     
/* 318 */     if ((toContainer && mark != 4660) || (!toContainer && mark != 16706)) {
/* 319 */       log.error(sm.getString("ajpmessage.invalid", new Object[] { "" + mark }));
/* 320 */       if (log.isTraceEnabled()) {
/* 321 */         dump("In");
/*     */       }
/* 323 */       return -1;
/*     */     } 
/* 325 */     if (log.isTraceEnabled()) {
/* 326 */       log.trace("Received " + this.len + " " + this.buf[0]);
/*     */     }
/* 328 */     return this.len;
/*     */   }
/*     */ 
/*     */   
/*     */   private void dump(String prefix) {
/* 333 */     if (log.isTraceEnabled()) {
/* 334 */       log.trace(prefix + ": " + prefix + " " + HexUtils.toHexString(this.buf) + "/" + this.pos);
/*     */     }
/* 336 */     int max = this.pos;
/* 337 */     if (this.len + 4 > this.pos) {
/* 338 */       max = this.len + 4;
/*     */     }
/* 340 */     if (max > 1000) {
/* 341 */       max = 1000;
/*     */     }
/* 343 */     if (log.isTraceEnabled()) {
/* 344 */       for (int j = 0; j < max; j += 16) {
/* 345 */         log.trace(hexLine(this.buf, j, this.len));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validatePos(int posToTest) {
/* 352 */     if (posToTest > this.len + 4)
/*     */     {
/* 354 */       throw new ArrayIndexOutOfBoundsException(sm.getString("ajpMessage.invalidPos", new Object[] { Integer.valueOf(posToTest) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String hexLine(byte[] buf, int start, int len) {
/* 361 */     StringBuilder sb = new StringBuilder(); int i;
/* 362 */     for (i = start; i < start + 16; i++) {
/* 363 */       if (i < len + 4) {
/* 364 */         sb.append(hex(buf[i])).append(' ');
/*     */       } else {
/* 366 */         sb.append("   ");
/*     */       } 
/*     */     } 
/* 369 */     sb.append(" | ");
/* 370 */     for (i = start; i < start + 16 && i < len + 4; i++) {
/* 371 */       if (!Character.isISOControl((char)buf[i])) {
/* 372 */         sb.append(Character.valueOf((char)buf[i]));
/*     */       } else {
/* 374 */         sb.append('.');
/*     */       } 
/*     */     } 
/* 377 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String hex(int x) {
/* 382 */     String h = Integer.toHexString(x);
/* 383 */     if (h.length() == 1) {
/* 384 */       h = "0" + h;
/*     */     }
/* 386 */     return h.substring(h.length() - 2);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\coyote\ajp\AjpMessage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */