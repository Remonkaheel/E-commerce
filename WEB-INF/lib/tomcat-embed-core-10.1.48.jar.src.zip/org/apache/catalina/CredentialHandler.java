package org.apache.catalina;

public interface CredentialHandler {
  boolean matches(String paramString1, String paramString2);
  
  String mutate(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\CredentialHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */