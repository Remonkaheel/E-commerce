/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import jakarta.servlet.ServletOutputStream;
/*      */ import jakarta.servlet.ServletResponse;
/*      */ import jakarta.servlet.SessionTrackingMode;
/*      */ import jakarta.servlet.http.Cookie;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.Charset;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Supplier;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.Constants;
/*      */ import org.apache.coyote.ContinueResponseTiming;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.UEncoder;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.MimeHeaders;
/*      */ import org.apache.tomcat.util.http.parser.MediaTypeCache;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Response
/*      */   implements HttpServletResponse
/*      */ {
/*   73 */   private static final Log log = LogFactory.getLog(Response.class);
/*   74 */   protected static final StringManager sm = StringManager.getManager(Response.class);
/*      */   
/*   76 */   private static final MediaTypeCache MEDIA_TYPE_CACHE = new MediaTypeCache(100); protected static final int SC_EARLY_HINTS = 103; protected org.apache.coyote.Response coyoteResponse; protected final OutputBuffer outputBuffer; protected CoyoteOutputStream outputStream;
/*      */   protected CoyoteWriter writer;
/*      */   protected boolean appCommitted;
/*      */   protected boolean included;
/*      */   private boolean isCharacterEncodingSet;
/*      */   
/*      */   public Response() {
/*   83 */     this(8192);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean usingOutputStream;
/*      */   
/*      */   protected boolean usingWriter;
/*      */   
/*      */   protected final UEncoder urlEncoder;
/*      */   
/*      */   protected final CharChunk redirectURLCC;
/*      */   
/*      */   private final List<Cookie> cookies;
/*      */   
/*      */   private HttpServletResponse applicationResponse;
/*      */   
/*      */   protected Request request;
/*      */   
/*      */   protected ResponseFacade facade;
/*      */ 
/*      */   
/*      */   public void setCoyoteResponse(org.apache.coyote.Response coyoteResponse) {
/*      */     this.coyoteResponse = coyoteResponse;
/*      */     this.outputBuffer.setResponse(coyoteResponse);
/*      */   }
/*      */ 
/*      */   
/*      */   public org.apache.coyote.Response getCoyoteResponse() {
/*      */     return this.coyoteResponse;
/*      */   }
/*      */   
/*      */   public Context getContext() {
/*      */     return this.request.getContext();
/*      */   }
/*      */   
/*      */   public void recycle() {
/*      */     this.cookies.clear();
/*      */     this.outputBuffer.recycle();
/*      */     this.usingOutputStream = false;
/*      */     this.usingWriter = false;
/*      */     this.appCommitted = false;
/*      */     this.included = false;
/*      */     this.isCharacterEncodingSet = false;
/*      */     this.applicationResponse = null;
/*      */     if (getRequest().getDiscardFacades()) {
/*      */       if (this.facade != null) {
/*      */         this.facade.clear();
/*      */         this.facade = null;
/*      */       } 
/*      */       if (this.outputStream != null) {
/*      */         this.outputStream.clear();
/*      */         this.outputStream = null;
/*      */       } 
/*      */       if (this.writer != null) {
/*      */         this.writer.clear();
/*      */         this.writer = null;
/*      */       } 
/*      */     } else if (this.writer != null) {
/*      */       this.writer.recycle();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Response(int outputBufferSize) {
/*  146 */     this.appCommitted = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  152 */     this.included = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  158 */     this.isCharacterEncodingSet = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  164 */     this.usingOutputStream = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  170 */     this.usingWriter = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  176 */     this.urlEncoder = new UEncoder(UEncoder.SafeCharsSet.WITH_SLASH);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  182 */     this.redirectURLCC = new CharChunk();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     this.cookies = new ArrayList<>();
/*      */     
/*  191 */     this.applicationResponse = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  287 */     this.request = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  309 */     this.facade = null; this.outputBuffer = new OutputBuffer(outputBufferSize);
/*      */   }
/*      */   public List<Cookie> getCookies() { return this.cookies; }
/*      */   public long getContentWritten() { return this.outputBuffer.getContentWritten(); } public long getBytesWritten(boolean flush) { if (flush)
/*      */       try {
/*      */         this.outputBuffer.flush();
/*      */       } catch (IOException iOException) {} 
/*  316 */     return getCoyoteResponse().getBytesWritten(flush); } public HttpServletResponse getResponse() { if (this.facade == null) {
/*  317 */       this.facade = new ResponseFacade(this);
/*      */     }
/*  319 */     if (this.applicationResponse == null) {
/*  320 */       this.applicationResponse = this.facade;
/*      */     }
/*  322 */     return this.applicationResponse; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAppCommitted(boolean appCommitted) {
/*      */     this.appCommitted = appCommitted;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setResponse(HttpServletResponse applicationResponse) {
/*      */     ServletResponse servletResponse;
/*  334 */     HttpServletResponse httpServletResponse = applicationResponse;
/*  335 */     while (httpServletResponse instanceof HttpServletResponseWrapper) {
/*  336 */       servletResponse = ((HttpServletResponseWrapper)httpServletResponse).getResponse();
/*      */     }
/*  338 */     if (servletResponse != this.facade) {
/*  339 */       throw new IllegalArgumentException(sm.getString("response.illegalWrap"));
/*      */     }
/*  341 */     this.applicationResponse = applicationResponse;
/*      */   } public boolean isAppCommitted() {
/*      */     return (this.appCommitted || isCommitted() || isSuspended() || (getContentLength() > 0 && getContentWritten() >= getContentLength()));
/*      */   } public Request getRequest() {
/*      */     return this.request;
/*      */   }
/*      */   public void setRequest(Request request) {
/*      */     this.request = request;
/*      */   }
/*      */   public void setSuspended(boolean suspended) {
/*  351 */     this.outputBuffer.setSuspended(suspended);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSuspended() {
/*  361 */     return this.outputBuffer.isSuspended();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() {
/*  371 */     return this.outputBuffer.isClosed();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean setError() {
/*  384 */     return getCoyoteResponse().setError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isError() {
/*  394 */     return getCoyoteResponse().isError();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isErrorReportRequired() {
/*  399 */     return getCoyoteResponse().isErrorReportRequired();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean setErrorReported() {
/*  404 */     return getCoyoteResponse().setErrorReported();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetError() {
/*  409 */     getCoyoteResponse().resetError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finishResponse() throws IOException {
/*  420 */     this.outputBuffer.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getContentLength() {
/*  428 */     return getCoyoteResponse().getContentLength();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentType() {
/*  434 */     return getCoyoteResponse().getContentType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrintWriter getReporter() throws IOException {
/*  449 */     if (this.outputBuffer.isNew()) {
/*  450 */       this.outputBuffer.checkConverter();
/*  451 */       if (this.writer == null) {
/*  452 */         this.writer = new CoyoteWriter(this.outputBuffer);
/*      */       }
/*  454 */       return this.writer;
/*      */     } 
/*  456 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flushBuffer() throws IOException {
/*  466 */     this.outputBuffer.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBufferSize() {
/*  472 */     return this.outputBuffer.getBufferSize();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCharacterEncoding() {
/*  478 */     String charset = getCoyoteResponse().getCharacterEncoding();
/*  479 */     if (charset != null) {
/*  480 */       return charset;
/*      */     }
/*      */     
/*  483 */     Context context = getContext();
/*  484 */     String result = null;
/*  485 */     if (context != null) {
/*  486 */       result = context.getResponseCharacterEncoding();
/*      */     }
/*      */     
/*  489 */     if (result == null) {
/*  490 */       result = Constants.DEFAULT_BODY_CHARSET.name();
/*      */     }
/*      */     
/*  493 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletOutputStream getOutputStream() throws IOException {
/*  500 */     if (this.usingWriter) {
/*  501 */       throw new IllegalStateException(sm.getString("coyoteResponse.getOutputStream.ise"));
/*      */     }
/*      */     
/*  504 */     this.usingOutputStream = true;
/*  505 */     if (this.outputStream == null) {
/*  506 */       this.outputStream = new CoyoteOutputStream(this.outputBuffer);
/*      */     }
/*  508 */     return this.outputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/*  515 */     return getCoyoteResponse().getLocale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrintWriter getWriter() throws IOException {
/*  522 */     if (this.usingOutputStream) {
/*  523 */       throw new IllegalStateException(sm.getString("coyoteResponse.getWriter.ise"));
/*      */     }
/*      */     
/*  526 */     if (this.request.getConnector().getEnforceEncodingInGetWriter())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  535 */       setCharacterEncoding(getCharacterEncoding());
/*      */     }
/*      */     
/*  538 */     this.usingWriter = true;
/*  539 */     this.outputBuffer.checkConverter();
/*  540 */     if (this.writer == null) {
/*  541 */       this.writer = new CoyoteWriter(this.outputBuffer);
/*      */     }
/*  543 */     return this.writer;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCommitted() {
/*  549 */     return getCoyoteResponse().isCommitted();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  556 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  560 */     getCoyoteResponse().reset();
/*  561 */     this.outputBuffer.reset();
/*  562 */     this.usingOutputStream = false;
/*  563 */     this.usingWriter = false;
/*  564 */     this.isCharacterEncodingSet = false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetBuffer() {
/*  570 */     resetBuffer(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetBuffer(boolean resetWriterStreamFlags) {
/*  585 */     if (isCommitted()) {
/*  586 */       throw new IllegalStateException(sm.getString("coyoteResponse.resetBuffer.ise"));
/*      */     }
/*      */     
/*  589 */     this.outputBuffer.reset(resetWriterStreamFlags);
/*      */     
/*  591 */     if (resetWriterStreamFlags) {
/*  592 */       this.usingOutputStream = false;
/*  593 */       this.usingWriter = false;
/*  594 */       this.isCharacterEncodingSet = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBufferSize(int size) {
/*  603 */     if (isCommitted() || !this.outputBuffer.isNew()) {
/*  604 */       throw new IllegalStateException(sm.getString("coyoteResponse.setBufferSize.ise"));
/*      */     }
/*      */     
/*  607 */     this.outputBuffer.setBufferSize(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentLength(int length) {
/*  615 */     setContentLengthLong(length);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentLengthLong(long length) {
/*  621 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  626 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  630 */     getCoyoteResponse().setContentLength(length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentType(String type) {
/*  637 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  642 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  646 */     if (type == null) {
/*  647 */       getCoyoteResponse().setContentType(null);
/*      */       try {
/*  649 */         getCoyoteResponse().setCharacterEncoding(null);
/*  650 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */       
/*  653 */       this.isCharacterEncodingSet = false;
/*      */       
/*      */       return;
/*      */     } 
/*  657 */     String[] m = MEDIA_TYPE_CACHE.parse(type);
/*  658 */     if (m == null) {
/*      */ 
/*      */       
/*  661 */       getCoyoteResponse().setContentTypeNoCharset(type);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  666 */     if (m[1] == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  671 */       getCoyoteResponse().setContentTypeNoCharset(type);
/*      */     } else {
/*      */       
/*  674 */       getCoyoteResponse().setContentTypeNoCharset(m[0]);
/*      */ 
/*      */       
/*  677 */       if (!this.usingWriter) {
/*      */         try {
/*  679 */           getCoyoteResponse().setCharacterEncoding(m[1]);
/*  680 */         } catch (UnsupportedEncodingException e) {
/*  681 */           log.warn(sm.getString("coyoteResponse.encoding.invalid", new Object[] { m[1] }), e);
/*      */         } 
/*      */         
/*  684 */         this.isCharacterEncodingSet = true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterEncoding(String encoding) {
/*  693 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  698 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  704 */     if (this.usingWriter) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/*  709 */       getCoyoteResponse().setCharacterEncoding(encoding);
/*  710 */     } catch (UnsupportedEncodingException e) {
/*  711 */       log.warn(sm.getString("coyoteResponse.encoding.invalid", new Object[] { encoding }), e);
/*      */       return;
/*      */     } 
/*  714 */     this.isCharacterEncodingSet = (encoding != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocale(Locale locale) {
/*  721 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  726 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  730 */     getCoyoteResponse().setLocale(locale);
/*      */ 
/*      */ 
/*      */     
/*  734 */     if (this.usingWriter) {
/*      */       return;
/*      */     }
/*      */     
/*  738 */     if (this.isCharacterEncodingSet) {
/*      */       return;
/*      */     }
/*      */     
/*  742 */     if (locale == null) {
/*      */       try {
/*  744 */         getCoyoteResponse().setCharacterEncoding(null);
/*  745 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  751 */       Context context = getContext();
/*  752 */       if (context != null) {
/*  753 */         String charset = context.getCharset(locale);
/*  754 */         if (charset != null) {
/*      */           try {
/*  756 */             getCoyoteResponse().setCharacterEncoding(charset);
/*  757 */           } catch (UnsupportedEncodingException e) {
/*  758 */             log.warn(sm.getString("coyoteResponse.encoding.invalid", new Object[] { charset }), e);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeader(String name) {
/*  771 */     return getCoyoteResponse().getMimeHeaders().getHeader(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<String> getHeaderNames() {
/*  777 */     MimeHeaders headers = getCoyoteResponse().getMimeHeaders();
/*  778 */     int n = headers.size();
/*  779 */     List<String> result = new ArrayList<>(n);
/*  780 */     for (int i = 0; i < n; i++) {
/*  781 */       result.add(headers.getName(i).toString());
/*      */     }
/*  783 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<String> getHeaders(String name) {
/*  790 */     Enumeration<String> enumeration = getCoyoteResponse().getMimeHeaders().values(name);
/*  791 */     Set<String> result = new LinkedHashSet<>();
/*  792 */     while (enumeration.hasMoreElements()) {
/*  793 */       result.add(enumeration.nextElement());
/*      */     }
/*  795 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMessage() {
/*  803 */     return getCoyoteResponse().getMessage();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStatus() {
/*  809 */     return getCoyoteResponse().getStatus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCookie(Cookie cookie) {
/*  824 */     if (this.included || isCommitted()) {
/*      */       return;
/*      */     }
/*      */     
/*  828 */     this.cookies.add(cookie);
/*      */     
/*  830 */     String header = generateCookieString(cookie);
/*      */     
/*  832 */     addHeader("Set-Cookie", header, getContext().getCookieProcessor().getCharset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSessionCookieInternal(Cookie cookie) {
/*  841 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */     
/*  845 */     String name = cookie.getName();
/*  846 */     String headername = "Set-Cookie";
/*  847 */     String startsWith = name + "=";
/*  848 */     String header = generateCookieString(cookie);
/*  849 */     boolean set = false;
/*  850 */     MimeHeaders headers = getCoyoteResponse().getMimeHeaders();
/*  851 */     int n = headers.size();
/*  852 */     for (int i = 0; i < n; i++) {
/*  853 */       if (headers.getName(i).toString().equals("Set-Cookie") && 
/*  854 */         headers.getValue(i).toString().startsWith(startsWith)) {
/*  855 */         headers.getValue(i).setString(header);
/*  856 */         set = true;
/*      */       } 
/*      */     } 
/*      */     
/*  860 */     if (!set) {
/*  861 */       addHeader("Set-Cookie", header);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String generateCookieString(Cookie cookie) {
/*  870 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*  871 */       return 
/*  872 */         AccessController.<String>doPrivileged(new PrivilegedGenerateCookieString(getContext(), cookie, this.request.getRequest()));
/*      */     }
/*  874 */     return getContext().getCookieProcessor().generateHeader(cookie, this.request.getRequest());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDateHeader(String name, long value) {
/*  882 */     if (name == null || name.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  886 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  891 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  895 */     addHeader(name, FastHttpDateFormat.formatDate(value));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addHeader(String name, String value) {
/*  901 */     addHeader(name, value, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addHeader(String name, String value, Charset charset) {
/*  907 */     if (name == null || name.isEmpty() || value == null) {
/*      */       return;
/*      */     }
/*      */     
/*  911 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  916 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  920 */     char cc = name.charAt(0);
/*  921 */     if ((cc == 'C' || cc == 'c') && 
/*  922 */       checkSpecialHeader(name, value)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  927 */     getCoyoteResponse().addHeader(name, value, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkSpecialHeader(String name, String value) {
/*  939 */     if (name.equalsIgnoreCase("Content-Type")) {
/*  940 */       setContentType(value);
/*  941 */       return true;
/*      */     } 
/*  943 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addIntHeader(String name, int value) {
/*  950 */     if (name == null || name.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  954 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  959 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/*  963 */     addHeader(name, "" + value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsHeader(String name) {
/*  972 */     char cc = name.charAt(0);
/*  973 */     if (cc == 'C' || cc == 'c') {
/*  974 */       if (name.equalsIgnoreCase("Content-Type"))
/*      */       {
/*  976 */         return (getCoyoteResponse().getContentType() != null);
/*      */       }
/*  978 */       if (name.equalsIgnoreCase("Content-Length"))
/*      */       {
/*  980 */         return (getCoyoteResponse().getContentLengthLong() != -1L);
/*      */       }
/*      */     } 
/*      */     
/*  984 */     return getCoyoteResponse().containsHeader(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTrailerFields(Supplier<Map<String, String>> supplier) {
/*  990 */     getCoyoteResponse().setTrailerFields(supplier);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Supplier<Map<String, String>> getTrailerFields() {
/*  996 */     return getCoyoteResponse().getTrailerFields();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodeRedirectURL(String url) {
/* 1002 */     if (isEncodeable(toAbsolute(url))) {
/* 1003 */       return toEncoded(url, this.request.getSessionInternal().getIdInternal());
/*      */     }
/* 1005 */     return url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodeURL(String url) {
/*      */     String absolute;
/*      */     try {
/* 1015 */       absolute = toAbsolute(url);
/* 1016 */     } catch (IllegalArgumentException iae) {
/*      */       
/* 1018 */       return url;
/*      */     } 
/*      */     
/* 1021 */     if (isEncodeable(absolute)) {
/*      */       
/* 1023 */       if (url.equalsIgnoreCase("")) {
/* 1024 */         url = absolute;
/* 1025 */       } else if (url.equals(absolute) && !hasPath(url)) {
/* 1026 */         url = url + "/";
/*      */       } 
/* 1028 */       return toEncoded(url, this.request.getSessionInternal().getIdInternal());
/*      */     } 
/* 1030 */     return url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendAcknowledgement(ContinueResponseTiming continueResponseTiming) throws IOException {
/* 1046 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1051 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1055 */     getCoyoteResponse().action(ActionCode.ACK, continueResponseTiming);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEarlyHints() {
/* 1060 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1065 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1069 */     getCoyoteResponse().action(ActionCode.EARLY_HINTS, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendError(int status) throws IOException {
/* 1085 */     sendError(status, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendError(int status, String message) throws IOException {
/* 1102 */     if (isCommitted()) {
/* 1103 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendError.ise"));
/*      */     }
/*      */ 
/*      */     
/* 1107 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1111 */     if (103 == status) {
/* 1112 */       sendEarlyHints();
/*      */     } else {
/* 1114 */       setError();
/*      */       
/* 1116 */       getCoyoteResponse().setStatus(status);
/* 1117 */       getCoyoteResponse().setMessage(message);
/*      */ 
/*      */       
/* 1120 */       resetBuffer();
/*      */ 
/*      */       
/* 1123 */       setSuspended(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendRedirect(String location) throws IOException {
/* 1130 */     sendRedirect(location, 302);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendRedirect(String location, int status) throws IOException {
/* 1144 */     if (isCommitted()) {
/* 1145 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendRedirect.ise"));
/*      */     }
/*      */ 
/*      */     
/* 1149 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1154 */     resetBuffer(true);
/*      */     
/*      */     try {
/*      */       String locationUri;
/* 1158 */       Context context = getContext();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1164 */       if (getRequest().getCoyoteRequest().getSupportsRelativeRedirects() && (context == null || context
/* 1165 */         .getUseRelativeRedirects())) {
/* 1166 */         locationUri = location;
/*      */       } else {
/* 1168 */         locationUri = toAbsolute(location);
/*      */       } 
/* 1170 */       setStatus(status);
/* 1171 */       setHeader("Location", locationUri);
/* 1172 */       if (context != null && context.getSendRedirectBody()) {
/* 1173 */         PrintWriter writer = getWriter();
/* 1174 */         writer.print(sm.getString("coyoteResponse.sendRedirect.note", new Object[] { Escape.htmlElementContent(locationUri) }));
/* 1175 */         flushBuffer();
/*      */       } 
/* 1177 */     } catch (IllegalArgumentException e) {
/* 1178 */       log.warn(sm.getString("response.sendRedirectFail", new Object[] { location }), e);
/* 1179 */       setStatus(404);
/*      */     } 
/*      */ 
/*      */     
/* 1183 */     setSuspended(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateHeader(String name, long value) {
/* 1190 */     if (name == null || name.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/* 1194 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1199 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1203 */     setHeader(name, FastHttpDateFormat.formatDate(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeader(String name, String value) {
/* 1210 */     if (name == null || name.isEmpty() || value == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1214 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1219 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1223 */     char cc = name.charAt(0);
/* 1224 */     if ((cc == 'C' || cc == 'c') && 
/* 1225 */       checkSpecialHeader(name, value)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1230 */     getCoyoteResponse().setHeader(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIntHeader(String name, int value) {
/* 1237 */     if (name == null || name.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/* 1241 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1246 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1250 */     setHeader(name, "" + value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStatus(int status) {
/* 1258 */     if (isCommitted()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1263 */     if (this.included) {
/*      */       return;
/*      */     }
/*      */     
/* 1267 */     getCoyoteResponse().setStatus(status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isEncodeable(String location) {
/* 1288 */     if (location == null) {
/* 1289 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1293 */     if (location.startsWith("#")) {
/* 1294 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1298 */     Request hreq = this.request;
/* 1299 */     Session session = hreq.getSessionInternal(false);
/* 1300 */     if (session == null) {
/* 1301 */       return false;
/*      */     }
/* 1303 */     if (hreq.isRequestedSessionIdFromCookie()) {
/* 1304 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1308 */     if (!hreq.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.URL)) {
/* 1309 */       return false;
/*      */     }
/*      */     
/* 1312 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */       
/* 1314 */       Boolean result = AccessController.<Boolean>doPrivileged(new PrivilegedDoIsEncodable(getContext(), hreq, session, location));
/* 1315 */       return result.booleanValue();
/*      */     } 
/* 1317 */     return doIsEncodeable(getContext(), hreq, session, location);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean doIsEncodeable(Context context, Request hreq, Session session, String location) {
/*      */     URL url;
/*      */     try {
/* 1326 */       URI uri = new URI(location);
/* 1327 */       url = uri.toURL();
/* 1328 */     } catch (MalformedURLException|java.net.URISyntaxException|IllegalArgumentException e) {
/* 1329 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1333 */     if (!hreq.getScheme().equalsIgnoreCase(url.getProtocol())) {
/* 1334 */       return false;
/*      */     }
/* 1336 */     if (!hreq.getServerName().equalsIgnoreCase(url.getHost())) {
/* 1337 */       return false;
/*      */     }
/* 1339 */     int serverPort = hreq.getServerPort();
/* 1340 */     if (serverPort == -1) {
/* 1341 */       if ("https".equals(hreq.getScheme())) {
/* 1342 */         serverPort = 443;
/*      */       } else {
/* 1344 */         serverPort = 80;
/*      */       } 
/*      */     }
/* 1347 */     int urlPort = url.getPort();
/* 1348 */     if (urlPort == -1) {
/* 1349 */       if ("https".equals(url.getProtocol())) {
/* 1350 */         urlPort = 443;
/*      */       } else {
/* 1352 */         urlPort = 80;
/*      */       } 
/*      */     }
/* 1355 */     if (serverPort != urlPort) {
/* 1356 */       return false;
/*      */     }
/*      */     
/* 1359 */     String contextPath = context.getPath();
/* 1360 */     if (contextPath != null) {
/* 1361 */       String file = url.getFile();
/* 1362 */       if (!file.startsWith(contextPath)) {
/* 1363 */         return false;
/*      */       }
/* 1365 */       String tok = ";" + SessionConfig.getSessionUriParamName(context) + "=" + session.getIdInternal();
/* 1366 */       return (file.indexOf(tok, contextPath.length()) < 0);
/*      */     } 
/*      */ 
/*      */     
/* 1370 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String toAbsolute(String location) {
/* 1388 */     if (location == null) {
/* 1389 */       return null;
/*      */     }
/*      */     
/* 1392 */     boolean leadingSlash = location.startsWith("/");
/*      */     
/* 1394 */     if (location.startsWith("//")) {
/*      */       
/* 1396 */       this.redirectURLCC.recycle();
/*      */       
/* 1398 */       String scheme = this.request.getScheme();
/*      */       try {
/* 1400 */         this.redirectURLCC.append(scheme, 0, scheme.length());
/* 1401 */         this.redirectURLCC.append(':');
/* 1402 */         this.redirectURLCC.append(location, 0, location.length());
/* 1403 */         return this.redirectURLCC.toString();
/* 1404 */       } catch (IOException ioe) {
/* 1405 */         throw new IllegalArgumentException(location, ioe);
/*      */       } 
/*      */     } 
/* 1408 */     if (leadingSlash || !UriUtil.hasScheme(location)) {
/*      */       
/* 1410 */       this.redirectURLCC.recycle();
/*      */       
/* 1412 */       String scheme = this.request.getScheme();
/* 1413 */       String name = this.request.getServerName();
/* 1414 */       int port = this.request.getServerPort();
/*      */       
/*      */       try {
/* 1417 */         this.redirectURLCC.append(scheme, 0, scheme.length());
/* 1418 */         this.redirectURLCC.append("://", 0, 3);
/* 1419 */         this.redirectURLCC.append(name, 0, name.length());
/* 1420 */         if ((scheme.equals("http") && port != 80) || (scheme.equals("https") && port != 443)) {
/* 1421 */           this.redirectURLCC.append(':');
/* 1422 */           String portS = "" + port;
/* 1423 */           this.redirectURLCC.append(portS, 0, portS.length());
/*      */         } 
/* 1425 */         if (!leadingSlash) {
/* 1426 */           String relativePath = this.request.getDecodedRequestURI();
/* 1427 */           int pos = relativePath.lastIndexOf('/');
/* 1428 */           CharChunk encodedURI = null;
/* 1429 */           if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */             
/*      */             try {
/* 1432 */               encodedURI = AccessController.<CharChunk>doPrivileged(new PrivilegedEncodeUrl(this.urlEncoder, relativePath, pos));
/* 1433 */             } catch (PrivilegedActionException pae) {
/* 1434 */               throw new IllegalArgumentException(location, pae.getException());
/*      */             } 
/*      */           } else {
/* 1437 */             encodedURI = this.urlEncoder.encodeURL(relativePath, 0, pos);
/*      */           } 
/* 1439 */           this.redirectURLCC.append(encodedURI);
/* 1440 */           encodedURI.recycle();
/* 1441 */           this.redirectURLCC.append('/');
/*      */         } 
/* 1443 */         this.redirectURLCC.append(location, 0, location.length());
/*      */         
/* 1445 */         normalize(this.redirectURLCC);
/* 1446 */       } catch (IOException ioe) {
/* 1447 */         throw new IllegalArgumentException(location, ioe);
/*      */       } 
/*      */       
/* 1450 */       return this.redirectURLCC.toString();
/*      */     } 
/*      */ 
/*      */     
/* 1454 */     return location;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void normalize(CharChunk cc) {
/* 1468 */     int truncate = cc.indexOf('?');
/* 1469 */     if (truncate == -1) {
/* 1470 */       truncate = cc.indexOf('#');
/*      */     }
/* 1472 */     char[] truncateCC = null;
/* 1473 */     if (truncate > -1) {
/* 1474 */       truncateCC = Arrays.copyOfRange(cc.getBuffer(), cc.getStart() + truncate, cc.getEnd());
/* 1475 */       cc.setEnd(cc.getStart() + truncate);
/*      */     } 
/*      */     
/* 1478 */     if (cc.endsWith("/.") || cc.endsWith("/..")) {
/*      */       try {
/* 1480 */         cc.append('/');
/* 1481 */       } catch (IOException ioe) {
/* 1482 */         throw new IllegalArgumentException(cc.toString(), ioe);
/*      */       } 
/*      */     }
/*      */     
/* 1486 */     char[] c = cc.getChars();
/* 1487 */     int start = cc.getStart();
/* 1488 */     int end = cc.getEnd();
/* 1489 */     int startIndex = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     for (int i = 0; i < 3; i++) {
/* 1495 */       startIndex = cc.indexOf('/', startIndex + 1);
/*      */     }
/*      */ 
/*      */     
/* 1499 */     int index = startIndex;
/*      */     while (true) {
/* 1501 */       index = cc.indexOf("/./", 0, 3, index);
/* 1502 */       if (index < 0) {
/*      */         break;
/*      */       }
/* 1505 */       copyChars(c, start + index, start + index + 2, end - start - index - 2);
/* 1506 */       end -= 2;
/* 1507 */       cc.setEnd(end);
/*      */     } 
/*      */ 
/*      */     
/* 1511 */     index = startIndex;
/*      */     
/*      */     while (true) {
/* 1514 */       index = cc.indexOf("/../", 0, 4, index);
/* 1515 */       if (index < 0) {
/*      */         break;
/*      */       }
/*      */       
/* 1519 */       if (index == startIndex) {
/* 1520 */         throw new IllegalArgumentException();
/*      */       }
/* 1522 */       int index2 = -1;
/* 1523 */       for (int pos = start + index - 1; pos >= 0 && index2 < 0; pos--) {
/* 1524 */         if (c[pos] == '/') {
/* 1525 */           index2 = pos;
/*      */         }
/*      */       } 
/* 1528 */       copyChars(c, start + index2, start + index + 3, end - start - index - 3);
/* 1529 */       end = end + index2 - index - 3;
/* 1530 */       cc.setEnd(end);
/* 1531 */       index = index2;
/*      */     } 
/*      */ 
/*      */     
/* 1535 */     if (truncateCC != null) {
/*      */       try {
/* 1537 */         cc.append(truncateCC, 0, truncateCC.length);
/* 1538 */       } catch (IOException ioe) {
/* 1539 */         throw new IllegalArgumentException(ioe);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void copyChars(char[] c, int dest, int src, int len) {
/* 1545 */     System.arraycopy(c, src, c, dest, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasPath(String uri) {
/* 1557 */     int pos = uri.indexOf("://");
/* 1558 */     if (pos < 0) {
/* 1559 */       return false;
/*      */     }
/* 1561 */     pos = uri.indexOf('/', pos + 3);
/* 1562 */     return (pos >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String toEncoded(String url, String sessionId) {
/* 1574 */     if (url == null || sessionId == null) {
/* 1575 */       return url;
/*      */     }
/*      */     
/* 1578 */     String path = url;
/* 1579 */     String query = "";
/* 1580 */     String anchor = "";
/* 1581 */     int question = url.indexOf('?');
/* 1582 */     if (question >= 0) {
/* 1583 */       path = url.substring(0, question);
/* 1584 */       query = url.substring(question);
/*      */     } 
/* 1586 */     int pound = path.indexOf('#');
/* 1587 */     if (pound >= 0) {
/* 1588 */       anchor = path.substring(pound);
/* 1589 */       path = path.substring(0, pound);
/*      */     } 
/* 1591 */     StringBuilder sb = new StringBuilder(path);
/* 1592 */     if (sb.length() > 0) {
/* 1593 */       sb.append(';');
/* 1594 */       sb.append(SessionConfig.getSessionUriParamName(this.request.getContext()));
/* 1595 */       sb.append('=');
/* 1596 */       sb.append(sessionId);
/*      */     } 
/* 1598 */     sb.append(anchor);
/* 1599 */     sb.append(query);
/* 1600 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private static class PrivilegedGenerateCookieString
/*      */     implements PrivilegedAction<String>
/*      */   {
/*      */     private final Context context;
/*      */     private final Cookie cookie;
/*      */     private final HttpServletRequest request;
/*      */     
/*      */     PrivilegedGenerateCookieString(Context context, Cookie cookie, HttpServletRequest request) {
/* 1611 */       this.context = context;
/* 1612 */       this.cookie = cookie;
/* 1613 */       this.request = request;
/*      */     }
/*      */ 
/*      */     
/*      */     public String run() {
/* 1618 */       return this.context.getCookieProcessor().generateHeader(this.cookie, this.request);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrivilegedDoIsEncodable
/*      */     implements PrivilegedAction<Boolean>
/*      */   {
/*      */     private final Context context;
/*      */     private final Request hreq;
/*      */     private final Session session;
/*      */     private final String location;
/*      */     
/*      */     PrivilegedDoIsEncodable(Context context, Request hreq, Session session, String location) {
/* 1631 */       this.context = context;
/* 1632 */       this.hreq = hreq;
/* 1633 */       this.session = session;
/* 1634 */       this.location = location;
/*      */     }
/*      */ 
/*      */     
/*      */     public Boolean run() {
/* 1639 */       return Boolean.valueOf(Response.doIsEncodeable(this.context, this.hreq, this.session, this.location));
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrivilegedEncodeUrl
/*      */     implements PrivilegedExceptionAction<CharChunk>
/*      */   {
/*      */     private final UEncoder urlEncoder;
/*      */     private final String relativePath;
/*      */     private final int end;
/*      */     
/*      */     PrivilegedEncodeUrl(UEncoder urlEncoder, String relativePath, int end) {
/* 1651 */       this.urlEncoder = urlEncoder;
/* 1652 */       this.relativePath = relativePath;
/* 1653 */       this.end = end;
/*      */     }
/*      */ 
/*      */     
/*      */     public CharChunk run() throws IOException {
/* 1658 */       return this.urlEncoder.encodeURL(this.relativePath, 0, this.end);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\Response.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */