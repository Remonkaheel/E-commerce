/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import jakarta.servlet.ReadListener;
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.SessionTrackingMode;
/*      */ import jakarta.servlet.WriteListener;
/*      */ import java.io.IOException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.EnumSet;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.core.AsyncContextImpl;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.Adapter;
/*      */ import org.apache.coyote.Request;
/*      */ import org.apache.coyote.Response;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.ByteChunk;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.HexUtils;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.http.ServerCookie;
/*      */ import org.apache.tomcat.util.http.ServerCookies;
/*      */ import org.apache.tomcat.util.net.SocketEvent;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CoyoteAdapter
/*      */   implements Adapter
/*      */ {
/*   64 */   private static final Log log = LogFactory.getLog(CoyoteAdapter.class);
/*      */ 
/*      */ 
/*      */   
/*   68 */   private static final String POWERED_BY = "Servlet/6.0 JSP/3.1 (" + ServerInfo.getServerInfo() + " Java/" + 
/*   69 */     System.getProperty("java.vm.vendor") + "/" + System.getProperty("java.runtime.version") + ")";
/*      */   
/*   71 */   private static final EnumSet<SessionTrackingMode> SSL_ONLY = EnumSet.of(SessionTrackingMode.SSL);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ADAPTER_NOTES = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   private final Connector connector;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoyoteAdapter(Connector connector) {
/*   86 */     this.connector = connector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   protected static final StringManager sm = StringManager.getManager(CoyoteAdapter.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean asyncDispatch(Request req, Response res, SocketEvent status) throws Exception {
/*  112 */     Request request = (Request)req.getNote(1);
/*  113 */     Response response = (Response)res.getNote(1);
/*      */     
/*  115 */     if (request == null) {
/*  116 */       throw new IllegalStateException(sm.getString("coyoteAdapter.nullRequest"));
/*      */     }
/*      */     
/*  119 */     boolean success = true;
/*  120 */     AsyncContextImpl asyncConImpl = request.getAsyncContextInternal();
/*      */     
/*  122 */     req.setRequestThread();
/*      */     
/*      */     try {
/*  125 */       if (!request.isAsync())
/*      */       {
/*      */ 
/*      */         
/*  129 */         response.setSuspended(false);
/*      */       }
/*      */       
/*  132 */       if (status == SocketEvent.TIMEOUT) {
/*  133 */         if (!asyncConImpl.timeout()) {
/*  134 */           asyncConImpl.setErrorState(null, false);
/*      */         }
/*  136 */       } else if (status == SocketEvent.ERROR) {
/*      */ 
/*      */ 
/*      */         
/*  140 */         success = false;
/*  141 */         Throwable t = (Throwable)req.getAttribute("jakarta.servlet.error.exception");
/*  142 */         Context context = request.getContext();
/*  143 */         ClassLoader oldCL = null;
/*      */         try {
/*  145 */           oldCL = context.bind(false, null);
/*  146 */           if (req.getReadListener() != null) {
/*  147 */             req.getReadListener().onError(t);
/*      */           }
/*  149 */           if (res.getWriteListener() != null) {
/*  150 */             res.getWriteListener().onError(t);
/*      */           }
/*  152 */           res.action(ActionCode.CLOSE_NOW, t);
/*  153 */           asyncConImpl.setErrorState(t, true);
/*      */         } finally {
/*  155 */           context.unbind(false, oldCL);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  160 */       if (!request.isAsyncDispatching() && request.isAsync()) {
/*  161 */         WriteListener writeListener = res.getWriteListener();
/*  162 */         ReadListener readListener = req.getReadListener();
/*  163 */         if (writeListener != null && status == SocketEvent.OPEN_WRITE) {
/*  164 */           Context context = request.getContext();
/*  165 */           ClassLoader oldCL = null;
/*      */           try {
/*  167 */             oldCL = context.bind(false, null);
/*  168 */             res.onWritePossible();
/*  169 */             if (request.isFinished() && req.sendAllDataReadEvent() && readListener != null) {
/*  170 */               readListener.onAllDataRead();
/*      */             }
/*      */             
/*  173 */             if (response.getCoyoteResponse().isExceptionPresent()) {
/*  174 */               throw response.getCoyoteResponse().getErrorException();
/*      */             }
/*  176 */           } catch (Throwable t) {
/*  177 */             ExceptionUtils.handleThrowable(t);
/*      */             
/*  179 */             response.setSuspended(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  185 */             writeListener.onError(t);
/*  186 */             res.action(ActionCode.CLOSE_NOW, t);
/*  187 */             asyncConImpl.setErrorState(t, true);
/*      */           } finally {
/*  189 */             context.unbind(false, oldCL);
/*      */           } 
/*  191 */         } else if (readListener != null && status == SocketEvent.OPEN_READ) {
/*  192 */           Context context = request.getContext();
/*  193 */           ClassLoader oldCL = null;
/*      */           try {
/*  195 */             oldCL = context.bind(false, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  201 */             if (!request.isFinished()) {
/*  202 */               req.onDataAvailable();
/*      */             }
/*  204 */             if (request.isFinished() && req.sendAllDataReadEvent()) {
/*  205 */               readListener.onAllDataRead();
/*      */             }
/*      */             
/*  208 */             if (request.getCoyoteRequest().isExceptionPresent()) {
/*  209 */               throw request.getCoyoteRequest().getErrorException();
/*      */             }
/*  211 */           } catch (Throwable t) {
/*  212 */             ExceptionUtils.handleThrowable(t);
/*      */             
/*  214 */             response.setSuspended(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  220 */             readListener.onError(t);
/*  221 */             res.action(ActionCode.CLOSE_NOW, t);
/*  222 */             asyncConImpl.setErrorState(t, true);
/*      */           } finally {
/*  224 */             context.unbind(false, oldCL);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  232 */       if (!request.isAsyncDispatching() && request.isAsync() && response.isErrorReportRequired()) {
/*  233 */         this.connector.getService().getContainer().getPipeline().getFirst().invoke(request, response);
/*      */       }
/*      */       
/*  236 */       if (request.isAsyncDispatching()) {
/*  237 */         this.connector.getService().getContainer().getPipeline().getFirst().invoke(request, response);
/*  238 */         if (response.isError()) {
/*  239 */           Throwable t = (Throwable)request.getAttribute("jakarta.servlet.error.exception");
/*  240 */           asyncConImpl.setErrorState(t, true);
/*      */         } 
/*      */       } 
/*      */       
/*  244 */       if (!request.isAsync()) {
/*  245 */         request.finishRequest();
/*  246 */         response.finishResponse();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  251 */       AtomicBoolean error = new AtomicBoolean(false);
/*  252 */       res.action(ActionCode.IS_ERROR, error);
/*  253 */       if (error.get()) {
/*  254 */         if (request.isAsyncCompleting() || request.isAsyncDispatching())
/*      */         {
/*      */           
/*  257 */           res.action(ActionCode.ASYNC_POST_PROCESS, null);
/*      */         }
/*  259 */         success = false;
/*      */       } 
/*  261 */     } catch (IOException ioe) {
/*      */       
/*  263 */       success = false;
/*  264 */     } catch (Throwable t) {
/*  265 */       ExceptionUtils.handleThrowable(t);
/*  266 */       success = false;
/*  267 */       log.error(sm.getString("coyoteAdapter.asyncDispatch"), t);
/*      */     } finally {
/*  269 */       if (!success) {
/*  270 */         res.setStatus(500);
/*      */       }
/*      */ 
/*      */       
/*  274 */       if (!success || !request.isAsync()) {
/*  275 */         long time = 0L;
/*  276 */         if (req.getStartTimeNanos() != -1L) {
/*  277 */           time = System.nanoTime() - req.getStartTimeNanos();
/*      */         }
/*  279 */         Context context = request.getContext();
/*  280 */         if (context != null) {
/*  281 */           context.logAccess(request, response, time, false);
/*      */         } else {
/*  283 */           log(req, res, time);
/*      */         } 
/*      */       } 
/*      */       
/*  287 */       req.getRequestProcessor().setWorkerThreadName(null);
/*  288 */       req.clearRequestThread();
/*      */       
/*  290 */       if (!success || !request.isAsync()) {
/*  291 */         updateWrapperErrorCount(request, response);
/*  292 */         request.recycle();
/*  293 */         response.recycle();
/*      */       } 
/*      */     } 
/*  296 */     return success;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void service(Request req, Response res) throws Exception {
/*  303 */     Request request = (Request)req.getNote(1);
/*  304 */     Response response = (Response)res.getNote(1);
/*      */     
/*  306 */     if (request == null) {
/*      */       
/*  308 */       request = this.connector.createRequest();
/*  309 */       request.setCoyoteRequest(req);
/*  310 */       response = this.connector.createResponse();
/*  311 */       response.setCoyoteResponse(res);
/*      */ 
/*      */       
/*  314 */       request.setResponse(response);
/*  315 */       response.setRequest(request);
/*      */ 
/*      */       
/*  318 */       req.setNote(1, request);
/*  319 */       res.setNote(1, response);
/*      */ 
/*      */       
/*  322 */       req.getParameters().setQueryStringCharset(this.connector.getURICharset());
/*      */     } 
/*      */     
/*  325 */     if (this.connector.getXpoweredBy()) {
/*  326 */       response.addHeader("X-Powered-By", POWERED_BY);
/*      */     }
/*      */     
/*  329 */     boolean async = false;
/*  330 */     boolean postParseSuccess = false;
/*      */     
/*  332 */     req.setRequestThread();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  337 */       postParseSuccess = postParseRequest(req, request, res, response);
/*  338 */       if (postParseSuccess) {
/*      */         
/*  340 */         request.setAsyncSupported(this.connector.getService().getContainer().getPipeline().isAsyncSupported());
/*      */         
/*  342 */         this.connector.getService().getContainer().getPipeline().getFirst().invoke(request, response);
/*      */       } 
/*  344 */       if (request.isAsync()) {
/*  345 */         async = true;
/*  346 */         ReadListener readListener = req.getReadListener();
/*  347 */         if (readListener != null && request.isFinished()) {
/*      */ 
/*      */           
/*  350 */           ClassLoader oldCL = null;
/*      */           try {
/*  352 */             oldCL = request.getContext().bind(false, null);
/*  353 */             if (req.sendAllDataReadEvent()) {
/*  354 */               req.getReadListener().onAllDataRead();
/*      */             }
/*      */           } finally {
/*  357 */             request.getContext().unbind(false, oldCL);
/*      */           } 
/*      */         } 
/*      */         
/*  361 */         Throwable throwable = (Throwable)request.getAttribute("jakarta.servlet.error.exception");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  366 */         if (!request.isAsyncCompleting() && throwable != null) {
/*  367 */           request.getAsyncContextInternal().setErrorState(throwable, true);
/*      */         }
/*      */       } else {
/*  370 */         request.finishRequest();
/*  371 */         response.finishResponse();
/*      */       }
/*      */     
/*  374 */     } catch (IOException iOException) {
/*      */     
/*      */     } finally {
/*  377 */       AtomicBoolean error = new AtomicBoolean(false);
/*  378 */       res.action(ActionCode.IS_ERROR, error);
/*      */       
/*  380 */       if (request.isAsyncCompleting() && error.get()) {
/*      */ 
/*      */ 
/*      */         
/*  384 */         res.action(ActionCode.ASYNC_POST_PROCESS, null);
/*  385 */         async = false;
/*      */       } 
/*      */ 
/*      */       
/*  389 */       if (!async && postParseSuccess) {
/*      */ 
/*      */         
/*  392 */         Context context = request.getContext();
/*  393 */         Host host = request.getHost();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  402 */         long time = System.nanoTime() - req.getStartTimeNanos();
/*  403 */         if (context != null) {
/*  404 */           context.logAccess(request, response, time, false);
/*  405 */         } else if (response.isError()) {
/*  406 */           if (host != null) {
/*  407 */             host.logAccess(request, response, time, false);
/*      */           } else {
/*  409 */             this.connector.getService().getContainer().logAccess(request, response, time, false);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  414 */       req.getRequestProcessor().setWorkerThreadName(null);
/*  415 */       req.clearRequestThread();
/*      */ 
/*      */       
/*  418 */       if (!async) {
/*  419 */         updateWrapperErrorCount(request, response);
/*  420 */         request.recycle();
/*  421 */         response.recycle();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateWrapperErrorCount(Request request, Response response) {
/*  428 */     if (response.isError()) {
/*  429 */       Wrapper wrapper = request.getWrapper();
/*  430 */       if (wrapper != null) {
/*  431 */         wrapper.incrementErrorCount();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean prepare(Request req, Response res) throws IOException, ServletException {
/*  440 */     Request request = (Request)req.getNote(1);
/*  441 */     Response response = (Response)res.getNote(1);
/*      */     
/*  443 */     return postParseRequest(req, request, res, response);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Request req, Response res, long time) {
/*  450 */     Request request = (Request)req.getNote(1);
/*  451 */     Response response = (Response)res.getNote(1);
/*      */     
/*  453 */     if (request == null) {
/*      */       
/*  455 */       request = this.connector.createRequest();
/*  456 */       request.setCoyoteRequest(req);
/*  457 */       response = this.connector.createResponse();
/*  458 */       response.setCoyoteResponse(res);
/*      */ 
/*      */       
/*  461 */       request.setResponse(response);
/*  462 */       response.setRequest(request);
/*      */ 
/*      */       
/*  465 */       req.setNote(1, request);
/*  466 */       res.setNote(1, response);
/*      */ 
/*      */       
/*  469 */       req.getParameters().setQueryStringCharset(this.connector.getURICharset());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  475 */       boolean logged = false;
/*  476 */       Context context = request.mappingData.context;
/*  477 */       Host host = request.mappingData.host;
/*  478 */       if (context != null) {
/*  479 */         logged = true;
/*  480 */         context.logAccess(request, response, time, true);
/*  481 */       } else if (host != null) {
/*  482 */         logged = true;
/*  483 */         host.logAccess(request, response, time, true);
/*      */       } 
/*  485 */       if (!logged) {
/*  486 */         this.connector.getService().getContainer().logAccess(request, response, time, true);
/*      */       }
/*  488 */     } catch (Throwable t) {
/*  489 */       ExceptionUtils.handleThrowable(t);
/*  490 */       log.warn(sm.getString("coyoteAdapter.accesslogFail"), t);
/*      */     } finally {
/*  492 */       updateWrapperErrorCount(request, response);
/*  493 */       request.recycle();
/*  494 */       response.recycle();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class RecycleRequiredException
/*      */     extends Exception
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */   }
/*      */   
/*      */   public void checkRecycled(Request req, Response res) {
/*  505 */     Request request = (Request)req.getNote(1);
/*  506 */     Response response = (Response)res.getNote(1);
/*  507 */     String messageKey = null;
/*  508 */     if (request != null && request.getHost() != null) {
/*  509 */       messageKey = "coyoteAdapter.checkRecycled.request";
/*  510 */     } else if (response != null && response.getContentWritten() != 0L) {
/*  511 */       messageKey = "coyoteAdapter.checkRecycled.response";
/*      */     } 
/*  513 */     if (messageKey != null) {
/*      */ 
/*      */       
/*  516 */       log(req, res, 0L);
/*      */       
/*  518 */       if (this.connector.getState().isAvailable()) {
/*  519 */         if (log.isInfoEnabled()) {
/*  520 */           log.info(sm.getString(messageKey), new RecycleRequiredException());
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  526 */       else if (log.isDebugEnabled()) {
/*  527 */         log.debug(sm.getString(messageKey), new RecycleRequiredException());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDomain() {
/*  536 */     return this.connector.getDomain();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean postParseRequest(Request req, Request request, Response res, Response response) throws IOException, ServletException {
/*      */     MessageBytes serverName;
/*  564 */     if (req.scheme().isNull()) {
/*      */ 
/*      */       
/*  567 */       req.scheme().setString(this.connector.getScheme());
/*  568 */       request.setSecure(this.connector.getSecure());
/*      */     } else {
/*      */       
/*  571 */       request.setSecure(req.scheme().equals("https"));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  576 */     String proxyName = this.connector.getProxyName();
/*  577 */     int proxyPort = this.connector.getProxyPort();
/*  578 */     if (proxyPort != 0) {
/*  579 */       req.setServerPort(proxyPort);
/*  580 */     } else if (req.getServerPort() == -1) {
/*      */       
/*  582 */       if (req.scheme().equals("https")) {
/*  583 */         req.setServerPort(443);
/*      */       } else {
/*  585 */         req.setServerPort(80);
/*      */       } 
/*      */     } 
/*  588 */     if (proxyName != null) {
/*  589 */       req.serverName().setString(proxyName);
/*      */     }
/*      */     
/*  592 */     MessageBytes undecodedURI = req.requestURI();
/*      */ 
/*      */     
/*  595 */     if (undecodedURI.equals("*")) {
/*  596 */       if ("OPTIONS".equals(req.getMethod())) {
/*  597 */         StringBuilder allow = new StringBuilder();
/*  598 */         allow.append("GET, HEAD, POST, PUT, DELETE, OPTIONS");
/*      */         
/*  600 */         if (this.connector.getAllowTrace()) {
/*  601 */           allow.append(", TRACE");
/*      */         }
/*  603 */         res.setHeader("Allow", allow.toString());
/*      */         
/*  605 */         this.connector.getService().getContainer().logAccess(request, response, 0L, true);
/*  606 */         return false;
/*      */       } 
/*  608 */       response.sendError(400, sm.getString("coyoteAdapter.invalidURI"));
/*      */     } 
/*      */ 
/*      */     
/*  612 */     MessageBytes decodedURI = req.decodedURI();
/*      */ 
/*      */     
/*  615 */     if ("CONNECT".equals(req.getMethod())) {
/*  616 */       response.sendError(501, sm.getString("coyoteAdapter.connect"));
/*      */     
/*      */     }
/*  619 */     else if (undecodedURI.getType() == 2) {
/*  620 */       if (this.connector.getRejectSuspiciousURIs() && 
/*  621 */         checkSuspiciousURIs(undecodedURI.getByteChunk())) {
/*  622 */         response.sendError(400, sm.getString("coyoteAdapter.invalidURI"));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  627 */       decodedURI.duplicate(undecodedURI);
/*      */ 
/*      */       
/*  630 */       parsePathParameters(req, request);
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  635 */         req.getURLDecoder().convert(decodedURI.getByteChunk(), this.connector
/*  636 */             .getEncodedSolidusHandlingInternal(), this.connector
/*  637 */             .getEncodedReverseSolidusHandlingInternal());
/*  638 */       } catch (IOException ioe) {
/*  639 */         response.sendError(400, sm.getString("coyoteAdapter.invalidURIWithMessage", new Object[] { ioe.getMessage() }));
/*      */       } 
/*      */       
/*  642 */       if (normalize(req.decodedURI(), this.connector.getAllowBackslash()))
/*      */       {
/*  644 */         convertURI(decodedURI, request);
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  649 */         response.sendError(400, sm.getString("coyoteAdapter.invalidURI"));
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  664 */       decodedURI.toChars();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  670 */     if (this.connector.getUseIPVHosts()) {
/*  671 */       serverName = req.localName();
/*  672 */       if (serverName.isNull())
/*      */       {
/*  674 */         res.action(ActionCode.REQ_LOCAL_NAME_ATTRIBUTE, null);
/*      */       }
/*      */     } else {
/*  677 */       serverName = req.serverName();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  682 */     String version = null;
/*  683 */     Context versionContext = null;
/*  684 */     boolean mapRequired = true;
/*      */     
/*  686 */     if (response.isError())
/*      */     {
/*      */ 
/*      */       
/*  690 */       decodedURI.recycle();
/*      */     }
/*      */     
/*  693 */     while (mapRequired) {
/*      */       
/*  695 */       this.connector.getService().getMapper().map(serverName, decodedURI, version, request.getMappingData());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  700 */       if (request.getContext() == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  708 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  715 */       if (request.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.URL)) {
/*      */ 
/*      */         
/*  718 */         String str = request.getPathParameter(SessionConfig.getSessionUriParamName(request.getContext()));
/*  719 */         if (str != null) {
/*  720 */           request.setRequestedSessionId(str);
/*  721 */           request.setRequestedSessionURL(true);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  727 */         parseSessionCookiesId(request);
/*  728 */       } catch (IllegalArgumentException e) {
/*      */         
/*  730 */         if (!response.isError()) {
/*  731 */           response.setError();
/*  732 */           response.sendError(400, e.getMessage());
/*      */         } 
/*  734 */         return true;
/*      */       } 
/*  736 */       parseSessionSslId(request);
/*      */       
/*  738 */       String sessionID = request.getRequestedSessionId();
/*      */       
/*  740 */       mapRequired = false;
/*  741 */       if (version == null || request.getContext() != versionContext) {
/*      */ 
/*      */         
/*  744 */         version = null;
/*  745 */         versionContext = null;
/*      */         
/*  747 */         Context[] contexts = (request.getMappingData()).contexts;
/*      */ 
/*      */         
/*  750 */         if (contexts != null && sessionID != null)
/*      */         {
/*  752 */           for (int i = contexts.length; i > 0; i--) {
/*  753 */             Context ctxt = contexts[i - 1];
/*  754 */             if (ctxt.getManager().findSession(sessionID) != null) {
/*      */ 
/*      */               
/*  757 */               if (!ctxt.equals((request.getMappingData()).context)) {
/*      */ 
/*      */                 
/*  760 */                 version = ctxt.getWebappVersion();
/*  761 */                 versionContext = ctxt;
/*      */                 
/*  763 */                 request.getMappingData().recycle();
/*  764 */                 mapRequired = true;
/*      */ 
/*      */ 
/*      */                 
/*  768 */                 request.recycleSessionInfo();
/*  769 */                 request.recycleCookieInfo(true);
/*      */               } 
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*  777 */       if (!mapRequired && request.getContext().getPaused()) {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/*  782 */           Thread.sleep(1000L);
/*  783 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */         
/*  787 */         request.getMappingData().recycle();
/*  788 */         mapRequired = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  793 */     MessageBytes redirectPathMB = (request.getMappingData()).redirectPath;
/*  794 */     if (!redirectPathMB.isNull()) {
/*  795 */       String redirectPath = URLEncoder.DEFAULT.encode(redirectPathMB.toString(), StandardCharsets.UTF_8);
/*  796 */       String query = request.getQueryString();
/*  797 */       if (request.isRequestedSessionIdFromURL())
/*      */       {
/*      */ 
/*      */         
/*  801 */         redirectPath = redirectPath + ";" + redirectPath + "=" + SessionConfig.getSessionUriParamName(request.getContext());
/*      */       }
/*  803 */       if (query != null)
/*      */       {
/*      */         
/*  806 */         redirectPath = redirectPath + "?" + redirectPath;
/*      */       }
/*  808 */       response.sendRedirect(redirectPath);
/*  809 */       request.getContext().logAccess(request, response, 0L, true);
/*  810 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  814 */     if (!this.connector.getAllowTrace() && "TRACE".equals(req.getMethod())) {
/*  815 */       Wrapper wrapper = request.getWrapper();
/*  816 */       StringBuilder header = null;
/*  817 */       if (wrapper != null) {
/*  818 */         String[] methods = wrapper.getServletMethods();
/*  819 */         if (methods != null)
/*  820 */           for (String method : methods) {
/*  821 */             if (!"TRACE".equals(method))
/*      */             {
/*      */               
/*  824 */               if (header == null) {
/*  825 */                 header = new StringBuilder(method);
/*      */               } else {
/*  827 */                 header.append(", ").append(method);
/*      */               } 
/*      */             }
/*      */           }  
/*      */       } 
/*  832 */       if (header != null) {
/*  833 */         res.addHeader("Allow", header.toString());
/*      */       }
/*  835 */       response.sendError(405, sm.getString("coyoteAdapter.trace"));
/*      */       
/*  837 */       return true;
/*      */     } 
/*      */     
/*  840 */     doConnectorAuthenticationAuthorization(req, request);
/*      */     
/*  842 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void doConnectorAuthenticationAuthorization(Request req, Request request) {
/*  848 */     String username = req.getRemoteUser().toString();
/*  849 */     if (username != null) {
/*  850 */       if (log.isDebugEnabled()) {
/*  851 */         log.debug(sm.getString("coyoteAdapter.authenticate", new Object[] { username }));
/*      */       }
/*  853 */       if (req.getRemoteUserNeedsAuthorization()) {
/*  854 */         Authenticator authenticator = request.getContext().getAuthenticator();
/*  855 */         if (!(authenticator instanceof org.apache.catalina.authenticator.AuthenticatorBase)) {
/*  856 */           if (log.isDebugEnabled()) {
/*  857 */             log.debug(sm.getString("coyoteAdapter.authorize", new Object[] { username }));
/*      */           }
/*      */ 
/*      */           
/*  861 */           request.setUserPrincipal(request.getContext().getRealm().authenticate(username));
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  870 */         request.setUserPrincipal(new CoyotePrincipal(username));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  875 */     String authType = req.getAuthType().toString();
/*  876 */     if (authType != null) {
/*  877 */       request.setAuthType(authType);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parsePathParameters(Request req, Request request) {
/*  893 */     req.decodedURI().toBytes();
/*      */     
/*  895 */     ByteChunk uriBC = req.decodedURI().getByteChunk();
/*      */ 
/*      */ 
/*      */     
/*  899 */     int semicolon = uriBC.indexOf(';', 1);
/*      */ 
/*      */     
/*  902 */     if (semicolon == -1) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  908 */     Charset charset = this.connector.getURICharset();
/*      */     
/*  910 */     if (log.isTraceEnabled()) {
/*  911 */       log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "uriBC", uriBC.toString() }));
/*  912 */       log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "semicolon", String.valueOf(semicolon) }));
/*  913 */       log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "enc", charset.name() }));
/*      */     } 
/*      */     
/*  916 */     while (semicolon > -1) {
/*      */       
/*  918 */       int start = uriBC.getStart();
/*  919 */       int end = uriBC.getEnd();
/*      */       
/*  921 */       int pathParamStart = semicolon + 1;
/*      */       
/*  923 */       int pathParamEnd = ByteChunk.findBytes(uriBC.getBuffer(), start + pathParamStart, end, new byte[] { 59, 47 });
/*      */       
/*  925 */       String pv = null;
/*      */       
/*  927 */       if (pathParamEnd >= 0) {
/*  928 */         if (charset != null) {
/*  929 */           pv = new String(uriBC.getBuffer(), start + pathParamStart, pathParamEnd - pathParamStart, charset);
/*      */         }
/*      */         
/*  932 */         byte[] buf = uriBC.getBuffer();
/*  933 */         for (int i = 0; i < end - start - pathParamEnd; i++) {
/*  934 */           buf[start + semicolon + i] = buf[start + i + pathParamEnd];
/*      */         }
/*  936 */         uriBC.setBytes(buf, start, end - start - pathParamEnd + semicolon);
/*      */       } else {
/*  938 */         if (charset != null) {
/*  939 */           pv = new String(uriBC.getBuffer(), start + pathParamStart, end - start - pathParamStart, charset);
/*      */         }
/*  941 */         uriBC.setEnd(start + semicolon);
/*      */       } 
/*      */       
/*  944 */       if (log.isTraceEnabled()) {
/*  945 */         log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "pathParamStart", String.valueOf(pathParamStart) }));
/*  946 */         log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "pathParamEnd", String.valueOf(pathParamEnd) }));
/*  947 */         log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "pv", pv }));
/*      */       } 
/*      */       
/*  950 */       if (pv != null) {
/*  951 */         int equals = pv.indexOf('=');
/*  952 */         if (equals > -1) {
/*  953 */           String name = pv.substring(0, equals);
/*  954 */           String value = pv.substring(equals + 1);
/*  955 */           request.addPathParameter(name, value);
/*  956 */           if (log.isTraceEnabled()) {
/*  957 */             log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "equals", String.valueOf(equals) }));
/*  958 */             log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "name", name }));
/*  959 */             log.trace(sm.getString("coyoteAdapter.debug", new Object[] { "value", value }));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  964 */       semicolon = uriBC.indexOf(';', semicolon);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseSessionSslId(Request request) {
/*  975 */     if (request.getRequestedSessionId() == null && SSL_ONLY
/*  976 */       .equals(request.getServletContext().getEffectiveSessionTrackingModes()) && request.connector.secure) {
/*      */       
/*  978 */       String sessionId = (String)request.getAttribute("jakarta.servlet.request.ssl_session_id");
/*  979 */       if (sessionId != null) {
/*  980 */         request.setRequestedSessionId(sessionId);
/*  981 */         request.setRequestedSessionSSL(true);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseSessionCookiesId(Request request) {
/*  998 */     Context context = (request.getMappingData()).context;
/*  999 */     if (context != null && 
/* 1000 */       !context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1005 */     ServerCookies serverCookies = request.getServerCookies();
/* 1006 */     int count = serverCookies.getCookieCount();
/* 1007 */     if (count <= 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1011 */     String sessionCookieName = SessionConfig.getSessionCookieName(context);
/*      */     
/* 1013 */     for (int i = 0; i < count; i++) {
/* 1014 */       ServerCookie scookie = serverCookies.getCookie(i);
/* 1015 */       if (scookie.getName().equals(sessionCookieName))
/*      */       {
/* 1017 */         if (!request.isRequestedSessionIdFromCookie()) {
/*      */           
/* 1019 */           convertMB(scookie.getValue());
/* 1020 */           request.setRequestedSessionId(scookie.getValue().toString());
/* 1021 */           request.setRequestedSessionCookie(true);
/* 1022 */           request.setRequestedSessionURL(false);
/* 1023 */           if (log.isTraceEnabled()) {
/* 1024 */             log.trace(" Requested cookie session id is " + request.getRequestedSessionId());
/*      */           }
/*      */         }
/* 1027 */         else if (!request.isRequestedSessionIdValid()) {
/*      */           
/* 1029 */           convertMB(scookie.getValue());
/* 1030 */           request.setRequestedSessionId(scookie.getValue().toString());
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertURI(MessageBytes uri, Request request) throws IOException {
/* 1049 */     ByteChunk bc = uri.getByteChunk();
/* 1050 */     int length = bc.getLength();
/* 1051 */     CharChunk cc = uri.getCharChunk();
/* 1052 */     cc.allocate(length, -1);
/*      */     
/* 1054 */     Charset charset = this.connector.getURICharset();
/*      */     
/* 1056 */     B2CConverter conv = request.getURIConverter();
/* 1057 */     if (conv == null) {
/* 1058 */       conv = new B2CConverter(charset, false);
/* 1059 */       request.setURIConverter(conv);
/*      */     } else {
/* 1061 */       conv.recycle();
/*      */     } 
/*      */     
/*      */     try {
/* 1065 */       conv.convert(bc, cc, true);
/* 1066 */       uri.setChars(cc.getBuffer(), cc.getStart(), cc.getLength());
/* 1067 */     } catch (IOException ioe) {
/*      */ 
/*      */       
/* 1070 */       request.getResponse().sendError(400);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertMB(MessageBytes mb) {
/* 1083 */     if (mb.getType() != 2) {
/*      */       return;
/*      */     }
/*      */     
/* 1087 */     ByteChunk bc = mb.getByteChunk();
/* 1088 */     CharChunk cc = mb.getCharChunk();
/* 1089 */     int length = bc.getLength();
/* 1090 */     cc.allocate(length, -1);
/*      */ 
/*      */     
/* 1093 */     byte[] bbuf = bc.getBuffer();
/* 1094 */     char[] cbuf = cc.getBuffer();
/* 1095 */     int start = bc.getStart();
/* 1096 */     for (int i = 0; i < length; i++) {
/* 1097 */       cbuf[i] = (char)(bbuf[i + start] & 0xFF);
/*      */     }
/* 1099 */     mb.setChars(cbuf, 0, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean normalize(MessageBytes uriMB, boolean allowBackslash) {
/* 1115 */     ByteChunk uriBC = uriMB.getByteChunk();
/* 1116 */     byte[] b = uriBC.getBytes();
/* 1117 */     int start = uriBC.getStart();
/* 1118 */     int end = uriBC.getEnd();
/* 1119 */     boolean appendedSlash = false;
/*      */ 
/*      */     
/* 1122 */     if (start == end) {
/* 1123 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1127 */     if (b[start] != 47 && b[start] != 92) {
/* 1128 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     int pos;
/*      */ 
/*      */     
/* 1135 */     for (pos = start; pos < end; pos++) {
/* 1136 */       if (b[pos] == 92) {
/* 1137 */         if (allowBackslash) {
/* 1138 */           b[pos] = 47;
/*      */         } else {
/* 1140 */           return false;
/*      */         } 
/* 1142 */       } else if (b[pos] == 0) {
/* 1143 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1148 */     for (pos = start; pos < end - 1; pos++) {
/* 1149 */       if (b[pos] == 47) {
/* 1150 */         while (pos + 1 < end && b[pos + 1] == 47) {
/* 1151 */           copyBytes(b, pos, pos + 1, end - pos - 1);
/* 1152 */           end--;
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1160 */     if (end - start >= 2 && b[end - 1] == 46 && (
/* 1161 */       b[end - 2] == 47 || (b[end - 2] == 46 && b[end - 3] == 47))) {
/* 1162 */       b[end] = 47;
/* 1163 */       end++;
/* 1164 */       appendedSlash = true;
/*      */     } 
/*      */ 
/*      */     
/* 1168 */     uriBC.setEnd(end);
/*      */     
/* 1170 */     int index = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 1174 */       index = uriBC.indexOf("/./", 0, 3, index);
/* 1175 */       if (index < 0) {
/*      */         break;
/*      */       }
/* 1178 */       copyBytes(b, start + index, start + index + 2, end - start - index - 2);
/* 1179 */       end -= 2;
/* 1180 */       uriBC.setEnd(end);
/*      */     } 
/*      */     
/* 1183 */     index = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 1187 */       index = uriBC.indexOf("/../", 0, 4, index);
/* 1188 */       if (index < 0) {
/*      */         break;
/*      */       }
/*      */       
/* 1192 */       if (index == 0) {
/* 1193 */         return false;
/*      */       }
/* 1195 */       int index2 = -1;
/* 1196 */       for (pos = start + index - 1; pos >= 0 && index2 < 0; pos--) {
/* 1197 */         if (b[pos] == 47) {
/* 1198 */           index2 = pos;
/*      */         }
/*      */       } 
/* 1201 */       copyBytes(b, start + index2, start + index + 3, end - start - index - 3);
/* 1202 */       end = end + index2 - index - 3;
/* 1203 */       uriBC.setEnd(end);
/* 1204 */       index = index2;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1209 */     if (appendedSlash && end > 1 && b[end - 1] == 47) {
/* 1210 */       uriBC.setEnd(end - 1);
/*      */     }
/*      */     
/* 1213 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void copyBytes(byte[] b, int dest, int src, int len) {
/* 1226 */     System.arraycopy(b, src, b, dest, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean checkSuspiciousURIs(ByteChunk undecodedURI) {
/* 1234 */     byte[] bytes = undecodedURI.getBytes();
/* 1235 */     int start = undecodedURI.getStart();
/* 1236 */     int end = undecodedURI.getEnd();
/*      */ 
/*      */     
/* 1239 */     int segmentStart = undecodedURI.indexOf('/', 0);
/* 1240 */     int segmentEnd = -1;
/* 1241 */     if (segmentStart > -1) {
/* 1242 */       segmentEnd = undecodedURI.indexOf('/', segmentStart + 1);
/*      */     }
/*      */     
/* 1245 */     while (segmentStart > -1) {
/* 1246 */       int pos = start + segmentStart + 1;
/*      */ 
/*      */       
/* 1249 */       if (segmentEnd > 0 && bytes[pos] == 59) {
/* 1250 */         return true;
/*      */       }
/*      */ 
/*      */       
/* 1254 */       int dotCount = 0;
/* 1255 */       boolean encodedDot = false;
/* 1256 */       while (pos < end) {
/* 1257 */         if (bytes[pos] == 46) {
/* 1258 */           dotCount++;
/* 1259 */           pos++; continue;
/* 1260 */         }  if (pos + 2 < end && bytes[pos] == 37 && bytes[pos + 1] == 50 && (bytes[pos + 2] == 101 || bytes[pos + 2] == 69)) {
/*      */           
/* 1262 */           encodedDot = true;
/* 1263 */           dotCount++;
/* 1264 */           pos += 3; continue;
/* 1265 */         }  if (bytes[pos] == 59) {
/* 1266 */           if (dotCount > 0)
/* 1267 */             return true; 
/*      */           break;
/*      */         } 
/* 1270 */         if (bytes[pos] == 47) {
/*      */           break;
/*      */         }
/* 1273 */         dotCount = 0;
/*      */       } 
/*      */ 
/*      */       
/* 1277 */       if (dotCount > 0 && encodedDot) {
/* 1278 */         return true;
/*      */       }
/*      */ 
/*      */       
/* 1282 */       pos = start + segmentStart + 1;
/* 1283 */       while (pos < end) {
/* 1284 */         if (pos + 2 < end && bytes[pos] == 37) {
/* 1285 */           byte b1 = bytes[pos + 1];
/* 1286 */           byte b2 = bytes[pos + 2];
/* 1287 */           pos += 3;
/* 1288 */           int decoded = (HexUtils.getDec(b1) << 4) + HexUtils.getDec(b2);
/* 1289 */           if (decoded < 20 || decoded == 127 || decoded == 47)
/* 1290 */             return true; 
/*      */           continue;
/*      */         } 
/* 1293 */         pos++;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1298 */       if (segmentEnd == -1) {
/* 1299 */         segmentStart = -1; continue;
/*      */       } 
/* 1301 */       segmentStart = segmentEnd;
/* 1302 */       if (segmentStart > -1) {
/* 1303 */         segmentEnd = undecodedURI.indexOf('/', segmentStart + 1);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1308 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\CoyoteAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */