/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoyoteReader
/*     */   extends BufferedReader
/*     */ {
/*  32 */   private static final char[] LINE_SEP = new char[] { '\r', '\n' };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MAX_LINE_LENGTH = 4096;
/*     */ 
/*     */   
/*     */   protected InputBuffer ib;
/*     */ 
/*     */   
/*  42 */   protected char[] lineBuffer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoyoteReader(InputBuffer ib) {
/*  49 */     super(ib, 1);
/*  50 */     this.ib = ib;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  62 */     throw new CloneNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/*  73 */     this.ib = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  82 */     this.ib.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  88 */     return this.ib.read();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] cbuf) throws IOException {
/*  94 */     return this.ib.read(cbuf, 0, cbuf.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] cbuf, int off, int len) throws IOException {
/* 100 */     return this.ib.read(cbuf, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 106 */     return this.ib.skip(n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ready() throws IOException {
/* 112 */     return this.ib.ready();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int readAheadLimit) throws IOException {
/* 118 */     this.ib.mark(readAheadLimit);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 124 */     this.ib.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/*     */     String result;
/* 131 */     if (this.lineBuffer == null) {
/* 132 */       this.lineBuffer = new char[4096];
/*     */     }
/*     */     
/* 135 */     int pos = 0;
/* 136 */     int end = -1;
/* 137 */     int skip = -1;
/* 138 */     StringBuilder aggregator = null;
/* 139 */     while (end < 0) {
/* 140 */       mark(4096);
/* 141 */       while (pos < 4096 && end < 0) {
/* 142 */         int nRead = read(this.lineBuffer, pos, 4096 - pos);
/* 143 */         if (nRead < 0) {
/* 144 */           if (pos == 0 && aggregator == null) {
/* 145 */             return null;
/*     */           }
/* 147 */           end = pos;
/* 148 */           skip = pos;
/*     */         } 
/* 150 */         for (int i = pos; i < pos + nRead && end < 0; i++) {
/* 151 */           if (this.lineBuffer[i] == LINE_SEP[0]) {
/* 152 */             char nextchar; end = i;
/* 153 */             skip = i + 1;
/*     */             
/* 155 */             if (i == pos + nRead - 1) {
/* 156 */               nextchar = (char)read();
/*     */             } else {
/* 158 */               nextchar = this.lineBuffer[i + 1];
/*     */             } 
/* 160 */             if (nextchar == LINE_SEP[1]) {
/* 161 */               skip++;
/*     */             }
/* 163 */           } else if (this.lineBuffer[i] == LINE_SEP[1]) {
/* 164 */             end = i;
/* 165 */             skip = i + 1;
/*     */           } 
/*     */         } 
/* 168 */         if (nRead > 0) {
/* 169 */           pos += nRead;
/*     */         }
/*     */       } 
/* 172 */       if (end < 0) {
/* 173 */         if (aggregator == null) {
/* 174 */           aggregator = new StringBuilder();
/*     */         }
/* 176 */         aggregator.append(this.lineBuffer);
/* 177 */         pos = 0; continue;
/*     */       } 
/* 179 */       reset();
/*     */       
/* 181 */       skip(skip);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 186 */     if (aggregator == null) {
/* 187 */       result = new String(this.lineBuffer, 0, end);
/*     */     } else {
/* 189 */       aggregator.append(this.lineBuffer, 0, end);
/* 190 */       result = aggregator.toString();
/*     */     } 
/*     */     
/* 193 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\CoyoteReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */