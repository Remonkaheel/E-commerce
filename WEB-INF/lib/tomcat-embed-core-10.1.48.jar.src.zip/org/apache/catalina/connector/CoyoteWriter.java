/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoyoteWriter
/*     */   extends PrintWriter
/*     */ {
/*  30 */   private static final char[] LINE_SEP = System.lineSeparator().toCharArray();
/*     */ 
/*     */ 
/*     */   
/*     */   protected OutputBuffer ob;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean error = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoyoteWriter(OutputBuffer ob) {
/*  44 */     super(ob);
/*  45 */     this.ob = ob;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  57 */     throw new CloneNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/*  68 */     this.ob = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void recycle() {
/*  76 */     this.error = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/*  86 */     if (this.error) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  91 */       this.ob.flush();
/*  92 */     } catch (IOException ioe) {
/*  93 */       setErrorException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 105 */       this.ob.close();
/* 106 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 109 */     this.error = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkError() {
/* 116 */     flush();
/* 117 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int c) {
/* 124 */     if (this.error) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 129 */       this.ob.write(c);
/* 130 */     } catch (IOException ioe) {
/* 131 */       setErrorException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] buf, int off, int len) {
/* 140 */     if (this.error) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 145 */       this.ob.write(buf, off, len);
/* 146 */     } catch (IOException ioe) {
/* 147 */       setErrorException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] buf) {
/* 155 */     write(buf, 0, buf.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String s, int off, int len) {
/* 162 */     if (this.error) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 167 */       this.ob.write(s, off, len);
/* 168 */     } catch (IOException ioe) {
/* 169 */       setErrorException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String s) {
/* 177 */     write(s, 0, s.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(boolean b) {
/* 186 */     if (b) {
/* 187 */       write("true");
/*     */     } else {
/* 189 */       write("false");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(char c) {
/* 196 */     write(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(int i) {
/* 202 */     write(String.valueOf(i));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(long l) {
/* 208 */     write(String.valueOf(l));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(float f) {
/* 214 */     write(String.valueOf(f));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(double d) {
/* 220 */     write(String.valueOf(d));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(char[] s) {
/* 226 */     write(s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String s) {
/* 232 */     if (s == null) {
/* 233 */       s = "null";
/*     */     }
/* 235 */     write(s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(Object obj) {
/* 241 */     write(String.valueOf(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println() {
/* 247 */     write(LINE_SEP);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(boolean b) {
/* 253 */     print(b);
/* 254 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(char c) {
/* 260 */     print(c);
/* 261 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(int i) {
/* 267 */     print(i);
/* 268 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(long l) {
/* 274 */     print(l);
/* 275 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(float f) {
/* 281 */     print(f);
/* 282 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(double d) {
/* 288 */     print(d);
/* 289 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(char[] c) {
/* 295 */     print(c);
/* 296 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(String s) {
/* 302 */     print(s);
/* 303 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(Object o) {
/* 309 */     print(o);
/* 310 */     println();
/*     */   }
/*     */ 
/*     */   
/*     */   private void setErrorException(Exception e) {
/* 315 */     this.error = true;
/* 316 */     this.ob.setErrorException(e);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\CoyoteWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */