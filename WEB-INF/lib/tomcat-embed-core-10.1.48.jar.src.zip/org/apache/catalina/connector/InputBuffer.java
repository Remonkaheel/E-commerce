/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import jakarta.servlet.ReadListener;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.BadRequestException;
/*     */ import org.apache.coyote.Constants;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.collections.SynchronizedStack;
/*     */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputBuffer
/*     */   extends Reader
/*     */   implements ByteChunk.ByteInputChannel, ApplicationBufferHandler
/*     */ {
/*  57 */   protected static final StringManager sm = StringManager.getManager(InputBuffer.class);
/*     */   
/*  59 */   private static final Log log = LogFactory.getLog(InputBuffer.class);
/*     */   
/*  61 */   private static final ByteBuffer EMPTY_BUFFER = ByteBuffer.allocate(0);
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */ 
/*     */   
/*  67 */   public final int INITIAL_STATE = 0;
/*  68 */   public final int CHAR_STATE = 1;
/*  69 */   public final int BYTE_STATE = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private static final Map<Charset, SynchronizedStack<B2CConverter>> encoders = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteBuffer bb;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CharBuffer cb;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private int state = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B2CConverter conv;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Request coyoteRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private int markPos = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readLimit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputBuffer() {
/* 144 */     this(8192);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputBuffer(int size) {
/* 156 */     this.size = size;
/*     */     
/* 158 */     this.bb = EMPTY_BUFFER;
/* 159 */     this.cb = CharBuffer.allocate(size);
/* 160 */     clear(this.cb);
/* 161 */     this.readLimit = size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequest(Request coyoteRequest) {
/* 175 */     this.coyoteRequest = coyoteRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recycle() {
/* 186 */     this.state = 0;
/*     */ 
/*     */     
/* 189 */     if (this.cb.capacity() > this.size) {
/* 190 */       this.cb = CharBuffer.allocate(this.size);
/* 191 */       clear(this.cb);
/*     */     } else {
/* 193 */       clear(this.cb);
/*     */     } 
/* 195 */     this.readLimit = this.size;
/* 196 */     this.markPos = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     this.bb = EMPTY_BUFFER;
/* 202 */     this.closed = false;
/*     */     
/* 204 */     if (this.conv != null) {
/* 205 */       this.conv.recycle();
/* 206 */       ((SynchronizedStack)encoders.get(this.conv.getCharset())).push(this.conv);
/* 207 */       this.conv = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 214 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() {
/* 219 */     int available = availableInThisBuffer();
/* 220 */     if (available == 0) {
/* 221 */       this.coyoteRequest.action(ActionCode.AVAILABLE, Boolean.valueOf((this.coyoteRequest.getReadListener() != null)));
/* 222 */       available = (this.coyoteRequest.getAvailable() > 0) ? 1 : 0;
/*     */     } 
/* 224 */     return available;
/*     */   }
/*     */ 
/*     */   
/*     */   private int availableInThisBuffer() {
/* 229 */     int available = 0;
/* 230 */     if (this.state == 2) {
/* 231 */       available = this.bb.remaining();
/* 232 */     } else if (this.state == 1) {
/* 233 */       available = this.cb.remaining();
/*     */     } 
/* 235 */     return available;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadListener(ReadListener listener) {
/* 240 */     this.coyoteRequest.setReadListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFinished() {
/* 245 */     int available = 0;
/* 246 */     if (this.state == 2) {
/* 247 */       available = this.bb.remaining();
/* 248 */     } else if (this.state == 1) {
/* 249 */       available = this.cb.remaining();
/*     */     } 
/* 251 */     if (available > 0) {
/* 252 */       return false;
/*     */     }
/* 254 */     return this.coyoteRequest.isFinished();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReady() {
/* 260 */     if (this.coyoteRequest.getReadListener() == null) {
/* 261 */       if (log.isDebugEnabled()) {
/* 262 */         log.debug(sm.getString("inputBuffer.requiresNonBlocking"));
/*     */       }
/* 264 */       return false;
/*     */     } 
/* 266 */     if (isFinished()) {
/*     */ 
/*     */ 
/*     */       
/* 270 */       if (!this.coyoteRequest.isRequestThread()) {
/* 271 */         this.coyoteRequest.action(ActionCode.DISPATCH_READ, null);
/* 272 */         this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */       } 
/* 274 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     if (availableInThisBuffer() > 0) {
/* 285 */       return true;
/*     */     }
/*     */     
/* 288 */     return this.coyoteRequest.isReady();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isBlocking() {
/* 293 */     return (this.coyoteRequest.getReadListener() == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int realReadBytes() throws IOException {
/* 301 */     if (this.closed) {
/* 302 */       return -1;
/*     */     }
/*     */     
/* 305 */     if (this.state == 0) {
/* 306 */       this.state = 2;
/*     */     }
/*     */     
/*     */     try {
/* 310 */       return this.coyoteRequest.doRead(this);
/* 311 */     } catch (BadRequestException bre) {
/*     */       
/* 313 */       handleReadException((Exception)bre);
/* 314 */       throw bre;
/* 315 */     } catch (IOException ioe) {
/* 316 */       handleReadException(ioe);
/*     */ 
/*     */       
/* 319 */       throw new ClientAbortException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleReadException(Exception e) throws IOException {
/* 327 */     this.coyoteRequest.setErrorException(e);
/*     */     
/* 329 */     Request request = (Request)this.coyoteRequest.getNote(1);
/* 330 */     Response response = request.getResponse();
/* 331 */     request.setAttribute("jakarta.servlet.error.exception", e);
/* 332 */     if (e instanceof java.net.SocketTimeoutException) {
/*     */       try {
/* 334 */         response.sendError(408);
/* 335 */       } catch (IllegalStateException ex) {
/*     */         
/* 337 */         response.setStatus(408);
/* 338 */         response.setError();
/*     */       } 
/*     */     } else {
/*     */       try {
/* 342 */         response.sendError(400);
/* 343 */       } catch (IllegalStateException ex) {
/*     */         
/* 345 */         response.setStatus(400);
/* 346 */         response.setError();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int readByte() throws IOException {
/* 353 */     throwIfClosed();
/*     */     
/* 355 */     if (checkByteBufferEof()) {
/* 356 */       return -1;
/*     */     }
/* 358 */     return this.bb.get() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 363 */     throwIfClosed();
/*     */     
/* 365 */     if (checkByteBufferEof()) {
/* 366 */       return -1;
/*     */     }
/* 368 */     int n = Math.min(len, this.bb.remaining());
/* 369 */     this.bb.get(b, off, n);
/* 370 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer to) throws IOException {
/* 386 */     throwIfClosed();
/*     */     
/* 388 */     if (checkByteBufferEof()) {
/* 389 */       return -1;
/*     */     }
/* 391 */     int n = Math.min(to.remaining(), this.bb.remaining());
/* 392 */     int orgLimit = this.bb.limit();
/* 393 */     this.bb.limit(this.bb.position() + n);
/* 394 */     to.put(this.bb);
/* 395 */     this.bb.limit(orgLimit);
/* 396 */     to.limit(to.position()).position(to.position() - n);
/* 397 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int realReadChars() throws IOException {
/* 404 */     checkConverter();
/*     */     
/* 406 */     boolean eof = false;
/*     */     
/* 408 */     if (this.bb.remaining() <= 0) {
/* 409 */       int nRead = realReadBytes();
/* 410 */       if (nRead < 0) {
/* 411 */         eof = true;
/*     */       }
/*     */     } 
/*     */     
/* 415 */     if (this.markPos == -1) {
/* 416 */       clear(this.cb);
/*     */     } else {
/*     */       
/* 419 */       makeSpace(this.bb.remaining());
/* 420 */       if (this.cb.capacity() - this.cb.limit() == 0 && this.bb.remaining() != 0) {
/*     */         
/* 422 */         clear(this.cb);
/* 423 */         this.markPos = -1;
/*     */       } 
/*     */     } 
/*     */     
/* 427 */     this.state = 1;
/* 428 */     this.conv.convert(this.bb, this.cb, this, eof);
/*     */     
/* 430 */     if (this.cb.remaining() == 0 && eof) {
/* 431 */       return -1;
/*     */     }
/* 433 */     return this.cb.remaining();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 440 */     throwIfClosed();
/*     */     
/* 442 */     if (checkCharBufferEof()) {
/* 443 */       return -1;
/*     */     }
/* 445 */     return this.cb.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] cbuf) throws IOException {
/* 451 */     throwIfClosed();
/* 452 */     return read(cbuf, 0, cbuf.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] cbuf, int off, int len) throws IOException {
/* 458 */     throwIfClosed();
/*     */     
/* 460 */     if (checkCharBufferEof()) {
/* 461 */       return -1;
/*     */     }
/* 463 */     int n = Math.min(len, this.cb.remaining());
/* 464 */     this.cb.get(cbuf, off, n);
/* 465 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 471 */     throwIfClosed();
/*     */     
/* 473 */     if (n < 0L) {
/* 474 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 477 */     long nRead = 0L;
/* 478 */     while (nRead < n) {
/* 479 */       if (this.cb.remaining() >= n) {
/* 480 */         this.cb.position(this.cb.position() + (int)n);
/* 481 */         nRead = n; continue;
/*     */       } 
/* 483 */       nRead += this.cb.remaining();
/* 484 */       this.cb.position(this.cb.limit());
/* 485 */       int nb = realReadChars();
/* 486 */       if (nb < 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 491 */     return nRead;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ready() throws IOException {
/* 497 */     throwIfClosed();
/* 498 */     if (this.state == 0) {
/* 499 */       this.state = 1;
/*     */     }
/* 501 */     return (available() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 507 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int readAheadLimit) throws IOException {
/* 514 */     throwIfClosed();
/*     */     
/* 516 */     if (this.cb.remaining() <= 0) {
/* 517 */       clear(this.cb);
/*     */     }
/* 519 */     else if (this.cb.capacity() > 2 * this.size && this.cb.remaining() < this.cb.position()) {
/* 520 */       this.cb.compact();
/* 521 */       this.cb.flip();
/*     */     } 
/*     */     
/* 524 */     this.readLimit = this.cb.position() + readAheadLimit + this.size;
/* 525 */     this.markPos = this.cb.position();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 532 */     throwIfClosed();
/*     */     
/* 534 */     if (this.state == 1) {
/* 535 */       if (this.markPos < 0) {
/* 536 */         clear(this.cb);
/* 537 */         this.markPos = -1;
/* 538 */         IOException ioe = new IOException();
/* 539 */         this.coyoteRequest.setErrorException(ioe);
/* 540 */         throw ioe;
/*     */       } 
/* 542 */       this.cb.position(this.markPos);
/*     */     } else {
/*     */       
/* 545 */       clear(this.bb);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void throwIfClosed() throws IOException {
/* 551 */     if (this.closed) {
/* 552 */       IOException ioe = new IOException(sm.getString("inputBuffer.streamClosed"));
/* 553 */       this.coyoteRequest.setErrorException(ioe);
/* 554 */       throw ioe;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void checkConverter() throws IOException {
/* 559 */     if (this.conv != null) {
/*     */       return;
/*     */     }
/*     */     
/* 563 */     Charset charset = this.coyoteRequest.getCharset();
/*     */     
/* 565 */     if (charset == null) {
/* 566 */       charset = Constants.DEFAULT_BODY_CHARSET;
/*     */     }
/*     */     
/* 569 */     SynchronizedStack<B2CConverter> stack = encoders.get(charset);
/* 570 */     if (stack == null) {
/* 571 */       stack = new SynchronizedStack();
/* 572 */       encoders.putIfAbsent(charset, stack);
/* 573 */       stack = encoders.get(charset);
/*     */     } 
/* 575 */     this.conv = (B2CConverter)stack.pop();
/*     */     
/* 577 */     if (this.conv == null) {
/* 578 */       this.conv = createConverter(charset);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static B2CConverter createConverter(Charset charset) throws IOException {
/* 584 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 586 */         return AccessController.<B2CConverter>doPrivileged(new PrivilegedCreateConverter(charset));
/* 587 */       } catch (PrivilegedActionException ex) {
/* 588 */         Exception e = ex.getException();
/* 589 */         if (e instanceof IOException) {
/* 590 */           throw (IOException)e;
/*     */         }
/* 592 */         throw new IOException(e);
/*     */       } 
/*     */     }
/*     */     
/* 596 */     return new B2CConverter(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setByteBuffer(ByteBuffer buffer) {
/* 604 */     this.bb = buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getByteBuffer() {
/* 610 */     return this.bb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expand(int size) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkByteBufferEof() throws IOException {
/* 621 */     if (this.bb.remaining() == 0) {
/* 622 */       return (realReadBytes() < 0);
/*     */     }
/* 624 */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkCharBufferEof() throws IOException {
/* 628 */     if (this.cb.remaining() == 0) {
/* 629 */       return (realReadChars() < 0);
/*     */     }
/* 631 */     return false;
/*     */   }
/*     */   
/*     */   private void clear(Buffer buffer) {
/* 635 */     buffer.rewind().limit(0);
/*     */   }
/*     */   
/*     */   private void makeSpace(int count) {
/* 639 */     int desiredSize = this.cb.limit() + count;
/* 640 */     if (desiredSize > this.readLimit) {
/* 641 */       desiredSize = this.readLimit;
/*     */     }
/*     */     
/* 644 */     if (desiredSize <= this.cb.capacity()) {
/*     */       return;
/*     */     }
/*     */     
/* 648 */     int newSize = 2 * this.cb.capacity();
/* 649 */     if (desiredSize >= newSize) {
/* 650 */       newSize = 2 * this.cb.capacity() + count;
/*     */     }
/*     */     
/* 653 */     if (newSize > this.readLimit) {
/* 654 */       newSize = this.readLimit;
/*     */     }
/*     */     
/* 657 */     CharBuffer tmp = CharBuffer.allocate(newSize);
/* 658 */     int oldPosition = this.cb.position();
/* 659 */     this.cb.position(0);
/* 660 */     tmp.put(this.cb);
/* 661 */     tmp.flip();
/* 662 */     tmp.position(oldPosition);
/* 663 */     this.cb = tmp;
/*     */   }
/*     */   
/*     */   private static class PrivilegedCreateConverter
/*     */     implements PrivilegedExceptionAction<B2CConverter>
/*     */   {
/*     */     private final Charset charset;
/*     */     
/*     */     PrivilegedCreateConverter(Charset charset) {
/* 672 */       this.charset = charset;
/*     */     }
/*     */ 
/*     */     
/*     */     public B2CConverter run() throws IOException {
/* 677 */       return new B2CConverter(this.charset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\InputBuffer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */