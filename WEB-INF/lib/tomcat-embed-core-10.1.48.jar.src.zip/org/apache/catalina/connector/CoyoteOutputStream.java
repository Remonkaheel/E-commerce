/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.WriteListener;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Objects;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoyoteOutputStream
/*     */   extends ServletOutputStream
/*     */ {
/*  33 */   protected static final StringManager sm = StringManager.getManager(CoyoteOutputStream.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OutputBuffer ob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoyoteOutputStream(OutputBuffer ob) {
/*  45 */     this.ob = ob;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  57 */     throw new CloneNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/*  68 */     this.ob = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int i) throws IOException {
/*  77 */     boolean nonBlocking = checkNonBlockingWrite();
/*     */     try {
/*  79 */       this.ob.writeByte(i);
/*  80 */     } catch (IOException ioe) {
/*  81 */       handleIOException(ioe);
/*     */     } 
/*  83 */     if (nonBlocking) {
/*  84 */       checkRegisterForWrite();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/*  91 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  97 */     boolean nonBlocking = checkNonBlockingWrite();
/*     */     try {
/*  99 */       this.ob.write(b, off, len);
/* 100 */     } catch (IOException ioe) {
/* 101 */       handleIOException(ioe);
/*     */     } 
/* 103 */     if (nonBlocking) {
/* 104 */       checkRegisterForWrite();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer from) throws IOException {
/* 110 */     Objects.requireNonNull(from);
/* 111 */     boolean nonBlocking = checkNonBlockingWrite();
/*     */     try {
/* 113 */       this.ob.write(from);
/* 114 */     } catch (IOException ioe) {
/* 115 */       handleIOException(ioe);
/*     */     } 
/* 117 */     if (nonBlocking) {
/* 118 */       checkRegisterForWrite();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 128 */     boolean nonBlocking = checkNonBlockingWrite();
/*     */     try {
/* 130 */       this.ob.flush();
/* 131 */     } catch (IOException ioe) {
/* 132 */       handleIOException(ioe);
/*     */     } 
/* 134 */     if (nonBlocking) {
/* 135 */       checkRegisterForWrite();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkNonBlockingWrite() {
/* 147 */     boolean nonBlocking = !this.ob.isBlocking();
/* 148 */     if (nonBlocking && !this.ob.isReady()) {
/* 149 */       throw new IllegalStateException(sm.getString("coyoteOutputStream.nbNotready"));
/*     */     }
/* 151 */     return nonBlocking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkRegisterForWrite() {
/* 162 */     this.ob.checkRegisterForWrite();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/* 169 */       this.ob.close();
/* 170 */     } catch (IOException ioe) {
/* 171 */       handleIOException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReady() {
/* 177 */     if (this.ob == null) {
/* 178 */       throw new IllegalStateException(sm.getString("coyoteOutputStream.null"));
/*     */     }
/* 180 */     return this.ob.isReady();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteListener(WriteListener listener) {
/* 186 */     this.ob.setWriteListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleIOException(IOException ioe) throws IOException {
/*     */     try {
/* 192 */       this.ob.setErrorException(ioe);
/* 193 */     } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     throw ioe;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\CoyoteOutputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */