/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import jakarta.servlet.WriteListener;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.CloseNowException;
/*     */ import org.apache.coyote.Constants;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.C2BConverter;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputBuffer
/*     */   extends Writer
/*     */ {
/*  49 */   private static final StringManager sm = StringManager.getManager(OutputBuffer.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */ 
/*     */   
/*  56 */   private final Map<Charset, C2BConverter> encoders = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int defaultBufferSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteBuffer bb;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final CharBuffer cb;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initial = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private long bytesWritten = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private long charsWritten = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doFlush = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected C2BConverter conv;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Response coyoteResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean suspended = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputBuffer(int size) {
/* 134 */     this.defaultBufferSize = size;
/* 135 */     this.bb = ByteBuffer.allocate(size);
/* 136 */     clear(this.bb);
/* 137 */     this.cb = CharBuffer.allocate(size);
/* 138 */     clear(this.cb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponse(Response coyoteResponse) {
/* 150 */     this.coyoteResponse = coyoteResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuspended() {
/* 160 */     return this.suspended;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuspended(boolean suspended) {
/* 170 */     this.suspended = suspended;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 180 */     return this.closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recycle() {
/* 191 */     this.initial = true;
/* 192 */     this.bytesWritten = 0L;
/* 193 */     this.charsWritten = 0L;
/*     */     
/* 195 */     if (this.bb.capacity() > 16 * this.defaultBufferSize)
/*     */     {
/* 197 */       this.bb = ByteBuffer.allocate(this.defaultBufferSize);
/*     */     }
/* 199 */     clear(this.bb);
/* 200 */     clear(this.cb);
/* 201 */     this.closed = false;
/* 202 */     this.suspended = false;
/* 203 */     this.doFlush = false;
/*     */     
/* 205 */     if (this.conv != null) {
/* 206 */       this.conv.recycle();
/* 207 */       this.conv = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 220 */     if (this.closed) {
/*     */       return;
/*     */     }
/* 223 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 229 */     if (this.cb.remaining() > 0) {
/* 230 */       flushCharBuffer();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (!this.coyoteResponse.isCommitted() && this.coyoteResponse.getContentLengthLong() == -1L && (this.bb
/* 240 */       .remaining() > 0 || !"HEAD".equals(this.coyoteResponse.getRequest().getMethod()))) {
/* 241 */       this.coyoteResponse.setContentLength(this.bb.remaining());
/*     */     }
/*     */     
/* 244 */     doFlush((this.coyoteResponse.getStatus() == 101));
/* 245 */     this.closed = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     Request req = (Request)this.coyoteResponse.getRequest().getNote(1);
/* 251 */     req.inputBuffer.close();
/*     */     
/* 253 */     this.coyoteResponse.action(ActionCode.CLOSE, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 264 */     doFlush(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFlush(boolean realFlush) throws IOException {
/* 277 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 282 */       this.doFlush = true;
/* 283 */       if (this.initial) {
/* 284 */         this.coyoteResponse.commit();
/* 285 */         this.initial = false;
/*     */       } 
/* 287 */       if (this.cb.remaining() > 0) {
/* 288 */         flushCharBuffer();
/*     */       }
/* 290 */       if (this.bb.remaining() > 0) {
/* 291 */         flushByteBuffer();
/*     */       }
/*     */     } finally {
/* 294 */       this.doFlush = false;
/*     */     } 
/*     */     
/* 297 */     if (realFlush) {
/* 298 */       this.coyoteResponse.action(ActionCode.CLIENT_FLUSH, null);
/*     */ 
/*     */       
/* 301 */       if (this.coyoteResponse.isExceptionPresent()) {
/* 302 */         throw new ClientAbortException(this.coyoteResponse.getErrorException());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realWriteBytes(ByteBuffer buf) throws IOException {
/* 320 */     if (this.closed) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 325 */     if (buf.remaining() > 0) {
/*     */       
/*     */       try {
/* 328 */         this.coyoteResponse.doWrite(buf);
/* 329 */       } catch (CloseNowException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 334 */         this.closed = true;
/* 335 */         throw e;
/* 336 */       } catch (IOException ioe) {
/*     */ 
/*     */ 
/*     */         
/* 340 */         throw new ClientAbortException(ioe);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 349 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 353 */     writeBytes(b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer from) throws IOException {
/* 360 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 364 */     writeBytes(from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeBytes(byte[] b, int off, int len) throws IOException {
/* 371 */     if (this.closed) {
/*     */       return;
/*     */     }
/*     */     
/* 375 */     append(b, off, len);
/* 376 */     this.bytesWritten += len;
/*     */ 
/*     */ 
/*     */     
/* 380 */     if (this.doFlush) {
/* 381 */       flushByteBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeBytes(ByteBuffer from) throws IOException {
/* 389 */     if (this.closed) {
/*     */       return;
/*     */     }
/*     */     
/* 393 */     int remaining = from.remaining();
/* 394 */     append(from);
/* 395 */     this.bytesWritten += remaining;
/*     */ 
/*     */ 
/*     */     
/* 399 */     if (this.doFlush) {
/* 400 */       flushByteBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeByte(int b) throws IOException {
/* 408 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 412 */     if (isFull(this.bb)) {
/* 413 */       flushByteBuffer();
/*     */     }
/*     */     
/* 416 */     transfer((byte)b, this.bb);
/* 417 */     this.bytesWritten++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realWriteChars(CharBuffer from) throws IOException {
/* 434 */     while (from.remaining() > 0) {
/* 435 */       this.conv.convert(from, this.bb);
/* 436 */       if (this.bb.remaining() == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 440 */       if (from.remaining() > 0) {
/* 441 */         flushByteBuffer(); continue;
/* 442 */       }  if (this.conv.isUnderflow() && this.bb.limit() > this.bb.capacity() - 4)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 451 */         flushByteBuffer();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int c) throws IOException {
/* 460 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 464 */     if (isFull(this.cb)) {
/* 465 */       flushCharBuffer();
/*     */     }
/*     */     
/* 468 */     transfer((char)c, this.cb);
/* 469 */     this.charsWritten++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] c) throws IOException {
/* 477 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 481 */     write(c, 0, c.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] c, int off, int len) throws IOException {
/* 489 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 493 */     append(c, off, len);
/* 494 */     this.charsWritten += len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String s, int off, int len) throws IOException {
/* 505 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 509 */     if (s == null) {
/* 510 */       throw new NullPointerException(sm.getString("outputBuffer.writeNull"));
/*     */     }
/*     */     
/* 513 */     int sOff = off;
/* 514 */     int sEnd = off + len;
/* 515 */     while (sOff < sEnd) {
/* 516 */       int n = transfer(s, sOff, sEnd - sOff, this.cb);
/* 517 */       sOff += n;
/* 518 */       if (sOff < sEnd && isFull(this.cb)) {
/* 519 */         flushCharBuffer();
/*     */       }
/*     */     } 
/*     */     
/* 523 */     this.charsWritten += len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String s) throws IOException {
/* 530 */     if (this.suspended) {
/*     */       return;
/*     */     }
/*     */     
/* 534 */     if (s == null) {
/* 535 */       s = "null";
/*     */     }
/* 537 */     write(s, 0, s.length());
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkConverter() throws IOException {
/* 542 */     if (this.conv != null) {
/*     */       return;
/*     */     }
/*     */     
/* 546 */     Charset charset = this.coyoteResponse.getCharset();
/*     */     
/* 548 */     if (charset == null) {
/* 549 */       if (this.coyoteResponse.getCharacterEncoding() != null)
/*     */       {
/*     */         
/* 552 */         charset = B2CConverter.getCharset(this.coyoteResponse.getCharacterEncoding());
/*     */       }
/* 554 */       charset = Constants.DEFAULT_BODY_CHARSET;
/*     */     } 
/*     */     
/* 557 */     this.conv = this.encoders.get(charset);
/*     */     
/* 559 */     if (this.conv == null) {
/* 560 */       this.conv = createConverter(charset);
/* 561 */       this.encoders.put(charset, this.conv);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static C2BConverter createConverter(Charset charset) throws IOException {
/* 567 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 569 */         return AccessController.<C2BConverter>doPrivileged(new PrivilegedCreateConverter(charset));
/* 570 */       } catch (PrivilegedActionException ex) {
/* 571 */         Exception e = ex.getException();
/* 572 */         if (e instanceof IOException) {
/* 573 */           throw (IOException)e;
/*     */         }
/* 575 */         throw new IOException(ex);
/*     */       } 
/*     */     }
/*     */     
/* 579 */     return new C2BConverter(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getContentWritten() {
/* 587 */     return this.bytesWritten + this.charsWritten;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNew() {
/* 596 */     return (this.bytesWritten == 0L && this.charsWritten == 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBufferSize(int size) {
/* 601 */     if (size > this.bb.capacity()) {
/* 602 */       this.bb = ByteBuffer.allocate(size);
/* 603 */       clear(this.bb);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 609 */     reset(false);
/*     */   }
/*     */   
/*     */   public void reset(boolean resetWriterStreamFlags) {
/* 613 */     clear(this.bb);
/* 614 */     clear(this.cb);
/* 615 */     this.bytesWritten = 0L;
/* 616 */     this.charsWritten = 0L;
/* 617 */     if (resetWriterStreamFlags) {
/* 618 */       if (this.conv != null) {
/* 619 */         this.conv.recycle();
/*     */       }
/* 621 */       this.conv = null;
/*     */     } 
/* 623 */     this.initial = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBufferSize() {
/* 628 */     return this.bb.capacity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReady() {
/* 638 */     return this.coyoteResponse.isReady();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWriteListener(WriteListener listener) {
/* 643 */     this.coyoteResponse.setWriteListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBlocking() {
/* 648 */     return (this.coyoteResponse.getWriteListener() == null);
/*     */   }
/*     */   
/*     */   public void checkRegisterForWrite() {
/* 652 */     this.coyoteResponse.checkRegisterForWrite();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(byte[] src, int off, int len) throws IOException {
/* 665 */     if (this.bb.remaining() == 0) {
/* 666 */       appendByteArray(src, off, len);
/*     */     } else {
/* 668 */       int n = transfer(src, off, len, this.bb);
/* 669 */       len -= n;
/* 670 */       off += n;
/* 671 */       if (len > 0 && isFull(this.bb)) {
/* 672 */         flushByteBuffer();
/* 673 */         appendByteArray(src, off, len);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(char[] src, int off, int len) throws IOException {
/* 689 */     if (len <= this.cb.capacity() - this.cb.limit()) {
/* 690 */       transfer(src, off, len, this.cb);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 700 */     if (len + this.cb.limit() < 2 * this.cb.capacity()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 705 */       int n = transfer(src, off, len, this.cb);
/*     */       
/* 707 */       flushCharBuffer();
/*     */       
/* 709 */       transfer(src, off + n, len - n, this.cb);
/*     */     }
/*     */     else {
/*     */       
/* 713 */       flushCharBuffer();
/*     */       
/* 715 */       realWriteChars(CharBuffer.wrap(src, off, len));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void append(ByteBuffer from) throws IOException {
/* 721 */     if (this.bb.remaining() == 0) {
/* 722 */       appendByteBuffer(from);
/*     */     } else {
/* 724 */       transfer(from, this.bb);
/* 725 */       if (from.hasRemaining() && isFull(this.bb)) {
/* 726 */         flushByteBuffer();
/* 727 */         appendByteBuffer(from);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorException(Exception e) {
/* 734 */     this.coyoteResponse.setErrorException(e);
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendByteArray(byte[] src, int off, int len) throws IOException {
/* 739 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 743 */     int limit = this.bb.capacity();
/* 744 */     while (len > limit) {
/* 745 */       realWriteBytes(ByteBuffer.wrap(src, off, limit));
/* 746 */       len -= limit;
/* 747 */       off += limit;
/*     */     } 
/*     */     
/* 750 */     if (len > 0) {
/* 751 */       transfer(src, off, len, this.bb);
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendByteBuffer(ByteBuffer from) throws IOException {
/* 756 */     if (from.remaining() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 760 */     int limit = this.bb.capacity();
/* 761 */     int fromLimit = from.limit();
/* 762 */     while (from.remaining() > limit) {
/* 763 */       from.limit(from.position() + limit);
/* 764 */       realWriteBytes(from.slice());
/* 765 */       from.position(from.limit());
/* 766 */       from.limit(fromLimit);
/*     */     } 
/*     */     
/* 769 */     if (from.remaining() > 0) {
/* 770 */       transfer(from, this.bb);
/*     */     }
/*     */   }
/*     */   
/*     */   private void flushByteBuffer() throws IOException {
/* 775 */     realWriteBytes(this.bb.slice());
/* 776 */     clear(this.bb);
/*     */   }
/*     */   
/*     */   private void flushCharBuffer() throws IOException {
/* 780 */     realWriteChars(this.cb.slice());
/* 781 */     clear(this.cb);
/*     */   }
/*     */   
/*     */   private void transfer(byte b, ByteBuffer to) {
/* 785 */     toWriteMode(to);
/* 786 */     to.put(b);
/* 787 */     toReadMode(to);
/*     */   }
/*     */   
/*     */   private void transfer(char b, CharBuffer to) {
/* 791 */     toWriteMode(to);
/* 792 */     to.put(b);
/* 793 */     toReadMode(to);
/*     */   }
/*     */   
/*     */   private int transfer(byte[] buf, int off, int len, ByteBuffer to) {
/* 797 */     toWriteMode(to);
/* 798 */     int max = Math.min(len, to.remaining());
/* 799 */     if (max > 0) {
/* 800 */       to.put(buf, off, max);
/*     */     }
/* 802 */     toReadMode(to);
/* 803 */     return max;
/*     */   }
/*     */   
/*     */   private int transfer(char[] buf, int off, int len, CharBuffer to) {
/* 807 */     toWriteMode(to);
/* 808 */     int max = Math.min(len, to.remaining());
/* 809 */     if (max > 0) {
/* 810 */       to.put(buf, off, max);
/*     */     }
/* 812 */     toReadMode(to);
/* 813 */     return max;
/*     */   }
/*     */   
/*     */   private int transfer(String s, int off, int len, CharBuffer to) {
/* 817 */     toWriteMode(to);
/* 818 */     int max = Math.min(len, to.remaining());
/* 819 */     if (max > 0) {
/* 820 */       to.put(s, off, off + max);
/*     */     }
/* 822 */     toReadMode(to);
/* 823 */     return max;
/*     */   }
/*     */   
/*     */   private void transfer(ByteBuffer from, ByteBuffer to) {
/* 827 */     toWriteMode(to);
/* 828 */     int max = Math.min(from.remaining(), to.remaining());
/* 829 */     if (max > 0) {
/* 830 */       int fromLimit = from.limit();
/* 831 */       from.limit(from.position() + max);
/* 832 */       to.put(from);
/* 833 */       from.limit(fromLimit);
/*     */     } 
/* 835 */     toReadMode(to);
/*     */   }
/*     */   
/*     */   private void clear(Buffer buffer) {
/* 839 */     buffer.rewind().limit(0);
/*     */   }
/*     */   
/*     */   private boolean isFull(Buffer buffer) {
/* 843 */     return (buffer.limit() == buffer.capacity());
/*     */   }
/*     */   
/*     */   private void toReadMode(Buffer buffer) {
/* 847 */     buffer.limit(buffer.position()).reset();
/*     */   }
/*     */   
/*     */   private void toWriteMode(Buffer buffer) {
/* 851 */     buffer.mark().position(buffer.limit()).limit(buffer.capacity());
/*     */   }
/*     */   
/*     */   private static class PrivilegedCreateConverter
/*     */     implements PrivilegedExceptionAction<C2BConverter>
/*     */   {
/*     */     private final Charset charset;
/*     */     
/*     */     PrivilegedCreateConverter(Charset charset) {
/* 860 */       this.charset = charset;
/*     */     }
/*     */ 
/*     */     
/*     */     public C2BConverter run() throws IOException {
/* 865 */       return new C2BConverter(this.charset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\OutputBuffer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */