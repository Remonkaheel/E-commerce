/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Executor;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.core.AprStatus;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.coyote.AbstractProtocol;
/*      */ import org.apache.coyote.Adapter;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.UpgradeProtocol;
/*      */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.CharsetUtil;
/*      */ import org.apache.tomcat.util.buf.EncodedSolidusHandling;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.compat.JreCompat;
/*      */ import org.apache.tomcat.util.net.SSLHostConfig;
/*      */ import org.apache.tomcat.util.net.openssl.OpenSSLImplementation;
/*      */ import org.apache.tomcat.util.net.openssl.OpenSSLStatus;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Connector
/*      */   extends LifecycleMBeanBase
/*      */ {
/*   60 */   private static final Log log = LogFactory.getLog(Connector.class); public static final String INTERNAL_EXECUTOR_NAME = "Internal"; protected Service service; protected boolean allowBackslash; protected boolean allowTrace; protected long asyncTimeout;
/*      */   protected boolean enableLookups;
/*      */   protected boolean enforceEncodingInGetWriter;
/*      */   protected boolean xpoweredBy;
/*      */   protected String proxyName;
/*      */   protected int proxyPort;
/*      */   protected boolean discardFacades;
/*      */   protected int redirectPort;
/*      */   protected String scheme;
/*      */   protected boolean secure;
/*      */   
/*      */   public Connector() {
/*   72 */     this("HTTP/1.1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connector(String protocol) {
/*  110 */     this.service = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  117 */     this.allowBackslash = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  123 */     this.allowTrace = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  129 */     this.asyncTimeout = 30000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  135 */     this.enableLookups = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  145 */     this.enforceEncodingInGetWriter = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  151 */     this.xpoweredBy = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  159 */     this.proxyName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     this.proxyPort = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     this.discardFacades = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     this.redirectPort = 443;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  187 */     this.scheme = "http";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  193 */     this.secure = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  205 */     this.maxCookieCount = 200;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     this.maxParameterCount = 10000;
/*      */     
/*  213 */     this.maxPartCount = 50;
/*      */     
/*  215 */     this.maxPartHeaderSize = 512;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  220 */     this.maxPostSize = 2097152;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  226 */     this.maxSavePostSize = 4096;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  232 */     this.parseBodyMethods = "POST";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  243 */     this.useIPVHosts = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  267 */     this.adapter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  273 */     this.uriCharset = StandardCharsets.UTF_8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  279 */     this.encodedReverseSolidusHandling = EncodedSolidusHandling.DECODE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  285 */     this.encodedSolidusHandling = EncodedSolidusHandling.REJECT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  291 */     this.useBodyEncodingForURI = false; this.configuredProtocol = protocol; ProtocolHandler p = null; try { p = ProtocolHandler.create(protocol); } catch (Exception e) { log.error(sm.getString("coyoteConnector.protocolHandlerInstantiationFailed"), e); }  if (p != null) { this.protocolHandler = p; this.protocolHandlerClassName = this.protocolHandler.getClass().getName(); } else { this.protocolHandler = null; this.protocolHandlerClassName = protocol; }  setThrowOnFailure(Boolean.getBoolean("org.apache.catalina.startup.EXIT_ON_INIT_FAILURE")); } public Connector(ProtocolHandler protocolHandler) { this.service = null; this.allowBackslash = false; this.allowTrace = false; this.asyncTimeout = 30000L; this.enableLookups = false; this.enforceEncodingInGetWriter = true; this.xpoweredBy = false; this.proxyName = null; this.proxyPort = 0; this.discardFacades = true; this.redirectPort = 443; this.scheme = "http"; this.secure = false; this.maxCookieCount = 200; this.maxParameterCount = 10000; this.maxPartCount = 50; this.maxPartHeaderSize = 512; this.maxPostSize = 2097152; this.maxSavePostSize = 4096; this.parseBodyMethods = "POST"; this.useIPVHosts = false; this.adapter = null; this.uriCharset = StandardCharsets.UTF_8; this.encodedReverseSolidusHandling = EncodedSolidusHandling.DECODE; this.encodedSolidusHandling = EncodedSolidusHandling.REJECT; this.useBodyEncodingForURI = false;
/*      */     this.protocolHandlerClassName = protocolHandler.getClass().getName();
/*      */     this.configuredProtocol = this.protocolHandlerClassName;
/*      */     this.protocolHandler = protocolHandler;
/*      */     setThrowOnFailure(Boolean.getBoolean("org.apache.catalina.startup.EXIT_ON_INIT_FAILURE")); }
/*      */   
/*      */   protected static final StringManager sm = StringManager.getManager(Connector.class); private int maxCookieCount; protected int maxParameterCount; private int maxPartCount; private int maxPartHeaderSize; protected int maxPostSize; protected int maxSavePostSize; protected String parseBodyMethods; protected HashSet<String> parseBodyMethodsSet; protected boolean useIPVHosts; protected final String protocolHandlerClassName; protected final String configuredProtocol;
/*      */   protected final ProtocolHandler protocolHandler;
/*      */   protected Adapter adapter;
/*      */   private Charset uriCharset;
/*      */   private EncodedSolidusHandling encodedReverseSolidusHandling;
/*      */   private EncodedSolidusHandling encodedSolidusHandling;
/*      */   protected boolean useBodyEncodingForURI;
/*      */   private boolean rejectSuspiciousURIs;
/*      */   
/*      */   public Object getProperty(String name) {
/*  307 */     if (this.protocolHandler == null) {
/*  308 */       return null;
/*      */     }
/*  310 */     return IntrospectionUtils.getProperty(this.protocolHandler, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setProperty(String name, String value) {
/*  323 */     if (this.protocolHandler == null) {
/*  324 */       return false;
/*      */     }
/*  326 */     return IntrospectionUtils.setProperty(this.protocolHandler, name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Service getService() {
/*  334 */     return this.service;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setService(Service service) {
/*  344 */     this.service = service;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAllowBackslash() {
/*  352 */     return this.allowBackslash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowBackslash(boolean allowBackslash) {
/*  362 */     this.allowBackslash = allowBackslash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAllowTrace() {
/*  370 */     return this.allowTrace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowTrace(boolean allowTrace) {
/*  380 */     this.allowTrace = allowTrace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getAsyncTimeout() {
/*  388 */     return this.asyncTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsyncTimeout(long asyncTimeout) {
/*  398 */     this.asyncTimeout = asyncTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDiscardFacades() {
/*  407 */     return (this.discardFacades || Globals.IS_SECURITY_ENABLED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDiscardFacades(boolean discardFacades) {
/*  417 */     this.discardFacades = discardFacades;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getEnableLookups() {
/*  425 */     return this.enableLookups;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnableLookups(boolean enableLookups) {
/*  435 */     this.enableLookups = enableLookups;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getEnforceEncodingInGetWriter() {
/*  443 */     return this.enforceEncodingInGetWriter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnforceEncodingInGetWriter(boolean enforceEncodingInGetWriter) {
/*  453 */     this.enforceEncodingInGetWriter = enforceEncodingInGetWriter;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCookieCount() {
/*  458 */     return this.maxCookieCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMaxCookieCount(int maxCookieCount) {
/*  463 */     this.maxCookieCount = maxCookieCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxParameterCount() {
/*  472 */     return this.maxParameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxParameterCount(int maxParameterCount) {
/*  483 */     this.maxParameterCount = maxParameterCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxPartCount() {
/*  488 */     return this.maxPartCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMaxPartCount(int maxPartCount) {
/*  493 */     this.maxPartCount = maxPartCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxPartHeaderSize() {
/*  498 */     return this.maxPartHeaderSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMaxPartHeaderSize(int maxPartHeaderSize) {
/*  503 */     this.maxPartHeaderSize = maxPartHeaderSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxPostSize() {
/*  511 */     return this.maxPostSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxPostSize(int maxPostSize) {
/*  521 */     this.maxPostSize = maxPostSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxSavePostSize() {
/*  529 */     return this.maxSavePostSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxSavePostSize(int maxSavePostSize) {
/*  540 */     this.maxSavePostSize = maxSavePostSize;
/*  541 */     setProperty("maxSavePostSize", String.valueOf(maxSavePostSize));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getParseBodyMethods() {
/*  549 */     return this.parseBodyMethods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParseBodyMethods(String methods) {
/*  560 */     HashSet<String> methodSet = new HashSet<>();
/*      */     
/*  562 */     if (null != methods) {
/*  563 */       methodSet.addAll(Arrays.asList(StringUtils.splitCommaSeparated(methods)));
/*      */     }
/*      */     
/*  566 */     if (methodSet.contains("TRACE")) {
/*  567 */       throw new IllegalArgumentException(sm.getString("coyoteConnector.parseBodyMethodNoTrace"));
/*      */     }
/*      */     
/*  570 */     this.parseBodyMethods = methods;
/*  571 */     this.parseBodyMethodsSet = methodSet;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isParseBodyMethod(String method) {
/*  576 */     return this.parseBodyMethodsSet.contains(method);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPort() {
/*  587 */     if (this.protocolHandler instanceof AbstractProtocol) {
/*  588 */       return ((AbstractProtocol)this.protocolHandler).getPort();
/*      */     }
/*      */     
/*  591 */     Object port = getProperty("port");
/*  592 */     if (port instanceof Integer) {
/*  593 */       return ((Integer)port).intValue();
/*      */     }
/*      */     
/*  596 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPort(int port) {
/*  606 */     setProperty("port", String.valueOf(port));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPortOffset() {
/*  613 */     if (this.protocolHandler instanceof AbstractProtocol) {
/*  614 */       return ((AbstractProtocol)this.protocolHandler).getPortOffset();
/*      */     }
/*      */     
/*  617 */     Object port = getProperty("portOffset");
/*  618 */     if (port instanceof Integer) {
/*  619 */       return ((Integer)port).intValue();
/*      */     }
/*      */     
/*  622 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPortOffset(int portOffset) {
/*  627 */     setProperty("portOffset", String.valueOf(portOffset));
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPortWithOffset() {
/*  632 */     int port = getPort();
/*      */     
/*  634 */     if (port > 0) {
/*  635 */       return port + getPortOffset();
/*      */     }
/*  637 */     return port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLocalPort() {
/*  646 */     return ((Integer)getProperty("localPort")).intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProtocol() {
/*  654 */     return this.configuredProtocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProtocolHandlerClassName() {
/*  662 */     return this.protocolHandlerClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProtocolHandler getProtocolHandler() {
/*  670 */     return this.protocolHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProxyName() {
/*  678 */     return this.proxyName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyName(String proxyName) {
/*  689 */     if (proxyName != null && !proxyName.isEmpty()) {
/*  690 */       this.proxyName = proxyName;
/*      */     } else {
/*  692 */       this.proxyName = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getProxyPort() {
/*  701 */     return this.proxyPort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyPort(int proxyPort) {
/*  711 */     this.proxyPort = proxyPort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRedirectPort() {
/*  720 */     return this.redirectPort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRedirectPort(int redirectPort) {
/*  730 */     this.redirectPort = redirectPort;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getRedirectPortWithOffset() {
/*  735 */     return getRedirectPort() + getPortOffset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getScheme() {
/*  743 */     return this.scheme;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScheme(String scheme) {
/*  753 */     this.scheme = scheme;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSecure() {
/*  762 */     return this.secure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSecure(boolean secure) {
/*  772 */     this.secure = secure;
/*  773 */     setProperty("secure", Boolean.toString(secure));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getURIEncoding() {
/*  781 */     return this.uriCharset.name();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Charset getURICharset() {
/*  789 */     return this.uriCharset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURIEncoding(String URIEncoding) {
/*      */     try {
/*  799 */       Charset charset = B2CConverter.getCharset(URIEncoding);
/*  800 */       if (!CharsetUtil.isAsciiSuperset(charset)) {
/*  801 */         log.error(sm.getString("coyoteConnector.notAsciiSuperset", new Object[] { URIEncoding, this.uriCharset.name() }));
/*      */         return;
/*      */       } 
/*  804 */       this.uriCharset = charset;
/*  805 */     } catch (UnsupportedEncodingException e) {
/*  806 */       log.error(sm.getString("coyoteConnector.invalidEncoding", new Object[] { URIEncoding, this.uriCharset.name() }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseBodyEncodingForURI() {
/*  815 */     return this.useBodyEncodingForURI;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseBodyEncodingForURI(boolean useBodyEncodingForURI) {
/*  825 */     this.useBodyEncodingForURI = useBodyEncodingForURI;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getXpoweredBy() {
/*  835 */     return this.xpoweredBy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXpoweredBy(boolean xpoweredBy) {
/*  846 */     this.xpoweredBy = xpoweredBy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseIPVHosts(boolean useIPVHosts) {
/*  857 */     this.useIPVHosts = useIPVHosts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseIPVHosts() {
/*  867 */     return this.useIPVHosts;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getExecutorName() {
/*  872 */     Object obj = this.protocolHandler.getExecutor();
/*  873 */     if (obj instanceof Executor) {
/*  874 */       return ((Executor)obj).getName();
/*      */     }
/*  876 */     return "Internal";
/*      */   }
/*      */ 
/*      */   
/*      */   public void addSslHostConfig(SSLHostConfig sslHostConfig) {
/*  881 */     this.protocolHandler.addSslHostConfig(sslHostConfig);
/*      */   }
/*      */ 
/*      */   
/*      */   public SSLHostConfig[] findSslHostConfigs() {
/*  886 */     return this.protocolHandler.findSslHostConfigs();
/*      */   }
/*      */ 
/*      */   
/*      */   public void addUpgradeProtocol(UpgradeProtocol upgradeProtocol) {
/*  891 */     this.protocolHandler.addUpgradeProtocol(upgradeProtocol);
/*      */   }
/*      */ 
/*      */   
/*      */   public UpgradeProtocol[] findUpgradeProtocols() {
/*  896 */     return this.protocolHandler.findUpgradeProtocols();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEncodedReverseSolidusHandling() {
/*  901 */     return this.encodedReverseSolidusHandling.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEncodedReverseSolidusHandling(String encodedReverseSolidusHandling) {
/*  906 */     this.encodedReverseSolidusHandling = EncodedSolidusHandling.fromString(encodedReverseSolidusHandling);
/*      */   }
/*      */ 
/*      */   
/*      */   public EncodedSolidusHandling getEncodedReverseSolidusHandlingInternal() {
/*  911 */     return this.encodedReverseSolidusHandling;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEncodedSolidusHandling() {
/*  916 */     return this.encodedSolidusHandling.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEncodedSolidusHandling(String encodedSolidusHandling) {
/*  921 */     this.encodedSolidusHandling = EncodedSolidusHandling.fromString(encodedSolidusHandling);
/*      */   }
/*      */ 
/*      */   
/*      */   public EncodedSolidusHandling getEncodedSolidusHandlingInternal() {
/*  926 */     return this.encodedSolidusHandling;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getRejectSuspiciousURIs() {
/*  931 */     return this.rejectSuspiciousURIs;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRejectSuspiciousURIs(boolean rejectSuspiciousURIs) {
/*  936 */     this.rejectSuspiciousURIs = rejectSuspiciousURIs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Request createRequest() {
/*  949 */     return new Request(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Response createResponse() {
/*  960 */     int size = this.protocolHandler.getDesiredBufferSize();
/*  961 */     if (size > 0) {
/*  962 */       return new Response(size);
/*      */     }
/*  964 */     return new Response();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String createObjectNameKeyProperties(String type) {
/*  971 */     Object addressObj = getProperty("address");
/*      */     
/*  973 */     StringBuilder sb = new StringBuilder("type=");
/*  974 */     sb.append(type);
/*  975 */     String id = (this.protocolHandler != null) ? this.protocolHandler.getId() : null;
/*  976 */     if (id != null) {
/*      */       
/*  978 */       sb.append(",port=0,address=");
/*  979 */       sb.append(ObjectName.quote(id));
/*      */     } else {
/*  981 */       sb.append(",port=");
/*  982 */       int port = getPortWithOffset();
/*  983 */       if (port > 0) {
/*  984 */         sb.append(port);
/*      */       } else {
/*  986 */         sb.append("auto-");
/*  987 */         sb.append(getProperty("nameIndex"));
/*      */       } 
/*  989 */       String address = "";
/*  990 */       if (addressObj instanceof InetAddress) {
/*  991 */         address = ((InetAddress)addressObj).getHostAddress();
/*  992 */       } else if (addressObj != null) {
/*  993 */         address = addressObj.toString();
/*      */       } 
/*  995 */       if (!address.isEmpty()) {
/*  996 */         sb.append(",address=");
/*  997 */         sb.append(ObjectName.quote(address));
/*      */       } 
/*      */     } 
/* 1000 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause() {
/*      */     try {
/* 1009 */       if (this.protocolHandler != null) {
/* 1010 */         this.protocolHandler.pause();
/*      */       }
/* 1012 */     } catch (Exception e) {
/* 1013 */       log.error(sm.getString("coyoteConnector.protocolHandlerPauseFailed"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resume() {
/*      */     try {
/* 1023 */       if (this.protocolHandler != null) {
/* 1024 */         this.protocolHandler.resume();
/*      */       }
/* 1026 */     } catch (Exception e) {
/* 1027 */       log.error(sm.getString("coyoteConnector.protocolHandlerResumeFailed"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initInternal() throws LifecycleException {
/* 1035 */     super.initInternal();
/*      */     
/* 1037 */     if (this.protocolHandler == null) {
/* 1038 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerInstantiationFailed"));
/*      */     }
/*      */ 
/*      */     
/* 1042 */     this.adapter = new CoyoteAdapter(this);
/* 1043 */     this.protocolHandler.setAdapter(this.adapter);
/*      */ 
/*      */     
/* 1046 */     if (null == this.parseBodyMethodsSet) {
/* 1047 */       setParseBodyMethods(getParseBodyMethods());
/*      */     }
/*      */     
/* 1050 */     if (JreCompat.isJre22Available() && OpenSSLStatus.getUseOpenSSL() && OpenSSLStatus.isAvailable() && this.protocolHandler instanceof org.apache.coyote.http11.AbstractHttp11Protocol) {
/*      */ 
/*      */       
/* 1053 */       AbstractHttp11JsseProtocol<?> jsseProtocolHandler = (AbstractHttp11JsseProtocol)this.protocolHandler;
/* 1054 */       if (jsseProtocolHandler.isSSLEnabled() && jsseProtocolHandler.getSslImplementationName() == null)
/*      */       {
/* 1056 */         jsseProtocolHandler
/* 1057 */           .setSslImplementationName("org.apache.tomcat.util.net.openssl.panama.OpenSSLImplementation");
/*      */       }
/* 1059 */     } else if (AprStatus.isAprAvailable() && AprStatus.getUseOpenSSL() && this.protocolHandler instanceof org.apache.coyote.http11.AbstractHttp11Protocol) {
/*      */ 
/*      */       
/* 1062 */       AbstractHttp11JsseProtocol<?> jsseProtocolHandler = (AbstractHttp11JsseProtocol)this.protocolHandler;
/* 1063 */       if (jsseProtocolHandler.isSSLEnabled() && jsseProtocolHandler.getSslImplementationName() == null)
/*      */       {
/* 1065 */         jsseProtocolHandler.setSslImplementationName(OpenSSLImplementation.class.getName());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1071 */       this.protocolHandler.init();
/* 1072 */     } catch (Exception e) {
/* 1073 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerInitializationFailed"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/* 1087 */     String id = (this.protocolHandler != null) ? this.protocolHandler.getId() : null;
/* 1088 */     if (id == null && getPortWithOffset() < 0) {
/* 1089 */       throw new LifecycleException(sm
/* 1090 */           .getString("coyoteConnector.invalidPort", new Object[] { Integer.valueOf(getPortWithOffset()) }));
/*      */     }
/*      */     
/* 1093 */     setState(LifecycleState.STARTING);
/*      */ 
/*      */     
/* 1096 */     if (this.protocolHandler != null && this.service != null) {
/* 1097 */       this.protocolHandler.setUtilityExecutor(this.service.getServer().getUtilityExecutor());
/*      */     }
/*      */     
/*      */     try {
/* 1101 */       this.protocolHandler.start();
/* 1102 */     } catch (Exception e) {
/*      */       
/* 1104 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerStartFailed"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/* 1117 */     setState(LifecycleState.STOPPING);
/*      */     
/*      */     try {
/* 1120 */       if (this.protocolHandler != null) {
/* 1121 */         this.protocolHandler.stop();
/*      */       }
/* 1123 */     } catch (Exception e) {
/* 1124 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerStopFailed"), e);
/*      */     } 
/*      */ 
/*      */     
/* 1128 */     if (this.protocolHandler != null) {
/* 1129 */       this.protocolHandler.setUtilityExecutor(null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void destroyInternal() throws LifecycleException {
/*      */     try {
/* 1137 */       if (this.protocolHandler != null) {
/* 1138 */         this.protocolHandler.destroy();
/*      */       }
/* 1140 */     } catch (Exception e) {
/* 1141 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerDestroyFailed"), e);
/*      */     } 
/*      */     
/* 1144 */     if (getService() != null) {
/* 1145 */       getService().removeConnector(this);
/*      */     }
/*      */     
/* 1148 */     super.destroyInternal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1155 */     StringBuilder sb = new StringBuilder("Connector[");
/* 1156 */     String name = (String)getProperty("name");
/* 1157 */     if (name == null) {
/* 1158 */       sb.append(getProtocol());
/* 1159 */       sb.append('-');
/* 1160 */       String id = (this.protocolHandler != null) ? this.protocolHandler.getId() : null;
/* 1161 */       if (id != null) {
/* 1162 */         sb.append(id);
/*      */       } else {
/* 1164 */         int port = getPortWithOffset();
/* 1165 */         if (port > 0) {
/* 1166 */           sb.append(port);
/*      */         } else {
/* 1168 */           sb.append("auto-");
/* 1169 */           sb.append(getProperty("nameIndex"));
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1173 */       sb.append(name);
/*      */     } 
/* 1175 */     sb.append(']');
/* 1176 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getDomainInternal() {
/* 1184 */     Service s = getService();
/* 1185 */     if (s == null) {
/* 1186 */       return null;
/*      */     }
/* 1188 */     return this.service.getDomain();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getObjectNameKeyProperties() {
/* 1194 */     return createObjectNameKeyProperties("Connector");
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\Connector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */