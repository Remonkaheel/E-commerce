/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import jakarta.servlet.ReadListener;
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Objects;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoyoteInputStream
/*     */   extends ServletInputStream
/*     */ {
/*  37 */   protected static final StringManager sm = StringManager.getManager(CoyoteInputStream.class);
/*     */ 
/*     */   
/*     */   protected InputBuffer ib;
/*     */ 
/*     */   
/*     */   protected CoyoteInputStream(InputBuffer ib) {
/*  44 */     this.ib = ib;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/*  52 */     this.ib = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  61 */     throw new CloneNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  67 */     checkNonBlockingRead();
/*     */     
/*  69 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       
/*     */       try {
/*  72 */         Integer result = AccessController.<Integer>doPrivileged(new PrivilegedRead(this.ib));
/*  73 */         return result.intValue();
/*  74 */       } catch (PrivilegedActionException pae) {
/*  75 */         Exception e = pae.getException();
/*  76 */         if (e instanceof IOException) {
/*  77 */           throw (IOException)e;
/*     */         }
/*  79 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/*  83 */     return this.ib.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  90 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/*  92 */         Integer result = AccessController.<Integer>doPrivileged(new PrivilegedAvailable(this.ib));
/*  93 */         return result.intValue();
/*  94 */       } catch (PrivilegedActionException pae) {
/*  95 */         Exception e = pae.getException();
/*  96 */         if (e instanceof IOException) {
/*  97 */           throw (IOException)e;
/*     */         }
/*  99 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 103 */     return this.ib.available();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 109 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 115 */     checkNonBlockingRead();
/*     */     
/* 117 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 119 */         Integer result = AccessController.<Integer>doPrivileged(new PrivilegedReadArray(this.ib, b, off, len));
/* 120 */         return result.intValue();
/* 121 */       } catch (PrivilegedActionException pae) {
/* 122 */         Exception e = pae.getException();
/* 123 */         if (e instanceof IOException) {
/* 124 */           throw (IOException)e;
/*     */         }
/* 126 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 130 */     return this.ib.read(b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer b) throws IOException {
/* 147 */     Objects.requireNonNull(b);
/* 148 */     checkNonBlockingRead();
/*     */     
/* 150 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 152 */         Integer result = AccessController.<Integer>doPrivileged(new PrivilegedReadBuffer(this.ib, b));
/* 153 */         return result.intValue();
/* 154 */       } catch (PrivilegedActionException pae) {
/* 155 */         Exception e = pae.getException();
/* 156 */         if (e instanceof IOException) {
/* 157 */           throw (IOException)e;
/*     */         }
/* 159 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 163 */     return this.ib.read(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 174 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 176 */         AccessController.doPrivileged(new PrivilegedClose(this.ib));
/* 177 */       } catch (PrivilegedActionException pae) {
/* 178 */         Exception e = pae.getException();
/* 179 */         if (e instanceof IOException) {
/* 180 */           throw (IOException)e;
/*     */         }
/* 182 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     } else {
/*     */       
/* 186 */       this.ib.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFinished() {
/* 192 */     return this.ib.isFinished();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReady() {
/* 198 */     if (this.ib == null) {
/* 199 */       throw new IllegalStateException(sm.getString("coyoteInputStream.null"));
/*     */     }
/* 201 */     return this.ib.isReady();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadListener(ReadListener listener) {
/* 207 */     this.ib.setReadListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkNonBlockingRead() {
/* 212 */     if (!this.ib.isBlocking() && !this.ib.isReady()) {
/* 213 */       throw new IllegalStateException(sm.getString("coyoteInputStream.nbNotready"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedAvailable
/*     */     implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     
/*     */     PrivilegedAvailable(InputBuffer inputBuffer) {
/* 223 */       this.inputBuffer = inputBuffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public Integer run() throws IOException {
/* 228 */       return Integer.valueOf(this.inputBuffer.available());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedClose
/*     */     implements PrivilegedExceptionAction<Void>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     
/*     */     PrivilegedClose(InputBuffer inputBuffer) {
/* 238 */       this.inputBuffer = inputBuffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public Void run() throws IOException {
/* 243 */       this.inputBuffer.close();
/* 244 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedRead
/*     */     implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     
/*     */     PrivilegedRead(InputBuffer inputBuffer) {
/* 254 */       this.inputBuffer = inputBuffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public Integer run() throws IOException {
/* 259 */       Integer integer = Integer.valueOf(this.inputBuffer.readByte());
/* 260 */       return integer;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedReadArray
/*     */     implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     private final byte[] buf;
/*     */     private final int off;
/*     */     private final int len;
/*     */     
/*     */     PrivilegedReadArray(InputBuffer inputBuffer, byte[] buf, int off, int len) {
/* 273 */       this.inputBuffer = inputBuffer;
/* 274 */       this.buf = buf;
/* 275 */       this.off = off;
/* 276 */       this.len = len;
/*     */     }
/*     */ 
/*     */     
/*     */     public Integer run() throws IOException {
/* 281 */       Integer integer = Integer.valueOf(this.inputBuffer.read(this.buf, this.off, this.len));
/* 282 */       return integer;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedReadBuffer
/*     */     implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     private final ByteBuffer bb;
/*     */     
/*     */     PrivilegedReadBuffer(InputBuffer inputBuffer, ByteBuffer bb) {
/* 293 */       this.inputBuffer = inputBuffer;
/* 294 */       this.bb = bb;
/*     */     }
/*     */ 
/*     */     
/*     */     public Integer run() throws IOException {
/* 299 */       Integer integer = Integer.valueOf(this.inputBuffer.read(this.bb));
/* 300 */       return integer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\CoyoteInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */