/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import jakarta.servlet.AsyncContext;
/*      */ import jakarta.servlet.DispatcherType;
/*      */ import jakarta.servlet.FilterChain;
/*      */ import jakarta.servlet.MultipartConfigElement;
/*      */ import jakarta.servlet.RequestDispatcher;
/*      */ import jakarta.servlet.ServletConnection;
/*      */ import jakarta.servlet.ServletContext;
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.ServletInputStream;
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import jakarta.servlet.ServletRequestAttributeEvent;
/*      */ import jakarta.servlet.ServletRequestAttributeListener;
/*      */ import jakarta.servlet.ServletResponse;
/*      */ import jakarta.servlet.SessionTrackingMode;
/*      */ import jakarta.servlet.http.Cookie;
/*      */ import jakarta.servlet.http.HttpServletMapping;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import jakarta.servlet.http.HttpSession;
/*      */ import jakarta.servlet.http.HttpUpgradeHandler;
/*      */ import jakarta.servlet.http.Part;
/*      */ import jakarta.servlet.http.PushBuilder;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.Principal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import javax.security.auth.Subject;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.TomcatPrincipal;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.core.ApplicationFilterChain;
/*      */ import org.apache.catalina.core.ApplicationMapping;
/*      */ import org.apache.catalina.core.ApplicationPart;
/*      */ import org.apache.catalina.core.ApplicationPushBuilder;
/*      */ import org.apache.catalina.core.ApplicationSessionCookieConfig;
/*      */ import org.apache.catalina.core.AsyncContextImpl;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.util.ParameterMap;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.catalina.util.TLSUtil;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.Constants;
/*      */ import org.apache.coyote.UpgradeToken;
/*      */ import org.apache.coyote.http11.upgrade.InternalHttpUpgradeHandler;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.ContextBind;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.ByteChunk;
/*      */ import org.apache.tomcat.util.buf.EncodedSolidusHandling;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.Parameters;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.http.Rfc6265CookieProcessor;
/*      */ import org.apache.tomcat.util.http.ServerCookie;
/*      */ import org.apache.tomcat.util.http.ServerCookies;
/*      */ import org.apache.tomcat.util.http.fileupload.FileItem;
/*      */ import org.apache.tomcat.util.http.fileupload.FileItemFactory;
/*      */ import org.apache.tomcat.util.http.fileupload.FileUpload;
/*      */ import org.apache.tomcat.util.http.fileupload.FileUploadException;
/*      */ import org.apache.tomcat.util.http.fileupload.RequestContext;
/*      */ import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
/*      */ import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
/*      */ import org.apache.tomcat.util.http.fileupload.impl.SizeException;
/*      */ import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;
/*      */ import org.apache.tomcat.util.http.parser.AcceptLanguage;
/*      */ import org.apache.tomcat.util.http.parser.MediaType;
/*      */ import org.apache.tomcat.util.http.parser.Upgrade;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Request
/*      */   implements HttpServletRequest
/*      */ {
/*      */   private static final String HTTP_UPGRADE_HEADER_NAME = "upgrade";
/*  133 */   private static final Log log = LogFactory.getLog(Request.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected org.apache.coyote.Request coyoteRequest;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Request(Connector connector) {
/*  190 */     this.cookies = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  202 */     this.attributes = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  209 */     this.sslAttributesParsed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  215 */     this.locales = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  221 */     this.notes = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  227 */     this.authType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  233 */     this.internalDispatcherType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  239 */     this.inputBuffer = new InputBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  245 */     this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  251 */     this.reader = new CoyoteReader(this.inputBuffer);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  257 */     this.usingInputStream = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  263 */     this.usingReader = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  269 */     this.userPrincipal = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  275 */     this.parametersParsed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  281 */     this.cookiesParsed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  287 */     this.cookiesConverted = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  293 */     this.secure = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  299 */     this.subject = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  306 */     this.postData = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  312 */     this.parameterMap = new ParameterMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  318 */     this.parts = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  324 */     this.partsParseException = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  330 */     this.session = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  336 */     this.requestDispatcherPath = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  342 */     this.requestedSessionCookie = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  348 */     this.requestedSessionId = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  354 */     this.requestedSessionURL = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  360 */     this.requestedSessionSSL = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  366 */     this.localesParsed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  372 */     this.localPort = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  377 */     this.remoteAddr = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  383 */     this.peerAddr = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  389 */     this.remoteHost = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  395 */     this.remotePort = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  400 */     this.localAddr = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  406 */     this.localName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  411 */     this.asyncContext = null;
/*      */     
/*  413 */     this.asyncSupported = null;
/*      */     
/*  415 */     this.applicationRequest = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  420 */     this.maxParameterCount = -1;
/*      */     
/*  422 */     this.maxPartCount = -1;
/*      */     
/*  424 */     this.maxPartHeaderSize = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  597 */     this.filterChain = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  629 */     this.mappingData = new MappingData();
/*  630 */     this.applicationMapping = new ApplicationMapping(this.mappingData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  643 */     this.facade = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  683 */     this.response = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  714 */     this.URIConverter = null; this.connector = connector; if (connector != null) {
/*      */       this.maxParameterCount = connector.getMaxParameterCount(); this.maxPartCount = connector.getMaxPartCount();
/*      */       this.maxPartHeaderSize = connector.getMaxPartHeaderSize();
/*      */     } 
/*      */   } public void setCoyoteRequest(org.apache.coyote.Request coyoteRequest) { this.coyoteRequest = coyoteRequest;
/*      */     this.inputBuffer.setRequest(coyoteRequest); } public org.apache.coyote.Request getCoyoteRequest() { return this.coyoteRequest; } protected static final StringManager sm = StringManager.getManager(Request.class); protected Cookie[] cookies; protected static final Locale defaultLocale = Locale.getDefault(); private final Map<String, Object> attributes; protected boolean sslAttributesParsed; protected final ArrayList<Locale> locales; private final transient HashMap<String, Object> notes; protected String authType; protected DispatcherType internalDispatcherType; protected final InputBuffer inputBuffer; protected CoyoteInputStream inputStream; protected CoyoteReader reader; protected boolean usingInputStream; protected boolean usingReader; protected Principal userPrincipal; protected boolean parametersParsed; protected boolean cookiesParsed; protected boolean cookiesConverted; protected boolean secure; protected transient Subject subject; protected static final int CACHED_POST_LEN = 8192; protected byte[] postData; protected ParameterMap<String, String[]> parameterMap; protected Collection<Part> parts; protected Exception partsParseException; protected Session session; protected Object requestDispatcherPath; protected boolean requestedSessionCookie; protected String requestedSessionId; protected boolean requestedSessionURL; protected boolean requestedSessionSSL; protected boolean localesParsed; protected int localPort; protected String remoteAddr;
/*  720 */   protected B2CConverter getURIConverter() { return this.URIConverter; }
/*      */   protected String peerAddr;
/*      */   protected String remoteHost;
/*      */   protected int remotePort;
/*      */   protected String localAddr;
/*      */   protected String localName; private volatile AsyncContextImpl asyncContext; protected Boolean asyncSupported; private HttpServletRequest applicationRequest; private int maxParameterCount; private int maxPartCount; private int maxPartHeaderSize; protected final Connector connector; protected FilterChain filterChain; protected final MappingData mappingData; private final ApplicationMapping applicationMapping; protected RequestFacade facade; protected Response response; protected B2CConverter URIConverter; public void addPathParameter(String name, String value) { this.coyoteRequest.addPathParameter(name, value); } public String getPathParameter(String name) { return this.coyoteRequest.getPathParameter(name); } public void setAsyncSupported(boolean asyncSupported) { this.asyncSupported = Boolean.valueOf(asyncSupported); } public void recycle() { this.internalDispatcherType = null; this.requestDispatcherPath = null; this.authType = null; this.inputBuffer.recycle(); this.usingInputStream = false; this.usingReader = false; this.userPrincipal = null; this.subject = null; this.parametersParsed = false; if (this.connector != null) { this.maxParameterCount = this.connector.getMaxParameterCount(); this.maxPartCount = this.connector.getMaxPartCount(); this.maxPartHeaderSize = this.connector.getMaxPartHeaderSize(); } else { this.maxParameterCount = -1; this.maxPartCount = -1; this.maxPartHeaderSize = -1; }  if (this.parts != null) { for (Part part : this.parts) { try { part.delete(); } catch (Throwable t) { ExceptionUtils.handleThrowable(t); log.warn(sm.getString("coyoteRequest.deletePartFailed", new Object[] { part.getName() }), t); }  }  this.parts = null; }  this.partsParseException = null; this.locales.clear(); this.localesParsed = false; this.secure = false; this.remoteAddr = null; this.peerAddr = null; this.remoteHost = null; this.remotePort = -1; this.localPort = -1; this.localAddr = null; this.localName = null; this.attributes.clear(); this.sslAttributesParsed = false; this.notes.clear(); recycleSessionInfo(); recycleCookieInfo(false); if (getDiscardFacades()) { this.parameterMap = new ParameterMap(); } else { this.parameterMap.setLocked(false); this.parameterMap.clear(); }  this.mappingData.recycle(); this.applicationMapping.recycle(); this.applicationRequest = null; if (getDiscardFacades()) { if (this.facade != null) { this.facade.clear(); this.facade = null; }  if (this.inputStream != null) { this.inputStream.clear(); this.inputStream = null; }  if (this.reader != null) { this.reader.clear(); this.reader = null; }  }  this.asyncSupported = null; if (this.asyncContext != null) { this.asyncContext.recycle(); this.asyncContext = null; }
/*      */      } public void recycleSessionInfo() { if (this.session != null)
/*      */       try { this.session.endAccess(); }
/*      */       catch (Throwable t) { ExceptionUtils.handleThrowable(t); log.warn(sm.getString("coyoteRequest.sessionEndAccessFail"), t); }
/*  729 */         this.session = null; this.requestedSessionCookie = false; this.requestedSessionId = null; this.requestedSessionURL = false; this.requestedSessionSSL = false; } protected void setURIConverter(B2CConverter URIConverter) { this.URIConverter = URIConverter; }
/*      */   protected void recycleCookieInfo(boolean recycleCoyote) { this.cookiesParsed = false;
/*      */     this.cookiesConverted = false;
/*      */     this.cookies = null;
/*      */     if (recycleCoyote)
/*      */       getCoyoteRequest().getCookies().recycle();  }
/*      */   public Connector getConnector() { return this.connector; }
/*      */   public Context getContext() { return this.mappingData.context; }
/*  737 */   public boolean getDiscardFacades() { return (this.connector == null || this.connector.getDiscardFacades()); } public Wrapper getWrapper() { return this.mappingData.wrapper; } public FilterChain getFilterChain() { return this.filterChain; }
/*      */   public void setFilterChain(FilterChain filterChain) { this.filterChain = filterChain; }
/*      */   public Host getHost() { return this.mappingData.host; }
/*      */   public MappingData getMappingData() { return this.mappingData; }
/*      */   public HttpServletRequest getRequest() { if (this.facade == null)
/*      */       this.facade = new RequestFacade(this);  if (this.applicationRequest == null)
/*      */       this.applicationRequest = this.facade;  return this.applicationRequest; }
/*      */   public void setRequest(HttpServletRequest applicationRequest) { ServletRequest servletRequest; HttpServletRequest httpServletRequest = applicationRequest; while (httpServletRequest instanceof HttpServletRequestWrapper)
/*      */       servletRequest = ((HttpServletRequestWrapper)httpServletRequest).getRequest();  if (servletRequest != this.facade)
/*      */       throw new IllegalArgumentException(sm.getString("request.illegalWrap"));  this.applicationRequest = applicationRequest; }
/*      */   public Response getResponse() { return this.response; }
/*      */   public void setResponse(Response response) { this.response = response; }
/*      */   public InputStream getStream() { if (this.inputStream == null)
/*      */       this.inputStream = new CoyoteInputStream(this.inputBuffer);  return (InputStream)this.inputStream; }
/*  751 */   public ServletInputStream createInputStream() throws IOException { if (this.inputStream == null) {
/*  752 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/*  754 */     return this.inputStream; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finishRequest() throws IOException {
/*  764 */     if (this.response.getStatus() == 413) {
/*  765 */       checkSwallowInput();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getNote(String name) {
/*  777 */     return this.notes.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNote(String name) {
/*  787 */     this.notes.remove(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocalPort(int port) {
/*  797 */     this.localPort = port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNote(String name, Object value) {
/*  808 */     this.notes.put(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRemoteAddr(String remoteAddr) {
/*  818 */     this.remoteAddr = remoteAddr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRemoteHost(String remoteHost) {
/*  828 */     this.remoteHost = remoteHost;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSecure(boolean secure) {
/*  838 */     this.secure = secure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServerPort(int port) {
/*  848 */     this.coyoteRequest.setServerPort(port);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxParameterCount(int maxParameterCount) {
/*  858 */     this.maxParameterCount = maxParameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxPartCount(int maxPartCount) {
/*  868 */     this.maxPartCount = maxPartCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxPartHeaderSize(int maxPartHeaderSize) {
/*  878 */     this.maxPartHeaderSize = maxPartHeaderSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(String name) {
/*  887 */     SpecialAttributeAdapter adapter = specialAttributes.get(name);
/*  888 */     if (adapter != null) {
/*  889 */       return adapter.get(this, name);
/*      */     }
/*      */     
/*  892 */     Object attr = this.attributes.get(name);
/*      */     
/*  894 */     if (attr != null) {
/*  895 */       return attr;
/*      */     }
/*      */     
/*  898 */     attr = this.coyoteRequest.getAttribute(name);
/*  899 */     if (attr != null) {
/*  900 */       return attr;
/*      */     }
/*  902 */     if (!this.sslAttributesParsed && TLSUtil.isTLSRequestAttribute(name)) {
/*  903 */       this.coyoteRequest.action(ActionCode.REQ_SSL_ATTRIBUTE, this.coyoteRequest);
/*  904 */       attr = this.coyoteRequest.getAttribute("jakarta.servlet.request.X509Certificate");
/*  905 */       if (attr != null) {
/*  906 */         this.attributes.put("jakarta.servlet.request.X509Certificate", attr);
/*      */       }
/*  908 */       attr = this.coyoteRequest.getAttribute("jakarta.servlet.request.cipher_suite");
/*  909 */       if (attr != null) {
/*  910 */         this.attributes.put("jakarta.servlet.request.cipher_suite", attr);
/*      */       }
/*  912 */       attr = this.coyoteRequest.getAttribute("jakarta.servlet.request.key_size");
/*  913 */       if (attr != null) {
/*  914 */         this.attributes.put("jakarta.servlet.request.key_size", attr);
/*      */       }
/*  916 */       attr = this.coyoteRequest.getAttribute("jakarta.servlet.request.ssl_session_id");
/*  917 */       if (attr != null) {
/*  918 */         this.attributes.put("jakarta.servlet.request.ssl_session_id", attr);
/*      */       }
/*  920 */       attr = this.coyoteRequest.getAttribute("jakarta.servlet.request.ssl_session_mgr");
/*  921 */       if (attr != null) {
/*  922 */         this.attributes.put("jakarta.servlet.request.ssl_session_mgr", attr);
/*      */       }
/*  924 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_protocol_version");
/*  925 */       if (attr != null) {
/*  926 */         this.attributes.put("org.apache.tomcat.util.net.secure_protocol_version", attr);
/*      */       }
/*  928 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_requested_protocol_versions");
/*  929 */       if (attr != null) {
/*  930 */         this.attributes.put("org.apache.tomcat.util.net.secure_requested_protocol_versions", attr);
/*      */       }
/*  932 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_requested_ciphers");
/*  933 */       if (attr != null) {
/*  934 */         this.attributes.put("org.apache.tomcat.util.net.secure_requested_ciphers", attr);
/*      */       }
/*  936 */       attr = this.attributes.get(name);
/*  937 */       this.sslAttributesParsed = true;
/*      */     } 
/*  939 */     return attr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getContentLengthLong() {
/*  945 */     return this.coyoteRequest.getContentLengthLong();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getAttributeNames() {
/*  976 */     if (isSecure() && !this.sslAttributesParsed) {
/*  977 */       getAttribute("jakarta.servlet.request.X509Certificate");
/*      */     }
/*      */ 
/*      */     
/*  981 */     Set<String> names = new HashSet<>(this.attributes.keySet());
/*  982 */     return Collections.enumeration(names);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCharacterEncoding() {
/*  988 */     String characterEncoding = this.coyoteRequest.getCharacterEncoding();
/*  989 */     if (characterEncoding != null) {
/*  990 */       return characterEncoding;
/*      */     }
/*      */     
/*  993 */     Context context = getContext();
/*  994 */     if (context != null) {
/*  995 */       return context.getRequestCharacterEncoding();
/*      */     }
/*      */     
/*  998 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private Charset getCharset() {
/* 1003 */     Charset charset = null;
/*      */     try {
/* 1005 */       charset = this.coyoteRequest.getCharset();
/* 1006 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */     
/* 1009 */     if (charset != null) {
/* 1010 */       return charset;
/*      */     }
/*      */     
/* 1013 */     Context context = getContext();
/* 1014 */     if (context != null) {
/* 1015 */       String encoding = context.getRequestCharacterEncoding();
/* 1016 */       if (encoding != null) {
/*      */         try {
/* 1018 */           return B2CConverter.getCharset(encoding);
/* 1019 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1025 */     return Constants.DEFAULT_BODY_CHARSET;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getContentLength() {
/* 1031 */     return this.coyoteRequest.getContentLength();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentType() {
/* 1037 */     return this.coyoteRequest.getContentType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentType(String contentType) {
/* 1047 */     this.coyoteRequest.setContentType(contentType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletInputStream getInputStream() throws IOException {
/* 1054 */     if (this.usingReader) {
/* 1055 */       throw new IllegalStateException(sm.getString("coyoteRequest.getInputStream.ise"));
/*      */     }
/*      */     
/* 1058 */     this.usingInputStream = true;
/* 1059 */     if (this.inputStream == null) {
/* 1060 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/* 1062 */     return this.inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/* 1070 */     if (!this.localesParsed) {
/* 1071 */       parseLocales();
/*      */     }
/*      */     
/* 1074 */     if (!this.locales.isEmpty()) {
/* 1075 */       return this.locales.get(0);
/*      */     }
/*      */     
/* 1078 */     return defaultLocale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<Locale> getLocales() {
/* 1085 */     if (!this.localesParsed) {
/* 1086 */       parseLocales();
/*      */     }
/*      */     
/* 1089 */     if (!this.locales.isEmpty()) {
/* 1090 */       return Collections.enumeration(this.locales);
/*      */     }
/* 1092 */     ArrayList<Locale> results = new ArrayList<>();
/* 1093 */     results.add(defaultLocale);
/* 1094 */     return Collections.enumeration(results);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getParameter(String name) {
/* 1108 */     if (!this.parametersParsed) {
/* 1109 */       parseParameters();
/*      */     }
/*      */     
/* 1112 */     return this.coyoteRequest.getParameters().getParameter(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String[]> getParameterMap() {
/* 1126 */     if (this.parameterMap.isLocked()) {
/* 1127 */       return (Map<String, String[]>)this.parameterMap;
/*      */     }
/*      */     
/* 1130 */     Enumeration<String> enumeration = getParameterNames();
/* 1131 */     while (enumeration.hasMoreElements()) {
/* 1132 */       String name = enumeration.nextElement();
/* 1133 */       String[] values = getParameterValues(name);
/* 1134 */       this.parameterMap.put(name, values);
/*      */     } 
/*      */     
/* 1137 */     this.parameterMap.setLocked(true);
/*      */     
/* 1139 */     return (Map<String, String[]>)this.parameterMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getParameterNames() {
/* 1150 */     if (!this.parametersParsed) {
/* 1151 */       parseParameters();
/*      */     }
/*      */     
/* 1154 */     return this.coyoteRequest.getParameters().getParameterNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getParameterValues(String name) {
/* 1167 */     if (!this.parametersParsed) {
/* 1168 */       parseParameters();
/*      */     }
/*      */     
/* 1171 */     return this.coyoteRequest.getParameters().getParameterValues(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProtocol() {
/* 1178 */     return this.coyoteRequest.protocol().toStringType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedReader getReader() throws IOException {
/* 1185 */     if (this.usingInputStream) {
/* 1186 */       throw new IllegalStateException(sm.getString("coyoteRequest.getReader.ise"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1193 */     if (this.coyoteRequest.getCharacterEncoding() == null) {
/*      */ 
/*      */       
/* 1196 */       Context context = getContext();
/* 1197 */       if (context != null) {
/* 1198 */         String enc = context.getRequestCharacterEncoding();
/* 1199 */         if (enc != null)
/*      */         {
/*      */           
/* 1202 */           setCharacterEncoding(enc);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1207 */     this.usingReader = true;
/*      */     
/* 1209 */     this.inputBuffer.checkConverter();
/* 1210 */     if (this.reader == null) {
/* 1211 */       this.reader = new CoyoteReader(this.inputBuffer);
/*      */     }
/* 1213 */     return this.reader;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRemoteAddr() {
/* 1219 */     if (this.remoteAddr == null) {
/* 1220 */       this.coyoteRequest.action(ActionCode.REQ_HOST_ADDR_ATTRIBUTE, this.coyoteRequest);
/* 1221 */       this.remoteAddr = this.coyoteRequest.remoteAddr().toString();
/*      */     } 
/* 1223 */     return this.remoteAddr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPeerAddr() {
/* 1231 */     if (this.peerAddr == null) {
/* 1232 */       this.coyoteRequest.action(ActionCode.REQ_PEER_ADDR_ATTRIBUTE, this.coyoteRequest);
/* 1233 */       this.peerAddr = this.coyoteRequest.peerAddr().toString();
/*      */     } 
/* 1235 */     return this.peerAddr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRemoteHost() {
/* 1241 */     if (this.remoteHost == null) {
/* 1242 */       if (!this.connector.getEnableLookups()) {
/* 1243 */         this.remoteHost = getRemoteAddr();
/*      */       } else {
/* 1245 */         this.coyoteRequest.action(ActionCode.REQ_HOST_ATTRIBUTE, this.coyoteRequest);
/* 1246 */         this.remoteHost = this.coyoteRequest.remoteHost().toString();
/*      */       } 
/*      */     }
/* 1249 */     return this.remoteHost;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getRemotePort() {
/* 1254 */     if (this.remotePort == -1) {
/* 1255 */       this.coyoteRequest.action(ActionCode.REQ_REMOTEPORT_ATTRIBUTE, this.coyoteRequest);
/* 1256 */       this.remotePort = this.coyoteRequest.getRemotePort();
/*      */     } 
/* 1258 */     return this.remotePort;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLocalName() {
/* 1263 */     if (this.localName == null) {
/* 1264 */       this.coyoteRequest.action(ActionCode.REQ_LOCAL_NAME_ATTRIBUTE, this.coyoteRequest);
/* 1265 */       this.localName = this.coyoteRequest.localName().toString();
/*      */     } 
/* 1267 */     return this.localName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLocalAddr() {
/* 1272 */     if (this.localAddr == null) {
/* 1273 */       this.coyoteRequest.action(ActionCode.REQ_LOCAL_ADDR_ATTRIBUTE, this.coyoteRequest);
/* 1274 */       this.localAddr = this.coyoteRequest.localAddr().toString();
/*      */     } 
/* 1276 */     return this.localAddr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLocalPort() {
/* 1282 */     if (this.localPort == -1) {
/* 1283 */       this.coyoteRequest.action(ActionCode.REQ_LOCALPORT_ATTRIBUTE, this.coyoteRequest);
/* 1284 */       this.localPort = this.coyoteRequest.getLocalPort();
/*      */     } 
/* 1286 */     return this.localPort;
/*      */   }
/*      */ 
/*      */   
/*      */   public RequestDispatcher getRequestDispatcher(String path) {
/*      */     String requestPath, relative;
/* 1292 */     Context context = getContext();
/* 1293 */     if (context == null) {
/* 1294 */       return null;
/*      */     }
/*      */     
/* 1297 */     if (path == null) {
/* 1298 */       return null;
/*      */     }
/*      */     
/* 1301 */     int fragmentPos = path.indexOf('#');
/* 1302 */     if (fragmentPos > -1) {
/* 1303 */       log.warn(sm.getString("request.fragmentInDispatchPath", new Object[] { path }));
/* 1304 */       path = path.substring(0, fragmentPos);
/*      */     } 
/*      */ 
/*      */     
/* 1308 */     if (path.startsWith("/")) {
/* 1309 */       return context.getServletContext().getRequestDispatcher(path);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1327 */     String servletPath = (String)getAttribute("jakarta.servlet.include.servlet_path");
/* 1328 */     if (servletPath == null) {
/* 1329 */       servletPath = getServletPath();
/*      */     }
/*      */ 
/*      */     
/* 1333 */     String pathInfo = getPathInfo();
/*      */ 
/*      */     
/* 1336 */     if (pathInfo == null) {
/* 1337 */       requestPath = servletPath;
/*      */     } else {
/* 1339 */       requestPath = servletPath + servletPath;
/*      */     } 
/*      */     
/* 1342 */     int pos = requestPath.lastIndexOf('/');
/*      */     
/* 1344 */     if (context.getDispatchersUseEncodedPaths()) {
/* 1345 */       if (pos >= 0) {
/* 1346 */         relative = URLEncoder.DEFAULT.encode(requestPath.substring(0, pos + 1), StandardCharsets.UTF_8) + URLEncoder.DEFAULT.encode(requestPath.substring(0, pos + 1), StandardCharsets.UTF_8);
/*      */       } else {
/* 1348 */         relative = URLEncoder.DEFAULT.encode(requestPath, StandardCharsets.UTF_8) + URLEncoder.DEFAULT.encode(requestPath, StandardCharsets.UTF_8);
/*      */       }
/*      */     
/* 1351 */     } else if (pos >= 0) {
/* 1352 */       relative = requestPath.substring(0, pos + 1) + requestPath.substring(0, pos + 1);
/*      */     } else {
/* 1354 */       relative = requestPath + requestPath;
/*      */     } 
/*      */ 
/*      */     
/* 1358 */     return context.getServletContext().getRequestDispatcher(relative);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getScheme() {
/* 1364 */     return this.coyoteRequest.scheme().toStringType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerName() {
/* 1370 */     return this.coyoteRequest.serverName().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getServerPort() {
/* 1376 */     return this.coyoteRequest.getServerPort();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSecure() {
/* 1382 */     return this.secure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(String name) {
/* 1390 */     if (name.startsWith("org.apache.tomcat.")) {
/* 1391 */       this.coyoteRequest.getAttributes().remove(name);
/*      */     }
/*      */     
/* 1394 */     boolean found = this.attributes.containsKey(name);
/* 1395 */     if (found) {
/* 1396 */       Object value = this.attributes.get(name);
/* 1397 */       this.attributes.remove(name);
/*      */ 
/*      */       
/* 1400 */       notifyAttributeRemoved(name, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, Object value) {
/* 1409 */     if (name == null) {
/* 1410 */       throw new IllegalArgumentException(sm.getString("coyoteRequest.setAttribute.namenull"));
/*      */     }
/*      */ 
/*      */     
/* 1414 */     if (value == null) {
/* 1415 */       removeAttribute(name);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1420 */     SpecialAttributeAdapter adapter = specialAttributes.get(name);
/* 1421 */     if (adapter != null) {
/* 1422 */       adapter.set(this, name, value);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1428 */     if (Globals.IS_SECURITY_ENABLED && name.equals("org.apache.tomcat.sendfile.filename")) {
/*      */       String canonicalPath;
/*      */ 
/*      */       
/*      */       try {
/* 1433 */         canonicalPath = (new File(value.toString())).getCanonicalPath();
/* 1434 */       } catch (IOException ioe) {
/* 1435 */         throw new SecurityException(sm.getString("coyoteRequest.sendfileNotCanonical", new Object[] { value }), ioe);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1440 */       System.getSecurityManager().checkRead(canonicalPath);
/*      */       
/* 1442 */       value = canonicalPath;
/*      */     } 
/*      */     
/* 1445 */     Object oldValue = this.attributes.put(name, value);
/*      */ 
/*      */     
/* 1448 */     if (name.startsWith("org.apache.tomcat.")) {
/* 1449 */       this.coyoteRequest.setAttribute(name, value);
/*      */     }
/*      */ 
/*      */     
/* 1453 */     notifyAttributeAssigned(name, value, oldValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyAttributeAssigned(String name, Object value, Object oldValue) {
/*      */     ServletRequestAttributeEvent event;
/* 1465 */     Context context = getContext();
/* 1466 */     if (context == null) {
/*      */       return;
/*      */     }
/* 1469 */     Object[] listeners = context.getApplicationEventListeners();
/* 1470 */     if (listeners == null || listeners.length == 0) {
/*      */       return;
/*      */     }
/* 1473 */     boolean replaced = (oldValue != null);
/*      */     
/* 1475 */     if (replaced) {
/* 1476 */       event = new ServletRequestAttributeEvent(context.getServletContext(), (ServletRequest)getRequest(), name, oldValue);
/*      */     } else {
/* 1478 */       event = new ServletRequestAttributeEvent(context.getServletContext(), (ServletRequest)getRequest(), name, value);
/*      */     } 
/*      */     
/* 1481 */     for (Object o : listeners) {
/* 1482 */       if (o instanceof ServletRequestAttributeListener) {
/*      */ 
/*      */         
/* 1485 */         ServletRequestAttributeListener listener = (ServletRequestAttributeListener)o;
/*      */         try {
/* 1487 */           if (replaced) {
/* 1488 */             listener.attributeReplaced(event);
/*      */           } else {
/* 1490 */             listener.attributeAdded(event);
/*      */           } 
/* 1492 */         } catch (Throwable t) {
/* 1493 */           ExceptionUtils.handleThrowable(t);
/*      */           
/* 1495 */           this.attributes.put("jakarta.servlet.error.exception", t);
/* 1496 */           context.getLogger().error(sm.getString("coyoteRequest.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyAttributeRemoved(String name, Object value) {
/* 1509 */     Context context = getContext();
/* 1510 */     Object[] listeners = context.getApplicationEventListeners();
/* 1511 */     if (listeners == null || listeners.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1515 */     ServletRequestAttributeEvent event = new ServletRequestAttributeEvent(context.getServletContext(), (ServletRequest)getRequest(), name, value);
/* 1516 */     for (Object o : listeners) {
/* 1517 */       if (o instanceof ServletRequestAttributeListener) {
/*      */ 
/*      */         
/* 1520 */         ServletRequestAttributeListener listener = (ServletRequestAttributeListener)o;
/*      */         try {
/* 1522 */           listener.attributeRemoved(event);
/* 1523 */         } catch (Throwable t) {
/* 1524 */           ExceptionUtils.handleThrowable(t);
/*      */           
/* 1526 */           this.attributes.put("jakarta.servlet.error.exception", t);
/* 1527 */           context.getLogger().error(sm.getString("coyoteRequest.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterEncoding(String enc) throws UnsupportedEncodingException {
/* 1536 */     if (this.usingReader) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1541 */     Charset charset = B2CConverter.getCharset(enc);
/*      */ 
/*      */     
/* 1544 */     this.coyoteRequest.setCharset(charset);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletContext getServletContext() {
/* 1550 */     return getContext().getServletContext();
/*      */   }
/*      */ 
/*      */   
/*      */   public AsyncContext startAsync() {
/* 1555 */     return startAsync((ServletRequest)getRequest(), (ServletResponse)this.response.getResponse());
/*      */   }
/*      */ 
/*      */   
/*      */   public AsyncContext startAsync(ServletRequest request, ServletResponse response) {
/* 1560 */     if (!isAsyncSupported()) {
/* 1561 */       IllegalStateException ise = new IllegalStateException(sm.getString("request.asyncNotSupported"));
/* 1562 */       log.warn(sm.getString("coyoteRequest.noAsync", new Object[] { StringUtils.join(getNonAsyncClassNames()) }), ise);
/* 1563 */       throw ise;
/*      */     } 
/*      */     
/* 1566 */     if (this.asyncContext == null) {
/* 1567 */       this.asyncContext = new AsyncContextImpl(this);
/*      */     }
/*      */     
/* 1570 */     this.asyncContext.setStarted(getContext(), request, response, (request == 
/* 1571 */         getRequest() && response == getResponse().getResponse()));
/* 1572 */     this.asyncContext.setTimeout(getConnector().getAsyncTimeout());
/*      */     
/* 1574 */     return (AsyncContext)this.asyncContext;
/*      */   }
/*      */ 
/*      */   
/*      */   private Set<String> getNonAsyncClassNames() {
/* 1579 */     Set<String> result = new HashSet<>();
/*      */     
/* 1581 */     Wrapper wrapper = getWrapper();
/* 1582 */     if (!wrapper.isAsyncSupported()) {
/* 1583 */       result.add(wrapper.getServletClass());
/*      */     }
/*      */     
/* 1586 */     FilterChain filterChain = getFilterChain();
/* 1587 */     if (filterChain instanceof ApplicationFilterChain) {
/* 1588 */       ((ApplicationFilterChain)filterChain).findNonAsyncFilters(result);
/*      */     } else {
/* 1590 */       result.add(sm.getString("coyoteRequest.filterAsyncSupportUnknown"));
/*      */     } 
/*      */     
/* 1593 */     Wrapper wrapper1 = wrapper;
/* 1594 */     while (wrapper1 != null) {
/* 1595 */       wrapper1.getPipeline().findNonAsyncValves(result);
/* 1596 */       Container container = wrapper1.getParent();
/*      */     } 
/*      */     
/* 1599 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAsyncStarted() {
/* 1604 */     if (this.asyncContext == null) {
/* 1605 */       return false;
/*      */     }
/*      */     
/* 1608 */     return this.asyncContext.isStarted();
/*      */   }
/*      */   
/*      */   public boolean isAsyncDispatching() {
/* 1612 */     if (this.asyncContext == null) {
/* 1613 */       return false;
/*      */     }
/*      */     
/* 1616 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1617 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_DISPATCHING, result);
/* 1618 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsyncCompleting() {
/* 1622 */     if (this.asyncContext == null) {
/* 1623 */       return false;
/*      */     }
/*      */     
/* 1626 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1627 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_COMPLETING, result);
/* 1628 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsync() {
/* 1632 */     if (this.asyncContext == null) {
/* 1633 */       return false;
/*      */     }
/*      */     
/* 1636 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1637 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_ASYNC, result);
/* 1638 */     return result.get();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAsyncSupported() {
/* 1643 */     if (this.asyncSupported == null) {
/* 1644 */       return true;
/*      */     }
/*      */     
/* 1647 */     return this.asyncSupported.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public AsyncContext getAsyncContext() {
/* 1652 */     if (!isAsyncStarted()) {
/* 1653 */       throw new IllegalStateException(sm.getString("request.notAsync"));
/*      */     }
/* 1655 */     return (AsyncContext)this.asyncContext;
/*      */   }
/*      */   
/*      */   public AsyncContextImpl getAsyncContextInternal() {
/* 1659 */     return this.asyncContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public DispatcherType getDispatcherType() {
/* 1664 */     return Objects.<DispatcherType>requireNonNullElse(this.internalDispatcherType, DispatcherType.REQUEST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestId() {
/* 1670 */     return this.coyoteRequest.getRequestId();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProtocolRequestId() {
/* 1676 */     return this.coyoteRequest.getProtocolRequestId();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletConnection getServletConnection() {
/* 1682 */     return this.coyoteRequest.getServletConnection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCookie(Cookie cookie) {
/* 1695 */     if (!this.cookiesConverted) {
/* 1696 */       convertCookies();
/*      */     }
/*      */     
/* 1699 */     int size = 0;
/* 1700 */     if (this.cookies != null) {
/* 1701 */       size = this.cookies.length;
/*      */     }
/*      */     
/* 1704 */     Cookie[] newCookies = new Cookie[size + 1];
/* 1705 */     if (this.cookies != null) {
/* 1706 */       System.arraycopy(this.cookies, 0, newCookies, 0, size);
/*      */     }
/* 1708 */     newCookies[size] = cookie;
/*      */     
/* 1710 */     this.cookies = newCookies;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLocale(Locale locale) {
/* 1722 */     this.locales.add(locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCookies() {
/* 1730 */     this.cookiesParsed = true;
/* 1731 */     this.cookiesConverted = true;
/* 1732 */     this.cookies = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearLocales() {
/* 1740 */     this.locales.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAuthType(String type) {
/* 1751 */     this.authType = type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPathInfo(String path) {
/* 1762 */     this.mappingData.pathInfo.setString(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestedSessionCookie(boolean flag) {
/* 1774 */     this.requestedSessionCookie = flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestedSessionId(String id) {
/* 1787 */     this.requestedSessionId = id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestedSessionURL(boolean flag) {
/* 1800 */     this.requestedSessionURL = flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestedSessionSSL(boolean flag) {
/* 1813 */     this.requestedSessionSSL = flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDecodedRequestURI() {
/* 1824 */     return this.coyoteRequest.decodedURI().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MessageBytes getDecodedRequestURIMB() {
/* 1834 */     return this.coyoteRequest.decodedURI();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserPrincipal(Principal principal) {
/* 1846 */     if (Globals.IS_SECURITY_ENABLED && principal != null) {
/* 1847 */       if (this.subject == null) {
/* 1848 */         HttpSession session = getSession(false);
/* 1849 */         if (session == null) {
/*      */           
/* 1851 */           this.subject = newSubject(principal);
/*      */         } else {
/*      */           
/* 1854 */           this.subject = (Subject)session.getAttribute("javax.security.auth.subject");
/* 1855 */           if (this.subject == null) {
/* 1856 */             this.subject = newSubject(principal);
/* 1857 */             session.setAttribute("javax.security.auth.subject", this.subject);
/*      */           } else {
/* 1859 */             this.subject.getPrincipals().add(principal);
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1863 */         this.subject.getPrincipals().add(principal);
/*      */       } 
/*      */     }
/* 1866 */     this.userPrincipal = principal;
/*      */   }
/*      */ 
/*      */   
/*      */   private Subject newSubject(Principal principal) {
/* 1871 */     Subject result = new Subject();
/* 1872 */     result.getPrincipals().add(principal);
/* 1873 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTrailerFieldsReady() {
/* 1881 */     return this.coyoteRequest.isTrailerFieldsReady();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> getTrailerFields() {
/* 1887 */     if (!isTrailerFieldsReady()) {
/* 1888 */       throw new IllegalStateException(sm.getString("coyoteRequest.trailersNotReady"));
/*      */     }
/*      */     
/* 1891 */     return this.coyoteRequest.getTrailerFields();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public PushBuilder newPushBuilder() {
/* 1897 */     return newPushBuilder(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public PushBuilder newPushBuilder(HttpServletRequest request) {
/* 1902 */     AtomicBoolean result = new AtomicBoolean();
/* 1903 */     this.coyoteRequest.action(ActionCode.IS_PUSH_SUPPORTED, result);
/* 1904 */     if (result.get()) {
/* 1905 */       return (PushBuilder)new ApplicationPushBuilder(this, request);
/*      */     }
/* 1907 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends HttpUpgradeHandler> T upgrade(Class<T> httpUpgradeHandlerClass) throws IOException, ServletException {
/*      */     HttpUpgradeHandler httpUpgradeHandler;
/* 1917 */     InstanceManager instanceManager = null;
/*      */ 
/*      */     
/*      */     try {
/* 1921 */       if (InternalHttpUpgradeHandler.class.isAssignableFrom(httpUpgradeHandlerClass)) {
/* 1922 */         httpUpgradeHandler = httpUpgradeHandlerClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } else {
/* 1924 */         instanceManager = getContext().getInstanceManager();
/* 1925 */         httpUpgradeHandler = (HttpUpgradeHandler)instanceManager.newInstance(httpUpgradeHandlerClass);
/*      */       } 
/* 1927 */     } catch (ReflectiveOperationException|javax.naming.NamingException|IllegalArgumentException|SecurityException e) {
/* 1928 */       throw new ServletException(e);
/*      */     } 
/*      */     
/* 1931 */     UpgradeToken upgradeToken = new UpgradeToken(httpUpgradeHandler, (ContextBind)getContext(), instanceManager, getUpgradeProtocolName(httpUpgradeHandlerClass));
/*      */     
/* 1933 */     this.coyoteRequest.action(ActionCode.UPGRADE, upgradeToken);
/*      */ 
/*      */ 
/*      */     
/* 1937 */     this.response.setStatus(101);
/*      */     
/* 1939 */     return (T)httpUpgradeHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getUpgradeProtocolName(Class<? extends HttpUpgradeHandler> httpUpgradeHandlerClass) {
/* 1946 */     String result = this.response.getHeader("upgrade");
/*      */     
/* 1948 */     if (result == null) {
/*      */ 
/*      */       
/* 1951 */       List<Upgrade> upgradeProtocols = Upgrade.parse(getHeaders("upgrade"));
/* 1952 */       if (upgradeProtocols != null && upgradeProtocols.size() == 1) {
/* 1953 */         result = ((Upgrade)upgradeProtocols.get(0)).toString();
/*      */       }
/*      */     } 
/*      */     
/* 1957 */     if (result == null)
/*      */     {
/* 1959 */       result = httpUpgradeHandlerClass.getName();
/*      */     }
/* 1961 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthType() {
/* 1967 */     return this.authType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContextPath() {
/* 1973 */     int lastSlash = this.mappingData.contextSlashCount;
/*      */     
/* 1975 */     if (lastSlash == 0) {
/* 1976 */       return "";
/*      */     }
/*      */     
/* 1979 */     String canonicalContextPath = getServletContext().getContextPath();
/*      */     
/* 1981 */     String uri = getRequestURI();
/* 1982 */     int pos = 0;
/* 1983 */     if (!getContext().getAllowMultipleLeadingForwardSlashInPath()) {
/*      */ 
/*      */       
/*      */       do {
/*      */         
/* 1988 */         pos++;
/* 1989 */       } while (pos < uri.length() && uri.charAt(pos) == '/');
/* 1990 */       pos--;
/* 1991 */       uri = uri.substring(pos);
/*      */     } 
/*      */     
/* 1994 */     char[] uriChars = uri.toCharArray();
/*      */     
/* 1996 */     while (lastSlash > 0) {
/* 1997 */       pos = nextSlash(uriChars, pos + 1);
/* 1998 */       if (pos == -1) {
/*      */         break;
/*      */       }
/* 2001 */       lastSlash--;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2008 */     if (pos == -1) {
/* 2009 */       candidate = uri;
/*      */     } else {
/* 2011 */       candidate = uri.substring(0, pos);
/*      */     } 
/* 2013 */     String candidate = removePathParameters(candidate);
/* 2014 */     candidate = UDecoder.URLDecode(candidate, this.connector.getURICharset());
/* 2015 */     candidate = RequestUtil.normalize(candidate);
/* 2016 */     boolean match = canonicalContextPath.equals(candidate);
/* 2017 */     while (!match && pos != -1) {
/* 2018 */       pos = nextSlash(uriChars, pos + 1);
/* 2019 */       if (pos == -1) {
/* 2020 */         candidate = uri;
/*      */       } else {
/* 2022 */         candidate = uri.substring(0, pos);
/*      */       } 
/* 2024 */       candidate = removePathParameters(candidate);
/* 2025 */       candidate = UDecoder.URLDecode(candidate, this.connector.getURICharset());
/* 2026 */       candidate = RequestUtil.normalize(candidate);
/* 2027 */       match = canonicalContextPath.equals(candidate);
/*      */     } 
/* 2029 */     if (match) {
/* 2030 */       if (pos == -1) {
/* 2031 */         return uri;
/*      */       }
/* 2033 */       return uri.substring(0, pos);
/*      */     } 
/*      */ 
/*      */     
/* 2037 */     throw new IllegalStateException(sm
/* 2038 */         .getString("coyoteRequest.getContextPath.ise", new Object[] { canonicalContextPath, uri }));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String removePathParameters(String input) {
/* 2044 */     int nextSemiColon = input.indexOf(';');
/*      */     
/* 2046 */     if (nextSemiColon == -1) {
/* 2047 */       return input;
/*      */     }
/* 2049 */     StringBuilder result = new StringBuilder(input.length());
/* 2050 */     result.append(input, 0, nextSemiColon);
/*      */     while (true) {
/* 2052 */       int nextSlash = input.indexOf('/', nextSemiColon);
/* 2053 */       if (nextSlash == -1) {
/*      */         break;
/*      */       }
/* 2056 */       nextSemiColon = input.indexOf(';', nextSlash);
/* 2057 */       if (nextSemiColon == -1) {
/* 2058 */         result.append(input.substring(nextSlash));
/*      */         break;
/*      */       } 
/* 2061 */       result.append(input, nextSlash, nextSemiColon);
/*      */     } 
/*      */ 
/*      */     
/* 2065 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private int nextSlash(char[] uri, int startPos) {
/* 2070 */     int len = uri.length;
/* 2071 */     int pos = startPos;
/* 2072 */     while (pos < len) {
/* 2073 */       if (uri[pos] == '/')
/* 2074 */         return pos; 
/* 2075 */       if (this.connector.getEncodedSolidusHandlingInternal() == EncodedSolidusHandling.DECODE && uri[pos] == '%' && pos + 2 < len && uri[pos + 1] == '2' && (uri[pos + 2] == 'f' || uri[pos + 2] == 'F'))
/*      */       {
/*      */         
/* 2078 */         return pos;
/*      */       }
/* 2080 */       pos++;
/*      */     } 
/* 2082 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Cookie[] getCookies() {
/* 2088 */     if (!this.cookiesConverted) {
/* 2089 */       convertCookies();
/*      */     }
/* 2091 */     return this.cookies;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServerCookies getServerCookies() {
/* 2102 */     parseCookies();
/* 2103 */     return this.coyoteRequest.getCookies();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getDateHeader(String name) {
/* 2110 */     String value = getHeader(name);
/* 2111 */     if (value == null) {
/* 2112 */       return -1L;
/*      */     }
/*      */ 
/*      */     
/* 2116 */     long result = FastHttpDateFormat.parseDate(value);
/* 2117 */     if (result != -1L) {
/* 2118 */       return result;
/*      */     }
/* 2120 */     throw new IllegalArgumentException(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeader(String name) {
/* 2127 */     return this.coyoteRequest.getHeader(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getHeaders(String name) {
/* 2133 */     return this.coyoteRequest.getMimeHeaders().values(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getHeaderNames() {
/* 2139 */     return this.coyoteRequest.getMimeHeaders().names();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntHeader(String name) {
/* 2146 */     String value = getHeader(name);
/* 2147 */     if (value == null) {
/* 2148 */       return -1;
/*      */     }
/*      */     
/* 2151 */     return Integer.parseInt(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpServletMapping getHttpServletMapping() {
/* 2157 */     return this.applicationMapping.getHttpServletMapping();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMethod() {
/* 2163 */     return this.coyoteRequest.getMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPathInfo() {
/* 2169 */     return this.mappingData.pathInfo.toStringType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPathTranslated() {
/* 2176 */     Context context = getContext();
/* 2177 */     if (context == null) {
/* 2178 */       return null;
/*      */     }
/*      */     
/* 2181 */     if (getPathInfo() == null) {
/* 2182 */       return null;
/*      */     }
/*      */     
/* 2185 */     return context.getServletContext().getRealPath(getPathInfo());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getQueryString() {
/* 2191 */     return this.coyoteRequest.queryString().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRemoteUser() {
/* 2198 */     if (this.userPrincipal == null) {
/* 2199 */       return null;
/*      */     }
/*      */     
/* 2202 */     return this.userPrincipal.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MessageBytes getRequestPathMB() {
/* 2212 */     return this.mappingData.requestPath;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestedSessionId() {
/* 2218 */     return this.requestedSessionId;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestURI() {
/* 2224 */     return this.coyoteRequest.requestURI().toStringType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer getRequestURL() {
/* 2230 */     return RequestUtil.getRequestURL(this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServletPath() {
/* 2236 */     return this.mappingData.wrapperPath.toStringType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpSession getSession() {
/* 2242 */     return getSession(true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpSession getSession(boolean create) {
/* 2248 */     Session session = doGetSession(create);
/* 2249 */     if (session == null) {
/* 2250 */       return null;
/*      */     }
/*      */     
/* 2253 */     return session.getSession();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestedSessionIdFromCookie() {
/* 2260 */     if (this.requestedSessionId == null) {
/* 2261 */       return false;
/*      */     }
/*      */     
/* 2264 */     return this.requestedSessionCookie;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestedSessionIdFromURL() {
/* 2271 */     if (this.requestedSessionId == null) {
/* 2272 */       return false;
/*      */     }
/*      */     
/* 2275 */     return this.requestedSessionURL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestedSessionIdValid() {
/* 2282 */     if (this.requestedSessionId == null) {
/* 2283 */       return false;
/*      */     }
/*      */     
/* 2286 */     Context context = getContext();
/* 2287 */     if (context == null) {
/* 2288 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2295 */     ClassLoader originalClassLoader = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*      */     try {
/* 2297 */       Manager manager = context.getManager();
/* 2298 */       if (manager == null) {
/* 2299 */         return false;
/*      */       }
/*      */       
/* 2302 */       Session session = null;
/*      */       try {
/* 2304 */         session = manager.findSession(this.requestedSessionId);
/* 2305 */       } catch (IOException iOException) {}
/*      */ 
/*      */ 
/*      */       
/* 2309 */       if (session == null || !session.isValid()) {
/*      */         
/* 2311 */         if ((getMappingData()).contexts != null) {
/* 2312 */           for (int i = (getMappingData()).contexts.length; i > 0; i--) {
/* 2313 */             Context ctxt = (getMappingData()).contexts[i - 1];
/*      */             try {
/* 2315 */               if (ctxt.getManager().findSession(this.requestedSessionId) != null) {
/* 2316 */                 return true;
/*      */               }
/* 2318 */             } catch (IOException iOException) {}
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 2323 */         return false;
/*      */       } 
/*      */       
/* 2326 */       return true;
/*      */     } finally {
/* 2328 */       context.unbind(Globals.IS_SECURITY_ENABLED, originalClassLoader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUserInRole(String role) {
/* 2337 */     if (this.userPrincipal == null) {
/* 2338 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2342 */     Context context = getContext();
/* 2343 */     if (context == null) {
/* 2344 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2349 */     if ("*".equals(role)) {
/* 2350 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2355 */     if ("**".equals(role) && !context.findSecurityRole("**")) {
/* 2356 */       return (this.userPrincipal != null);
/*      */     }
/*      */     
/* 2359 */     Realm realm = context.getRealm();
/* 2360 */     if (realm == null) {
/* 2361 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2365 */     return realm.hasRole(getWrapper(), this.userPrincipal, role);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal getPrincipal() {
/* 2373 */     return this.userPrincipal;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal getUserPrincipal() {
/* 2379 */     if (this.userPrincipal instanceof TomcatPrincipal) {
/* 2380 */       GSSCredential gssCredential = ((TomcatPrincipal)this.userPrincipal).getGssCredential();
/* 2381 */       if (gssCredential != null) {
/* 2382 */         int left = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 2394 */           left = gssCredential.getRemainingLifetime();
/* 2395 */         } catch (GSSException|IllegalStateException e) {
/* 2396 */           log.warn(sm.getString("coyoteRequest.gssLifetimeFail", new Object[] { this.userPrincipal.getName() }), e);
/*      */         } 
/*      */ 
/*      */         
/* 2400 */         if (left <= 0) {
/*      */           
/*      */           try {
/* 2403 */             logout();
/* 2404 */           } catch (ServletException servletException) {}
/*      */ 
/*      */ 
/*      */           
/* 2408 */           return null;
/*      */         } 
/*      */       } 
/* 2411 */       return ((TomcatPrincipal)this.userPrincipal).getUserPrincipal();
/*      */     } 
/*      */     
/* 2414 */     return this.userPrincipal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Session getSessionInternal() {
/* 2422 */     return doGetSession(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeSessionId(String newSessionId) {
/* 2436 */     if (this.requestedSessionId != null && !this.requestedSessionId.isEmpty()) {
/* 2437 */       this.requestedSessionId = newSessionId;
/*      */     }
/*      */     
/* 2440 */     Context context = getContext();
/* 2441 */     if (context != null && 
/* 2442 */       !context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)) {
/*      */       return;
/*      */     }
/*      */     
/* 2446 */     if (this.response != null && context != null) {
/* 2447 */       Cookie newCookie = ApplicationSessionCookieConfig.createSessionCookie(context, newSessionId, isSecure());
/* 2448 */       this.response.addSessionCookieInternal(newCookie);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String changeSessionId() {
/* 2456 */     Session session = getSessionInternal(false);
/* 2457 */     if (session == null) {
/* 2458 */       throw new IllegalStateException(sm.getString("coyoteRequest.changeSessionId"));
/*      */     }
/*      */     
/* 2461 */     Manager manager = getContext().getManager();
/*      */     
/* 2463 */     String newSessionId = manager.rotateSessionId(session);
/* 2464 */     changeSessionId(newSessionId);
/*      */     
/* 2466 */     return newSessionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Session getSessionInternal(boolean create) {
/* 2475 */     return doGetSession(create);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isParametersParsed() {
/* 2483 */     return this.parametersParsed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFinished() {
/* 2492 */     return this.coyoteRequest.isFinished();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkSwallowInput() {
/* 2501 */     Context context = getContext();
/* 2502 */     if (context != null && !context.getSwallowAbortedUploads()) {
/* 2503 */       this.coyoteRequest.action(ActionCode.DISABLE_SWALLOW_INPUT, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean authenticate(HttpServletResponse response) throws IOException, ServletException {
/* 2509 */     if (response.isCommitted()) {
/* 2510 */       throw new IllegalStateException(sm.getString("coyoteRequest.authenticate.ise"));
/*      */     }
/*      */     
/* 2513 */     return getContext().getAuthenticator().authenticate(this, response);
/*      */   }
/*      */ 
/*      */   
/*      */   public void login(String username, String password) throws ServletException {
/* 2518 */     if (getAuthType() != null || getRemoteUser() != null || getUserPrincipal() != null) {
/* 2519 */       throw new ServletException(sm.getString("coyoteRequest.alreadyAuthenticated"));
/*      */     }
/*      */     
/* 2522 */     getContext().getAuthenticator().login(username, password, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public void logout() throws ServletException {
/* 2527 */     getContext().getAuthenticator().logout(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<Part> getParts() throws IOException, IllegalStateException, ServletException {
/* 2534 */     parseParts(true);
/*      */     
/* 2536 */     if (this.partsParseException != null) {
/* 2537 */       Context context = getContext();
/* 2538 */       if (context != null && context.getLogger().isDebugEnabled()) {
/* 2539 */         context.getLogger()
/* 2540 */           .debug(sm.getString("coyoteRequest.partsParseException", new Object[] { this.partsParseException.getMessage() }));
/*      */       }
/* 2542 */       if (this.partsParseException instanceof IOException)
/* 2543 */         throw (IOException)this.partsParseException; 
/* 2544 */       if (this.partsParseException instanceof IllegalStateException)
/* 2545 */         throw (IllegalStateException)this.partsParseException; 
/* 2546 */       if (this.partsParseException instanceof ServletException) {
/* 2547 */         throw (ServletException)this.partsParseException;
/*      */       }
/*      */     } 
/*      */     
/* 2551 */     return this.parts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseParts(boolean explicit) {
/* 2558 */     if (this.parts != null || this.partsParseException != null) {
/*      */       return;
/*      */     }
/*      */     
/* 2562 */     Context context = getContext();
/* 2563 */     MultipartConfigElement mce = getWrapper().getMultipartConfigElement();
/*      */     
/* 2565 */     if (mce == null) {
/* 2566 */       if (context.getAllowCasualMultipartParsing()) {
/*      */         
/* 2568 */         mce = new MultipartConfigElement(null, this.connector.getMaxPostSize(), this.connector.getMaxPostSize(), this.connector.getMaxPostSize());
/*      */       } else {
/* 2570 */         if (explicit) {
/* 2571 */           this.partsParseException = new IllegalStateException(sm.getString("coyoteRequest.noMultipartConfig"));
/*      */         } else {
/* 2573 */           this.parts = Collections.emptyList();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2599 */     Parameters parameters = this.coyoteRequest.getParameters();
/* 2600 */     parameters.setLimit(this.maxParameterCount);
/*      */     
/* 2602 */     boolean success = false;
/*      */     try {
/*      */       File location;
/* 2605 */       String locationStr = mce.getLocation();
/* 2606 */       if (locationStr == null || locationStr.length() == 0) {
/* 2607 */         location = (File)context.getServletContext().getAttribute("jakarta.servlet.context.tempdir");
/*      */       } else {
/*      */         
/* 2610 */         location = new File(locationStr);
/* 2611 */         if (!location.isAbsolute())
/*      */         {
/* 2613 */           location = (new File((File)context.getServletContext().getAttribute("jakarta.servlet.context.tempdir"), locationStr)).getAbsoluteFile();
/*      */         }
/*      */       } 
/*      */       
/* 2617 */       if (!location.exists() && context.getCreateUploadTargets()) {
/* 2618 */         log.warn(sm.getString("coyoteRequest.uploadCreate", new Object[] { location.getAbsolutePath(), 
/* 2619 */                 (getMappingData()).wrapper.getName() }));
/* 2620 */         if (!location.mkdirs()) {
/* 2621 */           log.warn(sm.getString("coyoteRequest.uploadCreateFail", new Object[] { location.getAbsolutePath() }));
/*      */         }
/*      */       } 
/*      */       
/* 2625 */       if (!location.isDirectory()) {
/* 2626 */         parameters.setParseFailedReason(Parameters.FailReason.MULTIPART_CONFIG_INVALID);
/* 2627 */         this.partsParseException = new IOException(sm.getString("coyoteRequest.uploadLocationInvalid", new Object[] { location }));
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2633 */       DiskFileItemFactory factory = new DiskFileItemFactory();
/*      */       try {
/* 2635 */         factory.setRepository(location.getCanonicalFile());
/* 2636 */       } catch (IOException ioe) {
/* 2637 */         parameters.setParseFailedReason(Parameters.FailReason.IO_ERROR);
/* 2638 */         this.partsParseException = ioe;
/*      */         return;
/*      */       } 
/* 2641 */       factory.setSizeThreshold(mce.getFileSizeThreshold());
/*      */       
/* 2643 */       FileUpload upload = new FileUpload();
/* 2644 */       upload.setFileItemFactory((FileItemFactory)factory);
/* 2645 */       upload.setFileSizeMax(mce.getMaxFileSize());
/* 2646 */       upload.setSizeMax(mce.getMaxRequestSize());
/* 2647 */       upload.setPartHeaderSizeMax(this.maxPartHeaderSize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2660 */       int partLimit = this.maxParameterCount;
/* 2661 */       if (partLimit > -1) {
/* 2662 */         partLimit -= parameters.size();
/*      */       }
/* 2664 */       int maxPartCount = this.maxPartCount;
/* 2665 */       if (maxPartCount > -1 && (
/* 2666 */         partLimit < 0 || partLimit > maxPartCount)) {
/* 2667 */         partLimit = maxPartCount;
/*      */       }
/*      */       
/* 2670 */       upload.setFileCountMax(partLimit);
/*      */       
/* 2672 */       this.parts = new ArrayList<>();
/* 2673 */       List<FileItem> items = null;
/*      */       try {
/* 2675 */         items = upload.parseRequest((RequestContext)new ServletRequestContext(this));
/* 2676 */         int maxPostSize = getConnector().getMaxPostSize();
/* 2677 */         long postSize = 0L;
/* 2678 */         Charset charset = getCharset();
/* 2679 */         for (FileItem item : items) {
/* 2680 */           ApplicationPart part = new ApplicationPart(item, location);
/* 2681 */           if (part.getSubmittedFileName() == null) {
/* 2682 */             String name = part.getName();
/* 2683 */             if (maxPostSize >= 0) {
/*      */ 
/*      */ 
/*      */               
/* 2687 */               postSize = Math.addExact(postSize, (name.getBytes(charset)).length);
/*      */               
/* 2689 */               postSize = Math.addExact(postSize, 1L);
/*      */               
/* 2691 */               postSize = Math.addExact(postSize, part.getSize());
/*      */               
/* 2693 */               postSize = Math.addExact(postSize, 1L);
/* 2694 */               if (postSize > maxPostSize) {
/* 2695 */                 parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 2696 */                 throw new IllegalStateException(sm.getString("coyoteRequest.maxPostSizeExceeded"));
/*      */               } 
/*      */             } 
/* 2699 */             String value = null;
/*      */             try {
/* 2701 */               value = part.getString(charset.name());
/* 2702 */             } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */             
/* 2705 */             parameters.addParameter(name, value);
/*      */           } else {
/*      */             
/* 2708 */             this.maxParameterCount--;
/*      */           } 
/* 2710 */           this.parts.add(part);
/*      */         } 
/*      */         
/* 2713 */         success = true;
/* 2714 */       } catch (InvalidContentTypeException e) {
/* 2715 */         parameters.setParseFailedReason(Parameters.FailReason.INVALID_CONTENT_TYPE);
/* 2716 */         this.partsParseException = (Exception)new ServletException((Throwable)e);
/* 2717 */       } catch (SizeException|org.apache.tomcat.util.http.fileupload.impl.FileCountLimitExceededException e) {
/* 2718 */         parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 2719 */         checkSwallowInput();
/* 2720 */         this.partsParseException = new IllegalStateException((Throwable)e);
/* 2721 */       } catch (IOException ioe) {
/* 2722 */         parameters.setParseFailedReason(Parameters.FailReason.IO_ERROR);
/* 2723 */         this.partsParseException = ioe;
/* 2724 */       } catch (IllegalStateException e) {
/*      */         
/* 2726 */         checkSwallowInput();
/* 2727 */         this.partsParseException = e;
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */         
/* 2733 */         if (!success) {
/* 2734 */           this.parts.clear();
/* 2735 */           if (items != null) {
/* 2736 */             for (FileItem item : items) {
/*      */               try {
/* 2738 */                 item.delete();
/* 2739 */               } catch (Throwable t) {
/* 2740 */                 ExceptionUtils.handleThrowable(t);
/* 2741 */                 log.warn(sm.getString("request.partCleanup.failed"), t);
/*      */               }
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/*      */     } finally {
/*      */       
/* 2752 */       if (this.partsParseException != null || !success) {
/* 2753 */         parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Part getPart(String name) throws IOException, IllegalStateException, ServletException {
/* 2761 */     for (Part part : getParts()) {
/* 2762 */       if (name.equals(part.getName())) {
/* 2763 */         return part;
/*      */       }
/*      */     } 
/* 2766 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Session doGetSession(boolean create) {
/* 2775 */     Context context = getContext();
/* 2776 */     if (context == null) {
/* 2777 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2781 */     if (this.session != null && !this.session.isValid()) {
/* 2782 */       this.session = null;
/*      */     }
/* 2784 */     if (this.session != null) {
/* 2785 */       return this.session;
/*      */     }
/*      */ 
/*      */     
/* 2789 */     Manager manager = context.getManager();
/* 2790 */     if (manager == null) {
/* 2791 */       return null;
/*      */     }
/* 2793 */     if (this.requestedSessionId != null) {
/*      */       try {
/* 2795 */         this.session = manager.findSession(this.requestedSessionId);
/* 2796 */       } catch (IOException ioe) {
/* 2797 */         if (log.isDebugEnabled()) {
/* 2798 */           log.debug(sm.getString("request.session.failed", new Object[] { this.requestedSessionId, ioe.getMessage() }), ioe);
/*      */         } else {
/* 2800 */           log.info(sm.getString("request.session.failed", new Object[] { this.requestedSessionId, ioe.getMessage() }));
/*      */         } 
/* 2802 */         this.session = null;
/*      */       } 
/* 2804 */       if (this.session != null && !this.session.isValid()) {
/* 2805 */         this.session = null;
/*      */       }
/* 2807 */       if (this.session != null) {
/* 2808 */         this.session.access();
/*      */         
/* 2810 */         this.session.setNew(false);
/* 2811 */         return this.session;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2816 */     if (!create) {
/* 2817 */       return null;
/*      */     }
/*      */     
/* 2820 */     boolean trackModesIncludesCookie = context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE);
/* 2821 */     if (trackModesIncludesCookie && this.response.getResponse().isCommitted()) {
/* 2822 */       throw new IllegalStateException(sm.getString("coyoteRequest.sessionCreateCommitted"));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2827 */     String sessionId = getRequestedSessionId();
/* 2828 */     if (!this.requestedSessionSSL)
/*      */     {
/*      */       
/* 2831 */       if ("/".equals(context.getSessionCookiePath()) && isRequestedSessionIdFromCookie()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2841 */         if (context.getValidateClientProvidedNewSessionId()) {
/* 2842 */           boolean found = false;
/* 2843 */           for (Container container : getHost().findChildren()) {
/* 2844 */             Manager m = ((Context)container).getManager();
/* 2845 */             if (m != null) {
/*      */               try {
/* 2847 */                 if (m.findSession(sessionId) != null) {
/* 2848 */                   found = true;
/*      */                   break;
/*      */                 } 
/* 2851 */               } catch (IOException iOException) {}
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 2856 */           if (!found) {
/* 2857 */             sessionId = null;
/*      */           }
/*      */         } 
/*      */       } else {
/* 2861 */         sessionId = null;
/*      */       }  } 
/* 2863 */     this.session = manager.createSession(sessionId);
/*      */ 
/*      */     
/* 2866 */     if (this.session != null && trackModesIncludesCookie) {
/*      */       
/* 2868 */       Cookie cookie = ApplicationSessionCookieConfig.createSessionCookie(context, this.session.getIdInternal(), isSecure());
/*      */       
/* 2870 */       this.response.addSessionCookieInternal(cookie);
/*      */     } 
/*      */     
/* 2873 */     if (this.session == null) {
/* 2874 */       return null;
/*      */     }
/*      */     
/* 2877 */     this.session.access();
/* 2878 */     return this.session;
/*      */   }
/*      */   
/*      */   protected String unescape(String s) {
/* 2882 */     if (s == null) {
/* 2883 */       return null;
/*      */     }
/* 2885 */     if (s.indexOf('\\') == -1) {
/* 2886 */       return s;
/*      */     }
/* 2888 */     StringBuilder buf = new StringBuilder();
/* 2889 */     for (int i = 0; i < s.length(); i++) {
/* 2890 */       char c = s.charAt(i);
/* 2891 */       if (c != '\\') {
/* 2892 */         buf.append(c);
/*      */       } else {
/* 2894 */         if (++i >= s.length()) {
/* 2895 */           throw new IllegalArgumentException();
/*      */         }
/* 2897 */         c = s.charAt(i);
/* 2898 */         buf.append(c);
/*      */       } 
/*      */     } 
/* 2901 */     return buf.toString();
/*      */   }
/*      */   
/*      */   private CookieProcessor getCookieProcessor() {
/* 2905 */     Context context = getContext();
/* 2906 */     if (context == null)
/*      */     {
/*      */ 
/*      */       
/* 2910 */       return (CookieProcessor)new Rfc6265CookieProcessor();
/*      */     }
/* 2912 */     return context.getCookieProcessor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseCookies() {
/* 2921 */     if (this.cookiesParsed) {
/*      */       return;
/*      */     }
/*      */     
/* 2925 */     this.cookiesParsed = true;
/*      */     
/* 2927 */     ServerCookies serverCookies = this.coyoteRequest.getCookies();
/* 2928 */     serverCookies.setLimit(this.connector.getMaxCookieCount());
/* 2929 */     getCookieProcessor().parseCookieHeader(this.coyoteRequest.getMimeHeaders(), serverCookies);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertCookies() {
/* 2936 */     if (this.cookiesConverted) {
/*      */       return;
/*      */     }
/*      */     
/* 2940 */     this.cookiesConverted = true;
/*      */     
/* 2942 */     parseCookies();
/*      */     
/* 2944 */     ServerCookies serverCookies = this.coyoteRequest.getCookies();
/*      */     
/* 2946 */     int count = serverCookies.getCookieCount();
/* 2947 */     if (count <= 0) {
/*      */       return;
/*      */     }
/*      */     
/* 2951 */     this.cookies = new Cookie[count];
/*      */     
/* 2953 */     int idx = 0;
/* 2954 */     for (int i = 0; i < count; i++) {
/* 2955 */       ServerCookie scookie = serverCookies.getCookie(i);
/*      */       
/*      */       try {
/* 2958 */         Cookie cookie = new Cookie(scookie.getName().toString(), null);
/* 2959 */         scookie.getValue().getByteChunk().setCharset(getCookieProcessor().getCharset());
/* 2960 */         cookie.setValue(unescape(scookie.getValue().toString()));
/* 2961 */         this.cookies[idx++] = cookie;
/* 2962 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*      */     } 
/*      */ 
/*      */     
/* 2966 */     if (idx < count) {
/* 2967 */       Cookie[] ncookies = new Cookie[idx];
/* 2968 */       System.arraycopy(this.cookies, 0, ncookies, 0, idx);
/* 2969 */       this.cookies = ncookies;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseParameters() {
/* 2979 */     this.parametersParsed = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3001 */     Parameters parameters = this.coyoteRequest.getParameters();
/* 3002 */     boolean success = false;
/*      */     
/*      */     try {
/* 3005 */       parameters.setLimit(this.maxParameterCount);
/*      */ 
/*      */ 
/*      */       
/* 3009 */       Charset charset = getCharset();
/*      */       
/* 3011 */       boolean useBodyEncodingForURI = this.connector.getUseBodyEncodingForURI();
/* 3012 */       parameters.setCharset(charset);
/* 3013 */       if (useBodyEncodingForURI) {
/* 3014 */         parameters.setQueryStringCharset(charset);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3019 */       parameters.handleQueryParameters();
/*      */       
/* 3021 */       if (this.usingInputStream || this.usingReader) {
/* 3022 */         success = true;
/*      */         
/*      */         return;
/*      */       } 
/* 3026 */       String mediaType = MediaType.parseMediaTypeOnly(getContentType());
/*      */       
/* 3028 */       if ("multipart/form-data".equals(mediaType)) {
/* 3029 */         parseParts(false);
/* 3030 */         success = true;
/*      */         
/*      */         return;
/*      */       } 
/* 3034 */       if (!getConnector().isParseBodyMethod(getMethod())) {
/* 3035 */         success = true;
/*      */         
/*      */         return;
/*      */       } 
/* 3039 */       if (!"application/x-www-form-urlencoded".equals(mediaType)) {
/* 3040 */         success = true;
/*      */         
/*      */         return;
/*      */       } 
/* 3044 */       int len = getContentLength();
/*      */       
/* 3046 */       if (len > 0) {
/* 3047 */         int maxPostSize = this.connector.getMaxPostSize();
/* 3048 */         if (maxPostSize >= 0 && len > maxPostSize) {
/* 3049 */           Context context = getContext();
/* 3050 */           if (context != null && context.getLogger().isDebugEnabled()) {
/* 3051 */             context.getLogger().debug(sm.getString("coyoteRequest.postTooLarge"));
/*      */           }
/* 3053 */           checkSwallowInput();
/* 3054 */           parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/*      */           return;
/*      */         } 
/* 3057 */         byte[] formData = null;
/* 3058 */         if (len < 8192) {
/* 3059 */           if (this.postData == null) {
/* 3060 */             this.postData = new byte[8192];
/*      */           }
/* 3062 */           formData = this.postData;
/*      */         } else {
/* 3064 */           formData = new byte[len];
/*      */         } 
/*      */         try {
/* 3067 */           readPostBodyFully(formData, len);
/* 3068 */         } catch (IOException ioe) {
/*      */           
/* 3070 */           Context context = getContext();
/* 3071 */           if (context != null && context.getLogger().isDebugEnabled()) {
/* 3072 */             context.getLogger().debug(sm.getString("coyoteRequest.parseParameters"), ioe);
/*      */           }
/* 3074 */           parameters.setParseFailedReason(Parameters.FailReason.CLIENT_DISCONNECT);
/*      */           return;
/*      */         } 
/* 3077 */         parameters.processParameters(formData, 0, len);
/* 3078 */       } else if ("chunked".equalsIgnoreCase(this.coyoteRequest.getHeader("transfer-encoding"))) {
/* 3079 */         byte[] formData = null;
/*      */         try {
/* 3081 */           formData = readChunkedPostBody();
/* 3082 */         } catch (IllegalStateException ise) {
/*      */           
/* 3084 */           parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 3085 */           Context context = getContext();
/* 3086 */           if (context != null && context.getLogger().isDebugEnabled()) {
/* 3087 */             context.getLogger().debug(sm.getString("coyoteRequest.parseParameters"), ise);
/*      */           }
/*      */           return;
/* 3090 */         } catch (IOException ioe) {
/*      */           
/* 3092 */           parameters.setParseFailedReason(Parameters.FailReason.CLIENT_DISCONNECT);
/* 3093 */           Context context = getContext();
/* 3094 */           if (context != null && context.getLogger().isDebugEnabled()) {
/* 3095 */             context.getLogger().debug(sm.getString("coyoteRequest.parseParameters"), ioe);
/*      */           }
/*      */           return;
/*      */         } 
/* 3099 */         if (formData != null) {
/* 3100 */           parameters.processParameters(formData, 0, formData.length);
/*      */         }
/*      */       } 
/* 3103 */       success = true;
/*      */     } finally {
/* 3105 */       if (!success) {
/* 3106 */         parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected int readPostBody(byte[] body, int len) throws IOException {
/* 3128 */     int offset = 0;
/*      */     while (true) {
/* 3130 */       int inputLen = getStream().read(body, offset, len - offset);
/* 3131 */       if (inputLen <= 0) {
/* 3132 */         return offset;
/*      */       }
/* 3134 */       offset += inputLen;
/* 3135 */       if (len - offset <= 0) {
/* 3136 */         return len;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readPostBodyFully(byte[] body, int len) throws IOException {
/* 3150 */     int offset = 0;
/*      */     do {
/* 3152 */       int inputLen = getStream().read(body, offset, len - offset);
/* 3153 */       if (inputLen <= 0) {
/* 3154 */         throw new EOFException();
/*      */       }
/* 3156 */       offset += inputLen;
/* 3157 */     } while (len - offset > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] readChunkedPostBody() throws IOException {
/* 3169 */     ByteChunk body = new ByteChunk();
/*      */     
/* 3171 */     byte[] buffer = new byte[8192];
/*      */     
/* 3173 */     int len = 0;
/* 3174 */     while (len > -1) {
/* 3175 */       len = getStream().read(buffer, 0, 8192);
/* 3176 */       if (this.connector.getMaxPostSize() >= 0 && body.getLength() + len > this.connector.getMaxPostSize()) {
/*      */         
/* 3178 */         checkSwallowInput();
/* 3179 */         throw new IllegalStateException(sm.getString("coyoteRequest.chunkedPostTooLarge"));
/*      */       } 
/* 3181 */       if (len > 0) {
/* 3182 */         body.append(buffer, 0, len);
/*      */       }
/*      */     } 
/* 3185 */     if (body.getLength() == 0) {
/* 3186 */       return null;
/*      */     }
/* 3188 */     if (body.getLength() < (body.getBuffer()).length) {
/* 3189 */       int length = body.getLength();
/* 3190 */       byte[] result = new byte[length];
/* 3191 */       System.arraycopy(body.getBuffer(), 0, result, 0, length);
/* 3192 */       return result;
/*      */     } 
/*      */     
/* 3195 */     return body.getBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseLocales() {
/* 3204 */     this.localesParsed = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3210 */     TreeMap<Double, ArrayList<Locale>> locales = new TreeMap<>();
/*      */     
/* 3212 */     Enumeration<String> values = getHeaders("accept-language");
/*      */     
/* 3214 */     while (values.hasMoreElements()) {
/* 3215 */       String value = values.nextElement();
/* 3216 */       parseLocalesHeader(value, locales);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3221 */     for (ArrayList<Locale> list : locales.values()) {
/* 3222 */       for (Locale locale : list) {
/* 3223 */         addLocale(locale);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseLocalesHeader(String value, TreeMap<Double, ArrayList<Locale>> locales) {
/*      */     List<AcceptLanguage> acceptLanguages;
/*      */     try {
/* 3239 */       acceptLanguages = AcceptLanguage.parse(new StringReader(value));
/* 3240 */     } catch (IOException ioe) {
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3246 */     for (AcceptLanguage acceptLanguage : acceptLanguages) {
/*      */       
/* 3248 */       Double key = Double.valueOf(-acceptLanguage.getQuality());
/* 3249 */       ((ArrayList<Locale>)locales.computeIfAbsent(key, k -> new ArrayList())).add(acceptLanguage.getLocale());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3265 */   private static final Map<String, SpecialAttributeAdapter> specialAttributes = new HashMap<>();
/*      */   
/*      */   static {
/* 3268 */     specialAttributes.put("org.apache.catalina.core.DISPATCHER_TYPE", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3271 */             return (request.internalDispatcherType == null) ? DispatcherType.REQUEST : 
/* 3272 */               request.internalDispatcherType;
/*      */           }
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {
/* 3277 */             request.internalDispatcherType = (DispatcherType)value;
/*      */           }
/*      */         });
/* 3280 */     specialAttributes.put("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3283 */             return (request.requestDispatcherPath == null) ? request.getRequestPathMB().toString() : 
/* 3284 */               request.requestDispatcherPath.toString();
/*      */           }
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {
/* 3289 */             request.requestDispatcherPath = value;
/*      */           }
/*      */         });
/* 3292 */     specialAttributes.put("org.apache.catalina.ASYNC_SUPPORTED", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3295 */             return request.asyncSupported;
/*      */           }
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {
/* 3300 */             Boolean oldValue = request.asyncSupported;
/* 3301 */             request.asyncSupported = (Boolean)value;
/* 3302 */             request.notifyAttributeAssigned(name, value, oldValue);
/*      */           }
/*      */         });
/* 3305 */     specialAttributes.put("org.apache.catalina.realm.GSS_CREDENTIAL", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3308 */             if (request.userPrincipal instanceof TomcatPrincipal) {
/* 3309 */               return ((TomcatPrincipal)request.userPrincipal).getGssCredential();
/*      */             }
/* 3311 */             return null;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {}
/*      */         });
/* 3319 */     specialAttributes.put("org.apache.catalina.parameter_parse_failed", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3322 */             if (request.getCoyoteRequest().getParameters().isParseFailed()) {
/* 3323 */               return Boolean.TRUE;
/*      */             }
/* 3325 */             return null;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {}
/*      */         });
/* 3333 */     specialAttributes.put("org.apache.catalina.parameter_parse_failed_reason", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3336 */             return request.getCoyoteRequest().getParameters().getParseFailedReason();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {}
/*      */         });
/* 3344 */     specialAttributes.put("org.apache.tomcat.sendfile.support", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3347 */             return Boolean.valueOf((request.getConnector().getProtocolHandler().isSendfileSupported() && request
/* 3348 */                 .getCoyoteRequest().getSendfile()));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {}
/*      */         });
/* 3356 */     specialAttributes.put("org.apache.catalina.filters.RemoteIpFilter.secure", new SpecialAttributeAdapter()
/*      */         {
/*      */           public Object get(Request request, String name) {
/* 3359 */             return Boolean.valueOf(request.isSecure());
/*      */           }
/*      */ 
/*      */           
/*      */           public void set(Request request, String name, Object value) {
/* 3364 */             if (value instanceof Boolean)
/* 3365 */               request.setSecure(((Boolean)value).booleanValue()); 
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private static interface SpecialAttributeAdapter {
/*      */     Object get(Request param1Request, String param1String);
/*      */     
/*      */     void set(Request param1Request, String param1String, Object param1Object);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\connector\Request.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */