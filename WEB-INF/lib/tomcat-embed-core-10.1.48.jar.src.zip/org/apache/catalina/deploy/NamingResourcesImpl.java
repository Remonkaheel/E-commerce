/*      */ package org.apache.catalina.deploy;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.naming.Context;
/*      */ import javax.naming.NamingException;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.JmxEnabled;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.mbeans.MBeanUtils;
/*      */ import org.apache.catalina.util.Introspection;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextTransaction;
/*      */ import org.apache.tomcat.util.descriptor.web.InjectionTarget;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*      */ import org.apache.tomcat.util.descriptor.web.ResourceBase;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NamingResourcesImpl
/*      */   extends LifecycleMBeanBase
/*      */   implements Serializable, NamingResources
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   69 */   private static final Log log = LogFactory.getLog(NamingResourcesImpl.class);
/*      */   
/*   71 */   private static final StringManager sm = StringManager.getManager(NamingResourcesImpl.class);
/*      */   
/*      */   private volatile boolean resourceRequireExplicitRegistration = false;
/*      */   
/*      */   private Object container;
/*      */   
/*      */   private final Set<String> entries;
/*      */   
/*      */   private final Map<String, ContextEjb> ejbs;
/*      */   
/*      */   private final Map<String, ContextEnvironment> envs;
/*      */   private final Map<String, ContextLocalEjb> localEjbs;
/*      */   private final Map<String, MessageDestinationRef> mdrs;
/*      */   private final HashMap<String, ContextResourceEnvRef> resourceEnvRefs;
/*      */   private final HashMap<String, ContextResource> resources;
/*      */   private final HashMap<String, ContextResourceLink> resourceLinks;
/*      */   private final HashMap<String, ContextService> services;
/*      */   private ContextTransaction transaction;
/*      */   protected final PropertyChangeSupport support;
/*      */   
/*      */   public NamingResourcesImpl() {
/*   92 */     this.container = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   98 */     this.entries = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  104 */     this.ejbs = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  110 */     this.envs = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  116 */     this.localEjbs = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  122 */     this.mdrs = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  128 */     this.resourceEnvRefs = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  134 */     this.resources = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  140 */     this.resourceLinks = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  146 */     this.services = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  152 */     this.transaction = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  158 */     this.support = new PropertyChangeSupport(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getContainer() {
/*  166 */     return this.container;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContainer(Object container) {
/*  176 */     this.container = container;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransaction(ContextTransaction transaction) {
/*  186 */     this.transaction = transaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextTransaction getTransaction() {
/*  194 */     return this.transaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEjb(ContextEjb ejb) {
/*  206 */     String ejbLink = ejb.getLink();
/*  207 */     String lookupName = ejb.getLookupName();
/*      */     
/*  209 */     if (ejbLink != null && !ejbLink.isEmpty() && lookupName != null && !lookupName.isEmpty()) {
/*  210 */       throw new IllegalArgumentException(sm.getString("namingResources.ejbLookupLink", new Object[] { ejb.getName() }));
/*      */     }
/*      */     
/*  213 */     if (this.entries.contains(ejb.getName())) {
/*      */       return;
/*      */     }
/*  216 */     this.entries.add(ejb.getName());
/*      */ 
/*      */     
/*  219 */     synchronized (this.ejbs) {
/*  220 */       ejb.setNamingResources(this);
/*  221 */       this.ejbs.put(ejb.getName(), ejb);
/*      */     } 
/*  223 */     this.support.firePropertyChange("ejb", (Object)null, ejb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEnvironment(ContextEnvironment environment) {
/*  231 */     if (this.entries.contains(environment.getName())) {
/*  232 */       ContextEnvironment ce = findEnvironment(environment.getName());
/*  233 */       ContextResourceLink rl = findResourceLink(environment.getName());
/*  234 */       if (ce != null) {
/*  235 */         if (ce.getOverride()) {
/*  236 */           removeEnvironment(environment.getName());
/*      */         } else {
/*      */           return;
/*      */         } 
/*  240 */       } else if (rl != null) {
/*      */         
/*  242 */         NamingResourcesImpl global = getServer().getGlobalNamingResources();
/*  243 */         if (global.findEnvironment(rl.getGlobal()) != null) {
/*  244 */           if (global.findEnvironment(rl.getGlobal()).getOverride()) {
/*  245 */             removeResourceLink(environment.getName());
/*      */           } else {
/*      */             return;
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  256 */     List<InjectionTarget> injectionTargets = environment.getInjectionTargets();
/*  257 */     String value = environment.getValue();
/*  258 */     String lookupName = environment.getLookupName();
/*      */ 
/*      */     
/*  261 */     if (injectionTargets != null && !injectionTargets.isEmpty() && (value == null || value.isEmpty())) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  266 */     if (value != null && !value.isEmpty() && lookupName != null && !lookupName.isEmpty()) {
/*  267 */       throw new IllegalArgumentException(sm
/*  268 */           .getString("namingResources.envEntryLookupValue", new Object[] { environment.getName() }));
/*      */     }
/*      */     
/*  271 */     if (!checkResourceType((ResourceBase)environment)) {
/*  272 */       throw new IllegalArgumentException(sm
/*  273 */           .getString("namingResources.resourceTypeFail", new Object[] { environment.getName(), environment.getType() }));
/*      */     }
/*      */     
/*  276 */     this.entries.add(environment.getName());
/*      */     
/*  278 */     synchronized (this.envs) {
/*  279 */       environment.setNamingResources(this);
/*  280 */       this.envs.put(environment.getName(), environment);
/*      */     } 
/*  282 */     this.support.firePropertyChange("environment", (Object)null, environment);
/*      */ 
/*      */     
/*  285 */     if (this.resourceRequireExplicitRegistration) {
/*      */       try {
/*  287 */         MBeanUtils.createMBean(environment);
/*  288 */       } catch (Exception e) {
/*  289 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { environment.getName() }), e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Server getServer() {
/*  297 */     if (this.container instanceof Server) {
/*  298 */       return (Server)this.container;
/*      */     }
/*  300 */     if (this.container instanceof Context) {
/*      */       
/*  302 */       Engine engine = (Engine)((Context)this.container).getParent().getParent();
/*  303 */       return engine.getService().getServer();
/*      */     } 
/*  305 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLocalEjb(ContextLocalEjb ejb) {
/*  315 */     if (this.entries.contains(ejb.getName())) {
/*      */       return;
/*      */     }
/*  318 */     this.entries.add(ejb.getName());
/*      */ 
/*      */     
/*  321 */     synchronized (this.localEjbs) {
/*  322 */       ejb.setNamingResources(this);
/*  323 */       this.localEjbs.put(ejb.getName(), ejb);
/*      */     } 
/*  325 */     this.support.firePropertyChange("localEjb", (Object)null, ejb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMessageDestinationRef(MessageDestinationRef mdr) {
/*  337 */     if (this.entries.contains(mdr.getName())) {
/*      */       return;
/*      */     }
/*  340 */     if (!checkResourceType((ResourceBase)mdr)) {
/*  341 */       throw new IllegalArgumentException(sm
/*  342 */           .getString("namingResources.resourceTypeFail", new Object[] { mdr.getName(), mdr.getType() }));
/*      */     }
/*  344 */     this.entries.add(mdr.getName());
/*      */ 
/*      */     
/*  347 */     synchronized (this.mdrs) {
/*  348 */       mdr.setNamingResources(this);
/*  349 */       this.mdrs.put(mdr.getName(), mdr);
/*      */     } 
/*  351 */     this.support.firePropertyChange("messageDestinationRef", (Object)null, mdr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/*  363 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addResource(ContextResource resource) {
/*  371 */     if (this.entries.contains(resource.getName())) {
/*      */       return;
/*      */     }
/*  374 */     if (!checkResourceType((ResourceBase)resource)) {
/*  375 */       throw new IllegalArgumentException(sm
/*  376 */           .getString("namingResources.resourceTypeFail", new Object[] { resource.getName(), resource.getType() }));
/*      */     }
/*  378 */     this.entries.add(resource.getName());
/*      */ 
/*      */     
/*  381 */     synchronized (this.resources) {
/*  382 */       resource.setNamingResources(this);
/*  383 */       this.resources.put(resource.getName(), resource);
/*      */     } 
/*  385 */     this.support.firePropertyChange("resource", (Object)null, resource);
/*      */ 
/*      */     
/*  388 */     if (this.resourceRequireExplicitRegistration) {
/*      */       try {
/*  390 */         MBeanUtils.createMBean(resource);
/*  391 */       } catch (Exception e) {
/*  392 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { resource.getName() }), e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addResourceEnvRef(ContextResourceEnvRef resource) {
/*  405 */     if (this.entries.contains(resource.getName())) {
/*      */       return;
/*      */     }
/*  408 */     if (!checkResourceType((ResourceBase)resource)) {
/*  409 */       throw new IllegalArgumentException(sm
/*  410 */           .getString("namingResources.resourceTypeFail", new Object[] { resource.getName(), resource.getType() }));
/*      */     }
/*  412 */     this.entries.add(resource.getName());
/*      */ 
/*      */     
/*  415 */     synchronized (this.resourceEnvRefs) {
/*  416 */       resource.setNamingResources(this);
/*  417 */       this.resourceEnvRefs.put(resource.getName(), resource);
/*      */     } 
/*  419 */     this.support.firePropertyChange("resourceEnvRef", (Object)null, resource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addResourceLink(ContextResourceLink resourceLink) {
/*  427 */     if (this.entries.contains(resourceLink.getName())) {
/*      */       return;
/*      */     }
/*  430 */     this.entries.add(resourceLink.getName());
/*      */ 
/*      */     
/*  433 */     synchronized (this.resourceLinks) {
/*  434 */       resourceLink.setNamingResources(this);
/*  435 */       this.resourceLinks.put(resourceLink.getName(), resourceLink);
/*      */     } 
/*  437 */     this.support.firePropertyChange("resourceLink", (Object)null, resourceLink);
/*      */ 
/*      */     
/*  440 */     if (this.resourceRequireExplicitRegistration) {
/*      */       try {
/*  442 */         MBeanUtils.createMBean(resourceLink);
/*  443 */       } catch (Exception e) {
/*  444 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { resourceLink.getName() }), e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addService(ContextService service) {
/*  457 */     if (this.entries.contains(service.getName())) {
/*      */       return;
/*      */     }
/*  460 */     this.entries.add(service.getName());
/*      */ 
/*      */     
/*  463 */     synchronized (this.services) {
/*  464 */       service.setNamingResources(this);
/*  465 */       this.services.put(service.getName(), service);
/*      */     } 
/*  467 */     this.support.firePropertyChange("service", (Object)null, service);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextEjb findEjb(String name) {
/*  479 */     synchronized (this.ejbs) {
/*  480 */       return this.ejbs.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextEjb[] findEjbs() {
/*  492 */     synchronized (this.ejbs) {
/*  493 */       return (ContextEjb[])this.ejbs.values().toArray((Object[])new ContextEjb[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextEnvironment findEnvironment(String name) {
/*  506 */     synchronized (this.envs) {
/*  507 */       return this.envs.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextEnvironment[] findEnvironments() {
/*  519 */     synchronized (this.envs) {
/*  520 */       return (ContextEnvironment[])this.envs.values().toArray((Object[])new ContextEnvironment[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextLocalEjb findLocalEjb(String name) {
/*  533 */     synchronized (this.localEjbs) {
/*  534 */       return this.localEjbs.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextLocalEjb[] findLocalEjbs() {
/*  546 */     synchronized (this.localEjbs) {
/*  547 */       return (ContextLocalEjb[])this.localEjbs.values().toArray((Object[])new ContextLocalEjb[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MessageDestinationRef findMessageDestinationRef(String name) {
/*  560 */     synchronized (this.mdrs) {
/*  561 */       return this.mdrs.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MessageDestinationRef[] findMessageDestinationRefs() {
/*  573 */     synchronized (this.mdrs) {
/*  574 */       return (MessageDestinationRef[])this.mdrs.values().toArray((Object[])new MessageDestinationRef[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextResource findResource(String name) {
/*  587 */     synchronized (this.resources) {
/*  588 */       return this.resources.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextResourceLink findResourceLink(String name) {
/*  601 */     synchronized (this.resourceLinks) {
/*  602 */       return this.resourceLinks.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextResourceLink[] findResourceLinks() {
/*  614 */     synchronized (this.resourceLinks) {
/*  615 */       return (ContextResourceLink[])this.resourceLinks.values().toArray((Object[])new ContextResourceLink[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextResource[] findResources() {
/*  627 */     synchronized (this.resources) {
/*  628 */       return (ContextResource[])this.resources.values().toArray((Object[])new ContextResource[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextResourceEnvRef findResourceEnvRef(String name) {
/*  642 */     synchronized (this.resourceEnvRefs) {
/*  643 */       return this.resourceEnvRefs.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextResourceEnvRef[] findResourceEnvRefs() {
/*  655 */     synchronized (this.resourceEnvRefs) {
/*  656 */       return (ContextResourceEnvRef[])this.resourceEnvRefs.values().toArray((Object[])new ContextResourceEnvRef[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextService findService(String name) {
/*  669 */     synchronized (this.services) {
/*  670 */       return this.services.get(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextService[] findServices() {
/*  682 */     synchronized (this.services) {
/*  683 */       return (ContextService[])this.services.values().toArray((Object[])new ContextService[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeEjb(String name) {
/*      */     ContextEjb ejb;
/*  696 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  699 */     synchronized (this.ejbs) {
/*  700 */       ejb = this.ejbs.remove(name);
/*      */     } 
/*  702 */     if (ejb != null) {
/*  703 */       this.support.firePropertyChange("ejb", ejb, (Object)null);
/*  704 */       ejb.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeEnvironment(String name) {
/*      */     ContextEnvironment environment;
/*  713 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  716 */     synchronized (this.envs) {
/*  717 */       environment = this.envs.remove(name);
/*      */     } 
/*  719 */     if (environment != null) {
/*  720 */       this.support.firePropertyChange("environment", environment, (Object)null);
/*      */       
/*  722 */       if (this.resourceRequireExplicitRegistration) {
/*      */         try {
/*  724 */           MBeanUtils.destroyMBean(environment);
/*  725 */         } catch (Exception e) {
/*  726 */           log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { environment.getName() }), e);
/*      */         } 
/*      */       }
/*  729 */       environment.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLocalEjb(String name) {
/*      */     ContextLocalEjb localEjb;
/*  741 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  744 */     synchronized (this.localEjbs) {
/*  745 */       localEjb = this.localEjbs.remove(name);
/*      */     } 
/*  747 */     if (localEjb != null) {
/*  748 */       this.support.firePropertyChange("localEjb", localEjb, (Object)null);
/*  749 */       localEjb.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeMessageDestinationRef(String name) {
/*      */     MessageDestinationRef mdr;
/*  762 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  765 */     synchronized (this.mdrs) {
/*  766 */       mdr = this.mdrs.remove(name);
/*      */     } 
/*  768 */     if (mdr != null) {
/*  769 */       this.support.firePropertyChange("messageDestinationRef", mdr, (Object)null);
/*  770 */       mdr.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/*  783 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeResource(String name) {
/*      */     ContextResource resource;
/*  791 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  794 */     synchronized (this.resources) {
/*  795 */       resource = this.resources.remove(name);
/*      */     } 
/*  797 */     if (resource != null) {
/*  798 */       this.support.firePropertyChange("resource", resource, (Object)null);
/*      */       
/*  800 */       if (this.resourceRequireExplicitRegistration) {
/*      */         try {
/*  802 */           MBeanUtils.destroyMBean(resource);
/*  803 */         } catch (Exception e) {
/*  804 */           log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { resource.getName() }), e);
/*      */         } 
/*      */       }
/*  807 */       resource.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeResourceEnvRef(String name) {
/*      */     ContextResourceEnvRef resourceEnvRef;
/*  819 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  822 */     synchronized (this.resourceEnvRefs) {
/*  823 */       resourceEnvRef = this.resourceEnvRefs.remove(name);
/*      */     } 
/*  825 */     if (resourceEnvRef != null) {
/*  826 */       this.support.firePropertyChange("resourceEnvRef", resourceEnvRef, (Object)null);
/*  827 */       resourceEnvRef.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeResourceLink(String name) {
/*      */     ContextResourceLink resourceLink;
/*  836 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  839 */     synchronized (this.resourceLinks) {
/*  840 */       resourceLink = this.resourceLinks.remove(name);
/*      */     } 
/*  842 */     if (resourceLink != null) {
/*  843 */       this.support.firePropertyChange("resourceLink", resourceLink, (Object)null);
/*      */       
/*  845 */       if (this.resourceRequireExplicitRegistration) {
/*      */         try {
/*  847 */           MBeanUtils.destroyMBean(resourceLink);
/*  848 */         } catch (Exception e) {
/*  849 */           log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { resourceLink.getName() }), e);
/*      */         } 
/*      */       }
/*  852 */       resourceLink.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeService(String name) {
/*      */     ContextService service;
/*  864 */     this.entries.remove(name);
/*      */ 
/*      */     
/*  867 */     synchronized (this.services) {
/*  868 */       service = this.services.remove(name);
/*      */     } 
/*  870 */     if (service != null) {
/*  871 */       this.support.firePropertyChange("service", service, (Object)null);
/*  872 */       service.setNamingResources(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initInternal() throws LifecycleException {
/*  882 */     super.initInternal();
/*      */ 
/*      */ 
/*      */     
/*  886 */     this.resourceRequireExplicitRegistration = true;
/*      */     
/*  888 */     for (ContextResource cr : this.resources.values()) {
/*      */       try {
/*  890 */         MBeanUtils.createMBean(cr);
/*  891 */       } catch (Exception e) {
/*  892 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { cr.getName() }), e);
/*      */       } 
/*      */     } 
/*      */     
/*  896 */     for (ContextEnvironment ce : this.envs.values()) {
/*      */       try {
/*  898 */         MBeanUtils.createMBean(ce);
/*  899 */       } catch (Exception e) {
/*  900 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { ce.getName() }), e);
/*      */       } 
/*      */     } 
/*      */     
/*  904 */     for (ContextResourceLink crl : this.resourceLinks.values()) {
/*      */       try {
/*  906 */         MBeanUtils.createMBean(crl);
/*  907 */       } catch (Exception e) {
/*  908 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { crl.getName() }), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/*  916 */     fireLifecycleEvent("configure_start", null);
/*  917 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/*  923 */     cleanUp();
/*  924 */     setState(LifecycleState.STOPPING);
/*  925 */     fireLifecycleEvent("configure_stop", null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanUp() {
/*      */     Context ctxt;
/*  932 */     if (this.resources.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/*  937 */       if (this.container instanceof Server) {
/*  938 */         ctxt = ((Server)this.container).getGlobalNamingContext();
/*      */       } else {
/*  940 */         ctxt = ContextBindings.getClassLoader();
/*  941 */         ctxt = (Context)ctxt.lookup("comp/env");
/*      */       } 
/*  943 */     } catch (NamingException e) {
/*  944 */       log.warn(sm.getString("namingResources.cleanupNoContext", new Object[] { this.container }), e);
/*      */       return;
/*      */     } 
/*  947 */     for (ContextResource cr : this.resources.values()) {
/*  948 */       if (cr.getSingleton()) {
/*  949 */         String closeMethod = cr.getCloseMethod();
/*  950 */         if (closeMethod != null && !closeMethod.isEmpty()) {
/*  951 */           Object resource; String name = cr.getName();
/*      */           
/*      */           try {
/*  954 */             resource = ctxt.lookup(name);
/*  955 */           } catch (NamingException e) {
/*  956 */             log.warn(sm.getString("namingResources.cleanupNoResource", new Object[] { cr.getName(), this.container }), e);
/*      */             continue;
/*      */           } 
/*  959 */           cleanUp(resource, name, closeMethod);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanUp(Object resource, String name, String closeMethod) {
/*      */     Method m;
/*      */     try {
/*  976 */       m = resource.getClass().getMethod(closeMethod, (Class[])null);
/*  977 */     } catch (SecurityException e) {
/*  978 */       log.debug(sm.getString("namingResources.cleanupCloseSecurity", new Object[] { closeMethod, name, this.container }), e);
/*      */       return;
/*  980 */     } catch (NoSuchMethodException e) {
/*  981 */       log.debug(sm.getString("namingResources.cleanupNoClose", new Object[] { name, this.container, closeMethod }), e);
/*      */       return;
/*      */     } 
/*      */     try {
/*  985 */       m.invoke(resource, (Object[])null);
/*  986 */     } catch (IllegalArgumentException|IllegalAccessException e) {
/*  987 */       log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), e);
/*  988 */     } catch (InvocationTargetException e) {
/*  989 */       Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/*  990 */       ExceptionUtils.handleThrowable(t);
/*  991 */       log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void destroyInternal() throws LifecycleException {
/* 1000 */     this.resourceRequireExplicitRegistration = false;
/*      */ 
/*      */     
/* 1003 */     for (ContextResourceLink crl : this.resourceLinks.values()) {
/*      */       try {
/* 1005 */         MBeanUtils.destroyMBean(crl);
/* 1006 */       } catch (Exception e) {
/* 1007 */         log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { crl.getName() }), e);
/*      */       } 
/*      */     } 
/*      */     
/* 1011 */     for (ContextEnvironment ce : this.envs.values()) {
/*      */       try {
/* 1013 */         MBeanUtils.destroyMBean(ce);
/* 1014 */       } catch (Exception e) {
/* 1015 */         log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { ce.getName() }), e);
/*      */       } 
/*      */     } 
/*      */     
/* 1019 */     for (ContextResource cr : this.resources.values()) {
/*      */       try {
/* 1021 */         MBeanUtils.destroyMBean(cr);
/* 1022 */       } catch (Exception e) {
/* 1023 */         log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { cr.getName() }), e);
/*      */       } 
/*      */     } 
/*      */     
/* 1027 */     super.destroyInternal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getDomainInternal() {
/* 1034 */     Object c = getContainer();
/*      */     
/* 1036 */     if (c instanceof JmxEnabled) {
/* 1037 */       return ((JmxEnabled)c).getDomain();
/*      */     }
/*      */     
/* 1040 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getObjectNameKeyProperties() {
/* 1046 */     Object c = getContainer();
/* 1047 */     if (c instanceof Container) {
/* 1048 */       return "type=NamingResources" + ((Container)c).getMBeanKeyProperties();
/*      */     }
/*      */     
/* 1051 */     return "type=NamingResources";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkResourceType(ResourceBase resource) {
/* 1065 */     if (!(this.container instanceof Context))
/*      */     {
/* 1067 */       return true;
/*      */     }
/*      */     
/* 1070 */     if (resource.getInjectionTargets() == null || resource.getInjectionTargets().isEmpty())
/*      */     {
/* 1072 */       return true;
/*      */     }
/*      */     
/* 1075 */     Context context = (Context)this.container;
/*      */     
/* 1077 */     String typeName = resource.getType();
/* 1078 */     Class<?> typeClass = null;
/* 1079 */     if (typeName != null) {
/* 1080 */       typeClass = Introspection.loadClass(context, typeName);
/* 1081 */       if (typeClass == null)
/*      */       {
/*      */         
/* 1084 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1088 */     Class<?> compatibleClass = getCompatibleType(context, resource, typeClass);
/* 1089 */     if (compatibleClass == null)
/*      */     {
/*      */       
/* 1092 */       return false;
/*      */     }
/*      */     
/* 1095 */     resource.setType(compatibleClass.getCanonicalName());
/* 1096 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private Class<?> getCompatibleType(Context context, ResourceBase resource, Class<?> typeClass) {
/* 1101 */     Class<?> result = null;
/*      */     
/* 1103 */     for (InjectionTarget injectionTarget : resource.getInjectionTargets()) {
/* 1104 */       Class<?> clazz = Introspection.loadClass(context, injectionTarget.getTargetClass());
/* 1105 */       if (clazz == null) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1111 */       String targetName = injectionTarget.getTargetName();
/*      */       
/* 1113 */       Class<?> targetType = getSetterType(clazz, targetName);
/* 1114 */       if (targetType == null)
/*      */       {
/* 1116 */         targetType = getFieldType(clazz, targetName);
/*      */       }
/* 1118 */       if (targetType == null) {
/*      */         continue;
/*      */       }
/*      */       
/* 1122 */       targetType = Introspection.convertPrimitiveType(targetType);
/*      */       
/* 1124 */       if (typeClass == null) {
/*      */         
/* 1126 */         if (result == null) {
/* 1127 */           result = targetType; continue;
/* 1128 */         }  if (targetType.isAssignableFrom(result))
/*      */           continue; 
/* 1130 */         if (result.isAssignableFrom(targetType)) {
/*      */           
/* 1132 */           result = targetType;
/*      */           continue;
/*      */         } 
/* 1135 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1140 */       if (targetType.isAssignableFrom(typeClass)) {
/* 1141 */         result = typeClass;
/*      */         continue;
/*      */       } 
/* 1144 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 1148 */     return result;
/*      */   }
/*      */   
/*      */   private Class<?> getSetterType(Class<?> clazz, String name) {
/* 1152 */     Method[] methods = Introspection.getDeclaredMethods(clazz);
/* 1153 */     if (methods != null && methods.length > 0) {
/* 1154 */       for (Method method : methods) {
/* 1155 */         if (Introspection.isValidSetter(method) && Introspection.getPropertyName(method).equals(name)) {
/* 1156 */           return method.getParameterTypes()[0];
/*      */         }
/*      */       } 
/*      */     }
/* 1160 */     return null;
/*      */   }
/*      */   
/*      */   private Class<?> getFieldType(Class<?> clazz, String name) {
/* 1164 */     Field[] fields = Introspection.getDeclaredFields(clazz);
/* 1165 */     if (fields != null && fields.length > 0) {
/* 1166 */       for (Field field : fields) {
/* 1167 */         if (field.getName().equals(name)) {
/* 1168 */           return field.getType();
/*      */         }
/*      */       } 
/*      */     }
/* 1172 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\deploy\NamingResourcesImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */