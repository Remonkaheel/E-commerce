package org.apache.catalina;

import java.util.Set;

public interface Pipeline extends Contained {
  Valve getBasic();
  
  void setBasic(Valve paramValve);
  
  void addValve(Valve paramValve);
  
  Valve[] getValves();
  
  void removeValve(Valve paramValve);
  
  Valve getFirst();
  
  boolean isAsyncSupported();
  
  void findNonAsyncValves(Set<String> paramSet);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Pipeline.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */