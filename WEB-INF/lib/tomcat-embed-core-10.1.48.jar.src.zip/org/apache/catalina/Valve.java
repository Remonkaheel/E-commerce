package org.apache.catalina;

import jakarta.servlet.ServletException;
import java.io.IOException;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;

public interface Valve {
  Valve getNext();
  
  void setNext(Valve paramValve);
  
  void backgroundProcess();
  
  void invoke(Request paramRequest, Response paramResponse) throws IOException, ServletException;
  
  boolean isAsyncSupported();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Valve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */