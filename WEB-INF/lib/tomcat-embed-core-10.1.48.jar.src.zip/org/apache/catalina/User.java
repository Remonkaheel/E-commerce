package org.apache.catalina;

import java.security.Principal;
import java.util.Iterator;

public interface User extends Principal {
  String getFullName();
  
  void setFullName(String paramString);
  
  Iterator<Group> getGroups();
  
  String getPassword();
  
  void setPassword(String paramString);
  
  Iterator<Role> getRoles();
  
  UserDatabase getUserDatabase();
  
  String getUsername();
  
  void setUsername(String paramString);
  
  void addGroup(Group paramGroup);
  
  void addRole(Role paramRole);
  
  boolean isInGroup(Group paramGroup);
  
  boolean isInRole(Role paramRole);
  
  void removeGroup(Group paramGroup);
  
  void removeGroups();
  
  void removeRole(Role paramRole);
  
  void removeRoles();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\User.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */