/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TLSCertificateReloadListener
/*     */   implements LifecycleListener
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(TLSCertificateReloadListener.class);
/*  48 */   private static final StringManager sm = StringManager.getManager(TLSCertificateReloadListener.class);
/*  49 */   private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
/*     */ 
/*     */   
/*  52 */   private int checkPeriod = 86400;
/*  53 */   private int daysBefore = 14;
/*     */ 
/*     */   
/*  56 */   private final Calendar nextCheck = Calendar.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCheckPeriod() {
/*  70 */     return this.checkPeriod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckPeriod(int checkPeriod) {
/*  80 */     this.checkPeriod = checkPeriod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDaysBefore() {
/*  93 */     return this.daysBefore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDaysBefore(int daysBefore) {
/* 105 */     this.daysBefore = daysBefore;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/* 111 */     if (event.getType().equals("periodic")) {
/*     */       Server server;
/* 113 */       if (event.getSource() instanceof Server) {
/* 114 */         server = (Server)event.getSource();
/*     */       } else {
/*     */         return;
/*     */       } 
/* 118 */       checkCertificatesForRenewal(server);
/* 119 */     } else if (event.getType().equals("before_init")) {
/*     */       
/* 121 */       if (!(event.getLifecycle() instanceof Server)) {
/* 122 */         log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCertificatesForRenewal(Server server) {
/* 130 */     Calendar calendar = Calendar.getInstance();
/* 131 */     if (calendar.compareTo(this.nextCheck) > 0) {
/* 132 */       this.nextCheck.add(13, getCheckPeriod());
/*     */     } else {
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     calendar.add(5, getDaysBefore());
/*     */ 
/*     */     
/* 144 */     Service[] services = server.findServices();
/* 145 */     for (Service service : services) {
/* 146 */       Connector[] connectors = service.findConnectors();
/* 147 */       for (Connector connector : connectors) {
/* 148 */         SSLHostConfig[] sslHostConfigs = connector.findSslHostConfigs();
/* 149 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 150 */           if (!sslHostConfig.certificatesExpiringBefore(calendar.getTime()).isEmpty())
/*     */             
/*     */             try {
/*     */               
/* 154 */               connector.getProtocolHandler().addSslHostConfig(sslHostConfig, true);
/*     */ 
/*     */               
/* 157 */               Set<X509Certificate> expiringCertificates = sslHostConfig.certificatesExpiringBefore(calendar.getTime());
/* 158 */               log.info(sm.getString("tlsCertRenewalListener.reloadSuccess", new Object[] { connector, sslHostConfig
/* 159 */                       .getHostName() }));
/* 160 */               if (!expiringCertificates.isEmpty()) {
/* 161 */                 for (X509Certificate expiringCertificate : expiringCertificates) {
/* 162 */                   log.warn(sm.getString("tlsCertRenewalListener.notRenewed", new Object[] { connector, sslHostConfig
/* 163 */                           .getHostName(), expiringCertificate
/* 164 */                           .getSubjectX500Principal().getName(), this.dateFormat
/* 165 */                           .format(expiringCertificate.getNotAfter()) }));
/*     */                 } 
/*     */               }
/* 168 */             } catch (IllegalArgumentException iae) {
/* 169 */               log.error(sm.getString("tlsCertRenewalListener.reloadFailed", new Object[] { connector, sslHostConfig
/* 170 */                       .getHostName() }), iae);
/*     */             }  
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\TLSCertificateReloadListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */