/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.UnavailableException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.security.auth.Subject;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityUtil
/*     */ {
/*     */   private static final int INIT = 0;
/*     */   private static final int SERVICE = 1;
/*     */   private static final int DOFILTER = 1;
/*     */   private static final int EVENT = 2;
/*     */   private static final int DOFILTEREVENT = 2;
/*     */   private static final int DESTROY = 3;
/*     */   private static final String INIT_METHOD = "init";
/*     */   private static final String DOFILTER_METHOD = "doFilter";
/*     */   private static final String SERVICE_METHOD = "service";
/*     */   private static final String EVENT_METHOD = "event";
/*     */   private static final String DOFILTEREVENT_METHOD = "doFilterEvent";
/*     */   private static final String DESTROY_METHOD = "destroy";
/*  73 */   private static final Map<Class<?>, Method[]> classCache = (Map)new ConcurrentHashMap<>();
/*     */   
/*  75 */   private static final Log log = LogFactory.getLog(SecurityUtil.class);
/*     */ 
/*     */   
/*  78 */   private static final boolean packageDefinitionEnabled = !(System.getProperty("package.definition") == null && System.getProperty("package.access") == null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.security");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doAsPrivilege(String methodName, Servlet targetObject) throws Exception {
/*  96 */     doAsPrivilege(methodName, targetObject, (Class<?>[])null, (Object[])null, (Principal)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doAsPrivilege(String methodName, Servlet targetObject, Class<?>[] targetType, Object[] targetArguments) throws Exception {
/* 113 */     doAsPrivilege(methodName, targetObject, targetType, targetArguments, (Principal)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doAsPrivilege(String methodName, Servlet targetObject, Class<?>[] targetParameterTypes, Object[] targetArguments, Principal principal) throws Exception {
/* 132 */     Method method = null;
/* 133 */     Method[] methodsCache = classCache.get(Servlet.class);
/* 134 */     if (methodsCache == null) {
/* 135 */       method = createMethodAndCacheIt(null, Servlet.class, methodName, targetParameterTypes);
/*     */     } else {
/* 137 */       method = findMethod(methodsCache, methodName);
/* 138 */       if (method == null) {
/* 139 */         method = createMethodAndCacheIt(methodsCache, Servlet.class, methodName, targetParameterTypes);
/*     */       }
/*     */     } 
/*     */     
/* 143 */     execute(method, targetObject, targetArguments, principal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doAsPrivilege(String methodName, Filter targetObject) throws Exception {
/* 157 */     doAsPrivilege(methodName, targetObject, (Class<?>[])null, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doAsPrivilege(String methodName, Filter targetObject, Class<?>[] targetType, Object[] targetArguments) throws Exception {
/* 174 */     doAsPrivilege(methodName, targetObject, targetType, targetArguments, (Principal)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doAsPrivilege(String methodName, Filter targetObject, Class<?>[] targetParameterTypes, Object[] targetParameterValues, Principal principal) throws Exception {
/* 192 */     Method method = null;
/* 193 */     Method[] methodsCache = classCache.get(Filter.class);
/* 194 */     if (methodsCache == null) {
/* 195 */       method = createMethodAndCacheIt(null, Filter.class, methodName, targetParameterTypes);
/*     */     } else {
/* 197 */       method = findMethod(methodsCache, methodName);
/* 198 */       if (method == null) {
/* 199 */         method = createMethodAndCacheIt(methodsCache, Filter.class, methodName, targetParameterTypes);
/*     */       }
/*     */     } 
/*     */     
/* 203 */     execute(method, targetObject, targetParameterValues, principal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void execute(Method method, Object targetObject, Object[] targetArguments, Principal principal) throws Exception {
/*     */     try {
/* 222 */       Subject subject = null;
/* 223 */       PrivilegedExceptionAction<Void> pea = () -> {
/*     */           method.invoke(targetObject, targetArguments);
/*     */           
/*     */           return null;
/*     */         };
/*     */       
/* 229 */       if (targetArguments != null && targetArguments[0] instanceof HttpServletRequest) {
/* 230 */         HttpServletRequest request = (HttpServletRequest)targetArguments[0];
/*     */         
/* 232 */         boolean hasSubject = false;
/* 233 */         HttpSession session = request.getSession(false);
/* 234 */         if (session != null) {
/* 235 */           subject = (Subject)session.getAttribute("javax.security.auth.subject");
/* 236 */           hasSubject = (subject != null);
/*     */         } 
/*     */         
/* 239 */         if (subject == null) {
/* 240 */           subject = new Subject();
/*     */           
/* 242 */           if (principal != null) {
/* 243 */             subject.getPrincipals().add(principal);
/*     */           }
/*     */         } 
/*     */         
/* 247 */         if (session != null && !hasSubject) {
/* 248 */           session.setAttribute("javax.security.auth.subject", subject);
/*     */         }
/*     */       } 
/*     */       
/* 252 */       Subject.doAsPrivileged(subject, pea, (AccessControlContext)null);
/* 253 */     } catch (PrivilegedActionException pe) {
/*     */       Throwable e;
/* 255 */       if (pe.getException() instanceof java.lang.reflect.InvocationTargetException) {
/* 256 */         e = pe.getException().getCause();
/* 257 */         ExceptionUtils.handleThrowable(e);
/*     */       } else {
/* 259 */         e = pe;
/*     */       } 
/*     */       
/* 262 */       if (log.isDebugEnabled()) {
/* 263 */         log.debug(sm.getString("SecurityUtil.doAsPrivilege"), e);
/*     */       }
/*     */       
/* 266 */       if (e instanceof UnavailableException)
/* 267 */         throw (UnavailableException)e; 
/* 268 */       if (e instanceof ServletException)
/* 269 */         throw (ServletException)e; 
/* 270 */       if (e instanceof IOException)
/* 271 */         throw (IOException)e; 
/* 272 */       if (e instanceof RuntimeException) {
/* 273 */         throw (RuntimeException)e;
/*     */       }
/* 275 */       throw new ServletException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method findMethod(Method[] methodsCache, String methodName) {
/* 290 */     if (methodName.equals("init"))
/* 291 */       return methodsCache[0]; 
/* 292 */     if (methodName.equals("destroy"))
/* 293 */       return methodsCache[3]; 
/* 294 */     if (methodName.equals("service"))
/* 295 */       return methodsCache[1]; 
/* 296 */     if (methodName.equals("doFilter"))
/* 297 */       return methodsCache[1]; 
/* 298 */     if (methodName.equals("event"))
/* 299 */       return methodsCache[2]; 
/* 300 */     if (methodName.equals("doFilterEvent")) {
/* 301 */       return methodsCache[2];
/*     */     }
/* 303 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method createMethodAndCacheIt(Method[] methodsCache, Class<?> targetType, String methodName, Class<?>[] parameterTypes) throws Exception {
/* 322 */     if (methodsCache == null) {
/* 323 */       methodsCache = new Method[4];
/*     */     }
/*     */     
/* 326 */     Method method = targetType.getMethod(methodName, parameterTypes);
/*     */     
/* 328 */     if (methodName.equals("init")) {
/* 329 */       methodsCache[0] = method;
/* 330 */     } else if (methodName.equals("destroy")) {
/* 331 */       methodsCache[3] = method;
/* 332 */     } else if (methodName.equals("service")) {
/* 333 */       methodsCache[1] = method;
/* 334 */     } else if (methodName.equals("doFilter")) {
/* 335 */       methodsCache[1] = method;
/* 336 */     } else if (methodName.equals("event")) {
/* 337 */       methodsCache[2] = method;
/* 338 */     } else if (methodName.equals("doFilterEvent")) {
/* 339 */       methodsCache[2] = method;
/*     */     } 
/*     */     
/* 342 */     classCache.put(targetType, methodsCache);
/*     */     
/* 344 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(Object cachedObject) {
/* 354 */     classCache.remove(cachedObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPackageProtectionEnabled() {
/* 364 */     if (packageDefinitionEnabled && Globals.IS_SECURITY_ENABLED) {
/* 365 */       return true;
/*     */     }
/* 367 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\SecurityUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */