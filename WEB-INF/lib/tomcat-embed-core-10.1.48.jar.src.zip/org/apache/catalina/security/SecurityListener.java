/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityListener
/*     */   implements LifecycleListener
/*     */ {
/*  42 */   private static final Log log = LogFactory.getLog(SecurityListener.class);
/*     */   
/*  44 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.security");
/*     */ 
/*     */   
/*     */   private static final String UMASK_PROPERTY_NAME = "org.apache.catalina.security.SecurityListener.UMASK";
/*     */ 
/*     */   
/*     */   private static final String UMASK_FORMAT = "%04o";
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_BUILD_DATE_WARNING_AGE_DAYS = -1;
/*     */   
/*  55 */   private final Set<String> checkedOsUsers = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int buildDateWarningAgeDays = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private Integer minimumUmask = Integer.valueOf(7);
/*     */ 
/*     */   
/*     */   public SecurityListener() {
/*  70 */     this.checkedOsUsers.add("root");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*  77 */     if (event.getType().equals("before_init")) {
/*  78 */       if (!(event.getLifecycle() instanceof org.apache.catalina.Server)) {
/*  79 */         log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */       }
/*  81 */       doChecks();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckedOsUsers(String userNameList) {
/*  95 */     if (userNameList == null || userNameList.isEmpty()) {
/*  96 */       this.checkedOsUsers.clear();
/*     */     } else {
/*  98 */       String[] userNames = userNameList.split(",");
/*  99 */       for (String userName : userNames) {
/* 100 */         if (!userName.isEmpty()) {
/* 101 */           this.checkedOsUsers.add(userName.toLowerCase(Locale.getDefault()));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCheckedOsUsers() {
/* 114 */     return StringUtils.join(this.checkedOsUsers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinimumUmask(String umask) {
/* 124 */     if (umask == null || umask.isEmpty()) {
/* 125 */       this.minimumUmask = Integer.valueOf(0);
/*     */     } else {
/* 127 */       this.minimumUmask = Integer.valueOf(umask, 8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMinimumUmask() {
/* 138 */     return String.format("%04o", new Object[] { this.minimumUmask });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuildDateWarningAgeDays(String ageDays) {
/*     */     try {
/* 148 */       this.buildDateWarningAgeDays = Integer.parseInt(ageDays);
/* 149 */     } catch (NumberFormatException nfe) {
/*     */       
/* 151 */       log.warn(sm.getString("SecurityListener.buildDateAgeUnreadable", new Object[] { ageDays, 
/* 152 */               String.valueOf(-1) }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBuildDateWarningAgeDays() {
/* 162 */     return this.buildDateWarningAgeDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doChecks() {
/* 169 */     checkOsUser();
/* 170 */     checkUmask();
/* 171 */     checkServerBuildAge();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkOsUser() {
/* 176 */     String userName = System.getProperty("user.name");
/* 177 */     if (userName != null) {
/* 178 */       String userNameLC = userName.toLowerCase(Locale.getDefault());
/*     */       
/* 180 */       if (this.checkedOsUsers.contains(userNameLC))
/*     */       {
/* 182 */         throw new Error(sm.getString("SecurityListener.checkUserWarning", new Object[] { userName }));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkUmask() {
/* 189 */     String prop = System.getProperty("org.apache.catalina.security.SecurityListener.UMASK");
/* 190 */     Integer umask = null;
/* 191 */     if (prop != null) {
/*     */       try {
/* 193 */         umask = Integer.valueOf(prop, 8);
/* 194 */       } catch (NumberFormatException nfe) {
/* 195 */         log.warn(sm.getString("SecurityListener.checkUmaskParseFail", new Object[] { prop }));
/*     */       } 
/*     */     }
/* 198 */     if (umask == null) {
/* 199 */       if ("\r\n".equals(System.lineSeparator())) {
/*     */         
/* 201 */         if (log.isDebugEnabled()) {
/* 202 */           log.debug(sm.getString("SecurityListener.checkUmaskSkip"));
/*     */         }
/*     */       }
/* 205 */       else if (this.minimumUmask.intValue() > 0) {
/* 206 */         log.warn(sm.getString("SecurityListener.checkUmaskNone", new Object[] { "org.apache.catalina.security.SecurityListener.UMASK", getMinimumUmask() }));
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 212 */     if ((umask.intValue() & this.minimumUmask.intValue()) != this.minimumUmask.intValue()) {
/* 213 */       throw new Error(sm.getString("SecurityListener.checkUmaskFail", new Object[] { String.format("%04o", new Object[] { umask
/* 214 */                 }), getMinimumUmask() }));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void checkServerBuildAge() {
/* 219 */     int allowedAgeDays = getBuildDateWarningAgeDays();
/*     */     
/* 221 */     if (allowedAgeDays >= 0) {
/* 222 */       String buildDateString = ServerInfo.getServerBuiltISO();
/*     */       
/* 224 */       if (null == buildDateString || buildDateString.isEmpty() || !Character.isDigit(buildDateString.charAt(0))) {
/* 225 */         log.warn(sm.getString("SecurityListener.buildDateUnreadable", new Object[] { buildDateString }));
/*     */       } else {
/*     */         try {
/* 228 */           Date buildDate = (new SimpleDateFormat("yyyy-MM-dd")).parse(buildDateString);
/*     */           
/* 230 */           Calendar old = Calendar.getInstance();
/* 231 */           old.add(5, -allowedAgeDays);
/*     */           
/* 233 */           if (buildDate.before(old.getTime())) {
/* 234 */             log.warn(sm.getString("SecurityListener.buildDateIsOld", new Object[] { String.valueOf(allowedAgeDays) }));
/*     */           }
/* 236 */         } catch (ParseException pe) {
/* 237 */           log.warn(sm.getString("SecurityListener.buildDateUnreadable", new Object[] { buildDateString }));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\SecurityListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */