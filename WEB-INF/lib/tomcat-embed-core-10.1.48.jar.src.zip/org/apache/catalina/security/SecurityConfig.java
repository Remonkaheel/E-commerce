/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import java.security.Security;
/*     */ import org.apache.catalina.startup.CatalinaProperties;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityConfig
/*     */ {
/*  30 */   private static final Object singletonLock = new Object();
/*  31 */   private static volatile SecurityConfig singleton = null;
/*     */   
/*  33 */   private static final Log log = LogFactory.getLog(SecurityConfig.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PACKAGE_ACCESS = "sun.,org.apache.catalina.,org.apache.jasper.,org.apache.coyote.,org.apache.tomcat.";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PACKAGE_DEFINITION = "java.,sun.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat.,org.apache.jasper.";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String packageDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String packageAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityConfig() {
/*  59 */     String definition = null;
/*  60 */     String access = null;
/*     */     try {
/*  62 */       definition = CatalinaProperties.getProperty("package.definition");
/*  63 */       access = CatalinaProperties.getProperty("package.access");
/*  64 */     } catch (Exception ex) {
/*  65 */       if (log.isDebugEnabled()) {
/*  66 */         log.debug("Unable to load properties using CatalinaProperties", ex);
/*     */       }
/*     */     } finally {
/*  69 */       this.packageDefinition = definition;
/*  70 */       this.packageAccess = access;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityConfig newInstance() {
/*  81 */     if (singleton == null) {
/*  82 */       synchronized (singletonLock) {
/*  83 */         if (singleton == null) {
/*  84 */           singleton = new SecurityConfig();
/*     */         }
/*     */       } 
/*     */     }
/*  88 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackageAccess() {
/*  97 */     if (this.packageAccess == null) {
/*  98 */       setSecurityProperty("package.access", "sun.,org.apache.catalina.,org.apache.jasper.,org.apache.coyote.,org.apache.tomcat.");
/*     */     } else {
/* 100 */       setSecurityProperty("package.access", this.packageAccess);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackageDefinition() {
/* 110 */     if (this.packageDefinition == null) {
/* 111 */       setSecurityProperty("package.definition", "java.,sun.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat.,org.apache.jasper.");
/*     */     } else {
/* 113 */       setSecurityProperty("package.definition", this.packageDefinition);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSecurityProperty(String properties, String packageList) {
/* 124 */     if (System.getSecurityManager() != null) {
/* 125 */       String definition = Security.getProperty(properties);
/* 126 */       if (definition != null && definition.length() > 0) {
/* 127 */         if (packageList.length() > 0) {
/* 128 */           definition = definition + "," + definition;
/*     */         }
/*     */       } else {
/* 131 */         definition = packageList;
/*     */       } 
/*     */       
/* 134 */       Security.setProperty(properties, definition);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\SecurityConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */