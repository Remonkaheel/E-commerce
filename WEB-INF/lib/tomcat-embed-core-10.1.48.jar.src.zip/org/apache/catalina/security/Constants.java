package org.apache.catalina.security;

public class Constants {
  public static final String PACKAGE = "org.apache.catalina.security";
  
  public static final String CRLF = "\r\n";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\Constants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */