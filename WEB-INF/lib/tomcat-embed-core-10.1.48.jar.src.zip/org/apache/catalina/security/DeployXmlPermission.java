/*    */ package org.apache.catalina.security;
/*    */ 
/*    */ import java.security.BasicPermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeployXmlPermission
/*    */   extends BasicPermission
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DeployXmlPermission(String name) {
/* 31 */     super(name);
/*    */   }
/*    */   
/*    */   public DeployXmlPermission(String name, String actions) {
/* 35 */     super(name, actions);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\DeployXmlPermission.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */