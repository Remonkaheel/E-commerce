/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityClassLoad
/*     */ {
/*     */   public static void securityClassLoad(ClassLoader loader) throws Exception {
/*  26 */     securityClassLoad(loader, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void securityClassLoad(ClassLoader loader, boolean requireSecurityManager) throws Exception {
/*  32 */     if (requireSecurityManager && System.getSecurityManager() == null) {
/*     */       return;
/*     */     }
/*     */     
/*  36 */     loadCorePackage(loader);
/*  37 */     loadCoyotePackage(loader);
/*  38 */     loadLoaderPackage(loader);
/*  39 */     loadRealmPackage(loader);
/*  40 */     loadServletsPackage(loader);
/*  41 */     loadSessionPackage(loader);
/*  42 */     loadUtilPackage(loader);
/*  43 */     loadJakartaPackage(loader);
/*  44 */     loadConnectorPackage(loader);
/*  45 */     loadTomcatPackage(loader);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadCorePackage(ClassLoader loader) throws Exception {
/*  50 */     String basePackage = "org.apache.catalina.core.";
/*  51 */     loader.loadClass("org.apache.catalina.core.AccessLogAdapter");
/*  52 */     loader.loadClass("org.apache.catalina.core.ApplicationContextFacade$PrivilegedExecuteMethod");
/*  53 */     loader.loadClass("org.apache.catalina.core.ApplicationDispatcher$PrivilegedForward");
/*  54 */     loader.loadClass("org.apache.catalina.core.ApplicationDispatcher$PrivilegedInclude");
/*  55 */     loader.loadClass("org.apache.catalina.core.ApplicationPushBuilder");
/*  56 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl");
/*  57 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl$AsyncRunnable");
/*  58 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl$DebugException");
/*  59 */     loader.loadClass("org.apache.catalina.core.AsyncListenerWrapper");
/*  60 */     loader.loadClass("org.apache.catalina.core.ContainerBase$PrivilegedAddChild");
/*  61 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$AnnotationCacheEntry");
/*  62 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$AnnotationCacheEntryType");
/*  63 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$PrivilegedGetField");
/*  64 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$PrivilegedGetMethod");
/*  65 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$PrivilegedLoadClass");
/*  66 */     loader.loadClass("org.apache.catalina.core.ApplicationHttpRequest$AttributeNamesEnumerator");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadLoaderPackage(ClassLoader loader) throws Exception {
/*  71 */     String basePackage = "org.apache.catalina.loader.";
/*  72 */     loader.loadClass("org.apache.catalina.loader.WebappClassLoaderBase$PrivilegedFindClassByName");
/*  73 */     loader.loadClass("org.apache.catalina.loader.WebappClassLoaderBase$PrivilegedHasLoggingConfig");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadRealmPackage(ClassLoader loader) throws Exception {
/*  78 */     String basePackage = "org.apache.catalina.realm.";
/*  79 */     loader.loadClass("org.apache.catalina.realm.LockOutRealm$LockRecord");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadServletsPackage(ClassLoader loader) throws Exception {
/*  84 */     String basePackage = "org.apache.catalina.servlets.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     loader.loadClass("org.apache.catalina.servlets.DefaultServlet");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadSessionPackage(ClassLoader loader) throws Exception {
/*  95 */     String basePackage = "org.apache.catalina.session.";
/*  96 */     loader.loadClass("org.apache.catalina.session.StandardSession");
/*  97 */     loader.loadClass("org.apache.catalina.session.StandardSession$PrivilegedNewSessionFacade");
/*  98 */     loader.loadClass("org.apache.catalina.session.StandardManager$PrivilegedDoUnload");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadUtilPackage(ClassLoader loader) throws Exception {
/* 103 */     String basePackage = "org.apache.catalina.util.";
/* 104 */     loader.loadClass("org.apache.catalina.util.ParameterMap");
/* 105 */     loader.loadClass("org.apache.catalina.util.RequestUtil");
/* 106 */     loader.loadClass("org.apache.catalina.util.TLSUtil");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadCoyotePackage(ClassLoader loader) throws Exception {
/* 111 */     String basePackage = "org.apache.coyote.";
/* 112 */     loader.loadClass("org.apache.coyote.http11.Constants");
/*     */     
/* 114 */     Class<?> clazz = loader.loadClass("org.apache.coyote.Constants");
/* 115 */     clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 116 */     loader.loadClass("org.apache.coyote.http2.Stream$PrivilegedPush");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadJakartaPackage(ClassLoader loader) throws Exception {
/* 121 */     loader.loadClass("jakarta.servlet.http.Cookie");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadConnectorPackage(ClassLoader loader) throws Exception {
/* 126 */     String basePackage = "org.apache.catalina.connector.";
/* 127 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetAttributePrivilegedAction");
/* 128 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterMapPrivilegedAction");
/* 129 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetRequestDispatcherPrivilegedAction");
/* 130 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterPrivilegedAction");
/* 131 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterNamesPrivilegedAction");
/* 132 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterValuePrivilegedAction");
/* 133 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetCharacterEncodingPrivilegedAction");
/* 134 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetHeadersPrivilegedAction");
/* 135 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetHeaderNamesPrivilegedAction");
/* 136 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetCookiesPrivilegedAction");
/* 137 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetLocalePrivilegedAction");
/* 138 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetLocalesPrivilegedAction");
/* 139 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$SetContentTypePrivilegedAction");
/* 140 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$DateHeaderPrivilegedAction");
/* 141 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetSessionPrivilegedAction");
/* 142 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$FlushBufferPrivilegedAction");
/* 143 */     loader.loadClass("org.apache.catalina.connector.OutputBuffer$PrivilegedCreateConverter");
/* 144 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedAvailable");
/* 145 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedClose");
/* 146 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedRead");
/* 147 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedReadArray");
/* 148 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedReadBuffer");
/* 149 */     loader.loadClass("org.apache.catalina.connector.CoyoteOutputStream");
/* 150 */     loader.loadClass("org.apache.catalina.connector.InputBuffer$PrivilegedCreateConverter");
/* 151 */     loader.loadClass("org.apache.catalina.connector.Response$PrivilegedDoIsEncodable");
/* 152 */     loader.loadClass("org.apache.catalina.connector.Response$PrivilegedGenerateCookieString");
/* 153 */     loader.loadClass("org.apache.catalina.connector.Response$PrivilegedEncodeUrl");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadTomcatPackage(ClassLoader loader) throws Exception {
/* 158 */     String basePackage = "org.apache.tomcat.";
/*     */     
/* 160 */     loader.loadClass("org.apache.tomcat.util.buf.B2CConverter");
/* 161 */     loader.loadClass("org.apache.tomcat.util.buf.ByteBufferUtils");
/* 162 */     loader.loadClass("org.apache.tomcat.util.buf.C2BConverter");
/* 163 */     loader.loadClass("org.apache.tomcat.util.buf.HexUtils");
/* 164 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache");
/* 165 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache$ByteEntry");
/* 166 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache$CharEntry");
/* 167 */     loader.loadClass("org.apache.tomcat.util.buf.UriUtil");
/*     */     
/* 169 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap");
/* 170 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntryImpl");
/* 171 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntryIterator");
/* 172 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntrySet");
/* 173 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$Key");
/*     */     
/* 175 */     loader.loadClass("org.apache.tomcat.util.http.CookieProcessor");
/* 176 */     loader.loadClass("org.apache.tomcat.util.http.NamesEnumerator");
/*     */     
/* 178 */     Class<?> clazz = loader.loadClass("org.apache.tomcat.util.http.FastHttpDateFormat");
/* 179 */     clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 180 */     loader.loadClass("org.apache.tomcat.util.http.parser.HttpParser");
/* 181 */     loader.loadClass("org.apache.tomcat.util.http.parser.MediaType");
/* 182 */     loader.loadClass("org.apache.tomcat.util.http.parser.MediaTypeCache");
/* 183 */     loader.loadClass("org.apache.tomcat.util.http.parser.SkipResult");
/*     */     
/* 185 */     loader.loadClass("org.apache.tomcat.util.net.Constants");
/* 186 */     loader.loadClass("org.apache.tomcat.util.net.DispatchType");
/* 187 */     loader.loadClass("org.apache.tomcat.util.net.NioEndpoint$NioSocketWrapper$NioOperationState");
/* 188 */     loader.loadClass("org.apache.tomcat.util.net.Nio2Endpoint$Nio2SocketWrapper$Nio2OperationState");
/* 189 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$BlockingMode");
/* 190 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$CompletionCheck");
/* 191 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$CompletionHandlerCall");
/* 192 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$CompletionState");
/* 193 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$VectoredIOCompletionHandler");
/* 194 */     loader.loadClass("org.apache.tomcat.util.net.TLSClientHelloExtractor");
/* 195 */     loader.loadClass("org.apache.tomcat.util.net.TLSClientHelloExtractor$ExtractorResult");
/*     */     
/* 197 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedGetTccl");
/* 198 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedSetTccl");
/* 199 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedSetAccessControlContext");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\security\SecurityClassLoad.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */