/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SemaphoreValve
/*     */   extends ValveBase
/*     */ {
/*     */   protected Semaphore semaphore;
/*     */   protected int concurrency;
/*     */   protected boolean fairness;
/*     */   protected boolean block;
/*     */   protected boolean interruptible;
/*     */   protected int highConcurrencyStatus;
/*     */   
/*     */   public SemaphoreValve() {
/*  43 */     super(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     this.semaphore = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.concurrency = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.fairness = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     this.block = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     this.interruptible = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this.highConcurrencyStatus = -1;
/*     */   }
/*     */   public int getConcurrency() { return this.concurrency; }
/* 120 */   public void setConcurrency(int concurrency) { this.concurrency = concurrency; } public boolean getFairness() { return this.fairness; } public void setFairness(boolean fairness) { this.fairness = fairness; } public int getHighConcurrencyStatus() { return this.highConcurrencyStatus; }
/*     */   public boolean getBlock() { return this.block; }
/*     */   public void setBlock(boolean block) { this.block = block; }
/*     */   public boolean getInterruptible() { return this.interruptible; }
/* 124 */   public void setInterruptible(boolean interruptible) { this.interruptible = interruptible; } public void setHighConcurrencyStatus(int highConcurrencyStatus) { this.highConcurrencyStatus = highConcurrencyStatus; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 137 */     this.semaphore = new Semaphore(this.concurrency, this.fairness);
/* 138 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 151 */     super.stopInternal();
/* 152 */     this.semaphore = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 170 */     if (controlConcurrency(request, response)) {
/* 171 */       boolean shouldRelease = true;
/*     */       try {
/* 173 */         if (this.block) {
/* 174 */           if (this.interruptible) {
/*     */             try {
/* 176 */               this.semaphore.acquire();
/* 177 */             } catch (InterruptedException e) {
/* 178 */               shouldRelease = false;
/* 179 */               permitDenied(request, response);
/*     */               return;
/*     */             } 
/*     */           } else {
/* 183 */             this.semaphore.acquireUninterruptibly();
/*     */           }
/*     */         
/* 186 */         } else if (!this.semaphore.tryAcquire()) {
/* 187 */           shouldRelease = false;
/* 188 */           permitDenied(request, response);
/*     */           
/*     */           return;
/*     */         } 
/* 192 */         getNext().invoke(request, response);
/*     */       } finally {
/* 194 */         if (shouldRelease) {
/* 195 */           this.semaphore.release();
/*     */         }
/*     */       } 
/*     */     } else {
/* 199 */       getNext().invoke(request, response);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean controlConcurrency(Request request, Response response) {
/* 214 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void permitDenied(Request request, Response response) throws IOException, ServletException {
/* 228 */     if (this.highConcurrencyStatus > 0)
/* 229 */       response.sendError(this.highConcurrencyStatus); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\SemaphoreValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */