/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.IOTools;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyErrorReportValve
/*     */   extends ErrorReportValve
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(ProxyErrorReportValve.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean useRedirect = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUseRedirect() {
/*  62 */     return this.useRedirect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseRedirect(boolean useRedirect) {
/*  69 */     this.useRedirect = useRedirect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean usePropertiesFile = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUsePropertiesFile() {
/*  81 */     return this.usePropertiesFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsePropertiesFile(boolean usePropertiesFile) {
/*  88 */     this.usePropertiesFile = usePropertiesFile;
/*     */   }
/*     */   
/*     */   private String getRedirectUrl(Response response) {
/*  92 */     ResourceBundle resourceBundle = ResourceBundle.getBundle(getClass().getSimpleName(), response.getLocale());
/*  93 */     String redirectUrl = null;
/*     */     try {
/*  95 */       redirectUrl = resourceBundle.getString(Integer.toString(response.getStatus()));
/*  96 */     } catch (MissingResourceException missingResourceException) {}
/*     */ 
/*     */     
/*  99 */     if (redirectUrl == null) {
/*     */       try {
/* 101 */         redirectUrl = resourceBundle.getString(Integer.toString(0));
/* 102 */       } catch (MissingResourceException missingResourceException) {}
/*     */     }
/*     */ 
/*     */     
/* 106 */     return redirectUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void report(Request request, Response response, Throwable throwable) {
/* 112 */     int statusCode = response.getStatus();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     if (statusCode < 400 || response.getContentWritten() > 0L) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 124 */     AtomicBoolean result = new AtomicBoolean(false);
/* 125 */     response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, result);
/* 126 */     if (!result.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 130 */     String urlString = null;
/* 131 */     if (this.usePropertiesFile) {
/* 132 */       urlString = getRedirectUrl(response);
/*     */     } else {
/* 134 */       ErrorPage errorPage = findErrorPage(statusCode, throwable);
/* 135 */       if (errorPage != null) {
/* 136 */         urlString = errorPage.getLocation();
/*     */       }
/*     */     } 
/* 139 */     if (urlString == null) {
/* 140 */       super.report(request, response, throwable);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 145 */     if (!response.setErrorReported()) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     StringBuilder stringBuilder = new StringBuilder(urlString);
/* 150 */     if (urlString.contains("?")) {
/* 151 */       stringBuilder.append('&');
/*     */     } else {
/* 153 */       stringBuilder.append('?');
/*     */     } 
/* 155 */     stringBuilder.append("requestUri=");
/* 156 */     stringBuilder.append(URLEncoder.encode(request.getDecodedRequestURI(), request.getConnector().getURICharset()));
/* 157 */     stringBuilder.append("&statusCode=");
/* 158 */     stringBuilder.append(URLEncoder.encode(String.valueOf(statusCode), StandardCharsets.UTF_8));
/*     */     
/* 160 */     String reason = null;
/* 161 */     String description = null;
/* 162 */     StringManager smClient = StringManager.getManager("org.apache.catalina.valves", request.getLocales());
/* 163 */     response.setLocale(smClient.getLocale());
/*     */     try {
/* 165 */       reason = smClient.getString("http." + statusCode + ".reason");
/* 166 */       description = smClient.getString("http." + statusCode + ".desc");
/* 167 */     } catch (Throwable t) {
/* 168 */       ExceptionUtils.handleThrowable(t);
/*     */     } 
/* 170 */     if (reason == null || description == null) {
/* 171 */       reason = smClient.getString("errorReportValve.unknownReason");
/* 172 */       description = smClient.getString("errorReportValve.noDescription");
/*     */     } 
/* 174 */     stringBuilder.append("&statusDescription=");
/* 175 */     stringBuilder.append(URLEncoder.encode(description, StandardCharsets.UTF_8));
/* 176 */     stringBuilder.append("&statusReason=");
/* 177 */     stringBuilder.append(URLEncoder.encode(reason, StandardCharsets.UTF_8));
/*     */     
/* 179 */     String message = response.getMessage();
/* 180 */     if (message != null) {
/* 181 */       stringBuilder.append("&message=");
/* 182 */       stringBuilder.append(URLEncoder.encode(message, StandardCharsets.UTF_8));
/*     */     } 
/* 184 */     if (throwable != null) {
/* 185 */       stringBuilder.append("&throwable=");
/* 186 */       stringBuilder.append(URLEncoder.encode(throwable.toString(), StandardCharsets.UTF_8));
/*     */     } 
/*     */     
/* 189 */     urlString = stringBuilder.toString();
/* 190 */     if (this.useRedirect) {
/* 191 */       if (log.isTraceEnabled()) {
/* 192 */         log.trace("Redirecting error reporting to " + urlString);
/*     */       }
/*     */       try {
/* 195 */         response.sendRedirect(urlString);
/* 196 */       } catch (IOException iOException) {}
/*     */     }
/*     */     else {
/*     */       
/* 200 */       if (log.isTraceEnabled()) {
/* 201 */         log.trace("Proxying error reporting to " + urlString);
/*     */       }
/* 203 */       HttpURLConnection httpURLConnection = null;
/*     */       try {
/* 205 */         URL url = (new URI(urlString)).toURL();
/* 206 */         httpURLConnection = (HttpURLConnection)url.openConnection();
/* 207 */         httpURLConnection.connect();
/* 208 */         response.setContentType(httpURLConnection.getContentType());
/* 209 */         response.setContentLength(httpURLConnection.getContentLength());
/* 210 */         ServletOutputStream servletOutputStream = response.getOutputStream();
/* 211 */         InputStream inputStream = url.openStream();
/* 212 */         IOTools.flow(inputStream, (OutputStream)servletOutputStream);
/* 213 */       } catch (URISyntaxException|IOException|IllegalArgumentException e) {
/* 214 */         if (log.isDebugEnabled()) {
/* 215 */           log.debug(sm.getString("proxyErrorReportValve.error", new Object[] { urlString }), e);
/*     */         }
/*     */       } finally {
/*     */         
/* 219 */         if (httpURLConnection != null)
/* 220 */           httpURLConnection.disconnect(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\ProxyErrorReportValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */