/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HealthCheckValve
/*     */   extends ValveBase
/*     */ {
/*     */   private static final String UP = "{\n  \"status\": \"UP\",\n  \"checks\": []\n}";
/*     */   private static final String DOWN = "{\n  \"status\": \"DOWN\",\n  \"checks\": []\n}";
/*  41 */   private String path = "/health";
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean context = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkContainersAvailable = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public HealthCheckValve() {
/*  54 */     super(true);
/*     */   }
/*     */   
/*     */   public final String getPath() {
/*  58 */     return this.path;
/*     */   }
/*     */   
/*     */   public final void setPath(String path) {
/*  62 */     this.path = path;
/*     */   }
/*     */   
/*     */   public boolean getCheckContainersAvailable() {
/*  66 */     return this.checkContainersAvailable;
/*     */   }
/*     */   
/*     */   public void setCheckContainersAvailable(boolean checkContainersAvailable) {
/*  70 */     this.checkContainersAvailable = checkContainersAvailable;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/*  75 */     super.startInternal();
/*  76 */     this.context = getContainer() instanceof org.apache.catalina.Context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*  81 */     MessageBytes urlMB = this.context ? request.getRequestPathMB() : request.getDecodedRequestURIMB();
/*  82 */     if (urlMB.equals(this.path)) {
/*  83 */       response.setContentType("application/json");
/*  84 */       if (!this.checkContainersAvailable || isAvailable(getContainer())) {
/*  85 */         response.getOutputStream().print("{\n  \"status\": \"UP\",\n  \"checks\": []\n}");
/*     */       } else {
/*  87 */         response.setStatus(503);
/*  88 */         response.getOutputStream().print("{\n  \"status\": \"DOWN\",\n  \"checks\": []\n}");
/*     */       } 
/*     */     } else {
/*  91 */       getNext().invoke(request, response);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean isAvailable(Container container) {
/*  96 */     for (Container child : container.findChildren()) {
/*  97 */       if (!isAvailable(child)) {
/*  98 */         return false;
/*     */       }
/*     */     } 
/* 101 */     return container.getState().isAvailable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\HealthCheckValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */