/*    */ package org.apache.catalina.valves.rewrite;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Random;
/*    */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*    */ import org.apache.tomcat.util.file.ConfigurationSource;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomizedTextRewriteMap
/*    */   implements RewriteMap
/*    */ {
/* 36 */   protected static final StringManager sm = StringManager.getManager(RandomizedTextRewriteMap.class);
/*    */   
/* 38 */   private static final Random random = new Random();
/* 39 */   private final Map<String, String[]> map = (Map)new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RandomizedTextRewriteMap(String txtFilePath, boolean useRandom) {
/*    */     
/* 49 */     try { ConfigurationSource.Resource txtResource = ConfigFileLoader.getSource().getResource(txtFilePath); 
/* 50 */       try { BufferedReader reader = new BufferedReader(new InputStreamReader(txtResource.getInputStream())); 
/* 51 */         try { String line; while ((line = reader.readLine()) != null) {
/* 52 */             if (line.startsWith("#") || line.isEmpty()) {
/*    */               continue;
/*    */             }
/* 55 */             if (line.indexOf('#') > 0)
/*    */             {
/* 57 */               line = line.substring(0, line.indexOf('#')).trim();
/*    */             }
/* 59 */             String[] keyValuePair = line.split(" ", 2);
/* 60 */             if (keyValuePair.length > 1) {
/* 61 */               String possibleValues[], key = keyValuePair[0];
/* 62 */               String value = keyValuePair[1];
/*    */               
/* 64 */               if (useRandom && value.contains("|")) {
/* 65 */                 possibleValues = value.split("\\|");
/*    */               } else {
/* 67 */                 possibleValues = new String[1];
/* 68 */                 possibleValues[0] = value;
/*    */               } 
/* 70 */               this.map.put(key, possibleValues); continue;
/*    */             } 
/* 72 */             throw new IllegalArgumentException(sm.getString("rewriteMap.txtInvalidLine", new Object[] { line, txtFilePath }));
/*    */           } 
/*    */           
/* 75 */           reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (txtResource != null) txtResource.close();  } catch (Throwable throwable) { if (txtResource != null) try { txtResource.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 76 */     { throw new IllegalArgumentException(sm.getString("rewriteMap.txtReadError", new Object[] { txtFilePath }), ioe); }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public String setParameters(String params) {
/* 82 */     throw new IllegalArgumentException(
/* 83 */         StringManager.getManager(RewriteMap.class).getString("rewriteMap.tooManyParameters"));
/*    */   }
/*    */ 
/*    */   
/*    */   public String lookup(String key) {
/* 88 */     String[] possibleValues = this.map.get(key);
/* 89 */     if (possibleValues != null) {
/* 90 */       if (possibleValues.length > 1) {
/* 91 */         return possibleValues[random.nextInt(possibleValues.length)];
/*    */       }
/* 93 */       return possibleValues[0];
/*    */     } 
/*    */     
/* 96 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\RandomizedTextRewriteMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */