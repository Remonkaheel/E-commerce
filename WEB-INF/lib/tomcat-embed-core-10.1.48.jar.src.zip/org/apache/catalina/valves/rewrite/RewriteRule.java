/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteRule
/*     */ {
/*  27 */   protected RewriteCond[] conditions = new RewriteCond[0];
/*     */   
/*  29 */   protected ThreadLocal<Pattern> pattern = new ThreadLocal<>();
/*  30 */   protected Substitution substitution = null;
/*     */   
/*  32 */   protected String patternString = null;
/*  33 */   protected String substitutionString = null;
/*  34 */   protected String flagsString = null;
/*     */   
/*     */   protected boolean positive = true;
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps) {
/*  39 */     if (!"-".equals(this.substitutionString)) {
/*  40 */       this.substitution = new Substitution();
/*  41 */       this.substitution.setSub(this.substitutionString);
/*  42 */       this.substitution.parse(maps);
/*  43 */       this.substitution.setEscapeBackReferences(isEscapeBackReferences());
/*     */     } 
/*     */     
/*  46 */     if (this.patternString.startsWith("!")) {
/*  47 */       this.positive = false;
/*  48 */       this.patternString = this.patternString.substring(1);
/*     */     } 
/*  50 */     int flags = 32;
/*  51 */     if (isNocase()) {
/*  52 */       flags |= 0x2;
/*     */     }
/*  54 */     Pattern.compile(this.patternString, flags);
/*     */     
/*  56 */     for (RewriteCond condition : this.conditions) {
/*  57 */       condition.parse(maps);
/*     */     }
/*     */     
/*  60 */     if (isEnv()) {
/*  61 */       for (String s : this.envValue) {
/*  62 */         Substitution newEnvSubstitution = new Substitution();
/*  63 */         newEnvSubstitution.setSub(s);
/*  64 */         newEnvSubstitution.parse(maps);
/*  65 */         this.envSubstitution.add(newEnvSubstitution);
/*  66 */         this.envResult.add(new ThreadLocal<>());
/*     */       } 
/*     */     }
/*  69 */     if (isCookie()) {
/*  70 */       this.cookieSubstitution = new Substitution();
/*  71 */       this.cookieSubstitution.setSub(this.cookieValue);
/*  72 */       this.cookieSubstitution.parse(maps);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addCondition(RewriteCond condition) {
/*  77 */     RewriteCond[] conditions = Arrays.<RewriteCond>copyOf(this.conditions, this.conditions.length + 1);
/*  78 */     conditions[this.conditions.length] = condition;
/*  79 */     this.conditions = conditions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharSequence evaluate(CharSequence url, Resolver resolver) {
/*  91 */     Pattern pattern = this.pattern.get();
/*  92 */     if (pattern == null) {
/*     */       
/*  94 */       int flags = 32;
/*  95 */       if (isNocase()) {
/*  96 */         flags |= 0x2;
/*     */       }
/*  98 */       pattern = Pattern.compile(this.patternString, flags);
/*  99 */       this.pattern.set(pattern);
/*     */     } 
/* 101 */     Matcher matcher = pattern.matcher(url);
/*     */     
/* 103 */     if ((this.positive ^ matcher.matches()) != 0)
/*     */     {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     boolean done = false;
/* 109 */     boolean rewrite = true;
/* 110 */     Matcher lastMatcher = null;
/* 111 */     int pos = 0;
/* 112 */     while (!done) {
/* 113 */       if (pos < this.conditions.length) {
/* 114 */         rewrite = this.conditions[pos].evaluate(matcher, lastMatcher, resolver);
/* 115 */         if (rewrite) {
/* 116 */           Matcher lastMatcher2 = this.conditions[pos].getMatcher();
/* 117 */           if (lastMatcher2 != null) {
/* 118 */             lastMatcher = lastMatcher2;
/*     */           }
/* 120 */           while (pos < this.conditions.length && this.conditions[pos].isOrnext()) {
/* 121 */             pos++;
/*     */           }
/* 123 */         } else if (!this.conditions[pos].isOrnext()) {
/* 124 */           done = true;
/*     */         } 
/* 126 */         pos++; continue;
/*     */       } 
/* 128 */       done = true;
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (rewrite) {
/* 133 */       if (isEnv()) {
/* 134 */         for (int i = 0; i < this.envSubstitution.size(); i++) {
/* 135 */           ((ThreadLocal<String>)this.envResult.get(i)).set(((Substitution)this.envSubstitution.get(i)).evaluate(matcher, lastMatcher, resolver));
/*     */         }
/*     */       }
/* 138 */       if (isCookie()) {
/* 139 */         this.cookieResult.set(this.cookieSubstitution.evaluate(matcher, lastMatcher, resolver));
/*     */       }
/* 141 */       if (this.substitution != null) {
/* 142 */         return this.substitution.evaluate(matcher, lastMatcher, resolver);
/*     */       }
/* 144 */       return url;
/*     */     } 
/*     */     
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     return "RewriteRule " + this.patternString + " " + this.substitutionString + (
/* 158 */       (this.flagsString != null) ? (" " + this.flagsString) : "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean escapeBackReferences = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean chain = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean cookie = false;
/*     */ 
/*     */ 
/*     */   
/* 179 */   protected String cookieName = null;
/* 180 */   protected String cookieValue = null;
/* 181 */   protected String cookieDomain = null;
/* 182 */   protected int cookieLifetime = -1;
/* 183 */   protected String cookiePath = null;
/*     */   protected boolean cookieSecure = false;
/*     */   protected boolean cookieHttpOnly = false;
/* 186 */   protected Substitution cookieSubstitution = null;
/* 187 */   protected ThreadLocal<String> cookieResult = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean env = false;
/*     */ 
/*     */   
/* 194 */   protected ArrayList<String> envName = new ArrayList<>();
/* 195 */   protected ArrayList<String> envValue = new ArrayList<>();
/* 196 */   protected ArrayList<Substitution> envSubstitution = new ArrayList<>();
/* 197 */   protected ArrayList<ThreadLocal<String>> envResult = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean forbidden = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean gone = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean host = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean last = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean next = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean nocase = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean noescape = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean nosubreq = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean qsappend = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean qsdiscard = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean redirect = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   protected int redirectCode = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   protected int skip = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean type = false;
/*     */ 
/*     */ 
/*     */   
/* 307 */   protected String typeValue = null;
/*     */ 
/*     */   
/*     */   protected boolean valveSkip = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEscapeBackReferences() {
/* 315 */     return this.escapeBackReferences;
/*     */   }
/*     */   
/*     */   public void setEscapeBackReferences(boolean escapeBackReferences) {
/* 319 */     this.escapeBackReferences = escapeBackReferences;
/*     */   }
/*     */   
/*     */   public boolean isChain() {
/* 323 */     return this.chain;
/*     */   }
/*     */   
/*     */   public void setChain(boolean chain) {
/* 327 */     this.chain = chain;
/*     */   }
/*     */   
/*     */   public RewriteCond[] getConditions() {
/* 331 */     return this.conditions;
/*     */   }
/*     */   
/*     */   public void setConditions(RewriteCond[] conditions) {
/* 335 */     this.conditions = conditions;
/*     */   }
/*     */   
/*     */   public boolean isCookie() {
/* 339 */     return this.cookie;
/*     */   }
/*     */   
/*     */   public void setCookie(boolean cookie) {
/* 343 */     this.cookie = cookie;
/*     */   }
/*     */   
/*     */   public String getCookieName() {
/* 347 */     return this.cookieName;
/*     */   }
/*     */   
/*     */   public void setCookieName(String cookieName) {
/* 351 */     this.cookieName = cookieName;
/*     */   }
/*     */   
/*     */   public String getCookieValue() {
/* 355 */     return this.cookieValue;
/*     */   }
/*     */   
/*     */   public void setCookieValue(String cookieValue) {
/* 359 */     this.cookieValue = cookieValue;
/*     */   }
/*     */   
/*     */   public String getCookieResult() {
/* 363 */     return this.cookieResult.get();
/*     */   }
/*     */   
/*     */   public boolean isEnv() {
/* 367 */     return this.env;
/*     */   }
/*     */   
/*     */   public int getEnvSize() {
/* 371 */     return this.envName.size();
/*     */   }
/*     */   
/*     */   public void setEnv(boolean env) {
/* 375 */     this.env = env;
/*     */   }
/*     */   
/*     */   public String getEnvName(int i) {
/* 379 */     return this.envName.get(i);
/*     */   }
/*     */   
/*     */   public void addEnvName(String envName) {
/* 383 */     this.envName.add(envName);
/*     */   }
/*     */   
/*     */   public String getEnvValue(int i) {
/* 387 */     return this.envValue.get(i);
/*     */   }
/*     */   
/*     */   public void addEnvValue(String envValue) {
/* 391 */     this.envValue.add(envValue);
/*     */   }
/*     */   
/*     */   public String getEnvResult(int i) {
/* 395 */     return ((ThreadLocal<String>)this.envResult.get(i)).get();
/*     */   }
/*     */   
/*     */   public boolean isForbidden() {
/* 399 */     return this.forbidden;
/*     */   }
/*     */   
/*     */   public void setForbidden(boolean forbidden) {
/* 403 */     this.forbidden = forbidden;
/*     */   }
/*     */   
/*     */   public boolean isGone() {
/* 407 */     return this.gone;
/*     */   }
/*     */   
/*     */   public void setGone(boolean gone) {
/* 411 */     this.gone = gone;
/*     */   }
/*     */   
/*     */   public boolean isLast() {
/* 415 */     return this.last;
/*     */   }
/*     */   
/*     */   public void setLast(boolean last) {
/* 419 */     this.last = last;
/*     */   }
/*     */   
/*     */   public boolean isNext() {
/* 423 */     return this.next;
/*     */   }
/*     */   
/*     */   public void setNext(boolean next) {
/* 427 */     this.next = next;
/*     */   }
/*     */   
/*     */   public boolean isNocase() {
/* 431 */     return this.nocase;
/*     */   }
/*     */   
/*     */   public void setNocase(boolean nocase) {
/* 435 */     this.nocase = nocase;
/*     */   }
/*     */   
/*     */   public boolean isNoescape() {
/* 439 */     return this.noescape;
/*     */   }
/*     */   
/*     */   public void setNoescape(boolean noescape) {
/* 443 */     this.noescape = noescape;
/*     */   }
/*     */   
/*     */   public boolean isNosubreq() {
/* 447 */     return this.nosubreq;
/*     */   }
/*     */   
/*     */   public void setNosubreq(boolean nosubreq) {
/* 451 */     this.nosubreq = nosubreq;
/*     */   }
/*     */   
/*     */   public boolean isQsappend() {
/* 455 */     return this.qsappend;
/*     */   }
/*     */   
/*     */   public void setQsappend(boolean qsappend) {
/* 459 */     this.qsappend = qsappend;
/*     */   }
/*     */   
/*     */   public final boolean isQsdiscard() {
/* 463 */     return this.qsdiscard;
/*     */   }
/*     */   
/*     */   public final void setQsdiscard(boolean qsdiscard) {
/* 467 */     this.qsdiscard = qsdiscard;
/*     */   }
/*     */   
/*     */   public boolean isRedirect() {
/* 471 */     return this.redirect;
/*     */   }
/*     */   
/*     */   public void setRedirect(boolean redirect) {
/* 475 */     this.redirect = redirect;
/*     */   }
/*     */   
/*     */   public int getRedirectCode() {
/* 479 */     return this.redirectCode;
/*     */   }
/*     */   
/*     */   public void setRedirectCode(int redirectCode) {
/* 483 */     this.redirectCode = redirectCode;
/*     */   }
/*     */   
/*     */   public int getSkip() {
/* 487 */     return this.skip;
/*     */   }
/*     */   
/*     */   public void setSkip(int skip) {
/* 491 */     this.skip = skip;
/*     */   }
/*     */   
/*     */   public Substitution getSubstitution() {
/* 495 */     return this.substitution;
/*     */   }
/*     */   
/*     */   public void setSubstitution(Substitution substitution) {
/* 499 */     this.substitution = substitution;
/*     */   }
/*     */   
/*     */   public boolean isType() {
/* 503 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(boolean type) {
/* 507 */     this.type = type;
/*     */   }
/*     */   
/*     */   public String getTypeValue() {
/* 511 */     return this.typeValue;
/*     */   }
/*     */   
/*     */   public void setTypeValue(String typeValue) {
/* 515 */     this.typeValue = typeValue;
/*     */   }
/*     */   
/*     */   public String getPatternString() {
/* 519 */     return this.patternString;
/*     */   }
/*     */   
/*     */   public void setPatternString(String patternString) {
/* 523 */     this.patternString = patternString;
/*     */   }
/*     */   
/*     */   public String getSubstitutionString() {
/* 527 */     return this.substitutionString;
/*     */   }
/*     */   
/*     */   public void setSubstitutionString(String substitutionString) {
/* 531 */     this.substitutionString = substitutionString;
/*     */   }
/*     */   
/*     */   public final String getFlagsString() {
/* 535 */     return this.flagsString;
/*     */   }
/*     */   
/*     */   public final void setFlagsString(String flagsString) {
/* 539 */     this.flagsString = flagsString;
/*     */   }
/*     */   
/*     */   public boolean isHost() {
/* 543 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(boolean host) {
/* 547 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getCookieDomain() {
/* 551 */     return this.cookieDomain;
/*     */   }
/*     */   
/*     */   public void setCookieDomain(String cookieDomain) {
/* 555 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */   
/*     */   public int getCookieLifetime() {
/* 559 */     return this.cookieLifetime;
/*     */   }
/*     */   
/*     */   public void setCookieLifetime(int cookieLifetime) {
/* 563 */     this.cookieLifetime = cookieLifetime;
/*     */   }
/*     */   
/*     */   public String getCookiePath() {
/* 567 */     return this.cookiePath;
/*     */   }
/*     */   
/*     */   public void setCookiePath(String cookiePath) {
/* 571 */     this.cookiePath = cookiePath;
/*     */   }
/*     */   
/*     */   public boolean isCookieSecure() {
/* 575 */     return this.cookieSecure;
/*     */   }
/*     */   
/*     */   public void setCookieSecure(boolean cookieSecure) {
/* 579 */     this.cookieSecure = cookieSecure;
/*     */   }
/*     */   
/*     */   public boolean isCookieHttpOnly() {
/* 583 */     return this.cookieHttpOnly;
/*     */   }
/*     */   
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly) {
/* 587 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */   
/*     */   public boolean isValveSkip() {
/* 591 */     return this.valveSkip;
/*     */   }
/*     */   
/*     */   public void setValveSkip(boolean valveSkip) {
/* 595 */     this.valveSkip = valveSkip;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\RewriteRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */