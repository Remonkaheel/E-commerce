/*    */ package org.apache.catalina.valves.rewrite;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Resolver
/*    */ {
/*    */   public abstract String resolve(String paramString);
/*    */   
/*    */   public String resolveEnv(String key) {
/* 29 */     return System.getProperty(key);
/*    */   }
/*    */   
/*    */   public abstract String resolveSsl(String paramString);
/*    */   
/*    */   public abstract String resolveHttp(String paramString);
/*    */   
/*    */   public abstract boolean resolveResource(int paramInt, String paramString);
/*    */   
/*    */   public abstract Charset getUriCharset();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\Resolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */