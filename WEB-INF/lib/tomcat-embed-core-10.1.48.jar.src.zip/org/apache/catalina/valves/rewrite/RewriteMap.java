/*    */ package org.apache.catalina.valves.rewrite;
/*    */ 
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RewriteMap
/*    */ {
/*    */   String setParameters(String paramString);
/*    */   
/*    */   void setParameters(String... params) {
/* 57 */     if (params == null) {
/*    */       return;
/*    */     }
/* 60 */     if (params.length > 1) {
/* 61 */       throw new IllegalArgumentException(
/* 62 */           StringManager.getManager(RewriteMap.class).getString("rewriteMap.tooManyParameters"));
/*    */     }
/* 64 */     setParameters(params[0]);
/*    */   }
/*    */   
/*    */   String lookup(String paramString);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\RewriteMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */