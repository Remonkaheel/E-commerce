/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*     */ import org.apache.tomcat.util.net.SSLSupport;
/*     */ import org.apache.tomcat.util.net.jsse.PEMFile;
/*     */ import org.apache.tomcat.util.net.openssl.ciphers.Cipher;
/*     */ import org.apache.tomcat.util.net.openssl.ciphers.EncryptionLevel;
/*     */ import org.apache.tomcat.util.net.openssl.ciphers.OpenSSLCipherConfigurationParser;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverImpl
/*     */   extends Resolver
/*     */ {
/*  48 */   private static final StringManager sm = StringManager.getManager(ResolverImpl.class);
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Request request;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Log containerLog;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ResolverImpl(Request request) {
/*  63 */     this(request, request.getContext().getLogger());
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolverImpl(Request request, Log containerLog) {
/*  68 */     this.request = request;
/*  69 */     this.containerLog = containerLog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String resolve(String key) {
/*  83 */     if (key.equals("HTTP_USER_AGENT"))
/*  84 */       return this.request.getHeader("user-agent"); 
/*  85 */     if (key.equals("HTTP_REFERER"))
/*  86 */       return this.request.getHeader("referer"); 
/*  87 */     if (key.equals("HTTP_COOKIE"))
/*  88 */       return this.request.getHeader("cookie"); 
/*  89 */     if (key.equals("HTTP_FORWARDED"))
/*  90 */       return this.request.getHeader("forwarded"); 
/*  91 */     if (key.equals("HTTP_HOST"))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  96 */       return this.request.getServerName(); } 
/*  97 */     if (key.equals("HTTP_PROXY_CONNECTION"))
/*  98 */       return this.request.getHeader("proxy-connection"); 
/*  99 */     if (key.equals("HTTP_ACCEPT"))
/* 100 */       return this.request.getHeader("accept"); 
/* 101 */     if (key.equals("REMOTE_ADDR"))
/* 102 */       return this.request.getRemoteAddr(); 
/* 103 */     if (key.equals("REMOTE_HOST"))
/* 104 */       return this.request.getRemoteHost(); 
/* 105 */     if (key.equals("REMOTE_PORT"))
/* 106 */       return String.valueOf(this.request.getRemotePort()); 
/* 107 */     if (key.equals("REMOTE_USER"))
/* 108 */       return this.request.getRemoteUser(); 
/* 109 */     if (key.equals("REMOTE_IDENT"))
/* 110 */       return this.request.getRemoteUser(); 
/* 111 */     if (key.equals("REQUEST_METHOD"))
/* 112 */       return this.request.getMethod(); 
/* 113 */     if (key.equals("SCRIPT_FILENAME"))
/* 114 */       return this.request.getServletContext().getRealPath(this.request.getServletPath()); 
/* 115 */     if (key.equals("REQUEST_PATH"))
/* 116 */       return this.request.getRequestPathMB().toString(); 
/* 117 */     if (key.equals("CONTEXT_PATH"))
/* 118 */       return this.request.getContextPath(); 
/* 119 */     if (key.equals("SERVLET_PATH"))
/* 120 */       return emptyStringIfNull(this.request.getServletPath()); 
/* 121 */     if (key.equals("PATH_INFO"))
/* 122 */       return emptyStringIfNull(this.request.getPathInfo()); 
/* 123 */     if (key.equals("QUERY_STRING"))
/* 124 */       return emptyStringIfNull(this.request.getQueryString()); 
/* 125 */     if (key.equals("AUTH_TYPE"))
/* 126 */       return this.request.getAuthType(); 
/* 127 */     if (key.equals("DOCUMENT_ROOT"))
/* 128 */       return this.request.getServletContext().getRealPath("/"); 
/* 129 */     if (key.equals("SERVER_NAME"))
/* 130 */       return this.request.getLocalName(); 
/* 131 */     if (key.equals("SERVER_ADDR"))
/* 132 */       return this.request.getLocalAddr(); 
/* 133 */     if (key.equals("SERVER_PORT"))
/* 134 */       return String.valueOf(this.request.getLocalPort()); 
/* 135 */     if (key.equals("SERVER_PROTOCOL"))
/* 136 */       return this.request.getProtocol(); 
/* 137 */     if (key.equals("SERVER_SOFTWARE"))
/* 138 */       return "tomcat"; 
/* 139 */     if (key.equals("THE_REQUEST"))
/* 140 */       return this.request.getMethod() + " " + this.request.getMethod() + " " + this.request.getRequestURI(); 
/* 141 */     if (key.equals("REQUEST_URI"))
/* 142 */       return this.request.getRequestURI(); 
/* 143 */     if (key.equals("REQUEST_FILENAME"))
/* 144 */       return this.request.getPathTranslated(); 
/* 145 */     if (key.equals("HTTPS"))
/* 146 */       return this.request.isSecure() ? "on" : "off"; 
/* 147 */     if (key.equals("TIME_YEAR"))
/* 148 */       return String.valueOf(Calendar.getInstance().get(1)); 
/* 149 */     if (key.equals("TIME_MON"))
/* 150 */       return String.valueOf(Calendar.getInstance().get(2)); 
/* 151 */     if (key.equals("TIME_DAY"))
/* 152 */       return String.valueOf(Calendar.getInstance().get(5)); 
/* 153 */     if (key.equals("TIME_HOUR"))
/* 154 */       return String.valueOf(Calendar.getInstance().get(11)); 
/* 155 */     if (key.equals("TIME_MIN"))
/* 156 */       return String.valueOf(Calendar.getInstance().get(12)); 
/* 157 */     if (key.equals("TIME_SEC"))
/* 158 */       return String.valueOf(Calendar.getInstance().get(13)); 
/* 159 */     if (key.equals("TIME_WDAY"))
/* 160 */       return String.valueOf(Calendar.getInstance().get(7)); 
/* 161 */     if (key.equals("TIME")) {
/* 162 */       return FastHttpDateFormat.getCurrentDate();
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String resolveEnv(String key) {
/* 169 */     Object result = this.request.getAttribute(key);
/* 170 */     return (result != null) ? result.toString() : System.getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String resolveSsl(String key) {
/* 175 */     SSLSupport sslSupport = (SSLSupport)this.request.getAttribute("jakarta.servlet.request.ssl_session_mgr");
/*     */ 
/*     */     
/*     */     try {
/* 179 */       if (key.equals("HTTPS"))
/* 180 */         return String.valueOf((sslSupport != null)); 
/* 181 */       if (key.equals("SSL_PROTOCOL"))
/* 182 */         return sslSupport.getProtocol(); 
/* 183 */       if (key.equals("SSL_SESSION_ID"))
/* 184 */         return sslSupport.getSessionId(); 
/* 185 */       if (!key.equals("SSL_SESSION_RESUMED"))
/*     */       {
/* 187 */         if (!key.equals("SSL_SECURE_RENEG"))
/*     */         {
/* 189 */           if (!key.equals("SSL_COMPRESS_METHOD"))
/*     */           {
/* 191 */             if (!key.equals("SSL_TLS_SNI")) {
/*     */               
/* 193 */               if (key.equals("SSL_CIPHER"))
/* 194 */                 return sslSupport.getCipherSuite(); 
/* 195 */               if (key.equals("SSL_CIPHER_EXPORT"))
/* 196 */               { String cipherSuite = sslSupport.getCipherSuite();
/* 197 */                 if (cipherSuite != null) {
/* 198 */                   Set<Cipher> cipherList = OpenSSLCipherConfigurationParser.parse(cipherSuite);
/* 199 */                   if (cipherList.size() == 1) {
/* 200 */                     Cipher cipher = cipherList.iterator().next();
/* 201 */                     if (cipher.getLevel().equals(EncryptionLevel.EXP40) || cipher
/* 202 */                       .getLevel().equals(EncryptionLevel.EXP56)) {
/* 203 */                       return "true";
/*     */                     }
/* 205 */                     return "false";
/*     */                   }
/*     */                 
/*     */                 }  }
/* 209 */               else if (key.equals("SSL_CIPHER_ALGKEYSIZE"))
/* 210 */               { String cipherSuite = sslSupport.getCipherSuite();
/* 211 */                 if (cipherSuite != null) {
/* 212 */                   Set<Cipher> cipherList = OpenSSLCipherConfigurationParser.parse(cipherSuite);
/* 213 */                   if (cipherList.size() == 1) {
/* 214 */                     Cipher cipher = cipherList.iterator().next();
/* 215 */                     return String.valueOf(cipher.getAlg_bits());
/*     */                   } 
/*     */                 }  }
/* 218 */               else { if (key.equals("SSL_CIPHER_USEKEYSIZE")) {
/* 219 */                   Integer keySize = sslSupport.getKeySize();
/* 220 */                   return (keySize == null) ? null : sslSupport.getKeySize().toString();
/* 221 */                 }  if (key.startsWith("SSL_CLIENT_")) {
/* 222 */                   X509Certificate[] certificates = sslSupport.getPeerCertificateChain();
/* 223 */                   if (certificates != null && certificates.length > 0) {
/* 224 */                     key = key.substring("SSL_CLIENT_".length());
/* 225 */                     String result = resolveSslCertificates(key, certificates);
/* 226 */                     if (result != null)
/* 227 */                       return result; 
/* 228 */                     if (key.startsWith("SAN_OTHER_msUPN_"))
/*     */                     {
/* 230 */                       key = key.substring("SAN_OTHER_msUPN_".length());
/*     */                     }
/* 232 */                     else if (!key.equals("CERT_RFC4523_CEA"))
/*     */                     {
/* 234 */                       if (key.equals("VERIFY"));
/*     */                     }
/*     */                   
/*     */                   } 
/* 238 */                 } else if (key.startsWith("SSL_SERVER_")) {
/* 239 */                   X509Certificate[] certificates = sslSupport.getLocalCertificateChain();
/* 240 */                   if (certificates != null && certificates.length > 0) {
/* 241 */                     key = key.substring("SSL_SERVER_".length());
/* 242 */                     String result = resolveSslCertificates(key, certificates);
/* 243 */                     if (result != null)
/* 244 */                       return result; 
/* 245 */                     if (key.startsWith("SAN_OTHER_dnsSRV_"))
/*     */                     {
/* 247 */                       key = key.substring("SAN_OTHER_dnsSRV_".length()); } 
/*     */                   } 
/*     */                 }  }
/*     */             
/*     */             }  }  }  } 
/* 252 */     } catch (IOException ioe) {
/*     */       
/* 254 */       if (this.containerLog.isDebugEnabled()) {
/* 255 */         this.containerLog.debug(sm.getString("resolverImpl.tlsError"), ioe);
/*     */       }
/*     */     } 
/* 258 */     return null;
/*     */   }
/*     */   
/*     */   private String resolveSslCertificates(String key, X509Certificate[] certificates) {
/* 262 */     if (key.equals("M_VERSION"))
/* 263 */       return String.valueOf(certificates[0].getVersion()); 
/* 264 */     if (key.equals("M_SERIAL"))
/* 265 */       return certificates[0].getSerialNumber().toString(); 
/* 266 */     if (key.equals("S_DN"))
/* 267 */       return certificates[0].getSubjectX500Principal().toString(); 
/* 268 */     if (key.startsWith("S_DN_")) {
/* 269 */       key = key.substring("S_DN_".length());
/* 270 */       return resolveComponent(certificates[0].getSubjectX500Principal().getName(), key);
/* 271 */     }  if (key.startsWith("SAN_Email_")) {
/*     */       
/* 273 */       key = key.substring("SAN_Email_".length());
/* 274 */       return resolveAlternateName(certificates[0], 1, Integer.parseInt(key));
/* 275 */     }  if (key.startsWith("SAN_DNS_")) {
/*     */       
/* 277 */       key = key.substring("SAN_DNS_".length());
/* 278 */       return resolveAlternateName(certificates[0], 2, Integer.parseInt(key));
/* 279 */     }  if (key.equals("I_DN"))
/* 280 */       return certificates[0].getIssuerX500Principal().getName(); 
/* 281 */     if (key.startsWith("I_DN_")) {
/* 282 */       key = key.substring("I_DN_".length());
/* 283 */       return resolveComponent(certificates[0].getIssuerX500Principal().toString(), key);
/* 284 */     }  if (key.equals("V_START"))
/* 285 */       return String.valueOf(certificates[0].getNotBefore().getTime()); 
/* 286 */     if (key.equals("V_END"))
/* 287 */       return String.valueOf(certificates[0].getNotAfter().getTime()); 
/* 288 */     if (key.equals("V_REMAIN")) {
/* 289 */       long remain = certificates[0].getNotAfter().getTime() - System.currentTimeMillis();
/* 290 */       if (remain < 0L) {
/* 291 */         remain = 0L;
/*     */       }
/*     */       
/* 294 */       return String.valueOf(TimeUnit.MILLISECONDS.toDays(remain));
/* 295 */     }  if (key.equals("A_SIG"))
/* 296 */       return certificates[0].getSigAlgName(); 
/* 297 */     if (key.equals("A_KEY"))
/* 298 */       return certificates[0].getPublicKey().getAlgorithm(); 
/* 299 */     if (key.equals("CERT")) {
/*     */       try {
/* 301 */         return PEMFile.toPEM(certificates[0]);
/* 302 */       } catch (CertificateEncodingException certificateEncodingException) {}
/*     */     
/*     */     }
/* 305 */     else if (key.startsWith("CERT_CHAIN_")) {
/* 306 */       key = key.substring("CERT_CHAIN_".length());
/*     */       try {
/* 308 */         return PEMFile.toPEM(certificates[Integer.parseInt(key)]);
/* 309 */       } catch (NumberFormatException|ArrayIndexOutOfBoundsException|CertificateEncodingException numberFormatException) {}
/*     */     } 
/*     */ 
/*     */     
/* 313 */     return null;
/*     */   }
/*     */   
/*     */   private String resolveComponent(String fullDN, String component) {
/* 317 */     HashMap<String, String> components = new HashMap<>();
/* 318 */     StringTokenizer tokenizer = new StringTokenizer(fullDN, ",");
/* 319 */     while (tokenizer.hasMoreElements()) {
/* 320 */       String token = tokenizer.nextToken().trim();
/* 321 */       int pos = token.indexOf('=');
/* 322 */       if (pos > 0 && pos + 1 < token.length()) {
/* 323 */         components.put(token.substring(0, pos), token.substring(pos + 1));
/*     */       }
/*     */     } 
/* 326 */     return components.get(component);
/*     */   }
/*     */   
/*     */   private String resolveAlternateName(X509Certificate certificate, int type, int n) {
/*     */     try {
/* 331 */       Collection<List<?>> alternateNames = certificate.getSubjectAlternativeNames();
/* 332 */       if (alternateNames != null) {
/* 333 */         List<String> elements = new ArrayList<>();
/* 334 */         for (List<?> alternateName : alternateNames) {
/* 335 */           Integer alternateNameType = (Integer)alternateName.get(0);
/* 336 */           if (alternateNameType.intValue() == type) {
/* 337 */             elements.add(String.valueOf(alternateName.get(1)));
/*     */           }
/*     */         } 
/* 340 */         if (elements.size() > n) {
/* 341 */           return elements.get(n);
/*     */         }
/*     */       } 
/* 344 */     } catch (NumberFormatException|ArrayIndexOutOfBoundsException|java.security.cert.CertificateParsingException numberFormatException) {}
/*     */ 
/*     */     
/* 347 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String resolveHttp(String key) {
/* 352 */     return Objects.<String>requireNonNullElse(this.request.getHeader(key), "");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean resolveResource(int type, String name) {
/* 357 */     WebResourceRoot resources = this.request.getContext().getResources();
/* 358 */     WebResource resource = resources.getResource(name);
/* 359 */     if (!resource.exists()) {
/* 360 */       return false;
/*     */     }
/* 362 */     switch (type) {
/*     */       case 0:
/* 364 */         return resource.isDirectory();
/*     */       case 1:
/* 366 */         return resource.isFile();
/*     */       case 2:
/* 368 */         return (resource.isFile() && resource.getContentLength() > 0L);
/*     */     } 
/* 370 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String emptyStringIfNull(String value) {
/* 376 */     return Objects.<String>requireNonNullElse(value, "");
/*     */   }
/*     */ 
/*     */   
/*     */   public Charset getUriCharset() {
/* 381 */     return this.request.getConnector().getURICharset();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\ResolverImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */