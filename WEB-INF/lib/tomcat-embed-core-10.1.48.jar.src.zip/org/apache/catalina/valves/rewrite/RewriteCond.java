/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteCond
/*     */ {
/*     */   public static abstract class Condition
/*     */   {
/*     */     public abstract boolean evaluate(String param1String, Resolver param1Resolver);
/*     */   }
/*     */   
/*     */   public static class PatternCondition
/*     */     extends Condition
/*     */   {
/*     */     public Pattern pattern;
/*  31 */     private final ThreadLocal<Matcher> matcher = new ThreadLocal<>();
/*     */ 
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver) {
/*  35 */       Matcher m = this.pattern.matcher(value);
/*  36 */       if (m.matches()) {
/*  37 */         this.matcher.set(m);
/*  38 */         return true;
/*     */       } 
/*  40 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Matcher getMatcher() {
/*  45 */       return this.matcher.get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LexicalCondition
/*     */     extends Condition
/*     */   {
/*  57 */     public int type = 0;
/*     */     
/*     */     public String condition;
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver) {
/*  62 */       int result = value.compareTo(this.condition);
/*  63 */       switch (this.type) {
/*     */         case -1:
/*  65 */           return (result < 0);
/*     */         case 0:
/*  67 */           return (result == 0);
/*     */         case 1:
/*  69 */           return (result > 0);
/*     */       } 
/*  71 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ResourceCondition
/*     */     extends Condition
/*     */   {
/*     */     public int type;
/*     */ 
/*     */ 
/*     */     
/*     */     public ResourceCondition() {
/*  85 */       this.type = 0;
/*     */     }
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver) {
/*  89 */       return resolver.resolveResource(this.type, value);
/*     */     }
/*     */   }
/*     */   
/*  93 */   protected String testString = null;
/*  94 */   protected String condPattern = null;
/*  95 */   protected String flagsString = null;
/*     */   
/*     */   public String getCondPattern() {
/*  98 */     return this.condPattern;
/*     */   }
/*     */   
/*     */   public void setCondPattern(String condPattern) {
/* 102 */     this.condPattern = condPattern;
/*     */   }
/*     */   
/*     */   public String getTestString() {
/* 106 */     return this.testString;
/*     */   }
/*     */   
/*     */   public void setTestString(String testString) {
/* 110 */     this.testString = testString;
/*     */   }
/*     */   
/*     */   public final String getFlagsString() {
/* 114 */     return this.flagsString;
/*     */   }
/*     */   
/*     */   public final void setFlagsString(String flagsString) {
/* 118 */     this.flagsString = flagsString;
/*     */   }
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps) {
/* 122 */     this.test = new Substitution();
/* 123 */     this.test.setSub(this.testString);
/* 124 */     this.test.parse(maps);
/* 125 */     if (this.condPattern.startsWith("!")) {
/* 126 */       this.positive = false;
/* 127 */       this.condPattern = this.condPattern.substring(1);
/*     */     } 
/* 129 */     if (this.condPattern.startsWith("<")) {
/* 130 */       LexicalCondition ncondition = new LexicalCondition();
/* 131 */       ncondition.type = -1;
/* 132 */       ncondition.condition = this.condPattern.substring(1);
/* 133 */       this.condition = ncondition;
/* 134 */     } else if (this.condPattern.startsWith(">")) {
/* 135 */       LexicalCondition ncondition = new LexicalCondition();
/* 136 */       ncondition.type = 1;
/* 137 */       ncondition.condition = this.condPattern.substring(1);
/* 138 */       this.condition = ncondition;
/* 139 */     } else if (this.condPattern.startsWith("=")) {
/* 140 */       LexicalCondition ncondition = new LexicalCondition();
/* 141 */       ncondition.type = 0;
/* 142 */       ncondition.condition = this.condPattern.substring(1);
/* 143 */       this.condition = ncondition;
/* 144 */     } else if (this.condPattern.equals("-d")) {
/* 145 */       ResourceCondition ncondition = new ResourceCondition();
/* 146 */       ncondition.type = 0;
/* 147 */       this.condition = ncondition;
/* 148 */     } else if (this.condPattern.equals("-f")) {
/* 149 */       ResourceCondition ncondition = new ResourceCondition();
/* 150 */       ncondition.type = 1;
/* 151 */       this.condition = ncondition;
/* 152 */     } else if (this.condPattern.equals("-s")) {
/* 153 */       ResourceCondition ncondition = new ResourceCondition();
/* 154 */       ncondition.type = 2;
/* 155 */       this.condition = ncondition;
/*     */     } else {
/* 157 */       PatternCondition ncondition = new PatternCondition();
/* 158 */       int flags = 32;
/* 159 */       if (isNocase()) {
/* 160 */         flags |= 0x2;
/*     */       }
/* 162 */       ncondition.pattern = Pattern.compile(this.condPattern, flags);
/* 163 */       this.condition = ncondition;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Matcher getMatcher() {
/* 168 */     if (this.condition instanceof PatternCondition) {
/* 169 */       return ((PatternCondition)this.condition).getMatcher();
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     return "RewriteCond " + this.testString + " " + this.condPattern + ((this.flagsString != null) ? (" " + this.flagsString) : "");
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean positive = true;
/*     */   
/* 182 */   protected Substitution test = null;
/*     */   
/* 184 */   protected Condition condition = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nocase = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ornext = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/* 208 */     String value = this.test.evaluate(rule, cond, resolver);
/* 209 */     if (this.positive) {
/* 210 */       return this.condition.evaluate(value, resolver);
/*     */     }
/* 212 */     return !this.condition.evaluate(value, resolver);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNocase() {
/* 217 */     return this.nocase;
/*     */   }
/*     */   
/*     */   public void setNocase(boolean nocase) {
/* 221 */     this.nocase = nocase;
/*     */   }
/*     */   
/*     */   public boolean isOrnext() {
/* 225 */     return this.ornext;
/*     */   }
/*     */   
/*     */   public void setOrnext(boolean ornext) {
/* 229 */     this.ornext = ornext;
/*     */   }
/*     */   
/*     */   public boolean isPositive() {
/* 233 */     return this.positive;
/*     */   }
/*     */   
/*     */   public void setPositive(boolean positive) {
/* 237 */     this.positive = positive;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\RewriteCond.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */